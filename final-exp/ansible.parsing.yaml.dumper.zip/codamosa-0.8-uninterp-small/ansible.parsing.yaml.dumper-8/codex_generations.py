

# Generated at 2022-06-25 04:32:04.204923
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    unicode_0 = AnsibleVaultEncryptedUnicode("abcde")
    var_0 = represent_vault_encrypted_unicode(dumper, unicode_0)


# Generated at 2022-06-25 04:32:06.778710
# Unit test for function represent_undefined
def test_represent_undefined():
    assert callable(represent_undefined)
    assert type(AnsibleUndefined) is type

# Generated at 2022-06-25 04:32:07.451107
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert("True")


# Generated at 2022-06-25 04:32:08.469949
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass # TODO: Implement tests for represent_hostvars


# Generated at 2022-06-25 04:32:10.650183
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_0 = AnsibleUnicode('/usr/libexec/pi-web-agent/toolkit/pi_web_agent_toolkit_main.py')
    var_0 = represent_unicode(unicode_0)


# Generated at 2022-06-25 04:32:12.305567
# Unit test for function represent_undefined
def test_represent_undefined():
    float_0 = 5328.518
    var_0 = represent_undefined(float_0)


# Generated at 2022-06-25 04:32:13.704186
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleUndefined(0) or AnsibleUndefined('0') or AnsibleUndefined() or AnsibleUndefined(None)

# Generated at 2022-06-25 04:32:17.352161
# Unit test for function represent_undefined
def test_represent_undefined():
    result = represent_undefined

    assert result == var_0
    assert result == float_0


# Generated at 2022-06-25 04:32:22.281293
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper = AnsibleDumper()
    data = b"\xc1\xbc\xd6\xbc"
    ansible_dumper.represent_binary(data)


# Generated at 2022-06-25 04:32:26.865129
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = 5328.518
    var_0 = represent_binary(float_0)


# Generated at 2022-06-25 04:32:38.645532
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n34393365363938306163353536333639616262666233376165623438353764373661326266613761\n63386239363161616564316333613137646265393933306364613335\n'
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-25 04:32:40.368282
# Unit test for function represent_binary
def test_represent_binary():
    data = AnsibleDumper.represent_binary(binary_type('test'))
    assert '!!binary' in data

# Generated at 2022-06-25 04:32:49.702325
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import VaultLib
    from ansible.parsing.vault import VaultSecret
    v = VaultLib([])
    s = VaultSecret('$ANSIBLE_VAULT;0.1;AES256')
    d = AnsibleVaultEncryptedUnicode(v, s, b'lalala')
    assert represent_vault_encrypted_unicode(None, d) == '!vault |\n' \
        '  $ANSIBLE_VAULT;0.1;AES256\n' \
        '  63313864356166323761633832623137623761623666613766626436333764396263666430316438\n' \
        '  66626562383233373537373065663361'



# Generated at 2022-06-25 04:32:57.553337
# Unit test for function represent_undefined
def test_represent_undefined():
    # Create an AnsibleUndefined object
    undefined = AnsibleUndefined()

    # Dump the undefined object
    dumped = yaml.dump(undefined, Dumper=AnsibleDumper)
    assert dumped == ''
    dumped = yaml.dump([undefined], Dumper=AnsibleDumper)
    assert dumped == '[]\n'
    dumped = yaml.dump([undefined, undefined], Dumper=AnsibleDumper)
    assert dumped == '[]\n'
    dumped = yaml.dump([undefined, 1, undefined], Dumper=AnsibleDumper)
    assert dumped == '[null, 1]\n'

# Generated at 2022-06-25 04:33:05.552844
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.SafeDumper
    dumper.add_representer(binary_type, represent_binary)
    text = '{"binary_str": "binary_str\xe3\x80\x80"}'
    assert yaml.safe_load(text, Loader=yaml.SafeLoader) == yaml.safe_load(yaml.safe_dump(yaml.safe_load(text, Loader=yaml.SafeLoader), Dumper=dumper), Loader=yaml.SafeLoader)

# Generated at 2022-06-25 04:33:09.176152
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = dict(data={'a': 1, 'b': 2})
    hv = HostVars(d)
    assert yaml.safe_dump(hv, default_flow_style=False) == 'a: 1\nb: 2\n'



# Generated at 2022-06-25 04:33:20.305134
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    # Setup
    dumper = AnsibleDumper
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES128;valentin\n34643861626436303931393932356336316362626661326438303362373134643439313262616633\n63636236343565366336626238666530626433656539303563643938373\n')

# Generated at 2022-06-25 04:33:22.389705
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert represent_unicode(dumper, 'abc') == 'abc'


# Generated at 2022-06-25 04:33:27.491627
# Unit test for function represent_unicode
def test_represent_unicode():
    rep = AnsibleDumper.represent_unicode
    assert rep(None, AnsibleUnicode('foo')) == rep(None, 'foo') == "foo\n..."


# Generated at 2022-06-25 04:33:33.142442
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Create a vault encrypted unicode object
    text = '$ANSIBLE_VAULT;1.1;AES256\r\n...\r\n'
    data = AnsibleVaultEncryptedUnicode(text)
    # Create a yaml output to test
    yaml = """--- !vault |
  $ANSIBLE_VAULT;1.1;AES256
...
"""
    # Create the object used by yaml to represent data
    yaml_representer = AnsibleDumper
    yaml_representer.default_flow_style = False
    # Assert the object yaml is equal to the one we want
    assert(yaml_representer.represent_vault_encrypted_unicode(data) == yaml)

# Generated at 2022-06-25 04:33:46.750475
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def sort_dict(data):
        return dict((k, data[k]) for k in sorted(data))

    test_data = '''{
        "_meta": {
            "hostvars": {
                "1": {
                    "a": 2,
                    "b": 3
                }
            }
        },
        "1": {
            "a": 1,
            "b": 2
        }
    }'''

    test_data = yaml.load(test_data, Loader=AnsibleLoader)

# Generated at 2022-06-25 04:33:49.938852
# Unit test for function represent_undefined
def test_represent_undefined():
    blob = AnsibleUndefined

    assert AnsibleDumper.represent_undefined(blob) == bool(blob)

# Generated at 2022-06-25 04:33:53.363565
# Unit test for function represent_unicode
def test_represent_unicode():
    yaml.dump(AnsibleUnicode(u'test'), stream=None, Dumper=AnsibleDumper)



# Generated at 2022-06-25 04:33:58.120660
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_data = {"hello": "world", "some": {"complex": "object"}}
    test_data_repr = yaml.dump(test_data, Dumper=AnsibleDumper, default_flow_style=False)
    assert test_data_repr == '''{hello: world, some: {complex: object}}\n'''



# Generated at 2022-06-25 04:34:00.542002
# Unit test for function represent_unicode
def test_represent_unicode():
    data = u"hello"
    msg = yaml.dump(data, Dumper=AnsibleDumper)
    assert msg.strip() == u"hello", 'str(data) should be "hello"'

# Generated at 2022-06-25 04:34:04.436439
# Unit test for function represent_hostvars
def test_represent_hostvars():
    result = represent_hostvars(None, {'key1': 'value1'})
    assert result == "{'key1': 'value1'}"

# Generated at 2022-06-25 04:34:12.574299
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    aveu = AnsibleVaultEncryptedUnicode("my secret", "my ciphertext")
    assert yaml.dump(aveu, Dumper=AnsibleDumper) == '!vault |\n  my ciphertext'


if __name__ == "__main__":
    import pytest
    pytest.main([
        '-v',
        # '--pdb',
        __file__
    ])

# Generated at 2022-06-25 04:34:14.890158
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(None, AnsibleUnicode('foo')) \
        == yaml.representer.SafeRepresenter.represent_str(None, text_type('foo'))



# Generated at 2022-06-25 04:34:19.472209
# Unit test for function represent_unicode
def test_represent_unicode():
    a = AnsibleUnicode('foo')
    b = AnsibleUnicode(u'foo')
    c = AnsibleUnicode(u'foo'.encode('utf-8'))
    d = AnsibleUnicode(u'fóo'.encode('utf-8'))

    assert yaml.dump(a) == yaml.dump(b) == yaml.dump(c) == yaml.dump(d) == "foo\n..."



# Generated at 2022-06-25 04:34:24.108337
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    data = vault.encrypt('test string')
    e = AnsibleVaultEncryptedUnicode(data.encode('utf-8'))
    yaml.dump(e, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-25 04:34:39.427286
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    obj = AnsibleVaultEncryptedUnicode('mycontent')
    x = represent_vault_encrypted_unicode(None, obj)

# Generated at 2022-06-25 04:34:41.673448
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode(b'abcd')
    assert yaml.dump(data, Dumper=AnsibleDumper) == '!vault |\n  abcd\n'

# Generated at 2022-06-25 04:34:43.688203
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b"\x80\x01"
    expected = "!!binary |\n  gA=="
    result = dumper.represent_binary(dumper, data)
    assert result == expected

# Generated at 2022-06-25 04:34:49.416881
# Unit test for function represent_binary
def test_represent_binary():
    def _ensure_bytes(data):
        return [ord(c) for c in binary_type(data)]
    dumper = AnsibleDumper()
    assert dumper.represent_binary('hello') == _ensure_bytes('hello')

# Generated at 2022-06-25 04:34:54.100584
# Unit test for function represent_undefined
def test_represent_undefined():
    # Just assert that represent_undefined can represent AnsibleUndefined without exploding
    AnsibleUndefined()
    assert True

# Generated at 2022-06-25 04:35:00.029612
# Unit test for function represent_undefined
def test_represent_undefined():
    AnsibleDumper.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    assert bool(AnsibleUndefined("foo"))



# Generated at 2022-06-25 04:35:08.895194
# Unit test for function represent_hostvars
def test_represent_hostvars():

    def check_result(obj, dumped):
        result = yaml.safe_load(dumped)
        assert isinstance(result, dict), "Dumped object is not a dictionary"
        assert set(result.keys()) == set(obj.keys())
        for key in result:
            assert result[key] == obj[key]

    dumper = AnsibleDumper()
    check_result(HostVars({'a': 1, 'b': 2, 'c': {'a': 1}}), dumper.represent_hostvars(HostVars({'a': 1, 'b': 2, 'c': {'a': 1}})))

# Generated at 2022-06-25 04:35:11.189389
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    data = b'this is binary'
    assert dumper.represent_binary(dumper, data) == \
        (u'this is binary'.encode('utf-8'), True, None)



# Generated at 2022-06-25 04:35:18.569178
# Unit test for function represent_unicode
def test_represent_unicode():
    class YAML:
        def __init__(self, yaml_data):
            self.yaml_data = yaml_data

        def __repr__(self):
            return self.yaml_data
    y = YAML('foo: bar\n')
    assert represent_unicode(y, text_type('foo')) == 'foo'

# Generated at 2022-06-25 04:35:26.021368
# Unit test for function represent_hostvars
def test_represent_hostvars():
    json_result = '\n'.join(
        (
            '{',
            '    "localhost": {',
            '        "omg_look_key": "omg_look_value"',
            '    }',
            '}'
        )
    )
    obj_result = yaml.load(json_result)
    assert isinstance(obj_result, dict)
    assert isinstance(obj_result.get('localhost'), dict)
    assert obj_result.get('localhost').get('omg_look_key') == 'omg_look_value'

    result = yaml.dump(obj_result, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == json_result


if __name__ == "__main__":
    test_represent_hostvars()

# Generated at 2022-06-25 04:35:46.279052
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ret = dumper.represent_data(A.AnsibleVaultEncryptedData('$ANSIBLE_VAULT;1.1;AES256\n3330333133333233613032363961643136626465393337646532303538666631396661383337343666\n3937353633663633386162323135356435343762653162396332353161633532353139396465636361\n62333137356436633266643262326331633933626631663733'))


# Generated at 2022-06-25 04:35:51.014357
# Unit test for function represent_undefined
def test_represent_undefined():
    assert yaml.dump(AnsibleUndefined(fail_on_undefined=True), Dumper=AnsibleDumper) == ''
    assert yaml.dump(AnsibleUndefined(fail_on_undefined=False), Dumper=AnsibleDumper) == 'null\n'

# Generated at 2022-06-25 04:35:54.901691
# Unit test for function represent_undefined
def test_represent_undefined():
    ''' Test represent_undefined() function '''

    dumper = AnsibleDumper
    assert not bool(AnsibleUndefined)
    assert not bool(AnsibleUndefined("foo"))
    assert not bool(AnsibleUndefined(foo="foo"))

# Generated at 2022-06-25 04:36:01.239967
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    assert dumper.represent_unicode(u'foo') == "foo\n"
    assert dumper.represent_unicode(u'\u2122') == "\u2122\n"
    assert dumper.represent_unicode(u'\u2122\n') == "\u2122\n"

# Generated at 2022-06-25 04:36:03.987732
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(
        AnsibleUnicode(u"foo"),
        Dumper=AnsibleDumper,
    ) == "\nfoo\n...\n"



# Generated at 2022-06-25 04:36:06.589623
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, u'abc') == u"u'abc'"
    assert represent_unicode(AnsibleDumper, u'123') == u"u'123'"



# Generated at 2022-06-25 04:36:10.721703
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_data(AnsibleUndefined) is False



# Generated at 2022-06-25 04:36:12.807185
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    assert bool is dumper.represent_undefined(dumper, AnsibleVarsModule.undefined)


# Generated at 2022-06-25 04:36:14.834888
# Unit test for function represent_undefined
def test_represent_undefined():
    class MyUndefined(AnsibleUndefined):
        def __init__(self, value):
            self._value = value

    dumper = AnsibleDumper
    # Here value=0 will ensure _fail_with_undefined_error happens
    assert dumper.represent_undefined(dumper, MyUndefined(0))

# Generated at 2022-06-25 04:36:20.838658
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(AnsibleUndefined())
    assert not dumper.represent_undefined(bool(0))

# Generated at 2022-06-25 04:36:58.131995
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    # AnsibleUndefined(None) will be replaced in the output with a stub
    # that will trigger _fail_with_undefined_error when it's used
    # (which will be as soon as bool() is called in an if conditional)
    assert dumper.represent_undefined(AnsibleUndefined(None)) == True

# Generated at 2022-06-25 04:37:04.336869
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(width=999999)
    bad_thing = AnsibleUndefined()
    output = yaml.dump(bad_thing, Dumper=AnsibleDumper, default_flow_style=False)
    assert output == "None\n"

# Generated at 2022-06-25 04:37:06.788415
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined()) == True

# Generated at 2022-06-25 04:37:09.339172
# Unit test for function represent_hostvars
def test_represent_hostvars():
    d = {'test': 1}
    data = HostVars(d)
    assert AnsibleDumper.represent_dict(data) == '{test: 1}'



# Generated at 2022-06-25 04:37:15.709013
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    plain_data = u'\xe4\xf6\xfc'
    plain_result = dumper.represent_unicode(dumper, plain_data)
    assert plain_result == "!!python/unicode '\\344\\366\\374'"
    data = AnsibleUnicode(plain_data)
    result = dumper.represent_unicode(dumper, data)
    assert result == "!!python/unicode '\\344\\366\\374'"
    data_str = AnsibleUnsafeText(plain_data)
    result_str = dumper.represent_unicode(dumper, data_str)
    assert result_str == "!!python/unicode '\\344\\366\\374'"

# Generated at 2022-06-25 04:37:18.483212
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = AnsibleDumper()
    hostvars = HostVars()
    hostvars._hostvars = {
        "host1": {"k1": "v1"},
        "host2": {"k2": "v2"},
    }
    assert dumper.represent_hostvars(hostvars) == dumper.represent_dict(hostvars._hostvars)

# Generated at 2022-06-25 04:37:24.654789
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, 'foo') == yaml.representer.SafeRepresenter.represent_str(yaml.representer.SafeRepresenter(), text_type('foo'))
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == yaml.representer.SafeRepresenter.represent_str(yaml.representer.SafeRepresenter(), text_type('foo'))
    # Other classes
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeText('foo')) == yaml.representer.SafeRepresenter.represent_str(yaml.representer.SafeRepresenter(), text_type('foo'))
    assert represent_unicode(AnsibleDumper, AnsibleUnsafeBytes('foo'.encode())) == yaml.representer.SafeRepresenter

# Generated at 2022-06-25 04:37:27.586820
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(dict(
        foo=dict(bar=1),
    ))
    hostvarsvars = HostVarsVars(hostvars, dict(bar=2))

    assert yaml.dump(hostvars, Dumper=AnsibleDumper) == '{foo: {bar: 1}}'
    assert yaml.dump(hostvarsvars, Dumper=AnsibleDumper) == '{bar: 2}'



# Generated at 2022-06-25 04:37:31.871874
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump(AnsibleUnicode(u"what\u2020\u2021"), Dumper=AnsibleDumper) == "what\\u2020\\u2021\n...\n"


# Generated at 2022-06-25 04:37:41.058484
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Simple case
    d = dict(one="2", two=2, three=None)
    yaml_text = '''
one: 2
two: 2
three: null
'''
    dump = yaml.dump(d, Dumper=AnsibleDumper)
    assert dump == yaml_text

    # Need to use AnsibleLoader to test unicode, because otherwise
    # the type is converted to a str, and then dumped again
    yaml_text = u'''
one: 2
two: !!python/unicode '2'
three: null
'''
    data = AnsibleLoader(yaml_text, yaml.SafeLoader).get_single_data()

# Generated at 2022-06-25 04:38:56.709820
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(indent=2)
    assert dumper.represent_undefined(AnsibleUndefined()) == 'False'

# Generated at 2022-06-25 04:39:04.312972
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import io
    import sys

    # This module is only tested with Python 3.
    if sys.version_info[0] < 3:
        return

    # Test that hostvars can be encoded.
    hv = HostVars()
    hv['example.com'] = dict(test='test')
    stream = io.StringIO()
    yaml.dump(hv, stream, Dumper=AnsibleDumper)
    assert stream.getvalue() == 'example.com:\n  test: test\n'



# Generated at 2022-06-25 04:39:08.226443
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hostvars = HostVars(vars={'test': 'success'})
    assert yaml.dump(hostvars, default_flow_style=False,
                     Dumper=AnsibleDumper) == "{test: success}"

# Generated at 2022-06-25 04:39:11.643775
# Unit test for function represent_unicode
def test_represent_unicode():
    data = yaml.dump(['hello'], Dumper=AnsibleDumper)
    assert data == "- 'hello'\n"



# Generated at 2022-06-25 04:39:18.718258
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml_data = yaml.safe_load("""
    foo: {{ bar }}
    """)
    dump_data = yaml.dump(yaml_data, Dumper=AnsibleDumper)
    assert dump_data == '''\
foo:
'''

# Generated at 2022-06-25 04:39:21.723599
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_data(AnsibleUndefined()) is AnsibleUndefined()

# Generated at 2022-06-25 04:39:28.394955
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {u'asdf': AnsibleUnicode('sdfg'), u'foo': AnsibleUnicode('bar')}
    correct_result = text_type('{asdf: sdfg, foo: bar}').encode('ascii', 'ignore')
    inner_data = HostVarsVars(data)
    result = yaml.dump(inner_data, Dumper=AnsibleDumper)
    print(result)
    assert result == correct_result, "The result is not correct."

# Generated at 2022-06-25 04:39:32.034126
# Unit test for function represent_binary
def test_represent_binary():
    representer = AnsibleDumper()
    data = b'foo'
    result = representer.represent_binary(data)
    assert result is not None

# Generated at 2022-06-25 04:39:41.832831
# Unit test for function represent_undefined
def test_represent_undefined():
    # Tests:
    #   - the type of the exception thrown here is Exception and not yaml.representer.RepresenterError.
    #   - the message of the exception thrown here contains 'undefined'
    #   - the variable being dumped is present in the error message.

    dumper = AnsibleDumper

    # Register this function for the safe dumper
    dumper.add_representer(AnsibleUndefined, represent_undefined)

    # Test that the error type is the generic Exception
    try:
        from ansible.template import StrictUndefined
        dumper.represent_data({'foo': StrictUndefined()})
        assert False
    except Exception as e:
        assert isinstance(e, Exception)
        assert "undefined" in e.message
        assert 'foo' in e.message

    # Test that the error

# Generated at 2022-06-25 04:39:44.425023
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert yaml.safe_load(yaml.dump(HostVars({'name': 'test', 'type': 'test'}), Dumper=AnsibleDumper)) == {'type': 'test', 'name': 'test'}

