

# Generated at 2022-06-25 04:32:02.948688
# Unit test for function represent_undefined
def test_represent_undefined():
    bytes_0 = b''
    var_0 = represent_undefined(bytes_0)


# Generated at 2022-06-25 04:32:04.165420
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # FIXME: This test is not yet implemented
    pass


# Generated at 2022-06-25 04:32:05.712789
# Unit test for function represent_hostvars
def test_represent_hostvars():
    unk0 = ''
    var0 = represent_hostvars(unk0)


# Generated at 2022-06-25 04:32:07.693923
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    bytes_0 = b''
    var_0 = represent_vault_encrypted_unicode(bytes_0)


# Generated at 2022-06-25 04:32:11.681425
# Unit test for function represent_binary
def test_represent_binary():
    bytes_0 = b''
    var_0 = represent_binary(bytes_0)


# Generated at 2022-06-25 04:32:12.590742
# Unit test for function represent_undefined
def test_represent_undefined():
    # FIXME: test_case_1 not implemented
    pass


# Generated at 2022-06-25 04:32:13.981948
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert repr(test_case_0()) == '<generator object represent_hostvars at 0x1026a4050>'


# Generated at 2022-06-25 04:32:17.815201
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert(isinstance(represent_vault_encrypted_unicode(b''),
        yaml.representer.SafeRepresenter))



# Generated at 2022-06-25 04:32:22.317061
# Unit test for function represent_binary
def test_represent_binary():
    assert (yaml.representer.SafeRepresenter.represent_binary(None, b'test_content') == "!!binary |\n  dGVzdF9jb250ZW50\n")



# Generated at 2022-06-25 04:32:31.215000
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    bytes_0 = b'!vault |\n'
    bytes_1 = b'$ANSIBLE_VAULT;1.1;AES256\n'
    bytes_2 = b'3536336633393830353761303337653930633231623366333631383836386636333566313531336165\n'
    bytes_3 = b'3834383137326665393731393931656132663366353762633065616236663533343036396534353338\n'
    bytes_4 = b'3435323061306336373736623862653832383636356465656232373164363339353731326135613430\n'

# Generated at 2022-06-25 04:32:40.031626
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    data = '$ANSIBLE_VAULT;1.2;AES256;sam'
    data_value = AnsibleVaultEncryptedUnicode(data)
    assert represent_vault_encrypted_unicode(dumper, data_value) == "!vault |\n  $ANSIBLE_VAULT;1.2;AES256;sam\n"



# Generated at 2022-06-25 04:32:42.878942
# Unit test for function represent_undefined
def test_represent_undefined():
    d1 = yaml.load('''
x: "{{ undefined_var }}"
''')
    dumper = AnsibleDumper()
    result = dumper.represent_data(d1)

    assert result



# Generated at 2022-06-25 04:32:48.658221
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    '''represent_vault_encrypted_unicode should return a AnsibleVaultEncryptedUnicode object'''
    AVEU = AnsibleVaultEncryptedUnicode('abcd')
    assert represent_vault_encrypted_unicode(AnsibleDumper, AVEU) == "!vault |\n      'YWJjZA=='\n"

# Generated at 2022-06-25 04:32:52.987448
# Unit test for function represent_unicode
def test_represent_unicode():
    rep = AnsibleDumper()
    assert rep.represent_unicode(u'abc') == u"'abc'"
    assert rep.represent_unicode(u'1\u20481') == u"'1\\u20481'"
    assert rep.represent_unicode(u'\u222B') == u"'\\u222b'"



# Generated at 2022-06-25 04:32:58.133249
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dumper = yaml.Dumper

    dumper.add_representer(
        HostVars,
        represent_hostvars,
    )

    hostvars = HostVars({"a": 1, "b": 2})
    yaml_str = yaml.dump(hostvars, Dumper=dumper)

    assert yaml_str == "{a: 1, b: 2}\n"



# Generated at 2022-06-25 04:33:08.801192
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:33:11.256637
# Unit test for function represent_unicode
def test_represent_unicode():
    assert represent_unicode(AnsibleDumper, AnsibleUnicode('foo')) == 'foo'



# Generated at 2022-06-25 04:33:15.913661
# Unit test for function represent_binary
def test_represent_binary():
    dumper = yaml.Dumper()
    dumper.add_representer(binary_type, represent_binary)
    assert '!!binary |' in dumper.represent_scalar('tag:yaml.org,2002:binary', b'\xFF\xFF\xFF\xFF\xFF')

# Generated at 2022-06-25 04:33:19.230645
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    plaintext = b'asdf'
    ciphertext = b'asdf'
    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext, plaintext)
    dumper = AnsibleDumper()
    assert '!vault |\nasdf\n' == dumper.represent_data(vault_encrypted_unicode)

# Generated at 2022-06-25 04:33:25.254903
# Unit test for function represent_undefined
def test_represent_undefined():
    '''
    Demonstrates that represent_undefined is called.
    '''
    dumper = AnsibleDumper()
    # Here we use a lambda to catch the called of _fail_with_undefined_error
    dumper.represent_undefined = lambda self, data: self._fail_with_undefined_error(data)

    try:
        dumper.represent_data(AnsibleUndefined('message'))
    except Exception as e:
        assert e.__class__.__name__ == 'YAMLUndefinedError'
        assert e.message == 'message'
    else:
        assert False, 'YAMLUndefinedError not raised'

# Generated at 2022-06-25 04:33:34.834316
# Unit test for function represent_undefined
def test_represent_undefined():
    dumped = yaml.dump(dict(a='a', b=AnsibleUndefined('b')), Dumper=AnsibleDumper)

    assert dumped == "---\na: a\n"



# Generated at 2022-06-25 04:33:38.385159
# Unit test for function represent_undefined
def test_represent_undefined():
    setattr(yaml.representer.SafeRepresenter, '_fail_with_undefined_error', lambda x: 'undefined')
    dumper = AnsibleDumper
    assert dumper.represent_data(AnsibleUndefined()) == 'undefined'
    delattr(yaml.representer.SafeRepresenter, '_fail_with_undefined_error')

# Generated at 2022-06-25 04:33:43.540552
# Unit test for function represent_undefined
def test_represent_undefined():
    yaml.representer.SafeRepresenter.add_representer(
        AnsibleUndefined,
        represent_undefined,
    )
    class FakeAnsibleUndefined(AnsibleUndefined):
        def _fail_with_undefined_error(*args, **kwargs):
            return True
    dump_data = [{'variable': FakeAnsibleUndefined()}]
    output = yaml.safe_dump(dump_data, default_flow_style=False).strip()
    assert output == "- {variable: null}"

# Generated at 2022-06-25 04:33:46.844981
# Unit test for function represent_unicode
def test_represent_unicode():
    for value in (42, 42.0):
        assert yaml.safe_dump(value, Dumper=AnsibleDumper) == "42\n...\n"
    # This is the bad case, we don't want to convert everything to str
    assert yaml.safe_dump(u'\x80', Dumper=AnsibleDumper) == u"\x80\n"

# Generated at 2022-06-25 04:33:58.685362
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import _fail_with_undefined_error
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from copy import deepcopy
    yaml.SafeLoader.add_constructor(u'tag:yaml.org,2002:bool', lambda self, node: AnsibleUnsafeText(node.value))
    yaml.SafeLoader.add_multi_constructor(u'tag:yaml.org,2002:str', lambda self, node: AnsibleUnsafeText(node.value))

    def my_fail_with_undefined_error(obj, obj_lineno=None):
        raise Exception(obj)

    old_fail_with_undefined_error = deepcopy(_fail_with_undefined_error)

# Generated at 2022-06-25 04:34:05.612253
# Unit test for function represent_binary
def test_represent_binary():
    yaml_string = AnsibleDumper.represent_binary(None, b"test")
    expected_string = "!!binary \"dGVzdA==\"\n"
    assert yaml_string == expected_string



# Generated at 2022-06-25 04:34:09.831783
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    assert yaml.dump(
        AnsibleVaultEncryptedUnicode('ABCD'), Dumper=AnsibleDumper
    ) == '!vault |\n          QkJD\n'

# Generated at 2022-06-25 04:34:13.532716
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_string = text_type("Hello world")
    unicode_string_expected_yaml = u'Hello world'

    assert unicode_string_expected_yaml == yaml.dump(unicode_string, Dumper=AnsibleDumper, default_flow_style=False)



# Generated at 2022-06-25 04:34:21.979788
# Unit test for function represent_binary
def test_represent_binary():
    test_data = [
        {u'unicode': u'\u0022', u'ascii': '"', u'bytes': u'\x22'},
        {u'unicode': u'\u2665', u'ascii': '?', u'bytes': u'\xe2\x99\xa5'},
        {u'unicode': u'\u2603', u'ascii': '?', u'bytes': u'\xe2\x98\x83'},
        {u'unicode': u'\u263a', u'ascii': '?', u'bytes': u'\xe2\x98\xba'},
    ]
    for d in test_data:
        assert d['unicode'].encode('utf-8') == d['bytes']
       

# Generated at 2022-06-25 04:34:24.765115
# Unit test for function represent_undefined
def test_represent_undefined():
    ansible_dumper = AnsibleDumper
    undefined = AnsibleUndefined('ansible undefined test')
    assert ansible_dumper.represent_undefined(undefined) is True



# Generated at 2022-06-25 04:34:34.216919
# Unit test for function represent_hostvars
def test_represent_hostvars():

    data = HostVars(dict(x=10))

    assert yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False) == 'x: 10\n'

# Generated at 2022-06-25 04:34:37.825570
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper(indent=4, default_flow_style=False)
    data = {
        u'foo': u'bar'
    }

    output = yaml.safe_dump(data, default_flow_style=False, Dumper=AnsibleDumper)
    print(output)



# Generated at 2022-06-25 04:34:41.308192
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper()
    data = u'\u2713'
    output = dumper.represent_unicode(data)

    assert data == output.value



# Generated at 2022-06-25 04:34:43.393329
# Unit test for function represent_hostvars
def test_represent_hostvars():
    foo = HostVars({"bar": "baz"})
    bar = yaml.dump({"foo": foo}, Dumper=AnsibleDumper)
    assert bar == "{foo: {bar: baz}}\n"

# Generated at 2022-06-25 04:34:50.090164
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    binary = b"This is a binary string"
    yaml_binary = dumper._represent_binary(binary)
    assert binary_type(yaml_binary) == b"!!binary |\n  VGhpcyBpcyBhIGJpbmFyeSBzdHJpbmc=\n"

# Generated at 2022-06-25 04:34:57.246440
# Unit test for function represent_unicode
def test_represent_unicode():
    data = {'a': 1, 'b': 2, 'c': AnsibleUnicode('this is a string')}
    yaml_out = yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml_out == u"{a: 1, b: 2, c: 'this is a string'}\n"



# Generated at 2022-06-25 04:35:02.494489
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    dumper = AnsibleDumper(
        None,
        default_flow_style=None,
        canonical=False,
        indent=4,
        width=1000,
        allow_unicode=True,
        line_break=True,
        encoding='utf-8',
        explicit_start=False,
        explicit_end=False,
        version=None,
        tags=None,
    )

# Generated at 2022-06-25 04:35:04.792462
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = u'Bengaluru'
    assert dumper.represent_unicode(dumper, data) == dumper.represent_str(dumper, data)


# Generated at 2022-06-25 04:35:12.532513
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = yaml.representer.Representer()
    dumper.add_representer(AnsibleUndefined, represent_undefined)
    # If !fail_on_undefined is not set, no exception will be thrown and 'null' will be returned
    # Note that we are not testing the behavior of setting !fail_on_undefined here
    assert dumper.represent_data(AnsibleUndefined()) == 'null'



# Generated at 2022-06-25 04:35:19.123954
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    assert dumper.represent_undefined(None) is False
    assert dumper.represent_undefined(AnsibleUndefined(var_name='missing_var')) is True
    assert dumper.represent_undefined(AnsibleUndefined()) is True

# Generated at 2022-06-25 04:35:46.934629
# Unit test for function represent_undefined
def test_represent_undefined():
    # Here bool will ensure _fail_with_undefined_error happens
    # if the value is Undefined.
    # This happens because Jinja sets __bool__ on StrictUndefined
    assert represent_undefined(AnsibleUndefined('foo')) is True


# Generated at 2022-06-25 04:35:56.337501
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = '^u'
    bool_0 = False
    int_0 = -3065
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(int_0)
    float_0 = 0.5
    ansible_dumper_0 = AnsibleDumper(bool_0, ansible_vault_encrypted_unicode_0, float_0)
    dict_0 = {}
    ansible_unicode_0 = module_0.AnsibleUnicode(**dict_0)
    var_0 = ansible_dumper_0.represent_data(ansible_unicode_0)
    list_0 = []
    set_0 = {str_0}

# Generated at 2022-06-25 04:36:02.244600
# Unit test for function represent_hostvars
def test_represent_hostvars():
    dict_0 = {}
    ansible_unicode_0 = module_0.AnsibleUnicode(**dict_0)
    str_0 = '^u'
    bool_0 = False
    int_0 = -3065
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(int_0)
    float_0 = 0.5
    ansible_dumper_0 = AnsibleDumper(bool_0, ansible_vault_encrypted_unicode_0, float_0)
    dict_1 = dict(var_0=ansible_unicode_0)
    list_0 = []
    set_0 = {str_0}
    var_1 = represent_vault_encrypted_unicode(set_0)
    bytes_

# Generated at 2022-06-25 04:36:10.005557
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = 'f'
    ansible_dumper_0 = AnsibleDumper(str_0)
    dict_0 = {str_0: str_0}
    hostvars_0 = HostVars(**dict_0)
    var_0 = represent_hostvars(ansible_dumper_0, hostvars_0)
    str_1 = 'e'
    tuple_0 = (hostvars_0, str_1)
    var_1 = represent_hostvars(tuple_0)


# Generated at 2022-06-25 04:36:20.637844
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = '^u'
    bool_0 = False
    int_0 = -3065
    ansible_vault_encrypted_unicode_0 = module_0.AnsibleVaultEncryptedUnicode(int_0)
    float_0 = 0.5
    ansible_dumper_0 = AnsibleDumper(bool_0, ansible_vault_encrypted_unicode_0, float_0)
    dict_0 = {}
    ansible_unicode_0 = module_0.AnsibleUnicode(**dict_0)
    var_0 = ansible_dumper_0.represent_data(ansible_unicode_0)
    list_0 = []
    set_0 = {str_0}

# Generated at 2022-06-25 04:36:31.013818
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = '\x84\x81\xae'
    bool_0 = True
    int_0 = -23510
    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes(int_0)
    ansible_dumper_0 = AnsibleDumper(bool_0, str_0, ansible_unsafe_bytes_0)
    hostvars_0 = HostVars()
    var_0 = represent_hostvars(hostvars_0)
    ansible_unsafe_text_0 = AnsibleUnsafeText(int_0)
    var_1 = represent_hostvars(ansible_unsafe_text_0)
    ansible_mapping_0 = module_0.AnsibleMapping()

# Generated at 2022-06-25 04:36:42.154945
# Unit test for function represent_undefined
def test_represent_undefined():
    str_0 = '\x11\xad\xb2\x16\xa5\xc0`\x8d\x17\x9a\xce'
    bool_0 = False
    int_0 = 26649
    ansible_vault_encrypted_unicode_1 = module_0.AnsibleVaultEncryptedUnicode(int_0)
    float_0 = 0.9902912621359223
    ansible_dumper_1 = AnsibleDumper(bool_0, ansible_vault_encrypted_unicode_1, float_0)
    dict_0 = {}
    ansible_unicode_0 = module_0.AnsibleUnicode(**dict_0)
    var_0 = ansible_dumper_1.represent_data(ansible_unicode_0)

# Generated at 2022-06-25 04:36:49.826756
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '+'
    bool_0 = True
    dict_0 = {}
    ansible_unicode_0 = module_0.AnsibleUnicode(**dict_0)
    float_0 = 0.0
    ansible_dumper_0 = AnsibleDumper(str_0, bool_0, ansible_unicode_0, float_0)
    int_0 = -1091

# Generated at 2022-06-25 04:36:58.221569
# Unit test for function represent_undefined
def test_represent_undefined():

    # Assign the parameters passed to the `represent_undefined` function.
    data = AnsibleUndefined

    # Call the created `represent_undefined` function.
    result = represent_undefined( data )

    # Create an assertion to verify that the result created by the `represent_undefined`
    # function matches the expected result.
    assert(result == AnsibleUndefined)


# Generated at 2022-06-25 04:37:09.703862
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_1 = '\x8c'
    ansible_dumper_2 = AnsibleDumper(str_1)
    ansible_vault_encrypted_unicode_2 = module_0.AnsibleVaultEncryptedUnicode(str_1)
    ansible_mapping_0 = module_0.AnsibleMapping(**{})
    ansible_mapping_1 = module_0.AnsibleMapping(**{})
    hostvars_vars_0 = HostVarsVars(ansible_vault_encrypted_unicode_2, ansible_mapping_0, ansible_mapping_1)
    var_6 = ansible_dumper_2.represent_data(hostvars_vars_0)
    vars_with_sources_0 = VarsWithSources