

# Generated at 2022-06-25 04:32:04.215637
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = 'sUj{'
    var_0 = represent_vault_encrypted_unicode(str_0)


# Generated at 2022-06-25 04:32:07.045554
# Unit test for function represent_binary
def test_represent_binary():
    data = None
    expected = None
    result = represent_binary(data)
    assert result == expected


# Generated at 2022-06-25 04:32:11.208553
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper
    data = AnsibleUndefined

    assert dumper.represent_undefined(dumper, data) == False

# Generated at 2022-06-25 04:32:12.145348
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass


# Generated at 2022-06-25 04:32:15.878947
# Unit test for function represent_binary
def test_represent_binary():
    assert True


# Generated at 2022-06-25 04:32:19.976571
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # no need to really test anything here, just checking to see if
    # the static method overrides the default method
    data = hostvars_data
    assert represent_hostvars(data) == hostvars_data


# Generated at 2022-06-25 04:32:23.430265
# Unit test for function represent_hostvars
def test_represent_hostvars():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()



# Generated at 2022-06-25 04:32:24.377933
# Unit test for function represent_hostvars
def test_represent_hostvars():
    assert represent_hostvars("data") == "data"


# Generated at 2022-06-25 04:32:26.778961
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = 'W70P8x3d4_4'
    var_0 = represent_hostvars(str_0)


# Generated at 2022-06-25 04:32:28.758554
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '5-qv'
    var_0 = represent_binary(str_0)


# Generated at 2022-06-25 04:32:36.414375
# Unit test for function represent_unicode
def test_represent_unicode():
    assert yaml.dump({'foo': 'bar'}, Dumper=AnsibleDumper) == '{foo: bar}\n'
    assert yaml.dump({'foo': 'bar\n'}, Dumper=AnsibleDumper) == '{foo: bar\n}\n'
    assert yaml.dump({'foo': 'bar\n\n'}, Dumper=AnsibleDumper) == '{foo: |\n  bar\n  \n}\n'

# Generated at 2022-06-25 04:32:39.959103
# Unit test for function represent_binary
def test_represent_binary():
    s = yaml.dump(b'\xDE\xAD\xBE\xEF', Dumper=AnsibleDumper)
    assert s == '!binary |-\n  -R-Y-f-4-\n'



# Generated at 2022-06-25 04:32:43.081913
# Unit test for function represent_undefined
def test_represent_undefined():
    output = yaml.dump(AnsibleUndefined() == False, Dumper=AnsibleDumper)
    assert u'!!python/name:ansible.module_utils.common.unsafe_proxy.AnsibleUnsafeText \n' in output



# Generated at 2022-06-25 04:32:51.777656
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars("sample_host", {})
    # Test with empty dict
    assert yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False) == '{}\n'
    hv["ansible_all_ipv4_addresses"] = ["192.168.1.1", "192.168.1.2"]
    # Test with dict with single element
    assert yaml.dump(hv, Dumper=AnsibleDumper, default_flow_style=False) == 'ansible_all_ipv4_addresses: [192.168.1.1, 192.168.1.2]\n'


if __name__ == '__main__':
    import sys
    import json


# Generated at 2022-06-25 04:33:01.007299
# Unit test for function represent_vault_encrypted_unicode

# Generated at 2022-06-25 04:33:05.083137
# Unit test for function represent_unicode
def test_represent_unicode():
    loader = yaml.Loader
    loader.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: AnsibleUnicode(loader.construct_scalar(node)))
    yaml_data = yaml.load(u'foo: !ansible_unicode "test"', Loader=loader)
    bytes_data = yaml.dump(yaml_data, Dumper=AnsibleDumper)
    assert bytes_data == b'foo: test\n'

# Generated at 2022-06-25 04:33:14.391622
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper = AnsibleDumper()
    # Test with hostvars as dict
    hostvars = {'name': 'hostvars_dict', 'age': 20}
    result = ansible_dumper.represent_hostvars(hostvars)
    assert result == '!hostvars\nage: 20\nname: hostvars_dict\n'

    # Test with hostvars as HostVars object
    hostvars = HostVars('hostvars', 'hostname')
    result = ansible_dumper.represent_hostvars(hostvars)
    assert result == '!hostvars\n'

    # Test with hostvars as HostVarsVars object
    hostvars = HostVarsVars('hostvars', 'hostname')
    result = ansible_dumper

# Generated at 2022-06-25 04:33:22.390455
# Unit test for function represent_hostvars
def test_represent_hostvars():
    '''
    Test `represent_hostvars` as a standalone function
    by using the default dumper.
    '''
    d = yaml.representer.SafeRepresenter.represent_dict
    hv = HostVars(dict(a=1, b=2))
    res = represent_hostvars(d, hv)
    assert res == d(dict(a=1, b=2))
    hvvs = HostVarsVars(dict(a=1, b=2))
    res = represent_hostvars(d, hvvs)
    assert res == d(dict(a=1, b=2))

# Generated at 2022-06-25 04:33:30.939269
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper
    represent_binary(dumper, b'abc123')

    # We make sure that represent_binary is the only representer
    # for bytes, because we want to make sure that Python 2 does
    # not add a representer for bytes, which are named str
    # in Python 2
    assert len(list(filter(lambda x: x[1] == represent_binary, yaml.representer.BaseRepresenter.yaml_representers.items()))) == 1



# Generated at 2022-06-25 04:33:39.909396
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import encrypt_string
    v = VaultLib([])
    plaintext = 'Hello World!'
    ciphertext = encrypt_string(v, plaintext)
    vault = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-25 04:33:50.622053
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import time
    data1 = {'data': '123'}
    data2 = {'data': '456', 'time': time.time()}
    hostvars = HostVars(vars=[data1, data2], cur_keys_len=2)
    result = yaml.dump(hostvars, Dumper=AnsibleDumper)
    assert result == '{data: 123, time: %f}\n' % time.time()



# Generated at 2022-06-25 04:34:00.363395
# Unit test for function represent_unicode
def test_represent_unicode():
    # Marking this test as an xfail until we figure out how to fix it.
    # See https://github.com/ansible/ansible/issues/32546
    pytest.xfail("Unicode representer breaks python3 tests")
    import sys
    if sys.version_info[0] >= 3:
        # We are running under python3, so we cannot use 'unicode'
        unicode = str

    plain_string = 'vagrantfile.template'
    plain_unicode = u'vagrantfile.template'
    dumper = AnsibleDumper()

    # This call to represent_unicode will fail because we are passing a
    # unicode object.  We'll then try to use represent_unicode to convert
    # the unicode object to a string.

# Generated at 2022-06-25 04:34:03.471770
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(b'bytes') == '"bytes"\n', \
        'represent_binary does not work'

# Generated at 2022-06-25 04:34:08.622354
# Unit test for function represent_unicode
def test_represent_unicode():
    """This tests that the represent_unicode function is adding
    representers for unicode objects to the AnsibleDumper class.
    It does this by creating an instance of the AnsibleDumper and
    then verifying that the representer for unicode has been added
    to the instance.
    """
    test_dumper = AnsibleDumper()
    # Get the representer functions from the AnsibleDumper instance
    test_dumper_representers = test_dumper.yaml_representers
    # Verify that the unicode representer is in the representers
    assert test_dumper_representers[unicode] == represent_unicode

# Generated at 2022-06-25 04:34:10.505675
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper()
    u = AnsibleUndefined()
    dumper.represent_undefined(u)

# Generated at 2022-06-25 04:34:12.048725
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined) == False



# Generated at 2022-06-25 04:34:17.468912
# Unit test for function represent_hostvars
def test_represent_hostvars():
    h = HostVars({"foo": "bar"})
    expected = '{\n    foo: bar\n}'
    assert yaml.dump(h, Dumper=AnsibleDumper) == expected



# Generated at 2022-06-25 04:34:19.377915
# Unit test for function represent_hostvars
def test_represent_hostvars():
    print(yaml.dump(HostVars(), Dumper=AnsibleDumper))

# Generated at 2022-06-25 04:34:28.217051
# Unit test for function represent_binary
def test_represent_binary():
    rep = AnsibleDumper.represent_binary
    yamldata = rep(None, '\x00\x01\x02\x03\x04\x05\x06\x07')
    assert yamldata == "!!binary |\n  AAAEAAQIDBAUGBwg="
    # Note: base64 -D on Linux returns '\t' (0x09) as LF (0x0A)
    # so we test with b'\t' instead of '\t'
    assert yaml.load(yamldata) == b'\x00\x01\x02\x03\x04\x05\x06\x07'

# Generated at 2022-06-25 04:34:31.925867
# Unit test for function represent_binary
def test_represent_binary():

    data = AnsibleUnsafeBytes(b'abcd\x00\xff')

    dumper = AnsibleDumper(None)
    representer = represent_binary(dumper, data)

    assert isinstance(representer.value, binary_type)
    assert representer.value == data

# Generated at 2022-06-25 04:34:43.529413
# Unit test for function represent_unicode
def test_represent_unicode():
    string = u'[\u3042\u3044\u3046\u3048\u304a\u304b\u304d\u304f\u3051\u3053]'
    with open('/tmp/a', 'w') as f:
        yaml.dump(string, f, Dumper=AnsibleDumper)
    with open('/tmp/a') as f:
        assert yaml.load(f) == string

# Generated at 2022-06-25 04:34:50.117283
# Unit test for function represent_unicode
def test_represent_unicode():
    unicode_string = u'unicode'
    assert yaml.dump(unicode_string, Dumper=AnsibleDumper) == '- unicode\n'
    assert yaml.dump(unicode_string, default_flow_style=True, Dumper=AnsibleDumper) == "'unicode'\n"


# Generated at 2022-06-25 04:34:52.764408
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.vars.hostvars import HostVars

    hv = HostVars({"foo": "bar"})
    expected = {'foo': 'bar'}

    assert expected == yaml.load(yaml.dump(hv, Dumper=AnsibleDumper))



# Generated at 2022-06-25 04:34:55.656457
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined("test")
    assert not bool(data)
    assert data.__bool__() == False
    assert data._fail_with_undefined_error() == True



# Generated at 2022-06-25 04:35:06.023957
# Unit test for function represent_unicode
def test_represent_unicode():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils import string_types, unsafe_proxy
    dumper = AnsibleDumper()
    # Ensure that we represent unicode with the appropriate unicode style
    # (we want to use plain style, which ensures that we use single quotes
    # when the string contains non-printables)
    for test_string in [
        AnsibleUnicode(u'foo'),
        unsafe_proxy.UnsafeProxy(u'foo', string_types),
        unsafe_proxy.UnsafeText(u'foo'),
        string_types(u'foo'),
        'foo',
    ]:
        unicode_representer(dumper, test_string) == u"'foo'"

# Generated at 2022-06-25 04:35:12.304355
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    a = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;9.9;AES256\n3064353038333632633536646166623161663039613338626261613562343032303164663436\n613965363961356663366661633833653138666363326331316132313731383130353763373834\n6286\n')
    dumper = AnsibleDumper()
    print(dumper.represent_data(a))


if __name__ == '__main__':
    # execute unit test
    test_represent_vault_encrypted_unicode()

# Generated at 2022-06-25 04:35:21.770786
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # prepare test data
    hv = HostVars(
        host_name='localhost',
        hostvars_type=HostVars.NONE,
        vars_as_dict=VarsWithSources({'ring': 'test'})
    )

    output = yaml.dump([hv], Dumper=AnsibleDumper, default_flow_style=False)
    # This should be an empty dictionary
    assert output == u'\n- hostvars:\n    ring: test\n    _hostvars_type: none\n    _hostvars_name: localhost\n'



# Generated at 2022-06-25 04:35:33.295853
# Unit test for function represent_undefined
def test_represent_undefined():
    # Test that regular values are not affected.
    yaml.assert_equal(yaml.dump(1/3), ".3333333333333333\n")
    yaml.assert_equal(yaml.dump(True), "true\n")

    # Test that Undefined() fails with this function.
    yaml.assert_raises(yaml.representer.RepresenterError, yaml.dump, AnsibleUndefined)
    # Test that Undefined() fails with this dump function.
    yaml.assert_raises(yaml.representer.RepresenterError, AnsibleDumper().dump, AnsibleUndefined)

    # Test that Undefined() does not fail with regular dump function.
    yaml.assert_equal(yaml.Dumper().dump(AnsibleUndefined), '')
    # Test that Undefined() does not fail with

# Generated at 2022-06-25 04:35:36.596373
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper(allow_unicode=True)
    test_bytes = u'foo\u1234bar'
    actual = dumper.represent_binary(test_bytes)
    expected = u'!binary |-\n  Zm9v4pyWYmFy\n'
    assert actual == expected

# Generated at 2022-06-25 04:35:42.193333
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dumper = AnsibleDumper()
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256'
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    actual = dumper.represent_vault_encrypted_unicode(data)
    expected = u'!vault |\n  ' + ciphertext.decode()
    assert actual == expected

# Generated at 2022-06-25 04:36:21.442366
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Generate random data
    dict_0 = {}
    ansible_mapping_0 = module_4.AnsibleMapping(dict_0)
    list_0 = []
    ansible_sequence_0 = module_4.AnsibleSequence(list_0)
    complex_0 = ansible_mapping_0._data
    ansible_unsafe_text_0 = module_3.AnsibleUnsafeText(complex_0)
    ansible_unsafe_bytes_0 = module_3.AnsibleUnsafeBytes(complex_0)
    ansible_mapping_1 = module_4.AnsibleMapping(complex_0)
    ansible_sequence_1 = module_4.AnsibleSequence(complex_0)
    ansible_vault_encrypted_unicode_0 = module

# Generated at 2022-06-25 04:36:28.274562
# Unit test for function represent_unicode
def test_represent_unicode():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = 'base64'
    str_1 = '} O2"l/'
    str_2 = None
    dict_1 = {str_0: ansible_dumper_0, str_1: ansible_dumper_0, str_2: ansible_dumper_0}
    ansible_

# Generated at 2022-06-25 04:36:39.223507
# Unit test for function represent_binary
def test_represent_binary():
    # Test passing with basic value
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()
    tuple_

# Generated at 2022-06-25 04:36:44.260239
# Unit test for function represent_unicode
def test_represent_unicode():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    list_0 = []
    ansible_vault_encrypted_unicode_0 = module_4.AnsibleVaultEncryptedUnicode(list_0)
    var_0 = represent_vault_encrypted_unicode(ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 04:36:53.546289
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:37:03.812587
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:37:12.935945
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:37:16.315714
# Unit test for function represent_binary
def test_represent_binary():
    ansible_dumper_0 = AnsibleDumper()
    ansible_unsafe_bytes_0 = module_3.AnsibleUnsafeBytes()
    var_0 = ansible_dumper_0.represent_binary(ansible_unsafe_bytes_0)
    list_0 = []
    var_1 = represent_binary(list_0)


# Generated at 2022-06-25 04:37:21.383107
# Unit test for function represent_unicode
def test_represent_unicode():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:37:29.652536
# Unit test for function represent_unicode
def test_represent_unicode():
    complex_0 = None
    str_0 = "Ixl<1)b0ZI^"
    str_1 = "R\x7f N"
    unicode_0 = "W`"
    str_2 = 'y'
    list_0 = [complex_0, str_0, str_1, unicode_0, str_2]
    ansible_dumper_0 = AnsibleDumper(list_0)
    ansible_unicode_0 = AnsibleUnicode(complex_0)
    var_0 = ansible_dumper_0.represent_data(ansible_unicode_0)


# Generated at 2022-06-25 04:38:11.855791
# Unit test for function represent_binary
def test_represent_binary():
    assert [False] == [False]

# Generated at 2022-06-25 04:38:12.704192
# Unit test for function represent_binary
def test_represent_binary():
    pass


# Generated at 2022-06-25 04:38:18.506965
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:38:24.397268
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:38:31.741759
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:38:41.038632
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = -4748.37193
    float_1 = -4748.37193
    float_2 = -4748.37193
    complex_0 = float(float_2)
    complex_1 = complex(float_1, float_0)
    complex_2 = complex(float_2, float_1)
    complex_3 = complex(float_1, float_2)
    complex_4 = complex(float_0, float_1)
    complex_5 = complex(float_0, float_0)
    dict_0 = {complex_4: float_2, complex_5: float_2, complex_2: float_1, complex_3: complex_5, complex_1: float_0, complex_0: float_2}
    async_iterator_0 = dict_0.__aiter__()

# Generated at 2022-06-25 04:38:49.747780
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:38:50.377590
# Unit test for function represent_binary
def test_represent_binary():
    pass


# Generated at 2022-06-25 04:39:01.027109
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()

# Generated at 2022-06-25 04:39:04.657901
# Unit test for function represent_binary
def test_represent_binary():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0, complex_0: complex_0}
    async_iterator_0 = None
    float_0 = -4748.37193
    host_vars_vars_0 = module_0.HostVarsVars(async_iterator_0, float_0)
    ansible_dumper_0 = AnsibleDumper(dict_0, host_vars_vars_0)
    str_0 = '#9FzChmB0P<?NWx!G'
    ansible_undefined_0 = module_2.AnsibleUndefined(str_0)
    async_iterator_1 = ansible_undefined_0.__aiter__()