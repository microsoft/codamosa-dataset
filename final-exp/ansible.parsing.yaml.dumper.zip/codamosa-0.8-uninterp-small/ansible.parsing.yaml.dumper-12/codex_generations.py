

# Generated at 2022-06-25 04:32:06.916537
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    pass

# Generated at 2022-06-25 04:32:08.504890
# Unit test for function represent_binary
def test_represent_binary():
    m_data = None
    m_self = AnsibleDumper()
    m_self.represent_binary(m_data)


# Generated at 2022-06-25 04:32:09.755773
# Unit test for function represent_undefined
def test_represent_undefined():
    # FIXME: provide tests here
    raise NotImplementedError('FIXME: provide tests here')


# Generated at 2022-06-25 04:32:11.691349
# Unit test for function represent_binary
def test_represent_binary():
    data = b'foo'
    var_0 = yaml.representer.SafeRepresenter.represent_binary(data)
    assert var_0 == b'>-\n  foo\n'


# Generated at 2022-06-25 04:32:17.373815
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined

    # Ensure that the function throws an exception when
    # incorrect types are sent
    with pytest.raises(TypeError) as excinfo:
        represent_undefined(data)
    assert "object of type 'AnsibleUndefined' has no len()" in str(excinfo.value)

# Generated at 2022-06-25 04:32:26.845586
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    list_0 = None
    assert (represent_vault_encrypted_unicode(list_0) is None)

# Generated at 2022-06-25 04:32:28.293466
# Unit test for function represent_binary
def test_represent_binary():
    s = b"test_binary"
    represent_binary(s)


# Generated at 2022-06-25 04:32:30.366758
# Unit test for function represent_binary
def test_represent_binary():
    binary_0 = represent_binary
    binary_0(binary_0)



# Generated at 2022-06-25 04:32:33.251601
# Unit test for function represent_undefined
def test_represent_undefined():
    # Bool should ensure _fail_with_undefined_error
    # if the value is Undefined
    assert represent_undefined(None, AnsibleUndefined) == True
    # End of test_case_0() function



# Generated at 2022-06-25 04:32:34.784422
# Unit test for function represent_unicode
def test_represent_unicode():
    list_0 = None
    var_0 = represent_unicode(list_0)


# Generated at 2022-06-25 04:32:41.918847
# Unit test for function represent_binary
def test_represent_binary():
    """This function is called by the yaml dumper and
    should return a bytestring that the dumper can serialize.
    """
    # This is a python3-esque byte string
    byte_string = b"\xff\x12"
    dumper = AnsibleDumper()
    result = dumper.represent_binary(byte_string)
    assert result == b'!binary |\n  /+8=\n'

# Generated at 2022-06-25 04:32:43.816332
# Unit test for function represent_undefined
def test_represent_undefined():
    test = AnsibleUndefined
    assert represent_undefined(SafeDumper(), test) == 'null\n...\n'

# Generated at 2022-06-25 04:32:46.437552
# Unit test for function represent_binary
def test_represent_binary():
    data = b'foo'
    output = yaml.representer.SafeRepresenter.represent_binary(AnsibleDumper, data)
    assert output == u"!binary |\n  Zm9v\n"



# Generated at 2022-06-25 04:32:57.274687
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    cls = AnsibleVaultEncryptedUnicode
    data = cls('$ANSIBLE_VAULT;1.1;AES256;foo\n332f3937323536653264383938316366656263663330373163643331303565353266393738666565\n32336166643934616663653265313531353135313531353135313531353135313539393939393939\n39393931623934626137646233633937633036336665643436663433623466333734663833623165\n65343663303365386666656436333464343562666238636335333436616334\n')
    dumper = AnsibleDumper()
    dumper.add

# Generated at 2022-06-25 04:33:00.391944
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined()
    assert AnsibleDumper.represent_undefined(AnsibleDumper(), data) is False

# Generated at 2022-06-25 04:33:04.849591
# Unit test for function represent_undefined
def test_represent_undefined():
    import datetime

    # Undefined should be writeable
    data = [datetime.datetime.now(), AnsibleUndefined('something')]
    d = AnsibleDumper(width=10)
    assert d.represent_data(data) is not None
    assert d.represent_unicode(u'foo')



# Generated at 2022-06-25 04:33:09.063413
# Unit test for function represent_hostvars
def test_represent_hostvars():
    data = {'test': 'test'}
    dumper = AnsibleDumper(None)

    data = HostVars(data)
    rep = represent_hostvars(dumper, data)
    rep_data = yaml.load(rep)
    assert rep_data['test'] == 'test'

# Generated at 2022-06-25 04:33:20.305012
# Unit test for function represent_hostvars
def test_represent_hostvars():
    def get_hostname(data):
        return data._host.get_name()

    def get_hostvars(data):
        return data._host.get_vars()

    def get_host(data):
        return data._host

    hostvars_obj = HostVars('test')
    host_vars_obj = HostVarsVars('test', {})

    obj = {get_hostname: hostvars_obj,
           get_host: host_vars_obj}

    result = yaml.dump(obj, Dumper=AnsibleDumper, default_flow_style=False)
    assert result == (
        u'get_host: !hostvars\n'
        u'get_hostname: !hostvars\n'
    )



# Generated at 2022-06-25 04:33:22.379813
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(binary_type('abc')).strip() == '!!binary |\n  YWJj'


# Generated at 2022-06-25 04:33:27.568616
# Unit test for function represent_unicode
def test_represent_unicode():
    dumper = AnsibleDumper
    data = u'unicodetest'
    repr_data = yaml.representer.SafeRepresenter.represent_unicode(dumper, data)
    # repr_data returns a tuple with the first element being the unicode string and the second being a scalar string
    # We check that the unicode string is equal to the data passed in
    # This is effectively testing if our represent_unicode function
    # is getting called
    assert repr_data[0] == data


# Generated at 2022-06-25 04:33:39.946601
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import argparse
    # Test yaml output
    string = '''
    ---
    test_host:[
    {
        "varname_1": "value_1",
        "varname_2" : "value_2"
    }
    ]
    ...
    '''
    p = argparse.ArgumentParser(description='backwards compatability test')
    o = p.add_argument('--hostvars', type=text_type, action='store', dest='hostvars', default=None)
    results = p.parse_args(['--hostvars', 'test_host', 'varname_1=value_1', 'varname_2=value_2'])

# Generated at 2022-06-25 04:33:47.214282
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    Returns the YAML representation of HostVars.
    """
    data = HostVars(dict(a=1, b=2, c=3), 'some_path')
    new_data = yaml.load(yaml.dump(data, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)
    assert new_data == {'a': 1, 'b': 2, 'c': 3}
    # test hostvarsvars
    data = HostVarsVars(dict(a=1, b=2, c=3), 'some_path')
    new_data = yaml.load(yaml.dump(data, Dumper=AnsibleDumper), Loader=yaml.SafeLoader)

# Generated at 2022-06-25 04:33:57.045532
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test with a HostVars object
    hv = HostVars()
    data = {'a': 'b'}
    hv.data = data
    output = yaml.dump(hv, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == "a: b\n"

    # Test with a HostVarsVars object
    hvv = HostVarsVars()
    hvv.data = data
    output = yaml.dump(hvv, default_flow_style=False, Dumper=AnsibleDumper)
    assert output == "a: b\n"



# Generated at 2022-06-25 04:33:58.672731
# Unit test for function represent_undefined
def test_represent_undefined():
    assert not AnsibleDumper.represent_undefined(None, AnsibleUndefined())

# Generated at 2022-06-25 04:34:08.767548
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from copy import deepcopy

    # create a hostvars object
    hostvars = HostVars(var1='foo', var2='bar', var3=[1, 2, 3], var4={'a': 'b', 'c': 'd'})

    # dump the hostvars object
    yaml.dump(hostvars, stream=None, Dumper=AnsibleDumper, default_flow_style=False)

    # create a dictionary with the same attributes
    hostvars_dict = {'var1': 'foo', 'var2': 'bar', 'var3': [1, 2, 3], 'var4': {'a': 'b', 'c': 'd'}}

    # dump the dictionary

# Generated at 2022-06-25 04:34:13.846994
# Unit test for function represent_hostvars
def test_represent_hostvars():
    import ansible.vars.hostvars as hostvars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    d = AnsibleDumper()
    h = hostvars.HostVars(dict(a=1), dict(b=2))
    m = VariableManager()
    t = Templar(m)
    d.represent_data(dict(a=h, b=t))

# Generated at 2022-06-25 04:34:22.680937
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable

    dumper = AnsibleDumper
    templar = Templar(loader=None, variables=VariableManager())

    # Variables used for the test
    undefined = templar._fail_with_undefined_error('hello', '{{hello}}', attempting_to_render=False)
    unsafe = templar.template('{{ hello | to_json }}', dict(hello=undefined), fail_on_undefined=False)
    # Make sure the templar works as expected.
    assert isinstance(unsafe, AnsibleUnsafeText)

    # Now use AnsibleDumper's representer

# Generated at 2022-06-25 04:34:32.415198
# Unit test for function represent_unicode
def test_represent_unicode():

    import six

    assert yaml.dump(six.u("test"), Dumper=AnsibleDumper) == 'test\n...\n'
    assert yaml.dump(six.u("12345"), Dumper=AnsibleDumper) == '12345\n...\n'
    assert yaml.dump(six.u(""), Dumper=AnsibleDumper) == '\n...\n'
    assert yaml.dump(six.u("@#$@#%@#&@#"), Dumper=AnsibleDumper) == '@#$@#%@#&@#\n...\n'
    assert yaml.dump(six.u("asdf-asd"), Dumper=AnsibleDumper) == 'asdf-asd\n...\n'

# Generated at 2022-06-25 04:34:35.959025
# Unit test for function represent_undefined
def test_represent_undefined():
    assert AnsibleDumper.represent_undefined(AnsibleDumper, object()) is False
    assert AnsibleDumper.represent_undefined(AnsibleDumper, 'foo') is True
    assert AnsibleDumper.represent_undefined(AnsibleDumper, AnsibleUndefined('foo')) is True

# Generated at 2022-06-25 04:34:41.780742
# Unit test for function represent_unicode
def test_represent_unicode():
    """
    Test that unicode strings are present as unicode strings in the yaml output
    """

    data = [u'abc123', u'\u2026']
    serialized_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert serialized_data == u"- abc123\n- '\u2026'\n"



# Generated at 2022-06-25 04:34:55.827106
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    data = AnsibleUnsafeBytes(b'f\x00o\x00o\x00')
    assert dumper.represent_binary(data) == '!!binary |\n  ZgAAAG8A'



# Generated at 2022-06-25 04:34:59.169780
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    test_string = u'hello world'
    av = AnsibleVaultEncryptedUnicode(test_string)
    av_repr = represent_vault_encrypted_unicode(AnsibleDumper, av)
    assert yaml.safe_load(av_repr) == u'hello world'



# Generated at 2022-06-25 04:35:05.953929
# Unit test for function represent_hostvars
def test_represent_hostvars():
    output = yaml.dump(HostVars({u'spam': u'eggs'}), Dumper=SafeDumper)
    assert output == '{spam: eggs}\n'


# Generated at 2022-06-25 04:35:08.626745
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ''' represent_hostvars function should return a string '''
    from ansible.parsing.yaml.objects import AnsibleUnicode
    test_val = {'mykey': 'myval'}
    test_dump = AnsibleDumper.represent_dict(test_val)
    if not isinstance(test_dump, text_type):
        return False
    return True


if __name__ == '__main__':
    print(test_represent_hostvars())

# Generated at 2022-06-25 04:35:09.744152
# Unit test for function represent_binary
def test_represent_binary():
    file_data = open(__file__, 'rb').read()
    assert AnsibleDumper(file_data).represent_unicode(file_data).endswith(file_data)

# Generated at 2022-06-25 04:35:20.070184
# Unit test for function represent_hostvars
def test_represent_hostvars():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsWithSources
    import yaml
    import io

    f = io.BytesIO()
    datastructure = AnsibleMapping({u'key1': u'value1'})
    hostvars = HostVars(hostname=u'hostname', hostvars=datastructure)
    vars_with_sources = VarsWithSources(hostname=u'hostname', hostvars=hostvars)

    AnsibleDumper.add_representer(
        HostVars,
        represent_hostvars,
    )


# Generated at 2022-06-25 04:35:22.101043
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper(None)
    dump = dumper.represent_undefined(AnsibleUndefined('some text'))
    assert dump is None



# Generated at 2022-06-25 04:35:28.003448
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template.safe_eval import AnsibleUndefined

    undefined = AnsibleUndefined('varname')

    assert '<varname> is undefined' == yaml.dump(undefined, Dumper=AnsibleDumper)

# Generated at 2022-06-25 04:35:29.885710
# Unit test for function represent_unicode
def test_represent_unicode():
    dat = AnsibleUnsafeText(u'foobar')
    assert represent_unicode(None, dat) == 'foobar'


# Generated at 2022-06-25 04:35:36.241225
# Unit test for function represent_hostvars
def test_represent_hostvars():

    hostvars = HostVars().vars

    result = yaml.dump(hostvars, Dumper=AnsibleDumper)

    # Output data is indented for readability. The actual output
    # is a single line.
    result = result.replace('\n', ' ')

    # Output should be a dictionary with one entry with a key
    # of 'vars' and an empty dictionary as the value.
    assert result == "vars: {}"



# Generated at 2022-06-25 04:36:10.407124
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    var_4 = represent_vault_encrypted_unicode()
    assert var_4 == var_3


# Generated at 2022-06-25 04:36:20.884070
# Unit test for function represent_unicode
def test_represent_unicode():
    int_2 = -4474
    dict_1 = None
    int_0 = -2773
    float_0 = -677.495
    float_1 = -0.0077
    str_0 = '\x19\xff\x1c\xac*\xaa\x94\xaf\x15'
    float_2 = -0.8
    float_3 = 0.0
    list_0 = []
    float_4 = -0.5
    float_5 = 4690.0
    float_6 = -10.8
    list_1 = []

# Generated at 2022-06-25 04:36:27.950558
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '\xab]\xbe\xa0\xda\xad\xad\xef\x15'
    list_0 = []
    bytes_0 = b'\x1c\x1e\x7f\x0c\x17L\xac8\xee\x98\x12\xe0K\x8d\x1a\x10\xaf\x06\xbd\x85\x82\x1f\xf1\x7fr\x9c\x9f5\x1c\x19\x83'
    var_0 = represent_binary(bytes_0)
    list_1 = []
    int_0 = -2059
    set_0 = {str_0, int_0, str_0}
    ansible_dumper_0

# Generated at 2022-06-25 04:36:33.901476
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(42, 42)
    float_0 = -249.9
    var_0 = represent_vault_encrypted_unicode(float_0)

    # Testing with an invalid argument (should raise a TypeError)
    try:
        represent_vault_encrypted_unicode(ansible_vault_encrypted_unicode_0)
    except TypeError:
        pass


# Generated at 2022-06-25 04:36:42.607918
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = 'l#7'
    str_1 = 'G'
    int_0 = -1
    float_0 = -6791.268
    int_1 = -1
    str_2 = 'G'
    float_1 = -6791.268
    str_3 = 'l#7'
    int_2 = -1
    float_2 = -6791.268
    int_3 = -1
    str_4 = 'G'
    float_3 = -6791.268
    str_5 = 'l#7'
    int_4 = -1
    float_4 = -6791.268
    int_5 = -1
    str_6 = 'G'
    float_5 = -6791.268
    str_7 = 'l#7'

# Generated at 2022-06-25 04:36:53.087025
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = '\\D\r0}'
    int_0 = -1728
    str_1 = '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    set_0 = {str_1, int_0, str_1}
    dict_0 = None
    int_1 = 446
    ansible_dumper_0 = AnsibleDumper(dict_0, str_1, int_0, int_0, int_1)
    float_0 = -332.737
    ansible_undefined_0 = module_1.AnsibleUnd

# Generated at 2022-06-25 04:37:03.285965
# Unit test for function represent_unicode
def test_represent_unicode():
    str_0 = '%\x1d\x9f\'\x1f\x97w\x19\x8d\x13\x94\x19\x95\x9a\x1a\x1b\x96\x02<\x02\x17\x16\x1a\x10'
    int_0 = -3164
    str_1 = '\n    name: debug\n    short_description: Executes tasks in interactive debug session.\n    description:\n        - Task execution is \'linear\' but controlled by an interactive debug session.\n    version_added: "2.1"\n    author: Kishin Yagami (!UNKNOWN)\n'
    set_0 = {str_1, int_0, str_1}
    dict_0 = {}

# Generated at 2022-06-25 04:37:09.955803
# Unit test for function represent_binary
def test_represent_binary():
    float_0 = -332.737
    bytes_0 = b'P\xa6\x1ej\x84V\x14\xc9\xcc\x9d~\x1b\x8d\x90\xa1E\xb4'
    var_0 = represent_binary(float_0)

    var_1 = represent_binary(bytes_0)



# Generated at 2022-06-25 04:37:19.648766
# Unit test for function represent_binary
def test_represent_binary():
    str_0 = '~t\x8d\xad\x90\x11\xb7\xbb\x87\x99\xd4\x1c\x94\xe10\x03\xcb'
    dict_0 = None
    int_0 = -1673
    str_1 = 'task'
    ansible_dumper_0 = AnsibleDumper(dict_0, int_0, str_1)
    float_0 = -543.7
    float_1 = -7.1

# Generated at 2022-06-25 04:37:30.638281
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    str_0 = '$\x86'
    float_0 = -2423.080739
    str_1 = 'Hd\x9a'
    int_0 = 4202
    str_2 = '\n    name: ec2\n    short_description: create, terminate, start or stop an instance in ec2\n    description:\n        - Creates or terminates ec2 instances.\n    version_added: "2.0"\n    options:\n'
    dict_0 = {str_1: str_2, str_0: int_0, str_2: str_1}
    int_1 = 6124
    ansible_dumper_0 = AnsibleDumper(dict_0, str_2, float_0, float_0, int_1)
    float_1 = 0.197
