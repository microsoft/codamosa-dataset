

# Generated at 2022-06-25 04:32:04.204689
# Unit test for function represent_binary
def test_represent_binary():
    assert True


# Generated at 2022-06-25 04:32:07.725211
# Unit test for function represent_binary
def test_represent_binary():
    # Should work, nothing to see here.
    # Not sure what to test here.
    # Arguments don't matter.

    class FakeArgs(object):
        def __init__(self, data):
            self.data = data
    fargs = FakeArgs('Fake data')
    func = represent_binary(fargs)


# Generated at 2022-06-25 04:32:16.268398
# Unit test for function represent_binary
def test_represent_binary():
    try:
        from unittest import mock
    except ImportError:
        import mock
    with mock.patch('ansible.module_utils.common.yaml.objects.yaml.representer.SafeRepresenter.represent_binary') as mock_represent_binary:
        with mock.patch('ansible.module_utils.common.yaml.objects.binary_type') as mock_binary_type:
            try:
                represent_binary('foo')
            except TypeError:
                pass
            else:
                assert False
    try:
        from unittest import mock
    except ImportError:
        import mock

# Generated at 2022-06-25 04:32:25.158612
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Test with simple AnsibleVaultEncryptedUnicode
    # Should return the data
    data = AnsibleVaultEncryptedUnicode('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61343566383436323963323936336162346560336530643631663365653530333533356637353666\n          33303534363961306335363462623333653630333434323661333435663732326264353361333830\n          39\n', 'test', 'test')
    # Expected: The data

# Generated at 2022-06-25 04:32:35.134061
# Unit test for function represent_binary
def test_represent_binary():

    raw_dict_0 = {
        'vars': {'foo': 'bar', 'bar': 'baz'},
        'hosts': ['a', 'b', 'c'],
    }
    raw_dict_1 = {
        'vars': {
            'foo': AnsibleUnicode('bar'),
            'bar': 'baz',
        },
        'hosts': ['a', 'b', 'c'],
    }
    raw_dict_2 = {
        'vars': AnsibleVaultEncryptedUnicode('bar', 'baz', 'baz'),
        'hosts': ['a', 'b', 'c'],
    }

# Generated at 2022-06-25 04:32:38.922053
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import AnsibleUndefined
    ansible_undefined = AnsibleUndefined()
    var_0 = represent_undefined(ansible_undefined)
    assert var_0 == False

# Generated at 2022-06-25 04:32:46.971515
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Init AnsibleMapping object
    data = AnsibleMapping()

    # Init AnsibleVaultEncryptedUnicode object
    var_0 = AnsibleVaultEncryptedUnicode()
    var_0._ciphertext = binary_type('correct_horse_battery_staple')

    data['var_0'] = var_0

    # Init AnsibleUnsafeBytes object
    var_1 = AnsibleUnsafeBytes()
    var_1.string = u'correct_horse_battery_staple'

    data['var_1'] = var_1

    # Init AnsibleUnicode object
    var_2 = AnsibleUnicode()
    var_2.string = u'correct_horse_battery_staple'

    data['var_2'] = var_2

    # Init AnsibleUnsafe

# Generated at 2022-06-25 04:32:52.575273
# Unit test for function represent_hostvars
def test_represent_hostvars():

    # Init
    tuple_0 = ()
    var_0 = AnsibleDumper(tuple_0)

    # Test
    tuple_1 = ()
    tuple_1 = (dict())
    var_1 = yaml.representer.SafeRepresenter.represent_dict(var_0, tuple_1)


# Generated at 2022-06-25 04:32:53.678007
# Unit test for function represent_unicode
def test_represent_unicode():
    pass



# Generated at 2022-06-25 04:32:56.215144
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    # Case 0
    tuple_0 = ()
    var_0 = represent_vault_encrypted_unicode(tuple_0)


test_represent_vault_encrypted_unicode()

# Generated at 2022-06-25 04:33:05.853268
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    ad = AnsibleDumper
    data = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n1234567890123456789012345678901234567890123456789012345678901234\n')
    output = ad.represent_vault_encrypted_unicode(ad, data)
    assert output == ad.represent_scalar('!vault', data._ciphertext.decode(), style='|')


# Generated at 2022-06-25 04:33:08.471289
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    dump = yaml.safe_dump(AnsibleVaultEncryptedUnicode(b'ENC[blahblah]'))
    assert dump == "!vault\n|\n  ENC[blahblah]\n"

# Generated at 2022-06-25 04:33:13.120806
# Unit test for function represent_unicode
def test_represent_unicode():
    data = AnsibleUnicode("this\x00is\x00a\x00test")
    assert yaml.load(yaml.dump([data], Dumper=AnsibleDumper))[0] == "this\x00is\x00a\x00test"



# Generated at 2022-06-25 04:33:22.750638
# Unit test for function represent_undefined
def test_represent_undefined():
    from ansible.template import Jinja2Template
    from ansible.template.clean import Cleaner
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.template.vars import AnsibleVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import tempfile

    temp = tempfile.NamedTemporaryFile(delete=True)
    temp.write(b"foo: '{{ foo }}'\n"); temp.flush()

# Generated at 2022-06-25 04:33:24.511164
# Unit test for function represent_unicode
def test_represent_unicode():
    ''' represent_unicode should represent unicode objects the same as yaml.representer.SafeRepresenter.represent_str '''
    pass

# Generated at 2022-06-25 04:33:27.148087
# Unit test for function represent_undefined
def test_represent_undefined():
    data = AnsibleUndefined("Current")
    # Here __bool__ is used to check the type and will
    # raise UndefinedError() if isinstance(data, UndefinedType)
    assert AnsibleDumper().represent_undefined(data)



# Generated at 2022-06-25 04:33:32.547510
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # represent_hostvars should not fail when dumping a HostVars object
    # without any variables set (it raises an exception without this fix
    # because the HostVars object is not iterable).
    hv = HostVars()
    assert yaml.dump([hv], Dumper=AnsibleDumper) == "[{}]\n"

# Generated at 2022-06-25 04:33:35.803683
# Unit test for function represent_unicode
def test_represent_unicode():
    obj = AnsibleUnicode('foo')
    yaml.safe_dump(obj, default_flow_style=False)



# Generated at 2022-06-25 04:33:43.845843
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    data = AnsibleVaultEncryptedUnicode('foo')
    output_string = '!vault |\n          ' + data._ciphertext.decode()
    rep = yaml.representer.SafeRepresenter()
    actual_output = yaml.representer.BaseRepresenter.represent_scalar(rep, u'!vault', data._ciphertext.decode(), style='|')
    assert output_string == actual_output

# Generated at 2022-06-25 04:33:49.743894
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.dump(u'\u2665', Dumper=AnsibleDumper) == '"\\u2665"\n'
    assert yaml.dump(b'\xe2\x99\xa5', Dumper=AnsibleDumper) == "'\\xe2\\x99\\xa5'\n"



# Generated at 2022-06-25 04:33:57.513777
# Unit test for function represent_binary
def test_represent_binary():
    dumper = AnsibleDumper()
    assert dumper.represent_binary(b'abc') == yaml.representer.SafeRepresenter.represent_binary(dumper, b'abc')
    assert dumper.represent_binary(b'abc') != yaml.representer.SafeRepresenter.represent_str(dumper, 'abc')

# Generated at 2022-06-25 04:34:00.356499
# Unit test for function represent_binary
def test_represent_binary():
    s = AnsibleDumper().represent_binary('täst'.encode('utf-8'))
    assert s == '!!binary |\n  dMOzdA==\n'


# Generated at 2022-06-25 04:34:05.212337
# Unit test for function represent_binary
def test_represent_binary():
    assert yaml.representer.SafeRepresenter.represent_binary(object(), b'string') == "!!binary 'c3RyaW5n'\n"

# Generated at 2022-06-25 04:34:15.363163
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    secret = VaultSecret('1234567890123456')
    vault = VaultLib(secret)
    plaintext = "{'bar': 'baz'}"
    ciphertext = vault.encrypt(plaintext)
    data = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-25 04:34:17.972531
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars(dict(a=1))
    out = yaml.dump(hv, Dumper=AnsibleDumper)
    assert out == u'{a: 1}\n'

# Generated at 2022-06-25 04:34:24.154961
# Unit test for function represent_undefined
def test_represent_undefined():
    dumper = AnsibleDumper

    class FakeData:
        pass

    fake_data = FakeData()

    assert dumper.add_representer(AnsibleUndefined, represent_undefined)
    rc = None
    try:
        rc = dumper.represent_undefined(dumper, fake_data)
    except ValueError as e:
        assert str(e) == "Failed to serialize undefined value for yaml"
    assert rc is False

# Generated at 2022-06-25 04:34:27.144991
# Unit test for function represent_unicode
def test_represent_unicode():
    o = AnsibleUnicode('é')
    assert yaml.dump(o) == "!!ansible-unicode 'é'\n"

    o = u'é'
    assert yaml.dump(o) == "é\n"



# Generated at 2022-06-25 04:34:31.118469
# Unit test for function represent_binary
def test_represent_binary():
    expected_result = yaml.representer.SafeRepresenter.represent_str(None, binary_type(u'hello'))
    actual_result = represent_binary(None, AnsibleUnsafeBytes(u'hello'))
    assert actual_result == expected_result


# Generated at 2022-06-25 04:34:33.871824
# Unit test for function represent_hostvars
def test_represent_hostvars():
    hv = HostVars({"key": "value"})
    assert AnsibleDumper().represent_data(hv) in [
        u"{key: value}",
        u"{key: value}\n",
    ]



# Generated at 2022-06-25 04:34:38.054240
# Unit test for function represent_vault_encrypted_unicode
def test_represent_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password='random password')
    encrypted_data = vault.encrypt('test')
    data = AnsibleVaultEncryptedUnicode(encrypted_data)

    obj = AnsibleDumper.represent_vault_encrypted_unicode(AnsibleDumper(), data)
    assert obj.value == encrypted_data.decode()



# Generated at 2022-06-25 04:34:58.772970
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # raise ValueError(str_0)
    pass


# Generated at 2022-06-25 04:35:08.290888
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # TODO: add test for when data is not a collections.Mapping
    # so we test for ``raise TypeError``
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)

# Generated at 2022-06-25 04:35:14.455656
# Unit test for function represent_hostvars
def test_represent_hostvars():
    """
    Test: 'represent_hostvars'
    """
    input_0 = 'UNKNOWN'
    test_0 = [{u"foo": u"bar",u"a": u"b"}]
    expected_0 = u"{foo: bar, a: b}\n"
    actual_0 = yaml.dump(test_0, default_flow_style=False, Dumper=AnsibleDumper)
    assert actual_0 == expected_0, "Expected {}, got {}".format(expected_0, actual_0)
    test_0 = [{u"foo\nbar": u"baz\n<html>"}]
    expected_0 = u"{foo\\nbar: baz\\n<html>}\n"

# Generated at 2022-06-25 04:35:23.383355
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(str_1, str_2)
    ansible_dumper_0.represent_data = lambda a: a
    ansible_dumper_0.list_tags = lambda: {}
    ansible_dumper_0.add_representer = lambda a, b: a
    ansible_dumper_0.add_multi_representer = lambda a, b: a
    ansible_dumper_0.represent_sequence = lambda a: a
    ansible_dumper_0.represent_dict = lambda a: a
    ansible_dumper_0.represent_scalar = lambda a, b, c: a


# Generated at 2022-06-25 04:35:30.144258
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_dumper_0 = AnsibleDumper()
    ansible_dumper_1 = AnsibleDumper()
    ansible_dumper_2 = AnsibleDumper()
    ansible_dumper_3 = AnsibleDumper()
    ansible_dumper_4 = AnsibleDumper()
    ansible_dumper_5 = AnsibleDumper()
    ansible_dumper_6 = AnsibleDumper()
    ansible_dumper_7 = AnsibleDumper()
    ansible_dumper_8 = AnsibleDumper()
    ansible_dumper_9 = AnsibleDumper()
    ansible_dumper_10 = AnsibleDumper()
    ansible_dumper_11 = AnsibleDumper()
    ansible_dumper_12 = AnsibleDumper()
    ansible_

# Generated at 2022-06-25 04:35:36.280305
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = 'X'
    str_1 = 'MP'
    ansible_dumper_0 = type(str_0, (object,), {})()
    ansible_vault_encrypted_unicode_0 = type(str_1, (object,), {})()
    ansible_vault_encrypted_unicode_0.ciphertext = ''
    ansible_vault_encrypted_unicode_0._ciphertext = ''
    var_0 = represent_hostvars(ansible_dumper_0)
    var_1 = represent_hostvars(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:35:39.343063
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # test function: represent_hostvars
    represent_hostvars(set_0)


# Generated at 2022-06-25 04:35:45.388940
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)
    var_0 = represent_hostvars(ansible_dumper_1)


# Generated at 2022-06-25 04:35:56.212655
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Test for unhandled type
    try:
        tuple_0 = (bytes(),)
        set_0 = {bytes(), bytes(), bytes()}
        str_0 = 'v%'
        str_1 = 'r)3w_7Vk]~D\r'
        ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_0, str_1)
        var_0 = represent_hostvars(ansible_dumper_0)
        pytest.fail("should raise exception")
    except AssertionError as e:
        pytest.fail("exception is thrown, but should be handled")

    # Test for unhandled type

# Generated at 2022-06-25 04:35:57.332084
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # TODO: Implement test for function represent_hostvars.
    pass


# Generated at 2022-06-25 04:36:18.028223
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)
    ansible_dumper_0.hostvars = ansible_dumper_1
    var_0 = represent_hostvars(None)


# Generated at 2022-06-25 04:36:27.147999
# Unit test for function represent_hostvars
def test_represent_hostvars():
    ansible_unicode_0 = module_1.AnsibleUnicode(None)
    ansible_unsafe_text_0 = None
    ansible_unsafe_bytes_0 = None
    ansible_undefined_0 = None
    hostvars_0 = module_1.HostVars(ansible_unicode_0, ansible_unsafe_text_0, ansible_unsafe_bytes_0)
    hostvars_vars_0 = module_1.HostVarsVars(ansible_unicode_0, ansible_unsafe_text_0, ansible_unsafe_bytes_0)
    ansible_sequence_0 = None
    ansible_mapping_0 = None

# Generated at 2022-06-25 04:36:34.774147
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = "FO"
    str_1 = "Te_"
    str_2 = "Te_F"
    str_3 = "Te_FO"
    str_4 = "Te_FOC"
    str_5 = "Te_FOCU"
    str_6 = "Te_FOCUS"
    str_7 = "Te_FOCUS_"
    str_8 = "Te_FOCUS_T"
    str_9 = "Te_FOCUS_TE"
    str_10 = "Te_FOCUS_TES"
    str_11 = "Te_FOCUS_TEST"
    str_12 = "Te_FOCUS_TESTS"
    str_13 = "Te_FOCUS_TESTS_"

# Generated at 2022-06-25 04:36:39.420737
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    bytes_0 = b"f\xaa\xa9\t\x1e\xc6'&\xbc"
    var_0 = ansible_dumper_0.represent_data(bytes_0)


# Generated at 2022-06-25 04:36:49.249954
# Unit test for function represent_hostvars
def test_represent_hostvars():
    # Should have type HostVars
    ansible_hostvars_0 = HostVars(str())
    tuple_0 = (ansible_hostvars_0,)
    # Should have type HostVarsVars
    ansible_hostvars_vars_0 = HostVarsVars(str())
    tuple_1 = (ansible_hostvars_vars_0,)
    # Should have type VarsWithSources
    ansible_vars_with_sources_0 = VarsWithSources(str())
    tuple_2 = (ansible_vars_with_sources_0,)

# Generated at 2022-06-25 04:37:00.191292
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)
    bytes_0 = b"f\xaa\xa9\t\x1e\xc6'&\xbc"
    ansible_unsafe_bytes_0 = None
    ans

# Generated at 2022-06-25 04:37:08.988802
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)
    ansible_dumper_1.represent_data(str_2)
    hostvars_0 = HostVars()

# Generated at 2022-06-25 04:37:15.729476
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    ansible_dumper_1 = AnsibleDumper(tuple_0, ansible_dumper_0, ansible_dumper_0)
    ansible_unsafe_bytes_0 = None

# Generated at 2022-06-25 04:37:20.824100
# Unit test for function represent_hostvars
def test_represent_hostvars():
    str_0 = ", elements value check is supported only with 'list' type"
    tuple_0 = (str_0,)
    set_0 = {str_0, str_0, str_0}
    str_1 = 'e;]*%jfYgVa\\'
    str_2 = 'SY2+x\\Zjs?mr*'
    ansible_dumper_0 = AnsibleDumper(tuple_0, set_0, str_1, str_2)
    var_0 = represent_hostvars(tuple_0)


# Generated at 2022-06-25 04:37:22.942863
# Unit test for function represent_hostvars
def test_represent_hostvars():
    pass
