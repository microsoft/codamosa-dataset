

# Generated at 2022-06-24 01:42:47.798226
# Unit test for function get_domain
def test_get_domain():
    config.init(
        {
            "hvcs": "github",
            "hvcs_domain": "github.com",
            "token": "",
            "owner": "",
            "repository": "",
        }
    )
    # GitHub
    assert get_domain() == "github.com"

    config.init(
        {
            "hvcs": "gitlab",
            "token": "",
            "hvcs_domain": "gitlab.com",
            "owner": "",
            "repository": "",
        }
    )
    # Gitlab
    assert get_domain() == "gitlab.com"



# Generated at 2022-06-24 01:42:49.629424
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    print(Gitlab.token())
    # None
    

# Generated at 2022-06-24 01:42:50.508566
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert True, "Tests not implemented"


# Generated at 2022-06-24 01:42:58.128541
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    import pytest
    from .hvcs import Base


    @staticmethod
    def domain() -> str:
        raise NotImplementedError


    @staticmethod
    def api_url() -> str:
        raise NotImplementedError


    @staticmethod
    def token() -> Optional[str]:
        raise NotImplementedError


    @classmethod
    def check_build_status(cls, owner: str, repo: str, ref: str) -> bool:
        raise NotImplementedError


    class ClassUnderTest(Base):
        pass

    with pytest.raises(NotImplementedError):
        ClassUnderTest.check_build_status('', '', '')

# Generated at 2022-06-24 01:43:00.672822
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    __testTokenAuth = TokenAuth(
        token="",
    )
    assert __testTokenAuth.__call__(
        r=None,
    ) is None
    pass



# Generated at 2022-06-24 01:43:02.108725
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert Base.check_build_status("owner", "repo", "ref") == False



# Generated at 2022-06-24 01:43:06.638515
# Unit test for method api_url of class Base
def test_Base_api_url():
    pass



# Generated at 2022-06-24 01:43:14.099409
# Unit test for method token of class Github
def test_Github_token():
    actual = Github.token()
    expected = os.environ.get("GH_TOKEN")
    assert actual == expected

# Generated at 2022-06-24 01:43:18.651875
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    logger.debug(__name__)
    domain_1 = Gitlab.domain()
    hvcs_domain = config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))
    domain_2 = hvcs_domain if hvcs_domain else "gitlab.com"
    assert domain_1 == domain_2



# Generated at 2022-06-24 01:43:22.742042
# Unit test for method session of class Github
def test_Github_session():
    assert isinstance(Github.session(), Session)
    assert Github.session().auth is not None



# Generated at 2022-06-24 01:43:33.808364
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():

    no_environ_vars = {
        'CI_SERVER_HOST': None,
        'HVCS_DOMAIN': None,
    }
    with patch.dict('os.environ', no_environ_vars):

        assert Gitlab.domain() == 'gitlab.com'

    with patch.dict('os.environ', {'CI_SERVER_HOST': 'gitlab.example.org'}):

        assert Gitlab.domain() == 'gitlab.example.org'

    with patch.dict('os.environ', {'CI_SERVER_HOST': 'gitlab.example.org'}):

        assert Gitlab.domain() == 'gitlab.example.org'


# Generated at 2022-06-24 01:43:36.388930
# Unit test for constructor of class Base
def test_Base():
    try:
        Base()
    except NotImplementedError:
        assert True
    else:
        raise AssertionError



# Generated at 2022-06-24 01:43:37.797621
# Unit test for function get_token
def test_get_token():
    assert get_token() == "dummy"
get_token.__test__ = False



# Generated at 2022-06-24 01:43:41.015656
# Unit test for constructor of class Github
def test_Github():
    Github.domain()
    Github.api_url()
    Github.token()
    Github.auth()
    Github.session()
    Github.check_build_status("", "", "")
    Github.upload_dists("", "", "", "")



# Generated at 2022-06-24 01:43:51.626680
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    import pytest

    from .helpers import httpretty

    html = (
        '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n'
        '<html><head>\n'
        '<title>404 Not Found</title>\n'
        "<meta charset='utf-8'>"
        "</head><body>\n"
        '<h1>Not Found</h1>\n'
        '<p>The requested URL / was not found on this server.</p>\n'
        "<hr>\n"
        '<address>Apache/2.4.7 (Ubuntu) Server at api.github.com Port 443</address>\n'
        "</body></html>\n"
    )


# Generated at 2022-06-24 01:43:54.673705
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("owner", "repo", "branch")



# Generated at 2022-06-24 01:43:57.413789
# Unit test for method token of class Github
def test_Github_token():
    """
    Test method token of class Github
    """
    expected = None
    actual = Github.token()
    assert expected == actual



# Generated at 2022-06-24 01:44:00.429472
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == 'github.com' or Base.domain() == 'gitlab.com' or Base.domain() == 'bitbucket.org'

# Generated at 2022-06-24 01:44:01.444108
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-24 01:44:03.043228
# Unit test for function check_token
def test_check_token():
    """
    Test for the check_token function
    """
    assert check_token() is True, "Expected True"

# Generated at 2022-06-24 01:44:06.245802
# Unit test for function post_changelog
def test_post_changelog():
    if get_hvcs().__name__ == 'Github':
        assert post_changelog('informatics-lab', 'pandas-profiling', '1.4.0', 'New release') == True
    if get_hvcs().__name__ == 'Gitlab':
        assert post_changelog('informatics-lab', 'pandas-profiling', '1.4.0', 'New release') == False


# Generated at 2022-06-24 01:44:10.107438
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    response = TokenAuth("token")
    assert response



# Generated at 2022-06-24 01:44:11.036611
# Unit test for method domain of class Base
def test_Base_domain():
    value = Base.domain()

# Generated at 2022-06-24 01:44:12.137754
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    assert TokenAuth("dummy") == TokenAuth("dummy")



# Generated at 2022-06-24 01:44:15.881854
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    os.environ['CI_SERVER_HOST'] = 'gitlab.com'
    os.environ['GL_TOKEN'] = 'xyz'
    assert Gitlab().domain() == 'gitlab.com'


# Generated at 2022-06-24 01:44:17.100127
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == "localhost"



# Generated at 2022-06-24 01:44:22.906903
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Test case 1:
    # Expected result: True
    assert Github.check_build_status(owner="owner", repo="repo", ref="ref") == True

    # Test case 2:
    # Expected result: True
    assert Github.check_build_status(owner="owner", repo="repo", ref="ref") == True



# Generated at 2022-06-24 01:44:25.598756
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") is False


# Generated at 2022-06-24 01:44:26.472547
# Unit test for function get_token
def test_get_token():
    get_token()

# Generated at 2022-06-24 01:44:31.427206
# Unit test for function upload_to_release
def test_upload_to_release():
    owner = "test_owner"
    repo = "test_repo"
    version = "test_version"
    path = "test_path"
    # test_upload_to_release return None
    assert upload_to_release(owner, repo, version) is None

# Generated at 2022-06-24 01:44:43.336530
# Unit test for constructor of class Github
def test_Github():
    assert Github.domain() == "github.com"
    assert Github.api_url() == "https://api.github.com"
    assert (
        Github.token()
        == "token 73e8d8c64060a499e92c06daf2f1b9c9b58a0daa")
    assert Github.auth() == TokenAuth("73e8d8c64060a499e92c06daf2f1b9c9b58a0daa")
    assert Github.check_build_status("stanfordnmbl", "osim-rl",
                                     "28d8cbe4a4e55f4c59d7f26a64e5f7dfcb06f92f")

# Generated at 2022-06-24 01:44:45.292751
# Unit test for function get_token
def test_get_token():
    """
    Unit tests for function get_token
    """
    assert get_hvcs().token() is not None



# Generated at 2022-06-24 01:44:48.436181
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token_auth = TokenAuth(token="token")
    request = {}
    result = token_auth(request)
    assert result == {"headers": {"Authorization": "token token"}}



# Generated at 2022-06-24 01:44:50.845120
# Unit test for constructor of class Gitlab
def test_Gitlab():
    gl = Gitlab()
    assert gl.domain() == "gitlab.com"
    assert gl.api_url() == "https://" + gl.domain()


# Generated at 2022-06-24 01:44:54.665081
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    TokenAuth.__call__(
        None,
        r=mock.Mock(
            headers={"Authorization": "token {self.token}"},
        ),
    )

# Generated at 2022-06-24 01:44:55.625259
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() != None


# Generated at 2022-06-24 01:44:57.261248
# Unit test for method api_url of class Base
def test_Base_api_url():
    with pytest.raises(NotImplementedError):
        Base.api_url()

# Generated at 2022-06-24 01:44:59.162336
# Unit test for method session of class Github
def test_Github_session():
    session = Github.session()
    assert session.auth == Github.auth()
    assert session.headers["Accept"] == "application/vnd.github.v3+json"


# Generated at 2022-06-24 01:45:04.951058
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("gopniko/deblibs", "master", "89e6a84be0c5cbabfbd9d1790a8e1d5a5e5a5e5e5") is False
    assert check_build_status("gopniko/deblibs", "master", "89e6a84be0c5cbabfbd9d1790a8e1d5a5e5a5e5a") is True


# Generated at 2022-06-24 01:45:06.040431
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-24 01:45:08.072634
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == "github.com"




# Generated at 2022-06-24 01:45:10.484076
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    auth1 = TokenAuth("token1")
    auth2 = TokenAuth("token2")

    assert auth1 == auth2

    auth2.token = auth1.token

    assert auth1 == auth2


# Generated at 2022-06-24 01:45:13.792842
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab.domain() == "gitlab.com"
    assert Gitlab.api_url() == "https://gitlab.com"
    assert Gitlab.token() is None



# Generated at 2022-06-24 01:45:17.600872
# Unit test for function check_token
def test_check_token():
    # Test case 1
    config["hvcs"] = "github"
    os.environ["GH_TOKEN"] = "112233445566778899"
    assert check_token() == True

    # Test case 2
    config["hvcs"] = "gitlab"
    del os.environ["GH_TOKEN"]
    os.environ["GL_TOKEN"] = "112233445566778899"
    assert check_token() == True

    # Test case 3
    config["hvcs"] = "github"
    del os.environ["GL_TOKEN"]
    assert check_token() == False

# Generated at 2022-06-24 01:45:20.097531
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == "http://example.com"

# Generated at 2022-06-24 01:45:21.848550
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base().domain() == NotImplemented



# Generated at 2022-06-24 01:45:25.575764
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__(): 
    token = '862f195d96f830484ecb8a84a92bfbcb42c01e80'
    t = TokenAuth(token)
    assert(t.token == token)
    assert(t.__call__)
    assert(t.__call__ != None)



# Generated at 2022-06-24 01:45:27.195737
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("owner", "repository", "version", "changelog") == True

# Generated at 2022-06-24 01:45:28.891351
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    logging.getLogger("").setLevel(logging.DEBUG)
    Gitlab.api_url()

# Generated at 2022-06-24 01:45:32.092410
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://{domain}".format(domain="gitlab.com")

# Generated at 2022-06-24 01:45:37.803126
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    token_auth_1 = TokenAuth(token='AAA')
    token_auth_2 = TokenAuth(token='AAA')
    token_auth_3 = TokenAuth(token='BBB')
    token_auth_4 = object
    assert token_auth_1 == token_auth_1
    assert token_auth_1 == token_auth_2
    assert token_auth_1 != token_auth_3
    assert token_auth_1 != token_auth_4


# Generated at 2022-06-24 01:45:45.900388
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    token_present = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    os.environ["GL_TOKEN"] = token_present
    assert Gitlab.token() == token_present
    token_missing = ""
    os.environ["GL_TOKEN"] = token_missing
    assert Gitlab.token() == None


# Generated at 2022-06-24 01:45:48.268212
# Unit test for function get_domain
def test_get_domain():
    """
    Unit test for function get_domain
    """
    assert get_domain() == ""



# Generated at 2022-06-24 01:45:59.333860
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    from .helpers import modify_environment

    # Test using GH_TOKEN env variable
    if not Github.token():
        with modify_environment(GH_TOKEN="token"):
            test_Github_check_build_status()

    # Test with failed and successful build
    with modify_environment(
        TRAVIS_BRANCH="master", TRAVIS_PULL_REQUEST="false", TRAVIS_REPO_SLUG="org/repo"
    ):
        assert Github.check_build_status("org", "repo", "sha1")

    # Test with no GH_TOKEN env variable
    with modify_environment(GH_TOKEN=None):
        assert not Github.check_build_status("org", "repo", "sha1")



# Generated at 2022-06-24 01:46:00.768195
# Unit test for function get_domain
def test_get_domain():
    """
    Tests the function get_domain.
    """
    assert get_domain() == "gitlab.com", "The domain should be gitlab.com"

# Generated at 2022-06-24 01:46:02.888225
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token = "123"
    auth = TokenAuth(token)
    assert isinstance(auth, AuthBase)
    assert auth.token == token



# Generated at 2022-06-24 01:46:06.905939
# Unit test for function check_build_status
def test_check_build_status():
    assert not check_build_status('njamescode', 'git-changelog', 'master')

# Generated at 2022-06-24 01:46:09.405395
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-24 01:46:10.421685
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab()



# Generated at 2022-06-24 01:46:13.988182
# Unit test for method __ne__ of class TokenAuth

# Generated at 2022-06-24 01:46:14.673468
# Unit test for constructor of class Github
def test_Github():
    Github()



# Generated at 2022-06-24 01:46:15.671190
# Unit test for function get_token
def test_get_token():
    assert get_token() is None


# Generated at 2022-06-24 01:46:16.601177
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token()



# Generated at 2022-06-24 01:46:17.656579
# Unit test for constructor of class Github
def test_Github():
    assert Github is not None



# Generated at 2022-06-24 01:46:19.081973
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    print(Gitlab.api_url())
    

# Generated at 2022-06-24 01:46:22.517605
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    class MockConfig:
        def get(self, key):
            return "gitlab.com"

    config.get = MockConfig().get
    assert Gitlab.api_url() == "https://gitlab.com"


# Generated at 2022-06-24 01:46:26.663435
# Unit test for function get_token
def test_get_token():
    if os.environ.get('CI_SERVER_HOST', None) == 'github.com':
        assert get_token() == os.environ['GITHUB_TOKEN']
    elif os.environ.get('CI_SERVER_HOST', None) == 'gitlab.com':
        assert get_token() == os.environ['GL_TOKEN']
    else:
        assert get_token() is None


# Generated at 2022-06-24 01:46:32.821231
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert(
        Github.api_url()
        == "https://api.github.com"
    ), "Expected 'https://api.github.com' for default Github.api_url"

    config.set("hvcs_domain", "test.github.com")
    assert(
        Github.api_url()
        == "https://test.github.com"
    ), "Expected 'https://test.github.com' for Github.api_url with 'hvcs_domain' set in config file"

    config.set("hvcs_domain", "api.github.com")

# Generated at 2022-06-24 01:46:35.010665
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://gitlab.com"


# Generated at 2022-06-24 01:46:36.352666
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == "https://foo.com"

# Generated at 2022-06-24 01:46:36.928043
# Unit test for function check_token
def test_check_token():
    assert check_token() is True

# Generated at 2022-06-24 01:46:39.892540
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("gosa", "gosa", "ef8928a2b6c30be01a7b") == False
    assert check_build_status("gosa", "gosa-plugin-ci", "6d50c6f2e6f8c71aad1f") == True


# Generated at 2022-06-24 01:46:43.793664
# Unit test for method api_url of class Base
def test_Base_api_url():
    class TestBase(Base):
        # Dummy Base class to unit test `api_url` method
        @staticmethod
        def domain():
            return "dummy.com"

    assert TestBase.api_url() == "https://dummy.com/api/v4/"



# Generated at 2022-06-24 01:46:45.914157
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() is not None

# Generated at 2022-06-24 01:46:52.737041
# Unit test for method auth of class Github
def test_Github_auth():
    """Test for method auth of class Github"""
    # Is this class method?
    if not hasattr(Github, "auth") or not callable(getattr(Github, "auth")):
        raise AssertionError("Class Github has no method auth")

    print(
        "[PASS] Method auth of class Github found and callable"
    )  # noqa E501

# Generated at 2022-06-24 01:46:57.497114
# Unit test for function check_build_status
def test_check_build_status():
    # Successful case.
    config.set("hvcs","Github")
    assert Github.check_build_status("owner","repo", "sha1") == True
    # Failing case.
    assert Github.check_build_status("owner","repo", "sha1") == False



# Generated at 2022-06-24 01:47:04.731704
# Unit test for function check_token
def test_check_token():
    class TestClass(Base):
        @staticmethod
        def token() -> Optional[str]:
            return os.environ.get("TEST_HVCS_TOKEN")
    # Tests if it can't find the env var
    with mock.patch("release.hvcs.Base", return_value=TestClass):
        assert check_token() == False
    # Tests if it can find the env var
    with mock.patch("release.hvcs.Base", return_value=TestClass):
        assert check_token() == True

# Generated at 2022-06-24 01:47:13.016263
# Unit test for method session of class Github
def test_Github_session():
    from unittest.mock import Mock
    from .utils import MockResponse

    instance = Github()
    expected = session = Github.session()

    env = {}

    try:
        os.environ["GH_TOKEN"] = "gh_token"

        response = MockResponse()
        response.status_code = 200
        response.raise_for_status = Mock()

        session.request = Mock(return_value=response)

        actual = instance.session()

        assert actual == expected

    finally:
        os.environ.clear()
        os.environ.update(env)



# Generated at 2022-06-24 01:47:14.851187
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    base = Base()
    assert base.check_build_status("", "", "") == False



# Generated at 2022-06-24 01:47:17.230451
# Unit test for method domain of class Github
def test_Github_domain():
  assert Github.domain() == 'github.com'


# Generated at 2022-06-24 01:47:27.609097
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():

    # Arrange
    token_auth_1 = object()
    token_auth_2 = object()
    assert token_auth_1.__eq__(token_auth_2) is NotImplemented

    # Act
    token_auth_1 = TokenAuth(object())
    token_auth_2 = TokenAuth(object())

    # Assert
    assert token_auth_1.__eq__(token_auth_2) is False

    # Act
    token_auth_1 = TokenAuth(object())
    token_auth_2 = TokenAuth(token_auth_1.token)

    # Assert
    assert token_auth_1.__eq__(token_auth_2) is True



# Generated at 2022-06-24 01:47:28.157776
# Unit test for function get_token
def test_get_token():
    assert get_token() is not None


# Generated at 2022-06-24 01:47:29.404446
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-24 01:47:31.548757
# Unit test for function upload_to_release
def test_upload_to_release():
    assert GitHub.upload_dists()

# Generated at 2022-06-24 01:47:33.569160
# Unit test for method api_url of class Github
def test_Github_api_url():
    Github._fix_mime_types()
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-24 01:47:37.202409
# Unit test for function check_token
def test_check_token():
    """
    Unit test for function check_token
    """
    assert check_token() is not None

# Generated at 2022-06-24 01:47:42.579583
# Unit test for method auth of class Github
def test_Github_auth():
    """Test Github auth function"""
    assert Github.auth() == TokenAuth(os.environ.get("GH_TOKEN"))



# Generated at 2022-06-24 01:47:50.382333
# Unit test for method domain of class Base
def test_Base_domain():
    import sys
    import pytest
    from .helpers import (
        add_cls_method_to_module,
        remove_cls_method_from_module,
    )
    from .context import Base
    from .helpers import dummy

    add_cls_method_to_module(Base, "domain", dummy, "dummy")
    try:
        result = Base.domain()
    except NotImplementedError:
        pytest.fail("NotImplementedError unexpectedly raised")
    finally:
        remove_cls_method_from_module(Base, "domain")
    assert result == "dummy"

# Generated at 2022-06-24 01:47:53.083449
# Unit test for constructor of class Base
def test_Base():
    from gitlab_tools.helpers.unittests import mock_config
    import gitlab_tools.hvcs
    mock_config(gitlab_tools.hvcs)
    return Base

# Generated at 2022-06-24 01:47:57.014296
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth("x")


# Generated at 2022-06-24 01:48:06.472753
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status(): 
    owner = "Test_owner"
    repo = "Test_repo"
    ref = "Test_ref"
    gl = gitlab.Gitlab('https://git.ocb.int', private_token='z_8qy3TpxzbbbezSxzDv')
    gl.auth()
    jobs = gl.projects.get(owner + "/" + repo).commits.get(ref).statuses.list()
    assert Gitlab.check_build_status(owner, repo, ref) == False

if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 01:48:11.457244
# Unit test for constructor of class Base
def test_Base():
    with pytest.raises(NotImplementedError):
        Base()



# ugprade to gitlab 9.4.4, see https://gitlab.com/gitlab-org/gitlab-ce/issues/35257

# Generated at 2022-06-24 01:48:13.354259
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs.__name__ == 'get_hvcs'


# Generated at 2022-06-24 01:48:20.639922
# Unit test for constructor of class Base
def test_Base():
    class Concrete(Base):
        @staticmethod
        def domain() -> str:
            pass

        @staticmethod
        def api_url() -> str:
            pass

        @staticmethod
        def token() -> str:
            pass

        @staticmethod
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            pass

        @classmethod
        def post_release_changelog(
            cls, owner: str, repo: str, version: str, changelog: str
        ) -> bool:
            pass

        @classmethod
        def upload_dists(cls, owner: str, repo: str, version: str, path: str) -> bool:
            pass

    Concrete()



# Generated at 2022-06-24 01:48:26.721947
# Unit test for function check_build_status
def test_check_build_status():
    class MockGithub(Base):
        @staticmethod
        def check_build_status(*args):
            return True

    def mock_get_hvcs():
        return MockGithub()

    try:
        with patch("hvcs.github"), patch("hvcs.get_hvcs", mock_get_hvcs):
            check_build_status("owner", "repository", "ref")
    except Exception as err:
        raise AssertionError(err) from err



# Generated at 2022-06-24 01:48:34.266709
# Unit test for method session of class Github
def test_Github_session():
    from unittest.mock import patch

    from .hvcs import Base
    from .hvcs import Github

    def mock_build_requests_session(*args, **kwargs):
        return args, kwargs

    with patch(
        "semantic_release.hvcs.build_requests_session", side_effect=mock_build_requests_session
    ):
        args, kwargs = Github.session()
        assert args == ()
        assert kwargs == {
            "raise_for_status": True,
            "retry": True,
        }


# Generated at 2022-06-24 01:48:35.421201
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("user","repo","ref") == False


# Generated at 2022-06-24 01:48:40.534466
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    hvcs_domain = config.get("hvcs_domain")
    domain = hvcs_domain if hvcs_domain else Github.DEFAULT_DOMAIN
    # commit has been pushed, check is there build available
    Github.check_build_status("tensorflow", "tensorboard", "d0ddd73f233085f8e62227c2ceb0a9f5e7f829ec")
    # commit has not been pushed, no build message should be displayed
    Github.check_build_status("tensorflow","tensorboard","21d1de6fea0a7a8683c8b6bd73b9a9b2afe867e1")



# Generated at 2022-06-24 01:48:43.739252
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("owner","repo","1.0.0","changelog") == Github.post_release_changelog.return_value


# Generated at 2022-06-24 01:48:47.768952
# Unit test for constructor of class Github
def test_Github():
    """Test for constructor of class Github"""
    obj = Github()
    assert isinstance(obj, Github), "constructor failed"


# Generated at 2022-06-24 01:48:50.910642
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "hailteam"
    repo = "vep"
    ref = "35831"
    assert Gitlab.check_build_status(owner, repo, ref) == True
    

# Generated at 2022-06-24 01:48:54.702225
# Unit test for function upload_to_release
def test_upload_to_release():
    owner = "tormod17"
    repository = "hvcs-utils"
    version = "0.1.1"
    path = "./dist/"

    assert upload_to_release(owner, repository, version, path) == True

# Generated at 2022-06-24 01:48:59.744616
# Unit test for function get_hvcs
def test_get_hvcs():
    """
        Test the get_hvcs() function
    """
    import config

    # Github case :
    config.set_property('hvcs', 'github')
    assert type(get_hvcs()) == Github
    # Gitlab case :
    config.set_property('hvcs', 'gitlab')
    assert type(get_hvcs()) == Gitlab



# Generated at 2022-06-24 01:49:02.974129
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    """Test to check if the code properly raises an exception when
    no implementation is provided.
    """
    with pytest.raises(NotImplementedError):
        cls = Base()
        cls.check_build_status("test", "test", "test")


# Generated at 2022-06-24 01:49:03.767297
# Unit test for constructor of class Github
def test_Github():
    assert isinstance(Github(), Base)



# Generated at 2022-06-24 01:49:07.467788
# Unit test for constructor of class Base
def test_Base():
    with Base() as base:
        assert base.domain() == base.api_url()



# Generated at 2022-06-24 01:49:12.986918
# Unit test for method session of class Github
def test_Github_session():
    # Test the session method of class Github
    gh_token = "dummy_gh_auth"
    try:
        os.environ["GH_TOKEN"] = gh_token
        auth = Github.auth()
        session = Github.session()
    finally:
        del os.environ["GH_TOKEN"]
    correct_auth = TokenAuth(gh_token)
    assert auth == correct_auth



# Generated at 2022-06-24 01:49:16.046914
# Unit test for method domain of class Base
def test_Base_domain():
    from .github import Github
    from .gitlab import Gitlab

    assert Base.domain() is None
    assert Github.domain() == "github.com"
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-24 01:49:18.094614
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == \
        "https://github.com"

# Generated at 2022-06-24 01:49:19.687235
# Unit test for method domain of class Base
def test_Base_domain():
    assert False, "Test not implemented."


# Generated at 2022-06-24 01:49:24.594072
# Unit test for method auth of class Github
def test_Github_auth():
    """Test for method auth of class Github"""

    # Setup
    Github.token = lambda: "test"

    # Exercise
    actual = Github.auth

    # Verify
    assert actual.token == "test"

    # Cleanup - none necessary



# Generated at 2022-06-24 01:49:25.767581
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    raw_request = None
    agent = TokenAuth(1)
    assert agent(raw_request).headers == {'Authorization': 'token 1'}



# Generated at 2022-06-24 01:49:28.472785
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    class MockBase:
        @staticmethod
        def check_build_status(*args, **kwargs):
            pass

    MockBase.check_build_status(owner="", repo="", ref="")

# Generated at 2022-06-24 01:49:29.999237
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    assert TokenAuth("token") != TokenAuth("token2")
    assert TokenAuth("token") == TokenAuth("token")


# Generated at 2022-06-24 01:49:33.489112
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()

# Generated at 2022-06-24 01:49:35.790818
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() == "gitlab.com"



# Generated at 2022-06-24 01:49:36.657391
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    TokenAuth("token")



# Generated at 2022-06-24 01:49:38.867719
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    assert TokenAuth("3") == TokenAuth("3")
    assert TokenAuth("3") != TokenAuth("4")
    assert TokenAuth("3") != "3"
    assert TokenAuth("3") != None


# Generated at 2022-06-24 01:49:40.277390
# Unit test for method session of class Github
def test_Github_session():
    req = Github.session().get(Github.domain())
    assert req.ok



# Generated at 2022-06-24 01:49:41.347270
# Unit test for method token of class Base
def test_Base_token():
    with pytest.raises(NotImplementedError):
        Base.token()


# Generated at 2022-06-24 01:49:42.852879
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    assert Gitlab.token() is not None


# Generated at 2022-06-24 01:49:44.240798
# Unit test for method token of class Base
def test_Base_token():
    # Setup
    # Exercise
    # Verify
    assert Base.token() is None


# Generated at 2022-06-24 01:49:47.230361
# Unit test for method domain of class Github
def test_Github_domain():
    # Test a valid call to the method
    assert Github.domain() == Github.DEFAULT_DOMAIN or Github.domain().startswith("api.")
    if config.get("hvcs_domain"):
        assert Github.domain() == config.get("hvcs_domain")



# Generated at 2022-06-24 01:49:49.090920
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token_auth = TokenAuth("token")
    assert token_auth.token == "token"



# Generated at 2022-06-24 01:49:53.032108
# Unit test for method domain of class Base
def test_Base_domain():
    # Setup requirements
    expected_result = 'test domain'
    class _BaseChild(Base):
        @staticmethod
        def domain():
            return expected_result
    obj = _BaseChild()
    # Call the method(s) under test
    result = obj.domain()
    # Check the result
    assert result == expected_result

# Generated at 2022-06-24 01:49:54.667838
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-24 01:49:55.836354
# Unit test for function check_token
def test_check_token():
    assert check_token() == True


# Generated at 2022-06-24 01:50:00.405803
# Unit test for method api_url of class Base
def test_Base_api_url():
    # Failure case of test case, raises error
    with pytest.raises(NotImplementedError):
        # Calling api_url with arguments
        Base.api_url()


# Generated at 2022-06-24 01:50:01.456956
# Unit test for constructor of class Gitlab
def test_Gitlab():
    gl = Gitlab()
    assert gl

# Generated at 2022-06-24 01:50:08.468293
# Unit test for method api_url of class Base
def test_Base_api_url():
    from .errors import ImproperConfigurationError

    with LoggedFunction(logger) as (logger, start, _):
        logger.debug("Testing Base.api_url")
        try:
            actual = Base.api_url()
        except ImproperConfigurationError as ex:
            logger.debug(
                "Skipped as ImproperConfigurationError was thrown as this is expected"
            )
            return
        # UNIT UNDER TEST: Raise error
        raise AssertionError(f"Expected ImproperConfigurationError to be raised")



# Generated at 2022-06-24 01:50:11.508463
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    assert Gitlab.token() == os.environ.get("GL_TOKEN")

 

# Generated at 2022-06-24 01:50:18.532049
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    from http import client
    import urllib3.fields
    import urllib3.util
    import urllib3.request
    import requests

    class MockRequest(urllib3.request.RequestMethods):
        def __init__(self, method, url, headers=None, body=None):
            self.method = method
            self.url = url
            self.headers = headers or {}
            self.body = body
            self.stream = None
            self.method = method
            self.redirect_location = None

        def get_method(self):
            return self.method

    class MockResponse(client.HTTPResponse):
        def __init__(self):
            self.status = 200
            self.reason = "status reason"

# Generated at 2022-06-24 01:50:23.797369
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    class TokenAuth1(TokenAuth):
        def __init__(self, token):
            self.token = token

    class TokenAuth2(TokenAuth):
        def __init__(self, token):
            self.token = token

    token1 = "1"
    token2 = "2"

    assert TokenAuth1(token1) != TokenAuth1(token2)
    assert TokenAuth1(token1) != TokenAuth2(token1)
    assert TokenAuth1(token1) != "TokenAuth1(token1)"

# Generated at 2022-06-24 01:50:29.276340
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    try:
        Gitlab.domain()
    except Exception as e:
        logger.exception(f"Gitlab.domain: {e}")
        assert False
    assert True



# Generated at 2022-06-24 01:50:30.016186
# Unit test for function check_build_status
def test_check_build_status():
    assert False



# Generated at 2022-06-24 01:50:31.244299
# Unit test for function get_domain
def test_get_domain():
    test_hvcs = get_hvcs().__class__.__name__
    assert get_domain() == test_hvcs.lower()



# Generated at 2022-06-24 01:50:36.884278
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    """
    Test if the method api_url returns the correct url.
    """
    config.update({"hvcs_domain": "test"})
    assert Gitlab.api_url() == "https://test"
    config.update({"hvcs_domain": None})
    assert Gitlab.api_url() == "https://gitlab.com"


# Generated at 2022-06-24 01:50:38.792580
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token() == 'HVCS_TOKEN_VALUE'
    

# Generated at 2022-06-24 01:50:44.819045
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    assert (
        TokenAuth(token="token")
        == TokenAuth(token="token")
        == TokenAuth(token="token")
        == TokenAuth(token="token")
    )
    assert (
        TokenAuth(token="token")
        != TokenAuth(token=None)
        != TokenAuth(token="token2")
        != TokenAuth(token="token2")
    )
    assert (
        TokenAuth(token="token")
        != object()
        != object()
        != object()
        != object()
    )



# Generated at 2022-06-24 01:50:51.550663
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set('hvcs', 'github')
    hvcs = get_hvcs()
    assert hvcs.__class__.__name__ == 'Github'
    config.set('hvcs', 'gitlab')
    hvcs = get_hvcs()
    assert hvcs.__class__.__name__ == 'Gitlab'
    config.set('hvcs', 'none')
    with pytest.raises(ImproperConfigurationError) as e:
        get_hvcs()
        assert '"none" is not a valid option for hvcs.' in str(e)


# Generated at 2022-06-24 01:50:53.739175
# Unit test for function check_token
def test_check_token():
    assert callable(check_token)



# Generated at 2022-06-24 01:50:57.251116
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    test_case1 = os.environ.get("GL_TOKEN")
    result1 = Gitlab.token()
    test_case2 = os.environ.get("a")
    result2 = Gitlab.token()
    assert (test_case1 == result1 and result2 == None)

# Generated at 2022-06-24 01:51:01.108781
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-24 01:51:01.711958
# Unit test for function get_token
def test_get_token():
    assert get_token() is not None

# Generated at 2022-06-24 01:51:12.588213
# Unit test for function get_hvcs
def test_get_hvcs():
    config["hvcs"]="github"
    assert get_hvcs()==Github
    config["hvcs"]="gitlab"
    assert get_hvcs()==Gitlab
    assert get_hvcs.__doc__=="Get HVCS helper class\n\n:raises ImproperConfigurationError: if the hvcs option provided is not valid"
    try:
        config["hvcs"]="bitbucket"
        get_hvcs()
        assert False
    except ImproperConfigurationError as e:
        assert str(e)=="'bitbucket' is not a valid option for hvcs."

# Generated at 2022-06-24 01:51:18.249499
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(config.get("github_api_token"))



# Generated at 2022-06-24 01:51:29.416909
# Unit test for function check_token
def test_check_token():
    # True test
    config.set("hvcs", "github")
    os.environ["GITHUB_TOKEN"] = "token"
    assert check_token()
    # False test
    config.set("hvcs", "github")
    os.environ["GITHUB_TOKEN"] = ""
    assert not check_token()
    # Error test
    config.set("hvcs", "gitlab")
    os.environ["GITHUB_TOKEN"] = ""
    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    os.environ["GL_TOKEN"] = "token"
    assert check_token()
    os.environ["GITHUB_TOKEN"] = "token"
    assert check_token()


# Generated at 2022-06-24 01:51:30.681682
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("owner", "repository", "version", "changelog")


# Generated at 2022-06-24 01:51:31.685310
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None

# Generated at 2022-06-24 01:51:34.299800
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    os.environ["CI_SERVER_HOST"] = "mydomain"
    assert Gitlab.api_url() == "https://mydomain"
    del os.environ["CI_SERVER_HOST"]



# Generated at 2022-06-24 01:51:43.810788
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        assert Gitlab.check_build_status("vitu-ai", "xain", "5f1e0f53c8e2d41f9bad0d5b5a0b5f89d63a1793") == False
        print("test_Gitlab_check_build_status: Passed")
    except:
        print("test_Gitlab_check_build_status: Failed")


# Generated at 2022-06-24 01:51:48.377970
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    # Test for local instance
    os.environ["GL_TOKEN"] = "test_token"
    assert Gitlab.token() == "test_token"



# Generated at 2022-06-24 01:51:50.164046
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    instance = TokenAuth(token='token')
    other = TokenAuth(token='token')
    assert instance == other



# Generated at 2022-06-24 01:51:57.252907
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    (
        monkeypatch.setattr(
            Gitlab,
            "token",
            lambda: "mytoken",
        )
    )
    gl = gitlab.Gitlab("https://gitlab.com", private_token="mytoken")
    gl.auth()
    jobs = [{"status": "success"}, {"status": "skipped"}, {"status": "failed"}]
    jobs_failure = [{"status": "success"}, {"status": "failed"}]
    monkeypatch.setattr(
        gl.projects,
        "get",
        lambda owner, repo: Mock(commits=Mock(get=Mock(statuses=Mock(list=lambda: jobs)))),
    )


# Generated at 2022-06-24 01:52:02.406843
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    """
    TokenAuth.__ne__
    """
    a = TokenAuth(token="someToken")
    b = TokenAuth(token="someToken")
    c = TokenAuth(token="someOtherToken")
    assert a != b
    assert a != c



# Generated at 2022-06-24 01:52:09.792584
# Unit test for function post_changelog
def test_post_changelog():
    # Check if function post_changelog is working correctly
    owner = "owner_test"
    repository = "repository_test"
    version_test = "version_test"
    changelog = "changelog_test"
    # Create an instance of the class Github
    request_hvcs_test = Github()
    # Initialize a variable for the method get_hvcs
    hvcs = get_hvcs()
    # Check if the function returns True
    assert post_changelog(owner, repository, version_test, changelog) == True



# Generated at 2022-06-24 01:52:12.504933
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://gitlab.com"



# Generated at 2022-06-24 01:52:23.621690
# Unit test for function post_changelog
def test_post_changelog():

    # We fake the changelog for the testing purposes
    def fake_post_changelog(cls, owner: str, repo: str, version: str, changelog: str):
        # We set our changelog as a static field
        cls.changelog = changelog
        return True

    # We fake the changelog
    Base.post_release_changelog = fake_post_changelog

    assert post_changelog(None, None, None, None)
    assert Github.changelog is None
    assert Gitlab.changelog is None

    assert post_changelog("owner", "repo", "version", "changelog")
    assert Github.changelog == "changelog"
    assert Gitlab.changelog is None

# Generated at 2022-06-24 01:52:27.153348
# Unit test for constructor of class Github
def test_Github():
    """Unit test for the constructor of class Github
    """
    assert Github() is not None



# Generated at 2022-06-24 01:52:33.961187
# Unit test for method auth of class Github
def test_Github_auth():
    from .settings import config
    from .hvcs import Github
    existing_auth_method = config.get("auth_method")
    existing_token = config.get("token")
    try:
        config["auth_method"] = "token"
        config["token"] = "test-token"
        assert Github.auth() == TokenAuth("test-token")
    finally:
        config["auth_method"] = existing_auth_method
        config["token"] = existing_token



# Generated at 2022-06-24 01:52:44.349368
# Unit test for method session of class Github
def test_Github_session():
    """Unit test for method session of class Github"""

    config.set("hvcs_domain", "custom.domain")
    assert Github.api_url() == "https://custom.domain"
    os.environ["GH_TOKEN"] = "token"
    assert Github.token() == "token"
    try:
        assert Github.session().auth.token == "token"
        Github.session().close()
    except:
        pass

    config.set("hvcs_domain", "")
    assert Github.api_url() == "https://api.github.com"
    os.environ["GH_TOKEN"] = ""
    assert Github.token() == None
    assert Github.session().auth == None
    return True

