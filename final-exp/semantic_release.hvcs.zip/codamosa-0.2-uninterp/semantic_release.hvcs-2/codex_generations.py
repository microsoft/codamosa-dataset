

# Generated at 2022-06-18 03:19:51.548017
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:19:53.556323
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    """
    Test method __call__ of class TokenAuth
    """
    token = "token"
    r = "r"
    auth = TokenAuth(token)
    result = auth(r)
    assert result.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:19:54.734430
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:19:56.531566
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:19:57.594459
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:19:58.974077
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:20:04.243462
# Unit test for method auth of class Github
def test_Github_auth():
    """Test method auth of class Github"""
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() == TokenAuth("test")

    # Cleanup
    os.environ.pop("GH_TOKEN")



# Generated at 2022-06-18 03:20:06.358034
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:20:07.830300
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:14.052789
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:22:31.952895
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:22:34.329550
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:22:35.505122
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:22:38.476296
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = type("Request", (), {"headers": {}})()
    auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:22:40.820808
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("test", "test", "test") == True



# Generated at 2022-06-18 03:22:43.602074
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:22:45.140831
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:22:52.981950
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2") == True

    # Test with a failed build
    assert Gitlab.check_build_status("hysds", "hysds", "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2") == False

    # Test with a pending build

# Generated at 2022-06-18 03:22:56.152683
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:22:57.355150
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
