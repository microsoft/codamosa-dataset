

# Generated at 2022-06-18 03:18:34.809091
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "bitbucket")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:18:36.313475
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:18:37.183833
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None


# Generated at 2022-06-18 03:18:40.369099
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:18:42.113508
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:18:44.038309
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.Request()
    token = "token"
    auth = TokenAuth(token)
    auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:18:52.769456
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hail-is", "hail", "d2c2f8d9e9e9c9f9b9d9c9d9e9c9d9e9c9d9e9c9")

    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hail-is", "hail", "d2c2f8d9e9e9c9f9b9d9c9d9e9c9d9e9c9d9e9c9")



# Generated at 2022-06-18 03:18:54.354874
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:18:58.605467
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:19:09.299578
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1: check_build_status returns True when all jobs are successful
    assert Gitlab.check_build_status("test", "test", "test") == True

    # Test 2: check_build_status returns False when one job is failed
    assert Gitlab.check_build_status("test", "test", "test") == False

    # Test 3: check_build_status returns False when one job is failed and one job is still in pending status
    assert Gitlab.check_build_status("test", "test", "test") == False

    # Test 4: check_build_status returns False when one job is failed and one job is still in pending status
    assert Gitlab.check_build_status("test", "test", "test") == False

    # Test 5: check_build_status returns True when one job is failed but allow_failure is

# Generated at 2022-06-18 03:19:57.320226
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:19:58.505655
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:19:59.975330
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:01.661301
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:12.405121
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1:
    #   - owner = "hivetech"
    #   - repo = "hive-ci"
    #   - ref = "c2d7b5f0a8f8e9e8a2a9c9b9d8c7d6e6f5f4f3f2f1f0"
    #   - expected result = True
    owner = "hivetech"
    repo = "hive-ci"
    ref = "c2d7b5f0a8f8e9e8a2a9c9b9d8c7d6e6f5f4f3f2f1f0"
    result = Gitlab.check_build_status(owner, repo, ref)
    assert result == True

    # Test 2:
    #   - owner =

# Generated at 2022-06-18 03:20:14.268445
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:20.875269
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:20:22.169515
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:20:23.406930
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True

# Generated at 2022-06-18 03:20:24.920218
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:21:40.252953
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    # Test with a commit that has a failed job
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "b9f9f9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9") == False

    # Test with a commit that has a pending job
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9") == False

    # Test with a commit that has a successful job
    assert Gitlab.check_build

# Generated at 2022-06-18 03:21:41.420695
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:21:47.612038
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("hysds", "hysds", "a6c3f6e")
    # Test with a failure status
    assert not Gitlab.check_build_status("hysds", "hysds", "b5d5c5d")
    # Test with a pending status
    assert not Gitlab.check_build_status("hysds", "hysds", "c4e4b4c")
    # Test with a failure status that is allowed to fail
    assert Gitlab.check_build_status("hysds", "hysds", "d3f3a3b")
    # Test with a failure status that is allowed to fail

# Generated at 2022-06-18 03:21:48.655885
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:21:49.703816
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:21:51.587309
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:52.605310
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False

# Generated at 2022-06-18 03:21:54.385379
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:21:57.549146
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # test with a success status
    assert Gitlab.check_build_status("test", "test", "test") == True

    # test with a failure status
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:59.926912
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == True

# Generated at 2022-06-18 03:22:49.727128
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:22:54.366600
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:22:55.962890
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:22:56.800821
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:23:02.623350
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:23:03.376198
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None


# Generated at 2022-06-18 03:23:06.435811
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:23:11.289976
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("vsc-my", "vsc-base", "d9d9a6c0a4e4b4c8d8a6d9d9a6c0a4e4b4c8d8a6")
    # Test with a failed build
    assert not Gitlab.check_build_status("vsc-my", "vsc-base", "d9d9a6c0a4e4b4c8d8a6d9d9a6c0a4e4b4c8d8a7")
    # Test with a pending build

# Generated at 2022-06-18 03:23:11.936938
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:23:13.061176
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:24:40.988104
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-18 03:24:47.050052
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successfull build
    assert Gitlab.check_build_status("test", "test", "test")
    # Test with a failed build
    assert not Gitlab.check_build_status("test", "test", "test")
    # Test with a pending build
    assert not Gitlab.check_build_status("test", "test", "test")
    # Test with a failed build allowed to fail
    assert Gitlab.check_build_status("test", "test", "test")



# Generated at 2022-06-18 03:24:47.834851
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:24:48.583425
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:24:49.417505
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:24:54.925341
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:24:55.774885
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:24:59.467603
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("hysds", "hysds", "d6b4b6d")

    # Test with a failure status
    assert not Gitlab.check_build_status("hysds", "hysds", "d6b4b6d")



# Generated at 2022-06-18 03:25:00.645228
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:25:07.236724
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    owner = "test_owner"
    repo = "test_repo"
    ref = "test_ref"
    class MockGitlab:
        def __init__(self, url, private_token):
            pass
        def auth(self):
            pass
        def projects(self):
            return self
        def get(self, project):
            return self
        def commits(self):
            return self
        def get(self, commit):
            return self
        def statuses(self):
            return self
        def list(self):
            return [{"status": "success", "allow_failure": False, "name": "test_job"}]