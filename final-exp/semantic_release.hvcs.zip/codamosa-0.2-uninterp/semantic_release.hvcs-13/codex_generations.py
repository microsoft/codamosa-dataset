

# Generated at 2022-06-18 03:18:37.896173
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:18:39.453724
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:18:40.508063
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-18 03:18:41.591057
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:18:47.252023
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "d9f7d3e3e9a7b8f8b2a7c1a1c7d7e9f9f7d3e3e9")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "d9f7d3e3e9a7b8f8b2a7c1a1c7d7e9f9f7d3e3e9")
    # Test with a pending build

# Generated at 2022-06-18 03:18:52.412915
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    # Test for method __call__ of class TokenAuth
    # Setup
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    # Exercise
    result = auth(r)
    # Verify
    assert result.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:18:53.998770
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:18:55.183102
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:18:56.616449
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:18:57.842615
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:19:53.223772
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "f7c4c6d") == True

    # Test with a failed build
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "f7c4c6d") == False



# Generated at 2022-06-18 03:19:55.776710
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:20:03.079391
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test with a valid option
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    # Test with an invalid option
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    # Test with no option
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:20:04.281376
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:06.078214
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:14.802085
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the method check_build_status of class Gitlab"""
    # Test with a successful build
    assert Gitlab.check_build_status("pypa", "pip", "a8a9b9c2c6d0d9a8d8c9b9a2a8c6d0c9b9a8c6d0")
    # Test with a failed build
    assert not Gitlab.check_build_status("pypa", "pip", "a8a9b9c2c6d0d9a8d8c9b9a2a8c6d0c9b9a8c6d1")
    # Test with a pending build

# Generated at 2022-06-18 03:20:17.704946
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:19.106563
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:20:21.273059
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:20:27.517924
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hail-is", "hail", "d9b9c9d0e9f9d8d8d7d7d6d6d5d5d4d4")
    # Test with a failed build
    assert not Gitlab.check_build_status("hail-is", "hail", "d9b9c9d0e9f9d8d8d7d7d6d6d5d5d4d4")


# Generated at 2022-06-18 03:21:18.293211
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:19.155190
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:21:20.729047
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:21:21.645397
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:21:22.493993
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:23.598667
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:21:25.503424
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.Request()
    r.headers = {}
    token = "token"
    auth = TokenAuth(token)
    auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:21:26.341686
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:21:29.347026
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:31.586629
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab



# Generated at 2022-06-18 03:22:36.414869
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "c9e1f9c") is True

    # Test with a failed build
    assert Gitlab.check_build_status("hysds", "hysds", "d8f8f9c") is False

    # Test with a pending build
    assert Gitlab.check_build_status("hysds", "hysds", "d8f8f9c") is False



# Generated at 2022-06-18 03:22:39.551474
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.Request("GET", "https://example.com/")
    token = "1234567890"
    auth = TokenAuth(token)
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:22:42.081668
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.Request()
    token = "token"
    auth = TokenAuth(token)
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:22:45.172126
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:22:50.742203
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:22:52.665970
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = auth(None)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:22:55.542618
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == False


# Generated at 2022-06-18 03:22:57.507839
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == True

# Generated at 2022-06-18 03:23:05.315263
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True
    assert Gitlab.check_build_status("hive", "hive", "b4d6b4f") is True

# Generated at 2022-06-18 03:23:06.279373
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:24:59.958992
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:25:04.075495
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")

    # Clean up
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:25:05.075547
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:25:07.382166
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:25:09.998831
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:25:16.772182
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "")


# Generated at 2022-06-18 03:25:19.049213
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:25:20.613672
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:25:27.732431
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1: check_build_status with a successful pipeline
    assert Gitlab.check_build_status("hive-test", "hive-test", "b6d0c2f1e8b8d9c9c9d9c9c9c9c9c9c9c9c9c9c9") == True

    # Test 2: check_build_status with a failed pipeline
    assert Gitlab.check_build_status("hive-test", "hive-test", "b6d0c2f1e8b8d9c9c9d9c9c9c9c9c9c9c9c9c9c9") == False



# Generated at 2022-06-18 03:25:31.324914
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "bitbucket")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
