

# Generated at 2022-06-18 03:19:27.574536
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test with a valid option
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    # Test with an invalid option
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    # Test with no option
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:19:31.719148
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test for a successful build
    assert Gitlab.check_build_status("hive", "hive-operator", "d8b8f9b7c9b3d8f7f8f9b7c9b3d8f7f8f9b7c9b3")
    # Test for a failed build
    assert not Gitlab.check_build_status("hive", "hive-operator", "d8b8f9b7c9b3d8f7f8f9b7c9b3d8f7f8f9b7c9b4")
    # Test for a build that is still in pending status

# Generated at 2022-06-18 03:19:33.754816
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:19:35.852344
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:19:39.342234
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.Request(method="GET", url="https://github.com/")
    auth = TokenAuth("token")
    assert auth(r).headers["Authorization"] == "token token"



# Generated at 2022-06-18 03:19:40.478292
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == False


# Generated at 2022-06-18 03:19:44.583624
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hail-is", "hail", "f9c7b2a")
    # Test with a failed build
    assert not Gitlab.check_build_status("hail-is", "hail", "e6f8d7d")
    # Test with a pending build
    assert not Gitlab.check_build_status("hail-is", "hail", "2e9a3c3")
    # Test with a failed build that is allowed to fail
    assert Gitlab.check_build_status("hail-is", "hail", "d8b8f1d")
    # Test with a build that does not exist
    assert not Gitlab.check_build_status("hail-is", "hail", "doesnotexist")
    #

# Generated at 2022-06-18 03:19:47.903816
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:19:48.729321
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:19:49.406766
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:22:10.014089
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:22:13.671548
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:22:16.236937
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == False


# Generated at 2022-06-18 03:22:18.346659
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the method check_build_status of class Gitlab"""
    assert Gitlab.check_build_status("test", "test", "test") == True

# Generated at 2022-06-18 03:22:21.156504
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:22:22.563451
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:22:24.268057
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:22:25.683597
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:22:27.022744
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:22:38.148627
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "8b8f8c9")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "f9b7d9a")
    # Test with a pipeline with a failed job
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "b4c4d4e")
    # Test with a pipeline with a pending job
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "f4c4d4e")
    # Test with a pipeline with a failed job

# Generated at 2022-06-18 03:24:58.447558
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "c0a8d7f7f9e2e9d7e8d7f7f9e2e9d7e8d7f7f9e2"
    )

    # Test with a failure status
    assert not Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "c0a8d7f7f9e2e9d7e8d7f7f9e2e9d7e8d7f7f9e3"
    )

    # Test with a pending status

# Generated at 2022-06-18 03:25:01.078725
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() == TokenAuth("test")
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:25:05.779131
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:25:11.232590
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    """
    Test for method __call__ of class TokenAuth
    """
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request("GET", "http://example.com")
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:25:14.873599
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hive-test", "hive-test", "e9c3d9f9b8f7b8a9a8a7a6a5a4a3a2a1") == True


# Generated at 2022-06-18 03:25:18.254543
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:25:21.613603
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:25:23.342229
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:25:29.546542
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "c2d8a6c8a6a8b6d0e6a9b6e9c6d8a6c8a6a8b6d0")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("gitlab-org", "gitlab-ce", "c2d8a6c8a6a8b6d0e6a9b6e9c6d8a6c8a6a8b6d0")


# Generated at 2022-06-18 03:25:30.618499
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())

