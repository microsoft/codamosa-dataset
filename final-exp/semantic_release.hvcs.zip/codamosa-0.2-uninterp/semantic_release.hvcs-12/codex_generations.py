

# Generated at 2022-06-18 03:18:27.624286
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:18:30.614702
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:18:32.622852
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:18:34.728014
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:18:35.872966
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:18:41.428414
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:18:42.560909
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:18:44.777746
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:18:55.337371
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the method check_build_status of class Gitlab"""
    # Test with a successful build
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "1d8d8f3b4c4e4d4c4f4a4e4c4d4e4f4a4b4c4d4e")
    # Test with a build that failed
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "1d8d8f3b4c4e4d4c4f4a4e4c4d4e4f4a4b4c4d4f")
    # Test with a build that is still pending

# Generated at 2022-06-18 03:19:00.485364
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:20:14.341936
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success build
    assert Gitlab.check_build_status("pypa", "pip", "d8b8e6e8c6c7b6f9d6c3f6b8e6c7b6f9d6c3f6b8")
    # Test with a failed build
    assert not Gitlab.check_build_status("pypa", "pip", "d8b8e6e8c6c7b6f9d6c3f6b8e6c7b6f9d6c3f6b8")


# Generated at 2022-06-18 03:20:17.332465
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") is False


# Generated at 2022-06-18 03:20:21.094656
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")

    # Cleanup
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:20:21.878660
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is not None


# Generated at 2022-06-18 03:20:23.753206
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:20:25.325483
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:26.688354
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:20:31.962557
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "f7b8a9b")

    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "f7b8a9b")



# Generated at 2022-06-18 03:20:41.494282
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hive-test", "hive-test", "c7d4a6f3a6d5b6d9c7d4a6f3a6d5b6d9c7d4a6f3")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive-test", "hive-test", "c7d4a6f3a6d5b6d9c7d4a6f3a6d5b6d9c7d4a6f4")
    # Test with a pending build

# Generated at 2022-06-18 03:20:50.354640
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hive", "hive", "c9f5f6b5c6c5b1f5c5e5c5c5c5c5c5c5c5c5c5c5") == True
    # Test with a failed pipeline
    assert Gitlab.check_build_status("hive", "hive", "c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5") == False
    # Test with a pending pipeline

# Generated at 2022-06-18 03:23:00.259947
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:23:01.337999
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:23:07.134047
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "f5a5b3f9f9a9b9a9a9a9a9a9a9a9a9a9a9a9a9a9")

    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "f5a5b3f9f9a9b9a9a9a9a9a9a9a9a9a9a9a9a9a")



# Generated at 2022-06-18 03:23:11.265349
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "gitlab")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:23:12.157712
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:13.059750
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:23:18.207051
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    owner = "hail-is"
    repo = "hail"
    ref = "d7e5b5f5e8c8f5b5c7e5b5f5e8c8f5b5c7e5b5f5"
    assert Gitlab.check_build_status(owner, repo, ref)

    # Test with a failed pipeline
    owner = "hail-is"
    repo = "hail"
    ref = "d7e5b5f5e8c8f5b5c7e5b5f5e8c8f5b5c7e5b5f5"
    assert not Gitlab.check_build_status(owner, repo, ref)

    # Test with a failed pipeline and an allowed failure

# Generated at 2022-06-18 03:23:19.131557
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:23:20.422457
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:23:25.944949
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:25:40.282230
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test for method check_build_status of class Gitlab"""
    assert Gitlab.check_build_status(
        "hvcs-bot", "hvcs-bot", "b8d9f8f7c5e5b5b7d5f5f5f5f5f5f5f5f5f5f5f5"
    )



# Generated at 2022-06-18 03:25:43.651697
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:25:44.789500
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:25:52.644568
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a project that has a pipeline with a failed job
    assert not Gitlab.check_build_status(
        "pypa", "pip", "d2f0a3c3b6a8f0c8b0e9e9d9f8c8d7d6e5e4f3f2"
    )

    # Test with a project that has a pipeline with a pending job
    assert not Gitlab.check_build_status(
        "pypa", "pip", "d2f0a3c3b6a8f0c8b0e9e9d9f8c8d7d6e5e4f3f2"
    )

    # Test with a project that has a pipeline with

# Generated at 2022-06-18 03:25:57.362980
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")

    # Clean up
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:25:59.542521
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:26:06.496895
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test 1: check_build_status returns False if a job failed
    assert Gitlab.check_build_status("owner", "repo", "ref") == False

    # Test 2: check_build_status returns False if a job is still in pending status
    assert Gitlab.check_build_status("owner", "repo", "ref") == False

    # Test 3: check_build_status returns True if all jobs are in success or skipped status
    assert Gitlab.check_build_status("owner", "repo", "ref") == True



# Generated at 2022-06-18 03:26:07.495995
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:26:15.918548
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test case 1
    # Test with a valid owner, repo and ref
    # Expected result: True
    assert Gitlab.check_build_status("owner", "repo", "ref") == True

    # Test case 2
    # Test with a valid owner, repo and ref
    # Expected result: False
    assert Gitlab.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:26:17.917066
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False
