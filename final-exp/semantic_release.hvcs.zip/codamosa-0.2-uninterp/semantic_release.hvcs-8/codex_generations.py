

# Generated at 2022-06-18 03:18:49.027511
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:18:50.782106
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:18:52.534800
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:18:56.877387
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test for method check_build_status of class Gitlab"""
    # Test with a successful build
    assert Gitlab.check_build_status("saltstack", "salt", "c6b0b6d") == True

    # Test with a failed build
    assert Gitlab.check_build_status("saltstack", "salt", "c6b0b6d") == True



# Generated at 2022-06-18 03:18:58.479487
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:19:00.137921
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:19:02.747380
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:19:10.483504
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the method check_build_status of class Gitlab"""
    # Test with a successful build
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "9d9a8e7d")
    # Test with a build that is still pending
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "c5f5e5d")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "c5f5e5d")


# Generated at 2022-06-18 03:19:12.869010
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:19:21.755703
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test case 1:
    #   - the method check_build_status returns True when all jobs are success
    #   - the method check_build_status returns False when one job is failed
    #   - the method check_build_status returns False when one job is failed and not allowed to fail
    #   - the method check_build_status returns False when one job is pending
    #   - the method check_build_status returns False when one job is pending and not allowed to fail
    #   - the method check_build_status returns False when one job is failed and one job is pending
    #   - the method check_build_status returns False when one job is failed and one job is pending and not allowed to fail
    #   - the method check_build_status returns False when

# Generated at 2022-06-18 03:20:08.029647
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None


# Generated at 2022-06-18 03:20:10.292998
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:20:15.687533
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test with a valid hvcs
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    # Test with an invalid hvcs
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    # Reset config
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:20:17.162997
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:18.888559
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:20:27.717546
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test case 1: check_build_status returns False if a job failed
    # Arrange
    owner = "owner"
    repo = "repo"
    ref = "ref"
    jobs = [
        {"status": "success", "name": "job1", "allow_failure": False},
        {"status": "failed", "name": "job2", "allow_failure": False},
    ]
    # Act
    result = Gitlab.check_build_status(owner, repo, ref)
    # Assert
    assert result == False

    # Test case 2: check_build_status returns True if all jobs are successful
    # Arrange

# Generated at 2022-06-18 03:20:29.033440
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:30.958383
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:20:32.423838
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:20:33.837215
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(os.environ.get("GH_TOKEN"))



# Generated at 2022-06-18 03:21:24.514610
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:28.710221
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("vscode-dev-containers", "vscode-remote-try-python", "6a8e6d3d6e9f6a8e6d3d6e9f6a8e6d3d6e9f6a8e") == True
    assert Gitlab.check_build_status("vscode-dev-containers", "vscode-remote-try-python", "6a8e6d3d6e9f6a8e6d3d6e9f6a8e6d3d6e9f6a8e") == False

# Generated at 2022-06-18 03:21:32.915939
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:21:34.531989
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:21:37.409603
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "gitlab")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:21:43.224777
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hive", "hive-test", "d8b8f8d8f8d8f8d8f8d8f8d8f8d8f8d8f8d8f8d") == True
    assert Gitlab.check_build_status("hive", "hive-test", "d8b8f8d8f8d8f8d8f8d8f8d8f8d8f8d8f8d8f8d") == False


# Generated at 2022-06-18 03:21:46.099142
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:21:47.956391
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:21:48.945968
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:21:52.182161
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() == TokenAuth("test")
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:22:45.140556
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:22:46.018939
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == False


# Generated at 2022-06-18 03:22:47.391620
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:22:56.247320
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful pipeline

# Generated at 2022-06-18 03:22:57.607478
# Unit test for method auth of class Github
def test_Github_auth():
    # Setup
    token = "token"
    expected = TokenAuth(token)

    # Exercise
    actual = Github.auth()

    # Verify
    assert actual == expected


# Generated at 2022-06-18 03:23:01.757095
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "token"
    assert Github.auth() == TokenAuth("token")

    # Cleanup
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:23:02.689869
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False



# Generated at 2022-06-18 03:23:08.709618
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def __init__(self, status_code, json_data, text):
            self.status_code = status_code
            self.json_data = json_data
            self.text = text

        def json(self):
            return self.json_data

    class MockSession:
        def __init__(self, status_code, json_data, text):
            self.status_code = status_code
            self.json_data = json_data
            self.text = text

        def get(self, url):
            return MockResponse(self.status_code, self.json_data, self.text)

    class MockGitlab:
        def __init__(self, status_code, json_data, text):
            self.status_code = status_code

# Generated at 2022-06-18 03:23:14.276109
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    owner = "test_owner"
    repo = "test_repo"
    ref = "test_ref"
    # test case 1:
    #   - the status of the last job is success
    #   - the status of the last job is skipped
    #   - the status of the last job is pending
    #   - the status of the last job is failed and allow_failure is True
    #   - the status of the last job is failed and allow_failure is False
    #   - the status of the last job is failed and allow_failure is None
    #   - the status of the last job is None
    #   - the status of the last job is unknown
    #   - the status of the last job is not a string
    #   -

# Generated at 2022-06-18 03:23:18.614472
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:24:06.619446
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:24:07.430466
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:24:08.458147
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True



# Generated at 2022-06-18 03:24:12.306653
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:24:14.004433
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:24:17.372475
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("pypa", "pip", "b8c8b7f7b0d2a8e0e9f9b7d1a5a5a8e0e9f9b7d1")
    # Test with a failed build
    assert not Gitlab.check_build_status("pypa", "pip", "b8c8b7f7b0d2a8e0e9f9b7d1a5a5a8e0e9f9b7d2")



# Generated at 2022-06-18 03:24:19.179202
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == True



# Generated at 2022-06-18 03:24:23.326575
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hive-test", "hive-test", "e8b9a9b") == True
    assert Gitlab.check_build_status("hive-test", "hive-test", "e8b9a9b") == False


# Generated at 2022-06-18 03:24:24.398241
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:24:25.101378
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:25:24.052350
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def __init__(self, json_data, status_code):
            self.json_data = json_data
            self.status_code = status_code

        def json(self):
            return self.json_data

    class MockSession:
        def __init__(self):
            self.status_code = None


# Generated at 2022-06-18 03:25:25.182771
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:25:26.142840
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:25:29.293580
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hvcs-bot", "hvcs-bot", "f8c8a8e") == True
    assert Gitlab.check_build_status("hvcs-bot", "hvcs-bot", "f8c8a8e") == False


# Generated at 2022-06-18 03:25:30.619194
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:25:33.192324
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:25:40.035668
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "d9f0a9a6b0a7e9f8f0d8a9f0a7d9f0a9a6b0a7e9f")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "d9f0a9a6b0a7e9f8f0d8a9f0a7d9f0a9a6b0a7e9f")



# Generated at 2022-06-18 03:25:48.924716
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hive", "hive-test", "d8a8c7f7e8b8c9e9d0a1b2c3d4e5f6a7b8c9d0a1")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive", "hive-test", "d8a8c7f7e8b8c9e9d0a1b2c3d4e5f6a7b8c9d0a2")



# Generated at 2022-06-18 03:25:49.963480
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:25:52.522568
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    owner = "test_owner"
    repo = "test_repo"
    ref = "test_ref"
    Gitlab.check_build_status(owner, repo, ref)



# Generated at 2022-06-18 03:26:43.905538
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:26:46.882519
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:26:48.763751
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:26:55.476698
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:27:04.129019
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    # Test with a valid hvcs
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    # Test with an invalid hvcs
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    # Test with no hvcs
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:27:09.218879
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() is not None
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:27:14.923498
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "b0c9d8f8c9f9b5a0d4e0c8d8e4d4c0d4d8d8c0d8")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "b0c9d8f8c9f9b5a0d4e0c8d8e4d4c0d4d8d8c0d8")



# Generated at 2022-06-18 03:27:16.537592
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:27:17.899237
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None


# Generated at 2022-06-18 03:27:19.605223
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())

