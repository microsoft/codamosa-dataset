

# Generated at 2022-06-18 03:20:04.914991
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:06.250573
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:20:12.594104
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    hvcs = get_hvcs()
    assert hvcs.__class__.__name__ == "Github"
    config.set("hvcs", "gitlab")
    hvcs = get_hvcs()
    assert hvcs.__class__.__name__ == "Gitlab"
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:20:14.383027
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:17.331452
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:20:18.694853
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-18 03:20:20.102797
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:21.723977
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:20:22.912520
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:32.542513
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def __init__(self, status_code, json_data, headers):
            self.status_code = status_code
            self.json_data = json_data
            self.headers = headers

        def json(self):
            return self.json_data

    class MockSession:
        def __init__(self):
            self.headers = {}


# Generated at 2022-06-18 03:23:46.230467
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:47.943740
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:23:49.142690
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:23:55.626027
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hysds", "hysds", "d5e8f7e8a8a9b7d9a1c8a9b7d9a1c8a9b7d9a1c8")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hysds", "hysds", "d5e8f7e8a8a9b7d9a1c8a9b7d9a1c8a9b7d9a1c9")
    # Test with a pipeline that is still running

# Generated at 2022-06-18 03:23:57.113603
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    Gitlab.check_build_status("owner", "repo", "ref")



# Generated at 2022-06-18 03:23:58.938150
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() is not None
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:24:00.798625
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:24:05.587329
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1
    owner = "test"
    repo = "test"
    ref = "test"
    assert Gitlab.check_build_status(owner, repo, ref) == False

    # Test 2
    owner = "test"
    repo = "test"
    ref = "test"
    assert Gitlab.check_build_status(owner, repo, ref) == False

    # Test 3
    owner = "test"
    repo = "test"
    ref = "test"
    assert Gitlab.check_build_status(owner, repo, ref) == False

    # Test 4
    owner = "test"
    repo = "test"
    ref = "test"
    assert Gitlab.check_build_status(owner, repo, ref) == False

    # Test 5
    owner = "test"

# Generated at 2022-06-18 03:24:06.513561
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None


# Generated at 2022-06-18 03:24:08.325635
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:26:54.707762
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:26:57.453704
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:27:00.600131
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:27:12.265000
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hive", "hive", "a7a5b2f9a7d5c5f5f5f5f5f5f5f5f5f5f5f5f5f5")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive", "hive", "a7a5b2f9a7d5c5f5f5f5f5f5f5f5f5f5f5f5f5f6")
    # Test with a pending build

# Generated at 2022-06-18 03:27:19.764247
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test for method check_build_status of class Gitlab"""
    # Test with a successful build
    assert Gitlab.check_build_status("pypa", "pip", "b1d9c7f0d8e0a7f8e8c6f0e0d9c8f0e0d9c8f0e0")
    # Test with a failed build
    assert not Gitlab.check_build_status("pypa", "pip", "b1d9c7f0d8e0a7f8e8c6f0e0d9c8f0e0d9c8f0e0")

