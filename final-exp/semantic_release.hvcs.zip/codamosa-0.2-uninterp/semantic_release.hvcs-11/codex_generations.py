

# Generated at 2022-06-18 03:18:21.970284
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:18:24.687972
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hive", "hive", "c7d9f9e")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive", "hive", "b9a9c0a")
    # Test with a pending build
    assert not Gitlab.check_build_status("hive", "hive", "e9a9c0a")



# Generated at 2022-06-18 03:18:35.796672
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1: check_build_status with a pending job
    # Expected result: False
    assert Gitlab.check_build_status("vsc-mypy", "vsc-mypy", "0c8f9a9a9f9d8c8b7a6b5c4d3e2f1a0b9c8d7e6f") == False

    # Test 2: check_build_status with a failed job
    # Expected result: False
    assert Gitlab.check_build_status("vsc-base", "vsc-base", "d7b4c6c4c6b4a5b6c7d8e9f0a1b2c3d4e5f6a7b8") == False

    # Test 3: check_build_status with a success job
    #

# Generated at 2022-06-18 03:18:37.268784
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:18:41.696142
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:18:43.327137
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:18:52.575767
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "not_a_valid_option")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:18:53.843322
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:18:55.336367
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:18:57.061313
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:31.000061
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:20:32.461129
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:20:33.581060
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:35.155249
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-18 03:20:45.544756
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-18 03:20:50.653736
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "bitbucket")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:20:51.674682
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:55.748618
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:20:57.221865
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:21:00.959332
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:22:31.420561
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "gitlab")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:22:32.890508
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:22:38.863722
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("hysds", "hysds", "f8b6a8b8a7c6b5d4c3b2a1") == True

    # Test with a failure status
    assert Gitlab.check_build_status("hysds", "hysds", "f8b6a8b8a7c6b5d4c3b2a1") == True


# Generated at 2022-06-18 03:22:40.176784
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:22:41.502300
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:22:46.074235
# Unit test for method auth of class Github
def test_Github_auth():
    # Test for method auth of class Github
    # Setup test values
    token = "token"
    # Invoke method
    result = Github.auth(token)
    # Check for expected result
    assert result == TokenAuth(token)



# Generated at 2022-06-18 03:22:49.727400
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "test")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:22:50.563514
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:22:57.710121
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success build
    assert Gitlab.check_build_status("hysds", "hysds", "9f9e6f9c6c7b6c8d6c9d6c8d6c9d6c8d6c9d6c8d") == True
    # Test with a failure build
    assert Gitlab.check_build_status("hysds", "hysds", "9f9e6f9c6c7b6c8d6c9d6c8d6c9d6c8d6c9d6c8d") == False


# Generated at 2022-06-18 03:23:00.112248
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:24:35.226204
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:24:41.861387
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:24:45.571010
# Unit test for method auth of class Github
def test_Github_auth():
    # Test with no token
    assert Github.auth() is None

    # Test with token
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")

    # Cleanup
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:24:46.945913
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:24:48.644383
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:24:49.419252
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:24:57.765001
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")



# Generated at 2022-06-18 03:24:58.941040
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:25:02.876452
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github



# Generated at 2022-06-18 03:25:09.412172
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hive-test", "hive-test", "f9b9d9c7d8f8c7d9b9f8d8c7f9d8c7f9")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hive-test", "hive-test", "f9b9d9c7d8f8c7d9b9f8d8c7f9d8c7f9")
