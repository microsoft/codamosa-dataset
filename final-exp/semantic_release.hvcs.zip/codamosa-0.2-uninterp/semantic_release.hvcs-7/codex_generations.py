

# Generated at 2022-06-18 03:20:16.657149
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful build

# Generated at 2022-06-18 03:20:18.342391
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:20:27.281049
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hive", "hive-docker", "7b3c3c9b9d9c9f8f4b4c4c4c4c4c4c4c4c4c4c4c")
    # Test with a failed build
    assert not Gitlab.check_build_status("hive", "hive-docker", "7b3c3c9b9d9c9f8f4b4c4c4c4c4c4c4c4c4c4c4")
    # Test with a pending build

# Generated at 2022-06-18 03:20:36.503313
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs().__name__ == "Github"
    config.set("hvcs", "gitlab")
    assert get_hvcs().__name__ == "Gitlab"
    config.set("hvcs", "Github")
    assert get_hvcs().__name__ == "Github"
    config.set("hvcs", "Gitlab")
    assert get_hvcs().__name__ == "Gitlab"
    config.set("hvcs", "github")
    assert get_hvcs().__name__ == "Github"
    config.set("hvcs", "gitlab")
    assert get_hvcs().__name__ == "Gitlab"

# Generated at 2022-06-18 03:20:37.535825
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:40.181118
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:20:49.092106
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hail-is", "hail", "f7a5a8d8b6c8d3e3c7f0e8d0f9f9d6f2b0d9c6c4")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hail-is", "hail", "d8d8c8c8b8b8a8a8989878786868585848484")
    # Test with a pending pipeline

# Generated at 2022-06-18 03:20:49.869764
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is not None


# Generated at 2022-06-18 03:20:51.153355
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == False


# Generated at 2022-06-18 03:20:52.774024
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True



# Generated at 2022-06-18 03:22:46.338323
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a success status
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == True

    # Test with a failure status
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == False



# Generated at 2022-06-18 03:22:51.988121
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:22:53.317307
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:23:02.717989
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("saltstack", "salt", "a4d8f8b7f4b4a4b9f9b8a8d4f8d4b4a4b4a4b4a4")
    # Test with a failed build
    assert not Gitlab.check_build_status("saltstack", "salt", "a4d8f8b7f4b4a4b9f9b8a8d4f8d4b4a4b4a4b4a5")
    # Test with a build that is still pending

# Generated at 2022-06-18 03:23:04.142186
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:23:05.138750
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:07.886625
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    owner = "hive-test"
    repo = "hive-test"
    ref = "master"
    assert Gitlab.check_build_status(owner, repo, ref) == True


# Generated at 2022-06-18 03:23:08.930349
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:23:10.705239
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:23:11.607040
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:24:59.801598
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:25:01.489803
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    assert get_hvcs() == Gitlab


# Generated at 2022-06-18 03:25:06.598331
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "a8f8e1d3b3c7f9b6f2c7a8f8e1d3b3c7f9b6f2c7")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "a8f8e1d3b3c7f9b6f2c7a8f8e1d3b3c7f9b6f2c7")


# Generated at 2022-06-18 03:25:08.865185
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:25:16.132813
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")


# Generated at 2022-06-18 03:25:23.859455
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "e9b8d8d1f8c7f2d3c3b8e8e9d9f8d8d1f8c7f2d3"
    )
    assert not Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "e9b8d8d1f8c7f2d3c3b8e8e9d9f8d8d1f8c7f2d3"
    )



# Generated at 2022-06-18 03:25:25.036397
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:25:31.532747
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("david-guillen-fandos", "gitlab-test", "4a4b4c4d4e4f4g4h4i4j4k4l4m4n4o4p4q4r4s4t4u4v4w4x4y4z") == True
    assert Gitlab.check_build_status("david-guillen-fandos", "gitlab-test", "4a4b4c4d4e4f4g4h4i4j4k4l4m4n4o4p4q4r4s4t4u4v4w4x4y4z") == False


# Generated at 2022-06-18 03:25:39.030365
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1
    owner = "test_owner"
    repo = "test_repo"
    ref = "test_ref"
    jobs = [{"status": "success", "allow_failure": False, "name": "test_job"}]
    gl = gitlab.Gitlab("test_url", private_token="test_token")
    gl.auth = MagicMock()
    gl.projects.get.return_value.commits.get.return_value.statuses.list.return_value = jobs
    assert Gitlab.check_build_status(owner, repo, ref) == True

    # Test 2
    jobs = [{"status": "failed", "allow_failure": False, "name": "test_job"}]
    gl.projects.get.return_value.commits.get.return_value.stat

# Generated at 2022-06-18 03:25:40.304508
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())

