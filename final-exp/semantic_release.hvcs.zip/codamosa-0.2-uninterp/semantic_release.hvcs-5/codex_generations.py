

# Generated at 2022-06-18 03:19:58.801608
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "test"
    assert Github.auth() == TokenAuth("test")
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-18 03:20:01.038682
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:20:02.715063
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:20:09.992296
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:20:11.666476
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())


# Generated at 2022-06-18 03:20:20.842086
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "none")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:20:27.544984
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a job that failed
    assert Gitlab.check_build_status("hive-test", "hive-test", "e5b5b5d7a5c5d5e5f5f5f5f5f5f5f5f5f5f5f5f5") == False
    # Test with a job that is still pending
    assert Gitlab.check_build_status("hive-test", "hive-test", "e5b5b5d7a5c5d5e5f5f5f5f5f5f5f5f5f5f5f5f5") == False
    # Test with a job that succeeded

# Generated at 2022-06-18 03:20:34.170381
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test function get_hvcs"""
    config.set("hvcs", "github")
    assert get_hvcs() is Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() is Gitlab
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:20:37.499856
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    owner = "owner"
    repo = "repo"
    ref = "ref"
    Gitlab.check_build_status(owner, repo, ref)
    assert True



# Generated at 2022-06-18 03:20:40.447781
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:25:23.705474
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False

# Generated at 2022-06-18 03:25:25.144444
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:25:32.264248
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "f8d3b3a3b6c9e2f9f8d3b3a3b6c9e2f9f8d3b3a")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "f8d3b3a3b6c9e2f9f8d3b3a3b6c9e2f9f8d3b3b")
    # Test with a pending build

# Generated at 2022-06-18 03:25:38.795629
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a good status
    assert Gitlab.check_build_status(
        "hive-test", "hive-test", "b3a3a8b6e2e7a8e6d0d7f7c6c3c0b1b0a9a8a7a6"
    )

    # Test with a bad status
    assert not Gitlab.check_build_status(
        "hive-test", "hive-test", "b3a3a8b6e2e7a8e6d0d7f7c6c3c0b1b0a9a8a7a6"
    )



# Generated at 2022-06-18 03:25:40.360695
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-18 03:25:41.454257
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None


# Generated at 2022-06-18 03:25:44.505919
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:25:45.681867
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:25:46.942318
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == False

# Generated at 2022-06-18 03:25:55.530466
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
    config.set("hvcs_domain", "gitlab.com")
    assert Gitlab.domain() == "gitlab.com"
    config.set("hvcs_domain", "gitlab.com/")
    assert Gitlab.domain() == "gitlab.com"
    config.set("hvcs_domain", "gitlab.com/group/subgroup")
    assert Gitlab.domain() == "gitlab.com/group/subgroup"
    config.set("hvcs_domain", "gitlab.com/group/subgroup/")
    assert Gitlab.domain() == "gitlab.com/group/subgroup"
    config.set("hvcs_domain", "gitlab.com/group/subgroup/repo")
    assert Gitlab