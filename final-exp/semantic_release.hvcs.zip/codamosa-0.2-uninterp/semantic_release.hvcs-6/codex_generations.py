

# Generated at 2022-06-18 03:20:11.343957
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test for method check_build_status of class Gitlab"""
    # Test with a success status
    assert Gitlab.check_build_status("hive", "hive-test", "b6c8a6c4b9d9a6f7a6b8c9d0a6b8c9d0a6b8c9d0")

    # Test with a failure status
    assert not Gitlab.check_build_status("hive", "hive-test", "b6c8a6c4b9d9a6f7a6b8c9d0a6b8c9d0a6b8c9d1")

    # Test with a pending status

# Generated at 2022-06-18 03:20:13.141334
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = requests.get("https://api.github.com")
    assert r.headers["Authorization"] == f"token {config.github.token}"



# Generated at 2022-06-18 03:20:23.489675
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hive", "hive", "b7d0d9f9b8a8b8f0f0d9d9b8f0f0f0f0f0f0f0f0") == True
    assert Gitlab.check_build_status("hive", "hive", "b7d0d9f9b8a8b8f0f0d9d9b8f0f0f0f0f0f0f0f1") == False
    assert Gitlab.check_build_status("hive", "hive", "b7d0d9f9b8a8b8f0f0d9d9b8f0f0f0f0f0f0f0f2") == False
    assert Gitlab.check_build_status

# Generated at 2022-06-18 03:20:25.429015
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:20:28.396191
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:20:30.631871
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:20:36.795166
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-18 03:20:39.095062
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:20:41.175799
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("hive-framework", "hive-framework", "c5e6b8f")
    # Test with a failure status
    assert not Gitlab.check_build_status("hive-framework", "hive-framework", "c5e6b8f")


# Generated at 2022-06-18 03:20:44.418179
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test for method check_build_status of class Gitlab"""
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:23:44.251394
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:23:52.447948
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hysds", "hysds", "e9b9e9f1c9b1c7c5d5f8f8c8b2c5c5c5c5c5c5c5") == True
    # Test with a failed pipeline
    assert Gitlab.check_build_status("hysds", "hysds", "c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5") == False
    # Test with a pipeline that is still running

# Generated at 2022-06-18 03:23:53.375993
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == False

# Generated at 2022-06-18 03:23:54.464831
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:23:56.044827
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:23:57.197860
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:24:01.333789
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    assert get_hvcs() == Github
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")

# Generated at 2022-06-18 03:24:02.483224
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:24:03.469388
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == False



# Generated at 2022-06-18 03:24:08.342489
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test for a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "a0d9f9c8d8b7e0b0f2d7d1e5b5e7f3c5f5d5d5d5")
    # Test for a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "a0d9f9c8d8b7e0b0f2d7d1e5b5e7f3c5f5d5d5d6")
    # Test for a build that is still pending