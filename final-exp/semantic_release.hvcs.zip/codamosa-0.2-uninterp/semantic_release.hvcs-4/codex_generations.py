

# Generated at 2022-06-18 03:19:55.015449
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test_owner", "test_repo", "test_ref") == True

# Generated at 2022-06-18 03:19:57.041982
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:19:58.138080
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:06.433801
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test for a successful pipeline
    assert Gitlab.check_build_status("hive", "hive-operator", "b8f9b9c1f2d7b7e8d8e7f9b8c1d2f3d4e5f6a7b8")
    # Test for a failed pipeline
    assert not Gitlab.check_build_status("hive", "hive-operator", "b8f9b9c1f2d7b7e8d8e7f9b8c1d2f3d4e5f6a7b8")


# Generated at 2022-06-18 03:20:07.922610
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:15.760965
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    owner = "hive-test"
    repo = "hive-test"
    ref = "f5c0d7f2a2a8a8a8a8a8a8a8a8a8a8a8a8a8a8a8"
    assert Gitlab.check_build_status(owner, repo, ref)

    # Test with a failed build
    ref = "f5c0d7f2a2a8a8a8a8a8a8a8a8a8a8a8a8a8a8b"
    assert not Gitlab.check_build_status(owner, repo, ref)

    # Test with a pending build

# Generated at 2022-06-18 03:20:17.507779
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:20:18.948072
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:20:20.275174
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test get_hvcs function"""
    assert get_hvcs() == Github

# Generated at 2022-06-18 03:20:27.400712
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "Github")
    assert get_hvcs() == Github
    config.set("hvcs", "Gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "GITHUB")
    assert get_hvcs() == Github
    config.set("hvcs", "GITLAB")
    assert get_hvcs() == Gitlab

# Generated at 2022-06-18 03:24:43.853261
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    class TestGitlab(Gitlab):
        """
        Test class for Gitlab
        """

        @staticmethod
        def token() -> Optional[str]:
            """Gitlab token property

            :return: The Gitlab token environment variable (GL_TOKEN) value
            """
            return "test"

    class TestGitlab2(Gitlab):
        """
        Test class for Gitlab
        """

        @staticmethod
        def token() -> Optional[str]:
            """Gitlab token property

            :return: The Gitlab token environment variable (GL_TOKEN) value
            """
            return "test2"

    class TestGitlab3(Gitlab):
        """
        Test class for Gitlab
        """

       

# Generated at 2022-06-18 03:24:46.290496
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "token"
    auth = TokenAuth(token)
    r = requests.Request()
    r = auth(r)
    assert r.headers["Authorization"] == f"token {token}"



# Generated at 2022-06-18 03:24:47.589510
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:24:49.938565
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:24:51.384850
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:24:55.194506
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("owner", "repo", "ref") == True



# Generated at 2022-06-18 03:24:58.431591
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    # Test with a successful build
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "a2e2c0f")

    # Test with a failed build
    assert not Gitlab.check_build_status("gitlab-org", "gitlab-ce", "f8f0b8c")



# Generated at 2022-06-18 03:24:59.931858
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:25:01.080741
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:25:03.412664
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False
