

# Generated at 2022-06-18 03:23:14.464467
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test method check_build_status of class Gitlab
    """
    owner = "test"
    repo = "test"
    ref = "test"
    Gitlab.check_build_status(owner, repo, ref)



# Generated at 2022-06-18 03:23:15.499601
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-18 03:23:21.669517
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hail-is", "hail", "d5f8c8d5b5e5b5c5d5e5f8c8d5b5e5b5c5d5e5f8")

    # Test with a failed build
    assert not Gitlab.check_build_status("hail-is", "hail", "d5f8c8d5b5e5b5c5d5e5f8c8d5b5e5b5c5d5e5f9")

    # Test with a pending build

# Generated at 2022-06-18 03:23:23.593101
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:24.712009
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:23:25.458409
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:30.005050
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("hysds", "hysds", "a7b3a9b9c8d8f8a8a7b3a9b9c8d8f8a8a7b3a9b9")
    # Test with a failed build
    assert not Gitlab.check_build_status("hysds", "hysds", "a7b3a9b9c8d8f8a8a7b3a9b9c8d8f8a8a7b3a9b8")
    # Test with a pending build

# Generated at 2022-06-18 03:23:31.645281
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:23:32.929824
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:23:36.422182
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful build
    assert Gitlab.check_build_status("pypa", "pip", "9c9f1d0") is True

    # Test with a failed build
    assert Gitlab.check_build_status("pypa", "pip", "9c9f1d0") is True



# Generated at 2022-06-18 03:27:04.264922
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:27:06.996570
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:27:09.519349
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:27:10.893593
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:27:13.282797
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:27:21.374029
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status(
        "hail-is", "hail", "e5f5a0d5a8c0e1f8a1b9f2d0c9f9a8b7c6d5e4f3"
    )

    # Test with a failed pipeline
    assert not Gitlab.check_build_status(
        "hail-is", "hail", "a8b7c6d5e4f3e5f5a0d5a8c0e1f8a1b9f2d0c9f9"
    )

    # Test with a pending pipeline