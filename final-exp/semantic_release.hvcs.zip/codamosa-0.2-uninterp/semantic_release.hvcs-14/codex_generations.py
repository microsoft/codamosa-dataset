

# Generated at 2022-06-18 03:21:00.868104
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    with pytest.raises(ImproperConfigurationError):
        config.set("hvcs", "foo")
        get_hvcs()



# Generated at 2022-06-18 03:21:03.589005
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:21:13.418813
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful pipeline
    assert Gitlab.check_build_status(
        "conda-forge", "conda-forge-webservices", "a6b0f6f8c0a8a8c9e9e9e9e9e9e9e9e9e9e9e9e9"
    )

    # Test with a failed pipeline
    assert not Gitlab.check_build_status(
        "conda-forge", "conda-forge-webservices", "a6b0f6f8c0a8a8c9e9e9e9e9e9e9e9e9e9e9e9e9"
    )



# Generated at 2022-06-18 03:21:14.337273
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:21:16.389255
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:21:18.294718
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:21:24.362410
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test for a successful build
    assert Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "e9b9c6e8b6e8f0f3d0a3f7c8f6b8d7c9e9c6e8b6"
    )

    # Test for a failed build
    assert not Gitlab.check_build_status(
        "gitlab-org", "gitlab-ce", "e9b9c6e8b6e8f0f3d0a3f7c8f6b8d7c9e9c6e8b6"
    )

# Generated at 2022-06-18 03:21:25.421903
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:21:26.722477
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test for get_hvcs function"""
    assert get_hvcs() == Github


# Generated at 2022-06-18 03:21:29.427063
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:24:06.693644
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:24:11.614486
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "Gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "Github")
    assert get_hvcs() == Github
    config.set("hvcs", "")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "Gitlab")
    assert get_hvcs() == Gitlab
   

# Generated at 2022-06-18 03:24:15.459264
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "f7b8a60") == True

    # Test with a failure status
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "a9b2a4f") == False

    # Test with a pending status
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "4a4b4c4") == False

    # Test with an unknown status
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "d7e8f9g") == False



# Generated at 2022-06-18 03:24:16.892475
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-18 03:24:17.778151
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:24:25.695987
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a successful pipeline

# Generated at 2022-06-18 03:24:34.077612
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success build
    assert Gitlab.check_build_status("vsc-base", "vsc-base", "d7b1c9e9b9f9c8f8d7d6d5d4d3d2d1d0c9c8c7c6")
    # Test with a failed build
    assert not Gitlab.check_build_status("vsc-base", "vsc-base", "c9c8c7c6c5c4c3c2c1c0b9b8b7b6b5b4b3b2b1")
    # Test with a pending build

# Generated at 2022-06-18 03:24:35.090863
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:24:36.306454
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:24:45.862561
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    """
    # Test with a success status
    assert Gitlab.check_build_status("hysds", "hysds", "d8f9a9c9b8a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4")

    # Test with a failure status
    assert not Gitlab.check_build_status("hysds", "hysds", "d8f9a9c9b8a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4")
