

# Generated at 2022-06-18 03:19:53.298610
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:19:57.527383
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "invalid")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-18 03:19:58.701283
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-18 03:20:00.922707
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-18 03:20:06.395392
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test when a job failed
    assert Gitlab.check_build_status("test", "test", "test") == False

    # Test when a job is still in pending status
    assert Gitlab.check_build_status("test", "test", "test") == False

    # Test when all jobs are successful
    assert Gitlab.check_build_status("test", "test", "test") == True



# Generated at 2022-06-18 03:20:10.251107
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.auth() == TokenAuth("test_token")
    del os.environ["GH_TOKEN"]


# Generated at 2022-06-18 03:20:16.656677
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hive-test", "hive-test", "b1c6b9e6d3a6a7b8a9b0c1d2e3f4g5h6i7j8k9l0")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hive-test", "hive-test", "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0")
    # Test with a pending pipeline

# Generated at 2022-06-18 03:20:21.094359
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test method check_build_status of class Gitlab"""
    # Test with a valid owner, repo and ref
    assert Gitlab.check_build_status("owner", "repo", "ref") == True

    # Test with an invalid owner, repo and ref
    assert Gitlab.check_build_status("owner", "repo", "ref") == True



# Generated at 2022-06-18 03:20:22.113901
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:20:23.698361
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == False


# Generated at 2022-06-18 03:23:08.614710
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "bitbucket")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-18 03:23:13.032574
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a successful pipeline
    assert Gitlab.check_build_status("hive", "hive-operator", "a0b9a4a1c4d4f8b0a8b4f4a1d4c0b9a0f8d4a4b1")
    # Test with a failed pipeline
    assert not Gitlab.check_build_status("hive", "hive-operator", "c0b9a4a1c4d4f8b0a8b4f4a1d4c0b9a0f8d4a4b1")



# Generated at 2022-06-18 03:23:14.195127
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth(Github.token())



# Generated at 2022-06-18 03:23:15.498726
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Generated at 2022-06-18 03:23:16.586104
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-18 03:23:17.618763
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-18 03:23:19.115815
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-18 03:23:20.931875
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    owner = "test_owner"
    repo = "test_repo"
    ref = "test_ref"
    Gitlab.check_build_status(owner, repo, ref)



# Generated at 2022-06-18 03:23:21.718291
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-18 03:23:23.592834
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
