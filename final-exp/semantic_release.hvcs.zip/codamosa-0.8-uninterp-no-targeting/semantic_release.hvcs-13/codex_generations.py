

# Generated at 2022-06-21 20:48:04.157024
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() == get_hvcs().domain()

# Generated at 2022-06-21 20:48:08.995265
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the check_build_status method of class Gitlab
    """
    ref = "refs/heads/master"
    result = Gitlab.check_build_status("YunlianMoon", "travis-github-pipeline", ref)
    assert isinstance(result, bool)
    assert True == result



# Generated at 2022-06-21 20:48:11.194374
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    domain = Gitlab.domain()
    assert domain == os.environ.get("CI_SERVER_HOST", "gitlab.com")


# Generated at 2022-06-21 20:48:12.569630
# Unit test for method token of class Base
def test_Base_token():
    """It raises a NotImplementedError."""
    assert Base.token() is None

# Generated at 2022-06-21 20:48:19.497984
# Unit test for function get_domain
def test_get_domain():
#    repositories = ("hvcs-test-123","hvcs-pytest-testrepo1")
#    for repos in repositories:
#        assert get_domain(repos) is not None, "get_domain returned None"
#        assert get_domain(repos) == "github.com", "get_domain returned incorrect value"
    assert get_domain().capitalize() == "Github.com"
    assert get_domain().capitalize() == "Gitlab.com"

# Generated at 2022-06-21 20:48:22.711214
# Unit test for constructor of class Gitlab
def test_Gitlab():
    """
    Test constructor of class Gitlab
    """
    gl = Gitlab()
    assert gl


# Generated at 2022-06-21 20:48:23.904358
# Unit test for function get_token
def test_get_token():
    assert get_token() == os.environ.get("GH_TOKEN")

# Generated at 2022-06-21 20:48:25.972369
# Unit test for method api_url of class Base
def test_Base_api_url():
    assert Base.api_url() == "https://api.github.com/repos"



# Generated at 2022-06-21 20:48:27.531280
# Unit test for constructor of class Github
def test_Github():
    Github.domain()
    Github.api_url()
    Github.token()
    assert isinstance(Github.domain(), str)
    assert isinstance(Github.api_url(), str)
    assert isinstance(Github.token(), Optional[str])



# Generated at 2022-06-21 20:48:29.344365
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    auth_obj = TokenAuth("1234")
    assert auth_obj.token == "1234"



# Generated at 2022-06-21 20:51:07.410587
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    class Fake_Base(Base):
        @staticmethod
        def domain() -> str:
            return "domain.com"

        @staticmethod
        def api_url() -> str:
            return "https://api.domain.com"

        @staticmethod
        def token() -> Optional[str]:
            return "token"

        @staticmethod
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            return True

        @classmethod
        def post_release_changelog(
            cls, owner: str, repo: str, version: str, changelog: str
        ) -> bool:
            return True

        @classmethod
        def upload_dists(cls, owner: str, repo: str, version: str, path: str) -> bool:
            return True
   

# Generated at 2022-06-21 20:51:08.593740
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab.domain() == "gitlab.com"
    assert Gitlab.api_url() == "https://gitlab.com"
    assert Gitlab.token() is None

# Generated at 2022-06-21 20:51:10.102491
# Unit test for method domain of class Github
def test_Github_domain():
    Github.domain()
    # test_Github_domain has run



# Generated at 2022-06-21 20:51:11.775218
# Unit test for method token of class Github
def test_Github_token():
    res = Github.token()
    assert res is not None



# Generated at 2022-06-21 20:51:13.418102
# Unit test for function check_build_status
def test_check_build_status():
    check_build_status(owner = "Virajkulkarni",repository = "test", ref = "master")
test_check_build_status()

# Generated at 2022-06-21 20:51:14.273173
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("test_owner","test_repo","test_version","test_changelog")


# Generated at 2022-06-21 20:51:15.348478
# Unit test for method auth of class Github
def test_Github_auth():
    Github.token = lambda: "foo"
    assert Github.auth() == TokenAuth("foo")



# Generated at 2022-06-21 20:51:17.326748
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.token() is not None
    assert Github.auth() is not None
    assert Github.auth().__eq__(TokenAuth(Github.token()))



# Generated at 2022-06-21 20:51:19.564473
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == NotImplemented


# Generated at 2022-06-21 20:51:22.812930
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    """
    test_TokenAuth___ne__
    """
    from .tests.test_helpers import FakeAuthBase

    token_auth = TokenAuth("token")
    assert token_auth != FakeAuthBase()



# Generated at 2022-06-21 20:53:52.252221
# Unit test for function check_build_status
def test_check_build_status():
    with patch('version_query.config', new_callable=PropertyMock) as mock_config:
        mock_config.hvcs = 'github'
        with patch('version_query.Github') as mock_github:
            ref = 'dd4f8f9f9'
            mock_github.check_build_status.return_value = True
            assert check_build_status('gitmate-test-user/test', 'test', ref) == True
            mock_github.check_build_status.assert_called_with(
                'gitmate-test-user', 'test', ref
            )
            mock_config.hvcs = 'gitlab'
            with patch('version_query.Gitlab') as mock_gitlab:
                mock_gitlab.check_build_status.return_value = True

# Generated at 2022-06-21 20:53:56.165402
# Unit test for method api_url of class Base
def test_Base_api_url():
    try:
        hvcs = Base
        hvcs.api_url()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("NotImplementedError not raised")



# Generated at 2022-06-21 20:53:57.133948
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base().domain() == None

# Generated at 2022-06-21 20:53:59.642163
# Unit test for method token of class Gitlab
def test_Gitlab_token():
	with unittest.mock.patch.dict('os.environ', {'GL_TOKEN': 'hello'}):
		assert Gitlab.token() == 'hello'


# Generated at 2022-06-21 20:54:08.562659
# Unit test for method api_url of class Github
def test_Github_api_url():
    # Test with no hvcs_domain and without the environment variable.
    config["hvcs_domain"] = None
    os.environ.pop("GH_TOKEN", None)
    assert Github.token() is None
    assert Github.api_url() == "https://api.github.com"

    # Test with a specific hvcs_domain.
    config["hvcs_domain"] = "test.com"
    os.environ.pop("GH_TOKEN", None)
    assert Github.token() is None
    assert Github.api_url() == "https://test.com"

    # Test with a specific hvcs_domain and the environment variable.
    config["hvcs_domain"] = "test.com"
    os.environ["GH_TOKEN"] = "token"
    assert Github.token()

# Generated at 2022-06-21 20:54:15.197248
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    # Setup
    token = "some_token"
    other = TokenAuth("some_token")
    auth = TokenAuth(token)

    # Exercise
    result = auth == other

    # Verify:
    # - self.token == getattr(other, "token", None),
    assert auth.token == getattr(other, "token", None)
    # Assert
    assert result is True


# Generated at 2022-06-21 20:54:16.901812
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    assert Gitlab.token() == None

# Generated at 2022-06-21 20:54:20.281558
# Unit test for method domain of class Base
def test_Base_domain():
    # Create a proper subclass
    class Dummy(Base):
        @staticmethod
        def domain():  # type: ignore
            return "domain"

    # Check functionality
    assert Dummy.domain() == "domain"



# Generated at 2022-06-21 20:54:25.815514
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    try:
        import os

        os.environ["CI_SERVER_HOST"] = "FOO"
        API_URL = "https://FOO"
        assert API_URL == Gitlab.api_url()
    except Exception as e:
        logger.error("Unit test Gitlab_api_url FAILED")



# Generated at 2022-06-21 20:54:27.747287
# Unit test for function get_token
def test_get_token():
    assert get_token()

