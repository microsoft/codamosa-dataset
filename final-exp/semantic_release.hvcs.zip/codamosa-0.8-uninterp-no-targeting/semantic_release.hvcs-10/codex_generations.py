

# Generated at 2022-06-21 20:48:06.624131
# Unit test for function get_token
def test_get_token():
    # For Github
    assert Github.token()
    # For Gitlab
    assert Gitlab.token()

# Generated at 2022-06-21 20:48:11.115617
# Unit test for method session of class Github
def test_Github_session():
    # Setup test variables
    raise_for_status = True
    retry = True
    test_result = Github.session (raise_for_status, retry)

    # Check results
    assert isinstance (test_result, Session), 'test_result should be of type Session'
    assert test_result.auth, 'test_result.auth should not be None'


# Generated at 2022-06-21 20:48:12.535112
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == os.environ.get("CI_SERVER_HOST")


# Generated at 2022-06-21 20:48:13.288527
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base().domain()

# Generated at 2022-06-21 20:48:16.736820
# Unit test for function upload_to_release
def test_upload_to_release():
    def test_for_hvcs(hvcs, owner, repository, version, path):
        config.set("hvcs", hvcs)
        assert upload_to_release(owner, repository, version, path)

    test_for_hvcs("github", "ownerc", "release", "1.1.0", "dist")
    test_for_hvcs("gitlab", "ownerc", "release", "1.1.0", "dist")

# Generated at 2022-06-21 20:48:18.170877
# Unit test for method token of class Base
def test_Base_token():
    """Test method Base.token"""
    raise NotImplementedError



# Generated at 2022-06-21 20:48:18.737802
# Unit test for constructor of class Github
def test_Github():
    gh = Github()
    assert gh


# Generated at 2022-06-21 20:48:19.874695
# Unit test for method token of class Github
def test_Github_token():
    assert Github.token() == "mytoken"
    # Test if method token does not return None
    assert Github.token() != None



# Generated at 2022-06-21 20:48:23.239025
# Unit test for constructor of class Gitlab
def test_Gitlab():
    obj = Gitlab()
    assert obj is not None

if __name__ == "__main__":
    test_Gitlab()

# Generated at 2022-06-21 20:48:26.014659
# Unit test for method api_url of class Base
def test_Base_api_url():
    class DummyBase(Base):
        pass

    try:
        DummyBase.api_url()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-21 20:50:12.587540
# Unit test for constructor of class Github
def test_Github():
    # Check the value of the attribute api_url is same as the desired value
    assert Github.api_url() == "https://api.github.com"
    # Check the value of the attribute domain is same as the desired value
    assert Github.domain() == "github.com"
    # Check the value of the attribute token is same as the desired value
    assert Github.token() == "GH_TOKEN"
    # Check the value of the attribute auth is same as the desired value
    assert Github.auth() == TokenAuth("GH_TOKEN")



# Generated at 2022-06-21 20:50:13.396345
# Unit test for method api_url of class Base
def test_Base_api_url():
    # Can't test abstract class
    assert True



# Generated at 2022-06-21 20:50:14.498867
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    assert TokenAuth("token") != TokenAuth("token2")



# Generated at 2022-06-21 20:50:16.661650
# Unit test for method token of class Github
def test_Github_token():
    # Test that Github.token() is equals to "TOKEN"
    assert Github.token() == "TOKEN"

# Generated at 2022-06-21 20:50:19.554705
# Unit test for constructor of class Base
def test_Base():
    with LoggedFunction(logger.debug):
        Base()

###############################################################################

# TODO: Remove this class in future and use gitlab.Gitlab

# Generated at 2022-06-21 20:50:22.941515
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    """Test for the method check_build_status of class Github"""
    instance = Github()
    assert False == instance.check_build_status("", "", "")



# Generated at 2022-06-21 20:50:23.943660
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("Borda", "hvcs", "1.0.0", "<p>Changelog</p>")



# Generated at 2022-06-21 20:50:28.149961
# Unit test for function get_hvcs
def test_get_hvcs():
    from cliff.lister import Lister
    from cliff.show import ShowOne
    from cliff.command import Command

    class Test(Command):
        def take_action(self, parsed_args):
            self.app.stdout.write("\n")
            self.app.stdout.write(get_hvcs())
            self.app.stdout.write("\n")

    class Test2(Command):
        def take_action(self, parsed_args):
            self.app.stdout.write("\n")
            self.app.stdout.write(get_hvcs().domain())
            self.app.stdout.write("\n")

    class TestList(Lister):
        def take_action(self, parsed_args):
            self.app.stdout.write("\n")

# Generated at 2022-06-21 20:50:30.656062
# Unit test for function check_build_status
def test_check_build_status():
    # I don't know how to make these tests anymore.
    pass



# Generated at 2022-06-21 20:50:34.905158
# Unit test for function get_hvcs
def test_get_hvcs():

    # Case 1: get_hvcs is called while the hvcs config is someting other than Github or Gitlab
    config_save = config.get_config()
    with pytest.raises(ImproperConfigurationError) as e:
        config.set_config({"hvcs": "fakehvcs"})
        get_hvcs()

    config.set_config(config_save)

    # Case 2: get_hvcs is called while the hvcs config is Github
    config_save = config.get_config()
    config.set_config({"hvcs": "github"})
    assert type(get_hvcs()) == Github

    config.set_config(config_save)

    # Case 3: get_hvcs is called while the hvcs config is Gitlab

# Generated at 2022-06-21 20:52:22.081558
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token() == None



# Generated at 2022-06-21 20:52:24.318119
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-21 20:52:28.769298
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    obj1 = TokenAuth("token")
    obj2 = TokenAuth("token")
    assert obj1 == obj2
    obj3 = TokenAuth("TOKEN")
    assert obj1 != obj3
    obj4 = "TOKEN"
    assert obj1 != obj4



# Generated at 2022-06-21 20:52:39.258989
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    from .helpers import random_string
    from .helpers import logging_setup

    logging_setup(level=logging.DEBUG)

    from .settings import config

    domain = config.get("hvcs_domain") or "github.com"
    api_url = config.get("hvcs_domain") or f"api.{domain}"
    token = config.get("hvcs_token") or os.environ.get("GH_TOKEN")

    logger.debug(f"domain: {domain}")
    logger.debug(f"api_url: {api_url}")
    logger.debug(f"token: {token}")

    owner = random_string(10)
    repo = random_string(10)
    ref = random_string(40)


# Generated at 2022-06-21 20:52:44.388623
# Unit test for function get_domain
def test_get_domain():
    # Set up configuration
    with patch.dict("os.environ", {"CI_SERVER_HOST": "unittest.com"}):
        config.update({"hvcs_domain": "unittest.com"})

        # Test
        assert get_domain() == "unittest.com"



# Generated at 2022-06-21 20:52:50.173685
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test function get_hvcs"""
    expected_output = {"Github": Github, "Gitlab": Gitlab}
    test_inputs = ["Github", "Gitlab"]
    for i in test_inputs:
            assert get_hvcs(i) == expected_output[i]



# Generated at 2022-06-21 20:52:54.212016
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab

# Generated at 2022-06-21 20:53:01.135669
# Unit test for constructor of class Base
def test_Base():
    assert issubclass(Base, object)
    assert hasattr(Base, "__init__")
    assert callable(Base.__init__)
    assert hasattr(Base, "domain")
    assert callable(Base.domain)
    assert hasattr(Base, "api_url")
    assert callable(Base.api_url)
    assert hasattr(Base, "token")
    assert callable(Base.token)
    assert hasattr(Base, "check_build_status")
    assert callable(Base.check_build_status)
    assert hasattr(Base, "post_release_changelog")
    assert callable(Base.post_release_changelog)
    assert hasattr(Base, "upload_dists")
    assert callable(Base.upload_dists)


# Generated at 2022-06-21 20:53:02.449143
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    api_url = Gitlab.api_url()
    print(api_url)
    assert api_url == "https://gitlab.com"



# Generated at 2022-06-21 20:53:04.266554
# Unit test for method auth of class Github
def test_Github_auth():
    expected = False
    actual = Github.auth() == Github.auth()
    assert actual == expected

