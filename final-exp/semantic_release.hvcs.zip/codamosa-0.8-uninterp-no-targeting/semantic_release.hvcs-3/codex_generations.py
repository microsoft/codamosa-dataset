

# Generated at 2022-06-21 20:51:31.329465
# Unit test for method auth of class Github
def test_Github_auth():
    token = "abcdefghijklmnopqrstuvwxyz"
    assert Github.auth() == None

    os.environ["GH_TOKEN"] = token

    assert Github.auth() == TokenAuth(token)


# Generated at 2022-06-21 20:51:32.230284
# Unit test for function check_token
def test_check_token():

    assert check_token() == True

# Generated at 2022-06-21 20:51:34.345542
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))


# Generated at 2022-06-21 20:51:37.063482
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    """
    Test method __ne__ for class TokenAuth
    """
    return TokenAuth("").__ne__(None)

# Generated at 2022-06-21 20:51:39.727975
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """Unit test for method __eq__ of class TokenAuth"""
    # Same token
    assert TokenAuth("123") == TokenAuth("123")
    # Different token
    assert TokenAuth("123") != TokenAuth("456")
    # AuthBase is not a TokenAuth
    assert TokenAuth("123") != AuthBase()



# Generated at 2022-06-21 20:51:41.257326
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-21 20:51:42.171637
# Unit test for function get_token
def test_get_token():
    assert get_token() != None

# Generated at 2022-06-21 20:51:43.094498
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == ""



# Generated at 2022-06-21 20:51:44.888418
# Unit test for method api_url of class Base
def test_Base_api_url():
    from .mocks import MockedBase

    assert MockedBase.api_url() == "https://base.com/api/v3"



# Generated at 2022-06-21 20:51:54.990462
# Unit test for method token of class Github
def test_Github_token():
    from ..settings import config
    from pip._vendor.pyparsing import stringEnd
    import unittest
    import unittest.mock as mock

    def mock_getenv(key: str, default: Optional[str] = None):
        return "GH_TOKEN_123"

    with mock.patch("os.getenv", mock_getenv):
        assert config.get("hvcs_domain") is None
        assert Github.token() == "GH_TOKEN_123"

    def mock_getenv(key: str, default: Optional[str] = None):
        return None

    with mock.patch("os.getenv", mock_getenv):
        assert config.get("hvcs_domain") is None
        assert Github.token() is None



# Generated at 2022-06-21 20:54:48.459092
# Unit test for constructor of class Github
def test_Github():
    g = Github()


# Generated at 2022-06-21 20:54:49.396564
# Unit test for method token of class Base
def test_Base_token():
    assert Base().token() is None

# Generated at 2022-06-21 20:54:52.941542
# Unit test for function get_domain
def test_get_domain():
    domain = [
        ("github", "github.com"),
        ("gitlab", "gitlab.com"),
    ]

    for i in domain:
        with mock_config({"hvcs": i[0]}):
            assert get_domain() == i[1]

# Generated at 2022-06-21 20:54:53.982067
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("test_owner","test_repo","test_ref") == False


# Generated at 2022-06-21 20:54:55.056031
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    pass



# Generated at 2022-06-21 20:54:58.053614
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    if not Base.check_build_status:
        hvcs_names = [cls.__name__ for cls in Base.__subclasses__()]
        raise ImproperConfigurationError(
            f"At least one HVCS in {', '.join(hvcs_names)} must "
            "implement the function check_build_status"
        )



# Generated at 2022-06-21 20:55:00.036424
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token() == None


# Generated at 2022-06-21 20:55:05.114045
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """
    Method __eq__ of class TokenAuth
    """
    token_auth: TokenAuth = TokenAuth("abc123")
    assert token_auth == TokenAuth("abc123")
    assert token_auth != TokenAuth("def456")
    assert token_auth != "abc123"

# Generated at 2022-06-21 20:55:06.528914
# Unit test for method api_url of class Base
def test_Base_api_url():
    assert Base.api_url() == ''


# Generated at 2022-06-21 20:55:10.746887
# Unit test for function get_hvcs
def test_get_hvcs():
    """This tests whether the get_hvcs function returns correct helper class
    based on configuration information.
    """
    hvcs = "Github"
    config.load_config(
        config_file=None,
        hvcs=hvcs
    )
    config.load()
    assert get_hvcs() == Github
