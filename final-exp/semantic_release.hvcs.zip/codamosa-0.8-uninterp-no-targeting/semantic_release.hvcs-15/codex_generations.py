

# Generated at 2022-06-21 20:48:31.570749
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():

    assert TokenAuth(token="token")("").headers["Authorization"] == "token token"
    assert (TokenAuth("token")("")).headers["Authorization"] == "token token"
    assert (
        TokenAuth("token")(object())
        .headers["Authorization"]
        == "token token"
    )



# Generated at 2022-06-21 20:48:33.544640
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-21 20:48:35.322708
# Unit test for method token of class Github
def test_Github_token():
    try:
        Github.token()
    except Exception as e:
        assert False, e

# Generated at 2022-06-21 20:48:37.500484
# Unit test for method session of class Github
def test_Github_session():
    """ Run test of Github.session """
    Github.session(raise_for_status=True, retry=False)


# Generated at 2022-06-21 20:48:39.189805
# Unit test for method session of class Github
def test_Github_session():
    Github = Github()
    Github.session(raise_for_status=True, retry=True)



# Generated at 2022-06-21 20:48:43.917685
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """Test case for method TokenAuth.__eq__"""
    test_token = '1234567890'
    auth = TokenAuth(test_token)
    assert auth == TokenAuth(test_token) and TokenAuth(test_token) == auth
    assert auth != TokenAuth('0987654321') and TokenAuth('0987654321') != auth

# Generated at 2022-06-21 20:48:46.378979
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    if os.getenv("RUN_GITLAB_TOKEN_TEST"):
        print(Gitlab.token())
    else:
        print("Please set environment variable RUN_GITLAB_TOKEN_TEST")



# Generated at 2022-06-21 20:48:47.104631
# Unit test for function check_token
def test_check_token():
    assert check_token()



# Generated at 2022-06-21 20:48:48.497651
# Unit test for constructor of class Github
def test_Github():
    assert Github.domain()
    assert Github.api_url()
    assert Github.token()
    assert Github.auth()
    assert Github.session()


# Generated at 2022-06-21 20:48:51.462904
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    auth = TokenAuth("123456789")
    assert auth.token == "123456789"



# Generated at 2022-06-21 20:53:55.732210
# Unit test for function get_token
def test_get_token():
    config.set("hvcs", "github")
    os.environ["GH_TOKEN"] = "GH_TOKEN"
    assert get_token() == "GH_TOKEN"

    config.set("hvcs", "gitlab")
    os.environ["GL_TOKEN"] = "GL_TOKEN"
    assert get_token() == "GL_TOKEN"


# Generated at 2022-06-21 20:53:59.570851
# Unit test for function check_build_status
def test_check_build_status():
    owner = "DAVFoundation"
    repository = "s3vaultlib"
    ref = "c865be40a6bfea0d3db3fdc016a710857654e9a6"
    assert get_hvcs().check_build_status(owner, repository, ref)



# Generated at 2022-06-21 20:54:01.465656
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == 'https://api.github.com', 'Wrong API URL'



# Generated at 2022-06-21 20:54:03.785576
# Unit test for function get_token
def test_get_token():
    hvcs = get_hvcs()
    token = hvcs.token()
    if token == None:
        assert False, "Token is None"


# Generated at 2022-06-21 20:54:07.479137
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() in ["github.com", "mydomain.com"]
    # Explicitly set the hvcs_domain to something else
    config.set("hvcs_domain", "mydomain.com")
    assert Github.domain() == "mydomain.com"



# Generated at 2022-06-21 20:54:11.671405
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.DEFAULT_DOMAIN == "github.com"
    os.environ["GITHUB_HOST"] = "github.custom.com"
    assert Github.domain() == "github.custom.com"


# Generated at 2022-06-21 20:54:13.827009
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert Base.check_build_status('owner', 'repo', 'ref') is False


# Generated at 2022-06-21 20:54:17.149844
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    assert TokenAuth(None) == "foo"
    assert not TokenAuth(None) == TokenAuth("foo")
    assert TokenAuth("foo") == TokenAuth("foo")



# Generated at 2022-06-21 20:54:20.205624
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    config.set("hvcs_domain", "gitlab-instance.local")
    assert Gitlab.domain() == "gitlab-instance.local"
    config.clear()


# Generated at 2022-06-21 20:54:22.955566
# Unit test for constructor of class Github
def test_Github():
    assert Github.api_url() == "https://api.github.com"
