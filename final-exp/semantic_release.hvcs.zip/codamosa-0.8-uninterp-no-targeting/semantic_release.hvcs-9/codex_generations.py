

# Generated at 2022-06-21 20:48:55.627264
# Unit test for constructor of class Gitlab
def test_Gitlab():
    """Unit test for constructor of class Gitlab"""
    assert Gitlab is not None


# Generated at 2022-06-21 20:49:02.999230
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert (
        Github.check_build_status("google", "cloud-python", "be3848e7e0fb6eaedb6c3e3e514b7f9ce0f0d5d5")
        is False
    )
    assert (
        Github.check_build_status(
            "google", "cloud-python", "fb251f7b8d39b5d01fea5213f23435b1ef8a62a2"
        )
        is False
    )



# Generated at 2022-06-21 20:49:08.409185
# Unit test for function get_hvcs
def test_get_hvcs():
    from . import ImproperConfigurationError
    from . import config
    from . import globals
    from . import github
    from . import gitlab
    assert get_hvcs() is github
    config.config["hvcs"] = "gitlab"
    assert get_hvcs() is gitlab
    config.config["hvcs"] = "none"
    assert get_hvcs() is gitlab
    globals.globals.pop("gitlab")
    config.config["hvcs"] = "gitlab"
    assert get_hvcs() is github
    config.config["hvcs"] = "none"
    with raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-21 20:49:09.634397
# Unit test for method auth of class Github
def test_Github_auth():
    pass  # no coverage

# Generated at 2022-06-21 20:49:11.293970
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status('user', 'repo', 'ref') == False


# Generated at 2022-06-21 20:49:12.380656
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs","gitlab")
    assert get_hvcs() == Gitlab

# Generated at 2022-06-21 20:49:16.053128
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("test", "test", "test", "test") == get_hvcs().post_release_changelog("test", "test", "test", "test")



# Generated at 2022-06-21 20:49:24.707726
# Unit test for constructor of class Base
def test_Base():
    class X(Base):
        pass
    assert X.domain() ==  'github.com'
    assert X.api_url() == 'https://api.github.com/'
    assert X.token() == 'GH_TOKEN'
    assert X.check_build_status(owner='owner', repo='repo', ref='ref') == False
    assert X.post_release_changelog(owner='owner', repo='repo', version='version',
        changelog='changelog') == False
    assert X.upload_dists(owner='owner', repo='repo', version='version',
        path='path') == True


# Generated at 2022-06-21 20:49:31.052347
# Unit test for method session of class Github
def test_Github_session():
    # Arrange
    # Act
    result = Github.session()

    # Assert
    assert isinstance(result, Session) is True
    assert result.raise_for_status is True
    assert isinstance(result.auth, TokenAuth) is True
    assert result.auth.token == Github.token()
    assert result.headers["Authorization"] == f"token {result.auth.token}"

# Generated at 2022-06-21 20:49:32.544776
# Unit test for method auth of class Github
def test_Github_auth():
  m = Github.auth
  assert m() == None


# Generated at 2022-06-21 20:51:07.836267
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = config.get("hvcs")
    try:
        globals()[hvcs.capitalize()]
    except KeyError:
        raise ImproperConfigurationError('"{0}" is not a valid option for hvcs.')


# Generated at 2022-06-21 20:51:11.962567
# Unit test for function check_token
def test_check_token():
    with patch.dict(os.environ, {"GH_TOKEN": "hola", "GL_TOKEN": "hola", "BITBUCKET_TOKEN": "hola"}):
        assert check_token() is True
    with patch.dict(os.environ, {"GH_TOKEN": "hola"}):
        assert check_token() is True
    with patch.dict(os.environ, {"GH_TOKEN": "hola", "BITBUCKET_TOKEN": "hola"}):
        assert check_token() is True
    with patch.dict(os.environ, {"GL_TOKEN": "hola"}):
        assert check_token() is True

# Generated at 2022-06-21 20:51:12.686862
# Unit test for function check_token
def test_check_token():
    assert check_token() is True
    assert check_token() is True

# Generated at 2022-06-21 20:51:15.504303
# Unit test for method token of class Github
def test_Github_token():
    """Unit test for method token of class Github"""
    os.environ["GH_TOKEN"] = "test-token"
    assert Github.token() == os.environ["GH_TOKEN"]



# Generated at 2022-06-21 20:51:22.630879
# Unit test for constructor of class Github
def test_Github():
    actual1 = Github.domain()
    expected1 = "github.com"
    assert actual1 == expected1, "test error"

    actual2 = Github.api_url()
    expected2 = "https://api.github.com"
    assert actual2 == expected2, "test error"

    actual3 = Github.token()
    expected3 = "GITHUB_TOKEN"
    assert actual3 == expected3, "test error"


# Generated at 2022-06-21 20:51:24.816639
# Unit test for method api_url of class Base
def test_Base_api_url():
    raised = False
    try:
        Base.api_url()
    except NotImplementedError:
        raised = True
    assert raised, "Improper exception raised"


# Generated at 2022-06-21 20:51:29.357275
# Unit test for function check_token
def test_check_token():
    assert check_token()
    os.environ["GH_TOKEN"] = None
    assert not check_token()
    os.environ["GH_TOKEN"] = "test"
    assert check_token()



# Generated at 2022-06-21 20:51:39.592694
# Unit test for method token of class Base
def test_Base_token():
    import unittest

    class BaseImpl(Base):
        @staticmethod
        def domain() -> str:
            return "domain"

        @staticmethod
        def api_url() -> str:
            return "api_url"

        @staticmethod
        def token() -> Optional[str]:
            return "token"

        @staticmethod
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            return True

        @classmethod
        def post_release_changelog(
            cls, owner: str, repo: str, version: str, changelog: str
        ) -> bool:
            return True

        @classmethod
        def upload_dists(cls, owner: str, repo: str, version: str, path: str) -> bool:
            return True


# Generated at 2022-06-21 20:51:43.093389
# Unit test for function check_token
def test_check_token():
    """
    This function is used to unit test the function check_token.
    """
    from . import config
    config.configuration(None, None, None, None)
    logger.debug("No token set, this is expected")
    assert not get_hvcs().token()



# Generated at 2022-06-21 20:51:50.157966
# Unit test for function post_changelog
def test_post_changelog():
    import unittest
    import collections
    from f8a_utils.version_utils import SemVer
    from f8a_utils.github import set_release_notes
    from f8a_utils.github import Github
    from f8a_utils.gitlab import set_release_notes as set_release_notes_gitlab
    from f8a_utils.gitlab import Gitlab
    from git import Repo
    from tempfile import TemporaryDirectory
    from freezegun import freeze_time
    from unittest.mock import patch

    with patch("f8a_utils.hvcs.config", new=collections.defaultdict(str)):
        config["hvcs"] = "github"
        config["tmpdir"] = '/tmp'
        config["hvcs_domain"] = 'github.com'
        config

# Generated at 2022-06-21 20:54:56.087122
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    auth = TokenAuth('xyz')
    assert auth.token == 'xyz'
    r = Session().get('http://https://www.github.com/')
    r.headers["Authorization"] = f"token {auth.token}"
    assert r.status_code == 200
    assert r.headers["Authorization"] == 'token xyz'


# Generated at 2022-06-21 20:54:59.723844
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com", "Failed to return proper domain"


# Generated at 2022-06-21 20:55:01.494986
# Unit test for function upload_to_release
def test_upload_to_release():
    owner = 'gehcautodev'
    repository = 'test_upload_release'
    version = '0.1.0'
    path = '/apps/autobump/artifacts/dist'
    assert upload_to_release(owner, repository, version, path) == True



# Generated at 2022-06-21 20:55:06.859753
# Unit test for constructor of class Github
def test_Github():
    assert Github.domain() == 'github.com'
    assert Github.api_url() == 'https://api.github.com'
    assert Github.token() == '123456789ABCDEF'
    Github.token = lambda: '123456789ABCDEF'
    assert Github.token() == '123456789ABCDEF'


# Generated at 2022-06-21 20:55:12.193887
# Unit test for function get_hvcs
def test_get_hvcs():
    logger.info(f"function get_hvcs")
    config["hvcs"] = "gitlab"
    assert isinstance(get_hvcs(), Gitlab)
    config["hvcs"] = "github"
    assert isinstance(get_hvcs(), Github)
    config["hvcs"] = "test"
    try:
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        assert True



# Generated at 2022-06-21 20:55:12.857112
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    assert True

# Generated at 2022-06-21 20:55:16.188879
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    """
    Test equality of two TokenAuth instances
    """
    assert TokenAuth("token") == TokenAuth("token")
    assert not TokenAuth("token_one") == TokenAuth("token_two")



# Generated at 2022-06-21 20:55:21.828599
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token_ = "token"
    token_auth = TokenAuth(token_)
    assert token_auth.token == token_
    assert token_auth.__eq__(token_auth)
    another_token_auth = TokenAuth("anotherToken")
    assert not token_auth == another_token_auth



# Generated at 2022-06-21 20:55:23.168712
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-21 20:55:23.961885
# Unit test for function get_token
def test_get_token():
    assert get_token() is None

