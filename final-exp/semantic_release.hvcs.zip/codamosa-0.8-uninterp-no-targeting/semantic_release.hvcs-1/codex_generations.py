

# Generated at 2022-06-21 20:48:33.433331
# Unit test for method api_url of class Base
def test_Base_api_url():
    method = LoggedFunction()(Base.api_url)
    result = method()
    assert result is not None, "Base.api_url: should return a value"



# Generated at 2022-06-21 20:48:34.781745
# Unit test for method api_url of class Base
def test_Base_api_url():
    assert Base.api_url() == ''


# Generated at 2022-06-21 20:48:36.856642
# Unit test for function check_token
def test_check_token():
    """
    Tests the function check_token()
    """
    assert check_token() == True

# Generated at 2022-06-21 20:48:38.467372
# Unit test for function check_token
def test_check_token():
    """
    Unit test for function check_token()
    """
    assert check_token()



# Generated at 2022-06-21 20:48:39.853627
# Unit test for method session of class Github
def test_Github_session():
    Github()
    assert True, "Test session of class Github"



# Generated at 2022-06-21 20:48:43.576814
# Unit test for method auth of class Github
def test_Github_auth():
    token = os.environ.get("GH_TOKEN")
    if token:
        expected = TokenAuth(token)
        actual = Github.auth()
        assert expected == actual, "TokenAuth is not equal"
        assert expected is not None
    else:
        assert Github.auth() is None



# Generated at 2022-06-21 20:48:45.564973
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    obj = TokenAuth('token')
    assert(obj.__ne__(None))



# Generated at 2022-06-21 20:48:46.561736
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert not Github.check_build_status("", "", "")


# Generated at 2022-06-21 20:48:48.815006
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    t1 = TestClass1()
    assert t1.check_build_status("owner", "repo", "ref") == None


# Generated at 2022-06-21 20:48:51.867088
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False



# Generated at 2022-06-21 20:51:06.639944
# Unit test for function post_changelog
def test_post_changelog():
    """
    Unit test for function post_changelog
    """
    owner = "owner"
    repository = "repo"
    version = "v.1.2"
    changelog = """
        * Hi!
        * This is a changelog
        * with some test lines
        """
    assert post_changelog(owner, repository, version, changelog)

# Generated at 2022-06-21 20:51:12.247064
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    """Test TokenAuth"""
    token = "test_token"
    
    token_auth = TokenAuth(token)
    assert token_auth
    assert token_auth.token == "test_token"

    new_token_auth = TokenAuth(token)
    assert token_auth == new_token_auth

    r = {
        "headers": {'Authorization': 'token test_token'}
    }
    assert token_auth(r) is r


# Generated at 2022-06-21 20:51:15.127435
# Unit test for method session of class Github
def test_Github_session():
    assert (
        Github.session(raise_for_status=True, retry=True)
        == build_requests_session(raise_for_status=True, retry=True)
    )



# Generated at 2022-06-21 20:51:16.784676
# Unit test for method api_url of class Base
def test_Base_api_url():
    with pytest.raises(NotImplementedError):
        Base.api_url()

# Generated at 2022-06-21 20:51:21.417442
# Unit test for method api_url of class Github
def test_Github_api_url():

    '''
    Test Github.api_url()
    '''
    result = Github.api_url()
    assert isinstance(result, str)
    assert result.startswith("https://api.github")



# Generated at 2022-06-21 20:51:27.365811
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab.domain() == os.environ.get(
        "CI_SERVER_HOST", "gitlab.com"
    )
    assert Gitlab.api_url() == f"https://{os.environ.get('CI_SERVER_HOST', 'gitlab.com')}"
    assert Gitlab.token() == os.environ.get("GL_TOKEN")

# Generated at 2022-06-21 20:51:29.904104
# Unit test for function get_token
def test_get_token():
    """
    Unit test for function get_token
    """
    assert get_token() is None

# Generated at 2022-06-21 20:51:34.345981
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None
    os.environ["GH_TOKEN"] = "GH_TOKEN"
    assert Github.auth() == TokenAuth("GH_TOKEN")

# Generated at 2022-06-21 20:51:37.064251
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    auth = TokenAuth('XXXXXX')
    assert auth.__ne__(object)
    assert not auth.__ne__(auth)


# Generated at 2022-06-21 20:51:37.802041
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-21 20:54:04.707760
# Unit test for function check_token
def test_check_token():
    assert get_hvcs().check_token() == True


# Generated at 2022-06-21 20:54:05.898011
# Unit test for function get_token
def test_get_token():
    assert get_token()


# Generated at 2022-06-21 20:54:08.109769
# Unit test for method token of class Github
def test_Github_token():
    # Simple test to see if the token can be retrieved and is a string
    token = Github.token()
    assert isinstance(token, str)



# Generated at 2022-06-21 20:54:09.861923
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-21 20:54:13.440650
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    Gitlab.domain=MagicMock(return_value="gitlab.example.com")
    assert Gitlab.api_url()=="https://gitlab.example.com"

# Generated at 2022-06-21 20:54:14.113524
# Unit test for function get_token
def test_get_token():
    assert str is type(get_token())

# Generated at 2022-06-21 20:54:16.477091
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert Base.check_build_status("owner", "repo", "ref") is False


# Generated at 2022-06-21 20:54:22.632664
# Unit test for function get_hvcs
def test_get_hvcs():
    mock_config = {}
    with patch("tito.common.config.config", mock_config):
        mock_config["hvcs"] = "github"
        result = get_hvcs()
        assert result == Github
        mock_config["hvcs"] = "gitlab"
        result = get_hvcs()
        assert result == Gitlab
        mock_config["hvcs"] = "XYZ"
        try:
            get_hvcs()
            assert False
        except ImproperConfigurationError:
            assert True


# Generated at 2022-06-21 20:54:27.471621
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """
    test for method __eq__ of class TokenAuth
    """
    # TokenAuth is checking only the token so equal if equal tokens are passed
    token1 = "token1"
    token2 = "token2"
    token_auth1 = TokenAuth(token1)
    token_auth2 = TokenAuth(token1)
    assert token_auth1 == token_auth2
    token_auth3 = TokenAuth(token2)
    assert token_auth1 != token_auth3



# Generated at 2022-06-21 20:54:28.513899
# Unit test for method token of class Github
def test_Github_token():
    assert Github.token() != None
