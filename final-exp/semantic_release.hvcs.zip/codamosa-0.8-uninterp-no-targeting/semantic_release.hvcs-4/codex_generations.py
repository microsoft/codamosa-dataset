

# Generated at 2022-06-21 20:50:38.788441
# Unit test for method session of class Github
def test_Github_session():
    assert Github.session()


# Generated at 2022-06-21 20:50:39.490951
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() == "github.com"



# Generated at 2022-06-21 20:50:41.650297
# Unit test for method api_url of class Github
def test_Github_api_url():
    expected_value = "https://api.github.com/"
    actual_value = Github.api_url()
    assert actual_value == expected_value


# Generated at 2022-06-21 20:50:44.411038
# Unit test for constructor of class Base
def test_Base():
    """Test the constructor of class Base
    """
    isinstance(Base(), Base)


# Generated at 2022-06-21 20:50:46.748211
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release('irisli', 'test', '0.1.0', 'C:\\Users\\irisl\\Desktop\\test') == True
    assert upload_to_release('irisli', 'test', '0.2.0', 'C:\\Users\\irisl\\Desktop\\test') == False

# Generated at 2022-06-21 20:50:49.699044
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("google", "tensorboard", "random_hash")



# Generated at 2022-06-21 20:50:54.409809
# Unit test for function check_build_status
def test_check_build_status():
    # GitHub
    if os.environ.get("GH_TOKEN"):
        assert (check_build_status("googleapis", "deploy-manager", "b3f8d8c0838e0c24db9f9a9f8a2b2d2a3a3b3c3d"))
    # GitLab
    if os.environ.get("GL_TOKEN"):
        assert (check_build_status("googleapis", "deploy-manager", "b3f8d8c0838e0c24db9f9a9f8a2b2d2a3a3b3c3d"))



# Generated at 2022-06-21 20:50:56.743824
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
    config.set("hvcs_domain", "foo")
    assert Gitlab.domain() == "foo"
    os.environ["CI_SERVER_HOST"] = "bar"
    assert Gitlab.domain() == "bar"



# Generated at 2022-06-21 20:50:58.338558
# Unit test for function upload_to_release
def test_upload_to_release():
    assert get_hvcs().upload_dists("me", "repo", "version", "path") == False

# Generated at 2022-06-21 20:51:10.683686
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    test_cases_check_build_status = [
        {
            "input": {
                "owner": "hpcugent",
                "repo": "easybuild",
                "ref": "easybuild-framework",
            },
            "expect": True,
        },
        {
            "input": {
                "owner": "hpcugent",
                "repo": "foo",
                "ref": "easybuild-framework",
            },
            "expect": False,
        },
    ]
    for testcase in test_cases_check_build_status:
        ret_val = Base.check_build_status(**testcase["input"])

# Generated at 2022-06-21 20:53:25.097430
# Unit test for function check_token
def test_check_token():
    assert check_token() is True

# Generated at 2022-06-21 20:53:27.050527
# Unit test for method token of class Base
def test_Base_token(): # noqa: D103
    assert Base.token() is None



# Generated at 2022-06-21 20:53:31.285344
# Unit test for function check_token
def test_check_token():
    mocked_token = config.get("token")
    if not mocked_token:
        config.set("token", "mocked_token")
    assert check_token() == True

    config.set("token", None)
    assert check_token() == False

    config.set("token", mocked_token)

# Generated at 2022-06-21 20:53:32.548067
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-21 20:53:34.953120
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    # Check if expected exception is raised with invalid value
    with pytest.raises(NotImplementedError):
        TokenAuth.TokenAuth(None)

        TokenAuth.TokenAuth(None)

# Generated at 2022-06-21 20:53:39.441981
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def raise_for_status(self):
            pass

        def json(self):
            return {"status": "success"}

    def get_mock_return():
        return MockResponse()

    gitlab.Gitlab.__getattr__ = lambda x, y: get_mock_return

    assert Gitlab.check_build_status("owner", "repo", "ref")



# Generated at 2022-06-21 20:53:50.118241
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    # Case 1: With environment variable CI_SERVER set
    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    assert Gitlab.api_url() == "https://gitlab.com"
    os.environ.pop("CI_SERVER_HOST")

    # Case 2: With hvcs_domain set in config
    config["hvcs_domain"] = "gitlab.sample.com"
    assert Gitlab.api_url() == "https://gitlab.sample.com"
    config.pop("hvcs_domain")

    # Case 3: With neither optional environment variable nor hvcs_domain set in
    #         config
    assert Gitlab.api_url() == "https://gitlab.com"

    os.environ.pop("CI_SERVER_HOST")


# Generated at 2022-06-21 20:53:53.009657
# Unit test for function get_hvcs
def test_get_hvcs():
    if sys.platform.startswith("win"):
        # Windows doesn't allow overwriting environment variables like this
        return
    config["hvcs"] = "gitlab"
    assert(get_hvcs() == Gitlab)
    config["hvcs"] = "github"
    assert(get_hvcs() == Github)



# Generated at 2022-06-21 20:53:57.583237
# Unit test for method api_url of class Github
def test_Github_api_url():
    # No custom domain
    assert Github.api_url() == "https://api.github.com"
    # Custom domain
    config.set("hvcs_domain", "gitlab.com")
    assert Github.api_url() == "https://gitlab.com"
    config.set("hvcs_domain", None)



# Generated at 2022-06-21 20:53:58.263407
# Unit test for constructor of class Github
def test_Github():
    Github()

