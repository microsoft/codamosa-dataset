

# Generated at 2022-06-21 20:47:49.111675
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == None, "domain() returned unexpected value"


# Generated at 2022-06-21 20:47:53.096138
# Unit test for method auth of class Github
def test_Github_auth():
    local = Github

    # test with missing auth parameter
    assert local.auth() is None

    # test with missing credentials
    os.environ["GH_TOKEN"] = ""
    assert local.auth() is None

    # test with invalid credentials
    os.environ["GH_TOKEN"] = "123"
    assert local.auth() is not None

    # test with valid credentials
    os.environ["GH_TOKEN"] = "abc"
    assert local.auth() is not None



# Generated at 2022-06-21 20:47:54.027593
# Unit test for method api_url of class Base
def test_Base_api_url():
    obj = Base()
    assert obj.api_url().startswith("https://")



# Generated at 2022-06-21 20:47:55.758206
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert Base.check_build_status("owner", "repo", "ref") is False

# Generated at 2022-06-21 20:47:57.453321
# Unit test for function get_domain
def test_get_domain():
    assert (get_domain() is None)



# Generated at 2022-06-21 20:47:58.753921
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-21 20:47:59.955591
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-21 20:48:03.268970
# Unit test for method domain of class Base
def test_Base_domain(): # type: ignore
    assert Base.domain().__class__.__name__ == "str"


# Generated at 2022-06-21 20:48:07.371092
# Unit test for constructor of class Github
def test_Github():
    hvcs = Github()
    assert hvcs.token() == os.environ.get("GH_TOKEN")
    assert hvcs.domain()=="github.com"
    assert hvcs.api_url()== "https://api.github.com"


# Generated at 2022-06-21 20:48:09.778497
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab.domain() is not None
    assert Gitlab.api_url() is not None
    assert Gitlab.token() is not None


# Generated at 2022-06-21 20:51:12.511230
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog('james_owner', 'james_repository', 'james_version', 'james_changelog') == True

# Generated at 2022-06-21 20:51:15.629613
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    a = TokenAuth(token="123")
    assert a.token == "123"
    assert a.__call__.__doc__ == 'Invoke this authentication method.'
    assert "token 123" in a.__call__(r=None)



# Generated at 2022-06-21 20:51:23.681701
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    from copy import copy

    token_auth_one = TokenAuth("token")
    token_auth_two = TokenAuth("token")
    token_auth_three = copy(token_auth_one)
    assert token_auth_one == token_auth_two
    assert token_auth_two == token_auth_three
    assert token_auth_one == token_auth_three

    token_auth_one = TokenAuth("token")
    token_auth_two = TokenAuth("token2")
    assert token_auth_one != token_auth_two



# Generated at 2022-06-21 20:51:28.699870
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    >>> hvcs.Gitlab.check_build_status("test", "test", "test")
    check_build_status: job test is still in pending status
    False
    """
    pass



# Generated at 2022-06-21 20:51:30.118119
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    Base.check_build_status("owner", "repo", "ref")

# Generated at 2022-06-21 20:51:32.352355
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    # Create an instance of Gitlab
    gl = Gitlab()
    # Check that the token is not empty
    assert(len(Gitlab.token()) > 5)


# Generated at 2022-06-21 20:51:33.604805
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """Test for method __eq__."""
    pass



# Generated at 2022-06-21 20:51:39.430105
# Unit test for method session of class Github
def test_Github_session():
    assert isinstance(Github.session(retry=False), Session)
    assert Github.session(retry=False).auth != Github.session(retry=True).auth
    assert Github.session(retry=False).auth == Github.session(retry=False).auth
    assert Github.session(retry=False).auth != Github.session(retry=True).auth



# Generated at 2022-06-21 20:51:47.705158
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    class Base(object):
        @staticmethod
        def domain() -> str:
            raise NotImplementedError

        @staticmethod
        def api_url() -> str:
            raise NotImplementedError

        @staticmethod
        def token() -> Optional[str]:
            raise NotImplementedError

        @staticmethod
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            return True

        @classmethod
        def post_release_changelog(
            cls, owner: str, repo: str, version: str, changelog: str
        ) -> bool:
            raise NotImplementedError


# Generated at 2022-06-21 20:51:49.787387
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    Github.check_build_status('autoai-pipelines','pipelines-cli','c7d90b5')


# Generated at 2022-06-21 20:53:25.741436
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()

# Generated at 2022-06-21 20:53:31.596441
# Unit test for method api_url of class Github
def test_Github_api_url():
    domain = "github.com"
    assert Github.api_url() == "https://api.github.com"
    assert Github.api_url(domain=domain) == f"https://api.{domain}"
    assert Github.api_url("test.test") == "https://test.test"
    assert Github.api_url(domain=None) == "https://api.github.com"



# Generated at 2022-06-21 20:53:33.781570
# Unit test for method domain of class Base
def test_Base_domain():
    from .base import Base
    from .helpers import assert_function_returns_string
    assert_function_returns_string(Base.domain)




# Generated at 2022-06-21 20:53:38.673899
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    # We assume that method __ne__ of class TokenAuth and method __call__ of class TokenAuth are working fine
    # and so we will focus on testing method __eq__ and __ne__ of class TokenAuth
    tok = TokenAuth("token")
    assert tok == tok
    assert tok == TokenAuth("token")
    assert tok != TokenAuth("token2")
    assert tok != "token"
    assert tok != "token"



# Generated at 2022-06-21 20:53:48.955516
# Unit test for constructor of class Base
def test_Base():
    with pytest.raises(NotImplementedError):
        assert Base().domain() is None
    with pytest.raises(NotImplementedError):
        assert Base().api_url() is None
    with pytest.raises(NotImplementedError):
        assert Base().token() is None
    with pytest.raises(NotImplementedError):
        assert Base().check_build_status(None, None, None) is None
    with pytest.raises(NotImplementedError):
        assert Base().post_release_changelog(None, None, None, None) is None
    assert Base().upload_dists(None, None, None, None) is True



# Generated at 2022-06-21 20:53:52.307264
# Unit test for function post_changelog
def test_post_changelog():
    assert post_changelog("inveniosoftware", "invenio-cli", "0.1.1", "The initial release") == True

# Generated at 2022-06-21 20:53:56.259097
# Unit test for method token of class Base
def test_Base_token():
    from .helpers import get_env_variable
    from .settings import config
    config["token"] = get_env_variable("FAKE_TOKEN")
    assert Base.token(), "On test Base.token()"


# Generated at 2022-06-21 20:53:58.613120
# Unit test for function check_build_status
def test_check_build_status():
    assert True == config.get('hvcs').check_build_status('owner', 'repository', 'ref')



# Generated at 2022-06-21 20:54:04.010038
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://gitlab.com"

    os.environ["CI_SERVER_HOST"] = "gitlab.local"
    assert Gitlab.api_url() == "https://gitlab.local"

    config._config["hvcs_domain"] = "gitlab.mydomain"
    assert Gitlab.api_url() == "https://gitlab.mydomain"



# Generated at 2022-06-21 20:54:06.740596
# Unit test for method api_url of class Github
def test_Github_api_url():
    """Unit test for Github.api_url()"""
    config["hvcs_domain"] = ""
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-21 20:55:47.801178
# Unit test for function check_build_status
def test_check_build_status():
    import unittest
    import unittest.mock

    class TestCheckBuildStatus(unittest.TestCase):
        """Unit test for function check_build_status"""

        @staticmethod
        @unittest.mock.patch("git_changelog_builder.utils.Github.check_build_status")
        def test_github_check_build_status(github):
            """Test function with Github as HVCS"""
            config.set("hvcs", "github")
            assert check_build_status("owner", "repo", "ref") is github.return_value


# Generated at 2022-06-21 20:55:49.399537
# Unit test for function check_build_status
def test_check_build_status():
  assert check_build_status("", "", "") == True
# this test that is receiving a fake object just doesn't make sense
# it doesn't do any checking of what happens, just checks that a syntax does
# not throw an error


# Generated at 2022-06-21 20:55:50.534839
# Unit test for function post_changelog
def test_post_changelog():
    assert True == post_changelog("neuropil","neuropil", "0.1.0", "changelog content" )


# Generated at 2022-06-21 20:55:56.690707
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://gitlab.com"

    config.override({"hvcs_domain": "something.com"})
    assert Gitlab.api_url() == "https://something.com"

    config.reset_override("hvcs_domain")
    os.environ["CI_SERVER_HOST"] = "something-else.com"
    assert Gitlab.api_url() == "https://something-else.com"


# Generated at 2022-06-21 20:55:58.650965
# Unit test for function upload_to_release
def test_upload_to_release():
    try:
        return get_hvcs().upload_dists("yunxi", "douban", "0.1", ".\\dist")
    except:
        return False

# Generated at 2022-06-21 20:56:00.953434
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    """
    Tests for constructor of class TokenAuth
    """
    token = "12345"
    token_auth = TokenAuth(token)
    assert token_auth.token == token
    assert token_auth("request")



# Generated at 2022-06-21 20:56:11.593184
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))

    os.environ["CI_SERVER_HOST"] = "my_domain"
    assert Gitlab.domain() == "my_domain"
    del os.environ["CI_SERVER_HOST"]

    config.set("hvcs_domain", "my_domain")
    assert Gitlab.domain() == "my_domain"
    config.set("hvcs_domain", None)

    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-21 20:56:13.496084
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    isinstance(Github.api_url(), str)
    isinstance(Github.domain(), str)

# Generated at 2022-06-21 20:56:16.957049
# Unit test for function get_hvcs
def test_get_hvcs():
    get_hvcs_result = get_hvcs()
    assert isinstance(get_hvcs_result, Base)
    config.set("hvcs","wrong")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs","github")

