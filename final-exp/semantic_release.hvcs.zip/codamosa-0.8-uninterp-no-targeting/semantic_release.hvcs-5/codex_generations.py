

# Generated at 2022-06-21 20:48:20.546762
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    token1 = "qwerty"
    token2 = "asdfgh"
    auth1 = TokenAuth(token1)
    auth2 = TokenAuth(token2)
    assert auth1 == auth2  # equal
    auth2 = TokenAuth(token1)
    assert auth1 == auth2  # equal
    assert auth1 == object()  # equal
    assert auth1 != token1  # not equal
    assert auth1 != "asdfgh"  # not equal



# Generated at 2022-06-21 20:48:23.304019
# Unit test for method session of class Github
def test_Github_session():
    func_name = "session"
    logger.info("Testing Github class, method: %s", func_name)

    # Workflow:
    # 1. Create an instance of the class
    # 2. Invoke the method
    # 3. Evaluate the result

    # 1.
    github = Github()

    # 2. & 3.
    result = github.session()
    assert result



# Generated at 2022-06-21 20:48:28.358478
# Unit test for constructor of class Gitlab
def test_Gitlab():
    # at least one of the two env variables must be set to run the test
    if not Gitlab.token() and not Gitlab.domain():
        pytest.skip("Skipping Gitlab tests because $GL_TOKEN or $CI_SERVER_HOST are not defined")
    test = Gitlab()
    assert test.domain()
    assert test.token()
    assert test.api_url()

# Generated at 2022-06-21 20:48:29.245439
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github or get_hvcs() == Gitlab


# Generated at 2022-06-21 20:48:30.138101
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == 'base'

# Generated at 2022-06-21 20:48:32.463189
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-21 20:48:37.326974
# Unit test for function get_hvcs
def test_get_hvcs():
    # set up test
    config_options = {'hvcs': 'Github'}
    config.set_options(config_options)

    # run test
    test_class = get_hvcs()

    # check outcomes
    assert(test_class.name == 'Github')

# Generated at 2022-06-21 20:48:39.761636
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    with patch.object(config, "get", return_value=None):
        assert Gitlab.api_url() == "https://gitlab.com"



# Generated at 2022-06-21 20:48:41.101534
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    assert TokenAuth(token="").__ne__(object()) is True



# Generated at 2022-06-21 20:48:44.555106
# Unit test for method token of class Base
def test_Base_token():
    from .settings import config
    from .helpers import LoggedFunction
    hostname = 'github'
    exist_token = '1be18a2b9a110c863740d0713cae950a6'
    token = Base.token()
    assert token==exist_token


# Generated at 2022-06-21 20:51:12.611270
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    TokenAuth("token") != TokenAuth("token")



# Generated at 2022-06-21 20:51:13.710680
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("username","repo","v0.0.1") == True



# Generated at 2022-06-21 20:51:14.740831
# Unit test for function get_domain
def test_get_domain():
    """
    Get the domain for the current VCS

    :return: The domain in string form
    """
    assert get_domain()

# Generated at 2022-06-21 20:51:16.570990
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token = "TOKEN"
    result = TokenAuth(token)
    assert result.token == "TOKEN"


# Generated at 2022-06-21 20:51:22.080206
# Unit test for function get_hvcs
def test_get_hvcs():
    assert(get_hvcs().DEFAULT_DOMAIN=="github.com")
    config['hvcs'] = "gitlab"
    assert(get_hvcs().DEFAULT_DOMAIN=="gitlab.com")
    config['hvcs'] = "github"

# Generated at 2022-06-21 20:51:23.723691
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == TokenAuth.__call__(Github.token())


# Generated at 2022-06-21 20:51:24.521662
# Unit test for function post_changelog
def test_post_changelog():
    post_changelog()

# Generated at 2022-06-21 20:51:30.759076
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://api.gitlab.com"
    # Gitlab domain is not set
    assert Gitlab.api_url() == "https://gitlab.com"
    setattr(config, "hvcs_domain", "test")
    assert Gitlab.api_url() == "https://test"


# Generated at 2022-06-21 20:51:36.113013
# Unit test for constructor of class Base
def test_Base():
    with pytest.raises(NotImplementedError):
        Base.domain()
    with pytest.raises(NotImplementedError):
        Base.api_url()
    with pytest.raises(NotImplementedError):
        Base.token()
    with pytest.raises(NotImplementedError):
        Base.check_build_status()
    with pytest.raises(NotImplementedError):
        Base.post_release_changelog()
    assert Base.upload_dists()



# Generated at 2022-06-21 20:51:38.646230
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    from .hvcs import Base

    class Dummy(Base):
        pass

    try:
        Dummy.check_build_status("", "", "")
        assert False, "method check_build_status should fail when not implemented"
    except NotImplementedError:
        pass



# Generated at 2022-06-21 20:53:21.082546
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    """ Test the method token of class Gitlab"""
    try:
        del os.environ["GL_TOKEN"]
    except KeyError:
        pass

    assert Gitlab.token() is None

    os.environ["GL_TOKEN"] = "foo"

    assert Gitlab.token() == "foo"



# Generated at 2022-06-21 20:53:25.174327
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    # Create instance of class Base
    instance = Base()
    # Assert method check_build_status raises NotImplementedError
    with pytest.raises(NotImplementedError):
        instance.check_build_status(owner="owner",repo="repo",ref="ref")


# Generated at 2022-06-21 20:53:26.307947
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token() is None


# Generated at 2022-06-21 20:53:32.883044
# Unit test for constructor of class Gitlab
def test_Gitlab():
    """Unit test for constructor of class Gitlab"""
    assert Gitlab.api_url() in "https://"
    assert Gitlab.token() is not None
    assert Gitlab.check_build_status("hpc-admin", "conda-forge-webservices", "12345") is not None
    assert Gitlab.post_release_changelog("hpc-admin", "conda-forge-webservices", "12345", "3.14")



# Generated at 2022-06-21 20:53:34.386288
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token_auth = TokenAuth("token")
    assert token_auth.token == "token"



# Generated at 2022-06-21 20:53:35.931791
# Unit test for method token of class Github
def test_Github_token():
    assert Github.token() == os.environ.get("GH_TOKEN")



# Generated at 2022-06-21 20:53:42.673951
# Unit test for function check_token
def test_check_token():
    """
    Unit test for checking the functionality of check_token
    """
    # When there is a token
    with patch('hubrelease.hvcs.config.get') as config_get, \
            patch('hubrelease.hvcs.Github.token') as git_token, \
            patch('hubrelease.hvcs.Gitlab.token') as gl_token:
        config_get.return_value = "github"
        git_token.return_value = "token"
        assert check_token() is True


# Generated at 2022-06-21 20:53:46.626959
# Unit test for function check_build_status
def test_check_build_status():
    assert check_build_status("owner", "repository", "e99d6d15e6c087c4a4e2a7d1f6480b161e9b4a50")



# Generated at 2022-06-21 20:53:50.417203
# Unit test for method auth of class Github
def test_Github_auth():
    Github.auth()



# Generated at 2022-06-21 20:53:55.472934
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    GITHUB_TOKEN = "test-token"
    os.environ["GL_TOKEN"] = GITHUB_TOKEN
    assert(Gitlab.token() == os.environ["GL_TOKEN"])
    os.environ.pop("GL_TOKEN", None)


# Generated at 2022-06-21 20:55:46.110016
# Unit test for method __ne__ of class TokenAuth
def test_TokenAuth___ne__():
    """
    Tests the method `__ne__` of the class `TokenAuth`
    """
    token_auth = TokenAuth(token = "long_token")
    
    assert token_auth != None

# Generated at 2022-06-21 20:55:48.118936
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() != "https://gitlab.com"


# Generated at 2022-06-21 20:55:49.289289
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-21 20:55:51.205681
# Unit test for constructor of class Base
def test_Base():
    try:
        Base()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("Expected NotImplementedError")



# Generated at 2022-06-21 20:55:52.231791
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == "example.com"


# Generated at 2022-06-21 20:55:55.092060
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status(owner="owner", repo="repo", ref="ref") == False
    pass


# Generated at 2022-06-21 20:56:00.722028
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    domain = Github.domain()
    repo = config.get("project")
    ref = config.get("sha")

    # Test pagination
    while True:
        response = Github.session().get(
            f"{Github.api_url()}/repos/{domain}/{repo}/commits/{ref}/status"
        )
        assert response.ok
        status = response.json().get("state")
        assert status in ["pending", "success", "failure"]
        if status != "pending":
            break

    assert status == "success"



# Generated at 2022-06-21 20:56:04.879100
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    from requests.auth import AuthBase

    assert TokenAuth(
        "test_token"
    ) == TokenAuth("test_token")



# Generated at 2022-06-21 20:56:11.408940
# Unit test for method token of class Github
def test_Github_token():
    if os.getenv("GH_TOKEN"):
        # Check if token auth works
        session = Github.session()
        response = session.get(f"{Github.api_url()}/user")
        assert response.json().get("id") == config.get("github_id")
    else:
        # Check if it fails
        assert Github.token() is None


# Generated at 2022-06-21 20:56:12.550767
# Unit test for method auth of class Github
def test_Github_auth():
  assert True
