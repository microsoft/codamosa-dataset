

# Generated at 2022-06-21 20:51:18.799707
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    pass

# Generated at 2022-06-21 20:51:22.812531
# Unit test for function check_build_status
def test_check_build_status():
    assert True == get_hvcs().check_build_status("xuniyao", "mdf", "master")
    assert False == get_hvcs().check_build_status("xuniyao", "mdf", "fdsafdsa")


# Generated at 2022-06-21 20:51:26.636569
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    session = build_requests_session(
        with_retries=Retry(total=3, status_forcelist=[429, 500, 502, 503, 504])
    )

    auth = TokenAuth("123123123")
    assert auth == TokenAuth("123123123")
    assert isinstance(auth.token, str) == True
    assert isinstance(auth.__call__(session), Session) == True

# Generated at 2022-06-21 20:51:28.924611
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    TokenAuth("123") == TokenAuth("123")



# Generated at 2022-06-21 20:51:30.028121
# Unit test for method token of class Github
def test_Github_token():
    assert Github.token() is None



# Generated at 2022-06-21 20:51:31.895465
# Unit test for method api_url of class Base
def test_Base_api_url():
    try:
        Base.api_url()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-21 20:51:33.097231
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    assert Base.check_build_status("owner","repo","ref")


# Generated at 2022-06-21 20:51:36.239224
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("conan-io", "gitctl", "8f6798a23a2acdde1cfb5a213bba9f34ea05359d")



# Generated at 2022-06-21 20:51:40.512488
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # create fake job with failure status
    class FalseJob:
        def __init__(self):
            self.status = "failed"
            self.allow_failure = False
            self.name = "unit-test"

    # create fake job with failure status allowed
    class TrueJob:
        def __init__(self):
            self.status = "failed"
            self.allow_failure = True
            self.name = "unit-test"

    # create fake job with pending status
    class PendingJob:
        def __init__(self):
            self.status = "pending"
            self.name = "unit-test"

    # create fake job with success status
    class SuccessJob:
        def __init__(self):
            self.status = "success"
            self.name = "unit-test"



# Generated at 2022-06-21 20:51:45.002843
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    """
    Test TokenAuth.__eq__(self, other) method returns expected results
    """
    assert TokenAuth(token='1234') == TokenAuth(token='1234')
    assert not (TokenAuth(token='1233') == TokenAuth(token='1234'))
    assert TokenAuth(token='1234') == AuthBase()
    assert AuthBase() == TokenAuth(token='1234')



# Generated at 2022-06-21 20:54:38.288424
# Unit test for function post_changelog
def test_post_changelog():
    """
    Unit test for function post_changelog
    :return:
    """
    assert get_hvcs().post_release_changelog('test','test','test','test') is None



# Generated at 2022-06-21 20:54:39.772098
# Unit test for function get_domain
def test_get_domain():
    assert isinstance(get_domain(), str)

if __name__ == "__main__":
    test_get_domain()

# Generated at 2022-06-21 20:54:50.085593
# Unit test for method token of class Base
def test_Base_token():
    class TestBase(Base):
        @staticmethod
        def domain() -> str:
            return "gitlab.com"
        @staticmethod
        def api_url() -> str:
            return "https://api.gitlab.com"
        @staticmethod
        def token() -> Optional[str]:
            return "***"
        @staticmethod
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            pass
        @classmethod
        def post_release_changelog(
            cls, owner: str, repo: str, version: str, changelog: str
        ) -> bool:
            pass
        @classmethod
        def upload_dists(cls, owner: str, repo: str, version: str, path: str) -> bool:
            pass
    assert Test

# Generated at 2022-06-21 20:54:52.106829
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    t = TokenAuth("token")
    assert t == TokenAuth("token")
    assert t != TokenAuth("other token")
    assert t != None



# Generated at 2022-06-21 20:54:53.028719
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    assert TokenAuth("token")
    


# Generated at 2022-06-21 20:54:54.082144
# Unit test for method session of class Github
def test_Github_session():
    obj = Github
    res = obj.session()
    assert isinstance(res, (Session,))



# Generated at 2022-06-21 20:54:55.452018
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() == get_hvcs().domain()

# Generated at 2022-06-21 20:54:56.432977
# Unit test for method token of class Base
def test_Base_token():
    assert Base.token() is None, 'Base.token() is None'

# Generated at 2022-06-21 20:55:01.499136
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    try:
        Base.check_build_status(owner=None, repo=None, ref=None)
        print('Fail: Test should have failed but did not')
    except NotImplementedError:
        print('Pass: Test passed')

# Generated at 2022-06-21 20:55:08.790272
# Unit test for function get_hvcs
def test_get_hvcs():
    print("Test case 1: hvcs is set to github")
    hvcs = "github"
    config.set("hvcs", hvcs)
    assert get_hvcs() == Github
    print("PASSED")
    print("Test case 2: hvcs is set to gitlab")
    hvcs = "gitlab"
    config.set("hvcs", hvcs)
    assert get_hvcs() == Gitlab
    print("PASSED")

