

# Generated at 2022-06-21 20:48:00.068926
# Unit test for method token of class Github
def test_Github_token():
    """Test the method token of the class Github."""
    assert Github.token() == os.environ.get("GH_TOKEN")
    assert Github.token() is not None



# Generated at 2022-06-21 20:48:02.937640
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release("test", "test", "test", "test")

# Generated at 2022-06-21 20:48:03.866436
# Unit test for function get_domain
def test_get_domain():
    domain = get_domain()
    assert domain is not None
    assert type(domain) is str



# Generated at 2022-06-21 20:48:13.141132
# Unit test for method session of class Github
def test_Github_session():
    from .helpers import temp_config

    session = Github.session()
    assert isinstance(session, Session)

    token = "abcd1234"
    with temp_config({Github.domain(): {"token": token}}):
        session = Github.session()
        assert session.auth == TokenAuth(token)

        session = Github.session(raise_for_status=False)
        assert isinstance(session, Session)

    with temp_config({Github.domain(): {"token": token}}):
        session = Github.session()
        assert session.auth == TokenAuth(token)

        session = Github.session(retry=False)
        assert isinstance(session, Session)

    with temp_config({Github.domain(): {"token": token}}):
        session = Github.session()

# Generated at 2022-06-21 20:48:16.947474
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    """Method to check if Gitlab.api_url works as expected"""
    assert (
        "{domain}/api/v4".format(domain=Gitlab.domain()) == Gitlab.api_url()
    )


# Generated at 2022-06-21 20:48:23.713398
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    logging.info("unit test start")
    logging.info("testing Base.check_build_status")

    # test 1
    logging.info("unittest_Base_check_build_status test 1")
    assert Base.check_build_status(owner = "", repo = "", ref = "") == False
    logging.info("unittest_Base_check_build_status test 1 done")

# Generated at 2022-06-21 20:48:34.353650
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    import pytest
    from requests.auth import AuthBase

    class TestTokenAuth(AuthBase):
        def __init__(self, token="1234"):
            self.token = token

        def __eq__(self, other):
            return all([self.token == getattr(other, "tocken", None)])

        def __ne__(self, other):
            return not self == other

    auth = TestTokenAuth()
    test_cases = [
        (True, auth, TestTokenAuth("1234")),
        (True, auth, TestTokenAuth("1234")),
        (False, auth, AuthBase()),
        (False, auth, TestTokenAuth("")),
        (False, auth, TestTokenAuth("567")),
    ]


# Generated at 2022-06-21 20:48:35.709411
# Unit test for constructor of class Gitlab
def test_Gitlab():
    g = Gitlab()
    assert g is not None

# Generated at 2022-06-21 20:48:37.028824
# Unit test for method domain of class Base
def test_Base_domain():
    assert Base.domain() == NotImplementedError


# Generated at 2022-06-21 20:48:45.651559
# Unit test for method auth of class Github
def test_Github_auth():
    # Setup mock GH_TOKEN environment variable
    os.environ["GH_TOKEN"] = "test-token"
    # Setup mock Github.auth() return value
    github_auth_retval = TokenAuth("test-token")
    # Setup mock TokenAuth.__eq__ return value
    github_auth_retval_TokenAuth_call_return_value = True
    github_auth_retval.__eq__ = lambda self, other: github_auth_retval_TokenAuth_call_return_value
    # Setup mock requests.Session.request return value
    github_auth_session_request_retval = lambda: None
    github_auth_session_request_retval.status_code = 200

# Generated at 2022-06-21 20:49:40.601237
# Unit test for constructor of class Gitlab
def test_Gitlab():
    """Unit test for constructor of class Gitlab"""
    config.clear()
    gitlab_instance = Gitlab()
    assert (
        gitlab_instance
        == Gitlab(
            domain="gitlab.com",
            token=None,
        )
    )

    config.clear()
    config.set("hvcs_domain", "hvcs_domain")
    gitlab_instance = Gitlab()
    assert (
        gitlab_instance
        == Gitlab(
            domain="hvcs_domain",
            token=None,
        )
    )

    config.clear()
    os.environ["CI_SERVER_HOST"] = "ci_server_host"
    gitlab_instance = Gitlab()

# Generated at 2022-06-21 20:49:42.347794
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    assert isinstance(hvcs, Base)


# Generated at 2022-06-21 20:49:45.103371
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    # Input data of the unit test
    expected_result=None
    os.environ['GL_TOKEN']=None
    # Call method to test
    result=Gitlab.token()
    # Check result
    assert result==expected_result

# Generated at 2022-06-21 20:49:45.883735
# Unit test for function get_domain
def test_get_domain():
    assert get_domain() == "github.com"


# Generated at 2022-06-21 20:49:48.759913
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    logger.info("Executing module 'Github' unit test...")
    assert (
        Github.check_build_status(
            "owner", "repo", "ref"
        )
        == False
    ), "Module 'Github' unit test FAILED."
    logger.info("Module 'Github' unit test PASSED.")



# Generated at 2022-06-21 20:49:50.517365
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    Base.check_build_status("", "", "")



# Generated at 2022-06-21 20:50:00.599259
# Unit test for function get_hvcs
def test_get_hvcs():
    from .config import config as c
    from . import get_hvcs
    from .github import Github
    from .gitlab import Gitlab
    from .errors import ImproperConfigurationError

    c.set("hvcs", "Github")
    assert isinstance(get_hvcs(), Github)
    c.set("hvcs", "gitlab")
    assert isinstance(get_hvcs(), Gitlab)
    c.set("hvcs", "GitHub")
    assert isinstance(get_hvcs(), Github)
    c.set("hvcs", "GITLAB")
    assert isinstance(get_hvcs(), Gitlab)
    c.set("hvcs", "Bitbucket")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
   

# Generated at 2022-06-21 20:50:01.163449
# Unit test for function check_token
def test_check_token():
    assert check_token()



# Generated at 2022-06-21 20:50:03.771161
# Unit test for function get_token
def test_get_token():
    token = os.environ.get("GITHUB_TOKEN")
    assert get_token() == token


# Generated at 2022-06-21 20:50:06.906716
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    from requests import Request, Session
    auth = TokenAuth("token")
    r = Request("GET", "http://example.com")
    prepared_request = auth(r)
    assert prepared_request.headers["Authorization"] == "token token"



# Generated at 2022-06-21 20:50:59.999374
# Unit test for method token of class Gitlab
def test_Gitlab_token():
    assert Gitlab.token() == 'CiNwvudtHxWtVXybzgcR'


# Generated at 2022-06-21 20:51:12.760112
# Unit test for function get_token
def test_get_token():
    test_config = {'hvcs': 'github'}
    test_token = 'abcdef'
    # test happy case
    with mock.patch.dict(config, test_config, clear=True):
        with mock.patch.dict(os.environ, {'GH_TOKEN': test_token}, clear=True):
            assert get_token() == 'abcdef'
    # test non-happy case
    with mock.patch.dict(config, test_config, clear=True):
        with mock.patch.dict(os.environ, {'GH_TOKEN': None}, clear=True):
            assert get_token() == None

    # test no config case
    with mock.patch.dict(config, clear=True):
        with mock.patch.dict(os.environ, clear=True):
            assert get_

# Generated at 2022-06-21 20:51:14.560034
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False



# Generated at 2022-06-21 20:51:16.607994
# Unit test for function check_token
def test_check_token():
    original_env = os.environ
    os.environ = {"GITHUB_TOKEN": "42"}
    assert check_token() == True
    os.environ = {}
    assert check_token() == False
    os.environ = {"GL_TOKEN": "42"}
    assert check_token() == True
    os.environ = original_env


# Generated at 2022-06-21 20:51:17.283755
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"



# Generated at 2022-06-21 20:51:19.198633
# Unit test for method token of class Github
def test_Github_token():
    assert Github.token() == None

# Generated at 2022-06-21 20:51:20.272853
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
    del os.environ['CI_SERVER_HOST']


# Generated at 2022-06-21 20:51:21.301934
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    result = Gitlab.api_url()
    assert result == 'https://gitlab.com'

# Generated at 2022-06-21 20:51:22.536874
# Unit test for function check_token
def test_check_token():
    assert check_token() is not None


# Generated at 2022-06-21 20:51:27.316708
# Unit test for constructor of class Base
def test_Base():
    class Test(Base):
        pass

    try:
        Base()
        assert False, "Base should not be instantiated directly"
    except NotImplementedError:
        pass
    try:
        Test()
        assert False, "Base should not be instantiated directly"
    except TypeError:
        pass



# Generated at 2022-06-21 20:52:15.184358
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release("x", "y", "1.0.0", "dist/") == True

# Generated at 2022-06-21 20:52:21.361805
# Unit test for function check_token
def test_check_token():
    """Tests the function check_token()
    """
    from matador import constants

    assert len(constants.providers) == 2, "There are more or less providers than expected"
    for provider in constants.providers:
        assert check_token() == (
            True
        ), "There is a token in the env variables or config file"

# Generated at 2022-06-21 20:52:22.975052
# Unit test for constructor of class TokenAuth
def test_TokenAuth():
    token = "1A2B3C4D5E6F7G"
    assert TokenAuth(token)



# Generated at 2022-06-21 20:52:23.866119
# Unit test for method domain of class Base
def test_Base_domain():
    Base.domain()

# Generated at 2022-06-21 20:52:28.371315
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # domain = 'github.com'
    # repo = 'test_repo_name'
    # ref = 'test_sha1'
    # owner = 'test_owner'
    # response = Github.check_build_status(owner, repo, ref)
    pass



# Generated at 2022-06-21 20:52:30.338031
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("juan", "test", "test") == True



# Generated at 2022-06-21 20:52:36.591450
# Unit test for function get_domain
def test_get_domain():
    """

    :return:
    """
    # GitLab
    try:
        os.environ["CI_SERVER_HOST"] = "gitlab.com"
        assert get_hvcs().domain() == 'gitlab.com'
        os.environ["CI_SERVER_HOST"] = "gitlab.mycompany.com"
        assert get_hvcs().domain() == 'gitlab.mycompany.com'
    except KeyError:
        logger.debug(
            "CI_SERVER_HOST must be set in your environment variables."
            " CI_SERVER_HOST:  the GitLab instance domain"
        )
        pass

    # GitHub

# Generated at 2022-06-21 20:52:37.856024
# Unit test for method api_url of class Base
def test_Base_api_url():
    assert Base.api_url() == "https://api.github.com"

# Generated at 2022-06-21 20:52:38.827521
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()


# Generated at 2022-06-21 20:52:45.573135
# Unit test for constructor of class Base
def test_Base():
    from .hvcs import Base
    assert isinstance(Base, object)
    with pytest.raises(NotImplementedError):
        Base.domain()
    with pytest.raises(NotImplementedError):
        Base.api_url()
    with pytest.raises(NotImplementedError):
        Base.token()
    with pytest.raises(NotImplementedError):
        Base.check_build_status(owner="", repo="", ref="")
    with pytest.raises(NotImplementedError):
        Base.post_release_changelog(owner="", repo="", version="", changelog="")
    assert Base.upload_dists(owner="", repo="", version="", path="") is True



# Generated at 2022-06-21 20:53:35.102708
# Unit test for method domain of class Base
def test_Base_domain():
    """
    Ensure Base.domain raises implementation error
    """
    Base.domain()

# Generated at 2022-06-21 20:53:40.312956
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    from .settings import config  # noqa

    config.set("hvcs_domain", "github.com")

    Github.check_build_status("python-semantic-release", "python-semantic-release", "3b5a5e00f1bbd9830c8a1b04a9ec9ddcba680090")
    Github.check_build_status("python-semantic-release", "python-semantic-release", "thisdoesntexist")



# Generated at 2022-06-21 20:53:45.472023
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    a = TokenAuth("my_token")
    class Request:
        def __init__(self):
            self.headers = {}
    b = Request()
    a.__call__(b)
    assert(b.headers["Authorization"] == f"token {a.token}")



# Generated at 2022-06-21 20:53:47.522874
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    self = TokenAuth("abc123")
    other = TokenAuth("abc123")
    assert self == other


# Generated at 2022-06-21 20:53:57.870513
# Unit test for method session of class Github
def test_Github_session():
    """Unit test for method session of class Github
    """
    print("Start test for method session of class Github")

    github = Github()
    token = github.token()

    if token is None:
        raise ImproperConfigurationError("Environment variable GH_TOKEN not set")
    print("Environment variable GH_TOKEN set, a session will be returned")

    session = github.session()
    assert isinstance(session, Session)
    assert session.auth is not None
    assert session.auth.token == token

    print("Done test for method session of class Github")


Gitlab = gitlab.Gitlab

# Generated at 2022-06-21 20:53:58.888109
# Unit test for constructor of class Gitlab
def test_Gitlab():
    assert Gitlab is not None

# Generated at 2022-06-21 20:54:06.741720
# Unit test for function post_changelog
def test_post_changelog():
    """
    Test of the post_changelog function
    """
    assert get_hvcs().post_release_changelog("Jlachowski", "sphinx-gitlab-version-upstream", "1.0.0", "Test")
    assert get_hvcs().post_release_changelog("Jlachowski", "sphinx-gitlab-version-upstream", "1.0.0", "")
    assert not get_hvcs().post_release_changelog("Jlachowski", "sphinx-gitlab-version-upstream", "1.0.0", None)



# Generated at 2022-06-21 20:54:18.966128
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class testGitlab(Base):
        domain = "fakedomain"
        token = "faketoken"
        @staticmethod
        def api_url() -> str:
            """Gitlab api_url property

            :return: The Gitlab instance API url
            """
            return f"https://{Gitlab.domain()}"
        @staticmethod
        def token() -> Optional[str]:
            """Gitlab token property

            :return: The Gitlab token environment variable (GL_TOKEN) value
            """
            return testGitlab.token
        # UNIT TEST: check_build_status

# Generated at 2022-06-21 20:54:22.359229
# Unit test for function get_token
def test_get_token():
    token = get_token()
    assert token is not None


# Generated at 2022-06-21 20:54:24.232403
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release('hayj', 'test-repo', '0.1.3', 'dist')

# Generated at 2022-06-21 20:56:01.921598
# Unit test for function get_domain
def test_get_domain():
    """
    Unit test for function get_domain
    """
    # testing for github
    test_config = {'hvcs': 'github'}
    test_domain = 'github.com'
    with patch.dict(config, test_config):
        with patch.dict(os.environ, {"CI_SERVER_HOST": test_domain}):
            assert get_domain() == test_domain
    # testing for gitlab
    test_config = {'hvcs': 'gitlab'}
    test_domain = 'gitlab.com'
    with patch.dict(config, test_config):
        with patch.dict(os.environ, {"CI_SERVER_HOST": test_domain}):
            assert get_domain() == test_domain

# Generated at 2022-06-21 20:56:04.566947
# Unit test for method domain of class Base
def test_Base_domain(): # noqa: D102
    assert Base.domain() == "example.com" # noqa: D202


# Generated at 2022-06-21 20:56:05.761091
# Unit test for constructor of class Github
def test_Github():
    obj = Github()
    assert(obj)



# Generated at 2022-06-21 20:56:08.161776
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release('owner', 'repository', '0.0.0', '/path/to/dist')

# Generated at 2022-06-21 20:56:10.370264
# Unit test for function get_domain
def test_get_domain():
    """ Test for get_domain
    """
    assert re.match(
        r"\b([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}\b",
        get_domain(),
    ), "Not a valid domain"

# Generated at 2022-06-21 20:56:14.126995
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    try:
        os.environ["CI_SERVER_HOST"] = "gitlab.com"
        assert Gitlab.domain() == "gitlab.com"
    finally:
        os.environ["CI_SERVER_HOST"] = ""

# Generated at 2022-06-21 20:56:16.510142
# Unit test for function upload_to_release
def test_upload_to_release():
    assert upload_to_release("testOwner","testRepo","testVersion","testPath") == True



# Generated at 2022-06-21 20:56:18.180918
# Unit test for method token of class Base
def test_Base_token():
    with pytest.raises(NotImplementedError):
        Base().token()

# Generated at 2022-06-21 20:56:21.185149
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        assert True
