

# Generated at 2022-06-21 20:50:22.725830
# Unit test for function get_token
def test_get_token():
    """
    Unit test for function get_token
    """
    test_token = ""
    os.environ["GH_TOKEN"] = test_token
    assert Github.token() == test_token



# Generated at 2022-06-21 20:50:28.926373
# Unit test for method api_url of class Gitlab
def test_Gitlab_api_url():
    assert Gitlab.api_url() == "https://gitlab.com"
    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    assert Gitlab.api_url() == "https://gitlab.com"
    os.environ["CI_SERVER_HOST"] = "gitlab.com/gitlab-org/"
    assert Gitlab.api_url() == "https://gitlab.com/gitlab-org"


# Generated at 2022-06-21 20:50:30.751465
# Unit test for method __eq__ of class TokenAuth
def test_TokenAuth___eq__():
    assert TokenAuth("test_token") == TokenAuth("test_token")



# Generated at 2022-06-21 20:50:34.196809
# Unit test for method api_url of class Github
def test_Github_api_url():
    from ..settings import config

    config.load(file="#example-hvcs-config")


    api_url = config.hvcs.api_url()
    assert api_url == "https://api.github.com"



# Generated at 2022-06-21 20:50:37.097136
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    try:
        Base.check_build_status("any", "any", "any")
    except NotImplementedError:
        logger.debug("Method check_build_status of Base is not implemented")


# Generated at 2022-06-21 20:50:39.151427
# Unit test for method domain of class Base
def test_Base_domain():
    instance = Base()
    with instance.assertRaises(NotImplementedError):
        Base.domain(instance)



# Generated at 2022-06-21 20:50:40.482156
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("appsembler", "appsembler-build", "7829ce6be48ac6f666eda6cfe0888a99e6bff5a5")
 

# Generated at 2022-06-21 20:50:41.301218
# Unit test for method auth of class Github
def test_Github_auth():

    assert Github.auth() == None



# Generated at 2022-06-21 20:50:45.401827
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1: status
    assert Gitlab.check_build_status("hysds", "hysds-verdi-components", "0d4c4b7c6b4f6c0f611cbd6c0c8e9aa9c7d42582") == True
    # Test 2: status
    assert Gitlab.check_build_status("hysds", "hysds-verdi", "4cc8f8e0a4b32a0d2f2f3da3a9a62bccadf6eaf3") == True
    # Test 3: status

# Generated at 2022-06-21 20:50:48.260656
# Unit test for method check_build_status of class Base
def test_Base_check_build_status():
    import pytest
    with pytest.raises(NotImplementedError):
        Base.check_build_status("", "", "")