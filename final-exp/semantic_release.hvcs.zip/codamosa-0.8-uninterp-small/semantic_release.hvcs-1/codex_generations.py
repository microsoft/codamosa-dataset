

# Generated at 2022-06-26 01:16:33.835700
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        assert Gitlab.check_build_status("X","Y","Z")==False
        assert Gitlab.check_build_status("Z","Y","X")==False
        assert Gitlab.check_build_status("Z","X","Y")==False
    except:
        pass


# Generated at 2022-06-26 01:16:35.163060
# Unit test for method auth of class Github
def test_Github_auth():
    client = Github()
    assert client.auth() is None



# Generated at 2022-06-26 01:16:38.550413
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """unit test for check_build_status method of Gitlab class"""
    owner = "julesdelf"
    repo = "hvac"
    ref = "1234"
    Gitlab.check_build_status(owner, repo, ref)



# Generated at 2022-06-26 01:16:40.396266
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status('', '', '')


# Generated at 2022-06-26 01:16:45.708409
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.info("testing Gitlab.check_build_status")
    url_0 = "example.com"
    optional_0 = config.get("CI_SERVER_HOST")
    if optional_0 is not None:
        url_0 = optional_0
    gl = gitlab.Gitlab(url_0, private_token=Gitlab.token())
    gl.auth()
    gitlab_project = gl.projects.get("openpreserve/jhove2")
    gitlab_pipelines = gitlab_project.pipelines.list()
    for gitlab_pipeline in gitlab_pipelines:
        if gitlab_pipeline.sha == "d20ac9e6752e6b3c85b360e32c0d8da69dd0ef99":
            pipeline_0

# Generated at 2022-06-26 01:16:49.293027
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("davidfloegel", "gitlab-ci-demo", "07af83dfd0c7da0c265c3a7f8a0e9b3a3b32272e") == True


# Generated at 2022-06-26 01:16:50.233823
# Unit test for method domain of class Github
def test_Github_domain():
    test_case_0()


# Generated at 2022-06-26 01:16:51.754636
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        optional_0 = get_hvcs()
        if (optional_0 is None):
            return 0
        else:
            return 1
    except NotImplementedError:
        return 0


# Generated at 2022-06-26 01:17:00.755439
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "waltermoreira"
    repo = "hierarchical-versioning-scheme"
    ref = "00b3224ab80d1d7b9e56986ba5e5f5c5d5ffa01e"
    
    expected_0 = True
    expected_1 = False

    optional_1 = Gitlab.check_build_status(owner, repo, ref)

    assert(expected_0 == optional_1)
    
    owner = "waltermoreira"
    repo = "hierarchical-versioning-scheme"
    ref = "0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a"


# Generated at 2022-06-26 01:17:11.306217
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-26 01:18:42.957027
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if not Gitlab.check_build_status("space", "repository", "sha1"):
        logger.debug("test_Gitlab_check_build_status failed.")


# Generated at 2022-06-26 01:18:50.820634
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Input arguments for the method
    owner = "org"
    repo = "repo"
    ref = "ref"
    data = {"name": "pipeline", "status": "success", "allow_failure": False}

    # Expected output of the method
    expected_output = True

    # Response of the method
    response = Gitlab.check_build_status(owner, repo, ref)

    # Expected response of the method
    expected_response = True

    # Check the output
    assert response == expected_response
    # Check the response
    assert response == expected_output


# Generated at 2022-06-26 01:18:56.592219
# Unit test for function get_hvcs
def test_get_hvcs():
    optional_1 = test_case_0()
    # Verify the type of get_hvcs's returned value matches the expected one.
    optional_1.domain()



# Generated at 2022-06-26 01:18:57.557564
# Unit test for method auth of class Github
def test_Github_auth():
    optional_0 = Github.auth()


# Generated at 2022-06-26 01:19:00.624451
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # TODO: Please fill the unit test arguments
    print('This test is not implemented yet')


# Generated at 2022-06-26 01:19:05.844265
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Checking the return value of method check_build_status of class Gitlab
    hvcs = config.get('hvcs', 'github')
    if hvcs == 'gitlab':
        optional_0 = Gitlab().check_build_status(owner='', repo='', ref='')
        check_0 = isinstance(optional_0, bool)
        assert check_0
    else:
        assert True


# Generated at 2022-06-26 01:19:07.537962
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    name_1 = "TokenAuth"
    class_2 = globals()[name_1]
    class_2.__call__()



# Generated at 2022-06-26 01:19:15.351979
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner: str = "greenmind-consulting/sphinx-markdown-tables"
    repo: str = "sphinx-markdown-tables"
    ref: str = "34d08e17f78dc756457c0f9d9b7a6332cf72f6bd"
    optional_0 = Gitlab.check_build_status(owner, repo, ref)
    sys.stdout.write(f"sphinx-markdown-tables.Gitlab.check_build_status(owner, repo, ref) returned {optional_0}\n")


# Generated at 2022-06-26 01:19:18.694642
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_1 = Gitlab.check_build_status('tlaukkan', 'openmp-apps', '4a4f98e10e23eeb0d06c9a882a0e2a18f739ba8b')
    return optional_1


# Generated at 2022-06-26 01:19:21.395596
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        optional_0 = get_hvcs()
    except ImproperConfigurationError:
        pass


# Generated at 2022-06-26 01:20:52.357011
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github().domain() == "github.com"


# Generated at 2022-06-26 01:20:58.058535
# Unit test for function get_hvcs
def test_get_hvcs():
    """
    Make sure this import is fine by testing get_hvcs
    To run the unit test, type on the command line
    make test-unit-0
    """
    optional_0 = get_hvcs()


# Generated at 2022-06-26 01:21:00.723545
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status(str,str,str)
    assert optional_0 is not None


# Generated at 2022-06-26 01:21:03.584358
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    stat_0 = Github.check_build_status("owner_0", "repo_0", "ref_0")


# Generated at 2022-06-26 01:21:07.102832
# Unit test for method auth of class Github
def test_Github_auth():
    try:
        # Test existence of function
        assert callable(getattr(Github, 'auth'))
        return 0
    except Exception as ex:
        print(ex)
        return 1


# Generated at 2022-06-26 01:21:12.037360
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("quamolit", "quamolit", "fe14de36cfdcdfe7a6a8a15b7520f0a9dba56dcc")



# Generated at 2022-06-26 01:21:15.047522
# Unit test for function get_hvcs
def test_get_hvcs():
    print("Testing function get_hvcs")
    optional_0 = get_hvcs().domain()
    print("Test succeeded")
    return optional_0


# Generated at 2022-06-26 01:21:16.032592
# Unit test for method auth of class Github
def test_Github_auth():
    optional_0 = Github.auth()


# Generated at 2022-06-26 01:21:17.011923
# Unit test for method domain of class Github
def test_Github_domain():
    instance = Github()
    result = instance.domain()
    assert result == Github.default_domain



# Generated at 2022-06-26 01:21:20.508161
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        assert(get_hvcs().__class__.__name__ == 'Github')
        assert(get_hvcs().__class__.__name__ == 'Gitlab')
    except ImproperConfigurationError:
        print('"{0}" is not a valid option for hvcs.')
