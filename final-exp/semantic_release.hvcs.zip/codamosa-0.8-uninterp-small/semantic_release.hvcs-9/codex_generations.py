

# Generated at 2022-06-26 01:16:28.794286
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    test_case_0()



# Generated at 2022-06-26 01:16:34.387610
# Unit test for method domain of class Github
def test_Github_domain():
    hvcs_domain = config.get("hvcs_domain")
    DEFAULT_DOMAIN = "github.com"
    optional_0 = hvcs_domain if hvcs_domain else DEFAULT_DOMAIN
    assert optional_0 == Github.domain()


# Generated at 2022-06-26 01:16:45.052355
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # test commit with all jobs success
    s = Gitlab.check_build_status("hive-vm", "hive-operator", "e3dbd2e1f0b86a3b8a5e5e9643ee8530b5ddf841")
    assert s
    # test commit with one job failed
    s = Gitlab.check_build_status("hive-vm", "hive-operator", "6a4a6b4e6e13c490d9f0a0e6e3d3efd662c89f02")
    assert not s


# Generated at 2022-06-26 01:16:46.948545
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:16:49.092819
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    optional_0 = Github.check_build_status(owner="owner-0", repo="repo-0", ref="ref-0")


# Generated at 2022-06-26 01:16:51.652611
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("gitlab-org", "gitlab-ce", "master")


# Generated at 2022-06-26 01:16:56.372103
# Unit test for method auth of class Github
def test_Github_auth():
	# Test case 0:
	global optional_0
	optional_0 = None
	assert(Github.auth() == optional_0)
	# Test case 1:
	global optional_0
	optional_0 = "a"
	assert(Github.auth() == optional_0)


# Generated at 2022-06-26 01:16:59.314483
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    obj = Gitlab()
    owner_0 = "root"
    repo_0 = "dummy"
    ref_0 = "ref"
    ret_0 = obj.check_build_status(owner_0, repo_0, ref_0)
    print(ret_0)


# Generated at 2022-06-26 01:17:02.125306
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        optional_0 = get_hvcs()
    except:
        optional_0 = ("")
    assert optional_0 == ("")


# Generated at 2022-06-26 01:17:09.985818
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    with mock.patch("hvcs.version.Hvcs._get_project_repo") as ProjectMock:
        ProjectMock.return_value = mock.MagicMock(
            commit="d8bb6eaec2a4b67ebc4d4f4fd7bb4e6f02b7e9ee"
        )
        matcher = re.compile(r"[0-9a-f]{40}").search
        assert matcher(Gitlab.check_build_status(owner="vfxprod", repo="autokratom"))



# Generated at 2022-06-26 01:18:19.547441
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    print("Test: test_Gitlab_method_domain")
    result = Gitlab.domain()
    print("The returned result: ")
    print(result)
    print("")


# Generated at 2022-06-26 01:18:22.526382
# Unit test for method api_url of class Github
def test_Github_api_url():
    # Verify the domain and api_url of Github
    assert Github.domain() == "github.com"
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-26 01:18:25.147970
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    print("test case 1")
    optional_0 = Github.check_build_status("test_owner","test_repo","test_ref")
    return optional_0


# Generated at 2022-06-26 01:18:34.960599
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    repo_owner = "Birds-of-Aether"
    repo_name = "Bird-of-Aether-Website"
    ref = "8fb5ccc1a0e7a52e9e3b78a2bdbd76bfd0e0217a"
    print(Github.check_build_status(repo_owner, repo_name, ref))



# Generated at 2022-06-26 01:18:36.180415
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    obj = Gitlab()
    test_case_0()


# Generated at 2022-06-26 01:18:39.186549
# Unit test for method auth of class Github
def test_Github_auth():
    # Setup
    __args = (None, )
    # Exercise
    result = Github.auth(*__args)
    # Verify
    assert result is None
    # Cleanup - none necessary as no resources created


# Generated at 2022-06-26 01:18:40.654539
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status("the_str_0", "the_str_1", "the_str_2")


# Generated at 2022-06-26 01:18:42.324118
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status()


# Generated at 2022-06-26 01:18:44.846316
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner, repo, ref = "example", "example", "example"
    print(Gitlab.check_build_status(owner, repo, ref))


# Generated at 2022-06-26 01:18:55.589737
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("windup", "windup-distribution", "v4.6.0.Final")
    assert Gitlab.check_build_status("windup", "windup-distribution", "v4.6.1.Final")
    assert Gitlab.check_build_status("jboss-windup", "windup-distribution", "v4.6.1.Final")
    assert Gitlab.check_build_status("jboss-windup", "windup-distribution", "v4.6.0.Final")


# Generated at 2022-06-26 01:20:23.455041
# Unit test for method api_url of class Github
def test_Github_api_url():
    optional_0 = Github.api_url()


# Generated at 2022-06-26 01:20:29.272831
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError) as e_info:
        get_hvcs()
    assert str(e_info.value) == '"None" is not a valid option for hvcs.'


# Generated at 2022-06-26 01:20:37.701432
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    print("Testing check_build_status")
    owner = "cdi-wg"
    repo = "test-pip"
    ref = "c1d8faf202cddbdbaa33a0c7d8a5975c89f91ce2"
    print("Testing for " + owner + "/" + repo)
    if Gitlab.check_build_status(owner, repo, ref):
        print("Gitlab.check_build_status succeeded")


# Generated at 2022-06-26 01:20:39.254495
# Unit test for method auth of class Github
def test_Github_auth():
    optional_0 = Github.auth()


# Generated at 2022-06-26 01:20:41.620424
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    expected_result = os.environ.get("CI_SERVER_HOST")
    assert Gitlab.domain() == expected_result


# Generated at 2022-06-26 01:20:43.174482
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:20:46.650032
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Optional inputs
    optional_0 = "tests/github/owner"
    optional_1 = "test-repo"
    optional_2 = "test-ref"
    Gitlab.check_build_status(optional_0,optional_1,optional_2)


# Generated at 2022-06-26 01:20:50.339050
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "zaytsev"
    repo = "kicad-lib-check"
    ref = "1d5c6bebdd6b5f6e5ce8d4ba6dc5ed2fc4ce4c3d"
    result = Gitlab.check_build_status(owner, repo, ref)

    if result != True:
        raise ValueError ("invalid result")
    return True


# Generated at 2022-06-26 01:20:53.319011
# Unit test for method auth of class Github
def test_Github_auth():
    subject = Github()
    if subject.auth() is not None:
        assert type(subject.auth()) == TokenAuth
    else:
        assert subject.auth() is None


# Generated at 2022-06-26 01:20:55.111553
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status()


# Generated at 2022-06-26 01:22:01.755481
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status("vhusublime", "vhdepot-py", "64c6d8982daa2a1ddea2f3837450f853a92dbcf6")


# Generated at 2022-06-26 01:22:04.431812
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # create an instance of class Github
    obj = Github()
    # check if the response is success
    assert (obj.check_build_status("owner", "repo", "ref"))
    return


# Generated at 2022-06-26 01:22:10.067736
# Unit test for method api_url of class Github
def test_Github_api_url():
    if 'GITHUB_API_URL' in os.environ:
        del os.environ['GITHUB_API_URL']
    assert Github.api_url() == 'https://api.github.com'
    os.environ['GITHUB_API_URL'] = 'https://my.api.github.com'
    assert Github.api_url() == 'https://my.api.github.com'


# Generated at 2022-06-26 01:22:11.839083
# Unit test for method api_url of class Github
def test_Github_api_url():
    optional_0 = Github.api_url()


# Generated at 2022-06-26 01:22:18.568174
# Unit test for method auth of class Github
def test_Github_auth():
    hvcs = Github()
    optional_0 = hvcs.auth()


# Generated at 2022-06-26 01:22:21.006315
# Unit test for method domain of class Github
def test_Github_domain():
    github = Github
    expected_0_0 = 'github.com'
    actual_0_0 = github.domain()
    assert actual_0_0 == expected_0_0


# Generated at 2022-06-26 01:22:22.662062
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status('ns1', 'repo1', 'sha1') == False


# Generated at 2022-06-26 01:22:25.793938
# Unit test for method domain of class Github
def test_Github_domain():
    opt_0 = Github.domain()
    assert opt_0 == 'github.com'

    optional_1 = get_domain()
    assert optional_1 == 'github.com'



# Generated at 2022-06-26 01:22:27.998834
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-26 01:22:29.221539
# Unit test for function get_hvcs
def test_get_hvcs():
    optional_0 = get_hvcs()

# Generated at 2022-06-26 01:23:42.456353
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    if Gitlab.domain() != 'gitlab.com':
        raise AssertionError()


# Generated at 2022-06-26 01:23:44.182267
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "example"
    repo = "example"
    ref = "4cc4ff42f76fe34c0ff0"
    ret_value = Gitlab.check_build_status(owner, repo, ref)


# Generated at 2022-06-26 01:23:45.820104
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():

    assert (Github.check_build_status("owner", "repo", "ref") == False)


# Generated at 2022-06-26 01:23:46.676751
# Unit test for method auth of class Github
def test_Github_auth():
    Github.auth()


# Generated at 2022-06-26 01:23:51.150430
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Testing
    def _Gitlab_check_build_status_impl(owner, repo, ref):
        res_0 = Gitlab.check_build_status(owner, repo, ref)
        return (True if res_0 else False)
    # Testing
    def _Gitlab_check_build_status_client_call(owner, repo, ref):
        res_1 = Gitlab.check_build_status(owner, repo, ref)
        return (True if res_1 else False)
    # Unit test
    owner = "owner"
    repo = "repo"
    ref = "ref"
    ret_2 = _Gitlab_check_build_status_impl(owner, repo, ref)
    ret_3 = _Gitlab_check_build_status_client_call(owner, repo, ref)


# Generated at 2022-06-26 01:23:53.328833
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a success status
    assert Gitlab.check_build_status("project_owner", "project_name", "123456789")

    # Test with an error status
    assert not Gitlab.check_build_status("error_project_owner", "error_project_name", "123456789")

if __name__ == "__main__":
    print(get_domain())

# Generated at 2022-06-26 01:23:54.861840
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = "0"
    optional_1 = "1"
    optional_2 = "2"

    assert Gitlab.check_build_status(optional_0, optional_1, optional_2)


# Generated at 2022-06-26 01:23:58.524500
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "owner"
    repo = "repo"
    ref = "ref"
    mock_check_build_status = MagicMock(return_value=True)
    with patch.object(type(Gitlab), 'check_build_status',
        new=mock_check_build_status):
        Gitlab.check_build_status(owner, repo, ref)
        assert mock_check_build_status.called
        assert mock_check_build_status.call_args[0][0] == owner
        assert mock_check_build_status.call_args[0][1] == repo
        assert mock_check_build_status.call_args[0][2] == ref


# Generated at 2022-06-26 01:24:02.713810
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))
    optional_1 = os.environ.get("GL_TOKEN")
    optional_2 = get_domain()
    optional_3 = os.environ.get("CI_SERVER_HOST")
    optional_4 = config.get("hvcs_domain")
    optional_5 = os.environ.get("GL_TOKEN")
    optional_6 = get_domain()
    optional_7 = os.environ.get("CI_SERVER_HOST")
    optional_8 = config.get("hvcs_domain")
    optional_9 = os.environ.get("GL_TOKEN")
    optional_10 = get_domain()

# Generated at 2022-06-26 01:24:03.726392
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("gitlab-org", "gitlab-foss", "1b12f15a") == True


# Generated at 2022-06-26 01:25:18.851225
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    obj = Gitlab()
    response = obj.check_build_status(owner, repo, ref)
    logger.debug(f'test_Gitlab_check_build_status: response: {response}')
