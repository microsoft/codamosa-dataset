

# Generated at 2022-06-26 01:20:03.336980
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status('test','test','test'), "Test for method check_build_status of class Gitlab is failing"


# Generated at 2022-06-26 01:20:11.144372
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test check_build_status

    :return: None
    """

    # Ensure check fails if no token
    token = os.environ.get("GL_TOKEN")
    os.environ.pop("GL_TOKEN", None)
    assert not Gitlab.check_build_status("", "", "")
    os.environ["GL_TOKEN"] = token

    # Test success
    assert Gitlab.check_build_status("GNU-Toolchain-CI", "repo-utils", "4ba4f2a4c4")

    # TODO test failure with exception handling



# Generated at 2022-06-26 01:20:27.423193
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Case 1:
    # In this case, we call the method check_build_status of class Gitlab
    # with an owner, a repository and a ref which in fact passed the CI build,
    # we expect the method to return True.
    optional_0 = Gitlab.check_build_status("Datamart", "dm-test", "6e839f7775a7f397a009aeb9f948a6e127c7cb17")
    assert optional_0
    # Case 2:
    # In this case, we call the method check_build_status of class Gitlab
    # with an owner, a repository and a ref which in fact didn't pass the CI build,
    # we expect the method to return False.

# Generated at 2022-06-26 01:20:33.298628
# Unit test for method domain of class Github
def test_Github_domain():
    """
    Method domain of class Github
    """

    # Check the isinstance of the class Github
    if not isinstance(Github(), Github):
        raise AssertionError("The class Github is not an instance of Github")

    # Make sure the domain of class Github is a string
    if not isinstance(optional_0, str):
        raise AssertionError("The optional_0 is not a str")

    # Make sure the domain of class Github is correct
    if optional_0 != 'github.com':
        raise AssertionError("The optional_0 is not equal to github.com")

test_case_0()

test_Github_domain()


# Generated at 2022-06-26 01:20:34.655981
# Unit test for method domain of class Github
def test_Github_domain():
    optional_0 = Github.domain()


# Generated at 2022-06-26 01:20:38.341298
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    try:
        Gitlab.domain()
    except:
        assert False


# Generated at 2022-06-26 01:20:40.490932
# Unit test for method domain of class Github
def test_Github_domain():
    optional_0 = Github.domain()
    assert optional_0 == 'github.com'


# Generated at 2022-06-26 01:20:49.156187
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    url = "https://gitlab.com"
    private_token = "abc123"
    gl = gitlab.Gitlab(url, private_token=private_token)
    gl.auth()
    jobs = gl.projects.get("nbeguier/testproj").commits.get("27a404c60f").statuses.list()
    for job in jobs:
        if job["status"] not in ["success", "skipped"]:
            if job["status"] == "pending":
                logger.debug(f"check_build_status: job {job['name']} is still in pending status")
                return False
            elif job["status"] == "failed" and not job["allow_failure"]:
                logger.debug(f"check_build_status: job {job['name']} failed")
                return

# Generated at 2022-06-26 01:21:02.813744
# Unit test for function get_hvcs
def test_get_hvcs():
    assert isinstance(get_hvcs(), Base)

from typing import (Any,
                    Iterable)

from abc import abstractmethod
from json import (loads)

from requests import (get,
                      post)
from requests.exceptions import (HTTPError)
from requests.models import (Response)

from .base import Base
from .logger import get_logger

from .build_requests_session import (build_requests_session)
from .config import (config)
from .decorators import (LoggedFunction)
from .exceptions import (ImproperConfigurationError)

from .retry import (Retry)

from .utils import (flatten)

logger = get_logger(__name__)



# Generated at 2022-06-26 01:21:06.038542
# Unit test for method auth of class Github
def test_Github_auth():
    # Test cases
    test_case_0()

    # Test case 1
    token = Github.token()
    if not token:
        TokenAuth(token)
        pass
    else:
        pass


# Generated at 2022-06-26 01:23:38.039931
# Unit test for method auth of class Github
def test_Github_auth():
    optional_0 = Github.auth()


# Generated at 2022-06-26 01:23:42.590251
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # We expect the build to fail
    class Gitlab:
        @staticmethod
        def domain() -> str:
            """Gitlab domain property

            :return: The Gitlab instance domain
            """
            domain = config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))
            return domain if domain else "gitlab.com"

        @staticmethod
        def api_url() -> str:
            """Gitlab api_url property

            :return: The Gitlab instance API url
            """
            return f"https://{Gitlab.domain()}"

        @staticmethod
        def token() -> Optional[str]:
            """Gitlab token property

            :return: The Gitlab token environment variable (GL_TOKEN) value
            """

# Generated at 2022-06-26 01:23:43.379064
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Tested by a CI Gitlab job :)
    return True


# Generated at 2022-06-26 01:23:43.986120
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github

# Generated at 2022-06-26 01:23:45.360319
# Unit test for method auth of class Github
def test_Github_auth():
    instance = Github()
    instance.auth()


# Generated at 2022-06-26 01:23:49.831273
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Tests if the Correct Exception is raised given no token
    os.environ["GL_TOKEN"] = ""
    with raises(gitlab.exceptions.GitlabAuthenticationError):
        Gitlab.check_build_status("test","test","test")

    # Tests the Correct Exception is raised given invalid token
    os.environ["GL_TOKEN"] = "abcd"
    with raises(gitlab.exceptions.GitlabAuthenticationError):
        Gitlab.check_build_status("test","test","test")

    # Tests the Correct Exception is raised given invalid owner
    os.environ["GL_TOKEN"] = "abcd"
    with raises(gitlab.exceptions.GitlabAuthenticationError):
        Gitlab.check_build_status("test","test","test")

    # Tests the Correct Exception is raised given

# Generated at 2022-06-26 01:23:50.759621
# Unit test for function get_hvcs
def test_get_hvcs():
    ret_1 = get_hvcs()
    assert_equals(ret_1, Github)

# Generated at 2022-06-26 01:23:52.171801
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    test_instance = Gitlab()

    optional_0 = Gitlab.check_build_status(owner="owner",
                                           repo="repo",
                                           ref="ref")


# Generated at 2022-06-26 01:23:53.128057
# Unit test for method auth of class Github
def test_Github_auth():
    Github.auth()



# Generated at 2022-06-26 01:23:54.022141
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    # Test without fail
    domain = Gitlab.domain()
    assert domain == "gitlab.com"
