

# Generated at 2022-06-26 01:17:14.987457
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    assert True, (hvcs)


# Generated at 2022-06-26 01:17:24.937762
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    bool_0 = True
    bool_1 = False
    str_0 = test_lib.lib_rand_str()
    str_1 = test_lib.lib_rand_str()
    str_2 = test_lib.lib_rand_str()
    str_3 = test_lib.lib_rand_str()
    str_4 = test_lib.lib_rand_str()
    str_5 = test_lib.lib_rand_str()
    str_6 = test_lib.lib_rand_str()
    str_7 = test_lib.lib_rand_str()
    str_8 = test_lib.lib_rand_str()
    str_9 = test_lib.lib_rand_str()
    str_10 = test_lib.lib_rand_str()

# Generated at 2022-06-26 01:17:26.298999
# Unit test for function get_hvcs
def test_get_hvcs():
    pass

# Generated at 2022-06-26 01:17:36.313597
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    bool_0 = True
    str_0 = "v1.1.1"
    str_1 = "kf-backend"
    str_2 = "kf-backend"
    ret_0 = Gitlab.check_build_status(str_0, str_1, str_2)
    if (ret_0 is not bool_0):
        print("FAIL", "expected value:", bool_0, "got:", ret_0)
        test_failed()


# Generated at 2022-06-26 01:17:42.584402
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    bool_0 = True
    token_auth_0 = TokenAuth(bool_0)
    assert token_auth_0.__class__ == TokenAuth
    assert token_auth_0.token == True
    assert token_auth_0.__call__ == object.__call__
    # self.__call__(r, **kwargs)
    # STUB_TokenAuth___call__
    raise NotImplementedError()


# Generated at 2022-06-26 01:17:45.093167
# Unit test for method domain of class Github
def test_Github_domain():
    github_0 = Github()
    github_0.domain()

    github_1 = Github()
    github_1.domain()


# Generated at 2022-06-26 01:17:49.164488
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    bool_0 = True
    token_auth_0 = TokenAuth(bool_0)
    session_0 = build_requests_session()
    session_0.auth = token_auth_0
    bool_1 = TokenAuth(bool_0) == token_auth_0
    assert bool_1



# Generated at 2022-06-26 01:17:56.142469
# Unit test for function get_hvcs
def test_get_hvcs():
    # Setup
    hvcs = "GitHub"
    # Exercise
    result = globals()[hvcs.capitalize()]
    # Verify
    assert isinstance(result, Base)
    assert result.domain() == "github.com"
    assert result.api_url() == "https://api.github.com"
    assert result.token() == os.getenv("GH_TOKEN")
    assert result.auth() == TokenAuth(os.getenv("GH_TOKEN"))
    # Teardown

if __name__ == "__main__":
    test_case_0()
    test_get_hvcs()

# Generated at 2022-06-26 01:18:01.715487
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        token = Github.token()
        print("Github token: %s" %token)
        auth = Github.auth()
        print("Github auth: %s" %auth)
    except Exception as e:
        print("Error: %s" %e)
    try:
        domain = Github.domain()
        print("Github domain: %s" %domain)
        url = Github.api_url()
        print("Github url: %s" %url)
    except Exception as e:
        print("Error: %s" %e)
    try:
        session = Github.session()
        print("Github session: %s" %session)
    except Exception as e:
        print("Error: %s" %e)

# Generated at 2022-06-26 01:18:04.475746
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    try:
        token_auth_1 = TokenAuth(False)
        assert False
    except:
        assert True


# Generated at 2022-06-26 01:20:09.103346
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    bool_0 = True
    bool_1 = False
    class_0 = Gitlab()
    bool_2 = class_0.check_build_status(bool_0, bool_0, bool_1)


# Generated at 2022-06-26 01:20:13.974096
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    config.reset()
    config.register_map({"hvcs_domain": "gitlab.com", "hvcs_type": "gitlab"})
    config.register_map({"hostname": "gitlab.com"})
    owner = "owner"
    repo = "repo"
    ref = "ref"
    assert Gitlab.check_build_status(owner, repo, ref) == False


# Generated at 2022-06-26 01:20:21.487669
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner_0 = "git"
    repo_0 = "git"
    ref_0 = "8c4aad9e1d0b1f3fa54a18d3eb98470a7abf1cfe"
    assert Gitlab.check_build_status(owner_0, repo_0, ref_0) == True


# Generated at 2022-06-26 01:20:24.492786
# Unit test for method domain of class Github
def test_Github_domain():
    """Unit test for method domain of class Github"""
    tester = Github()
    logger.debug("Unit test of method domain of class Github")
    tester.domain()


# Generated at 2022-06-26 01:20:30.881581
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    bool_0 = True
    token_auth_0 = TokenAuth(bool_0)
    r_0 = Mock()
    result_0 = token_auth_0.__call__(r_0)
    # test that the returned result is not None
    assert result_0 is not None
    # test that the returned result is true
    assert result_0


# Generated at 2022-06-26 01:20:34.225870
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token_auth_0 = TokenAuth(None)
    r_0 = 255
    r_0 = token_auth_0.__call__(r_0)


# Generated at 2022-06-26 01:20:37.882313
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token_auth_0 = TokenAuth(False)
    token_auth_0.__call__(False)


# Generated at 2022-06-26 01:20:43.247948
# Unit test for function get_hvcs
def test_get_hvcs():
    print("get_hvcs")
    get_hvcs()
    print()

if __name__ == "__main__":
    # Test Github
    test_case_0()

    # Test Gitlab
    token_auth_0 = TokenAuth(True)

    # Test get_hvcs
    test_get_hvcs()

# Generated at 2022-06-26 01:20:50.555102
# Unit test for function get_hvcs
def test_get_hvcs():
    #
    # These tests will pass if the variables are defined.
    #
    hvcs = get_hvcs()
    assert hvcs.domain()
    assert hvcs.api_url()
    assert hvcs.token()
    assert hvcs.auth()
    assert hvcs.session()
    assert hvcs.check_build_status("owner","repo","ref")
    assert hvcs.create_release("owner","repo","tag","changelog")
    assert hvcs.get_release("owner","repo","tag")
    assert hvcs.edit_release("owner","repo","id","changelog")
    assert hvcs.post_release_changelog("owner","repo","version","changelog")

# Generated at 2022-06-26 01:21:02.892105
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    GITLAB_OWNER = os.environ.get('GITLAB_OWNER', 'test')
    GITLAB_REPO = os.environ.get('GITLAB_REPO', 'test')
    GITLAB_BRANCH = os.environ.get('GITLAB_BRANCH', 'test')
    GITLAB_REF = os.environ.get('GITLAB_REF', 'test')
    Gitlab.check_build_status(GITLAB_OWNER, GITLAB_REPO, GITLAB_REF)

if __name__ == "__main__":
    test_Gitlab_check_build_status()