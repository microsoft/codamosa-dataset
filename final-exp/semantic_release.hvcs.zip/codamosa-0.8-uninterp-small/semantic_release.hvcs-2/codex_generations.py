

# Generated at 2022-06-26 01:17:26.979101
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = ""
    token_auth = TokenAuth(token)
    r = ""
    result = token_auth(r)


# Generated at 2022-06-26 01:17:27.939670
# Unit test for method api_url of class Github
def test_Github_api_url():
    optional_0 = Github.api_url()


# Generated at 2022-06-26 01:17:29.224238
# Unit test for function get_hvcs
def test_get_hvcs():
    assert type(get_hvcs()) is Base


# Generated at 2022-06-26 01:17:43.177028
# Unit test for function get_hvcs
def test_get_hvcs():

    print("starting tests")

    # Test case 1
    class Dummy(Base):
        """Dummy helper class"""
        pass

    config.set("hvcs", "dummy")
    Dummy = get_hvcs()
    assert Dummy == Dummy
    print("test 1 passed")

    ###
    # Test case 2
    ###
    config.set("hvcs", "dummy")
    try:
        get_hvcs()
        assert False, "Should have thrown an exception"
    except ImproperConfigurationError:
        pass
    print("test 2 passed")

    config.set("hvcs", "github")
    Github = get_hvcs()
    assert Github == Github
    print("test 3 passed")

# Generated at 2022-06-26 01:17:46.793543
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.info("Test for check_build_status")
    logger.info("Test case 1: check_build_status")
    assert Gitlab.check_build_status("namespace","testrepo","testref") == True


# Generated at 2022-06-26 01:17:49.209303
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    try:
        Github.check_build_status(0,0,0)
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 01:17:50.757517
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Everything is fine
    optional_0 = Gitlab.check_build_status("owner", "repo", "ref")
    if optional_0:
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-26 01:17:52.137024
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()

# Testing method of class Gitlab

# Generated at 2022-06-26 01:17:53.461035
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:17:56.141147
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    exists_0 = None
    try:
        optional_0 = check_build_status('str_0', 'str_1', 'str_2')
        exists_0 = True
    except:
        pass
    assert exists_0 == True


# Generated at 2022-06-26 01:20:11.352713
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status("hiveeyes", "hiveeyes-influxdb-adapter", "9d0827b309c4fa8e65cacbf414f0aa0fda81b6f8")
    return optional_0


# Generated at 2022-06-26 01:20:27.480705
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if 'CI_SERVER_HOST' not in os.environ:
        # unit test is not being run on gitlab-ci, so just return True
        return True

    # get the project id and commit hash of the commit under test
    ci_project_id = os.environ.get('CI_PROJECT_ID')
    ci_commit_sha = os.environ.get('CI_COMMIT_SHA')
    assert ci_project_id is not None and ci_commit_sha is not None

    # determine repo name as well as owner namespace
    ci_repository = os.environ.get('CI_REPOSITORY')
    assert ci_repository is not None

    repo_and_namespace = ci_repository.split('/')

# Generated at 2022-06-26 01:20:28.449956
# Unit test for method auth of class Github
def test_Github_auth():
    test_case_0()



# Generated at 2022-06-26 01:20:41.408922
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class DummyApi:
        class DummyProject:
            class DummyCommit:
                class DummyStatuses:
                    def list(self):
                        return [
                            {
                                "name": "job1",
                                "status": "success",
                                "allow_failure": False,
                            },
                            {
                                "name": "job2",
                                "status": "success",
                                "allow_failure": True,
                            },
                        ]

                def __init__(self, ref: str):
                    self.statuses = DummyApi.DummyProject.DummyCommit.DummyStatuses()

            def __init__(self, ref: str):
                self.ref = ref
                self.commits = DummyApi.DummyProject.DummyCommit

# Generated at 2022-06-26 01:20:47.626733
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Optional parameter 'owner' for function GitHub.check_build_status
    optional_0 = None
    # Optional parameter 'repo' for function GitHub.check_build_status
    optional_1 = None
    # Optional parameter 'ref' for function GitHub.check_build_status
    optional_2 = None
    try:
        Gitlab.check_build_status(optional_0, optional_1, optional_2)
    except Exception as e:
        # GithubException
        assert isinstance(e, gitlab.exceptions.GitlabGetError)



# Generated at 2022-06-26 01:20:51.426554
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # No exception raised for invalid owner
    Gitlab.check_build_status("owner", "repo", "ref", "token")


# Generated at 2022-06-26 01:20:53.533915
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status("owner","repo","ref")


# Generated at 2022-06-26 01:21:07.500399
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        logger.info("Test case 0")
        test_case_0()
    except Exception as ex:
        logger.error("Test case 0 failed: " + str(ex))
    try:
        logger.info("Test case 1")
        # optional_1 test case
        optional_1 = get_token()
        Gitlab.check_build_status(optional_1,optional_1,optional_1)
    except Exception as ex:
        logger.error("Test case 1 failed: " + str(ex))

# Generated at 2022-06-26 01:21:11.357439
# Unit test for method api_url of class Github
def test_Github_api_url():
    instance = Github()
    optional_0 = Github.domain(instance)
    optional_1 = Github.api_url(instance)


# Generated at 2022-06-26 01:21:13.904493
# Unit test for function get_hvcs
def test_get_hvcs():
    # Unit test without error (1)
    optional_0 = get_hvcs()


# Generated at 2022-06-26 01:23:28.391939
# Unit test for method domain of class Github
def test_Github_domain():
    # Input parameters for unit test
    Github_domain_owner = "github_domain_owner"
    Github_domain_repo = "github_domain_repo"
    Github_domain_ref = "github_domain_ref"
    Github_domain_version = "github_domain_version"
    Github_domain_path = "github_domain_path"
    Github_domain_changelog = "github_domain_changelog"
#     Github_domain_file_path = "github_domain_file_path"
#     Github_domain_file_path_file_path = "github_domain_file_path_file_path"
#     Github_domain_file_path_file = "github_domain_file_path_file"
#     Github_domain_file_path_label = "github_domain_file_path_label"

# Generated at 2022-06-26 01:23:29.147250
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == 'gitlab.com'


# Generated at 2022-06-26 01:23:29.913425
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:23:32.460863
# Unit test for method domain of class Github
def test_Github_domain():
    case_0 = Github.domain() == 'github.com'
    case_1 = config.get("hvcs_domain") == "gitlab.com"


# Generated at 2022-06-26 01:23:33.410153
# Unit test for function get_hvcs
def test_get_hvcs():
    if get_hvcs() != Github:
        raise AssertionError
    return True


# Generated at 2022-06-26 01:23:34.888490
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"


# Generated at 2022-06-26 01:23:36.031177
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        result = get_hvcs()
        assert result != None
    except ImproperConfigurationError:
        assert False


# Generated at 2022-06-26 01:23:36.843066
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:23:37.877917
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("user1", "repo1", "hash1")



# Generated at 2022-06-26 01:23:40.231325
# Unit test for method api_url of class Github
def test_Github_api_url():
    unit_test0 = Github.api_url()
    optional_0 = api_url()
