

# Generated at 2022-06-26 01:16:23.150005
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Test case 0
    github_0 = Github()
    str_0 = github_0.check_build_status(owner="tensorflow/tensorboard", repo="tensorboard", ref="tensorflow/tensorboard#tensorboard")
    print(str_0)
    # Test case 1
    github_0 = Github()
    str_0 = github_0.check_build_status(owner="tensorflow/tensorboard", repo="tensorboard", ref="tensorflow/tensorboard#tensorboard")
    print(str_0)
    # Test case 2
    github_0 = Github()
    str_0 = github_0.check_build_status(owner="tensorflow/tensorboard", repo="tensorboard", ref="tensorflow/tensorboard#tensorboard")

# Generated at 2022-06-26 01:16:26.361390
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() is Github
    return


# Generated at 2022-06-26 01:16:29.574448
# Unit test for method auth of class Github
def test_Github_auth():
    github_0 = Github()
    token_auth_0 = github_0.auth()


# Generated at 2022-06-26 01:16:32.857933
# Unit test for function get_hvcs
def test_get_hvcs():

    gitlab_0 = Gitlab()
    str_0 = gitlab_0.api_url()
    assert str_0 == "https://gitlab.com"

    github_0 = Github()
    str_0 = github_0.api_url()
    assert str_0 == "https://api.github.com"


# Generated at 2022-06-26 01:16:35.387044
# Unit test for method api_url of class Github
def test_Github_api_url():
    github_1 = Github()
    str_1 = github_1.api_url()
    assert(str_1 == "https://api.github.com")
    

# Generated at 2022-06-26 01:16:37.837780
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    print("Test Github check_build_status")

    github = Github()
    github.check_build_status("owner", "repo", "ref")


# Generated at 2022-06-26 01:16:41.998982
# Unit test for method api_url of class Github
def test_Github_api_url():
    test_case_0()

# ------------------------------------------------------------------------------


# Generated at 2022-06-26 01:16:44.436885
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("test", "test", "test") == True


# Generated at 2022-06-26 01:16:46.875938
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    gitlab_0 = Gitlab()
    gitlab_0.domain()


# Generated at 2022-06-26 01:16:53.215070
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if os.environ.get("HVCS_DOMAIN") == "gitlab.com":
        if os.environ.get("CI_SERVER_HOST") == "gitlab.com":
            assert Gitlab.check_build_status("collective","collective.github.com", "ce52197c9fcb3590c044e6ef53a6b2f63979cd4c") == True


# Generated at 2022-06-26 01:18:06.101159
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None, "the auth of Github class is not None"


# Generated at 2022-06-26 01:18:11.661844
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Arrange
    owner = "owner"
    repo = "repo"
    ref = "ref"
    hvcs = Github()
    # Act
    result = hvcs.check_build_status(owner=owner, repo=repo, ref=ref)
    # Assert
    expected_result = True
    assert result == expected_result


# Generated at 2022-06-26 01:18:13.765180
# Unit test for function get_hvcs
def test_get_hvcs():
    """
    Tests that get_hvcs() returns a helper class
    """

    # test case 0
    hvcs_test.test_case_0()
    assert base_0

# Generated at 2022-06-26 01:18:20.542987
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # create a pipeline for project 'python_htcondor'
    gl = gitlab.Gitlab(Gitlab.api_url(), private_token=Gitlab.token())
    gl.auth()
    print("Gitlab domain:", Gitlab.domain())
    print("Gitlab api url:", Gitlab.api_url())
    print("Gitlab token:", Gitlab.token())
    project = gl.projects.get("CMS-HTCondor-Devs/python_htcondor")
    pipeline = project.pipelines.create(
        {"ref": "master", "variables": [{"key": "TEST", "value": "test"}]}
    )

    # wait until pipeline is finished
    while True:
        pipeline.refresh()

# Generated at 2022-06-26 01:18:34.861703
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        os.environ['CI_SERVER_HOST'] = 'gitlab.com'
    except Exception as e:
        logger.error("test_Gitlab_check_build_status: environment variable CI_SERVER_HOST not found")
        return
    try:
        os.environ['GL_TOKEN'] = 'token_ci'
    except Exception as e:
        logger.error("test_Gitlab_check_build_status: environment variable GL_TOKEN not found")
        return
    owner = 'owner_ci'
    repo = 'repo_ci'
    ref = 'ref_ci'
    base_0 = Gitlab()
    base_1 = base_0.check_build_status(owner, repo, ref)


# Generated at 2022-06-26 01:18:36.793400
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        base_0 = get_hvcs()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 01:18:42.955502
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test for check_build_status"""
    gl = Gitlab()
    res = gl.check_build_status("sr", "repo", "123456")
    assert(res)



# Generated at 2022-06-26 01:18:48.383032
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    ok("check_build_status", "true", Gitlab.check_build_status("f5devcentral", "f5-support-test", "9c7399f"))
    ok("check_build_status", "false", Gitlab.check_build_status("f5devcentral", "f5-support-test", "f7399f"))


# Generated at 2022-06-26 01:19:02.416224
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.debug("Unit test for method check_build_status of class Gitlab")
    base_0 = Gitlab
    owner = "robotology"
    repo = "sweetie-bot-deployment"
    ref = "51e35e34c5f5d88d7b5f10b5554d13e31164d926" # A non-existent commit, status should be: pending
    ref = "master" # A commit that succeeds, status should be: success
    #ref = "78f1a32c33a2a0d6c88a63e13bd6cb1ef89ca05a" # A commit that fails, status should be: failed
    base_0.check_build_status(owner, repo, ref)
    base_0.check_build_status(owner, repo, ref)

#

# Generated at 2022-06-26 01:19:05.179347
# Unit test for method auth of class Github
def test_Github_auth():
    # Arrange
    git_token = Github.token()
    # Act
    auth_1 = Github.auth()
    # Assert
    assert git_token is not None
    assert auth_1 is not None


# Generated at 2022-06-26 01:20:28.866012
# Unit test for method api_url of class Github
def test_Github_api_url():
    github_api_url = Github.api_url()

# # Unit test for method token of class Github
# def test_Github_token():
#     github_token = Github.token()

# # Unit test for method auth of class Github
# def test_Github_auth():
#     github_auth = Github.auth()


# Generated at 2022-06-26 01:20:30.383797
# Unit test for method domain of class Github
def test_Github_domain():
    try:
        Github.domain()
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-26 01:20:34.127024
# Unit test for method auth of class Github
def test_Github_auth():
    auth = Github.auth()
    if(auth == None):
        print("test_Github_auth(): Failed")
    else:
        print("test_Github_auth(): Passed")


# Generated at 2022-06-26 01:20:37.858912
# Unit test for function get_hvcs
def test_get_hvcs():
    base_0 = get_hvcs()
    assert isinstance(base_0, Base)

# Generated at 2022-06-26 01:20:44.181715
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    # Unit test for method domain of class Gitlab with no environment variable set
    domain = Gitlab.domain()
    assert domain == "gitlab.com"

    # Unit test for method domain of class Gitlab with environment variable set
    os.environ['CI_SERVER_HOST'] = 'gitlab.com'
    domain = Gitlab.domain()
    assert domain == "gitlab.com"



# Generated at 2022-06-26 01:20:48.452156
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    owner = 'soberton'
    repo = 'covid19-wheels'
    ref = 'v0.0.3'
    print (f"owner = {owner}")
    print (f"repo = {repo}")
    print (f"ref = {ref}")
    print (f"Github.check_build_status = {Github.check_build_status(owner, repo, ref)}")


# Generated at 2022-06-26 01:20:53.480369
# Unit test for method auth of class Github
def test_Github_auth():
    try:
        token = Github.token()
        if not token:
            return None
        return TokenAuth(token)
    except Exception as e:
        print("Exception (test_Github_auth) %s" % (e))
        assert False


# Generated at 2022-06-26 01:21:03.409257
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    import gitlab
    owner = "b0noI"
    repo = "testing"
    ref = "974b5a3131d3eb2bcc5a5a5dcdc5a5a5a5a5a5a5"
    gl = gitlab.Gitlab("https://gitlab.com", "1yFiedTsxvnSXoBgj4eD")
    #return Gitlab.check_build_status(owner, repo, ref)


# Generated at 2022-06-26 01:21:06.545819
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs_github = "github"
    os.environ['HVCS'] = hvcs_github
    assert get_hvcs() == Github


# Generated at 2022-06-26 01:21:10.481616
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 01:22:32.439551
# Unit test for method auth of class Github
def test_Github_auth():
    # TO-DO: test for Github.auth
    return


# Generated at 2022-06-26 01:22:37.372823
# Unit test for method auth of class Github
def test_Github_auth():
    base_0 = Github()
    assert Github == type(base_0)
    assert base_0.auth() == TokenAuth(Github.token())


# Generated at 2022-06-26 01:22:47.320180
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.debug("Test Gitlab.check_build_status")
    # Check the build status of a repository
    # Get the last commit of the repository
    # The commit is a SHA1 hash
    # Get the build of this commit
    # Check the status of the build
    if os.environ.get("GITLAB_TOKEN"):
        g = git.Git(os.getcwd())
        commit = g.rev_parse("HEAD", short=10)
        last_build = Gitlab.check_build_status("pymatgen", "pymatgen", commit)
        assert last_build
    else:
        logger.warning("GITLAB_TOKEN variable is not set, skip test_Gitlab_check_build_status")


# Generated at 2022-06-26 01:22:49.216086
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
    assert Gitlab.domain() != "Github.com"


# Generated at 2022-06-26 01:22:55.655592
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    base_1 = Gitlab()
    owner_1 = "root"
    repo_1 = "release-bot"
    ref_1 = "2932de9bb969029f4757d5aab3c3e1e7062b4d7b"
    result_1 = base_1.check_build_status(owner_1, repo_1, ref_1)
    if result_1:
        print("test_Gitlab_check_build_status case 1 PASSED")
    else:
        print("test_Gitlab_check_build_status case 1 FAILED")

    ref_2 = "4795f8b8a0985c5de9e5f5c5d098ab239fbec726"

# Generated at 2022-06-26 01:22:58.307837
# Unit test for method auth of class Github
def test_Github_auth():
    """
    Method to test auth of class Github
    """
    token = os.environ.get("GH_TOKEN")
    if not token:
        return None
    return TokenAuth(token)


# Generated at 2022-06-26 01:23:01.701754
# Unit test for method domain of class Github
def test_Github_domain():
    print("[Github] Testing domain...")
    config["hvcs_domain"] = "github.com"
    result = Github.domain()
    assert result == "github.com"


# Generated at 2022-06-26 01:23:02.523450
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(owner, repo, ref) == True


# Generated at 2022-06-26 01:23:03.272708
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(owner, repo, ref)


# Generated at 2022-06-26 01:23:06.858408
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # test of check_build_status with a successful status
    assert Gitlab.check_build_status("Tornado-bot","TornadoFDS","0f4362e7c33f4cf4d4c4a9a919c791d3f3a3c838")

    # test of check_build_status with a failed status
    assert not Gitlab.check_build_status("FDS-SMV","FDS-SMV","a3815aa61c8b9f1b9c84d2db85cee8edfc30e4c4")


# Generated at 2022-06-26 01:24:30.935144
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("12574794", "GitlabTest", "e85cab4e4102c6f1ccc8f93f02545d9d1b6ff7c6")
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "29f3c7e92e8b196b5b0a8a55c5a5d5b5f0c5157b")


# Generated at 2022-06-26 01:24:31.530628
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:24:33.834044
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "ea-academy-2019"
    repo = "ea-academy-2019"
    ref = "d26b8f8ea1a9595f0b83100d4f8c814a1a0d1ef0"
    assert_equal(Gitlab.check_build_status(owner, repo, ref), True)



# Generated at 2022-06-26 01:24:38.371691
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test cases for get_hvcs
    # Case 0: The hvcs option is not defined on config.json
    assert get_hvcs() == Github
    config.data["hvcs"] = "github"
    assert get_hvcs() == Github
    config.data["hvcs"] = "gitlab"
    assert get_hvcs() == Gitlab

    # Case 1: The hvcs option is not defined on config.json
    config.data.pop("hvcs", None)
    assert get_hvcs() == Github

    # Case 2: The hvcs option is "github"
    config.data["hvcs"] = "github"
    assert get_hvcs() == Github

    # Case 3: The hvcs option is "gitlab"

# Generated at 2022-06-26 01:24:39.263893
# Unit test for method domain of class Github
def test_Github_domain():
    pass


# Generated at 2022-06-26 01:24:42.867576
# Unit test for method auth of class Github
def test_Github_auth():
    if True:
        expected = None

        # Check if the results are equivalent
        assert expected == Github.auth()


# Generated at 2022-06-26 01:24:46.256793
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test case 0, with all valid inputs
    optional_0 = get_domain()
    optional_1 = get_token()
    optional_2 = get_owner()
    optional_3 = get_repo()
    optional_4 = get_ref()
    try:
        res = Gitlab.check_build_status(optional_2, optional_3, optional_4)
        # Test was successful
        assert (res == True)
    except HTTPError as e:
        print("HTTPError occurred")
        assert (e.code == 400)


# Generated at 2022-06-26 01:24:47.095338
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == "github" or get_hvcs() == "gitlab"

# Generated at 2022-06-26 01:24:53.084052
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Define input parameters
    owner = "dojo"
    repo = "dojo"
    ref = "master"

    # Call method under test
    optional_0 = Gitlab.check_build_status(owner, repo, ref)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:24:53.997345
# Unit test for method auth of class Github
def test_Github_auth():
    Github.auth() #
