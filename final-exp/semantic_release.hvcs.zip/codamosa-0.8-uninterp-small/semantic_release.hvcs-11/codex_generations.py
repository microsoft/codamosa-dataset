

# Generated at 2022-06-26 01:17:11.345392
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    global successful_exit
    successful_exit = False
    owner = "a"
    repo = "b"
    ref = "c"
    class gl:
        class projects:
            class get:
                class commits:
                    class get:
                        class statuses:
                            class list:
                                def __call__(self):
                                    global successful_exit
                                    successful_exit = True
                                    return ()
    Gitlab.check_build_status(owner, repo, ref)
    assert successful_exit


# Generated at 2022-06-26 01:17:16.013182
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    """Unit test for method Gitlab.domain"""

    os.environ["CI_SERVER_HOST"] = "gitlab.com"

    gitlab = Gitlab()
    # Test for base case
    test_domain = "gitlab.com"
    assert gitlab.domain() == test_domain


# Generated at 2022-06-26 01:17:22.872038
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        # Gitlab.check_build_status("hivetech", "test_repo_1", "test_ref_1")

        Gitlab.check_build_status("hivetech", "test_repo_2", "test_ref_2")

        # Gitlab.check_build_status("hivetech", "test_repo_3", "test_ref_3")
    except:
        print("Gitlab.check_build_status() failed")


# Generated at 2022-06-26 01:17:35.098311
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "owner"
    repo = "repo"
    ref = "ref"

    owner_repo = owner + "/" + repo

    # Test 1: check_build_status where job status is success
    return_value_1 = True

    # Test 2: check_build_status where job status is still pending
    return_value_2 = False

    # Test 3: check_build_status where job status is failed
    return_value_3 = False

    # Test 4: check_build_status where job status is failed and allow_failure is True
    return_value_4 = True

    # Test 5: check_build_status for a tag that does not exist
    return_value_5 = True

    gl = gitlab.Gitlab(Gitlab.api_url(), private_token=Gitlab.token())


# Generated at 2022-06-26 01:17:41.215271
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    status = Gitlab.check_build_status("mahc", "hvcs-test", "9f16a1ae70cc1d35e2cae61fd8ac7757cddbe5da")
    if status != True:
        print("Unit test Gitlab.check_build_status: Fail")
    else:
        print("Unit test Gitlab.check_build_status: Pass")


# Generated at 2022-06-26 01:17:51.663272
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    auth = TokenAuth("some-token")
    r = requests.Request("https://example.com/api/v3")
    # If the function walks over the main branch, it works
    assert auth(r)

    # If the function walks over the alternative branch, it works
    r = requests.Request("https://example.com/api/v3")
    assert auth(r)

    # If the function walks over the alternative branch, it works
    r = requests.Request("https://example.com/api/v3")
    assert auth(r)

    # If the function walks over the alternative branch, it works
    r = requests.Request("https://example.com/api/v3")
    assert auth(r)

    # If the function walks over the alternative branch, it works

# Generated at 2022-06-26 01:17:53.342773
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status('test_owner', 'test_repo', 'test_ref')


# Generated at 2022-06-26 01:17:55.335796
# Unit test for method api_url of class Github
def test_Github_api_url():
    github = Github()
    actual = github.api_url()
    expected = f"https://{Github.DEFAULT_DOMAIN}"
    assert actual == expected


# Generated at 2022-06-26 01:18:01.004825
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-26 01:18:01.639612
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()


# Generated at 2022-06-26 01:19:49.024972
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Owner and repo on gitlab.com
    assert Gitlab.check_build_status("gitlab-org", "gitlab-runner", "a2da2c4513987f75d1e8c7e3852c48bacb0d5f5e")

    # Owner and repo on custom domain
    if Gitlab.domain() != "gitlab.com":
        assert Gitlab.check_build_status("cfme", "cfme-rhconsulting-scripts", "e14e21a9a0f14d86fdc57d594540e1f4c1cb8238")


# Generated at 2022-06-26 01:19:50.872239
# Unit test for method auth of class Github
def test_Github_auth():
    test = get_auth()
    test.equals(None)


# Generated at 2022-06-26 01:19:59.615372
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    def test_case_1():
        optional_0 = get_domain()
        optional_1 = get_token()
        if optional_0 != None:
            domain_0 = optional_0
        else:
            domain_0 = "gitlab.com"
        if optional_1 != None:
            token_0 = optional_1
        else:
            token_0 = "a"
        optional_2 = check_build_status(domain_0, token_0, "b", "c")
        return optional_2
    optional_0 = Gitlab.check_build_status("a", "b", "c")
    if optional_0 != None:
        return_value = optional_0
    else:
        optional_1 = test_case_1()
        if optional_1 != None:
            return_value = optional_

# Generated at 2022-06-26 01:20:01.889906
# Unit test for function get_hvcs
def test_get_hvcs():
    with mock.patch("shipit.config.get", return_value="gitlab"):
        assert get_hvcs() == Gitlab


# Generated at 2022-06-26 01:20:02.819022
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == get_domain()

# Generated at 2022-06-26 01:20:03.799677
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    pass


# Generated at 2022-06-26 01:20:05.050724
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-26 01:20:07.844420
# Unit test for method api_url of class Github
def test_Github_api_url():
    expected_0 = 'https://api.github.com'
    actual_0 = Github.api_url()
    assert expected_0 == actual_0


# Generated at 2022-06-26 01:20:10.496910
# Unit test for method api_url of class Github
def test_Github_api_url():
    """
    Unit test for method api_url of class Github
    """
    # Case 0:
    print("Case 0:")
    test_case_0()


# Generated at 2022-06-26 01:20:20.969706
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = get_domain()
    if optional_0 == "gitlab.com":
        optional_1 = get_token()
        if optional_1 is not None:
            optional_2 = get_owner_and_repo()
            if optional_2 is not None:
                optional_3 = get_ref()
                if optional_3 is not None:
                    a = Gitlab()
                    a.check_build_status(optional_2[0], optional_2[1], optional_3)

# Generated at 2022-06-26 01:21:58.114372
# Unit test for method auth of class Github
def test_Github_auth():
    instance = Github()
    assert_equal(instance.auth(), None)


# Generated at 2022-06-26 01:22:03.321760
# Unit test for method api_url of class Github
def test_Github_api_url():
    optional_0 = Github.api_url()
    optional_1 = get_api_url()
    # The expected value is False
    assert optional_0 == optional_1


# Generated at 2022-06-26 01:22:04.499381
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github()
    github.auth()


# Generated at 2022-06-26 01:22:12.611121
# Unit test for method auth of class Github
def test_Github_auth():
    Github = Github()
    Github.auth = None

    # Evaluate the method with arguments.
    try:
        Github.auth()
        # If the method call does not throw an exception,
        # then it is working as expected.
        assert True
    except AssertionError as e:
        # An assertion failed,
        # so the test method must throw an exception.
        raise e
    except Exception as e:
        # An exception was thrown,
        # but not the exception that the test method must throw.
        raise AssertionError(e)
    else:
        # No exception was thrown.
        raise AssertionError()


# Generated at 2022-06-26 01:22:19.061043
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_1 = Gitlab.check_build_status("project_owner", "project_name", "sha1")


# Generated at 2022-06-26 01:22:22.159155
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status('pytorch', 'vision', '96c7d9a3a65a8a093fcdc2e33b69d2c8783c0a1a')


# Generated at 2022-06-26 01:22:23.569092
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs().domain() == 'github.com'

# Generated at 2022-06-26 01:22:24.978454
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:22:38.777972
# Unit test for method api_url of class Github
def test_Github_api_url():
    optional_0 = Github.api_url()
    optional_1 = Github.token()
    bool_0 = Github.check_build_status(optional_1, optional_0, optional_0)
    optional_2 = Github.auth()
    bool_1 = Github.post_release_changelog(optional_0, optional_0, optional_0, optional_1)
    bool_2 = Github.create_release(optional_0, optional_0, optional_1, optional_1)
    optional_3 = Github.get_release(optional_0, optional_0, optional_1)
    bool_3 = Github.edit_release(optional_0, optional_0, optional_3, optional_1)

# Generated at 2022-06-26 01:22:42.690760
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    # Unit test for method __call__ of class TokenAuth
    _0 = TokenAuth("token")
    # Parameter r, of type Callable
    # Return type: Callable
    _1 = _0("r")


# Generated at 2022-06-26 01:24:32.676959
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    optional_0 = Gitlab.domain()


# Generated at 2022-06-26 01:24:35.969956
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():

    env_var_default = os.environ.get("CI_SERVER_HOST")
    os.environ["CI_SERVER_HOST"] = "42.gitlab.com"
    try:
        actual_domain = Gitlab.domain()
    finally:
        if env_var_default is not None:
            os.environ["CI_SERVER_HOST"] = env_var_default
        else:
            del os.environ["CI_SERVER_HOST"]

    assert actual_domain == "42.gitlab.com"


# Generated at 2022-06-26 01:24:37.067672
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status("owner", "repo", "ref")
    return


# Generated at 2022-06-26 01:24:41.378619
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        assert get_hvcs() == Github
    except ImproperConfigurationError:
        pass
    os.environ["CI_SERVER_HOST"] = "lol.com"
    os.environ["CI_SERVER_TYPE"] = "lol"
    try:
        assert get_hvcs() == Gitlab
    except ImproperConfigurationError:
        pass
    del os.environ["CI_SERVER_HOST"]
    del os.environ["CI_SERVER_TYPE"]
    try:
        assert get_hvcs() == Github
    except ImproperConfigurationError:
        pass
    try:
        config.set("hvcs", "lol")
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-26 01:24:44.006286
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    optional_0 = Gitlab.check_build_status('bas', 'qa_test_repo', 'e2238805c3e1a201f7cfd811b2d7a89f6d6dc9f9')
    assert(optional_0 == True)


# Generated at 2022-06-26 01:24:46.399871
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    test_TokenAuth___call___var = TokenAuth(token = None)
    test_TokenAuth___call___var.__call__(r = 'test_r')


# Generated at 2022-06-26 01:24:51.821083
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    optional_0 = TokenAuth.__call__(self)
    if optional_0 != None:
        print("Executed test case __call__")
    else:
        print("Test case __call__ was not executed")


# Generated at 2022-06-26 01:24:52.999678
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("", "", "") == True


# Generated at 2022-06-26 01:24:54.288601
# Unit test for method auth of class Github
def test_Github_auth():
    ret = Github.auth()
    assert ret is None


# Generated at 2022-06-26 01:24:55.449005
# Unit test for method api_url of class Github
def test_Github_api_url():
    # Test empty inputs
    optional_0 = Github.api_url()
