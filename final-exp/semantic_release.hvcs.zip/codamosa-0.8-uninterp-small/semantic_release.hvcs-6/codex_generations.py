

# Generated at 2022-06-26 01:22:10.905734
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Input: 
    #owner = 'yilu0'
    owner = "ai-platform"
    repo = "tensorflow_metadata"
    ref = "fd11fd235793fdfd967b48a828b7e2f2c4f7d3d4"
    Github.check_build_status(owner, repo, ref)



# Generated at 2022-06-26 01:22:12.323352
# Unit test for method domain of class Github
def test_Github_domain():
    if not Github.domain():
        raise Exception("Failed")


# Generated at 2022-06-26 01:22:19.061698
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    base_0 = Gitlab()
    out_1 = base_0.domain()
    assert out_1 == "gitlab.com"


# Generated at 2022-06-26 01:22:21.082436
# Unit test for method api_url of class Github
def test_Github_api_url():
    base_0 = get_hvcs()
    assert base_0.api_url() == 'https://api.github.com'


# Generated at 2022-06-26 01:22:32.400651
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    if os.environ.get("TEST_HOSTNAME") is not None:
        os.environ["CI_SERVER_HOST"] = os.environ.get("TEST_HOSTNAME")

    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    assert Gitlab.domain() == "gitlab.com"

    del os.environ["CI_SERVER_HOST"]
    assert Gitlab.domain() == "gitlab.com"

    os.environ["CI_SERVER_HOST"] = "gitlab.acme.com"
    assert Gitlab.domain() == "gitlab.acme.com"

    del os.environ["CI_SERVER_HOST"]
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-26 01:22:41.549455
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # test build status is "success"
    assert Gitlab.check_build_status(owner="Hyperledger", repo="iroha", ref="5f1e5f5")
    # test build status is not "success"
    assert not Gitlab.check_build_status(owner="Hyperledger-LF-Infra",
                                          repo="blockchain-explorer-regression-tests",
                                          ref="28a5761")


# Generated at 2022-06-26 01:22:46.153789
# Unit test for method auth of class Github
def test_Github_auth():
    from unittest.mock import patch

    os.environ["GH_TOKEN"] = "unit test"

    expected = TokenAuth("unit test")

    actual = Github.auth()

    if actual != expected:
        raise AssertionError("Github.auth() returns wrong value")
    del os.environ["GH_TOKEN"]



# Generated at 2022-06-26 01:22:52.471051
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    url_0 = Gitlab.check_build_status('Ensembl', 'ensembl-webcode', 'c8d4668396f04a03a4f2d78c6b5b5ed5f5a1e3bb')
    url_1 = Gitlab.check_build_status('Ensembl', 'ensembl-webcode', 'e6ff69cac37c2f9b0e2005c902545a8c19f2cc81')
    assert isinstance(url_0, bool)
    assert isinstance(url_1, bool)
    assert url_0
    assert not url_1


# Generated at 2022-06-26 01:22:54.000527
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = "github"
    assert(get_hvcs().__name__ == hvcs.capitalize())


# Generated at 2022-06-26 01:22:58.220672
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status( "raynaldmo", "Deep_Fit", "d2acb34a05b6aa8f7a505b9d9cab684f93df8e29")
    assert not Gitlab.check_build_status( "Raynaldmo", "Deep_Fit", "d2acb34a05b6aa8f7a505b9d9cab684f93df8e29")
    assert not Gitlab.check_build_status( "raynaldmo", "Deep_Fits", "d2acb34a05b6aa8f7a505b9d9cab684f93df8e29")
