

# Generated at 2022-06-26 01:16:38.044111
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if config.get("hvcs_type") == "Gitlab":
        build_status = Gitlab.check_build_status(config.get("hvcs_owner"), config.get("hvcs_repo"), os.environ.get("CI_COMMIT_SHA"))
        print(f"The build status returned by method check_build_status is {build_status}")
        assert build_status == True


# Generated at 2022-06-26 01:16:43.752919
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test case 0: Test if the get_hvcs will return a HVCS helper class if successfully
    test_base_0 = Base()
    def test_case_0():
        base_0 = get_hvcs()
    test_case_0.__name__ = 'test_case_0'
    test_case_0.description = 'test if the get_hvcs will return a HVCS helper class if successfully'
    utilities.assert_equals(test_case_0, test_base_0)

# Run unit tests
if __name__ == "__main__":
    test_get_hvcs()

# Generated at 2022-06-26 01:16:46.904915
# Unit test for method auth of class Github
def test_Github_auth():
    base = get_hvcs()
    auth = base.auth()
    assert auth.token == os.environ.get("GH_TOKEN")


# Generated at 2022-06-26 01:16:57.685903
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-26 01:17:01.952996
# Unit test for method auth of class Github
def test_Github_auth():
    # Method auth of class Github
    print('\n=== Testing for auth ===')
    class_0 = Github()
    function_0 = class_0.auth()
    print('\t=== Auth ===')
    print('\tThe expected token to be returned:')
    print('\t\t' + str(os.environ["GH_TOKEN"]))
    print('\tThe actual token to be returned:')
    print('\t\t' + str(function_0.token))


# Generated at 2022-06-26 01:17:12.805028
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    base_0 = Gitlab
    owner_0 = "orange-cloudfoundry"
    repo_0 = "cf-deployment"
    ref_0 = "bd940f0e7d5dac6c042239f9c6b50d7ba63f88db"
    ret_0 = Gitlab.check_build_status(owner_0, repo_0, ref_0)
    logger.debug(f"ret_0: {ret_0}")
    exception_0 = False

# Generated at 2022-06-26 01:17:23.328902
# Unit test for function get_hvcs
def test_get_hvcs():
    path_0 = os.getcwd() + "/test_cases/0"
    config.load_config(path_0)
    assert get_hvcs().domain() == 'gitlab.com'
    assert get_hvcs().api_url() == r'https://gitlab.com'
    assert get_hvcs().token() == r'xxx'

    path_1 = os.getcwd() + "/test_cases/1"
    config.load_config(path_1)
    assert get_hvcs().domain() == 'github.com'
    assert get_hvcs().api_url() == r'https://api.github.com'
    assert get_hvcs().token() == r'xxx'

    path_2 = os.getcwd() + "/test_cases/2"
   

# Generated at 2022-06-26 01:17:30.252456
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github()
    out = github.auth()
    assert(out is not None)
    #out_domain = out.domain()
    #out_api_url = out.api_url()
    #out_token = out.token()
    #assert(out_domain == 'github.com')
    #assert(out_api_url == 'https://api.github.com')
    #assert(out_token == 'token 1e0428a237be48ec24e4c1c89e00a8a177fbecb9')



# Generated at 2022-06-26 01:17:32.643760
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    gl = Gitlab()
    assert True == gl.check_build_status(owner=os.getenv('GITLAB_USER'), repo=os.getenv('GITLAB_REPO'), ref=os.getenv('GITLAB_REF'))


# Generated at 2022-06-26 01:17:39.228845
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST")) == "gitlab.com":
        assert not Gitlab.check_build_status("yoyonel", "testgitlab", "master")

if __name__ == "__main__":
    test_case_0()
    test_Gitlab_check_build_status()

# Generated at 2022-06-26 01:19:04.580443
# Unit test for method api_url of class Github
def test_Github_api_url():
    gh = Github()
    if (gh.domain() == Github.DEFAULT_DOMAIN):
       assert gh.api_url() == "https://api.github.com"
    else:
       assert gh.api_url() == "https://api.example.com"


# Generated at 2022-06-26 01:19:08.665874
# Unit test for method auth of class Github
def test_Github_auth():
    test_token = "123"
    # Set environment variable GH_TOKEN to test_token
    os.environ["GH_TOKEN"] = test_token

    github = Github()
    auth = github.auth()
    token = auth.token

    # Set environment variable GH_TOKEN to ""
    os.environ["GH_TOKEN"] = ""

    # Assert test_token and token are equal
    assert test_token == token


# Generated at 2022-06-26 01:19:18.497343
# Unit test for method auth of class Github
def test_Github_auth():
    base_0 = Github()
    base_0.domain = lambda : 'github.com'
    base_0.api_url = lambda : 'https://api.github.com'
    base_0.token = lambda : 'Token_Not_Found'
    assert base_0.auth() == None
    os.environ['GH_TOKEN'] = '29d3c9118fc72385b29d09e7f0ba25c28f6b1f6c'
    assert base_0.auth() == TokenAuth('29d3c9118fc72385b29d09e7f0ba25c28f6b1f6c')
    os.environ['GH_TOKEN'] = 'Token_Not_Found'
    return 'test_Github_auth: OK'


# Generated at 2022-06-26 01:19:29.202687
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    domain_1 = "gitlab.com"
    domain_2 = "ci.gitlab.com"
    domain_3 = "git.test"

    orig_hvcs_domain = os.environ.get("HVCS_DOMAIN")
    orig_ci_server_host = os.environ.get("CI_SERVER_HOST")

    # Test 1: Environment variable empty
    os.environ["HVCS_DOMAIN"] = ""
    os.environ["CI_SERVER_HOST"] = ""
    assert Gitlab.domain() == domain_1

    # Test 2: HVCS_DOMAIN is not empty
    os.environ["HVCS_DOMAIN"] = domain_2
    os.environ["CI_SERVER_HOST"] = ""
    assert Gitlab.domain() == domain

# Generated at 2022-06-26 01:19:30.193632
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs()



# Generated at 2022-06-26 01:19:34.916114
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    #  Case 0: This is a case gitlab
    base_0 = get_hvcs()

    owner = "ABC"
    repo = "ABCDEF"
    ref = "1234567890"

    with mock.patch("swh.vault.get_hvcs", return_value=base_0):
        test = Gitlab.check_build_status(owner, repo, ref)

    assert test == True


# Generated at 2022-06-26 01:19:46.337648
# Unit test for method check_build_status of class Github

# Generated at 2022-06-26 01:19:48.028725
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("owner", "repo", "ref") == True


# Generated at 2022-06-26 01:19:50.506098
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == os.environ.get("CI_SERVER_HOST")


# Generated at 2022-06-26 01:19:52.252739
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    test_get_hvcs_case_0()


# Generated at 2022-06-26 01:21:10.478982
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs.__doc__ is not None
    base = get_hvcs()
    assert isinstance(base, Base)


# Generated at 2022-06-26 01:21:13.490661
# Unit test for method api_url of class Github
def test_Github_api_url():
    # make sure that the api_url is formed correctly
    assert "https://api.github.com" == Github.api_url()


# Generated at 2022-06-26 01:21:18.306989
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    owner_0 = "tensorflow"
    repo_0 = "tensorflow"
    ref_0 = "c0d945a031f8af7b92d67afc5b5f1feeea04a36f"
    ret_0 = Github.check_build_status(owner_0, repo_0, ref_0)
    if ret_0 is None:
        return False
    return True



# Generated at 2022-06-26 01:21:27.001923
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    project_1 = "atom/atom"
    status_1 = Gitlab.check_build_status("atom", "atom", "894d3e7bb8")
    project_2 = "Z3Prover/z3"
    status_2 = Gitlab.check_build_status("Z3Prover", "z3", "08fcbfa05f")
    project_3 = "hg-git/hg-git"
    status_3 = Gitlab.check_build_status("hg-git", "hg-git", "7a82795cfc")
    assert status_1 == True
    assert status_2 == True
    assert status_3 == True


# Generated at 2022-06-26 01:21:28.769532
# Unit test for method domain of class Github
def test_Github_domain():
    github = Github()
    assert github.domain() == 'github.com'


# Generated at 2022-06-26 01:21:31.948369
# Unit test for function get_hvcs
def test_get_hvcs():

    def case_0():
        # Base case
        base_0 = get_hvcs()
    
    def case_1():
        # Wrong input
        base_1 = get_hvcs()


# Generated at 2022-06-26 01:21:39.471471
# Unit test for function get_hvcs
def test_get_hvcs():
    import pytest
    from .config import Config

    config_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config.initialize(config_path)

    # Test: The invalid option provided
    config["hvcs"] = "blabla"
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

    # Test: The valid option provided
    config["hvcs"] = "github"
    assert get_hvcs().__name__ == "Github"

# Generated at 2022-06-26 01:21:42.452211
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Case 0: test Gitlab.check_build_status on a dummy project
    assert Gitlab.check_build_status("ouspg", "shifter", "master")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 01:21:51.291831
# Unit test for function get_hvcs
def test_get_hvcs():
    os.environ["HVCS"] = ''
    assert get_hvcs() == Base
    
    os.environ["HVCS"] = 'github'
    assert get_hvcs() == Github
    
    os.environ["HVCS"] = 'gitlab'
    assert get_hvcs() == Gitlab
    
    os.environ["HVCS"] = 'any_string'
    try:
        get_hvcs()
    except Exception as e:
        assert type(e) == ImproperConfigurationError
    else:
        assert False # should not reach here
    
    os.environ["HVCS"] = ''


# Generated at 2022-06-26 01:21:53.043485
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-26 01:23:08.823544
# Unit test for method auth of class Github
def test_Github_auth():
    token = "test"
    dr = TokenAuth(token)
    assert dr.token == token


# Generated at 2022-06-26 01:23:11.799400
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("DE-EPCC", "TEST-repo-TEST", "d0c716c7022a9b7fcd6dbaeeb8c8feb5fc6c9316") == False
    assert Gitlab.check_build_status("DE-EPCC", "TEST-repo-TEST", "4e5efa8e3c1e50862aae5e6d55d33002ae4a4a4c") == True


# Generated at 2022-06-26 01:23:13.279260
# Unit test for method api_url of class Github
def test_Github_api_url():
    github_0 = Github
    github_0.api_url()

# Generated at 2022-06-26 01:23:17.847101
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Try a success
    base_0 = Gitlab()
    assert(base_0.check_build_status("hysds", "hysds", "dd741bfa0e3c0b4d4d1a7a4afb14e4a6d9d6efa0") == True)
    # Try a failure
    assert(base_0.check_build_status("hysds", "hysds", "72b6f07e09d07d05f5758b00cf80f1c9a9dbe35d") == False)
    # Try a pending

# Generated at 2022-06-26 01:23:18.560586
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Base.unit_test('domain',Gitlab)


# Generated at 2022-06-26 01:23:19.069157
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    gitlab_0 = Gitlab.domain()


# Generated at 2022-06-26 01:23:21.414324
# Unit test for method api_url of class Github
def test_Github_api_url():
    base_0 = Github()
    print("Test for method api_url of class Github:")
    print(base_0.api_url())
    print("\n")


# Generated at 2022-06-26 01:23:24.494578
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    owner_0 = get_owner()
    repo_0 = get_repo()
    ref_0 = get_ref()
    assert Github.check_build_status(owner_0, repo_0, ref_0) is True


# Generated at 2022-06-26 01:23:25.702740
# Unit test for method auth of class Github
def test_Github_auth():
    base = Github
    assert isinstance(base.auth(),TokenAuth)


# Generated at 2022-06-26 01:23:33.126429
# Unit test for method domain of class Github
def test_Github_domain():
    # Input strings
    hvcs_domain_0 = "github.com"
    hvcs_domain_1 = ""
    
    # Expected return value
    domain_0 = "github.com"
    domain_1 = "github.com"
    
    # Call method domain of Github
    domain_return_0 = Github.domain()
    
    # Call method domain of Github
    domain_return_1 = Github.domain()
    
    # Check if return value is correct
    assert domain_return_0 == domain_0
    
    # Check if return value is correct
    assert domain_return_1 == domain_1
