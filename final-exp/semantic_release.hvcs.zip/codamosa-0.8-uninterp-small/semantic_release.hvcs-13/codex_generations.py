

# Generated at 2022-06-26 01:17:48.274633
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        assert 'Test' != get_hvcs()
    except ImproperConfigurationError:
        assert True


# Generated at 2022-06-26 01:17:53.262788
# Unit test for method auth of class Github
def test_Github_auth():
    assert 'Github' in __name__
    base_0 = Github()
    tests_0 = [
        (0,),
    ]
    for test_0 in tests_0:
        try:
            assert base_0.auth() is not None
        except AssertionError as e:
            print(test_0)
            raise e


# Generated at 2022-06-26 01:17:54.426138
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-26 01:17:56.201629
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("testing", "testing", "e540ccd274576e25bfedf028e3ec3ab3eb389c0f")


# Generated at 2022-06-26 01:17:58.035619
# Unit test for method domain of class Github
def test_Github_domain():
    config['hvcs'] = 'Github'
    config['hvcs_domain'] = 'api.github.com'
    assert Github.domain() == 'api.github.com'


# Generated at 2022-06-26 01:17:59.513179
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    base_0 = get_hvcs()
    domain = base_0.domain()
    assert domain == "github.com" or domain == "gitlab.com"


# Generated at 2022-06-26 01:18:03.017164
# Unit test for function get_hvcs
def test_get_hvcs():
    base = get_hvcs()
    assert base is not None
    assert base.api_url() is not None
    assert base.check_build_status('opendrop', 'opendrop', 'a8a51d9f') == True
    assert base.post_release_changelog('opendrop', 'opendrop', '0.0.1', 'changelog') == True
    assert base.upload_dists('opendrop', 'opendrop', '0.0.1', '/home/opendrop/dist') == True

# Generated at 2022-06-26 01:18:05.445806
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hybridva", "hybridva", "v0.1.0") == True
    assert Gitlab.check_build_status("hybridva", "hybridva", "v0.2.0") == True
    assert Gitlab.check_build_status("hybridva", "hybridva", "v0.3.0") == True


# Generated at 2022-06-26 01:18:08.502770
# Unit test for method api_url of class Github
def test_Github_api_url():
    base_1 = Github.api_url()
    # result = 'https://api.github.com'
    # assert base_1 == result


# Generated at 2022-06-26 01:18:09.903606
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    print("Testing domain in Gitlab")
    assert Gitlab.domain() == os.environ.get("CI_SERVER_HOST", "gitlab.com")  # Tested with gitlab.com


# Generated at 2022-06-26 01:19:53.358093
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Unit test Gitlab.check_build_status, A simple test case
    print("Running unit test Gitlab.check_build_status.")
    assert Gitlab.check_build_status("haysclark", "sphinx-gitlab-changelog", "f7e88e1d77b7a22f80e8b057a4f4d2c7012b9f9f")
    print("Passed.")


# Generated at 2022-06-26 01:19:54.526639
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-26 01:19:56.379168
# Unit test for function get_hvcs
def test_get_hvcs():
    print('\n')
    print('Running test case for get_hvcs')
    print('--------------------------------------------')
    if base_0 == None:
        print('Error accessing base_0')
    else:
        print('Success, base_0 has been assigned')

test_get_hvcs()

# Generated at 2022-06-26 01:19:58.884441
# Unit test for method auth of class Github
def test_Github_auth():
    base_0 = Github()
    base_1 = get_hvcs()
    
    if (base_0.auth() != base_1.auth()):
        return False
    
    return True


# Generated at 2022-06-26 01:20:09.104093
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com", "domain for no CI_SERVER_HOST  is gitlab.com"

    os.environ["CI_SERVER_HOST"] = "http://example.com"
    assert Gitlab.domain() == "example.com", "domain for CI_SERVER_HOST is example.com"

    os.environ["CI_SERVER_HOST"] = "https://gitlab-ci-token:wrong_token@gitlab.com"
    assert Gitlab.domain() == "gitlab.com", "domain for CI_SERVER_HOST is gitlab.com"

    os.environ["CI_SERVER_HOST"] = "https://gitlab-ci-token:wrong_token@gitlab.com/"

# Generated at 2022-06-26 01:20:13.037778
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("kubernetes", "kubernetes", "v1.15.0-beta.0") == True
    assert Gitlab.check_build_status("kubernetes", "kubernetes", "v1.15.1-beta.0") == False



# Generated at 2022-06-26 01:20:19.306915
# Unit test for method domain of class Github
def test_Github_domain():
    """
    hvcs.Github.domain()
    """
    base_0 = get_hvcs()
    assert base_0.domain() == "github.com"



# Generated at 2022-06-26 01:20:31.068953
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    '''
        The method check_build_status checks the last build status of a commit
        of a project. It uses the API of Gitlab and compare the status of jobs
        to identify if the build failed.
    '''
    assert Gitlab.check_build_status("bionano", "bnx-format", "f0be7087acfd631dcc1f154f75c7ad848e83c9af") == True, "Gitlab.check_build_status failed"
    assert Gitlab.check_build_status("bionano", "bnx-format", "744f9849e6b7ca17eae0a4ecee8dfb4d4d4fe4b7") == False, "Gitlab.check_build_status failed"


# Generated at 2022-06-26 01:20:37.359531
# Unit test for method auth of class Github
def test_Github_auth():
    _fix_mime_types()

    # Create object
    x = Github()

    # Method scope: auth
    # Return type: TokenAuth
    ret_val = x.auth()
    assert isinstance(ret_val, TokenAuth)


# Generated at 2022-06-26 01:20:39.352723
# Unit test for method domain of class Github
def test_Github_domain():
    base1 = Github()
    base1.domain()


# Generated at 2022-06-26 01:22:16.085765
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # set the environment variables
    os.environ["CI_SERVER_HOST"] = "http://localhost"
    os.environ["CI_BUILD_REF_NAME"] = "master"
    os.environ["CI_PROJECT_PATH"] = "bob/myrepo"
    os.environ["GL_TOKEN"] = "toto"

    gl = Gitlab()
    r = gl.check_build_status("bob", "myrepo", "master")
    assert r == True


# Generated at 2022-06-26 01:22:27.140719
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    global Gitlab
    Gitlab = dyn.make_dyn_class('Gitlab', Base = Base)
    Gitlab.check_build_status = Gitlab.check_build_status.im_func

    class gitlab:
        class projects:
            @staticmethod
            def get(name: str) -> type:
                global project
                project = dyn.make_dyn_class('project', Base = Base)
                project.commits = project.commits.im_func
                project = project()
                return project

        class exceptions:
            class GitlabGetError:
                pass

            class GitlabUpdateError:
                pass

    Gitlab.gitlab = gitlab
    Gitlab.gitlab.exceptions = Gitlab.gitlab.exceptions.im_func


# Generated at 2022-06-26 01:22:29.067693
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github


# Generated at 2022-06-26 01:22:30.898359
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Case 0
    test_Gitlab_check_build_status_0()


# Generated at 2022-06-26 01:22:38.422880
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test if unit test project on Gitlab.com is built successfully"""
    assert Gitlab.check_build_status("intree-cloud", "atomicity-lab-ci-pipeline", "fc1aabb")
    assert not Gitlab.check_build_status("intree-cloud", "atomicity-lab-ci-pipeline", "badsha")


# Generated at 2022-06-26 01:22:42.052987
# Unit test for method api_url of class Github
def test_Github_api_url():
    answ = "https://api.github.com"
    base_0 = Github()
    api_url_0 = base_0.api_url()
    assert api_url_0 == answ


# Generated at 2022-06-26 01:22:43.684041
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == os.environ.get("CI_SERVER_HOST")


# Generated at 2022-06-26 01:22:46.237926
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """To test the method check_build_status of the class Gitlab"""
    base_0 = get_hvcs()
    print(Gitlab.domain())


# Generated at 2022-06-26 01:22:48.273267
# Unit test for function get_hvcs
def test_get_hvcs():
    base_1 = get_hvcs()
    base_2 = get_hvcs()

    assert(base_1 == base_2)

# Generated at 2022-06-26 01:22:49.476940
# Unit test for method domain of class Github
def test_Github_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-26 01:24:43.832038
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    '''
    test_Gitlab_domain will test domain of class Gitlab.
    '''
    if not Gitlab.domain():
        raise Exception("Gitlab.domain(): Gitlab.domain can't be empty and is not.")


# Generated at 2022-06-26 01:24:45.998530
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    gl = Gitlab()
    assert gl.check_build_status("YoannRobin", "setup", "16e24f85638630fef456aacfbfb60dd07c8a9b50")
    assert not gl.check_build_status("lablup", "lablup-backend-launcher", "master")


# Generated at 2022-06-26 01:24:50.840389
# Unit test for method auth of class Github
def test_Github_auth():
    base_2 = Github()
    base_2.domain()
    base_2.api_url()
    base_2.token()
    base_2.auth()


# Generated at 2022-06-26 01:24:53.682216
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    base_0 = get_hvcs()
    if base_0 is Github:
        return
    assert Gitlab.check_build_status(owner="alxzoomer", repo="hello-world", ref="4baea634f056368a0832edee14c76bca9119d754") == True


# Generated at 2022-06-26 01:25:02.543709
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Check that a successful build returns True
    assert Gitlab.check_build_status("redhat-performance", "cockpit", "35a7950b95db1b811a2d7e5b95c5f73857b9c9d7")
    # Check that a pending build returns False
    assert not Gitlab.check_build_status("redhat-performance", "cockpit", "b1e48f74ceb5d621c3e3f2c2b160cd005b9c127d")
    # Check that a failed build returns False
    assert not Gitlab.check_build_status("redhat-performance", "cockpit", "a5b70c7523602af8f59d07d15b0c9a302eb719bf")
    # Check that a failed build with allowed failure returns False

# Generated at 2022-06-26 01:25:04.238865
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    assert isinstance(hvcs,Base)

# Generated at 2022-06-26 01:25:12.143926
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    if os.environ.get('CI_SERVER_HOST') == 'gitlab.com':
        assert(Gitlab.domain() == "gitlab.com")
    else:
        assert(Gitlab.domain() == os.environ.get('CI_SERVER_HOST'))

if __name__ == "__main__":
    test_case_0()
    #test_Gitlab_domain()

# Generated at 2022-06-26 01:25:17.373431
# Unit test for method auth of class Github
def test_Github_auth():
    # Inside a unit test, load a stub/mock of config
    config.read("tests/stubs/config.ini")

    # Inside a unit test, GH_TOKEN is set
    # os.environ['GH_TOKEN'] = 'my_token'

    # Run method
    Github.auth()


# Generated at 2022-06-26 01:25:21.232014
# Unit test for method auth of class Github
def test_Github_auth():
    base_0 = get_hvcs()
    print("\nToken in Github is:", Github.token())
    print("\nUrl in Github is:", Github.api_url())
    print("\nAuth token of Github is:", Github.auth())


# Generated at 2022-06-26 01:25:27.177725
# Unit test for function get_hvcs
def test_get_hvcs():
    base_0 = get_hvcs()
    assert base_0 == Github

    config.set("hvcs", "github")
    base_1 = get_hvcs()
    assert base_1 == Github

    config.set("hvcs", "gitlab")
    base_2 = get_hvcs()
    assert base_2 == Gitlab

    config.set("hvcs", None)
    base_3 = get_hvcs()
    assert base_3 == Github

    config.set("hvcs", "github")
    base_4 = get_hvcs()
    assert base_4 == Github
