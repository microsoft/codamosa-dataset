

# Generated at 2022-06-26 01:17:10.496480
# Unit test for method api_url of class Github
def test_Github_api_url():
    if get_hvcs_domain() == "github.com":
        # We are using the default URL which should be "https://api.github.com"
        # so Github.api_url() should be equal to "https://api.github.com"
        assert Github.api_url() == "https://api.github.com"
    else:
        # We are using a custom URL which is not prefixed with "api"
        # so Github.api_url() should be equal to our custom URL
        assert Github.api_url() == f"https://{get_hvcs_domain()}"



# Generated at 2022-06-26 01:17:12.164891
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-26 01:17:15.895313
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status('bundestag','datenhaltung','0e9eef1406f8a0bcf5a88c3ddae5b5b534e3d3df') == False


# Generated at 2022-06-26 01:17:17.734428
# Unit test for method domain of class Github
def test_Github_domain():
    extract_test_case(test_case_0, globals())
    print("\n")


# Generated at 2022-06-26 01:17:24.335741
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    test_owner = 'elastic'
    test_repo = 'python-logstash'
    test_ref = '4c4b4e3f5d5d0075ad0a88e48287b3e9f123cebf'
    test_result = Gitlab.check_build_status(test_owner, test_repo, test_ref)
    logger.debug(f"Gitlab.check_build_status: {test_result}")
    assert test_result == True


# Generated at 2022-06-26 01:17:27.967416
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    # Function under test
    token = 'token'
    tokenAuth_object = TokenAuth(token)
    r = 'r'
    returned = tokenAuth_object.__call__(r)
    #
    assert(returned == r)


# Generated at 2022-06-26 01:17:28.872462
# Unit test for method domain of class Github
def test_Github_domain():
    str_0 = Github.domain()



# Generated at 2022-06-26 01:17:35.319484
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Testcase 0
    bool_0 = Gitlab.check_build_status("namespace", "repository", "ref")
    assert bool_0 != None


# Generated at 2022-06-26 01:17:39.409772
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = config.get("hvcs")
    expected_hvcs_class = globals().get(hvcs.capitalize(), None)

    assert(expected_hvcs_class == get_hvcs())


# Generated at 2022-06-26 01:17:41.947468
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = None
    auth = TokenAuth("")
    auth_call_result = auth(r)
    assert auth_call_result == None


# Generated at 2022-06-26 01:19:29.300297
# Unit test for function get_hvcs
def test_get_hvcs():

    try:
        get_hvcs()
    except ImproperConfigurationError:
        pass

    config.set("hvcs", "github")
    assert get_hvcs() == Github

    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab

# Generated at 2022-06-26 01:19:32.481153
# Unit test for method api_url of class Github
def test_Github_api_url():
    github_1 = Github()
    str_0 = github_1.api_url()
    str_1 = Github.DEFAULT_DOMAIN
    str_2 = "api."
    assert str_0 == str_2 + str_1
    

# Generated at 2022-06-26 01:19:35.887519
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        owner = "litetechnology"
        repo = "lis3mdl-driver"
        git_ref = "6cba6a42b8c72ecee0ddbc9c88d1f56e1a841a56"
        bool_0 = Gitlab.check_build_status(owner, repo, git_ref)
        logger.debug(f"test_Gitlab_check_build_status: success")
    except Exception as e:
        logger.error(f"test_Gitlab_check_build_status: failed, error: {e}")
        raise e



# Generated at 2022-06-26 01:19:44.250980
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Case 0: "test" is not a repo of "testcase"
    bool_0 = Github.check_build_status("testcase", "test", "test")
    assert bool_0 == False, "TestCase 0: Bad repo name, invalid git commit hash"
    # Case 1: "test" is a repo of "testcase"
    bool_1 = Github.check_build_status("testcase", "test", "ab66cff7c57")
    assert bool_1 == True, "TestCase 1: Good repo name, valid git commit hash"


# Generated at 2022-06-26 01:19:46.870780
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert (
        Gitlab.check_build_status(owner="mah-dmre", repo="pipeline", ref="master") == False
    )


# Generated at 2022-06-26 01:19:55.796724
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():

    try:
        domain_0 = os.environ['CI_SERVER_HOST']
        os.environ['CI_SERVER_HOST'] = ''
    except KeyError:
        domain_0 = 'NameNotFound'
        os.environ['CI_SERVER_HOST'] = ''

    domain_1 =  Gitlab.domain()

    if (domain_1 == 'gitlab.com'):
        if (domain_0 == 'NameNotFound'):
            print('Test case #1: Pass')
        else:
            print('Test case #1: Fail')
    else:
        print('Test case #1: Fail')

    os.environ['CI_SERVER_HOST'] = domain_0


# Generated at 2022-06-26 01:19:57.549506
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = '5zNLiIZy5LGnNvF1WQY1'
    tokenauth = TokenAuth(token)
    r = 'something'
    tokenauth.__call__(r)
    return True


# Generated at 2022-06-26 01:20:06.400349
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.info("test_Gitlab_check_build_status: testing the Gitlab.check_build_status()")

    class params:
        owner = "hyperledger"
        repo = "cactus"
        ref = "4b4e4b5d5ee5f9b844b02e1ef73a688b92d05b75"
        expected_out = True

    assert params.expected_out == Gitlab.check_build_status(params.owner, params.repo, params.ref)

if __name__ == "__main__":

    test_case_0()

    test_Gitlab_check_build_status()

    logger.info("All tests passed!")

# Generated at 2022-06-26 01:20:14.772081
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        base_0 = get_hvcs()
    except ImproperConfigurationError:
        print("Failed to get HVCS")

    config.config["hvcs"] = "gitlab"
    base_1 = get_hvcs()
    if isinstance(base_1, Base):
        print("Successfully get Gitlab HVCS")
    
    config.config["hvcs"] = "github"
    base_1 = get_hvcs()
    if isinstance(base_1, Base):
        print("Successfully get Github HVCS")
    else:
        print("Fail to get Github HVCS")
    
    config.config["hvcs"] = "fake"

# Generated at 2022-06-26 01:20:20.457493
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    bool_0 = Gitlab.check_build_status("SAP", "hana-ml", "4a8cf46ffe4a2c693e5475bff1b9aab07ee3e3fa")


# Generated at 2022-06-26 01:23:39.152138
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github


# Generated at 2022-06-26 01:23:41.337189
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    # Test case 0
    token = "dummy_token"
    token_auth = TokenAuth(token)



# Generated at 2022-06-26 01:23:42.502181
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    bool_1 = Gitlab.check_build_status("test_owner","test_repo","test_ref")


# Generated at 2022-06-26 01:23:50.993667
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github()
    GH_TOKEN = os.environ.get("GH_TOKEN")
    print(GH_TOKEN)

    def test_case_0():
        return github.token() is not None
    def test_case_1():
        return github.token() == GH_TOKEN
    def test_case_2():
        return github.token() == "NotAGoodToken"

    pass_all = True
    if not test_case_0():
        print("Test case 0 Failed\n")
        pass_all = False
    if not test_case_1():
        print("Test case 1 Failed\n")
        pass_all = False
    if test_case_2():
        print("Test case 2 Failed\n")
        pass_all = False

# Generated at 2022-06-26 01:23:53.921826
# Unit test for method auth of class Github
def test_Github_auth():
    github_0 = Github
    token_0 = "qUBf7TK"
    method_0 = github_0.auth()
    assert (method_0 == token_0)


# Generated at 2022-06-26 01:23:58.515093
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token_0 = Mock(auth_token)
    token_1 = TokenAuth(token_0)
    response = Mock(Response)
    headers = Mock(Header)
    headers.set("Authorization", "token " + auth_token)
    response.set_headers(headers)
    result_1 = token_1.__call__(response)
    assert result_1 == response



# Generated at 2022-06-26 01:24:06.011677
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token_0 = "token_0"
    obj_0 = TokenAuth(token_0)
    req_0 = Session()
    ret_0 = obj_0.__call__(req_0)
    assert ret_0 == req_0, "obj_0.__call__(req_0) returned value is not (req_0)"
    assert str(ret_0) == "<Response [200]>", "obj_0.__call__(req_0) returned value is not <Response [200]>"

# Generated at 2022-06-26 01:24:07.061829
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        hvcs = get_hvcs()
        assert isinstance(hvcs, Base)
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-26 01:24:10.274226
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert(Gitlab.check_build_status("sflpro", "gst_validator", "dba841a7054cdd6f87c6e9f6e8a6f9c634e0e726") is True)
    assert(Gitlab.check_build_status("sflpro", "gst_validator", "2f50dba841a7054cdd6f87c6e9f6e8a6f9c634e0e726") is False)


# Generated at 2022-06-26 01:24:11.830536
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    class_0 = TokenAuth()
    #self.assertEqual(class_0.__call__(), None)
    pass
