

# Generated at 2022-06-12 06:51:27.168129
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test scope for the function get_hvcs"""
    assert get_hvcs() == Github

# Generated at 2022-06-12 06:51:28.931346
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:51:31.396353
# Unit test for method api_url of class Github
def test_Github_api_url():
    # Evaluating class Github.api_url
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-12 06:51:36.254873
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # this test is intended to check the behavior of GL_TOKEN env. variable
    os.environ["GL_TOKEN"] = "token"
    assert Gitlab.check_build_status("gitlab-org", "gitlab-ce", "0a2a5bf7c5d5868ed9b9f9b87d31f2adf00261dc") == True

# Generated at 2022-06-12 06:51:37.193781
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is None



# Generated at 2022-06-12 06:51:42.699549
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if os.environ.get("CI_SERVER_HOST"):
        gl = Gitlab()
        assert gl.check_build_status(
            owner="Torlus",
            repo="cmake-update",
            ref="f8442406a36a4d3db6f3ee9ac8a634e1f9787fbe",
        )
        assert gl.check_build_status(
            owner="Torlus",
            repo="cmake-update",
            ref="c3e3553c634f4d4ebb4c4df6e8f6ba830e966a85",
        )



# Generated at 2022-06-12 06:51:46.336499
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set('hvcs', 'Github')
    assert get_hvcs() == Github
    config.set('hvcs', 'gitlab')
    assert get_hvcs() == Gitlab
    config.set('hvcs', 'foo')
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set('hvcs', 'Github')

# Generated at 2022-06-12 06:51:51.337530
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    build_status_passed = Gitlab.check_build_status("kinvolk", "lokomotive", "7d4c4edbc3b2c9e3dab557b44a4aa6a7ece0b45b")
    assert build_status_passed == True
    build_status_failed = Gitlab.check_build_status("kinvolk", "lokomotive", "687e79e8c20e54db2f020b5fba2b3f3a02f13d54")
    assert build_status_failed == False
    build_status_failed_but_allowed = Gitlab.check_build_status("kinvolk", "lokomotive", "5d521d01a08a6a19bf6c822dfb7dde358119b78e")

# Generated at 2022-06-12 06:51:53.121239
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of class Gitlab
    :return:
    """
    assert Gitlab.check_build_status("test", "test", "test")
    assert not Gitlab.check_build_status("test", "test", "test")



# Generated at 2022-06-12 06:51:57.974541
# Unit test for method auth of class Github
def test_Github_auth():
    # Check that the method returns None when key is empty and returns a value of type TokenAuth when key is set
    assert Github.auth() is None
    github = Github()
    github.token = "..."
    assert isinstance(Github.auth(), TokenAuth)



# Generated at 2022-06-12 06:53:59.069901
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test values
    owner = "nf.dummy_test_1"
    repo = "nf-core-dummy"
    # Obtain a list of the current branches
    gl = gitlab.Gitlab(Gitlab.api_url(), private_token=Gitlab.token())
    gl.auth()
    branches = gl.projects.get(owner + "/" + repo).branches.list()
    # Pick the first branch of the list and obtain its commit
    branch = branches[1]['name']
    commits = gl.projects.get(owner + "/" + repo).commits.list(ref_name=branch)
    ref = commits[0]['id']
    assert Gitlab.check_build_status(owner, repo, ref) == True



# Generated at 2022-06-12 06:54:02.684979
# Unit test for method api_url of class Github
def test_Github_api_url():
    _domain = 'github.com'
    _api_url = 'https://'+_domain
    assert Github.domain() == _domain
    assert Github.api_url() == _api_url
test_Github_api_url()

# Generated at 2022-06-12 06:54:05.012668
# Unit test for method auth of class Github
def test_Github_auth():
    # Get the token environment variable (GH_TOKEN) value
    token = os.environ.get("GH_TOKEN")
    assert Github.token() == token



# Generated at 2022-06-12 06:54:09.470067
# Unit test for method auth of class Github
def test_Github_auth():
    Github.token = lambda: "A"
    TokenAuth.__eq__ = lambda self, other: self.token == other.token
    expected = TokenAuth("A")
    result = Github.auth()
    assert expected == result

# Generated at 2022-06-12 06:54:18.100982
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test Gitlab.check_build_status"""

    # Set environment variables
    os.environ["CI_PROJECT_PATH"] = "Vidjil/vidjil"
    os.environ["CI_COMMIT_SHA"] = "b461fa67ef7d1f88c72e836ba0faa798c9a9bce0"

    # Test successful result
    assert Gitlab.check_build_status("Vidjil", "vidjil", "b461fa67ef7d1f88c72e836ba0faa798c9a9bce0")



# Generated at 2022-06-12 06:54:23.083678
# Unit test for method auth of class Github
def test_Github_auth():
    auth = Github.auth()
    assert isinstance(auth, TokenAuth)
    assert auth.token == os.environ.get("GH_TOKEN")

    os.environ["GH_TOKEN"] = ""
    auth = Github.auth()
    assert auth is None
import pytest


# Generated at 2022-06-12 06:54:24.252679
# Unit test for method domain of class Github
def test_Github_domain():
    Github.domain()


# Generated at 2022-06-12 06:54:27.308764
# Unit test for function get_hvcs
def test_get_hvcs():
    """ Unit test for Function get_hvcs
    """
    hvcs = get_hvcs()
    assert isinstance(hvcs, Base)



# Generated at 2022-06-12 06:54:28.231347
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:54:30.768163
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"
