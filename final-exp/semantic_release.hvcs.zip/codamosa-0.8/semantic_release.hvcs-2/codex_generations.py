

# Generated at 2022-06-12 06:50:41.267435
# Unit test for method auth of class Github
def test_Github_auth():
    logger.info("Test Github auth")
    token = Github.token()
    if token is None:
        logger.error("Test Failed!")
        print("Test Failed!")
    else:
        logger.info("Test Passed!")
        print("Test Passed!")



# Generated at 2022-06-12 06:50:45.977868
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    valid_classes = ["Github","Gitlab"]
    assert isinstance(hvcs, Base)
    assert hvcs.__class__.__name__ in valid_classes

# Generated at 2022-06-12 06:50:51.915317
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"
    
    # Unit test for method api_url of class Github when the hvcs_domain is set
    config.set("hvcs_domain", "test")
    assert Github.api_url() == "https://test"
    
    # Unit test for method api_url of class Github when an empty hvcs_domain is set
    config.set("hvcs_domain", "")
    assert Github.api_url() == "https://api.github.com"
    


# Generated at 2022-06-12 06:50:56.410449
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """This method tests the Gitlab _check_build_status method.
    """
    gl = Gitlab()
    status = gl.check_build_status("owner_namespace", "owner_name", "ref")
    assert status == True or status == False

# Generated at 2022-06-12 06:51:01.213378
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test of method check_build_status of class Gitlab."""
    owner = "pyenv"
    repo = "pyenv"
    ref = "1a28e63e64f68fcd89337da2d1b9c558f8065173"

    assert Gitlab.check_build_status(owner, repo, ref) is True

# Generated at 2022-06-12 06:51:05.006584
# Unit test for method auth of class Github
def test_Github_auth():
    global GITHUB_DATA
    GITHUB_DATA = {}
    GITHUB_DATA["domain"] = "github.com"
    GITHUB_DATA["url"] = "https://github.com"
    GITHUB_DATA["hvcs_domain"] = "github.com"

    result = Github.auth()
    assert result is None



# Generated at 2022-06-12 06:51:09.709383
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    import os
    os.environ["GH_TOKEN"] = "test_token"
    assert Github.check_build_status("owner", "repo", "ref") is False


# Generated at 2022-06-12 06:51:15.726250
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse_success:
        def json(self):
            return {"status": "success", "allow_failure": False}

    class MockResponse_failed:
        def json(self):
            return {"status": "failed", "allow_failure": False}

    class MockResponse_pending:
        def json(self):
            return {"status": "pending"}

    class MockResponse_failed_allowed:
        def json(self):
            return {"status": "failed", "allow_failure": True}

    class MockResponse_failed_allow_failure_malformed:
        def json(self):
            return {"status": "failed"}

    class MockResponse_malformed:
        def json(self):
            return {"status2": "failed", "allow_failure": False}


# Generated at 2022-06-12 06:51:17.367848
# Unit test for method auth of class Github
def test_Github_auth():
    Github = Github()
    Github.auth()



# Generated at 2022-06-12 06:51:29.266283
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test for status of the pipeline on a project which passed the last pipeline
    print("test_Gitlab_check_build_status: test for passed pipeline")
    owner = "HashVault"
    repo = "opdssdk"
    ref = "feae66bd46e355fea0a87c8f2eea9a9d0eaf025f"
    assert Gitlab.check_build_status(owner, repo, ref) == True

    # Test for status of the pipeline on a project which failed the last pipeline
    print("test_Gitlab_check_build_status: test for failed pipeline")
    owner = "HashVault"
    repo = "opdssdk"

# Generated at 2022-06-12 06:54:54.655133
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """This Unit test mocks some gitlab api responses to evaluate the
    check_build_status method of the Gitlab class"""

    ref = "1234567890"
    owner = "my-project"
    repo = "my-repo"
    status_list = [
        {"name": "job1", "status": "success", "allow_failure": False},
        {"name": "job2", "status": "failed", "allow_failure": False},
        {"name": "job3", "status": "pending", "allow_failure": False},
    ]

    for job in status_list:
        assert Gitlab.check_build_status(owner, repo, ref) == False, \
            "method check_build_status of class Github should return False " \
            "if a job failed without allow_failure"

# Generated at 2022-06-12 06:54:56.174047
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:55:02.440357
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Unit test for method check_build_status of class Gitlab"""
    test = Gitlab()
    owner = os.environ.get("CI_PROJECT_NAMESPACE")
    repo = os.environ.get("CI_PROJECT_NAME")
    ref = os.environ.get("CI_COMMIT_SHA")
    print(test.check_build_status(owner, repo, ref))



# Generated at 2022-06-12 06:55:03.099948
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    pass

# Generated at 2022-06-12 06:55:09.226173
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("hysds", "verdi", "9f66a5f5d521d0b139c6917dd62e6d5a6e8f9c03"
) == True
    assert Gitlab.check_build_status("hysds", "verdi", "a8afb735ef957afd17506d11f54e7c7a73f0ae0c"
) == False
    assert Gitlab.check_build_status("hysds", "verdi", "08b0f44d1a2e8d23b152c9b2a38e32a275d8e3f3"
) == True


# Generated at 2022-06-12 06:55:15.553369
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "GitHub")
    assert get_hvcs().__name__ == "Github"

    config.set("hvcs", "GitLab")
    assert get_hvcs().__name__ == "Gitlab"

    with pytest.raises(ImproperConfigurationError):
        config.set("hvcs", "Invalid")
        get_hvcs()



# Generated at 2022-06-12 06:55:23.858074
# Unit test for function get_hvcs
def test_get_hvcs():
    config._config = {}
    assert isinstance(get_hvcs(), Base)
    config._config["hvcs"] = "gitlab"
    assert isinstance(get_hvcs(), Gitlab)
    config._config["hvcs"] = "github"
    assert isinstance(get_hvcs(), Github)
    config._config["hvcs"] = "gitlab_test"
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-12 06:55:30.140091
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

    config.set("hvcs", "github")
    assert get_hvcs() == Github

    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab



# Generated at 2022-06-12 06:55:31.861498
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert isinstance(get_hvcs(), Github)

# Generated at 2022-06-12 06:55:37.244347
# Unit test for method auth of class Github
def test_Github_auth():
    test_token = "SomeToken"
    assert Github.auth() == None
    os.environ["GH_TOKEN"] = test_token
    assert Github.auth() != None
    assert Github.auth() == TokenAuth(test_token)
