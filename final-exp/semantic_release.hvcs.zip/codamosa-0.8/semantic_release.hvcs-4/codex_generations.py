

# Generated at 2022-06-12 06:48:51.743963
# Unit test for function get_hvcs
def test_get_hvcs():
    """
    Test for function get_hvcs
    """
    logging.basicConfig(filename=".log", level=logging.DEBUG)
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "NotImplemented")
    try:
        get_hvcs()
    except ImproperConfigurationError as e:
        assert type(e) == ImproperConfigurationError

# Generated at 2022-06-12 06:49:01.656257
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the Gitlab.check_build_status() method
    """
    os.environ["GL_TOKEN"] = "3q2bXekCWxbsCqdyyAjw"
    assert Gitlab.check_build_status(
        owner="gitlab-org", repo="gitlab-ce", ref="5a5f566c1d"
    )
    assert Gitlab.check_build_status(
        owner="gitlab-org", repo="gitlab-ce", ref="d4a7f75a0c"
    )
    assert Gitlab.check_build_status(
        owner="gitlab-org", repo="gitlab-ee", ref="5a5f566c1d"
    )

# Generated at 2022-06-12 06:49:03.431993
# Unit test for method auth of class Github
def test_Github_auth():
    assert not Github.auth()



# Generated at 2022-06-12 06:49:09.397136
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class TestGitlab(Gitlab):
        def domain(self):
            return "test.domaine"

        def api_url(self):
            return "test.api_url"

        def token(self):
            return "test.token"

    test_gitlab = TestGitlab()
    res = test_gitlab.check_build_status(
        "owner", "repo", "ref"
    )
    assert res is False

# Generated at 2022-06-12 06:49:13.189241
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("NeoVintageous", "NeoVintageous", "ab94f9a9ecef") == True
    assert Gitlab.check_build_status("NeoVintageous", "NeoVintageous", "a23fd0fb38e4") == False


# Generated at 2022-06-12 06:49:14.210717
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    auth = TokenAuth("token")
    r = Mock()
    r.headers = {}
    assert auth(r) == r
    assert r.headers == {"Authorization": "token token"}



# Generated at 2022-06-12 06:49:17.342227
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    return_value = True
    # Define arguments
    owner = "RamiroAguero"
    repo = "semantic-release-test"
    ref = "70eafd8677dcebae8748e5f5dfbfc569aa2e2d0e"
    # Return value
    return_value = True
    # Invoke method
    return_value = Github.check_build_status(owner, repo, ref)


# Generated at 2022-06-12 06:49:19.343369
# Unit test for method auth of class Github
def test_Github_auth():
    # Set up test objects
    auth = TokenAuth(token="token")

    # Assert on Github.auth()
    assert Github.auth() == auth



# Generated at 2022-06-12 06:49:21.122039
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() is not None



# Generated at 2022-06-12 06:49:23.632310
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test for Gitlab helper class"""
    Gitlab.check_build_status("TEST1", "TEST2", "TEST3")

# Generated at 2022-06-12 06:50:22.885731
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab._fix_mime_types()
    assert Gitlab.check_build_status("eclipse", "linux-container", "713b8b8332de7d9bcef4a2c992da4dd4d3b3a1e1") == True
    assert Gitlab.check_build_status("eclipse", "linux-container", "7e7c0d40b7c9f28578048f27c92320ae56c55b6d") == False
    assert Gitlab.check_build_status("eclipse", "linux-container", "1e621beeaf6aae822dccc6f5a624f2c64768e8e3") == False


# Generated at 2022-06-12 06:50:33.318214
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of the class Gitlab.
    """
    class Env:
        def __init__(self, var_name, value):
            self.var_name = var_name
            self.value = value
            self.old_value = None

        def __enter__(self):
            self.old_value = os.environ.get(self.var_name)
            os.environ[self.var_name] = self.value

        def __exit__(self, exc_type, exc_val, exc_tb):
            if self.old_value:
                os.environ[self.var_name] = self.old_value
            else:
                del os.environ[self.var_name]


# Generated at 2022-06-12 06:50:34.501326
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("a", "b", "c") == True


# Generated at 2022-06-12 06:50:37.774669
# Unit test for function get_hvcs
def test_get_hvcs():
    from .tests import Configurations
    from .exceptions import ImproperConfigurationError
    with Configurations(configs={"hvcs": "GitLab"}):
        assert get_hvcs() is Gitlab
    with Configurations(configs={"hvcs": "Github"}):
        assert get_hvcs() is Github
    with Configurations(configs={"hvcs": "MyHvcs"}):
        with pytest.raises(ImproperConfigurationError):
            get_hvcs()



# Generated at 2022-06-12 06:50:38.750488
# Unit test for method domain of class Github
def test_Github_domain():
    Github.domain()

# Generated at 2022-06-12 06:50:39.757045
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test function get_hvcs"""
    assert get_hvcs() == config.get("hvcs").capitalize()

# Generated at 2022-06-12 06:50:51.160345
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class_name = Gitlab.__name__
    function_name = Gitlab.check_build_status.__name__
    owner = "IUT-Blagnac"
    repo = "Hydra"
    ref = "2537d4c19675a3abc99a98a1f7d1a590617d8f5e"

    # 1. Call of the method in normal conditions
    # 1.1. All jobs are sucessful  
    assert Gitlab.check_build_status(owner,repo,ref) == True

    # 1.2. One job failed
    owner = "IUT-Blagnac"
    repo = "Compile"
    ref = "2537d4c19675a3abc99a98a1f7d1a590617d8f5e"
    assert Gitlab

# Generated at 2022-06-12 06:50:57.584024
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    import unittest

    class GithubTestCase(unittest.TestCase):
        def test_check_build_status(self):
            self.assertFalse(
                Github.check_build_status(
                    owner="dummy_owner", repo="dummy_repo", ref="dummy_ref"
                )
            )

    unittest.main()



# Generated at 2022-06-12 06:51:00.578368
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    _fix_mime_types()
    owner = 'owner'
    repo = 'repo'
    sha1 = 'sha1'
    result = Github.check_build_status(owner, repo, sha1)
    assert isinstance(result, bool)



# Generated at 2022-06-12 06:51:02.364322
# Unit test for function get_hvcs
def test_get_hvcs():
    """Should return the class specified in the 'hvcs' configuration variable"""
    config["hvcs"] = "gitlab"
    assert isinstance(get_hvcs(), Gitlab)

    config["hvcs"] = "github"
    assert isinstance(get_hvcs(), Github)

# Generated at 2022-06-12 06:52:05.687933
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() in [
        "https://api.github.com",
        "https://github.com",
    ], "Api URL seems invalid"



# Generated at 2022-06-12 06:52:14.694147
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import hvcs.gitlab as hvcs_gitlab
    # The path should point to a directory that contains both the gitlab.py file and the test_Gitlab_check_build_status_data.py file
    sys.path.append(os.path.join(sys.path[0], "tests"))
    import test_Gitlab_check_build_status_data as test_data

    # test_data.jobs is a list of dictionaries that contains the data of a gitlab job,
    # the result of the test of each job is saved in test_data.job_results,
    # this is a list of True/False which should have the same length as test_data.jobs

# Generated at 2022-06-12 06:52:15.234179
# Unit test for method api_url of class Github
def test_Github_api_url():
    pass



# Generated at 2022-06-12 06:52:23.629030
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def __init__(self, status_code, response_content):
            self.status_code = status_code
            self.content = response_content

        def json(self):
            return self.content

    class MockRequests:
        class Session:
            def __init__(self):
                self.requests = []

            def get(self, url, **kwargs):
                self.requests.append((url, kwargs))

# Generated at 2022-06-12 06:52:33.557998
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    
    # Test for a private Gitlab instance with a failed job
    owner = 'test'
    repo = 'project'
    ref = '5ced7b5'
    Gitlab.check_build_status = MagicMock(return_value = False)
    assert Gitlab.check_build_status(owner, repo, ref) == False
    
    
    
    # Test for a private Gitlab instance with a successful job
    owner = 'test'
    repo = 'project'
    ref = 'd73e15e'
    Gitlab.check_build_status = MagicMock(return_value = True)
    assert Gitlab.check_build_status(owner, repo, ref) == True



# Generated at 2022-06-12 06:52:34.843809
# Unit test for method auth of class Github
def test_Github_auth():
    pass



# Generated at 2022-06-12 06:52:37.571734
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    auth = TokenAuth("token")
    request = {"headers": {}}
    request = auth(request)
    assert request["headers"] == {"Authorization": f"token {auth.token}"}



# Generated at 2022-06-12 06:52:41.970829
# Unit test for function get_hvcs
def test_get_hvcs():
    config.reset("hvcs")
    assert isinstance(get_hvcs(), Github)

    config.option("hvcs", "gitlab")
    assert isinstance(get_hvcs(), Gitlab)

    config.reset("hvcs")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-12 06:52:43.953375
# Unit test for method api_url of class Github
def test_Github_api_url():
    github = Github()
    assert github.api_url() == "https://api.github.com"

# Generated at 2022-06-12 06:52:46.055289
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:53:48.968202
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    logger.debug("Test for method check_build_status of class Gitlab")
    assert Gitlab.check_build_status("TestGitlab", "TestGitlabRepo", "d4f4a4d4")

# Generated at 2022-06-12 06:53:53.372034
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    """Unit test for TokenAuth.__call__
    """
    # Setup
    token = "token"
    auth = TokenAuth(token)
    request = Session().get("http://github.com")
    # Test
    request = auth(request)
    # Assert
    assert request.headers.get("Authorization") == f"token {token}"



# Generated at 2022-06-12 06:53:54.911763
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-12 06:53:55.928855
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert (Gitlab.domain() == "gitlab.com")


# Generated at 2022-06-12 06:53:58.408535
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == 'https://api.github.com'

# Generated at 2022-06-12 06:54:03.986844
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    test_owner = "apache"
    test_repo = "hdfs"
    test_ref = "bf7a4bc0bc8b7d4103d3b19c7b0397915c7e3681"
    success = check_build_status(test_owner, test_repo, test_ref)
    if success: print("Successful")
    else: print("Failed")

# Generated at 2022-06-12 06:54:12.985343
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    from .hvcs import Github
    from .helpers import dummy_package_data, dummy_config
    from .settings import config
    from .errors import ImproperConfigurationError

    config.update(dummy_config())

    assert(Github.check_build_status('pandas-dev', 'pandas', ""))
    config['hvcs_domain'] = None
    Github.token = lambda: "test_token"
    assert(not Github.check_build_status('pandas-dev', 'pandas', ""))



# Generated at 2022-06-12 06:54:16.162930
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    Github.check_build_status("tensorflow", "tensorboard", "e3dffb2e")


# Generated at 2022-06-12 06:54:19.710373
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs","github")
    assert isinstance(get_hvcs(), Github)
    config.set("hvcs","gitlab")
    assert isinstance(get_hvcs(), Gitlab)



# Generated at 2022-06-12 06:54:29.305800
# Unit test for method auth of class Github
def test_Github_auth():
    # Path of config file for tests
    config_path = os.path.join(os.path.dirname(__file__), "tests", "config", "config.cfg")
    config.read(config_path)

    # Auth for Github
    gh_auth = config["github"]["auth"]

    # Tests
    assert Github.auth() == TokenAuth(gh_auth)
    assert Github.auth() == TokenAuth(gh_auth)
    assert Github.auth() == TokenAuth(gh_auth)
    assert Github.auth() == TokenAuth(gh_auth)
    assert Github.auth() == TokenAuth(gh_auth)
    assert Github.auth() == TokenAuth(gh_auth)



# Generated at 2022-06-12 06:56:30.732896
# Unit test for method auth of class Github
def test_Github_auth():
    b = Github()
    if b.token() is not None:
        assert isinstance(b.auth(), TokenAuth)
    else:
        assert b.auth() is None


# Generated at 2022-06-12 06:56:32.852331
# Unit test for method auth of class Github
def test_Github_auth():
  expected = TokenAuth(None)
  actual = Github.auth()
  assert expected == actual


# Generated at 2022-06-12 06:56:41.709700
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    # Reset to default value
    config.set("hvcs", "github")

    # Test with gitlab
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab

    # Test with github
    config.set("hvcs", "github")
    assert get_hvcs() == Github

    # Test with wrong value
    wrong = "foo"
    config.set("hvcs", wrong)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", "github")

# Generated at 2022-06-12 06:56:46.120073
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class DummyScriptTest:
        """Empty object for testing purposes"""

    class DummyScripts:
        """Empty object for testing purposes"""

        sync_scripts = DummyScriptTest()

    class DummyTests:
        """Empty object for testing purposes"""

        sync_tests = DummyScripts()

    class DummyScriptsRepoInfo:
        """Empty object for testing purposes"""

        tests = DummyTests()

    class DummyScriptsRepoInfoBin:
        """Empty object for testing purposes"""

        scripts_repo_info = DummyScriptsRepoInfo()

    class DummyRepoInfo:
        """Empty object for testing purposes"""

        scripts = DummyScriptsRepoInfo()
        hvcs = "gitlab"

    class DummyRepo:
        """Empty object for testing purposes"""

       

# Generated at 2022-06-12 06:56:48.258369
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert not Github.check_build_status("owner","repo","sha")


# Generated at 2022-06-12 06:56:52.450507
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    hvcs = Gitlab
    owner = "docker"
    repo = "docker"
    ref = "59a4a4ec4c45ae44e0616126aae7dd6b30ab6e3d"
    assert hvcs.check_build_status(owner, repo, ref)



# Generated at 2022-06-12 06:56:55.688064
# Unit test for function get_hvcs
def test_get_hvcs():
    assert issubclass(get_hvcs(), Base)


# Generated at 2022-06-12 06:56:59.982878
# Unit test for function get_hvcs
def test_get_hvcs():
    config.__dict__['config'] = {'hvcs': 'gitlab'}
    assert get_hvcs().__name__ == 'Gitlab'
    config.__dict__['config'] = {'hvcs': 'github'}
    assert get_hvcs().__name__ == 'Github'



# Generated at 2022-06-12 06:57:07.111777
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain()==config.get("hvcs_domain", os.environ.get("CI_SERVER_HOST"))
    os.environ["CI_SERVER_HOST"]="Gitlab.com"
    assert Gitlab.domain()==os.environ.get("CI_SERVER_HOST")
    del os.environ["CI_SERVER_HOST"]
    assert Gitlab.domain()==config.get("hvcs_domain")


# Generated at 2022-06-12 06:57:10.271177
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert (Gitlab.check_build_status("Gitlab_owner", "Gitlab_repo", "abcdef") == False)