

# Generated at 2022-06-12 06:49:35.317403
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:49:41.518218
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = config.get("hvcs")
    config.update({"hvcs": "github"})
    assert(get_hvcs() == Github)
    config.update({"hvcs": "gitlab"})
    assert(get_hvcs() == Gitlab)
    config.update({"hvcs": hvcs})

# Generated at 2022-06-12 06:49:42.543766
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    return True

# Generated at 2022-06-12 06:49:45.088349
# Unit test for method auth of class Github
def test_Github_auth():
    github_token = "github_token"
    assert Github.token() == github_token
    assert Github.auth()



# Generated at 2022-06-12 06:49:50.077786
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
import os
from typing import Optional

from github import BadCredentialsException
from github import Github
from github.GithubException import GithubException

from pydist import config
from pydist.hvcs_base import Base
from pydist.utils import LoggedFunction

logger = config.get_logger(__name__)


# Generated at 2022-06-12 06:49:54.823328
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    hvcs = get_hvcs()
    assert hvcs.domain()
    assert hvcs.api_url()



# Generated at 2022-06-12 06:50:04.312402
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponseException(Exception):
        def __init__(self, status_code, content):
            self.status_code = status_code
            self.content = content

    class MockResponse:
        def __init__(self, status_code, content):
            self.status_code = status_code
            self.content = content

    # in order to check that Gitlab.check_build_status(...) returns False
    # we need to raise a HTTPError exception with a non 2XX status code

# Generated at 2022-06-12 06:50:05.361955
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() == None

# Generated at 2022-06-12 06:50:07.039093
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:50:18.075957
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Tests if method is false when detecting pending status
    class TestClass:
        def list(self):
            return [{"status": "pending", "name": "job0", "allow_failure": False}]

    gl = gitlab.Gitlab("https://gitlab.com", private_token="")
    project = TestClass()
    project.statuses = TestClass()
    commit = TestClass()
    commit.statuses = TestClass()
    project.commits = TestClass()
    project.commits.get = TestClass()
    project.commits.get.statuses = TestClass()
    gl.projects = TestClass()
    gl.projects.get = TestClass()
    gl.projects.get.return_value = project

    assert Gitlab.check_build_status("owner", "repo", "ref")

# Generated at 2022-06-12 06:52:20.125129
# Unit test for method api_url of class Github
def test_Github_api_url():
    config.clear()
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-12 06:52:29.443068
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("cea-hpc", "friction-factor-library", "ec5590e65b70f86d7872a39f3a3b3dbb979e280e")
    assert not Gitlab.check_build_status("cea-hpc", "friction-factor-library-fails", "ec5590e65b70f86d7872a39f3a3b3dbb979e280e")
    assert not Gitlab.check_build_status("cea-hpc", "friction-factor-library-fails", "cafe6a849f0fb7c0bb072e98d96b8a6cf618a6ae")

# Generated at 2022-06-12 06:52:31.449978
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    assert get_hvcs()



# Generated at 2022-06-12 06:52:36.471897
# Unit test for method auth of class Github
def test_Github_auth():
    from .settings import config
    config["hvcs_domain"] = "example.com"
    config["username"] = "example_username"
    os.environ["GH_TOKEN"] = "example_GH_TOKEN"
    assert type(Github.auth()) == TokenAuth



# Generated at 2022-06-12 06:52:37.438585
# Unit test for method api_url of class Github
def test_Github_api_url():
    return



# Generated at 2022-06-12 06:52:38.690707
# Unit test for function get_hvcs
def test_get_hvcs():
    github = get_hvcs()
    assert type(github) == Github

# Generated at 2022-06-12 06:52:40.590439
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False


# Unit tests for method get_release of class Github

# Generated at 2022-06-12 06:52:48.197785
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # Test the connection
    with set_env(
        CI_SERVER_HOST="gitlab.com",
        GL_TOKEN="FILLMEIN",
        hvcs_domain="gitlab.com",
        hvcs_type="gitlab",
    ):
        assert Gitlab.check_build_status(
            owner="datamart/datamart-rest-api-py",
            repo="datamart-rest-api-py",
            ref="6b4f4f4d8c054a5a5e660bc79b476d1d5a5b5c5b",
        )

# Generated at 2022-06-12 06:52:51.021261
# Unit test for method auth of class Github
def test_Github_auth():
    assert GitHub.auth().__class__.__name__ == 'TokenAuth'


# Generated at 2022-06-12 06:52:57.293560
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    try:
        get_hvcs()
        assert False, "Should have raised"
    except ImproperConfigurationError as e:
        assert "foo" in str(e)

# Generated at 2022-06-12 06:54:24.305149
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == 'https://api.github.com'

# Generated at 2022-06-12 06:54:26.200054
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert isinstance(Github.check_build_status(None, None, None), bool)



# Generated at 2022-06-12 06:54:30.381881
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

    config.set("hvcs","github")
    assert isinstance(get_hvcs(), Github)

    config.set("hvcs","gitlab")
    assert isinstance(get_hvcs(), Gitlab)



# Generated at 2022-06-12 06:54:31.808008
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status('owner', 'repo', 'ref')

# Generated at 2022-06-12 06:54:37.311223
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    status = Gitlab.check_build_status(
        "PyGithub",
        "PyGithub",
        "2a2a72a53d431dceb740788e1494c9db4d4bdf32",
    )
    if status:
        print(status)
    return status

# Generated at 2022-06-12 06:54:44.539508
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == Github.DEFAULT_DOMAIN

    try:
        import semantic_release.hvcs.config

        semantic_release.hvcs.config.config["hvcs_domain"] = "custom.domain.com"

        assert Github.domain() == "custom.domain.com"
    finally:
        semantic_release.hvcs.config.config.pop("hvcs_domain", None)



# Generated at 2022-06-12 06:54:46.912399
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain()=='gitlab.com'


# Generated at 2022-06-12 06:54:49.890365
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    expected = "https://gitlab.com"
    actual = Gitlab.domain()
    assert actual == expected, f"actual: {actual}"


# Generated at 2022-06-12 06:54:53.537795
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the method check_build_status of the Gitlab class
    """
    Gitlab.check_build_status("mattsegal", "pytest-pythonpath", "f9dc23b9db7d5b3f5c5b521de78f01ece5ba41b4")

# Generated at 2022-06-12 06:54:55.254301
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:56:27.111997
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-12 06:56:29.209081
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-12 06:56:30.231088
# Unit test for method auth of class Github
def test_Github_auth():
    assert False, "Not implemented"



# Generated at 2022-06-12 06:56:37.877105
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """test function for Gitlab.check_build_status method"""
    if os.environ.get("GL_TOKEN"):
        if Gitlab.check_build_status("ash", "test_gitlab_check_build_status", "0c25d7a"):
            print("check_build_status is working fine.")
        else:
            assert False, "check_build_status is not working properly."
    else:
        print("GL_TOKEN is not defined")



# Generated at 2022-06-12 06:56:45.802272
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    import unittest

    class TestGitlabCheckBuildStatus(unittest.TestCase):
        def test_on_gitlab_com(self):
            self.assertTrue(Gitlab.check_build_status("wipro-opensource", "qiskit-bot", "06b860935f934c3dcd6e3d6e8dc6d97f7cab5890"))

        def test_on_gitlab_com_with_failed_pipeline(self):
            self.assertFalse(Gitlab.check_build_status("wipro-opensource", "qiskit-bot", "d77647dab16e99e0b10c8d67fda6454ccd7c1a01"))


# Generated at 2022-06-12 06:56:54.935090
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    # Test if hvcs_domain is set in configuration.ini
    config.load_config("configuration.ini")
    config.set("hvcs_domain", "example.com")
    assert Gitlab.domain() == "example.com"

    # Test if hvcs_domain is NOT set but CI_SERVER_HOST is set in the env
    config.set("hvcs_domain", None)
    os.environ["CI_SERVER_HOST"] = "example.com"
    assert Gitlab.domain() == "example.com"

    # Test if hvcs_domain and CI_SERVER_HOST are NOT set
    config.set("hvcs_domain", None)
    os.environ["CI_SERVER_HOST"] = "example.com"

# Generated at 2022-06-12 06:57:02.165211
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    import unittest
    from unittest.mock import create_autospec, patch
    import gitlab
    from urllib.error import HTTPError
    from requests.exceptions import HTTPError as RequestsHTTPError
    from gitlab_helper import Gitlab
    from gitlab.v4.objects import PipelineStatus
    from gitlab_helper import logger

    class Response:
        def __init__(self, text: Union[str, List]):
            self.text = text

            if isinstance(text, str):
                self.json = lambda: [{"status": text}]
            else:
                self.json = lambda: text

    class GitlabClient:
        """gitlab.gitlab.Gitlab class mock"""

        def __init__(self):
            self.auth = lambda: None

# Generated at 2022-06-12 06:57:04.418082
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("owner", "repo", "ref") == False

# Generated at 2022-06-12 06:57:14.901701
# Unit test for method auth of class Github
def test_Github_auth():

    from .helpers import LoggedFunction
    from .settings import config
    from .test_helpers import assert_equals, assert_raises

    @LoggedFunction(logger)
    def _test_Github_auth_1():
        try:
            config.set("hvcs_domain", "github.com")
            del os.environ["GH_TOKEN"]
            assert_equals(Github.auth(), None)
            os.environ["GH_TOKEN"] = "token"
            assert_equals(
                Github.auth(),
                TokenAuth("token"),
            )
            del os.environ["GH_TOKEN"]
            assert_equals(Github.auth(), None)
        finally:
            config.set("hvcs_domain", None)

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-12 06:57:25.327119
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test the Gitlab class check_build_status method"""
    assert Gitlab.check_build_status(
        owner="Manubulon", repo="pylint", ref="5eeb1a67b6bf8c2da6829d4f56991d16269c8e2e",
    ) is True
    assert Gitlab.check_build_status(
        owner="Manubulon", repo="pylint", ref="cbea2be44d8de8f1a9a1f80d724a049c8bca3cf3",
    ) is False