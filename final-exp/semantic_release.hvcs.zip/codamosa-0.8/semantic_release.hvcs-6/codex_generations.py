

# Generated at 2022-06-12 06:50:04.804329
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test the check_build_status method
    """
    assert Gitlab.check_build_status(
        "hysds/hysds-docker-compose", "master", "ef5eb5d5a5dc5a5a5a5dc5e5a5a5a5a5a5a5a5a5"
    ) is False
    assert Gitlab.check_build_status(
        "hysds/hysds-docker-compose", "master", "2f4a4e0a2a5f5f5f5f5a5a5f5f5a5a5a5a5a5a5"
    ) is False

# Generated at 2022-06-12 06:50:09.366217
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    token = "secrettoken"
    testTokenAuth = TokenAuth(token)
    testRequest = type('Requets', (object,), {'headers': {}})
    r = testTokenAuth(testRequest)
    assert(r.headers["Authorization"] == f"token {token}")



# Generated at 2022-06-12 06:50:14.337902
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "bogus")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-12 06:50:18.537164
# Unit test for method auth of class Github
def test_Github_auth():
    """
    This test method gets a string and checks if it has the right value.
    """
    test_auth = Github.auth()
    assert test_auth == TokenAuth(os.environ.get("GH_TOKEN"))


# Generated at 2022-06-12 06:50:19.875177
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"


# Generated at 2022-06-12 06:50:21.564575
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    Github.check_build_status(owner='owner', repo='repo', ref='ref')

# Generated at 2022-06-12 06:50:24.070672
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():

    assert Github.check_build_status("owner1","repo1","ref1") == True


# Generated at 2022-06-12 06:50:27.312053
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = MockClass()

    auth = TokenAuth("token")
    auth(r)
    assert r.headers["Authorization"] == f"token {auth.token}"
    return r



# Generated at 2022-06-12 06:50:35.681817
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test 1
    owner = "sagemath"
    repo = "sage-package-manager"
    ref = "d03b0a0e980e58c632d53acf0f6fbbb2a37a9e5a"
    assert Gitlab.check_build_status(owner, repo, ref) is True

    # Test 2
    owner = "sagemath"
    repo = "sage-package-manager"
    ref = "eb2f69b9a9a6e1e6c5b5f5dc5a5b6d5a6a5a6a5a"
    assert Gitlab.check_build_status(owner, repo, ref) is True

    # Test 3
    owner = "sagemath"

# Generated at 2022-06-12 06:50:41.522917
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    from requests import Request
    from requests.auth import _basic_auth_str

    token = "foo"
    tauth = TokenAuth(token)
    url = "https://github.com/example.git"
    req = Request(method="GET", url=url)
    prepared = req.prepare()
    assert prepared.headers["Authorization"] == _basic_auth_str(token, "")
# End of unit test for method __call__ of class TokenAuth



# Generated at 2022-06-12 06:52:46.086837
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("bronze", "test", "44c6efb7")
    assert not Gitlab.check_build_status("bronze", "test", "d7ac8acf")
    assert not Gitlab.check_build_status("bronze", "test", "b0e40b92")
    assert Gitlab.check_build_status("bronze", "test", "f34bf2a2")
    assert Gitlab.check_build_status("bronze", "test", "65a8e6a4")
    assert Gitlab.check_build_status("bronze", "test", "2ed5eafc")
    assert Gitlab.check_build_status("bronze", "test", "f9778a7d")
    assert not Gitlab.check

# Generated at 2022-06-12 06:52:47.878561
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab._check_build_status(owner="owner", repo="repo", ref="ref")

# Generated at 2022-06-12 06:52:50.736345
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("A", "B", "123") == True



# Generated at 2022-06-12 06:53:00.125678
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Add mock responses for both succesful and failed build status requests
    patcher = requests_mock.Mocker(real_http=True)
    patcher.register_uri(
        "GET",
        f"https://{Gitlab.domain()}/api/v4/projects/toto/tata/commits/d111cb7cb94c13cb22d8247d117b0a0a9a248c18/statuses",  # pylint: disable=line-too-long
        json=[
            {u"name": u"build", u"status": u"failed", u"allow_failure": False},
            {u"name": u"deploy", u"status": u"failed", u"allow_failure": True},
        ],
    )

# Generated at 2022-06-12 06:53:05.054123
# Unit test for method domain of class Github
def test_Github_domain():
    # Test with no config value set
    hvcs_domain = config.pop("hvcs_domain", None)
    assert Github.domain() == Github.DEFAULT_DOMAIN
    if hvcs_domain is not None:
        config["hvcs_domain"] = hvcs_domain

    # Test with config value set
    assert Github.domain() == hvcs_domain


# Generated at 2022-06-12 06:53:07.209311
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-12 06:53:14.277910
# Unit test for method domain of class Github
def test_Github_domain():
    "test the Github.domain method"
    # check that the method returns the value in the config file
    config.set("hvcs_domain", "github.com")
    assert Github.domain() == "github.com"

    # check that the method returns the default value when nothing is set in the config file
    config.set("hvcs_domain", "")
    assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:53:15.682285
# Unit test for function get_hvcs
def test_get_hvcs():
    expected_result = config.get("hvcs")
    assert get_hvcs() == expected_result

# Generated at 2022-06-12 06:53:17.552701
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    expected = 'gitlab.com'
    assert Gitlab.domain() == expected


# Generated at 2022-06-12 06:53:27.314605
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    gl = gitlab.Gitlab("https://gitlab.com", private_token="pTKzJmZkY3q7V_QxjA_R")
    gl.auth()
    jobs = gl.projects.get("k95c/aa").commits.get("010efd7bd31d0c8b54791dd30e73c4e4d57d9e0e").statuses.list()
    for job in jobs:
        if job["status"] not in ["success", "skipped"]:
            if job["status"] == "Pending": 
                print("Job is still in pending status")
                return False
            elif job["status"] == "Failed":
                print("Job failed")
                return False
    return True


# Generated at 2022-06-12 06:55:22.119078
# Unit test for function get_hvcs
def test_get_hvcs():
    """
    Unit test for function get_hvcs
    """
    hvcs = config.get("hvcs")
    try:
        return globals()[hvcs.capitalize()]
    except KeyError:
        raise ImproperConfigurationError('"{0}" is not a valid option for hvcs.')


# Generated at 2022-06-12 06:55:24.046190
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("swazidigital", "swazi-sainsbury", "f1d3a3b7a6")

# Generated at 2022-06-12 06:55:30.183824
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    ref = "c41b9ff33b91d11f1ff3d1e94f8dfa8a6a08d89c"
    gl = Gitlab()
    assert gl.check_build_status("arm-trusted-firmware", "arm-trusted-firmware", ref)



# Generated at 2022-06-12 06:55:36.638170
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github

    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab

    with pytest.raises(ImproperConfigurationError):
        config.set("hvcs", "invalid_hvcs")
        get_hvcs()


# Generated at 2022-06-12 06:55:38.805528
# Unit test for method api_url of class Github
def test_Github_api_url():
  assert Github.api_url() == 'https://api.github.com', 'Expected api.github.com'


# Generated at 2022-06-12 06:55:41.058051
# Unit test for method api_url of class Github
def test_Github_api_url():
    g = Github()
    assert g.api_url() == "https://api.github.com"


# Generated at 2022-06-12 06:55:44.475602
# Unit test for method auth of class Github
def test_Github_auth():
    # Test: Create a TokenAuth instance with empty token
    token_auth = TokenAuth("")

    # Test: Get auth method of module Github
    auth = Github.auth()

    # Test: Check whether result equals expected value
    assert auth == token_auth

# Generated at 2022-06-12 06:55:47.313913
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert True == Gitlab.check_build_status("OVH", "ovh-cli", os.environ.get("CI_COMMIT_SHA"))

# Generated at 2022-06-12 06:55:48.866782
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:55:57.033278
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # test for gitlab.com
    gitlab.Gitlab.from_config("/tmp/gitlab.cfg").projects.list()
    class_Gitlab = Gitlab()
    class_Gitlab.check_build_status("sylabs", "singularity-client", "0")
    class_Gitlab.check_build_status("sylabs", "singularity", "0")
    #test for domain gitlab.sylabs.io
    os.environ["CI_SERVER_HOST"] = "gitlab.sylabs.io"
    class_Gitlab.check_build_status("singularity-hub", "singularity-hub", "0")
    class_Gitlab.check_build_status("singularity-hub", "singularity-hub-internal", "0")
    os.en