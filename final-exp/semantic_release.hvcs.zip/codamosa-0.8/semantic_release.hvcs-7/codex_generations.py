

# Generated at 2022-06-12 06:48:54.859343
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test with a job failed False
    assert Gitlab.check_build_status("form8ion", "chaos-monkey-ecs", "123") is False

 # Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-12 06:49:03.147489
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    from pytest import raises
    from .settings import config, CONFIG_PATH

    class MockConfig(dict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.get = self.__getitem__

    # Case: With token and correct status
    config = MockConfig({"hvcs_domain": "github.com"})
    config["hvcs_token"] = "token"
    config["hvcs_domain"] = "github.com"
    config["hvcs_api_url"] = "https://api.github.com"
    os.environ["GH_TOKEN"] = config["hvcs_token"]
    github = Github
    with raises(NotImplementedError):
        github.domain()

# Generated at 2022-06-12 06:49:07.216742
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    #Dependency injection for the method
    Gitlab.token = lambda : str("1")
    Gitlab.api_url = lambda : str("http://127.0.0.1")
    
    assert Gitlab.check_build_status(None, None, None) == False

# Generated at 2022-06-12 06:49:09.772561
# Unit test for function get_hvcs
def test_get_hvcs():
    config.add_values({"hvcs": "github"})
    old_vcs = config.get("hvcs")
    new_vcs = get_hvcs()
    config.add_values({"hvcs": old_vcs})
    assert new_vcs == Github



# Generated at 2022-06-12 06:49:18.543732
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test1
    Gitlab.check_build_status("ocaml", "opam", "bfbd0e25a8d1a683a602dc12b2c7ee9a2f2cc7e6")

    # Test2
    Gitlab.check_build_status("ocaml", "opam", "a2f2cc7e6")

    # Test3
    Gitlab.check_build_status("ocaml", "opam", "")

    # Test4
    Gitlab.check_build_status("ocaml", "", "bfbd0e25a8d1a683a602dc12b2c7ee9a2f2cc7e6")

    # Test5

# Generated at 2022-06-12 06:49:19.372303
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("test", "test", "test")



# Generated at 2022-06-12 06:49:20.524703
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(owner="testowner", repo="testrepo", ref="testsha")

# Generated at 2022-06-12 06:49:29.443360
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockJob(object):

        def __init__(self, name, status, allow_failure):
            self.name = name
            self.status = status
            self.allow_failure = allow_failure

        def __getitem__(self, key):
            if key == "name":
                return self.name
            elif key == "status":
                return self.status
            elif key == "allow_failure":
                return self.allow_failure
    os.environ["GL_TOKEN"] = "test_token"
    status_pass = Gitlab.check_build_status("hyperledger", "indy-node", "c8a6d7a6c885216ebdb8c8d4b4fe9cbd0ab9a0d4")
    assert status_pass == True

# Generated at 2022-06-12 06:49:38.063780
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class Gitlab:
        @staticmethod
        @LoggedFunction(logger)
        def check_build_status(owner: str, repo: str, ref: str) -> bool:
            jobs = [{"status": "pending"}, {"status": "failed", "allow_failure": False}, {"status": "success"}]
            for job in jobs:
                if job["status"] not in ["success", "skipped"]:
                    if job["status"] == "pending":
                        logger.debug(
                            f"check_build_status: job {job['name']} is still in pending status"
                        )
                        return False
                    elif job["status"] == "failed" and not job["allow_failure"]:
                        logger.debug(f"check_build_status: job {job['name']} failed")
                        return False

# Generated at 2022-06-12 06:49:40.636883
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    github = Github()
    assert github.check_build_status('test','test','test') == False


# Generated at 2022-06-12 06:50:46.314592
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    Gitlab.domain()



# Generated at 2022-06-12 06:50:57.636201
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    domain = "mock_domain"
    os.environ["GL_TOKEN"] = "mock_token"
    config["gitlab_domain"] = domain

    gl = gitlab.Gitlab(domain, private_token=config["gitlab_token"])
    gl.auth()
    project = gl.projects.get("mock_owner/mock_repo")

    def mock_job(*args, **kwargs):
        class Dummy:
            def __init__(
                self, status="pending", name="mock_job", allow_failure=False
            ):
                self.status = status
                self.name = name
                self.allow_failure = allow_failure

        return Dummy(*args, **kwargs)


# Generated at 2022-06-12 06:51:00.512598
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    return
    gl = Gitlab()
    if gl.domain() != Gitlab.domain():
        raise Exception("The domain was not the same")


# Generated at 2022-06-12 06:51:07.569601
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # scritp should use the default gitlab-website (gitlab.com) and API token
    # (test token)
    os.environ["GL_TOKEN"] = "xyDYTf7YhyzNwJt7sxzP"
    assert not Gitlab.check_build_status("halite", "Halite", "3a3a7011560b99f3d48a3c4a4b9cb4b78d45e2e4")
    assert Gitlab.check_build_status("HaliteChallenge", "Halite-AI-Challenge-Scripts", "1a2013f1abebb3706d58ea2a3612ef9c2f3b3ba7")
    os.environ["GL_TOKEN"] = "not-a-real-token"

# Generated at 2022-06-12 06:51:09.821868
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "Invalid_HVCS")



# Generated at 2022-06-12 06:51:15.975846
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    if platform.system() == "Windows":
        return
    base_dir = os.path.dirname(os.path.realpath(__file__))
    docker_dir = os.path.join(base_dir, "test_docker")
    cwd = os.getcwd()


# Generated at 2022-06-12 06:51:17.671708
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(None, None) == None



# Generated at 2022-06-12 06:51:29.613160
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Case 1: check_build_status for a pipeline which status is success
    # Inputs:
    #   - owner: "cyborg-project"
    #   - repo: "cyborg"
    #   - ref: "6d8c8a1b64fbb4791c1e6dc42e6d3b6cce17f59e"
    # Expected output: True
    assert Gitlab.check_build_status("cyborg-project", "cyborg", "6d8c8a1b64fbb4791c1e6dc42e6d3b6cce17f59e") == True

    # Case 2: check_build_status for a pipeline which status is failed
    # Inputs:
    #   - owner: "cyborg-project"
    #   - repo: "cyborg"

# Generated at 2022-06-12 06:51:39.188179
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "test-owner"
    repo = "test-repo"
    ref = "test-ref"

    patcher_gitlab_Gitlab_check_build_status_gitlab = mock.patch.object(
        gitlab.Gitlab, "get", return_value=MockGitlabObject()
    )
    patcher_gitlab_Gitlab_check_build_status_statuses = mock.patch.object(
        gitlab.Gitlab, "get", return_value=MockGitlabJobs()
    )

    with patcher_gitlab_Gitlab_check_build_status_gitlab, patcher_gitlab_Gitlab_check_build_status_statuses:
        assert Gitlab.check_build_status(owner, repo, ref)


# Unit tests for

# Generated at 2022-06-12 06:51:40.529817
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("patata", "patata", "patata") == True



# Generated at 2022-06-12 06:52:49.708267
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    conf = hvcs.config.Config()
    conf["hvcs_domain"] = ""
    # test domain
    assert(Gitlab.domain() == "gitlab.com")
    # test domain with environment variable
    os.environ["CI_SERVER_HOST"] = "gitlab.example.com"
    assert(Gitlab.domain() == "gitlab.example.com")
    del os.environ["CI_SERVER_HOST"]
    # test domain with hvcs_domain
    conf["hvcs_domain"] = "gitlab.example.com"
    assert(Gitlab.domain() == "gitlab.example.com")
    conf["hvcs_domain"] = ""

# Generated at 2022-06-12 06:52:52.245365
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() is Github or get_hvcs() is Gitlab
    # Reset.
    config.reset_config()
    assert get_hvcs() == Github

# Generated at 2022-06-12 06:52:56.806916
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    gitlab_check_build_status = Gitlab.check_build_status("RomainBouqueau", "test_tools", "5e5f9b5e5a2a2c3eddf84c7fdde8c5ce5d5c5df5")
    assert gitlab_check_build_status is True


# Generated at 2022-06-12 06:53:06.197361
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test variables
    test_data = {
        "owner": "test",
        "repo": "test",
        "ref": "abc123abc123abc123abc123abc123abc123abc1",
    }
    test_json = {"status": "success"}
    test_status_codes = ["success", "failed", "pending", "skipped"]

    # Mock Gitlab class
    with patch("gitlab.Gitlab") as mock_gl:
        mock_gl.return_value.auth.return_value = True
        for status in test_status_codes:
            test_json["status"] = status

# Generated at 2022-06-12 06:53:18.010111
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Unit test for method check_build_status of class Gitlab
    """
    import gitlab
    import hvcs
    import os
    import requests
    import tempfile
    import test_utils

    token = "12345"
    ref = "abcdef"
    owner = "openfortinet"
    repo = "hvcs"
    url = f"https://gitlab.com/api/v4/projects/{owner}%2F{repo}/repository/commits/{ref}/statuses"

    # Create a temp directory.
    temp_dir = tempfile.TemporaryDirectory()

    # The response of Gitlab.check_build_status for all the unit tests.
    class CheckBuildStatus_response():
        def __init__(self, content):
            self.content = content
       

# Generated at 2022-06-12 06:53:21.715299
# Unit test for method auth of class Github
def test_Github_auth():
    try:
        assert Github.auth() is not None
    except AssertionError:
        logger.exception("Github auth test failed")
        raise



# Generated at 2022-06-12 06:53:28.875552
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-12 06:53:32.119605
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    """Unit test for method check_build_status of class Github"""
    assert Github.check_build_status('sphinx-doc', 'sphinx', 'master') is True



# Generated at 2022-06-12 06:53:33.923731
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
        assert Gitlab.check_build_status(owner="group/subgroup", repo="test", ref="test") == False 

# Generated at 2022-06-12 06:53:46.412663
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Set value for var repo
    repo = "getha"

    # Set value for var domain
    domain = "gitlab.com"

    # Set value for var owner
    owner = "fintechstudios"

    # Set value for var ref
    ref = "4fbcbff2f8a49eb8415e55dea6a7a70c8dba79c5"

    # Call method check_build_status of class Gitlab with args
    assert Gitlab.check_build_status(repo, owner, ref) == True

    # Set value for var repo
    repo = "getha"

    # Set value for var domain
    domain = "gitlab.com"

    # Set value for var owner
    owner = "fintechstudios"

    # Set value for var ref

# Generated at 2022-06-12 06:56:13.463532
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""

    class TestConfig:
        """A dummy config object"""

        @staticmethod
        def get(key) -> Any:
            """Return the value of the key if it exists in the config"""
            return CONFIG.get(key)

    # Case 1: valid hvcs
    hvcs_list = CONFIG.get("hvcs_list")
    for hvcs in hvcs_list:
        result = get_hvcs()
        assert isinstance(result, globals()[hvcs.capitalize()])
        assert result.name == hvcs.capitalize()

    # Case 2: invalid hvcs
    CONFIG["hvcs"] = "invalid_hvcs"
    with pytest.raises(ImproperConfigurationError):
        get_hvcs

# Generated at 2022-06-12 06:56:15.844904
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("AugerAIOrg","auto_auger") == True

# Generated at 2022-06-12 06:56:17.760640
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # setup

    # run
    result = Github.check_build_status(owner="owner", repo="repo", ref="sha1")

    # assert
    assert result == False



# Generated at 2022-06-12 06:56:20.577077
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:56:22.493429
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert not Github.check_build_status("test", "test", "test")


# Generated at 2022-06-12 06:56:28.286491
# Unit test for function get_hvcs
def test_get_hvcs():
    """Test for function get_hvcs"""
    spwd = os.getcwd()
    os.chdir("tests/resources/hvcs/git/github_ok")
    github = get_hvcs()
    assert github.domain() == "github.com"
    os.chdir("../gitlab_ok")
    gitlab = get_hvcs()
    assert gitlab.domain() == "gitlab.com"
    os.chdir("../custom_github_ok")
    custom_github = get_hvcs()
    assert custom_github.domain() == "foo.bar"
    os.chdir(spwd)
    config.clear_config_cache()


# Generated at 2022-06-12 06:56:29.300634
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    pass



# Generated at 2022-06-12 06:56:35.232203
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Set the environment variables
    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    os.environ["GL_TOKEN"] = (
        "bUcya6UAVadH-CJfPWz6"
    )
    # The method check_build_status of Gitlab cannot be tested because it cannot use the API of gitlab.com


# Generated at 2022-06-12 06:56:44.488768
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    from .helpers import unset_environment_variables
    from .helpers import set_environment_variables

    unset_environment_variables(["GL_TOKEN"])
    assert Gitlab.check_build_status(None, None, None)

    token = "my_token"
    set_environment_variables({"GL_TOKEN": token})

    owner = "my_namespace"
    repo = "my_repo"
    ref = "my_ref"


# Generated at 2022-06-12 06:56:47.833599
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    status = Gitlab.check_build_status("hyperledger", "aries-framework-dotnet", "v0.7.0")
    print(status)