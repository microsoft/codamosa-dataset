

# Generated at 2022-06-12 06:50:33.463064
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class GitlabMock(Gitlab):
        def statuses_list(self) -> List[Any]:
            return [
                {"status": "success", "name": "job_1"},
                {"status": "skipped", "name": "job_2"},
                {"status": "pending", "name": "job_3"},
                {"status": "failed", "allow_failure": True, "name": "job_4"},
                {"status": "failed", "allow_failure": False, "name": "job_5"},
            ]

    # mock the statuses.list method on the GitlabMock class to return mock call data
    GitlabMock.statuses_list = GitlabMock.statuses_list.__get__(object(), GitlabMock)

    assert GitlabMock.check_build_status

# Generated at 2022-06-12 06:50:42.735147
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Setup
    test_build_status = {
        "id": 41,
        "sha": "290321e1a2b8a9d04d33c2f609b24035f0e39d0a",
        "ref": "master",
        "status": "pending",
        "name": "test",
        "stage": "test",
        "created_at": "2020-01-15T13:46:14.337Z",
        "started_at": "2020-01-15T13:46:14.337Z",
        "finished_at": None,
        "coverage": None,
        "allow_failure": True,
    }
    # Test pending status
    test_build_status["status"] = "pending"

# Generated at 2022-06-12 06:50:51.941490
# Unit test for function get_hvcs
def test_get_hvcs():
    from hvcs.util import config
    from hvcs.hvcs import Base, Github, Gitlab
    from hvcs import __version__ as hvcs_version
    # hvcs=github
    config.set("hvcs", "github")
    assert isinstance(get_hvcs(), Base)
    assert isinstance(get_hvcs(), Github)
    assert not isinstance(get_hvcs(), Gitlab)
    # hvcs=gitlab
    config.set("hvcs", "gitlab")
    assert isinstance(get_hvcs(), Base)
    assert not isinstance(get_hvcs(), Github)
    assert isinstance(get_hvcs(), Gitlab)
    # hvcs=fake_instance
    config.set("hvcs", "fake_instance")

# Generated at 2022-06-12 06:51:02.935245
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.token.return_value = "1a3hoiijhgdfh"
    Gitlab.api_url.return_value = "https://gitlab.com"
    Gitlab.session.return_value.get.return_value.text = """[{"name":"build","status":"pending"},{"name":"test","status":"pending"}]"""
    assert Gitlab.check_build_status("owner","repo","ref") == False
    Gitlab.session.return_value.get.return_value.text = """[{"name":"build","status":"success"},{"name":"test","status":"pending"}]"""
    assert Gitlab.check_build_status("owner","repo","ref") == False

# Generated at 2022-06-12 06:51:07.027663
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    gitlab_obj = Gitlab()

    # Check for invalid URL:
    res = Gitlab.check_build_status("bk-ci-pipeline/dev", "bk-bake-config-mgmt", "aa44444444444444444444444444444444444444")
    assert not res

    # Check for valid URL with success status:
    res = Gitlab.check_build_status("bk-ci-pipeline/dev", "bk-bake-config-mgmt", "a0b9beeb36abbd0ff0fbd07c14ece8fad5fad7b2")
    assert res

    # Check for valid URL with failure status:

# Generated at 2022-06-12 06:51:08.653114
# Unit test for function get_hvcs
def test_get_hvcs():
    # NOTE: This test requires a config.yaml file to be present on the project root folder
    assert get_hvcs() == Github



# Generated at 2022-06-12 06:51:12.579203
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("org", "repo", "sha1") == True
    os.environ["CI_SERVER_HOST"] = "gitlab.com"
    assert Gitlab.check_build_status("org", "repo", "sha1") == True
    os.environ["GL_TOKEN"] = "token"
    assert Gitlab.check_build_status("org", "repo", "sha1") == True



# Generated at 2022-06-12 06:51:21.863373
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    gitlab_domain = "gitlab.com"
    # No config set
    with unittest.mock.patch.dict(os.environ, {}, clear=True):
        assert Gitlab.domain() == gitlab_domain
    # Config set and env not set
    config["hvcs_domain"] = "custom-domain.org"
    with unittest.mock.patch.dict(os.environ, {}, clear=True):
        assert Gitlab.domain() == "custom-domain.org"
    # Config set and env set
    with unittest.mock.patch.dict(os.environ, {"CI_SERVER_HOST": "env-domain.org"}):
        assert Gitlab.domain() == "custom-domain.org"
    # Config not set and env set

# Generated at 2022-06-12 06:51:33.656460
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # test with a failed job and a passed job
    Gitlab.token = Mock(return_value="wadwadwd")
    gitlab.Gitlab.auth = Mock()
    gitlab.Gitlab.projects.get().commits.get().statuses.list = Mock(
        return_value=[
            {"status": "failed", "allow_failure": False, "name": "test1"},
            {"status": "success", "allow_failure": False, "name": "test2"},
        ]
    )
    assert Gitlab.check_build_status("whatever", "whatever", "whatever") is False

    # test with a passed job and a failed allowed job
    Gitlab.token = Mock(return_value="wadwadwd")
    gitlab.Gitlab.auth = Mock()
    gitlab.G

# Generated at 2022-06-12 06:51:39.398042
# Unit test for function get_hvcs
def test_get_hvcs():
    # Test correct default value
    assert type(get_hvcs()) is Github
    # Test correct value from config
    config.set("hvcs", "gitlab")
    assert type(get_hvcs()) is Gitlab
    # Test incorrect value from config
    config.set("hvcs", "test")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    # Clean up
    config.set("hvcs", "github")



# Generated at 2022-06-12 06:53:13.355895
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:53:20.702172
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.token = MagicMock(return_value="test_token")
    Gitlab.api_url = MagicMock(return_value="https://gitlab.com")
    github_requests = [
        MagicMock(return_value=MagicMock(status_code=200, json=MagicMock(return_value={
            "status": "failed",
            "allow_failure": True
        }))),
        MagicMock(return_value=MagicMock(status_code=200, json=MagicMock(return_value={
            "status": "success"
        })))
    ]
    response = MagicMock()
    response.json = MagicMock(return_value={
        "id": "job id",
        "name": "Job",
        "status": "pending"
    })


# Generated at 2022-06-12 06:53:25.146076
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "lhaas"
    repository = "test"
    ref = "b9f5b1a30f1e84e0c8657538a7094d3b525dda27"

    assert Gitlab.check_build_status(owner, repository, ref)

# Generated at 2022-06-12 06:53:35.282746
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    import pytest
    from unittest.mock import patch
    from semantic_release import hvcs

    # GIVEN
    commit_ref = "1234567890"
    owner = "owner"
    repo = "repo"
    expected_url = f"{hvcs.Github.api_url()}/repos/{owner}/{repo}/commits/{commit_ref}/status"

    # WHEN
    with patch("requests.Session.get") as mock_get:
        mock_get.return_value.json.return_value = {"state": "success"}
        result = hvcs.Github.check_build_status(owner, repo, commit_ref)

        # THEN
        assert result is True
        mock_get.assert_called_with(expected_url)

   

# Generated at 2022-06-12 06:53:43.604516
# Unit test for method domain of class Github
def test_Github_domain():
    # Test successful flow - returns the provided config value
    with config.override("hvcs_domain", "gh.com"):
        assert Github.domain() == "gh.com"

    # Test successful flow - returns the default
    with config.override("hvcs_domain", ""):
        assert Github.domain() == "github.com"

    # Test successful flow - returns the default
    with config.override("hvcs_domain", None):
        assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:53:45.830565
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    with pytest.raises(TypeError):
        assert Gitlab.check_build_status(None, None, None)



# Generated at 2022-06-12 06:53:51.451998
# Unit test for function get_hvcs
def test_get_hvcs():
    from .utils import config
    from .core import ImproperConfigurationError
    from .hvcs import Github
    from .hvcs import Gitlab
    config.set('hvcs', 'github')
    assert get_hvcs() == Github
    config.set('hvcs', 'gitlab')
    assert get_hvcs() == Gitlab
    with pytest.raises(ImproperConfigurationError):
        config.set('hvcs', 'test')
        get_hvcs()

# Generated at 2022-06-12 06:53:52.341255
# Unit test for method domain of class Github
def test_Github_domain():
    return Github.domain()

# Generated at 2022-06-12 06:53:55.348381
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    result = Gitlab.check_build_status(owner="cubicweb", repo="cubicweb", ref="a14ba5e54fa542247fa5a5bc5e23d8a5b5a5ad46")
    assert result


# Generated at 2022-06-12 06:54:00.599767
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(
        owner="I2PC", repo="i2pd", ref="647b85f7e6c4ac822e4242dda4e4a59c9e0f73c8"
    ) is False



# Generated at 2022-06-12 06:55:44.728756
# Unit test for function get_hvcs
def test_get_hvcs():
    class Gitlab(Base):
        """Gitlab helper class"""

    class Github(Base):
        """Github helper class"""

    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "foo")
    try:
        get_hvcs()
        assert False
    except Exception:
        pass



# Generated at 2022-06-12 06:55:50.968962
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    ''' unit test for method check_build_status of class Gitlab
    '''
    owner = "sarangof"
    repo = "airflow-ci-cd"
    ref = "4e4e4d9"
    expected = Gitlab.check_build_status(owner, repo, ref)
    print(expected)
    assert expected == True

# Generated at 2022-06-12 06:55:58.210539
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "frappe"
    repo = "erpnext"
    ref = "8b2d04a3bf3da9c9ec8af8bafcff98ad700a6f12"
    status = Gitlab.check_build_status(owner, repo, ref)
    assert status == True
    ref = "1cd8f29468b64d7f6a3459c933b6d8f350a1b6df"
    status = Gitlab.check_build_status(owner, repo, ref)
    assert status == False
test_Gitlab_check_build_status()

# Generated at 2022-06-12 06:56:06.628622
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockGitlab():
        def __init__(self, url: str, private_token: str) -> None:
            pass
        def auth(self) -> None: 
            pass
        class projects():
            def __init__(self, repository: str) -> None:
                pass
            class commits():
                def __init__(self, ref: str) -> None:
                    pass
                class statuses():
                    def __init__(self) -> None:
                        pass
                    def list(self):
                        class MockStatus():
                            def __init__(self, status: str, allow_failure: bool) -> None:
                                self.status = status
                                self.allow_failure = allow_failure

# Generated at 2022-06-12 06:56:08.524443
# Unit test for method api_url of class Github
def test_Github_api_url():
    ref = "github.com"
    assert ref == Github.api_url()


# Generated at 2022-06-12 06:56:11.263919
# Unit test for method auth of class Github
def test_Github_auth():
    try:
        # Test with correct input
        assert Github.auth()
        assert Github.auth() != None
    except Exception as e:
        print("test_Github_auth failed with exception: " + str(e))



# Generated at 2022-06-12 06:56:22.512258
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockGitlab:
        class MockProject:
            class MockCommits:
                class MockStatuses:
                    def list(self):
                        return [{"status": "success"}, {"status": "failed", "allow_failure": True}]
                def get(self, ref):
                    return self.MockStatuses()

        def __init__(self, url, private_token=None):
            pass

        def auth(self):
            pass

        def projects(self):
            return self.MockProject()
    Gitlab.check_build_status = MockGitlab
    assert Gitlab.check_build_status("dummy", "dummy", "ref")

    class MockGitlab:
        class MockProject:
            class MockCommits:
                class MockStatuses:
                    def list(self):
                        return

# Generated at 2022-06-12 06:56:24.828813
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    """
    Test to check build status
    """
    response = Github.check_build_status("owner", "repo", "ref")
    assert response == False



# Generated at 2022-06-12 06:56:31.626232
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = config['owner']
    repo = config['repo']
    ref = utils.exec_cmd("git rev-parse --verify HEAD")
    assert Gitlab.check_build_status(owner, repo, ref) == True

if __name__ == "__main__":
    test_Gitlab_check_build_status()

# Generated at 2022-06-12 06:56:33.258594
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

