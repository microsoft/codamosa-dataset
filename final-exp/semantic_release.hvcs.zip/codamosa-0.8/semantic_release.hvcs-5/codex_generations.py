

# Generated at 2022-06-12 06:49:27.721955
# Unit test for function get_hvcs
def test_get_hvcs():
    _fix_mime_types()

    try:
        hvcs = get_hvcs()
        assert isinstance(hvcs.domain(), str)
        assert isinstance(hvcs.api_url(), str)
    except ImproperConfigurationError:
        assert False

# Generated at 2022-06-12 06:49:35.380827
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    check_build_status_test_cases = [
        ("test_owner", "test_repo", "sha1", True),
        ("test_owner", "test_repo", "sha1", False)
    ]

    for owner, repo, ref, status in check_build_status_test_cases:
        with patch("cdflow_release.gitlab.gitlab.Gitlab") as mock_gitlab:
            mock_gitlab_class = Mock()
            mock_gitlab.return_value = mock_gitlab_class
            mock_authentication = Mock()
            mock_gitlab_class.auth.return_value = mock_authentication
            mock_projects = Mock()
            mock_gitlab_class.projects = mock_projects
            mock_project = Mock()
            mock_projects.get.return_value = mock

# Generated at 2022-06-12 06:49:40.393247
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "siemens"
    repo = "hale"
    ref = "8f764a0"
    print(Gitlab.check_build_status(owner, repo, ref))

#Unit test for method post_release_changelog of class Gitlab

# Generated at 2022-06-12 06:49:49.005924
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner = "TEST"
    repo = "TEST"
    ref = "TEST"

    gl = gitlab.Gitlab(Gitlab.api_url(), private_token=Gitlab.token())
    gl.auth()
    jobs = gl.projects.get(owner + "/" + repo).commits.get(ref).statuses.list()

    if jobs:
        for job in jobs:
            job["status"]="test"
            job["name"]="test"
            job["allow_failure"]="test"
    assert Gitlab.check_build_status(owner, repo, ref) == True



# Generated at 2022-06-12 06:50:01.023880
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test Gitlab.check_build_status where a non-pending job has failed, so it returns False.
    """
    class Gitlab__init__mock:
        """Mock for the Gitlab class constructor."""

        class Gitlab__init__mock__projects:
            """Mock for the Gitlab.projects property."""

            def __init__(self, owner: str, repo: str):
                self.owner: str = owner
                self.repo: str = repo

            class Gitlab__init__mock__projects__get:
                """Mock for the Gitlab.projects.get method."""

                def __init__(self, owner: str, repo: str):
                    self.owner: str = owner
                    self.repo: str = repo


# Generated at 2022-06-12 06:50:05.576543
# Unit test for function get_hvcs
def test_get_hvcs():
    import config, pytest
    with pytest.raises(ImproperConfigurationError) as excinfo:
        assert get_hvcs()
        config.set("hvcs", "github")
        assert get_hvcs() == Github
        config.set("hvcs", "gitlab")
        assert get_hvcs() == Gitlab
        config.set("hvcs", "invalid")
        assert get_hvcs()
    assert excinfo.value.args == ('"invalid" is not a valid option for hvcs.',)

# Generated at 2022-06-12 06:50:15.966923
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # The test is done outside of the unit test system because the method is static and
    # because it needs a Gitlab instance with a project and a pipeline.
    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen

    if sys.version_info >= (3, 3):
        import unittest.mock as mock
    else:
        import mock
    from hvcs import config_utils

    with mock.patch("hvcs.config.get", config_utils.get_side_effect({})):
        hvcs = Hvcs()
        hvcs._get_hvcs_domain = mock.MagicMock(return_value="gitlab.com")

# Generated at 2022-06-12 06:50:18.443927
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status(owner="owner", repo="repo", ref="ref") is False



# Generated at 2022-06-12 06:50:26.006849
# Unit test for function get_hvcs
def test_get_hvcs():
    assert isinstance( get_hvcs(), Base )
    assert not isinstance( get_hvcs(), Gitlab)
    assert isinstance( get_hvcs(), Github)
    config.set('hvcs', 'Github')
    assert isinstance( get_hvcs(), Github)
    assert not isinstance( get_hvcs(), Gitlab)
    config.set('hvcs', 'Gitlab')
    assert isinstance( get_hvcs(), Gitlab)
    assert not isinstance( get_hvcs(), Github)

# Generated at 2022-06-12 06:50:27.111755
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs() == Github

# Generated at 2022-06-12 06:51:57.505286
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:52:04.712836
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set_values({"hvcs": "Github"})
    g = get_hvcs()
    assert isinstance(g, Github)
    config.set_values({"hvcs": "Gitlab"})
    g = get_hvcs()
    assert isinstance(g, Gitlab)
    config.set_values({"hvcs": "Nope"})
    try:
        get_hvcs()
    except ImproperConfigurationError:
        pass



# Generated at 2022-06-12 06:52:07.280165
# Unit test for method api_url of class Github
def test_Github_api_url():
    from . import Github

    assert Github.api_url().startswith("https://api.github.com")



# Generated at 2022-06-12 06:52:15.802811
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    owner, repo, ref = "inveniosoftware", "invenio-search", "master"
    # The commit_status_id is the id of an existing commit status on the referenced commit
    commit_status_id = 13111863
    jobs = [
        {
            "id": commit_status_id,
            "status": "success",  # vaiable to test, it can also be: pending, failed, running, skipped
            "ref": "master",
            "name": "build",
            "allow_failure": False,
        }
    ]
    expected_output = True if jobs[0]["status"] == "success" else False
    # Create a mock object.
    mock_requests_response = mock.Mock(status_code=200)
    mock_requests_response.json.return_value

# Generated at 2022-06-12 06:52:20.341878
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab_check_build_status = Gitlab.check_build_status
    assert Gitlab_check_build_status(owner="Horta-Julien",repo="test-repo",ref="3a4f4efbd1cda610f46a47bf2b9d96585c1fba7d") == True


# Generated at 2022-06-12 06:52:23.061779
# Unit test for method domain of class Github
def test_Github_domain():
    # Create the object
    obj = Github()

    # Check result
    assert obj.domain == "github.com"



# Generated at 2022-06-12 06:52:27.655503
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set_config_options(
        {"hvcs": "gitlab"}
    )
    assert isinstance(get_hvcs(), Base)
    config.set_config_options(
        {"hvcs": "github"}
    )
    assert isinstance(get_hvcs(), Base)



# Generated at 2022-06-12 06:52:30.719761
# Unit test for method api_url of class Github
def test_Github_api_url():
    # setup and exercise
    github = Github()
    actual = github.api_url()

    # verify
    assert actual == "https://api.github.com"



# Generated at 2022-06-12 06:52:32.245672
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:52:36.404307
# Unit test for method auth of class Github
def test_Github_auth():
    environment = {}
    obj = Github()
    assert obj.domain() == "github.com"
    assert obj.api_url() == "https://api.github.com"
    assert type(obj.token()) is str


# Generated at 2022-06-12 06:54:26.198845
# Unit test for function get_hvcs
def test_get_hvcs():
    config._reset()
    assert get_hvcs() is Github
    assert config.get("hvcs") == "github"

    config.set("hvcs", "gitlab")
    assert get_hvcs() is Gitlab
    assert config.get("hvcs") == "gitlab"

    config.set("hvcs", "travis_ci")
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    assert config.get("hvcs") == "travis_ci"



# Generated at 2022-06-12 06:54:29.580446
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = config.get("hvcs")
    try:
        return globals()[hvcs.capitalize()]
    except KeyError:
        raise ImproperConfigurationError('"{0}" is not a valid option for hvcs.')



# Generated at 2022-06-12 06:54:32.581613
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():

    from .helpers import mock_response

    class GithubMock(Github):
        @staticmethod
        def session():
            return mock_response({"state": "success"}, 200)

    assert GithubMock.check_build_status("owner", "repo", "12345") == True



# Generated at 2022-06-12 06:54:37.462611
# Unit test for function get_hvcs
def test_get_hvcs():
    # setup test
    config.clear()
    config.set("hvcs", "gitlab")
    # run test
    result = get_hvcs()
    # assert that unit test resulted in expected
    assert result == Gitlab



# Generated at 2022-06-12 06:54:40.611113
# Unit test for method auth of class Github
def test_Github_auth():
    # Arrange
    # Act
    result = Github.auth()
    # Assert
    assert isinstance(result, TokenAuth)



# Generated at 2022-06-12 06:54:46.475259
# Unit test for method auth of class Github
def test_Github_auth():
    import pytest
    import mock

    test_global_config = {
    }

    # mock config
    with mock.patch('semantic_release.hvcs.config', test_global_config):
        # mock os.environ
        with mock.patch('semantic_release.hvcs.os.environ', {'GH_TOKEN': 'GH_TOKEN_VALUE'}):
            assert Github.auth() == TokenAuth(token='GH_TOKEN_VALUE')



# Generated at 2022-06-12 06:54:51.828972
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # Init the class to test
    gitlab_test = Gitlab()

    # Test the method
    expected = gitlab_test.check_build_status('gitlab-org', 'gitlab-foss', 'ea1a14e64067ceecac0cadc6bf7f1e0beb942d9b')
    assert expected is True


# Generated at 2022-06-12 06:54:56.323077
# Unit test for method domain of class Github
def test_Github_domain():
    """Method domain of class Github."""
    # Default test
    assert Github.domain() == "github.com"

    # Domain
    config["hvcs_domain"] = "gitlab.com"
    assert Github.domain() == "gitlab.com"

# Generated at 2022-06-12 06:55:04.518638
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    try:
        config.set("hvcs", "bitbucket")
        get_hvcs()
    except ImproperConfigurationError as e:
        assert "is not a valid option for hvcs" in str(e)
    except Exception as e:
        assert False, str(e)
    else:
        assert False, "Expected an exception to be raised"

# Generated at 2022-06-12 06:55:11.172745
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status(owner, repo, "aa38c2a9e17b429c8cd7e69b055f0c1f6749a6c8")
    assert not Gitlab.check_build_status(owner, repo, "b2d2c2a9e17b429c8cd7e69b055f0c1f6749a6c8")


# Generated at 2022-06-12 06:56:50.342678
# Unit test for method auth of class Github
def test_Github_auth():
    # Setup
    expected = TokenAuth("token")

    # Exercise
    actual = Github.auth()

    # Verify
    assert actual == expected
    # Teardown - None



# Generated at 2022-06-12 06:56:52.450221
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == os.environ.get("CI_SERVER_HOST"), "Should return Gitlab domain"



# Generated at 2022-06-12 06:56:59.428101
# Unit test for function get_hvcs
def test_get_hvcs():
    # Start with a clean configuration
    config.configuration = {}

    # Check if HVCS is Github
    # Test that no exception is raised
    config.configuration["hvcs"] = "github"
    hvcs = get_hvcs()
    assert isinstance(hvcs, Github)

    # Check if HVCS is Gitlab
    # Test that no exception is raised
    config.configuration["hvcs"] = "gitlab"
    hvcs = get_hvcs()
    assert isinstance(hvcs, Gitlab)

    # Check if configuration is not set
    # Test that ImproperConfigurationError is raised
    config.configuration = {}
    try:
        hvcs = get_hvcs()
    except ImproperConfigurationError:
        pass

    # Check if HVCS is not

# Generated at 2022-06-12 06:57:05.380511
# Unit test for function get_hvcs
def test_get_hvcs():
    c = config.get("hvcs")
    hvcs_inst = get_hvcs()
    assert isinstance(hvcs_inst, Base)
    config.set("hvcs", None)
    try:
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        pass
    finally:
        config.set("hvcs", c)

# Generated at 2022-06-12 06:57:13.837266
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "test")
    try:
        get_hvcs()
        assert False, "should not reach this line"
    except ImproperConfigurationError:
        assert True
    config.set("hvcs", None)
    try:
        get_hvcs()
        assert False, "should not reach this line"
    except ImproperConfigurationError:
        assert True



# Generated at 2022-06-12 06:57:21.708336
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """The method check the status of the pipeline on GitLab"""
    owner = "samybob1"
    repo = "command-line-parser"
    ref = "c05b34b1268f7fd53c3b3dfcffd3b5de5b9f9d50"
    result = Gitlab.check_build_status(owner, repo, ref)
    # The pipeline was successful
    assert result



# Generated at 2022-06-12 06:57:23.140429
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github
    assert github.token()
    assert github.auth()



# Generated at 2022-06-12 06:57:30.954574
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test the real method with a fake token
    assert Gitlab.check_build_status("humanitarian-apps", "pop", "6016b083fde477fddc2a24b3c28b9e6fad04d39f")

    # Mock the gitlab methods used by the real method, to check it behavior with different types of jobs
    def new_get(self, _):
        class MockTag:
            def set_release_description(self, changelog):
                return True
        return MockTag()

    def new_list(self):
        class MockJob:
            def __init__(self, status, allow_failure=True):
                self.status = status
                self.allow_failure = allow_failure


# Generated at 2022-06-12 06:57:32.694187
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    pass

# Generated at 2022-06-12 06:57:42.588733
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    class GitlabTest(Base):
        def __init__(self, domain):
            self.domain = domain
        def domain(self):
            return self.domain
    # Test local domain
    os.environ["CI_SERVER_HOST"] = "local.test"
    os.environ["hvcs_domain"] = "local.test"
    local_test = GitlabTest("local.test")
    assert GitlabTest.domain(local_test) is "local.test"
    # Test CI domain
    os.environ["CI_SERVER_HOST"] = "test.gitlab.com"
    os.environ["hvcs_domain"] = "test.gitlab.com"
    ci_test = GitlabTest("test.gitlab.com")