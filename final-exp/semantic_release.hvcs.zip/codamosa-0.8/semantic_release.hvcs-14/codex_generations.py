

# Generated at 2022-06-12 06:50:04.132576
# Unit test for method auth of class Github
def test_Github_auth():
    assert Github.auth() is not None

# Generated at 2022-06-12 06:50:06.931867
# Unit test for method __call__ of class TokenAuth
def test_TokenAuth___call__():
    r = {"headers": {}}
    t = TokenAuth("abc")
    t(r)
    assert r == {"headers": {"Authorization": "token abc"}}



# Generated at 2022-06-12 06:50:17.978676
# Unit test for method check_build_status of class Gitlab

# Generated at 2022-06-12 06:50:24.484616
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs().domain() == Github.domain()
    config.set("hvcs", "gitlab")
    assert get_hvcs().domain() == Gitlab.domain()
    config.set("hvcs", "github")
    assert get_hvcs().domain() == Github.domain()

    with pytest.raises(ImproperConfigurationError):
        config.set("hvcs", "foo")
        get_hvcs()


# Generated at 2022-06-12 06:50:26.910307
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    response = Github.check_build_status("owner", "repo", "ref")
    assert isinstance(response, bool)



# Generated at 2022-06-12 06:50:30.526672
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        config.set("hvcs", "Unknown")
        get_hvcs()
        config.set("hvcs", None)

# Unit tests for class Base

# Generated at 2022-06-12 06:50:35.566101
# Unit test for method api_url of class Github
def test_Github_api_url():    
    assert Github.api_url() == "https://api.github.com"



# Generated at 2022-06-12 06:50:44.361949
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Arrange
    import sys
    if sys.version_info[0] < 3:
        return "No Unit Test"

    import unittest
    import unittest.mock

    class TestGithub(Github):
        @staticmethod
        def domain():
            return "github.com"

        @staticmethod
        def api_url():
            return "https://api.github.com"

    class TestCase(unittest.TestCase):
        @unittest.mock.patch("semantic_release.hvcs.Github.session")
        def test_Github_check_build_status(self, mock_session):
            # Arrange
            import requests
            mock_session_obj = unittest.mock.Mock()

# Generated at 2022-06-12 06:50:50.742390
# Unit test for function get_hvcs
def test_get_hvcs():
    config.hvcs = None
    try:
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        pass

    config.hvcs = "github"
    assert isinstance(get_hvcs(), Github)

    config.hvcs = "gitlab"
    assert isinstance(get_hvcs(), Gitlab)

    try:
        config.hvcs = "unsupported"
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        pass

# Generated at 2022-06-12 06:51:02.283400
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    def mock_get_request(*args, **kwargs):
        class MockResponse:
            def __init__(self, json_data, status_code):
                self.json_data = json_data
                self.status_code = status_code

            def json(self):
                return self.json_data
        test_data = []
        test_data.append({"id": "abcabcabcabcabcabcabcabcabcabcabcabcabca",
                          "name": "unittest_name_1","allow_failure": True,
                          "status": "success"})

# Generated at 2022-06-12 06:53:49.853242
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test case for method check_build_status of class Gitlab
    """
    assert Gitlab.check_build_status("Hops", "hops-util-py", "master") == True


# Generated at 2022-06-12 06:53:51.079747
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github()
    assert github.auth() is None

# Generated at 2022-06-12 06:53:54.300725
# Unit test for method auth of class Github
def test_Github_auth():
    from .settings import config

    config.initialize({
        "hvcs_domain": "",
    })

    os.environ["GH_TOKEN"] = "foo"

    g = Github()

    assert g.auth() == TokenAuth("foo")



# Generated at 2022-06-12 06:53:57.345088
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs
    """
    with mock.patch("release_exporter.utils.config", return_value="github"):
        assert get_hvcs() == Github
    with mock.patch("release_exporter.utils.config", return_value="gitlab"):
        assert get_hvcs() == Gitlab

# Generated at 2022-06-12 06:54:06.535760
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        domain = Gitlab.domain()
        token = Gitlab.token()
        check_status = Gitlab.check_build_status(owner = "kvj", repo = "test", ref = "06d6e71df22b9fb9f7d315e801f93a7fadfa0ad8")
        if check_status:
            logger.debug("test_Gitlab_check_build_status: check_build_status test passed")
        else:
            logger.debug("test_Gitlab_check_build_status: check_build_status test failed")
    except Exception as e:
        logger.debug("test_Gitlab_check_build_status: check_build_status test failed")
        logger.error(e)


# Generated at 2022-06-12 06:54:10.732185
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    assert(hvcs.__name__ == "Github")
    assert(hvcs.domain() == "github.com")


# Generated at 2022-06-12 06:54:12.618416
# Unit test for function get_hvcs
def test_get_hvcs():
    assert get_hvcs()


# Functions for releasing a new version

# Generated at 2022-06-12 06:54:16.551362
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    os.environ['GL_TOKEN'] = 'test'
    out = Gitlab.check_build_status('YottaDB', 'ydb-common-master', 'test')
    assert out == True



# Generated at 2022-06-12 06:54:18.850374
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    git = Gitlab()
    status = git.check_build_status("0.10.1", "job", "0.10.1")
    print(status)



# Generated at 2022-06-12 06:54:20.736146
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:56:21.453561
# Unit test for method auth of class Github
def test_Github_auth():
    github = Github()
    assert github.auth() != None


# Generated at 2022-06-12 06:56:22.431474
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"

# Generated at 2022-06-12 06:56:25.088864
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    # Test 1
    response = Github.check_build_status("test-owner", "test-repo", "test-ref")
    assert response == False
# Unit for method create_release of class Github

# Generated at 2022-06-12 06:56:33.474130
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    #TODO: Use test fixtures in order to avoid
    # the need to edit this method to test
    # different scenarios
    owner, repo, ref = "user1", "repo1", "2b866a036418d4b4a4bcccdd5e9e67b08c59ae0d"
    gitlab = Gitlab()
    assert gitlab.check_build_status(owner, repo, ref) == None


# Generated at 2022-06-12 06:56:41.579092
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", 'gitlab')
    assert isinstance(get_hvcs(), Gitlab)
    config.set("hvcs", 'github')
    assert isinstance(get_hvcs(), Github)
    config.set("hvcs", 'xx')
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    config.set("hvcs", None)
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-12 06:56:47.239683
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"
    os.environ["HVCS_DOMAIN"] = "github.com"
    assert Github.api_url() == "https://api.github.com"
    os.environ["HVCS_DOMAIN"] = "api.github.com"
    assert Github.api_url() == "https://api.github.com"
    os.environ["HVCS_DOMAIN"] = "my.github"
    assert Github.api_url() == "https://my.github"
    os.environ["HVCS_DOMAIN"] = "api.my.github"
    assert Github.api_url() == "https://api.my.github"



# Generated at 2022-06-12 06:56:54.221614
# Unit test for method api_url of class Github
def test_Github_api_url():
    # tests the case where there is a domain
    domain = "https://custom.github.com"
    config["hvcs_domain"] = domain
    api_url = Github.api_url()
    config["hvcs_domain"] = None

    assert api_url == domain
    # tests the case where there is not a valid domain
    domain = "invalid"
    config["hvcs_domain"] = domain

    api_url = Github.api_url()
    config["hvcs_domain"] = None

    assert api_url == "https://api.invalid"



# Generated at 2022-06-12 06:57:02.056913
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    # Mock the method post_event_to_zulip
    @patch("zulip_bots.bots.release_notes.ReleaseNotesHandler.post_event_to_zulip")
    def test(self, mock_method):
        # Patch the method check_build_status of class Gitlab
        with patch("zulip_bots.bots.release_notes.Gitlab.check_build_status") as mocked_method:
            mocked_method.return_value = True
            msg = {"content": "@**release_notes** foo/bar-bot master"}
            release_notes_bot = ReleaseNotesHandler(None, None, None, None, None)
            # Check if the message is handled correctly
            release_notes_bot.handle_message(msg, None)
            self.assertTrue(mocked_method.called)
            self

# Generated at 2022-06-12 06:57:06.053475
# Unit test for function get_hvcs
def test_get_hvcs():
    import pytest
    from packit_service.config import Config
    Config.override_configuration(
        {
            "hvcs": "foo",
        },
    )
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()



# Generated at 2022-06-12 06:57:13.495704
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # success
    Gitlab.check_build_status('matrix-bot', 'matrix-bot', 'cb211a48fa9a032fed1d8a1a194b47f58d45f77c')
    # fail
    Gitlab.check_build_status('matrix-bot', 'matrix-bot', '04d3b3c8a8e2c1d967f9b3c3e6ccaa55aeb0d85e')

 