

# Generated at 2022-06-12 06:49:09.558861
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    '''
    Testing Gitlab.domain
    '''
    # this test is not possible since we don't have a config file
    pass

# Generated at 2022-06-12 06:49:12.653478
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("HBPNeuromorphicPlatform", "PyNN", "f971b2c6f7590b0c6bc8a8a5025b6aa80866a86d")



# Generated at 2022-06-12 06:49:17.083255
# Unit test for function get_hvcs
def test_get_hvcs():
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab

    config.set("hvcs", "github")
    assert get_hvcs() == Github

    config.set("hvcs", "gitlab")



# Generated at 2022-06-12 06:49:27.917144
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Test case: all jobs are successful
    conf = {
        "hvcs_domain": "gitlab.com",
        "verbose": 0
    }
    config.update(conf)
    Gitlab.token.__func__.cache_clear()
    Gitlab.domain.__func__.cache_clear()
    assert Gitlab.check_build_status("camptocamp", "puppet-puppet", "921439d3e3dbbb6a3a6d65d6feab9c9f9b9efb10") == True
    assert Gitlab.check_build_status("camptocamp", "puppet-postgresql", "942a0a1fe99f22c3454ecb1c2f4d4d4b8f9eae9a") == True
    assert Gitlab

# Generated at 2022-06-12 06:49:31.978279
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        get_hvcs()
    except ImproperConfigurationError:
        return

    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab
    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "test")
    try:
        get_hvcs()
        assert False, "Should raise ImproperConfigurationError"
    except ImproperConfigurationError:
        pass

    # Reset config
    config.set("hvcs", None)
# Unit tests for class HvcsBase

# Generated at 2022-06-12 06:49:34.332609
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert (Gitlab.domain() == "gitlab.com")

# Generated at 2022-06-12 06:49:35.354109
# Unit test for method auth of class Github
def test_Github_auth():
    # Can't create abstract class, don't know how to test
    pass


# Generated at 2022-06-12 06:49:40.775853
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    status = Gitlab.check_build_status("CSCS-SIL","hpc-test", "6b27f2a6e0c0e8eeb1fdc294dff5b5c5c5e5e5f5")
    assert status == 'success'

# Generated at 2022-06-12 06:49:42.592499
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    assert Gitlab.check_build_status("toto", "toto", "toto") == True


# Generated at 2022-06-12 06:49:45.945505
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.domain()
    Gitlab.api_url()
    Gitlab.token()
    Gitlab.check_build_status("owner","repo","ref")
    assert True



# Generated at 2022-06-12 06:50:47.143661
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test method check_build_status of class Gitlab"""
    class_Gitlab = Gitlab()
    result = class_Gitlab.check_build_status()
    assert result == 'Passed'

# Generated at 2022-06-12 06:50:48.391569
# Unit test for method auth of class Github
def test_Github_auth():
    token = "token"
    auth = TokenAuth(token)
    assert Github.auth() == auth


# Generated at 2022-06-12 06:50:57.739536
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    fake_data = {
        "status": "success",
        "created_at": "2016-03-17T12:22:30.306Z",
        "updated_at": "2016-03-17T12:22:30.306Z",
        "name": "rspec:other",
        "target_url": "http://gitlab.local/root/example-project-1/pipelines/1",
        "description": "",
        "allow_failure": False,
    }
    Gitlab.check_build_status("ns", "repo", "ref")

# Generated at 2022-06-12 06:51:06.040495
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    from unittest.mock import patch, call

    # For testing purposes, we patch builtins.open to log the content of file opened

# Generated at 2022-06-12 06:51:06.953513
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    gl = Gitlab()
    assert True



# Generated at 2022-06-12 06:51:09.684658
# Unit test for function get_hvcs
def test_get_hvcs():
    """
    Test get_hvcs function
    """
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()

# Generated at 2022-06-12 06:51:15.026589
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """Test method check_build_status of class Gitlab
    """
    class MockResponse:
        def __init__(self, status_code, content):
            self.status_code = status_code
            self.content = content

    class FakeGitlab:
        def __init__(self, *args):
            pass

        def auth(self):
            pass

        def projects(self):
            return self

        def statuses(self):
            return self

        def list(self):
            return [{"status": "success"}]

    class FakeGitlab2:
        def __init__(self, *args):
            pass

        def auth(self):
            pass

        def projects(self):
            return self

        def statuses(self):
            return self


# Generated at 2022-06-12 06:51:16.260095
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == "https://api.github.com"

# Generated at 2022-06-12 06:51:17.974148
# Unit test for method auth of class Github
def test_Github_auth():
    object_ = Github()
    assert object_.auth() == None


# Generated at 2022-06-12 06:51:29.898488
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():

    @mock.patch("k8s_infra.app.hvcs.gitlab.Gitlab.auth")
    @mock.patch("k8s_infra.app.hvcs.gitlab.Gitlab.projects")
    @mock.patch("k8s_infra.app.hvcs.gitlab.Gitlab.__init__")
    def check_build_status(
            mock_gitlab_init,
            mock_gitlab_projects,
            mock_gitlab_auth,
            project: str,
            sha: str,
            status: list = ["success", "skipped"],
    ) -> bool:
        mock_gitlab_init.return_value = None
        mock_gitlab_auth.return_value = None

        # mock the statuses
        mock_stat

# Generated at 2022-06-12 06:52:36.681935
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-12 06:52:45.367799
# Unit test for function get_hvcs
def test_get_hvcs():
    with patch.dict(source.config.config, {"hvcs": "github"}):
        assert source.builds.get_hvcs() == source.builds.Github
    with patch.dict(source.config.config, {"hvcs": "gitlab"}):
        assert source.builds.get_hvcs() == source.builds.Gitlab
    with patch.dict(source.config.config, {"hvcs": "fake"}):
        with pytest.raises(source.builds.ImproperConfigurationError):
            source.builds.get_hvcs()

if __name__ == "__main__":
    main()

# Generated at 2022-06-12 06:52:50.145521
# Unit test for function get_hvcs
def test_get_hvcs():
    """Unit test for function get_hvcs"""
    os.environ["HOME"] = "."
    os.environ["SKIP_CHANGELOG"] = "false"
    Config("tests/.chglog.yml")
    assert get_hvcs() == Github



# Generated at 2022-06-12 06:52:51.563164
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"

# Generated at 2022-06-12 06:53:00.247113
# Unit test for function get_hvcs
def test_get_hvcs():
    config.reset()
    config.set_configuration_file(None)
    assert get_hvcs() == Github

    config.reset()
    config.set_configuration_file(None)
    config.set('hvcs', 'gitlab')
    assert get_hvcs() == Gitlab

    config.reset()
    config.set_configuration_file(None)
    config.set('hvcs', 'whatever')
    try:
        get_hvcs()
        assert False
    except ImproperConfigurationError:
        assert True
    except Exception:
        assert False

# Generated at 2022-06-12 06:53:08.031957
# Unit test for method auth of class Github
def test_Github_auth():
    # Verify that the method auth of class Github raises an Exception when no token is defined
    # and returns a TokenAuth object when a token is defined

    github = Github()
    if github.token():
        auth = github.auth()
        assert (
            type(auth) == TokenAuth
        ), "The function auth() of the class Github returns {auth} instead of {expect}".format(
            auth=type(auth), expect=TokenAuth
        )
    else:
        try:
            github.auth()
        except Exception as e:
            assert type(e) == ImproperConfigurationError, "The function auth() of the class Github raises {expect} instead of ImproperConfigurationError".format(
                expect=type(e)
            )



# Generated at 2022-06-12 06:53:13.016785
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()
    assert get_hvcs() == Github

    config.set("hvcs", "github")
    assert get_hvcs() == Github
    config.set("hvcs", "gitlab")
    assert get_hvcs() == Gitlab



# Generated at 2022-06-12 06:53:17.591684
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    try:
        os.environ["CI_SERVER_HOST"] = "gitlab.com"
        os.environ["GL_TOKEN"] = "12345"
        Gitlab.check_build_status("patches_test", "patches_test", "f3251e63df017")
    except Exception:
        assert False

# Generated at 2022-06-12 06:53:22.097452
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
  
  # Result of method check_build_status must be a boolean
  assert isinstance(Gitlab.check_build_status("group_name", "repo_name", "commit_sha1"), bool) == True

# Generated at 2022-06-12 06:53:28.308465
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    # Create gitlab object
    gl = gitlab.Gitlab("https://gitlab.com", private_token="a")

    # Make some test calls
    print(gl.auth())
    print(gl.projects.search("anaconda"))

    assert Gitlab.check_build_status(
        'anaconda', 'conda-forge.github.io', '4ff4bbed4ab4c59d5f8c5ea5f5c03f5d9d5aa3c1') == True
    assert Gitlab.check_build_status(
        'anaconda', 'conda-forge.github.io', 'not_a_commit_id') == False

# Generated at 2022-06-12 06:55:29.841230
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"
    os.environ["HVCS_DOMAIN"] = "gitlab.com"
    assert Github.domain() == "gitlab.com"
    del os.environ["HVCS_DOMAIN"]


# Generated at 2022-06-12 06:55:31.590219
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    """Unit test for method check_build_status of class Github"""
    pass



# Generated at 2022-06-12 06:55:37.742169
# Unit test for function get_hvcs
def test_get_hvcs():
    try:
        get_hvcs()
    except ImproperConfigurationError as e:
        logger.error(e)
    # try:
    #     get_hvcs("test")
    # except ImproperConfigurationError as e:
    #     logger.error(e)



# Generated at 2022-06-12 06:55:43.244947
# Unit test for function get_hvcs
def test_get_hvcs():
    logger.info("Testing: get_hvcs")
    try:
        assert globals()[get_hvcs().__name__] is get_hvcs()
    except AssertionError as e:
        logger.error("Test failed: get_hvcs")
        raise e
    logger.info("Test succeeded: get_hvcs")



# Generated at 2022-06-12 06:55:45.101092
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("mygroup/myproject", "myrepo", "abcd1234")

# Generated at 2022-06-12 06:55:55.590244
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    import gitlab
    import pytest
    from Jumpscale.clients.gitlab.GitlabClient import GitlabClient

    MODEL_URL = "development/test"
    REF = "abcd1111"
    REF_SUCCESS = "abcd1112"
    REF_FAILED = "abcd1113"
    REF_FINAL = "abcd1114"

    def mock_get_project(self, project_id):
        class MockProject:
            def __init__(self):
                self._id = None

            @property
            def id(self):
                return self._id

        project = MockProject()
        if project_id == MODEL_URL:
            project._id = "1"

# Generated at 2022-06-12 06:55:57.515523
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == config.get("hvcs_domain")

# Generated at 2022-06-12 06:56:06.303752
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    class MockResponse:
        def __init__(self, status, json_data):
            self.status = status
            self.json_data = json_data

        def json(self):
            return self.json_data

    class MockGet:
        def __init__(self, status, json_data):
            self.status_code = status
            self.response = MockResponse(status, json_data)

    class MockGitlab:
        def __init__(self, user, token):
            self.user = user
            self.token = token

        def auth(self):
            pass

        def projects(self):
            return MockProjects()

    class MockProjects:
        def get(self, name):
            return MockProject(name)


# Generated at 2022-06-12 06:56:13.903689
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    """
    Test method check_build_status of class Gitlab
    """
    owner = "owner"
    repo = "repo"
    ref = "ref"
    pipeline_in_progress = [
        {
            "name": "job_name",
            "status": "pending",
            "ref": {"name": ref},
            "project": {"path_with_namespace": f"{owner}/{repo}"},
        }
    ]
    pipeline_failed = [
        {
            "name": "job_name",
            "status": "failed",
            "ref": {"name": ref},
            "project": {"path_with_namespace": f"{owner}/{repo}"},
        }
    ]

# Generated at 2022-06-12 06:56:18.072389
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status(owner="Hvass-Labs", repo="TensorFlow-Tutorials", ref="38d3c3b7a51fbea8e7e1d6c5b6ec84bb6cde8822")

