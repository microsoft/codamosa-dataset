

# Generated at 2022-06-12 06:51:59.622194
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    import requests_mock
    import unittest

    class MyTestCase(unittest.TestCase):
        "Test the Github helper class"

        def test_check_build_status_success(self):
            "Test build status check for a successful build"
            with requests_mock.Mocker() as m:
                # Set the return value for a successful build
                m.get(
                    "https://api.github.com/repos/User/repo/commits/12345/status",
                    json={"state": "success"},
                )
                # Check the Github build status
                status = Github.check_build_status("User", "repo", "12345")
                self.assertTrue(status)


# Generated at 2022-06-12 06:52:04.116676
# Unit test for method auth of class Github
def test_Github_auth():
    expected_result = Github.token()
    result = Github.auth()
    assert (
        result == expected_result
    ), f"Incorrect result: {result}, expected: {expected_result}"



# Generated at 2022-06-12 06:52:06.216600
# Unit test for method api_url of class Github
def test_Github_api_url():
    assert Github.api_url() == 'https://api.github.com'


# Generated at 2022-06-12 06:52:08.067554
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    assert Github.check_build_status("vsoch","dockerfiles", "master") == True





# Generated at 2022-06-12 06:52:13.721057
# Unit test for function get_hvcs
def test_get_hvcs():
    with pytest.raises(ImproperConfigurationError) as e:
        get_hvcs()
    assert str(e.value) == '"None" is not a valid option for hvcs.'
    with mock.patch.dict(config, {"hvcs": "Github"}, clear=True):
        assert isinstance(get_hvcs(), Github)
    with mock.patch.dict(config, {"hvcs": "Gitlab"}, clear=True):
        assert isinstance(get_hvcs(), Gitlab)

# Generated at 2022-06-12 06:52:16.252057
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    Gitlab.check_build_status("louiz","gitlab-test-repo","edc7bfc3d3f8bab6b8d8f9a9acdeb2aace273254")



# Generated at 2022-06-12 06:52:18.407566
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:52:22.487741
# Unit test for function get_hvcs
def test_get_hvcs():
    hvcs = get_hvcs()
    assert isinstance(hvcs, Github) or isinstance(hvcs, Gitlab)

# Generated at 2022-06-12 06:52:23.796407
# Unit test for method domain of class Github
def test_Github_domain():
    assert Github.domain() == "github.com"



# Generated at 2022-06-12 06:52:35.116228
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    @mock.patch("plotly_gateway.providers.Gitlab.token", return_value="test")
    @mock.patch("plotly_gateway.providers.Gitlab.api_url", return_value="test")
    @mock.patch("plotly_gateway.providers.gitlab.Gitlab")
    def test_job_failure(mock_gitlab, mock_api_url, mock_token):
        mock_gitlab_instance = mock.MagicMock()
        mock_gitlab_instance.auth.return_value = None
        mock_gitlab_instance.projects.get().statuses.list.return_value = [
            {"status": "failed", "allow_failure": False, "name": "test"}
        ]

# Generated at 2022-06-12 06:57:16.776083
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    from config import Config
    import os

    Config.set("hvcs_domain", os.environ["HVCS_DOMAIN"])
    Config.set("token", os.environ["HVCS_TOKEN"])

    # Test passing use case
    assert Gitlab.check_build_status("robotframework", "robotframework",
                                     "1cebc4d9bf4a4f0f758008a8ef7a59dbd6c406af")

    # Test failing use case - job failed
    assert not Gitlab.check_build_status("robotframework", "robotframework",
                                         "c5f6e5e6c5a03f313e8b82b2fe2d57fde7fd5b6d")

    # Test failing use case - job pending

# Generated at 2022-06-12 06:57:20.844890
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    os.environ['CI_SERVER_HOST'] = 'gitlab.com'
    assert Gitlab.domain() == 'gitlab.com'


# Generated at 2022-06-12 06:57:22.721471
# Unit test for method domain of class Gitlab
def test_Gitlab_domain():
    assert Gitlab.domain() == "gitlab.com"


# Generated at 2022-06-12 06:57:29.742386
# Unit test for function get_hvcs
def test_get_hvcs():
    with patch("changelog_generator.config.get", new=MagicMock(return_value = "github")):
        assert get_hvcs() == Github
    with patch("changelog_generator.config.get", new=MagicMock(return_value = "gitlab")):
        assert get_hvcs() == Gitlab
    with patch("changelog_generator.config.get", new=MagicMock(return_value = "other")):
        try:
            get_hvcs()
        except ImproperConfigurationError as e:
            assert str(e) == '"other" is not a valid option for hvcs.'

# Generated at 2022-06-12 06:57:31.544274
# Unit test for method check_build_status of class Gitlab
def test_Gitlab_check_build_status():
    pass


# Generated at 2022-06-12 06:57:33.917540
# Unit test for method check_build_status of class Github
def test_Github_check_build_status():
    Github.check_build_status("owner", "repo", "ref")


# Generated at 2022-06-12 06:57:41.635922
# Unit test for function get_hvcs
def test_get_hvcs():
    # Setup
    os.environ["HVCS"] = ""

    # Test Gitlab
    os.environ["HVCS"] = "gitlab"
    assert "Gitlab" in str(get_hvcs.__name__)

    # Test Github
    os.environ["HVCS"] = "github"
    assert "Github" in str(get_hvcs.__name__)

    # Test ImproperConfigurationError
    os.environ["HVCS"] = "Invalid"
    with pytest.raises(ImproperConfigurationError):
        get_hvcs()


# Generated at 2022-06-12 06:57:46.698361
# Unit test for method auth of class Github
def test_Github_auth():
    Github.token.__func__.__globals__["os"].environ["GH_TOKEN"] = "foo"
    assert Github.auth() == TokenAuth("foo")

    Github.token.__func__.__globals__["os"].environ["GH_TOKEN"] = ""
    assert Github.auth() is None



# Generated at 2022-06-12 06:57:53.715418
# Unit test for function get_hvcs
def test_get_hvcs():
    from json import loads
    from os import environ, path

    from .config import Config

    environ["GH_TOKEN"] = "token"
    environ["CI_SERVER_HOST"] = "gitlab.com"
    Config.load(loads('{"hvcs": "Github"}'))
    assert get_hvcs() is Github

    environ["GH_TOKEN"] = "token"
    environ["CI_SERVER_HOST"] = "gitlab.com"
    Config.load(loads('{"hvcs_domain": "github.com", "hvcs": "Gitlab"}'))
    assert get_hvcs() is Gitlab

    assert get_hvcs() is Github

