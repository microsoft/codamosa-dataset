

# Generated at 2022-06-18 12:34:51.115621
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON
    content = '{"a": 1, "b": 2}'
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_json(content, validator)
    assert value == {"a": 1, "b": 2}
    assert error_messages == []

    # Test invalid JSON
    content = '{"a": 1, "b": 2'
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_json(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "parse_error"
    assert error_messages[0].position.line_no == 1

# Generated at 2022-06-18 12:35:01.692814
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "John Doe", "age": "42"}'
    class Person(Schema):
        name = String()
        age = Integer()
    value, error_messages = validate_json(content, Person)
    assert value == {"name": "John Doe", "age": 42}
    assert error_messages == []

    content = '{"name": "John Doe", "age": "forty-two"}'
    value, error_messages = validate_json(content, Person)
    assert value == {"name": "John Doe", "age": "forty-two"}

# Generated at 2022-06-18 12:35:09.839868
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:21.101646
# Unit test for function validate_json
def test_validate_json():
    # Test that validate_json returns a two-tuple of (value, error_messages)
    # when given valid JSON.
    json_string = '{"name": "John Doe"}'
    schema = Schema({"name": str})
    value, error_messages = validate_json(json_string, schema)
    assert value == {"name": "John Doe"}
    assert error_messages == []

    # Test that validate_json returns a two-tuple of (value, error_messages)
    # when given invalid JSON.
    json_string = '{"name": "John Doe"}'
    schema = Schema({"name": int})
    value, error_messages = validate_json(json_string, schema)
    assert value == {"name": "John Doe"}
    assert len(error_messages) == 1


# Generated at 2022-06-18 12:35:32.945342
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 15, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:35:38.966285
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    content = '{"name": "John"}'
    value, errors = validate_json(content, Person)
    assert value == {"name": "John"}
    assert errors == []

    content = '{"name": "John", "age": "30"}'
    value, errors = validate_json(content, Person)
    assert value == {"name": "John", "age": "30"}
    assert len(errors) == 1
    assert errors[0].code == "unknown_field"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 12

    content = '{"name": "John", "age": "30"}'
    value,

# Generated at 2022-06-18 12:35:43.601156
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )



# Generated at 2022-06-18 12:35:55.754544
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function
    """
    # Test for valid json
    content = '{"name": "John", "age": 30, "city": "New York"}'
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
            "city": Field(type="string"),
        }
    )
    value, error_messages = validate_json(content, validator)
    assert value == {
        "name": "John",
        "age": 30,
        "city": "New York",
    }
    assert error_messages == []

    # Test for invalid json
    content = '{"name": "John", "age": 30, "city": "New York'

# Generated at 2022-06-18 12:36:01.877162
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "John"}'
    validator = Schema({"name": str})
    value, error_messages = validate_json(content, validator)
    assert value == {"name": "John"}
    assert error_messages == []

    content = '{"name": "John", "age": "20"}'
    validator = Schema({"name": str})
    value, error_messages = validate_json(content, validator)
    assert value == {"name": "John"}
    assert error_messages == [
        Message(
            text="Additional properties are not allowed ('age' was unexpected)",
            code="additional_properties",
            position=Position(column_no=15, line_no=1, char_index=14),
        )
    ]


# Generated at 2022-06-18 12:36:11.492946
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test for invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test for valid JSON

# Generated at 2022-06-18 12:36:31.527153
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': ScalarToken('bar', 2, 9, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken({'foo': ScalarToken('bar', 2, 9, '{"foo": "bar", "baz": "qux"}'), 'baz': ScalarToken('qux', 15, 22, '{"foo": "bar", "baz": "qux"}')}, 0, 26, '{"foo": "bar", "baz": "qux"}')

# Generated at 2022-06-18 12:36:39.993988
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({"a": ScalarToken(1, 3, 3, '{"a":1}')}, 0, 5, '{"a":1}')
    assert tokenize_json('[1,2,3]') == ListToken([ScalarToken(1, 1, 1, '[1,2,3]'), ScalarToken(2, 3, 3, '[1,2,3]'), ScalarToken(3, 5, 5, '[1,2,3]')], 0, 7, '[1,2,3]')

# Generated at 2022-06-18 12:36:43.958329
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )



# Generated at 2022-06-18 12:36:54.277356
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': 'b', 'c': 'd'}, 0, 17, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({'a': 'b', 'c': 'd', 'e': 'f'}, 0, 25, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:37:06.113967
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )

# Generated at 2022-06-18 12:37:17.761158
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')

# Generated at 2022-06-18 12:37:24.135050
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 12, 13, '{"a": 1, "b": 2}'): ScalarToken(
                2, 18, 19, '{"a": 1, "b": 2}'
            ),
        },
        0,
        20,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:37:34.863256
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:46.647806
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:37:58.138807
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": [2, 3]}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 0
    assert token.end == 18
    assert token.content == '{"a": 1, "b": [2, 3]}'

    token = tokenize_json('{"a": 1, "b": [2, 3]}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 0
    assert token.end == 18
    assert token.content == '{"a": 1, "b": [2, 3]}'


# Generated at 2022-06-18 12:38:17.127353
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end

# Generated at 2022-06-18 12:38:25.406455
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json(b'{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json(b'{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:38:36.155200
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.get_position(0) == Position(line_no=1, column_no=1, char_index=0)
    assert token.get_position(1) == Position(line_no=1, column_no=2, char_index=1)
    assert token.get_position(2) == Position(line_no=1, column_no=3, char_index=2)

# Generated at 2022-06-18 12:38:47.417874
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:58.132606
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("42") == ScalarToken(42, 0, 2, "42")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 4, "3.14")

# Generated at 2022-06-18 12:39:09.592633
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            "a": ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'),
            "b": ScalarToken(2, 11, 12, '{"a": 1, "b": 2}'),
        },
        0,
        16,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:39:21.098676
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:25.426454
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:39:33.180888
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )


# Generated at 2022-06-18 12:39:43.931079
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

# Generated at 2022-06-18 12:39:57.593111
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].type == "list"

# Generated at 2022-06-18 12:40:09.369326
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:19.517438
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json returns a token
    assert isinstance(tokenize_json('{"a": 1}'), Token)
    # Test that tokenize_json returns a token with the correct content
    assert tokenize_json('{"a": 1}').content == '{"a": 1}'
    # Test that tokenize_json returns a token with the correct start position
    assert tokenize_json('{"a": 1}').start == 0
    # Test that tokenize_json returns a token with the correct end position
    assert tokenize_json('{"a": 1}').end == 7
    # Test that tokenize_json returns a token with the correct value
    assert tokenize_json('{"a": 1}').value == {"a": 1}
    # Test that tokenize_json returns a token with the correct type

# Generated at 2022-06-18 12:40:26.890589
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 21
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 20
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end

# Generated at 2022-06-18 12:40:37.705522
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test valid JSON

# Generated at 2022-06-18 12:40:41.338313
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:40:50.368961
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:41:01.910138
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:41:12.669730
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:41:20.947658
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(
                1, 6, 7, '{"a": 1}'
            )
        },
        0,
        8,
        '{"a": 1}',
    )
    assert tokenize_json('[1, 2, 3]') == ListToken(
        [
            ScalarToken(1, 1, 2, '[1, 2, 3]'),
            ScalarToken(2, 4, 5, '[1, 2, 3]'),
            ScalarToken(3, 7, 8, '[1, 2, 3]'),
        ],
        0,
        9,
        '[1, 2, 3]',
    )
    assert tokenize_

# Generated at 2022-06-18 12:41:48.924451
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        8,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:41:59.656902
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
   

# Generated at 2022-06-18 12:42:10.610340
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:42:20.514940
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:42:30.322952
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"a": "b"}'
    token = tokenize_json(json_string)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == len(json_string) - 1
    assert token.content == json_string
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == json_string
    assert token.children[1].value == "b"
    assert token.children[1].start == 6
    assert token.children[1].end == 7
    assert token.children[1].content == json_string


# Generated at 2022-06-18 12:42:38.808999
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        assert False

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 1
    else:
        assert False

    # Test valid

# Generated at 2022-06-18 12:42:48.231749
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 13, '{"a": [1, 2]}')}, 0, 16, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:56.153525
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        10,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:43:07.015916
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": 1}') == DictToken({'a': 1}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': [1, 2, 3]}, 0, 15, '{"a": [1, 2, 3]}')
    assert tokenize_json('{"a": {"b": "c"}}') == DictToken({'a': {'b': 'c'}}, 0, 15, '{"a": {"b": "c"}}')

# Generated at 2022-06-18 12:43:14.057634
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:43:48.685089
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 5, '[1, 2]')
    assert tokenize_json('{"a": {"b": 1}}') == DictToken({'a': DictToken({'b': ScalarToken(1, 7, 8, '{"a": {"b": 1}}')}, 2, 12, '{"a": {"b": 1}}')}, 0, 14, '{"a": {"b": 1}}')
    assert tokenize

# Generated at 2022-06-18 12:43:55.874610
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:44:06.147735
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:44:18.423076
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 5, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 14, 14, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:44:26.573697
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 2, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": ScalarToken("b", 2, 5, '{"a": "b", "c": "d"}'), "c": ScalarToken("d", 11, 14, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:44:31.210353
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

