

# Generated at 2022-06-18 12:34:52.716578
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        10,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:35:00.629096
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert isinstance(token.value["a"], ScalarToken)
    assert token.value["a"].value == 1
    assert token.value["a"].start == 5
    assert token.value["a"].end == 6
    assert token.value["a"].content == content
    assert token.start == 0
    assert token.end == 8
    assert token.content == content


# Generated at 2022-06-18 12:35:09.028169
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 19
    assert token.end_position.char_index == 18
    assert token.content == content

    content = '{"a": "b", "c": "d"}\n'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line

# Generated at 2022-06-18 12:35:20.275830
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 2, 9, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken(
        {
            "foo": ScalarToken("bar", 2, 9, '{"foo": "bar", "baz": "qux"}'),
            "baz": ScalarToken("qux", 14, 21, '{"foo": "bar", "baz": "qux"}'),
        },
        0,
        25,
        '{"foo": "bar", "baz": "qux"}',
    )


# Generated at 2022-06-18 12:35:26.231215
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"

    content = '[1, 2, 3]'
    token = tokenize_json(content)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "list"

    content = '"test"'
    token = tokenize_json(content)
    assert token.value == "test"
    assert token.start == 0

# Generated at 2022-06-18 12:35:36.558395
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:35:41.077046
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 0, 1, '{"a": 1}'): ScalarToken(
                1, 5, 5, '{"a": 1}'
            )
        },
        0,
        8,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:35:53.858929
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
    else:
        assert False, "Expected ParseError"

    # Test valid JSON

# Generated at 2022-06-18 12:36:00.471194
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 3, 7, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 12, 16, '{"a": "b", "c": "d"}')}, 0, 18, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:36:10.166232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:36:31.143717
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:39.676338
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:51.058454
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:37:02.315717
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8, '[1, 2, 3]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')

# Generated at 2022-06-18 12:37:11.129716
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:20.967041
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:26.484678
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:37:37.404272
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:37:49.176142
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 1, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        8,
        '{"a": "b"}',
    )


# Generated at 2022-06-18 12:38:00.069992
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('["a", "b"]') == ListToken(['a', 'b'], 0, 9, '["a", "b"]')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': 'b', 'c': 'd'}, 0, 19, '{"a": "b", "c": "d"}')
    assert tokenize_json('["a", "b", "c"]') == ListToken(['a', 'b', 'c'], 0, 13, '["a", "b", "c"]')

# Generated at 2022-06-18 12:38:23.266914
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 2, '[1, 2, 3]'), ScalarToken(2, 4, 5, '[1, 2, 3]'), ScalarToken(3, 7, 8, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')
    assert tokenize_json('{"a": [1, 2, 3]}') == D

# Generated at 2022-06-18 12:38:34.581995
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == {'a': 1}
    assert tokenize_json('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert tokenize_json('{"a": {"b": 2}}') == {'a': {'b': 2}}
    assert tokenize_json('{"a": [1, 2, 3]}') == {'a': [1, 2, 3]}
    assert tokenize_json('{"a": [1, 2, 3], "b": [4, 5, 6]}') == {'a': [1, 2, 3], 'b': [4, 5, 6]}

# Generated at 2022-06-18 12:38:45.852082
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:38:56.979602
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken(
        {"a": [1, 2]}, 0, 11, '{"a": [1, 2]}'
    )
    assert tokenize_json('{"a": [1, 2], "b": {"c": 3}}') == DictToken(
        {"a": [1, 2], "b": {"c": 3}}, 0, 26, '{"a": [1, 2], "b": {"c": 3}}'
    )

# Generated at 2022-06-18 12:39:07.350978
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2, 3]}'), ScalarToken(2, 9, 10, '{"a": [1, 2, 3]}'), ScalarToken(3, 12, 13, '{"a": [1, 2, 3]}')], 5, 14, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:39:18.235353
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:29.423106
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": {"b": [1, 2, 3]}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": {"b": [1, 2, 3]}}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 23
    assert token.end_position.char_index == 22

    content = '{"a": {"b": [1, 2, 3]}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:39:39.898552
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:39:47.505633
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )
    assert tokenize_json('{"a": "b"}') == DictToken(
        {"a": ScalarToken("b", 4, 7, '{"a": "b"}')}, 0, 10, '{"a": "b"}'
    )

# Generated at 2022-06-18 12:39:52.021370
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert token.value == {"key": "value"}
    assert token.start_index == 0
    assert token.end_index == len(content) - 1



# Generated at 2022-06-18 12:40:12.323268
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:22.404613
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:40:28.648060
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:38.302575
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')

# Generated at 2022-06-18 12:40:42.055886
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 14, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )



# Generated at 2022-06-18 12:40:49.969635
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:41:01.460902
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 3, '{"a": "b"}'): ScalarToken('b', 6, 9, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:41:07.324570
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(
                1, 6, 7, '{"a": 1}'
            )
        },
        0,
        8,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:41:16.493943
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3], "b": {"c": "d"}}'
    token = tokenize_json(content)
    assert token.value == {"a": [1, 2, 3], "b": {"c": "d"}}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[1].value == [1, 2, 3]

# Generated at 2022-06-18 12:41:23.654906
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:08.888855
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos

# Generated at 2022-06-18 12:42:19.331178
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"

    content = '["a", "b"]'
    token = tokenize_json(content)
    assert token.value == ["a", "b"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "list"

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:42:29.895842
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 3, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 13, '{"a": 1, "b": 2}'): ScalarToken(
                2, 17, 18, '{"a": 1, "b": 2}'
            ),
        },
        0,
        19,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:42:38.486118
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:42:47.787761
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 4, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:55.946744
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 9, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 14, 15, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:06.841240
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end_position.line_no == 1
    assert token.children[0].end_position.column_no == 3
    assert token.children[1].value == "b"

# Generated at 2022-06-18 12:43:18.371619
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:43:29.072477
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)
    assert token.value == {"name": "John", "age": 30, "city": "New York"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 51
    assert token.end_position.char_index == 50

    content = '{"name": "John", "age": 30, "city": "New York"}\n'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:39.173025
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:44:08.535044
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=20, line_no=1, char_index=19)
    assert token.content == content

    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:44:20.779578
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 3, 3, '[1, 2, 3]'), ScalarToken(3, 5, 5, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')