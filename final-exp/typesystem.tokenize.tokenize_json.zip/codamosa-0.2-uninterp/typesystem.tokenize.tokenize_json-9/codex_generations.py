

# Generated at 2022-06-18 12:34:49.947625
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)
    assert token.content == content

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content.encode("utf-8"))
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:35:01.480368
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:35:09.682288
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:35:20.944168
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:35:32.896499
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.column_no == 2
        assert exc.position.line_no == 1
        assert exc.position.char_index == 1

    # Test valid JSON
    token = tokenize_json('{"a": 1}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}
    assert token

# Generated at 2022-06-18 12:35:40.258607
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:35:52.376738
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:56.006898
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_index == 0
    assert token.end_index == 8
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[1].value == "b"


# Generated at 2022-06-18 12:36:02.082629
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:36:11.639014
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 17, 18, '{"a": 1, "b": 2}'
            ),
        },
        0,
        19,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:36:52.815396
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:37:04.613092
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:37:12.261308
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 8, 12, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}')

# Generated at 2022-06-18 12:37:21.556536
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 17, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:37:33.520515
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end_position.line_no == 1
    assert token.children[0].end_position.column_no == 3
    assert token.children

# Generated at 2022-06-18 12:37:44.934403
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:37:56.424845
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 13

    content = '{"a": 1, "b": 2}\n'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1

# Generated at 2022-06-18 12:38:05.026385
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:38:14.802255
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_pos == Position(column_no=13, line_no=1, char_index=12)

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:38:24.274362
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:38:37.966758
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 0, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 5, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 9, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 14, 15, '{"a": 1, "b": 2}'
            ),
        },
        0,
        16,
        '{"a": 1, "b": 2}',
    )



# Generated at 2022-06-18 12:38:48.155592
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1, "f": 2}}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1, "f": 2}}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=len(content), line_no=1, char_index=len(content))
    assert token.children[0].value == "a"

# Generated at 2022-06-18 12:38:58.556209
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == '{"foo": "bar"}'

    # Test invalid JSON
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{"foo": "bar"')
    assert exc_info.value.text == "Expecting value"
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.position.line

# Generated at 2022-06-18 12:39:10.393847
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2
    assert token.children[3].type == "scalar"


# Generated at 2022-06-18 12:39:21.653525
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 16, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:39:31.354197
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )
    assert tokenize_json('[1, 2]') == ListToken(
        [ScalarToken(1, 1, 2, '[1, 2]'), ScalarToken(2, 4, 5, '[1, 2]')], 0, 6, '[1, 2]'
    )
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')
    assert tokenize_json('true') == Scal

# Generated at 2022-06-18 12:39:42.225035
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:39:52.451815
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 2, '[1, 2, 3]'), ScalarToken(2, 4, 5, '[1, 2, 3]'), ScalarToken(3, 7, 8, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')

# Generated at 2022-06-18 12:39:56.084076
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:40:07.917801
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 5, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 9, 10, '{"a": 1, "b": 2}'): ScalarToken(
                2, 13, 14, '{"a": 1, "b": 2}'
            ),
        },
        0,
        15,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:40:23.670172
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:34.320575
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:40:41.640271
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:50.513703
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken("a", 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')

# Generated at 2022-06-18 12:41:02.056154
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:12.834128
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("42") == ScalarToken(42, 0, 2, "42")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 4, "3.14")

# Generated at 2022-06-18 12:41:16.879754
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        10,
        '{"a": "b"}',
    )



# Generated at 2022-06-18 12:41:23.924995
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1]}')], 6, 9, '{"a": [1]}')}, 0, 10, '{"a": [1]}')

# Generated at 2022-06-18 12:41:33.396126
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "2"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[1].value == 1
    assert token.children[2].value == "b"
    assert token.children[3].value == "2"

    content = '{"a": {"b": "c"}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": {"b": "c"}}

# Generated at 2022-06-18 12:41:45.194489
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.start_position.line_no == 1
    assert token.end_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.column_no == len(content)

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.char_index == 0
    assert token.end

# Generated at 2022-06-18 12:42:08.927732
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:42:19.372330
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:42:24.709474
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "John Doe",
        "age": 42,
        "is_active": true,
        "address": {
            "street": "123 Main St.",
            "city": "Anytown",
            "state": "CA"
        },
        "phone_numbers": [
            "555-555-5555",
            "555-555-5556"
        ]
    }
    """
    token = tokenize_json(content)

# Generated at 2022-06-18 12:42:35.013213
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "John",
        "age": 30,
        "cars": [
            { "model": "Ford", "mpg": 23.5 },
            { "model": "BMW", "mpg": 28.5 }
        ]
    }
    """
    token = tokenize_json(content)
    assert token.value == {
        "name": "John",
        "age": 30,
        "cars": [
            {"model": "Ford", "mpg": 23.5},
            {"model": "BMW", "mpg": 28.5},
        ],
    }
    assert token.start_position == Position(column_no=1, line_no=2, char_index=1)

# Generated at 2022-06-18 12:42:44.377995
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 4, '{"foo": "bar"}'): ScalarToken('bar', 9, 12, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}')

# Generated at 2022-06-18 12:42:53.650608
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")
    assert tokenize_json('"hello"') == ScalarToken("hello", 0, 7, '"hello"')

# Generated at 2022-06-18 12:43:04.908432
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:43:16.540011
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

# Generated at 2022-06-18 12:43:22.045510
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:43:32.554190
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 2, 5, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 11, 14, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:43:52.956667
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:44:05.085771
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:44:16.752520
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': 'b', 'c': 'd'}, 0, 19, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({'a': 'b', 'c': 'd', 'e': 'f'}, 0, 29, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:44:25.640790
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 2, '[1, 2]'), ScalarToken(2, 4, 5, '[1, 2]')], 0, 7, '[1, 2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')

# Generated at 2022-06-18 12:44:35.319860
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."
        assert exc.code == "no_content"
    else:
        assert False, "Expected ParseError"

    # Test for invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.position.column_no == 2
        assert exc.position.line_no == 1
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"