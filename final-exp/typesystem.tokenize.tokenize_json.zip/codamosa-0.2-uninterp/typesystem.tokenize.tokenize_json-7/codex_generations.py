

# Generated at 2022-06-18 12:35:06.799789
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": "b"}'
    validator = Schema({"a": str})
    value, error_messages = validate_json(content, validator)
    assert value == {"a": "b"}
    assert error_messages == []

    content = '{"a": "b"}'
    validator = Schema({"a": int})
    value, error_messages = validate_json(content, validator)
    assert value == {"a": "b"}
    assert error_messages == [
        Message(
            text="Must be an integer.",
            code="type_error.integer",
            position=Position(column_no=7, line_no=1, char_index=6),
        )
    ]

    content = '{"a": "b"}'

# Generated at 2022-06-18 12:35:18.244974
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON
    content = '{"foo": "bar"}'
    validator = Field(type="string")
    value, error_messages = validate_json(content, validator)
    assert value == {"foo": "bar"}
    assert error_messages == []

    # Test invalid JSON
    content = '{"foo": "bar"'
    validator = Field(type="string")
    value, error_messages = validate_json(content, validator)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text == "Expecting value."
    assert error_messages[0].code == "parse_error"
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 11


# Generated at 2022-06-18 12:35:25.227311
# Unit test for function validate_json
def test_validate_json():
    # Test that a valid JSON string returns a tuple of (value, None)
    content = '{"a": 1, "b": 2}'
    validator = Field(type="object", properties={"a": Field(type="integer"), "b": Field(type="integer")})
    assert validate_json(content, validator) == ({'a': 1, 'b': 2}, None)

    # Test that an invalid JSON string returns a tuple of (None, error_messages)
    content = '{"a": 1, "b": "2"}'
    validator = Field(type="object", properties={"a": Field(type="integer"), "b": Field(type="integer")})

# Generated at 2022-06-18 12:35:34.299607
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    content = '{"name": "John", "age": "30"}'
    value, errors = validate_json(content, MySchema)
    assert value == {"name": "John", "age": 30}
    assert errors == [
        ValidationError(
            text="Must be an integer.",
            code="invalid_type",
            position=Position(column_no=15, line_no=1, char_index=14),
        )
    ]

# Generated at 2022-06-18 12:35:44.242775
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    validator = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
            "cars": Field(type="array", items=Field(type="string")),
        }
    )
    value, error_messages = validate_json(content, validator)
    assert value == {"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}
    assert error_messages == []

    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]'

# Generated at 2022-06-18 12:35:56.263263
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert exc.text == "No content."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position == Position(column_no=1, line_no=1, char_index=1)
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:36:02.231991
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    valid_json = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    # Invalid JSON
    invalid_json = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]'
    # Schema
    class Person(Schema):
        name = String()
        age = Integer()
        cars = List(String())
    # Validating valid JSON
    value, error_messages = validate_json(valid_json, Person)
    assert value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}
    assert error_messages == []
    # Validating invalid JSON

# Generated at 2022-06-18 12:36:06.455614
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test valid JSON

# Generated at 2022-06-18 12:36:15.114906
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON
    valid_json = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    value, error_messages = validate_json(valid_json, Schema)
    assert error_messages == []
    assert value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}

    # Test invalid JSON
    invalid_json = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]'
    value, error_messages = validate_json(invalid_json, Schema)
    assert len(error_messages) == 1
    assert error_messages[0].code == 'parse_error'

# Generated at 2022-06-18 12:36:23.960827
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON
    content = '{"a": 1, "b": 2}'
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_json(content, validator)
    assert value == {"a": 1, "b": 2}
    assert error_messages == []

    # Test invalid JSON
    content = '{"a": 1, "b": 2'
    validator = Schema({"a": int, "b": int})
    value, error_messages = validate_json(content, validator)
    assert value is None

# Generated at 2022-06-18 12:36:49.402217
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:36:56.390954
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d')}, 0, 19, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d'), 'e': ScalarToken('f')}, 0, 29, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:37:07.552076
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 6, 11, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:37:18.750123
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:37:24.532069
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:37:35.253960
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:37:47.059040
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:37:58.466003
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d')}, 0, 17, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d'), 'e': ScalarToken('f')}, 0, 25, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:38:06.251317
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:38:16.150749
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:38:34.454925
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:38:45.671914
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1]}')], 5, 8, '{"a": [1]}')}, 0, 9, '{"a": [1]}')

# Generated at 2022-06-18 12:38:56.774531
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('{"a": [1, 2]}') == DictToken(
        {
            "a": ListToken(
                [
                    ScalarToken(1, 5, 6, '{"a": [1, 2]}'),
                    ScalarToken(2, 8, 9, '{"a": [1, 2]}'),
                ],
                3,
                10,
                '{"a": [1, 2]}',
            )
        },
        0,
        12,
        '{"a": [1, 2]}',
    )

# Generated at 2022-06-18 12:39:04.135576
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{\"a\": 1}") == DictToken(
        {"a": ScalarToken(1, 5, 6, "{\"a\": 1}")}, 0, 9, "{\"a\": 1}"
    )
    assert tokenize_json("[1, 2]") == ListToken(
        [ScalarToken(1, 1, 2, "[1, 2]"), ScalarToken(2, 4, 5, "[1, 2]")], 0, 6, "[1, 2]"
    )

# Generated at 2022-06-18 12:39:16.146114
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:27.392531
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("0") == ScalarToken(0, 0, 1, "0")
    assert tokenize_json("0.0") == ScalarToken(0.0, 0, 3, "0.0")

# Generated at 2022-06-18 12:39:34.172438
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:39:44.045557
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json('{"a": [1, 2]}') == DictToken(
        {
            "a": ListToken(
                [
                    ScalarToken(1, 5, 6, '{"a": [1, 2]}'),
                    ScalarToken(2, 8, 9, '{"a": [1, 2]}'),
                ],
                3,
                10,
                '{"a": [1, 2]}',
            )
        },
        0,
        13,
        '{"a": [1, 2]}',
    )

# Generated at 2022-06-18 12:39:54.089844
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:05.560811
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
    else:
        assert False, "Expected ParseError"

    # Test valid JSON

# Generated at 2022-06-18 12:40:20.908932
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:26.038132
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:40:37.062092
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:40:45.257241
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "no_content"
        assert exc.text == "No content."
    else:
        assert False, "ParseError not raised"

    # Test for JSON parse error
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 13
        assert exc.position.char_index == 12
        assert exc.code == "parse_error"
        assert exc.text == "Expecting value."
   

# Generated at 2022-06-18 12:40:50.512352
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'


# Generated at 2022-06-18 12:41:01.144566
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"foo": "bar"')

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14


# Generated at 2022-06-18 12:41:12.380322
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:41:20.751551
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:31.257592
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:41:43.221856
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3], "c": {"d": 4, "e": 5}}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3], "c": {"d": 4, "e": 5}}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=len(content), line_no=1, char_index=len(content) - 1)
    assert token.content == content

    content = '{"a": 1, "b": [2, 3], "c": {"d": 4, "e": 5}}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:41:58.315922
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")
    assert tokenize_json("1e1") == ScalarToken(10, 0, 3, "1e1")

# Generated at 2022-06-18 12:42:08.891348
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:42:19.373219
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].type == 'scalar'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[1].value == 'John'
    assert token

# Generated at 2022-06-18 12:42:24.669886
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')

# Generated at 2022-06-18 12:42:34.985862
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:42:44.333450
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:42:53.618117
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:04.910042
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[1].value == 1
    assert token.children[1].start == 6
    assert token.children[1].end == 6
    assert token.children[1].content == content
    assert token.children[2].value == "b"
    assert token.children[2].start == 9

# Generated at 2022-06-18 12:43:08.509423
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(
                1, 6, 7, '{"a": 1}'
            )
        },
        0,
        8,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:43:18.720105
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}

# Generated at 2022-06-18 12:43:34.873651
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:44.804623
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 2, '{"a": "b"}'): ScalarToken('b', 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:43:53.327594
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    assert token.value["a"] == 1
    assert token.value["b"] == [2, 3]

    assert isinstance(token.value["a"], ScalarToken)
    assert token.value["a"].value == 1
    assert token.value["a"].start == 5
    assert token.value["a"].end == 6
    assert token.value["a"].content == content

    assert isinstance(token.value["b"], ListToken)

# Generated at 2022-06-18 12:43:57.135840
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:06.795185
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 3, 7, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 12, 16, '{"a": "b", "c": "d"}')}, 0, 18, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:44:19.119778
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:44:26.897746
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].start == 6
    assert token.children[1].end == 6
    assert token.children[1].content == content