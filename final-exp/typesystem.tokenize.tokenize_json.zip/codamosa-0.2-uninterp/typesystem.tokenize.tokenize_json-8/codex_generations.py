

# Generated at 2022-06-18 12:34:59.352690
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15


# Generated at 2022-06-18 12:35:08.029599
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'city': 'New York'}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[0].type == 'scalar'
    assert token.children[1].value == 'John'
    assert token.children[1].start == 10

# Generated at 2022-06-18 12:35:19.290838
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}
    assert token.start == 0
    assert token.end == 6

    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 8

    token = tokenize_json('"hello"')
    assert isinstance(token, ScalarToken)
    assert token.value == "hello"
    assert token.start == 0
    assert token.end == 7

    token = tokenize_json('{"a": {"b": [1, 2, 3]}}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:35:25.755776
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:35:36.222861
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 4, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 4, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 11, '{"a": 1, "b": 2}')}, 0, 13, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:35:47.476584
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 1, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:35:59.245029
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:36:05.559530
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )

# Generated at 2022-06-18 12:36:13.309876
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:36:22.525063
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("0") == ScalarToken(0, 0, 1, "0")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_

# Generated at 2022-06-18 12:36:42.644642
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:53.035515
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 4, '{"foo": "bar"}'): ScalarToken('bar', 10, 13, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}')

# Generated at 2022-06-18 12:37:04.852698
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2, "c": 3}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2, "c": 3}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2, "c": 3}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2, "c": 3}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:37:12.366515
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:37:21.608121
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:29.382744
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token.value == {"foo": "bar"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=14, line_no=1, char_index=13)
    assert token.content == content



# Generated at 2022-06-18 12:37:39.458075
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].type == 'scalar'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[1].value == 'John'
    assert token

# Generated at 2022-06-18 12:37:52.016083
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 8
    assert token.end_position.char_index == 7
    assert token.content == content

    content = '{"a": {"b": "c"}}'
    token = tokenize_json(content)
    assert token.value == {"a": {"b": "c"}}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1

# Generated at 2022-06-18 12:38:01.722823
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 17

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 17

# Generated at 2022-06-18 12:38:12.777102
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test valid JSON

# Generated at 2022-06-18 12:38:39.312355
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=15, line_no=1, char_index=14)
    assert token.content == content
    assert token.type == "dict"

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}

# Generated at 2022-06-18 12:38:48.884075
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": "2"}')
    assert token.value == {"a": 1, "b": "2"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 16
    assert token.end_position.char_index == 15
    assert token.content == '{"a": 1, "b": "2"}'

    token = tokenize_json('{"a": 1, "b": "2"}')
    assert token.value == {"a": 1, "b": "2"}
    assert token.start_position.line_no == 1
    assert token

# Generated at 2022-06-18 12:38:59.255380
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('["a", "b"]') == ListToken(["a", "b"], 0, 9, '["a", "b"]')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": "b", "c": "d"}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:39:11.316583
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
   

# Generated at 2022-06-18 12:39:22.607021
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')

# Generated at 2022-06-18 12:39:27.927424
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:39:34.372512
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:39:44.072902
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2", "c": [3, 4, 5], "d": {"e": 6, "f": 7}}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2", "c": [3, 4, 5], "d": {"e": 6, "f": 7}}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=len(content), line_no=1, char_index=len(content) - 1)
    assert token.children[0].value == "a"

# Generated at 2022-06-18 12:39:54.089445
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:40:05.561661
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 8, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:22.243932
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:40:28.563718
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:40:38.270118
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:45.759142
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = token

# Generated at 2022-06-18 12:40:55.778507
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 23
    assert token.end_position.char_index == 22
    assert token.content == content

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}

# Generated at 2022-06-18 12:41:04.249138
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json('{"a": [1, 2]}') == DictToken(
        {
            "a": ListToken(
                [
                    ScalarToken(1, 7, 8, '{"a": [1, 2]}'),
                    ScalarToken(2, 10, 11, '{"a": [1, 2]}'),
                ],
                5,
                12,
                '{"a": [1, 2]}',
            )
        },
        0,
        14,
        '{"a": [1, 2]}',
    )

# Generated at 2022-06-18 12:41:14.785215
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.char_index == 2
    assert token.children[0].end_position.char_index == 3
    assert token.children[0].content == content
    assert token.children[1].value == 1
    assert token.children[1].start_position.char_index == 6
    assert token.children[1].end_position.char_index == 6

# Generated at 2022-06-18 12:41:22.545734
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:32.206530
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 21

    content = '{"a": "b", "c": "d"}\n{"e": "f", "g": "h"}'
    token = tokenize_json(content)
    assert token.value == [{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]
    assert token.start_position.line_no == 1
    assert token.start

# Generated at 2022-06-18 12:41:43.997141
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:42:07.462032
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 4, 5, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 12, 13, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:17.872714
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:42:27.977435
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:42:36.069411
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken('a', 1, 3, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken('b', 11, 13, '{"a": 1, "b": 2}'): ScalarToken(
                2, 17, 18, '{"a": 1, "b": 2}'
            ),
        },
        0,
        19,
        '{"a": 1, "b": 2}',
    )



# Generated at 2022-06-18 12:42:45.796025
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:54.709266
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:05.657081
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:17.348273
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 2, '{"a": "b"}'): ScalarToken('b', 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:43:27.908965
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:43:38.119970
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:44:01.994300
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1


# Generated at 2022-06-18 12:44:09.024431
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')},
        0,
        15,
        '{"a": 1, "b": 2}'
    )

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"a": 1, "b": 2')

    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json('')

    # Test empty string with whitespace
    with pytest.raises(ParseError):
        tokenize_json

# Generated at 2022-06-18 12:44:21.227905
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({"foo": ScalarToken("bar", 2, 8, '{"foo": "bar"}')}, 0, 12, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken({"foo": ScalarToken("bar", 2, 8, '{"foo": "bar", "baz": "qux"}'), "baz": ScalarToken("qux", 15, 21, '{"foo": "bar", "baz": "qux"}')}, 0, 25, '{"foo": "bar", "baz": "qux"}')