

# Generated at 2022-06-18 12:34:43.403589
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14



# Generated at 2022-06-18 12:34:51.582892
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": [1, 2, 3]}
    assert token.start_index == 0
    assert token.end_index == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].type == "scalar"
    assert token.children[0].value == "a"
    assert token.children[1].type == "list"
    assert token.children[1].value == [1, 2, 3]
    assert token.children[1].children[0].type == "scalar"
    assert token.children[1].children[0].value == 1

# Generated at 2022-06-18 12:35:02.083822
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:35:10.064658
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 6, 11, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:35:21.256972
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:35:32.945316
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0

    # Test invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{")
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 2
    assert excinfo.value.position.char_index == 1

    # Test valid JSON

# Generated at 2022-06-18 12:35:38.938327
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        '{"name": "John", "age": 30, "cars": [{"model": "BMW 230", "mpg": 27.5}, {"model": "Ford Edge", "mpg": 24.1}]}'
    )
    assert token.value == {
        "name": "John",
        "age": 30,
        "cars": [{"model": "BMW 230", "mpg": 27.5}, {"model": "Ford Edge", "mpg": 24.1}],
    }
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=1, line_no=1, char_index=126)

# Generated at 2022-06-18 12:35:50.894130
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3], "b": {"c": "d"}}'
    token = tokenize_json(content)
    assert token.value == {"a": [1, 2, 3], "b": {"c": "d"}}
    assert token.start_position.char_index == 0
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)

    assert isinstance(token.value, dict)
    assert isinstance(token.value["a"], list)
    assert isinstance(token.value["b"], dict)

    assert token

# Generated at 2022-06-18 12:36:01.587895
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 17, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:36:11.276388
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2
    assert token.children[3].type == "scalar"


# Generated at 2022-06-18 12:36:28.984836
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == len(content)
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == len(content) - 1


# Generated at 2022-06-18 12:36:38.473964
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:49.643507
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 4, '{"foo": "bar"}'): ScalarToken('bar', 9, 13, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}')

# Generated at 2022-06-18 12:37:00.577677
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:37:10.153534
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken(
        {"a": "b", "c": "d"}, 0, 17, '{"a": "b", "c": "d"}'
    )

# Generated at 2022-06-18 12:37:20.391953
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:32.428666
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 10, '[1, 2, 3]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')

# Generated at 2022-06-18 12:37:43.491974
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 2, 6, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 11, 15, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:37:55.103275
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:38:04.106531
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:38:22.957527
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )


# Generated at 2022-06-18 12:38:34.494670
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": "c"}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "c"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 17
    assert token.content == '{"a": 1, "b": "c"}'

    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1

# Generated at 2022-06-18 12:38:45.717717
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 8
    assert token.end_position.char_index == 7
    assert token.content == content

    content = '{"a": "b"}\n{"c": "d"}'
    token = tokenize_json(content)
    assert token.value == [{"a": "b"}, {"c": "d"}]
    assert token.start_position.line_no == 1
    assert token.start

# Generated at 2022-06-18 12:38:56.825516
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:06.966358
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 15, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:39:17.886606
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "c"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "c"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == "c"

# Generated at 2022-06-18 12:39:29.096148
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(
                1, 6, 6, '{"a": 1}'
            )
        },
        0,
        8,
        '{"a": 1}',
    )
    assert tokenize_json('[1, 2]') == ListToken(
        [ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')],
        0,
        5,
        '[1, 2]',
    )

# Generated at 2022-06-18 12:39:35.331657
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == content



# Generated at 2022-06-18 12:39:44.825047
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')
    assert tokenize_json('1') == ScalarToken(1, 0, 0, '1')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')

# Generated at 2022-06-18 12:39:54.341978
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == len(content)
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content.encode("utf-8"))

# Generated at 2022-06-18 12:40:26.295026
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:37.338379
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 10
    assert token.content == content

    content = '{"a": "b"}\n{"c": "d"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token

# Generated at 2022-06-18 12:40:45.198094
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:40:54.909298
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:41:03.942390
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 15, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:41:14.627327
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:22.435685
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 8, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 8, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:41:32.130672
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos.char_index == 0
    assert token.start_pos.line_no == 1
    assert token.start_pos.column_no == 1
    assert token.end_pos.char_index == len(content) - 1
    assert token.end_pos.line_no == 1
    assert token.end_pos.column_no == len(content)
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:41:43.959380
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')},
        0,
        15,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:41:52.478728
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:44.757881
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0

    # Test invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{")
    assert excinfo.value.text == "Expecting property name enclosed in double quotes."
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no

# Generated at 2022-06-18 12:42:53.946001
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end

# Generated at 2022-06-18 12:43:04.908299
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=9, line_no=1, char_index=8)
    assert token.content == content

    content = '{"a": "b"}\n{"c": "d"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)


# Generated at 2022-06-18 12:43:16.505663
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"foo": "bar"')

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert token.value == {"foo": "bar"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=13, line_no=1, char_index=12)

    # Test nested JSON
    token = tokenize_json('{"foo": {"bar": "baz"}}')
    assert token.value == {"foo": {"bar": "baz"}}
   

# Generated at 2022-06-18 12:43:22.026815
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:43:32.556923
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": "2"}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": "2"}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": "2"}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": "2"}'): ScalarToken(
                "2", 14, 17, '{"a": 1, "b": "2"}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": "2"}',
    )


# Generated at 2022-06-18 12:43:36.774471
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )



# Generated at 2022-06-18 12:43:46.932630
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "No exception raised."

    # Test empty object
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    # Test empty array
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []

    # Test null
    token = tokenize_json("null")

# Generated at 2022-06-18 12:43:54.698356
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 16, '{"a": 1, "b": 2}')
    assert tokenize_json('["a", "b"]') == ListToken(['a', 'b'], 0, 9, '["a", "b"]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')
    assert tokenize_json('1.0') == ScalarToken

# Generated at 2022-06-18 12:44:05.549288
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)