

# Generated at 2022-06-18 12:34:50.368220
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 2, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 2, 3, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 5, 12, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:01.565177
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:35:09.715510
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1]}')], 6, 9, '{"a": [1]}')}, 0, 10, '{"a": [1]}')

# Generated at 2022-06-18 12:35:20.983326
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": 1, "b": 2}, 0, 13, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2, "c": 3}') == DictToken({"a": 1, "b": 2, "c": 3}, 0, 20, '{"a": 1, "b": 2, "c": 3}')

# Generated at 2022-06-18 12:35:32.944872
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:41.474576
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:54.150404
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:36:00.714692
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 7, 11, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:36:10.408285
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:36:20.194132
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:36:39.964232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )

# Generated at 2022-06-18 12:36:51.182497
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{\"foo\": \"bar\"}") == DictToken(
        {"foo": ScalarToken("bar", 7, 12, "{\"foo\": \"bar\"}")}, 0, 18, "{\"foo\": \"bar\"}"
    )
    assert tokenize_json("[1, 2, 3]") == ListToken(
        [
            ScalarToken(1, 1, 2, "[1, 2, 3]"),
            ScalarToken(2, 4, 5, "[1, 2, 3]"),
            ScalarToken(3, 7, 8, "[1, 2, 3]"),
        ],
        0,
        9,
        "[1, 2, 3]",
    )
    assert tokenize_json

# Generated at 2022-06-18 12:36:56.802610
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:07.878332
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": "foo"}')
    assert token.value == {"a": 1, "b": "foo"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 19
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 18

    token = tokenize_json('{"a": 1, "b": "foo"}\n{"a": 2, "b": "bar"}')
    assert token.value == [{"a": 1, "b": "foo"}, {"a": 2, "b": "bar"}]
    assert token.start_position.line_no

# Generated at 2022-06-18 12:37:19.036653
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:24.639179
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:37:35.285958
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.end_position.column_no == 15
    assert token.start_position.line_no == 1
    assert token.end_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.end

# Generated at 2022-06-18 12:37:47.107253
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == 14
    assert token.content == '{"a": 1, "b": 2}'
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2
    assert token.children[3].type == "scalar"



# Generated at 2022-06-18 12:37:58.506387
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:38:06.277357
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
   

# Generated at 2022-06-18 12:38:15.522157
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 4, 5, '{"a": [1, 2]}'), ScalarToken(2, 7, 8, '{"a": [1, 2]}')], 3, 9, '{"a": [1, 2]}')}, 0, 11, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:24.658406
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "no_content"
        assert exc.text == "No content."
    else:
        assert False

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.code == "parse_error"
        assert exc.text == "Expecting property name enclosed in double quotes."
    else:
        assert False

    # Test valid

# Generated at 2022-06-18 12:38:35.677722
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:38:46.962274
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 4, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:50.422595
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )



# Generated at 2022-06-18 12:39:00.201015
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        10,
        '{"a": "b"}',
    )


# Generated at 2022-06-18 12:39:11.523679
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:22.760841
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:39:32.109446
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 3, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 7, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 16, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:43.121412
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:39:55.717245
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')

# Generated at 2022-06-18 12:40:07.523577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:40:18.172361
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 2, '{"a": "b"}'): ScalarToken('b', 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:26.129363
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 8
    assert token.end_position.char_index == 7

    content = '{"a": "b"}\n{"c": "d"}'
    token = tokenize_json(content)
    assert token.value == [{"a": "b"}, {"c": "d"}]
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1

# Generated at 2022-06-18 12:40:37.142849
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:40.892122
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')


# Generated at 2022-06-18 12:40:49.903476
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {
            ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken(
                "bar", 9, 14, '{"foo": "bar"}'
            )
        },
        0,
        15,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:41:01.383196
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert token.value == {"key": "value"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "key"
    assert token.children[0].start == 2
    assert token.children[0].end == 5
    assert token.children[0].content == content
    assert token.children[0].type == "scalar"
    assert token.children[1].value == "value"
    assert token.children[1].start == 8
    assert token.children[1].end == 14
    assert token.children[1].content == content

# Generated at 2022-06-18 12:41:12.378354
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('[1, 2, 3]') == ListToken(
        [
            ScalarToken(1, 1, 2, '[1, 2, 3]'),
            ScalarToken(2, 4, 5, '[1, 2, 3]'),
            ScalarToken(3, 7, 8, '[1, 2, 3]'),
        ],
        0,
        10,
        '[1, 2, 3]',
    )

# Generated at 2022-06-18 12:41:20.701923
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")

# Generated at 2022-06-18 12:41:37.810600
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:41:47.255946
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 2, 7, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 12, 17, '{"a": "b", "c": "d"}')}, 0, 19, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:41:57.069930
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:42:03.493771
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}



# Generated at 2022-06-18 12:42:13.761489
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:23.306968
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {
        "name": "John",
        "age": 30,
        "cars": ["Ford", "BMW", "Fiat"],
    }
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=1, line_no=1, char_index=len(content))

    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:42:29.467711
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:42:38.168643
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1

    # Test valid JSON

# Generated at 2022-06-18 12:42:47.788091
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:42:55.945962
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"a": "b", "c": "d", "e": "f"}'
   

# Generated at 2022-06-18 12:43:18.494002
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:43:29.253389
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:39.349883
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:43:49.124441
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:56.124649
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:06.280521
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 3, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:18.579203
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2, 3]}'), ScalarToken(2, 9, 10, '{"a": [1, 2, 3]}'), ScalarToken(3, 12, 13, '{"a": [1, 2, 3]}')], 5, 14, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:44:26.650376
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')
