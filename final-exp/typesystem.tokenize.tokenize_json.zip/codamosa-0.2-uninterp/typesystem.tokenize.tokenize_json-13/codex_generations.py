

# Generated at 2022-06-18 12:34:43.899771
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:34:51.981397
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:35:02.451733
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:10.271612
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=20, line_no=1, char_index=19)
    assert token.content == content

    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:35:21.662825
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:35:33.125962
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

# Generated at 2022-06-18 12:35:42.156978
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}

    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}

    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}

    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}


# Generated at 2022-06-18 12:35:54.532655
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test empty object
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    # Test empty array
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []

    # Test empty string
    token = tokenize_json('""')
    assert isinstance(token, ScalarToken)
    assert token.value == ""

    # Test empty string
    token = tokenize_json('"foo"')
    assert isinstance(token, ScalarToken)
    assert token.value == "foo"

    # Test empty string
    token = tokenize_json("1")

# Generated at 2022-06-18 12:36:00.922534
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:10.600847
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 4, 13, '{"a": [1, 2, 3]}')}, 0, 15, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:36:27.064292
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': 'bar'}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken({'foo': 'bar', 'baz': 'qux'}, 0, 29, '{"foo": "bar", "baz": "qux"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux", "quux": "corge"}') == DictToken({'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}, 0, 45, '{"foo": "bar", "baz": "qux", "quux": "corge"}')

# Generated at 2022-06-18 12:36:36.410628
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:47.372969
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test empty object
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    # Test empty array
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []

    # Test null
    token = tokenize_json("null")
    assert isinstance(token, ScalarToken)
    assert token.value is None

    # Test true
    token = tokenize_json("true")
    assert isinstance(token, ScalarToken)
    assert token.value is True

    # Test false
    token = tokenize_json("false")

# Generated at 2022-06-18 12:36:53.074355
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15


# Generated at 2022-06-18 12:37:04.898333
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
        assert False
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

    # Test invalid JSON
    try:
        tokenize_json("{")
        assert False
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

    # Test valid JSON
    token = tokenize_json('{"a": 1}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:37:12.385708
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=15, line_no=1, char_index=14)

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)


# Generated at 2022-06-18 12:37:17.398484
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:37:23.963078
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 17, 18, '{"a": 1, "b": 2}'
            ),
        },
        0,
        19,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:37:34.777608
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
    else:
        assert False, "Expected ParseError"

    # Test valid JSON

# Generated at 2022-06-18 12:37:46.551222
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 4
    assert token.children[0].content == content
    assert token.children[0].type == "scalar"
    assert token.children[1].value == "b"
    assert token.children[1].start == 7
    assert token.children[1].end == 9

# Generated at 2022-06-18 12:38:03.238041
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json returns a Token object
    assert isinstance(tokenize_json("{}"), Token)
    # Test that tokenize_json raises a ParseError on invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")
    # Test that tokenize_json raises a ParseError on empty string
    with pytest.raises(ParseError):
        tokenize_json("")


# Generated at 2022-06-18 12:38:13.230443
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0

    # Test invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"foo": "bar", "baz": "qux", "quux": "corge"}')
    assert excinfo.value.text == "Expecting property name enclosed in double quotes."
    assert excinfo.value.code == "parse_error"
    assert excinfo.value

# Generated at 2022-06-18 12:38:23.595629
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:38:34.869824
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
   

# Generated at 2022-06-18 12:38:46.249013
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:38:57.235392
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token.value == {"foo": "bar"}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"foo": "bar", "baz": "qux"}'
    token = tokenize_json(content)
    assert token.value == {"foo": "bar", "baz": "qux"}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"foo": "bar", "baz": "qux", "quux": "corge"}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:39:04.395260
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a":1}')}, 0, 5, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a":1, "b":2}'), "b": ScalarToken(2, 8, 9, '{"a":1, "b":2}')}, 0, 12, '{"a":1, "b":2}')

# Generated at 2022-06-18 12:39:16.187049
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:39:27.442253
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:34.192076
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test tokenize_json with empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Expected ParseError"

    # Test tokenize_json with invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:40:37.905447
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.content == content


# Generated at 2022-06-18 12:40:45.458263
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "a": "b",
        "c": [
            "d",
            "e"
        ]
    }
    """
    token = tokenize_json(content)
    assert token.value == {
        "a": "b",
        "c": ["d", "e"],
    }
    assert token.start_position == Position(column_no=1, line_no=2, char_index=0)
    assert token.end_position == Position(column_no=1, line_no=10, char_index=38)

    content = """
    {
        "a": "b",
        "c": [
            "d",
            "e"
        ]
    }
    """
    token = tokenize_json(content)

# Generated at 2022-06-18 12:40:52.849080
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:02.912491
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test empty object
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    # Test empty list
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []

    # Test empty string
    token = tokenize_json('""')
    assert isinstance(token, ScalarToken)
    assert token.value == ""

    # Test empty string
    token = tokenize_json('"hello"')
    assert isinstance(token, ScalarToken)
    assert token.value == "hello"

    # Test empty string
    token = tokenize_json("1")

# Generated at 2022-06-18 12:41:13.696260
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": ScalarToken("b", 3, 5, '{"a": "b", "c": "d"}'), "c": ScalarToken("d", 12, 14, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:41:21.774706
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end_position.line_no == 1
    assert token.children[0].end_position.column_no == 3
    assert token.children

# Generated at 2022-06-18 12:41:31.885659
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:43.721710
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:48.056630
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.content == content


# Generated at 2022-06-18 12:41:58.484926
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

    # Test invalid JSON
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.text == "Expecting value."
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 13
        assert exc.position.char_index == 12

    # Test valid JSON

# Generated at 2022-06-18 12:42:20.473119
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': ['Ford', 'BMW', 'Fiat']}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].type == 'scalar'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[1].value == 'John'
    assert token

# Generated at 2022-06-18 12:42:30.984242
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:42:39.297029
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 23
    assert token.end_position.char_index == 22
    assert token.content == content

    content = '{"a": 1, "b": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [1, 2, 3]}

# Generated at 2022-06-18 12:42:44.010017
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:42:53.419136
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John Doe", "age": 42}'
    token = tokenize_json(content)
    assert token.value == {"name": "John Doe", "age": 42}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 31
    assert token.end_position.char_index == 30

    content = '{"name": "John Doe", "age": 42, "address": {"street": "123 Main St", "city": "Anytown", "state": "CA"}}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:04.875456
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 0, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:43:16.432374
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:21.984623
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": "b", "c": "d", "e": "f"}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:43:32.554726
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 14, '{"foo": "bar"}')},
        0,
        15,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:43:42.579580
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 5, 10, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:44:18.423984
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:44:28.240367
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')