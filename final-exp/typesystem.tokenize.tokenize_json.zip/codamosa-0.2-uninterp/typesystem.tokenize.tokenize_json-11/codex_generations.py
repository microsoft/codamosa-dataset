

# Generated at 2022-06-18 12:35:03.885719
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json raises ParseError on empty content
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test that tokenize_json raises ParseError on invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test that tokenize_json returns a Token on valid JSON
    assert isinstance(tokenize_json("{}"), Token)



# Generated at 2022-06-18 12:35:11.972577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:35:18.573079
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9


# Generated at 2022-06-18 12:35:25.408534
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_pos == 2
    assert token.children[0].end_pos == 3
    assert token.children[0].content == content
    assert token.children[1].value == 1
    assert token.children[1].start_pos == 6
    assert token.children[1].end_pos == 6
    assert token.children[1].content == content

# Generated at 2022-06-18 12:35:35.957774
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:47.176919
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 12, 13, '{"a": 1, "b": 2}'): ScalarToken(
                2, 18, 19, '{"a": 1, "b": 2}'
            ),
        },
        0,
        20,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:35:58.831866
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 3, '{"a": "b"}'): ScalarToken("b", 7, 9, '{"a": "b"}')}, 0, 10, '{"a": "b"}')

# Generated at 2022-06-18 12:36:05.096637
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )

# Generated at 2022-06-18 12:36:13.203719
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:22.449154
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": ScalarToken("b", 3, 6, '{"a": "b", "c": "d"}'), "c": ScalarToken("d", 12, 15, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:36:37.918618
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')
        },
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:36:48.788082
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:36:59.815033
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 10, '[1, 2, 3]')

# Generated at 2022-06-18 12:37:09.561186
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1}}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1}}
    assert token.start_pos == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_pos == Position(column_no=len(content), line_no=1, char_index=len(content) - 1)
    assert token.content == content
    assert token.children[0].value == "a"

# Generated at 2022-06-18 12:37:19.902013
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:37:31.658849
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 2, '{"a": "b"}'): ScalarToken('b', 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:37:35.640435
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:45.816377
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14



# Generated at 2022-06-18 12:37:57.062584
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:38:05.488344
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:38:22.599956
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:38:34.453597
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        raise AssertionError("Expected ParseError to be raised")

    # Test for invalid JSON
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.text == "Expecting value."
        assert exc.code == "parse_error"
        assert exc.position.column_no == 13
        assert exc.position.line_no == 1
        assert exc.position.char_index

# Generated at 2022-06-18 12:38:39.507366
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:38:48.970942
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:38:59.335276
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 3, 3, '[1, 2, 3]'), ScalarToken(3, 5, 5, '[1, 2, 3]')], 0, 8, '[1, 2, 3]')

# Generated at 2022-06-18 12:39:06.917687
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}


# Generated at 2022-06-18 12:39:17.844288
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.end_position.char_index == 13

    content = '[1, 2, 3]'
    token = tokenize_json(content)
    assert token.value == [1, 2, 3]
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position

# Generated at 2022-06-18 12:39:29.052524
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 16, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:39:39.732050
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:39:47.389954
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 15, 15, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:40:02.957750
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:40:12.432614
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test JSON parse error
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 12
        assert exc.position.char_index == 11
        assert exc.text == "Expecting value."

    # Test JSON parse error with newlines

# Generated at 2022-06-18 12:40:22.521068
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:40:28.708015
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:40:38.364032
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
   

# Generated at 2022-06-18 12:40:45.824773
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:40:53.037292
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:41:02.994594
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2

# Generated at 2022-06-18 12:41:13.775499
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:41:20.493751
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:41:32.317153
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('["a", 1]') == ListToken([ScalarToken('a', 1, 2, '["a", 1]'), ScalarToken(1, 5, 5, '["a", 1]')], 0, 8, '["a", 1]')

# Generated at 2022-06-18 12:41:44.151555
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
   

# Generated at 2022-06-18 12:41:50.773926
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:02.197098
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)
    assert token.value == {"name": "John", "age": 30, "city": "New York"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 46
    assert token.end_position.char_index == 45
    assert token.content == content

    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:42:12.794376
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    content = ""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "no_content"
        assert exc.text == "No content."

    # Test for invalid JSON
    content = '{"key": "value", "key2": "value2"}'
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 27
        assert exc.position.char_index == 26
        assert exc.code == "parse_error"

# Generated at 2022-06-18 12:42:22.349849
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {"a": 1, "b": 2}, 0, 12, '{"a": 1, "b": 2}'
    )
    assert tokenize_json('{"a": {"b": 1}}') == DictToken(
        {"a": DictToken({"b": 1}, 6, 12, '{"a": {"b": 1}}')}, 0, 13, '{"a": {"b": 1}}'
    )

# Generated at 2022-06-18 12:42:33.307937
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].start == 6
    assert token.children[1].end == 6
    assert token.children[1].content == content


# Generated at 2022-06-18 12:42:40.623131
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 11, 14, '{"a": "b", "c": "d"}')}, 0, 16, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:42:50.908468
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:01.890953
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a":1}')}, 0, 5, '{"a":1}')
    assert tokenize_json('{"a":[1]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a":[1]}')], 3, 8, '{"a":[1]}')}, 0, 9, '{"a":[1]}')

# Generated at 2022-06-18 12:43:18.522792
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3], "c": {"d": "e"}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [1, 2, 3], "c": {"d": "e"}}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    assert isinstance(token.value["a"], ScalarToken)
    assert token.value["a"].value == 1
    assert token.value["a"].start == 4
    assert token.value["a"].end == 5
    assert token.value["a"].content == content

    assert isinstance(token.value["b"], ListToken)
   

# Generated at 2022-06-18 12:43:29.242672
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        8,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:43:39.351827
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:49.125333
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 16, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': [1, 2]}, 0, 12, '{"a": [1, 2]}')
    assert tokenize_json('{"a": [1, 2], "b": [3, 4]}') == DictToken({'a': [1, 2], 'b': [3, 4]}, 0, 24, '{"a": [1, 2], "b": [3, 4]}')
    assert tokenize_json('{"a": [1, 2], "b": [3, 4], "c": [5, 6]}') == Dict

# Generated at 2022-06-18 12:44:00.098137
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 5, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 14, 14, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:44:08.048193
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:44:20.365554
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == None
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")
    assert tokenize_json("1.1e1") == Scalar

# Generated at 2022-06-18 12:44:30.423807
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)