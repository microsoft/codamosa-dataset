

# Generated at 2022-06-18 12:35:01.433266
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 9, 10, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:35:09.614365
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:35:20.903890
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 3, '{"a": "b"}'): ScalarToken('b', 7, 9, '{"a": "b"}')}, 0, 10, '{"a": "b"}')

# Generated at 2022-06-18 12:35:26.549272
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:35:36.697980
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 0, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 14, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:35:47.859551
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:59.562760
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:05.560185
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": [2, 3]}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:36:08.939770
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert token.value == {"key": "value"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:36:15.452234
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that the function tokenize_json can handle empty strings
    assert tokenize_json("") == {}

    # Test that the function tokenize_json can handle empty objects
    assert tokenize_json("{}") == {}

    # Test that the function tokenize_json can handle empty lists
    assert tokenize_json("[]") == []

    # Test that the function tokenize_json can handle empty strings
    assert tokenize_json('""') == ""

    # Test that the function tokenize_json can handle empty strings
    assert tokenize_json("null") is None

    # Test that the function tokenize_json can handle empty strings
    assert tokenize_json("true") is True

    # Test that the function tokenize_json can handle empty strings
    assert tokenize_json("false") is False

    # Test that the function tokenize_json

# Generated at 2022-06-18 12:36:38.362984
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test invalid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"foo": "bar"')

    # Test valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert token.value == {"foo": "bar"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=12, line_no=1, char_index=11)



# Generated at 2022-06-18 12:36:49.547941
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:36:57.697457
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "b"}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == 8
    assert token.content == '{"a": "b"}'
    assert token.children[0].value == "a"
    assert token.children[1].value == "b"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[1].start == 6
    assert token.children[1].end == 7


# Generated at 2022-06-18 12:37:08.560458
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 15, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:37:15.212660
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken('bar', 9, 14, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}')

# Generated at 2022-06-18 12:37:23.102629
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:37:34.124516
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:45.673684
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end_position.line_no == 1
    assert token.children[0].end_position.column_no == 3
    assert token.children

# Generated at 2022-06-18 12:37:57.056349
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:05.521437
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:23.910143
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == 14
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == 13

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_

# Generated at 2022-06-18 12:38:35.180445
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that we can tokenize a simple JSON object
    json_string = '{"a": 1, "b": 2}'
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 16

    # Test that we can tokenize a simple JSON array
    json_string = "[1, 2, 3]"
    token = tokenize_json(json_string)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start_

# Generated at 2022-06-18 12:38:46.639694
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {'a': 1, 'b': 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=14, line_no=1, char_index=13)
    assert token.content == '{"a": 1, "b": 2}'

    token = tokenize_json('[1, 2]')
    assert isinstance(token, ListToken)
    assert token.value == [1, 2]
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end

# Generated at 2022-06-18 12:38:52.316252
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=13, line_no=1, char_index=12)


# Generated at 2022-06-18 12:39:01.426978
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken("a", 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:09.901290
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.end_position.char_index == 13
    assert token.content == content


# Generated at 2022-06-18 12:39:15.205146
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
   

# Generated at 2022-06-18 12:39:26.273454
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 14, 15, '{"a": 1, "b": 2}'
            ),
        },
        0,
        16,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:39:33.644615
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:43.967858
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1}}'
    token = tokenize_json(content)
    assert token.value == {'a': 1, 'b': '2', 'c': [1, 2, 3], 'd': {'e': 1}}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)

    content = '{"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1}}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:40:06.855954
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:40:14.400516
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:40:23.458828
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 6, 11, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:40:28.537610
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:40:38.237222
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:40:45.726800
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.end_position.char_index == 8

    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token

# Generated at 2022-06-18 12:40:52.992402
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:02.968060
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end

# Generated at 2022-06-18 12:41:13.737637
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b", "c"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", "b", "c"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:41:21.835349
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == 16
    assert token.content == '{"a": 1, "b": 2}'

    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 8
    assert token.content == '[1, 2, 3]'

    token = tokenize_json('"hello"')
    assert isinstance(token, ScalarToken)
    assert token.value == "hello"
    assert token.start == 0


# Generated at 2022-06-18 12:41:50.298866
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:42:01.659628
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:42:08.001223
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.content == content


# Generated at 2022-06-18 12:42:18.407447
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:28.738499
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}'
    )
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:42:37.672151
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

# Generated at 2022-06-18 12:42:47.702493
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 1, 2, '{"a": "b"}'): ScalarToken('b', 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:42:54.554470
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)
    assert token.value == {"name": "John", "age": 30, "city": "New York"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 50
    assert token.end_position.char_index == 49


# Generated at 2022-06-18 12:43:05.533392
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:43:11.824642
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '[1, 2, 3]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '"foo"'
    token = tokenize_json(content)
    assert isinstance(token, ScalarToken)
    assert token.value == "foo"
    assert token.start

# Generated at 2022-06-18 12:43:34.831943
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": "2"}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "2"}
    assert token.start == 0
    assert token.end == 16
    assert token.content == '{"a": 1, "b": "2"}'
    assert token.get_position(0) == Position(column_no=1, line_no=1, char_index=0)
    assert token.get_position(1) == Position(column_no=2, line_no=1, char_index=1)
    assert token.get_position(2) == Position(column_no=3, line_no=1, char_index=2)

# Generated at 2022-06-18 12:43:44.756600
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 19, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:43:53.294744
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 19
    assert token.end_position.char_index == 18

    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:44:05.128114
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 8, '{"a": [1, 2]}')], 5, 9, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:16.799398
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1

# Generated at 2022-06-18 12:44:22.783041
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content


# Generated at 2022-06-18 12:44:28.523187
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )