

# Generated at 2022-06-18 12:35:02.716725
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 4, '{"foo": "bar"}'): ScalarToken('bar', 9, 13, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}')

# Generated at 2022-06-18 12:35:10.413122
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

# Generated at 2022-06-18 12:35:21.540294
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:33.037461
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("42") == ScalarToken(42, 0, 2, "42")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")

# Generated at 2022-06-18 12:35:39.064580
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

# Generated at 2022-06-18 12:35:51.031967
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test for empty object
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    # Test for empty list
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")

    # Test for empty string
    assert tokenize_json('""') == ScalarToken("", 0, 2, '""')

    # Test for empty string
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")

    # Test for empty string
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")

    # Test for empty string
    assert tokenize_json("false") == Scalar

# Generated at 2022-06-18 12:35:56.594105
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "foo"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "foo"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:36:00.525779
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content


# Generated at 2022-06-18 12:36:10.218445
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:36:19.843856
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {'a': 1, 'b': 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 17
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {'a': 1, 'b': 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token

# Generated at 2022-06-18 12:36:40.515905
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:50.158917
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": "2"}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": "2"}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": "2"}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": "2"}'): ScalarToken(
                "2", 16, 19, '{"a": 1, "b": "2"}'
            ),
        },
        0,
        20,
        '{"a": 1, "b": "2"}',
    )



# Generated at 2022-06-18 12:37:01.130269
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"

    content = '{"a": [1, 2, 3], "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": [1, 2, 3], "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"

    content = '{"a": [1, 2, 3], "b": 2}'
    token

# Generated at 2022-06-18 12:37:10.488960
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

# Generated at 2022-06-18 12:37:20.555482
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:37:32.512433
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:43.672117
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b", "c": "d"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 20

    content = '{"a": "b", "c": "d"}\n{"e": "f", "g": "h"}'
    token = tokenize_json(content)
    assert token.value == [{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]
    assert token.start_position.line_no == 1
    assert token.start

# Generated at 2022-06-18 12:37:55.278702
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': 1}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 15, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": [1, 2, 3]}') == DictToken({'a': 1, 'b': [1, 2, 3]}, 0, 24, '{"a": 1, "b": [1, 2, 3]}')

# Generated at 2022-06-18 12:38:04.255335
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 10, '[1, 2, 3]')

# Generated at 2022-06-18 12:38:14.327534
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:38:38.176460
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": "b", "c": "d"}, 0, 19, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({"a": "b", "c": "d", "e": "f"}, 0, 29, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:38:48.276680
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

# Generated at 2022-06-18 12:38:58.682748
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'),
        ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')
    }, 0, 19, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:39:07.588706
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "a": 1,
        "b": [
            "c",
            "d"
        ]
    }
    """
    token = tokenize_json(content)
    assert token.value == {
        "a": 1,
        "b": ["c", "d"],
    }
    assert token.start_position.line_no == 2
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 8
    assert token.end_position.column_no == 2



# Generated at 2022-06-18 12:39:18.452577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 16, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:39:29.579626
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:40.064123
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:39:47.616447
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:39:56.509836
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=9, line_no=1, char_index=8)
    assert token.content == content

    content = '{"a": "b"}\n{"c": "d"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:40:08.359143
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1

# Generated at 2022-06-18 12:40:25.425603
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_pos == 2
    assert token.children[0].end_pos == 4
    assert token.children[0].content == content
    assert token.children[1].value == 1
    assert token.children[1].start_pos == 7
    assert token.children[1].end_pos == 8
    assert token.children[1].content == content
    assert token.children[2].value == "b"

# Generated at 2022-06-18 12:40:36.337794
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == None
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": 1, "b": 2}, 0, 15, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:40:44.471143
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 7, 12, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:40:52.167682
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 14, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:41:02.557536
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('[1, 2, 3]') == ListToken(
        [
            ScalarToken(1, 1, 1, '[1, 2, 3]'),
            ScalarToken(2, 3, 3, '[1, 2, 3]'),
            ScalarToken(3, 5, 5, '[1, 2, 3]'),
        ],
        0,
        9,
        '[1, 2, 3]',
    )

# Generated at 2022-06-18 12:41:13.449361
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": "b", "c": "d"}, 0, 19, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({"a": "b", "c": "d", "e": "f"}, 0, 29, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:41:21.655118
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15

    token = tokenize_json('{"a": 1, "b": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": [1, 2, 3]}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position

# Generated at 2022-06-18 12:41:31.886589
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:41:43.682071
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:52.137073
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:42:09.208042
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[1].value == 1
    assert token.children[1].start == 6
    assert token.children[1].end == 6
    assert token.children[1].content == content
    assert token.children[2].value == "b"

# Generated at 2022-06-18 12:42:18.324339
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )



# Generated at 2022-06-18 12:42:28.631795
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:37.672338
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:47.702773
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:42:55.895575
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:43:06.806263
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )

# Generated at 2022-06-18 12:43:12.620935
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json('{"foo": "bar", "baz": "qux", "quux": "corge"}')
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.text == "Expecting value."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:43:20.145978
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2, "c": 3}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2, "c": 3}
    assert token.start_position.char_index == 0
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)

    content = '{"a": 1, "b": 2, "c": 3}'
    token = tokenize_json(content.encode("utf-8"))

# Generated at 2022-06-18 12:43:31.039128
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            "a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'),
            "b": ScalarToken(2, 10, 11, '{"a": 1, "b": 2}'),
        },
        0,
        17,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:43:51.061934
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '["a", 1, "b", 2]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", 1, "b", 2]
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content

    content = '["a", 1, "b", 2'

# Generated at 2022-06-18 12:43:57.214744
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:06.824558
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:44:19.107814
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 2, 5, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 10, 13, '{"a": "b", "c": "d"}')}, 0, 18, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:44:30.085114
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 13

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1