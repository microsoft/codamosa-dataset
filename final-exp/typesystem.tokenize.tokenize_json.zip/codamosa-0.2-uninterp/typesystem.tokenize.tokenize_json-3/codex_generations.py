

# Generated at 2022-06-18 12:34:53.404740
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d')}, 0, 17, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({'a': ScalarToken('b'), 'c': ScalarToken('d'), 'e': ScalarToken('f')}, 0, 25, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:35:03.674307
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 1
    assert exc_info.value.position.char_index == 0

    # Test invalid JSON
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("{")
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 2
    assert exc_info.value.position.char_index == 1

    # Test valid JSON


# Generated at 2022-06-18 12:35:11.392524
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 10, 11, '{"a": 1, "b": 2}')}, 0, 16, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:35:22.059020
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": [1, 2, 3]}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:35:33.474624
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.column_no == 2
        assert exc.position.line_no == 1
        assert exc.position.char_index == 1
    else:
        assert False, "Expected ParseError"

    # Test valid JSON

# Generated at 2022-06-18 12:35:40.614862
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 6, 7, '{"a": [1, 2]}'), ScalarToken(2, 9, 10, '{"a": [1, 2]}')], 5, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:53.444599
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:36:00.071985
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:36:09.752795
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0

    # Test invalid JSON
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.text == "Expecting value."
        assert exc.code == "parse_error"
        assert exc.position.column_no == 12
        assert exc.position.line_no == 1
        assert exc.position.char_index == 11

    # Test valid JSON

# Generated at 2022-06-18 12:36:19.193448
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1]}')], 5, 8, '{"a": [1]}')}, 0, 9, '{"a": [1]}')

# Generated at 2022-06-18 12:36:50.932830
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 8, '{"a": [1, 2]}')], 5, 9, '{"a": [1, 2]}')}, 0, 11, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:59.959915
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == content


# Generated at 2022-06-18 12:37:09.673937
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": ScalarToken("b", 3, 5, '{"a": "b", "c": "d"}'), "c": ScalarToken("d", 12, 14, '{"a": "b", "c": "d"}')}, 0, 17, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:37:20.038349
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:37:32.094876
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

# Generated at 2022-06-18 12:37:43.134084
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2, 3]}'), ScalarToken(2, 8, 9, '{"a": [1, 2, 3]}'), ScalarToken(3, 11, 12, '{"a": [1, 2, 3]}')], 3, 13, '{"a": [1, 2, 3]}')}, 0, 16, '{"a": [1, 2, 3]}')

# Generated at 2022-06-18 12:37:47.893596
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content


# Generated at 2022-06-18 12:37:58.997931
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
        assert exc.text == "Expecting property name enclosed in double quotes."

    # Test valid JSON

# Generated at 2022-06-18 12:38:06.588357
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({"a": ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:38:16.758278
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:38:33.821525
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.char_index == 0

    # Test invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{'foo': 'bar'}")
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.column_no == 2
    assert excinfo.value.position.char_index == 1

    # Test valid JSON

# Generated at 2022-06-18 12:38:38.170865
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 14, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )



# Generated at 2022-06-18 12:38:48.276424
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "2"}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": "2"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"

    content = '["a", 1, "b", "2"]'
    token = tokenize_json(content)
    assert token.value == ["a", 1, "b", "2"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "list"

    content = '"a"'
    token = tokenize_json(content)
    assert token.value == "a"


# Generated at 2022-06-18 12:38:54.535267
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Expected ParseError to be raised."

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"
        assert exc.position == Position(column_no=1, line_no=1, char_index=1)
    else:
        assert False, "Expected ParseError to be raised."



# Generated at 2022-06-18 12:38:59.333089
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_pos == 0
    assert token.end_pos == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:39:11.360178
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == len(content)
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:39:22.597391
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {"a": 1, "b": 2}, 0, 15, '{"a": 1, "b": 2}'
    )

# Generated at 2022-06-18 12:39:26.444715
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), 'b': ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:39:33.716502
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 16, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": [2, 3]}') == DictToken({'a': 1, 'b': [2, 3]}, 0, 21, '{"a": 1, "b": [2, 3]}')
    assert tokenize_json('{"a": 1, "b": [2, 3, {"c": 4}]}') == DictToken({'a': 1, 'b': [2, 3, {'c': 4}]}, 0, 36, '{"a": 1, "b": [2, 3, {"c": 4}]}')

# Generated at 2022-06-18 12:39:43.968020
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 2, 7, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 12, 17, '{"a": "b", "c": "d"}')}, 0, 19, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:39:56.000810
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 13, '{"a": [1, 2]}')}, 0, 16, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:05.235697
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == "b"
    assert token.children[1].type == "scalar"



# Generated at 2022-06-18 12:40:13.382403
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column

# Generated at 2022-06-18 12:40:22.913594
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 6, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 11, 12, '{"a": 1, "b": 2}'): ScalarToken(
                2, 16, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )


# Generated at 2022-06-18 12:40:33.682159
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:40:40.681657
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:40:49.669443
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": {"car1":"Ford", "car2":"BMW", "car3":"Fiat"}}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': {'car1': 'Ford', 'car2': 'BMW', 'car3': 'Fiat'}}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content

# Generated at 2022-06-18 12:41:01.104529
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.fields import String, Integer, Array, Dict, Boolean

    content = """
    {
        "name": "John Doe",
        "age": 42,
        "is_active": true,
        "favorite_colors": ["red", "blue", "green"]
    }
    """

    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-18 12:41:12.382526
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b"}')}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({'a': ScalarToken('b', 3, 6, '{"a": "b", "c": "d"}'), 'c': ScalarToken('d', 13, 16, '{"a": "b", "c": "d"}')}, 0, 18, '{"a": "b", "c": "d"}')

# Generated at 2022-06-18 12:41:18.834912
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": [{"model": "BMW 230", "mpg": 27.5}, {"model": "Ford Edge", "mpg": 24.1}]}'
    token = tokenize_json(content)
    assert token.value == {'name': 'John', 'age': 30, 'cars': [{'model': 'BMW 230', 'mpg': 27.5}, {'model': 'Ford Edge', 'mpg': 24.1}]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == 'dict'
    assert token.children[0].value == 'name'
    assert token.children[0].start == 2
    assert token.children[0].end == 7
   

# Generated at 2022-06-18 12:41:31.922251
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 1, 2, '{"a":1}'): ScalarToken(1, 5, 5, '{"a":1}')}, 0, 7, '{"a":1}')
    assert tokenize_json('{"a":1, "b":2}') == DictToken({ScalarToken('a', 1, 2, '{"a":1, "b":2}'): ScalarToken(1, 5, 5, '{"a":1, "b":2}'), ScalarToken('b', 10, 11, '{"a":1, "b":2}'): ScalarToken(2, 14, 14, '{"a":1, "b":2}')}, 0, 17, '{"a":1, "b":2}')


# Generated at 2022-06-18 12:41:43.723632
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:41:52.136814
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'),
        ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')
    }, 0, 20, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:03.204923
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}'
    token = tokenize_json(content)
    assert token.value == {"name": "John", "age": 30, "cars": ["Ford", "BMW", "Fiat"]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "name"
    assert token.children[0].type == "scalar"
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[1].value == "John"

# Generated at 2022-06-18 12:42:13.433541
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2
    assert token.children[3].type == "scalar"



# Generated at 2022-06-18 12:42:22.945821
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:42:33.941216
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')

# Generated at 2022-06-18 12:42:42.238951
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )
    assert tokenize_json('{"a": [1]}') == DictToken(
        {
            "a": ListToken(
                [ScalarToken(1, 7, 8, '{"a": [1]}')], 5, 9, '{"a": [1]}'
            )
        },
        0,
        11,
        '{"a": [1]}',
    )
    assert tokenize

# Generated at 2022-06-18 12:42:52.329789
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": ScalarToken(1, 5, 6, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 12, 13, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:43:03.760510
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": "c"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "c"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", 1, "c"]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == ["a", 1, "c"]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": "c"}'
    token = tokenize_json(content)
    assert isinstance

# Generated at 2022-06-18 12:43:18.719811
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 0, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 7, '{"a": 1, "b": 2}'),
            ScalarToken("b", 9, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 16, '{"a": 1, "b": 2}'),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:43:29.416712
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:39.518388
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:43:49.294917
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': 'bar'}, 0, 14, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken({'foo': 'bar', 'baz': 'qux'}, 0, 29, '{"foo": "bar", "baz": "qux"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux", "quux": "corge"}') == DictToken({'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}, 0, 44, '{"foo": "bar", "baz": "qux", "quux": "corge"}')

# Generated at 2022-06-18 12:43:56.243602
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 5, '[1, 2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')

# Generated at 2022-06-18 12:44:06.346466
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:44:18.623952
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:44:26.674855
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 1, '{"a": 1}'): ScalarToken(1, 4, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )