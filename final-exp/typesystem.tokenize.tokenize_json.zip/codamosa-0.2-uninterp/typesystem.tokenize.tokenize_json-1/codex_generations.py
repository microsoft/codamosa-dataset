

# Generated at 2022-06-18 12:35:10.391668
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 4, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:35:21.506160
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "John Doe",
        "age": 42,
        "address": {
            "street": "123 Main St.",
            "city": "Anytown",
            "state": "CA",
            "zip": "90210"
        },
        "phone": [
            {
                "type": "home",
                "number": "555-1212"
            },
            {
                "type": "work",
                "number": "555-1213"
            }
        ]
    }
    """
    token = tokenize_json(content)
    assert token.start_pos == Position(column_no=1, line_no=2, char_index=1)

# Generated at 2022-06-18 12:35:32.990232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

# Generated at 2022-06-18 12:35:40.314643
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 13, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 13, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 13, '{"a": 1, "b": 2}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({'a': 1, 'b': 2}, 0, 13, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:35:52.425738
# Unit test for function tokenize_json

# Generated at 2022-06-18 12:36:03.238971
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:36:12.301699
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({"a": ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'), "b": ScalarToken(2, 11, 12, '{"a": 1, "b": 2}')}, 0, 15, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:36:21.805735
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'),
        ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')
    }, 0, 18, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:36:29.948220
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:36:39.377926
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 10, '[1, 2, 3]')

# Generated at 2022-06-18 12:36:59.864771
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 7, 8, '{"a": 1, "b": 2}'),
        ScalarToken('b', 12, 13, '{"a": 1, "b": 2}'): ScalarToken(2, 18, 19, '{"a": 1, "b": 2}')
    }, 0, 20, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:37:09.599935
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 9, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 14, 15, '{"a": 1, "b": 2}')}, 0, 17, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:37:19.948232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 7, 11, '{"foo": "bar"}')}, 0, 15, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:37:31.894961
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:37:42.579359
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:47.942176
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 0, 1, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')
        },
        0,
        8,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:37:59.040735
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            "a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'),
            "b": ScalarToken(2, 8, 9, '{"a": 1, "b": 2}'),
        },
        0,
        14,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:38:03.499913
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {
            ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken(
                "bar", 10, 14, '{"foo": "bar"}'
            )
        },
        0,
        15,
        '{"foo": "bar"}',
    )



# Generated at 2022-06-18 12:38:14.074882
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)

    # Test invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{")
    assert excinfo.value.text == "Expecting property name enclosed in double quotes."
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=1)

    # Test valid JSON
    token = tokenize_

# Generated at 2022-06-18 12:38:23.773557
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:38:39.236131
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "foo": "bar",
        "baz": [1, 2, 3],
        "qux": {
            "a": "b",
            "c": "d"
        }
    }
    """
    token = tokenize_json(content)
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == len(content)
    assert token.start_position.line_no == 1
    assert token.end_position.line_no == 8
    assert token.start_position.column_no == 1
    assert token.end_position.column_no == 1


# Generated at 2022-06-18 12:38:48.823857
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken('bar', 9, 14, '{"foo": "bar"}')}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json(b'{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken('bar', 9, 14, '{"foo": "bar"}')}, 0, 15, '{"foo": "bar"}')

# Generated at 2022-06-18 12:38:59.213577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 0, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 8, '{"a": [1, 2]}'), ScalarToken(2, 10, 11, '{"a": [1, 2]}')], 6, 12, '{"a": [1, 2]}')}, 0, 14, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:11.274068
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            "a": ScalarToken(1, 3, 4, '{"a": 1, "b": 2}'),
            "b": ScalarToken(2, 10, 11, '{"a": 1, "b": 2}'),
        },
        0,
        16,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:39:22.512039
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[1].value == 1
    assert token.children[1].type == "scalar"
    assert token.children[2].value == "b"
    assert token.children[2].type == "scalar"
    assert token.children[3].value == 2
    assert token.children[3].type == "scalar"


# Generated at 2022-06-18 12:39:31.938738
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    token = tokenize_json(content)
    assert token.value == {"name": "John", "age": 30, "city": "New York"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "name"
    assert token.children[0].type == "scalar"
    assert token.children[0].start == 2
    assert token.children[0].end == 7
    assert token.children[0].content == content
    assert token.children[1].value == "John"
    assert token.children[1].type == "scalar"

# Generated at 2022-06-18 12:39:42.922500
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:39:53.490028
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            "a": ScalarToken(1, 2, 3, '{"a": 1, "b": 2}'),
            "b": ScalarToken(2, 8, 9, '{"a": 1, "b": 2}'),
        },
        0,
        14,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:40:05.469626
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 2, '{"a": "b"}'): ScalarToken('b', 6, 8, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:40:13.542641
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 5, '{"a": 1, "b": 2}'),
        ScalarToken('b', 8, 9, '{"a": 1, "b": 2}'): ScalarToken(2, 12, 12, '{"a": 1, "b": 2}')
    }, 0, 17, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:40:40.194326
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:40:44.974830
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": "b"}'): ScalarToken("b", 6, 8, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )



# Generated at 2022-06-18 12:40:52.509023
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test for invalid JSON
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 13
        assert exc.position.char_index == 12
        assert exc.text == "Expecting value."

    # Test for valid JSON

# Generated at 2022-06-18 12:41:02.710661
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [2, 3], "c": {"d": 4, "e": 5}}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": [2, 3], "c": {"d": 4, "e": 5}}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[0].start == 2
    assert token.children[0].end == 3
    assert token.children[0].content == content
    assert token.children[1].value == 1

# Generated at 2022-06-18 12:41:13.566283
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 2, '[1, 2]'), ScalarToken(2, 4, 5, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:41:21.687223
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:41:31.885661
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:41:43.681631
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert token.value == {"a": 1}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 7
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 6
    assert token.content == '{"a": 1}'
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].type == "scalar"
    assert token.children[0].start_position.line_no == 1

# Generated at 2022-06-18 12:41:50.498371
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

# Generated at 2022-06-18 12:42:01.885986
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:42:33.607487
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:42:40.809032
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == 14
    assert token.content == '{"a": 1, "b": 2}'
    assert token.children[0].value == "a"
    assert token.children[0].start == 2
    assert token.children[0].end == 4
    assert token.children[0].content == '{"a": 1, "b": 2}'
    assert token.children[1].value == 1
    assert token.children[1].start == 7
    assert token.children[1].end == 8

# Generated at 2022-06-18 12:42:46.356605
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.content == content


# Generated at 2022-06-18 12:42:55.087346
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.char_index == 0
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)
    assert token.content == content

    content = '[1, 2, 3]'
    token = tokenize_json(content)
    assert token.value == [1, 2, 3]
    assert token.start_position.char_index == 0
    assert token.start

# Generated at 2022-06-18 12:43:06.055024
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:43:17.744506
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 7, 8, '{"a": "b"}')}, 0, 10, '{"a": "b"}')

# Generated at 2022-06-18 12:43:28.578158
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'),
        ScalarToken('b', 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')
    }, 0, 19, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:43:38.640400
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 7, 7, '{"a": [1, 2]}'), ScalarToken(2, 10, 10, '{"a": [1, 2]}')], 6, 11, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:43:48.522833
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 9, 13, '{"foo": "bar"}')},
        0,
        14,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-18 12:43:55.743812
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 19, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:44:23.364977
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 14, 15, '{"a": 1, "b": 2}'
            ),
        },
        0,
        16,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:44:33.219469
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )