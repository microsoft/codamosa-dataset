

# Generated at 2022-06-18 12:34:50.018786
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )

# Generated at 2022-06-18 12:35:01.480029
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test empty object
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    # Test empty array
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []

    # Test simple object
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}

    # Test simple array
    token = tokenize_json('["foo", "bar"]')
    assert isinstance(token, ListToken)
    assert token.value == ["foo", "bar"]

    # Test simple scal

# Generated at 2022-06-18 12:35:09.649255
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {"a": ScalarToken("b", 2, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}'
    )
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken(
        {
            "a": ScalarToken("b", 2, 5, '{"a": "b", "c": "d"}'),
            "c": ScalarToken("d", 10, 13, '{"a": "b", "c": "d"}'),
        },
        0,
        18,
        '{"a": "b", "c": "d"}',
    )

# Generated at 2022-06-18 12:35:20.955738
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("123") == ScalarToken(123, 0, 3, "123")
    assert tokenize_json("123.4") == ScalarToken(123.4, 0, 5, "123.4")

# Generated at 2022-06-18 12:35:32.945030
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:35:41.667936
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

# Generated at 2022-06-18 12:35:54.276595
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("123") == ScalarToken(123, 0, 3, "123")
    assert tokenize_json("123.4") == ScalarToken(123.4, 0, 5, "123.4")

# Generated at 2022-06-18 12:36:00.840493
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": {"b": "c"}}'
    token = tokenize_json(content)
    assert token.value == {"a": {"b": "c"}}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 17

    content = '{"a": {"b": "c"}}\n'
    token = tokenize_json(content)
    assert token.value == {"a": {"b": "c"}}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no

# Generated at 2022-06-18 12:36:10.524625
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 9, '{"a": "b"}')
    assert tokenize

# Generated at 2022-06-18 12:36:20.310534
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1, 1, 1, '[1, 2, 3]'), ScalarToken(2, 4, 4, '[1, 2, 3]'), ScalarToken(3, 7, 7, '[1, 2, 3]')], 0, 9, '[1, 2, 3]')

# Generated at 2022-06-18 12:36:38.120853
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 4, 9, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-18 12:36:49.161224
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 7, '{"a": 1, "b": 2}'),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 16, '{"a": 1, "b": 2}'),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:37:00.152739
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:37:09.819215
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '["a", "b"]'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:37:20.172974
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:37:32.380834
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 3, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:37:43.443811
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{\"foo\": \"bar\"}") == DictToken(
        {"foo": ScalarToken("bar", 6, 11, "{\"foo\": \"bar\"}")}, 0, 15, "{\"foo\": \"bar\"}"
    )
    assert tokenize_json("[1, 2, 3]") == ListToken(
        [
            ScalarToken(1, 1, 2, "[1, 2, 3]"),
            ScalarToken(2, 4, 5, "[1, 2, 3]"),
            ScalarToken(3, 7, 8, "[1, 2, 3]"),
        ],
        0,
        9,
        "[1, 2, 3]",
    )
    assert tokenize_json

# Generated at 2022-06-18 12:37:55.054681
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == content
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].start_position.char

# Generated at 2022-06-18 12:38:04.069147
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")

# Generated at 2022-06-18 12:38:14.282840
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")
    assert tokenize_json("1e1") == ScalarToken(10, 0, 3, "1e1")

# Generated at 2022-06-18 12:38:26.507543
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John Doe", "age": 42, "address": {"street": "123 Main St", "city": "Anytown", "state": "CA"}}'
    token = tokenize_json(content)
    assert token.value == {
        "name": "John Doe",
        "age": 42,
        "address": {"street": "123 Main St", "city": "Anytown", "state": "CA"},
    }
    assert token.start == 0
    assert token.end == len(content) - 1

    content = '{"name": "John Doe", "age": 42, "address": {"street": "123 Main St", "city": "Anytown", "state": "CA"}}'
    token = tokenize_json(content)

# Generated at 2022-06-18 12:38:36.795682
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': 'bar'}, 0, 14, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux"}') == DictToken({'foo': 'bar', 'baz': 'qux'}, 0, 29, '{"foo": "bar", "baz": "qux"}')
    assert tokenize_json('{"foo": "bar", "baz": "qux", "quux": "corge"}') == DictToken({'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}, 0, 44, '{"foo": "bar", "baz": "qux", "quux": "corge"}')

# Generated at 2022-06-18 12:38:47.769930
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken({"a": "b", "c": "d"}, 0, 18, '{"a": "b", "c": "d"}')
    assert tokenize_json('{"a": "b", "c": "d", "e": "f"}') == DictToken({"a": "b", "c": "d", "e": "f"}, 0, 27, '{"a": "b", "c": "d", "e": "f"}')

# Generated at 2022-06-18 12:38:58.260872
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=14, line_no=1, char_index=13)

    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-18 12:39:09.770618
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == 13
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == 12

    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1

# Generated at 2022-06-18 12:39:21.269918
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 4, '{"foo": "bar"}'): ScalarToken('bar', 9, 13, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}')

# Generated at 2022-06-18 12:39:31.080973
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')

# Generated at 2022-06-18 12:39:40.792001
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json returns a Token object
    assert isinstance(tokenize_json('{"a": "b"}'), Token)
    # Test that tokenize_json raises an error if the content is empty
    with pytest.raises(ParseError):
        tokenize_json('')
    # Test that tokenize_json raises an error if the content is not valid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"a": "b"')
    # Test that tokenize_json raises an error if the content is not valid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"a": "b"')


# Generated at 2022-06-18 12:39:48.025681
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1.0}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1.0}'): ScalarToken(1.0, 6, 8, '{"a": 1.0}')}, 0, 10, '{"a": 1.0}')

# Generated at 2022-06-18 12:39:53.368580
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9


# Generated at 2022-06-18 12:40:09.742224
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"
        assert exc.position == Position(column_no=1, line_no=1, char_index=1)
    else:
        assert False, "Expected ParseError"

    # Test valid JSON


# Generated at 2022-06-18 12:40:19.853871
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )

# Generated at 2022-06-18 12:40:23.839842
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')},
        0,
        9,
        '{"a": "b"}',
    )



# Generated at 2022-06-18 12:40:34.505410
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 6, 7, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 11, '{"a": 1, "b": 2}'): ScalarToken(
                2, 15, 16, '{"a": 1, "b": 2}'
            ),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:40:41.865070
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 0, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 7, '{"a": 1, "b": 2}'),
            ScalarToken("b", 9, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 16, '{"a": 1, "b": 2}'),
        },
        0,
        18,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:40:45.481245
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-18 12:40:55.405932
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:41:01.982592
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.content == content


# Generated at 2022-06-18 12:41:09.816354
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.end_position.char_index == 13
    assert token.content == content


# Generated at 2022-06-18 12:41:18.818592
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1, '[1, 2]'), ScalarToken(2, 4, 4, '[1, 2]')], 0, 6, '[1, 2]')

# Generated at 2022-06-18 12:41:29.979767
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert token.value == {"a": "b"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 9
    assert token.content == content



# Generated at 2022-06-18 12:41:41.812447
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken('a', 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 5, 5, '{"a": [1, 2]}'), ScalarToken(2, 8, 8, '{"a": [1, 2]}')], 4, 9, '{"a": [1, 2]}')}, 0, 11, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:41:49.396524
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken('bar', 9, 14, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken('bar', 9, 14, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}')

# Generated at 2022-06-18 12:41:54.737785
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {
            ScalarToken("a", 0, 1, '{"a": 1}'): ScalarToken(
                1, 6, 6, '{"a": 1}'
            )
        },
        0,
        9,
        '{"a": 1}',
    )



# Generated at 2022-06-18 12:42:06.330901
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:42:16.753743
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken("a", 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({ScalarToken("a", 1, 2, '{"a": [1, 2]}'): ListToken([ScalarToken(1, 6, 6, '{"a": [1, 2]}'), ScalarToken(2, 9, 9, '{"a": [1, 2]}')], 5, 10, '{"a": [1, 2]}')}, 0, 12, '{"a": [1, 2]}')

# Generated at 2022-06-18 12:42:26.627943
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "Expected ParseError"

    # Test invalid JSON
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1
    else:
        assert False, "Expected ParseError"

    # Test valid JSON

# Generated at 2022-06-18 12:42:36.298151
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({
        ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 7, 7, '{"a": 1, "b": 2}'),
        ScalarToken('b', 13, 14, '{"a": 1, "b": 2}'): ScalarToken(2, 19, 19, '{"a": 1, "b": 2}')
    }, 0, 21, '{"a": 1, "b": 2}')

# Generated at 2022-06-18 12:42:46.141154
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-18 12:42:50.783463
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')


# Generated at 2022-06-18 12:43:05.700019
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 2, 5, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-18 12:43:17.387355
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

    content = '{"a":1, "b":2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14

# Generated at 2022-06-18 12:43:27.909577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-18 12:43:38.120244
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1}'): ScalarToken(1, 6, 6, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 1, 2, '{"a": 1, "b": 2}'): ScalarToken(1, 6, 6, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 12, '{"a": 1, "b": 2}'): ScalarToken(2, 16, 16, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-18 12:43:48.076434
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == len(content)
    assert token.content == content
    assert token.type == "dict"
    assert token.children[0].value == "a"
    assert token.children[0].start_position.line_no == 1
    assert token.children[0].start_position.column_no == 2
    assert token.children[0].end_position.line_no == 1
    assert token.children[0].end_

# Generated at 2022-06-18 12:43:55.435481
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == 13
    assert token.content == '{"a": 1, "b": 2}'

    token = tokenize_json('{"a": 1, "b": 2}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}
    assert token.start == 0
    assert token.end == 13
    assert token.content == '{"a": 1, "b": 2}'

    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token

# Generated at 2022-06-18 12:44:05.910658
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"a": 1, "b": 2}'
    token = tokenize_json(json_string)
    assert token.value == {"a": 1, "b": 2}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 15
    assert token.end_position.char_index == 14
    assert token.content == json_string

    json_string = '{"a": 1, "b": 2}'
    token = tokenize_json(json_string.encode("utf-8"))
    assert token.value == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:44:18.167944
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 3, '{"a": 1}'): ScalarToken(1, 6, 7, '{"a": 1}')},
        0,
        9,
        '{"a": 1}',
    )

# Generated at 2022-06-18 12:44:26.410412
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 13, 14, '{"a": 1, "b": 2}'): ScalarToken(
                2, 19, 20, '{"a": 1, "b": 2}'
            ),
        },
        0,
        21,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-18 12:44:35.738974
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2]}') == DictToken({'a': ListToken([ScalarToken(1, 5, 6, '{"a": [1, 2]}'), ScalarToken(2, 8, 9, '{"a": [1, 2]}')], 4, 10, '{"a": [1, 2]}')}, 0, 13, '{"a": [1, 2]}')