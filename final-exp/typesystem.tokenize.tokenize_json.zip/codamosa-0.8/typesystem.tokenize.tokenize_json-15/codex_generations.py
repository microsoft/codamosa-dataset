

# Generated at 2022-06-12 16:01:33.365308
# Unit test for function tokenize_json
def test_tokenize_json():
    test_input = '{"a": "1", "b": "2"}'
    result = tokenize_json(test_input)
    expected = {'a': '1', 'b': '2'}
    assert result == expected


# Generated at 2022-06-12 16:01:36.300703
# Unit test for function tokenize_json
def test_tokenize_json():
    root_token = tokenize_json("{}")
    assert isinstance(root_token, DictToken)
    assert root_token.is_root()
    assert not root_token.children
    assert not root_token.get("key", raise_error=False)



# Generated at 2022-06-12 16:01:40.090827
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "Gopi"}') == {'name': 'Gopi'}


# Generated at 2022-06-12 16:01:43.649799
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("123") == ScalarToken("123")
    assert tokenize_json("[1, 2, 3]") == ListToken(["1", "2", "3"])
    assert tokenize_json('{"a": "123"}') == DictToken({"a": "123"})



# Generated at 2022-06-12 16:01:47.849884
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello": [3, "world"]}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value["hello"], ListToken)
    assert token.value["hello"].value == [3, "world"]



# Generated at 2022-06-12 16:01:56.055984
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:02:00.507903
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'

    token = tokenize_json(content)
    assert token == DictToken(
        {"a": ScalarToken(1, 2, 3, content), "b": ScalarToken(2, 9, 10, content)},
        0,
        14,
        content,
    )

    content = '{"a": 1, "b": 2}{"a": 1, "b": 2}'

    try:
        tokenize_json(content)
    except ParseError:
        pass
    else:
        assert False, "expected ParseError"


# Unit tests for function validate_json

# Generated at 2022-06-12 16:02:11.467893
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:02:20.820170
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "Your name"}') == {
        "name": "Your name"
    }
    assert tokenize_json('{"name": "Your name", "age": 20}') == {
        "name": "Your name",
        "age": 20,
    }
    assert tokenize_json('[1, 2, "John"]') == [1, 2, "John"]
    assert tokenize_json('["hello", "world"]') == ["hello", "world"]
    assert tokenize_json('{"isTrue": true}') == {"isTrue": True}
    assert tokenize_json('{"isFalse": false}') == {"isFalse": False}
    assert tokenize_json('{"isNull": null}') == {"isNull": None}



# Generated at 2022-06-12 16:02:31.538793
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")

# Generated at 2022-06-12 16:02:57.950665
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "f1": "test",
        "f2": [
            1,
            2,
            3,
            4
        ]
        }"""
    token = tokenize_json(content)
    assert token["f1"] == "test"
    assert token["f2"] == [1, 2, 3, 4]



# Generated at 2022-06-12 16:03:04.993807
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"test": "value"}') == {'test': 'value'}
    assert tokenize_json('{"test": null}') == {'test': None}
    assert tokenize_json('{"test": true}') == {'test': True}
    assert tokenize_json('{"test": false}') == {'test': False}
    assert tokenize_json('{"test": [1]}') == {'test': [1]}
    assert tokenize_json('{"test": [1, 2]}') == {'test': [1, 2]}
    assert tokenize_json('{"test": {"nested": "value"}}') == {'test': {'nested': 'value'}}
    assert tokenize_json('{"test": 1.23}') == {'test': 1.23}
    assert token

# Generated at 2022-06-12 16:03:16.277780
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test errors
    # No content
    try:
        tokenize_json("")
    except ParseError as error:
        assert error.position is not None
        assert error.position.line_no == 1
        assert error.position.column_no == 1
        assert error.position.char_index == 0
        assert error.text == "No content."
    else:
        assert False

    # JSON string error
    try:
        tokenize_json("{")
    except ParseError as error:
        assert error.position is not None
        assert error.position.line_no == 1
        assert error.position.column_no == 2
        assert error.position.char_index == 1
        assert error.text == "Unterminated string starting at line 1 column 1."
    else:
        assert False

    # JSON parse

# Generated at 2022-06-12 16:03:22.902868
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
    "name": "John",
    "age": 30,
    "cars": [
        { "name": "Ford", "models": ["Fiesta", "Focus", "Mustang"] },
        { "name": "BMW", "models": ["320", "X3", "X5"] },
        { "name": "Fiat", "models": ["500", "Panda"] }
    ]}
    """
    token = tokenize_json(content)

# Generated at 2022-06-12 16:03:29.996558
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import pprint
    json_string="""{
    "foo": [1, 2, 3],
    "bar": "hi",
    "baz": true,
    "qux": {"foo": "bar"},
    "quux": null
}"""
    json_dict=json.loads(json_string)
    token=tokenize_json(json_string)
    assert token.value==json_dict, pprint.pformat(token.value)
    print(token)
    assert str(token) == json_string, json_string



# Generated at 2022-06-12 16:03:37.675369
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = r"""
    {
        "a": 1
    }
    """
    invalid_json = r"""
    {
        "a": 1a
    }
    """
    token = tokenize_json(valid_json)
    assert type(token) is DictToken
    assert len(token.children) == 1
    assert type(token.children[0][0]) is ScalarToken
    assert token.children[0][0].value == "a"

    with pytest.raises(ParseError):
        token = tokenize_json(invalid_json)


# Generated at 2022-06-12 16:03:42.418444
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert token.value == {'key': 'value'}
    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.column_no == 15
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == 14



# Generated at 2022-06-12 16:03:45.372271
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"message":"hello"}') == DictToken({"message": "hello"}, 0, 18, '{"message":"hello"}')


# Generated at 2022-06-12 16:03:55.307063
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("1") == tokenize_json(b"1")
    assert tokenize_json("[1]") == tokenize_json(b"[1]")
    assert tokenize_json("[]") == tokenize_json(b"[]")
    assert tokenize_json("{}") == tokenize_json(b"{}")
    assert tokenize_json("{}") == tokenize_json(b"{}")
    assert tokenize_json('{"one":1}') == tokenize_json(b'{"one":1}')
    assert tokenize_json("x") == tokenize_json(b"x")
    assert tokenize_json("[\"s\"") == tokenize_json(b"[\"s\"")
    assert tokenize_json("") == tokenize_json(b"")
   

# Generated at 2022-06-12 16:04:01.067024
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"hello": "world", "foo": [1.0, 2.0]}"""
    token = tokenize_json(content)
    assert token.children[0].children[0].value == "hello"
    assert token.children[0].children[1].value == "world"
    assert token.children[0].children[2].value == "foo"
    assert token.children[0].children[3].value[0] == 1.0
    assert token.children[0].children[3].value[1] == 2.0



# Generated at 2022-06-12 16:04:11.936128
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that tokenize_json() generates correct tokens for the various types
    of values that can be represented in JSON
    """

    # Verify that passing an empty string raises a ParseError as expected.
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")

    # Verify that passing a non-JSON string raises a ParseError as expected.
    with pytest.raises(ParseError, match="Expecting value, found 'foo'"):
        tokenize_json("foo")

    # Verify that passing a number raises a ParseError as expected.
    with pytest.raises(ParseError, match="Expecting value, found '42'"):
        tokenize_json("42")

    # Verify that passing a string is parsed to a ScalarToken

# Generated at 2022-06-12 16:04:22.582935
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This unit test verifies that tokenize_json is working properly.
    """
    # Test validation with a valid string
    value, errors = validate_json(
        json.dumps({"text": "Hello, world!"}),
        {"text": Field(str)},
    )
    assert value == {"text": "Hello, world!"}
    assert errors == []

    # Test validation with an invalid string
    value, errors = validate_json(
        json.dumps({"text": 42}),
        {"text": Field(str)},
    )
    assert value is None

# Generated at 2022-06-12 16:04:28.652495
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import json

    json_content = r"""
    {
        "foo": "bar",
        "baz": null,
        "qux": [
            true,
            false,
            -1,
            0.123,
            [1, 2, 3],
            {
                "lorem": 1,
                "ipsum": 2,
                "dolor": 3
            }
        ]
    }
    """
    assert tokenize_json(json_content) == json.loads(json_content)


# Generated at 2022-06-12 16:04:36.070099
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = "{'name':'Joe','age':30}"
    pos = Position(column_no=1, line_no=1, char_index=1)
    with pytest.raises(ParseError) as excinfo:
        validate_json(content=valid_json, validator=Schema)

    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == pos
    assert excinfo.value.text == "Expecting property name enclosed in double quotes"



# Generated at 2022-06-12 16:04:42.055259
# Unit test for function tokenize_json
def test_tokenize_json():
    assert type(tokenize_json("[]")) is ListToken
    assert type(tokenize_json('{"foo": [1]}')) is DictToken
    assert type(tokenize_json('"foo"')) is ScalarToken
    assert tokenize_json('{"foo": [1]}')["foo"][0] == ScalarToken(1, 12, 12)

    try:
        tokenize_json("{")
        assert False
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1



# Generated at 2022-06-12 16:04:45.657573
# Unit test for function tokenize_json
def test_tokenize_json():
    print('test_tokenize_json')
    content = '{"name":"Rob","movies":[{"name":"Goodfellas"},{"name":"Barton Fink"},{"name":"Pulp Fiction"},{"name":"Travis Bickle"},{"name":"Armando"}]}'
    token = tokenize_json(content)
    print(token)

# Generated at 2022-06-12 16:04:51.129032
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":null,"b":true,"c":false,"d":[0,1.5,2]}'
    token = tokenize_json(content)
    assert token.value == {"a": None, "b": True, "c": False, "d": [0, 1.5, 2]}


# Generated at 2022-06-12 16:05:02.239051
# Unit test for function tokenize_json
def test_tokenize_json():
    raw_json = '{"one": 1, "two": 2}'
    tokens = tokenize_json(raw_json)
    assert type(tokens).__name__ == "DictToken"
    assert tokens.start_pos == 0
    assert tokens.end_pos == 21
    assert tokens.value == {"one": 1, "two": 2}
    assert type(tokens.children[0]).__name__ == "ScalarToken"
    assert tokens.children[0].start_pos == 1
    assert tokens.children[0].end_pos == 5
    assert tokens.children[0].value == "one"
    assert type(tokens.children[1]).__name__ == "ScalarToken"
    assert tokens.children[1].start_pos == 7
    assert tokens.children[1].end_pos

# Generated at 2022-06-12 16:05:13.382616
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json_1 = '{"foo": [1, 2, 3]}'
    expected_tokenized_1 = DictToken(
        {"foo": ListToken([1, 2, 3])}, start=0, end=20, content=valid_json_1
    )
    assert tokenize_json(valid_json_1) == expected_tokenized_1

    valid_json_2 = '{"foo": [1, 2, 3], "bar": true, "baz": 1.1, "qux": "qux"}'

# Generated at 2022-06-12 16:05:24.320639
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == DictToken({ScalarToken('hello', 0, 6, '{"hello": "world"}'): ScalarToken('world', 13, 20, '{"hello": "world"}')}, 0, 20, '{"hello": "world"}')
    assert tokenize_json('[{"hello": "world"}]') == ListToken([DictToken({ScalarToken('hello', 1, 7, '[{"hello": "world"}]'): ScalarToken('world', 14, 21, '[{"hello": "world"}]')}, 1, 21, '[{"hello": "world"}]')], 0, 22, '[{"hello": "world"}]')
    assert tokenize_json('') is None
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')

# Generated at 2022-06-12 16:05:34.982612
# Unit test for function tokenize_json
def test_tokenize_json():
    class BookSchema(Schema):
        title = Field(type="string")
        year = Field(type="integer")
        description = Field(type="string")
        author = Field(type="string")

    test_string = """
    [
      {
        "title": "Toni Morrison",
        "year": "1987",
        "description": "Toni Morrison's first book, it was nominated for the National Book Award in 1977.",
        "author": "used to be"
      }
    ]
    """
    token = tokenize_json(test_string)
    import sys
    import types
    for name, obj in types.getmembers(sys.modules[__name__]):
        if isinstance(obj, types.FunctionType):
            obj()

# Generated at 2022-06-12 16:05:43.735875
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test some basic functionality & edge cases
    # Test data taken from https://json.org/example.html

    assert tokenize_json("") == None

    assert tokenize_json('"hello world"') == ScalarToken("hello world", 0, 13, '"hello world"')
    assert tokenize_json('[1]') == ListToken([ScalarToken(1, 1, 1, '"1"')], 0, 2, '[1]')
    assert tokenize_json('{"foo":"bar"}') == DictToken({ScalarToken('foo', 1, 4, '"foo"'): ScalarToken('bar', 7, 10, '"bar"')}, 0, 13, '{"foo":"bar"}')

# Generated at 2022-06-12 16:05:54.105876
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), dict)
    assert isinstance(tokenize_json("[]"), list)
    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("{") == ParseError(
        text="Expecting property name enclosed in double quotes", code="parse_error",
        position=Position(char_index=1, line_no=1, column_no=1)
    )
    assert tokenize_json("{,") == ParseError(
        text="Expecting property name enclosed in double quotes", code="parse_error",
        position=Position(char_index=1, line_no=1, column_no=1)
    )

# Generated at 2022-06-12 16:06:02.193307
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{
        "str-key": "str",
        "true-key": true,
        "false-key": false,
        "int-key": 1,
        "float-key": 1.23e+10,
        "null-key": null,
        "list-key": [1, 2, 3],
        "dict-key": {
            "a": "apple",
            "b": "banana",
            "c": "carrot"
        }
    }""")
    assert isinstance(token, DictToken)
    assert len(token.value) == 8
    assert isinstance(token.value["str-key"], ScalarToken)
    assert token.value["str-key"].value == "str"

# Generated at 2022-06-12 16:06:11.288791
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("1.0"), ScalarToken)
    assert isinstance(tokenize_json('"Hello"'), ScalarToken)
    assert isinstance(tokenize_json("true"), ScalarToken)
    assert isinstance(tokenize_json("false"), ScalarToken)
    assert isinstance(tokenize_json("null"), ScalarToken)
    assert isinstance(tokenize_json("[1.0]"), ListToken)
    assert isinstance(tokenize_json('["Hello"]'), ListToken)
    assert isinstance(tokenize_json("[true]"), ListToken)
    assert isinstance(tokenize_json("[false]"), ListToken)
    assert isinstance(tokenize_json("[null]"), ListToken)

# Generated at 2022-06-12 16:06:18.439460
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"A": [1, 2, 3], "B": {"C": {"D": {"E": "F"}}}}'
    decoded_dict = tokenize_json(content)
    assert type(decoded_dict) is DictToken
    assert decoded_dict.value.get("A").value[0].value == 1
    assert decoded_dict.value.get("A").value[1].value == 2
    assert decoded_dict.value.get("A").value[2].value == 3

# Generated at 2022-06-12 16:06:25.916239
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """
    {
        "key1": 1,
        "key2": "value",
        "key3": ["a", "b", "c"],
        "key4": {"key5": true, "key6": false, "key7": null }
    }
    """
    json_str = json_str.strip()
    token = tokenize_json(json_str)
    assert token.token_type == "dict"
    assert token.items[0].key.value == "key1"
    assert token.items[0].value.value == 1
    assert token.items[1].key.value == "key2"
    assert token.items[1].value.value == "value"
    assert token.items[2].key.value == "key3"
    assert token.items[2].value

# Generated at 2022-06-12 16:06:32.992160
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    json_string = """{
    "foo": 1,
    "bar": 2
}"""

    token = tokenize_json(json_string)
    assert token.value == json.loads(json_string)
    assert isinstance(token, DictToken)
    assert isinstance(list(token.value.keys())[0], ScalarToken)
    assert token.start_position.line == 1
    assert token.start_position.column == 0
    assert token.end_position.line == 5
    assert token.end_position.column == 1



# Generated at 2022-06-12 16:06:37.511139
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":1}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert isinstance(token.value['a'], ScalarToken)
    assert token.value['a'].value == 1


# Generated at 2022-06-12 16:06:46.547436
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": ["bar", 3.14, true]}')
    assert isinstance(token, DictToken)
    assert token.data == {"foo": ["bar", 3.14, True]}
    assert token.start == 0
    assert token.end == 32
    assert token.content == '{"foo": ["bar", 3.14, true]}'
    assert token.length == 33
    assert token.text == '{"foo": ["bar", 3.14, true]}'
    assert token.start == token.position.char_index
    assert token.end == token.position.char_index + token.length

    assert isinstance(token.data.get("foo"), ListToken)
    token = token.data.get("foo")
    assert token.data == ["bar", 3.14, True]
    assert token

# Generated at 2022-06-12 16:06:54.309359
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = '''{
        "name": "John Smith",
        "age": 32
    }'''

    token = tokenize_json(test_json)
    assert isinstance(token, DictToken)



# Generated at 2022-06-12 16:06:58.590340
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """{"foo": "bar", "baz": {"spam": [1,2,3]}}"""
    assert (
        tokenize_json(json)
        == DictToken(
            {
                "foo": ScalarToken("bar"),
                "baz": DictToken({"spam": ListToken([1, 2, 3])}),
            },
            0,
            46,
            json,
        )
    )



# Generated at 2022-06-12 16:07:01.231192
# Unit test for function tokenize_json
def test_tokenize_json():
    # The unit test for the tokenize_json function
    assert validate_json('"this is a string"', str) != None

# Generated at 2022-06-12 16:07:05.889465
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
      {
        "foo": {"bar": "baz", "baz": "bar"}
      }
    """
    result = tokenize_json(content)
    assert result.to_json(indent=2) == content


# Generated at 2022-06-12 16:07:14.066814
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"x": 1, "hello": [1,2,3], "yeah": ["y", "a", "h"]}'
    token = tokenize_json(json_str)
    assert isinstance(token, Token)
    assert token.value == {
        'x': 1,
        'hello': [1, 2, 3],
        'yeah': ['y', 'a', 'h']
    }
    assert token.line_no == 1
    assert token.column_no == 1
    assert token.end_line_no == 1
    assert token.end_column_no == 52

    # Test for an empty JSON string.
    with pytest.raises(ParseError) as exc:
        tokenize_json("")
    error = exc.value
    assert error.text == "No content."


# Generated at 2022-06-12 16:07:24.062017
# Unit test for function tokenize_json
def test_tokenize_json():
    dicttok = tokenize_json('{"a": 1, "b": [1, 2, 3], "c": {"a": 1, "b": [1, 2, 3]}}')

# Generated at 2022-06-12 16:07:33.556617
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{"name": "bob"}""")
    assert token.type == "dict"
    assert token.value == {"name": "bob"}
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.start_position.char_index == 0
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 12
    assert token.end_position.char_index == 11

    token = tokenize_json("""
        {"name": "bob"}
    """)
    assert token.type == "dict"
    assert token.value == {"name": "bob"}
    assert token.start_position.line_no == 2
    assert token.start_position.column_no

# Generated at 2022-06-12 16:07:42.486713
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_token_init(token: Token, raw, start, end, content: str = '') -> None:
        assert token.raw == raw
        assert token.start == start
        assert token.end == end
        assert token.content == content
        assert str(token.position) == "{}:{}".format(token.start, token.end)

    content = '{"name": "John Doe", "age": 42}'
    token = tokenize_json(content)
    assert_token_init(token, '', 0, 29, content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-12 16:07:51.284178
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}

    token = tokenize_json('{"hello": true}')
    assert token.value == {"hello": ScalarToken(True, 6, 10, '{"hello": true}')}

    token = tokenize_json('{"hello": [1, 2, 3]}')

# Generated at 2022-06-12 16:07:55.303711
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("hello world")
    assert not tokenize_json("")
    assert tokenize_json("""{
        "users": [{"name": "bob", "age": 32}, {"name": "Alice", "age": 24}]
    }""")


# Generated at 2022-06-12 16:08:07.053326
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"name": "Alice", "age": 35, "hobbies": ["running", "swimming"]}'
    json_bytes = json_string.encode("utf-8")
    assert tokenize_json(json_string) == tokenize_json(json_bytes)

    empty_string = ""
    empty_bytes = empty_string.encode("utf-8")
    assert tokenize_json(empty_string) == tokenize_json(empty_bytes)



# Generated at 2022-06-12 16:08:12.005284
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json("[]"), ListToken)
    assert isinstance(tokenize_json('{"foo": "bar"}'), DictToken)
    assert isinstance(tokenize_json('["foo", "bar"]'), ListToken)
    assert isinstance(tokenize_json('42'), ScalarToken)
    assert isinstance(tokenize_json('3.14'), ScalarToken)
    assert isinstance(tokenize_json('true'), ScalarToken)
    assert isinstance(tokenize_json('false'), ScalarToken)
    assert isinstance(tokenize_json('null'), ScalarToken)



# Generated at 2022-06-12 16:08:16.756646
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''{
        "name": "john doe",
        "age": 42,
        "brothers": [
            {
                "name": "joe doe",
                "age": 40
            },
            {
                "name": "jack doe",
                "age": 38
            },
            {
                "name": "joshua doe",
                "age": 36
            }
        ]
    }'''

    token = tokenize_json(content)
    assert token.value.keys() == {"name", "age", "brothers"}

    brothers = token.value.get("brothers")
    assert brothers.value[0].value["name"] == "joe doe"



# Generated at 2022-06-12 16:08:27.738467
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:08:38.382482
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """
    {
        "person": {
            "name": {
                "first": "John",
                "last": "Doe"
            },
            "age": 21,
            "likes": ["python", "dancing"]
        },
        "job": [
            "developer",
            "tester",
            {
                "title": "QA Engineer",
                "years": 5
            }
        ],
        "is_funny": true
    }
    """

# Generated at 2022-06-12 16:08:49.628192
# Unit test for function tokenize_json
def test_tokenize_json():
    # valid json
    json_string = '{"name":"bob","age":20}'
    token = tokenize_json(json_string)
    assert type(token) is DictToken
    assert str(token.value['name']) == 'bob'
    assert str(token.value['age']) == '20'
    # invalid json
    json_string = '{"name"="bob","age":20}'
    try:
        token = tokenize_json(json_string)
        assert False
    except ParseError as e:
        assert True

    # no content
    json_string = ""
    try:
        token = tokenize_json(json_string)
        assert False
    except ParseError as e:
        assert True


# Generated at 2022-06-12 16:08:57.197109
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
      "city": "London",
      "street": "Baker Street",
      "building": 221,
      "apartment": "B"
      "name": "Sherlock Holmes",
      "phone": "555-0123",
      "visited": true,
      "favourite_colour": null,
      "languages": ["en", "fr", "de"],
      "employers": [
          {
              "name": "Scotland Yard",
              "phone": "555-4321",
              "city": "London"
          },
          {
              "name": "Reichenbach Falls Hotel",
              "phone": "555-1239",
              "city": "Meiringen"
          }
      ]
    }
    """
    result = tokenize_json(content)
    print

# Generated at 2022-06-12 16:09:08.076407
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "world"}')
    assert isinstance(token, DictToken)
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=17, line_no=1, char_index=16)
    assert token.content == '{"name": "world"}'

    assert isinstance(token.value, dict)
    assert len(token.value) == 1

    value = token.value
    assert "name" in value
    assert isinstance(value["name"], ScalarToken)
    assert value["name"].start_position == Position(column_no=8, line_no=1, char_index=7)

# Generated at 2022-06-12 16:09:10.604836
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name":"zoe"}')
    assert token.value["name"] == "zoe"


# Generated at 2022-06-12 16:09:16.797912
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{"foo": "bar"}""")
    assert isinstance(token, Token)

    assert token.as_dict() == {"foo": "bar"}

    assert token.as_dict(include_positions=True) == {
        "foo": {
            "value": "bar",
            "start": [2, 3],
            "end": [2, 10],
        }
    }



# Generated at 2022-06-12 16:09:24.759242
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

    content = '[1]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)



# Generated at 2022-06-12 16:09:27.469156
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": "value", "key2": "value2"}')
    assert isinstance(token, DictToken)
    assert token.value == {"key": "value", "key2": "value2"}
    assert token.end_pos == {"line": 1, "column": 39}
    assert token.start_pos == {"line": 1, "column": 1}


# Generated at 2022-06-12 16:09:34.610990
# Unit test for function tokenize_json
def test_tokenize_json():
    x = """
    {
      "a": [1,2,3],
      "b": [{"c": 1, "d": 2}, {"c": 3, "d": 4}]
    }
    """
    token = tokenize_json(x)
    assert token.to_primitive_types() == {
        "a": [1,2,3],
        "b": [{"c": 1, "d": 2}, {"c": 3, "d": 4}]
    }


# Generated at 2022-06-12 16:09:41.705152
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json = '{"name": "Abe", "age": 30}'
    token = tokenize_json(input_json)
    assert token.content == input_json
    assert token.is_dict()
    assert token.value == {"name": "Abe", "age": 30}
    assert token.position.char_index == 0
    assert token.position.line_no == 1
    assert token.position.column_no == 1


# Generated at 2022-06-12 16:09:47.673823
# Unit test for function tokenize_json
def test_tokenize_json():
    tokens = tokenize_json('{"a":{"b":2}}')
    assert isinstance(tokens, DictToken)
    assert isinstance(tokens.token_value.get('a'), DictToken)
    assert isinstance(tokens.token_value.get('a').token_value.get('b'), ScalarToken)
    assert tokens.token_value.get('a').token_value.get('b').token_value == 2


# Generated at 2022-06-12 16:09:54.413437
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"string":"value"}') == {
        "string": "value"
    }
    assert tokenize_json('{"number":1234}') == {
        "number": 1234
    }
    assert tokenize_json('{"boolean":true}') == {
        "boolean": True
    }
    assert tokenize_json('{"null":null}') == {
        "null": None
    }
    assert tokenize_json('{"list":[99, "a"]}') == {
        "list": [99, "a"]
    }

# Generated at 2022-06-12 16:09:57.149641
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('[1,2,3]') == ListToken([1, 2, 3], 0, 6, '[1,2,3]')




# Generated at 2022-06-12 16:09:59.283185
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"1":1}'), DictToken)
    assert isinstance(tokenize_json('[1,2,3]'), ListToken)
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('')
    assert excinfo.value.text == "No content."



# Generated at 2022-06-12 16:10:08.845226
# Unit test for function tokenize_json
def test_tokenize_json():
    testString = '{"a": [1, 2], "c": {"e": 3}, "b": null}' # A full test string
    result = tokenize_json(testString)
    assert result.value == {"a": [1, 2], "c": {"e": 3}, "b": None}


# Generated at 2022-06-12 16:10:20.897209
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"hello": "world"}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 1
    (obj, ) = token.value
    assert obj.start_pos == (1, 1)
    assert obj.end_pos == (1, 15)
    assert isinstance(obj, DictToken)
    assert len(obj.value) == 1
    ((key, value), ) = obj.value.items()
    assert isinstance(key, ScalarToken)
    assert key.value == "hello"
    assert key.start_pos == (1, 2)
    assert key.end_pos == (1, 7)

    assert isinstance(value, ScalarToken)
    assert value.value == "world"
    assert value.start_

# Generated at 2022-06-12 16:10:37.099879
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "greeting": "Hello world!",
        "list": [1, 2, 3],
        "dictionary": {
            "key": "value"
        }
    }"""
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert token.position_start == 0
    assert token.position_end == 127
    assert token.position_child_start == 9
    assert token.position_child_end == 126
    assert token.content == content
    assert isinstance(token.data, dict)
    assert token.data["greeting"] == "Hello world!"
    assert isinstance(token.data["list"], list)
    assert token.data["list"] == [1, 2, 3]
    assert isinstance(token.data["dictionary"], dict)

# Generated at 2022-06-12 16:10:40.991156
# Unit test for function tokenize_json
def test_tokenize_json():
  content = '{"a":2, "b":[1.0, 2.0]}'
  result = tokenize_json(content)
  assert isinstance(result, DictToken)
  assert isinstance(result.value['a'], ScalarToken)
  assert isinstance(result.value['b'], ListToken)
  assert isinstance(result.value['b'].value[0], ScalarToken)

# Generated at 2022-06-12 16:10:43.422940
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("1") == ScalarToken(1, 0, 0, "1")



# Generated at 2022-06-12 16:10:54.311624
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = (
        b'{"glossary": {"title": "example glossary", "GlossDiv": {"title": "S", '
        b'"GlossList": {"GlossEntry": {"ID": "SGML", "SortAs": "SGML", '
        b'"GlossTerm": "Standard Generalized Markup Language", '
        b'"Acronym": "SGML", "Abbrev": "ISO 8879:1986", "GlossDef": '
        b'{"para": "A meta-markup language, used to create markup languages " '
        b'such as DocBook.", "GlossSeeAlso": ["GML", "XML"]}, '
        b'"GlossSee": "markup"}}}}}'
    )

# Generated at 2022-06-12 16:11:03.151876
# Unit test for function tokenize_json
def test_tokenize_json():
    # test String
    content = '"abcd"'
    token = tokenize_json(content)
    assert type(token) == ScalarToken
    assert token.value == "abcd"

    # test Number
    content = '32'
    token = tokenize_json(content)
    assert type(token) == ScalarToken
    assert token.value == 32

    # test object
    content = '{"a":{"c":"d"},"b":"abcd"}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert type(token.value["a"]) == DictToken

    # test array
    content = '["abcd", 12, {"a":"b"}, [{"c":32}]]'
    token = tokenize_json(content)
    assert type(token) == ListToken

# Generated at 2022-06-12 16:11:08.542344
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test an empty string
    try:
        tokenize_json("")
    except ParseError as ex:
        assert ex.code == "no_content"
        assert ex.text == "No content."
        assert ex.position.line_no == 1
        assert ex.position.column_no == 1
        assert ex.position.char_index == 0

    # Test a valid JSON dict
    token = tokenize_json('{"key":"value"}')
    assert token.end_col == len('"key":"value"')

    # Test a valid JSON tuple
    token = tokenize_json('["key", "value"]')
    assert token.end_col == len('["key", "value"]')

    # Test an invalid JSON string