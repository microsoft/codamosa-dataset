

# Generated at 2022-06-12 16:01:40.418528
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "typesystem", "version": "0.0.6"}')
    assert isinstance(token, DictToken)


# Generated at 2022-06-12 16:01:48.376745
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"one":2}') == {
        "one": 2
    }

    assert isinstance(tokenize_json('["one",2]'), list)

    assert tokenize_json('{"one":2}') == {"one": 2}

    assert tokenize_json('{"name":{"one":2}}') == {"name": {"one": 2}}

    assert tokenize_json('["one",2]') == ["one", 2]

    assert tokenize_json('{"name":{"one":2}}') == {"name": {"one": 2}}

    assert tokenize_json('{"name":"david"}') == {"name": "david"}

    assert tokenize_json('{"name":"d\'avid"}') == {"name": "d'avid"}


# Generated at 2022-06-12 16:01:55.419036
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name" : "bob", "age" : 80}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert isinstance(token.value[0], Token)
    assert token.value[0].value == "name"
    assert token.value[0].start == 1
    assert token.value[0].end == 6
    assert isinstance(token.value[1], Token)
    assert token.value[1].value == "age"
    assert token.value[1].start == 12
    assert token.value[1].end == 15



# Generated at 2022-06-12 16:02:00.316615
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key1": "value1", "key2": ["item1", "item2"]}'
    parsed_json = tokenize_json(json_str)
    assert isinstance(parsed_json, dict) == True
    assert isinstance(parsed_json["key1"], str) == True
    assert isinstance(parsed_json["key2"], list) == True

    # Test exception handling
    json_str = '{"key1": "value1", "key2": ["item1", "item2"]'
    try:
        parsed_json = tokenize_json(json_str)
    except ParseError as exc:
        assert isinstance(exc, ParseError) == True


# Generated at 2022-06-12 16:02:02.300611
# Unit test for function tokenize_json
def test_tokenize_json():

    content = '{"j": 1}'
    assert tokenize_json(content) == {"j": 1}

# Generated at 2022-06-12 16:02:12.807067
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 6, 13, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}'
    )
    assert tokenize_json('{"foo": 10}') == DictToken(
        {"foo": ScalarToken(10, 6, 8, '{"foo": 10}')}, 0, 9, '{"foo": 10}'
    )

# Generated at 2022-06-12 16:02:22.528053
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 4, "b": "foo", "c": {"d": [1, 2, 3]}}'
    assert isinstance(tokenize_json(content), DictToken)

    content = '{"a": 4, "b": "foo", "c": {"d": [1, 2, 3]}}'
    assert isinstance(tokenize_json(content), DictToken)

    content = '{"a": 4, "b": "foo", "c": {"d": [1, 2, 3]}}'
    assert isinstance(tokenize_json(content), DictToken)

    content = '{"a": 4, "b": "foo", "c": {"d": [1, 2, 3]}}'
    assert isinstance(tokenize_json(content), DictToken)


# Generated at 2022-06-12 16:02:33.882584
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json('"hello"') == "hello"
    assert tokenize_json("42") == 42
    assert tokenize_json("42.3") == 42.3
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")
    with pytest.raises(ParseError, match="parse_error"):
        tokenize_json("42..")
    with pytest.raises(ParseError, match="parse_error"):
        tokenize_json("4 2")
    with pytest.raises(ParseError, match="parse_error"):
        tokenize_json("{42: 2}")

# Generated at 2022-06-12 16:02:41.980496
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":[2,3,4], "c":{"d":5}}'
    token = tokenize_json(content)

    assert token is not None
    assert token.type == Token.DICT
    assert token.start_pos_col == 1
    assert token.end_pos_col == 31
    assert token.start_pos_line == 1
    assert token.end_pos_line == 1
    assert token.content == content

    content = '{"a":1, "b":[2,3,4], "c":{"d":5}}'
    token = tokenize_json(content)

    assert token is not None
    assert token.type == Token.DICT
    assert token.start_pos_col == 1
    assert token.end_pos_col == 31
    assert token.start_pos

# Generated at 2022-06-12 16:02:53.045495
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    [
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        },
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        },
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        }
    ]
    '''

    tokens = tokenize_json(content)
    assert isinstance(tokens, ListToken)
    assert len(tokens.value) == 3

    for token in tokens.value:
        assert isinstance(token, DictToken)
        for key, value in token.value.items():
            assert isinstance

# Generated at 2022-06-12 16:03:06.036631
# Unit test for function tokenize_json
def test_tokenize_json():
    # GIVEN
    content = """
    {
        "arr" : [
            1.1,
            2,
            null,
            true,
            false,
            "foo",
            {
                "l" : "two"
            }
        ],
        "obj" : {
            "foo": "bar"
        }
    }
    """

    # WHEN
    token = tokenize_json(content)

    # THEN

# Generated at 2022-06-12 16:03:17.014888
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid JSON
    content = '{"test": "value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"test": "value"}

    content = '[0, 1, 2, 3]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == [0, 1, 2, 3]

    content = '[{"test": [1, 2]}, {"test": "value"}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], DictToken)
    assert isinstance(token.value[0].value["test"], ListToken)

# Generated at 2022-06-12 16:03:28.461244
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as e:
        assert e.code == "no_content" and e.text == "No content."
        assert e.position.column_no == 1 and e.position.line_no == 1 and e.position.char_index == 0

    # Test for Null
    assert tokenize_json("null") is None

    # Test for Bool
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False

    # Test for Number
    assert tokenize_json("1") == 1
    assert tokenize_json("1.1") == 1.1
    assert tokenize_json("-1.1") == -1.1
    assert tokenize_json("1e3") == 1000

    # Test

# Generated at 2022-06-12 16:03:38.959755
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = """{
    "first_name": "John",
    "last_name": "Smith",
    "age": 25,
    "address": {
        "streetAddress": "21 2nd Street",
        "city": "New York",
        "state": "NY",
        "postalCode": "10021"
    },
    "phoneNumber": [
        {
            "type": "home",
            "number": "212 555-1234"
        },
        {
            "type": "fax",
            "number": "646 555-4567"
        }
    ],
    "gender": {
        "type": "male"
    }
}
    """
    token = tokenize_json(json_content)

# Generated at 2022-06-12 16:03:41.179305
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(str)
    content = '"test"'
    token = tokenize_json(content)
    assert token.value == "test"
    assert field.validate(token) == "test"





# Generated at 2022-06-12 16:03:51.405118
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (tokenize_json('{"a": "b"}') ==
            DictToken({ScalarToken('a', 2, 3, '{"a": "b"}'):
                       ScalarToken('b', 7, 8, '{"a": "b"}')},
                      0, 10, '{"a": "b"}'))
    assert (tokenize_json('["a", "b"]') ==
            ListToken([ScalarToken('a', 2, 3, '["a", "b"]'),
                       ScalarToken('b', 7, 8, '["a", "b"]')],
                      0, 10, '["a", "b"]'))
    assert (tokenize_json('"a"') ==
            ScalarToken('a', 1, 2, '"a"'))

# Generated at 2022-06-12 16:04:00.557124
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads

    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.json import tokenize_json, validate_json

    # Tokenize primitive values
    assert isinstance(tokenize_json('""'), ScalarToken)
    assert isinstance(tokenize_json('"test"'), ScalarToken)
    assert isinstance(tokenize_json('true'), ScalarToken)
    assert isinstance(tokenize_json('false'), ScalarToken)
    assert isinstance(tokenize_json('null'), ScalarToken)
    assert isinstance(tokenize_json('1'), ScalarToken)
    assert isinstance(tokenize_json('1.1'), ScalarToken)
    assert isinstance(tokenize_json('-1'), ScalarToken)

# Generated at 2022-06-12 16:04:09.640519
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem import String
    from .tokenize.tokens import Token
    from .tokenize.positional_validation import FlattenedToken
    from . import validate_json

    schema = String()
    content = b'["test","test2","test3"]'
    token = tokenize_json(content)
    assert isinstance(token, Token)
    flattened_token = FlattenedToken(token)
    assert all(validator is schema for validator in flattened_token.validators)
    token2 = tokenize_json(b'["test","test2","test3"]')
    assert isinstance(token2, Token)
    assert token2 == token


# Generated at 2022-06-12 16:04:20.709612
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """
    {
    "foo": "bar",
    "baz": [1, 2, "three"],
    "qux": {
        "baz": true,
        "bax": null
        }
    }
    """
    token = tokenize_json(json)
    assert token.start_token == "{"
    assert token.end_token == "}"

# Generated at 2022-06-12 16:04:28.839903
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    assert tokenize_json("  { }   ") == DictToken(
        {}, char_index=1, end_index=4, content="  { }   "
    )

# Generated at 2022-06-12 16:04:42.537155
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name":"Robin Jose","age":23,"sex":"male"}') == {
        "name": "Robin Jose",
        "age": 23,
        "sex": "male",
    }
    assert tokenize_json('"some_string"') == "some_string"
    assert tokenize_json("23") == 23
    assert tokenize_json("23.3") == 23.3
    assert tokenize_json("true") == True
    assert tokenize_json("false") == False
    assert tokenize_json("null") == None
    assert tokenize_json('["one","two","three","four","five"]') == [
        "one",
        "two",
        "three",
        "four",
        "five",
    ]

# Generated at 2022-06-12 16:04:50.325190
# Unit test for function tokenize_json
def test_tokenize_json():
    content = r'''{
    "b1":{
        "b2":{
            "c1":true,
            "c2":false,
            "c3":1,
            "c4":-1,
            "c5":1.11,
            "c6":-1.11,
            "c7":"str",
            "c8":null,
            "c9":[1,2,3],
            "c10":{"d1":true, "d2":false}
        }
    }
}'''

    result = tokenize_json(content)
    assert(result.start == 0)
    assert(result.end == 311)
    assert(isinstance(result, DictToken))
    result = result.as_dict()
    assert(len(result) == 1)

# Generated at 2022-06-12 16:04:59.616089
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.code == "no_content"

    # Arbitrary parsing error
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("{")
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.line_no == 1
    assert exc_info.value.column_no == 1

    # Parse success
    assert tokenize_json("1") == ScalarToken(1, 0, 0, content="1")



# Generated at 2022-06-12 16:05:04.254731
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"data": {"name": "John Doe", "age": 30}}'
    token = tokenize_json(content)
    assert token == DictToken(
        {
            "data": DictToken(
                {
                    "name": ScalarToken("John Doe", 24, 33, content),
                    "age": ScalarToken(30, 37, 39, content),
                },
                16,
                40,
                content
            )
        },
        0,
        40,
        content
    )


# Generated at 2022-06-12 16:05:15.908889
# Unit test for function tokenize_json
def test_tokenize_json():
    tests = [
        ('{"one": "two"}', {"one": "two"}),
        ("[]", []),
        ('{"one": null}', {"one": None}),
        ('{"one": true}', {"one": True}),
        ('{"one": false}', {"one": False}),
        ('{"one": "2"}', {"one": "2"}),
        ('{"one": 2}', {"one": 2}),
        ('{"one": 2.2}', {"one": 2.2}),
        (
            '{"one": [{"two": "three"}, {"four": "five"}]}',
            {"one": [{"two": "three"}, {"four": "five"}]},
        ),
    ]

    for content, expected in tests:
        assert tokenize_json(content) == expected
        assert validate

# Generated at 2022-06-12 16:05:18.300354
# Unit test for function tokenize_json
def test_tokenize_json():

    content = ""
    tokenize_json(content)

    content = "{}"
    tokenize_json(content)


# Generated at 2022-06-12 16:05:23.500413
# Unit test for function tokenize_json
def test_tokenize_json():
    # Given
    content = u'{"age": 35, "first_name": "John", "last_name": "Smith"}'
    # When
    token = tokenize_json(content)
    # Then
    assert token.value == {"age": 35, "first_name": "John", "last_name": "Smith"}


# Generated at 2022-06-12 16:05:26.798154
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    token = tokenize_json(content)
    assert token == [
        "foo", {"bar": ["baz", None, 1.0, 2]},
    ]


# Generated at 2022-06-12 16:05:35.371253
# Unit test for function tokenize_json
def test_tokenize_json():
    # test for empty input
    json_string="{}"
    token = tokenize_json(json_string)
    assert type(token) == DictToken
    assert token.value == {}

    # test for input with one entry
    json_string="{\"a\" : \"a string value\"}"
    token = tokenize_json(json_string)
    assert type(token) == DictToken
    assert token.value == {"a" : "a string value"}

    # test for input with two entry
    json_string="{\"a\" : \"a string value\", \"b\": 12}"
    token = tokenize_json(json_string)
    assert type(token) == DictToken
    assert token.value == {"a" : "a string value", "b" : 12}

    # test for input with nested values
   

# Generated at 2022-06-12 16:05:44.095846
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "test"}') == DictToken({'name': ScalarToken('test', 10, 15, '{"name": "test"}')}, 0, 19, '{"name": "test"}')
    assert tokenize_json('{"name": "test", "age": 10}') == DictToken({'name': ScalarToken('test', 10, 15, '{"name": "test", "age": 10}'), 'age': ScalarToken(10, 26, 27, '{"name": "test", "age": 10}')}, 0, 31, '{"name": "test", "age": 10}')
    assert isinstance(tokenize_json('{"name": "test"}'), DictToken)
    assert isinstance(tokenize_json('["name"]'), ListToken)

# Generated at 2022-06-12 16:05:56.205377
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:00.621731
# Unit test for function tokenize_json
def test_tokenize_json():
    orig_json = '{"Integers": [1, 2, 3], "Floats": [1.0, 2.0, 3.0], "Strings": ["a", "b", "c"]}'
    the_token = tokenize_json(orig_json)
    print(the_token)



# Generated at 2022-06-12 16:06:09.987954
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '["Yo",{"a":1,"b":2,"c":3,"d":[1,"2", 3]},null,false,true,{"a":1,"b":2,"c":3,"d":[1,"2", 3]}]'
    result = tokenize_json(content)

# Generated at 2022-06-12 16:06:15.095845
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"customer": "Acme Corp.", "date": "2020-02-03", "amount": 1000.01, "active": true}'
    token = tokenize_json(content)
    assert token.s == '{"customer": "Acme Corp.", "date": "2020-02-03", "amount": 1000.01, "active": true}'
    assert token.children["customer"].s == '"Acme Corp."'
    assert token.children["date"].s == '"2020-02-03"'
    assert token.children["amount"].s == "1000.01"
    assert token.children["active"].s == "true"



# Generated at 2022-06-12 16:06:24.227499
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
        {
            "foo": true,
            "bar": [1, 2, 3],
            "baz": "baz"
        }
    """

    token = tokenize_json(content)
    assert isinstance(token, dict)

    assert isinstance(token["foo"], ScalarToken)
    assert token["foo"].value == True
    assert token["foo"].start == 3
    assert token["foo"].end == 9
    assert token["foo"].content == content

    assert isinstance(token["bar"], ListToken)
    assert token["bar"].value == [1, 2, 3]
    assert token["bar"].start == 13
    assert token["bar"].end == 25
    assert token["bar"].content == content

    assert isinstance(token["baz"], ScalarToken)

# Generated at 2022-06-12 16:06:27.309325
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "luca"}')
    assert isinstance(token, DictToken)
    assert token.value["name"].value == "luca"



# Generated at 2022-06-12 16:06:35.439941
# Unit test for function tokenize_json
def test_tokenize_json():
    import typesystem
    schema = typesystem.Schema(fields = {
        "first_name": typesystem.String(required=True),
        "last_name": typesystem.String(required=True),
        "age": typesystem.Integer(minimum=0, maximum=120),
        "telephone": typesystem.String(pattern=r"^\d{3}-\d{3}-\d{4}$"),
    })
    value, error_messages = validate_json(
        b"""
    {
      "first_name": "John",
      "last_name": "Doe",
      "age": "35",
      "telephone": "555-555-5555"
    }
    """,
        validator=schema,
    )

# Generated at 2022-06-12 16:06:42.417775
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("[1, 2, 3]")
    assert isinstance(token, ListToken)
    assert len(token.value) == 3
    assert isinstance(token.value[0], ScalarToken)
    assert token.value[0].value == 1
    assert isinstance(token.value[1], ScalarToken)
    assert token.value[1].value == 2
    assert isinstance(token.value[2], ScalarToken)
    assert token.value[2].value == 3



# Generated at 2022-06-12 16:06:46.358057
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = """
    {
        "a": 1,
        "b": "b",
        "c": [
            {
                "d": 2
            },
            {
                "e": "e"
            }
        ]
    }
    """
    json_token = tokenize_json(json_content)
    assert json_token.value == {
        "a": 1,
        "b": "b",
        "c": [
            {"d": 2},
            {"e": "e"},
        ],
    }


# Generated at 2022-06-12 16:06:56.922722
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:07:06.941766
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '["c"]'
    tokens = tokenize_json(json_str)
    print("tokens\n")
    print(tokens.data)
    print("tokens data type \n")
    print(type(tokens.data))
    # print("tokens data type", type(tokens.data[0]))

# Generated at 2022-06-12 16:07:12.205659
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '["a", {"b": 42}]'

    token = tokenize_json(content)

    assert token.value == ["a", {"b": 42}]
    assert token.value == token[1].value

    content2 = '[{"z": 42}]'

    token2 = tokenize_json(content2)

    assert token2.value == [{"z": 42}]
    assert token2.value == token2[1].value


# Generated at 2022-06-12 16:07:15.362143
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == ''



# Generated at 2022-06-12 16:07:25.867801
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_token_types(token, expected_types):
        token_types = get_token_types(token)
        assert token_types == expected_types

    # Test unicode escapes
    assert_token_types(tokenize_json('{"foo": "b\\u0061r"}'), [DictToken, ScalarToken])

    # Test simple JSON
    assert_token_types(tokenize_json('{"foo": "bar"}'), [DictToken, ScalarToken])
    assert_token_types(tokenize_json('["foo", "bar"]'), [ListToken, ScalarToken, ScalarToken])

    # Test empty JSON
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")

    # Test parsing errors

# Generated at 2022-06-12 16:07:28.868089
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"value": "hello"}'
    # pylint: disable=unsubscriptable-object
    assert tokenize_json(content).value["value"].value == "hello"



# Generated at 2022-06-12 16:07:32.146028
# Unit test for function tokenize_json
def test_tokenize_json():
    sample = """[
        "foo",
        [null, 42, "bar", true, false],
        {
            "foo": 42,
            "bar": [false, "baz"]
        }
    ]"""
    assert isinstance(tokenize_json(sample), ListToken)



# Generated at 2022-06-12 16:07:40.900321
# Unit test for function tokenize_json
def test_tokenize_json():
    examples = [
        '{"key": "value"}',
        '{"key": {"nested": "value"}}',
        '{"key": [{"nested": "value"}]}',
        '{"key": ["one", "two", "three"]}',
        '{"key": [1, 2, 3]}',
        '{"key": [1.1, 2.2, 3.3]}',
        '{"key": [True, False, True]}',
        '{"key": [null]}',
    ]

    for example in examples:
        assert example == json.dumps(tokenize_json(example))


# Generated at 2022-06-12 16:07:49.319173
# Unit test for function tokenize_json
def test_tokenize_json():
    test_cases = [
        ("", []),
        ("42", [42]),
        ("3.14", [3.14]),
        ('"string"', ["string"]),
        ("null", [None]),
        ("true", [True]),
        ("false", [False]),
        ("[null]", [None]),
        ("[null, false, 1]", [None, False, 1]),
        ("[null, [], {}]", [None, [], {}]),
        ('{"a": 42, "b": 3.14}', {"a": 42, "b": 3.14}),
        ('{"a": [1,2,3], "b": {"c": null}}', {"a": [1, 2, 3], "b": {"c": None}}),
    ]

# Generated at 2022-06-12 16:07:58.641740
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = "{\"a\": \"b\"}"
    token = tokenize_json(json_str)
    assert(token.value == {'a': 'b'})
    json_str = "{\"a\": 1}"
    token = tokenize_json(json_str)
    assert(token.value == {'a': 1})
    json_str = "{\"a\": 1.1}"
    token = tokenize_json(json_str)
    assert(token.value == {'a': 1.1})
    json_str = "{\"a\": true}"
    token = tokenize_json(json_str)
    assert(token.value == {'a': True})
    json_str = "{\"a\": false}"
    token = tokenize_json(json_str)

# Generated at 2022-06-12 16:08:05.479472
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"fruit": ["apple", "orange", "banana", "strawberry", "kiwi"], "vegetable": "tomato"}'
    token = tokenize_json(json_string)
    assert token.value == {'fruit': ['apple', 'orange', 'banana', 'strawberry', 'kiwi'], 'vegetable': 'tomato'}
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 108
    assert token.line_no == 1
    assert token.column_no == 1
    assert token.json_content == json_string

    fruit_token = token.value['fruit']
    assert fruit_token.value == ['apple', 'orange', 'banana', 'strawberry', 'kiwi']

# Generated at 2022-06-12 16:08:15.997368
# Unit test for function tokenize_json
def test_tokenize_json():
    inputs = [
        ('', []),
        ('{}', []),
        ('{"a": "b"}', ['a']),
        ('{"a": "b", "c": "d"}', ['a', 'c']),
        ('{"a": "b", "c": [1, 2, 3], "d": "e"}', ['a', 'c', 'd']),
        ('{"a": {"b": "c", "d": "e"}, "f": "g"}', ['a', 'f'])
    ]
    for input in inputs:
        string = input[0]
        expected = input[1]
        print(f"Testing {string}")
        root = tokenize_json(string)

# Generated at 2022-06-12 16:08:27.238058
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({})
    assert tokenize_json("[]") == ListToken([])
    assert tokenize_json("true") == ScalarToken(True)
    assert tokenize_json("false") == ScalarToken(False)
    assert tokenize_json("null") == ScalarToken(None)
    assert tokenize_json("42") == ScalarToken(42)
    assert tokenize_json("42.1") == ScalarToken(42.1)
    assert tokenize_json("42.1e-3") == ScalarToken(42.1e-3)
    assert tokenize_json('"hello world"') == ScalarToken("hello world")
    assert tokenize_json('"hello\\u0020world"') == ScalarToken("hello world")
    assert tokenize_

# Generated at 2022-06-12 16:08:37.851692
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 2, 3, '{"a": 1}'): ScalarToken(1, 7, 8, '{"a": 1}')}, 1, 9, '{"a": 1}'
    )

# Generated at 2022-06-12 16:08:49.376653
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json(b'""') == ScalarToken("", 0, 1, '""')
    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json(b"123") == ScalarToken(123, 0, 2, "123")
    assert tokenize_json(b'{"a": "b"}') == DictToken(
        {"a": ScalarToken("b", 3, 5, '"b"')}, 0, 8, '{"a": "b"}'
    )

# Generated at 2022-06-12 16:08:59.109737
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":2, "b":3}'
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert token.value == {'a': 2, 'b': 3}
    assert token.start_char == 0
    assert token.end_char == 13
    assert token.content == content
    assert token.type == "dict"
    assert token.type == "dict"
    assert isinstance(token.nested_tokens, list)
    assert len(token.nested_tokens) == 2


# Generated at 2022-06-12 16:09:09.653959
# Unit test for function tokenize_json
def test_tokenize_json():
    """ Unit test for function tokenize_json """
    # Test tokenizing an empty string.
    try:
        tokenize_json(content="")
    except ParseError as exc:
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert exc.text == "No content."
        assert exc.code == "no_content"
    else:
        raise AssertionError("The empty string should raise a parse error.")
    # Test tokenizing ill-formatted JSON.
    try:
        tokenize_json(content='{"foo": 1, {"bar": 2')
    except ParseError as exc:
        assert exc.position == Position(column_no=15, line_no=1, char_index=14)

# Generated at 2022-06-12 16:09:16.695834
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"\xEF\xBB\xBFfalse") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json('{"hello": "world"}') == DictToken(
        {ScalarToken("hello", 1, 7, '"hello"'): ScalarToken("world", 11, 18, '"world"')},
        0,
        18,
        '{"hello": "world"}',
    )

# Generated at 2022-06-12 16:09:23.902146
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"abc": "def"}')
    assert isinstance(token, DictToken)
    assert token.value == {'abc': 'def'}
    assert token.start_index == 0
    assert token.end_index == 12
    assert token.content == '{"abc": "def"}'

    # Value is a list token
    token = tokenize_json('[{"abc": "def"}]')
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], DictToken)
    assert token.content == '[{"abc": "def"}]'
    assert token.value[0].content == '{"abc": "def"}'



# Generated at 2022-06-12 16:09:27.284830
# Unit test for function tokenize_json
def test_tokenize_json():
  content = '{"name":"Turing"}'
  token = tokenize_json(content)
  assert token.start_position == (0,0,0)
  assert token.end_position == (0,0,14)
  assert token.content == '{"name":"Turing"}'
  assert token.get_token_type() == "dict"
  assert str(token) == '{"name":"Turing"}'
  assert token.value == {"name": "Turing"}



# Generated at 2022-06-12 16:09:38.273799
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_token = tokenize_json('{"name" : "dan", "age" : 2, "number" : 10.5}')
    assert type(dict_token) == DictToken
    assert dict_token.start_index == 0
    assert dict_token.end_index == 39

    list_token = tokenize_json('[[1, 2], [3, 4]]')
    assert type(list_token) == ListToken
    assert list_token.start_index == 0
    assert list_token.end_index == 14

    scalar_token = tokenize_json('10')
    assert type(scalar_token) == ScalarToken
    assert scalar_token.start_index == 0
    assert scalar_token.end_index == 1

    scalar_token = tokenize_json('"name"')


# Generated at 2022-06-12 16:09:47.826570
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{'1':'2'}")
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert token[0].value == "2"

# Generated at 2022-06-12 16:09:52.837272
# Unit test for function tokenize_json
def test_tokenize_json():
    t = tokenize_json("{'a': 'x'}")
    assert t.return_type is dict
    assert len(t.children) == 1
    assert t.children[0].start == 1
    assert t.children[0].end == 6
    assert t.children[0].return_type is str
    assert t.children[0].value == "a"



# Generated at 2022-06-12 16:10:04.516334
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """"{
    "first_name": "John",
    "last_name": "Doe",
    "age": {"first": "20", "second": false},
    "address": ["123 Main Street", "New York, NY", "12345"],
    "hobbies": [
        {"name": "golf", "description": "an expensive sport", "ratings": [1,2,3]},
        {"name": "studying python", "description":"awesome", "ratings": [1,2,3,4]}
    ],
    "is_active": true
}"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    token_dict = token.data
    assert token_dict["first_name"].data == "John"

# Generated at 2022-06-12 16:10:06.634702
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"name": "Dave"}, {"name": "Steve"}]'
    actual = tokenize_json(content)
    expected = ListToken([DictToken([("name", ScalarToken("Dave"))]), DictToken([("name", ScalarToken("Steve"))])], 0, len(content) - 1, content)
    assert actual == expected

# Generated at 2022-06-12 16:10:11.667731
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": {"c": [1], "d": [2,3]}, "e": "1"}') \
        == {
            "a": 1,
            "b": {
                "c": [1],
                "d": [2, 3]
            },
            "e": "1"
        }


# Generated at 2022-06-12 16:10:23.743166
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("hello") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("hello") is None
    assert tokenize_json("hello") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None
    assert tokenize_json("world") is None

# Generated at 2022-06-12 16:10:33.641180
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(
        {}, start=0, end=0, content="{}"
    )
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 4, 10, content='{"foo": "bar"}')},
        start=0,
        end=10,
        content='{"foo": "bar"}',
    )
    assert tokenize_json("[1, 2]") == ListToken(
        [ScalarToken(1, 1, 1, content="[1, 2]"), ScalarToken(2, 4, 4, content="[1, 2]")],
        start=0,
        end=4,
        content="[1, 2]",
    )
    assert tokenize_json("1")

# Generated at 2022-06-12 16:10:40.719435
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("0") == ScalarToken(0, 0, 1, "0")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("-1") == ScalarToken(-1, 0, 2, "-1")

# Generated at 2022-06-12 16:10:45.438687
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"a": 123}]'
    token = tokenize_json(content)
    assert token.value == [{"a": 123}]

    content = '[{"a": "123"}]'
    token = tokenize_json(content)
    assert token.value == [{"a": "123"}]



# Generated at 2022-06-12 16:10:53.322158
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    [
        {"name": "Jane", "age": 26},
        {"name": "Josue", "age": 22}
    ]
    """
    tokens = tokenize_json(content)
    assert isinstance(tokens, ListToken)
    assert len(tokens.value) == 2
    assert isinstance(tokens.value[0], DictToken)
    assert tokens.value[0].value == {"name": "Jane", "age": 26}
    assert tokens.value[1].value == {"name": "Josue", "age": 22}

# Generated at 2022-06-12 16:11:05.084559
# Unit test for function tokenize_json
def test_tokenize_json():
    _expect(
        tokenize_json('{"data": "value"}'),
        DictToken(
            {
                ScalarToken("data", 0, 3, '{"data": "value"}'): ScalarToken(
                    "value", 8, 12, '{"data": "value"}'
                ),
            },
            0,
            13,
            '{"data": "value"}',
        ),
    )

# Generated at 2022-06-12 16:11:13.162575
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("1") == ScalarToken(1, 0, 0, "1")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"hello"') == ScalarToken("hello", 0, 3, '"hello"')
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("123.45") == ScalarToken(123.45, 0, 5, "123.45")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 9, "[1, 2, 3]")