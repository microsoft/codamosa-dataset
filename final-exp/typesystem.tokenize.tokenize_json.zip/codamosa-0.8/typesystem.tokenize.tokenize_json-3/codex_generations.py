

# Generated at 2022-06-12 16:01:30.761819
# Unit test for function tokenize_json
def test_tokenize_json():
    query = """{
        "hello_world": "value",
        "nested": {
          "key": "value",
          "nested": {
            "key": "value"
          }
        },
        "arr": [1,2,3,4],
        "arr_nested": [
          {
            "key": 1
          },
          {
            "key": 2
          }
        ]
      }"""
    print(tokenize_json(query))

# Generated at 2022-06-12 16:01:39.005807
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"first_name": "Winnie", "last_name": "the Pooh"}'
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.value.get("first_name").value == "Winnie"
    assert token.value.get("last_name").value == "the Pooh"
    json_str = '{"first_name": "Winnie", "last_name": "the Pooh", "age": 7}'
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.value.get("first_name").value == "Winnie"
    assert token.value.get("last_name").value == "the Pooh"

# Generated at 2022-06-12 16:01:45.999835
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test normal message
    r = tokenize_json('{"a":1, "b":2}')
    assert isinstance(r, DictToken)
    assert len(r.value) == 2

    # Test malformed message
    with pytest.raises(ParseError) as excinfo:
        r = tokenize_json('{"a":1, "b"2}')
    assert excinfo.type is ParseError

    # Test malformed message with no content
    with pytest.raises(ParseError) as excinfo:
        r = tokenize_json('')
    assert excinfo.type is ParseError



# Generated at 2022-06-12 16:01:52.409298
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}
    assert tokenize_json("{\"foo\": 1}") == {"foo": 1}
    assert tokenize_json("[\"foo\", \"bar\", 1, 2, 3]") == ["foo", "bar", 1, 2, 3]

    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"

    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"



# Generated at 2022-06-12 16:02:02.307710
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Positions
    the_dict = {"a": 1, "b": True, "c": None}
    # {'a': 1, 'b': True, 'c': None}
    token = tokenize_json(the_dict)
    # {'a': 1, 'b': True, 'c': None, 'd': [{'e': 'f', 'g': {'h': 1}}]}
    the_dict.update({"d": [{"e": "f", "g": {"h": 1}}]})
    token = tokenize_json(the_dict)

# Generated at 2022-06-12 16:02:12.807287
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"k1": "v1"}') == DictToken(
        {"k1": ScalarToken("v1", 3, 9, '{"k1": "v1"}')}, 0, 11, '{"k1": "v1"}'
    )

# Generated at 2022-06-12 16:02:22.528190
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{ "id": 9, "name": "foo" }') == DictToken({
        ScalarToken('id', 1, 2, '{ "id": 9, "name": "foo" }'): ScalarToken(9, 11, 12, '{ "id": 9, "name": "foo" }'),
        ScalarToken('name', 18, 19, '{ "id": 9, "name": "foo" }'): ScalarToken('foo', 27, 30, '{ "id": 9, "name": "foo" }'),
    }, 0, 33, '{ "id": 9, "name": "foo" }')


# Generated at 2022-06-12 16:02:27.805770
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '{"a": "string", "b": 1, "c": [1, 2, 3]}'
    test_dict = {"a": "string", "b": 1, "c": [1, 2, 3]}
    assert tokenize_json(test_content) == DictToken(test_dict, 0, len(test_content) - 1)

# Generated at 2022-06-12 16:02:38.184069
# Unit test for function tokenize_json
def test_tokenize_json():
    # The following example is taking from the standard json module.
    content = '{"a": ["dog", "cat", 42]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.items) == 1

    key = list(token.items.keys())[0]
    assert isinstance(key, ScalarToken)
    assert key.value == "a"
    assert key.start_position.char_index == 1
    assert key.end_position.char_index == 3

    value = list(token.items.values())[0]
    assert isinstance(value, ListToken)
    assert len(value.items) == 3

    item_0 = value.items[0]
    assert isinstance(item_0, ScalarToken)

# Generated at 2022-06-12 16:02:44.921598
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test parsing valid strings
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 3, "3.14")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 7, "[1, 2, 3]")

# Generated at 2022-06-12 16:02:59.867502
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''{"json": {"key": "value", "int": 1}}'''
    expected_value = {
        "json": {
            "int": 1,
            "key": "value"
        }
    }
    # Tokenize the JSON
    actual_value = tokenize_json(content)
    # Check that the tokenized JSON matches the expected object
    assert actual_value == expected_value


# Generated at 2022-06-12 16:03:04.659259
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "str", "b": 1}') == DictToken({'a': 'str', 'b':1}, 0, 17, '{"a": "str", "b": 1}')
    assert tokenize_json('"str"') == ScalarToken('str', 0, 4, '"str"')
    assert tokenize_json('{"a": "str", "b": 1, "c": [1, 2, "three"]}') == DictToken({'a':'str', 'b':1, 'c':[1,2,'three']}, 0, 40, '{"a": "str", "b": 1, "c": [1, 2, "three"]}')

# Generated at 2022-06-12 16:03:11.163896
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": {"key": "value"}, "b": [1, 2, {"c": "d"}]}'
    token = tokenize_json(content)
    expected_token = DictToken(
        {
            "a": DictToken({"key": ScalarToken("value", 7, 16, content)}, 0, 16, content),
            "b": ListToken(
                [
                    ScalarToken(1, 21, 22, content),
                    ScalarToken(2, 24, 25, content),
                    DictToken({"c": ScalarToken("d", 27, 30, content)}, 26, 30, content),
                ],
                19,
                31,
                content,
            ),
        },
        0,
        31,
        content,
    )
    assert token == expected_token

# Unit

# Generated at 2022-06-12 16:03:20.188209
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:03:25.369235
# Unit test for function tokenize_json
def test_tokenize_json():
    json_input = '{"hello": 1, "world": 2}'
    token = tokenize_json(json_input)
    assert token.start == 0
    assert token.end == len(json_input) - 1
    assert token.kind == "DictToken"
    assert token.value == {"hello": 1, "world": 2}



# Generated at 2022-06-12 16:03:33.943421
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'

    from typesystem.tokenize.tokens import Token

    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert token.value == {'foo': 'bar'}
    assert token.start_index == 0
    assert token.end_index == 11
    assert token.line_no == 1
    assert token.column_no == 1

    # Empty JSON string
    position = Position(column_no=1, line_no=1, char_index=0)
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")

    # Handle cases that result in a JSON parse error.
    position = Position(column_no=1, line_no=2, char_index=8)

# Generated at 2022-06-12 16:03:42.276563
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
        assert False
    except ParseError as exc:
        assert isinstance(exc.position, Position)
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."
        assert exc.code == "no_content"

    # Test invalid JSON string
    try:
        tokenize_json("syntax error")
        assert False
    except ParseError as exc:
        assert isinstance(exc.position, Position)
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "Expecting value."

# Generated at 2022-06-12 16:03:51.072607
# Unit test for function tokenize_json
def test_tokenize_json():
    x = tokenize_json("[1, 2, 3]")
    x.value[0].raw_value == 1
    x.value[0].start_pos.char_index == 1
    x.value[0].end_pos.char_index == 1
    x.value[1].raw_value == 2
    x.value[1].start_pos.char_index == 3
    x.value[1].end_pos.char_index == 3
    x.value[2].raw_value == 3
    x.value[2].start_pos.char_index == 5
    x.value[2].end_pos.char_index == 5



# Generated at 2022-06-12 16:03:59.681758
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), Token)
    assert isinstance(tokenize_json("[]"), Token)
    assert isinstance(tokenize_json("true"), Token)
    assert isinstance(tokenize_json("false"), Token)
    assert isinstance(tokenize_json("null"), Token)
    assert isinstance(tokenize_json("1"), Token)
    assert isinstance(tokenize_json("1.1"), Token)
    assert isinstance(tokenize_json("{\"foo\": \"bar\"}"), Token)
    assert isinstance(tokenize_json("{\n\"foo\": \"bar\"\n}"), Token)
    assert isinstance(tokenize_json("[\"foo\", \"bar\"]"), Token)

# Generated at 2022-06-12 16:04:04.011357
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{"a":[1,2,3],"b":"c"}""")
    assert token.start == 0
    assert token.end == 23
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, 3], "b": "c"}



# Generated at 2022-06-12 16:04:23.734601
# Unit test for function tokenize_json
def test_tokenize_json():
    # Example 1
    content = ""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"

    # Example 2
    content = "1"
    token = tokenize_json(content)
    assert token.value == 1

    # Example 3
    content = '{"a": 1}'
    token = tokenize_json(content)
    assert token.value == {"a": 1}
    assert token.token_type == "dict"
    assert token.is_dict() is True

    # Example 4
    content = '{ "a" : 1 }'
    token = tokenize_json(content)
    assert token.value == {"a": 1}

# Generated at 2022-06-12 16:04:31.673110
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string= 'json_string'
    json_string_2= "json_string"
    # Case - empty string
    try:
        tokenize_json(content='')
    except ParseError as e:
        assert (e.code == 'no_content')
        assert (e.text == 'No content.')
        assert (e.position.column_no == 1)
        assert (e.position.line_no == 1)
        assert (e.position.char_index == 0)
    # Case - invalid string
    try:
        tokenize_json(content='{"invalid_key": "invalid_value"}')
    except ParseError as e:
        assert (e.code == 'parse_error')
        assert (e.text == 'Expecting property name enclosed in double quotes.')

# Generated at 2022-06-12 16:04:34.860364
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({ScalarToken('key', 0, 2, '{"key": "value"}'): ScalarToken('value', 9, 13, '{"key": "value"}')}, 0, 22, '{"key": "value"}')


# Generated at 2022-06-12 16:04:43.422541
# Unit test for function tokenize_json
def test_tokenize_json():
    test_data = """{"a": {"b": {"c": 42}}}"""
    token = tokenize_json(test_data)
    assert isinstance(token, DictToken)
    assert list(token.keys()) == ["a"]
    assert isinstance(token["a"], DictToken)
    assert list(token["a"].keys()) == ["b"]
    assert isinstance(token["a"]["b"], DictToken)
    assert list(token["a"]["b"].keys()) == ["c"]
    assert isinstance(token["a"]["b"]["c"], ScalarToken)
    assert token["a"]["b"]["c"].value == 42



# Generated at 2022-06-12 16:04:50.458999
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "is_registered": {"type": "boolean"},
            "address": {"type": "object", "properties": {"city": {"type": "string"}}},
            "favourite_numbers": {"type": "array", "items": {"type": "integer"}},
        },
    }
    token = tokenize_json(
        """
    {
        "name": "Shahid",
        "age": 43,
        "is_registered": true,
        "address": {
            "city": "London"
        },
        "favourite_numbers": [2, 4, 8]
    }
    """
    )

    # Test

# Generated at 2022-06-12 16:05:01.984127
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"id": 123, "name": "John Doe", "active": true}')
    assert isinstance(token, DictToken)

    # Test with a byte-string.
    token = tokenize_json(b'[1, 2, 3, 4]')
    assert isinstance(token, ListToken)

    # Test with an empty string.
    with pytest.raises(ParseError, match="^No content.$"):
        tokenize_json(" ")

    # Test with an unclosed list.
    with pytest.raises(ParseError, match="^Expecting value$"):
        tokenize_json('[1, 2, 3')

    # Test with a bad key.

# Generated at 2022-06-12 16:05:12.958139
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"a":1}'), DictToken) == True
    assert isinstance(tokenize_json('{"a":"hello"}'), DictToken) == True
    assert isinstance(tokenize_json('[1,2,3]'), ListToken) == True
    assert isinstance(tokenize_json('[1,2,3]')[0], ScalarToken) == True
    assert isinstance(tokenize_json('[1,2,3]')[2], ScalarToken) == True
    assert isinstance(tokenize_json('[1,2,3]')[1], ScalarToken) == True
    assert isinstance(tokenize_json('"hello"'), ScalarToken) == True
    assert isinstance(tokenize_json('"hello", "world"'), ScalarToken) == False


# Generated at 2022-06-12 16:05:23.916098
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:05:31.440032
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test a simple dictionary
    content = "{\"x\":1}"
    token = tokenize_json(content)
    assert token.value == {"x": 1}
    assert token.start_pos == 0
    assert token.end_pos == 7
    assert token.content == content

    # Test a simple list
    content = "[0,1,2]"
    token = tokenize_json(content)
    assert token.value == [0, 1, 2]
    assert token.start_pos == 0
    assert token.end_pos == 7
    assert token.content == content

    # Test an empty string
    content = ""
    try:
        token = tokenize_json(content)
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
       

# Generated at 2022-06-12 16:05:35.147793
# Unit test for function tokenize_json
def test_tokenize_json():
    json_test = {'test': [1, 2, 3, 4, 5]}
    test_string = json.dumps(json_test)
    token = tokenize_json(test_string)
    assert isinstance(token, DictToken)
    assert isinstance(token.value['test'], ListToken)
    assert len(token.value['test']) == 5

# Generated at 2022-06-12 16:05:55.066044
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 3, "3.14")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, "[1, 2, 3]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-12 16:06:04.746189
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"name": "Bob Ross", "favorite-color": "pink"}')
    assert isinstance(token, DictToken)
    assert token.value == {
        (ScalarToken(text="name", value="name", source_location=None, content=None),):
        ScalarToken(text="Bob Ross", value="Bob Ross", source_location=None, content=None),
        (ScalarToken(text="favorite-color", value="favorite-color", source_location=None, content=None),):
        ScalarToken(text="pink", value="pink", source_location=None, content=None),
    }

    token = tokenize_json(b'{"name": "Bob Ross", "favorite-color": "pink",}')

# Generated at 2022-06-12 16:06:11.902106
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"key": "value"}'), DictToken)
    assert isinstance(tokenize_json('["value1", "value2"]'), ListToken)
    assert isinstance(tokenize_json(''), Token)
    assert isinstance(tokenize_json('"string"'), ScalarToken)
    assert isinstance(tokenize_json('null'), ScalarToken)
    assert isinstance(tokenize_json('true'), ScalarToken)
    assert isinstance(tokenize_json('false'), ScalarToken)
    assert isinstance(tokenize_json(r'{"key": "value", "key2": "value2"}'), DictToken)



# Generated at 2022-06-12 16:06:20.341586
# Unit test for function tokenize_json
def test_tokenize_json():
    # invalid json
    invalid_json = "{a:b}"
    with pytest.raises(ParseError):
        tokenize_json(invalid_json)

    # valid json
    valid_json = '{"a":"b"}'
    token = tokenize_json(valid_json)
    assert token.data == {"a": "b"}
    assert token.start_index == 0
    assert token.end_index == 8

    # empty json
    empty_json = ''
    with pytest.raises(ParseError):
        tokenize_json(empty_json)



# Generated at 2022-06-12 16:06:32.356889
# Unit test for function tokenize_json
def test_tokenize_json():
    # Normal json parse
    content = '{"animal": "cat", "name": "Sammy"}'
    token = tokenize_json(content)
    assert token.value == {"animal": "cat", "name": "Sammy"}

    # Not a valid json (missing comma) - should raise ParseError
    content = '{"animal": "cat" "name": "Sammy"}'

    try:
        token = tokenize_json(content)
    except ParseError as e:
        assert (
            e.message == "Expecting ',' delimiter"
            and e.code == "parse_error"
            and e.position.line_no == 1
            and e.position.column_no == 20
            and e.position.char_index == 19
        )

    # Not a valid json (use of single quote) - should

# Generated at 2022-06-12 16:06:43.508490
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:49.464890
# Unit test for function tokenize_json
def test_tokenize_json():
    # Load the test JSON file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    p = open(current_dir + "/example_document.json", mode="r")
    example_content = p.read()

    token = tokenize_json(example_content)

# Generated at 2022-06-12 16:06:52.819008
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('["foo", {"bar":["baz", null, 1.0, 2]}]')
    assert token
    assert token.value == ["foo", {"bar":["baz", None, 1.0, 2]}]

# Generated at 2022-06-12 16:06:55.425500
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"Hello": 5}')
    assert token.value == {"Hello": 5}
    assert token.start == 0
    assert token.end == 9    
    

# Generated at 2022-06-12 16:07:06.794949
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token, ScalarToken
    assert isinstance(tokenize_json('{}'), Token)
    assert isinstance(tokenize_json(''), Token)
    assert isinstance(tokenize_json('1'), ScalarToken)
    assert isinstance(tokenize_json('1.0'), ScalarToken)
    assert isinstance(tokenize_json('1e0'), ScalarToken)
    assert isinstance(tokenize_json('"str"'), ScalarToken)
    assert isinstance(tokenize_json('"str'), Token)
    assert isinstance(tokenize_json('true'), ScalarToken)
    assert isinstance(tokenize_json('false'), ScalarToken)
    assert isinstance(tokenize_json('null'), ScalarToken)

# Generated at 2022-06-12 16:07:17.162316
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{}')
    assert isinstance(token, DictToken)



# Generated at 2022-06-12 16:07:27.713725
# Unit test for function tokenize_json
def test_tokenize_json():
    # parse_error test
    try:
        tokenize_json('{ "foo": 0.2 }')
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert isinstance(exc.position, Position)
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        assert False

    # parse_error test
    try:
        tokenize_json('')
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert isinstance(exc.position, Position)
        assert exc.position.column_no == 1
        assert exc.position.line_

# Generated at 2022-06-12 16:07:36.335438
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"test": [1, 2, "3", {"abc": "123"}]}')
    assert token == {"test": [1, 2, "3", {"abc": "123"}]}

    token = tokenize_json('[{"_id": 1, "string": "Test string"}, {"_id": 2, "string": "Test string 2"}]')
    assert token == [{"_id": 1, "string": "Test string"}, {"_id": 2, "string": "Test string 2"}]

    token = tokenize_json('{"_id": {"timestamp": 1498760400, "machine": 1326045, "pid": 14963, "increment": 1707880, "creationTime": "2017-07-01T00:00:00Z"}, "string": "Test string"}')

# Generated at 2022-06-12 16:07:42.595834
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello":"world"}') == DictToken(
        {
            ScalarToken("hello", 0, 4, '{"hello":"world"}'): ScalarToken(
                "world", 8, 14, '{"hello":"world"}'
            )
        },
        0,
        14,
        '{"hello":"world"}',
    )
    assert tokenize_json('{"hello":1.0}') == DictToken(
        {
            ScalarToken("hello", 0, 4, '{"hello":1.0}'): ScalarToken(
                1.0, 8, 10, '{"hello":1.0}'
            )
        },
        0,
        10,
        '{"hello":1.0}',
    )

# Generated at 2022-06-12 16:07:51.401113
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '[{"a": "b", "c":3}, {"a": "b", "c":3}]'
    json_token = tokenize_json(json)
    assert isinstance(json_token, ListToken)
    assert isinstance(json_token.value[0], DictToken)
    assert isinstance(json_token.value[1], DictToken)
    assert json_token.value[0].value['a'].value == 'b'
    assert json_token.value[1].value['a'].value == 'b'
    assert json_token.value[0].value['c'].value == 3
    assert json_token.value[1].value['c'].value == 3
    assert json_token.value[0].value['a'].start == 3

# Generated at 2022-06-12 16:07:53.486251
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}



# Generated at 2022-06-12 16:07:59.709748
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key1": [1, 2, 3], "key2": "value"}') == DictToken({
        ScalarToken('key1'): ListToken([
            ScalarToken(1),
            ScalarToken(2),
            ScalarToken(3)
        ]),
        ScalarToken('key2'): ScalarToken('value'),
    })

# Generated at 2022-06-12 16:08:09.203276
# Unit test for function tokenize_json
def test_tokenize_json():
    """Test for parsing the json string"""
    assert tokenize_json('{"key": 10}') == DictToken({'key': ScalarToken(10, 1, 6, '{"key": 10}')}, 0, 9, '{"key": 10}')
    assert tokenize_json('{"key": false}') == DictToken({'key': ScalarToken(False, 1, 9, '{"key": false}')}, 0, 13, '{"key": false}')
    assert tokenize_json('{"key": "value"}') == DictToken({'key': ScalarToken('value', 1, 11, '{"key": "value"}')}, 0, 15, '{"key": "value"}')

# Generated at 2022-06-12 16:08:15.365211
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Test function tokenize json
    '''
    import typesystem
    from typesystem.tokenize.tokens import ScalarToken, DictToken
    from typesystem.tokenize.tokens import ListToken

    schema = typesystem.Schema([
        typesystem.String(name='first_name'),
        typesystem.String(name='last_name'),
        typesystem.Integer(name='age'),
        typesystem.Array(
            typesystem.String(),
            minimum_items=1,
            name='hobbies',
        ),
        typesystem.Object(
            properties={
                'address': typesystem.String(),
            },
            name='home',
        ),
    ])
    first_name = "John"
    last_name = "Doe"
    age = 35

# Generated at 2022-06-12 16:08:26.757908
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        """{
            "a": 1,
            "b": {
                "c": "d"
            },
            "e": [1, 2, 3, "four", false]
        }"""
    )
    assert isinstance(token, DictToken)
    assert token.value["a"] == ScalarToken("1", 32, 32, "1")
    assert token.value["b"] == DictToken({"c": ScalarToken("d", 70, 70, "d")})

# Generated at 2022-06-12 16:08:41.624095
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema({"price": {"type": "number", "enum": [1, 2, 3]}})
    token = tokenize_json('{"price": 2}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value["price"], ScalarToken)
    try:
        token = tokenize_json('{"price": 2.4}')
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.char_index == 8
        assert exc.position.column_no == 10
        assert exc.position.line_no == 1
        error = str(exc)
        assert error == "Expecting property name enclosed in double quotes."
    token = tokenize_json('{"price": 2.0}')

# Generated at 2022-06-12 16:08:52.217992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"num": 123, "values": [10, 11, 12], "names": ["Bill", "Ted", "Bono"]}'
    token_schema = {
        "type": "object",
        "additional_properties": {"type": "any"},
        "properties": {
            "num": {"type": "number"},
            "values": {"type": "list", "items": {"type": "number"}},
            "names": {"type": "list", "items": {"type": "string"}},
        },
        "title": "DictToken",
    }
    schema = Schema.from_dict(token_schema)
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.start == 0, "token.start index should be 0"

# Generated at 2022-06-12 16:09:03.055897
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John Smith", "age": 25, "address": {"street": "21 2nd Street", "city": "New York", "state": "NY", "postalCode": "10021"}}'
    token = tokenize_json(content)
    assert token.get_value() == json.loads(content)
    content = '''
    {
        "name": "John Smith",
        "age": 25,
        "address": {
           "street": "21 2nd Street",
           "city": "New York",
           "state": "NY",
           "postalCode": "10021"
        }
    }'''
    token = tokenize_json(content)
    assert token.get_value() == json.loads(content)

# Generated at 2022-06-12 16:09:12.908265
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert token.start == 0
    assert token.end == 6

    assert type(token.value['a']) == ScalarToken
    assert token.value['a'].value == 1

    content = '[]'
    token = tokenize_json(content)
    assert type(token) == ListToken
    assert token.start == 0
    assert token.end == 1
    assert token.value == []

    content = 'null'
    token = tokenize_json(content)
    assert type(token) == ScalarToken
    assert token.value == None
    assert token.start == 0
    assert token.end == 4

    content = '[1]'

# Generated at 2022-06-12 16:09:22.545790
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:09:33.882235
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 2, 10, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-12 16:09:45.161500
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{ "firstName": "John", "lastName": "Smith", "age": 25, "address": { "streetAddress": "21 2nd Street", "city": "New York", "state": "NY", "postalCode": "10021" }, "phoneNumber": [{ "type": "home", "number": "212 555-1234" }, { "type": "fax", "number": "646 555-4567" } ] }')
    assert token.end == 313

# Generated at 2022-06-12 16:09:47.712206
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"foo": "bar"}'
    token_dict = tokenize_json(json_string)
    assert token_dict.as_dict() == {"foo": "bar"}


# Generated at 2022-06-12 16:09:54.932318
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"system_id": "xxx"}'

    # Get the root token.
    root_token = tokenize_json(content)

    # Check the root token is a DictToken.
    assert isinstance(root_token, DictToken)

    # Check the root token has a key of "system_id"
    assert "system_id" in root_token

    # Check the root token has a value for the key "system_id" of type ScalarToken representing the string 'xxx'
    assert isinstance(root_token["system_id"], ScalarToken)
    assert root_token["system_id"].value == "xxx"


# Generated at 2022-06-12 16:10:05.716099
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import Text

    class User(Schema):
        name = Text()

    def check(json_str, expected):
        token = tokenize_json(json_str)
        valid_token = validate_with_positions(token, User)
        assert valid_token == expected

    check('{"name":"foo"}', ({"name": "foo"}, []))
    check('{"name":""}', ({"name": ""}, []))
    check('{"name":""}', ({"name": ""}, []))

# Generated at 2022-06-12 16:10:13.724941
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": {"b": 1}}')
    assert token.value == {"a": {"b": 1}}

# Generated at 2022-06-12 16:10:23.323795
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {
        "first_name": "Ted",
        "last_name": "Cruz",
        "age": 47,
        "aliases": ["rafael", "tough"],
        "spouse": {"first_name": "Heidi", "age": 42},
        "other_spouses": [
            {"first_name": "Dan", "age": 40},
            {"first_name": "Jenna", "age": 32},
        ],
        "some_null": None,
    }
    assert tokenize_json(json.dumps(content)) == content



# Generated at 2022-06-12 16:10:29.261643
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello": "world", "list": [0, 1, {"key": "value"}]}')
    assert token.type == "dict"
    assert token["hello"].type == "str"
    assert token["hello"].value == "world"
    assert token["list"].type == "list"
    assert token["list"].value == [
        0,
        1,
        {"key": "value"},
    ]

    token = tokenize_json('{"key": "only key"}')
    assert token.type == "dict"
    assert token["key"].type == "str"
    assert token["key"].value == "only key"

# Generated at 2022-06-12 16:10:31.472328
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(content="{}")
    assert isinstance(token, DictToken)
    assert token.value == {}



# Generated at 2022-06-12 16:10:39.449924
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"prop": "hello"}') == {'prop': 'hello'}
    assert tokenize_json('{"prop": "hello"}') == {'prop': 'hello'}
    assert tokenize_json('[]') == []
    assert tokenize_json('["hello"]') == ['hello']

    assert tokenize_json('1') == 1
    assert tokenize_json('1.0') == 1.0
    assert tokenize_json('1e5') == 1e5
    assert tokenize_json('.23') == .23
    assert tokenize_json('-1.02e6') == -1.02e6
    assert tokenize_json('1.02e-3') == 1.02e-3

# Generated at 2022-06-12 16:10:50.441067
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON
    assert tokenize_json('{"name": "John Doe"}') == {
        "name": "John Doe"
    }
    assert tokenize_json('{"name": "John Doe", "age": 23}') == {
        "name": "John Doe",
        "age": 23,
    }
    assert tokenize_json('{"name": "John Doe", "age": [1, 2]}') == {
        "name": "John Doe",
        "age": [1, 2],
    }

    # Test invalid JSON
    try:
        tokenize_json('{"name": "John Doe", "age": [1, 2}')
    except ParseError as exc:
        assert exc.position == Position(
            column_no=28, line_no=1, char_index=28
        )


# Generated at 2022-06-12 16:11:01.009534
# Unit test for function tokenize_json
def test_tokenize_json():
    input_content = json.dumps({'a_string': 'some string', 'a_int': 12, 'a_float': 12, 'an_array': [1,2,3,4], 'a_dict': {'k': 'v'}})
    token = tokenize_json(input_content)
    assert isinstance(token, Token), 'token is not a Token'
    assert isinstance(token, DictToken), 'did not generate a DictToken as expected'
    assert isinstance(token.value, dict), 'value of DictToken is not a dict'
    assert token.value['a_string'] == 'some string', 'DictToken[\'a_string\'] is not string'
    assert token.value['a_int'] == 12, 'DictToken[\'a_int\'] is not an int'


# Generated at 2022-06-12 16:11:03.381490
# Unit test for function tokenize_json
def test_tokenize_json():
    validator = Field(name="Testing", required=True, primitive_type=str)
    token = tokenize_json('{"Testing": "Test string."}')
    value, error_messages = validate_with_positions(token=token, validator=validator)
    assert value == "Test string."
    assert not error_messages


# Generated at 2022-06-12 16:11:12.120938
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[\n 1,\n 2,\n 3\n]") == ListToken([1, 2, 3], 0, 13)
    assert tokenize_json("{\"key\": [\n 1,\n 2,\n 3\n]}") == DictToken(
        {"key": ListToken([1, 2, 3], 8, 21)}, 0, 22
    )
    assert tokenize_json("true") == ScalarToken(True, 0, 3)
    assert tokenize_json("false") == ScalarToken(False, 0, 4)
    assert tokenize_json("null") == ScalarToken(None, 0, 3)
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3)