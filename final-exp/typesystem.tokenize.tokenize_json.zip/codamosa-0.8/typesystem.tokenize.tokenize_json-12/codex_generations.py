

# Generated at 2022-06-12 16:01:40.335947
# Unit test for function tokenize_json
def test_tokenize_json():
    t = tokenize_json('{"test": 1, "dict": {"test": 1}}')
    assert t.map == {"test": 1, "dict": {"test": 1}}



# Generated at 2022-06-12 16:01:48.322784
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json(b'{"name": "Hello World"}')
    assert result.value == {"name": "Hello World"}
    result = tokenize_json(b'{"name": "Hello World", "age": 23, "city": "Pune"}')
    assert result.value == {
        "name": "Hello World",
        "age": 23,
        "city": "Pune",
    }
    result = tokenize_json(b'{"name": "Hello World", "age": "23", "city": "Pune"}')
    assert result.value == {
        "name": "Hello World",
        "age": "23",
        "city": "Pune",
    }

# Generated at 2022-06-12 16:01:51.681185
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":"1", "b":2, "c":["3",4,null]}')
    assert token.type == 'dict'
    assert token.value == {'a': '1', 'b': 2, 'c': ['3', 4, None]}

# Generated at 2022-06-12 16:01:57.307111
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b")})
    assert tokenize_json('{"a": 1}') == DictToken({"a": ScalarToken(1)})
    assert tokenize_json('{"a": [1, "b"]}') == DictToken({"a": ListToken([1, ScalarToken("b")])})
    assert tokenize_json('{"a": {"b": 1}}') == DictToken({"a": DictToken({"b": ScalarToken(1)})})



# Generated at 2022-06-12 16:02:09.438971
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:02:19.404540
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"a": 1, "b": [1, 2, 3], "c": 3.2e-8}'
    token = tokenize_json(json_str)
    assert token.value == {"a": 1, "b": [1, 2, 3], "c": 3.2e-8}
    assert token.position.start_column == 1
    assert token.position.end_column == 32
    assert token.position.start_line == 1
    assert token.position.end_line == 1
    assert token.position.start_char_index == 0
    assert token.position.end_char_index == 31
    assert isinstance(token, DictToken)
    dict_token = token

# Generated at 2022-06-12 16:02:25.903574
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string case
    with raises(ParseError, match="No content"):
        tokenize_json("")
    # Test simple string case
    token = tokenize_json('{"message":"Hello World!"}')
    assert token.value["message"].value=="Hello World!"
    # Test unicode string
    token = tokenize_json('{"message":"🌍"}')
    assert token.value["message"].value=="🌍"
    # Test blank string case
    with raises(ParseError, match="Expecting value"):
        tokenize_json('{")')

# Generated at 2022-06-12 16:02:28.828573
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"id": "1", "list": ["a", "b", 3]}'
    result = tokenize_json(content)
    print(result)
    assert isinstance(result, DictToken)

# Generated at 2022-06-12 16:02:38.989059
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:02:41.583749
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "col1": ["a", "b", "c"],
        "col2": [1, 2, 3]
    }
    """
    try:
        tokenize_json(content)
    except ParseError as e:
        assert e.code == "parse_error"
        assert e.position.line_no == 4
        assert e.position.column_no == 2
    else:
        assert False, "Should raise ParseError."

# Generated at 2022-06-12 16:03:04.429255
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This is a simple test for function tokenize_json()
    """
    import json

    def strip_positions(data):
        """
        Assisting function for strip positions from test data
        """
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    strip_positions(value)
                elif isinstance(value, str):
                    data[key] = value.strip().strip('"')
                elif isinstance(value, list):
                    for item in value:
                        strip_positions(item)
        return data

    data = {
        "alpha": {
            "beta": [1, "gamma"]
        },
        "delta": ["epsilon", {"zeta": "eta"}]
    }

    # Convert

# Generated at 2022-06-12 16:03:15.861010
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == {
        "hello": "world"
    }, "should tokenize a valid json string"

    assert tokenize_json("1") == 1, "should tokenize a valid json number"
    assert tokenize_json("true") == True, "should tokenize a valid json boolean"
    assert tokenize_json("false") == False, "should tokenize a valid json boolean"
    assert tokenize_json("null") == None, "should tokenize a valid json null"

    assert tokenize_json("") == None, "should tokenize an empty string"
    assert tokenize_json("[hello]") == None, "should tokenize an unclosed array"
    assert tokenize_json("hello") == None, "should tokenize an invalid string"

# Generated at 2022-06-12 16:03:27.794848
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:03:31.441926
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": [1, 2.2, 3]}'
    obj = {"key": [1, 2.2, 3]}
    assert tokenize_json(content) == obj

# Generated at 2022-06-12 16:03:34.862801
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"test": 1}')
    assert isinstance(token, DictToken)
    assert token.value["test"].value == 1
    assert token.value["test"].value_type == "number"

# Generated at 2022-06-12 16:03:42.776609
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import io
    import typesystem
    import uuid

    # Test for all valid JSON types
    class TestSchema(typesystem.Schema):
        name = typesystem.String(max_length=10)
        number = typesystem.Integer()
        id = typesystem.String()

    # Valid JSON string
    content1 = '{"name": "John", "number": 3, "id": "d345b9ff-f0ad-43c7-b31a-52c83e8e00b2"}'

    # Invalid JSON string
    content2 = '{"name": "John", "number": false, "id": "d345b9ff-f0ad-43c7-b31a-52c83e8e00b2"}'

    # Test for encoding errors

# Generated at 2022-06-12 16:03:52.808672
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert token.start == 0
    assert token.end == 6
    assert token.value == {"a": 1}
    assert token.content == '{"a": 1}'

    token = tokenize_json('{"a": 1}')
    assert token.start == 0
    assert token.end == 6
    assert token.value == {"a": 1}
    assert token.content == '{"a": 1}'

    token = tokenize_json('["a", 1]')
    assert token.start == 0
    assert token.end == 6
    assert token.value == ["a", 1]
    assert token.content == '["a", 1]'

    token = tokenize_json('"string"')
    assert token.start == 0
    assert token.end == 8


# Generated at 2022-06-12 16:03:56.219810
# Unit test for function tokenize_json
def test_tokenize_json():
    json = open("test_json.json")
    json_obj = json.read()
    # print(json_obj)
    tokens = tokenize_json(json_obj)
    for token in tokens:
        print(token)



# Generated at 2022-06-12 16:03:58.822089
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"x": "3"}')
    assert type(token) is DictToken
    assert token.value == {ScalarToken("x"): ScalarToken("3")}


# Generated at 2022-06-12 16:04:05.864850
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:04:21.422581
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": "value"}')
    assert isinstance(token, DictToken)
    assert token.content == '{"key": "value"}'
    assert token.end_pos == 17
    assert token.start_pos == 0
    assert token.value == {"key": "value"}
    assert isinstance(token.value["key"], ScalarToken)
    assert token.value["key"].content == '"value"'
    assert token.value["key"].end_pos == 16
    assert token.value["key"].start_pos == 6
    assert token.value["key"].value == "value"
    assert token.value["key"].items == []


# Generated at 2022-06-12 16:04:27.924165
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-12 16:04:38.796983
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.fields import String
    from typesystem.schemas import Schema
    
    content = (
        '{"_comment": "This is a comment.", "string": "Single string", '
        '"list": [1, 2, 3], "dict": {"a": 1, "b": 2, "c": 3}, '
        '"empty_list": [], "empty_dict": {}}'
    )
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.children is not None
    assert len(token.children) == 6


# Generated at 2022-06-12 16:04:48.289795
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b"}') == DictToken({ScalarToken('a', 0, 3, '{"a":"b"}'): ScalarToken('b', 6, 9, '{"a":"b"}')}, 0, 9, '{"a":"b"}')
    assert tokenize_json('["b"]') == ListToken([ScalarToken('b', 2, 3, '["b"]')], 0, 4, '["b"]')
    assert tokenize_json('"string"') == ScalarToken('string', 1, 8, '"string"')
    assert tokenize_json('100') == ScalarToken(100, 0, 3, '100')
    assert tokenize_json('1.2') == ScalarToken(1.2, 0, 3, '1.2')

# Generated at 2022-06-12 16:05:00.407136
# Unit test for function tokenize_json
def test_tokenize_json():

    assert tokenize_json(b"null") == ScalarToken(value=None, start=0, end=3, content="null")
    assert tokenize_json(b"true") == ScalarToken(value=True, start=0, end=3, content="true")
    assert tokenize_json(b"false") == ScalarToken(value=False, start=0, end=4, content="false")
    assert tokenize_json(b'0') == ScalarToken(value=0, start=0, end=1, content="0")
    assert tokenize_json(b'42') == ScalarToken(value=42, start=0, end=2, content="42")
    assert tokenize_json(b'-42') == ScalarToken(value=-42, start=0, end=3, content="-42")


# Generated at 2022-06-12 16:05:06.825620
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest


# Generated at 2022-06-12 16:05:17.979874
# Unit test for function tokenize_json
def test_tokenize_json():
    payload = '{"a": 1, "b": 2}'
    with open("tests/json/json1.json", "r") as json_file:
        json_content = json_file.read()
    token = tokenize_json(payload)
    test_tok = tokenize_json(json_content)
    assert token.position.column_no == 1
    assert token.position.line_no == 1
    assert token.position.char_index == 0
    assert token.value == {"a": 1, "b": 2}
    assert token.children[0].value == "a"
    assert token.children[1].value == 1
    assert token.children[2].value == "b"
    assert token.children[3].value == 2
    assert test_tok.position.column_no == 1
   

# Generated at 2022-06-12 16:05:27.854567
# Unit test for function tokenize_json
def test_tokenize_json():
    # test an empty string
    content = ""
    token = tokenize_json(content)
    assert content == ""
    assert token is None

    # test a string with content
    content = """{"a":"b"}"""
    token = tokenize_json(content)
    assert token is not None

    # test a string with spaces
    content = """ {"a":"b"} """
    token = tokenize_json(content)
    assert token is not None

    # test a string with newlines
    content = """
    {"a":"b"}
    """
    token = tokenize_json(content)
    assert token is not None

    # test a unicode string
    content = """{"\u2019":"b"}"""
    token = tokenize_json(content)
    assert token is not None

    # test a bytestring
   

# Generated at 2022-06-12 16:05:34.014248
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "userId": 1,
        "id": 1,
        "title": "delectus aut autem",
        "completed": false
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.key == "root"
    assert token.value["userId"].value == 1
    assert token.value["id"].value == 1
    assert token.value["title"].value == "delectus aut autem"
    assert token.value["completed"].value == False


# Generated at 2022-06-12 16:05:36.887880
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        tokenize_json('{"some": "json"}')
        == DictToken({"some": "json"}, 0, 15, '{"some": "json"}')
    )



# Generated at 2022-06-12 16:05:48.001855
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 0

    token = tokenize_json("}")
    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 0

    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.start_index == 0
    assert token.end_index == 1
    assert not token.items

    token = tokenize_json("[a]")
    assert isinstance(token, ListToken)
    assert token.start_index == 0
    assert token.end_index == 2
    assert len(token) == 1
    assert token[0].start_index == 1

# Generated at 2022-06-12 16:05:53.543069
# Unit test for function tokenize_json
def test_tokenize_json():
    value = {"x": 1.0, "y": 2.0}
    json_value = json.dumps(value)
    token = tokenize_json(json_value)
    assert token.as_python() == value

    value = {"x": 1.0, "y": "2.0"}
    json_value = json.dumps(value)
    token = tokenize_json(json_value)
    assert token.as_python() == value


# Generated at 2022-06-12 16:06:01.737239
# Unit test for function tokenize_json
def test_tokenize_json():
    content = ""

    try:
        tokenize_json(content)
    except ParseError as exc:
        msg = str(exc)
        assert (
            msg
            == """
Parse error at line 1, column 1. No content.

1 |
  | ^"""[1:]
        )

    content = """
{"foo": [1, 2, 3], "bar": [1, 2, "a"]}
""".strip()

    token = tokenize_json(content)
    assert token.is_dict()
    assert token.get("foo").is_list()
    assert token.get("foo").get(2).get_value() == 3
    assert token.get("bar").is_list()
    assert token.get("bar").get(2).is_string()

    content = "true"

    token

# Generated at 2022-06-12 16:06:10.950248
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"a":"1","b":["ciara","fiona","siobhan"],"c":null,"d":true,"e":false,"f":1,"g":1.2}')
    assert "a" in token.value
    assert "b" in token.value
    assert "c" in token.value
    assert "d" in token.value
    assert "e" in token.value
    assert "f" in token.value
    assert "g" in token.value
    assert token.value["a"].value == "1"
    assert token.value["b"].value == ["ciara", "fiona", "siobhan"]
    assert token.value["c"].value == None
    assert token.value["d"].value == True
    assert token.value["e"].value == False

# Generated at 2022-06-12 16:06:16.510160
# Unit test for function tokenize_json
def test_tokenize_json():

    input_1 = ""
    output_1 = ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))
    assert(tokenize_json(input_1) == output_1)

    input_2 = "123"
    output_2 = ScalarToken(value=123, start_pos=0, end_pos=2, content="123")
    assert(tokenize_json(input_2) == output_2)

    input_3 = '{"abc": [1, "abc"]}'
    output_3 = DictToken(value={'abc': [1, 'abc']}, start_pos=0, end_pos=16, content='{"abc": [1, "abc"]}')

# Generated at 2022-06-12 16:06:23.994559
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with valid json
    content = '{"a":1,"b":2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

    # Test with invalid json
    content = '{a:1,"b":2}'
    with pytest.raises(ParseError):
        tokenize_json(content)

    # Test with empty string
    content = ''
    with pytest.raises(ParseError):
        tokenize_json(content)

    # Test with empty bytestring
    content = b''
    with pytest.raises(ParseError):
        tokenize_json(content)


# Generated at 2022-06-12 16:06:33.540170
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == DictToken({
        ScalarToken('hello', 1, 6, '{"hello": "world"}'): ScalarToken('world', 14, 19, '{"hello": "world"}')
    }, 0, 19, '{"hello": "world"}')

# Generated at 2022-06-12 16:06:35.965997
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"id": 1234, "name": "manoj"}')
    print('token is', token)



# Generated at 2022-06-12 16:06:45.618998
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({'a': ScalarToken(1, 0, 7, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': ScalarToken('b', 0, 9, '{"a": "b"}')}, 0, 10, '{"a": "b"}')
    assert tokenize_json('{"a": null}') == DictToken({'a': ScalarToken(None, 0, 12, '{"a": null}')}, 0, 13, '{"a": null}')

# Generated at 2022-06-12 16:06:56.652130
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tests.test_functions import tokens_match
    from typesystem.validators import AnyOf, Number

    validator = AnyOf(validators=[Number()])
    content = '[1, 2, 3]'
    token = tokenize_json(content)
    validate_json(content, validator)
    assert tokens_match(token, [1, 2, 3])
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content

    content = '{"value": [1, 2, 3]}'
    token = tokenize_json(content)
    validate_json(content, validator)
    assert token.keys() == ["value"]
    assert token["value"].start == 9
    assert token["value"].end == len(content) - 1

# Generated at 2022-06-12 16:07:08.200761
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"test":"test"}'
    result = tokenize_json(json_str)
    assert result == DictToken({ScalarToken('test', 2, 5, json_str): ScalarToken('test', 9, 12, json_str)}, 0, 13, json_str)



# Generated at 2022-06-12 16:07:14.037729
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json('{"x": "y"}')
    except ParseError as err:
        raise AssertionError(err)
    try:
        tokenize_json('{"x": "y"')
        raise AssertionError("this should never happen")
    except ParseError as err:
        assert str(err) == "Invalid JSON. Expected ',' delimiter at line 1 column 12 char 11."
    try:
        tokenize_json('["x", "4", "y"]')
    except ParseError as err:
        raise AssertionError(err)



# Generated at 2022-06-12 16:07:24.036241
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({'key': 'value'}, 0, 19, '{"key": "value"}')
    assert tokenize_json('["item1", "item2", "item3"]') == ListToken(['item1', 'item2', 'item3'], 0, 31, '["item1", "item2", "item3"]')

# Generated at 2022-06-12 16:07:33.271805
# Unit test for function tokenize_json
def test_tokenize_json():
    """ Test tokenize_json function """
    assert tokenize_json('{"key": "value"}') == {"key": "value"}
    assert tokenize_json('{"key": [1, 2, 3]}') == {"key": [1, 2, 3]}
    assert tokenize_json('"value"') == "value"
    assert tokenize_json('1') == 1
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]
    assert tokenize_json('null') == None
    assert tokenize_json('true') == True
    assert tokenize_json('false') == False
    assert tokenize_json('') == None
    try:
        tokenize_json('"value')
        assert False
    except ParseError:
        pass

# Generated at 2022-06-12 16:07:39.863807
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b","c":[1,2,3]}') == \
        {'a': 'b', 'c': [1, 2, 3]}
    assert tokenize_json('{"a": "b","c": [1,2,3]}') == \
        {'a': 'b', 'c': [1, 2, 3]}
    assert tokenize_json('''{"a": "b","c": [1,2,3]}''') == \
        {'a': 'b', 'c': [1, 2, 3]}


# Generated at 2022-06-12 16:07:48.410205
# Unit test for function tokenize_json
def test_tokenize_json():
    # Normal case
    content = '{"age": 34, "name": "john", "is_married": true}'
    token = tokenize_json(content)
    assert token.type == "dict"
    assert token.children[0].type == "scalar"
    assert token.children[0].value == "age"
    assert token.children[0].position == Position(column_no=2, line_no=1, char_index=1)
    assert token.children[1].value == 34
    assert token.children[1].position == Position(column_no=7, line_no=1, char_index=6)
    assert token.children[2].value == "name"
    assert token.children[2].position == Position(column_no=15, line_no=1, char_index=14)


# Generated at 2022-06-12 16:07:55.498903
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"asdf": 12, "a": [1,2,3], "b": {"a": "b"}}'
    result = tokenize_json(json_string)

    assert result.start == 0
    assert result.end == len(json_string)
    assert result.children[0].value == "asdf"
    assert result.children[1].value == 12
    assert result.children[2].value.children[0].value == 1
    assert result.children[3].children[0].value == "a"
    assert result.children[3].children[1].value == "b"



# Generated at 2022-06-12 16:07:58.641874
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token == {'foo': 'bar'}



# Generated at 2022-06-12 16:08:04.355910
# Unit test for function tokenize_json
def test_tokenize_json():
    content1 = '{"name":"John", "age": 30, "cars": [{"name":"Toyota","models":["Corolla","Camry"]}, {"name":"Ford","models":["Focus","Fiesta"]}, {"name":"Fiat","models":["500","Panda"]}]}'
    token = tokenize_json(content1)
    print(type(token.value['cars'].value))
    print(token.value['cars'].value)
    print(token)



# Generated at 2022-06-12 16:08:12.936857
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2, 3], "b": "hello"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    content = "null"
    token = tokenize_json(content)
    assert token is None
    assert isinstance(token, ScalarToken)
    content = '"hello"'
    token = tokenize_json(content)
    assert token == "hello"
    assert isinstance(token, ScalarToken)
    assert token.start == 0
    assert token.end == 6
    assert token.content == content
    content = '{"a": [1, 2, 3], "b": "hello"}'
    token = tokenize_json(content)
    assert token["a"] == [1, 2, 3]

# Generated at 2022-06-12 16:08:25.277601
# Unit test for function tokenize_json
def test_tokenize_json():
    content = r'{"name": "Mateusz", "surname": "Kowalski"}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert token.value == {'name': 'Mateusz', 'surname': 'Kowalski'}


# Generated at 2022-06-12 16:08:35.794195
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = '{"value": 1, "name": "string"}'

# Generated at 2022-06-12 16:08:40.324119
# Unit test for function tokenize_json
def test_tokenize_json():
    #test_tokenize_json_empty_string
    with pytest.raises(ParseError) as e_info:
        tokenize_json('')
    assert e_info.value.code == 'no_content'
    assert e_info.value.position.line_no == 1
    assert e_info.value.position.column_no == 1
    assert e_info.value.position.char_index == 0

    #test_tokenize_json_no_content
    with pytest.raises(ParseError) as e_info:
        tokenize_json('          ')
    assert e_info.value.code == 'no_content'
    assert e_info.value.position.line_no == 1
    assert e_info.value.position.column_no == 1

# Generated at 2022-06-12 16:08:44.723488
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = '{"key": "value"}'
    assert tokenize_json(test_json) == DictToken(
        {"key": ScalarToken("value", 4, 12, test_json)},
        0,
        16,
        test_json,
    )


# Generated at 2022-06-12 16:08:54.780236
# Unit test for function tokenize_json
def test_tokenize_json():
    # One line test cases
    json = """{"abc": 123}"""
    assert tokenize_json(json) == DictToken({"abc": ScalarToken(123)}, 0, 12)

    json = """{"abc": {"def": 456.789}}"""
    assert tokenize_json(json) == DictToken(
        {"abc": DictToken({"def": ScalarToken(456.789)})}, 0, 24
    )

    json = """[[123.456, 789.101112], true, false, null]"""

# Generated at 2022-06-12 16:09:05.403667
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"hello": "world"}') == DictToken(
        {ScalarToken("hello",0,5, b'{"hello": "world"}'): ScalarToken("world",11,16,b'{"hello": "world"}')},0,16,b'{"hello": "world"}'
    )
    assert tokenize_json('{"hello": "world"}') == DictToken(
        {ScalarToken("hello",0,5, '{"hello": "world"}'): ScalarToken("world",11,16,'{"hello": "world"}')},0,16,'{"hello": "world"}'
    )

# Generated at 2022-06-12 16:09:14.698691
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.tokenize.positioner import locate_token

    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        pet = Field(type="string")

    content = '{"name": "Patrick", "age": 5, "pet": "dog"}'
    value, error_messages = validate_json(content, MySchema)
    assert not error_messages
    assert value == {"name": "Patrick", "age": 5, "pet": "dog"}

    content = '{"age": 5, "pet": "dog"}'
    value, error_messages = validate_json(content, MySchema)

# Generated at 2022-06-12 16:09:23.451605
# Unit test for function tokenize_json
def test_tokenize_json():
    # TODO: Add more tests
    token = tokenize_json('{"name":"Tokyo","latitude":35.685,"longitude":139.7514}')
    token = tokenize_json("""[{"a":"b","c":"d"},{"e":"f","g":"h"}]""")
    token = tokenize_json("""{"a":"b","c":"d"}""")
    token = tokenize_json("""[{"a":"b","c":"d"},{"e":"f","g":"h"}]""")
    token = tokenize_json("""{"a":"b","c":[{"e":"f","g":"h"}]}""")
    token = tokenize_json("""["b","c",{"e":"f","g":"h"}]""")

# Generated at 2022-06-12 16:09:34.805323
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"firstName":"John", "lastName": "Doe", "likes": ["JavaScript", "Python"]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 3
    assert isinstance(token.value['firstName'], ScalarToken)
    assert token.value['firstName'].value == "John"
    assert isinstance(token.value['lastName'], ScalarToken)
    assert token.value['lastName'].value == "Doe"
    assert isinstance(token.value['likes'], ListToken)
    assert len(token.value['likes'].value) == 2
    assert isinstance(token.value['likes'].value[0], ScalarToken)

# Generated at 2022-06-12 16:09:40.295947
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"field1": "123"}') == DictToken({
        ScalarToken('field1', 0, 8, '{"field1": "123"}'): ScalarToken('123', 10, 15, '{"field1": "123"}'),
    }, 0, 15, '{"field1": "123"}')


# Generated at 2022-06-12 16:09:50.650511
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{}"
    assert isinstance(tokenize_json(content), Token)


# Generated at 2022-06-12 16:10:01.277765
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:10:10.168020
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test content with empty dict {}
    content = "{}"
    token = tokenize_json(content)
    assert token.type_ == "dict"
    assert token.value == {}

    # Test content with empty list []
    content = "[]"
    token = tokenize_json(content)
    assert token.type_ == "list"
    assert token.value == []

    # Test content with an empty string ""
    content = "\"\""
    token = tokenize_json(content)
    assert token.type_ == "scalar"
    assert token.value == ""

    # Test content with null
    content = "null"
    token = tokenize_json(content)
    assert token.type_ == "scalar"
    assert token.value == None

    # Test content with true
    content = "true"

# Generated at 2022-06-12 16:10:21.824053
# Unit test for function tokenize_json
def test_tokenize_json():
    # Arrange
    content = '''
    {
        "firstName": "John",
        "lastName": "Smith",
        "age": 25,
        "address": {
            "streetAddress": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "postalCode": "10021"
        },
        "phoneNumber": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "fax",
                "number": "646 555-4567"
            }
        ],
        "email": "john@allaboutjohn.com"
    }'''
    # Act
    token = tokenize_json(content)
    # Assert
    assert isinstance(token, Token)


# Generated at 2022-06-12 16:10:29.432926
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(
        value={}, content_index=(0, 1), char_index=(0, 1), content="{}"
    )
    assert tokenize_json("[]") == ListToken(
        value=[], content_index=(0, 1), char_index=(0, 1), content="[]"
    )
    assert tokenize_json("null") == ScalarToken(
        value=None, content_index=(0, 4), char_index=(0, 4), content="null"
    )
    assert tokenize_json('""') == ScalarToken(
        value="", content_index=(0, 2), char_index=(0, 2), content='""'
    )

# Generated at 2022-06-12 16:10:38.175480
# Unit test for function tokenize_json
def test_tokenize_json():
    def compare(a: Token, b: Token) -> None:
        assert isinstance(a, type(b))
        if isinstance(a, ScalarToken):
            assert a.value == b.value
        elif isinstance(a, DictToken):
            assert a.value == b.value
        elif isinstance(a, ListToken):
            assert len(a.value) == len(b.value)
            for a_item, b_item in zip(a.value, b.value):
                compare(a_item, b_item)
        assert a.start == b.start
        assert a.end == b.end
        assert a.content == b.content

    def test(s: str) -> None:
        compare(tokenize_json(s), tokenize_json(s))

    # Example taken from

# Generated at 2022-06-12 16:10:49.252577
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken('foo', 1, 5, '{"foo": "bar"}'): ScalarToken(
            'bar', 9, 13, '{"foo": "bar"}')}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json('[1, 2, "foo"]') == ListToken([
        ScalarToken(1, 1, 2, '[1, 2, "foo"]'),
        ScalarToken(2, 4, 5, '[1, 2, "foo"]'),
        ScalarToken('foo', 7, 12, '[1, 2, "foo"]')], 0, 14, '[1, 2, "foo"]')

# Generated at 2022-06-12 16:11:00.101348
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{ "a" : "b"}') == {"a": "b"}
    assert tokenize_json('[ { "a" : "b"} ]') == [{"a": "b"}]
    assert tokenize_json('{ "a" : { "a" : "b"}}') == {"a": {"a": "b"}}
    assert tokenize_json(b'{ "a" : "b"}') == {"a": "b"}
    assert tokenize_json('{"a":false}') == {"a": False}
    assert tokenize_json('{"a":true}') == {"a": True}
    assert tokenize_json('{"a":null}') == {"a": None}
    assert tokenize_json('{"a":3.14}') == {"a": 3.14}


# Generated at 2022-06-12 16:11:06.222415
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(content={"foo": 123, "bar": 456})
    assert token == DictToken(
        value={ScalarToken(value="foo"), ScalarToken(value=123), ScalarToken(value="bar"), ScalarToken(value=456)},
        start=0,
        end=22,
    )



# Generated at 2022-06-12 16:11:11.464766
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class UserSchema(Schema):
        first_name = String()

    user = ('{"first_name": "Abe"}')

    try:
        tokenized = tokenize_json(user)
    except ParseError as e:
        return "Parse Error"

    return validate_with_positions(token=tokenized, validator=UserSchema())
