

# Generated at 2022-06-12 16:01:35.469793
# Unit test for function tokenize_json
def test_tokenize_json():
    value, error_messages = validate_json(
        """{"foo": [1, 2, 3], "bar": "baz"}""",
        {"foo": [int], "bar": str},
    )
    assert value
    assert isinstance(value, dict)
    assert value["foo"] == [1, 2, 3]
    assert value["bar"] == "baz"
    assert error_messages == []


# Generated at 2022-06-12 16:01:46.571961
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases for tokenize_json()
    assert tokenize_json("7") == ScalarToken(7, 0, 0, "7")
    assert tokenize_json("7.0") == ScalarToken(7.0, 0, 3, "7.0")
    assert tokenize_json("7.9") == ScalarToken(7.9, 0, 3, "7.9")
    assert tokenize_json("-7") == ScalarToken(-7, 0, 2, "-7")
    assert tokenize_json("-7.0") == ScalarToken(-7.0, 0, 4, "-7.0")
    assert tokenize_json("-7.9") == ScalarToken(-7.9, 0, 4, "-7.9")

# Generated at 2022-06-12 16:01:53.268829
# Unit test for function tokenize_json
def test_tokenize_json():
    case_1 = ""
    try:
        tokenize_json(case_1)
    except ParseError as pe:
        assert pe.position.line_no == 1
        assert pe.position.column_no == 1
        assert pe.code == "no_content"

    case_2 = '{"f1": [1, 2, 3]}'
    token = tokenize_json(case_2)
    assert isinstance(token, DictToken)
    assert token.value["f1"].value[0] == ScalarToken(1, 8, 9, case_2)



# Generated at 2022-06-12 16:02:03.488076
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string="""
    {
    "key": "val",
    "key2": true,
    "key3": null,
    "key4": 10.0,
    "key5": 10,
    "key6": [
        1,
        2
    ],
    "key7": {
        "key": 2
    }
    }
    """

    root = tokenize_json(json_string)
    assert isinstance(root, DictToken)

    assert root.start_colno == 2
    assert root.end_colno == 47
    assert root.start_line_no == 2
    assert root.end_line_no == 12
    assert root.start_char_index == 2
    assert root.end_char_index == 49
    assert root.raw_line_no == 1
   

# Generated at 2022-06-12 16:02:10.520731
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    {
        "foo": [
            123,
            456
        ],
        "bar": {
            "baz": "qux"
        }
    }
    """
    token = tokenize_json(json_string)

    assert isinstance(token, DictToken)
    assert token.value == {
        "foo": [123, 456],
        "bar": {"baz": "qux"},
    }


# Generated at 2022-06-12 16:02:13.050362
# Unit test for function tokenize_json
def test_tokenize_json():
    # assert tokenize_json("1") == DictToken({"a": 1})
    assert tokenize_json("1") == ScalarToken(1, 0, 0, "1")


# Generated at 2022-06-12 16:02:22.751466
# Unit test for function tokenize_json
def test_tokenize_json():
    # test with invalid JSON
    try:
        tokenize_json("{")
    except ParseError as err:
        assert err.position.line_no == 1
        assert err.position.column_no == 2
    except Exception as err:
        assert False, "Wrong exception type raised."

    def _test_json(json: str) -> None:
        token = tokenize_json(json)
        json_parsed = eval(json)
        assert token.value == json_parsed
        assert token.as_json() == json_parsed


# Generated at 2022-06-12 16:02:29.860329
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unit test for tokenize_json.
    """
    json_str = '{"name": "david","address": {"street": "123 fake st", "city": "Seattle"}}'
    token = tokenize_json(json_str)
    assert token.data["name"] == "david"
    assert token.data["address"].data["street"] == "123 fake st"
    assert token.data["address"].data["city"] == "Seattle"


# Generated at 2022-06-12 16:02:32.729687
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"name":"David", "age": 34}'
    token = tokenize_json(json)
    assert(isinstance(token, DictToken))



# Generated at 2022-06-12 16:02:37.198756
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema()
    token = tokenize_json('{"eins": 1, "zwei": 2}')
    assert type(token) == DictToken
    assert token.value.keys() == {"eins", "zwei"}
    assert token.children[0].children[0].value == 1
    assert token.children[1].children[0].value == 2

# Generated at 2022-06-12 16:02:56.408331
# Unit test for function tokenize_json
def test_tokenize_json():
    # empty object
    assert tokenize_json("{}") == {"type": "dict", "value": {}}
    assert tokenize_json("{ }") == {"type": "dict", "value": {}}
    # empty dictionary
    assert tokenize_json("[]") == {"type": "list", "value": []}
    assert tokenize_json("[ ]") == {"type": "list", "value": []}
    # single-item object initializer
    assert tokenize_json('{"key": "value"}') == {
        "type": "dict",
        "value": {"key": {"type": "scalar", "value": "value"}},
    }
    # single-item array

# Generated at 2022-06-12 16:03:02.701522
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string="""
    {
        "name":"John",
        "age":30,
        "cars": {
            "car1":"Ford",
            "car2":"BMW",
            "car3":"Fiat"
        }
    }
    """
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert token.value["name"] == "John"
    assert token.value["cars"]["car3"] == "Fiat"
    assert token.start_position.char_index == 4
    assert token.end_position.line_no == 11


# Generated at 2022-06-12 16:03:14.009052
# Unit test for function tokenize_json
def test_tokenize_json():
    from datetime import date, datetime, timezone
    from decimal import Decimal
    from uuid import UUID

    date_string = "2020-04-08"
    date_value = date(2020, 4, 8)
    date_token = tokenize_json(date_string)

    assert date_token.value == date_value

    date_time_string = "2020-04-08T13:00:00Z"
    date_time_value = datetime(2020, 4, 8, 13, 00, 00, tzinfo=timezone.utc)
    date_time_token = tokenize_json(date_time_string)

    assert date_time_token.value == date_time_value

    decimal_string = "123.45"
    decimal_value = Decimal("123.45")
    decimal_

# Generated at 2022-06-12 16:03:21.761996
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"abc": 123}') == DictToken({ScalarToken('abc', 1, 6, '{"abc": 123}'): ScalarToken(123, 10, 13, '{"abc": 123}')}, 0, 14, '{"abc": 123}')
    assert tokenize_json('{"abc": 123} ') == DictToken({ScalarToken('abc', 1, 6, '{"abc": 123} '): ScalarToken(123, 10, 13, '{"abc": 123} ')}, 0, 15, '{"abc": 123} ')

# Generated at 2022-06-12 16:03:25.465129
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[1, 2, 3]") == ListToken(
        [ScalarToken(1, 1, 1, "[1, 2, 3]"), ScalarToken(2, 5, 5, "[1, 2, 3]"), ScalarToken(3, 9, 9, "[1, 2, 3]")],
        0, 10, "[1, 2, 3]",
    )

    # tokenize_json throws an error when no content is provided
    with pytest.raises(ParseError):
        tokenize_json("")


# Unit tests for function validate_json

# Generated at 2022-06-12 16:03:28.624864
# Unit test for function tokenize_json
def test_tokenize_json():
    with pytest.raises(ParseError):
        tokenize_json("[1,2,3")


# Generated at 2022-06-12 16:03:39.084753
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(primitive_type="string")
    required_field = Field(primitive_type="string", required=True)
    schema = Schema(fields={"required_field": required_field})

    valid_str = '{ "required_field": "test value" }'
    result = validate_json(content=valid_str, validator=schema)
    assert result == ({ "required_field": "test value" }, [])

    missing_required_field = '{ "non_existant_field": "test value" }'
    result = validate_json(content=missing_required_field, validator=schema)
    errors = [
        ValidationError(
            field_name="required_field",
            text="Required field.",
            code="required"
        )
    ]

# Generated at 2022-06-12 16:03:47.471532
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"id": 1, "age": 18}]'

    actual_token = tokenize_json(content)

    expected_token = ListToken(
        [
            DictToken(
                {
                    ScalarToken(
                        "id", 1, 2, content
                    ): ScalarToken(1, 5, 5, content),
                    ScalarToken(
                        "age", 8, 9, content
                    ): ScalarToken(18, 12, 13, content),
                },
                0, 13, content
            )
        ],
        0, 14, content
    )

    assert_equal(
        expected_token,
        actual_token
    )


# Generated at 2022-06-12 16:03:52.114791
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"test"') == ScalarToken(
        "test", position=Position(column_no=1, line_no=1, char_index=0), value="test"
    )
    assert tokenize_json('["test"]') == ListToken(
        [
            ScalarToken(
                "test",
                position=Position(column_no=2, line_no=1, char_index=1),
                value="test",
            )
        ],
        position=Position(column_no=1, line_no=1, char_index=0),
        value=["test"],
    )

# Generated at 2022-06-12 16:03:58.302624
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    schema = Schema({"status": String(max_length=10), "code": Integer(min_value=0)})
    token = tokenize_json(b'{"status": "ok", "code": 200}')
    content, errors = validate_with_positions(token=token, validator=schema)
    assert content == {"status": "ok", "code": 200}
    assert errors == []


# Generated at 2022-06-12 16:04:12.207318
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that we can get a parsed version of a JSON validator for a field.
    in_memory_file = "{\n  \"name\": \"Joe\", \n  \"age\": 21\n}"
    token = tokenize_json(in_memory_file)

    assert isinstance(token, DictToken)
    assert token.position.column_no == 0
    assert token.position.line_no == 0
    assert token.position.char_index == 0

    for key in token.value:
        assert isinstance(key, ScalarToken)
        assert key.value in ["name", "age"]
        assert key.position.column_no == 2

    assert isinstance(token.value["name"], ScalarToken)
    assert token.value["name"].value == "Joe"

# Generated at 2022-06-12 16:04:22.843082
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.testing_tokens import (
        CommentToken,
        ListToken,
        ScalarToken,
        Token,
        TokenType,
    )

    from typesystem.tokenize.positional_validation import validate_with_positions

    from typesystem.types import IntegerType, ListType, ObjectType, StringType
    from typesystem.schemas import Schema

    class Person(Schema):
        age = IntegerType()
        name = StringType()

    class Company(Schema):
        employees = ListType(Person)

    class CompanyType(ObjectType):
        schema = Company


# Generated at 2022-06-12 16:04:31.044950
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.exceptions import ParseError
    from typesystem.tokenize.tokens import ScalarToken, DictToken, ListToken
    # Test for empty content
    assert tokenize_json("") == DictToken({}, 0, 0, "")
    assert tokenize_json("    \n    ") == DictToken({}, 0, 0, "")
    assert tokenize_json("   \n  { }  \n\n ") == DictToken({}, 0, 0, "")

    # Test for valid content
    assert tokenize_json("  false ") == ScalarToken(
        False, 0, 5, "  false "
    )  # type:ignore
    assert tokenize_json("  true ") == ScalarToken(True, 0, 4, "  true ")  # type:ignore


# Generated at 2022-06-12 16:04:36.042216
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({}, 0, 13, '{"foo": "bar"}')
    assert tokenize_json('{"foo": "bar"}').items == [('foo', 'bar')]
    assert tokenize_json('{"foo": "bar"}').as_dict() == {'foo': 'bar'}



# Generated at 2022-06-12 16:04:45.268504
# Unit test for function tokenize_json
def test_tokenize_json():
    #Test handling of empty string
    try:
        tokenize_json("")
        raise ValueError("Test failed")
    except ParseError:
        pass
    try:
        tokenize_json("    ")
        raise ValueError("Test failed")
    except ParseError:
        pass
    #Test handling of not-json
    json_str_bad = "test"
    try:
        tokenize_json(json_str_bad)
        raise ValueError("Test failed")
    except ParseError:
        pass
    #Test handling of json-like strings
    json_str = '{"bla":"test"}'
    try:
        tokenize_json(json_str)
    except ParseError:
        raise ValueError("Test failed")


# Generated at 2022-06-12 16:04:57.517465
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
        {
            "hello": "world",
            "numbers": [1, 2, 3],
            "nested": {
                "foo": "bar",
                "list": [1, 2, 3]
            }
        }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

    assert isinstance(token.value["hello"], ScalarToken)
    assert token.value["hello"].value == "world"

    assert isinstance(token.value["numbers"], ListToken)
    assert len(token.value["numbers"].value) == 3

    assert isinstance(token.value["nested"], DictToken)
    assert isinstance(token.value["nested"].value["foo"], ScalarToken)

# Generated at 2022-06-12 16:05:04.527688
# Unit test for function tokenize_json
def test_tokenize_json():
    # If a string is given
    assert isinstance(tokenize_json("\"hello world\""), ScalarToken)
    assert tokenize_json("\"hello world\"").value == "hello world"

    # If an empty string is given
    with pytest.raises(ParseError) as excinfo:
        tokenize_json(" ")
    assert excinfo.value.text == "No content."
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)

    # Raise an error if the json string is not parsable
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"name": "John Smith"')

# Generated at 2022-06-12 16:05:15.541547
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '''
        {
            "test": {
                "test_1": 1,
                "test_2": "test_"
            }
        }
    '''
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert isinstance(token["test"], DictToken)
    assert len(token["test"]) == 2
    assert isinstance(token["test"]["test_1"], ScalarToken)
    assert token["test"]["test_1"] == 1
    assert isinstance(token["test"]["test_2"], ScalarToken)
    assert token["test"]["test_2"] == "test_"


# Generated at 2022-06-12 16:05:26.152355
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "key": "value"
        "bool_key": true,
        "list_key": ["a", 1, true]
    }
    """
    token = tokenize_json(content)
    assert token.start() == 1
    assert token.end() == 55
    assert isinstance(token, DictToken)
    assert token.keys() == {"key", "bool_key", "list_key"}
    assert isinstance(token["key"], ScalarToken)
    assert isinstance(token["bool_key"], ScalarToken)
    assert isinstance(token["list_key"], ListToken)
    assert token["key"].start() == 15
    assert token["key"].end() == 22
    assert token["bool_key"].start() == 29

# Generated at 2022-06-12 16:05:34.917096
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"a": {"b": "c", "d": [1, 2, 3]}}'
    token = tokenize_json(json_str)
    assert token.value == {'a': {'b': 'c', 'd': [1, 2, 3]}}
    assert token.start_index == 0
    assert token.end_index == len(json_str) - 1
    assert token.children[0].name == 'a'
    assert token.children[0].kind == 'dict'
    assert token.children[0].children[0].name == 'b'
    assert token.children[0].children[0].kind == 'scalar'
    assert token.children[0].children[0].value == 'c'
    assert token.children[0].children[1].name == 'd'


# Generated at 2022-06-12 16:05:43.475980
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Validate that the function tokenize_json returns a Token object.
    '''
    content = '{"name":"harry", "age":"12"}'
    token = tokenize_json(content)
    assert type(token) is DictToken
    assert token.value == {"name": "harry", "age":"12"}
    assert token.content == content


# Generated at 2022-06-12 16:05:54.064484
# Unit test for function tokenize_json
def test_tokenize_json():
    tok = tokenize_json('{"item": [1, "two", [3,true,null], null, false]}')
    print(repr(tok))
    dt = tok.as_dict()

# Generated at 2022-06-12 16:06:02.143601
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": ["bar", "baz"]}')


# Generated at 2022-06-12 16:06:07.873812
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[1, 2, 3, "abc", {"a": 1}]'
    # call tokenize_json
    token = tokenize_json(content)
    # compare the result
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3, "abc", {"a": 1}]
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-12 16:06:14.347167
# Unit test for function tokenize_json
def test_tokenize_json():
	assert tokenize_json('1') == ScalarToken(1, index_range=(0, 1))
	assert tokenize_json('"1"') == ScalarToken('1', index_range=(0, 3))
	assert tokenize_json('true') == ScalarToken(True, index_range=(0, 4))
	assert tokenize_json('false') == ScalarToken(False, index_range=(0, 5))
	assert tokenize_json('null') == ScalarToken(None, index_range=(0, 4))
	assert tokenize_json('[]') == ListToken([], index_range=(0, 2))
	assert tokenize_json('[1]') == ListToken([ScalarToken(1, index_range=(1, 2))], index_range=(0, 3))

# Generated at 2022-06-12 16:06:17.983174
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"b": {"c": ["hello", 1, null, true]}}'
    token = tokenize_json(content)
    assert(token.value == {"b": {"c": ["hello", 1, None, True]}})


# Generated at 2022-06-12 16:06:27.655614
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"a": "b", "c":{"d": [1,2]}}'
    json_bytes = json_string.encode("utf-8")
    token = tokenize_json(json_string)
    token_2 = tokenize_json(json_bytes)
    assert token == token_2
    assert isinstance(token, Token)
    assert isinstance(token_2, Token)
    assert token.value == token_2.value



# Generated at 2022-06-12 16:06:35.649190
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:38.005993
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1}'
    token = tokenize_json(content)
    assert isinstance(token, Token)


# Generated at 2022-06-12 16:06:46.878256
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:59.113936
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({
        ScalarToken('key', 0, 3, '{"key": "value"}'): ScalarToken('value', 8, 14, '{"key": "value"}')
    }, 0, 14, '{"key": "value"}')


# Generated at 2022-06-12 16:07:10.455084
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"") == ScalarToken(
        None, char_index=0, column_no=1, line_no=1, content=""
    )
    assert tokenize_json(b"null") == ScalarToken(
        None, char_index=0, column_no=1, line_no=1, content="null"
    )
    assert tokenize_json(b"true") == ScalarToken(
        True, char_index=0, column_no=1, line_no=1, content="true"
    )
    assert tokenize_json(b"false") == ScalarToken(
        False, char_index=0, column_no=1, line_no=1, content="false"
    )

# Generated at 2022-06-12 16:07:16.615994
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == DictToken(
        {
            ScalarToken('hello', 1, 6, '{"hello": "world"}'): ScalarToken(
                'world', 12, 18, '{"hello": "world"}'
            )
        },
        0,
        18,
        '{"hello": "world"}',
    )

# Generated at 2022-06-12 16:07:21.564427
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(
        value=None, start=0, end=3, content="null"
    )

    assert tokenize_json('"hello"') == ScalarToken(
        value="hello", start=0, end=6, content='"hello"'
    )

    assert tokenize_json("true") == ScalarToken(
        value=True, start=0, end=4, content="true"
    )


# Generated at 2022-06-12 16:07:31.493952
# Unit test for function tokenize_json
def test_tokenize_json():
    # Basic test
    json_string = """
    {
        "name": "John",
        "age": 20,
        "married": true,
        "friends": [
            {"name": "Bob"},
            {"name": "Jack"}
        ]
    }
    """
    token = tokenize_json(json_string)
    assert token.position_range.start == 0
    assert token.position_range.end == len(json_string)
    assert token.type == 'dict'
    assert token.as_dict() == {
        'name': 'John',
        'age': 20,
        'married': True,
        'friends': [{'name': 'Bob'}, {'name': 'Jack'}],
    }

# Generated at 2022-06-12 16:07:40.151679
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"name":"John"}')
    assert result.value == {'name': 'John'}
    assert result.line_no == 1
    assert result.column_no == 1
    assert result.length_in_characters == 11

    # The pedantry in these assertions and their order is for a reason.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"

    # Test the case where only whitespace is provided. This is subtly different
    # than

# Generated at 2022-06-12 16:07:48.672703
# Unit test for function tokenize_json
def test_tokenize_json():
    # Asserts whether the singleton tokens corresponding to null, true, false,
    # and the empty list and dict are tokenized correctly.
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    # Asserts whether a number, string, array, and dict with one element are
    # tokenized correctly.

# Generated at 2022-06-12 16:07:53.024380
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case No.1
    assert tokenize_json('{"key": "value"}') == {'key': 'value'}

    # Test case No.2
    assert tokenize_json('{"key": "value", "another": "value"}') == {'key': 'value', 'another': 'value'}


# Generated at 2022-06-12 16:08:00.178142
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 1, 2): ScalarToken(1, 6, 6)}, 0, 9)
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 1, 1), ScalarToken(2, 4, 4)], 0, 5)
    assert tokenize_json('1') == ScalarToken(1, 0, 0)



# Generated at 2022-06-12 16:08:09.649601
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import random
    import string
    import sys
    
    # Unit test to make sure the tokens generated by this module are the same as those generated by
    # the built-in json module

# Generated at 2022-06-12 16:08:25.988143
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        b"""
    {
  "firstName": "John",
  "lastName": "Smith",
  "age": 25,
  "address": {
    "streetAddress": "21 2nd Street",
    "city": "New York",
    "state": "NY",
    "postalCode": "10021"
  },
  "phoneNumbers": [
    {
      "type": "home",
      "number": "212 555-1234"
    },
    {
      "type": "fax",
      "number": "646 555-4567"
    }
  ]
}
    """)
    assert token.end_index == 538
    assert token.start_index == 0

# Generated at 2022-06-12 16:08:36.634643
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ScalarToken(None, 0, 0, "")
    assert tokenize_json(" ") == ScalarToken(None, 0, 0, " ")
    assert tokenize_json("  \t\t ") == ScalarToken(None, 0, 0, "  \t\t ")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("0") == ScalarToken(0, 0, 0, "0")
    assert tokenize_json("10") == ScalarToken(10, 0, 1, "10")

# Generated at 2022-06-12 16:08:46.656530
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 5, 6, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )
    assert tokenize_json('[{"a": 1}]') == ListToken(
        [DictToken({"a": ScalarToken(1, 6, 7, '[{"a": 1}]')}, 1, 10, '[{"a": 1}]')],
        0,
        12,
        '[{"a": 1}]',
    )

# Generated at 2022-06-12 16:08:55.833797
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """{ "a": 1, "b": ["hello", { "c": true }] }"""

# Generated at 2022-06-12 16:09:05.698468
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('[{"a": 1}]')

# Generated at 2022-06-12 16:09:14.921014
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"key":"value"}') == DictToken({'key':'value'}, 0, 18, '{"key":"value"}')

# Generated at 2022-06-12 16:09:20.270340
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Given a simple string of valid json
    When tokenize_json is called
    Then a dict of tokens is returned
    """
    content = (
        '{ "key": "value", "key2": 5, "key3": 6.9e-2, "key4": true, "key5": false, "key6": null, "key7": [1, 2, 3] }'
    )

# Generated at 2022-06-12 16:09:24.003117
# Unit test for function tokenize_json
def test_tokenize_json():
    cases = [
        '{"foo": "bar"}',
        '{"foo": 1}',
        '[1, 2, 3]',
        '[{"foo": "bar"}, {"foo": 2}]',
        '{}',
        '{"foo": {"bar": "baz"}}',
        '{"foo": [4, 5, 6]}',
    ]

    for i, content in enumerate(cases):
        token = tokenize_json(content)
        assert isinstance(token, DictToken) or isinstance(token, ListToken)



# Generated at 2022-06-12 16:09:29.256432
# Unit test for function tokenize_json
def test_tokenize_json():
    input_data = '{"key": "value"}'
    expected_data = DictToken({ScalarToken('key', 0, 4, input_data): ScalarToken('value', 8, 14, input_data)}, 0, 16, input_data)
    assert tokenize_json(input_data) == expected_data



# Generated at 2022-06-12 16:09:40.437859
# Unit test for function tokenize_json
def test_tokenize_json():
    content="{"+'"'+"a"+'"'+":1,\"b\":2," + '"'+"c"+'"'+":3}"
    token = tokenize_json(content)
    assert token == {'a': 1, 'b': 2, 'c': 3}
    assert token.__class__.__name__ == 'DictToken'
    assert len(token.children) == 3
    assert token.children['a'].value == 1
    assert token.children['a'].__class__.__name__ == 'ScalarToken'
    assert token.children['b'].value == 2
    assert token.children['b'].__class__.__name__ == 'ScalarToken'
    assert token.children['c'].value == 3

# Generated at 2022-06-12 16:09:53.167475
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"value": true, "count": [1, 2, 3]}'
    expected = DictToken(
        {ScalarToken("value", 0, 6, '"value"'): ScalarToken(True, 15, 20, 'true')},
        0,
        25,
        '{"value": true, "count": [1, 2, 3]}',
    )
    assert tokenize_json(content) == expected



# Generated at 2022-06-12 16:10:02.362242
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '["foo", true, false, null, 3.14]'
    json_token = tokenize_json(json_str)
    assert isinstance(json_token, ListToken)
    assert json_token.value == [
        ScalarToken("foo", 0, 4, json_str),
        ScalarToken(True, 6, 10, json_str),
        ScalarToken(False, 11, 16, json_str),
        ScalarToken(None, 17, 21, json_str),
        ScalarToken(3.14, 22, 27, json_str),
    ]



# Generated at 2022-06-12 16:10:10.849905
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases borrowed from the JSON PEP
    from typesystem.tests import TestCase

    class TestTokenizeJSON(TestCase):
        def test_empty(self):
            with self.assertRaises(ParseError) as cm:
                tokenize_json("")
            assert cm.exception.code == "no_content"
            assert cm.exception.position == Position(line_no=1, column_no=1, char_index=0)

        def test_pass_empty_bytes(self):
            with self.assertRaises(ParseError) as cm:
                tokenize_json(b"")
            assert cm.exception.code == "no_content"
            assert cm.exception.position == Position(line_no=1, column_no=1, char_index=0)


# Generated at 2022-06-12 16:10:22.631471
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test tokenizing a simple JSON
    assert tokenize_json("""{
        "name": "John",
        "age": 23
    }""") == {
        "name": "John",
        "age": 23,
    }

    # Test tokenizing a simple JSON with a nested list
    assert tokenize_json("""{
        "name": "John",
        "age": 23,
        "friends": ["Bob", "Jim"]
    }""") == {
        "name": "John",
        "age": 23,
        "friends": ["Bob", "Jim"],
    }

    # Test tokenizing a simple JSON with a nested object

# Generated at 2022-06-12 16:10:29.956470
# Unit test for function tokenize_json
def test_tokenize_json():
    with open("test_data/test_typesystem_json.json") as f:
        json_string = f.read()
    tokenized_json = tokenize_json(json_string)
    assert(tokenized_json.raw_value == {"foo": "bar", "baz": [1, 2], "qux": 3.14})

    # Test alternate syntax for json object, missing quotes
    tokenized_json = tokenize_json("{foo: bar, baz: [1, 2], qux: 3.14}")
    assert(tokenized_json.raw_value == {"foo": "bar", "baz": [1, 2], "qux": 3.14})

    # Test another alternate syntax for json object, missing quotes, commas

# Generated at 2022-06-12 16:10:38.511616
# Unit test for function tokenize_json
def test_tokenize_json():
    # JSONDecoder does not handle bytes, so convert to string before testing
    assert tokenize_json(b'{"hello": "world!"}') == tokenize_json('{"hello": "world!"}')
    assert tokenize_json(b'') == tokenize_json('')
    assert tokenize_json(b'{"hello": "world!"}') == tokenize_json('{"hello": "world!"}')
    assert tokenize_json(b'null') == tokenize_json('null')
    assert tokenize_json(b'true') == tokenize_json('true')
    assert tokenize_json(b'false') == tokenize_json('false')
    assert tokenize_json(b'1') == tokenize_json('1')

# Generated at 2022-06-12 16:10:49.397488
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    # Test tokenize_json endpoint
    """
    import pytest

    content1 = '{"a": {"b": "c"}}'
    content2 = '{"a": {"b": "c"], "d": "e"}}'
    content3 = '{"a": {"b": [1, 2, 3]}, "d": "e"}'
    content4 = '{"a": {"b": [1, 2, 3]}, "d": ["e", "f"]}'

    expected1 = [
        {
            "code": "valid",
            "messages": [],
            "position": {
                "char_index": 0,
                "column_no": 1,
                "line_no": 1,
            },
            "value": {"a": {"b": "c"}},
        }
    ]

# Generated at 2022-06-12 16:11:00.220791
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json(
        """{"a": [1, 2, 3], "b": [{"c": [["x"], "y"]}, {"c": [true, false, true]}]}"""
    )
    assert isinstance(result, DictToken)
    assert len(result) == 2
    assert result.position == (1, 84)
    assert result.content == """{"a": [1, 2, 3], "b": [{"c": [["x"], "y"]}, {"c": [true, false, true]}]}"""
    assert result["a"] == ListToken(
        [ScalarToken(1, 7, 7, result.content), ScalarToken(2, 10, 10, result.content), ScalarToken(3, 13, 13, result.content)], 5, 14, result.content
    )
   

# Generated at 2022-06-12 16:11:10.777439
# Unit test for function tokenize_json
def test_tokenize_json():
    # pylint: disable=protected-access
    # Check decoding of empty string
    token = tokenize_json("")
    assert token is None

    # Check decoding of a dictionary with a single item
    token = tokenize_json('{"hello": "world"}')
    assert isinstance(token, DictToken)
    assert token.value == {"hello": "world"}
    assert token.position.char_index == 0
    assert token.position.line_no == 0
    assert token.position.column_no == 0

    # Check decoding of a dictionary with multiple items
    token = tokenize_json('{"hello": "world", "foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"hello": "world", "foo": "bar"}

    # Check decoding of a list
    token