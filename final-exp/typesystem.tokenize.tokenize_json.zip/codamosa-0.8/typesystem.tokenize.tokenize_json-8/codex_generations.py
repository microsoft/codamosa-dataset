

# Generated at 2022-06-12 16:01:47.519534
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json = """
{
    "a": [
        1,
        2,
        3,
        4,
    ]
}
"""
    t = tokenize_json(input_json)

    assert isinstance(t, DictToken)
    assert t.value == {"a": [1, 2, 3, 4]}
    assert t.type == "dict"
    assert t.start.column_no == 2
    assert t.end.column_no == 2
    assert t.start.line_no == 2
    assert t.end.line_no == 10
    assert t.start.char_index == 5
    assert t.end.char_index == 37

    lst = [child for child in t.walk() if isinstance(child, ListToken)][0]

# Generated at 2022-06-12 16:01:52.197019
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"a": 1}')
    assert isinstance(result, DictToken)
    assert isinstance(result.value['a'], ScalarToken)
    assert result.value['a'].value == 1
    assert result.value['a'].start == 3
    assert result.value['a'].end == 4

# These three tests check parsing of whitespace before, after, or between tokens

# Generated at 2022-06-12 16:02:02.061820
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test the simple JSON, it should return the token dict containing all the keys and values
    # of the dict
    token_dict = tokenize_json('{"one": 1, "two": 2.0, "three": "3"}')
    assert type(token_dict) is DictToken
    assert token_dict.value == {'one': 1, 'three': '3', 'two': 2.0}

    # Test the JSON with nested dict, it should return the token dict containing all the keys and values
    # of the dict, but the values with nested dict should be a Token of type Dict
    token_dict = tokenize_json('{"one": 1, "nested_dict": {"two": 2, "three": 3}, "four": 4}')
    assert type(token_dict) is DictToken

# Generated at 2022-06-12 16:02:07.754654
# Unit test for function tokenize_json
def test_tokenize_json():
    example_dict = {"a": [1, 2, 3], "b": [{"c": [1, 2, 3]}]}
    assert tokenize_json(json.dumps(example_dict)) == DictToken(example_dict, 0, 31, '{"a": [1, 2, 3], "b": [{"c": [1, 2, 3]}]}')


# Generated at 2022-06-12 16:02:17.937842
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[1, 2]") == ListToken([ScalarToken(1), ScalarToken(2)], 0, 5, "[1, 2]")
    assert tokenize_json("[1, 2") == ListToken([ScalarToken(1), ScalarToken(2)], 0, 5, "[1, 2")
    assert tokenize_json("[1, ]") == ListToken([ScalarToken(1), ScalarToken(None)], 0, 5, "[1, ]")
    assert tokenize_json("[1, null]") == ListToken([ScalarToken(1), ScalarToken(None)], 0, 9, "[1, null]")

# Generated at 2022-06-12 16:02:25.814930
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
    "a": "1",
    "b": [
      {
        "b1": 2,
        "b2": 3
      }
    ]
    }"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.as_dict == {
        "a": ScalarToken("1", 10, 11, content),
        "b": ListToken(
            [
                DictToken(
                    {
                        "b1": ScalarToken("2", 42, 43, content),
                        "b2": ScalarToken("3", 50, 51, content),
                    },
                    27,
                    51,
                    content,
                )
            ],
            17,
            53,
            content,
        ),
    }
    assert len(content)

# Generated at 2022-06-12 16:02:36.555964
# Unit test for function tokenize_json
def test_tokenize_json():
    content=b'{"test1": {"test2": [{"test3": {"test4": "hello world"}}, {"test5": "test6"}]}}'
    token = tokenize_json(content)
    print(token)
    assert(type(token.value) is dict)
    assert(len(token.value) == 1)

    k1 = list(token.value.keys())[0]
    assert(str(k1.value) == "test1")
    assert(type(k1.value) is str)
    assert(k1.start == 0)
    assert(k1.end == 5)
    assert(str(k1) == '{"test1": {"test2": [{"test3": {"test4": "hello world"}}, {"test5": "test6"}]}}')

    v1 = list

# Generated at 2022-06-12 16:02:43.774815
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test some of the cases in JSONDecoder.
    decoder = _TokenizingDecoder()

    # Test string parsing.
    assert decoder.scan_once('"abc"', 0) == (ScalarToken('abc', 0, 4, 'abc'), 5)
    assert decoder.scan_once('"abc"def', 0) == (ScalarToken('abc', 0, 4, 'abc'), 5)
    assert decoder.scan_once('"abc\\"def"', 0) == (ScalarToken('abc"def', 0, 10, 'abc\\"def'), 11)
    assert decoder.scan_once('"abc\\"def\n', 0) == (ScalarToken('abc"def', 0, 10, 'abc\\"def\\n'), 11)

# Generated at 2022-06-12 16:02:52.796411
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content=None)
    assert tokenize_json("{\"a\": 3}") == DictToken(value={"a": ScalarToken(3, 0, 0, None)}, start=0, end=1, content=None)
    assert tokenize_json("{\"a\": {\"b\": 3}}") == DictToken(value={"a": DictToken(value={"b": ScalarToken(3,0, 0, None)}, start=0, end=0, content=None)}, start=0, end=1, content=None)


# Generated at 2022-06-12 16:02:56.959526
# Unit test for function tokenize_json
def test_tokenize_json():
    assert _TokenizingJSONObject('{"}', True, None, {}, 'test') is not None
    scanner = _make_scanner('test', {'0': '0'}, True, None, None, {})
    assert scanner('{"}', 0) is not None
    assert tokenize_json('{"}') is not None


# Generated at 2022-06-12 16:03:19.052004
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:03:29.812633
# Unit test for function tokenize_json
def test_tokenize_json():
    # check if the function tokenize_json is able to tokenize a json dict
    _json = '{"a": 2, "b": [1, 2, 3], "c": {"d": 4, "e": [4, 5, 6]}, "f": "string"}'
    token = tokenize_json(_json)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)

    assert isinstance(token.value["a"], ScalarToken)
    assert isinstance(token.value["b"], ListToken)
    assert isinstance(token.value["c"], DictToken)
    assert isinstance(token.value["f"], ScalarToken)
    assert token.value["a"].value == 2
    assert token.value["c"].value["d"].value == 4

# Generated at 2022-06-12 16:03:37.632225
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": [1, 2]}') == DictToken({'hello': ListToken([1, 2])}, 0, 15)
    assert tokenize_json('{"hello": [1, 2]') == DictToken({'hello': ListToken([1, 2])}, 0, 14)
    assert tokenize_json('{"hello": [1, 2}}') == DictToken({'hello': ListToken([1, 2])}, 0, 15)
    assert tokenize_json('{"hello": [1, 2]') == tokenize_json('{"hello": [1, 2]}')


# Generated at 2022-06-12 16:03:42.390069
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "John"}')
    assert isinstance(token, DictToken)
    assert token.keys() == ["name"]
    assert isinstance(token.get("name"), ScalarToken)
    assert token.get("name").value == "John"
    assert token.get("name").position.line_no == 1
    assert token.get("name").position.column_no == 10
    assert token.get("name").position.char_index == 10


# Generated at 2022-06-12 16:03:52.336520
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = """{"key1": ["value1", "value2"], "key2": "value3"}"""
    Token.content = test_json
    token = tokenize_json(test_json)
    assert token.type == "dict"
    assert token.start == 0
    assert token.end == len(test_json) - 1
    keys = token.keys()
    assert len(keys) == 2
    assert keys[0].type == 'scalar'
    assert keys[0].content == '"key1"'
    assert keys[1].type == 'scalar'
    assert keys[1].content == '"key2"'
    assert token[keys[0]].type == 'list'
    assert token[keys[1]].type == 'scalar'



# Generated at 2022-06-12 16:03:56.457030
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"type": "array", "items": {"type": "string"}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token["type"], ScalarToken)
    assert token["type"].to_python() == "array"



# Generated at 2022-06-12 16:04:04.427911
# Unit test for function tokenize_json
def test_tokenize_json():
    def assertToken(token, value):
        assert token.value == value
        assert token.start_pos == Position(
            1, 1, 0, 1, 1, 0
        )  # Column and line number are 1-based
        assert token.end_pos == Position(
            len(value) + 1, 1, len(value), len(value) + 1, 1, len(value)
        )

    def assertTokenWithPos(token, value, start_pos, end_pos):
        assert token.value == value
        assert token.start_pos == start_pos
        assert token.end_pos == end_pos


# Generated at 2022-06-12 16:04:13.042885
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that tokenize_json correctly tokenizes JSON strings.
    """
    assert tokenize_json('{"hello": "world"}') == DictToken(
        {"hello": ScalarToken("world", 8, 16, '{"hello": "world"}')},
        0,
        16,
        '{"hello": "world"}',
    )

# Generated at 2022-06-12 16:04:21.421811
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid json
    json = '{"key1": "value1", "key2": "value2"}'
    expected = DictToken(
        {"key2": ScalarToken("value2", 23, 32, json), "key1": ScalarToken("value1", 8, 17, json)},
        0,
        32,
        json
    )
    assert tokenize_json(json) == expected

    # Test parse error
    with pytest.raises(ParseError):
        tokenize_json('{"key": "value", "key2": "value2"')

# Generated at 2022-06-12 16:04:25.530779
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"string": "foo", "boolean": true, "float": 3.14, "int": 42, "none": null, "array": [{"foo": "bar"}, {"foo": "baz"}]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["string"] == "foo"


# Generated at 2022-06-12 16:04:36.221247
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""
        {
            "name": "Benny",
            "age": 44,
            "phone": [
                {
                    "name": "Home",
                    "number": "22-3333-3333"
                },
                {
                    "name": "Work",
                    "number": "22-3333-3333"
                }
            ]
        }
    """)
    assert token["phone"][1]["name"] == "Work"



# Generated at 2022-06-12 16:04:40.245335
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {
        "key_1": "value_1",
        "key_2": {"sub_key": ["sub_value_1", "sub_value_2"]},
    }
    content = json.dumps(content)
    token = tokenize_json(content)
    assert token.as_python() == json.loads(content)
    assert token.as_json() == content



# Generated at 2022-06-12 16:04:43.828947
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{ "a": 1, "b": 2, "c": {"d": 3, "e": [4, 5, { "f": 6 }] } }"""
    token = tokenize_json(content)
    assert token.value == {
        "a": 1,
        "b": 2,
        "c": {"d": 3, "e": [4, 5, {"f": 6}]},
    }


# Unit tests for function validate_json

# Generated at 2022-06-12 16:04:50.836499
# Unit test for function tokenize_json
def test_tokenize_json():

    content = """
    {
        "result": {
            "people": [
                {
                    "id": "1",
                    "name": "Person 1"
                },
                {
                    "id": "2",
                    "name": "Person 2"
                }
            ]
        }
    }
    """


# Generated at 2022-06-12 16:05:02.058426
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
      "foo": [
        1,
        2,
        true,
        "bar"
      ]
    }
    '''
    token = tokenize_json(content)
    assert token.content == content
    assert isinstance(token, DictToken)
    assert len(token.value) == 1
    assert token.value["foo"].content == "[\n        1,\n        2,\n        true,\n        \"bar\"\n      ]"
    assert token.value["foo"].position.line_no == 3
    assert token.value["foo"].position.column_no == 9
    assert isinstance(token.value["foo"], ListToken)
    assert len(token.value["foo"].value) == 4

# Generated at 2022-06-12 16:05:13.095095
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = """
    {
      "string": "this is a string",
      "integer": 42,
      "float": 3.14159,
      "true": true,
      "false": false,
      "null": null,
      "list": [
        "a",
        "b",
        "c"
      ],
      "dict": {"a": 1, "b": 2, "c": 3}
    }
    """

    invalid_json = """
    {
      "a": 1,
      "b": 2,
      "c": 3,
    }
    """

    valid_token = tokenize_json(valid_json)
    invalid_token = tokenize_json(invalid_json)


# Generated at 2022-06-12 16:05:24.010315
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b", "c": "d", "e": "f"}'
    token = tokenize_json(content)
    assert token.start == 0
    assert token.end == 27
    assert token.position.line_no == 1
    assert token.type == "dict"
    assert token.children == [
        DictToken(
            {
                ScalarToken("a", 1, 3): ScalarToken("b", 6, 8),
                ScalarToken("c", 10, 12): ScalarToken("d", 15, 17),
                ScalarToken("e", 19, 21): ScalarToken("f", 24, 26),
            },
            0,
            27,
            content,
        )
    ]
    assert len(token.children[0].children) == 3

# Generated at 2022-06-12 16:05:29.308671
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    data_string='{"a": 1, "b": "2", "c": [1,2,3]}'

    token=tokenize_json(data_string)
    #print(vars(token))
    assert json.dumps(token.value, indent=4) == json.dumps(json.loads(data_string), indent=4)
    print("Tokenize json success")
    return True


# Generated at 2022-06-12 16:05:36.572507
# Unit test for function tokenize_json
def test_tokenize_json():
	from pprint import pprint
	from .tokens import Token, ScalarToken, DictToken, ListToken
	from .positional_validation import validate_with_positions
	from ..fields import String, Number, Boolean, Dict, List, Date, DateTime, Time, Any
	from ..schemas import Schema

	class User(Schema):
	    name = String()
	    age = Number()
	    cool = Boolean()
	    cool_data = Dict({
	        "friends": List(String()),
	        "hobbies": List(String()),
	        "birthday": Date()
	    })

	class Photo(Schema):
	    width = Number()
	    height = Number()
	    date = DateTime()
	    user = User()


# Generated at 2022-06-12 16:05:42.367329
# Unit test for function tokenize_json
def test_tokenize_json():
    # It should handle empty content
    assert tokenize_json("") == None
    assert tokenize_json("   ") == None
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("  {  } {}") == DictToken({}, 3, 4, "{  } {}")
    # it should raise exception for invalid json
    with pytest.raises(ParseError):
        tokenize_json("{")



# Generated at 2022-06-12 16:05:59.501196
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken(
        {}, start=None, end=None, raw_string='{}'
    )
    assert tokenize_json('[]') == ListToken(
        [], start=None, end=None, raw_string='[]'
    )
    assert tokenize_json('{"a": 2}') == DictToken(
        {ScalarToken('a', start=None, end=None, raw_string=None): ScalarToken(
            2, start=None, end=None, raw_string='2')},
        start=None,
        end=None,
        raw_string='{"a": 2}')

# Generated at 2022-06-12 16:06:09.377525
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
        {
            "foo": "bar",
            "baz": [1, 2, 3, 4],
            "qux": {
                "quux": "quuux",
                "quuz": 123,
                "corge": true,
                "grault": false
            },
            "waldo": null
        }
    """
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert isinstance(token.value["baz"], ListToken)
    assert isinstance(token.value["baz"].value, list)
    assert isinstance(token.value["qux"], DictToken)
    assert isinstance(token.value["qux"].value, dict)

# Generated at 2022-06-12 16:06:14.232815
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 1, 2, "{}")
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 1, 9, '{"a": "b"}')

    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.match("No content.")

    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"a: "b"}')
    assert excinfo.match("Expecting ':' delimiter")



# Generated at 2022-06-12 16:06:19.051150
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:26.206447
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
        {
            "name": "Joe",
            "age": 28,
            "languages_known": ["English", "German"],
        }
    """
    token = tokenize_json(content)
    assert token.value == {
        "name": "Joe",
        "age": 28,
        "languages_known": ["English", "German"],
    }
    assert token.start_position == Position(column_no=2, line_no=2, char_index=1)
    assert token.end_position == Position(column_no=3, line_no=7, char_index=37)

    field = Field(name="name")
    value, errors = validate_json(content, validator=field)

# Generated at 2022-06-12 16:06:34.920548
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem import Schema
    from typesystem.fields import Field, String

    class PostSchema(Schema):
        title = String()

    token = tokenize_json(
        '{"title": "Use my library."}'
    )  # type: ignore
    assert token.value == {"title": "Use my library."}
    assert token.start_position == 0
    assert token.end_position == 32
    assert token.content == '{"title": "Use my library."}'

    token = tokenize_json(
        "[1,2, 3]"
    )  # type: ignore
    assert token.value == [1, 2, 3]
    assert token.start_position == 0
    assert token.end_position == 7
    assert token.content == "[1,2, 3]"

    token = tokenize_

# Generated at 2022-06-12 16:06:44.926756
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.error_messages import ErrorMessage

    schema = Schema(
        {
            "name": Field(type="string", max_length=100),
            "age": Field(type="number"),
            "active": Field(type="boolean"),
            "address": {"street_name": Field(type="string"), "city": Field(type="string"),},
            "places": {"name": Field(type="string"),},
            "tape": Field(type="string", max_length=100),
            "attachment": {"name": Field(type="string"),},
        }
    )


# Generated at 2022-06-12 16:06:48.323169
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    >>> tokenize_json('{"foo":"bar"}') # doctest: +NORMALIZE_WHITESPACE
    DictToken({'foo': ScalarToken('bar', 0, 8, '{"foo":"bar"}')}, 0, 13,
              '{"foo":"bar"}')
    """

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 16:06:57.528323
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('''{
        "string": "foo",
        "number": 1.23,
        "bool": false,
        "null": null,
        "list": [1, 2],
        "dict": {"k": "v"}
    }''')
    assert isinstance(token, DictToken)
    assert token.char_index == 0
    assert token.char_end_index == 110

    first = token[0]
    assert isinstance(first, ScalarToken)
    assert first.char_index == 2
    assert first.char_end_index == 16

    second = token[1]
    assert isinstance(second, ScalarToken)
    assert second.char_index == 18
    assert second.char_end_index == 22

    third = token[2]
    assert isinstance

# Generated at 2022-06-12 16:07:05.637669
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": [1, 2, 3], "bar": "baz"}')
    assert isinstance(token, DictToken)
    assert isinstance(token["bar"], ScalarToken)
    assert token["bar"] == "baz"
    assert isinstance(token["foo"], ListToken)
    assert token["foo"] == [1, 2, 3]



# Generated at 2022-06-12 16:07:21.723150
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
"name": "a",
"age": 40,
"verified": false,
"null": null,
"not-a-number": "NaN",
"exponent": 1.234567e+10,
"nested": {
    "a": 1,
    "b": 2
},
"list": [1, 2, 3, 4],
"escaped": "\\n\\r\\t"
}
"""

    # Test that we can tokenize a JSON string
    token = tokenize_json(content)
    assert isinstance(token, DictToken)



# Generated at 2022-06-12 16:07:30.150128
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1,"b":"2.2"}'
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert not isinstance(token, ListToken)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert token.value["a"] == ScalarToken(1, 3, 3, content)
    assert token.value["b"] == ScalarToken("2.2", 10, 12, content)
    assert token.value["a"].value == 1
    assert token.value["b"].value == "2.2"


# Generated at 2022-06-12 16:07:38.883519
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:07:47.527476
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import ScalarToken, ListToken, DictToken, Token

    def _validate(data, expected):
        token = tokenize_json(data)
        assert token == expected, token

    # Scalar tokens
    _validate(b'"', ScalarToken("", 0, 0, '""'))
    _validate(b'"asdf"', ScalarToken("asdf", 0, 5, '"asdf"'))
    _validate(b'"\\t"', ScalarToken("\t", 0, 4, '"\\t"'))
    _validate(b'"asdf"\n', ScalarToken("asdf", 0, 5, '"asdf"'))

# Generated at 2022-06-12 16:07:50.620989
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello":"world"}')
    assert isinstance(token, DictToken)
    assert token.value == {"hello": "world"}


# Generated at 2022-06-12 16:07:51.476468
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("")



# Generated at 2022-06-12 16:08:02.607807
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_token = tokenize_json(
        """
        {
            "name": "Bar",
            "age": 42,
            "is_alive": true,
            "children": ["Foo", null, "Baz"]
        }
    """
    )
    assert dict_token.get_raw_value() == {
        "name": "Bar",
        "age": 42,
        "is_alive": True,
        "children": ["Foo", None, "Baz"],
    }

# Generated at 2022-06-12 16:08:05.758822
# Unit test for function tokenize_json
def test_tokenize_json():
    content =  '{"name":"Abe Simpson","age":70}'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    assert token == {
        'name': 'Abe Simpson',
        'age': 70
    }

# Generated at 2022-06-12 16:08:13.847676
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":[1,2],"b":[3,4]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["a"], ListToken)
    assert isinstance(token.value["b"], ListToken)
    assert token.value["a"].value[0].value == 1
    assert token.value["a"].value[1].value == 2
    assert token.value["b"].value[0].value == 3
    assert token.value["b"].value[1].value == 4
    assert token.value["a"].value[0].start_position.char_index == 4
    assert token.value["a"].value[0].start_position.line_no == 1

# Generated at 2022-06-12 16:08:25.988978
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, None)
    assert tokenize_json("[]") == ListToken([], 0, 1, None)
    assert tokenize_json('["test"]') == ListToken(
        [ScalarToken("test", 1, 6, None)], 0, 7, None
    )
    assert tokenize_json('{"test": "test"}') == DictToken(
        {ScalarToken("test", 1, 6, None): ScalarToken("test", 9, 14, None)},
        0,
        15,
        None,
    )
    assert tokenize_json("100") == ScalarToken(100, 0, 3, None)
    assert tokenize_json("100.5") == ScalarToken(100.5, 0, 5, None)


# Generated at 2022-06-12 16:08:39.265086
# Unit test for function tokenize_json
def test_tokenize_json():
    obj = tokenize_json('{"first_name": "John", "last_name": "Doe"}')
    assert len(obj.data) == 2
    assert list(obj.data.keys()) == ['first_name', 'last_name']
    assert obj.data["first_name"].data == 'John'
    assert obj.data["last_name"].data == 'Doe'
    assert obj.data["last_name"].start_position == (1, 33)
    assert obj.data["last_name"].end_position == (1, 39)


# Generated at 2022-06-12 16:08:43.046688
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {"foo": "bar"}
    json_string = '{"foo": "bar"}'
    assert tokenize_json(json_string) == content
    
    

# Generated at 2022-06-12 16:08:46.214228
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 1.0}'
    tokenized = tokenize_json(content)
    json.dumps(tokenized.as_dict())

# Generated at 2022-06-12 16:08:49.870240
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.test_utils import assert_valid_schema_tokenization

    content = '{"foo": {"bar": 1, "baz": ["zippy", {"a": "b"}]}}'
    assert_valid_schema_tokenization(content)

# Generated at 2022-06-12 16:08:52.435522
# Unit test for function tokenize_json
def test_tokenize_json():
    content = r' {"name": "John"} '
    output = tokenize_json(content)
    assert output.dict_token()['name'] == "John"


# Generated at 2022-06-12 16:09:00.874625
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == None

    assert tokenize_json('') == None
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('{"foo" : "bar"}') == DictToken(
        {
            ScalarToken('foo', 1, 5, '{"foo" : "bar"}'): ScalarToken(
                'bar', 11, 15, '{"foo" : "bar"}'
            )
        },
        0,
        16,
        '{"foo" : "bar"}',
    )

# Generated at 2022-06-12 16:09:11.260933
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem import fields, schemas, validators

    class Person(schemas.Schema):
        first_name = fields.String(required=True)
        last_name = fields.String(required=True)
        age = fields.Integer(required=True)
        height = fields.Number(required=True)

    json_str = """{
        "first_name": "John",
        "last_name": "Smith",
        "age": 85,
        "height": 1.82
    }"""

    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)

    assert isinstance(token["first_name"], ScalarToken)
    assert token["first_name"].value == "John"

    assert isinstance(token["last_name"], ScalarToken)
    assert token

# Generated at 2022-06-12 16:09:21.132482
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":"b","c":[true, null]}'
    token = tokenize_json(content)
    assert token.data == {"a": "b", "c": [True, None]}
    assert token.start == 0
    assert token.end == len(content) - 1

    content = '"a"'
    token = tokenize_json(content)
    assert token.data == "a"
    assert token.start == 0
    assert token.end == len(content) - 1

    content = 'true'
    token = tokenize_json(content)
    assert token.data is True
    assert token.start == 0
    assert token.end == len(content) - 1

    content = '1'
    token = tokenize_json(content)
    assert token.data == 1

# Generated at 2022-06-12 16:09:31.238355
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 2}') == DictToken({"a": 2}, 0, 7, '{"a": 2}')
    assert tokenize_json('[2]') == ListToken([2], 0, 2, '[2]')
    # assert tokenize_json('[2]') == ListToken([ScalarToken(2, 1, 1, '[2]')], 0, 2, '[2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('-2') == ScalarToken(-2, 0, 1, '-2')

# Generated at 2022-06-12 16:09:40.083156
# Unit test for function tokenize_json
def test_tokenize_json():
    tests = (
        ('{"a":1,"b":2,"c":3}', {'a': 1, 'b': 2, 'c': 3}),
        ('{"a":1, "b": {"c": "c"}}', {'a': 1, 'b': {'c': 'c'}}),
        ('{"a":1, "b": [1, 2, 3]}', {'a': 1, 'b': [1, 2, 3]}),
    )
    for test_data, expected in tests:
        result = tokenize_json(test_data)
        assert result==expected

# Generated at 2022-06-12 16:09:55.565097
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"key1":"value1","key2":"value2"}'
    result = tokenize_json(content)
    assert result == {'key1': 'value1', 'key2': 'value2'}

    content = b'42'
    result = tokenize_json(content)
    assert result == 42

    content = b'false'
    result = tokenize_json(content)
    assert result is False

    content = b'true'
    result = tokenize_json(content)
    assert result is True

    content = b'null'
    result = tokenize_json(content)
    assert result is None

    content = b"""
        {
            "key1": "value1",
            "key2": "value2"
        }
    """
    # This should also work with indentation,

# Generated at 2022-06-12 16:09:58.003179
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tests.test_tokenize_json import tokenize_json
    assert tokenize_json


# Generated at 2022-06-12 16:10:00.012639
# Unit test for function tokenize_json
def test_tokenize_json():
    print(tokenize_json('{"name":"hong","age":18}'))



# Generated at 2022-06-12 16:10:09.362625
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    from json import loads
    
    def check(source):
        """
        Ensure that the source parses to the same JSON as the Python JSON parser.
        """
        tokenized = tokenize_json(source)
        assert tokenized.value == loads(source)

    # Test some basic valid JSON.
    check('"string"')
    check('42')
    check('3.14159')
    check('true')
    check('false')
    check('null')
    check('{}')
    check('[]')

    # Test some basic invalid JSON.
    with pytest.raises(ParseError):
        check('{')
    with pytest.raises(ParseError):
        check('}')
    with pytest.raises(ParseError):
        check('[')

# Generated at 2022-06-12 16:10:21.428132
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "1"
    token = tokenize_json(content)
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, int)

    content = '"test"'
    token = tokenize_json(content)
    assert isinstance(token, ScalarToken)
    assert isinstance(token.value, str)

    content = "{}"
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)

    content = '{"a":"b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)

    content = '{"a":["b","c"]}'
    token = tokenize_json(content)

# Generated at 2022-06-12 16:10:29.339542
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test all data types
    test_json_string = '''
    {
        "a": "a",
        "b": 1,
        "c": 1.0,
        "d": true,
        "e": false,
        "f": null,
        "g": {"a": "a"},
        "h": [{"a": "a"}],
        "i": {
            "a": "a",
            "b": 1,
            "c": 1.0,
            "d": true,
            "e": false,
            "f": null,
            "g": {"a": "a"},
            "h": [{"a": "a"}],
        }
    }
    '''
    tokens = tokenize_json(test_json_string)
    assert token_string(tokens)

# Generated at 2022-06-12 16:10:38.111103
# Unit test for function tokenize_json
def test_tokenize_json():
  # type: () -> None
    content = """
{
  "string": "Hello, world!",
  "boolean": true,
  "key": {
    "nested": [
      "foo",
      "bar"
    ]
  },
  "number": 123
}
"""
    token = tokenize_json(content)

    value = {
        "string": "Hello, world!",
        "boolean": True,
        "key": {"nested": ["foo", "bar"]},
        "number": 123,
    }
    assert value == token.value
    assert isinstance(token, DictToken)
    assert isinstance(token["boolean"], ScalarToken)
    assert token["boolean"].start_index == content.index("true")
    assert token["boolean"].end_index == content

# Generated at 2022-06-12 16:10:49.177423
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == {'a': 'b'}
    with pytest.raises(ParseError) as exc:
        tokenize_json('{"a": "b":}')
    assert exc.value.messages == [
        Message(
            text="Expecting ',' delimiter.",
            code="parse_error",
            position=Position(column_no=8, line_no=1, char_index=7),
        )
    ]
    with pytest.raises(ParseError) as exc:
        tokenize_json('{"a": "b"}"')

# Generated at 2022-06-12 16:10:54.969437
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{ \"foo\": [2, 3, 4] }"

    token = {
        "foo": [
            ScalarToken(2, 12, 13, content),
            ScalarToken(3, 15, 16, content),
            ScalarToken(4, 18, 19, content),
        ]
    }

    assert tokenize_json(content) == token

# Generated at 2022-06-12 16:11:04.592447
# Unit test for function tokenize_json
def test_tokenize_json():
    # Unit test: no content
    try:
        tokenize_json("")
        assert False
    except ParseError as exc:
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert exc.code == "no_content"
        assert exc.text == "No content."

    # Unit test: parse error, old-style JSON encode format
    try:
        tokenize_json('{"foo": "bar}}')
        assert False
    except ParseError as exc:
        assert exc.position == Position(column_no=9, line_no=1, char_index=8)
        assert exc.code == "parse_error"
        assert exc.text == "Extra data: line 1 column 9 (char 8)."

    # Unit test: parse error, new-style JSON