

# Generated at 2022-06-12 16:01:27.588487
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "a"}'
    class Person(Schema):
        name = fields.String(max_length=1)

    errors = validate_json(content, Person)
    assert errors[0].text == "Must be 1 characters or fewer."



# Generated at 2022-06-12 16:01:31.285073
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(properties={"name": String()})
    json_string = """{ "name": "John Doe" }"""
    assert validate_json(json_string, schema) == ({"name": "John Doe"}, [])

# Generated at 2022-06-12 16:01:37.593966
# Unit test for function validate_json
def test_validate_json():
    json_string = '[["a",1],["b",2]]'
    validator = Schema(
        {
            "type": "dict",
            "required": True,
            "strict": True,
            "children": {
                "a": {"type": "string"},
                "b": {"type": "integer"},
            },
        }
    )
    (value, error_messages) = validate_json(json_string, validator)
    assert error_messages == []
    assert value == {"a": "a", "b": 2}



# Generated at 2022-06-12 16:01:42.524610
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "list": [1, 2, 3],
        "dict": {"foo": "bar"}
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["dict"], DictToken)
    assert isinstance(token.value["list"], ListToken)

# Generated at 2022-06-12 16:01:48.226200
# Unit test for function validate_json
def test_validate_json():
    # valid JSON
    assert validate_json(
        '{"hello": "world"}',
        {"hello": "string"}
    ) == ({"hello": "world"}, [],)

    # invalid JSON
    assert isinstance(validate_json(
        '{"hello": "world"',
        {"hello": "string"}
    ), ParseError)

    # invalid JSON against a field
    assert isinstance(validate_json(
        '{"hello": "world"}',
        {"hello": "string", "goodbye": "string"}
    ), ValidationError)

# Generated at 2022-06-12 16:01:56.353911
# Unit test for function validate_json
def test_validate_json():
    # valid data
    assert validate_json('{"name": "John"}', {
        "name": Field(required=True)
    }) == ({'name': 'John'}, None)

    # valid data
    assert validate_json('{"name": ["John", "Doe"]}', {
        "name": Field(required=True, list=True, item=Field(type="string"))
    }) == ({'name': ['John', 'Doe']}, None)

    # valid data
    assert validate_json('{"name": 3}', {
        "name": Field(required=True, type="integer")
    }) == ({'name': 3}, None)

    # empty value

# Generated at 2022-06-12 16:02:03.771598
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": 1.0, "b": 2.0, "c": 3.0}'
    validator = {
        "a": float,
        "b": float,
        "c": float,
    }
    result = validate_json(content, validator)
    
    expected_error_messages = []
    expected_value = {"a": 1.0, "b": 2.0, "c": 3.0}

    assert result == (expected_value, expected_error_messages)

# Generated at 2022-06-12 16:02:09.146980
# Unit test for function validate_json
def test_validate_json():
    """
    >>> validate_json(b'{ "foo": "bar" }', {"type": "string"})
    (None, [{'text': 'Must be a string.', 'code': 'invalid_type', 'position': {'column_no': 6, 'line_no': 1, 'char_index': 6}}])
    """
    pass

# Generated at 2022-06-12 16:02:15.224905
# Unit test for function validate_json
def test_validate_json():
    schema = [
        {"name": "foo", "type": "string", "required": True},
        {"name": "bar", "type": "array", "items": {"type": "string"}},
    ]
    content = r'{"foo": "Hello, World!", "bar": ["a", "b", "c"]}'

    error_messages = validate_json(content=content, validator=schema)[1]
    assert not error_messages

# Generated at 2022-06-12 16:02:23.849330
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    {
        "a": 10,
        "b": "foo",
        "c": true,
        "d": null,
        "e": [1, 2, 3],
        "f": {
            "g": {
                "h": "bar"
            },
            "i": false
        },
        "j": [
            {
                "k": [
                    {
                        "l": "baz"
                    }
                ]
            }
        ]
    }
    """


# Generated at 2022-06-12 16:02:41.816422
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that the tokenize_json function raises an appropriate error for empty input
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert str(excinfo.value) == "No content."

    # Test that malformed input raises an error
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{")
    assert str(excinfo.value).startswith("Expecting property name enclosed")
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"a":')
    assert str(excinfo.value).startswith("Expecting value")

    # Test that incorrect string input raises an error

# Generated at 2022-06-12 16:02:44.340948
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')


# Generated at 2022-06-12 16:02:54.632456
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"text": "hello world", "number": 123, "array": [1, 2, 3], "object": {"nested": "object"}}'
    token = tokenize_json(content)
    assert token.is_dict()
    assert token.value.keys() == {0: 'text', 1: 'number', 2: 'array', 3: 'object'}
    for key in token.value.keys():
        assert token.value[key].is_scalar()
    assert token.value[0].value == "hello world"
    assert token.value[1].value == 123
    assert token.value[2].is_list()
    assert token.value[3].is_dict()
    assert token.value[3].value.keys() == {4: 'nested'}


# Generated at 2022-06-12 16:02:56.212182
# Unit test for function tokenize_json
def test_tokenize_json():
    # good data
    assert tokenize_json('{"answer": 42}')
    # bad data
    with pytest.raises(ParseError):
        tokenize_json(b"\x80")


# Generated at 2022-06-12 16:03:03.764307
# Unit test for function tokenize_json
def test_tokenize_json():
    json_sample = '{"a":1, "b":2.3, "c":"a string", "d":true, "f":false, "g":null, "h":[1,2,[3,4]]}'
    expected_token = {"a": ScalarToken(1, 1, 5), "b": ScalarToken(2.3, 8, 14), "c": ScalarToken("a string",17,29), "d": ScalarToken(True,32,36), "f": ScalarToken(False,39,44), "g": ScalarToken(None, 47, 51), "h": ListToken([ScalarToken(1,54,56), ScalarToken(2,58,60), ListToken([ScalarToken(3,62,64), ScalarToken(4,66,68)])],55,69)}
    actual

# Generated at 2022-06-12 16:03:15.258747
# Unit test for function tokenize_json
def test_tokenize_json():
    # Ensure that a json string tokenizes correctly
    json = '{"name":"Allison", "mail":"allison@example.com", "age":31}'
    assert tokenize_json(json) == {
        'age': 31,
        'mail': 'allison@example.com',
        'name': 'Allison'
    }
    # Ensure that an invalid json string throws an exception
    json = '{"name"Allison, "mail":"allison@example.com", "age":31}'
    with pytest.raises(ParseError):
        tokenize_json(json)
    # Ensure that a json array tokenizes correctly
    json = '[ "name", "Allison", "mail", "allison@example.com", "age", 31 ]'

# Generated at 2022-06-12 16:03:23.747050
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('[]') == ListToken([], 0, 1, '[')

    expected = [
        Token(DictToken({
            ScalarToken('number', 1, 7, '{"number":123'),
            ScalarToken(123, 9, 11, '{"number":123')
        }, 0, 11, '{"number":123'), 0, 11, '{"number":123')
    ]

    assert tokenize_json('{"number":123') == ListToken(expected, 0, 11, '{"number":123')



# Generated at 2022-06-12 16:03:29.366953
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {
        'name': 'name',
        'type': ['string', 'null'],
        'max_length': 255
    }
    validator = Field(schema)
    result = validate_json(
        content='{"name": "Danny"}',
        validator=validator
    )
    assert(result.value == {'name': 'Danny'})
    assert(result.error_messages == [])

# Generated at 2022-06-12 16:03:39.041988
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 1, 3, '{"a": 1}'): ScalarToken(1, 5, 6, '{"a": 1}')},
        0,
        8,
        '{"a": 1}',
    )
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")



# Generated at 2022-06-12 16:03:49.044534
# Unit test for function tokenize_json
def test_tokenize_json():
    # empty string test
    try:
        tokenize_json('')
        assert False, "Should throw ParseError"
    except ParseError:
        pass

    # null test
    token = tokenize_json('null')
    assert token.type() == 'scalar'
    assert token.value() is None
    assert token.position().char_index == 0
    assert token.position().line_no == 1
    assert token.position().column_no == 1
    assert token.length() == 4

    # bool test
    token = tokenize_json('true')
    assert token.type() == 'scalar'
    assert token.value() is True
    assert token.position().char_index == 0
    assert token.position().line_no == 1
    assert token.position().column_no == 1
   

# Generated at 2022-06-12 16:04:04.601229
# Unit test for function tokenize_json
def test_tokenize_json():
    data = """
    {
        "key1": "value1",
        "key2": [
            "value2a",
            "value2b"
        ],
        "key3": {
            "key3a": "nested_value3a",
            "key3b": "nested_value3b"
        }
    }
    """

    token = tokenize_json(data)
    assert token.value == {
        "key1": "value1",
        "key2": ["value2a", "value2b"],
        "key3": {
            "key3a": "nested_value3a",
            "key3b": "nested_value3b"
        }
    }
    assert token.type == Token.DICT

# Generated at 2022-06-12 16:04:13.155269
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tokenize JSON string and validate the result
    """
    assert(tokenize_json(b'') == None)
    assert(tokenize_json(b'"a"') == ScalarToken('a', 0, 2, '"a"'))
    assert(tokenize_json(b'["a"]') == ListToken(['a'], 0, 4, '["a"]'))
    assert(tokenize_json(b'["a"]') == ListToken(['a'], 0, 4, '["a"]'))
    assert(tokenize_json(b'{"a": "b"}') == DictToken({ScalarToken('a', 1, 3, '"a"'): ScalarToken('b', 6, 8, '"b"')}, 0, 10, '{"a": "b"}'))


# Unit test

# Generated at 2022-06-12 16:04:23.596583
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '''{
        "num": 1,
        "string": "hello",
        "bool": true,
        "none": null,
        "array": [1, 2, 3],
        "object": {"key": "value"}
    }'''
    test_token = tokenize_json(test_content)

# Generated at 2022-06-12 16:04:27.113643
# Unit test for function tokenize_json
def test_tokenize_json():
    s = '{"name": "test_name", "age": 12, "is_active": true}'
    token = tokenize_json(s)
    assert isinstance(token, DictToken)
    assert len(token) == 3
    assert token["name"].value == "test_name"

# Generated at 2022-06-12 16:04:30.800882
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"foo":"bar","a":true}'
    token = tokenize_json(json_string)
    print(token.to_python())


# Generated at 2022-06-12 16:04:37.417370
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        '{\
            "name": "test_person",\
            "address": {\
                "line1": "test_road",\
                "line2": "test_colony",\
                "line3": "test_state",\
                "line4": "test_country"\
            }\
        }'
    )
    assert isinstance(token, DictToken)
    assert token.get('name').value == 'test_person'
    assert token.get('address').get('line1').value == 'test_road'

# Generated at 2022-06-12 16:04:40.646872
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "Karthik", "age": "28"}'
    assert(tokenize_json(content).value == {"name": "Karthik", "age": "28"})

    content = '{"age": 28}'
    assert(tokenize_json(content).value == {"age": 28})



# Generated at 2022-06-12 16:04:46.158415
# Unit test for function tokenize_json
def test_tokenize_json():
    from pprint import pprint

    content = """{
            "id": 1,
            "name": "A",
            "price": 23.4,
            "tags": ["dog", "cat"],
            "stock": {
                "warehouse": 300,
                "retail": 20
            }
        }"""
    res = tokenize_json(content)
    print(res)
    pprint(res.children, width=20)



# Generated at 2022-06-12 16:04:58.217184
# Unit test for function tokenize_json
def test_tokenize_json():
  import json as std_json
  # Correct Syntax
  correct_json = '{"key-1": 1, "key-2": "value-2"}'
  token = tokenize_json(correct_json)
  assert isinstance(token, DictToken)
  value = std_json.loads(correct_json)
  assert token.value == value
  # Wrong Syntax
  wrong_json = '{"key-1": 1, "key-2": "value-2"},'
  with pytest.raises(ParseError) as excinfo:
    tokenize_json(wrong_json)
  assert excinfo.value.code == "parse_error"
  assert len(excinfo.value.position)== 1
  # Wrong Syntax: No Content
  wrong_json = ''

# Generated at 2022-06-12 16:05:03.008351
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({
        'a': ScalarToken('b', 2, 5, '{"a": "b"}')
    }, 0, 8, '{"a": "b"}')

    assert tokenize_json('{"a": 12, "b": 13}') == DictToken({
        'a': ScalarToken(12, 2, 5, '{"a": 12, "b": 13}'),
        'b': ScalarToken(13, 11, 14, '{"a": 12, "b": 13}')
    }, 0, 16, '{"a": 12, "b": 13}')


# Generated at 2022-06-12 16:05:13.237689
# Unit test for function tokenize_json
def test_tokenize_json():
    t = tokenize_json('{"a": [1,2,3]}')
    assert isinstance(t, DictToken)


# Generated at 2022-06-12 16:05:24.188294
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("[{\"a\": 1}]")
    assert str(token) == "[{'a': 1}]"
    assert token.start_pos == 1
    assert token.end_pos == 11

    assert isinstance(token, ListToken)
    value = token.value
    assert len(value) == 1
    assert isinstance(value[0], DictToken)
    value = value[0].value
    assert isinstance(value, dict)
    assert len(value) == 1
    key = list(value.keys())[0]
    assert isinstance(key, ScalarToken)
    value = list(value.values())[0]
    assert isinstance(value, ScalarToken)
    assert key.value == "a"
    assert key.start_pos == 2
    assert key.end_

# Generated at 2022-06-12 16:05:31.772528
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import ListToken, DictToken
    test_dict = {"a": "b", "c": [1, 2, 3]}
    dict_str = dict_to_string(test_dict)
    token = tokenize_json(dict_str)
    assert type(token) == DictToken
    assert token.value == {
        "a": "b",
        "c": [1, 2, 3],
    }
    assert token.value["c"].value == [1, 2, 3]
    assert type(token.value["c"]) == ListToken
    assert token.value["c"].value[0] == 1



# Generated at 2022-06-12 16:05:42.463424
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == ScalarToken(None, 0, 0, '')
    assert tokenize_json('{}') == DictToken({}, 0, 2, '{}')
    assert tokenize_json('42') == ScalarToken(42, 0, 2, '42')
    assert tokenize_json('3.14') == ScalarToken(3.14, 0, 4, '3.14')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 5, 'false')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')

# Generated at 2022-06-12 16:05:53.379224
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """
    {
        "key1" : 5,
        "key2" : "value2",
        "key3" : [1, 2, 3],
        "key4" : [
            true,
            false,
            null
        ]
    }
    """
    token = tokenize_json(json)
    assert token.children["key1"].value == 5
    assert token.children["key1"].start.line_no == 3
    assert token.children["key1"].start.column_no == 12
    assert token.children["key1"].end.line_no == 3
    assert token.children["key1"].end.column_no == 14
    assert token.children["key2"].value == "value2"
    assert token.children["key2"].start.line_no

# Generated at 2022-06-12 16:06:01.643502
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"bar": {"foo": "hello world"}, "baz": ["one", "two"]}'
    expected = DictToken(
        {
            "bar": DictToken({"foo": ScalarToken("hello world", 20, 32, json)}),
            "baz": ListToken([ScalarToken("one", 41, 44, json), ScalarToken("two", 47, 50, json)]),
        },
        0,
        52,
        json,
    )
    assert tokenize_json(json) == expected

    expected = ParseError(
        text="Expecting value", code="parse_error", position=Position(line_no=1, char_index=11, column_no=12)
    )

# Generated at 2022-06-12 16:06:10.877287
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 7, 12, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

# Generated at 2022-06-12 16:06:21.698681
# Unit test for function tokenize_json
def test_tokenize_json():
    data = """{
        "foo": "bar",
        "baz": [1, 2, 3],
        "qux":
            {"a": [],
             "b": {},
             "c": true,
             "d": false,
             "e": null}
    }
    """

    expected = {
        "foo": "bar",
        "baz": [1, 2, 3],
        "qux": {
            "a": [],
            "b": {},
            "c": True,
            "d": False,
            "e": None,
        },
    }

    token = tokenize_json(data)
    assert token.value == expected

    # test_invalid

# Generated at 2022-06-12 16:06:32.758520
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "ab", "b": [1, 2, 3], "c": {"d": "ef"}}'
    token = tokenize_json(content)

    assert type(token) == DictToken
    assert token.value == {"a": "ab", "b": [1, 2, 3], "c": {"d": "ef"}}

    assert token.items[0][0].value == "a"
    assert type(token.items[0][0]) == ScalarToken
    assert token.items[0][1].value == "ab"
    assert type(token.items[0][1]) == ScalarToken

    assert token.items[1][0].value == "b"
    assert type(token.items[1][0]) == ScalarToken

# Generated at 2022-06-12 16:06:37.113515
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b"""
    {
        "foo": "bar"
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}



# Generated at 2022-06-12 16:06:48.080312
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == tokenize_json('{"a": 1}')
    assert tokenize_json('{"a": 1}') != tokenize_json('{"a": 2}')
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('')
    assert exc_info.value.text == 'No content.'
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{"a": "abc')
    assert exc_info.value.text == 'Unterminated string starting at: line 1 column 7 (char 6).'
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{"a" 1}')

# Generated at 2022-06-12 16:06:57.497141
# Unit test for function tokenize_json
def test_tokenize_json():
    # Note - this unit test is *not* particularly comprehensive.
    # It's intended to catch the most obvious mistakes.
    def assertToken(token, token_type, value, content, expected_content=True):
        assert isinstance(token, token_type)
        assert token.value == value
        assert token.content == content if expected_content else token.content
        assert token.range.start == 0
        assert token.range.end == len(content)

    assertToken(
        tokenize_json("10"), ScalarToken, 10, "10"
    )

    assertToken(
        tokenize_json("10.0"), ScalarToken, 10.0, "10.0"
    )

    assertToken(
        tokenize_json("true"), ScalarToken, True, "true"
    )


# Generated at 2022-06-12 16:07:04.351707
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name":"Gondo"}') == {'name': 'Gondo'}
    assert tokenize_json('{"name":"Gondo"') == ParseError('Expecting "}".', "parse_error", Position(char_index=12, line_no=1, column_no=13))

# Generated at 2022-06-12 16:07:13.212256
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1, "b":2, "c":3}'
    result = tokenize_json(content)
    assert result.is_dict()
    assert result.to_python() == {"a": 1, "b": 2, "c": 3}
    assert result.children["a"].to_python() == 1
    assert result.children["b"].to_python() == 2
    assert result.children["c"].to_python() == 3
    content = '["a", "b", "c"]'
    result = tokenize_json(content)
    assert result.is_list()
    assert result.to_python() == ["a", "b", "c"]
    assert result.items[0].to_python() == "a"

# Generated at 2022-06-12 16:07:23.996614
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.code == "no_content"
    # Integer
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    # String, with escape characters
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("\"\\b\\f\\n\\r\\t\"") == ScalarToken("\b\f\n\r\t", 0, 10, '"\\b\\f\\n\\r\\t"')
    # True
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    # False
    assert token

# Generated at 2022-06-12 16:07:26.756864
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")



# Generated at 2022-06-12 16:07:35.141164
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.token_validation import validate
    import typesystem.tokenize.tokens as tokens
    import typesystem.tokenize.positional_validation as positional_validation
    import typesystem

    class CatSchema(Schema):
        name = String()
        age = Integer()
        weight = Float()



    c = CatSchema()

    ugly_json = '{"name": "Ralph", "weight": 10.5, "age": "meow"}'
    ugly_token = tokenize_json(ugly_json)

    print_token(ugly_token)

    # validate_json should print errors about the string 'meow' for

# Generated at 2022-06-12 16:07:44.200550
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("test") == ScalarToken("test", 0, 3, "test")

    assert tokenize_json(42) == ScalarToken(42, 0, 1, "42")


# Generated at 2022-06-12 16:07:51.738118
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(u'{"a":1}') == tokenize_json(b'{"a":1}')
    assert tokenize_json(u'{"a":1}') == {u'a': 1}
    assert tokenize_json(u'') == {}
    try:
        tokenize_json(u'{')
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
    try:
        tokenize_json(u'{ "a" 1 }')
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 7
    try:
        tokenize_json(u'{ a: 1 }')
    except ParseError as exc:
        assert exc

# Generated at 2022-06-12 16:08:02.915937
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('[]') == ListToken([], 0, 1, '[]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('-1.5') == ScalarToken(-1.5, 0, 4, '-1.5')
    assert tokenize_json('""') == ScalarToken('', 0, 2, '""')

# Generated at 2022-06-12 16:08:13.905209
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(
        r"""
    {
        "hello": "world",
        "things": [
            {"name": "John"},
            {"name": "James"}
        ]
    }""",
    ) == DictToken(  # type: ignore
        {
            "hello": ScalarToken("world"),
            "things": ListToken(
                [
                    DictToken({"name": ScalarToken("John")}),
                    DictToken({"name": ScalarToken("James")}),
                ]
            ),
        }
    )
    assert tokenize_json(r"""null""") == ScalarToken(None)  # type: ignore
    assert tokenize_json(r"""123""") == ScalarToken(123)  # type: ignore

# Generated at 2022-06-12 16:08:18.829556
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"hello": "world"}'
    token = tokenize_json(content)
    assert token.value == {"hello": "world"}
    assert token.start == 0
    assert token.stop == 16
    assert token.content == content
    assert token.data == {"hello": "world"}



# Generated at 2022-06-12 16:08:23.934899
# Unit test for function tokenize_json
def test_tokenize_json():
  content = """{
    "a": {
      "b": [1,2,3,4],
      "c": ['a', 'b', 'c']
    },
    "d": "e"
  }"""
  print(tokenize_json(content))


# Generated at 2022-06-12 16:08:30.604119
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:08:35.514442
# Unit test for function tokenize_json
def test_tokenize_json():
    validator = Field(type="integer")
    content = b'{"field_1":"hello","field_2":5}'
    try:
        value, error_messages = validate_json(content, validator)
    except ParseError as parse_error:
        print(parse_error)


# Generated at 2022-06-12 16:08:43.227244
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test tokenizing a valid JSON document.
    json_token = tokenize_json('{"glossary": {"title": "example glossary"}}')
    assert str(json_token) == "DictToken(value={'glossary': DictToken(value={'title': ScalarToken(value='example glossary')})})"

    # Test tokenizing JSON with missing quotes.
    try:
        tokenize_json('{"glossary": {"title": example glossary"}}')
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position == Position(column_no=28, line_no=1, char_index=27)

    # Test tokenizing invalid JSON.

# Generated at 2022-06-12 16:08:53.958066
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b"}') == DictToken({'a': 'b'}, 0, 8, '{"a":"b"}')
    assert tokenize_json('{"a":4}') == DictToken({'a': 4}, 0, 6, '{"a":4}')
    assert tokenize_json('{"a":null}') == DictToken({'a': None}, 0, 9, '{"a":null}')
    assert tokenize_json('{"a":true}') == DictToken({'a': True}, 0, 9, '{"a":true}')
    assert tokenize_json('{"a":false}') == DictToken({'a': False}, 0, 10, '{"a":false}')

# Generated at 2022-06-12 16:09:01.698788
# Unit test for function tokenize_json
def test_tokenize_json():
    # Simple scalar
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")

    # Nested dict
    source = '{"a": {"b": [1, 2, {"c": "d"}]}}'
    expected = DictToken(
        {"a": DictToken({"b": ListToken([1, 2, DictToken({"c": "d"},)])})},
        0,
        28,
        source,
    )
    assert tokenize_json(source) == expected

# Generated at 2022-06-12 16:09:11.993190
# Unit test for function tokenize_json
def test_tokenize_json():
    a = "{'a':1,'b':{'c':'d'}}"
    try:
        tokenize_json(a)
    except ParseError:
        pass
    else:
        raise RuntimeError("Should have raised an error!")

    b = '{}'
    try:
        tokenize_json(b)
    except ParseError:
        raise RuntimeError("Should not have raised an error!")
    else:
        pass

    c = '{"a":1,"b":{"c":"d"}}'
    try:
        tokenize_json(c)
    except ParseError:
        raise RuntimeError("Should not have raised an error!")
    else:
        pass

    assert isinstance(tokenize_json(b), DictToken)

# Generated at 2022-06-12 16:09:19.596560
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test tokenize_json function with a simple JSON object.
    """
    json_object = '{"a": "b", "c": [1, 2, 3.4]}'
    tokens = tokenize_json(json_object)
    assert tokens.string_value == '{"a": "b", "c": [1, 2, 3.4]}'
    assert tokens.start_pos == 0
    assert tokens.end_pos == 26
    assert tokens.raw == '{"a": "b", "c": [1, 2, 3.4]}'


# Generated at 2022-06-12 16:09:24.013619
# Unit test for function tokenize_json
def test_tokenize_json():
    print (tokenize_json('{"key": "value", "array": [1, 2, 3]}'))


# Generated at 2022-06-12 16:09:31.617412
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key_one": {"key_two": [{"key_three": [0, 1, 2, 3]}]}}'
    expected_result = DictToken(
        {"key_one": DictToken({"key_two": ListToken([DictToken(
            {"key_three": ListToken([0, 1, 2, 3])})
        ])})},
        0,
        len(content) - 1,
        content
    )
    result = tokenize_json(content)
    assert result == expected_result



# Generated at 2022-06-12 16:09:42.703167
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token == {}

    token = tokenize_json("[1, true, \"hello\"]")
    assert isinstance(token, ListToken)
    assert token == [1, True, "hello"]

    token = tokenize_json("\"hello\"")
    assert isinstance(token, ScalarToken)
    assert token == "hello"

    # Handle the empty string case explicitly for clear error messaging.
    try:
        token = tokenize_json("")
    except ParseError as exception:
        assert exception.text == "No content."
        assert exception.code == "no_content"
        assert exception.position == Position(column_no=1, line_no=1, char_index=0)

# Generated at 2022-06-12 16:09:49.195307
# Unit test for function tokenize_json
def test_tokenize_json():
    def test(json_string, expected_token_class, expected_tree):
        token = tokenize_json(json_string)
        assert token.__class__ is expected_token_class
        assert token.tree == expected_tree

    test('{"a": 1}', DictToken, {'a': 1})
    test('{"a": {"b": 1}}', DictToken, {'a': {'b': 1}})
    test('{"a": [1, 2, 3]}', DictToken, {'a': [1, 2, 3]})
    test('{"a": 1, "b": 2}', DictToken, {'a': 1, 'b': 2})

# Generated at 2022-06-12 16:09:55.090267
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == {'a': 1}
    assert tokenize_json('{"a": 1}') == {'a': 1}
    assert tokenize_json('{"a": 1,}') == {'a': 1}
    assert tokenize_json('{"a": 1,}') == {'a': 1}
    assert tokenize_json('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert tokenize_json('["a", "b"]') == ['a', 'b']



# Generated at 2022-06-12 16:10:05.856224
# Unit test for function tokenize_json
def test_tokenize_json():
    # Basic test
    content = "{\"foo\": 3}"
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert result.dict_value == {"foo": ScalarToken(3, 3, 6, content)}
    assert result.start == 0
    assert result.end == 10

    # A more elaborate test that verifies that tokens are correctly nested
    content = """
        {
            "foo": "bar",
            "baz": [1, 2, {"bat": 42}]
        }
    """
    result = tokenize_json(content)
    assert isinstance(result, DictToken)

# Generated at 2022-06-12 16:10:16.139154
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"some-field": "some-value"}') == DictToken(
        {
            "some-field": ScalarToken(
                "some-value", start=2, end=16, content='{"some-field": "some-value"}'
            )
        },
        start=0,
        end=18,
        content='{"some-field": "some-value"}',
    )
    assert tokenize_json(b'["some-value"]') == ListToken(
        [ScalarToken("some-value", start=1, end=11, content='["some-value"]')],
        start=0,
        end=12,
        content='["some-value"]',
    )

# Generated at 2022-06-12 16:10:26.846337
# Unit test for function tokenize_json
def test_tokenize_json():
    # Simple test of valid json to see what it does
    tk = tokenize_json('{"x": 1, "y": 2}')

    assert tk.start == 0
    assert tk.end == 14
    assert tk.value == {'x': 1, 'y': 2}
    assert tk.content == '{"x": 1, "y": 2}'
    assert tk.position == Position(column_no=1, line_no=1)

    # Tests of invalid json to see what it does
    with pytest.raises(ParseError) as pe:
        tokenize_json('{"x": 1, "y": }')

    assert pe.value.code == 'parse_error'
    assert pe.value.text == 'Expecting value'

# Generated at 2022-06-12 16:10:34.668787
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema(fields={"name": {"type": "string"}, "age": {"type": "integer"}})
    content = (
        '{"name": "Abe", "age": 27, "untouched": "should be untouched"}'
    )
    expected = DictToken(
        {"name": ScalarToken("Abe", 8, 16, content), "age": ScalarToken(27, 21, 26, content)},
        0,
        26,
        content
    )
    actual = tokenize_json(content)
    assert expected == actual

# Unit tests for function validate_json.

# Generated at 2022-06-12 16:10:36.652450
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":"b"}')
    expected = DictToken({"a": "b"}, 0, 5, {"a":"b"})
    assert token == expected



# Generated at 2022-06-12 16:10:50.488590
# Unit test for function tokenize_json
def test_tokenize_json():
    """Test function ``tokenize_json()``"""
    from typesystem.tokenize.tokens import DictToken, ListToken
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.fields import String, Number
    from typesystem import Schema

    def assert_token(token, expected_type, expected_value, expected_start, expected_end):
        assert isinstance(token, expected_type)
        assert token.value == expected_value
        assert token.position_start == expected_start
        assert token.position_end == expected_end

    # Test with valid JSON
    test = "{\"value\": 123.456}"
    token = tokenize_json(test)

# Generated at 2022-06-12 16:10:56.692419
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String

    token = tokenize_json('{"baz": "foo"}')
    assert isinstance(token, DictToken)
    assert token.value == {"baz": "foo"}

    token = tokenize_json('{"baz": 123, "bar": "foo"}')
    assert token.value == {"baz": 123, "bar": "foo"}

    try:
        tokenize_json('{"baz": 123, "bar": "foo"')
    except ParseError as exc:
        assert exc.position.line_no == 0
        assert exc.position.column_no == 31
        assert exc.position.char_index == 31
        assert exc.text == "No closing quotation."
        assert exc.code == "parse_error"


# Generated at 2022-06-12 16:11:04.885865
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Unit test for function tokenize_json.
    '''
    # pylint: disable=invalid-name
    # pylint: disable=invalid-name
    token = tokenize_json('{"foo": 2}')
    assert isinstance(token, DictToken)
    assert token.key == "foo"
    assert token.value == 2
    # Check that tokenize_json raises ParseError
    with pytest.raises(ParseError):
        tokenize_json('')
    # Check that tokenize_json raises ParseError
    with pytest.raises(ParseError):
        tokenize_json('{"foo: 2}')
    # Check that tokenize_json raises ParseError

# Generated at 2022-06-12 16:11:13.045305
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
      "name": "John Doe",
      "age": 47
    }"""

    tokenized = tokenize_json(content)
    assert tokenized.start == 0
    assert tokenized.end == len(content)

    expected = {'name': 'John Doe', 'age': 47}
    assert tokenized.value == expected

    as_dict = tokenized.to_dict()
    assert as_dict["value"] == expected

    assert tokenized.start_position.column_no == 1
    assert tokenized.start_position.line_no == 1

    assert tokenized.end_position.column_no == 2
    assert tokenized.end_position.line_no == 7
