

# Generated at 2022-06-12 16:01:34.329292
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        """
        {
          "foo": [
            "bar",
            "baz"
          ]
        }
        """
    )
    assert isinstance(token, DictToken)
    assert token.value == {
        "foo": ListToken(
            value=[ScalarToken(value="bar", start=26, end=30, content=token.content), 
                   ScalarToken(value="baz", start=33, end=37, content=token.content)],
            start=23,
            end=39,
            content=token.content,
        )
    }


# Generated at 2022-06-12 16:01:40.168184
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(name="test", type="string")

    value, errors = validate_json("{}", field)
    assert (value, errors) == (None, [])

    value, errors = validate_json("{}", Schema(fields={"test": field}))
    assert (value, errors) == ({}, [])

    value, errors = validate_json(
        b"{\"test\":\"hello world\"}", Schema(fields={"test": field})
    )
    assert (value, errors) == ({"test": "hello world"}, [])

    with pytest.raises(ParseError):
        validate_json("[{test}]", Schema(fields={"test": field}))

# Generated at 2022-06-12 16:01:43.105384
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "foo", "b": "bar"}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert isinstance(token.value["a"], str)
    assert isinstance(token.value["b"], str)
    assert token.value["a"] == "foo"
    assert token.value["b"] == "bar"



# Generated at 2022-06-12 16:01:53.230381
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo":1, "bar": 2}'
    token = tokenize_json(content)
    assert token.value == {"foo": 1, "bar": 2}
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 15

    # Position of the start of the key for "foo"
    assert token.value["foo"].start_position.char_index == 2
    assert token.value["foo"].end_position.char_index == 6

    # Position of the end of the key for "foo"
    assert token.value["bar"].start_position.char_index == 10
    assert token.value["bar"].end_position.char_index == 14


# Generated at 2022-06-12 16:02:00.535472
# Unit test for function tokenize_json
def test_tokenize_json():

    json_data = """
        {
            "array": [
                1,
                2,
                3,
                {"four": "hello world", "five": 5},
                6,
                [
                    7,
                    8,
                    9
                ]
            ]
        }
    """
    result = tokenize_json(json_data)
    assert result == {
        "array": [
            1,
            2,
            3,
            {"four": "hello world", "five": 5},
            6,
            [7, 8, 9],
        ]
    }

# Generated at 2022-06-12 16:02:02.484201
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name":"Kunal","age":25,"married":true}')
    assert token, token

# Generated at 2022-06-12 16:02:12.960056
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json(
        '{"a": 123, "b": "b"}'
    ) == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 123, "b": "b"}'): ScalarToken(
                123, 6, 8, '{"a": 123, "b": "b"}'
            ),
            ScalarToken("b", 11, 12, '{"a": 123, "b": "b"}'): ScalarToken(
                "b", 15, 16, '{"a": 123, "b": "b"}'
            ),
        },
        0,
        17,
        '{"a": 123, "b": "b"}',
    )
    assert token

# Generated at 2022-06-12 16:02:22.677508
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(json.dumps({"hello": "world"})) == {
        "hello": "world"
    }

    # Line breaks and leading whitespace should both be allowed
    assert tokenize_json(b"{  \n\r  \"  foo  \"  :  [  ] }") == {
        "  foo  ": []
    }

    # Tokenize invalid JSON and ensure that a ParseError is raised
    with pytest.raises(ParseError) as exc_info:
        tokenize_json(b"{:}}")

    # Ensure that the exception has a meaningful error message with
    # columns and line numbers
    exc = exc_info.value

    assert str(exc) == "ParseError: No content."
    assert exc.code == "no_content"
    assert exc.position

# Generated at 2022-06-12 16:02:32.491688
# Unit test for function tokenize_json
def test_tokenize_json():
    tokens = []
    for value in [
        '{"foo": 123, "bar": "string"}',
        '{"foo": [1, 2, 3], "bar": [true, false, null]}',
    ]:
        try:
            token = tokenize_json(value)
        except ParseError as error:
            assert error.text == "Expecting property name enclosed in double quotes."
            tokens.append(error.code)
        else:
            tokens.append(token.value)
    assert tokens == [{'foo': 123, 'bar': 'string'}, {'foo': [1, 2, 3], 'bar': [True, False, None]}]



# Generated at 2022-06-12 16:02:40.971799
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": 2, "c": false}') == {
        'a': 1,
        'b': 2,
        'c': False
    }

    assert tokenize_json('[1, "b", true]') == [1, "b", True]

    assert tokenize_json(content='123.45') == 123.45
    assert tokenize_json(content='123') == 123
    assert tokenize_json(content='"Hello"') == "Hello"
    assert tokenize_json(content='false') is False
    assert tokenize_json(content='true') is True
    assert tokenize_json(content='null') is None

    with pytest.raises(ParseError) as error:
        tokenize_json('')

    assert error.value.position

# Generated at 2022-06-12 16:02:56.161697
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test tokenize_json
    """
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    # Test that a default validator object is used.
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    # Test that an explicit validator object is used.
    assert tokenize_json("{}", validator=None) == DictToken({}, 0, 1, "{}")

    # Test that a validator class is used.
    assert tokenize_json("{}", validator=Schema) == DictToken({}, 0, 1, "{}")

    # Test that a validator instance is used.
    assert tokenize_json("{}", validator=Schema()) == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-12 16:03:01.328704
# Unit test for function tokenize_json
def test_tokenize_json():
    all_characters = "".join(chr(i) for i in range(256))
    print(len(all_characters))
    token = tokenize_json(all_characters)
    assert len(token) == 256
    print(all_characters)
    print(token)
    #print(token)
    #print(len(token))
    # print(token)
    # assert len(token) == 1
    # assert token[0].value == 1000




# Generated at 2022-06-12 16:03:06.540789
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:03:17.479015
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"test": 10}') == DictToken({ScalarToken("test", 1, 8, '{"test": 10}'): ScalarToken(10, 10, 13, '{"test": 10}')}, 0, 13, '{"test": 10}')
    assert tokenize_json('{"test": true}') == DictToken({ScalarToken("test", 1, 8, '{"test": true}'): ScalarToken(True, 10, 14, '{"test": true}')}, 0, 14, '{"test": true}')

# Generated at 2022-06-12 16:03:28.743803
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "John Doe", "age": 43 }')
    assert isinstance(token, DictToken)

    #assert token == {'name': 'John Doe', 'age': 43}
    assert token.value == {'name': 'John Doe', 'age': 43}
    assert token.start_pos == 0
    assert token.stop_pos == 29

    token = tokenize_json('{"name": "John Doe", "age": 43, "children": ["Jane", "Joe"] }')
    assert isinstance(token, DictToken)
    assert token.value == {'name': 'John Doe', 'age': 43, 'children': ['Jane', 'Joe']}
    assert token.start_pos == 0
    assert token.stop_pos == 61


# Generated at 2022-06-12 16:03:33.449053
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that tokenize_json works
    """
    json_string = '{"b":1}'
    result = tokenize_json(json_string)
    assert isinstance(result, Token)
    assert isinstance(result, DictToken)
    assert result.value == {'b': 1}



# Generated at 2022-06-12 16:03:41.050108
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test that tokenize_json raises an error on empty content
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test that tokenize_json raises an error on bad JSON
    with pytest.raises(ParseError):
        tokenize_json(r"\u001f")

    # Test that tokenize_json raises an error on if the first char is not
    # whitespace or {, [ or "
    with pytest.raises(ParseError):
        tokenize_json("1")

    # Test that tokenize_json returns a Token
    assert isinstance(tokenize_json("null"), ScalarToken)



# Generated at 2022-06-12 16:03:46.242893
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_token = DictToken(
        {ScalarToken("foo", 0, 2, '{"foo":1}'): ScalarToken(1, 5, 5, '{"foo":1}')},
        0,
        10,
        '{"foo":1}',
    )
    assert tokenize_json('{"foo":1}') == dict_token



# Generated at 2022-06-12 16:03:48.053504
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "Russ"}') == {'name': 'Russ'}



# Generated at 2022-06-12 16:03:57.852965
# Unit test for function tokenize_json
def test_tokenize_json():
    input = '{"a":1,"b":true,"c":[1,2,3,4,5]}'


# Generated at 2022-06-12 16:04:12.694589
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{}') == DictToken({}, 0, 1, "{}")
    assert tokenize_json(b'[1]') == ListToken([1], 0, 2, "[1]")
    assert tokenize_json(b'null') == ScalarToken(None, 0, 3, "null")
    assert tokenize_json(b'true') == ScalarToken(True, 0, 3, "true")
    assert tokenize_json(b'false') == ScalarToken(False, 0, 4, "false")
    assert tokenize_json(b'42') == ScalarToken(42, 0, 1, "42")
    assert tokenize_json(b'"hello"') == ScalarToken("hello", 0, 6, '"hello"')

# Generated at 2022-06-12 16:04:23.256202
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """
    {
        "arr": [1, 2, {"foo": "bar"}],
        "val1": "hello",
        "val2": null,
        "val3": true,
        "val4": false,
        "val5": 1,
        "val6": 1.5,
        "val7": 1.55e2
    }
    """

    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.value["val1"].value == "hello"
    assert token.value["arr"].value[2].value["foo"].value == "bar"


# Generated at 2022-06-12 16:04:31.246880
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = open("../test/test_tokenize_json.json", "r").read()
    out = tokenize_json(json_content)
    assert isinstance(out, DictToken)
    assert out.keys() == ["first_name", "last_name", "age", "address", "phone_number"]
    assert out.get("first_name").value == "John"
    assert out.get("last_name").value == "Smith"
    assert out.get("age").value == 25
    assert out.get("address").keys() == ["street_address", "city", "state", "postal_code"]
    assert out.get("address").get("street_address").value == "21 2nd Street"
    assert out.get("address").get("city").value == "New York"
    assert out.get

# Generated at 2022-06-12 16:04:36.860676
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:04:42.372571
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = '{"a": 1, "b": 2}'
    token = tokenize_json(valid_json)
    assert token.to_primitive() == {"a": 1, "b": 2}

    invalid_json = '{"a": 1, "b": 2]'
    with pytest.raises(ParseError):
        token = tokenize_json(invalid_json)



# Generated at 2022-06-12 16:04:45.618303
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"obj": {"key": "value", "array": [1, 2, 3]}}'
    token = tokenize_json(json)

    assert token.value == {"obj": {"key": "value", "array": [1, 2, 3]}}



# Generated at 2022-06-12 16:04:49.086461
# Unit test for function tokenize_json
def test_tokenize_json():
    data = {
        "a": 1,
        "b": ["hello", 2],
        "c": {
            "ca": 1,
            "cb": 2,
        },
    }
    json_data = json.dumps(data)
    output = tokenize_json(json_data)
    assert output.value == data


# Generated at 2022-06-12 16:04:53.048140
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
        Test tokenize_json function
    '''
    assert tokenize_json('{"key":"value"}') == {'key':'value'}


# Generated at 2022-06-12 16:05:03.380174
# Unit test for function tokenize_json
def test_tokenize_json():
    test_input = '{"test":5}'
    test_output = tokenize_json(test_input)

    # Make sure that the output of tokenize_json() is a `dict`
    assert isinstance(test_output, dict)
    # Make sure that the output of tokenize_json() is a `Token`
    assert isinstance(test_output, Token)
    # Make sure that the output of tokenize_json() is a `DictToken`
    assert isinstance(test_output, DictToken)
    # Make sure that the output of tokenize_json() is not a `ListToken`
    assert isinstance(test_output, ListToken) == False
    # Make sure that the output of tokenize_json() is not a `ScalarToken`
    assert isinstance(test_output, ScalarToken) == False

# Generated at 2022-06-12 16:05:09.076578
# Unit test for function tokenize_json
def test_tokenize_json():
    tok = tokenize_json('{ "a": [ "something", 555 ], "b": "something" }')
    assert tok.as_dict() == {
        "a": [Token(value="something", start=13, end=23, content="{..}"), 555],
        "b": "something",
    }


# Generated at 2022-06-12 16:05:21.344093
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    assert (tokenize_json("") == None)
    # Test invalid JSON
    invalid_json = "{"
    try:
        tokenize_json(invalid_json)
    except ParseError: # expected exception
        pass
    # Test valid JSON
    valid_json = '{"a": 1, "b": "abc"}'
    assert (tokenize_json(valid_json) == {"a": 1, "b": "abc"})


# Generated at 2022-06-12 16:05:27.489047
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, 2,{"foo": ["bar", null]}, null, true, false], "b": 12.3}'
    expected = {
        "a": [
            1,
            2,
            {"foo": ["bar", None]},
            None,
            True,
            False
        ],
        "b": 12.3
    }
    parsed = tokenize_json(content)
    print(parsed)
    assert parsed == expected
    return parsed


# Generated at 2022-06-12 16:05:34.022653
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "John", "age": 30, "cars": [{"name": "Ford", "models": ["Fiesta", "Focus", "Mustang"]}, {"name": "BMW", "models": ["320", "X3", "X5"]}, {"name": "Fiat", "models": ["500", "Panda"]}]}'
    token = tokenize_json(content)
    assert str(token) == '''<DictToken: ''' + content + '''>'''
    assert token.dict_payload["name"] == 'John'
    assert token.dict_payload["age"] == 30
    assert token.dict_payload["cars"][0].dict_payload["name"] == 'Ford'
    assert token.dict_payload["cars"][0].dict_payload["models"][1]

# Generated at 2022-06-12 16:05:43.135198
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty content should raise an error
    empty_content = ""
    with pytest.raises(ParseError, match='Failed to parse content.'):
        tokenize_json(empty_content)

    # Malformed json should return an error with the correct line and column
    malformed_json = '{ "a": 1, "b": false,'
    with pytest.raises(ParseError, match='Failed to parse content.'):
        tokenize_json(malformed_json)

    # Valid json should work as expected
    valid_json = '{"a": 1, "b": false}'
    token = tokenize_json(valid_json)
    assert isinstance(token, DictToken)
    assert token.value["a"] == 1
    assert token.value["b"] == False



# Generated at 2022-06-12 16:05:47.056923
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo":"bar"}') == {
        'foo': 'bar'
    }



# Generated at 2022-06-12 16:05:55.571109
# Unit test for function tokenize_json
def test_tokenize_json():
    print('test_tokenize_json')
    obj = {"key": "value", "key2": [None, True]}

# Generated at 2022-06-12 16:06:05.563251
# Unit test for function tokenize_json
def test_tokenize_json():
    # Happy Path Tests
    assert tokenize_json('"hello"') == ScalarToken('hello', 0, 6, 'hello')
    assert tokenize_json('1.1') == ScalarToken(1.1, 0, 3, '1.1')
    assert tokenize_json('-123') == ScalarToken(-123, 0, 4, '-123')
    assert tokenize_json('-123.123') == ScalarToken(-123.123, 0, 8, '-123.123')
    assert tokenize_json('1e50') == ScalarToken(1e50, 0, 4, '1e50')
    assert tokenize_json('1.1e-50') == ScalarToken(1.1e-50, 0, 7, '1.1e-50')

# Generated at 2022-06-12 16:06:13.296170
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.positional_validation import create_context
    from typesystem.tokenize.tokens import compute_path, DictToken, ListToken, ScalarToken
    from typesystem.tokenize.walk import walk_dict_token, walk_list_token

    token = tokenize_json('{"a": {"b": [1, 2, 3], "c": "hi"}, "d": 2}')
    assert isinstance(token, DictToken)

    assert token.start == 0
    assert token.end == 33

    assert len(token.key_value_pairs) == 2
    assert token.key_value_pairs[0][0].value == "a"
    assert token.key_value_pairs[1][0].value == "d"

    subdocument_token = token.key_value_

# Generated at 2022-06-12 16:06:23.122574
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:24.636876
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[]") == ListToken([])



# Generated at 2022-06-12 16:06:34.646609
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"}, 0, 9, '{"a": "b"}')
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 9, "[1, 2, 3]")


# Generated at 2022-06-12 16:06:37.814984
# Unit test for function tokenize_json
def test_tokenize_json():
    datatest = {"foo": "bar"}
    token_test = tokenize_json(json.dumps(datatest))
    assert token_test.value["foo"].value == "bar"



# Generated at 2022-06-12 16:06:46.763431
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("123") == ScalarToken(value=123, start=0, end=2, content="123")
    assert tokenize_json('"123"') == ScalarToken(value="123", start=0, end=4, content='"123"')
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content="{}")
    assert tokenize_json("{}") != ListToken(value={}, start=0, end=1, content="{}")

    assert tokenize_json("[]") == ListToken(value=[], start=0, end=1, content="[]")
    assert tokenize_json("[]") != DictToken(value=[], start=0, end=1, content="[]")


# Generated at 2022-06-12 16:06:52.145284
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 5, 6, '{"a": "b"}')},
        0, 10, '{"a": "b"}'
    )



# Generated at 2022-06-12 16:06:57.393134
# Unit test for function tokenize_json
def test_tokenize_json():

    sample_json = "{\"dogs\": [\"jessie\"], \"cats\": [\"eugene\"]}"
    tokenized_json = tokenize_json(sample_json)

    assert isinstance(tokenized_json, Token)
    assert 'dogs' in tokenized_json.value
    assert isinstance(tokenized_json.value['dogs'][0], Token)
    assert tokenized_json.value['dogs'][0].type_name == 'string'


# Generated at 2022-06-12 16:07:10.202783
# Unit test for function tokenize_json
def test_tokenize_json():
    data = {'a': 1, 'b': 2, 'c': 3}
    data_str = json.dumps(data)
    token = tokenize_json(data_str)
    assert isinstance(token, DictToken)
    assert token.value == {'a': 1, 'b': 2, 'c': 3}
    data_str = '{"a": {"b": [1, {}, [1, 2, 3]]}, "c": {"d": [{}]}, "e": null}'
    token = tokenize_json(data_str)
    assert isinstance(token, DictToken)
    assert token.value == {'a': {'b': [1, {}, [1, 2, 3]]},
                           'c': {'d': [{}]}, 'e': None}

#

# Generated at 2022-06-12 16:07:16.392677
# Unit test for function tokenize_json
def test_tokenize_json():
    tokens = json.loads(json.dumps(tokenize_json(json.dumps(sample_data))))
    
    assert tokens['type'] == 'DictToken'
    assert tokens['value']['a']['type'] == 'ScalarToken'
    assert tokens['value']['a']['value'] == 1
    assert tokens['value']['b']['type'] == 'ScalarToken'
    assert tokens['value']['b']['value'] == 'foo'
    assert tokens['value']['c']['type'] == 'DictToken'
    assert tokens['value']['c']['value']['1']['type'] == 'ScalarToken'
    assert tokens['value']['c']['value']['1']['value'] == True
   

# Generated at 2022-06-12 16:07:26.860193
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {
        "team": "U of I",
        "division": "Open",
        "projects": [
            {"name": "Duckietown", "size": 12},
            {"name": "ROS", "size": 10},
            {"name": "OpenCV", "size": 8},
        ],
    }
    content = json.dumps(content)
    token = tokenize_json(content)

# Generated at 2022-06-12 16:07:35.548480
# Unit test for function tokenize_json
def test_tokenize_json():
    """Unit tests for function tokenize_json"""

    # Test a valid dict
    dict_json = '{"foo": "bar"}'

    tokenized_value = tokenize_json(dict_json)
    assert isinstance(tokenized_value, DictToken)
    assert tokenized_value.value["foo"] == ScalarToken('"bar"', 6, 10, dict_json)

    # Test an invalid JSON string
    invalid_json = '{"foo: "bar"}'

    try:
        tokenize_json(invalid_json)
        raise AssertionError("Should have failed to parse JSON")
    except ParseError as pe:
        assert pe.position.line_no == 1
        assert pe.position.column_no == 6
        assert pe.position.char_index == 5

    # Test an empty string
   

# Generated at 2022-06-12 16:07:42.963937
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": {"bar": "baz"} }'
    expected_result = {
        "type": "dict",
        "token": {"foo": {"bar": "baz"}},
        "items": {
            "foo": {
                "type": "dict",
                "token": {"bar": "baz"},
                "items": {
                    "bar": {"type": "scalar", "token": "baz", "value": "baz"}
                },
            }
        },
    }
    dict_token = tokenize_json(content)
    assert dict_token.__dict__ == expected_result



# Generated at 2022-06-12 16:08:03.648757
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty String
    with pytest.raises(ParseError):
        tokenize_json(None)
    with pytest.raises(ParseError):
        tokenize_json('')

    # Syntax Errors
    with pytest.raises(ParseError):
        tokenize_json('{')

    # Errors
    with pytest.raises(ParseError):
        tokenize_json('{ }')

    # Strings
    assert tokenize_json('"foo"') == ScalarToken('foo', 0, 3, '"foo"')
    assert tokenize_json('"foo"') != ScalarToken('bar', 0, 3, '"foo"')

    # Numbers
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')
    assert tokenize_json

# Generated at 2022-06-12 16:08:10.290130
# Unit test for function tokenize_json
def test_tokenize_json():
    example = """
    {
        "name": "siva",
        "home": {
            "country": "India",
            "city": "Bengaluru"
        },
        "hobby": "coding"
    }
    """
    token = tokenize_json(example)
    assert token.start_position.line_no == 2
    assert token.start_position.column_no == 5
    assert token.end_position.line_no == 10
    assert token.end_position.column_no == 6
    assert token.content == example


# Generated at 2022-06-12 16:08:14.931079
# Unit test for function tokenize_json
def test_tokenize_json():
    test_array_string = '["test"]'
    test_object_string = '{"test":"test"}'
    test_scalar_string = '"test"'

    class TestArray(ListToken):
        child_type = ScalarToken

    class TestObject(DictToken):
        child_type = ScalarToken

    assert type(tokenize_json(test_array_string)) == TestArray
    assert type(tokenize_json(test_object_string)) == TestObject
    assert type(tokenize_json(test_scalar_string)) == ScalarToken

# Generated at 2022-06-12 16:08:19.090656
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert token == dict(key="value")
    assert isinstance(token.children[0], ScalarToken)
    assert isinstance(token.children[1], ScalarToken)



# Generated at 2022-06-12 16:08:22.538424
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(content=b'{"foo": "bar"}').value == {"foo": "bar"}


# Generated at 2022-06-12 16:08:26.522772
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"field":null}') == \
        DictToken({ScalarToken('field', 0, 5, '{"field":null}'):
                   ScalarToken(None, 11, 14, '{"field":null}')},
                  0, 14, '{"field":null}')



# Generated at 2022-06-12 16:08:37.277894
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.json.tokenize.tokens import (
        DictToken,
        ListToken,
        ScalarToken,
    )
    to_str = json.dumps

    class FooToken(ScalarToken):
        pass

    class BarToken(ScalarToken):
        pass

    class BazToken(ScalarToken):
        pass

    class _TokenizingDecoder(JSONDecoder):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.scan_once = _make_scanner(self)

    def _TokenizingJSONObject(
        s_and_end, strict, scan_once, memo, _w=WHITESPACE.match, _ws=WHITESPACE_STR
    ):
        s,

# Generated at 2022-06-12 16:08:43.256075
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Asserts that types are what you'd expect from tokenizing json.
    """
    content = '{"a_bool": true, "an_int": , "a_list": [], "a_string": "foo"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["a_bool"], ScalarToken)
    assert isinstance(token.value["a_list"], ListToken)
    assert isinstance(token.value["a_string"], ScalarToken)
    assert isinstance(token.value["an_int"], ScalarToken)



# Generated at 2022-06-12 16:08:53.946700
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        dict(ScalarToken('foo', 1, 5, '{"foo": "bar"}'), ScalarToken('bar', 9, 14, '{"foo": "bar"}')),
        0, 15, '{"foo": "bar"}')
    assert tokenize_json('{"foo": 1}') == DictToken(
        dict(ScalarToken('foo', 1, 5, '{"foo": 1}'), ScalarToken(1, 9, 10, '{"foo": 1}')),
        0, 11, '{"foo": 1}')

# Generated at 2022-06-12 16:09:04.930926
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {
        "type": "object",
        "properties": {
            "string": {"type": "string"},
            "number": {"type": "number"},
            "boolean": {"type": "boolean"},
            "null": {"type": "null"},
            "array": {"type": "array"},
            "object": {"type": "object"},
        },
        "required": ["string", "number", "boolean", "null", "array", "object"],
    }
    content = (
        '{"string": "Hello World!",'
        '"number": 42.0,'
        '"boolean": true,'
        '"null": null,'
        '"array": [1, 2, 3],'
        '"object": {"a": "b"}}'
    )


# Generated at 2022-06-12 16:09:20.972936
# Unit test for function tokenize_json
def test_tokenize_json():
    json_dict = {"key": "value", "boolean": True, "number": 4}
    json_str = json.dumps(json_dict)
    token = tokenize_json(json_str)
    assert token.value == json_dict
    assert isinstance(token, DictToken)
    assert token.key == []
    assert token.tokens[0].key == ["key"]
    assert token.tokens[1].value is True
    assert token.tokens[2].value == 4



# Generated at 2022-06-12 16:09:25.841781
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token

    assert isinstance(tokenize_json("{}"), Token)
    assert isinstance(tokenize_json("[]"), Token)
    assert isinstance(tokenize_json("[{}]"), Token)
    assert isinstance(tokenize_json("null"), Token)
    with pytest.raises(ParseError, match="No content."):
        tokenize_json('')
    with pytest.raises(ParseError, match="No content."):
        tokenize_json(' ')
    with pytest.raises(ParseError, match="No content."):
        tokenize_json('\n')
    with pytest.raises(ParseError, match="No content."):
        tokenize_json('\t')

# Generated at 2022-06-12 16:09:31.143269
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": "b"}') == DictToken(
        {ScalarToken("a", 0, 2, b'{"a": "b"}'): ScalarToken("b", 6, 8, b'{"a": "b"}')},
        0,
        8,
        b'{"a": "b"}',
    )



# Generated at 2022-06-12 16:09:37.777019
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test fails on bad JSON.
    with pytest.raises(ParseError):
        tokenize_json("{")

    # Test fails on empty string.
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test parse.
    token = tokenize_json('{"test": "value"}')
    assert isinstance(token, DictToken)
    assert token.value == {"test": "value"}


# Generated at 2022-06-12 16:09:48.216154
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 123}') == DictToken(
        {
            ScalarToken("a", 1, 1, '{"a": 123}'): ScalarToken(123, 8, 10, '{"a": 123}')
        },
        0,
        11,
        '{"a": 123}',
    )

# Generated at 2022-06-12 16:09:52.531162
# Unit test for function tokenize_json
def test_tokenize_json():
  content = """
  {
    "name1": "value1",
    "name2": "value2",
    "name3": 3
  }
  """
  token = tokenize_json(content)
  print(token)

  content = ""
  token = tokenize_json(content)
  print()

# Generated at 2022-06-12 16:10:04.029421
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar", "x": "y"}') == {'foo': 'bar', 'x': 'y'}
    assert tokenize_json('{"foo": "bar", "nested": {"x": "y"}}') == {'foo': 'bar', 'nested': {'x': 'y'}}
    assert tokenize_json('{"foo": "bar", "nested": [{"x": "y"}]}') == {'foo': 'bar', 'nested': [{'x': 'y'}]}
    assert tokenize_json('["foo", "bar", "nested"]') == ['foo', 'bar', 'nested']
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-12 16:10:11.853124
# Unit test for function tokenize_json
def test_tokenize_json():
    # Successful parsing of JSON tokens
    assert tokenize_json('{"a":1}') == DictToken({"a": ScalarToken(1, 3, 3, '{"a":1}')}, 0, 6, '{"a":1}')
    assert tokenize_json('[1,2]') == ListToken([ScalarToken(1, 1, 1, '[1,2]'), ScalarToken(2, 3, 3, '[1,2]')], 0, 5, '[1,2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_

# Generated at 2022-06-12 16:10:23.953027
# Unit test for function tokenize_json
def test_tokenize_json():
    # Successful parse.
    token = tokenize_json('initial')
    assert isinstance(token, ScalarToken)
    assert token.value == 'initial'
    assert token.start_pos == (1, 1, 0)
    assert token.end_pos == (1, 1, 7)

    # Failed parse.
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{')
    assert exc_info.value.code == 'parse_error'
    assert exc_info.value.position == Position(column_no=1, line_no=1, char_index=0)
    assert exc_info.value.text == 'Expecting property name enclosed in double quotes.'

    # Empty content.
    with pytest.raises(ParseError) as exc_info:
        token

# Generated at 2022-06-12 16:10:33.683799
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": 1}') == DictToken({'a': 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8, '[1, 2, 3]')
    assert tokenize_json('[]') == ListToken([], 0, 2, '[]')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 5, 'false')

# Generated at 2022-06-12 16:11:01.602646
# Unit test for function tokenize_json
def test_tokenize_json():
    assert validate_json('{"a": "b"}', {"a": "string"})[0] == {"a": "b"}
    assert validate_json('{"a": 1}', {"a": "integer"})[0] == {"a": 1}
    assert validate_json('{"a": 1.0}', {"a": "number"})[0] == {"a": 1.0}
    assert validate_json('{"a": true}', {"a": "boolean"})[0] == {"a": True}
    assert validate_json('{"a": [1,2,3]}', {"a": "list"})[0] == {"a": [1,2,3]}
    assert validate_json('{"a": [1,2,3]}', {"a": "list<integer>"})[0] == {"a": [1,2,3]}
   

# Generated at 2022-06-12 16:11:11.269939
# Unit test for function tokenize_json
def test_tokenize_json():
    # Given
    content = '{"key1": "value1", "key2": "value2", "key3": "value3", "key4": []}'