

# Generated at 2022-06-12 16:01:53.729953
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Basic unit tests for tokenizing JSON input.
    """
    # valid JSON
    assert tokenize_json('{"a": 5}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 5}'): ScalarToken(5, 6, 7, '{"a": 5}')},
        0,
        9,
        '{"a": 5}',
    )

    # invalid JSON
    with pytest.raises(
        ParseError, match=r"No content\. \(line: 1, column: 1, char: 0\)"
    ):
        assert tokenize_json("")


# Generated at 2022-06-12 16:02:04.220434
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:02:15.268030
# Unit test for function tokenize_json
def test_tokenize_json():
    tokens = tokenize_json("""
    {
      "simple_str": "Foo",
      "simple_bool": true,
      "simple_int": 1,
      "simple_float": 1.0,
      "simple_null": null,
      "simple_list": [1, 2, 3],
      "simple_dict": {
        "alpha": "foo",
        "beta": "bar"
      },
      "nested_dict": {
        "nested_list": [
          2,
          3
        ]
      }
    }
    """)

# Generated at 2022-06-12 16:02:23.884429
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{\"key\":\"value\"}")
    if not isinstance(token,DictToken):
        raise AssertionError("TypeError: not a dict")
    key, value = list(token.value.items())[0]
    if not isinstance(key, ScalarToken):
        raise AssertionError("TypeError: not a ScalarToken")
    if not isinstance(value, ScalarToken):
        raise AssertionError("TypeError: not a ScalarToken")
    if key.value != "key":
        raise AssertionError("no key: %s", str(key.value))
    if value.value != "value":
        raise AssertionError("no value: %s", str(value.value))
    if token.start_pos != 0:
        raise Assertion

# Generated at 2022-06-12 16:02:28.717998
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This function only runs the unit test for content-agnostic errors. Because
    the JSON parser used in normal execution does not distinguish between an
    empty string and an empty dict this test case does not bother either.
    """
    assert tokenize_json("a") == ScalarToken("a", 0, 0, "a")


# Unit tests for function validate_json

# Generated at 2022-06-12 16:02:38.911052
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ScalarToken, ListToken
    from typesystem.tokenize.positional_validation import parse
    # type: ignore

# Generated at 2022-06-12 16:02:40.529803
# Unit test for function tokenize_json
def test_tokenize_json():
    dummy = {}
    decoder = _TokenizingDecoder(content=dummy)
    (value, end) = decoder.parse_object(('{}', 0), True, decoder.scan_once, dummy, dummy)
    assert value == {}
    assert end == 2



# Generated at 2022-06-12 16:02:44.394079
# Unit test for function tokenize_json
def test_tokenize_json():
    # Declaring the content to be parsed
    content = """
    {
        "name": {
            "first": "John",
            "last": "Doe"
        },
        "children": [
            {
                "name": {
                    "first": "Jane",
                    "last": "Doe"
                },
                "age": 10,
                "birthday": "2010-09-28"
            }
        ]
    }
    """
    # Parsing the content to a token
    token = tokenize_json(content)
    # Displaying the type and value of the token
    print("Type:", type(token))
    print("Value:", token)

    # Expected output:
    # Type: <class 'typesystem.tokenize.tokens.DictToken'>
    # Value: Ordered

# Generated at 2022-06-12 16:02:54.674803
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{
        "name": "john",
        "age": 30,
        "address": {
            "street": "123 Main St.",
            "city": "San Francisco"
        }
    }""")

    assert token.validate_type("object")
    assert token.value["name"].value == "john"
    assert token.value["address"].value["city"].value == "San Francisco"

    # Test a parse error.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("""{
            "name": "john",
            "age": 30,
            "address": {
                "street": "123 Main St.",
                "city": "San Francisco",
            }
        }""")

# Generated at 2022-06-12 16:02:57.264781
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('["hello world"]') == ListToken([ScalarToken("hello world",2,15,'["hello world"]')],0,16,'["hello world"]')



# Generated at 2022-06-12 16:03:11.345804
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"foo":"bar"}'
    res = tokenize_json(content)
    assert isinstance(res, dict)
    assert res["foo"] == "bar"
    # invalid JSON
    content_bad = b'{"foo":}'
    try:
        res = tokenize_json(content_bad)
    except ParseError:
        pass



# Generated at 2022-06-12 16:03:13.575558
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert token.value == {"foo": "bar"}


# Generated at 2022-06-12 16:03:16.111610
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json = '{"name": "pratik"}'
    assert type(tokenize_json(input_json)) == DictToken

# Generated at 2022-06-12 16:03:21.276735
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    assert tokenize_json("") == None
    # Parse error
    try:
        tokenize_json("{")
        assert False, "Did not raise ParseError"
    except ParseError:
        pass
    # Parse and Validation Error
    assert validate_json("{}", Field(type="string")) == (None, [ValidationError(code='type', text='Must be of type string.')])
    # Valid JSON
    assert tokenize_json("null") == ScalarToken(value=None, start=0, end=3, content="null")

# Generated at 2022-06-12 16:03:30.897184
# Unit test for function tokenize_json
def test_tokenize_json():
    # parse json string
    data = """{
            "name": "WoC",
            "age": 20,
            "isMale": true
        }"""
    ret = tokenize_json(data)
    assert(ret.dict_value["name"].scalar_value=="WoC")
    assert (ret.dict_value["age"].scalar_value == 20)
    assert (ret.dict_value["isMale"].scalar_value == True)    
    
    #parse empty string
    data = ""
    try: 
        tokenize_json(data)
    except ParseError as err:
        assert(err.text =="No content.")
        assert(err.code =="no_content")
        assert(err.position.column_no ==1 )

# Generated at 2022-06-12 16:03:40.387774
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unit testing for function tokenize_json
    """
    def get_liminal_values(
        token: Token, liminal_values: typing.List[int]
    ) -> typing.List[int]:
        if isinstance(token, ScalarToken):
            liminal_values.append(token.start)
            liminal_values.append(token.stop)
        elif isinstance(token, ListToken):
            liminal_values.append(token.start)
            liminal_values.append(token.stop)
            for sub_token in token.value:
                get_liminal_values(sub_token, liminal_values)
        elif isinstance(token, DictToken):
            liminal_values.append(token.start)
            liminal_values.append(token.stop)

# Generated at 2022-06-12 16:03:47.471768
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key" : "value", "key1" : [1, 2, 3]}'
    d = tokenize_json(content)
    assert type(d) == DictToken
    assert d.children.items() == {'key': ScalarToken('value', 10, 17, content), 'key1': ListToken([
        ScalarToken(1, 27, 28, content), ScalarToken(2, 30, 31, content), ScalarToken(3, 33, 34, content)], 26, 35, content)}



# Generated at 2022-06-12 16:03:57.360152
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({})
    assert tokenize_json("{\"hello\": [null, 1, false]}") == DictToken(
        {"hello": ListToken([ScalarToken(None), ScalarToken(1), ScalarToken(False)])}
    )
    assert tokenize_json('{"hello": "world", "foo": "bar"}') == DictToken(
        {"hello": ScalarToken("world"), "foo": ScalarToken("bar")}
    )
    assert tokenize_json('{ "hello": "world", "foo": "bar" }') == DictToken(
        {"hello": ScalarToken("world"), "foo": ScalarToken("bar")}
    )
    assert tokenize_json('{"hello": "world", "foo": "bar"} ') == D

# Generated at 2022-06-12 16:04:09.039943
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json('{"foo": [1, 2, 3]}'), DictToken)
    assert isinstance(tokenize_json("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_json("1"), ScalarToken)
    assert isinstance(tokenize_json("1.0"), ScalarToken)
    assert isinstance(tokenize_json("true"), ScalarToken)
    assert isinstance(tokenize_json("false"), ScalarToken)
    assert isinstance(tokenize_json("null"), ScalarToken)
    assert isinstance(tokenize_json("\"foo\""), ScalarToken)
    with pytest.raises(ParseError):
        tokenize_json("{1}")

# Generated at 2022-06-12 16:04:20.191145
# Unit test for function tokenize_json
def test_tokenize_json():
    def _compare_token_contents(token: Token, dict_contents: dict):
        assert (
            token.type == dict_contents["type"]
            and token.value == dict_contents["value"]
            and token.start == dict_contents["start"]
            and token.end == dict_contents["end"]
        )
        if dict_contents["type"] == "DictToken":
            assert len(token.value) == len(dict_contents["value"])
            for key, my_sub_token in token.value.items():
                _compare_token_contents(
                    my_sub_token, dict_contents["value"][key]
                )

# Generated at 2022-06-12 16:04:32.832673
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "b"}')
    assert token.type == Token.DICT
    assert token.value == {"a": "b"}

    token = tokenize_json('{"a": ["c", "d"]}')
    assert token.type == Token.DICT
    assert token.value == {"a": ["c", "d"]}

    token = tokenize_json('{"a": ["c", 123]}')
    assert token.type == Token.DICT
    assert token.value == {"a": ["c", 123]}

    token = tokenize_json('["a", "b"]')
    assert token.type == Token.LIST
    assert token.value == ["a", "b"]

    token = tokenize_json('123')
    assert token.type == Token.SCALAR
    assert token.value

# Generated at 2022-06-12 16:04:41.993566
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = """
    {
        "my_array": [
            "first",
            "second",
            "third"
        ],
        "my_dict": {
            "a": "b",
            "c": "d"
        }
    }
    """
    token = tokenize_json(json_content)
    assert token.get("my_array")[0].value == "first"
    assert token.get("my_array")[1].value == "second"
    assert token.get("my_array")[2].value == "third"
    assert token.get("my_dict").get("a").value == "b"
    assert token.get("my_dict").get("c").value == "d"


# Generated at 2022-06-12 16:04:49.930633
# Unit test for function tokenize_json
def test_tokenize_json():
    t = tokenize_json(b'{"foo":{"bar":"baz","baz":{"bar":"baz"}}}')
    assert t.get("foo").get("bar").value == "baz"
    assert t.get("foo").get("baz").get("bar").value == "baz"

    with pytest.raises(ParseError) as exc:
        tokenize_json("")

    assert exc.value.code == "no_content"
    assert exc.value.text == "No content."
    assert exc.value.position == Position(column_no=1, line_no=1, char_index=0)

    with pytest.raises(ParseError) as exc:
        tokenize_json("{")

    assert exc.value.code == "parse_error"

# Generated at 2022-06-12 16:05:01.940709
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:05:07.553443
# Unit test for function tokenize_json
def test_tokenize_json():
    import sys
    import typesystem
    from typesystem.base import String

    from . import defs

    book = String(
        title = 'book',
        description = 'book title',
        max_length = 20
    )

    data = {
        "book": "ABC"
    }

    token = tokenize_json(defs.json)
    assert token.value['book'] == data['book']

# Generated at 2022-06-12 16:05:14.554233
# Unit test for function tokenize_json
def test_tokenize_json():
  with open("tests/test_data/tokenize_json/test_json.json") as file:
    assert tokenize_json(file.read()) == tokenize_json("tests/test_data/tokenize_json/test.token")
  with open("tests/test_data/tokenize_json/test_json2.json") as file:
    assert tokenize_json(file.read()) == tokenize_json("tests/test_data/tokenize_json/test2.token")


# Generated at 2022-06-12 16:05:20.656852
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({})
    assert tokenize_json("[]") == ListToken([])
    assert tokenize_json('{"foo": "bar"}') == DictToken({"foo": ScalarToken("bar")})
    assert tokenize_json("""{"foo": 42}""") == DictToken({"foo": ScalarToken(42)})



# Generated at 2022-06-12 16:05:29.447173
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == tokenize_json('{"a": 1}')
    assert tokenize_json('{"a": 1}') != tokenize_json('{"a": 2}')
    assert tokenize_json('[]') == tokenize_json('[]')
    assert tokenize_json('[]') != tokenize_json('[1, 2]')
    assert tokenize_json('"a"') == tokenize_json('"a"')
    assert tokenize_json('"a"') != tokenize_json('"b"')
    assert tokenize_json('1') == tokenize_json('1')
    assert tokenize_json('1') != tokenize_json('2')
    assert tokenize_json('true') == tokenize_json('true')
    assert tokenize_json('true')

# Generated at 2022-06-12 16:05:34.358024
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert len(token.value) == 1
    assert isinstance(token.value["key"], ListToken)
    assert len(token.value["key"].value) == 3
    assert token.value["key"].value[0].value == 1


# Generated at 2022-06-12 16:05:38.474993
# Unit test for function tokenize_json
def test_tokenize_json():
    expected_token = ScalarToken(True, 2, 30, '{"test": true}')
    token = tokenize_json('{"test": true}')
    assert isinstance(token, DictToken)
    assert token == {
        ScalarToken('test', 2, 8, '{"test": true}'): expected_token
    }



# Generated at 2022-06-12 16:05:56.948745
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"type": "dict", "required": ["name"], "properties": {"name": {"type": "string"}, "email": {"type": "string", "format": "email"}}}')
    expected = {
        'type': 'dict',
        'required': ['name'],
        'properties': {
            'name': {'type': 'string'},
            'email': {'type': 'string', 'format': 'email'}
        }
    }
    assert result == expected


# Generated at 2022-06-12 16:06:06.901080
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == None
    assert tokenize_json('{}') == DictToken({},0, 1, '{}')
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a',1,3, '{"a":1}'): ScalarToken(1,6,7,'{"a":1}')}, 0, 9, '{"a":1}')

# Generated at 2022-06-12 16:06:09.199858
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"name": "rob", "age": 23}'

    token = tokenize_json(json_string)

    assert isinstance(token, DictToken)
    assert token.value["name"] == "rob"



# Generated at 2022-06-12 16:06:16.289848
# Unit test for function tokenize_json
def test_tokenize_json():
    # tokenize valid json
    json_str = '{"id":"123","name":"John"}'
    assert type(tokenize_json(json_str)) == DictToken

    # tokenize invalid json
    false_json_str = '{"id":"123","name":"John"}'
    with pytest.raises(ParseError) as error:
        tokenize_json(false_json_str)
    expected_msg = Valida

# Generated at 2022-06-12 16:06:24.792903
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello": 1}')
    assert isinstance(token, DictToken)
    assert token == {'hello': ScalarToken(1, 8, 9, '{"hello": 1}')}
    assert token[0] == ScalarToken('hello', 1, 7, '{"hello": 1}')
    assert token[1] == ScalarToken(1, 8, 9, '{"hello": 1}')
    assert len(token) == 2
    assert token.start == 0
    assert token.end == 10
    assert token.content == '{"hello": 1}'

    token = tokenize_json('{"hello": 1}')
    for key, value in token.items():
        assert isinstance(key, ScalarToken)
        assert isinstance(value, ScalarToken)

# Generated at 2022-06-12 16:06:34.107166
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "John", "age": 30, "cars": [{"model":"Ford", "vin":"asdadasd"}, {"model":"BMW", "vin":"sadasdasdas"}]}')
    assert token.type == 'Dict'
    assert token.items[0][0].value == 'name'
    assert token.items[0][1].value == 'John'
    assert token.items[1][0].value == 'age'
    assert token.items[1][1].value == 30
    assert token.items[2][0].value == 'cars'
    assert token.items[2][1].type == 'List'
    assert token.items[2][1].items[0].items[0][0].value == 'model'

# Generated at 2022-06-12 16:06:44.410244
# Unit test for function tokenize_json
def test_tokenize_json():
    example_json = """
    {
        "field_0": "foo",
        "field_1": 10,
        "field_2": {
            "field_3": [1, 2, 3]
        },
        "field_4": null
    }
    """

    token = tokenize_json(example_json)
    assert(token.dict["field_0"].value == "foo")
    assert(token.dict["field_1"].value == 10)
    assert(token.dict["field_4"].value == None)

    assert(token.dict["field_2"].dict["field_3"].list[2].value == 3)
    assert(token.dict["field_2"].dict["field_3"].list[1].value == 2)

# Generated at 2022-06-12 16:06:50.117284
# Unit test for function tokenize_json
def test_tokenize_json():

    try:
        tokenize_json("{")
    except ParseError as e:
        assert e.position.column_no == 2
        assert e.position.line_no == 1
        assert e.position.char_index == 1
        assert e.code == "parse_error"

    try:
        tokenize_json("{}")
    except ParseError as e:
        assert e.position.column_no == 2
        assert e.position.line_no == 1
        assert e.position.char_index == 1
        assert e.code == "parse_error"

    try:
        tokenize_json("{\"a\"}")
    except ParseError as e:
        assert e.position.column_no == 5
        assert e.position.line_no == 1
        assert e.position.char_

# Generated at 2022-06-12 16:06:57.070385
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": null, "b": 1, "c": ["1", 2, 3]}'
    token = tokenize_json(content)
    value = token.value
    assert isinstance(value, dict)
    assert len(value) == 3
    assert value["a"] is None
    assert value["b"] == 1
    assert isinstance(value["c"], list)
    assert len(value["c"]) == 3
    assert value["c"][0] == "1"
    assert value["c"][1] == 2
    assert value["c"][2] == 3


# Generated at 2022-06-12 16:07:09.932375
# Unit test for function tokenize_json
def test_tokenize_json():
    data = '''{{
        "string": "string",
        "int": 1,
        "null": null,
        "true": false,
        "array": [1, 2, 3]
    }}'''

    actual = tokenize_json(data)

# Generated at 2022-06-12 16:07:29.218043
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str1 = '{"a": 1, "b": "2", "c":true, "d":false, "e":null}'
    json_str2 = """
        {
            "a": 1,
            "b": "2",
            "c":true,
            "d":false,
            "e":null
        }
    """
    tokens1 = tokenize_json(json_str1)
    tokens2 = tokenize_json(json_str2)
    assert tokens1.value == {
        'a': 1,
        'b': "2",
        'c': True,
        'd': False,
        'e': None
    }

# Generated at 2022-06-12 16:07:38.240167
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:07:40.775405
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token == [1, 2, 3]



# Generated at 2022-06-12 16:07:49.217139
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[]") == ListToken([])
    assert tokenize_json('{"a":"b"}') == DictToken({"a": "b"})
    assert tokenize_json('["a","b"]') == ListToken(["a", "b"])
    assert tokenize_json('{"a":"b","c":1}') == DictToken({"a": "b", "c": 1})

    assert tokenize_json('{"a": "b"}') == DictToken({"a": "b"})
    assert tokenize_json('{"a": "b", "c": 1}') == DictToken({"a": "b", "c": 1})

# Generated at 2022-06-12 16:07:56.379940
# Unit test for function tokenize_json
def test_tokenize_json():
    with open(os.path.join(os.path.dirname(__file__), "data/people.json")) as f:
        content = f.read()
    token = tokenize_json(content)

    # Number of tokens
    assert len(token.value) == 3

    # First name
    assert token.value[0][0].value == "firstName"
    assert token.value[0][1].value == "John"

    # Last name
    assert token.value[1][0].value == "lastName"
    assert token.value[1][1].value == "Smith"

    # Age
    assert token.value[2][0].value == "age"
    assert token.value[2][1].value == 25



# Generated at 2022-06-12 16:08:07.010885
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import random
    import string
    import sys

    test_strings = [
        b"null",
        b"true",
        b"false",
        b"\"hello world\"",
        b"0",
        b"1",
        b"-1",
        b"3.14159",
        b"0.0",
        b"-123.45e+6",
        b"{}",
        b"[]",
    ]

    def random_dict(length):
        items = {}
        for i in range(length):
            items["".join(random.choice(string.ascii_letters) for _ in range(5))] = random.random()
        return json.dumps(items)

    def random_list(length):
        items = []

# Generated at 2022-06-12 16:08:14.471820
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"name":"John Doe","email":"john@example.com","age":35,"high_score":99.9,"last_seen":["/home/john","/home/john/games/pong.exe"]}')
    assert result.type_name == "dict" and result.children['age'].type_name == "int" and result.children['age'].value == 35 and result.children['name'].type_name == "str" and result.children['name'].value == "John Doe" and result.children['email'].type_name == "str" and result.children['email'].value == "john@example.com" and result.children['high_score'].type_name == "float" and result.children['high_score'].value == 99.9 and result.children['last_seen'].children

# Generated at 2022-06-12 16:08:18.161232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 3, 7, '{"a": "b"}')}, 0, 10, '{"a": "b"}')



# Generated at 2022-06-12 16:08:28.458078
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json('10.1') == ScalarToken(10.1, 0, 4, '10.1')
    assert tokenize_json('10') == ScalarToken(10, 0, 2, '10')
    assert tokenize_json('{"a": "foo", "b": "bar"}') == DictToken({"a": ScalarToken("foo", 5, 10, '"foo"'), "b": ScalarToken("bar", 15, 20, '"bar"')}, 0, 24, '{"a": "foo", "b": "bar"}')

# Generated at 2022-06-12 16:08:39.119471
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)

    token = tokenize_json("[]")
    assert isinstance(token, ListToken)

    token = tokenize_json("[{}]")
    assert isinstance(token, ListToken)
    assert isinstance(token[0], DictToken)

    token = tokenize_json("[null]")
    assert isinstance(token, ListToken)
    assert isinstance(token[0], ScalarToken)
    assert token[0].value is None

    token = tokenize_json("[true]")
    assert isinstance(token, ListToken)
    assert isinstance(token[0], ScalarToken)
    assert token[0].value is True

    token = tokenize_json("[false]")

# Generated at 2022-06-12 16:08:56.112513
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
      "id": "[a-1]",
      "name": "Some name",
      "keywords": ["foo", "bar"],
      "related": {
        "id": "b-2",
        "name": "Other name"
      }
    }
    """

    token = tokenize_json(content)
    assert token.content == content.strip()
    assert token.pos.column_no == 1
    assert token.pos.line_no == 1
    assert token.end.column_no == 1
    assert token.end.line_no == 14
    assert token["id"].content.text == "[a-1]"
    assert token["id"].pos.column_no == 10
    assert token["id"].pos.line_no == 3
    assert token["id"].end

# Generated at 2022-06-12 16:09:02.137383
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"field1": "value1", "field2": "value2"}'
    token = tokenize_json(content)
    assert token.dict == {'field1': 'value1', 'field2': 'value2'}
    assert token.position.line_no == 1
    assert token.position.column_no == 1
    assert token.position.char_index == 0


# Generated at 2022-06-12 16:09:03.282480
# Unit test for function tokenize_json
def test_tokenize_json():
    # TODO: write test
    pass

# Generated at 2022-06-12 16:09:13.095687
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"key-1": "value_1", "key_2": "value-2"}'
    json_tokens = tokenize_json(json_string)
    assert isinstance(json_tokens, Token)
    assert isinstance(json_tokens, DictToken)
    assert isinstance(list(json_tokens.values())[0], Token)
    assert isinstance(list(json_tokens.values())[0], ScalarToken)
    assert list(json_tokens.values())[0].value == "value_1"
    assert isinstance(list(json_tokens.values())[1], Token)
    assert isinstance(list(json_tokens.values())[1], ScalarToken)

# Generated at 2022-06-12 16:09:15.410897
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (DictToken({}, 0, 0, "")) == tokenize_json("{}")


# Generated at 2022-06-12 16:09:23.930665
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token

    token = tokenize_json('[{ "a": 1, "b": [1,2,3] }]')
    assert isinstance(token, ListToken)
    assert token.start == 0
    assert token.end == len('[{ "a": 1, "b": [1,2,3] }]')
    assert token.value[0].start == 1
    assert token.value[0].end == len('{ "a": 1, "b": [1,2,3] }')
    assert token.value[0].value['a'].start == 3
    assert token.value[0].value['a'].end == 5
    assert token.value[0].value['a'].value == 1
    assert token.value[0].value['b'].start

# Generated at 2022-06-12 16:09:34.915068
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test actual failure cases
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")

    assert exc_info.value.text == "No content."
    assert exc_info.value.position == Position(
        char_index=0, line_no=1, column_no=1
    )
    assert exc_info.value.code == "no_content"

    with pytest.raises(ParseError) as exc_info:
        tokenize_json("{")

    assert exc_info.value.text == 'Expecting property name enclosed in double quotes.'
    assert exc_info.value.position == Position(
        char_index=1, line_no=1, column_no=2
    )
    assert exc_info.value.code == "parse_error"

   

# Generated at 2022-06-12 16:09:45.957877
# Unit test for function tokenize_json
def test_tokenize_json():
    content="""{
   "firstName": "John",
   "lastName": "Smith",
   "age": 25,
   "address": {
     "streetAddress": "21 2nd Street",
     "city": "New York",
     "state": "NY",
     "postalCode": "10021"
   },
   "phoneNumbers": [
     {
       "type": "home",
       "number": "212 555-1234"
     },
     {
       "type": "fax",
       "number": "646 555-4567"
     }
   ]
}
"""
    token = tokenize_json(content)
    assert type(token) is DictToken
    assert token.start is not None
    assert token.end is not None
    assert token.value is not None

# Generated at 2022-06-12 16:09:52.647529
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid json
    assert tokenize_json("{}") == DictToken(value={}, start_pos=0, end_pos=1, content="{}")
    # Test invalid json
    try:
        tokenize_json("{,}")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position == Position(line_no=1, column_no=2, char_index=1)

if __name__ == "__main__":
    test_tokenize_json()

# Generated at 2022-06-12 16:10:04.177567
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert isinstance(token, DictToken) and token.value == {"a": 1}

    token = tokenize_json('[{"a": 1}]')
    assert isinstance(token, ListToken) and [t.value for t in token.value] == [{"a": 1}]

    token = tokenize_json('{"a":1,"b":2,"c":3,"d":4}')
    assert isinstance(token, DictToken) and token.value == {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }

    token = tokenize_json('{"a":"1","b":[2,3],"c":4}')
    assert isinstance(token, DictToken) and token

# Generated at 2022-06-12 16:10:26.216450
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    { 
        "a": 1,
        "b": 2,
        "c": {
            "d": true,
            "e": false,
            "f": 3.2,
            "g": "hello"
        },
        "h": [
            "100",
            "200",
            "300"
        ],
        "i": null
    }
    """
    token = tokenize_json(content)
    assert token.kind == "dict"
    assert token.key == "a"
    assert token.start == Position(line_no=3, char_index=9, column_no=10)
    assert token.end == Position(line_no=10, char_index=60, column_no=9)
    assert token.children[0].kind == "dict"
   

# Generated at 2022-06-12 16:10:32.801636
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[1, 2, 3]'
    tokens = [
        ScalarToken(1, 1, 1, '[1, 2, 3]'),
        ScalarToken(2, 4, 4, '[1, 2, 3]'),
        ScalarToken(3, 7, 7, '[1, 2, 3]'),
    ]
    assert tokenize_json(content) == ListToken(tokens, 0, 9, '[1, 2, 3]')



# Generated at 2022-06-12 16:10:37.867071
# Unit test for function tokenize_json
def test_tokenize_json():
    assert type(tokenize_json("[1, 2]")) is ListToken
    assert type(tokenize_json("{1: 2}")) is DictToken
    assert type(tokenize_json("null")) is ScalarToken
    assert type(tokenize_json("true")) is ScalarToken
    assert type(tokenize_json("false")) is ScalarToken

    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token.as_dict() == {"foo": "bar"}
    assert token.text == content
    assert token.is_dict()
    assert not token.is_scalar()
    assert not token.is_list()
    assert token["foo"].text == "bar"

    content = '["foo", "bar"]'

# Generated at 2022-06-12 16:10:48.496716
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": [1,2,3]}') == DictToken(value={'a': ListToken(value=[ScalarToken(value=1, position_start=6, position_end=6, content='{"a": [1,2,3]}'), ScalarToken(value=2, position_start=8, position_end=8, content='{"a": [1,2,3]}'), ScalarToken(value=3, position_start=10, position_end=10, content='{"a": [1,2,3]}')], position_start=5, position_end=11, content='{"a": [1,2,3]}')}, position_start=0, position_end=13, content='{"a": [1,2,3]}')



# Generated at 2022-06-12 16:10:55.583554
# Unit test for function tokenize_json
def test_tokenize_json():
    test_data = {
        "a": "b",
        "c": [{"d": "e"}],
        "f": {"g": [1, "2", 3.2, True, None, {"h": "i"}, [1, "2", 3.2, True, None]]},
    }
    content = json.dumps(test_data, sort_keys=True)
    token = tokenize_json(content)
    assert token.value == test_data



# Generated at 2022-06-12 16:11:03.796260
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"f1": "v1"}'
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert token.keys() == [ScalarToken('f1', 0, 2, json_string)]
    assert isinstance(token.keys()[0], ScalarToken)
    assert token.values() == [ScalarToken('v1', 6, 8, json_string)]
    assert isinstance(token.values()[0], ScalarToken)
    assert token.key(0) == ScalarToken('f1', 0, 2, json_string)
    assert token.value(0) == ScalarToken('v1', 6, 8, json_string)

# Generated at 2022-06-12 16:11:12.357338
# Unit test for function tokenize_json
def test_tokenize_json():
    json_1='{"name":"jhon"}'
    json_2='{"name":"jhon", "role":"admin"}'
    json_3='{"name":"jhon", "role":"admin", "is_online":true}'
    json_4='{"name":"jhon", "role":"admin", "is_online":true, "is_online":false}'
    tokens_1 = tokenize_json(json_1)
    tokens_2 = tokenize_json(json_2)
    tokens_3 = tokenize_json(json_3)
    tokens_4 = tokenize_json(json_4)
    expected_1='dict{name=str<jhon>,}'
    expected_2='dict{name=str<jhon>, role=str<admin>,}'