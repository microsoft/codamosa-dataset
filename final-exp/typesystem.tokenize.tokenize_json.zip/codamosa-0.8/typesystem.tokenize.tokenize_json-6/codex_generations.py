

# Generated at 2022-06-12 16:01:53.190497
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that it can tokenize a JSON string
    """
    json_string = '{"integer": 10, "float": 5.25, "boolean": false, "null": null, "list": [1, 2, 3]}'
    json_tokens = tokenize_json(json_string)
    assert isinstance(json_tokens, DictToken)
    assert isinstance(json_tokens.value["integer"], ScalarToken)
    assert json_tokens.value["integer"].value == 10
    assert isinstance(json_tokens.value["float"], ScalarToken)
    assert json_tokens.value["float"].value == 5.25
    assert isinstance(json_tokens.value["boolean"], ScalarToken)

# Generated at 2022-06-12 16:02:03.391027
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_equal(value, expected):
        if expected != value:
            raise Exception("not equal. expected {}, found {}".format(expected, value))
    content = "{\"a\": 1, \"b\": 2}".encode("utf-8")
    assert isinstance(tokenize_json(content), DictToken)
    content = "{\"a\": 1, \"b\": 2}".encode("utf-8")
    assert_equal(len(tokenize_json(content).keys), 2)
    content = "{\"a\": 1, \"b\": 2}".encode("utf-8")
    assert_equal(tokenize_json(content).assignments[0].key, "a")
    content = "{\"a\": 1, \"b\": 2}".encode("utf-8")

# Generated at 2022-06-12 16:02:14.675793
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar", "baz": [0, 1, 2]}') == DictToken({}, 0, 32, '{"foo": "bar", "baz": [0, 1, 2]}')
    assert tokenize_json('{"a": [3, {"b": null}]}') == DictToken({}, 0, 23, '{"a": [3, {"b": null}]}')
    assert tokenize_json('{"a": [3, {"b": null}]}') == DictToken({}, 0, 23, '{"a": [3, {"b": null}]}')
    assert tokenize_json('{"a": [3, {"b": null}]}') == DictToken({}, 0, 23, '{"a": [3, {"b": null}]}')

# Generated at 2022-06-12 16:02:21.850604
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for the simple string
    token = tokenize_json('{"Greetings": "Hello There"}')
    assert(token.value["Greetings"] == "Hello There")

    # Test for the array
    token = tokenize_json('{"Greetings": ["hello", "hi"]}')
    assert(token.value["Greetings"] == ["hello", "hi"])

    # Test for the nested array
    token = tokenize_json('{"Greetings": [["hello", "hi"], ["Bonjour", "Hola"]]}')
    assert(token.value["Greetings"] == [["hello", "hi"], ["Bonjour", "Hola"]])

# Generated at 2022-06-12 16:02:23.196791
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json(content='{"a": [1, 2, "c"]}')



# Generated at 2022-06-12 16:02:27.768885
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key1":1,"key2":"value"}')
    assert isinstance(token, DictToken)
    assert token.value == {"key1": 1, "key2": "value"}
    assert token.start_mark == 0
    assert token.end_mark == 25


# Generated at 2022-06-12 16:02:38.146393
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"key_1": "hello", "key_2": true, "key_3": [1, 2, 3, 4]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    expected = [
        ("key_1", ScalarToken("hello", 10, 19, content)),
        ("key_2", ScalarToken(True, 20, 25, content)),
        (
            "key_3",
            ListToken(
                [
                    ScalarToken(1, 28, 28, content),
                    ScalarToken(2, 29, 29, content),
                    ScalarToken(3, 30, 30, content),
                    ScalarToken(4, 31, 31, content),
                ],
                26,
                33,
                content,
            ),
        ),
    ]

# Generated at 2022-06-12 16:02:39.619282
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"foo": "bar"}'
    tokenize_json(content)


# Generated at 2022-06-12 16:02:45.781261
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid JSON
    json_str_1 = '''
        {
            "one": 1,
            "two": {
                "three": 3,
                "four": [ 1, 2, 3]
            }
        }
    '''

# Generated at 2022-06-12 16:02:46.623246
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key1":"value1"}') == {"key1": "value1"}



# Generated at 2022-06-12 16:02:59.717141
# Unit test for function tokenize_json
def test_tokenize_json():
    expected = {
        "foo": {"a": 1, "b": []},
        "bar": True,
        "baz": 43.2,
    }

    token = tokenize_json('{"foo":{"a":1,"b":[]},"bar":true,"baz":43.2}')
    assert token.value == expected

    # Handle case where JSON is empty.
    with pytest.raises(ParseError):
        token = tokenize_json("")



# Generated at 2022-06-12 16:03:01.506891
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    from typesystem.tokenize.tokens import DictToken

    token = tokenize_json('{"a": 42}')
    assert isinstance(token, DictToken)
    assert token["a"].value == 42
    assert token.to_json() == json.loads('{"a": 42}')

# Generated at 2022-06-12 16:03:06.732382
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads
    from typesystem.tokenize.tokens import Token

    result = tokenize_json('[{"a_key": "a_value", "another_key": "another_value"}]')
    assert result == ListToken([
        DictToken({
            ScalarToken('a_key'): ScalarToken('a_value'),
            ScalarToken('another_key'): ScalarToken('another_value')
        })
    ])

    result = tokenize_json('[1,2,3]')
    assert result == ListToken([ScalarToken(1), ScalarToken(2), ScalarToken(3)])
    
    result = tokenize_json('{"some_key": "some_value"}')

# Generated at 2022-06-12 16:03:17.627335
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello": "world"}')
    assert len(token.children) == 2
    assert token.children[0].value == "hello"
    assert token.children[1].value == "world"

    token = tokenize_json('{"hello": [1, 2, 3]}')
    assert len(token.children) == 2
    assert token.children[0].value == "hello"
    assert len(token.children[1].children) == 3
    assert token.children[1].children[0].value == 1

    token = tokenize_json('{"hello": ["world", ["foo", "bar"]]}')
    assert len(token.children) == 2
    assert token.children[0].value == "hello"
    assert len(token.children[1].children) == 2
    assert token.children

# Generated at 2022-06-12 16:03:28.861157
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken("foo", 1, 7, '{"foo": "bar"}'): ScalarToken("bar", 9, 17, '{"foo": "bar"}')}, 0, 18, '{"foo": "bar"}')
    assert tokenize_json('{"foo": ["bar"]}') == DictToken({ScalarToken("foo", 1, 7, '{"foo": ["bar"]}'): ListToken([ScalarToken("bar", 9, 15, '{"foo": ["bar"]}')], 8, 18, '{"foo": ["bar"]}')}, 0, 19, '{"foo": ["bar"]}')

# Generated at 2022-06-12 16:03:33.496875
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == {}, "Empty JSON string"
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}, "Valid JSON string"
    assert tokenize_json('{"foo": "bar"') == {}, "Invalid JSON, missing close bracket"


# Generated at 2022-06-12 16:03:42.048623
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tokenize a simple JSON value
    result = tokenize_json('{"foo": "bar"}') 
    assert isinstance(result, DictToken)
    
    # Tokenize a simple JSON string value
    result = tokenize_json('"foo"')
    assert isinstance(result, ScalarToken)
    
    # Tokenize a simple JSON list
    result = tokenize_json('[1,2,3]')
    assert isinstance(result, ListToken)
    
    # Tokenize a simple JSON int value
    result = tokenize_json('1234')
    assert isinstance(result, ScalarToken)
    
    # Ensure a ValueError is raised if there is no content 
    with pytest.raises(ParseError) as e:
        tokenize_json('  ')
        
    





# Generated at 2022-06-12 16:03:47.325702
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": [1, 2, 3]}'
    token = tokenize_json(content=content)
    assert type(token) == DictToken
    assert token.value == {'key': [1, 2, 3]}
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content



# Generated at 2022-06-12 16:03:54.003042
# Unit test for function tokenize_json
def test_tokenize_json():
    str_data = '{"key": "value"}'
    data = tokenize_json(str_data)
    assert isinstance(data, DictToken)
    assert isinstance(data.token_dict, dict)
    key = data.token_dict.keys()
    assert isinstance(key.__next__(), ScalarToken)
    assert next(key) is None
    value = data.token_dict.values()
    assert isinstance(value.__next__(), ScalarToken)
    assert next(value) is None



# Generated at 2022-06-12 16:03:56.128525
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == {'key': 'value'}
    assert tokenize_json('[4, 5, 6]') == [4, 5, 6]


# Generated at 2022-06-12 16:04:13.128642
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1}')}, 0, 6, '{"a": 1}'
    )

# Generated at 2022-06-12 16:04:21.508197
# Unit test for function tokenize_json
def test_tokenize_json():
    content_1 = '{"a":{"b": 1}}'
    content_2 = '["a",{"b":{"c": 1}}]'
    token_1 = tokenize_json(content_1)
    token_2 = tokenize_json(content_2)
    assert type(token_1) == DictToken
    assert token_1.value['a'].value['b'].value == 1
    assert type(token_2) == ListToken
    assert token_2.value[1].value['b'].value['c'].value == 1


# Generated at 2022-06-12 16:04:29.829954
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == {
        'a': 1
    }
    assert tokenize_json('{"a":"1"}') == {
        'a': "1"
    }
    with pytest.raises(ParseError):
        tokenize_json("{a: 1}")
    assert tokenize_json("[]") == []
    assert tokenize_json("[1,2,3]") == [1, 2, 3]
    with pytest.raises(ParseError):
        tokenize_json("[1,2,3")
    assert tokenize_json('{"a": 1, "b": 2}') == {
        'a': 1,
        'b': 2
    }

# Generated at 2022-06-12 16:04:39.068711
# Unit test for function tokenize_json
def test_tokenize_json():
    # single quote string
    content = '{"one": "Two"}'
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.value == {"one": "Two"}
    assert isinstance(list(token.value.keys())[0], ScalarToken)
    assert isinstance(list(token.value.values())[0], ScalarToken)

    # double quote string
    content = '{"one": "Two"}'
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.value == {"one": "Two"}

# Generated at 2022-06-12 16:04:48.565242
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "propA": [1, 2, 3],
        "propB": {
            "propB1": ["a", "b", "c"],
            "propB2": 123
        },
        "propC": {
            "propC1": ["a", "b", "c"],
            "propC2": "abcd"
        }
    }
    """
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert type(token.value["propA"]) == ListToken
    assert type(token.value["propB"]) == DictToken
    assert type(token.value["propB"].value["propB1"]) == ListToken
    assert type(token.value["propB"].value["propB2"]) == ScalarToken

# Generated at 2022-06-12 16:05:00.736333
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
        {
            "foo": "bar",
            "baz": 123,
            "qux": {
                "fizz": "buzz"
            },
            "quacks": [
                "duck",
                "goose"
            ]
        }
    """


# Generated at 2022-06-12 16:05:09.868720
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_token = tokenize_json(
        '[{"id": 1, "name": "item1" , "price": 100.0, "items":[{"id": "1-1", "name": "subitem1", "price": 200.0}]}, {"id": 2, "name": "item2" , "price": 100.0, "items":[{"id": "2-1", "name": "subitem2", "price": 200.0}]}]'
    )
    assert isinstance(dict_token, ListToken)
    for list_token_item in dict_token.value:
        assert isinstance(list_token_item, DictToken)
        assert isinstance(list_token_item.value["id"], ScalarToken)
        assert isinstance(list_token_item.value["name"], ScalarToken)
        assert isinstance

# Generated at 2022-06-12 16:05:20.085965
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""
      {
        "foo": [
          {
            "bar": "baz",
            "qux": true
          },
          {
            "bar": "quux",
            "qux": false
          }
        ]
      }
    """)

    assert isinstance(token, DictToken)
    assert token.key_pairs[0][0].value == "foo"
    assert isinstance(token.key_pairs[0][1], ListToken)
    assert token.key_pairs[0][1].items[0]["bar"].value == "baz"
    assert token.key_pairs[0][1].items[0]["qux"].value == True



# Generated at 2022-06-12 16:05:29.010928
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken("b", 6, 7, '{"a": "b"}')}, 0, 9, '{"a": "b"}')

# Generated at 2022-06-12 16:05:35.238813
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""
        {
            "key1": "value1",
            "key2": "value2"
        }
    """) == DictToken(
        {
            "key1": ScalarToken("value1", 17, 25, """
        {
            "key1": "value1",
            "key2": "value2"
        }
    """),
            "key2": ScalarToken("value2", 37, 45, """
        {
            "key1": "value1",
            "key2": "value2"
        }
    """),
        },
        0,
        50,
        """
        {
            "key1": "value1",
            "key2": "value2"
        }
    """,
    )


# Generated at 2022-06-12 16:05:45.991085
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({
        ScalarToken("foo", 1, 5, '{"foo": "bar"}'): ScalarToken("bar", 9, 15, '{"foo": "bar"}'),
    }, 1, 15, '{"foo": "bar"}')

# Generated at 2022-06-12 16:05:52.877255
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"json": ["list", "of", {"data": "types"}]}"""
    tokenized = tokenize_json(content)
    assert isinstance(tokenized, DictToken)
    assert tokenized.start_position == 0
    assert tokenized.end_position == len(content) - 1

    assert isinstance(tokenized.children["json"], ListToken)
    assert tokenized.children["json"].start_position == 6
    assert tokenized.children["json"].end_position == 43

    assert isinstance(tokenized.children["json"].children[0], ScalarToken)
    assert tokenized.children["json"].children[0].start_position == 8
    assert tokenized.children["json"].children[0].end_position == 12


# Generated at 2022-06-12 16:06:01.073381
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:10.358871
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken("foo", 2, 5, '{"foo": "bar"}'): ScalarToken("bar", 10, 15, '{"foo": "bar"}')}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json('["foo", "bar", "baz"]') == ListToken([ScalarToken("foo", 2, 6, '["foo", "bar", "baz"]'), ScalarToken("bar", 9, 13, '["foo", "bar", "baz"]'), ScalarToken("baz", 16, 20, '["foo", "bar", "baz"]')], 0, 21, '["foo", "bar", "baz"]')

# Generated at 2022-06-12 16:06:21.616043
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:32.679621
# Unit test for function tokenize_json

# Generated at 2022-06-12 16:06:39.560915
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4"}}'
    )
    assert token == DictToken(
        {
            "key1": ScalarToken("value1"),
            "key2": ScalarToken("value2"),
            "key3": DictToken({"key4": ScalarToken("value4")}),
        }
    )



# Generated at 2022-06-12 16:06:47.715525
# Unit test for function tokenize_json
def test_tokenize_json():

    content = {"foo": "bar", "baz": [{"hello": "world"}]}
    token = tokenize_json(content)

    # type(token) == typesystem.tokenize.tokens.DictToken
    assert token == token
    assert token.start == 0
    assert token.end == 36
    assert token.is_list is False
    assert token.value == {"foo": "bar", "baz": [{"hello": "world"}]}

    token = token[1]

    # type(token) == typesystem.tokenize.tokens.ListToken
    assert token == token
    assert token.start == 15
    assert token.end == 33
    assert token.is_list is True
    assert token.value == [{"hello": "world"}]

    token = token[0]

    # type(token

# Generated at 2022-06-12 16:06:57.462354
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json(
        '[1, "foo", true, false, null, {"a": "b"}, [-1, null], -2.5, 3e-1]'
    )

# Generated at 2022-06-12 16:07:10.204670
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.types import String
    from typesystem.unset import UNSET  # noqa: 401
    from typesystem.tokenize.tokens import ScalarToken, DictToken, ListToken
    
    # test with string as valid JSON
    content = '{"test": "string"}'

    token = tokenize_json(content)
    assert type(token) is DictToken, "tokenize_json should return a DictToken"
    assert token.value == {"test": "string"}, "tokenize_json should return the correct value"
    assert token.start == 0, "tokenize_json should return the correct start"
    assert token.end == len(content) - 1, "tokenize_json should return the correct end"
    assert token.content == content, "tokenize_json should return the correct content"

    # test

# Generated at 2022-06-12 16:07:18.584037
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")



# Generated at 2022-06-12 16:07:29.091475
# Unit test for function tokenize_json
def test_tokenize_json():
    # Check the expected behaviour of the function
    # to verify that it functions as intended.
    # Create a dictionary of test cases and
    # corresponding expect outputs.
    test_cases = dict()
    test_cases['simple_list_tokens'] = {
        'input':'[1, "apple", 3]',
        'output':[ScalarToken(1, 1, 2, "[1, \"apple\", 3]"), ScalarToken("apple", 5, 13, "[1, \"apple\", 3]"), ScalarToken(3, 16, 17, "[1, \"apple\", 3]")],
        'start': 1,
        'end': 19
    }

# Generated at 2022-06-12 16:07:38.241224
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test tokenizing a simple JSON string
    content = '{"name":"foo","age":12}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token) == 2

    # Test tokenizing a simple JSON string
    content = '{"name":"foo","age":12}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token) == 2

    # Test tokenizing an empty string
    content = ""
    with pytest.raises(ParseError):
        token = tokenize_json(content)

    # Test tokenizing a string with trailing whitespace
    content = '{"name":"foo","age":12}\n\n'
    token = tokenize_json(content)

# Generated at 2022-06-12 16:07:45.060695
# Unit test for function tokenize_json
def test_tokenize_json():
    json_data = '''
{
  "firstName": "John",
  "lastName": "Smith",
  "age": 25,
  "address": {
    "streetAddress": "21 2nd Street",
    "city": "New York",
    "state": "NY",
    "postalCode": "10021"
  },
  "phoneNumber": [
    {
      "type": "home",
      "number": "212 555-1234"
    },
    {
      "type": "fax",
      "number": "646 555-4567"
    }
  ]
}
'''
    token = tokenize_json(json_data)
    assert isinstance(token, Token)
    assert isinstance(token.value, dict)
    assert token.value['firstName'] == "John"

# Generated at 2022-06-12 16:07:53.486537
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import dumps
    from typesystem import field

    data = {
        "string": "a string",
        "number": 1,
        "boolean": True,
        "null": None,
        "dict": {"key": "value"},
        "list": [0, 1, 2, 3]
    }
    content = dumps(data)

    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.content == content

    # A text containing non-ASCII characters.
    content = '{"key": "Вася"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.content == content

    content = b"{}"
    token = tokenize_json(content)

# Generated at 2022-06-12 16:07:56.208042
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key":"value"}'
    token = tokenize_json(content)
    assert token.to_json() == content

# Generated at 2022-06-12 16:08:02.694455
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello" : "world"}')
    assert isinstance(token, DictToken)
    assert token.value == {
        ScalarToken("hello", start=1, end=6, content='{"hello" : "world"}'): ScalarToken(
            "world",
            start=10,
            end=16,
            content='{"hello" : "world"}',
        ),
    }
    



# Generated at 2022-06-12 16:08:11.577637
# Unit test for function tokenize_json
def test_tokenize_json():
    class PersonSchemaBase(Schema):
        name = "Person"

        name = String()
        age = Integer()

    class PersonSchema(PersonSchemaBase):
        pass

    class PersonSchema2(PersonSchemaBase):
        pass

    person_schema = PersonSchema()
    person_schema_2 = PersonSchema2()
    doc = """
    {
        "name": "Tom",
        "age": 12
    }
    """
    token = tokenize_json(doc)
    assert token.validate(person_schema)
    try:
        # assert False, "this is a test"
        token.validate(person_schema_2)
    except ValidationError as e:
        assert "Person" in str(e)
    print(token)

    # test with list

# Generated at 2022-06-12 16:08:17.415528
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key":"value","integer":1,"float":1.1,"null":null}'
    result = tokenize_json(content)

    def validate_string(value):
        if not isinstance(value, str):
            raise ValidationError('Expected a string')

    def validate_integer(value):
        if not isinstance(value, int):
            raise ValidationError('Expected an integer')

    def validate_float(value):
        if not isinstance(value, float):
            raise ValidationError('Expected a float')

    def validate_null(value):
        if value is not None:
            raise ValidationError('Expected a null value')

    class ItemSchema(Schema):
        key = Field(validate=validate_string)
        integer = Field(validate=validate_integer)

# Generated at 2022-06-12 16:08:28.080937
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
{
    "a": [1, 2, 3],
    "b": [
        {"a": 1},
        {"b": 2}
    ]
}
'''
    root_token = tokenize_json(content)
    assert isinstance(root_token, DictToken)
    assert root_token.value.keys() == {"a", "b"}
    a_list = root_token.value["a"]
    assert isinstance(a_list, ListToken)
    assert a_list.value == [ScalarToken(1, 29, 29, content), ScalarToken(2, 31, 31, content), ScalarToken(3, 33, 33, content)]
    b_list = root_token.value["b"]
    assert isinstance(b_list, ListToken)

# Generated at 2022-06-12 16:08:41.921899
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import typesystem.tokenize.positional_validation as tok

    sample_json = """
    {
        "foo": "bar",
        "baz": [1, 2, 3, 4],
        "qux": {"hello": "world"}
    }
    """
    token = tokenize_json(sample_json)

    def assert_token_found(token: tok.Token):
        assert token.position is not None

    def assert_token_not_found(token: tok.Token):
        assert token.position is None

    # Assert that the root token is found.
    assert_token_found(token)

    # Assert that the first key token is found.
    first_key_token = token.to_dict()["foo"]

# Generated at 2022-06-12 16:08:47.076773
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key1": "hello", "key2": "world", "key3": ["one", "two", "three"]}'
    t = tokenize_json(json_str)
    assert t == {'key1': 'hello', 'key2': 'world', 'key3': ['one', 'two', 'three']}


# Generated at 2022-06-12 16:08:56.086743
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{"a": 1}""")
    assert token.start_pos == 0
    assert token.end_pos == 7
    assert token.value == {"a": 1}
    assert isinstance(token, DictToken)
    assert token.children["a"].value == 1
    assert isinstance(token.children["a"], ScalarToken)

    token = tokenize_json('{"a": "Hello World!"}')
    assert token.start_pos == 0
    assert token.end_pos == 20
    assert token.value == {"a": "Hello World!"}
    assert isinstance(token, DictToken)
    assert token.children["a"].value == "Hello World!"
    assert isinstance(token.children["a"], ScalarToken)


# Generated at 2022-06-12 16:09:07.012033
# Unit test for function tokenize_json
def test_tokenize_json():
    example_schema = {
        "properties": {
            "favourite": {
                "properties": {
                    "color": {"type": "string"},
                    "number": {"type": "integer"},
                }
            }
        }
    }
    example = """
        {
            "favourite": {
                "color": "red",
                "number": 2
            }
        }
    """
    token = tokenize_json(example)
    assert isinstance(token, DictToken)
    assert token.value == {"favourite": {"color": "red", "number": 2}}

    schema = Schema(example_schema)
    try:
        schema.validate(token)
    except ValidationError as err:
        print(err.messages)

# Generated at 2022-06-12 16:09:11.342567
# Unit test for function tokenize_json
def test_tokenize_json():
   assert tokenize_json(' {"name":"Luke","surname":"Skywalker","height":192} ') == DictToken({'name': 'Luke', 'surname': 'Skywalker', 'height': 192}, 0, 50, ' {"name":"Luke","surname":"Skywalker","height":192} ')


# Generated at 2022-06-12 16:09:21.170125
# Unit test for function tokenize_json
def test_tokenize_json():
    data = tokenize_json(
        '[{"f1": "12", "f2": -12, "f3": {"f3-1": 1.2, "f3-2": [1, 2]}}]'
    )
    assert isinstance(data, ListToken)
    assert isinstance(data.value, list)
    assert len(data.value) == 1
    assert isinstance(data.value[0], DictToken)
    assert isinstance(data.value[0].value, dict)
    assert len(data.value[0].value) == 3

    assert "f1" in data.value[0].value
    assert isinstance(data.value[0].value["f1"], ScalarToken)
    assert data.value[0].value["f1"].value == "12"

    assert "f2"

# Generated at 2022-06-12 16:09:25.580853
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"foo": "bar"}"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.content == content
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.value == {"foo": "bar"}



# Generated at 2022-06-12 16:09:36.227517
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"firstname":"Taro","surname":"Yamada","age":23,"male":true,"address":{"postalcode":"105-0011","prefecture":"Tokyo","city":"Minato","town":"Konan","building":null}}'
    token = tokenize_json(content)

    def _equal(token, content, expected):
        assert repr(token) == expected

        if content is not None:
            assert token.token_content == content

    _equal(token, "Taro", "ScalarToken(content='%s')" % "Taro")
    _equal(token.value["firstname"], "Taro", "ScalarToken(content='%s')" % "Taro")

# Generated at 2022-06-12 16:09:38.177343
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-12 16:09:49.309900
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"abc": [{"def": 10, "ghi": "oranges"}, "apples"]}')
    list_token = token.value['abc']
    assert list_token.value[1].start == 42
    assert list_token.value[1].end == 48
    assert list_token.value[1].value == 'apples'
    assert list_token.start == 22
    assert list_token.end == 53
    dict_token = token.value['abc'].value[0]
    assert dict_token.value['def'].start == 28
    assert dict_token.value['def'].end == 31
    assert dict_token.value['def'].value == 10
    assert dict_token.value['ghi'].start == 33

# Generated at 2022-06-12 16:10:05.500336
# Unit test for function tokenize_json
def test_tokenize_json():
    content1 = '{ "foo":"bar" }'
    content2 = '{ "foo":1, "baz":[2, 3] }'

    token1 = tokenize_json(content1)
    assert token1 == \
        DictToken({
            ScalarToken("foo", 2, 6, content1): ScalarToken("bar", 9, 13, content1)
        }, 0, 16, content1
        )
    token2 = tokenize_json(content2)

# Generated at 2022-06-12 16:10:15.677918
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {
    "$schema": "https://json-schema.org/draft/2019-09/schema#",
    "$id": "http://example.com/product.schema.json",
    "title": "Product",
    "description": "A product from Acme's catalog",
    "type": "object",
    "properties": {
        "productId": {
            "description": "The unique identifier for a product",
            "type": "integer"
        }
    },
    "required": ["productId"]
    }

# Generated at 2022-06-12 16:10:26.499318
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1,"b":2,"c":[1,2,3]}') == {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    assert tokenize_json('{"a":1,"b":2,"c":[1,2,3]') == {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    assert tokenize_json('{"a":1, "b":2, "c":2}') == {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    assert tokenize_json('{"a":1, "b":2, "c":[1,2,3]') == {'a': 1, 'b': 2, 'c': [1, 2, 3]}

# Generated at 2022-06-12 16:10:36.216827
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({"key": ScalarToken("value", 2, 17, '{"key": "value"}')}, 0, 18, '{"key": "value"}')
    assert tokenize_json('{"key": "value"}'), DictToken({"key": ScalarToken("value", 2, 17, '{"key": "value"}')}, 0, 18, '{"key": "value"}')

# Generated at 2022-06-12 16:10:41.653978
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tests that tokenize_json
    1. returns a Token object on valid input
    2. returns a ParseError object on invalid input
    """
    input_str = "{\"name\": \"John\", \"age\": 30 }"
    returned_obj = tokenize_json(input_str)
    assert isinstance(returned_obj, Token)
    input_str = "{{name: \"John\", age: 30 }"
    with pytest.raises(ParseError):
        tokenize_json(input_str)


# Generated at 2022-06-12 16:10:48.163409
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        """
        {
            "something": [
                {
                    "value": 1
                },
                {
                    "value": 2
                }
            ]
        }
    """
    )
    assert isinstance(token, DictToken)
    assert token.value["something"].value[0].value["value"].value == 1
    assert token.value["something"].value[1].value["value"].value == 2

# Generated at 2022-06-12 16:10:56.400333
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "field": [
            "a",
            "b",
            "c"
        ]
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"field": ["a", "b", "c"]}
    assert token.start_position.line_no == 2
    assert token.start_position.column_no == 9
    assert token.end_position.line_no == 6
    assert token.end_position.column_no == 5

# Generated at 2022-06-12 16:11:00.729823
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json = '{"age": "20", "name": "alice"}'
    d = tokenize_json(input_json)
    test_json_schema = {"properties": {"age": {"type": "string"},
                                       "name": {"type": "string"}}}
    json_validator = Field(json_schema=test_json_schema)
    json_validator.validate(d)
    assert isinstance(d, DictToken)
    assert d.value["name"].value == "alice"
    assert d.value["age"].value == "20"



# Generated at 2022-06-12 16:11:05.630428
# Unit test for function tokenize_json
def test_tokenize_json():
    content = json.dumps({
                "name": {
                    "first_name": "Jane",
                    "last_name": "Doe"
                },
                "age": 25
            })
    token = tokenize_json(content)
    assert isinstance(token, DictToken)


# Generated at 2022-06-12 16:11:11.390438
# Unit test for function tokenize_json
def test_tokenize_json():
    # Good cases
    assert tokenize_json('{"a": 1}') == DictToken({'a': 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": [1, 2, 3]}') == DictToken({'a': [1, 2, 3]}, 0, 12, '{"a": [1, 2, 3]}')
    assert tokenize_json('[1, 2, 3]') == ListToken([1, 2, 3], 0, 7, '[1, 2, 3]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')