

# Generated at 2022-06-26 10:42:04.069892
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{\"name\": \"example\", \"foo\": [1, 2, 3]}"
    expected = {
        "name": "example",
        "foo": [1, 2, 3],
    }
    assert tokenize_json(content) == expected


# Generated at 2022-06-26 10:42:05.485649
# Unit test for function tokenize_json
def test_tokenize_json():
    pass



# Generated at 2022-06-26 10:42:11.537054
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case for function tokenize_json
    # Verify that tokenizer fails on empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        # Expect failure due to parse error on empty string
        assert exc.code == "parse_error"
    else:
        assert False, "Empty string should cause parse error"
    # Verify that tokenizer fails on junk string
    try:
        tokenize_json("dfsd")
    except ParseError as exc:
        # Expect failure due to parse error
        assert exc.code == "parse_error"
    else:
        assert False, "Junk string should cause parse error"


# Generated at 2022-06-26 10:42:21.218583
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "{"
    exc_0 = ParseError(code="parse_error", position=Position(line_no=1, column_no=1, char_index=1), text="Expecting property name enclosed in double quotes.")
    try:
        tokenize_json(content_0)
        assert False
    except ParseError as exc:
        assert (exc.code == exc_0.code and exc.text == exc_0.text and exc.position == exc_0.position)
    content_1 = ""
    exc_1 = ParseError(code="no_content", position=Position(line_no=1, column_no=1, char_index=0), text="No content.")

# Generated at 2022-06-26 10:42:32.824371
# Unit test for function tokenize_json
def test_tokenize_json():
    # No content
    try:
        assert (tokenize_json(""))
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        raise AssertionError("Expected a ParseError to be raised.")

    # Empty JSON string
    assert tokenize_json('""') == ""

    # Empty JSON object
    assert tokenize_json("{}") == {}

    # Empty JSON array
    assert tokenize_json("[]") == []

    # Valid JSON string
    assert tokenize_json('"Hello, world!"') == "Hello, world!"

    # Valid JSON object

# Generated at 2022-06-26 10:42:36.775996
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    test_input_0 = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    expected_0 = json.loads(test_input_0)
    actual_0 = tokenize_json(test_input_0)
    assert actual_0 == expected_0

# Generated at 2022-06-26 10:42:44.254043
# Unit test for function tokenize_json
def test_tokenize_json():
    json_text_0 = "[]"
    token_0 = tokenizing_decoder_0.decode(json_text_0)
    json_text_1 = "{}"
    token_1 = tokenizing_decoder_0.decode(json_text_1)
    json_text_2 = "{\"key_0\": \"value_0\"}"
    token_2 = tokenizing_decoder_0.decode(json_text_2)
    json_text_3 = "[{\"key_0\": \"value_0\"}]"
    token_3 = tokenizing_decoder_0.decode(json_text_3)
    json_text_4 = "[{\"key_0\": \"value_0\"}, {\"key_1\": \"value_1\"}]"
    token_4 = tokenizing_decoder_

# Generated at 2022-06-26 10:42:55.851302
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string: The json parser does not support empty strings, so this test
    # should raise a ParseError.
    try:
        tokenize_json("")
        assert False, "Should have raised a ParseError."
    except ParseError as ex:
        assert ex.text == "No content.", "Expected a different error message string."
        assert (
            ex.code == "no_content"
        ), "Expected a different error code, {}.".format(ex.code)
        assert (
            ex.position.line_no == 1
            and ex.position.column_no == 1
            and ex.position.char_index == 0
        ), "Expected a different position: {}".format(ex.position)

# Generated at 2022-06-26 10:43:00.791715
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = b"abc"
    exc_0 = ParseError(
        text="Expecting value",
        code="parse_error",
        position=Position(column_no=1, line_no=1, char_index=1),
    )

    with pytest.raises(ParseError, match=str(exc_0)):
        tokenize_json(content_0)

# Generated at 2022-06-26 10:43:14.614208
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "[{\"name\": \"Bob\", \"age\": 22 }, {\"name\": \"Tom\", \"age\": 33 }]"
    result = tokenize_json(content)
    assert isinstance(result, ListToken)

    content = "{\"name\": \"Bob\", \"age\": 22}"
    result = tokenize_json(content)
    assert isinstance(result, DictToken)

    content = "[22, 33, 44]"
    result = tokenize_json(content)
    assert isinstance(result, ListToken)

    content = "{\"names\": [\"Bob\", \"Tom\"]}"
    result = tokenize_json(content)
    assert isinstance(result, DictToken)


# Generated at 2022-06-26 10:43:46.186404
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = '{"a": 1}'
    token = tokenize_json(valid_json)
    assert token.value == {'a': 1}

    # Test `colno`
    invalid_json_1 = '{"a": 1'
    try:
        token = tokenize_json(invalid_json_1)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 7
        assert exc.position.char_index == 6
    else:
        raise RuntimeError('Expected parse error, got: {}'.format(token))

    # Test `lineno`
    invalid_json_2 = '{"a": 1\r'

# Generated at 2022-06-26 10:43:55.358183
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test 1
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 9, '{"a": 1}'
    )
    # Test 2
    try:
        tokenize_json(b'{"a": 1}')
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.code == "parse_error"
        assert exc.text == 'Expecting value'.replace('"', '\\"')
    else:
        assert False, "Did not raise ParseError"
    # Test 3

# Generated at 2022-06-26 10:44:08.218291
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test the case where the content is not a string.
    content = b""
    try:
        raise ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))
    except ParseError as e:
        assert e.text == "No content.", e.text
    except ParseError as e:
        assert e.text == "No content.", e.text
    except ParseError as e:
        assert e.text == "No content.", e.text

    # Test the case where the content is a string.
    content = " "

# Generated at 2022-06-26 10:44:19.505322
# Unit test for function tokenize_json
def test_tokenize_json():
    # Fail parsing of an invalid JSON string
    try:
        validate_json(
            content='{ "foo" : "bar }', validator=get_basic_schema()
        )
    except ParseError as exc:
        assert exc.position.column_no == 14
        assert exc.position.line_no == 1
        assert exc.position.char_index == 13
        assert exc.code == "parse_error"
        assert exc.text == 'Expecting " delimiter.'

    # Fail parsing of an empty string
    try:
        validate_json(content="", validator=get_basic_schema())
    except ParseError as exc:
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.code

# Generated at 2022-06-26 10:44:20.667614
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("""
    {
        "hello": "world"
    }
    """)



# Generated at 2022-06-26 10:44:27.269322
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"a": 1, "b": [true, 2.5, "str", [null, false], {}], "c": {}}')
    assert isinstance(result, dict)
    assert result["a"] == ScalarToken(1, 2, 4, '{"a": 1, "b": [true, 2.5, "str", [null, false], {}], "c": {}}')

# Generated at 2022-06-26 10:44:34.075662
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "\"hello\": \"world\""
    expected_output = {
        "hello": "world"
    }
    output = tokenize_json(content)
    assert output == expected_output, "Expected {}, got {}".format(
        expected_output, output
    )



# Generated at 2022-06-26 10:44:43.717998
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Ensure that tokenize_json is functioning as expected
    """
    # Test empty content.
    try:
        validate_json("", Schema)
    except ParseError as exc:
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert exc.text == "No content."

    # Test simple parsing.
    token = tokenize_json(b'{"hi": "there"}')
    assert isinstance(token, DictToken)
    assert token.value == {"hi": "there"}
    assert token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert token.end_position == Position(column_no=12, line_no=1, char_index=11)

    # Test complex parsing

# Generated at 2022-06-26 10:44:45.769200
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json(""), Token)



# Generated at 2022-06-26 10:44:56.046140
# Unit test for function tokenize_json
def test_tokenize_json():
    #   Just a simple dict.
    assert tokenize_json('{"key": "value"}') == {
        "key": "value"
    }
    #   Dict with commas.
    assert tokenize_json('{"key": "value", "other key": "other value"}') == {
        "key": "value",
        "other key": "other value",
    }
    #   Dict with non-string keys.
    assert tokenize_json('{"key": "value", 123: "other value"}') == {
        "key": "value",
        123: "other value",
    }
    #   Nested dict.

# Generated at 2022-06-26 10:45:03.682045
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = '[{"a": [{"b": 1}]}]'
    value_0 = tokenize_json(content_0)


# Generated at 2022-06-26 10:45:07.208841
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(
        tokenize_json("{}"),
        DictToken,
    ), "tokenize_json with valid input does not produce a DictToken"


# Generated at 2022-06-26 10:45:14.915029
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenizing_decoder_1 = _TokenizingDecoder()
    myjson = {}
    myjson['one'] = 1
    myjson['foo'] = 'bar'
    myjson['array'] = [1,2,3]
    myjson['dict'] = {'one': 1, 'two': 2, 'three': 3}
    cnt = str(myjson)
    tok = tokenize_json(cnt)
    assert isinstance(tok, DictToken)
    assert 0 == tok.start_position.char_index
    assert len(cnt)-1 == tok.end_position.char_index
    assert 1 == len(tok.dict_value)
    assert 'one' == list(tok.dict_value.keys())[0]

# Generated at 2022-06-26 10:45:28.951948
# Unit test for function tokenize_json
def test_tokenize_json():
    import copy
    import json
    import pickle
    import unittest
    from collections import abc
    from typing import Any, Dict, Union
    import typesystem

    class TestJSONDecoder(json.JSONDecoder):

        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.doc: Dict[str, Any] = {}
            super().__init__(object_hook=self.object_hook, *args, **kwargs)

        def object_hook(self, obj: Dict[str, Any]) -> None:
            self.doc = obj
            return None


# Generated at 2022-06-26 10:45:40.418122
# Unit test for function tokenize_json
def test_tokenize_json():
    # Ensure that JSONDecodeErrors are raised when content is invalid.
    with pytest.raises(ParseError):
        tokenize_json("no_matching_bracket")

    # Ensure that JSONDecodeErrors are translated into ParseErrors.
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("[invalid")

    parse_error = exc_info.value
    assert parse_error.text == "Expecting object or ']'", "Unexpected error message."
    assert parse_error.code == "parse_error", "Unexpected error code."
    assert parse_error.position.line_no == 1
    assert parse_error.position.column_no == len("[invalid") + 1

    # Ensure that an empty string results in a ParseError.

# Generated at 2022-06-26 10:45:51.511523
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:46:02.607317
# Unit test for function tokenize_json
def test_tokenize_json():
    # In this example we set up a payment schema to validate a simple JSON
    # object containing a payment.

    # In this JSON example, we set up a simple payment:
    #
    # {
    #     "name": "Jane Doe",
    #     "amount": 99.99,
    #     "receipt": null
    # }
    #
    # This payment is for $99.99, and has no associated receipt.

    # import json
    from typesystem.schemas import Schema
    from typesystem.fields import String, Float, Null

    class PaymentSchema(Schema):
        name = String(max_length=30, required=True)
        amount = Float(gte=0, lte=100, required=True)
        receipt = Null()


# Generated at 2022-06-26 10:46:14.145498
# Unit test for function tokenize_json
def test_tokenize_json():
    test_tokenize_json_0()
    test_tokenize_json_1()
    test_tokenize_json_2()
    test_tokenize_json_3()
    test_tokenize_json_4()
    test_tokenize_json_5()
    test_tokenize_json_6()
    test_tokenize_json_7()
    test_tokenize_json_8()
    test_tokenize_json_9()
    test_tokenize_json_10()
    test_tokenize_json_11()
    test_tokenize_json_12()
    test_tokenize_json_13()
    test_tokenize_json_14()
    test_tokenize_json_15()
    test_tokenize_json_16()
    test_tokenize_json_17()
   

# Generated at 2022-06-26 10:46:22.625464
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test JSON decode error.
    try:
        tokenize_json('{"name": "Alice", "age": 20, }')

    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 24
        assert exc.position.char_index == 2

    # No content error.
    try:
        tokenize_json("")
    except ParseError:
        pass
    else:
        # Should not be reached.
        raise AssertionError("Expected ParseError to be raised.")



# Generated at 2022-06-26 10:46:34.246404
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("null")
    tokenize_json("true")
    tokenize_json("false")
    tokenize_json("1")
    tokenize_json("1.0")
    tokenize_json("-1")
    tokenize_json("-1.0")
    tokenize_json("1e10")
    tokenize_json("1.0e10")
    tokenize_json("-1e10")
    tokenize_json("-1.0e10")
    tokenize_json("{}")
    tokenize_json('{"hello": "world"}')
    tokenize_json('{"hello": "world"}')
    tokenize_json('["one", 2, {"three": 4}]')
    tokenize_json('["one", 2, {"three": 4}]')

# Generated at 2022-06-26 10:46:46.448071
# Unit test for function tokenize_json
def test_tokenize_json():
    text = '{"name":"foo","location":"Earth"}'
    result = tokenize_json(text)
    assert isinstance(result, DictToken)
    assert result.get("name") == "foo"
    assert result.get("location") == "Earth"

    text = "[ 1, 2, 3 ]"
    result = tokenize_json(text)
    assert isinstance(result, ListToken)
    assert len(result) == 3
    assert result.get(0) == 1
    assert result.get(1) == 2
    assert result.get(2) == 3
    assert result.get(3, required=False) is None

    text = "[]"
    result = tokenize_json(text)
    assert isinstance(result, ListToken)
    assert len(result) == 0

    text = ""

# Generated at 2022-06-26 10:46:58.246244
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test serialization of a simple scalar token.
    assert tokenize_json('"the quick brown fox"') == ScalarToken(
        "the quick brown fox", 0, 22, '"the quick brown fox"'
    )
    # Test serialization of a simple list token containing a scalar token.

# Generated at 2022-06-26 10:47:08.941860
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases:
    tokenize_json_0 = tokenize_json("nul")
    tokenize_json_1 = tokenize_json("{}")
    tokenize_json_2 = tokenize_json('{"array": ["value1", "value2"]}')
    tokenize_json_3 = tokenize_json('{"array": [1, "value2"]}')
    tokenize_json_4 = tokenize_json('{"array": [1, 2]}')
    tokenize_json_5 = tokenize_json("{'array': [1, 2]}")
    tokenize_json_6 = tokenize_json("{\"]([])\": [1, 2]}")
    # Test cases:
    # tokenize_json_7 = tokenize_json({"array": ["value1", "value2"]})


# Generated at 2022-06-26 10:47:20.582162
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = """
    {
      "$schema": "http://json-schema.org/draft-04/schema#",
      "type": "object",
      "properties": {
        "numbers": {
          "type": "array",
          "items": {
            "type": "integer"
          }
        },
        "string_list": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "boolean_list": {
          "type": "array",
          "items": {
            "type": "boolean"
          }
        }
      }
    }
    """
    token = tokenize_json(content_0)
    assert isinstance(token, DictToken)

# Generated at 2022-06-26 10:47:26.331085
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "b"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.as_dict()["a"], ScalarToken)



# Generated at 2022-06-26 10:47:34.598508
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test decoding an empty string with no whitespace
    actual = tokenize_json(content="")
    assert actual == None

    # Test decoding an empty string with whitespace
    actual = tokenize_json(content="   \t   ")
    assert actual == None

    # Test decoding an object with a single key,value pair
    actual = tokenize_json(content='{"key1": "value1"}')
    assert isinstance(actual, DictToken)
    assert actual.value == {"key1": "value1"}

    # Test decoding a list with a single array element
    actual = tokenize_json(content='[42]')
    assert isinstance(actual, ListToken)
    assert actual.value == [42]

    # Test decoding a list with several array element

# Generated at 2022-06-26 10:47:38.941421
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json("")
    except ParseError as err:
        assert err.code == "no_content"
        assert err.position.line_no == 1
        assert err.position.column_no == 1
        assert err.position.char_index == 0
        assert err.text == "No content."


# Generated at 2022-06-26 10:47:44.455917
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json(""), Token)
    assert isinstance(tokenize_json("{}"), Token)
    assert isinstance(tokenize_json("{\"foo\":\"bar\"}"), Token)
    assert isinstance(tokenize_json("[123,456]"), Token)
    assert isinstance(tokenize_json("null"), Token)
    assert isinstance(tokenize_json("true"), Token)
    assert isinstance(tokenize_json("false"), Token)
    assert isinstance(tokenize_json("null"), Token)



# Generated at 2022-06-26 10:47:55.269449
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ListToken([], 0, 0, "")
    assert tokenize_json(" ") == ListToken([], 1, 1, " ")
    assert tokenize_json("\n") == ListToken([], 1, 1, "\n")
    assert tokenize_json("\n\n") == ListToken([], 2, 2, "\n\n")
    assert tokenize_json("\t") == ListToken([], 1, 1, "\t")
    assert tokenize_json("\t\n\t") == ListToken([], 3, 3, "\t\n\t")
    assert tokenize_json("\r") == ListToken([], 1, 1, "\r")
    assert tokenize_json("\r\n") == ListToken([], 2, 2, "\r\n")
    assert token

# Generated at 2022-06-26 10:48:04.962530
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{}"
    schema = Schema(
        fields={
            "a": {"type": "string", "description": "a", "required": True},
            "b": {"type": "integer", "description": "b", "required": False},
        }
    )
    output = validate_json(content, schema)
    assert output == ({}, [])

    content = "{\"a\": \"test\", \"b\": 1}"
    schema = Schema(
        fields={
            "a": {"type": "string", "description": "a", "required": True},
            "b": {"type": "integer", "description": "b", "required": False},
        }
    )
    output = validate_json(content, schema)
    assert output == ({'a': "test", "b": 1}, [])


# Generated at 2022-06-26 10:48:15.972674
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Validate tokenize_json

    Validate that tokenize_json is returning the expected result.
    """
    # Test 1
    content1 = "{}"
    assert tokenize_json(content1) == {"type": "dict"}

    # Test 2
    content2 = "{\"a\": \"b\"}"
    assert tokenize_json(content2) == {"type": "dict", "properties": {"a": {"type": "str"}}}

    # Test 3
    content3 = "[]"
    assert tokenize_json(content3) == {"type": "list"}

    # Test 4
    content4 = "[1, null, \"string\"]"
    assert tokenize_json(content4) == {"type": "list", "items": [{"type": "int"}, {"type": "null"}, {"type": "str"}]}

   

# Generated at 2022-06-26 10:48:24.992319
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken(
        {ScalarToken("a", 0, 1, '{"a": 1}'): ScalarToken(1, 4, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json('{"a": 2}') == DictToken(
        {ScalarToken("a", 0, 1, '{"a": 2}'): ScalarToken(2, 4, 4, '{"a": 2}')}, 0, 7, '{"a": 2}'
    )

# Generated at 2022-06-26 10:48:34.961809
# Unit test for function tokenize_json
def test_tokenize_json():
    # Invalid JSON
    assert not tokenize_json("not json")
    # Empty JSON
    assert not tokenize_json("")
    # Flat JSON, no nesting
    assert tokenize_json('{"foo": "bar"}')
    # Complex, nested JSON
    assert tokenize_json('{"simple": {"a": "string", "b": [1, 2, 3]}}')
    # Python's builtin JSON parser can handle invalid UTF-8
    assert tokenize_json(b'{"foo": "\xc3"}')
    # TokenizingDecoder properly handles invalid UTF-8
    assert not tokenize_json(b'{"foo": "\xc3")')



# Generated at 2022-06-26 10:48:45.387530
# Unit test for function tokenize_json
def test_tokenize_json():
    validator = Field(type="string")

    # Handle cases that result in a JSON parse error.
    try:
        tokenize_json('{"x": ')
    except ParseError as exc:
        assert exc.text == "Expecting value."
        assert exc.code == "parse_error"
        assert exc.position.column_no == 6
        assert exc.position.line_no == 1
        assert exc.position.char_index == 6

    # Ensure that the validator is a Field or Schema class.
    with pytest.raises(TypeError) as excinfo:
        validate_json('{"x": "y"}', 42)
    assert excinfo.value.args[0] == "validator must be a Field or Schema class"

    # Ensure that the validator is a Field instance or Schema class.
   

# Generated at 2022-06-26 10:48:49.635629
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{}"
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)



# Generated at 2022-06-26 10:48:58.635451
# Unit test for function tokenize_json
def test_tokenize_json():
    #Parse error: No content.
    try:
        tokenize_json('')
    except ParseError as error:
        assert error.text == 'No content.' and error.code == 'no_content' and error.position.column_no == 1 and error.position.line_no == 1 and error.position.char_index == 0

    #Parse error: Expecting value
    try:
        tokenize_json('a')
    except ParseError as error:
        assert error.text == 'Expecting value' and error.code == 'parse_error' and error.position.column_no == 1 and error.position.line_no == 1 and error.position.char_index == 1

    #Parse error: Expecting property name enclosed in double quotes

# Generated at 2022-06-26 10:49:05.652379
# Unit test for function tokenize_json
def test_tokenize_json():

    content = dedent(
        """
        {
          "foo": "bar",
          "baz": {
            "hi": "there"
          },
          "qux": [1, 2, 3]
        }
        """
    )

    token = tokenize_json(content)

    assert token.start_position.column_no == 1
    assert token.start_position.line_no == 1
    assert token.end_position.column_no == 32
    assert token.end_position.line_no == 9



# Generated at 2022-06-26 10:49:07.295411
# Unit test for function tokenize_json
def test_tokenize_json():
    assert(True)


# Generated at 2022-06-26 10:49:09.908013
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{ "hello": "world" }'
    tokenize_json(content)

# Generated at 2022-06-26 10:49:22.194462
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{ "a": 1, "b": 2 }'
    expected = DictToken(
        {
            "a": ScalarToken(1, position_start=3, position_end=3, content=content),
            "b": ScalarToken(2, position_start=13, position_end=13, content=content),
        },
        position_start=0,
        position_end=21,
        content=content,
    )
    actual = tokenize_json(content)
    assert actual.content == expected.content
    assert actual.position_start == expected.position_start
    assert actual.position_end == expected.position_end
    assert actual.value == expected.value



# Generated at 2022-06-26 10:49:31.945109
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenizing_decoder_1 = _TokenizingDecoder()
    assert tokenize_json("{}") == {}, "Case 1 failed"
    assert tokenize_json("") == {}, "Case 2 failed"


# Generated at 2022-06-26 10:49:45.677415
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases for function tokenize_json
    content_0 = ""
    token_0 = tokenize_json(content_0)
    try:
        assert False
    except ParseError as exc:
        error_0 = exc
    content_1 = "a"
    token_1 = tokenize_json(content_1)
    try:
        assert False
    except ParseError as exc:
        error_1 = exc
    content_2 = "true"
    token_2 = tokenize_json(content_2)
    try:
        assert token_2.value == True
    except ParseError as exc:
        error_2 = exc
    content_3 = "null"
    token_3 = tokenize_json(content_3)

# Generated at 2022-06-26 10:49:54.767371
# Unit test for function tokenize_json
def test_tokenize_json():
    input = '{"a": 1, "b": {"c": 3, "d": "hello"}, "e": [1, 2, 3] }'
    output = tokenize_json(input)
    assert output.value == {"a": 1, "b": {"c": 3, "d": "hello"}, "e": [1, 2, 3]}
    assert isinstance(output, DictToken)

# Test that it correctly handles trailing commas

# Generated at 2022-06-26 10:50:08.007532
# Unit test for function tokenize_json
def test_tokenize_json():
    test_decoder = _TokenizingDecoder()
    assert test_decoder.decode('{"a": "b"}') == {"a": "b"}
    assert test_decoder.decode('{"a": "b", "b": "a"}') == {"a": "b", "b": "a"}
    assert test_decoder.decode('{"a": "b", "b": "a", "c": "c"}') == {"a": "b", "b": "a", "c": "c"}
    assert test_decoder.decode('{"a": "b", "b": "a", "c": "c", "d": "d"}') == {"a": "b", "b": "a", "c": "c", "d": "d"}

# Generated at 2022-06-26 10:50:11.317493
# Unit test for function tokenize_json
def test_tokenize_json():
    # Remove the pass statement below and add your own tests
    assert tokenize_json("") == Token(token_type=TokenType.ERROR, value="")

# Test case runner - change the file name to match your *.py file
if __name__ == "__main__":
    print("Running test cases...")
    test_case_0()
    # test_tokenize_json()
    print("Test cases completed!")

# Generated at 2022-06-26 10:50:18.351717
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "Hello World"
    str_1 = content_0
    str_2 = str_1.strip()
    bool_0 = bool(str_2)
    if bool_0:
        obj_0 = tokenize_json(content_0)
        return None
    str_3 = repr(content_0)
    str_4 = repr(1)
    str_5 = repr(1)
    obj_1 = ParseError(text=str_3, code=str_4, position=str_5)
    raise obj_1


# Generated at 2022-06-26 10:50:21.536454
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        # Test cases for tokenize_json
        # tokenize_json('', validator=None)
        assert False
    except ParseError:
        pass



# Generated at 2022-06-26 10:50:22.838352
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case with empty input
    assert tokenize_json("") is None


# Generated at 2022-06-26 10:50:32.991925
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:50:41.896444
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test 1
    content_1: bytes = b'{"a": 1}'
    tokens_1: Token = tokenize_json(content_1)
    assert isinstance(tokens_1, DictToken)
    assert tokens_1.get('a') == 1
    # Test 2
    content_2: str = '{"a": 1}'
    tokens_2: Token = tokenize_json(content_2)
    assert isinstance(tokens_2, DictToken)
    assert tokens_2.get('a') == 1



# Generated at 2022-06-26 10:50:52.632484
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{ "key1": "value1", "key2": "value2", "key3": "value3" }') == DictToken({"key1": "value1", "key2": "value2", "key3": "value3"}, 0, 62, '{ "key1": "value1", "key2": "value2", "key3": "value3" }')


print(test_case_0())

# Generated at 2022-06-26 10:51:05.991233
# Unit test for function tokenize_json
def test_tokenize_json():
    content = bytes(
        '{"key_1": {"key_1_1": [1.1, 1.2, "value_1_1_3", {"key_1_1_4": "value_1_1_4"}], "key_1_2": "value_1_2"}, "key_2": "value_2", "key_3": null, "key_4": true, "key_5": false}',
        'utf-8',
    )

    # Test 1

# Generated at 2022-06-26 10:51:17.744015
# Unit test for function tokenize_json
def test_tokenize_json():

    # Empty string.
    # This test case is a direct copy of the test case written by J.F. Sebastian.
    content = ""
    try:
        tokenize_json(content)
        assert False
    except ParseError as e:
        assert e.text == "No content."
        assert e.code == "no_content"
        assert e.position.line_no == 1
        assert e.position.column_no == 1
        assert e.position.char_index == 0

    # JSON-encoded null value.
    # This test case is a direct copy of the test case written by J.F. Sebastian.
    content = 'null'
    tokens = tokenize_json(content)
    assert type(tokens) is ScalarToken
    assert tokens.value is None
    assert tokens.start == 0

# Generated at 2022-06-26 10:51:28.806646
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "a"}') == {"a": "a"}
    assert tokenize_json('{"a": "кошка"}') == {"a": "кошка"}
    assert tokenize_json('{"a": "\\u4F60\\u597D"}') == {"a": "你好"}
    assert tokenize_json('{"a": "\\u4F60\\u597D"}') == {"a": "你好"}
    assert tokenize_json('{"a": "\\"hi\\"}"}') == {"a": '"}'}

    assert tokenize_json('{"a": "\\x12"}') == {"a": "\\x12"}

    assert tokenize_json('["hi", 123, null]') == ["hi", 123, None]

# Generated at 2022-06-26 10:51:38.120095
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import PARSE_ERROR_CODE, ParseError
    from .syntax_cases import cases
    for title, expression, position, error_text, error_code in cases:
        print("Tokenizing: %s" % expression)
        try:
            token = tokenize_json(expression)
        except ParseError as err:
            assert err.code == PARSE_ERROR_CODE
            if position is not None:
                assert err.position == position
            if error_text:
                assert err.text == error_text
        else:
            assert token is not None

