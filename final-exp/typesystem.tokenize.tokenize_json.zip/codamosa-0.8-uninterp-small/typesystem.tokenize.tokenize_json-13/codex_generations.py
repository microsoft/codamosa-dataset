

# Generated at 2022-06-26 10:42:07.673716
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({
        "name": str,
        "age": int,
        "gender": str,
    })
    content = """{
        "name": "Mark",
        "age": 18,
        "gender": "Male"
    }"""
    content = content.replace("\n", "")
    token, messages = validate_json(content=content, validator=schema)
    assert token.name == "Mark"
    assert token.age == 18
    assert token.gender == "Male"
    assert len(messages) == 0
    # Validating a Schema by Field.
    field = Field(type=Schema)
    token, messages = validate_json(content=content, validator=field)
    assert token["name"] == "Mark"
    assert token["age"] == 18
    assert token

# Generated at 2022-06-26 10:42:09.839337
# Unit test for function validate_json
def test_validate_json():
    validate_json("""{"name": "John Doe"}""", "list")


# Generated at 2022-06-26 10:42:11.273055
# Unit test for function validate_json
def test_validate_json():
    pass


# Generated at 2022-06-26 10:42:21.130787
# Unit test for function validate_json
def test_validate_json():
    # Test JSON with incorrect format
    assert validate_json(content=b"{'foo': 1, 'bar': 2}", validator=Field()) == (
        None,
        [
            Message(
                text="Expecting property name enclosed in double quotes.", code="parse_error", position=Position(
                    column_no=1,
                    line_no=1,
                    char_index=0,
                )
            ),
        ],
    )

    # Test JSON with incorrect format and custom validator

# Generated at 2022-06-26 10:42:30.227805
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": 1}') == {'foo': 1}
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}
    assert tokenize_json('{"foo": [1, "bar", true]}') == {'foo': [1, 'bar', True]}
    assert tokenize_json('{"foo": {"bar": "foobar", "foobar": "barfoo"}}') == {'foo': {'bar': 'foobar', 'foobar': 'barfoo'}}


# Generated at 2022-06-26 10:42:41.534418
# Unit test for function validate_json
def test_validate_json():
    content = "{}"
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert not token.children
    assert token.end == 2
    assert token.start == 0

    content = "[]"
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert not token.children
    assert token.end == 2
    assert token.start == 0

    content = '{"foo":["bar"],"baz":null}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.children
    assert token.end == 25
    assert token.start == 0

    content = '{"foo":["bar"],"baz":"qux"}'
    token = tokenize_json(content)


# Generated at 2022-06-26 10:42:54.821455
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    import json
    from .conftest import Person, PersonSchema
    person_data = json.loads(Person.data)
    valid_person = PersonSchema(**person_data)
    tok = tokenize_json(valid_person.to_json_string())
    value, messages = validate_json(content=valid_person.to_json_string(), validator=PersonSchema)
    assert value == person_data
    assert messages == list()
    assert tok == typesystem.validate_json(content=valid_person.to_json_string(), validator=PersonSchema)[0]

    # Test with a nested schema
    person_data = json.loads(Person.data_nested_schema)
    valid_person = PersonSchema(**person_data)
    tok = tokenize

# Generated at 2022-06-26 10:43:02.286233
# Unit test for function validate_json
def test_validate_json():
    content = """\
{"a": 1, "b": true}
"""
    class TestSchema(Schema):
        a = Field(type="integer")
        b = Field(type="boolean")

    value, error_messages = validate_json(content, TestSchema)
    assert value == {"a": 1, "b": True}
    assert len(error_messages) == 0



# Generated at 2022-06-26 10:43:12.654677
# Unit test for function tokenize_json
def test_tokenize_json():
    from unittest import TestCase

    class TokenizeJsonTests(TestCase):
        def test_empty_string(self):
            with self.assertRaises(ParseError):
                tokenize_json("")

        def test_invalid_json(self):
            with self.assertRaises(ParseError):
                tokenize_json("{")

    TokenizeJsonTests().test_empty_string()
    TokenizeJsonTests().test_invalid_json()


# Generated at 2022-06-26 10:43:27.170253
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    # Silence the pylint warning which is due to the fact that
    # pylint is unable to resolve the imported classes.
    # pylint: disable=no-member

    def validate_position(
        position: Position,
        line_no: int = None,
        column_no: int = None,
        char_index: int = None,
    ) -> None:
        """
        Assert that a position matches the expected values.
        """
        if line_no is not None:
            assert position.line_no == line_no
        if column_no is not None:
            assert position.column_no == column_no
        if char_index is not None:
            assert position.char_index == char

# Generated at 2022-06-26 10:43:50.262479
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test basic types
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json('"foo\\"bar"') == ScalarToken(
        'foo"bar', 0, 8, '"foo\\"bar"'
    )
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("123") == ScalarToken(123, 0, 3, "123")

# Generated at 2022-06-26 10:43:55.221663
# Unit test for function tokenize_json
def test_tokenize_json():
    content = [u'{"one": 1, "two": 2}']
    for c in content:
        try:
            answer = tokenize_json(c)
            print(answer)
        except Exception as e:
            print(f"Error: {e}")


# Generated at 2022-06-26 10:44:05.993879
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {"name": "Foo", "type": "object", "properties": {"b": {"type": "string"}}}
    assert validate_json(b'{"b":"a"}', schema) == ({"b": "a"}, [])
    assert validate_json(b'{"b":1}', schema) == (None, [])
    assert validate_json(b'', "") == (None, [])

if __name__ == "__main__":
    import sys
    import doctest

    result = doctest.testmod()
    sys.exit(result.failed)

# Generated at 2022-06-26 10:44:17.389126
# Unit test for function tokenize_json
def test_tokenize_json():
    decoder = _TokenizingDecoder()
    assert decoder.decode('[1,2,3]') == [1, 2, 3]
    assert decoder.decode('{"foo": "bar"}') == {"foo": "bar"}
    with pytest.raises(ParseError):
        tokenize_json("")
    with pytest.raises(ParseError):
        tokenize_json("\n")
    with pytest.raises(ParseError):
        tokenize_json("[")
    with pytest.raises(ParseError):
        tokenize_json("[1,2,]")



# Generated at 2022-06-26 10:44:29.344324
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases 0-1: test valid JSON of various forms.
    assert tokenize_json(content='{"foo":"bar"}') == {'foo': 'bar'}
    assert tokenize_json(content='["hello","world"]') == ['hello', 'world']
    # Test case 2: test bad JSON.
    try:
        tokenize_json(content='{"foo":"bar"')
    except ParseError as err:
        assert err.code == 'parse_error'
        assert err.position == Position(column_no=12, line_no=1, char_index=11)
        assert err.text == 'Unterminated string starting at: line 1 column 12 (char 11).'


# Generated at 2022-06-26 10:44:34.219346
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import ScalarToken

    content = '"test"'
    result = tokenize_json(content)
    assert isinstance(result, ScalarToken)
    assert result.value == "test"


# Generated at 2022-06-26 10:44:35.634929
# Unit test for function tokenize_json
def test_tokenize_json():
    pass


# Generated at 2022-06-26 10:44:44.524289
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"type": "Project", "path": "foo.py"}'
    value = tokenize_json(content)

# Generated at 2022-06-26 10:44:47.984057
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Make sure that by default we get a JSONDecodeError for invalid JSON.
    """
    with pytest.raises(ParseError):
        tokenize_json('{"a": 1')



# Generated at 2022-06-26 10:45:02.378383
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    unit test for function tokenize_json
    """
    assert isinstance(tokenize_json(""), Token)
    assert isinstance(tokenize_json(b""), Token)
    tokenize_json("\U0001f355")
    tokenize_json("\u00e9")
    tokenize_json("\U0001f355")
    tokenize_json("\u00e9")
    tokenize_json(b"\U0001f355")
    tokenize_json(b"\u00e9")
    tokenize_json("\U0001f355".encode("utf-8"))
    tokenize_json("\u00e9".encode("utf-8"))

    # Test no content.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc

# Generated at 2022-06-26 10:45:23.037974
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'["foo"]'
    result = tokenize_json(content)
    assert isinstance(result, ListToken)

    content = b'{"foo": ["bar"]}'
    result = tokenize_json(content)
    assert isinstance(result, DictToken)

    content = b'[{"foo":"bar"}]'
    result = tokenize_json(content)
    assert isinstance(result, ListToken)
    assert isinstance(result.value[0], DictToken)

    content = b'{"foo": {"bar": "baz"}}'
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert isinstance(result.value["foo"], DictToken)

    content = b'{"foo": "bar"}'

# Generated at 2022-06-26 10:45:33.282371
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(
        {}, char_index=0, column_no=1, line_no=1, content="{}"
    )
    assert tokenize_json("{}") == tokenize_json("{}")
    assert tokenize_json("{}") == tokenize_json("{}")
    assert tokenize_json('{"test": 1}') == DictToken(
        {"test": ScalarToken(1, char_index=11, column_no=6, line_no=1, content="1")},
        char_index=0,
        column_no=1,
        line_no=1,
        content='{"test": 1}',
    )

# Generated at 2022-06-26 10:45:38.636651
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "[\"foo\", \"bar\", [0.424234, 1.365436], {\"foo\": [\"test\"]}]"
    result = tokenize_json(content)
    assert isinstance(result, ListToken)
    assert result.value_list == [ScalarToken("foo", 1, 4), ScalarToken("bar", 8, 11)]


# Generated at 2022-06-26 10:45:40.173871
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("{}")


# Generated at 2022-06-26 10:45:51.410977
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('0') == ScalarToken(0, 0, 1, '0')
    assert tokenize_json('-0') == ScalarToken(0, 0, 2, '-0')
    assert tokenize_json('-1') == ScalarToken(-1, 0, 2, '-1')
    assert tokenize_json('0.123') == ScalarToken(0.123, 0, 5, '0.123')

# Generated at 2022-06-26 10:46:00.374589
# Unit test for function tokenize_json
def test_tokenize_json():
    content = (
        '{"properties": {"foo": {"type": "string"}, "bar": {"type": "string"}}}'
    )
    expected = {
        'properties': {'foo': {'type': 'string'}, 'bar': {'type': 'string'}}}
    assert tokenize_json(content) == expected
    content = '{"properties": {"foo": "baz"}}'
    expected = {'properties': {'foo': 'baz'}}
    assert tokenize_json(content) == expected



# Generated at 2022-06-26 10:46:12.015004
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string case
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.char_index == 0
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.text == "No content."

    # Test valid JSON string
    token = tokenize_json('{"foo": ["bar"]}')
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert token[0].start_mark.char_index == 0
    assert token[0].end_mark.char_index == 19



# Generated at 2022-06-26 10:46:19.608286
# Unit test for function tokenize_json
def test_tokenize_json():
    """Test function tokenize_json."""
    # Setup
    content = '{"key": "value"}'

    # Exercise
    actual = tokenize_json(content)

    # Verify
    assert isinstance(actual, Token)
    expected = {
        "key": "value"
    }
    assert actual.value == expected

    # Cleanup - none necessary



# Generated at 2022-06-26 10:46:32.549412
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar", "baz": [1, 2], "num": 3.3}') == {
        "foo": "bar",
        "baz": [1, 2],
        "num": 3.3,
    }
    assert tokenize_json('"foo"') == "foo"
    assert tokenize_json("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_json("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_json("123") == 123
    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False


# Generated at 2022-06-26 10:46:34.041138
# Unit test for function tokenize_json
def test_tokenize_json():
    # TODO: Add doctests
    pass



# Generated at 2022-06-26 10:46:42.433556
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test common cases.
    load_0 = tokenize_json("[1, 2, 3]")
    load_1 = tokenize_json("")
    load_2 = tokenize_json("null")
    load_3 = tokenize_json("{}")

    # Test edge cases.
    load_4 = tokenize_json("")
    load_5 = tokenize_json("{}")

# Generated at 2022-06-26 10:46:53.406703
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string case.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert (
            exc.position.line_no == 1
            and exc.position.column_no == 1
            and exc.position.char_index == 0
        )
    # Test valid string.
    assert tokenize_json('{"hello": "world"}').value == {"hello": "world"}
    # Test invalid string.
    try:
        tokenize_json("[1, 2")
    except ParseError as exc:
        assert exc.text == "Expecting value"
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column

# Generated at 2022-06-26 10:47:06.541595
# Unit test for function tokenize_json
def test_tokenize_json():
    test0_json = '{"name": "test0"}'
    test0_result = {'name': 'test0'}
    test0 = tokenize_json(test0_json)
    assert test0.value == test0_result
    
    test1_json = '{"a" : 1, "b" : 2}'
    test1_result = {'a' : 1, 'b' : 2}
    test1 = tokenize_json(test1_json)
    assert test1.value == test1_result
    
    test2_json = '{"a" : 1.0, "b" : 2.0}'
    test2_result = {'a' : 1.0, 'b' : 2.0}
    test2 = tokenize_json(test2_json)
    assert test2

# Generated at 2022-06-26 10:47:19.717393
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"menu": {"id": "file", "value": "File", "popup": {"menuitem": [{"value": "New", "onclick": "CreateNewDoc()"}, {"value": "Open", "onclick": "OpenDoc()"}, {"value": "Close", "onclick": "CloseDoc()"}]}}}'
    tok = tokenize_json(json_string)
    assert tok.get_by_path("menu/popup/menuitem/0/value") == "New"
    assert tok.get_by_path("menu/popup/menuitem/1/value") == "Open"
    assert tok.get_by_path("menu/popup/menuitem/2/value") == "Close"

# Generated at 2022-06-26 10:47:28.509708
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}, "Failed to tokenize empty json object"
    assert tokenize_json('{"foo": "bar"}') == {
        "foo": "bar"
    }, "Failed to tokenize json object with a single key/value pair"
    assert tokenize_json('{"foo": [{"baz": "qux"}]}') == {
        "foo": [{"baz": "qux"}]
    }, "Failed to tokenize json object with a nested json object"
    assert tokenize_json('["foo"]') == ["foo"], "Failed to tokenize json list"
    assert tokenize_json('"foo"') == "foo", "Failed to tokenize json string"
    assert tokenize_json("1") == 1, "Failed to tokenize json integer"
    assert token

# Generated at 2022-06-26 10:47:40.560964
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases for tokenize_json
    assert isinstance(tokenize_json("\"\""), ScalarToken)
    # AssertionError: Expected type 'ScalarToken' but got 'ListToken'
    try:
        assert isinstance(tokenize_json("[]"), ScalarToken)
    except AssertionError as exc:
        print("\t:", exc)
    try:
        assert isinstance(tokenize_json("{}"), ScalarToken)
    except AssertionError as exc:
        print("\t:", exc)
    assert isinstance(tokenize_json("{\"a\":1}"), DictToken)
    assert isinstance(tokenize_json("[1]"), ListToken)
    assert isinstance(tokenize_json("{}"), DictToken)

# Generated at 2022-06-26 10:47:47.627111
# Unit test for function tokenize_json
def test_tokenize_json():

    # Empty string input
    try:
        results = tokenize_json("")
    except ParseError as e:
        assert e.position == Position(column_no=1, line_no=1, char_index=0)
        assert e.code == "no_content"
        assert e.text == "No content."

    # Missing a leading quote
    try:
        results = tokenize_json("{\"foo\":\"bar\"}")
    except ParseError as e:
        assert e.position == Position(column_no=1, line_no=1, char_index=0)
        assert e.code == "parse_error"
        assert e.text == "Expecting property name enclosed in double quotes."

    # Missing an ending quote
    test_string = """{
        "foo": "bar"
    }"""

# Generated at 2022-06-26 10:47:56.463402
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.types import String

    json_string = '{"foo": "hello", "bar": "world"}'
    field = String(name="foo")
    json_dict = tokenize_json(json_string)
    validate_json(json_string, field)
    # Test if tokenize_json returns a dict with the right keys
    assert set(json_dict.keys()) == set(["foo", "bar"])
    # Test if tokenize_json returns a dict with the right values
    assert set(json_dict.values()) == set(["hello", "world"])

    # Raise ParseError with the correct error message
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")

# Generated at 2022-06-26 10:48:08.758714
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tests whether the tokenize_json function works as expected
    """
    # Both `tokenize_json` and the `_TokenizingDecoder` it uses raise
    # `ParseError`s, which can be caught and gives a `text`, `code` and
    # `position` attribute.

    # Case 1: parse error
    with pytest.raises(ParseError) as exc_info:
        _ = tokenize_json("")
    assert exc_info.value.text == "No content."
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position == Position(column_no=1, line_no=1, char_index=0)

    # Case 2: valid JSON

# Generated at 2022-06-26 10:48:16.584136
# Unit test for function tokenize_json
def test_tokenize_json():
    import typesystem
    import io

    schema_rides_0 = typesystem.Schema("rides_0")
    schema_rides_0.add_field("name", typ=str)
    schema_rides_0.add_field("description", typ=str, required=False)
    schema_rides_0.add_field("minimum_height", typ=int, required=False)
    schema_rides_0.add_field("maximum_height", typ=int, required=False)
    schema_rides_0.add_field("is_active", typ=bool, required=False)

    schema_theme_parks_0 = typesystem.Schema("theme_parks_0")
    schema_theme_parks_0.add_field("name", typ=str)
    schema_theme_parks_

# Generated at 2022-06-26 10:48:25.714204
# Unit test for function tokenize_json
def test_tokenize_json():
    data = b'{"a": 3, "b": "a" }'
    value, error_messages = validate_json(data, Field("a", type="string"))
    assert not error_messages
    assert value == {"a": "a", "b": "a"}
    data = b'{"a": 3, "b": "a" }'
    value, error_messages = validate_json(data, Field("a", type="number"))
    assert not error_messages
    assert value == {"a": 3, "b": "a"}
    data = b'{"a": "3", "b": "a" }'
    value, error_messages = validate_json(data, Field("a", type="number"))
    assert any(em.code == "parse_error" for em in error_messages)
   

# Generated at 2022-06-26 10:48:31.216418
# Unit test for function tokenize_json
def test_tokenize_json():
    # Unit test for tokenize_json
    json_str = '{"type": "list", "items": {"type": "integer"}}'
    token = tokenize_json(json_str)
    assert token.value == {"type": "list", "items": {"type": "integer"}}


# Generated at 2022-06-26 10:48:44.045187
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2, "c": 3}'
    validator = {"a": int, "b": int, "c": int}

    # Valid case
    try:
        tokenize_json(content)
        validate_json(content, validator)
        assert True
    except ParseError:
        assert False
    except ValidationError:
        assert False
    except Exception:
        assert False
        assert True

    # Invalid case: Parsing
    invalid_content = '{"a": 1}'
    try:
        tokenize_json(invalid_content)
        assert False
    except ParseError:
        assert True

    # Invalid case: Validation
    invalid_content = '{"a": "A"}'

# Generated at 2022-06-26 10:48:55.722752
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case when content is a string
    try:
        tokenize_json("")
    except ParseError:
        pass

    # Test case when content is a bytearray
    try:
        tokenize_json(bytearray())
    except ParseError:
        pass

    # Test case when content is an empty string
    try:
        tokenize_json(" ")
    except ParseError:
        pass

    # Test case when content is a string (pathological case)
    tokenize_json('""')
    # Test case when content is a bytearray (pathological case)
    tokenize_json(b'""')

    # Test case when content is a string (pathological case)
    tokenize_json('"\\"')
    # Test case when content is a bytearray (pathological

# Generated at 2022-06-26 10:49:06.505038
# Unit test for function tokenize_json
def test_tokenize_json():
    # JSON string content to test (created with json.dumps) - all valid json
    json_string = '{"a": "b", "c": ["d", "e"], "f": {"g": "h"}}'
    # Result of calling tokenize_json()
    result = tokenize_json(json_string)
    # Expected result to compare against

# Generated at 2022-06-26 10:49:15.926555
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test for case where content is a string
    content_string_0 = "{\"test\": true}"
    token_string_0 = tokenize_json(content_string_0)
    assert token_string_0.typ == 'Dict'
    assert token_string_0.value == {'test': True}

    # Test for case where content is a bytestring
    content_bytestring_0 = b"{\"test\": true}"
    token_bytestring_0 = tokenize_json(content_bytestring_0)
    assert token_bytestring_0.typ == 'Dict'
    assert token_bytestring_0.value == {'test': True}


# Generated at 2022-06-26 10:49:22.867338
# Unit test for function tokenize_json
def test_tokenize_json():

    def test_case_0():
        token = tokenize_json('{"a": 1}')
        assert token == {'a': 1}
        assert isinstance(token, DictToken)
        assert isinstance(token['a'], ScalarToken)

    def test_case_1():
        token = tokenize_json('[{"a": 1}]')
        assert token == [{'a': 1}]
        assert isinstance(token, ListToken)
        assert isinstance(token[0], DictToken)
        assert isinstance(token[0]['a'], ScalarToken)

    def test_case_2():
        token = tokenize_json('{"a": [{"b": 2}]}')
        assert token == {'a': [{'b': 2}]}

# Generated at 2022-06-26 10:49:29.490632
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    
    dict_token = tokenize_json(content)
    assert dict_token.children[0].metadata.content == '"a"'
    assert dict_token.children[1].value == 1


# Generated at 2022-06-26 10:49:38.792657
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    assert_equal(
        tokenize_json("{}"), DictToken(fields={}, start=0, end=1, raw="{}")
    )
    assert_equal(
        tokenize_json("{}"),
        DictToken({"json": "{}"}, start=0, end=1, raw="{}"),
    )
    assert_equal(
        tokenize_json("[]"), ListToken(items=[], start=0, end=1, raw="[]")
    )
    assert_equal(
        tokenize_json("[]"),
        ListToken({"json": "[]"}, start=0, end=1, raw="[]"),
    )

# Generated at 2022-06-26 10:49:46.873763
# Unit test for function tokenize_json
def test_tokenize_json():

# Test case for empty value
    assert tokenize_json("") == ScalarToken(None, 0, 0, "")

# Test case for dict value
    assert tokenize_json('{"a":1}') == DictToken({"a":ScalarToken(1, 5, 6, '{"a":1}')}, 0, 8, '{"a":1}')

# Test case for list value
    assert tokenize_json('["a",1]') == ListToken(["a",ScalarToken(1, 7, 8, '["a",1]')], 0, 9, '["a",1]')


# Generated at 2022-06-26 10:49:54.777848
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"test":"test"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.data == {"test": "test"}
    assert token.start == 0
    assert token.end == 15


# Generated at 2022-06-26 10:49:57.879156
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "{}"
    x = tokenize_json(content_0)


# Generated at 2022-06-26 10:50:09.427042
# Unit test for function tokenize_json
def test_tokenize_json():
    # A test for when the object cannot be parsed.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert isinstance(exc, ParseError), "Expect ParseError"
        assert isinstance(exc.code, str), "Expect string"
        assert exc.code == "no_content", "Expect an error code of no_content"
        assert isinstance(exc.text, str), "Expect string"
        assert exc.text == "No content.", "Expect an error text of no_content"
        assert isinstance(exc.position, Position), "Expect instance of Position"
        assert exc.position.char_index == 0, "Expect char index to be 0"
        assert exc.position.column_no == 1, "Expect column number to be 1"

# Generated at 2022-06-26 10:50:19.151998
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:50:26.795511
# Unit test for function tokenize_json
def test_tokenize_json():
    content = u'{"bingo":"bongo","apple":1,"banana":"two","cherry":{"plum":3,"peach":4},"egg":"salad"}'
    tokenized = tokenize_json(content)
    assert tokenized.as_primitive() == {'apple': 1, 'banana': 'two', 'bingo': 'bongo', 'cherry': {'plum': 3, 'peach': 4}, 'egg': 'salad'}
    assert tokenized.value_token.start == 0
    assert tokenized.value_token.end == len(content) - 1


# Generated at 2022-06-26 10:50:32.706646
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"sometext":"somerandtext","someint":12,"somelist":[1,2,3]}'
    assert validate_json(content, {"sometext": str, "someint": int, "somelist": list}) == (
        {"sometext": "somerandtext", "someint": 12, "somelist": [1, 2, 3]},
        [],
    )


if __name__ == "__main__":
    test_tokenize_json()

# Generated at 2022-06-26 10:50:43.522215
# Unit test for function tokenize_json
def test_tokenize_json():
    # test default value for content
    assert tokenize_json(b"")
    assert tokenize_json("")
    assert tokenize_json(b"{\"key\": [1, 2, 3], \"list\": [true, false, 3.2]}")
    # test given value for content
    assert tokenize_json(b"{\"key\": [1, 2, 3], \"list\": [true, false, 3.2]}", content=b"{\"key\": [1, 2, 3], \"list\": [true, false, 3.2]}")
    assert tokenize_json("{\"key\": [1, 2, 3], \"list\": [true, false, 3.2]}", content="{\"key\": [1, 2, 3], \"list\": [true, false, 3.2]}")

# Generated at 2022-06-26 10:50:55.126442
# Unit test for function tokenize_json
def test_tokenize_json():
    # Argument with value '{}'
    test_tokenize_json_0 = tokenize_json("{}")

    # Argument with value '"hello"'
    test_tokenize_json_1 = tokenize_json("\"hello\"")

    # Argument with value '"123"'
    test_tokenize_json_2 = tokenize_json("\"123\"")

    # Argument with value '[1]'
    test_tokenize_json_3 = tokenize_json("[1]")

    # Argument with value '{"hello": "world"}'
    test_tokenize_json_4 = tokenize_json("{\"hello\": \"world\"}")

    # Argument with value '{"hello": 123}'
    test_tokenize_json_5 = tokenize_json("{\"hello\": 123}")

    # Argument with value '

# Generated at 2022-06-26 10:51:07.725823
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid JSON inputs
    assert tokenize_json(b"1") == ScalarToken(value=1, start_index=0, stop_index=0, content="1")
    assert tokenize_json(b"1.1") == ScalarToken(value=1.1, start_index=0, stop_index=2, content="1.1")
    assert tokenize_json(b"true") == ScalarToken(value=True, start_index=0, stop_index=3, content="true")
    assert tokenize_json(b"false") == ScalarToken(value=False, start_index=0, stop_index=4, content="false")

# Generated at 2022-06-26 10:51:11.934394
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with bytestring content
    tokens = tokenize_json(b"{\"foo\": [1, 2, 3]}")
    assert isinstance(tokens, DictToken)
    tokens = tokenize_json(b"{\"foo\": {\"bar\": true}}")
    assert isinstance(tokens, DictToken)
    tokens = tokenize_json(b"[]")
    assert isinstance(tokens, ListToken)
    tokens = tokenize_json(b"[{\"bar\": [true, false]}]")
    assert isinstance(tokens, ListToken)
    tokens = tokenize_json(b"[{\"bar\": [true, false]}]")
    assert isinstance(tokens, ListToken)
    tokens = tokenize_json(b"null")

# Generated at 2022-06-26 10:51:27.064187
# Unit test for function tokenize_json
def test_tokenize_json():
    # Invalid JSON
    exception_raised = False
    try:
        tokenize_json("{")
    except ParseError as exc:
        exception_raised = True
        msg = exc.message
        assert msg.text == "Expecting property name enclosed in double quotes."
        assert msg.code == "parse_error"
        assert msg.position.column_no == 2
        assert msg.position.line_no == 1
        assert msg.position.char_index == 1
    assert exception_raised

    # Empty string
    exception_raised = False
    try:
        tokenize_json("")
    except ParseError as exc:
        exception_raised = True
        msg = exc.message
        assert msg.text == "No content."
        assert msg.code == "no_content"

# Generated at 2022-06-26 10:51:30.112383
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == {"a": "b"}


# Generated at 2022-06-26 10:51:39.808293
# Unit test for function tokenize_json
def test_tokenize_json():

    content = '''
    [
    {
        "foo": "bar"
    }
    ]
    '''
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 1
    assert token.value[0] == DictToken({"foo": ScalarToken("bar", 43, 46, content)}, 6, 57, content)

    content = '''
    [
    {
        "foo": "bar",
        "baz": "quux"
        "quux": "baz"
    }
    ]
    '''
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert "Expecting ',' delimiter" == exc.text

    content = ''