

# Generated at 2022-06-26 10:42:11.543266
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token

    token = tokenize_json('{"key": "value"}')
    assert isinstance(token, Token)

# Generated at 2022-06-26 10:42:17.308650
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    res = tokenize_json(content)
    assert type(res) is DictToken
    assert res.value == {ScalarToken("foo", 1, 5, content): ScalarToken("bar", 8, 13, content)}
    assert res.start_position == Position(char_index=0, line_no=1, column_no=1)
    assert res.stop_position == Position(char_index=13, line_no=1, column_no=14)

# Generated at 2022-06-26 10:42:31.455973
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import Boolean, Float, Integer, String

    schema = Integer()

    # Validate an integer.
    value, errors = validate_json(b"42", schema)
    assert value == 42
    assert errors == []

    # Validate a float.
    value, errors = validate_json(b"3.14", schema)
    assert value == 3
    assert errors == [
        Message(
            text="Not a valid integer.",
            code="invalid_type",
            position=Position(char_index=0, column_no=1, line_no=1),
        )
    ]

    # Validate a string.
    value, errors = validate_json(b'"foo"', schema)
    assert value == 0

# Generated at 2022-06-26 10:42:38.970485
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''[
        {
            "foo": "bar",
            "baz": 123
        },
        {
            "baz": 123
        }
    ]'''
    token = tokenize_json(content)
    output = [
        {
            "foo": "bar",
            "baz": 123,
        },
        {"baz": 123},
    ]
    assert token.value == output



# Generated at 2022-06-26 10:42:43.156410
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")



# Generated at 2022-06-26 10:42:45.535073
# Unit test for function tokenize_json
def test_tokenize_json():
    assert validate_json(None) is None


# Generated at 2022-06-26 10:42:48.806856
# Unit test for function tokenize_json
def test_tokenize_json():
    res = tokenize_json('{"foo": "bar"}')
    assert res.__class__ == DictToken

# Generated at 2022-06-26 10:42:51.541600
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{\n    \"foo\": \"bar\",\n    \"baz\": 1\n}"
    tokenize_json(content)

# Generated at 2022-06-26 10:43:04.942752
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads
    from typesystem.tokenize.tokens import Token, ScalarToken, DictToken, ListToken

    content = '''
    {
        "foo": "bar",
        "number": 12.34,
        "list": [
            {
                "id": 1
            },
            {
                "id": 2
            },
            {
                "id": 3
            }
        ]
    }
    '''

    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert isinstance(token.token_value, dict)
    assert token.token_value.get("foo") == "bar"
    assert token.token_value.get("number") == 12.34

# Generated at 2022-06-26 10:43:16.892972
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing primitive values
    assert tokenize_json('"content"') == "content"
    assert tokenize_json("content") == "content"
    assert tokenize_json("1") == 1
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("null") is None

    # Testing arrays and objects
    assert tokenize_json("[]") == []
    assert tokenize_json(
        """
        [
            "content",
            "more content"
        ]
    """
    ) == ["content", "more content"]
    assert tokenize_json('{"key": "value"}') == {"key": "value"}

# Generated at 2022-06-26 10:43:27.641975
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(
        value=dict(), start=0, end=1, content="{}"
    )



# Generated at 2022-06-26 10:43:30.037503
# Unit test for function tokenize_json
def test_tokenize_json():
    assert True


# Generated at 2022-06-26 10:43:31.698971
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json('')



# Generated at 2022-06-26 10:43:40.331335
# Unit test for function tokenize_json
def test_tokenize_json():
    json_data0 = "{\"foo\": [{\"bar\": \"baz\", \"spam\": [\"eggs\"]}]}"
    tokens0 = tokenize_json(json_data0)
    assert isinstance(tokens0, DictToken)
    assert tokens0.data == {
        "foo": [DictToken({"bar": ScalarToken("baz", 25, 29, json_data0), "spam": ListToken([ScalarToken("eggs", 38, 43, json_data0)], 31, 43, json_data0)}, 20, 43, json_data0)]
    }



# Generated at 2022-06-26 10:43:52.405480
# Unit test for function tokenize_json
def test_tokenize_json():
    from core import json
    import typesystem
    from typesystem.exceptions import ParseError
    from typesystem.json.tokenize import ScalarToken
    from typesystem.json.tokenize.tokens import DictToken
    from typesystem.json.tokenize.tokens import ListToken

    class MySchema(typesystem.Schema):
        foo = typesystem.String()
        list_of_things = typesystem.List(typesystem.String())

    schema = MySchema()
    schema.validate({"list_of_things": ["a", "b", "c"]})

    content = json.dumps({"list_of_things": ["a", "b", "c"]})
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-26 10:43:58.602550
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    def test_case():
        assert tokenize_json("") == DictToken({})

    test_case()

    # Test for basic JSON object
    def test_case_1():
        assert tokenize_json('{"name": "John Doe"}') == DictToken({"name": "John Doe"})

    test_case_1()

    # Test for basic JSON list
    def test_case_2():
        assert tokenize_json('["one", 2, true, false]') == ListToken(["one", 2, True, False])

    test_case_2()

    # Test dict with string keys
    def test_case_3():
        assert tokenize_json('{"key": "value"}') == DictToken({"key": "value"})

    test_case_3()

    #

# Generated at 2022-06-26 10:44:09.381850
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "null"
    token_0 = tokenize_json(content_0)
    expected_0 = ScalarToken(
        value=None, start=0, end=3, content="null",
    )
    assert token_0 == expected_0
    content_1 = "[1]"
    token_1 = tokenize_json(content_1)
    expected_1 = ListToken(
        value=[
            ScalarToken(
                value=1, start=1, end=1, content="[1]",
            ),
        ],
        start=0,
        end=2,
        content="[1]",
    )
    assert token_1 == expected_1
    content_2 = '{"a":1}'
    token_2 = tokenize_json(content_2)
    expected_2

# Generated at 2022-06-26 10:44:11.111474
# Unit test for function tokenize_json
def test_tokenize_json():
    # assert isinstance(tokenize_json(content), Token)
    pass


# Generated at 2022-06-26 10:44:20.358543
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing for a string input
    tokenizing_decoder_1 = _TokenizingDecoder()
    try:
        _result = tokenize_json("")
        assert False
    except ParseError as exc_:
        assert exc_.code == "no_content"
        assert exc_.position.line_no == 1
        assert exc_.position.column_no == 1
        assert exc_.position.char_index == 0

    try:
        _result = tokenize_json("[")
        assert False
    except ParseError as exc_:
        assert exc_.code == "parse_error"
        assert exc_.position.line_no == 1
        assert exc_.position.column_no == 2
        assert exc_.position.char_index == 1


# Generated at 2022-06-26 10:44:23.256204
# Unit test for function tokenize_json
def test_tokenize_json():
    class TestSchema(Schema):
        num = int

    token = tokenize_json('{"num": 1}')
    assert isinstance(token, DictToken)
    _, error_messages = validate_json(content='{"num": 1}', validator=TestSchema)
    assert error_messages == []



# Generated at 2022-06-26 10:44:38.189187
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string.
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert (
        str(exc_info.value)
        == "No content at line 1, column 1: No content. (code=no_content)"
    )

    # Test bad JSON.
    with pytest.raises(ParseError) as exc_info:
        tokenize_json(r'{"foo": "bar}')
    assert (
        str(exc_info.value)
        == "Unterminated string starting at line 1, column 12: Expecting value. (code=parse_error)"
    )

    # Test good JSON.
    token = tokenize_json(r'{"foo": "bar"}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-26 10:44:49.853732
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test basic functionality.
    json = '{"foo": "bar"}'
    token = tokenize_json(json)
    assert token.position_range.start == Position(column_no=1, line_no=1, char_index=0)
    assert token.position_range.end == Position(column_no=14, line_no=1, char_index=13)
    assert token.value == {"foo": "bar"}

    # Test the empty string case.
    json = ""
    with pytest.raises(ParseError):
        tokenize_json(json)

    # Test the invalid json case.
    json = '{"foo": "bar":}'
    with pytest.raises(ParseError):
        tokenize_json(json)

    # Test with a bytestring.
    json = b

# Generated at 2022-06-26 10:44:54.533212
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(
        tokenize_json("{}"),
        (DictToken,),
    ), "tokenize_json should return type DictToken"

# Generated at 2022-06-26 10:45:05.247092
# Unit test for function tokenize_json
def test_tokenize_json():

    result = tokenize_json("{}")
    assert isinstance(result, DictToken)
    result = tokenize_json("{}")
    assert result.value == {}
    result = tokenize_json("{}")
    assert result.start_position == Position(1, 1, 0)
    result = tokenize_json("{}")
    assert result.end_position == Position(1, 1, 2)
    result = tokenize_json("[]")
    assert isinstance(result, ListToken)
    result = tokenize_json("[]")
    assert result.value == []
    result = tokenize_json("[]")
    assert result.start_position == Position(1, 1, 0)
    result = tokenize_json("[]")
    assert result.end_position == Position(1, 1, 2)


# Generated at 2022-06-26 10:45:10.141004
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"c": true, "a": "Ha!", "b": [1.0, 2.0, 3.0]}'
    try:
        value, error_messages = validate_json(content, Schema)
    except ParseError as exc:
        print(exc)
    return value, error_messages


if __name__ == "__main__":
    value, error_messages = test_tokenize_json()

# Generated at 2022-06-26 10:45:15.710284
# Unit test for function tokenize_json
def test_tokenize_json():
    with pytest.raises(ParseError, match="No content"):
        tokenize_json("")

    with pytest.raises(ParseError, match="Expecting property name enclosed in double quotes"):
        tokenize_json("{}")



# Generated at 2022-06-26 10:45:29.370262
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases for function tokenize_json
    # content: A JSON string or bytestring.
    # validator: A Field instance or Schema class to validate against.
    validator = None
    content = "[{'type': 'string', 'name': 'foo'}, {'type': 'number', 'name': 'bar'}]"
    assert ast.dump(tokenize_json(content)) == ast.dump(JSONDecoder().decode(content))
    content = "[{'type': 'string', 'name': 'foo'}, {'type': 'number', 'name': 'bar'}]"
    assert ast.dump(tokenize_json(content)) == ast.dump(JSONDecoder().decode(content))

# Generated at 2022-06-26 10:45:40.443171
# Unit test for function tokenize_json
def test_tokenize_json():

    # Empty strings are invalid.
    content = ""
    token, error_messages = validate_json(content, {"name": "string"})
    assert not error_messages
    assert token is None
    assert error_messages[0].text == "No content."

    # JSON parse errors are also handled.
    content = "{}"
    token, error_messages = validate_json(content, {"name": "string"})
    assert not error_messages
    assert token is None
    assert error_messages[0].text == "Invalid types."

    # Escaped quotes are handled properly.
    content = '{"name": "foo\\"bar"}'
    token, error_messages = validate_json(content, {"name": "string"})
    assert not error_messages
    assert token is None
    assert error_mess

# Generated at 2022-06-26 10:45:44.987397
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:45:53.604992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "hello!"
    expected = "hello!"
    actual = tokenize_json(content)
    assert actual == expected

    content = '{"foo": "bar"}'
    expected = {
        'start': 0,
        'end': 13,
        'value': {
            'foo': {
                'start': 2,
                'end': 10,
                'value': 'bar'
            }
        }
    }
    actual = tokenize_json(content)
    assert actual == expected
    assert content[actual["start"] : actual["end"] + 1] == content

    content = '{"foo": ["bar", "baz"]}'

# Generated at 2022-06-26 10:46:12.334880
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
        "name": "Jack",
        "age": 18,
        "siblings": ["Jill", "Jane", "Joe"]
    }
    '''
    token = tokenize_json(content)
    dict_token = token

    assert dict_token.value == {"name": "Jack", "age": 18, "siblings": ["Jill", "Jane", "Joe"]}
    assert dict_token.start == 3
    assert dict_token.end == 52

    # This test failed at one point where we weren't correctly calculating
    # the end position of the token.
    assert dict_token.content[dict_token.start : dict_token.end] == content.strip()

    assert isinstance(dict_token.children[0], ScalarToken)

# Generated at 2022-06-26 10:46:23.814125
# Unit test for function tokenize_json
def test_tokenize_json():
    # Instead of using json.loads() to parse a string, we use the
    # class defined above, since it adds position info to the
    # json tokens.
    name_to_kind = {
        "true": True,
        "false": False,
        "null": None
    }

    def parse_json_string(json_string):
        # Use the TokenizingDecoder to parse the given string,
        # and return its JSON parse tree.
        return _TokenizingDecoder().decode(json_string)

    # Test 1. Basic parsing:
    assert parse_json_string("{}") == {}
    assert parse_json_string("[]") == []
    assert parse_json_string(r'"foo"') == "foo"
    assert parse_json_string("true") == True

# Generated at 2022-06-26 10:46:34.019189
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"") == None
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json(b"[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json(b'"foo" "bar"') == ScalarToken("foo", 0, 5, '"foo" "bar"')
    assert tokenize_json(b' "foo"') == ScalarToken("foo", 1, 6, ' "foo"')
    assert tokenize_json(b' "foo" ') == ScalarToken("foo", 1, 6, ' "foo" ')

# Generated at 2022-06-26 10:46:36.689991
# Unit test for function tokenize_json
def test_tokenize_json():
    # Case 1: Valid Case where input is a string
    token = tokenize_json("{\"key\":\"value\"}")
    assert isinstance(token, DictToken)



# Generated at 2022-06-26 10:46:43.524379
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
      "foo": {
        "one": 1,
        "two": 2,
        "three": 3
      },
      "bar": {
        "four": 4,
        "five": 5,
        "six": 6
      },
      "baz": {
        "seven": 7,
        "eight": 8,
        "nine": 9
      }
    }
    '''
    token = tokenize_json(content)
    return token


# Generated at 2022-06-26 10:46:47.851004
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 10}'
    validator = Field(type="integer")
    assert validate_json(content, validator) == ({"a": 10}, [])


# Generated at 2022-06-26 10:46:59.354840
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "  s a"
    token_0 = tokenize_json(content_0)
    assert isinstance(token_0, ScalarToken)
    assert token_0.value == "s a"
    assert token_0.start == 2
    assert token_0.end == 6
    assert token_0.content == content_0

    content_1 = "  null"
    token_1 = tokenize_json(content_1)
    assert isinstance(token_1, ScalarToken)
    assert token_1.value is None
    assert token_1.start == 2
    assert token_1.end == 7
    assert token_1.content == content_1

    content_2 = b"  s a"
    token_2 = tokenize_json(content_2)

# Generated at 2022-06-26 10:47:01.797866
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json('{')
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."



# Generated at 2022-06-26 10:47:13.358253
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with good input.
    text_0 = '{"key": "value"}'
    expected_0 = {
        "key": "value",
    }
    actual_0 = tokenize_json(text_0)
    assert actual_0 == expected_0

    # Test with good input.
    text_1 = "{\"key\": \"value\", \"key_0\": [1, 2, 3]}"
    expected_1 = {
        "key": "value",
        "key_0": [1, 2, 3],
    }
    actual_1 = tokenize_json(text_1)
    assert actual_1 == expected_1

    # Test with malformed input.
    text_2 = "{"
    with raises(ParseError) as error_context:
        tokenize_json(text_2)
   

# Generated at 2022-06-26 10:47:18.169176
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        tokenize_json('{"key": "value"}')
        == DictToken({ScalarToken('key', 0, 4, '{"key": "value"}'): ScalarToken('value', 9, 16, '{"key": "value"}')}, 0, 16, '{"key": "value"}')
    )

# Generated at 2022-06-26 10:47:28.516132
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for exception ParseError
    try:
        tokenize_json("")
    except ParseError:
        pass
    else:
        assert False, "unexpected"


# Generated at 2022-06-26 10:47:35.613656
# Unit test for function tokenize_json
def test_tokenize_json():
    test_case_0()
    test_content_0_1()
    test_content_0_2()
    test_content_0_3()
    test_content_0_4()
    test_content_0_5()
    test_content_0_6()
    test_content_0_7()



# Generated at 2022-06-26 10:47:42.002240
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case - valid input
    try:
        validate_json("{\"name\": \"typesystem\"}", Field(name="name", type=str))
    except ParseError:
        assert False

    # Test case - invalid input
    try:
        validate_json("{", Field(name="name", type=str))
        assert False
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0

# Generated at 2022-06-26 10:47:43.109211
# Unit test for function tokenize_json
def test_tokenize_json():
    pass

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:47:44.423861
# Unit test for function tokenize_json
def test_tokenize_json():
    pass

# Generated at 2022-06-26 10:47:53.178430
# Unit test for function tokenize_json
def test_tokenize_json():
    assert sf_assert_token(tokenize_json('{"foo": "bar"}'), 
    {
        'type': 'DictToken',
        'start': 0,
        'end': 16,
        'position': {
            'column_no': 1,
            'line_no': 1,
            'char_index': 0
        },
        'value': {
            'foo': 'bar'
        }
    })


# Generated at 2022-06-26 10:48:03.107167
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test no content
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0

    # Test parse error
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 1



# Generated at 2022-06-26 10:48:12.315909
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ScalarToken(None, 0, 0, "")
    assert tokenize_json(" ") == ScalarToken(None, 0, 1, " ")
    assert tokenize_json("{}") == DictToken({}, 0, 2, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 2, "[]")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json("null") == ScalarToken(None, 0, 5, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 5, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 6, "false")

# Generated at 2022-06-26 10:48:23.956824
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"a": 2}"""
    token = tokenize_json(content)
    assert token.get("a") == 2

    content = """{"a": 2, "b": [{"a": 1}, {"a": 2}]}"""
    token = tokenize_json(content)
    assert token.get("b")[0].get("a") == 1
    assert token.get("b")[1].get("a") == 2

    content = """{"b": [{"a": 1}]}"""
    token = tokenize_json(content)
    assert token.get("b")[0].get("a") == 1

    content = """{"a": ["b", "c", "d"]}"""
    token = tokenize_json(content)
    assert token.get("a")[0] == "b"

# Generated at 2022-06-26 10:48:35.720630
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    from typesystem.string import String
    from typesystem.schemas import Schema

    # Test case for parse error.
    with pytest.raises(ParseError) as error:
        tokenize_json("not a valid json")

    assert error.value.position.column_no == 1
    assert error.value.position.line_no == 1
    assert error.value.position.char_index == 0

    # Test case for empty string.
    with pytest.raises(ParseError) as error:
        tokenize_json("")

    assert str(error.value) == "No content."
    assert error.value.position.column_no == 1
    assert error.value.position.line_no == 1
    assert error.value.position.char_index == 0

    # Test case for

# Generated at 2022-06-26 10:48:58.012451
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("undefined") == tokenize_json("null")
    assert tokenize_json("true") == True
    assert tokenize_json("false") == False
    assert tokenize_json("1") == 1
    assert tokenize_json("1234") == 1234
    assert tokenize_json("123.4") == 123.4
    assert tokenize_json('"hello"') == "hello"
    assert tokenize_json("[1, 2]") == [1, 2]
    assert tokenize_json("{}") == {}
    assert tokenize_json("{}").__class__.__name__ == "DictToken"
    assert tokenize_json('{"hello": "world"}').get("hello") == "world"

# Generated at 2022-06-26 10:49:07.421765
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}
    assert tokenize_json('{"a": "b"}') == {"a": "b"}
    assert tokenize_json("[1,2,3]") == [1, 2, 3]
    assert tokenize_json('{"a": {"b": [1, 2, 3]}}') == {"a": {"b": [1, 2, 3]}}
    assert tokenize_json('{"a": {"a":1}}') == {"a":{"a":1}}
    assert tokenize_json('{"a": 1}') == {"a": 1}
    assert tokenize_json('{"a": [1]}') == {"a": [1]}

# Generated at 2022-06-26 10:49:09.459538
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') is not None


# Generated at 2022-06-26 10:49:15.614561
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("true"), ScalarToken)
    assert isinstance(tokenize_json("5"), ScalarToken)
    assert isinstance(tokenize_json("null"), ScalarToken)
    assert tokenize_json("true").value is True
    assert tokenize_json("5").value == 5
    assert tokenize_json("null").value is None
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json("[]"), ListToken)



# Generated at 2022-06-26 10:49:25.496432
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('[1, 2, 3]') == ListToken([1, 2, 3], 0, 9, '[1, 2, 3]')
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 0, 8, '{"a": "b"}')
    assert tokenize_json('{"a": true}') == DictToken({'a': True}, 0, 10, '{"a": true}')
    assert tokenize_json('{"a": 1}') == DictToken({'a': 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": ["b", "c"]}') == DictToken({'a': ['b', 'c']}, 0, 15, '{"a": ["b", "c"]}')
    #

# Generated at 2022-06-26 10:49:37.180640
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start_index=0, end_index=1, text="{}")
    assert tokenize_json("[]") == ListToken(value=[], start_index=0, end_index=1, text="[]")
    assert tokenize_json('{"abc": 123}') == DictToken(value={"abc": ScalarToken(value=123, start_index=8, end_index=10,text='123')}, start_index=0, end_index=12, text='{"abc": 123}')

# Generated at 2022-06-26 10:49:44.838248
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") is None
    assert tokenize_json('"hello world"') == "hello world"
    assert tokenize_json("10") == 10
    assert tokenize_json("10.5") == 10.5
    assert tokenize_json("10e5") == 100000
    assert tokenize_json('"\\n"') == "\n"
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("[]") == []
    assert tokenize_json("{}") == {}
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-26 10:49:57.629905
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}

    token = tokenize_json('{"foo": "b\\"ar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": 'b"ar'}

    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "Should have raised ParseError"


# Generated at 2022-06-26 10:50:09.283617
# Unit test for function tokenize_json
def test_tokenize_json():
    json_data_0 = b'{}'
    content_0 = json_data_0.decode('utf-8')
    result_0 = tokenize_json(content_0)
    assert isinstance(result_0, DictToken)
    assert result_0.position.char_index == 0
    assert result_0.position.line_no == 1
    assert result_0.position.column_no == 1
    assert result_0.position_end.char_index == 1
    assert result_0.position_end.line_no == 1
    assert result_0.position_end.column_no == 2
    assert result_0.value == {}

    json_data_1 = b'{"name": "John Doe"}'
    content_1 = json_data_1.decode('utf-8')
   

# Generated at 2022-06-26 10:50:19.092449
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with a valid JSON string
    result = tokenize_json('["foo", 1, true, null, {"bla": [1, 2, 3]}]')
    assert isinstance(result, Token)
    assert result.value == [
        "foo",
        1,
        True,
        None,
        {
            "bla": [
                1,
                2,
                3,
            ]
        }
    ]

    # Test with an invalid JSON string
    with pytest.raises(ParseError):
        tokenize_json('{"foo": }')

    # Test with an empty string
    with pytest.raises(ParseError):
        tokenize_json('')

    # Test with a non-string value

# Generated at 2022-06-26 10:50:41.520518
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = ""
    try:
        tokenize_json(content_0)
    except ParseError as exc:
        assert exc.text == "No content."
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        raise AssertionError()

    content_1 = "{\"foo\": 1 }"
    token_1 = tokenize_json(content_1)
    assert isinstance(token_1, DictToken)
    assert token_1.value == {"foo": ScalarToken(1, 9, 10, "1 ")}
    assert token_1.start == 0
    assert token_1.end == 12


# Generated at 2022-06-26 10:50:54.388043
# Unit test for function tokenize_json
def test_tokenize_json():
    global tokenizing_decoder_0
    # Test with valid input
    try:
        # Test with valid input
        content = "test"
        expected = None
        actual = tokenize_json(content)
        assert repr(expected) == repr(actual)
    except:
        raise
    # Test with valid input
    try:
        # Test with valid input
        content = b"test"
        expected = None
        actual = tokenize_json(content)
        assert repr(expected) == repr(actual)
    except:
        raise
    # Test with valid input
    try:
        content = '{"test": 1}'
        expected = None
        actual = validate_json(content, object)
        assert repr(expected) == repr(actual)
    except:
        raise
    # Test with valid input

# Generated at 2022-06-26 10:51:03.075773
# Unit test for function tokenize_json
def test_tokenize_json():
    # Assert that a non-string value results in an exception.
    with pytest.raises(AssertionError) as excinfo:
        tokenize_json(123)
    assert (
        str(excinfo.value)
        == "content must be a string, got int.\n\nUsage::\n\n    tokenize_json(content: Union[str, bytes]) -> Token"
    )
    # Assert that an empty string results in an exception.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert (
        str(excinfo.value)
        == "No content.\n\n<Position: line_no=1, column_no=1, char_index=0>"
    )
    # Assert that a malformed string results in an exception

# Generated at 2022-06-26 10:51:16.396393
# Unit test for function tokenize_json
def test_tokenize_json():
    test_case_0()
    assert tokenize_json(b'{"Active": true, "DBUser": "jeff", "DBPassword": "123456"}')['DBUser'] == 'jeff'
    assert tokenize_json(b'{"Name": "Some Name"}')['Name'] == 'Some Name'
    assert tokenize_json(b'{"Name": "Some \'Name\'"}')['Name'] == "Some \'Name\'"
    assert tokenize_json(b'{"Name": "Some \"Name\""}')['Name'] == 'Some "Name"'
    assert tokenize_json(b'{"Name": "Some \\\\"Name\\\\""}')['Name'] == 'Some "Name"'
    assert tokenize_json(b'{"Name": "Some \\tName\\n"}')['Name'] == "Some \tName\n"

# Generated at 2022-06-26 10:51:28.268822
# Unit test for function tokenize_json
def test_tokenize_json():
    test_data_json_0 = '{"data":5,"tuna":3}'
    test_data_json_1 = b'{"data":5,"tuna":3}'
    test_data_json_2 = '''{"data":5,"tuna":3}'''
    test_data_json_3 = b'''{"data":5,"tuna":3}'''
    test_data_json_4 = '''{"data":5,"tuna":3}'''
    test_data_json_5 = b'''{"data":5,"tuna":3}'''
    test_data_json_6 = '''{"data":5,"tuna":3}'''
    test_data_json_7 = b'''{"data":5,"tuna":3}'''
    test_data_json_

# Generated at 2022-06-26 10:51:39.306295
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests for function tokenize_json
    assert tokenize_json("{}") == {}, "tokenize_json: empty JSON object"
    assert tokenize_json('{"a": 1}') == {
        "a": 1
    }, "tokenize_json: simple JSON object"
    assert tokenize_json('{"a": 1.0}') == {
        "a": 1.0
    }, "tokenize_json: JSON float"
    assert tokenize_json('{"a": 1e-10}') == {
        "a": 1e-10
    }, "tokenize_json: JSON float"
    assert tokenize_json('{"a": 1E-10}') == {
        "a": 1E-10
    }, "tokenize_json: JSON float"