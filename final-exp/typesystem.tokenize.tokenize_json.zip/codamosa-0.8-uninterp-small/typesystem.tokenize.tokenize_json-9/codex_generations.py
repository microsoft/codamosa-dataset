

# Generated at 2022-06-26 10:42:15.387435
# Unit test for function tokenize_json
def test_tokenize_json():
    validate_json(None, None)


# Generated at 2022-06-26 10:42:22.735950
# Unit test for function tokenize_json
def test_tokenize_json():
    assert list(tokenize_json("{}")) == []
    assert list(tokenize_json("[]")) == []
    assert list(tokenize_json("1")) == []
    assert list(tokenize_json('"1"')) == []
    assert list(tokenize_json("true")) == []
    assert list(tokenize_json("false")) == []
    assert list(tokenize_json("null")) == []
    assert len(list(tokenize_json('{"a":1}'))) == 1
    assert list(tokenize_json('{"a":1}'))[0].value == \
        {"a": 1}
    assert len(list(tokenize_json('{"a":1,"b":2}'))) == 1

# Generated at 2022-06-26 10:42:33.854067
# Unit test for function tokenize_json
def test_tokenize_json():

    t = tokenize_json("{\"foo\": \"bar\"}")
    assert isinstance(t, Token)
    assert t.value == {"foo": "bar"}
    assert t.start == 0
    assert t.end == 13
    assert t.content == "{\"foo\": \"bar\"}"

    t = tokenize_json('{"foo": "bar"}')
    assert isinstance(t, Token)
    assert t.value == {"foo": "bar"}
    assert t.start == 0
    assert t.end == 13
    assert t.content == '{"foo": "bar"}'

    t = tokenize_json("{'foo': 'bar'}")
    assert isinstance(t, Token)
    assert t.value == {"foo": "bar"}
    assert t.start == 0
    assert t.end == 13


# Generated at 2022-06-26 10:42:42.603668
# Unit test for function tokenize_json
def test_tokenize_json():
    token_0 = tokenize_json("")
    token_1 = tokenize_json("\n{}\n")
    token_2 = tokenize_json("{\n}")
    token_3 = tokenize_json("[1,2,3]")
    token_4 = tokenize_json("{\n  \"foo\": true\n}")
    token_5 = tokenize_json("{\n  \"foo\": true,\n  \"bar\": null\n}")
    token_6 = tokenize_json("{\n  \"foo\": true,\n  \"bar\": null,\n  \"baz\": [1, 2]\n}")

# Generated at 2022-06-26 10:42:45.981070
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"baz": "hello", "foo": true, "bar": 1}]'
    tokens = tokenize_json(content)

    assert isinstance(tokens, Token)
    assert isinstance(tokens, ListToken)
    assert tokens.value == []

    dict_token = tokens.value[0]
    assert isinstance(dict_token, Token)
    assert isinstance(dict_token, DictToken)
    assert dict_token.value == {}

    assert dict_token.value["baz"].value == "hello"



# Generated at 2022-06-26 10:42:56.281894
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests for tokenize_json
    # Test case 0
    content = '["foo", {"bar": ["baz", null, 1.0, 2]}]'
    result = tokenize_json(content)
    assert list(result) == [
        ScalarToken("foo", 0, 4, content),
        DictToken(
            {"bar": ListToken([ScalarToken("baz", 13, 17, content), None, 1.0, 2])},
            6, 24,
            content,
        ),
    ]
    # Test case 1
    content = "[]"
    result = tokenize_json(content)
    assert list(result) == []
    # Test case 2
    content = "[false, true, null]"
    result = tokenize_json(content)

# Generated at 2022-06-26 10:43:06.637846
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string_0 = "[]"
    token_0 = tokenize_json(json_string_0)
    assert len(token_0.errors) == 0 and token_0.valid
    json_string_1 = "[null]"
    token_1 = tokenize_json(json_string_1)
    assert len(token_1.errors) == 0 and token_1.valid
    json_string_2 = "[true]"
    token_2 = tokenize_json(json_string_2)
    assert len(token_2.errors) == 0 and token_2.valid
    json_string_3 = "[false]"
    token_3 = tokenize_json(json_string_3)
    assert len(token_3.errors) == 0 and token_3.valid
    json_string_4 = "[0]"
   

# Generated at 2022-06-26 10:43:17.633262
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.base import ValidationError, ParseError
    from typesystem.fields import String

    content1 = "\n\t\r   "
    try:
        tokenize_json(content1)
    except ParseError as e:
        assert e.position and e.position.line_no == 1 and e.position.column_no == 5
        assert e.position.char_index == 4
        assert e.text == "No content."

    content2 = '{"name": "foo"}'
    tokenize_json(content2)

    content3 = '{"name": "foo", "age": 0}'
    tokenize_json(content3)

    content4 = '{"name": "foo", "age": 0, "unexpected": "bar"}'

# Generated at 2022-06-26 10:43:29.104315
# Unit test for function tokenize_json
def test_tokenize_json():
    with pytest.raises(ParseError):
        tokenize_json("")
    with pytest.raises(ParseError):
        tokenize_json("Invalid JSON")

    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("3") == 3
    assert tokenize_json("3.0") == 3.0
    assert tokenize_json("3e10") == 3e10
    assert tokenize_json("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}
    assert tokenize_json('{"foo": null}') == {"foo": None}

# Generated at 2022-06-26 10:43:39.905330
# Unit test for function tokenize_json
def test_tokenize_json():
    expected = DictToken(
        {
            "foo": ScalarToken("bar", 0, 3, b'{"foo": "bar"}'),
            "baz": ListToken(
                [ScalarToken(1, 9, 9, b'{"foo": "bar", "baz": [1]}')],
                13,
                15,
                b'{"foo": "bar", "baz": [1]}',
            ),
        },
        0,
        20,
        b'{"foo": "bar", "baz": [1]}',
    )
    actual = tokenize_json(b'{"foo": "bar", "baz": [1]}')
    assert actual == expected



# Generated at 2022-06-26 10:43:56.544811
# Unit test for function tokenize_json
def test_tokenize_json():
    empty_str = ""
    empty_dict = {}
    assert tokenize_json(empty_str) == empty_dict

    empty_dict_str = "{}"
    assert tokenize_json(empty_dict_str) == empty_dict

    expected_dict = {"key": "value"}
    assert tokenize_json('{"key": "value"}') == expected_dict

    expected_list = [1, 2, 3, 4]
    assert tokenize_json('[1, 2, 3, 4]') == expected_list

    expected_nested_dict = {"key": "value", "another_key": {"a": 1, "b": 2}}
    assert tokenize_json('{"key": "value", "another_key": {"a": 1, "b": 2}}') == expected_nested_dict

    expected_nested_

# Generated at 2022-06-26 10:44:04.855958
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == DictToken(
        {
            ScalarToken('a', 0, 2, '{"a": 1}'): ScalarToken(
                1, 6, 7, '{"a": 1}'
            )
        },
        0,
        10,
        '{"a": 1}',
    )


# Generated at 2022-06-26 10:44:18.320033
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:44:26.301686
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    valid_json_string = '{"foo": "bar"}'
    assert tokenize_json(valid_json_string).serialize() == valid_json_string

    invalid_json_string = '{"foo": "bar"'
    assert tokenize_json(invalid_json_string) is None


# Generated at 2022-06-26 10:44:31.882022
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":[1,2.0,"3",true,null]}'
    assert all([
        isinstance(token, type(tokenize_json(content)))
        for token in tokenize_json(content).children
    ])


# Generated at 2022-06-26 10:44:42.502829
# Unit test for function tokenize_json
def test_tokenize_json():
    input = r'''
{
  "glossary": {
    "title": "example glossary",
    "GlossDiv": {
      "title": "S",
      "GlossList": {
        "GlossEntry": {
          "ID": "SGML",
          "SortAs": "SGML",
          "GlossTerm": "Standard Generalized Markup Language",
          "Acronym": "SGML",
          "Abbrev": "ISO 8879:1986",
          "GlossDef": {
            "para": "A meta-markup language, used to create markup languages such as DocBook.",
            "GlossSeeAlso": ["GML", "XML"]
          },
          "GlossSee": "markup"
        }
      }
    }
  }
}
'''
    token

# Generated at 2022-06-26 10:44:54.777770
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests for empty content.
    def test_case_1():
        content = ""
        with pytest.raises(ParseError) as exc_info:
            tokenize_json(content)

    # Tests for valid content.
    def test_case_2():
        content = '{ "foo": "bar" }'
        tokenize_json(content)

    # Tests for invalid parse.
    def test_case_3():
        content = "{ foo: 'bar' }"
        with pytest.raises(ParseError) as exc_info:
            tokenize_json(content)

    # Tests for invalid content.
    def test_case_4():
        content = "Ã¼ber json string"

# Generated at 2022-06-26 10:45:05.349874
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.utils.convert import decode_value
    from typesystem.schemas import Schema
    from typesystem import fields

    class SimpleTypeSystem(Schema):
        fieldname = fields.String()
        other_fieldname = fields.Integer()

    content = '''\
    {
        "fieldname": "foo",
        "other_fieldname": "1"
    }'''

    token = tokenize_json(content)
    assert token.decode() == {"fieldname": "foo", "other_fieldname": 1}

    token = tokenize_json(content.encode("utf-8"))
    assert token.decode() == {"fieldname": "foo", "other_fieldname": 1}

    value, error_messages = validate_json(content, validator=SimpleTypeSystem)

# Generated at 2022-06-26 10:45:09.613748
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"f": [1, 2, 3]}'
    value = tokenize_json(content)
    # The following is a type stub annotation that may be useful,
    # but should be ignored by the code generator.
    # def tokenize_json(content: typing.Union[str, bytes]) -> Token: ...
    if False:
        pass


# Generated at 2022-06-26 10:45:11.662205
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') is not None


# Generated at 2022-06-26 10:45:24.804434
# Unit test for function tokenize_json
def test_tokenize_json():
    # Parse errors

    # Parse a JSON string and return a Token representing the parsed JSON.
    json_content = '{"foo": "bar"}'
    output = tokenize_json(json_content)
    expected_output = DictToken(
        {"foo": ScalarToken("bar", start=8, end=12, content=json_content)},
        start=0,
        end=13,
        content=json_content,
    )
    assert output == expected_output

    json_content = '"foo"'
    output = tokenize_json(json_content)
    expected_output = ScalarToken("foo", start=1, end=4, content=json_content)
    assert output == expected_output

    json_content = '{"foo": null}'
    output = tokenize_json(json_content)

# Generated at 2022-06-26 10:45:33.857922
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:45:46.027532
# Unit test for function tokenize_json
def test_tokenize_json():
    data = b"""
    {
        "id": 1,
        "name": "John Smith",
        "is_employee": true,
        "age": null,
        "address": {
            "street": "10 Market Street",
            "city": "San Francisco",
            "state": "CA",
            "zip": 94111,
            "country": "USA"
        },
        "notes": [
            "Likes to rock climb",
            "Works out daily"
        ],
        "lucky_numbers": [
            1,
            2,
            3,
            4,
            5
        ]
    }
    """
    token = tokenize_json(data)
    assert token



# Generated at 2022-06-26 10:45:53.947852
# Unit test for function tokenize_json
def test_tokenize_json():
    input_0 = '''
    {
        "foo": "bar"
    }
    '''
    input_1 = '''
    {
        "f o o": "bar"
    }
    '''
    input_2 = '''
    {
        "foo": true
    }
    '''
    input_3 = '''
    {
        "foo": null
    }
    '''
    input_4 = '''
    {
        "foo": {
            "bar": 1,
            "baz": 3.14
        },
        "boo": []
    }
    '''

# Generated at 2022-06-26 10:45:56.269788
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    #line 43:test_tokenize_json
    '''

    content = '{"test": "value"}'
    expected = DictToken({'test': ScalarToken('value', 7, 11, content)}, 0, 19, content)
    actual = tokenize_json(content)
    assert actual == expected


# Generated at 2022-06-26 10:46:03.968482
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}, f"tokenize_json returned {tokenize_json('{}')}"
    assert tokenize_json("[]") == [], f"tokenize_json returned {tokenize_json('[]')}"
    assert tokenize_json('"foo"') == "foo", f"tokenize_json returned {tokenize_json('foo')}"
    assert tokenize_json("null") == None, f"tokenize_json returned {tokenize_json('null')}"
    assert tokenize_json("true") is True, f"tokenize_json returned {tokenize_json('true')}"
    assert tokenize_json("false") is False, f"tokenize_json returned {tokenize_json('false')}"

# Generated at 2022-06-26 10:46:08.638267
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo":"bar"}'
    value = tokenize_json(content)
    assert value.type == '{}'
    assert value.value == {'foo': 'bar'}



# Generated at 2022-06-26 10:46:12.635841
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = json.dumps({'foo': 'bar'})
    invalid_json = '{"foo": "bar"'
    assert tokenize_json(valid_json)['foo'].value == 'bar'
    with pytest.raises(ParseError):
        tokenize_json(invalid_json)


# Generated at 2022-06-26 10:46:23.953838
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test that valid JSON data parses correctly.
    INPUT = b'{"foo": "bar"}'
    TOKEN = DictToken(
        {
            ScalarToken("foo", 0, 3, INPUT): ScalarToken("bar", 8, 11, INPUT)
        },
        0,
        13,
        INPUT,
    )
    assert TOKEN == tokenize_json(INPUT)

    # Test that invalid JSON data raises a ParseError.
    INPUT = b'{"foo": "bar"'
    ERROR_MESSAGE = ParseError.build(
        text="Expecting value.",
        code="parse_error",
        position=Position(line_no=1, column_no=13, char_index=12),
    )

    value, errors = validate_json(INPUT, {})


# Generated at 2022-06-26 10:46:27.778828
# Unit test for function tokenize_json
def test_tokenize_json():
    with pytest.raises(ParseError) as cm:
        tokenize_json("{}")
    assert cm.value.code == "parse_error"



# Generated at 2022-06-26 10:46:43.416269
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken
    content = '{"hello": ["world", 1]}'
    decoded_value = tokenize_json(content)
    assert isinstance(decoded_value, DictToken)
    assert decoded_value.value == {"hello": ListToken(
        [ScalarToken("world", 12, 17, content), ScalarToken(1, 19, 20, content)]
    )}
    decoded_value = tokenize_json("")
    assert decoded_value is None
    decoded_value = tokenize_json("null")
    assert decoded_value == ScalarToken(None, 0, 3, "null")
    decoded_

# Generated at 2022-06-26 10:46:54.956071
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string_0 = '{"bar": [1, 2, 3]}'
    token_0 = tokenize_json(json_string_0)
    assert type(token_0) == DictToken
    assert token_0.keys() == ["bar"]
    assert token_0.get("bar").values == [1, 2, 3]
    json_string_1 = "[1, 2, 3]"
    token_1 = tokenize_json(json_string_1)
    assert type(token_1) == ListToken
    assert token_1.values == [1, 2, 3]
    invalid_json_string_0 = "{"
    caught = False

# Generated at 2022-06-26 10:47:07.167498
# Unit test for function tokenize_json
def test_tokenize_json():
    # Make sure tokenize_json works when input is expected type (string, bytes)
    # Make sure tokenize_json throws ParseError when input is bytes
    try:
        validate_json(content="{}", validator=Field("string", required=False))
    except ParseError:
        raise AssertionError("tokenize_json throws ParseError on type str")
    # Make sure tokenize_json throws ParseError when input is string
    try:
        validate_json(content=b"{}", validator=Field("string", required=False))
    except ParseError:
        raise AssertionError("tokenize_json throws ParseError on type bytes")
    # Make sure tokenize_json throws ParseError when input is not expected type (string, bytes)

# Generated at 2022-06-26 10:47:17.369339
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing case 0
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None
    assert tokenize_json("") == None



# Generated at 2022-06-26 10:47:26.163014
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that validating known good JSON produces the expected results.
    test_validate_json("[null, 1, 2, 3]")

    # Test that calling the function with invalid JSON raises the expected error.
    test_invalid_json("[null, null")

    # Test that calling the function with valid JSON and a non-Field validator
    # raises a TypeError.
    test_validate_type_error("[]", "[]")



# Generated at 2022-06-26 10:47:34.532839
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{}"
    json_value = tokenize_json(content)
    assert isinstance(json_value, dict)
    assert len(json_value) == 0
    content = "{\"foo\":42}"
    json_value = tokenize_json(content)
    assert isinstance(json_value, dict)
    assert len(json_value) == 1
    assert json_value["foo"] == 42
    content = "{\"foo\":42, \"bar\":[{\"baz\":\"qux\"}]}"
    json_value = tokenize_json(content)
    assert isinstance(json_value, dict)
    assert len(json_value) == 2
    assert json_value["foo"] == 42
    assert isinstance(json_value["bar"], list)
    assert len(json_value["bar"]) == 1

# Generated at 2022-06-26 10:47:43.356494
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("[1, 2]")
    assert isinstance(token, ListToken)
    assert len(token.children) == 2
    assert isinstance(token.children[0], ScalarToken)
    assert token.children[0].value == 1

    token = tokenize_json("{}")
    assert isinstance(token, DictToken)

    message = "Expecting property name enclosed in double quotes"
    code = "parse_error"
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{1:2}")
    assert message in str(excinfo.value)
    assert excinfo.value.code == code
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo

# Generated at 2022-06-26 10:47:52.036094
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = r'{"foo": "bar", "number": 1}'
    token = tokenize_json(valid_json)
    assert isinstance(token, DictToken)

    # Handle cases that result in a JSON parse error.
    invalid_json = '{"foo": 1, "bar": 2,}'
    with pytest.raises(ParseError) as exc:
        tokenize_json(invalid_json)
    assert exc.value.code == "parse_error"



# Generated at 2022-06-26 10:47:55.631524
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"type": "string", "name": "a name"}')
    assert isinstance(token, Token)



# Generated at 2022-06-26 10:48:01.838742
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json(content = "")
    except ParseError as e:
        assert (e.position.line_no) == 1
        assert (e.position.column_no) == 1
        assert (e.position.char_index) == 0
        assert (e.code) == "no_content"
        assert (e.text) == "No content."


# Generated at 2022-06-26 10:48:23.016666
# Unit test for function tokenize_json
def test_tokenize_json():
    # TODO: refactor this to use a parametrized test

    content_0 = "{\"foo\": true}"
    expect_0 = DictToken(
        {
            ScalarToken("foo", 1, 4, content_0)
            : ScalarToken(True, 9, 12, content_0)
        },
        0,
        14,
        content_0
    )
    assert tokenize_json(content_0) == expect_0

    content_1 = "[{""foo"": null}]"

# Generated at 2022-06-26 10:48:30.091739
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json('{"key_1":"value_1","key_2":null,"key_3":true,"key_4":false,"key_5":1.0,"key_6":0.0,"key_7":1}')
    tokenize_json('{"key_1":"value_1","key_2":null,"key_3":true,"key_4":false,"key_5":1.0,"key_6":0.0,"key_7":1}')


# Generated at 2022-06-26 10:48:36.615638
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty input.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert str(exc) == (
            "No content. It looks like you didn't pass any JSON data. Check that a valid JSON "
            "string was passed to the parser."
        )

    # Test valid input.
    token = tokenize_json(
        '{"foo": "bar"}'
    )
    assert token.value == {"foo": "bar"}
    assert type(token.value) == dict

    # Test invalid input.
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:
        assert str(exc) == (
            "Unterminated string starting at: line 1 column 12 (char 11)."
        )



# Generated at 2022-06-26 10:48:42.468324
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"a":1, "b": 2}, {"c":3}]'
    validator = Schema([{"a": int, "b": int}, {"c": int}])
    value, messages = validate_json(content, validator)
    assert value == [{"a": 1, "b": 2}, {"c": 3}]
    assert len(messages) == 0



# Generated at 2022-06-26 10:48:49.997182
# Unit test for function tokenize_json
def test_tokenize_json():
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True
    assert True

# Generated at 2022-06-26 10:49:03.069600
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') is not None
    assert tokenize_json('{"a": 1}') is not None
    assert tokenize_json('{"b": 1}') is not None
    assert tokenize_json('{"a": 2}') is not None
    assert tokenize_json('{"b": 2}') is not None
    assert tokenize_json('{"a": 3}') is not None
    assert tokenize_json('{"b": 3}') is not None
    assert tokenize_json('{"b": 4}') is not None
    assert tokenize_json('{"a": 4}') is not None
    assert tokenize_json('{"b": 5}') is not None
    assert tokenize_json('{"a": 5}') is not None

# Generated at 2022-06-26 10:49:15.438957
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with a decimal string, should work just fine.
    assert tokenize_json(b"123") == ScalarToken(value=123, start=0, end=2, content="123")

    with pytest.raises(ParseError) as exc:
        # An empty string is not acceptable.
        tokenize_json(b"")

    # Make sure the tokenize_json function behaves as we expect.
    assert isinstance(exc.value, ParseError)
    assert "No content" in str(exc.value)
    assert exc.value.code == "no_content"
    assert exc.value.position == Position(line_no=1, column_no=1, char_index=0)

    with pytest.raises(ParseError) as exc:
        # Can't parse a non-string.
        token

# Generated at 2022-06-26 10:49:25.391586
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "key1": "value1",
  "key2": 2,
  "key3": 3.14,
  "key4": true,
  "key5": false,
  "key6": null,
  "key7": [
    1,
    2,
    3
  ]
}
"""
    parsed = tokenize_json(content.encode("utf-8"))

    assert parsed.__class__ is DictToken
    assert parsed._mapping["key1"].__class__ is ScalarToken
    assert parsed._mapping["key1"]._value == "value1"
    assert parsed._mapping["key2"].__class__ is ScalarToken
    assert parsed._mapping["key2"]._value == 2
    assert parsed._mapping["key3"].__

# Generated at 2022-06-26 10:49:33.728764
# Unit test for function tokenize_json
def test_tokenize_json():
    cases: typing.List[typing.Tuple[str, Token]] = [
        ('{ "key" : "value", "key2" : ["list", "item"] }', { "key": "value", "key2": ["list", "item"] }),
    ]
    for (content, expected) in cases:
        try:
            actual = tokenize_json(content)
        except ParseError:
            pass
        assert actual == expected

# Generated at 2022-06-26 10:49:46.249329
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:50:05.303474
# Unit test for function tokenize_json
def test_tokenize_json():
    # Case #0: Run through the _TokenizingDecoder
    # Example:
    #   content = '{ "key": "value" }'
    #   result = tokenize_json(content)
    #   assert isinstance(result, DictToken)

    tokenizing_decoder_0 = _TokenizingDecoder()
    content_0 = '{ "key": "value" }'
    result_0 = tokenize_json(content_0)
    assert isinstance(result_0, DictToken)


# Generated at 2022-06-26 10:50:17.759626
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads


# Generated at 2022-06-26 10:50:20.482187
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"foo": 1}'
    assert tokenize_json(json) == {'foo': 1}



# Generated at 2022-06-26 10:50:29.222918
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('  ') == {}
    assert tokenize_json('') == {}
    assert tokenize_json('0') == 0
    assert tokenize_json('1') == 1
    assert tokenize_json('true') == True
    assert tokenize_json('false') == False
    assert tokenize_json('null') == None
    assert tokenize_json('[1, 2]') == [1, 2]
    assert tokenize_json('{"foo": 4, "bar": "hello"}') == {"foo": 4, "bar": "hello"}

# Generated at 2022-06-26 10:50:38.493775
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = b'{ "hi" : "hello" }'
    result_0 = tokenize_json(content_0)
    content_1 = '{ "hi" : "hello" }'
    result_1 = tokenize_json(content_1)
    content_2 = '{ "hi" : "hello" }'
    result_2 = tokenize_json(content_2)
    content_3 = '{ "hi" : "hello" }'
    result_3 = tokenize_json(content_3)
    content_4 = '{ "hi" : "hello" }'
    result_4 = tokenize_json(content_4)
    content_5 = '{ "hi" : "hello" }'
    result_5 = tokenize_json(content_5)

# Generated at 2022-06-26 10:50:42.017677
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"title":"Foo","price":1.99}'
    expected = {'title': 'Foo', 'price': 1.99}
    result = tokenize_json(content)
    assert result == expected

# Unit tests for function tokenize_json

# Generated at 2022-06-26 10:50:54.664582
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("123") == ScalarToken(123, 0, 2, "123")
    assert tokenize_json("123.0") == ScalarToken(123.0, 0, 4, "123.0")

# Generated at 2022-06-26 10:51:07.545238
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{\"name\": \"hello\"}"

    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.get_position() == Position(column_no=1, line_no=1, char_index=0)
    assert token.get_position(absolute_end=True) == Position(column_no=16, line_no=1, char_index=15)
    assert token.content == content

    try:
        tokenize_json("")
        assert False, "Expecting ParseError"  # pragma: no cover
    except ParseError:
        pass

    try:
        tokenize_json('"')
        assert False, "Expecting ParseError"  # pragma: no cover
    except ParseError:
        pass



# Generated at 2022-06-26 10:51:12.479458
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("[1, 2, 3]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]



# Generated at 2022-06-26 10:51:19.747607
# Unit test for function tokenize_json
def test_tokenize_json():
    decoder = _TokenizingJSONObject()
    memo = {}
    content = "Content is a string"
    strict = True
    class_to_instantiate = _TokenizingDecoder
    instance_of_class_to_instantiate = class_to_instantiate
    class_to_instantiate2 = _TokenizingDecoder
    instance_of_class_to_instantiate2 = class_to_instantiate2
    class_to_instantiate3 = JSONDecoder
    instance_of_class_to_instantiate3 = class_to_instantiate3

# Generated at 2022-06-26 10:51:38.662998
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = {"spec": {"scalar": [1, 2, 3]}}
    tokenizing_decoder_0 = _TokenizingDecoder()
    token_0: typing.Union[DictToken, Token] = tokenizing_decoder_0.decode(content_0)
    assert isinstance(token_0, DictToken)
    assert token_0.value == {
        "spec": {"scalar": [1, 2, 3]}
    }  # type: ignore[dict-item]
    assert isinstance(token_0.value["spec"], DictToken)