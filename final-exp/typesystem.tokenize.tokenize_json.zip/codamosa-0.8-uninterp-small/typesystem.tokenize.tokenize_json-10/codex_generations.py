

# Generated at 2022-06-26 10:42:32.320971
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"key": "value", "null": null, "true": true, "false": false, "number": 1.23}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)

# Generated at 2022-06-26 10:42:41.792245
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for bytes
    value = b"{\"test\":true}"
    token = tokenize_json(value)
    assert len(token.values.values()) == 1
    assert token.values["test"].value is True
    assert token.values["test"].position.column_no == 6
    assert token.values["test"].position.line_no == 1
    # Test for string
    value = "{\"test\":true}"
    token = tokenize_json(value)
    assert len(token.values.values()) == 1
    assert token.values["test"].value is True
    assert token.values["test"].position.column_no == 6
    assert token.values["test"].position.line_no == 1


# Generated at 2022-06-26 10:42:54.935021
# Unit test for function tokenize_json
def test_tokenize_json():

    # Simple tests
    token = tokenize_json('{"foo": {"bar": [1, 2, 3]}}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": {"bar": [1, 2, 3]}}

    token = tokenize_json('{"x": "1.0"')
    assert isinstance(token, DictToken)
    assert token.value == {"x": "1.0"}

    # Test for JSONDecodeError
    try:
        tokenize_json("{} {}")
    except JSONDecodeError as exc:
        assert exc.msg == "Expecting '}' delimiter"
        assert exc.lineno == 1
        assert exc.colno == 4
        assert exc.pos == 3

# Generated at 2022-06-26 10:43:05.015015
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:43:11.561035
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    assert excinfo.value.code == "no_content"
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)

    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"foo": "')
    assert excinfo.value.text == "Unterminated string starting at: line 1 column 11 (char 10)"
    assert excinfo.value.code == "parse_error"

# Generated at 2022-06-26 10:43:18.888622
# Unit test for function tokenize_json
def test_tokenize_json():
    from typing import Any, Optional
    from ..tokenize.positional_validation import validate_with_positions

    def assert_tokens_equal(
        content: str, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> None:
        token = tokenize_json(content.encode())
        value, errors = validate_with_positions(token=token, validator=validator)
        assert not errors, errors
        assert value == validator.parse(content)
        # Positions are 0-indexed, but we should display 1-indexed.
        assert token.value_pos == Position(
            column_no=1, line_no=1, char_index=0
        ), token.value_pos


# Generated at 2022-06-26 10:43:29.621539
# Unit test for function tokenize_json
def test_tokenize_json():
    # Evaluate tokenize_json for a case where the result is valid.
    json_string = '{"a": "hi"}'
    expected = {"a": "hi"}
    assert tokenize_json(json_string) == expected

    # Evaluate tokenize_json for a case where the result is invalid.
    json_string_2 = '{"a: "hi"}'
    with pytest.raises(ParseError) as e:
        tokenize_json(json_string_2)
    assert e.value.code == "parse_error"

    # Evaluate tokenize_json for a case where the result is invalid.
    json_string_3 = '{"a": "hi}'
    with pytest.raises(ParseError) as e:
        tokenize_json(json_string_3)
    assert e

# Generated at 2022-06-26 10:43:40.948421
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case where content is a str
    content_0 = '{"name":"ram","age":23,"language":["python","java","ruby"]}'
    token_0 = tokenize_json(content_0)
    assert token_0.start == 0
    assert token_0.end == 60
    assert token_0.value == {"name": "ram", "age": 23, "language": ["python", "java", "ruby"]}
    assert token_0.type == "dict"
    assert token_0.content == '{"name":"ram","age":23,"language":["python","java","ruby"]}'
    assert token_0.key == None
    token_1 = token_0.children[0]
    assert token_1.start == 2
    assert token_1.end == 13

# Generated at 2022-06-26 10:43:53.741791
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content_0 = b"\xc2\xa9\xe2\x84\xa2"
    expected_1 = ScalarToken("©™", 1, 10, "©™")
    actual_1 = tokenize_json(test_content_0)
    assert actual_1 == expected_1, "Expected {0}, got {1}.".format(expected_1, actual_1)

    test_content_1 = "hello"
    expected_2 = ScalarToken("hello", 1, 6, "hello")
    actual_2 = tokenize_json(test_content_1)
    assert actual_2 == expected_2, "Expected {0}, got {1}.".format(expected_2, actual_2)

    test_content_2 = "{\"a\": 1, \"b\": true}"
    expected_

# Generated at 2022-06-26 10:44:01.173247
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json(""), Token)
    assert isinstance(tokenize_json(b""), Token)
    assert tokenize_json("") == tokenize_json(b"")
    assert isinstance(tokenize_json("[]"), ListToken)
    
    # Verify that tokenize_json properly praises valid JSON content
    assert tokenize_json("1234") == ScalarToken(value=1234, start=0, end=3, content="1234")

    # Verify that tokenize_json raises an error on invalid JSON content
    try:
        tokenize_json("this is not valid json")
    except ParseError as e:
        assert e.position == Position(column_no=1, line_no=1, char_index=0)
        assert e.text == "No content."
        assert e.code

# Generated at 2022-06-26 10:44:18.037342
# Unit test for function tokenize_json
def test_tokenize_json():
    data = {}
    content = '{"foo": 1}'
    tokenize_json(content)
    tokenize_json(content.encode())
    content = '{"foo": 1}'
    tokenize_json(content)
    tokenize_json(content.encode())
    content = '{"foo": [1,2,3]}'
    tokenize_json(content)
    tokenize_json(content.encode())
    content = '{"foo": [1,2,3]}'
    tokenize_json(content)
    tokenize_json(content.encode())



# Generated at 2022-06-26 10:44:22.318610
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') is None, 'expected None'
    assert tokenize_json('1') is None, 'expected None'


# Generated at 2022-06-26 10:44:27.667265
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases
    # content - A JSON string or bytestring.
    # validator - A Field instance or Schema class to validate against.
    # AssertionError: expected no exception, got <class 'typesystem.exceptions.ParseError'>
    test_case_0()



# Generated at 2022-06-26 10:44:30.395027
# Unit test for function tokenize_json
def test_tokenize_json():
    content = ''
    tokenize_json(content)



# Generated at 2022-06-26 10:44:41.589735
# Unit test for function tokenize_json
def test_tokenize_json():
    # test for a valid json
    json_0 = '{"the": "quick", "brown" :"fox"}'
    json_1 = '[{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"}]'
    json_2 = '{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"}'
    json_3 = '{"the": "quick", "brown" :"fox"}'
    json_4 = '[{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"},{"the": "quick", "brown" :"fox"}]'

# Generated at 2022-06-26 10:44:46.903036
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 5}') == DictToken({'a': ScalarToken(5)}, 0, 7, '{"a": 5}')
    assert tokenize_json('[1, 2, 3]') == ListToken([ScalarToken(1), ScalarToken(2), ScalarToken(3)], 0, 8, '[1, 2, 3]')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')


# Generated at 2022-06-26 10:44:48.295462
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") is None



# Generated at 2022-06-26 10:45:02.576718
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"a": 1}') == DictToken({"a": 1}, 0, 6, '{"a": 1}')
    assert tokenize_json('{"b": [1, "abcd"]}') == DictToken({"b": [1, "abcd"]}, 0, 14, '{"b": [1, "abcd"]}')


if __name__ == "__main__":
    import pytest

    pytest.main(args=[".", "--doctest-modules", "-v", "--capture=sys"])

# Generated at 2022-06-26 10:45:11.503517
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case:
    test_content = '[{"key": "value", "abc": "def"}]'
    assert list(tokenize_json(test_content).values.items()) == [(
        ScalarToken('key', 1, 9, test_content),
        ScalarToken('value', 12, 20, test_content),
    ), (
        ScalarToken('abc', 21, 30, test_content),
        ScalarToken('def', 33, 38, test_content),
    )]
    # Test case:
    test_content = '{"key": "value", "abc": "def"}'

# Generated at 2022-06-26 10:45:22.110061
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'"string"') == ScalarToken('string', 0, 8, '"string"')
    assert tokenize_json('"string"') == ScalarToken('string', 0, 8, '"string"')
    assert tokenize_json(b'{}') == DictToken({}, 0, 2, '{}')
    assert tokenize_json('{}') == DictToken({}, 0, 2, '{}')
    assert tokenize_json(b'{"foo": "bar"}') == DictToken({ScalarToken('foo', 1, 7, '"foo"'): ScalarToken('bar', 10, 16, '"bar"')}, 0, 17, '{"foo": "bar"}')

# Generated at 2022-06-26 10:45:33.480792
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"foo": "bar"}]'
    token = tokenize_json(content)
    assert token.value[0].value['foo'].value == 'bar'


# Generated at 2022-06-26 10:45:35.672440
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')


# Generated at 2022-06-26 10:45:48.563862
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.test_data import json_test_data

    for result, content in json_test_data:
        token = tokenize_json(content)
        assert isinstance(token, DictToken)
        assert token.token_type == "dict"
        assert token.raw == result
        assert token.value == result

    # Test invalid content
    position = Position(column_no=3, line_no=2, char_index=5)
    text = "Expecting property name enclosed in double quotes"
    code = "parse_error"

    content = '{"one": 2, foo": 3}'
    assert tokenize_json(content)

# Generated at 2022-06-26 10:46:01.341332
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:46:05.026182
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[1, 2]")
    assert tokenize_json(b"[1, 2]")


# Generated at 2022-06-26 10:46:14.822521
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        assert tokenize_json("") == {}
    except ParseError:
        pass
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    try:
        assert tokenize_json("123") == ScalarToken(123, 0, 2, "123")
    except Exception:
        pass
    assert tokenize_json("[1, 2, 3]") == ListToken([ScalarToken(1, 1, 1, "1"), ScalarToken(2, 4, 4, "2"), ScalarToken(3, 7, 7, "3")], 0, 9, "[1, 2, 3]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-26 10:46:24.572987
# Unit test for function tokenize_json
def test_tokenize_json():
    simple_dict = '{"name":"foo","age":42}'
    token = tokenize_json(simple_dict)
    assert type(token) == DictToken
    assert token.value["name"] == "foo"
    assert token.value["age"] == 42
    
    simple_list = "[1, 2, 3]"
    token = tokenize_json(simple_list)
    assert type(token) == ListToken
    assert token.value == [1, 2, 3]
    
    null_value = "null"
    token = tokenize_json(null_value)
    assert type(token) == ScalarToken
    assert token.value == None
    
    true_value = "true"
    token = tokenize_json(true_value)
    assert type(token) == ScalarToken

# Generated at 2022-06-26 10:46:30.244628
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{\n\"foo\": \"bar\"}") == DictToken(  # type: ignore
        {"foo": ScalarToken("bar", 6, 13, "{\"foo\": \"bar\"}")}, 0, 18, "{\"foo\": \"bar\"}"
    )



# Generated at 2022-06-26 10:46:37.095283
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(['{"a": 1}']) == ['{"a": 1}']
    assert tokenize_json(['{"a": 1}']) == ['{"a": 1}']
    assert tokenize_json(['{"a": 1}']) == ['{"a": 1}']
    assert tokenize_json(['{"a": 1}']) == ['{"a": 1}']


# Generated at 2022-06-26 10:46:46.761728
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case where content is a JSON string.
    json_string = '{"foo": "bar"}'
    f = io.StringIO(json_string)
    result_1 = tokenize_json(f)
    assert isinstance(result_1, DictToken)
    assert result_1.to_json() == json_string
    # Test case where content is a JSON bytestring.
    result_2 = tokenize_json(json_string.encode())
    assert isinstance(result_2, DictToken)
    assert result_2.to_json() == json_string
    # Test case where content is a non-empty string.
    result_3 = tokenize_json("foo")
    assert isinstance(result_3, ScalarToken)
    assert result_3.to_json() == '"foo"'


# Generated at 2022-06-26 10:46:59.870283
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
    "a": ["A", "B", "C"]
}"""
    token = tokenize_json(content.encode("utf-8"))
    assert isinstance(token, DictToken)
    assert token.value["a"]
    assert isinstance(token.value["a"], ListToken)
    assert token.value["a"].value[0] == "A"
    assert token.value["a"].value[1] == "B"
    assert token.value["a"].value[2] == "C"



# Generated at 2022-06-26 10:47:13.316791
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with string:
    content = '{"field": "value"}'
    token_0 = tokenize_json(content)
    assert token_0.kind == "dict"
    assert token_0.start_pos == Position(column_no=1, line_no=1, char_index=0)
    assert token_0.end_pos == Position(column_no=17, line_no=1, char_index=16)
    assert token_0.children == {
        "field": ScalarToken(
            "value",
            start_pos=Position(column_no=3, line_no=1, char_index=2),
            end_pos=Position(column_no=11, line_no=1, char_index=10),
            content=content,
        )
    }
    assert token_0

# Generated at 2022-06-26 10:47:21.503736
# Unit test for function tokenize_json
def test_tokenize_json():
    # NOTE: These test cases are generated via `./test_run.sh`
    with open('./test_cases/cases.json') as test_cases:
        for case in json.load(test_cases):
            content = case['content']
            expected = case['expected'] if 'expected' in case else None
            try:
                actual = tokenize_json(json.loads(content))
            except Exception as exception:
                actual = exception
            try:
                assert actual == expected
            except AssertionError as e:
                raise AssertionError('assertion error on line {}'.format(inspect.currentframe().f_lineno)) from e
    print('Testcase passed: {} passed, {} failed'.format(0, 0))


# Generated at 2022-06-26 10:47:27.459757
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = "7"
    value_0 = tokenize_json(content_0)
    primary_type_0 = type(value_0)
    assert primary_type_0 == ScalarToken
    assert value_0.value == 7


# Generated at 2022-06-26 10:47:39.010626
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json('  \n\t "foo" \t\n   ') == ScalarToken("foo", 2, 9, '"foo"')
    assert tokenize_json("{}") == DictToken({}, 0, 2, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 2, "[]")
    assert tokenize_json("[]").as_list() == []



# Generated at 2022-06-26 10:47:41.413361
# Unit test for function tokenize_json
def test_tokenize_json():
    return
    try:
        content = None
        validator = None
        tokenize_json(content, validator)
    except (ParseError, ValidationError) as exc:
        exc
    else:
        raise AssertionError("Unreachable code.")


# Generated at 2022-06-26 10:47:47.004957
# Unit test for function tokenize_json
def test_tokenize_json():
    def make_empty_string_error():
        return ParseError(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))

    result = tokenize_json('{"key": "value"}')
    assert isinstance(result, DictToken)
    result = tokenize_json('{"key": "value", "key2": "value2"}')
    assert isinstance(result, DictToken)
    result = tokenize_json('[1,2,3]')
    assert isinstance(result, ListToken)
    result = tokenize_json('["1","2","3"]')
    assert isinstance(result, ListToken)
    result = tokenize_json('true')
    assert isinstance(result, ScalarToken)
    result = tokenize

# Generated at 2022-06-26 10:47:52.834466
# Unit test for function tokenize_json
def test_tokenize_json():
    validator = Field(required=True, primitive_type=str)
    assert validate_json(b'{"foo":"bar"}', validator=validator) == (
        {"foo": "bar"},
        [],
    )
    assert validate_json(b'{"foo":"bar","bar":"baz"}', validator=validator) == (
        {"foo": "bar", "bar": "baz"},
        [],
    )



# Generated at 2022-06-26 10:47:57.026152
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(""), ListToken([], 0, 0, "")
    assert tokenize_json("[],"), ListToken([None, None], 0, 3, "[],")

# Generated at 2022-06-26 10:48:05.583718
# Unit test for function tokenize_json
def test_tokenize_json():
    # parsing empty string
    assert tokenize_json(b"") == {}

    # dictionary
    assert tokenize_json(b'{"foo": "bar"}') == {"foo": "bar"}

    # lists
    assert tokenize_json(b'"foo"') == "foo"
    assert tokenize_json(b'["foo"]') == ["foo"]

    # floats
    assert tokenize_json(b"-2") == -2
    assert tokenize_json(b"-2.0") == -2.0
    assert tokenize_json(b"1e1") == 10

    # ints and floats roundtrip
    assert tokenize_json(b"-1.0") == -1.0
    assert tokenize_json(b"0") == 0
    assert tokenize_json(b"1") == 1
    assert token

# Generated at 2022-06-26 10:48:23.222071
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that the ParserError exception is raised on a empty string.
    try:
        validate_json(content="", validator=Schema)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."
        assert exc.code == "no_content"
    else:
        assert False

    try:
        validate_json(content='{"a":1}', validator=Schema)
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 7
        assert exc.text == "Expecting property name enclosed in double quotes."
       

# Generated at 2022-06-26 10:48:34.746340
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "number": 1,
        "string": "foo",
        "boolean_true": true,
        "boolean_false": false,
        "null": null,
        "array": [
            1,
            "foo",
            true,
            false,
            null
        ]
    }
    """
    result = tokenize_json(content)
    expected = {
        "number": 1.0,
        "string": "foo",
        "boolean_true": True,
        "boolean_false": False,
        "null": None,
        "array": [1.0, "foo", True, False, None],
    }
    assert result == expected



# Generated at 2022-06-26 10:48:39.515389
# Unit test for function tokenize_json
def test_tokenize_json():
    # raise ParseError(text=exc.msg + ".", code="parse_error", position=position)
    content = '[1,2,3]'
    tokenize_json(content)


# Generated at 2022-06-26 10:48:48.058657
# Unit test for function tokenize_json
def test_tokenize_json():
    # Simple test
    assert tokenize_json('{"a": 1}') == {'a': 1}

    # Test a list with an inner dict
    assert tokenize_json('[{"a": 1}]') == [{'a': 1}]

    # Test a tuple
    assert tokenize_json('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}

    # Test a nested list
    assert tokenize_json('[{"a": [1, 2, 3]}]') == [{'a': [1, 2, 3]}]



# Generated at 2022-06-26 10:48:58.048151
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """[
        {
            "title": "hello",
            "name": "dog",
            "x": "1"
        },
        {
            "title": "hi",
            "name": "cat",
            "x": "2"
        }
    ]"""
    token = tokenize_json(json_string)
    assert token.start == 0
    assert token.end == len(json_string)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2
    assert token.value[0].start == 9
    assert token.value[0].end == len(json_string) - 1
    assert token.value[0].value == {
        "title": "hello",
        "name": "dog",
        "x": "1",
    }



# Generated at 2022-06-26 10:49:03.806820
# Unit test for function tokenize_json
def test_tokenize_json():
    # Pass empty string
    # Condition that results in a ParseError
    from typesystem.exceptions import ParseError as ParseError

    # SubTest 1
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0

    # Pass empty string
    # SubTest 2
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0

    # Pass empty string
    # SubTest

# Generated at 2022-06-26 10:49:15.860628
# Unit test for function tokenize_json
def test_tokenize_json():
    # Verify that a ParseError is raised when given invalid JSON
    with pytest.raises(ParseError):
        tokenize_json('{"foo": }')

    with pytest.raises(ParseError):
        tokenize_json('{ "foo":')

    # Verify that empty strings raise an appropriate error
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('')
    assert excinfo.value.code == "no_content"

    with pytest.raises(ParseError) as excinfo:
        tokenize_json('  ')
    assert excinfo.value.code == "no_content"

    # Verify that a DictToken is returned for a valid JSON object
    token = tokenize_json('{"foo": "bar"}')

# Generated at 2022-06-26 10:49:25.546173
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"unquoted_string"') == 'unquoted_string'
    assert tokenize_json('["un","quoted","string"]') == ["un","quoted","string"]
    assert tokenize_json('true') == True
    assert tokenize_json('false') == False
    assert tokenize_json('"\\" quote"') == "\" quote"
    assert tokenize_json('"\\f"') == "\f"
    assert tokenize_json('"\\b"') == "\b"
    assert tokenize_json('"\\n"') == "\n"
    assert tokenize_json('"\\r"') == "\r"
    assert tokenize_json('"\\t"') == "\t"
    assert tokenize_json('"\\u1234"') == "\u1234"


# Generated at 2022-06-26 10:49:37.181673
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test case tokenize_json_0
    content_0 = "test"
    try:
        assert tokenize_json(
            content_0
        ) == JSONDecodeError(msg="Expecting value", doc="test", pos=0), (
            "Expected: "
            + str(JSONDecodeError(msg="Expecting value", doc="test", pos=0))
            + "\nFound: "
            + str(tokenize_json(content_0))
        )
    except Exception as e:
        print(
            "Test case tokenize_json_0 failed: "
            + str(e)
            + "\n"
            + str(tokenize_json(content_0))
        )

    # Test case tokenize_json_1
    content_1 = "*"

# Generated at 2022-06-26 10:49:44.869544
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'""') == ScalarToken(u'', 0, 1, b'"')
    assert tokenize_json(b'') == ScalarToken(u'', 0, 1, b'"')
    assert tokenize_json(b'{}') == DictToken(
        {},
        0,
        1,
        b'{',
    )
    assert tokenize_json(b'[]') == ListToken([], 0, 1, b'[')
    assert tokenize_json(b'[1]') == ListToken(
        [ScalarToken(1, 1, 2, b'1')],
        0,
        3,
        b'[',
    )

# Generated at 2022-06-26 10:49:58.714136
# Unit test for function tokenize_json
def test_tokenize_json():
    from pydantic import BaseModel, Field, HttpUrl, constr, root_validator

    class MySchema(BaseModel):
        one: int
        two: int

    tokenize_json_0 = Schema(MySchema, content="{}")
    tokenize_json_1 = tokenize_json_0.validate(content="{}")

    tokenize_json_2 = tokenize_json_0.validate(content='{"one": 1}')
    tokenize_json_3 = tokenize_json_0.validate(content='{"one": 1, "two": 2}')
    tokenize_json_4 = tokenize_json_0.validate(content='{"one": "one"}')

# Generated at 2022-06-26 10:50:07.938128
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty cases
    assert tokenize_json(None) == None
    assert tokenize_json(b"") == None
    assert tokenize_json(u"") == None

    # Test JSON string
    assert tokenize_json(b"{}") == {}, "Parse error."
    assert tokenize_json(u"{}") == {}, "Parse error."
    assert tokenize_json(b'"Hello World!') == unicode('Hello World!'), "Parse error."
    assert tokenize_json(u'"Hello World!"') == unicode('Hello World!'), "Parse error."



# Generated at 2022-06-26 10:50:18.772937
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    tokenize_json() should pass a JSON string and return a JSON Token.
    """
    # Test valid json
    # https://www.json.org/json-en.html
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("[{},{}]") == ListToken([DictToken({}, 1, 2, "[{},{}]"), DictToken({}, 4, 5, "[{},{}]")], 0, 6, "[{},{}]")

# Generated at 2022-06-26 10:50:23.337140
# Unit test for function tokenize_json
def test_tokenize_json():
    print('\ntest_tokenize_json()')
    assert tokenize_json('{"a":"b"}') == {
        'a': 'b'
    }
    assert tokenize_json('["a","b"]') == ['a', 'b']


# Generated at 2022-06-26 10:50:27.204333
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == {
        "key": "value"
    }
    assert tokenize_json('"some string"') == "some string"



# Generated at 2022-06-26 10:50:39.358650
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:50:50.394191
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json(content=123)
        assert False
    except ParseError:
        assert True

    try:
        tokenize_json(content=b"{foo:123}")
        assert False
    except ParseError:
        assert True

    try:
        tokenize_json(content='{"f": "o"}')
        assert True
    except ParseError:
        assert False

    try:
        tokenize_json(content='{"a": "b", "c": "d", "e": "f"}')
        assert True
    except ParseError:
        assert False

    try:
        tokenize_json(content='{"a": "b"}')
        assert True
    except ParseError:
        assert False


# Generated at 2022-06-26 10:50:57.567565
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json_1 = tokenize_json('{"a": "value"}')
    tokenize_json_2 = tokenize_json('"hello"')
    tokenize_json_3 = tokenize_json('[1, "two", 3.0]')
    tokenize_json_4 = tokenize_json('{"a": "value", "b": {"c": "d"}}')
    tokenize_json_5 = tokenize_json('{"a": "value", "b": {"c": "d"}, "e": "f"}')
    tokenize_json_6 = tokenize_json('{"a": "value", "b": {"c": "d"}, "e": "f", "g": "h"}')
    token_json = tokenize_json('{"a": "value"}')
    token_number = tokenize_

# Generated at 2022-06-26 10:51:03.284200
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2]}'
    result = tokenize_json(content)
    dict_0 = {"a": 1, "b": [1, 2]}
    dict_1 = result
    assert dict_0 == dict_1


# Generated at 2022-06-26 10:51:10.654516
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:51:21.594219
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenizing_decoder_0 = _TokenizingDecoder()
    _val = tokenize_json("test_value")
    assert isinstance(_val, Token)
    _val = tokenize_json(123)
    assert isinstance(_val, Token)



# Generated at 2022-06-26 10:51:24.309860
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{}'
    assert isinstance(tokenize_json(content=content), DictToken)


# Generated at 2022-06-26 10:51:28.245403
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(name="test")
    token = tokenize_json("null")
    assert isinstance(token, ScalarToken)
    assert token.evaluate(field) == None



# Generated at 2022-06-26 10:51:33.595798
# Unit test for function tokenize_json
def test_tokenize_json():
    # Check that tokenize_json can tokenize a JSON-encoded list
    assert tokenize_json('[1, 2]') == ListToken([1, 2], 0, 7, '[1, 2]')


# Generated at 2022-06-26 10:51:40.585462
# Unit test for function tokenize_json
def test_tokenize_json():
    import random
    from typesystem.base import Text
    from typesystem.fields import String

    def _test_value(field: Field, value: typing.Any, is_scalar: bool = True) -> None:
        if not is_scalar:
            value_tokens = tokenize_json(value)
            assert type(value_tokens) == field.token_cls
            value = value_tokens.value

        content = json.dumps(value)
        assert json.loads(content) == value

        token = tokenize_json(content)
        assert type(token) == field.token_cls

    field = String()
    _test_value(field=field, value="foo")