

# Generated at 2022-06-26 10:42:00.945930
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for failure case
    try:
        test_case_0()
    except ParseError:
        pass
    # Test for success case
    bytes_0 = '{"foo": "bar"}'
    token_0 = tokenize_json(bytes_0)
    assert token_0.value['foo'].value == 'bar'


# Generated at 2022-06-26 10:42:10.782162
# Unit test for function tokenize_json
def test_tokenize_json():
    json_0 = b'{"a": 1, "b": 2}'
    token_0 = tokenize_json(json_0)
    assert isinstance(token_0, DictToken)
    assert isinstance(token_0.value, dict)
    assert token_0.value["a"] == ScalarToken(1, 3, 5, '{ "a": 1, "b": 2}\n')
    assert token_0.value["b"] == ScalarToken(2, 14, 16,
                                             '{ "a": 1, "b": 2}\n')

    json_1 = b"{}"
    token_1 = tokenize_json(json_1)
    assert isinstance(token_1, DictToken)
    assert isinstance(token_1.value, dict)


# Generated at 2022-06-26 10:42:15.338948
# Unit test for function tokenize_json
def test_tokenize_json():
    print("Test: tokenize_json")

    bytes_1 = b'{"test": "case"}'
    token_1 = tokenize_json(bytes_1)

    assert token_1 == token_1

    bytes_2 = b'{"test": "case"}'
    token_2 = tokenize_json(bytes_2)

    assert token_1 == token_2



# Generated at 2022-06-26 10:42:17.966891
# Unit test for function tokenize_json
def test_tokenize_json():
    bytes_0 = b"true"
    token_0 = tokenize_json(bytes_0)
    assert token_0 is not None

# Simple smoke test for function validate_json

# Generated at 2022-06-26 10:42:23.897092
# Unit test for function tokenize_json
def test_tokenize_json():
    buf = io.BytesIO(b"{}")
    bytes_0 = buf.read()
    token_0 = tokenize_json(bytes_0)
    assert isinstance(token_0, DictToken) == True



# Generated at 2022-06-26 10:42:34.394553
# Unit test for function tokenize_json
def test_tokenize_json():
    # bytes
    bytes_1 = b'{"a": [1, 2, 3]}'
    token_1 = tokenize_json(bytes_1)
    print(token_1)
    # str
    str_1 = '{"a": [1, 2, 3]}'
    token_2 = tokenize_json(str_1)
    print(token_2)
    assert token_1 == token_2

    # bytes
    bytes_2 = b'{"a": [[1, 2], [3, 4]]}'
    token_3 = tokenize_json(bytes_2)
    print(token_3)
    # str
    str_1 = '{"a": [[1, 2], [3, 4]]}'
    token_4 = tokenize_json(str_1)
    print(token_4)

# Generated at 2022-06-26 10:42:42.906722
# Unit test for function tokenize_json
def test_tokenize_json():
    token_0 = tokenize_json(
        b'[ {"key": "value"}, {"key": "value2", "key2": "value3"} ]'
    )
    token_1 = tokenize_json(
        b'[ {"key": "value"}, {"key": "value2", "key2": "value3"} ]'
    )
    token_1 = tokenize_json(
        b'[ {"key": "value"}, {"key": "value2", "key2": "value3"} ]'
    )
    assert token_0 != token_1
    assert token_0 == token_0
    assert token_0 != token_1
    assert token_1 == token_1
    assert token_0 != token_1
    assert token_0 == token_0
    assert token_1 == token_1
    assert token

# Generated at 2022-06-26 10:42:47.047517
# Unit test for function tokenize_json
def test_tokenize_json():
    assert [tokenize_json('{"name":"John Smith","age":33}')] == [{'name': 'John Smith', 'age': 33}]

# Generated at 2022-06-26 10:43:01.488807
# Unit test for function tokenize_json
def test_tokenize_json():
    b'{"a": "123"}'
    dict_obj = tokenize_json(b'{"a": "123"}')
    assert isinstance(dict_obj, DictToken)
    assert dict_obj.value == {"a": ScalarToken('123', 4, 8, '{"a": "123"}')}
    assert dict_obj.start == 0
    assert dict_obj.end == 11
    assert dict_obj.content == '{"a": "123"}'

    b'{"a": 123}'
    dict_obj = tokenize_json(b'{"a": 123}')
    assert isinstance(dict_obj, DictToken)
    assert dict_obj.value == {"a": ScalarToken(123, 4, 7, '{"a": 123}')}
    assert dict_obj.start == 0
    assert dict

# Generated at 2022-06-26 10:43:02.691209
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(None) is None


# Generated at 2022-06-26 10:43:18.975235
# Unit test for function tokenize_json
def test_tokenize_json():
    assert(1 == 1)

    try:
        assert(2 == 1)
    except:
        pass

    with pytest.raises(ValueError):
        assert(1 == 2)

    assert(test_case_0() == None)

    assert(validate_json(b'{}', None) == None)

    assert(tokenize_json(b'{}') == None)

    assert(tokenize_json(b'') == None)

    assert(tokenize_json(b'{"abc": "text"}') == None)

    assert(tokenize_json(b'{"abc": [3,2]}') == None)

    assert(tokenize_json(b'{"abc": [3,2],"def": ["hello", 7]}') == None)

# Generated at 2022-06-26 10:43:29.652041
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}').value == {}
    assert tokenize_json('[]').value == []
    assert tokenize_json('true').value == True
    assert tokenize_json('false').value == False
    assert tokenize_json('null').value == None
    assert tokenize_json('"abc"').value == 'abc'
    assert tokenize_json('1').value == 1
    assert tokenize_json('1.25').value == 1.25
    assert tokenize_json('1.25e+3').value == 1.25e3
    assert tokenize_json('1.25E-01').value == 1.25E-01
    assert tokenize_json('"\\"\\\\\\/"').value == '"\\/'

# Generated at 2022-06-26 10:43:31.261410
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "Alice"}'
    result = tokenize_json(content)
    assert result is not None


# Generated at 2022-06-26 10:43:41.468274
# Unit test for function tokenize_json
def test_tokenize_json():
    bytes_0 = b'{}'
    bytes_1 = b'{"widget": {"debug": "on", "window": {"title": "Sample Konfabulator Widget", "name": "main_window", "width": 500, "height": 500}, "image": {"src": "Images/Sun.png", "name": "sun1", "hOffset": 250, "vOffset": 250, "alignment": "center"}, "text": {"data": "Click Here", "size": 36, "style": "bold", "name": "text1", "hOffset": 250, "vOffset": 100, "alignment": "center", "onMouseUp": "sun1.opacity = (sun1.opacity / 100) * 90;"}}}'

# Generated at 2022-06-26 10:43:51.666673
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that the decoder can decode valid JSON strings.
    assert tokenize_json(b'{}') == DictToken({}, 0, 1, content=b"{}")
    assert tokenize_json('{"key": "value"}') == DictToken(
        {"key": ScalarToken("value", 8, 14, content='{"key": "value"}')},
        0,
        16,
        content='{"key": "value"}',
    )
    assert tokenize_json('["item"]') == ListToken(
        [ScalarToken("item", 6, 10, content='["item"]')], 0, 11, content='["item"]'
    )
    assert tokenize_json('"value"') == ScalarToken(
        "value", 0, 6, content='"value"'
    )
    assert tokenize

# Generated at 2022-06-26 10:43:57.307623
# Unit test for function tokenize_json
def test_tokenize_json():
    # Example 1
    content = b'{"count": 1}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {'count': 1}
    assert token.position.column_no == 1
    assert token.position.line_no == 1
    assert token.position.char_index == 0
    assert token.position.end.column_no == len(content)
    assert token.position.end.line_no == 1
    assert token.position.end.char_index == len(content) - 1


# Generated at 2022-06-26 10:44:08.956115
# Unit test for function tokenize_json
def test_tokenize_json():
    assertToken = assertToken_2
    token = tokenize_json("{}")
    assertToken(token, "[1:1] (1:1) {}")

    token = tokenize_json("{\"foo\": \"bar\"}")
    assertToken(token, "[1:1] (1:1) {[2:2] (2:2) \"foo\": [6:6] (2:6) \"bar\"}")

    token = tokenize_json(
        "{\"foo\": [{\"bar\": \"baz\"}, [1, 2, 3], {\"four\": 4}]}"
    )

# Generated at 2022-06-26 10:44:17.426748
# Unit test for function tokenize_json
def test_tokenize_json():
    # Success case
    bytes_10 = b'{}'
    token = tokenize_json(bytes_10)

    # Test with type str
    str_10 = '{}'
    token = tokenize_json(str_10)

    # Test with type tuple
    tuple_10 = ('{}',)
    try:
        tokenize_json(tuple_10)
    except Exception as e:
        r = True
    else:
        r = False
    assert r


# Generated at 2022-06-26 10:44:30.220141
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case for a basic JSON object.
    content = "{'foo': 'bar'}"
    value = tokenize_json(content)
    assert value == {'foo': 'bar'}

    # Test case for a JSON object that includes an array.
    content = "{'bar': [1, 2, 3]}"
    value = tokenize_json(content)
    assert value == {'bar': [1, 2, 3]}

    # Test case for a JSON object that includes a nested dictionary.
    content = "{'bar': {'baz': 1}}"
    value = tokenize_json(content)
    assert value == {'bar': {'baz': 1}}

    # Test case for a JSON object that includes a nested dictionary and an
    # array.

# Generated at 2022-06-26 10:44:40.693151
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json({}), DictToken)
    assert isinstance(tokenize_json(b"{}"), DictToken)
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json(b"{\"hello\": \"world\"}"), DictToken)
    assert isinstance(tokenize_json("{\"hello\": \"world\"}"), DictToken)
    assert isinstance(tokenize_json(b"[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_json("[1, 2, 3]"), ListToken)
    assert isinstance(tokenize_json(b'{"hello": "world"}'), DictToken)
    assert isinstance(tokenize_json("{\"hello\": \"world\"}"), DictToken)
   

# Generated at 2022-06-26 10:44:55.158499
# Unit test for function tokenize_json
def test_tokenize_json():
    # Case 0
    content = '{}'
    try:
        result = tokenize_json(content)
        assert result is not None
        assert result == {}, "Expected {}, got {}".format({}, result)
    except JSONDecodeError as exc:
        assert False, "Expected '{}', got '{}'".format({}, exc.msg)
    except ParseError as exc:
        assert False, "Expected '{}', got '{}'".format({}, exc.text)
    else:
        print("Passed test case 0.")

    # Case 1
    content = '   {   "a"   :   "A"   ,   "b"   :   [   1 , 2.0 , true   ,   [ "B" ]   ]   }   '

# Generated at 2022-06-26 10:44:57.403789
# Unit test for function tokenize_json
def test_tokenize_json():
    assert callable(tokenize_json)


# Generated at 2022-06-26 10:45:09.221827
# Unit test for function tokenize_json
def test_tokenize_json():
    assert test_tokenize_json_0() == None
    assert test_tokenize_json_1() == None
    assert test_tokenize_json_2() == None
    assert test_tokenize_json_3() == None
    assert test_tokenize_json_4() == None
    assert test_tokenize_json_5() == None
    assert test_tokenize_json_6() == None
    assert test_tokenize_json_7() == None
    assert test_tokenize_json_8() == None
    assert test_tokenize_json_9() == None
    assert test_tokenize_json_10() == None
    assert test_tokenize_json_11() == None
    assert test_tokenize_json_12() == None
    assert test_tokenize_json_13() == None
    assert test

# Generated at 2022-06-26 10:45:22.491519
# Unit test for function tokenize_json
def test_tokenize_json():
    # Assigning to _None_0
    _None_0 = None
    # Assigning to _False_0
    _False_0 = False
    # Assigning to _True_0
    _True_0 = True
    # Assigning to _10_0
    _10_0 = 10
    # Assigning to _3.14_0
    _3_14_0 = 3.14
    # Assigning to "test"
    _test_0 = "test"
    # Assigning to b'bytes'
    _bytes_0 = b'bytes'
    # Assigning to 'unicode'
    _unicode_0 = 'unicode'
    # Assigning to (1, 2)
    _1_2_0 = (1, 2)
    # Assigning to [1, 2, 3]
    _1

# Generated at 2022-06-26 10:45:28.824881
# Unit test for function tokenize_json
def test_tokenize_json():
    # Check if JSONDecodeError works with line and column numbers
    content = '{"key": "value"}\n{"key": "value"'
    try:
        tokenize_json(content)
    except ParseError as e:
        assert e.position.line_no == 2
        assert e.position.column_no == 15


# Generated at 2022-06-26 10:45:31.681135
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = b'{}'
    validator_0 = Schema

# Generated at 2022-06-26 10:45:33.001981
# Unit test for function tokenize_json
def test_tokenize_json():
    bytes_0 = b'{}'
    dict_1 = tokenize_json(bytes_0)


# Generated at 2022-06-26 10:45:38.118093
# Unit test for function tokenize_json
def test_tokenize_json():
    bytes_0 = b'{}'
    assert tokenize_json(bytes_0) == tokenize_json(bytes_0)

    bytes_0 = b'{}'
    assert tokenize_json(bytes_0) == tokenize_json(bytes_0)

    bytes_0 = b'{}'
    assert tokenize_json(bytes_0) == tokenize_json(bytes_0)

    bytes_0 = b'{"key":"value"}'
    assert tokenize_json(bytes_0) == tokenize_json(bytes_0)

    bytes_0 = b'{"key":"value"}'
    assert tokenize_json(bytes_0) == tokenize_json(bytes_0)

    bytes_0 = b'{"key":"value"}'
    assert tokenize_json(bytes_0) == tokenize

# Generated at 2022-06-26 10:45:41.459428
# Unit test for function tokenize_json
def test_tokenize_json():
    data = test_case_0()
    result = tokenize_json(data)
    assert result  == b'{}'

# Generated at 2022-06-26 10:45:42.909359
# Unit test for function tokenize_json
def test_tokenize_json():
    assert True

# test_case_1

# Generated at 2022-06-26 10:45:48.274479
# Unit test for function tokenize_json
def test_tokenize_json():
    json_0 = "{\n\t\"foo\": \"bar\"\n}\n"
    val_0 = tokenize_json(json_0)


# Generated at 2022-06-26 10:45:51.495942
# Unit test for function tokenize_json
def test_tokenize_json():
    test_case_0()
    test_result = tokenize_json('{"a":1,"b":2}')


# Generated at 2022-06-26 10:46:02.607031
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test the JSON Decode error case
    content_0 = '{"a": 123, "b": "abc", "c": true, "d": false, "e": null, "f": [123, true, false, null] }'
    # Call function tokenize_json and check the result.
    token = tokenize_json(content=content_0)
    print(token)

    content_0 = b"Not JSON"
    # Call function tokenize_json and check the result.
    token = tokenize_json(content=content_0)
    print(token)

    content_0 = b""
    # Call function tokenize_json and check the result.
    token = tokenize_json(content=content_0)
    print(token)

    # Test the empty string case
    content_0 = b""
    #

# Generated at 2022-06-26 10:46:09.258246
# Unit test for function tokenize_json
def test_tokenize_json():
    # Should successfully decode JSON
    tokenize_json("[1, true, {\"x\": \"y\"}]")

    # Should raise ParseError
    with pytest.raises(ParseError):
        tokenize_json("")
        tokenize_json("{")


# Generated at 2022-06-26 10:46:22.217645
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test 1 returns Token
    tokenizing_decoder_0 = _TokenizingDecoder()

    assert tokenize_json(b"{}") == tokenizing_decoder_0.decode(b"{}")
    assert tokenize_json(b"[]") == tokenizing_decoder_0.decode(b"[]")
    assert tokenize_json(b"") == tokenizing_decoder_0.decode(b"")
    assert tokenize_json(b"1") == tokenizing_decoder_0.decode(b"1")

# Generated at 2022-06-26 10:46:34.086955
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('3') == ScalarToken(3, 0, 1, '3')
    assert tokenize_json('foo') == ScalarToken('foo', 0, 3, 'foo')
    assert tokenize_json('"foo"') == ScalarToken('foo', 0, 5, '"foo"')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 5, 'false')
    assert tokenize_json('1.5') == ScalarToken(1.5, 0, 3, '1.5')

# Generated at 2022-06-26 10:46:38.565234
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json(""), Token)
    assert tokenize_json("").content == ""
    assert tokenize_json("{}").children == {}
    assert tokenize_json('{"foo": "bar"}').children["foo"].content == "bar"
    #test_case_0()


# Generated at 2022-06-26 10:46:40.964801
# Unit test for function tokenize_json
def test_tokenize_json():
    content_0 = ""
    token_0 = tokenize_json(content_0)



# Generated at 2022-06-26 10:46:42.254796
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}")

# Generated at 2022-06-26 10:46:48.603061
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with simple json
    json_to_tokenize = b'{"key1": "value1", "key2": "value2"}'
    expected_token_value = {'key1': 'value1', 'key2': 'value2'}
    token = tokenize_json(json_to_tokenize)
    assert token.value == expected_token_value



# Generated at 2022-06-26 10:47:04.325497
# Unit test for function tokenize_json
def test_tokenize_json():
    string_0 = '{}'
    token_0 = tokenize_json(string_0)
    string_1 = '[1]'
    token_1 = tokenize_json(string_1)
    string_2 = '{"a": 1}'
    token_2 = tokenize_json(string_2)
    string_3 = '[{"a": 1}, {"b": 2}]'
    token_3 = tokenize_json(string_3)
    string_4 = '[{"a": [1, 2]}, {"b": {"c": [3, 4]}}]'
    token_4 = tokenize_json(string_4)
    string_5 = '[{"a": [1, 2]}, {"b": {"c": [3, 4, null]}}]'
    token_5 = tokenize_json(string_5)

# Generated at 2022-06-26 10:47:14.219952
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests that tokenize_json raises a ParseError on an empty str.
    with pytest.raises(ParseError):
        tokenize_json("")
    expected_positional_errors = [
        {
            "start": 1,
            "end": 2,
            "message": "Unexpected field.",
            "field_name": "zipcode",
        },
        {
            "start": 1,
            "end": 2,
            "message": "Unexpected field.",
            "field_name": "zip",
        },
    ]
    assert validate_json(
        """{"name": "Foo", "zipcode": 999, "zip": 888}""",
        {"name": "string"},
    ) == ({"name": "Foo"}, expected_positional_errors)
    expected_positional_errors

# Generated at 2022-06-26 10:47:22.040421
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for case where content is empty
    try:
        tokenize_json("")
    except ParseError as exc:
        # Assertions on the error message
        assert exc.text == 'No content.'
        assert exc.code == 'no_content'
        # Assertions on the error position
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        assert False

    # Test for case where content is empty string
    try:
        tokenize_json('""')
    except ParseError as exc:
        # Assertions on the error message
        assert exc.text == 'Expecting value'
        assert exc.code == 'parse_error'
        # Assertions on the error position

# Generated at 2022-06-26 10:47:32.723136
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "123"
    result = tokenize_json(content)
    expected = ScalarToken(123, 0, 2, content)
    assert result == expected
    content = '"123"'
    result = tokenize_json(content)
    expected = ScalarToken("123", 0, 4, content)
    assert result == expected
    content = '[123, 456]'
    result = tokenize_json(content)
    expected = ListToken([123, 456], 0, 8, content)
    assert result == expected
    content = """
    {
      "test": 123,
      "foo": [1, 2, 3]
    }
    """
    result = tokenize_json(content)

# Generated at 2022-06-26 10:47:34.151864
# Unit test for function tokenize_json
def test_tokenize_json():
    assert validate_json(b'{"a": "b"}', {"a": str}) == [{"a": "b"}, None]

# Generated at 2022-06-26 10:47:34.963923
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'') == None

# Generated at 2022-06-26 10:47:37.958072
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"one": 1, "two": "abc"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)

# Generated at 2022-06-26 10:47:44.722512
# Unit test for function tokenize_json
def test_tokenize_json():
    # Parse a JSON string, returning a token.
    valid_json = b'{"a": [1, 2, 3], "b": "c", "d": null, "e": false}'
    token = tokenize_json(valid_json)

    invalid_json = b'{"a": ["b", "c", "d",}'
    # Parse errors should be raised if the JSON is invalid.
    try:
        tokenize_json(invalid_json)
    except ParseError as exc:
        assert isinstance(exc.position, Position)
        assert exc.text == "Expecting value"
        assert exc.code == "parse_error"


# Generated at 2022-06-26 10:47:49.296736
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"test": "dictionaries"}'
    token = {'test': 'dictionaries'}
    result = tokenize_json(content)
    assert result == token


# Generated at 2022-06-26 10:47:51.133904
# Unit test for function tokenize_json
def test_tokenize_json():
    test_string_0 = ""
    assert tokenize_json(test_string_0) is not None


# Generated at 2022-06-26 10:48:04.405765
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test with a JSON string that parses successfully.
    content_0 = '{"key": "value"}'
    token_0 = tokenize_json(content_0)
    assert token_0.type == "dict"
    assert token_0.value[0][0].type == "scalar"
    assert token_0.value[0][0].value == "key"
    assert token_0.value[0][1].type == "scalar"
    assert token_0.value[0][1].value == "value"
    # Test with a JSON string that fails to parse.
    content_1 = '{"key": [3, "value", ["value2", "value3]]'
    try:
        token_1 = tokenize_json(content_1)
    except ParseError as exc:
        assert exc

# Generated at 2022-06-26 10:48:12.751329
# Unit test for function tokenize_json
def test_tokenize_json():
    test_0_value = tokenize_json("[1, 2, 3]")
    test_0_expected = ListToken([ScalarToken(1, 1, 2, "[1, 2, 3]"),
                                 ScalarToken(2, 4, 5, "[1, 2, 3]"),
                                 ScalarToken(3, 7, 8, "[1, 2, 3]")], 1, 10, "[1, 2, 3]")
    assert test_0_value == test_0_expected, "simple list with ints"
    test_1_value = tokenize_json('{"one": 1, "two": 2, "three": 3}')

# Generated at 2022-06-26 10:48:23.989383
# Unit test for function tokenize_json
def test_tokenize_json():
    # Check that tokenization succeeds on valid JSON strings
    assert tokenize_json('{"key": "value"}') == {'key': 'value'}
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]
    assert tokenize_json('[{}, {}]') == [{}, {}]
    assert tokenize_json('{"key": {}}') == {'key': {}}
    assert tokenize_json('{"key": [1, 2, 3]}') == {'key': [1, 2, 3]}
    assert tokenize_json('1') == 1

    # Check that tokenization fails on invalid JSON strings,
    # and ensure that the Error message includes the column, line number and character index.

# Generated at 2022-06-26 10:48:34.064997
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.base import Field
    from typesystem.tokenize.tokens import DictToken, DictWrapperToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions

    assert tokenize_json(b'{"foo": 3}') == DictToken(
        {"foo": ScalarToken(3, 1, 7, '{"foo": 3}')}, 0, 8, '{"foo": 3}'
    )

    # Test with a field instance.
    field_instance = Field(type="string")
    assert validate_with_positions(tokenize_json(b'"foo"'), field_instance) == (
        "foo",
        [],
    )

    # Test with a schema class.

# Generated at 2022-06-26 10:48:45.046632
# Unit test for function tokenize_json
def test_tokenize_json():
    import textwrap

    content = textwrap.dedent(
        """\
        {
            "a": null,
            "b": true,
            "c": false,
            "d": 0,
            "e": 1,
            "f": "s",
            "g": {
                "h": 1,
                "i": [
                    1,
                    2,
                    3
                ]
            }
        }
    """
    )

    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 7
    assert token.value[0] == ("a", ScalarToken(None, 24, 28, content))
    assert token.value[1] == ("b", ScalarToken(True, 33, 37, content))
    assert token.value

# Generated at 2022-06-26 10:48:56.194381
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for a valid string.
    tok = tokenize_json('{"1": 0}')
    assert isinstance(tok, DictToken)
    children = tok.children
    assert len(children) == 1
    key = children[0][0]
    val = children[0][1]
    assert isinstance(key, ScalarToken)
    assert isinstance(val, ScalarToken)
    assert key.value == "1"
    assert val.value == 0

    # Test for a valid bytestring.
    tok = tokenize_json(b'{"1": 0}')
    assert isinstance(tok, DictToken)
    children = tok.children
    assert len(children) == 1
    key = children[0][0]
    val = children[0][1]

# Generated at 2022-06-26 10:49:02.878625
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": ["bar", "baz"]}')
    assert token.value == {"foo": ["bar", "baz"]}
    assert isinstance(token, DictToken)
    assert isinstance(token.value["foo"], ListToken)
    assert isinstance(token.value["foo"].value[0], ScalarToken)


# Generated at 2022-06-26 10:49:04.996173
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {"__typing__": "dict"}

# Generated at 2022-06-26 10:49:08.105708
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == {'a': 1}


# Generated at 2022-06-26 10:49:17.307806
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json(b"[1]") == ListToken([ScalarToken(1, 1, 1, "[1]")], 0, 3, "[1]")
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json(b'{"thing": 1}') == DictToken(
        {"thing": ScalarToken(1, 11, 11, '{"thing": 1}')}, 0, 14, '{"thing": 1}'
    )

# Generated at 2022-06-26 10:49:22.259250
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "[\n    1,\n    2\n]"
    token = tokenize_json(content)

    assert isinstance(token, ListToken)
    assert token.value[0].value == 1
    assert token.value[1].value == 2



# Generated at 2022-06-26 10:49:35.661771
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test #1
    content = '"one"'
    token = tokenize_json(content)
    assert isinstance(token, ScalarToken)
    assert token.value == "one"

    # Test #2
    content = "[1,2,3]"
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]

    # Test #3
    content = "{'a': 'b', 'c': 'd'}"
    with pytest.raises(ParseError):
        token = tokenize_json(content)

    # Test #4
    content = "1"
    token = tokenize_json(content)
    assert isinstance(token, ScalarToken)
    assert token.value == 1


# Generated at 2022-06-26 10:49:46.764360
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = textwrap.dedent(
        """
        {
          "foo": "bar",
          "a_string": "this is a string",
          "a_number": 1.23,
          "nested": {
            "inner": "value",
            "inner_2": "value"
          },
          "empty": "",
          "an_empty_object_with_trailing_comma": {},
          "a_list": [
            "item 1",
            "item 2"
          ],
          "list_of_lists": [
            [
              "item 1"
            ],
            [
              "item 2"
            ]
          ]
        }
        """
    )
    token = tokenize_json(test_json)

    assert isinstance(token, DictToken)
   

# Generated at 2022-06-26 10:49:58.503216
# Unit test for function tokenize_json
def test_tokenize_json():
    json_text = r"""{"pets": {"cats": [{"name": "Garfield"}, {"name": "Furball"}], "dogs": [{"name": "Fido"}]}}"""
    tokenizing_decoder_0 = _TokenizingDecoder(content=json_text)
    subtext = r"""{"cats": [{"name": "Garfield"}, {"name": "Furball"}], "dogs": [{"name": "Fido"}]}"""
    subtoken = tokenizing_decoder_0.decode(subtext)
    token = tokenizing_decoder_0.decode(json_text)

    assert token.start_index == 0
    assert token.end_index == 82
    assert token.content == json_text
    assert token.key == "*"

# Generated at 2022-06-26 10:50:05.025678
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"x": 1}') == DictToken({ScalarToken('x', 0, 3, '{\"x\": 1}'): ScalarToken(1, 5, 7, '{\"x\": 1}')}, 0, 10, '{\"x\": 1}')


# Generated at 2022-06-26 10:50:16.745679
# Unit test for function tokenize_json
def test_tokenize_json():
    # tests_0
    token = tokenize_json("""
{
  "name": "John Smith",
  "age": 25,
  "address": {
    "streetAddress": "21 2nd Street",
    "city": "New York"
  },
  "phoneNumber": [
    {
      "location": "home",
      "code": 44
    }
  ]
}
""")
    assert token.as_dict() == {
        "name": "John Smith",
        "age": 25,
        "address": {"streetAddress": "21 2nd Street", "city": "New York"},
        "phoneNumber": [{"location": "home", "code": 44}],
    }


# Generated at 2022-06-26 10:50:29.255375
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:50:30.517552
# Unit test for function tokenize_json
def test_tokenize_json():
    assert callable(tokenize_json)



# Generated at 2022-06-26 10:50:35.350718
# Unit test for function tokenize_json
def test_tokenize_json(): 
    result_0 = tokenize_json(content='{"key_0": "value"}')
    dict_0 = {
        'key_0': 'value'
    }
    assert result_0.value == dict_0
    assert result_0.start_position == 0
    assert result_0.end_position == 13
    result_1 = tokenize_json(content='[4, 6, 7]')
    dict_1 = [
        4,
        6,
        7
    ]
    assert result_1.value == dict_1
    assert result_1.start_position == 0
    assert result_1.end_position == 7


# Generated at 2022-06-26 10:50:45.143591
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    tokenize_json is a function that takes a str or bytes as input.  It
    should return an instance of Token.
    """
    # Test that valid JSON is tokenized successfully.
    assert tokenize_json('{"hello":"world"}') == DictToken(
        {"hello": ScalarToken("world", 2, 13, '{"hello":"world"}')},
        start=0,
        end=14,
        raw_content='{"hello":"world"}',
    )

    # Test that the tokenizer handles empty strings gracefully.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert "no_content" == exc.code
        assert str(exc.position) == "1:1"

# Generated at 2022-06-26 10:50:54.220251
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
    "a": 1,
    "b": {
        "c": 2,
        "d": "abc"
    },
    "e": [3, 4, 5],
    "f": false,
    "g": null
}
    """

# Generated at 2022-06-26 10:51:04.591369
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = "{\"foo\":\"bar\",\"baz\":42}"
    token = tokenize_json(test_json)
    assert isinstance(token, DictToken)

    # test handling of malformed json
    test_json = "{\"foo\":\"bar\",\"baz\":42"
    with pytest.raises(ParseError):
        tokenize_json(test_json)

    # test handling of empty json
    test_json = ""
    with pytest.raises(ParseError):
        tokenize_json(test_json)



# Generated at 2022-06-26 10:51:12.942505
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Make sure that the tokenizer successfully tokenizes an example JSON string.
    """
    example = '{"name": "Joe", "age": 42}'
    assert tokenize_json(example) == {
        "name": ScalarToken("Joe", 1, 6, example),
        "age": ScalarToken(42, 12, 15, example),
    }



# Generated at 2022-06-26 10:51:14.821062
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    assert tokenize_json(content) == {
        "key": "value"
    }



# Generated at 2022-06-26 10:51:27.482732
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:51:35.454001
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == None
    assert tokenize_json('abc') == None
    assert tokenize_json('{"abc": 123}') == None
    assert tokenize_json('{"abc": "def"}') == None
    assert tokenize_json('{"abc": [1, 2]}') == None
    assert tokenize_json('[1, 2, 3]') == None


# Generated at 2022-06-26 10:51:46.958878
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test a valid json string.
    json_string = """
    {
        "message": "Hello, world!",
        "user": {
            "name": "Somebody"
        }
    }
    """

    # Parse the string into a valid json document.
    json_document = json.loads(json_string)

    # Tokenize the string.
    token = tokenize_json(json_string)
    json_document_token = {
        "message": ScalarToken("Hello, world!", 3, 25, json_string),
        "user": DictToken(
            {
                "name": ScalarToken("Somebody", 41, 50, json_string),
            },
            30,
            51,
            json_string,
        ),
    }
    assert token == json_document_token

    # Test