

# Generated at 2022-06-26 10:42:16.231960
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json('{"a": 1, "b": [2, 3]}')
    assert value == {'a': 1, 'b': [2, 3]}



# Generated at 2022-06-26 10:42:22.157123
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[]") == ListToken([], 0, 1)
    assert tokenize_json("[\"a\", 1, true]") == ListToken(
        [ScalarToken("a", 1, 3), ScalarToken(1, 5, 6), ScalarToken(True, 8, 12)], 0, 13
    )
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken(
        {ScalarToken("a", 1, 3): ScalarToken(1, 6, 7), ScalarToken("b", 9, 11): ScalarToken(2, 14, 15)}, 0, 16
    )
    assert tokenize_json("{}") == DictToken({}, 0, 1)

# Generated at 2022-06-26 10:42:30.780766
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(content=b'[1,2,3]') == [1, 2, 3]
    assert tokenize_json(content=b'{"name": "John"}') == {"name": "John"}
    assert tokenize_json(content='"John"') == "John"
    assert tokenize_json(content='123') == 123
    assert tokenize_json(content='true') == True
    assert tokenize_json(content='false') == False
    assert tokenize_json(content='null') == None

# Generated at 2022-06-26 10:42:37.437708
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a":1}'

    # Sanity-check inspect.cleandoc for Python 3.5
    # (which doesn't have inspect.cleandoc)
    if sys.version_info < (3, 6):
        from inspect import cleandoc

        content = cleandoc(content)
    tokenize_json(content)



# Generated at 2022-06-26 10:42:43.675174
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo":"bar"}') == DictToken(
        value={ScalarToken("foo", 0, 2, '{"foo":"bar"}'): ScalarToken("bar", 8, 11, '{"foo":"bar"}')},
        start=0,
        end=15,
        content='{"foo":"bar"}')
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=2, content="{}")
    assert tokenize_json("{}") == dict()

    with pytest.raises(ParseError):
        tokenize_json("{x}")

    with pytest.raises(ParseError):
        tokenize_json("")

    with pytest.raises(ParseError):
        tokenize_json("{")

#

# Generated at 2022-06-26 10:42:49.128225
# Unit test for function tokenize_json
def test_tokenize_json():
    def _func():
        token = tokenize_json('{"a": 42, "b": "value", "c": [1, 2, 3]}')
        return token
    _func()


# Generated at 2022-06-26 10:42:52.430321
# Unit test for function tokenize_json
def test_tokenize_json():
    # TODO: make unit test actual unit tests.
    # Make sure this doesn't throw.
    content = '{"foo": "bar"}'
    tokenize_json(content)



# Generated at 2022-06-26 10:43:04.980845
# Unit test for function tokenize_json
def test_tokenize_json():

    data = b'{"menu": {'
    data += b'"id": "file",'
    data += b'"value": "File",'
    data += b'"popup": {'
    data += b'"menuitem": ['
    data += b'{'
    data += b'"value": "New",'
    data += b'"onclick": "CreateNewDoc()"'
    data += b'},'
    data += b'{'
    data += b'"value": "Open",'
    data += b'"onclick": "OpenDoc()"'
    data += b'},'
    data += b'{'
    data += b'"value": "Close",'
    data += b'"onclick": "CloseDoc()"'
    data += b'}'
    data += b']'
    data += b'}'


# Generated at 2022-06-26 10:43:11.567840
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test JSON string input.
    assert isinstance(tokenize_json(b""), DictToken)
    assert isinstance(tokenize_json(b"null"), ScalarToken)
    assert isinstance(tokenize_json(b"true"), ScalarToken)
    assert isinstance(tokenize_json(b"false"), ScalarToken)
    assert isinstance(tokenize_json(b"1"), ScalarToken)
    assert isinstance(tokenize_json(b"1.0"), ScalarToken)
    assert isinstance(tokenize_json(b"\"\""), ScalarToken)
    assert isinstance(tokenize_json(b"{}"), DictToken)
    assert isinstance(tokenize_json(b"[]"), ListToken)

# Generated at 2022-06-26 10:43:18.913057
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{}"
    tokenizing_decoder_0 = _TokenizingDecoder()
    assert tokenizing_decoder_0.decode(content) == {}
    # Ensure that the content type is a string
    content = b"{}"
    tokenizing_decoder_0 = _TokenizingDecoder()
    with pytest.raises(TypeError) as exc_info:
        assert tokenizing_decoder_0.decode(content)
    content = "[]"
    tokenizing_decoder_0 = _TokenizingDecoder()
    assert tokenizing_decoder_0.decode(content) == []
    # Ensure that the content type is a string
    content = b"[]"
    tokenizing_decoder_0 = _TokenizingDecoder()

# Generated at 2022-06-26 10:43:48.655769
# Unit test for function tokenize_json
def test_tokenize_json():

    # Make sure that the empty string case results in a parse error
    error_messages: typing.List[Message] = []
    content = ""
    expected_error_messages = [
        {
            "message": "No content.",
            "code": "no_content",
            "position": {
                "line_no": 1,
                "column_no": 1,
                "char_index": 0,
            },
        }
    ]
    try:
        token = tokenize_json(content)
    except ParseError as e:
        error_messages.append(e.to_dict())
    assert error_messages == expected_error_messages

    # Make sure that whitespace is handled properly
    content = "   null   "
    expected_value = None
    value, error_messages = validate_

# Generated at 2022-06-26 10:43:58.832202
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for valid JSON that should return a token with no validation errors.
    content = """
{
   "a": 1,
   "b": 2,
   "c": 3
}
"""
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert token.num_children() > 0

    errors = token.validate_with_positions(Field(name="test"))
    assert len(errors) == 0

    # Test for missing content that should raise a ParseError with the no_content
    # error code.
    content = ""
    with pytest.raises(ParseError) as excinfo:
        token = tokenize_json(content)
    assert excinfo.value.code == "no_content"

    # Test for invalid JSON that should raise a ParseError with the parse_

# Generated at 2022-06-26 10:44:09.452477
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests that content is optional
    tokenize_json(content=b'')
    # Tests that content is optional
    tokenize_json(content='')
    # Tests that content can be a bytestring
    tokenize_json(content=b'{"abc": 123}')
    # Tests that content can be a unicode str
    tokenize_json(content='{"abc": 123}')
    # Tests that content can be a unicode str
    tokenize_json(content='{"abc": 123}')
    # Tests that content can be a bytestring
    tokenize_json(content=b'{"abc": 123}')
    # Tests that content can be a unicode str
    tokenize_json(content='{"abc": 123}')
    # Tests that a JSONDecodeError is raised when the content
    # is the empty string

# Generated at 2022-06-26 10:44:19.270638
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json("")
        assert False
    except ParseError as err:
        assert err.code == "no_content"
        assert err.text == "No content."

    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 5, '{"foo": "bar"}'): ScalarToken("bar", 9, 14, '{"foo": "bar"}')}, 1, 15, '{"foo": "bar"}'
    )

    try:
        tokenize_json('{"foo": "bar"')
        assert False
    except ParseError as err:
        assert err.code == "parse_error"



# Generated at 2022-06-26 10:44:24.461962
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"hello": "world"}'
    result = tokenize_json(content)
    expected = {
        "hello": "world"
    }
    assert result == expected


# Generated at 2022-06-26 10:44:27.548899
# Unit test for function tokenize_json
def test_tokenize_json():
    data = b'{"a": 2}'
    result = tokenize_json(data)
    assert isinstance(result, DictToken)

# Test the case where content is None

# Generated at 2022-06-26 10:44:40.546838
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"name": "Jane"}'
    token = tokenize_json(content)
    assert token.value == {"name": "Jane"}
    assert token.start == 0
    assert token.end == 14
    assert token.content == '{"name": "Jane"}'
    tokens = token.iter_tokens()
    token1 = next(tokens)
    assert token1.value == {"name": "Jane"}
    assert token1.start == 0
    assert token1.end == 14
    assert token1.content == '{"name": "Jane"}'
    token2 = next(tokens)
    assert token2.value == "name"
    assert token2.start == 2
    assert token2.end == 7
    assert token2.content == '"name"'

# Generated at 2022-06-26 10:44:47.358882
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for the str case
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["foo"] == ScalarToken("bar")

    # Test for the bytes case
    content = b'{"foo": "bar"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["foo"] == ScalarToken("bar")

    # Test for the empty string case
    content = ""
    tokenize_json(content)



# Generated at 2022-06-26 10:45:01.973792
# Unit test for function tokenize_json
def test_tokenize_json():
    token_0 = tokenize_json("{}")
    token_1 = tokenize_json("""[
  "hello",
  "world"
]""")
    token_2 = tokenize_json("  null  ")
    token_3 = tokenize_json("""{
  "hello": "world",
  "foo": "bar",
  "baz": null
}""")
    token_4 = tokenize_json("""[
  "hello",
  "world"
]""")
    token_5 = tokenize_json("  null  ")
    token_6 = tokenize_json("""{
  "hello": "world",
  "foo": "bar",
  "baz": null
}""")
    token_7 = tokenize_json("""{}""")

# Unit

# Generated at 2022-06-26 10:45:09.599658
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"x": 2}'
    value = tokenize_json(content)
    # Expected assertion failure as value is not a dict as expected.
    assert value == {u"x": 2}



# Generated at 2022-06-26 10:45:20.649992
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(content='{}') == DictToken(value={}, start=0, end=1, content='{}')
    assert tokenize_json(content='{ "id": 1 }') == DictToken(value={ScalarToken('id', 1, 5, '{ "id": 1 }'): ScalarToken(1, 10, 10, '{ "id": 1 }')}, start=0, end=15, content='{ "id": 1 }')



# Generated at 2022-06-26 10:45:25.147355
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": "b"}') == DictToken(
        {ScalarToken('a', column_no=1, line_no=1, char_index=1): ScalarToken('b', column_no=5, line_no=1, char_index=5)},
        column_no=1,
        line_no=1,
        char_index=0,
    )



# Generated at 2022-06-26 10:45:33.973057
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.exceptions import ParseError
    from typesystem.specifications import IntegerSpecification
    from typesystem.specifications.json_specifications import JsonSpecification

    field = Field(type=IntegerSpecification())

    json = '{"foo": "bar"}'
    try:
        validate_json(json, field)
    except ParseError as err:
        assert err.message.text == "Unable to parse 'foo' value: expected an int."
        assert err.message.code == "invalid"
        assert err.message.position.character_index == 10
        assert err.message.position.line_number == 1
        assert err.message.position.column_number == 11

        assert len(err.message.context.all_messages) == 2


# Generated at 2022-06-26 10:45:47.464286
# Unit test for function tokenize_json
def test_tokenize_json():
    token_0 = tokenize_json('[{"a": "b"}]')
    assert type(token_0) is ListToken
    assert token_0.value == [
        {
            "a": ScalarToken(
                value="b",
                start_index=5,
                end_index=7,
                content='[{"a": "b"}]',
                position=Position(column_no=6, line_no=1, char_index=5),
            )
        }
    ]
    token_1 = tokenize_json('{"a": 42}')
    assert type(token_1) is DictToken

# Generated at 2022-06-26 10:45:53.423943
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"lat": 40.785091, "lng": -73.968285}'
    token = tokenize_json(content)
    assert token.children[0].children[1].value == 40.785091


# Generated at 2022-06-26 10:46:01.670184
# Unit test for function tokenize_json
def test_tokenize_json():
    
    content = '{"key":[["aaa","bbb","ccc"],"first",3.14]}'
    
    parser = tokenize_json(content)
    root = parser.children[0]
    assert(root.children[0].data == "key")
    assert(root.children[1].children[0].data == "aaa")
    assert(root.children[1].children[2].data == "ccc")
    assert(root.children[1].children[3].data == "first")
    assert(root.children[1].children[4].data == 3.14)


# Generated at 2022-06-26 10:46:13.797734
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Assert that tokenize_json returns the correct result for all valid JSON
    types.
    """
    # Test the different valid JSON types.

# Generated at 2022-06-26 10:46:19.133660
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"a":42}'), DictToken)
    assert isinstance(tokenize_json('[null]'), ListToken)
    assert isinstance(tokenize_json('"a"'), ScalarToken)


# Generated at 2022-06-26 10:46:32.870797
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing content is an empty string
    content = ""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.code == "no_content"

    # Testing content is string
    content = "string"
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.code == "parse_error"

    # Testing content is valid string
    content = '{"a":1}'
    tokenize_json(content)

    # Testing content is valid bytestring
    content = b'{"a":1}'
    tokenize_json(content)

    # Testing content is invalid string
    content = "{"

# Generated at 2022-06-26 10:46:35.670995
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == {
        "foo": "bar"
    }


# Generated at 2022-06-26 10:46:44.248308
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Verify that the result of the tokenizing_decoder_0 function is equal to the JSON encoded string
    """

    # Arrange
    # Act
    # Assert
    assert tokenize_json('{"test":"test"}') == '{"test":"test"}'



# Generated at 2022-06-26 10:46:55.425695
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken
    json_0 = '{}'
    token_0 = tokenize_json(json_0)
    assert isinstance(token_0, DictToken)

    json_1 = '[]'
    token_1 = tokenize_json(json_1)
    assert isinstance(token_1, ListToken)

    json_2 = '["foo", "bar", "baz"]'
    token_2 = tokenize_json(json_2)
    assert isinstance(token_2, ListToken)

    json_3 = '["foo", "bar", "baz"]'

# Generated at 2022-06-26 10:46:58.401615
# Unit test for function tokenize_json
def test_tokenize_json():
    # Call function with arguments (mock_file_handle)
    token_0 = tokenize_json(content=b"")
    assert isinstance(token_0, Token)



# Generated at 2022-06-26 10:47:09.017057
# Unit test for function tokenize_json
def test_tokenize_json():
    content="""{
  "name": "John Smith",
  "age": 25,
  "is_verified": false,
  "pets": ["dog", "cat", "fish"],
  "address": {
    "house_number": 1,
    "street": "Main Street",
    "postcode": "ABC 1XX"
  }
}"""
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert token.value == {
  "name": "John Smith",
  "age": 25,
  "is_verified": False,
  "pets": ["dog", "cat", "fish"],
  "address": {
    "house_number": 1,
    "street": "Main Street",
    "postcode": "ABC 1XX"
  }
}

# Unit

# Generated at 2022-06-26 10:47:20.608714
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('""') == ScalarToken(value='')
    assert tokenize_json('"foo"') == ScalarToken(value='foo')
    assert tokenize_json('"\\"foo\\bar"') == ScalarToken(value='"foo\\bar')
    assert tokenize_json('"\\b"') == ScalarToken(value='\b')
    assert tokenize_json('"\\f"') == ScalarToken(value='\f')
    assert tokenize_json('"\\n"') == ScalarToken(value='\n')
    assert tokenize_json('"\\r"') == ScalarToken(value='\r')
    assert tokenize_json('"\\t"') == ScalarToken(value='\t')
    assert tokenize_json('"\\u00fe"') == Scal

# Generated at 2022-06-26 10:47:32.081737
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON strings
    token = tokenize_json(b'{"a": "b"}')
    assert token
    assert token.position == (1, 8)

    token = tokenize_json('{"a": "b"}')
    assert token
    assert token.position == (1, 8)

    token = tokenize_json('{"a": "b", "c": "d"}')
    assert token
    assert token.position == (1, 16)

    # Test invalid JSON strings
    with pytest.raises(ParseError) as exc:
        tokenize_json('{"a": "b"')

    assert exc.value.position == (1, 10)
    assert exc.value.text == "Expecting ',' delimiter"

    with pytest.raises(ParseError) as exc:
        tokenize_

# Generated at 2022-06-26 10:47:40.828474
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("{}")
    tokenize_json("[]")
    tokenize_json("null")
    tokenize_json("true")
    tokenize_json("false")
    tokenize_json('{"foo":1}')
    tokenize_json('{"foo":1.3}')
    tokenize_json('{"foo":1.3e2}')
    tokenize_json('{"foo":"bar"}')
    tokenize_json('{"foo":["bar", 1]}')
    tokenize_json('{"foo":["bar", null]}')
    tokenize_json('{"foo":{"bar":1}}')
    tokenize_json('{"foo":{"bar":{"baz":["nested"]}}}')
    tokenize_json('{"foo":{"bar":{"baz":{"nested":123}}}}')

# Generated at 2022-06-26 10:47:47.945198
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": "b"}') == DictToken({"a": ScalarToken("b", 5, 8, '"a": "b"')}, 0, 11, '{"a": "b"}')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 2, 3, "1"), ScalarToken(2, 5, 6, "2")], 0, 7, '[1, 2]')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")

# Generated at 2022-06-26 10:48:00.932659
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    expected_1 = ScalarToken(10, 0, 1, "10")
    actual_1 = tokenize_json("10")
    assert actual_1 == expected_1

    expected_2 = ScalarToken(0.5, 0, 3, "0.5")
    actual_2 = tokenize_json("0.5")
    assert actual_2 == expected_2

    expected_3 = ScalarToken(True, 0, 3, "true")
    actual_3 = tokenize_json("true")
    assert actual_3 == expected_3

    expected_4 = ScalarToken(False, 0, 4, "false")
    actual_4 = tokenize_json("false")
    assert actual_4 == expected_4

    expected

# Generated at 2022-06-26 10:48:11.499415
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start_index=0, end_index=1, content="{}")
    assert tokenize_json('{"a": 1}') == DictToken(value={'a': ScalarToken(1, 4, 4)}, start_index=0, end_index=7, content='{"a": 1}')
    assert tokenize_json('["a", 1]') == ListToken(value=[ScalarToken('a', 1, 1), ScalarToken(1, 5, 5)], start_index=0, end_index=9, content='["a", 1]')

# Generated at 2022-06-26 10:48:19.297725
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'{"a":2}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)


# Generated at 2022-06-26 10:48:25.859441
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:48:35.046537
# Unit test for function tokenize_json
def test_tokenize_json():
    from typing_extensions import Literal
    from typesystem import String

    schema = String(max_length=10)

    # Test basic valid case with single value
    content = b'{"foo": "valid"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token) == 1
    assert "foo" in token
    token = token["foo"]
    assert isinstance(token, ScalarToken)
    assert token.value == "valid"

    # Test basic error case with single value
    content = b'{"foo": "invalid"}'
    token = tokenize_json(content)
    try:
        errors = validate_json(content, schema)
    except JSONDecodeError:
        pass

# Generated at 2022-06-26 10:48:45.413189
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    node = {
        "number": 1,
        "string": "str",
        "list": [1, 2],
        "dict": {"number": 1, "string": "str"},
        "null": None,
        "true": True,
        "false": False,
    }
    content = json.dumps(node)
    decoder = _TokenizingDecoder(content=content)
    token = tokenizing_decoder_0.decode(content)
    assert token == node
    token = tokenize_json(content)
    assert token == node
    token = tokenize_json(content.encode("utf-8"))
    assert token == node

    json.dumps(node)
    token = tokenize_json(content.encode("utf-8"))
    assert token == node



# Generated at 2022-06-26 10:48:57.096779
# Unit test for function tokenize_json
def test_tokenize_json():
    """Try validating JSON content.
    """
    validator = Schema(
        {
            "first_name": str,
            "last_name": str,
            "age": int,
            "address": {"street": str, "number": int},
            "nicknames": [str],
        }
    )
    # Parse and validate the JSON content.
    content = '{"first_name": "John", "last_name": "', 'Smith", "age": 25, "address": {"street": "Len', 'gdon", "number": 123}, "nicknames": ["Johnny"]}'
    value, error_messages = validate_json(content, validator)
    # Check that we got back a single positionally marked error message.

# Generated at 2022-06-26 10:49:07.105604
# Unit test for function tokenize_json
def test_tokenize_json():

    token = tokenize_json("null")
    assert token.value is None

    token = tokenize_json("false")
    assert token.value is False

    token = tokenize_json("[1,2,3]")

    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], ScalarToken)
    assert token.value[0].value == 1
    assert token.value[1].value == 2
    assert token.value[2].value == 3

    token = tokenize_json("{}")

    assert isinstance(token, DictToken)
    assert token.value == {}

    token = tokenize_json("{\"a\": 1}")
    assert isinstance(token.value["a"], ScalarToken)
    assert token.value["a"].value == 1

    token = token

# Generated at 2022-06-26 10:49:15.366543
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}, "Empty object (1/2)"
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}, "Simple object (1/2)"
    assert tokenize_json("[]") == [], "Empty array (1/2)"
    assert tokenize_json("[1, 29]") == [1, 29], "Simple array (1/2)"
    # Positionally marked error messages

    pos_error = validate_json("{", validator=Field("foo", type="string"))
    assert pos_error[1][0].position.line_no == 1

# Generated at 2022-06-26 10:49:16.114977
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json("")

# Generated at 2022-06-26 10:49:18.132364
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for valid content
    assert tokenize_json("{}").value == {}
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")

# Test for valid json, but invalid content

# Generated at 2022-06-26 10:49:24.480042
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == {}
    assert tokenize_json("{}") == {}
    assert tokenize_json("[]") == []
    assert tokenize_json("43") == 43
    assert tokenize_json("3.14") == 3.14
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("null") is None
    assert tokenize_json("\"foo\"") == "foo"
    assert tokenize_json("\"foo\\nbar\"") == "foo\nbar"
    assert tokenize_json("\"foo\\r\\nbar\"") == "foo\r\nbar"
    assert tokenize_json("\"foo\\u20ac\"") == "foo€"

# Generated at 2022-06-26 10:49:34.253813
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = b'{"key": "value"}'
    token = tokenize_json(json_string)
    expected: Token = DictToken({ScalarToken("key", 0, 2, "key"):ScalarToken("value", 0, 7, "value")}, 0, 13, "{\"key\": \"value\"}")
    assert token == expected


# Generated at 2022-06-26 10:49:41.569604
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("0") == ScalarToken(0, 0, 1, "0")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("-1") == ScalarToken(-1, 0, 2, "-1")

# Generated at 2022-06-26 10:49:48.348536
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"null"') == ScalarToken("null", 0, 6, '"null"')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json('"true"') == ScalarToken("true", 0, 6, '"true"')
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json('"false"') == ScalarToken("false", 0, 7, '"false"')
    assert tokenize_json("12.34") == ScalarToken(12.34, 0, 5, "12.34")
    assert tokenize_json('"12.34"')

# Generated at 2022-06-26 10:49:54.420725
# Unit test for function tokenize_json
def test_tokenize_json():
    test_input = b'{"name": "John Doe", "age": 30}'
    test_output = tokenize_json(test_input)
    assert test_output[0].value == "{\"name\": \"John Doe\", \"age\": 30}"


# Generated at 2022-06-26 10:50:07.798475
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.tokens import Token

    token = tokenize_json(b'{"foo": "bar", "bar": "baz"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar", "bar": "baz"}
    assert token.min_position == Position(line_no=1, char_index=0, column_no=1)
    assert token.max_position == Position(line_no=1, char_index=34, column_no=35)

    token = tokenize_json(b"[1, 2, 3, 4]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3, 4]


# Generated at 2022-06-26 10:50:13.113325
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(
        b'"{"a":1,"b":2,"c":3}"'
    ) == DictToken(
        {"a": ScalarToken(1, 9, 9, '"{"a":1,"b":2,"c":3}"'),"b": ScalarToken(2, 14, 14, '"{"a":1,"b":2,"c":3}"'),"c": ScalarToken(3, 19, 19, '"{"a":1,"b":2,"c":3}"'),},
        3,
        23,
        '"{"a":1,"b":2,"c":3}"',
    )


# Generated at 2022-06-26 10:50:17.316163
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field()
    data = "1"
    token = tokenize_json(data)
    assert type(token) == ScalarToken
    assert token.value == 1
    with pytest.raises(ParseError):
        tokenize_json("some invalid json")
    assert tokenize_json(data).value == 1



# Generated at 2022-06-26 10:50:21.288927
# Unit test for function tokenize_json
def test_tokenize_json():
    data = """{"x": "y", "z": "zz"}"""
    result = tokenize_json(data)
    assert result == {
        "x": "y",
        "z": "zz"
    }



# Generated at 2022-06-26 10:50:29.582542
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == []
    assert tokenize_json('{}') == {'__type__': 'dict', '__token__': {}, '__value__': {}, '__position__': {'start': 1, 'end': 2}}
    assert tokenize_json('{key: value}') == {'__type__': 'dict', '__token__': {'key': 'value'}, '__value__': {'key': 'value'}, '__position__': {'start': 1, 'end': 12}}

# Generated at 2022-06-26 10:50:32.059202
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == {'foo': 'bar'}



# Generated at 2022-06-26 10:50:38.512875
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 2}') is not None


# Generated at 2022-06-26 10:50:40.888473
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "Jane", "age": 30}')
    assert isinstance(token, dict)


# Generated at 2022-06-26 10:50:42.637461
# Unit test for function tokenize_json
def test_tokenize_json():
    assert callable(tokenize_json)



# Generated at 2022-06-26 10:50:54.219232
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'') is not None
    assert tokenize_json('{"a": 1, "b": 2}') is not None
    assert tokenize_json('[1, 2, 3, 4]') is not None
    assert tokenize_json('{"a": 1, "b": 2}') is not None
    assert tokenize_json('[1, 2, 3, 4]') is not None
    assert tokenize_json('[1, 2, 3, 4]') is not None
    assert tokenize_json('[1, 2, 3, 4]') is not None
    assert tokenize_json('') is not None
    assert tokenize_json('True') is not None


# Generated at 2022-06-26 10:51:02.880189
# Unit test for function tokenize_json
def test_tokenize_json():
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.text == "No content."
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position == Position(
        column_no=1, line_no=1, char_index=0
    )

    with pytest.raises(ParseError) as exc_info:
        tokenize_json("  ")
    assert exc_info.value.text == "No content."
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position == Position(
        column_no=1, line_no=1, char_index=0
    )


# Generated at 2022-06-26 10:51:16.280409
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for a JSON string
    assert tokenize_json('{"foo": {"bar": "baz"}}') == DictToken(
        {
            ScalarToken("foo", 1, 5, '{"foo": {"bar": "baz"}}'): DictToken(
                {
                    ScalarToken("bar", 10, 14, '{"foo": {"bar": "baz"}}'): ScalarToken(
                        "baz", 19, 23, '{"foo": {"bar": "baz"}}'
                    )
                },
                8,
                23,
                '{"foo": {"bar": "baz"}}',
            )
        },
        0,
        23,
        '{"foo": {"bar": "baz"}}',
    )
    # Test for a JSON string with trailing whitespace
    assert tokenize

# Generated at 2022-06-26 10:51:28.202262
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == None
    assert tokenize_json("null") == None
    assert tokenize_json("true") == True
    assert tokenize_json("false") == False
    assert tokenize_json('"test"') == "test"
    assert tokenize_json("42") == 42
    assert tokenize_json("42.1") == 42.1
    assert tokenize_json("42e3") == 42e3
    assert tokenize_json("42e+3") == 42e+3
    assert tokenize_json("42e-3") == 42e-3
    assert tokenize_json("42.1e3") == 42.1e3
    assert tokenize_json("42.1e+3") == 42.1e+3
    assert tokenize_json("42.1e-3")

# Generated at 2022-06-26 10:51:35.101834
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"foo": "bar"}')
    assert token.keys() == {"foo"}
    assert token["foo"].value == "bar"

    token = tokenize_json('{"foo": "bar"}')
    assert token.keys() == {"foo"}
    assert token["foo"].value == "bar"



# Generated at 2022-06-26 10:51:46.823677
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {}, "Should be able to parse a JSON object."
    assert tokenize_json("[]") == [], "Should be able to parse a JSON array."
    assert tokenize_json("null") is None, "Should be able to parse a JSON null."
    assert tokenize_json("true") == True, "Should be able to parse a JSON true."
    assert tokenize_json("false") == False, "Should be able to parse a JSON false."
    assert tokenize_json("5") == 5, "Should be able to parse a JSON integer."
    assert tokenize_json("0.5") == 0.5, "Should be able to parse a JSON float."