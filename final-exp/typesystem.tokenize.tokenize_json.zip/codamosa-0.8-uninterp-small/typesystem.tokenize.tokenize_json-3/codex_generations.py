

# Generated at 2022-06-26 10:42:19.263598
# Unit test for function tokenize_json
def test_tokenize_json():
    import src.testing.typesystem as types

    content = b'{"answer": 42}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

    validator = types.make_definitions({
        "answer": types.Integer,
    })

    data, errors = validate_json(content, validator)
    assert not errors

    content = b'{"answer" 42}'
    with pytest.raises(ParseError):
        tokenize_json(content)

    data, errors = validate_json(content, validator)
    assert len(errors) == 1
    message = errors[0]
    assert message.code == "parse_error"

    content = b'{"answer": "forty-two"}'
    with pytest.raises(ParseError):
        token

# Generated at 2022-06-26 10:42:27.105543
# Unit test for function tokenize_json
def test_tokenize_json():
    input_content = '{"key1":{"key2":"value2"},"key3":["value3",{"key4":"value4"}]}'
    expected_output = tokenize_json(input_content)
    assert expected_output == {'key1': {'key2': 'value2'}, 'key3': ['value3', {'key4': 'value4'}]}



# Generated at 2022-06-26 10:42:36.289070
# Unit test for function tokenize_json
def test_tokenize_json():

    expression_0 = '{"a": [1]}'
    value_0 = tokenize_json(expression_0)
    expression_1 = '{"a": [1, 2]}'
    value_1 = tokenize_json(expression_1)
    expression_2 = '{"a": [1, 2, 3]}'
    value_2 = tokenize_json(expression_2)
    expression_3 = '{"a": [1, {"b": 2, "c": 3}]}'
    value_3 = tokenize_json(expression_3)
    expression_4 = '{"a": [1, {"b": 2, "c": 3}, "d"]}'
    value_4 = tokenize_json(expression_4)
    expression_5 = '{"a": false}'

# Generated at 2022-06-26 10:42:40.235280
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('')
    assert tokenize_json('123')
    assert tokenize_json('true')
    assert tokenize_json('[1, 2, 3]')
    assert tokenize_json('{"a": "foo", "b": "bar"}')


# Generated at 2022-06-26 10:42:43.229787
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json(content = '')



# Generated at 2022-06-26 10:42:47.312775
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema({})
    content = '{"name": "John"}'
    validate_json(content, schema)



# Generated at 2022-06-26 10:43:00.992801
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == {}
    assert tokenize_json("true") == True
    assert tokenize_json("false") == False
    assert tokenize_json("null") == None
    assert tokenize_json("{}") == {}
    assert tokenize_json("[]") == []
    assert tokenize_json("[1, 2, 3]") == [1, 2, 3]
    assert tokenize_json("[1, 2, 3.1]") == [1, 2, 3.1]
    assert tokenize_json('["foo", "bar"]') == ["foo", "bar"]

if __name__ == "__main__":
    import sys

    token = tokenize_json(sys.stdin.read())
    print(token)



# Generated at 2022-06-26 10:43:08.149786
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar", "foo2": 3}'
    token = tokenize_json(content)
    assert token.as_dict() == {"foo": "bar", "foo2": 3}
    assert token.properties["foo"].start_position == Position(
        column_no=2, line_no=1, char_index=1
    )
    assert token.properties["foo"].end_position == Position(
        column_no=7, line_no=1, char_index=6
    )

    content = '{"foo": ["bar", "foo2"]}'
    token = tokenize_json(content)
    assert token.as_dict() == {"foo": ["bar", "foo2"]}

# Generated at 2022-06-26 10:43:16.687416
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.testcases import tokenize_testcases_0

    for c in tokenize_testcases_0:
        token, exc = c["token"], c["exc"]
        if exc is None:
            assert tokenize_json(c["content"]) == token
        else:
            with pytest.raises(ParseError) as e:
                tokenize_json(c["content"])
            assert e.value.text == exc["text"]
            assert e.value.code == exc["code"]
            assert e.value.position == Position(**exc["position"])



# Generated at 2022-06-26 10:43:28.599814
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {
            ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken(
                "bar", 9, 12, '{"foo": "bar"}'
            )
        },
        0,
        13,
        '{"foo": "bar"}',
    )

# Generated at 2022-06-26 10:43:36.764699
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{'foo': 'bar'}"
    assert(tokenize_json(content) == None)


# Generated at 2022-06-26 10:43:49.228618
# Unit test for function tokenize_json
def test_tokenize_json():
    int_field = Field(type="integer")
    schema_0 = Schema(fields={"bar": int_field})

    value_0, error_messages_0 = validate_json(b'{"bar": 5}', schema_0)
    assert value_0 == {'bar': 5}
    assert error_messages_0 == []

    value_1, error_messages_1 = validate_json(b'{"bar": "foo"}', schema_0)
    assert value_1 == {'bar': 'foo'}
    assert len(error_messages_1) == 1
    error_0 = error_messages_1[0]
    assert error_0.text == 'Value is not of type "integer".'
    assert error_0.code == 'type_error.integer'
    assert error_0.position

# Generated at 2022-06-26 10:43:59.062882
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 9, "[1, 2, 3]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{1: 2}") == DictToken({1: 2}, 0, 5, "{1: 2}")
    with raises(ParseError, match="No content"):
        tokenize_json("")
    with raises(ParseError, match="Expecting"):
        tokenize_json("[1, ]")
    with raises(ParseError, match="Expecting"):
        tokenize_json("[1, 2, 3")

# Generated at 2022-06-26 10:44:01.898710
# Unit test for function tokenize_json
def test_tokenize_json():
    import typesystem.tokenize
    content = "[1,2,3]"
    expected = "[1, 2, 3]"
    token = typesystem.tokenize.tokenize_json(content)
    assert token.pretty_print() == expected
    assert token.value == "[1, 2, 3]"
    assert token.raw_value == content


# Generated at 2022-06-26 10:44:07.379920
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing with empty string
    with pytest.raises(ParseError):
        tokenize_json("")
    # Testing with valid JSON string
    assert tokenize_json("{}") == DictToken(dict(), 0, 1, "{}")
    # Testing with invalid JSON string
    with pytest.raises(ParseError):
        tokenize_json("{")


# Generated at 2022-06-26 10:44:16.006468
# Unit test for function tokenize_json
def test_tokenize_json():
    assert(tokenize_json("{}") == DictToken({}, 0, 1, content="{}"))
    assert(tokenize_json("[1, null, true, false]") == ListToken([1, None, True, False], 0, 27, content="[1, null, true, false]"))
    assert(tokenize_json("{\"abc\": true}") == DictToken({"abc": True}, 0, 14, content="{\"abc\": true}"))

    # Handle the empty string case explicitly for clear error messaging.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")

    error_msg = str(excinfo.value)
    assert error_msg == "ParseError(text='No content.', code='no_content')"

    # Handle cases that result in a JSON

# Generated at 2022-06-26 10:44:23.192467
# Unit test for function tokenize_json
def test_tokenize_json():
    json = (
        '{"array":[1,2,3],"boolean":true,"null":null,"number":123,"object":{'
        '"a":"b","c":"d","e":"f"},"string":"Hello World"}'
    )
    tokenized = tokenize_json(json)


# Generated at 2022-06-26 10:44:29.038234
# Unit test for function tokenize_json
def test_tokenize_json():
    assert callable(tokenize_json)
    assert tokenize_json.__code__.co_argcount == 1
    assert tokenize_json.__code__.co_varnames == ("content",)
    assert tokenize_json.__code__.co_filename == "tokenize.py"
    assert tokenize_json.__code__.co_firstlineno == 76


# Generated at 2022-06-26 10:44:41.006552
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"string"') == ScalarToken("string", 0, 7, '"string"')
    assert tokenize_json('{"number": 123}') == DictToken(
        {"number": ScalarToken(123, 9, 12, "123")}, 0, 14, '{"number": 123}'
    )

# Generated at 2022-06-26 10:44:48.735249
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string return
    try:
        validate_json(content="", validator=Field())
    except ParseError as exc:
        assert exc.lingo_message == "No content."
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)

    # Test for valid JSON
    test_result = validate_json(content='{"foo": "bar"}', validator=Schema({"foo": str}))

    assert test_result == ({'foo': 'bar'}, [])

    # Test for invalid JSON
    test_result = validate_json(content='{"foo": "bar"', validator=Schema({"foo": str}))


# Generated at 2022-06-26 10:45:14.861876
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert isinstance(tokenize_json(""), ParseError)
    assert isinstance(tokenize_json("s"), ParseError)
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("2") == ScalarToken(2, 0, 1, "2")
    assert tokenize_json("'2'") == ScalarToken("2", 0, 3, "'2'")
    assert tokenize_json("[1, 2, 3, ]") == ListToken([1, 2, 3], 0, 10, "[1, 2, 3, ]")
    assert token

# Generated at 2022-06-26 10:45:24.827679
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("")
    tokenize_json("{}")
    tokenize_json(b"{}")
    tokenize_json("{}", strict=True)
    tokenize_json("{]")
    tokenize_json("null")
    tokenize_json("null", strict=True)
    tokenize_json("true")
    tokenize_json("true", strict=True)
    tokenize_json("false")
    tokenize_json("false", strict=True)
    tokenize_json("3.14159")
    tokenize_json("3.14159", strict=True)
    tokenize_json("314159E-5")
    tokenize_json("314159E-5", strict=True)
    tokenize_json("0.314159E1")

# Generated at 2022-06-26 10:45:27.156454
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo": [1, "two"]}') == {'foo': [1, 'two']}


# Generated at 2022-06-26 10:45:34.735167
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json_0 = tokenize_json('')
    tokenize_json_1 = tokenize_json('"foo"')
    tokenize_json_2 = tokenize_json('{"foo": "bar"}')
    tokenize_json_3 = tokenize_json('{"foo": "bar", "baz": {"qux": "quux"}}')
    tokenize_json_4 = tokenize_json('{"foo": "bar", "baz": "qux"}')
    tokenize_json_5 = tokenize_json('{"foo": "bar", "baz": "qux"}')
    tokenize_json_6 = tokenize_json('{"foo": "bar", "baz": "qux"}')

# Generated at 2022-06-26 10:45:47.681773
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test with valid JSON string
    input_string = '{"hello": "world"}'
    expected_output = DictToken(
        {
            ScalarToken(
                "hello",
                0,
                6,
                input_string
            ): ScalarToken(
                "world",
                10,
                16,
                input_string
            )
        },
        0,
        16,
        input_string
    )
    assert (
        tokenize_json(
            input_string
        )
        ==
        expected_output
    )

    # Test with valid JSON bytestring
    input_string = b'["hello", "world"]'

# Generated at 2022-06-26 10:45:50.550613
# Unit test for function tokenize_json
def test_tokenize_json():
    assert True
    # Passes
    # See https://github.com/encode/typesystem/issues/173

# Generated at 2022-06-26 10:46:02.229733
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        '{"type":"object", "properties":{"age":{"type":"number","minimum":0}}}'
    )
    assert token.type == "object"
    assert token.start_pos == 0
    assert token.end_pos == 84
    assert len(token.value) == 2
    assert token.value[0].type == "string"
    assert token.value[0].value == "type"
    assert token.value[0].start_pos == 1
    assert token.value[0].end_pos == 7
    assert token.value[1].type == "object"
    assert token.value[1].value[0].type == "string"
    assert token.value[1].value[0].value == "age"
    assert token.value[1].value[0].start_pos == 16


# Generated at 2022-06-26 10:46:07.110901
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json('{"foo": "bar"}')
    assert isinstance(value, DictToken)
    assert value.data['foo'].data == 'bar'


# Generated at 2022-06-26 10:46:15.541836
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema([
        {"key": "foo", "type": "string"},
        {"key": "bar", "type": "string", "required": True},
        {"key": "baz", "type": "string"},
    ])
    data = {
        "foo": "hello",
        "bar": "world",
        "baz": "!"
    }
    assert validate_json(json.dumps(data), schema) == (data, [])

    # Handles empty content.
    assert ("No content.", "no_content") == validate_json("", schema)[1][0]

    # Handles parse errors.
    assert ("Expecting value", "parse_error") == validate_json("{", schema)[1][0]

# Generated at 2022-06-26 10:46:24.796696
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case where we pass a JSON string to decode.
    expected = ListToken([ScalarToken(1, 1, 1, "1"), ScalarToken(2, 3, 3, "2")], 0, 4, "[1,2]")
    actual = tokenize_json("[1,2]")
    assert actual == expected

    # Test case where we pass a JSON string that contains only whitespace.
    expected = ListToken([ScalarToken(1, 3, 3, "1"), ScalarToken(2, 5, 5, "2")], 0, 6, "[ 1, 2]")
    actual = tokenize_json("[ 1, 2]")
    assert actual == expected

    # Test case where we pass a JSON string with mixed whitespace.

# Generated at 2022-06-26 10:46:40.237599
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token == {"foo": "bar"}



# Generated at 2022-06-26 10:46:41.550991
# Unit test for function tokenize_json
def test_tokenize_json():
    assert True


# Generated at 2022-06-26 10:46:52.610320
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(dict(), 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("\"foo\"") == ScalarToken("foo", 0, 5, "\"foo\"")
    assert tokenize_json("123.4") == ScalarToken(123.4, 0, 4, "123.4")
    assert tokenize_json("{\"foo\":1}") == DictToken(
        {"foo": ScalarToken(1, 5, 6, "1")}, 0, 8, "{\"foo\":1}"
    )


# Generated at 2022-06-26 10:47:02.463988
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty content
    content = ""
    value = tokenize_json(content)

    # JSON Array
    content = '[1, true, "apples"]'
    value = tokenize_json(content)

    # JSON Object
    content = '{"a": 1, "b": {"c": "d"}}'
    value = tokenize_json(content)

    # JSON Primitives
    content = '{"a": 1, "b": true, "c": null, "d": "apples"}'
    value = tokenize_json(content)



# Generated at 2022-06-26 10:47:11.646440
# Unit test for function tokenize_json
def test_tokenize_json():

    # JSON string
    assert tokenize_json("{}") == DictToken({}, 0, 1, '{}')
    assert tokenize_json("[]") == ListToken([], 0, 1, '[]')
    assert tokenize_json("1") == ScalarToken(1, 0, 0, '1')
    assert tokenize_json("true") == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json("false") == ScalarToken(False, 0, 4, 'false')

    # JSON string with whitespace
    assert tokenize_json("\n\t   {}  \n\t") == DictToken({}, 5, 6, '\n\t   {}  \n\t')

# Generated at 2022-06-26 10:47:21.413839
# Unit test for function tokenize_json
def test_tokenize_json():
    # test empty string
    bad_jsons = ["", "  "]
    for bad_json in bad_jsons:
        with pytest.raises(ParseError):
            tokenize_json(bad_json)

    # test bad json
    bad_jsons = [
        "{1,2}",
        "3",
        "foo",
        "{'a': 1",
        "{'a' 1}",
        "a" * 100_000,
        "[a",
        "[",
        "[,,]",
    ]
    for bad_json in bad_jsons:
        with pytest.raises(ParseError):
            tokenize_json(bad_json)


# Generated at 2022-06-26 10:47:32.530836
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == ScalarToken(None, 0, 0)
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken('foo'): ScalarToken('bar')}, 0, 14)
    assert tokenize_json('{"foo": [1, 2.0, 3]}') == DictToken(
        {ScalarToken('foo'): ListToken([
            ScalarToken(1, 9, 2),
            ScalarToken(2.0, 12, 5),
            ScalarToken(3, 18, 3),
        ])},
        0,
        20,
    )

# Generated at 2022-06-26 10:47:40.651866
# Unit test for function tokenize_json
def test_tokenize_json():
    for content in [
        b'""',
        b'"\\"\\"',
        b'"\\"\\\\\\""',
        b'"\\"\\\\\\"\\\\\\""',
        b'""""',
    ]:
        result = tokenize_json(content)
        assert isinstance(result, ScalarToken)
    for content in [b"{}", b'{"":""}', b'{"":"", "":""}', b'{"":0}']:
        result = tokenize_json(content)
        assert isinstance(result, DictToken)
    for content in [b"[]", b"[0]", b"[0,1,2]"]:
        result = tokenize_json(content)
        assert isinstance(result, ListToken)

# Generated at 2022-06-26 10:47:41.558202
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") is not None


# Generated at 2022-06-26 10:47:50.832529
# Unit test for function tokenize_json
def test_tokenize_json():
    # Try to load fixtures.json
    try:
        with open("fixtures.json", "r") as fh:
            json_data = fh.read()
    except FileNotFoundError:  # pragma: no cover
        print("fixtures.json not found, skipping test_tokenize_json")
        return

    # Parse the json into the tokenized version
    token = tokenize_json(json_data)

    print(token)



# Generated at 2022-06-26 10:48:04.544961
# Unit test for function tokenize_json
def test_tokenize_json():
    string_0 = "{\n  \"\": 0\n}"
    token_0 = tokenize_json(string_0)
    dict_0 = dict(content='{\n  \"\": 0\n}', open_token=None, tokens=None, close_token=None, value={'': 0}, start=Position(column_no=1, line_no=1, char_index=0), end=Position(column_no=14, line_no=3, char_index=13))
    assert token_0 == dict_0

    string_1 = "{\n  \"\": 0,\n  \"\": 1\n}"
    token_1 = tokenize_json(string_1)

# Generated at 2022-06-26 10:48:06.503114
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenizing_decoder_1 = _TokenizingDecoder()


# Generated at 2022-06-26 10:48:15.608017
# Unit test for function tokenize_json

# Generated at 2022-06-26 10:48:24.881418
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == None
    assert tokenize_json(b'\xe2\x98\x83') == None
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}
    assert tokenize_json('{"foo": "bar", "baz": "buz"}') == {"foo": "bar", "baz": "buz"}
    assert tokenize_json("[{") == None
    assert tokenize_json('{"foo": ["bar", "baz"]}') == {"foo": ["bar", "baz"]}
    assert tokenize_json("{'foo': 'bar'}") == None

# Generated at 2022-06-26 10:48:30.443587
# Unit test for function tokenize_json
def test_tokenize_json():
    for i in range(100):
        print(i, tokenize_json('{"foo": ["bar"]}'))


if __name__ == "__main__":
    test_case_0()
    test_tokenize_json()

# Generated at 2022-06-26 10:48:40.876397
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing empty string
    content = ""
    try:
        token = tokenize_json(content)
        raise AssertionError("No exception was raised for input: %r" % (content))
    except ParseError as exc:
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.position.column_no == 1
        assert exc.code == "no_content"
        assert exc.text == "No content."



# Generated at 2022-06-26 10:48:49.058542
# Unit test for function tokenize_json
def test_tokenize_json():
    print("test_tokenize_json")
    address_schema = Schema({"address": {"type": "string", "required": True}})
    content = """
    {
        "address": "foo"
    }
    """
    try:
        value, errors = validate_json(content, address_schema)
        print("Value:")
        print(value)
        print("Errors:")
        print(errors)
        assert not errors
        assert value == {"address": "foo"}
    except AssertionError:
        print("AssertionError")
        raise


if __name__ == "__main__":
    test_case_0()
    test_tokenize_json()

# Generated at 2022-06-26 10:48:55.645837
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"a":1,"b":2,"c":3,"d":4,"e":5}'
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert len(token.value) == 5
    assert token.value["a"].value == 1
    assert token.value["b"].value == 2
    assert token.value["c"].value == 3
    assert token.value["d"].value == 4
    assert token.value["e"].value == 5



# Generated at 2022-06-26 10:49:06.470868
# Unit test for function tokenize_json
def test_tokenize_json():
    def check_mapping0(mapping):
        # Check type of ``mapping``
        assert isinstance(mapping, dict)

        # Check length of ``mapping``
        assert len(mapping) == 2

        # Check keys of ``mapping``
        assert list(sorted(mapping.keys())) == ['a', 'b']

        assert mapping['a'] == 1
        assert mapping['b'] == 2

    content_0 = '{"a": 1, "b": 2}'
    token_0 = tokenize_json(content_0)

    # Check type of ``token_0``
    assert isinstance(token_0, dict)

    # Check keys of ``token_0``
    assert list(sorted(token_0.keys())) == ['a', 'b']

    # Check type of ``token_

# Generated at 2022-06-26 10:49:11.408186
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)

    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": 2}



# Generated at 2022-06-26 10:49:24.927957
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tests for tokenize_json
    decoder_0 = _TokenizingDecoder(content="")

# Generated at 2022-06-26 10:49:34.133285
# Unit test for function tokenize_json
def test_tokenize_json():
    # Set up test data
    content = b""

    # Invoke method
    try:
        tokenize_json(content)
        assert False, "Expected to throw ParseError."
    except ParseError as exc:
        # Check for return data
        assert "No content." in str(exc)
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0



# Generated at 2022-06-26 10:49:43.317146
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": "c"}') == DictToken(
        {"a": ScalarToken(1, 2, 3, '{"a": 1, "b": "c"}'), "b": ScalarToken("c", 10, 13, '{"a": 1, "b": "c"}')},
        0,
        18,
        '{"a": 1, "b": "c"}',
    )



# Generated at 2022-06-26 10:49:54.375895
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json(""), DictToken)
    assert tokenize_json("") == DictToken(
        {"key": ScalarToken(1, 1, 0, "")}, 1, 0, ""
    )
    assert tokenize_json("") == DictToken({"key": ScalarToken(1, 1, 0, "")}, 1, 0, "")
    assert tokenize_json("") == DictToken({"key": ScalarToken(1, 1, 0, "")}, 1, 0, "")

# Generated at 2022-06-26 10:50:07.765465
# Unit test for function tokenize_json
def test_tokenize_json():
    # check simple string:
    tokenize_json("{'ok': True}")
    tokenize_json("true")
    tokenize_json("false")
    # check special characters:
    tokenize_json("\"")
    tokenize_json("\'")
    tokenize_json("\b")
    tokenize_json("\f")
    tokenize_json("\n")
    tokenize_json("\r")
    tokenize_json("\t")
    tokenize_json("\\")
    tokenize_json("/")
    # check Unicode:
    tokenize_json("\u1234")
    # check "None" value
    tokenize_json("None")
    # check wrong string

# Generated at 2022-06-26 10:50:09.775479
# Unit test for function tokenize_json
def test_tokenize_json():
    pass


# Generated at 2022-06-26 10:50:11.852086
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[1, 2]") == ListToken([1, 2])



# Generated at 2022-06-26 10:50:19.895432
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key": "value"}'
    result = tokenize_json(json_str)
    assert type(result) == DictToken
    assert result.value == {'key': 'value'}
    assert type(result.value['key']) == ScalarToken
    assert result.value['key'].value == 'value'
    
    json_str = '[1, 2, "astring", null, [], {}]'
    result = tokenize_json(json_str)
    assert type(result) == ListToken
    assert type(result.value) == list
    assert type(result.value[0]) == ScalarToken
    assert result.value[0].value == 1
    assert type(result.value[1]) == ScalarToken
    assert result.value[1].value == 2

# Generated at 2022-06-26 10:50:28.928596
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that we can parse valid JSON.

    def schema_from_spec(spec: typing.Dict) -> Schema:
        return Schema(spec, name="Test Schema")

    def assert_validates_as(
        content: typing.Union[bytes, str],
        target_type: typing.Type,
        schema: typing.Optional[Schema] = None,
    ) -> None:
        if isinstance(content, bytes):
            content = content.decode("utf-8", "ignore")

        token = tokenize_json(content)
        assert isinstance(token, target_type)
        if schema is not None:
            for error in schema.validate(token):
                raise AssertionError(error.as_dict())

    assert_validates_as('"foo"', ScalarToken)

# Generated at 2022-06-26 10:50:41.532325
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key": "value"}'
    json_dict = {"key": "value"}
    ret = tokenize_json(json_str)
    assert ret == json_dict

    json_str = """
    {
        "key": "value"
    }
    """
    json_dict = {"key": "value"}
    ret = tokenize_json(json_str)
    assert ret == json_dict

    json_str = '{"key": "val\nu\te"}'
    json_dict = {"key": "val\nu\te"}
    ret = tokenize_json(json_str)
    assert ret == json_dict

    json_str = """
    {
        "key": "val\nu\te"
    }
    """

# Generated at 2022-06-26 10:50:47.638100
# Unit test for function tokenize_json
def test_tokenize_json():
    assert callable(tokenize_json)
    # TODO: add more tests, this is just a smoke test.
    tokenize_json("")

# Generated at 2022-06-26 10:50:54.296001
# Unit test for function tokenize_json
def test_tokenize_json():
    schema_structure_0 = {
        "array": False,
        "default": None,
        "properties": {"name": {"array": False, "default": None, "required": False, "type": "string"}},
        "required": False,
        "type": "object",
    }
    schema_structure_1 = {
        "array": False,
        "default": None,
        "properties": {"name": {"array": False, "default": None, "required": False, "type": "string"}},
        "required": False,
        "type": "object",
    }

# Generated at 2022-06-26 10:51:02.944327
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"key": "value"}') == DictToken({"key": ScalarToken("value", 1, 13, '{"key": "value"}')}, 0, 15, '{"key": "value"}')
    assert tokenize_json('{"key": "value", "key2": 2}') == DictToken({"key": ScalarToken("value", 1, 13, '{"key": "value", "key2": 2}'), "key2": ScalarToken(2.0, 16, 20, '{"key": "value", "key2": 2}')}, 0, 22, '{"key": "value", "key2": 2}')

# Generated at 2022-06-26 10:51:13.086358
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1}'
    source_content = content
    _TokenizingDecoder = _TokenizingDecoder
    tokenizing_decoder_0 = _TokenizingDecoder(content=source_content)
    tokens_0 = tokenizing_decoder_0.decode(content)
    expected = {
            'a': 1
    }
    # assert tokens_0 == expected
    assert tokens_0, "Please fix your unit test!"


# Generated at 2022-06-26 10:51:26.631115
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello"') is not None and type(tokenize_json('"hello"')) == ScalarToken
    assert tokenize_json('"hello"').value == 'hello'
    assert tokenize_json('"hello"').position.column_no == 1 and tokenize_json('"hello"').position.line_no == 1 and tokenize_json('"hello"').position.char_index == 0
    assert tokenize_json('"hello"').position.end_column_no == 7 and tokenize_json('"hello"').position.end_line_no == 1 and tokenize_json('"hello"').position.end_char_index == 6
    assert tokenize_json('"hello"').content == '"hello"'
    
    assert tokenize_json('{"key": "value"}') is not None and type

# Generated at 2022-06-26 10:51:34.621353
# Unit test for function tokenize_json
def test_tokenize_json():
    INVALID_CONTENT = "<not json>"
    parsed = tokenize_json(INVALID_CONTENT)
    assert isinstance(parsed, DictToken)
    assert len(parsed.children) == 1
    assert isinstance(parsed.children[0], ScalarToken)
    assert parsed.children[0].value == "not"
