

# Generated at 2022-06-22 06:19:08.915064
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import dumps
    from json_validation.typesystem.schemas import Schema
    from json_validation.typesystem.fields import String, Integer

    class UserSchema(Schema):
        name = String()
        age = Integer()
        id = Integer()


# Generated at 2022-06-22 06:19:11.711334
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder_tester = _TokenizingDecoder(content="[]")
    assert decoder_tester.context is None
    assert decoder_tester.memo is {}

# Generated at 2022-06-22 06:19:13.653146
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder()


# Generated at 2022-06-22 06:19:18.897883
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.scan_once
    assert decoder.parse_object
    assert decoder.parse_array
    assert decoder.parse_string
    assert decoder.match_number
    assert decoder.strict
    assert decoder.parse_float
    assert decoder.parse_int
    assert decoder.memo


# Generated at 2022-06-22 06:19:19.996962
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()



# Generated at 2022-06-22 06:19:26.869173
# Unit test for function validate_json
def test_validate_json():
    content = """
    {
        "foo": [
            {"bar": "baz"},
            {"baz": "baz"},
            {"bat": 1},
            {"bat": 2}
        ]
    }
    """
    try:
        validate_json(content, validator=List(
            validators=[Dict(
                fields={
                    "bar": String(required=False),
                    "baz": String(required=False),
                    "bat": Integer(required=False),
                }
            )]
        ))
    except ValidationError as exc:
        validation_errors = list(exc)
        assert len(validation_errors) == 2

        foo_list_error = validation_errors[0]

# Generated at 2022-06-22 06:19:38.340396
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"foo":["foo","bar"], "bar": {"baz": "qux"}}'
    expected = DictToken(
        [
            (
                ScalarToken("foo", 0, 3, json),
                ListToken(
                    [
                        ScalarToken("foo", 8, 11, json),
                        ScalarToken("bar", 12, 15, json),
                    ],
                    5,
                    16,
                    json,
                ),
            ),
            (
                ScalarToken("bar", 20, 23, json),
                DictToken(
                    [(ScalarToken("baz", 27, 30, json), ScalarToken("qux", 31, 34, json))],
                    25,
                    35,
                    json,
                ),
            ),
        ],
        0,
        36,
        json,
    )

# Generated at 2022-06-22 06:19:45.091965
# Unit test for function validate_json
def test_validate_json():
    invalid_json = b"{'foo': 'bar'}"
    invalid_value, error_messages = validate_json(invalid_json, Field())
    assert error_messages[0].code == "parse_error"

    invalid_json = '{"foo": "bar"}'
    valid_value, error_messages = validate_json(invalid_json, Field())
    assert len(error_messages) == 0
    assert valid_value == {"foo": "bar"}

# Generated at 2022-06-22 06:19:56.511742
# Unit test for function validate_json
def test_validate_json():
    assert(validate_json(b'{"a":1}', {"a": int}))
    assert(validate_json(b'{"a":1.1}', {"a": float}))
    assert(validate_json(b'{"a":null}', {"a": None}))
    assert(validate_json(b'{"a":true}', {"a": bool}))

    messages = validate_json(b'{"a": 1}', {"a": str})[1]
    assert(messages[0].code == "type_mismatch")

    messages = validate_json(b'{"a":}', {"a": str})[1]
    assert(messages[0].code == "parse_error")

    messages = validate_json(b'', {"a": str})[1]

# Generated at 2022-06-22 06:19:59.092064
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="").content == ""



# Generated at 2022-06-22 06:20:18.260813
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"field1": "value", "field2": [1, 2, 3]}') == DictToken({
        "field1": ScalarToken("value"),
        "field2": ListToken([
            ScalarToken(1),
            ScalarToken(2),
            ScalarToken(3)
        ])
    })

# Generated at 2022-06-22 06:20:25.011448
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case: wrong syntax
    result = tokenize_json('{ "name": "Eric", "age": 0, "height": "1.65m"}')
    assert isinstance(result, DictToken)
    assert result.value['age'].value == 0
    assert result.value['name'].value == 'Eric'
    assert result.value['height'].value == '1.65m'



# Generated at 2022-06-22 06:20:36.107679
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:20:38.336927
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _make_scanner is not None

# Generated at 2022-06-22 06:20:43.754088
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    text = '{"a": ["b", "c", {"d": 1}]}'
    tokens = _TokenizingDecoder().decode(text)
    assert tokens[0].value == 'a'
    assert tokens[1].value == 'b'
    assert tokens[2].value == 'c'
    assert tokens[3][0].value == 'd'
    assert tokens[3][1].value == 1

# Generated at 2022-06-22 06:20:49.703012
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    source = '"b" : "c"'
    token = tokenize_json(source)
    assert isinstance(token, DictToken)
    assert token.source_start == 0
    assert token.source_end == 5
    scalar = token.value["b"]
    assert isinstance(scalar, ScalarToken)
    assert scalar.value == "c"


# Generated at 2022-06-22 06:20:51.812725
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert repr(_TokenizingDecoder("", "", "", content="content")) == "<_TokenizingDecoder content=\"content\">"

# Generated at 2022-06-22 06:21:03.612058
# Unit test for function validate_json
def test_validate_json():
    # Define a JSON schema matching the JSON input
    class PersonSchema(Schema):
        class Meta:
            options = {"strict": True}

        first_name = "string"
        last_name = "string"
        age = "integer"

    # Good input
    good_input = '{"first_name": "John", "last_name": "Smith", "age": 25}'
    value, errors = validate_json(good_input, PersonSchema)
    assert errors == []
    assert value == {"first_name": "John", "last_name": "Smith", "age": 25}

    # Bad input
    bad_input = '{"first_name": "John", "age": "invalid_age"}'
    value, errors = validate_json(bad_input, PersonSchema)

# Generated at 2022-06-22 06:21:04.767752
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="{}") # pragma: no cover

# Generated at 2022-06-22 06:21:09.817271
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    If an empty string is provided, an error is raised.

    """
    errors = []
    try:
        tokenize_json("")
    except ValidationError as error:
        errors.append(error)

    assert len(errors) == 1
    assert errors[0].position.char_index == 0

# Generated at 2022-06-22 06:21:27.931565
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json1 = ""
    input_json2 = "null"
    input_json3 = '[{"type": "A", "data": "A"}, {"type": "B", "data": "B"}, {"type": "C", "data": "C"}]'
    input_json4 = '{"type": "A", "data": "A"}'
    input_json5 = '{"type": "A", "data": "A", "data2": "B"}'
    input_json6 = '{"type": "A", "data": "A", "data2": "B", "data3": "C"}'
    input_json7 = '{"type": "A", "data": "A", "data2": "B", "data3": "C", "data4": "D"}'

# Generated at 2022-06-22 06:21:35.345997
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "pham the hien"}'
    token = tokenize_json(content)
    assert(token.value == {'name': 'pham the hien'})
    assert(token.start == 0)
    assert(token.end == 23)
    assert(token.content == content)

test_tokenize_json()

# Generated at 2022-06-22 06:21:37.068972
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": 2}'
    token = tokenize_json(content)
    assert {"a": 1, "b": 2} == token.value



# Generated at 2022-06-22 06:21:48.607793
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json() function.
    """
    from typesystem.fields import String, Array, Dict
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        class Meta:
            fields = [
                Dict(name="foo", required=True, fields=[String(name="bar")]),
                Array(name="baz", required=True, items=String()),
            ]

    assert validate_json(b'{"foo":{"bar":"bob"},"baz":["alice","4"]}', TestSchema) == (
        {"foo": {"bar": "bob"}, "baz": ["alice", "4"]},
        [],
    )


# Generated at 2022-06-22 06:21:57.982243
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{\
        "countries": [\
            {\
                "name": "Spain",\
                "population": "46.59m",\
                "postal_codes": [\
                    "280xx",\
                    "290xx",\
                    "380xx",\
                    "390xx",\
                    "480xx",\
                    "490xx"\
                ]\
            },\
            {\
                "name": "France",\
                "population": "66.99m",\
                "postal_codes": [\
                    "2Axx",\
                    "2Bxx"\
                ]\
            }\
        ]\
    }"""
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:22:01.510874
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "name": "joe" }'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-22 06:22:05.447338
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"status":"0"}')
    assert isinstance(token, DictToken)
    assert isinstance(token.content, dict)
    assert token.content['status'] == "0"


# Generated at 2022-06-22 06:22:14.992397
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"a": "b", "c": {"d": 1}, "e": ["f", 3, 4]}"""
    token = tokenize_json(content)
    expected = DictToken(
        {
            ScalarToken("a"): ScalarToken("b"),
            ScalarToken("c"): DictToken(
                {ScalarToken("d"): ScalarToken(1)}
            ),
            ScalarToken("e"): ListToken([ScalarToken("f"), ScalarToken(3), ScalarToken(4)]),
        },
        0,
        len(content) - 1,
        content,
    )
    assert token.as_dict() == expected.as_dict()



# Generated at 2022-06-22 06:22:20.662210
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Setup
    decoder = _TokenizingDecoder(strict=True, object_pairs_hook=True, content="")

    # Assertions
    assert isinstance(decoder, JSONDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-22 06:22:21.803395
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(_TokenizingDecoder().scan_once)

# Generated at 2022-06-22 06:22:28.818376
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizer = _TokenizingDecoder(content = 'content')
    assert(tokenizer.scan_once != None)


# Generated at 2022-06-22 06:22:34.090286
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Given
    json_string = '{"test_key":"test_value"}'
    decoder = _TokenizingDecoder(content=json_string)

    # When
    decoder.decode(json_string)

    # Then
    assert decoder.scan_once

# Generated at 2022-06-22 06:22:42.220295
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "foo": "123", "bar": 456 }'
    context = _TokenizingDecoder(content=content)
    context.parse_array = JSONDecoder().parse_array
    context.parse_string = JSONDecoder().parse_string
    context.parse_float = JSONDecoder().parse_float
    context.parse_int = JSONDecoder().parse_int
    context.strict = False
    context.memo = {}
    assert context.scan_once == _make_scanner(context, content)


# Generated at 2022-06-22 06:22:52.684327
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name":"john","items":["chocolate","cookies"]}'
    expected_tokens = [
        ScalarToken("name", 1, 12, content),
        ScalarToken("john", 14, 25, content),
        ScalarToken("items", 27, 40, content),
        ListToken(["chocolate", "cookies"], 43, 66, content),
    ]
    json_tokens = tokenize_json(content).tokens
    for t1, t2 in zip(expected_tokens, json_tokens):
        assert t1.value == t2.value
        assert t1.start == t2.start
        assert t1.end == t2.end
        assert t1.content == t2.content



# Generated at 2022-06-22 06:22:57.908949
# Unit test for function validate_json
def test_validate_json():
    schemas = {
        "name": "TestSchema",
        "properties": {
            "prop1" : {
                "type": "integer",
                "minimum": 1,
                "maximum": 10
            },
            "prop2" : {
                "type": "integer",
            },
            "prop3" : {
                "type": "number",
                "minimum": 1,
                "maximum": 10
            },
            "prop4" : {
                "type": "number",
            },
        },
    }
    TestSchema = Schema.from_dict(schemas)

    content = r"""
        {
            "prop1": 0,
            "prop2": 1,
            "prop3": -1,
            "prop4": -1.0,
        }
    """
   

# Generated at 2022-06-22 06:23:07.597610
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    content = '{"name": "test"}'
    is_valid, error_messages = validate_json(content=content, validator=field)

    assert is_valid == False
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be of type 'string'."
    assert error_messages[0].code == "type_error"
    assert error_messages[0].position.column_no == 14
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.char_index == 13



# Generated at 2022-06-22 06:23:18.232766
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """{
        "some_list": [],
        "some_dict": {},
        "some_bool": true,
        "some_int": 123,
        "some_float": 123.123,
        "some_string": "testing the tokens",
        "some_null": null
    }"""

    content = tokenize_json(json)
    assert isinstance(content, DictToken)
    assert content.value["some_list"] == ListToken(value=[], start=14, end=16, content=json)
    assert content.value["some_dict"] == DictToken(value={}, start=33, end=35, content=json)
    assert content.value["some_bool"] == ScalarToken(value=True, start=52, end=56, content=json)

# Generated at 2022-06-22 06:23:22.423444
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"field": "value"}'
    assert tokenize_json(content) == DictToken({'field': ScalarToken('value', 10, 15, content)}, 0, 17, content)


# Generated at 2022-06-22 06:23:25.039899
# Unit test for function validate_json
def test_validate_json():
    """
    >>> validate_json('', None)
    (None, [<Position: (1, 1, 0)>])
    """



# Generated at 2022-06-22 06:23:34.603111
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, String, Integer

    schema = Schema({"some_str": String(max_length=10), "some_int": Integer(max_value=5)})

    content = b'{"some_str": "hello"}'
    value, error_messages = validate_json(content, schema)
    assert not error_messages
    assert value == {"some_str": "hello", "some_int": None}
    
    content = '{"some_str": "hello"}'
    value, error_messages = validate_json(content, schema)
    assert not error_messages
    assert value == {"some_str": "hello", "some_int": None}

    content = b'{"some_int": 2}'
    value, error_messages = validate_json(content, schema)
   

# Generated at 2022-06-22 06:23:42.566100
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert isinstance(decoder, JSONDecoder)
    assert decoder.scan_once is not None


# Generated at 2022-06-22 06:23:52.261164
# Unit test for function validate_json
def test_validate_json():
    input_content = '{"a": 1}'
    schema_json = '{"a": {"type": "integer"}}'
    message = {
        'context': {
            'field': 'a'
        },
        'text': 'Must be a valid integer',
        'code': 'invalid_type',
        'position': {
            'column_no': 4,
            'line_no': 1,
            'char_index': 3
        }
    }
    input_content_json = json.loads(input_content)
    schema_json_json = json.loads(schema_json)
    schema = Schema(schema_json_json, name="Test")
    token = tokenize_json(input_content)
    expected_result = Message(input_content_json, [message])
    actual_result

# Generated at 2022-06-22 06:24:01.378621
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.strict == True
    assert decoder.context == None
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_float == JSONDecoder.parse_float
    assert decoder.parse_int == JSONDecoder.parse_int
    assert decoder.parse_constant == JSONDecoder.parse_constant
    assert decoder.memo == {}
    assert decoder.parse_object == JSONDecoder.parse_object
    assert decoder.parse_string == JSONDecoder.parse_string
    assert decoder.scan_once == _make_scanner(decoder, content)
    assert decoder.scan_once == _make_scanner(decoder, content)

#

# Generated at 2022-06-22 06:24:06.325558
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    decoder = _TokenizingDecoder(content=content)
    tok, end = decoder.scan_once(content, 0)
    assert type(tok) == DictToken
    assert end == len(content)


# Generated at 2022-06-22 06:24:11.656714
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"a\": 1, \"b\": 2 }"
    decoder = _TokenizingDecoder(content=content)
    value, error_messages = validate_json(content, decoder)
    assert error_messages == []
    assert value == {"a": 1, "b": 2}


# Generated at 2022-06-22 06:24:13.728799
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content="{}")

# Generated at 2022-06-22 06:24:17.712762
# Unit test for function validate_json
def test_validate_json():
    content = "{\"id\": 12, \"name\": \"John Doe\", \"status\": \"active\"}"
    error_messages = validate_json(content, UserSchema)
    assert error_messages == []


# Generated at 2022-06-22 06:24:27.899450
# Unit test for function tokenize_json
def test_tokenize_json():
    import six

    # Test a variety of object types.
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"string"') == ScalarToken("string", 0, 8, '"string"')
    assert tokenize_json("123.4") == ScalarToken(123.4, 0, 5, "123.4")
    assert tokenize_json("[1, 2]") == ListToken([ScalarToken(1, 1, 2, "1"), ScalarToken(2, 4, 5, "2")], 0, 6, "[1, 2]")

# Generated at 2022-06-22 06:24:34.762118
# Unit test for function tokenize_json
def test_tokenize_json():
    # Simple valid input
    content = '{"a": "b"}'
    assert tokenize_json(content) == {"a": "b"}
    # Simple error input
    content = '{"a": "b"'
    with pytest.raises(ParseError) as excinfo:
        tokenize_json(content)  # noqa

    assert excinfo.value.text == "Unterminated string starting at: line 1 column 8 (char 7)"



# Generated at 2022-06-22 06:24:46.634938
# Unit test for function validate_json
def test_validate_json():
    # Valid content
    # Set up a test validator
    class TestValidator(Field):
        def bounds(self, item):
            # Raise an error if the value is not greater than 0.
            if item <= 0:
                raise ValidationError("Number is not greater than 0")
            return item

    validator = TestValidator()
    content = json.dumps(1)
    value, error_messages = validate_json(content, validator)
    # Make sure the value and error messages are returned
    assert(value == 1)
    assert(not error_messages)

    # No content
    content = json.dumps(0)
    value, error_messages = validate_json(content, validator)
    # Make sure the error message is returned
    assert(not value)
    assert(error_messages)

# Generated at 2022-06-22 06:24:55.082340
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = "{}"
    token = tokenize_json(valid_json)
    assert isinstance(token, DictToken)
    invalid_json = "{...}"
    with pytest.raises(ParseError):
        tokenize_json(invalid_json)


# Generated at 2022-06-22 06:25:07.241042
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "John",
        "age": 30,
        "friends": [
            { "name": "Robert", "age": 24 },
            { "name": "Alice", "age": 24 }
        ]
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {
        "name": "John",
        "age": 30,
        "friends": [
            {"name": "Robert", "age": 24},
            {"name": "Alice", "age": 24},
        ],
    }

    # When the string is empty or only contains whitespace, the parser should
    # fail with a ParseError.

# Generated at 2022-06-22 06:25:18.051696
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "{\"name\": \"abc\"}"
    test_strict = False
    test_object_pairs_hook = None
    test_parse_float = float
    test_parse_int = int
    test_parse_constant = None
    test_strict = False
    decoder = _TokenizingDecoder(
        test_content,
        test_strict,
        test_object_pairs_hook,
        test_parse_float,
        test_parse_int,
        test_parse_constant,
    )
    assert decoder.strict == test_strict
    assert decoder.parse_float == test_parse_float
    assert decoder.parse_int == test_parse_int
    assert decoder.parse_constant == test_parse_constant
    assert decoder.object

# Generated at 2022-06-22 06:25:29.611888
# Unit test for function validate_json
def test_validate_json():
    # validator is a field
    email_field = Field(type="string", format="email")
    content = '{"email": "jon@example.com", "age": 33}'

    value, error_messages = validate_json(content, email_field)
    assert value == "jon@example.com"
    assert isinstance(error_messages, list)
    assert len(error_messages) == 0

    content = '{"email": "jon"}'
    value, error_messages = validate_json(content, email_field)
    assert value == "jon"
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert error_messages[0].message_text == "Invalid email address."

    # validator is a schema

# Generated at 2022-06-22 06:25:43.015543
# Unit test for function validate_json
def test_validate_json():
    """
    Tests for validate_json
    """
    json_string = '{ "name": "John", "age": 30, "cars": { "car1": "Ford", "car2": "BMW", "car3": "Fiat" }}'
    json_string_invalid = '{ "name": "John", "age": 30, "cars": { "car1": "Ford", "car2": "BMW", "car3": "Fiat" }'

    class TestModel(Schema):
        name = Field(String())
        age = Field(Integer())
        cars = Field(Dictionary(Keys(String()), Values(String())))

    value, errors = validate_json(json_string, TestModel)
    assert not errors

# Generated at 2022-06-22 06:25:53.599667
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test true
    assert _TokenizingDecoder('{"hi":true}', object_hook=lambda x: x).decode('{"hi":true}') == \
        {'hi': True}
    # Test false
    assert _TokenizingDecoder('{"hi":false}', object_hook=lambda x: x).decode('{"hi":false}') == \
        {'hi': False}
    # Test null
    assert _TokenizingDecoder('{"hi":null}', object_hook=lambda x: x).decode('{"hi":null}') == \
        {'hi': None}
    # Test string
    assert _TokenizingDecoder('{"hi":"hello"}', object_hook=lambda x: x).decode('{"hi":"hello"}') \
        == {'hi': 'hello'}
    # Test int


# Generated at 2022-06-22 06:25:55.223084
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-22 06:26:06.089870
# Unit test for function validate_json

# Generated at 2022-06-22 06:26:14.801173
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(object_hook=_TokenizingJSONObject, object_pairs_hook=None, parse_float=float, parse_int=int, parse_constant=None, strict=True, object_hook=None, object_pairs_hook=None, parse_float=None, parse_int=None, parse_constant=None, strict=None, parse_array=None, parse_string=None, memo=None, _w=WHITESPACE.match, _ws=WHITESPACE_STR, content="this is a content")


# Generated at 2022-06-22 06:26:20.087236
# Unit test for function tokenize_json
def test_tokenize_json():
    # Arrange
    content_with_exponent = '{"type":"object","properties":{"name":{"type":"string","maxLength":200},"age":{"type":"integer","minimum":13,"maximum":100,"multipleOf":1}}}'
    content_with_exponent_fail = '{"type":"object","properties":{"name":{"type":"string","maxLength":200},"age":{"type":"integer","minimum":13,"maximum":100,"multipleOf":1}'
    content_numeric_string = '{"type":"object","properties":{"name":{"type":"string","maxLength":200},"age":{"type":"numeric"}}}'
    content_numeric_string_fail = '{"type":"object","properties":{"name":{"type":"string","maxLength":200},"age":{"type":"numeric'

# Generated at 2022-06-22 06:26:35.479099
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key1": "value1", "key2": 2, "key3": true, "key4": null, "key5": ["item1", "item2", {"item3": 3}], "key6": {"item1":"value1", "item2": 2 }, "key7": {"item1": {"item2": {"item3": {"item4": {"item5": {"item6": {"item7": "value2"}}}}}}} }'
    token = tokenize_json(json_str)
    print("")
    print("print the token")
    print(token)
    print("")
    print("print each token")
    for key, value in token.items():
        print("printing key: " + str(key))

# Generated at 2022-06-22 06:26:37.688155
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder(content="{}")
    assert tokenizing_decoder.scan_once("{}", 0) != None

# Generated at 2022-06-22 06:26:39.242942
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:26:40.905590
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content='content')

# Generated at 2022-06-22 06:26:43.791228
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder("", "")
    assert context.__class__.__name__ == "_TokenizingDecoder"
    assert context.scan_once("", "") == StopIteration


# Generated at 2022-06-22 06:26:55.024801
# Unit test for function validate_json
def test_validate_json():
    # Create message to compare against
    position = Position(line_no=1, column_no=1, char_index=0)
    field = "value"
    text = "This field is required."
    code = "required"
    message = Message(field=field, text=text, code=code, position=position)

    # Check for error on empty string
    content = ""
    value = None
    error_messages = [message]
    results = validate_json(content, Field(required=True))
    assert results == (value, error_messages)

    # Check for error on whitespace-only string
    content = " "
    value = None
    error_messages = [message]
    results = validate_json(content, Field(required=True))
    assert results == (value, error_messages)




# Generated at 2022-06-22 06:27:07.110876
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test the "normal" case
    assert tokenize_json("{\"foo\": \"bar\"}") == {'foo': 'bar'}

    # Test non-string content
    assert tokenize_json(b"{\"foo\": \"bar\"}") == {'foo': 'bar'}

    # Test non-string content with trailing/leading whitespace
    assert tokenize_json(b" {\"foo\": \"bar\"} ") == {'foo': 'bar'}

    # Test non-string content with trailing/leading whitespace and
    # other invalid non-whitespace characters.
    assert tokenize_json(b"* {\"foo\": \"bar\"} ") == {'foo': 'bar'}

    # Test the empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_

# Generated at 2022-06-22 06:27:08.564958
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.scan_once != None


# Generated at 2022-06-22 06:27:18.326410
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string", nullable=True)
    value, errors = validate_json("null", validator)
    assert value == None
    assert errors == []
    value, errors = validate_json("False", validator)
    assert value == "False"
    assert errors == [Message("Value is not valid.", "type_error", Position(1, 0, 1))]

    validator = Field(type="integer")
    value, errors = validate_json("[0]", validator)
    assert value == 0
    assert errors == [Message("Value is not valid.", "type_error", Position(1, 0, 1))]

# Generated at 2022-06-22 06:27:29.235308
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:27:44.339814
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello"') == ScalarToken('hello', 0, 6, '"hello"')
    assert tokenize_json('[1,2,3]') == ListToken([1, 2, 3], 0, 7, '[1,2,3]')
    assert tokenize_json('{"hi": "there"}') == DictToken({"hi": "there"}, 0, 16, '{"hi": "there"}')
    assert tokenize_json('{"hi": {"there": "buddy"}}') == DictToken({"hi": DictToken({"there": "buddy"}, 6, 17, '{"there": "buddy"}')}, 0, 17, '{"hi": {"there": "buddy"}}')


# Generated at 2022-06-22 06:27:54.426819
# Unit test for function validate_json
def test_validate_json():
    schema = validator = Schema(
        fields={"name": String(), "age": Integer(maximum=120)},
        additional_properties=False,
    )
    data = '{"name": "John", "age": 50, "unknown_key": "test"}'
    value, errors = validate_json(data, validator)
    assert value == {"name": "John", "age": 50}
    assert errors == [
        Message(
            message="Additional properties are not allowed",
            code="additional_properties",
            path=["unknown_key"],
            position=Position(char_index=32, line_no=1, column_no=33),
        )
    ]

    data = '{"name": "John", "age": 170}'
    value, errors = validate_json(data, validator)
    assert value

# Generated at 2022-06-22 06:28:05.634884
# Unit test for function validate_json
def test_validate_json():
    content = '{"type":"integer","title":"A integer","min_value":1}'
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema, fields
    from typesystem.wrappers import Base64
    from typesystem.exceptions import ValidationError
    from typesystem.json.errors import ParseError, ValidationErrors
    from typesystem.json.validators import JSONSchemaValidator, JWTValidator

    class IntegerSchema(Schema):
        type = String(enum=["integer"])
        title = String(required=True)
        min_value = Integer()
        default = fields.Constant(1)

    class IntegerSchemaValidator(JSONSchemaValidator):
        schema = IntegerSchema


# Generated at 2022-06-22 06:28:07.999526
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "1234")
    assert id(decoder) == id(decoder)


# Generated at 2022-06-22 06:28:10.413118
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("test_content")
    assert decoder.content == "test_content"


# Generated at 2022-06-22 06:28:16.581006
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
    try:
        tokenize_json("{}.")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 3
    assert tokenize_json("{}") == {"": ""}

