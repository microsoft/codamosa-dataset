

# Generated at 2022-06-22 06:18:47.958689
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.validators import (
        Dictionary,
        Float,
        Integer,
        List,
        String,
    )
    from typesystem.schemas import Schema

    class TokenTestSchema(Schema):
        int_field = Integer()
        float_field = Float()
        string_field = String()
        list_field = List(String())
        dict_field = Dictionary(properties={"a": String(), "b": String()})

    json_dict = '{"int_field": 2, "float_field": 2.2, "string_field": "Hello", "list_field": ["hi", "hello"], "dict_field": {"a": "1", "b": "2"}}'
    token = tokenize_json(json_dict)
    assert isinstance(token, DictToken)
    errors

# Generated at 2022-06-22 06:18:58.404187
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"id": "f3d3f3", "count": 3.1, "category": 2, "recovery": false, "timestamp": "2019-03-23T15:31:10.215Z", "names": ["e", "f", "g"]}]'
    token = tokenize_json(content)
    assert token.value == [
        {
            "id": "f3d3f3",
            "count": 3.1,
            "category": 2,
            "recovery": False,
            "timestamp": "2019-03-23T15:31:10.215Z",
            "names": ["e", "f", "g"],
        }
    ]



# Generated at 2022-06-22 06:19:07.301915
# Unit test for function validate_json
def test_validate_json():
    schema = {
        "scalar": int,
        "list_in_dict": [str],
        "dict_in_dict": {"item": int},
    }
    content = '{ "scalar": 10, "list_in_dict": ["a", "b"], "dict_in_dict": { "item": 20 } }'
    value, error_messages = validate_json(content, Schema(schema))
    if error_messages:
        raise ValueError("Expected no errors. Found: {}".format(error_messages))

# Generated at 2022-06-22 06:19:10.251342
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder({"a": 1, "b": 2})
    assert len(decoder.memo) == 0

# Generated at 2022-06-22 06:19:21.481917
# Unit test for function validate_json
def test_validate_json():
    from unittest.mock import Mock
    from typesystem.fields import BaseField
    from typesystem.types import String

    # Setup a mock validator
    validator_mock = Mock(spec=BaseField)
    validator_mock.validate = String("").validate
    validator_mock.label = "mock validator"

    # Valid input
    content = (
        '{'
        '"a": "foo",'
        '"b": "bar",'
        '"c": "baz"'
        '}'
    )
    value, errors = validate_json(content, validator_mock)
    assert value == {"a": "foo", "b": "bar", "c": "baz"}
    assert len(errors) == 0

    # Invalid input

# Generated at 2022-06-22 06:19:26.558075
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Make sure that a tokenizing decoder can be constructed without error.
    _TokenizingDecoder("", "content")

# Generated at 2022-06-22 06:19:38.037466
# Unit test for function validate_json
def test_validate_json():
    content='{"Model Name": "iPod touch", "Product Year": 2012}'
    field_vaildate_schema_json = Field(type="schema-json")
    value, message = validate_json(content=content, validator=field_vaildate_schema_json)
    message_collection = []
    message_collection.extend(message)
    assert isinstance(message_collection, list)
    assert len(message_collection) == 0
    
    content='{"Model Name": [1, 2, 3], "Product Year": 2012}'
    value, message = validate_json(content=content, validator=field_vaildate_schema_json)
    message_collection = []
    message_collection.extend(message)
    assert isinstance(message_collection, list)

# Generated at 2022-06-22 06:19:42.900002
# Unit test for function tokenize_json
def test_tokenize_json():  # pragma: no cover
    assert tokenize_json(b'{"foo": "bar", "baz": 5}') == DictToken({
        'foo': ScalarToken('bar', 0, 11),
        'baz': ScalarToken(5, 12, 18),
    }, 0, 18)



# Generated at 2022-06-22 06:19:45.093298
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.scan_once("", 0) == (None, 0)

# Generated at 2022-06-22 06:19:51.787540
# Unit test for function tokenize_json
def test_tokenize_json():
    class JSONValidator(Schema):
        name = String()
        age = Integer()

    json_content = '{"name":"Ravi", "age": 26}'
    token = tokenize_json(json_content)
    assert isinstance(token, DictToken)
    assert len(token.data) == 2


# Generated at 2022-06-22 06:20:04.666107
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"cat_name": "Kitty"}') == {'cat_name': 'Kitty'}


# Generated at 2022-06-22 06:20:13.896632
# Unit test for function tokenize_json
def test_tokenize_json():
    try:
        tokenize_json("")
    except ParseError as err:
        assert err.code == "no_content"
        assert err.text == "No content."
        assert err.position.column_no == 1
        assert err.position.line_no == 1
        assert err.position.char_index == 0

    try:
        tokenize_json("{")
    except ParseError as err:
        assert err.code == "parse_error"
        assert err.text == "Expecting property name enclosed in double quotes."
        assert err.position.column_no == 1
        assert err.position.line_no == 1
        assert err.position.char_index == 1


# Generated at 2022-06-22 06:20:18.579769
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test = '{"test": "test"}'
    JSONDecoder().decode(test)
    # content is named argument in __init__ of _TokenizingDecoder
    content = {}
    _TokenizingDecoder(content=content).__init__()
    _TokenizingDecoder().__init__()



# Generated at 2022-06-22 06:20:30.801992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
{
    "string": "string",
    "int": 1,
    "float": 1.5,
    "list": [
        "list_item"
    ],
    "dict": {
        "dict_key": "dict_value"
    }
}
'''.strip()
    structure = tokenize_json(content)
    assert isinstance(structure, DictToken)
    assert structure.start_index == 0
    assert len(structure.children) == 5

    assert structure.children[0].key_token.value == "string"
    assert structure.children[0].value_token.value == "string"

    assert structure.children[1].key_token.value == "int"
    assert structure.children[1].value_token.value == 1


# Generated at 2022-06-22 06:20:39.505715
# Unit test for function validate_json
def test_validate_json():
    '''Validate that the validate_json function returns the correct error messages.'''
    # Valid file
    with open('test_json_valid.json', 'r') as test_json_valid:
        valid_content = test_json_valid.read()
    valid_value, valid_error_messages = validate_json(valid_content, Field(type=str))
    # The valid file should have no errors
    assert valid_error_messages == []

    # Invalid file with one error
    with open('test_json_invalid.json', 'r') as test_json_invalid:
        invalid_content = test_json_invalid.read()
    _, invalid_error_messages = validate_json(invalid_content, Field(type=str))
    error_message = invalid_error_messages[0]
   

# Generated at 2022-06-22 06:20:40.547636
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None

# Generated at 2022-06-22 06:20:51.643808
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "message": "Hello World",
        "name": "John Smith",
        "count": 1,
        "age": 40,
        "enabled": true,
        "is_staff": false,
        "nested": {
            "foo": "bar",
            "hello": "world",
        }
    }
    """


# Generated at 2022-06-22 06:21:02.607045
# Unit test for function validate_json
def test_validate_json():
    def assert_valid(value, validator, expected):
        assert validate_json(value, validator) == expected

    def assert_invalid(value, validator, expected):
        actual = validate_json(value, validator)
        actual_errors = actual[1]
        assert len(actual_errors) == len(expected)
        for actual_error, expected_error in zip(actual_errors, expected):
            for name in ["line_no", "column_no", "char_index"]:
                assert getattr(actual_error.position, name) == getattr(
                    expected_error.position, name
                )
            assert actual_error.code == expected_error.code
            assert actual_error.text == expected_error.text


# Generated at 2022-06-22 06:21:10.341221
# Unit test for function validate_json
def test_validate_json():
    json_string = '''{
        "array": [1, 2, 3],
        "boolean": true,
        "null": null,
        "number": 123,
        "object": {"a": "b", "c": "d"},
        "string": "Hello World"
    }'''
    from typesystem import Schema
    from typesystem.types import *
    from typesystem.fields import *
    from .test_utils import get_error_messages

    schema = Schema(
        {"array": Array(items=Number()), "boolean": Boolean(), "null": Boolean(),
         "number": Number(), "object": Object({'a': String(), "c": String()}),
         "string": String(max_length=2)}
    )


# Generated at 2022-06-22 06:21:18.980518
# Unit test for function validate_json
def test_validate_json():
    content: typing.Any
    validator: typing.Any 
    expected_value: typing.Any
    expected_error_messages: typing.Any
    value: typing.Any
    error_messages: typing.Any

    content = b'["hello", "world"]'
    validator = typing.List[str]
    expected_value = ["hello", "world"]
    expected_error_messages = []
    (value, error_messages) = validate_json(content, validator)
    assert value == expected_value and error_messages == expected_error_messages

# Generated at 2022-06-22 06:21:33.304266
# Unit test for function validate_json
def test_validate_json():
    json_to_validate = """\
        {
            "username": "x",
            "password": "x",
            "email": "x",
            "first_name": "x",
            "last_name": "x",
            "address1": "x",
            "address2": "x",
            "city": "x",
            "state": "x",
            "zip_code": "x",
            "country": "UAE"
        }
        """
    try:
        # If everything goes well this should return a tuple of (value, None)
        value, errors = validate_json(json_to_validate, User)
    except ValidationError as exc:
        # If there are errors, those will be returned in a tuple (None, error_messages)
        errors = exc.messages



# Generated at 2022-06-22 06:21:44.078399
# Unit test for function validate_json
def test_validate_json():
    import json

    class ExampleSchema(Schema):
        field1 = Field(int)
        field2 = Field(float)
        field3 = Field(bool)

    s = ExampleSchema()
    data = {
        "field1": 10,
        "field2": 1.5,
        "field3": False,
    }

    assert s.validate_json(json.dumps(data)) == (data, [])

    data = {"field1": 10, "field3": False}

# Generated at 2022-06-22 06:21:47.050789
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder(content="{}")
    assert hasattr(d, 'scan_once')


# Generated at 2022-06-22 06:21:57.921529
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({"name": str})
    value, messages = validate_json(b'{"name": "bar"}', validator=schema)
    assert value == {"name": "bar"}
    assert messages == []

    _, messages = validate_json(b'{"name": "bar"}', validator=str)
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "type_error"
    assert message.position.line_no == 1
    assert message.position.column_no == 1
    assert message.position.char_index == 0
    assert message.text == "Expected str but got {..."

    _, messages = validate_json(b"", validator=str)
    assert len(messages) == 1
    message = messages[0]

# Generated at 2022-06-22 06:22:09.612493
# Unit test for function tokenize_json
def test_tokenize_json():
    def test_json(json_string, expected_result):
        token = tokenize_json(json_string)
        assert token == expected_result, "JSON string parsing failed"

    test_json("{}", DictToken({}, 0, 1, "{}"))

# Generated at 2022-06-22 06:22:18.648381
# Unit test for function tokenize_json
def test_tokenize_json():
    expected = ListToken(
        value=[
            ScalarToken(value=1.0, start=3, end=4, content='[1.0]'),
            ScalarToken(value=2.0, start=7, end=8, content='[1.0, 2.0]'),
        ],
        start=0, end=11, content='[1.0, 2.0]',
    )
    assert tokenize_json('[1.0, 2.0]') == expected


# Unit tests for function validate_json


# Generated at 2022-06-22 06:22:29.044506
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"key":"val"}'
    token = tokenize_json(json_str)
    assert str(token) == json_str

    json_str = '{"key":[1,2]}'
    token = tokenize_json(json_str)
    assert str(token) == json_str

    json_str = '{"key":{}}'
    token = tokenize_json(json_str)
    assert str(token) == json_str

    json_str = '{"key":{}, "key2":{}}'
    token = tokenize_json(json_str)
    assert str(token) == json_str

    json_str = '[1,2]'
    token = tokenize_json(json_str)
    assert str(token) == json_str


# Generated at 2022-06-22 06:22:41.313436
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"text": "123", "value": 45}', {"text": "string", "value": "integer"}) == ({'text': '123', 'value': 45}, None)
    assert validate_json('{"text": "123", "value": "45"}', {"text": "string", "value": "integer"}) == (None, [{'text': 'string', 'value': 'integer'}])
    assert len(validate_json('{"text": 123, "value": "45"}', {"text": "string", "value": "integer"})[1][0]["text"]) == 2
    assert validate_json('{"text": 123, "value": "45"}', {"text": "string"})[0] == {'text': '123'}

# Generated at 2022-06-22 06:22:46.224436
# Unit test for function validate_json
def test_validate_json():
    from .base import serialize_token
    from .examples import ExampleSchema
    from .fixtures import EXAMPLE_INSTANCE

    token = tokenize_json(EXAMPLE_INSTANCE)
    value, messages = validate_json(EXAMPLE_INSTANCE, validator=ExampleSchema)

    serialized_value = serialize_token(token)
    assert len(messages) == 1



# Generated at 2022-06-22 06:22:56.040019
# Unit test for function validate_json
def test_validate_json():
    field_type_text = """
        {
            "type": "object",
            "title": "Type Info",
            "properties": {
                "type": {
                    "type": "string"
                },
                "id": {
                    "type": "string"
                },
                "properties": {
                    "type": "object",
                    "patternProperties": {
                        "^[a-zA-Z0-9_]+$": {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "id": {
                                    "type": "string"
                                }
                            }
                        }
                    }
                }
            }
        }
    """


# Generated at 2022-06-22 06:23:11.670887
# Unit test for function validate_json
def test_validate_json():
  from typesystem import String
  #Successful validation
  assert validate_json('{"age": "24"}', String()) == ('{"age": "24"}', [])

  # Type mismatch

# Generated at 2022-06-22 06:23:23.038556
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"f1":1,"f2":"2","f3":true,"f4":null}')

# Generated at 2022-06-22 06:23:30.339271
# Unit test for function validate_json
def test_validate_json():
    content = b'{"fname":"aditya", "lname":"sridharan","age": 34, "languages_known": ["English", "Tamil"]}'
    schema = Schema.define(
        {
            "fname": str,
            "lname": str,
            "age": int,
            "languages_known": [str],
        }
    )
    value, error_messages = validate_json(content, schema)
    assert len(error_messages) == 0
    assert value == {'fname': 'aditya', 'lname': 'sridharan', 'age': 34, 'languages_known': ['English', 'Tamil']}


# Generated at 2022-06-22 06:23:38.402616
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == {'hello': 'world'}
    assert tokenize_json('{"hello" : "world"}') == {'hello': 'world'}
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]
    assert tokenize_json('[{"hello": "world"}, 2, 3]') == [{'hello': 'world'}, 2, 3]
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]



# Generated at 2022-06-22 06:23:41.423025
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Given
    decoder = _TokenizingDecoder(content="abc")
    
    # When
    scan_once = decoder.scan_once

    # Then
    assert scan_once is not None

# Generated at 2022-06-22 06:23:42.567509
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:23:46.745539
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    A unit testing for tokenize_json function
    """
    td = open('test_data.json', 'r')
    test_data = td.read()
    test_token = tokenize_json(test_data)
    assert test_token.name == "object"
    assert test_token.lhs.name == "integer"
    td.close()


# Generated at 2022-06-22 06:23:56.459387
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test of test_tokenize_json
    content = '[{"id": 1, "name": "Pepe"}]'
    decoder = _TokenizingDecoder(content=content)
    try:
        token = decoder.decode(content)
    except JSONDecodeError as exc:
        # Handle cases that result in a JSON parse error.
        position = Position(column_no=exc.colno, line_no=exc.lineno, char_index=exc.pos)
        raise ParseError(text=exc.msg + ".", code="parse_error", position=position)
    assert type(token) is ListToken



# Generated at 2022-06-22 06:23:59.153895
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")



# Generated at 2022-06-22 06:24:01.381150
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content=""),_TokenizingDecoder)

# Generated at 2022-06-22 06:24:09.745608
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "test_content"
    token_decoder = _TokenizingDecoder(content=test_content)
    assert token_decoder.content == test_content

# Generated at 2022-06-22 06:24:12.330655
# Unit test for function tokenize_json
def test_tokenize_json():
    input = '{"message": "hello"}'
    assert isinstance(tokenize_json(input), DictToken)


# Generated at 2022-06-22 06:24:24.943994
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that the tokenizing decoder can handle empty strings with useful
    # error messages. In practice empty strings are expected, so we want to be
    # clear about the specific error.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."
    assert excinfo.value.position == Position(column_no=1, line_no=1, char_index=0)

    with pytest.raises(ParseError) as excinfo:
        tokenize_json("   ")
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."

# Generated at 2022-06-22 06:24:34.388063
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b"{}", {"name": "string"}) == ({}, [])
    assert validate_json(b'{"name": "Bob"}', {"name": "string"}) == ({"name": "Bob"}, [])
    assert validate_json(b'{"name": 42}', {"name": "string"}) == ({}, [ValidationError(
            message=Message(text="String required.", code="type_error", position=Position(column_no=9, line_no=1, char_index=10)),
            validator="type_error",
            value=42,
            path=[],
        )])

# Generated at 2022-06-22 06:24:36.762588
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "")
    assert decoder.scan_once.__closure__[1].cell_contents == {}

# Generated at 2022-06-22 06:24:48.453653
# Unit test for function validate_json
def test_validate_json():
    import math
    import json
    import json
    import os
    import math

    schema = Schema.from_dict({"a": int, "b": {"c": float}})
    json_str = json.dumps(
        {
            "a": 1,
            "b": {
                "c": 1.7976931348623157e+308,
            },
        }
    )
    token = tokenize_json(json_str)
    (a, error_messages) = validate_with_positions(token, schema)
    assert not error_messages["a"]
    assert error_messages["a:b:c"][0].code == "too_large"

# Generated at 2022-06-22 06:24:53.075728
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": 1}'
    validator = Schema.of({
        "a": fields.Int()
    })
    assert validate_json(content, validator) == ({"a": 1}, [])

# Generated at 2022-06-22 06:25:04.933332
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"x": 1, "y": [1, 2, 3]}')
    assert isinstance(token, DictToken) and isinstance(token.value, dict)

# Generated at 2022-06-22 06:25:08.760159
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '"string"'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once('"string"', 0) == ('string', 10)



# Generated at 2022-06-22 06:25:19.302606
# Unit test for function tokenize_json
def test_tokenize_json():
    # Normal Case
    content = {"key1":"joe","key2":22,"key3":23.8,"key4":[19,20,21,22]}
    assert(tokenize_json(json.dumps(content)) == DictToken(content, 0, 48, str(content)))

    # Empty JSON
    assert(tokenize_json('') == DictToken({}, 0, 0, ''))

    # Not valid JSON
    content = "NonValidJSON"
    with pytest.raises(ParseError):
        tokenize_json(content)

    # JSON is valid, but not valid schema
    content = {"key1":"joe","key2":22,"key3":23.8,"key4":[19,20,21,22,22.78]}
    with pytest.raises(ValidationError):
        validate

# Generated at 2022-06-22 06:25:26.939954
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = b'"Hello World!"'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-22 06:25:30.513540
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content ='{"name": "test"}'
    decoder = _TokenizingDecoder(content = content)
    assert decoder.scan_once == _make_scanner(decoder, content)


# Generated at 2022-06-22 06:25:43.894568
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON
    token1 = tokenize_json('{"foo": 2, "bar": [true, false, null], "baz": "Hello world!"}')
    assert type(token1) == DictToken
    assert token1.value["foo"] == ScalarToken('2', 7, 8, '{"foo": 2, "bar": [true, false, null], "baz": "Hello world!"}')

# Generated at 2022-06-22 06:25:53.055722
# Unit test for function validate_json
def test_validate_json():
    """Simple test for validate_json().
    Note that it is not exhaustive because validate_json() is a wrapper
    around all the classes in this module.
    """
    from typesystem import String
    from typesystem.tokenize import tokenize_json
    from typesystem.tokenize.positional_validation import validate_with_positions

    good_json = '{"one": 1, "two": "2"}'
    bad_json = '{"one": 1, "two" 2}'
    # Tokenize good JSON
    token = tokenize_json(good_json)
    # Validate good JSON
    value, errors = validate_with_positions(token = token, validator = String())

    # There should be no errors
    assert len(errors["error"]) == 0
    assert len(errors["warning"]) == 0
   

# Generated at 2022-06-22 06:25:55.966390
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.content == "test"


# Generated at 2022-06-22 06:26:05.514285
# Unit test for function tokenize_json
def test_tokenize_json():
    ##############
    # single value

    # string
    assert tokenize_json('"hello"') == ScalarToken(value="hello", start=0, end=7, content='"hello"')

    # integer
    assert tokenize_json('2') == ScalarToken(value=2, start=0, end=1, content='2')

    # float
    assert tokenize_json('3.0') == ScalarToken(value=3.0, start=0, end=3, content='3.0')

    # boolean
    assert tokenize_json('true') == ScalarToken(value=True, start=0, end=4, content='true')

    # null
    assert tokenize_json('null') == ScalarToken(value=None, start=0, end=4, content='null')

    #########

# Generated at 2022-06-22 06:26:17.212580
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": "b"}'
    decoder = _TokenizingDecoder(content=content)
    assert(decoder.scan_once("{", 0)[0].value == {"a"})
    assert(decoder.scan_once("[", 0)[0].value == [])
    assert(decoder.scan_once("null", 0)[0].value == None)
    assert(decoder.scan_once("true", 0)[0].value == True)
    assert(decoder.scan_once("false", 0)[0].value == False)
    assert(decoder.scan_once("123", 0)[0].value == 123)
    assert(decoder.scan_once("123.456", 0)[0].value == 123.456)

# Unit tests for function: tokenize_json

# Generated at 2022-06-22 06:26:19.941740
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder()
    assert d.scan_once != None


# Generated at 2022-06-22 06:26:28.197733
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # python -B -m unittest tests/test_tokenize.py -v

    # Arrange
    # Act
    decoder = _TokenizingDecoder()

    # Assert
    assert decoder._scan_once is not None
    assert decoder.parse_array is not None
    assert decoder.parse_float is not None
    assert decoder.parse_int is not None
    assert decoder.parse_object is not None
    assert decoder.parse_string is not None
    assert decoder.strict is not None


# Generated at 2022-06-22 06:26:40.686696
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "str": "str",
        "int": 42,
        "float": 3.14,
        "bool": true,
        "null": null,
        "array": [1, 2, 3],
        "dict": {"key": "val"},
        "empty": {}
    }
    """

    token = tokenize_json(content)

    assert isinstance(token, DictToken)
    assert isinstance(token["str"], ScalarToken)
    assert token["str"].value == "str"
    assert token["str"].position == Position(
        column_no=18, line_no=2, char_index=17
    )

    assert isinstance(token["int"], ScalarToken)
    assert token["int"].value == 42

# Generated at 2022-06-22 06:26:56.611114
# Unit test for function validate_json
def test_validate_json():
    schema_class = Schema.define({"name": str, "age": int})
    validator = schema_class()

    value, errors = validate_json(
        """
    {
        "name": "Francis",
        "age": 15
    }
    """,
        validator,
    )
    assert not errors
    assert value == {"name": "Francis", "age": 15}

    value, errors = validate_json(
        """
    {
        "name": "Francis",
        "age": "15"
    }
    """,
        validator,
    )
    assert [e.code for e in errors] == ["invalid_type"]


# Generated at 2022-06-22 06:27:01.654384
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1, "b": [1, 2, 3], "c": {"d": "hello"}}') == {
        'a': 1,
        'b': [1, 2, 3],
        'c': {'d': "hello"},
    }



# Generated at 2022-06-22 06:27:08.721553
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={"a": int, "b": int})
    values, errors = validate_json(content='{"a": 1, "b": "two"}', validator=schema)
    assert values == {"a": 1, "b": "two"}
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "invalid_type"
    assert error.position.line_no == 1
    assert error.position.column_no == 12
    assert error.position.char_index == 11
    assert error.text == "Expected int."


# Generated at 2022-06-22 06:27:12.632653
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"test": "tokenizing JSON decoder"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0) is not None



# Generated at 2022-06-22 06:27:13.271869
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="{}")

# Generated at 2022-06-22 06:27:15.652871
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("string")
    assert decoder.scan_once("string", 0) == (ScalarToken("string", 0, 6), 7)


# Generated at 2022-06-22 06:27:25.752409
# Unit test for function validate_json
def test_validate_json():
    content = b'{"attr1":1,"attr2":3.14,"attr3":"some text","attr4":null,"attr5":true,"attr6":{"attr1":"some text"},"attr7":[1,2,3],"attr8":{"attr1":1, "attr2":"some text"},"attr9":[[1,2], [3,4]]}'
    class TestSchema(Schema):
        attr1 = fields.IntegerField()
        attr2 = fields.FloatField()
        attr3 = fields.StringField()
        attr4 = fields.NullField()
        attr5 = fields.BooleanField()
        attr6 = fields.DictField(fields.StringField("attr1"))
        attr7 = fields.ListField(fields.IntegerField())

# Generated at 2022-06-22 06:27:33.809747
# Unit test for function validate_json
def test_validate_json():
    class CatSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    json_str = '{"name": "fish", "age": "not an int"}'
    value, errors = validate_json(json_str, CatSchema)
    assert value == {"name": "fish", "age": "not an int"}
    assert errors == [
        ValidationError(
            text="Not a valid integer.",
            code="type_error.integer",
            position=Position(column_no=21, char_index=20, line_no=1),
        )
    ]

# Generated at 2022-06-22 06:27:46.240106
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:27:51.642542
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"Hello"') == ScalarToken("Hello", 0, 6, '"Hello"')
    assert tokenize_json('2') == ScalarToken(2, 0, 1, '2')
    assert tokenize_json("true") == ScalarToken(True, 0, 4, 'true')
    assert tokenize_json('{"a": "b"}') == DictToken(
        {ScalarToken("a", 1, 3, '"a"'): ScalarToken("b", 6, 8, '"b"')}, 0, 10, '{"a": "b"}'
    )

    # Handle incomplete json strings
    with pytest.raises(ParseError):
        tokenize_json("{")
    with pytest.raises(ParseError):
        tokenize_json("[1, 2")

# Generated at 2022-06-22 06:28:01.732975
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        from unittest.mock import MagicMock
    except ImportError:  # pragma: no cover: Python < 3.3
        from mock import MagicMock
    decoder = _TokenizingDecoder(MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock())
    assert decoder.scan_once() is not None

# Generated at 2022-06-22 06:28:07.578082
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:28:18.058928
# Unit test for function validate_json
def test_validate_json():
    # pylint: disable=line-too-long
    class PointSchema(Schema):
        lat = fields.Float(required=True)
        long = fields.Float(required=True)

    valid_json_string = '{"lat": -32.34568, "long": 153.345567}'
    valid_point, valid_point_errors = validate_json(
        valid_json_string, validator=PointSchema
    )
    assert valid_point == {"lat": -32.34568, "long": 153.345567}
    assert valid_point_errors == {}

    invalid_json_string = '{"lat": "32.3456BAD", "long": "153.345567"}'