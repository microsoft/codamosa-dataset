

# Generated at 2022-06-22 06:18:55.659013
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        decoder = _TokenizingDecoder("{}")
    except Exception as e:
        assert(False)
        
    try:
        decoder = _TokenizingDecoder("{ }")
    except Exception as e:
        assert(False)
        
    try:
        decoder = _TokenizingDecoder(" {} ")
    except Exception as e:
        assert(False)
        
    try:
        decoder = _TokenizingDecoder("{\"a\" : \"1\"}")
    except Exception as e:
        assert(False)
        
    try:
        decoder = _TokenizingDecoder("{\"a\" : [1, \"2\"]}")
    except Exception as e:
        assert(False)
        

# Generated at 2022-06-22 06:19:03.023684
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    content = " { \"key\" : \"value\" } "
    decoder = _TokenizingDecoder(content=content)
    dict_token, _ = decoder.scan_once(content, 0)
    assert dict_token.to_python() == json.loads(content)
    assert dict_token.to_python() == {"key": "value"}



# Generated at 2022-06-22 06:19:04.974548
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    func = lambda : _TokenizingDecoder()
    assert func() == JSONDecoder()

# Generated at 2022-06-22 06:19:15.823791
# Unit test for function validate_json
def test_validate_json():

    from typesystem import Schema, types, fields

    class Example(Schema):
        things = fields.List(fields.Dict({"thing1": fields.String()}))

    test1 = b'{"things": [{"thing1": "abc"}]}'
    test2 = b'{"things": [{"thing1": "abc"}, {"thing1": "def"}]}'
    test3 = b'{"things": [{"thing1": "abc"}]}'
    test4 = b'{"things": [{"thing1": "abc"}, {"thing1": "def"}]}'

    val, errors = validate_json(test1, Example)
    assert len(val)
    assert len(errors) == 0
    assert val['things'][0]['thing1'] == 'abc'


# Generated at 2022-06-22 06:19:19.316629
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder != None
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-22 06:19:24.938923
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    s = '{"title": "Sajjad"}'
    try:
        decoded = JSONDecoder().decode(s)
        assert isinstance(decoded, dict)
        assert decoded["title"] == "Sajjad"
    except JSONDecodeError as exc:
        assert False, str(exc)

    decoded = _TokenizingDecoder().decode(s)
    assert isinstance(decoded, DictToken)
    assert isinstance(decoded["title"], ScalarToken)
    assert decoded["title"].value == "Sajjad"

# Generated at 2022-06-22 06:19:31.364712
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(properties={"foo": "string"})
    assert validate_json(content=b'{"foo":true}', validator=schema) == \
        ({'foo': 'true'}, [{'code': 'invalid_type', 'position': Position(column_no=3, line_no=0, char_index=9), 'text': 'Expected type: string'}])


# Generated at 2022-06-22 06:19:41.619822
# Unit test for function validate_json
def test_validate_json():
    '''
    Testing function validate_json
    '''
    import typesystem
    import pytest
    import json

    json_string = '{"a": 1, "b": "a"}'
    schema = typesystem.Schema(fields={
        'a': typesystem.Integer(),
        'b': typesystem.String()
    })

    value, errors = validate_json(json_string, schema)
    assert value == json.loads(json_string)
    assert errors == []

    json_string = '{"a": 1, "b": "a", "c": "c"}'
    value, errors = validate_json(json_string, schema)
    assert value == json.loads(json_string)

# Generated at 2022-06-22 06:19:53.529541
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"foo":0}', {"foo": int}) == ({'foo': 0}, None)
    assert validate_json(
        '{"foo":"happy"}', {"foo": {"type": "string", "enum": ["sad"]}}
    ) == ({"foo": "happy"}, ["data.foo: Value must be one of: ['sad']."])
    assert validate_json('{"foo":"happy","bar":"sad"}', {"foo": str, "bar": str}) == (
        {"foo": "happy", "bar": "sad"},
        None,
    )

# Generated at 2022-06-22 06:20:03.966383
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """
    {
        "foo": [
            "a",
            1,
            2,
            false
        ]
    }
    """
    token = tokenize_json(json_str)
    assert len(token.contents) == 1
    assert token.contents["foo"].contents[0].value == "a"
    assert token.contents["foo"].contents[3].value == False
    assert token.contents["foo"].contents[3].positions.start_pos.column_no == 14
    assert token.contents["foo"].contents[3].positions.start_pos.line_no == 5



# Generated at 2022-06-22 06:20:16.400181
# Unit test for function tokenize_json
def test_tokenize_json():
    assert [1,2,3] == tokenize_json(b'[1,2,3]')


# Generated at 2022-06-22 06:20:25.646395
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {"name": str, "numbers": [int], "object": {"key": "value"}}
    json_string = """{"name": "Alice", "numbers": [1, 2, 3], "object": {"key": "value"}}"""

    token = tokenize_json(json_string)

    assert isinstance(token, DictToken)
    assert token.value == schema

    # Test validation
    field = Field(type=str)
    value, errors = validate_json(content=b"test", validator=field)
    assert errors == []



# Generated at 2022-06-22 06:20:37.049470
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from typesystem import fields
    from typesystem.schemas import Schema

    class CustomerSchema(Schema):
        name = fields.String(max_length=100)
        address = fields.Dict(
            fields=[
                ("line1", fields.String(max_length=100)),
                ("city", fields.String(max_length=100)),
                ("state", fields.String(min_length=2, max_length=2)),
                ("zip", fields.String(min_length=5, max_length=5)),
            ]
        )


# Generated at 2022-06-22 06:20:49.167010
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = """{"Hello": "World"}"""
    decoder = _TokenizingDecoder(content=content)
    assert decoder.strict == True
    assert decoder.parse_string == scanstring
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_object == object_pairs_hook
    assert decoder.parse_array == JSONArray
    assert decoder.memo == {}
    assert decoder.scan_once("""{"Hello": "World"}""", 0) == (
        DictToken({ScalarToken("Hello", 1, 7, content): ScalarToken("World", 10, 17, content)}, 0, 18, content),
        19,
    )

# Unit tests for JSONDecoder

# Generated at 2022-06-22 06:20:52.587531
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once == _make_scanner(decoder, content)

# Generated at 2022-06-22 06:21:03.298028
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert (
        tokenize_json(
            """
    [
    1,
    2,
    3
    ]
    """
        )
        == ListToken([ScalarToken(1, 7, 8, "[\n1,\n2,\n3\n]\n"), ScalarToken(2, 13, 14, "[\n1,\n2,\n3\n]\n"), ScalarToken(3, 19, 20, "[\n1,\n2,\n3\n]\n")], 0, 22, "[\n1,\n2,\n3\n]\n")
    )

# Generated at 2022-06-22 06:21:04.610980
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("{}")



# Generated at 2022-06-22 06:21:08.724468
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_string = "{\"json\":\"value\"}"
    token, error = validate_json(json_string, Field(name="json"))
    assert error is None, "validate_json failed"
    assert token is not None, "token not created"

# Generated at 2022-06-22 06:21:10.563707
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('1', int) == (1, [])



# Generated at 2022-06-22 06:21:16.833014
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def test(root: Token, error_list: typing.List[ValidationError]):
        assert len(error_list) == 0

    content = """{"foo": [1, 2, 3, 4]}"""
    token = tokenize_json(content)

    validator = Schema(
        {"foo": Field(list, items=Field(int))}
    )
    value, errors = validate_json(content, validator)
    test(token, errors)

    content = """{"foo": [1, "2", 3, 4]}"""
    token = tokenize_json(content)
    value, errors = validate_json(content, validator)
    assert len(errors) == 1 and isinstance(errors[0].position, Position)

# Generated at 2022-06-22 06:21:35.540830
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Field(name="string", type="string")
    validator = schema.validate_json
    content = b"""
        {
            "string": "test"
        }
        """
    json = tokenize_json(content)
    with pytest.raises(ParseError):
        content = b''
        json = tokenize_json(content)



# Generated at 2022-06-22 06:21:46.947427
# Unit test for function validate_json
def test_validate_json():
    from typesystem import parse, validators

    content = b'{"a": [1, 2, 3], "b": "foo"}'
    try:
        # validate against expected content
        validator = parse("a: int; b: string")
    except ValidationError as err:
        # handle typingsystem parse errors
        raise
    except Exception:
        # handle unexpected exceptions
        raise
    else:
        value, errors = validate_json(content, validator)

    print(value)
    assert errors == []

    content = b'{"a": [1, "b", 3], "b": "foo"}'
    try:
        # validate against expected content
        validator = parse("a: int; b: string")
    except ValidationError as err:
        # handle typingsystem parse errors
        raise

# Generated at 2022-06-22 06:21:57.920832
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.base import get_children

    # Test empty string.
    with pytest.raises(ParseError):
        tokenize_json("")

    # Test simple JSON.
    token = tokenize_json("{\"a\": 1}")
    assert token.get_token_type() == DictToken
    children = get_children(token)
    assert len(children) == 1
    token_a = children[0]
    assert token_a[0].get_token_type() == ScalarToken
    value = token_a[0].get_value()
    assert value == "a"
    assert token_a[1].get_token_type() == ScalarToken
    value = token_a[1].get_value()
    assert value == 1

    # Test bad JSON.

# Generated at 2022-06-22 06:22:08.019809
# Unit test for function validate_json
def test_validate_json():
    content = '{"field1": "string", "field2": 3, "field3": {"inner1": 5}}'
    validator = Schema(properties={
        "field1": Field(type="string"),
        "field2": Field(type="number"),
        "field3": Schema(properties={
            "inner1": Field(type="string")
        })
    })
    value, error_messages = validate_json(content=content, validator=validator)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Value of field 'field3.inner1' is not of type 'string'."


# Generated at 2022-06-22 06:22:20.552210
# Unit test for function validate_json
def test_validate_json():
    # content = '{"name": "value"}'
    content = '{"name": "value", "name2": "value2", "name3": "value3"}'
    # content = '{'
    # content = '"name": "value"'
    # content = '{"name": "value", "name2": "value2", "name3": "'
    # content = '"name": "value", "name2": "value2", "name3": "value3",'
    content = """
{
    "name": "value",
    "name2": "value2",
    "name3": "value3",
    "name4": "value4"
}
"""

    class TestSchema(Schema):
        name = Field(type="string")

    validator = TestSchema()
    value, error_mess

# Generated at 2022-06-22 06:22:22.581979
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content=None)


# Unit tests for constructor of class JSONDecoder

# Generated at 2022-06-22 06:22:32.642750
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_token = tokenize_json('{"a": 1, "b": [2, "3"]}')
    assert isinstance(dict_token, DictToken)
    assert len(dict_token.value) == 2
    assert "a" in dict_token.value
    assert "b" in dict_token.value
    assert isinstance(dict_token.value["a"], ScalarToken)
    assert isinstance(dict_token.value["b"], ListToken)
    assert len(dict_token.value["b"].value) == 2
    assert isinstance(dict_token.value["b"].value[0], ScalarToken)
    assert isinstance(dict_token.value["b"].value[1], ScalarToken)

    # Empty string

# Generated at 2022-06-22 06:22:43.937408
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken

    content = '{"harry": 1, "potter": ["a", 1.1, true]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert isinstance(token.value["harry"], ScalarToken)
    assert token.value["harry"].value == 1
    assert isinstance(token.value["potter"], ListToken)
    assert len(token.value["potter"].value) == 3
    assert isinstance(token.value["potter"].value[0], ScalarToken)

# Generated at 2022-06-22 06:22:54.582529
# Unit test for function validate_json
def test_validate_json():
    # Import get_price_data so that the file will be cached by the function
    from importlib import import_module
    import_module("fundamentals_analyzer.parse_data_files.get_price_data")
    from fundamentals_analyzer.parse_data_files.get_price_data import (
        PriceData,
    )

    # Initialize PriceData
    value = PriceData()

    # Test for empty string
    content = ""
    values, errors = validate_json(content, value)
    assert type(errors) == ValidationError
    assert errors.position.line_no == 1
    assert errors.position.column_no == 1
    assert errors.position.char_index == 0
    assert errors.text == "No content."
    assert errors.code == "no_content"

    # Test for invalid price data

# Generated at 2022-06-22 06:22:59.246770
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    source = '{"key1": "value1", "key2": "value2"}'
    decoder = _TokenizingDecoder(object_pairs_hook=OrderedDict, content=source)
    assert decoder.scan_once(source, 6)[1] == 8
    assert decoder.scan_once(source, 8)[1] == 18


# Generated at 2022-06-22 06:23:15.063602
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Verifies that the tokenize_json function can convert a simple JSON
    string into a token
    """
    content = '{"test":3}'
    obj = {"test":3}

    # Verify that a simple JSON string returns an expected token
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.children[0], ScalarToken)
    assert isinstance(token.children[1], ScalarToken)
    assert token.children[0].value == "test"
    assert token.children[1].value == 3
    assert token.value == obj

    # Verify that an empty string results in a ParseError
    exception = None
    try:
        tokenize_json("")
    except Exception as exc:
        exception = exc

# Generated at 2022-06-22 06:23:17.641025
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.json import _TokenizingDecoder
    import types
    assert _TokenizingDecoder is not None
    assert isinstance(_TokenizingDecoder, types.BuiltinFunctionType)


# Unit tests for method _make_scanner

# Generated at 2022-06-22 06:23:25.236909
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = r"""
        {
            "name": "John Smith",
            "age": 25,
            "address": {
                "street": "123 Fake Street",
                "zip": 12345,
                "state": "New York"
            }
        }
    """
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, _TokenizingDecoder)



# Generated at 2022-06-22 06:23:29.537573
# Unit test for function validate_json
def test_validate_json():
    message_list = []
    good_json = "{\"number\":42}"

    schema = Field(validate=lambda value: {"code": "required_field"}, name="number")

    message_list = validate_json(good_json, schema)
    assert message_list[1][0].code == "required_field"

# Generated at 2022-06-22 06:23:38.962057
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="integer")
    parsed, errors = validate_json(b"3", field)
    assert parsed == 3
    assert not errors

    parsed, errors = validate_json(b"not_an_integer", field)
    assert not parsed
    assert len(errors) == 1
    error = errors[0]
    assert error.text == "Value is not valid."
    assert error.code == "invalid"
    assert error.position.line_no == 1
    assert error.position.column_no == 1
    assert error.position.char_index == 0

# Generated at 2022-06-22 06:23:45.435231
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2.0}')
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.value == {'a': 1, 'b': 2.0}

    token = tokenize_json('[1, 2.0, "a"]')
    assert isinstance(token, Token)
    assert isinstance(token, ListToken)
    assert token.value == [1, 2.0, "a"]


# Generated at 2022-06-22 06:23:46.781559
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert (_TokenizingDecoder is not None)

# Generated at 2022-06-22 06:23:59.296025
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:00.077482
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(isinstance(_TokenizingDecoder(content='abc'), _TokenizingDecoder))


# Generated at 2022-06-22 06:24:02.077203
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None


# Generated at 2022-06-22 06:24:16.418361
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:27.037399
# Unit test for function validate_json
def test_validate_json():
    value_and_error_messages = validate_json(
        '{"foo": {"bar": "baz"}, "qux": 1}',
        Schema({"foo": {"bar": str}, "qux": int}),
    )
    value, error_messages = value_and_error_messages
    assert value == {"foo": {"bar": "baz"}, "qux": 1}
    assert not error_messages

    # Test with ParseError
    with pytest.raises(ParseError) as excinfo:
        validate_json('{"foo", 1}', Schema())
    assert excinfo.value.text == "Expecting property name enclosed in double quotes."
    assert excinfo.value.position.column_no == 7
    assert excinfo.value.position.line_no == 1

# Generated at 2022-06-22 06:24:38.717010
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(value=None, start=0, end=3, raw="null")
    assert tokenize_json("true") == ScalarToken(value=True, start=0, end=3, raw="true")
    assert tokenize_json('"hello"') == ScalarToken(value="hello", start=0, end=6, raw='"hello"')
    assert tokenize_json("12") == ScalarToken(value=12, start=0, end=1, raw="12")
    assert tokenize_json("2.33") == ScalarToken(value=2.33, start=0, end=3, raw="2.33")

# Generated at 2022-06-22 06:24:49.218527
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # This is the internal function that is created for the JSONDecoder() class
    # It is called by TokenizingJSONObject() from the cpython source
    # The second argument of scan_once is start index of first character
    # of the input string to be read.
    def scan_once(s, idx):
        assert(s[idx] == '"')
        end = s.find('"', idx + 1)
        assert (end > 0)
        str = s[idx + 1:end]
        return str, end + 1

    root = '{"a":"b", "c": "d", "e": "f"}'
    content = "root"
    obj = _TokenizingDecoder(content=content)
    obj.scan_once = scan_once

# Generated at 2022-06-22 06:25:01.032521
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("123") == ScalarToken(123, 0, 2, "123")
    assert tokenize_json('"abc"') == ScalarToken("abc", 1, 4, '"abc"')
    assert tokenize_json("0.123") == ScalarToken(0.123, 0, 5, "0.123")
    assert tokenize_json("0.123e1") == ScalarToken(0.123e1, 0, 6, "0.123e1")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")

# Generated at 2022-06-22 06:25:02.555515
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert isinstance(decoder, _TokenizingDecoder)


# Generated at 2022-06-22 06:25:04.528168
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None


# Generated at 2022-06-22 06:25:16.627777
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, errors = validate_json(b"hello", validator)
    assert value == "hello"
    assert not errors

    value, errors = validate_json(b"123", validator)
    assert value == 123
    assert not errors

    value, errors = validate_json(b'true', validator)
    assert value == True
    assert not errors

    value, errors = validate_json(b'[1, 2, 3]', validator)
    assert value == [1, 2, 3]
    assert not errors

    value, errors = validate_json(b'{"name": "Hello"}', validator)
    assert value == {"name": "Hello"}
    assert not errors

    value, errors = validate_json('{"name": "Hello"}', validator)

# Generated at 2022-06-22 06:25:18.898279
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='i am the content')
    return decoder


# Generated at 2022-06-22 06:25:24.402411
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, DateTime, Array
    import datetime
    import json

    class MySchema(Schema):
        name = String()
        age = Integer(minimum=13, maximum=99)
        birthday = DateTime()
        kids = Array(items=Integer())

    schema = MySchema()
    data = {
        "name": "Joe",
        "age": "forty-two",
        "birthday": "2016-01-01T01:23:45+10:00",
        "kids": [12, "thirteen", 14],
    }
    data_json = json.dumps(data)
    data_token = tokenize_json(data_json)
    error_messages = []
    value

# Generated at 2022-06-22 06:25:32.570025
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class Test:
        def __init__(self, *args: typing.Any, **kwargs: typing.Any):
            self.args = args
            self.kwargs = kwargs
    
    jd = _TokenizingDecoder(object_hook=Test, parse_constant=Test, parse_float=Test, parse_int=Test, parse_string=Test, strict=True, 
                            object_pairs_hook=Test, content="content")
    assert jd.object_hook == Test
    assert jd.parse_constant == Test
    assert jd.parse_float == Test
    assert jd.parse_int == Test
    assert jd.parse_string == Test
    assert jd.strict == True
    assert jd.object_pairs_hook == Test

# Generated at 2022-06-22 06:25:34.288132
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = _TokenizingDecoder()
    assert(a)


# Generated at 2022-06-22 06:25:39.522264
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, errors = validate_json(b"""
    {
        "foo": 1
    }
    """, validator)
    assert value is None
    assert isinstance(errors, (list,))
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-22 06:25:48.757589
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.schemas import Schema, init_schema
    from typesystem.fields import Text
    from typesystem import validate_json

    class Customer(Schema):
        first_name = Text()
        last_name = Text()
    
    init_schema(Customer)

    data = {"first_name": "John", "last_name": "Doe"}
    json_data = json.dumps(data)
    
    value, error_messages = validate_json(json_data, Customer)
    assert not error_messages
    assert value == data

# Generated at 2022-06-22 06:25:54.558384
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    Test for constructor of class _TokenizingDecoder.
    """
    # Arrange
    content_proper = "{"
    args = ["content"]
    kwargs = {"content": content_proper}
    # Act
    _TokenizingDecoder(*args, **kwargs)
    # Assert



# Generated at 2022-06-22 06:25:57.078538
# Unit test for function tokenize_json
def test_tokenize_json():
    input_data = open("test.json", "r").read()
    print(tokenize_json(input_data))


# Generated at 2022-06-22 06:25:59.805845
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    t = _TokenizingDecoder(content="Hello world")
    assert t.scan_once("Hello world", 0) == (None, 11)


# Generated at 2022-06-22 06:26:11.397772
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test invalid JSON with an explicit error message.
    content = """{ "invalid" }"""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert (
            exc.text
            == 'Expecting value: line 1 column 12 (char 12), line 1 column 12 (char 12) "invalid"'
        )
    else:  # pragma: no cover
        raise AssertionError("Expected exception not raised")

    # Test invalid JSON with an implicit error message.
    content = ""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
    else:  # pragma: no cover
        raise Ass

# Generated at 2022-06-22 06:26:14.406731
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('[1, 2, 3]')
    assert token == ListToken([1,2,3], 0, 8)



# Generated at 2022-06-22 06:26:17.368124
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer, String

    class MySchema(Schema):
        age = Integer()
        name = String(max_length=4)

    value, errors = validate_json(
        content='{"age":23,"name":"Sally"}', validator=MySchema
    )
    assert errors == []
    assert value == {"age": 23, "name": "Sally"}


# Generated at 2022-06-22 06:26:29.134902
# Unit test for function tokenize_json
def test_tokenize_json():
    input_json = '{"name": "xx", "age": 18}'
    value = tokenize_json(input_json)
    assert isinstance(value, dict)
    assert value["name"] == "xx"
    assert value["age"] == 18

    input_json = '{"name": "xx", "age": "18"}'
    value = tokenize_json(input_json)
    assert isinstance(value, dict)
    assert value["name"] == "xx"
    assert value["age"] == "18"



# Generated at 2022-06-22 06:26:35.250263
# Unit test for function validate_json
def test_validate_json():
    content = '[{"name": "ted","age": 25},{"name": "sally"}]'
    validator = schemas.UserListSchema()
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].attributes[0].code == "required"

# Generated at 2022-06-22 06:26:46.928479
# Unit test for function validate_json
def test_validate_json():
    # Passes validation
    test_data1 = '{"first_name": "Eric", "last_name": "Idle"}'
    retval = validate_json(test_data1, Field())
    assert isinstance(retval, tuple) and len(retval) == 2
    assert retval[0] == {"first_name": "Eric", "last_name": "Idle"}
    assert not retval[1]

    # Fails validation
    test_data2 = '{"first_name": "Eric", "last_name": "Idle", "email": "test@test.test"}'
    retval = validate_json(test_data2, Field())
    assert isinstance(retval, tuple) and len(retval) == 2
    assert not retval[0]

# Generated at 2022-06-22 06:26:55.796713
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid json
    json_string = b'{"a": "b"}' # type: ignore
    result = tokenize_json(json_string)
    assert type(result) == DictToken
    assert result.value == {"a": "b"}
    assert result.start == 0
    assert result.end   == 10
    assert result.content == '{"a": "b"}'

    # Test malformed json
    json_string = b'{"a": "b", ]!' # type: ignore
    try:
        tokenize_json(json_string)
        assert False
    except ParseError as e:
        assert e.position.line_no == 1
        assert e.position.column_no == 14
        assert e.position.char_index == 13
        assert e.code == "parse_error"

# Generated at 2022-06-22 06:27:02.416029
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": 2}')
    assert token.token_type == "dict"
    assert len(token.items) == 2
    assert token.items[0][0].value == "a"
    assert token.items[0][1].token_type == "scalar"
    assert token.items[0][1].value == 1



# Generated at 2022-06-22 06:27:14.600427
# Unit test for function tokenize_json
def test_tokenize_json():
    ## test empty string, should be no content
    content = ''
    try:
        tokenize_json(content)
    except ParseError:
        pass
    else:
        assert False

    ## test empty json string
    content = '{}'
    result = tokenize_json(content)
    assert result == DictToken({}, 0, 1, content)

    ## test json string with multiple key-value pairs
    content = '{"a": "b", "c": "d"}'
    result = tokenize_json(content)

# Generated at 2022-06-22 06:27:19.835560
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json

    content = '{"a": "A", "b": "B"}'
    decoder = _TokenizingDecoder(content=content)

    # check tokenizing JSONDecoder is well initialized
    assert decoder.scan_once is not None and isinstance(decoder.scan_once, type(json.JSONDecoder().scan_once))


# Generated at 2022-06-22 06:27:24.342128
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # For the constructor of class _TokenizingDecoder,
    # we can only test the length of the created object,
    # since the object is an instance of JSONDecoder which
    # is from an external library.
    t = _TokenizingDecoder(content = "")
    assert len(t.__dict__) == 5

# Generated at 2022-06-22 06:27:31.525833
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Force a json parse error so that we can test the position handling.
    content = """
        {
            "boolean": trU
        }
    """

    decoder = _TokenizingDecoder(content=content)

    with pytest.raises(ParseError) as excinfo:
        decoder.decode(content)

    expected = """
        parse_error:
            - "Unexpected character when looking for JSON property value."
            - line: 3
            - column: 15
        """

    assert expected.strip() == str(excinfo.value).strip()

# Generated at 2022-06-22 06:27:44.393214
# Unit test for function validate_json
def test_validate_json():
    _test_validate_json(
        '{"name": "foo", "age": "33"}',
        '{"age": "33", "name": "foo"}',
        '{"name": "foo", "age": 33}',
        '{"name": "foo", "age": 33, "extra": "hello"}',
    )

    _test_validate_json(
        '{"name": "foo", "age": "33"}',
        '{"age": "33", "name": "foo"}',
        '{"name": "foo", "age": 33}',
        '{"name": "foo", "age": 33, "extra": "hello"}',
        type(None),
    )


# Generated at 2022-06-22 06:28:01.806548
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = """
        {
            "name": "test",
            "version": 1,
            "fields": [
                {"name": "int_field", "type": "integer"},
                {"name": "bool_field", "type": "boolean"},
                {"name": "float_field", "type": "float"},
                {"name": "string_field", "type": "string"},
                {"name": "object_field", "type": "object"},
                {"name": "array_field", "type": "array"}
            ]
        }
    """


# Generated at 2022-06-22 06:28:04.359101
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='test')
    assert decoder.scan_once('test', 0) == ScalarToken('test', 0, 3, 'test')


# Generated at 2022-06-22 06:28:08.940495
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import pytest

    class TestClass:
        def __init__(self):
            self.memo = {"a": 1}

        def parse_string(self, string: str, idx: int, strict: bool) -> typing.Any:
            return "abc", idx

        def parse_array(self, string_and_idx: typing.Tuple[str, int], scan_once: typing.Any) -> typing.Any:
            return "def", idx

        def parse_float(self, value: str) -> typing.Any:
            return 1.0

        def parse_int(self, value: str) -> typing.Any:
            return 1


# Generated at 2022-06-22 06:28:19.796654
# Unit test for function validate_json
def test_validate_json():
    # Test JSON code with a bad field name
    json_str_bad_field = '{ "name1" : "John" }'
    try:
        # Parse the JSON with a field name that does not match the schema
        validate_json(json_str_bad_field, PersonSchema())
    except ValidationError as exc:
        message = exc.messages
        # Verify the message has a valid position (i.e. line, column, and character index)
        assert message.position.line_no == 0
        assert message.position.column_no == 2
        assert message.position.char_index == 2
        # Verify error message is that the field is unexpected
        assert message.code == "unexpected_field"
        assert message.text == "Object has unexpected field."

    # Test JSON code with a missing field
    json_