

# Generated at 2022-06-22 06:18:59.083388
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that the "tokenize_json" function correctly tokenizes JSON.
    """
    import datetime
    import decimal

    # Test content parsing with 'tokenize_json'.
    assert tokenize_json('"string"') == ScalarToken("string", 0, 7, '"string"')
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("1.0") == ScalarToken(1.0, 0, 3, "1.0")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")


# Generated at 2022-06-22 06:19:10.873817
# Unit test for function tokenize_json
def test_tokenize_json():
    # Should return DictToken if content is a valid json string
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}

    # Should raise ParseError if content is an invalid json string
    with pytest.raises(ParseError):
        tokenize_json('{"foo": "bar"')

    # Should raise ParseError if content is empty
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('')
    assert 'No content.' in str(excinfo.value)

    token = tokenize_json('{"foo": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": [1, 2, 3]}

# Generated at 2022-06-22 06:19:22.558153
# Unit test for function validate_json
def test_validate_json():
    from json import loads
    from dataclasses import dataclass

    from typesystem.fields import String
    from typesystem.tokenize import tokenize_json

    from .util import Test, assert_equal

    @dataclass
    class TestSchema(Schema):
        name: str = String()

    json_data = b'{"name":"Nikolay"}'
    expected = {
        "name": "Nikolay",
        "context": {
            "type_name": "TestSchema",
            "schema_version": "1.3.0",
        }
    }
    expected_token = tokenize_json(json_data)

    def test_tokenize_json_with_schema_type() -> None:
        token = tokenize_json(json_data)

# Generated at 2022-06-22 06:19:27.363384
# Unit test for function validate_json
def test_validate_json():
    validator = Field(format="uri")
    json = {
        "title": "test",
        "uri": "https://test.test.test"
    }
    errors = validate_json(json, validator)
    assert errors is None
    json["uri"] = "test.test.test"
    errors = validate_json(json, validator)
    assert errors[0]

# Generated at 2022-06-22 06:19:38.753610
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case - incorrect json format
    with pytest.raises(Exception) as e:
        tokenize_json('''
            [
                {
                    "id": 1,
                    "name": "John Doe",
                    "age": "25",
                    "address": "Sidney No. 1 Lake Park"
                },
            ]
            ''')
    assert str(e.value) == "Expecting ',' delimiter"
    assert e.value.msg == "Expecting ',' delimiter"
    assert e.value.lineno == 7
    assert e.value.colno == 1
    assert e.value.pos == 69
    # Test case - empty string
    with pytest.raises(Exception) as e:
        tokenize_json('')
    assert str(e.value) == "No content."

# Generated at 2022-06-22 06:19:40.935290
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": [1, 2, 3]}') == {'a': [1,2,3]}


# Generated at 2022-06-22 06:19:47.820995
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token == DictToken({ScalarToken('foo', 0, 4, content): ScalarToken('bar', 9, 13, content)}, 0, 13, content)

# Generated at 2022-06-22 06:19:50.747412
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()



# Generated at 2022-06-22 06:19:52.300658
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="string")
    assert decoder

# Generated at 2022-06-22 06:20:01.791136
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json() to see if it works correctly.

    Output:
        value = 10
        type(value) = <class 'int'>
        error_messages = ''
    """
    content = "{\"value\": \"10\"}"
    validator = Field(type="integer")
    value, error_messages = validate_json(content, validator)
    print("value = %s\ntype(value) = %s\nerror_messages = %s" % (value, type(value), error_messages))

test_validate_json()

# Generated at 2022-06-22 06:20:17.595545
# Unit test for function validate_json
def test_validate_json():
    json_string = '{"name": "Alice", "age": "20"}'
    Person = Schema(fields={"name": Field(required=True), "age": Field(required=True)})
    value, errors = validate_json(json_string, Person)
    assert len(errors) == 0
    assert value == {"name": "Alice", "age": "20"}
    json_string = '{"name": "Alice"}'
    value, errors = validate_json(json_string, Person)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].detail == "This field is required."
    assert errors[0].position == Position(line_no=1, column_no=12, char_index=11)

# Generated at 2022-06-22 06:20:29.698430
# Unit test for function validate_json
def test_validate_json():
    content = '{"key": "value"}'
    validator = Field(name="key")

    expected_value = {"key": "value"}
    value, error_messages = validate_json(content, validator)
    assert value == expected_value
    assert error_messages == []

    content = '{"key": "value", "key2": "value"}'
    value, error_messages = validate_json(content, validator)
    assert value == expected_value
    assert len(error_messages) == 1
    assert error_messages[0].text == 'Extra fields not permitted.'
    assert error_messages[0].code == 'extra_data'

    content = '{"key": [1, 2, 3]}'
    value, error_messages = validate_json(content, validator)
    assert value

# Generated at 2022-06-22 06:20:41.507475
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": "value"}')
    assert isinstance(token, DictToken)
    assert token.value == {"key": "value"}

    token = tokenize_json('{"key": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert token.value == {"key": [1, 2, 3]}
    
    token = tokenize_json('{"key": false}')
    assert isinstance(token, DictToken)
    assert token.value == {"key": False}

    token = tokenize_json('{"key": null}')
    assert isinstance(token, DictToken)
    assert token.value == {"key": None}

    token = tokenize_json('{"key": 42}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:20:45.456807
# Unit test for function validate_json
def test_validate_json():
    content = '{"hello": "world"}'
    validator = typing.Dict[str, str]
    value, error_messages = validate_json(content, validator)

    assert not error_messages
    assert isinstance(value, typing.Dict)



# Generated at 2022-06-22 06:20:46.524194
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:20:56.785668
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json("[]"), ListToken)
    assert isinstance(tokenize_json('"foo"'), ScalarToken)
    assert isinstance(tokenize_json("false"), ScalarToken)

    decoder = _TokenizingDecoder()
    assert isinstance(decoder.decode("{}"), DictToken)
    assert isinstance(decoder.decode("[]"), ListToken)
    assert isinstance(decoder.decode('"foo"'), ScalarToken)
    assert isinstance(decoder.decode("false"), ScalarToken)



# Generated at 2022-06-22 06:21:05.163762
# Unit test for function tokenize_json
def test_tokenize_json():
    content = (
        '{\n'
        '  "id": "abc-123",\n'
        '  "attributes": {\n'
        '    "name": "foo-bars",\n'
        '    "count": 100\n'
        '  },\n'
        '  "items": [\n'
        '    {\n'
        '      "id": "123-abc",\n'
        '      "name": "baz-batz"\n'
        '    }\n'
        '  ]\n'
        '}\n'
    )
    token = tokenize_json(content)
    assert token.start == 0
    assert token.end == len(content)
    assert token.content == content
    assert isinstance(token, DictToken)
    assert len

# Generated at 2022-06-22 06:21:06.929078
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-22 06:21:14.330726
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        # Tests for constructor of class _TokenizingDecoder with valid values
        decoder = _TokenizingDecoder(object_hook=lambda item: item, content="test")
        assert decoder is not None
    except Exception:
        # Tests for constructor of class _TokenizingDecoder with invalid values
        decoder = _TokenizingDecoder(content=None)
        assert decoder is not None

#Unit test for constructor of class _TokenizingDecoder

# Generated at 2022-06-22 06:21:18.356109
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""{"str": "value", "int": 1, "float": 4.5}""") == {
        "str": "value",
        "int": 1,
        "float": 4.5
    }

# Generated at 2022-06-22 06:21:33.219126
# Unit test for function tokenize_json
def test_tokenize_json():
    token_json_string = tokenize_json(
        b'{"name": {"first": "John", "last": "Doe"}, "age": 42, "is_vegetarian": false}'
    )


# Generated at 2022-06-22 06:21:37.560141
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "key1": "value1", "key2": "value2", '
    content += '"key3": "value3", "key4": "value4" }'
    decoder = _TokenizingDecoder(content=content)


# Generated at 2022-06-22 06:21:48.832724
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name":"luke"}'
    field = Field()
    result = validate_json(content, field)
    assert result == ({'name': 'luke'}, [])
    content = b'{"name":1}'
    field = Field()
    result = validate_json(content, field)
    assert result == (1, [(0, 0, 0), (0, 0, 1)])
    content = b'{"name":true}'
    field = Field()
    result = validate_json(content, field)
    assert result == (True, [(0, 0, 0), (0, 0, 1)])
    content = b'{"name":false}'
    field = Field()
    result = validate_json(content, field)

# Generated at 2022-06-22 06:21:58.589562
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({},0,0,"{}")
    assert tokenize_json("[]") == ListToken([],0,0,"[]")
    assert tokenize_json("1") == ScalarToken(1, 0, 0, "1")
    assert tokenize_json('"hello"') == ScalarToken("hello", 0, 0, '"hello"')
    assert tokenize_json("null") == ScalarToken(None, 0, 0, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 0, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 0, "false")
    assert tokenize_json("1.4") == ScalarToken(1.4, 0, 0, "1.4")


# Generated at 2022-06-22 06:21:59.824938
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizer = _TokenizingDecoder(content='abc')
    assert tokenizer is not None

# Generated at 2022-06-22 06:22:10.779870
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[1,2,"a",{"b":{"c":4}}]'
    tokens = tokenize_json(content)
    assert(tokens.kind == "list")
    assert(len(tokens.items) == 4)
    assert(tokens.items[0].kind == "scalar")
    assert(tokens.items[0].value == 1)
    assert(tokens.items[1].kind == "scalar")
    assert(tokens.items[1].value == 2)
    assert(tokens.items[2].kind == "scalar")
    assert(tokens.items[2].value == "a")
    assert(tokens.items[3].kind == "dict")
    assert(len(tokens.items[3].items) == 1)

# Generated at 2022-06-22 06:22:12.522281
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-22 06:22:24.659671
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    content = '{"test": "value"}'
    value, error_messages = validate_json(content, field)
    assert value == {"test": "value"}
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1

    content = '{"test": "value", "test": "value"}'
    value, error_messages = validate_json(content, field)
    assert value == None
    assert isinstance(error_messages, list)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Test: 'test' is defined more than once."
    assert error_messages[0].position.line_no == 0
    assert error_messages[0].position.column_no == 1


# Generated at 2022-06-22 06:22:30.960649
# Unit test for function tokenize_json
def test_tokenize_json():
    f = tokenize_json
    assert isinstance(f('"text"'), ScalarToken)
    assert isinstance(f('[1, 2, 3]'), ListToken)
    assert isinstance(f('{"a": 1}'), DictToken)
    with pytest.raises(ParseError):
        f('{}')
    with pytest.raises(ParseError):
        f('[')
    with pytest.raises(ParseError):
        f('"abc')


# Generated at 2022-06-22 06:22:31.967926
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:22:47.429799
# Unit test for function validate_json
def test_validate_json():
    """
    Test that validate_json returns a two-tuple, value and errors.
    """
    import typesystem
    from typesystem.json import JSONSchema

    class User(typesystem.Schema):
        username = typesystem.String()
        password = typesystem.String()
        bio = typesystem.String(required=False)

    schema = JSONSchema(schema=User)
    value, errors = validate_json(
        content='{"username": "jdoe", "password": "secret"}',
        validator=schema,
    )
    assert value, ('{"bio": null, "password": "secret", "username": "jdoe"}')
    assert errors, []


# Generated at 2022-06-22 06:22:54.513608
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        first_name = Field(String())
        last_name = Field(String())

    result = validate_json(
        b"""{"first_name": "Joe", "last_name": "Schmoe"}""", Person
    )
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], list)
    assert len(result[1]) == 0

    result = validate_json(
        b"""{"last_name": "Schmoe"}""", Person
    )
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], list)
    assert len(result[1]) == 1
    assert isinstance(result[1][0], ValidationError)
    assert result

# Generated at 2022-06-22 06:23:03.850907
# Unit test for function tokenize_json
def test_tokenize_json():
    # test empty string
    assert tokenize_json("  ") == None
    # test empty array
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    # test empty object
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    # test single empty array
    assert tokenize_json("[\n]") == ListToken([], 1, 2, "[\n]")
    # test single empty object
    assert tokenize_json("{\n}") == DictToken({}, 1, 2, "{\n}")
    # test nested array

# Generated at 2022-06-22 06:23:08.888892
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.scan_once('"123"', 0) == ('123', 5)
    assert decoder.scan_once('"123", "456"', 0) == ('123', 5)


# Generated at 2022-06-22 06:23:18.467871
# Unit test for function validate_json
def test_validate_json():
    import json
    def _validate(content, expected):
        result, messages = validate_json(content, Field(type="string"))
        assert result == expected
        assert isinstance(messages, list)

    _validate(b'{}', [])
    _validate('[]', [])
    _validate(json.dumps(None), None)
    _validate(json.dumps(True), True)
    _validate(json.dumps(123), '123')
    _validate(json.dumps('hello'), 'hello')
    _validate(json.dumps(['a', 'b']), ['a', 'b'])
    _validate(json.dumps({}), {})

# Generated at 2022-06-22 06:23:24.396631
# Unit test for function validate_json
def test_validate_json():
    class Schema(typesystem.Schema):
        first = typesystem.String(max_length=5, min_length=5)

    schema = Schema()
    value, error_messages = validate_json('{"first": "hello"}', schema)

    assert error_messages == []
    assert value == {"first": "hello"}


# Generated at 2022-06-22 06:23:28.643427
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"name":"ewu","points":[1,2,3]}'
    token = tokenize_json(json)
    print(dict(token.get_children()))



# Generated at 2022-06-22 06:23:41.491898
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken("foo", 0, 1, '{"foo": "bar"}'): ScalarToken("bar", 7, 8, '{"foo": "bar"}')}, 0, 12, '{"foo": "bar"}')
    assert tokenize_json('[0, 1, 2]') == ListToken([ScalarToken(0, 0, 1, '[0, 1, 2]'), ScalarToken(1, 3, 4, '[0, 1, 2]'), ScalarToken(2, 6, 7, '[0, 1, 2]')], 0, 9, '[0, 1, 2]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')

# Generated at 2022-06-22 06:23:53.411050
# Unit test for function validate_json
def test_validate_json():
    # Success
    content = '{"f1": 10}'
    validator = Schema(fields={
        "f1": {'type': 'integer', 'minimum': 9}
    })
    value, err_msgs = validate_json(content, validator)
    assert value['f1'] == 10
    assert err_msgs == []

    # Failure
    content = '{"f1": 5}'
    validator = Schema(fields={
        "f1": {'type': 'integer', 'minimum': 9}
    })
    value, err_msgs = validate_json(content, validator)
    assert value['f1'] == 5
    assert len(err_msgs) == 1
    msg = err_msgs[0]
    assert msg['code'] == 'minimum_value_error'

# Generated at 2022-06-22 06:24:02.116494
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:08.207584
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder



# Generated at 2022-06-22 06:24:18.717812
# Unit test for function validate_json
def test_validate_json():
    raw_json = '[{"name": "Jane"}, {"name": "Mary"}]'
    validator = Schema(fields=[
        Field(name="name", type="string", is_required=True),
    ])
    value, error_messages = validate_json(raw_json, validator)
    assert error_messages == []
    assert value == [{"name": "Jane"}, {"name": "Mary"}]
    raw_json = '[{"name": "Jane"}, {"age": "Mary"}]'
    validator = Schema(fields=[
        Field(name="name", type="string", is_required=True),
    ])
    value, error_messages = validate_json(raw_json, validator)

# Generated at 2022-06-22 06:24:28.589031
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        properties={
            "name": str,
            "age": int,
            "employee_code": str,
            "salary": float,
            "address": {
                "city": str,
                "state": str,
                "pincode": int,
            }
        }
    )
    correct_data = b'{"name":"John", "age":30, "employee_code": "E001", "salary": 45000.0, "address": {"city":"Pune", "state":"MH", "pincode":12}}'

# Generated at 2022-06-22 06:24:40.062799
# Unit test for function tokenize_json
def test_tokenize_json():
    # Arrange
    content = """{
        "visible_name": "Tanya",
        "from_city": "Dallas",
        "from_zip": "75202",
        "from_state": "TX",
        "to_city": "Austin",
        "to_zip": "78704",
        "to_state": "TX",
        "preferred_move_date": "2019-04-30",
        "stored_items_0": "Furniture",
        "stored_items_1": "Clothes",
        "stored_items_2": "Electronics",
        "stored_items_3": "Kitchen Utensils",
        "form_version": "v1"
    }"""
    # Act
    result = tokenize_json(content)
    # Assert
    assert result

# Generated at 2022-06-22 06:24:50.724142
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Array, Boolean, Integer, String
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        field_a = Integer()
        field_b = String()
        field_c = Integer(minimum=2)
        field_d = Array(items=String())
        field_e = Array(items=Integer())
        field_f = Boolean()

    # Happy path
    value, error_messages = validate_json(
        b'{"field_a":1, "field_b":"x", "field_c":2, "field_d":["a"]}',
        validator=ExampleSchema,
    )

# Generated at 2022-06-22 06:25:01.720799
# Unit test for function tokenize_json
def test_tokenize_json():
    obj = [{'a': 'A'}, 'b', 1]
    data = json.dumps(obj)
    assert json.loads(data) == obj
    root_token = tokenize_json(data)
    print(root_token)
    assert root_token.content == data
    assert len(root_token.children) == 3
    assert root_token.children[0].content == '{'
    assert root_token.children[0].children[0].content == '"'
    assert root_token.children[0].children[0].children[0].content == 'a'
    assert root_token.children[0].children[0].children[0].children[0].content == 'a'
    assert root_token.children[0].children[1].content == ':'

# Generated at 2022-06-22 06:25:06.733213
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {
        "items": [
            {"first_name": "John", "last_name": "Doe", "age": "45"},
            {"first_name": "Tom", "last_name": "Smith", "age": "34"},
        ]
    }

    content = json.dumps(content)

    tokens = tokenize_json(content)
    assert tokens.token_type == "DictToken"
    assert tokens.position == Position(
        column_no=1, line_no=1, char_index=0, content=content
    )
    assert tokens.end_position == Position(
        column_no=1, line_no=7, char_index=81, content=content
    )

# Generated at 2022-06-22 06:25:17.834119
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json with validator as Field
    """
    content = '{"a": 1, "b": "hello"}'
    validator = Field(type="object")
    value, error_messages = validate_json(content, validator)
    assert error_messages is None
    assert value == {"a": 1, "b": "hello"}

    content = '{"a": 1, "b": "hello"}'
    validator = Field(type="object", properties={"a": Field(type="integer")})
    value, error_messages = validate_json(content, validator)
    assert error_messages is None
    assert value == {"a": 1, "b": "hello"}

    content = '{"a": 1, "b": "hello"}'

# Generated at 2022-06-22 06:25:24.638178
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name":"john"}')
    assert "john" == token["name"]
    # pass empty string
    try:
        tokenize_json("")
    except ParseError as err:
        assert "No content" in str(err)
    # pass bad string
    try:
        tokenize_json('{"name":{')
    except ParseError as err:
        assert "Expecting value" in str(err)


# Generated at 2022-06-22 06:25:29.553275
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({
        ScalarToken('foo', 1, 3, '{"foo": "bar"}'): ScalarToken('bar', 10, 14, '{"foo": "bar"}')
    }, 0, 14, '{"foo": "bar"}')



# Generated at 2022-06-22 06:25:35.426604
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = r'{"name": "foo", "age": 20}'
    _TokenizingDecoder(content=content)

# Generated at 2022-06-22 06:25:37.724453
# Unit test for function validate_json
def test_validate_json():
    errors = validate_json('{"name": "typesystem"}', {'name': "string"})
    assert not errors

# Generated at 2022-06-22 06:25:40.849725
# Unit test for function validate_json
def test_validate_json():
    content = """
    {
        "name": "foo",
        "age": 19,
        "salary": 70000
    }
    """
    validator = Schema(
        {"name": Field(required=True), "age": Field(required=True), "salary": Field(required=True)}
    )
    value, error_messages = validate_json(content, validator)
    assert value == {'name': 'foo', 'age': 19, 'salary': 70000}
    assert error_messages == []

# Generated at 2022-06-22 06:25:52.021421
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.tokens import Token

    def token(start, end):
        return Token(start, end)

    def list_token(tokens, start, end):
        return ListToken(tokens=tokens, start=start, end=end)

    def dict_token(pairs, start, end):
        return DictToken(pairs=pairs, start=start, end=end)

    def scalar_token(obj, start, end):
        return ScalarToken(obj=obj, start=start, end=end)


# Generated at 2022-06-22 06:25:54.968337
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "This is a test string"
    _TokenizingDecoder(content=content)


# Generated at 2022-06-22 06:26:04.684870
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test_content")
    assert(decoder.parse_string == scanstring)
    assert(decoder.parse_float == float)
    assert(decoder.parse_int == int)
    assert(decoder.strict == True)
    assert(decoder.parse_array == JSONDecoder.parse_array)
    assert(decoder.scan_once == _make_scanner(decoder, "test_content"))


# Generated at 2022-06-22 06:26:14.531550
# Unit test for function validate_json
def test_validate_json():
    # TODO: use assertRaises for specific exceptions
    try:
        validate_json(b"", int)
        assert False
    except ParseError:
        pass

    try:
        validate_json(b"nonsense", int)
        assert False
    except ParseError:
        pass

    try:
        validate_json(b"{}", int)
        assert False
    except ValidationError:
        pass

    try:
        validate_json(b'"nonsense"', int)
        assert False
    except ValidationError:
        pass

    try:
        validate_json(b"[1, 2]", int)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-22 06:26:19.880677
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import (
        DictToken,
        ListToken,
        ScalarToken,
    )

    token = tokenize_json(
        '''{
            "name": {"first": "Steve", "last": "Woodruff"},
            "age": 39,
            "is_cool": true,
            "pets": ["Scooby", "Scrappy"],
            "pets_with_ages": [{"name": "Scooby", "age": 15}, {"name": "Scrappy", "age": 16}]
        }'''
    )

    assert isinstance(token, DictToken)
    assert len(token.value.keys()) == 5

# Generated at 2022-06-22 06:26:31.652507
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "John Smith",
        "age": 42,
        "is_cool": true,
        "scores": [1, 2.0, 3],
        "address": {
            "street": "123 Fake Street",
            "city": "Springfield"
        },
        "some_null_value": null
    }
    """
    token = tokenize_json(content)

    assert token
    assert token.start == content.index("{")
    assert token.end == len(content) - 1
    assert token.content == content

    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:26:34.204706
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test = _TokenizingDecoder("content")
    assert test.scan_once == _make_scanner(test, "content")


# Generated at 2022-06-22 06:26:43.321776
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = """{
        "key 1": "val 1",
        "key 2": [ 1, 2, 3, "four", true, null, false ]
    }"""

    decoder = _TokenizingDecoder(content=content)

    assert(decoder.parse_string is scanstring)
    assert(decoder.strict is True)

# Generated at 2022-06-22 06:26:53.267630
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json function.
    """
    from typesystem import Integer, typesystem

    class Person(typesystem.Schema):
        age = Integer()

    # Validation of a valid document should succeed
    value, errors = validate_json(b"{ \"age\": \"10\" }", Person)
    assert value == {"age": 10}
    assert errors == []

    # Validation of an invalid document should fail
    value, errors = validate_json(b"{ \"age\": \"abc\" }", Person)

# Generated at 2022-06-22 06:27:05.412498
# Unit test for function tokenize_json
def test_tokenize_json():  # type: ignore
    # Test formatting
    assert tokenize_json("[1, 2, 3]") == ListToken(
        elements=[
            ScalarToken(value=1, start=1, end=1, text="1"),
            ScalarToken(value=2, start=3, end=3, text="2"),
            ScalarToken(value=3, start=5, end=5, text="3"),
        ],
        start=0,
        end=7,
        text="[1, 2, 3]",
    )

# Generated at 2022-06-22 06:27:07.000059
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    return decoder

# Generated at 2022-06-22 06:27:16.396019
# Unit test for function validate_json
def test_validate_json():
    """ Tests that validate_json returns the correct results for given values """
    content_true = "true"
    content_false = "false"
    token_true = ScalarToken(True, 0, 3, content_true)
    token_false = ScalarToken(False, 0, 4, content_false)
    test_field = Field()
    test_value, errors = validate_json(content_true, test_field)
    assert test_value == True
    assert errors == []
    test_value, errors = validate_json(content_false, test_field)
    assert test_value == False
    assert errors == []

# Generated at 2022-06-22 06:27:26.953293
# Unit test for function validate_json
def test_validate_json():

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.base import Message
    from typesystem.exceptions import ValidationError
    from typesystem.json_schema import typesystem_to_json_schema

    class Person(Schema):
        name = String
        age = Integer(minimum=0)

    json_schema_person = typesystem_to_json_schema(Person)

    # Test valid json
    json_string = """{
        "name": "Josiah",
        "age": 28
    }"""
    result = validate_json(json_string, Person)
    assert result[0]["name"] == "Josiah"
    assert result[0]["age"] == 28
    assert len(result[1]) == 0

    # Test invalid

# Generated at 2022-06-22 06:27:32.258306
# Unit test for function validate_json
def test_validate_json():
    import json
    import typesystem
    schema = typesystem.Schema(
        properties={"a": typesystem.Integer(maximum=10),}
    )
    text = json.dumps({"a": 1})
    actual = validate_json(text, validator=schema)
    assert actual == ({"a": 1}, ())



# Generated at 2022-06-22 06:27:45.087074
# Unit test for function validate_json
def test_validate_json():
    class SampleSchema(Schema):
        first_name = validators.String(max_length=20)
        last_name = validators.String(max_length=20)
        number = validators.Integer()

        class Meta:
            strict = True

    validator = SampleSchema()
    json_content = '{"first":"John", "last":"Doe", "number":123}'
    value, errors = validate_json(json_content, validator)

    assert not errors

    json_content = '{"first":"John", "last":"Doe", "number":"123"}'
    value, errors = validate_json(json_content, validator)

    assert errors
    assert len(errors) == 1
    assert errors[0].position.column_no == 21
    assert errors[0].position.line_no == 1

# Generated at 2022-06-22 06:27:55.416859
# Unit test for function validate_json
def test_validate_json():
    validator = Schema("ExampleSchema", [
        Field("foo", type="integer"),
        Field("bar", type="number")
    ])
    # Success case
    json_content = '{"foo": 3, "bar": 2.5}'
    parsed_value, error_messages = validate_json(json_content, validator)
    assert parsed_value == {"foo": 3, "bar": 2.5}
    assert not error_messages

    # Failure case
    bad_content = '{"foo": "3", "bar": "2.5"}'
    parsed_value, error_messages = validate_json(bad_content, validator)

    assert parsed_value is None
    assert len(error_messages) == 2

# Generated at 2022-06-22 06:27:57.213874
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder



# Generated at 2022-06-22 06:28:09.308478
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "abc")
    assert set(decoder.__dict__.keys()) == {'parse_float', 'parse_int', 'strict', 'memo', 'parse_array', 'scan_once', 'parse_object', 'parse_string'}

test__TokenizingDecoder()

# Generated at 2022-06-22 06:28:12.117855
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import typesystem
    data = '{"name": "John", "age": 30, "cars": {"car1":"Ford", "car2":"BMW", "car3":"Fiat"}}'
    json_data = typesystem.to_json_schema(typesystem.Schema)
    decoder = _TokenizingDecoder(json_data, content=data)
    assert len(decoder.scan_once(data, 0)) == 2

# Generated at 2022-06-22 06:28:23.244739
# Unit test for function validate_json
def test_validate_json():
    def get_validation_error_messages(is_valid: bool, expected_errors: typing.List[Message]):
        assert is_valid == False, "Validation should fail with invalid json"
        assert len(expected_errors) == len(errors), "The number of errors should be correct"

        for expected_error, error in zip(expected_errors, errors):
            assert expected_error == error, "The error messages should be correct"

    ## Test for invalid json
    # Empty json
    is_valid, errors = validate_json("", Field())