

# Generated at 2022-06-22 06:18:54.522570
# Unit test for function validate_json
def test_validate_json():
    pass

# Generated at 2022-06-22 06:18:55.893760
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None

# Generated at 2022-06-22 06:18:59.348884
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({"name": String()})
    value, messages = validate_json(instance, schema)

# Generated at 2022-06-22 06:19:11.013792
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, fields, types

    class PersonSchema(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer()

    content = '{"name": "Bob", "age": "1234567"}'
    result = validate_json(content, validator=PersonSchema)
    assert result == (
        {'name': 'Bob', 'age': 1234567},
        [Message('Must have no more than 100 characters.',
            code='max_length',
            position=Position(2, 3, 17),
            type='error',
        )],
    ), result

    content = '{"name": "Bob"}'
    result = validate_json(content, validator=PersonSchema)

# Generated at 2022-06-22 06:19:22.558022
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:19:29.444783
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(type=str, pattern="^foo$")
    schema = Schema([field])
    import pytest
    with pytest.raises(ParseError, match=r"^.*No content$"):
        validate_json(content="", validator=schema)
    with pytest.raises(ParseError, match=r"^.*Expecting property.*"):
        validate_json(content='{"bar": "foo"}', validator=schema)

# Generated at 2022-06-22 06:19:31.926298
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "content")
    assert decoder.scan_once == _make_scanner(decoder, "content")

# Generated at 2022-06-22 06:19:42.113199
# Unit test for function validate_json

# Generated at 2022-06-22 06:19:54.287569
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:19:59.132855
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"test": "test"}')
    token, end = decoder.scan_once('{"test": "test"}', 0)
    assert token.value == {'test': 'test'}
    assert token.start == 0
    assert token.end == len('{"test": "test"}') - 1


# Generated at 2022-06-22 06:20:20.309850
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('"hello"'), ScalarToken)
    assert isinstance(tokenize_json('{"hello": 0}'), DictToken)
    assert isinstance(tokenize_json('[0, 1]'), ListToken)
    assert isinstance(tokenize_json('"singl\u00E9 field"'), ScalarToken)
    assert isinstance(tokenize_json('"Quote: \\""'), ScalarToken)
    assert isinstance(tokenize_json('"Slash: \\\\"'), ScalarToken)
    assert isinstance(tokenize_json('"Backslash: \\\\ "'), ScalarToken)
    assert isinstance(tokenize_json('"Backspace: \b"'), ScalarToken)

# Generated at 2022-06-22 06:20:32.432942
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{ "foo": "bar" }'
    token = tokenize_json(content)
    token_type = type(token)
    assert token_type == DictToken

    dict_token = token
    dict_token_value = dict_token.value

    dict_token_type = type(dict_token_value)
    assert dict_token_type == dict

    dict_token_value_key = list(dict_token_value.keys())
    dict_token_value_key_type = type(dict_token_value_key[0])
    assert dict_token_value_key_type == ScalarToken

    dict_token_value_value = list(dict_token_value.values())
    dict_token_value_value_type = type(dict_token_value_value[0])
    assert dict_

# Generated at 2022-06-22 06:20:36.396307
# Unit test for function tokenize_json
def test_tokenize_json():
    text = """
  {    
  "key": "value",
   "key2":"value"
    }
    """.strip()

    token = tokenize_json(text)
    assert type(token) is DictToken
    assert token.value == {"key": "value", "key2": "value"}

# Generated at 2022-06-22 06:20:48.155635
# Unit test for function validate_json
def test_validate_json():
    """
    This is a unit test for the function validate_json
    """
    import json

    from typesystem import Integer, Object, String

    from .test_basic_validation import complex_object_schema, simple_list_schema
    from .test_positional_validation import (
        complex_object_errors,
        list_with_errors_errors,
        simple_list_errors,
    )

    # Test case when validator is a Field
    simple_string = '"John"'
    string_validator = String()
    value, error_messages = validate_json(
        content=simple_string, validator=string_validator
    )
    assert value == "John"
    assert error_messages == []

    # Test case when validator is a Schema class

# Generated at 2022-06-22 06:20:50.952541
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "aaa"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once == _make_scanner(decoder, content)

# Generated at 2022-06-22 06:20:57.853386
# Unit test for function validate_json
def test_validate_json():
    with open('test_data.json') as f:
        content = f.read()
    field = Field(type="string", pattern='^\d{3}$')
    errors = validate_json(content, field)[1]
    assert isinstance(errors, list)
    assert isinstance(errors[0], Message)
    assert errors[0].code == 'field_does_not_match_regex'
    assert len(errors) == 3

# Generated at 2022-06-22 06:21:08.617811
# Unit test for function validate_json
def test_validate_json():
    from typesystem import schema
    from typesystem.fields import String, Integer, Float

    # Test string parsing
    def test_string_json_parse(content, expected):
        assert tokenize_json(content) == expected

    # Test parsing failure
    def test_json_error(content, expected):
        try:
            tokenize_json(content)
        except ParseError as exc:
            assert exc.position == expected
        else:
            assert False, "Expected a ParseError"

    test_string_json_parse(
        '"asdf"', ScalarToken(value="asdf", start=0, end=5, content=content)
    )

# Generated at 2022-06-22 06:21:12.992706
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":1, "b":true}'
    decoder = _TokenizingDecoder(content=content)
    result = decoder.decode(content)
    expected = DictToken({'a': ScalarToken(1, 2, 3, content), 'b': ScalarToken(True, 10, 12, content)}, 0, 17, content)

# Generated at 2022-06-22 06:21:18.807105
# Unit test for function tokenize_json
def test_tokenize_json():
    text1 = """{"data": {"ndarray": "[[1, 1], [3]]"} }"""
    text = text1.encode("utf-8")
    results = tokenize_json(text)
    assert isinstance(results, DictToken)
    assert isinstance(results.value, dict)

    results = validate_json(text1, Field(primitive="string"))
    assert results == ('{"data": {"ndarray": "[[1, 1], [3]]"} }', [])

    results = validate_json(text1, Field(primitive="number"))
    assert isinstance(results, tuple)
    errors = results[1]
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-22 06:21:27.786396
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"1": 2}') == DictToken({'1': 2}, 0, 7, content='{"1": 2}')
    assert tokenize_json('{"1" : 2}') == DictToken({'1': 2}, 0, 8, content='{"1" : 2}')
    assert tokenize_json('[1, 2, 3]') == ListToken([1, 2, 3], 0, 8, content='[1, 2, 3]')

# Generated at 2022-06-22 06:21:47.047080
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Array, Boolean, Integer, String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)
        is_active = Boolean()
        age = Integer(minimum=0, maximum=150)
        languages = Array(items=String(max_length=25), min_items=1)

        class Meta:
            title = "Test Schema"

    content = u'{"first_name": "John", "last_name": "Doe", "is_active": true, "languages": ["EN", "ES"], "age": 50}'

    value, error_messages = validate_json(
        content=content, validator=TestSchema
    )


# Generated at 2022-06-22 06:21:57.920851
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:21:58.812985
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content='test')

# Generated at 2022-06-22 06:22:06.289491
# Unit test for function validate_json
def test_validate_json():
    content = b'{"test": 1}'
    validator = Field(type="integer")
    value, errors = validate_json(content, validator)
    assert errors == []

    content = '{"test": "1"}'
    value, errors = validate_json(content, validator)
    assert errors == [ValidationError(
            code='type_error',
            message='Must be an integer.',
            path=['test'],
            
        )]

if __name__ == '__main__':
    test_validate_json()

# Generated at 2022-06-22 06:22:16.730672
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"key": "value"}]'
    token: Token = tokenize_json(content)
    assert isinstance(token, ListToken)
    for i, sub_token in enumerate(token.value):
        assert sub_token.start == 1 + i
        assert sub_token.end == len(content) - 1
    assert len(token.value) == 1
    assert isinstance(token.value[0], DictToken)
    assert token.value[0].start == 1
    assert token.value[0].end == len(content) - 1
    assert len(token.value[0].value) == 1
    assert token.value[0].value[0].start == 2
    assert token.value[0].value[0].end == 7
    assert token.value[0].value[1].start == 8
   

# Generated at 2022-06-22 06:22:20.206354
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{ "a": true, "b": null }'
    tokens = _TokenizingDecoder(content = json_str).decode(json_str)
    assert isinstance(tokens, Token)

# Generated at 2022-06-22 06:22:29.981391
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        {
            "last_name": Field(type=str),
            "first_name": Field(type=str),
            "age": Field(type=int),
        }
    )

    content1 = '''{ 
        "last_name": "Smith", 
        "first_name": "John", 
        "age": 30
    }
    '''

    value1, error_messages1 = validate_json(content1, schema)

    content2 = '''{ 
        "last_name": "Smith", 
        "age": 30
    }
    '''

    value2, error_messages2 = validate_json(content2, schema)


# Generated at 2022-06-22 06:22:36.893759
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": "1", "b": "2", "c": "3"}'
    validator = Schema({"a": str, "b": str, "c": str})
    value, validation_errors = validate_json(content, validator)
    expected_value = {"a": "1", "b": "2", "c": "3"}
    assert value == expected_value
    assert validation_errors == []


# Generated at 2022-06-22 06:22:41.314017
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json = '{"a": 1, "b": 2, "c": 3}'
    _TokenizingDecoder(content=json).decode('{"a": 1, "b": 2, "c": 3}') == '{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-22 06:22:46.512472
# Unit test for function validate_json
def test_validate_json():
  content = '{"id": 0, "name": "fiddlehead"}'
  expected = (
    {
      "id": 0,
      "name": "fiddlehead"
    },
    []
  )
  class FiddleheadSchema(Schema):
    id = Integer(required=True)
    name = String(required=True)
  assert validate_json(content, FiddleheadSchema) == expected


# Generated at 2022-06-22 06:23:04.956928
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder()
    assert context.memo == {}
    assert context.parse_array == JSONDecoder.parse_array
    assert context.parse_float == JSONDecoder.parse_float
    assert context.parse_int == JSONDecoder.parse_int
    assert context.parse_string == JSONDecoder.parse_string
    assert context.strict == True
    assert context.scan_once == _make_scanner(context, '')


# Generated at 2022-06-22 06:23:16.876827
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    content = '"test"'
    value, messages = validate_json(content, validator)  # type: ignore
    assert not messages
    assert value == "test"

    content = b"{}"
    value, messages = validate_json(content, validator)  # type: ignore
    assert len(messages) == 1
    assert messages[0].code == "type_error"

    content = '{"test": 3}'
    value, messages = validate_json(content, validator)  # type: ignore
    assert len(messages) == 1
    assert messages[0].code == "type_error"

    content = '["test"]'
    value, messages = validate_json(content, validator)  # type: ignore
    assert len(messages) == 1
   

# Generated at 2022-06-22 06:23:19.164871
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    result = _TokenizingDecoder("content")
    assert isinstance(result, _TokenizingDecoder)
    assert result.scan_once



# Generated at 2022-06-22 06:23:29.292515
# Unit test for function validate_json
def test_validate_json():
    def assert_valid_json(jsonString, validator):
        assert validate_json(jsonString, validator)[0] == "valid string"

    def assert_invalid_json(jsonString, validator, message):
        value, errors = validate_json(jsonString, validator)
        assert not value
        assert len(errors) == 1 and message in errors[0].text

    def assert_invalid_json_multiple_errors(jsonString, validator, messages):
        value, errors = validate_json(jsonString, validator)
        assert not value
        assert len(errors) == len(messages)
        for error in errors:
            assert error.text in messages


# Generated at 2022-06-22 06:23:42.117327
# Unit test for function tokenize_json
def test_tokenize_json():
    # def __init__(self, text: Text, code: Code, position: Position, field: Text)
    # def __repr__(self) -> Text
    # def __str__(self) -> Text
    # def _to_json(self) -> Dict[str, Text]
    # def position(self) -> Position
    # def text(self) -> Text
    # def code(self) -> Text
    # def field(self) -> Text

    # Check if tokenize_json throws exception on wrong json string
    content = "[test,test]"
    token = tokenize_json(content)
    assert type(token) == ListToken
    assert(len(token) == 2)
    assert(token[0].type == ScalarToken)
    assert(token[1].type == ScalarToken)

# Generated at 2022-06-22 06:23:53.969715
# Unit test for function validate_json
def test_validate_json():
    # test valid json
    validator = Field(type="string")
    assert validator.validate('"hello"') is None
    val, msgs = validate_json('"hello"', validator)
    assert val == "hello"
    assert msgs == []

    # test invalid json
    try:
        json.loads('"hello')
    except JSONDecodeError as e:
        assert e.msg == "Unterminated string starting at: line 1 column 6 (char 5)"
        assert e.lineno == 1
        assert e.colno == 6

    with pytest.raises(ParseError) as e:
        validate_json('"hello', validator)
    assert e.value.text == "Unterminated string starting at: line 1 column 6 (char 5)."
    assert e.value.position.line_no

# Generated at 2022-06-22 06:23:55.985426
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    b1 = _TokenizingDecoder(content="This is test content")
    assert(b1.scan_once)

# Generated at 2022-06-22 06:23:57.650014
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder("")
    assert isinstance(d, _TokenizingDecoder)



# Generated at 2022-06-22 06:24:02.754090
# Unit test for function tokenize_json
def test_tokenize_json():
    # it should produce the right token for a simple json str
    token = tokenize_json("""
    {"name": "Joe"}
    """)

    assert isinstance(token, DictToken)
    assert token.value == {"name": "Joe"}

    # it should raise parse error for an invalid json str
    with pytest.raises(ParseError) as excinfo:
        token = tokenize_json("[1,}")

    assert "Expecting value" in str(excinfo.value)


# Generated at 2022-06-22 06:24:06.317481
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    instance = _TokenizingDecoder()
    assert type(instance) == _TokenizingDecoder



# Generated at 2022-06-22 06:24:23.702101
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    try:
        value, error_messages = validate_json('{"hello": "world"}', DictToken)
        assert len(error_messages) == 0, "Did not expect any error messages."
        assert isinstance(value, dict), "Expected a dict"
        assert value['hello'] == 'world', "Expected the value of the hello key to be world"
    except ValueError as e:
        assert False, "The value was expected to be valid JSON and did not cause a ValueError."

    # Invalid JSON
    try:
        validate_json('{"hello": "world", }', DictToken)
        assert False, "Expected a ValueError."
    except ValueError as e:
        assert True, "The value was expected to be invalid JSON and caused a ValueError."



# Generated at 2022-06-22 06:24:32.991341
# Unit test for function validate_json
def test_validate_json():
    # Positive test cases
    exception_flag = False
    content = '{"n":1}'
    validator = Schema({
        "n": Field(int)
    })

    value, errors = validate_json(content, validator)
    assert value == {"n":1}
    assert errors == []

    content = '{"n":10}'
    validator = Schema({
        "n": Field(int)
    })

    value, errors = validate_json(content, validator)
    assert value == {"n":10}
    assert errors == []

    # Negative test cases
    content = '{"n":-10}'
    validator = Schema({
        "n": Field(int, gt=0)
    })


# Generated at 2022-06-22 06:24:45.059746
# Unit test for function validate_json
def test_validate_json():
    class Employee(Schema):
        name = String(max_length=100)
        age = Integer(minimum=18, maximum=65)
        employed = Boolean()

    assert validate_json(
        """
        {
            "name": "John Doe",
            "age": "25",
            "employed": true
        }
        """,
        Employee,
    ) == (
        {"name": "John Doe", "age": 25, "employed": True},
        [],
    )


# Generated at 2022-06-22 06:24:49.656329
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"name": "John", "age": 30, "car": null}'
    token = tokenize_json(json_str)
    assert token == {
        "name": ScalarToken("John", 6, 11, json_str),
        "age": ScalarToken(30, 17, 19, json_str),
        "car": ScalarToken(None, 25, 29, json_str),
    }



# Generated at 2022-06-22 06:24:57.825215
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = r'''{"foo": "bar"}'''
    data, _ = validate_json(valid_json, Field(str))
    assert data == {"foo": "bar"}

    invalid_json = r'''{"foo": "bar"} | '''
    token = tokenize_json(invalid_json)
    assert token.value == {"foo": "bar"}

    invalid_json = r'''{"foo": "bar"} ab d'''
    with pytest.raises(ParseError):
        token = tokenize_json(invalid_json)

# Generated at 2022-06-22 06:25:09.342906
# Unit test for function validate_json
def test_validate_json():
    # good JSON
    content = '{"foo": 42}'
    validator = Field(type="string")

    assert validate_json(content, validator) == (
        42,
        [
            Message(
                type="error",
                text="Expected string.",
                code="type_error",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

    content = '{"foo": "bar"}'
    validator = Field(type="boolean")

# Generated at 2022-06-22 06:25:19.732403
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="integer")
    json_string = "{\"age\": 28}"
    result = validate_json(content=json_string, validator=validator)
    assert result[0] == {'age': 28}
    assert result[1] == None

    validator_schema = Schema(fields={"age": Field(type="integer")})
    result = validate_json(content=json_string, validator=validator_schema)
    assert result[0] == {'age': 28}
    assert result[1] == None

    json_string = "{\"age\": \"Bobby\"}"
    result = validate_json(content=json_string, validator=validator)
    assert result[0] == None

# Generated at 2022-06-22 06:25:31.866929
# Unit test for function validate_json
def test_validate_json():
    import json
    # Valid input
    json_valid = """
    {
        "test": "value"
    }
    """
    json_valid = json_valid.strip()
    value, messages = validate_json(json_valid, Field("test", description="test"))
    assert len(messages) == 0
    assert value == {"test": "value"}
    # Invalid input
    json_invalid = """
    {
        "test": False
    }
    """
    json_invalid = json_invalid.strip()
    value, messages = validate_json(json_invalid, Field("test", description="test"))
    assert len(messages) == 1
    message = messages[0]
    assert isinstance(message, ValidationError)
    assert message.code == "invalid_type"
    assert message

# Generated at 2022-06-22 06:25:42.904008
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{ "name": "John Doe", "age": 42, "is_admin": true }'
    assert tokenize_json(json_string) == {
        'name': 'John Doe',
        'age': 42,
        'is_admin': True,
    }

    json_string = '{ "name": [ "John Doe", "Jane Doe" ], "age": 42, "is_admin": true }'
    assert tokenize_json(json_string) == {
        'name': ['John Doe', 'Jane Doe'],
        'age': 42,
        'is_admin': True,
    }



# Generated at 2022-06-22 06:25:44.366749
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"a": {"b": 1}}')
    t = _TokenizingDecoder()
    t.scan_once(token.content, 0)



# Generated at 2022-06-22 06:26:00.025602
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class A():
        def __init__(self, *args, **kwargs):
            re.VERBOSE = 0
            self.strict = False
            self.parse_int = None
            self.parse_float = None
            self.parse_array = None
            self.parse_string = None
            self.memo = dict()
            self.scan_once = None

    content = "{}"
    decoder = _TokenizingDecoder(context=A(), content=content)
    assert decoder.scan_once is not None
    assert decoder.strict is False
    assert decoder.parse_int is not None
    assert decoder.parse_float is not None
    assert decoder.parse_array is not None
    assert decoder.parse_string is not None
    assert decoder.memo is not None
   

# Generated at 2022-06-22 06:26:07.899863
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"foo"') == ScalarToken('foo', 0, 5, '"foo"')
    assert tokenize_json('["foo", "bar"]') == ListToken(
        [ScalarToken('foo', 2, 7, '"foo"'), ScalarToken('bar', 10, 15, '"bar"')],
        0,
        16,
        '["foo", "bar"]'
    )

# Generated at 2022-06-22 06:26:19.558185
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "Dave", "gender": "Male"}'
    validator = Schema(fields={"name": {"type": "string"}, "gender": {"type": "string"}})
    value, errors = validate_json(content, validator)
    assert value == {"name": "Dave", "gender": "Male"}, "Valid JSON, should have valid value"
    assert not errors, "Valid JSON, no errors should be reported"

    content = '{"name": "Dave", "gender": "Male"}'
    validator = Schema(fields={"name": {"type": "string"}})
    value, errors = validate_json(content, validator)

# Generated at 2022-06-22 06:26:31.211295
# Unit test for function tokenize_json
def test_tokenize_json():
    # test for empty content and valid content
    assert tokenize_json("") == ScalarToken(None, 0, 0, "")
    assert tokenize_json('{"key": "value"}') == DictToken(
        {"key": ScalarToken("value", 7, 14, '{"key": "value"}')}, 0, 19, '{"key": "value"}'
    )

    # test for invalid content
    with pytest.raises(ParseError):
        tokenize_json("[")
    with pytest.raises(ParseError):
        tokenize_json("{")
    with pytest.raises(ParseError):
        tokenize_json('"')
    with pytest.raises(ParseError):
        tokenize_json("")

# Generated at 2022-06-22 06:26:43.659086
# Unit test for function validate_json
def test_validate_json():
    """
    Test for function validate_json
    """
    class UserSchema(Schema):
        name = Field(type_=str)

    json_string = '{"name": "Bob"}'
    schema_obj = UserSchema()
    try:
        validate_json(content=json_string, validator=schema_obj)
    except ValidationError as exc:
        assert exc.message
        assert exc.message.startswith(
            "invalid value: {'name': 'Bob'}, expected a list value"
        )
        assert exc.context.key == "name"

    class UserSchema(Schema):
        name = Field(type_=str, required=True)

    json_string = '{"friends": ["Tom", "Alex"]}'
    schema_obj = UserSchema()

# Generated at 2022-06-22 06:26:54.912945
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": {"b":"c"}}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": {"b": "c"}}
    assert token.start_pos == 0
    assert token.end_pos == 14

    first_item = list(token.items())[0][1]
    assert isinstance(first_item, DictToken)
    assert first_item.start_pos == 5
    assert first_item.end_pos == 13
    assert first_item.value == {"b": "c"}

    token = tokenize_json('{"a": [1, 2, {"b": "c"}]}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": [1, 2, {"b": "c"}]}

# Generated at 2022-06-22 06:27:06.109827
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    schema = String()
    value, errors = validate_json(b'"abc"', schema)
    assert value == 'abc'
    assert not errors

    value, errors = validate_json(b'', schema)
    assert not value
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "no_content"
    assert error.text == "No content."

    value, errors = validate_json(b'{x=1, y=2}', schema)
    assert not value
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "parse_error"
    assert error.text == "Expecting property name enclosed in double quotes."

# Generated at 2022-06-22 06:27:12.641533
# Unit test for function validate_json
def test_validate_json():
    def test_good_json():
        json = '{"field": "test"}'
        validator = Schema({"field": String()})

        value, error_messages = validate_json(json, validator)

        assert len(error_messages) == 0
        assert value == {"field": "test"}

    def test_bad_json():
        """This test shows that when there is bad json the entire json string
        is returned with a parse error.
        """
        json = '{"field": "test"'
        validator = Schema({"field": String()})

        value, error_messages = validate_json(json, validator)

        assert len(error_messages) == 1
        assert type(error_messages[0]) == ParseError

# Generated at 2022-06-22 06:27:23.678977
# Unit test for function validate_json
def test_validate_json():
    import sys
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(dir_path + '/../libraries/validators')
    from dtypes import *

    schema = Schema(
        [
            String("length", max_length=3),
            Integer("number"),
            # Repeat the field to test error grouping
            Integer("number"),
        ]
    )

    # Happy path
    data = '''
        {
            "length": "foo",
            "number": 123
        }
    '''
    value, errors = validate_json(data, schema)
    assert value == {"length": "foo", "number": 123}
    assert not errors

    # Error path

# Generated at 2022-06-22 06:27:34.937188
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "Bob"}') == DictToken({
        ScalarToken('name', 0, 5, '{"name": "Bob"}'): ScalarToken('Bob', 11, 15, '{"name": "Bob"}'),
    }, 0, 15, '{"name": "Bob"}')

# Generated at 2022-06-22 06:27:46.901953
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder(content="{}")
    assert tokenizing_decoder.scan_once(content="{}", idx=0) == (
        DictToken({}, 0, 1, "{}"),
        2,
    )

# Generated at 2022-06-22 06:27:57.944244
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    content = ""
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert(exc.text == "No content.")
        assert(exc.code == "no_content")
        assert(exc.position.column_no == 1)
        assert(exc.position.line_no == 1)
        assert(exc.position.char_index == 0)

    # Test integer
    content = '42'
    token = tokenize_json(content)
    assert(token)
    assert(isinstance(token, ScalarToken))
    assert(token.value == 42)
    assert(token.start == 0)
    assert(token.end == 2)
    assert(token.content == '42')

    # Test valid float
    content = '4.2'
   

# Generated at 2022-06-22 06:28:01.089612
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":10, "b": "20", "c":null, "d": [1,2,3], "e": {"k": [{"a":"b"}]}}'

    assert isinstance(_TokenizingDecoder(content=content), JSONDecoder)



# Generated at 2022-06-22 06:28:12.604267
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"username": "user","password": "passwd"}', User) == (
        {"username": "user", "password": "passwd"},
        [],
    )
    assert (
        validate_json(b'{"username": "user","password": "passwd","group": "g1"}', User)[1]
        == []
    )
    assert (
        validate_json(b'{"username": "user"}', User)[1][0].text
        == "password: This field is required."
    )

# Generated at 2022-06-22 06:28:16.101543
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
   content = "{}"
   decoder = _TokenizingDecoder(content=content)
   assert decoder.scan_once('content', 0)



# Generated at 2022-06-22 06:28:26.164606
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    with open('data/test_object.json') as f:
        test_object = json.load(f)
    with open('data/test_array.json') as f:
        test_array = json.load(f)

    # Test parsing an empty object
    def parse_empty_object():
        tokenize_json('{}')
    # Test parsing an empty array
    def parse_empty_array():
        tokenize_json('[]')
    # Test parsing a top level scalar
    def parse_scalar_1():
        tokenize_json('"abc"')
    # Test parsing a top level scalar enclosed in brackets
    def parse_scalar_2():
        tokenize_json('["abc"]')
    # Test parsing a top level scalar enclosed in curly brackets