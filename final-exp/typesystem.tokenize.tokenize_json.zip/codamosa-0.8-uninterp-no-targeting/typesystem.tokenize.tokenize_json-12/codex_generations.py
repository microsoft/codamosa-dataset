

# Generated at 2022-06-22 06:18:59.999232
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"foo": "bar", "baz": "qux", "list": [1, 2, 3.5]}'
    token = tokenize_json(json_string)
    assert token.value == {
        "foo": "bar",
        "baz": "qux",
        "list": [1, 2, 3.5],
    }
    value = token.value
    assert value["foo"].value == "bar"
    assert value["baz"].value == "qux"
    assert value["list"].value == [1, 2, 3.5]
    assert value["foo"].start.line_no == 1
    assert value["foo"].start.column_no == 3
    assert value["baz"].start.line_no == 1
    assert value["baz"].start

# Generated at 2022-06-22 06:19:11.499735
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # num_char = 128
    # char = 0
    # content = ''
    # for i in range(num_char):
    #     char = int(random.randint(0, 128))
    #     content += chr(char)
    # content = content.encode("utf-8")
    content = '{"a": 1, "2": 3, "f": "sdfsfsfs", "z":[1,2,3,["d","e","r","r"]], "y": {"a": 1, "y": 2, "z":3}, "z": {"a": 1, "z": {"a": 1, "z": 3}} }'
    content = content.encode("utf-8")
    decoder = _TokenizingDecoder(content=content)
    print(decoder.memo)

    #

# Generated at 2022-06-22 06:19:22.648545
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{}', {}) == ({}, None)
    assert validate_json(b'{"string": "string"}', {"string": "string"}) == ({"string": "string"}, None)
    assert validate_json(b'{"string": "string", "int": "0"}', {"string": "string", "int": 0}) == ({"string": "string", "int": 0}, None)
    assert validate_json(b'{"string": "string", "int": 1}', {"string": "string", "int": 0}) == ({"string": "string", "int": 1}, None)
    assert validate_json(b'{"string": "string", "int": 0.1}', {"string": "string", "int": 0}) == ({"string": "string", "int": 0.1}, None)
   

# Generated at 2022-06-22 06:19:31.766340
# Unit test for function validate_json
def test_validate_json():
    validator = "hello"
    content = "test"
    x, err = validate_json(content, validator)
    assert x == None
    assert isinstance(err, ValidationError)
    assert isinstance(err.messages[0], Message)
    assert err.messages[0].code == "invalid_validator"
    assert err.messages[0].text == "Validator should be a Field instance or a Schema class."
    assert err.messages[0].position.column_no == 1
    assert err.messages[0].position.line_no == 1
    assert err.messages[0].position.char_index == 0

# Generated at 2022-06-22 06:19:33.738468
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder({})
    assert type(decoder) == _TokenizingDecoder


# Generated at 2022-06-22 06:19:43.618386
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test of a valid object
    content = '{"hello": "world", "numbers": [1,2,3]}'
    tokenizer = _TokenizingDecoder(content=content)
    value = tokenizer.decode(content)
    assert isinstance(value, DictToken)
    assert value.start_position == (1, 0)
    assert value.end_position == (1, len(content))

    # Test of an object with invalid property
    content = '{"hello": "world", "numbers": [1,2,3], "a": false, "b": null}'
    tokenizer = _TokenizingDecoder(content=content)
    value = tokenizer.decode(content)
    assert isinstance(value, DictToken)
    assert value.start_position == (1, 0)
    assert value

# Generated at 2022-06-22 06:19:44.885876
# Unit test for function validate_json
def test_validate_json():
    pass



# Generated at 2022-06-22 06:19:54.287719
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    decode = _TokenizingDecoder(content="Some string").decode
    assert decode('"abc"') == "abc"
    assert decode('{"key1":"val1","key2":"val2"}') == {
        "key1": "val1",
        "key2": "val2",
    }
    assert decode('["v1","v2","v3"]') == ["v1", "v2", "v3"]
    assert decode('123') == 123
    assert decode('123.4') == 123.4
    assert decode('"null"') == "null"
    assert decode('"true"') == "true"
    assert decode('"false"') == "false"
    assert decode('"null"') == "null"

# Generated at 2022-06-22 06:20:04.349352
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid JSON, should not raise an error
    tokenize_json('{"firstName": "John", "lastName": "Smith"}')
    # Invalid JSON, should raise ParseError with code and message
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{"firstName": "John", "lastName": "Smith}')
    assert exc_info.value.code == 'parse_error'
    assert exc_info.value.text == 'Expecting value'
    # Invalid JSON, should raise ParseError with code and message
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('')
    assert exc_info.value.code == 'no_content'
    assert exc_info.value.text == 'No content.'
    # Check line and column

# Generated at 2022-06-22 06:20:13.682594
# Unit test for function validate_json
def test_validate_json():
    input_json = '{"street": "123 St", "city": "Seattle"}'
    schema_class = create_schema_class(
        {
            "street": types.string(required=True),
            "city": types.string(required=True),
            "zip": types.string(required=True),
        }
    )

    value, messages = validate_json(input_json, schema_class)
    assert value == {"street": "123 St", "city": "Seattle"}
    assert len(messages) == 1

    message = messages[0]
    assert message.text == "Missing field: zip."
    assert message.code == "missing_field"
    assert message.position.column_no == 3
    assert message.position.line_no == 1
    assert message.position.char_index == 3

# Generated at 2022-06-22 06:20:37.230567
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json('{"foo": "bar"}'), DictToken)
    assert isinstance(tokenize_json('["foo", "bar"]'), ListToken)
    assert isinstance(tokenize_json('"foo"'), ScalarToken)
    assert isinstance(tokenize_json("1234"), ScalarToken)
    assert isinstance(tokenize_json("1234.5"), ScalarToken)
    assert isinstance(tokenize_json("1234e6"), ScalarToken)
    assert isinstance(tokenize_json("true"), ScalarToken)
    assert isinstance(tokenize_json("null"), ScalarToken)
    assert isinstance(tokenize_json("false"), ScalarToken)

# Generated at 2022-06-22 06:20:49.494979
# Unit test for function tokenize_json
def test_tokenize_json():
    # Tokenize JSON string
    json_string = '{"name":"John","age":31,"city":"New York"}'
    tokens = tokenize_json(json_string)
    # Tokenize JSON string bytestring
    json_bytestring = b'{"name":"John","age":31,"city":"New York"}'
    tokens_bytes = tokenize_json(json_bytestring)
    # Tokenize empty JSON string
    json_empty = '{"name":"","age":"","city":""}'
    tokens_empty = tokenize_json(json_empty)
    # Tokenize JSON string with parse error
    json_error = '{"name":"John","age":31,"city":"New York"'
    with pytest.raises(ParseError):
        print(tokenize_json(json_error))


# Generated at 2022-06-22 06:20:58.163382
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""
        {
            "foo": {
                "bar": 1
            }
        }
    """)
    assert isinstance(token, DictToken)
    assert token.keys() == {"foo"}
    foo_value = token.get("foo")
    assert isinstance(foo_value, DictToken)
    assert foo_value.keys() == {"bar"}
    bar_value = foo_value.get("bar")
    assert isinstance(bar_value, ScalarToken)
    assert bar_value.value == 1


# Generated at 2022-06-22 06:21:08.790810
# Unit test for function validate_json
def test_validate_json():
    json_data = '{"a":1}'
    class TestSchema(Schema):
        a = Field(type="integer")
    value, error_messages = validate_json(json_data, TestSchema)
    assert not error_messages
    json_data = '{"a":"one"}'
    value, error_messages = validate_json(json_data, TestSchema)
    assert error_messages[0].text == "Must be a valid integer."
    json_data = '{"a":1, "b":"one"}'
    class TestSchema(Schema):
        a = Field(type="integer", required=True)
        b = Field(type="text", required=False)
    value, error_messages = validate_json(json_data, TestSchema)
    assert not error_messages

# Generated at 2022-06-22 06:21:11.746212
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"\xef\xbb\xbf{") == DictToken(
        {}, 0, 2, "\xef\xbb\xbf{",
    )


# Generated at 2022-06-22 06:21:22.723676
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("42") == ScalarToken(
        42, char_index=0, column_no=1, line_no=1,
    )
    assert tokenize_json("42.5") == ScalarToken(
        42.5, char_index=0, column_no=1, line_no=1,
    )
    assert tokenize_json('"foo"') == ScalarToken(
        "foo", char_index=0, column_no=1, line_no=1,
    )
    assert tokenize_json("true") == ScalarToken(
        True, char_index=0, column_no=1, line_no=1,
    )

# Generated at 2022-06-22 06:21:31.978094
# Unit test for function validate_json
def test_validate_json():
    test_content = """{
  "firstName": "John",
  "lastName": "Smith",
  "age": 25,
  "address": {
    "streetAddress": "21 2nd Street",
    "city": "New York",
    "state": "NY",
    "postalCode": "10021-3100"
  }
}"""

    class AddressSchema(Schema):
        street_address = Field(type="string")
        city = Field(type="string")
        state = Field(type="string")
        postal_code = Field(type="string")

    class ContactSchema(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer")

# Generated at 2022-06-22 06:21:34.341540
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "abcabc"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.content == content


# Generated at 2022-06-22 06:21:45.652346
# Unit test for function validate_json
def test_validate_json():  # pragma: nocover
    validator = Field(type="dict", properties={"foo": {"type": "string"}})
    assert validate_json('{"foo": "bar"}', validator) == ({'foo': 'bar'}, [])
    json_bytes = '{"foo": "bar"}'.encode('utf-8')
    assert validate_json(json_bytes, validator) == ({'foo': 'bar'}, [])
    assert validate_json('{"foo": 1}', validator)[0] is None
    errors = validate_json('{"foo": 1}', validator)[1]
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].code == 'type_mismatch'
    assert errors[0].position.column_no == 9
   

# Generated at 2022-06-22 06:21:56.014940
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer, Date, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        first_name = String(max_length=128)
        last_name = String(max_length=128)
        email = String(max_length=128)
        age = Integer()
        birth_date = Date()
        is_male = Boolean()
        married = Boolean(optional=True)

    content = """{
        "first_name": "John",
        "last_name": "Doe",
        "email": "john@example.com",
        "age": 53,
        "birth_date": "2000-01-28",
        "is_male": true
    }"""

# Generated at 2022-06-22 06:22:08.127627
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder({},"") == None


# Generated at 2022-06-22 06:22:18.344772
# Unit test for function tokenize_json
def test_tokenize_json():
    example = """
{
    "string": "string",
    "number": 123,
    "null": null,
    "bool": true,
    "array": [
        "string",
        123,
        null,
        true,
        {
            "string": "string"
        }
    ],
    "object": {
        "string": "string"
    }
}
"""
    token = tokenize_json(example)
    assert isinstance(token, DictToken)
    assert token.value["array"] == [
        "string",
        123,
        None,
        True,
        {"string": "string"},
    ]

# Generated at 2022-06-22 06:22:19.974610
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(), _TokenizingDecoder)


# Generated at 2022-06-22 06:22:29.632000
# Unit test for function validate_json
def test_validate_json():
    '''
    Validate that this function returns a two-tuple of (value, error_messages)
    '''

    # Validator with error on validation
    class ErrorListSchema(Schema):
        items = [Field(type="string")]

    # Validator that throws error on parse
    class ErrorDictSchema(Schema):
        properties = {"name": Field(type="string")}

    # Validator that throws error on parse
    class ErrorArraySchema(Schema):
        items = Field(type="string")

    # Validator that throws error on parse
    class ErrorStringSchema(Schema):
        properties = {"name": "string"}

    # Validation with no parse or validation errors
    class ValidListSchema(Schema):
        items = [Field(type="string")]


# Generated at 2022-06-22 06:22:39.326213
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from json.decoder import JSONDecoder
    from typesystem.tokenize.tokens import ScalarToken, DictToken, ListToken
    from typesystem.tokenize.json_decoder import _TokenizingDecoder

    # We need to override the constructor of JSONDecoder in the unit test, because
    # the super constructor of JSONDecoder takes an extra parameter "encoding" which
    # is not included in the official document, so we cannot pass in test cases of
    # JSONDecoder directly to _TokenizingDecoder.
    class_name = "_TokenizingDecoder"
    target_constructor = getattr(_TokenizingDecoder, "__init__")
    target_source = inspect.getsource(target_constructor)
    subset_source = target_source[target_source.find(class_name):]

# Generated at 2022-06-22 06:22:48.817121
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={"name": Field(type="string"), "age": Field(type="number")})

    # Passing examples
    assert_equal(validate_json(b'{"name": "foo", "age": 42}', schema), ({"name": "foo", "age": 42}, []))
    assert_equal(validate_json('{"name": "foo", "age": 42}', schema), ({"name": "foo", "age": 42}, []))
    assert_equal(validate_json(b'{"name": "foo"}', schema), ({"name": "foo"}, []))
    assert_equal(validate_json('{"name": "foo"}', schema), ({"name": "foo"}, []))

    # Failing examples
    #   - Invalid JSON

# Generated at 2022-06-22 06:22:59.889465
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases taken from the json module unit tests.
    class TestJson(unittest.TestCase):
        def test_tokenize_json(self):
            with self.assertRaisesRegex(ParseError, r"No content\."):
                tokenize_json("")

            with self.assertRaisesRegex(ParseError, r"Expecting.*'\}' delimiter"):
                tokenize_json("{\"foo\":1,}")

            with self.assertRaisesRegex(ParseError, r"Unexpected.*'\}' delimiter"):
                tokenize_json("{\"foo\":1]")

            with self.assertRaisesRegex(ParseError, r"Expecting.*'\]' delimiter"):
                tokenize_json("[\"foo\",]")


# Generated at 2022-06-22 06:23:07.491539
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"hello": ["world", "!"]}'
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert result.keys() == ["hello"]
    assert isinstance(result["hello"], ListToken)
    assert result["hello"].values() == ["world", "!"]
    assert result["hello"][0] == "world"
    assert result["hello"][1] == "!"
    assert result.values() == [result["hello"]]



# Generated at 2022-06-22 06:23:16.336895
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(
        '{"a": {"b": {"c": [{"d": 1, "e": "value"}, {"f": {"g": null}}]}}, "h": ["ijkl"]}'
    ) == {
        "a": {
            "b": {
                "c": [{"d": 1, "e": "value"}, {"f": {"g": None}}]
            }
        },
        "h": ["ijkl"],
    }
    assert tokenize_json('{"hello": "world"}') == {"hello": "world"}



# Generated at 2022-06-22 06:23:25.607815
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:23:42.736768
# Unit test for function validate_json
def test_validate_json():
    # Invalid JSON content
    invalid_json = b'{"a": 2, "b": true} '
    # This is an empty value
    invalid_value = b"\x00\x00"

    validator = Field(type="string")

    value, error_messages = validate_json(invalid_json, validator)
    assert error_messages == [
        Message(
            code="parse_error",
            text="Extra data: line 1 column 14 (char 14)",
            position=Position(column_no=14, line_no=1, char_index=14),
        )
    ]
    value, error_messages = validate_json(invalid_value, validator)

# Generated at 2022-06-22 06:23:43.664191
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__

# Generated at 2022-06-22 06:23:52.498851
# Unit test for function validate_json
def test_validate_json():
    test_field = Field()
    test_field.parse_json = lambda x: int(x)

    assert validate_json('1', test_field) == (1, None)
    assert validate_json('"1"', test_field) == (1, None)
    assert validate_json('["1", "1", "1"]', test_field) == ([1, 1, 1], None)
    assert validate_json('{"1": "1", "2": "2", "3": "3"}', test_field) == ({1: 1, 2: 2, 3: 3}, None)

# Generated at 2022-06-22 06:24:01.571878
# Unit test for function tokenize_json
def test_tokenize_json():
    def test(input_string, expected_output_string):
        actual_output = tokenize_json(input_string).to_primitive()
        assert(actual_output == expected_output_string)
    test('{"a": 1}', '{"a": 1}')
    test('{"b": "my-string"}', '{"b": "my-string"}')
    test('{"a": 1, "b": "my-string"}', '{"a": 1, "b": "my-string"}')
    test('{"a": 1, "c": {"d": 3.2}}', '{"a": 1, "c": {"d": 3.2}}')

# Generated at 2022-06-22 06:24:12.126235
# Unit test for function validate_json
def test_validate_json():
    content = '{"password":"password"}'
    validator = Schema({"password": "string"})
    value, errors = validate_json(content,validator)
    assert len(errors) == 0
    content = '{"password":""}'
    validator = Schema({"password": "string"})
    value, errors = validate_json(content,validator)
    assert len(errors) == 1
    content = '{"password":""}'
    validator = Schema({"password": "string"})
    validate_json(content,validator)

if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-22 06:24:18.562293
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("1", Field(type="number")) == (
        1,
        [],
    )
    assert validate_json("null", Field()) == (None, [])
    assert validate_json("1", Field(type="string")) == (
        None,
        [
            ValidationError(
                text="Expected a string.",
                code="type_error",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

# Generated at 2022-06-22 06:24:28.125108
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.json_schema import JsonSchemaDraft4Validator

    # Schema is required to perform validation.
    class MySchema(Schema):
        name = String(max_length=10)

    # Default message type is ValidationError
    @MySchema.validator
    def validate_name(instance: MySchema, field: String) -> None:
        if len(field.value) < 3:
            raise ValidationError("Name must be at least 3 characters long.")

    content = '{"name": "short"}'
    value, error_messages = validate_json(content, MySchema)
    assert value == {"name": "short"}
    assert len(error_messages) == 1
    assert error_mess

# Generated at 2022-06-22 06:24:38.634876
# Unit test for function validate_json
def test_validate_json():
    # Test case for content type bool
    content = b'{"hello": true}'
    validator = {Field("hello"): bool}
    assert validate_json(content, validator) == ({'hello': True}, [])
    # Test case for content type int
    content = b'{"hello": 10}'
    validator = {Field("hello"): int}
    assert validate_json(content, validator) == ({'hello': 10}, [])
    # Test case for content type float
    content = b'{"hello": 10.5}'
    validator = {Field("hello"): float}
    assert validate_json(content, validator) == ({'hello': 10.5}, [])
    # Test case for content type str
    content = b'{"hello": "abcd"}'

# Generated at 2022-06-22 06:24:43.963684
# Unit test for function tokenize_json
def test_tokenize_json():
    string = '{"a": 1, "b": 2}'
    token = tokenize_json(string)
    assert token == {
        "a": ScalarToken(1, 2, 4, string),
        "b": ScalarToken(2, 11, 13, string),
    }


# Generated at 2022-06-22 06:24:45.339997
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert '"test"'


# Generated at 2022-06-22 06:24:55.521767
# Unit test for function validate_json
def test_validate_json():
    class PersonSchema(Schema):
        name = String()

    validation_result = validate_json(
        content={
            "name":"Martin" 
        },
        validator=PersonSchema,
    )

    assert validation_result.value == {"name":"Martin"}
    assert len(validation_result.errors) == 0

# Generated at 2022-06-22 06:24:59.253705
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenized_json = _TokenizingDecoder(content='json')
    assert 'json' == tokenized_json.content


# Generated at 2022-06-22 06:25:10.582118
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads

    assert loads(
        """
            {
                "foo": "bar",
                "baz": "qux",
                "xyzzy": ["a", "b", "c", {"a": null}]
            }
    """
    ) == tokenize_json(
        """
            {
                "foo": "bar",
                "baz": "qux",
                "xyzzy": ["a", "b", "c", {"a": null}]
            }
    """
    )

# Generated at 2022-06-22 06:25:20.467010
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 0, 5, '{"foo": "bar"}')},
        0,
        13,
        '{"foo": "bar"}',
    )
    try:
        # invalid JSON
        tokenize_json("{")
    except ParseError as exc:
        assert exc.position.char_index == 0
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
    try:
        # invalid JSON
        tokenize_json("}")
    except ParseError as exc:
        assert exc.position.char_index == 0
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1

# Generated at 2022-06-22 06:25:22.753259
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert (decoder.scan_once)


# Generated at 2022-06-22 06:25:35.041548
# Unit test for function tokenize_json
def test_tokenize_json():
    actual = tokenize_json('{"a" : {"b" : ["c", false, null, true, 123.4, -123]}}')

# Generated at 2022-06-22 06:25:47.929787
# Unit test for function tokenize_json
def test_tokenize_json():
    content1 = '{"a": "1", "b": 2, "c": [3, 4], "d": {"e": 5}}'
    # Test simple JSON object
    assert tokenize_json(content1) == DictToken({
        'a': ScalarToken('1', 3, 5, content1),
        'b': ScalarToken(2, 11, 12, content1),
        'c': ListToken([ScalarToken(3, 20, 21, content1), ScalarToken(4, 23, 24, content1)], 19, 25, content1),
        'd': DictToken({
            'e': ScalarToken(5, 34, 35, content1)
        }, 33, 36, content1)
    }, 0, 36, content1)
    # Test simple JSON array

# Generated at 2022-06-22 06:25:50.527967
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"name": "John", "age": 12}'
    _TokenizingDecoder(content=content)

# Generated at 2022-06-22 06:25:54.954260
# Unit test for function validate_json
def test_validate_json():
    """test validate_json - should raise a ValidationError with error messages"""
    # parse this valid json
    json_string = '{"name": "Elliot Alderson", "companies": ["Allsafe", "EvilCorp"]}'
    # validate it with a Field
    field = Field(type="string")
    with raises(ValidationError):
        validate_json(json_string, field)
    # validate it with a Schema
    with raises(ValidationError):
        class User(Schema):
            name = Field(type="string")
            age = Field(type="integer")
        schema = User()
        validate_json(json_string, schema)


# Generated at 2022-06-22 06:26:05.771631
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    import json

    class AddressSchema(typesystem.Schema):
        line_1 = typesystem.String()
        line_2 = typesystem.String(required=False)
        city = typesystem.String()
        state = typesystem.String()
        zip_code = typesystem.String()
        country = typesystem.String()

    class HomeAddressSchema(AddressSchema):
        primary = typesystem.Boolean(default=False)

    class OfficeAddressSchema(AddressSchema):
        office = typesystem.String()

    class PersonSchema(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        addresses = typesystem.Dictionary(of=typesystem.String(of=typesystem.OneOf(HomeAddressSchema, OfficeAddressSchema)))


# Generated at 2022-06-22 06:26:19.650647
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"foo": "bar"}', {'foo': str}) == (
        {"foo": "bar"},
        [],
    )
    assert validate_json('{"foo": 1}', {'foo': str}) == (
        None,
        [
            ValidationError(
                text="Value '1' (int) is not of type 'string'",
                code='invalid_type',
                position=Position(
                    column_no=10,
                    line_no=1,
                    char_index=9,
                ),
                validator="string",
                value=1,
                validator_value=None,
                path=["foo"],
            )
        ],
    )

# Generated at 2022-06-22 06:26:23.040477
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    mydecoder = JSONDecoder(content="this is content")
    mydecoder2 = _TokenizingDecoder(content="this is content")
    assert mydecoder2.scan_once is None


# Generated at 2022-06-22 06:26:24.155572
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")

# Generated at 2022-06-22 06:26:26.776294
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    decoder.scan_once("test", 0)
    assert True

# Generated at 2022-06-22 06:26:39.482101
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"x":1}') == DictToken({ScalarToken('x',0,2, '{"x":1}'): ScalarToken(1,5,5, '{"x":1}')},0,7,'{"x":1}')
    assert tokenize_json('[1]') == ListToken([ScalarToken(1,1,1,'[1]')],0,2,'[1]')
    assert tokenize_json('[1,2]') == ListToken([ScalarToken(1,1,1,'[1,2]'), ScalarToken(2,3,3,'[1,2]')],0,5,'[1,2]')

# Generated at 2022-06-22 06:26:50.056404
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        {
            "name": "Person",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
                "is_happy": {"type": "boolean"},
            },
        }
    )
    content = '{"name": "Joanna", "age": 18, "is_happy": true}'
    value, errors = validate_json(content, schema)
    assert value == {"name": "Joanna", "age": 18, "is_happy": True}
    assert not errors

    content = "some-invalid-json"
    with pytest.raises(ParseError) as exc:
        validate_json(content, schema)
    assert isinstance(exc.value.messages[0], ParseError)


# Generated at 2022-06-22 06:26:52.760281
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"a":1}')
    assert decoder.object_hook == dict



# Generated at 2022-06-22 06:27:04.896004
# Unit test for function tokenize_json
def test_tokenize_json():
    # Asking for a list but getting a dict
    with pytest.raises(ParseError) as exc:
        tokenize_json('{"model_id":"some_model_id","rows":[{"some_field":"some_value"}]}')
    assert "Expecting value" in exc.value.text
    assert exc.value.position.line_no == 1
    assert exc.value.position.column_no == 12
    assert exc.value.position.char_index == 11
    assert exc.value.code == "parse_error"

    # Asking for a dict but getting a list
    with pytest.raises(ParseError) as exc:
        tokenize_json(
            '{"model_id":"some_model_id","rows":[{"model_id":"some_model_id","rows":[]}]}'
        )

# Generated at 2022-06-22 06:27:07.389474
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """Should obey parent's constructor"""
    context = _TokenizingDecoder()
    assert isinstance(context, JSONDecoder)


# Generated at 2022-06-22 06:27:19.289893
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String
    from typesystem.tokenize.decoder import tokenize_json
    token = tokenize_json(b'{"name":"Greg Junge", "age":35}')
    fields = {"name": String(), "age": String()}
    assert token.validate(fields) == {
        "name": "Greg Junge",
        "age": "35",
    }
    assert type(token) == DictToken
    sub_tokens = token.items()
    assert len(sub_tokens) == 2
    name, age = sub_tokens
    assert type(name[0]) == ScalarToken
    assert type(age[0]) == ScalarToken
    assert type(name[1]) == ScalarToken
    assert type(age[1]) == ScalarToken



# Generated at 2022-06-22 06:27:35.034473
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"string":"foo","integer":3,"number":3.14159,"boolean":true,"null":null,"list":[1,2,3],"dict":{"foo":"bar"},"inner":{"inner2":"a"}}'
    json_token = tokenize_json(json_str)
    assert json_token.value == {
        'string': 'foo',
        'integer': 3,
        'number': 3.14159,
        'boolean': True,
        'null': None,
        'list': [1, 2, 3],
        'dict': {'foo': 'bar'},
        'inner': {'inner2': 'a'}
    }



# Generated at 2022-06-22 06:27:46.288488
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    For testing, a local copy of tokenize_json is defined above.
    """
    import json
    # TODO: More fully test this function and handle edge cases.
    # Currently relying on the underlying json package and an
    # assumption that it is well tested and maintained.
    content = """
        {
          "key1": [true, false, null, false, true],
          "key2": { "key1": {}, "key2": [] },
          "key3": [ null ]
        }
    """
    value = json.loads(content)
    assert tokenize_json(content) == value
    assert tokenize_json("{}") == {}
    assert tokenize_json("[]") == []


# Generated at 2022-06-22 06:27:57.089529
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer, Object, String
    from typesystem.schemas import Schema
    from typesystem.structures import BaseDict
    from typesystem.tokenize.positional_validation import PositionalValidationError

    validator = Schema(fields={"pk": Integer(), "name": String()})

    json_str = '{"pk": 1, "name": "1"}'
    value, error_messages = validate_json(json_str, validator)
    assert value == {"pk": 1, "name": "1"}
    assert not error_messages

    json_str = '{"pk": "1", "name": "1"}'
    value, error_messages = validate_json(json_str, validator)

# Generated at 2022-06-22 06:28:05.639428
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:28:11.804620
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:28:16.932896
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {'foo': ScalarToken('bar', 8, 12, '{"foo": "bar"}')}, 0, 14, '{"foo": "bar"}'
    )



# Generated at 2022-06-22 06:28:27.311882
# Unit test for function validate_json
def test_validate_json():
    # Parse and validate a JSON string, returning positionally marked error
    # messages on parse or validation failures.
    content = '{"test":"test"}'
    validator = Schema({"test":  "text"})
    assert (validate_json(content, validator)) == ({'test': 'test'}, [])
    content = '[1, 2, 3]'
    validator = Schema([1, 2, 3])
    assert (validate_json(content, validator)) == ([1, 2, 3], [])
    content = '{"test":"text"}'
    validator = Schema({"test":  "text"})
    assert (validate_json(content, validator)) == ({'test': 'text'}, [])
    content = '{"test":[1, 2, 3]}'
    validator = Sche