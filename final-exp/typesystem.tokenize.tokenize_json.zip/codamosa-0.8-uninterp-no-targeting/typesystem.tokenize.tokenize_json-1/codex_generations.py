

# Generated at 2022-06-22 06:18:44.808638
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """{
    "content": "",
    "docs": []
    }"""
    tokens = tokenize_json(json)
    assert isinstance(tokens, DictToken)
    assert isinstance(tokens.children["docs"], ListToken)
    assert tokens.children["docs"].children[0] is None



# Generated at 2022-06-22 06:18:46.918124
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    result = _TokenizingDecoder(content='{"a": 1, "b": 2}')
    expected = _TokenizingDecoder.__init__
    assert result == expected

# Generated at 2022-06-22 06:18:58.984254
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json handles the empty string case.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "ParseError not raised"

    # Test that tokenize_json raises an error with position information when
    # given malformed input.
    try:
        tokenize_json("{")
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1

# Generated at 2022-06-22 06:19:10.771345
# Unit test for function validate_json
def test_validate_json():
    import typesystem

    content = """
    {
        "my_field": [
            {
                "foo": 1
            },
            {
                "bar": "hello"
            },
            {
                "baz": 3
            }
        ]
    }
    """

    expected_messages = [
        Message(
            position=Position(
                line_no=8, column_no=9, char_index=59,
            ),
            text="Must be a string.",
            code="string",
        ),
        Message(
            position=Position(
                line_no=7, column_no=9, char_index=49,
            ),
            text="Must be an integer.",
            code="integer",
        ),
    ]


# Generated at 2022-06-22 06:19:22.514884
# Unit test for function validate_json
def test_validate_json():
    success_example = """{
        "name": "John",
        "age": 70,
        "address": {
            "street": "3rd Ave",
            "city": "New York"
        },
        "phone": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "office",
                "number": "645 555-4567"
            },
            {
                "type": "mobile",
                "number": "917 555-1234"
            }
        ]
    }"""
    success_value, success_errors = validate_json(
        content=success_example, validator=Field(type="object")
    )
    assert not success_errors


# Generated at 2022-06-22 06:19:32.558180
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ScalarToken(None, 0, 0, "")
    assert tokenize_json(" ") == ScalarToken(None, 0, 1, " ")
    assert tokenize_json("""{}""") == DictToken({}, 0, 2, """{}""")
    assert tokenize_json("""{"a": 1}""") == DictToken(
        {"a": ScalarToken(1, 4, 5, """{"a": 1}""")}, 0, 9, """{"a": 1}"""
    )

# Generated at 2022-06-22 06:19:37.180911
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    t = _TokenizingDecoder(content="a")
    assert t.scan_once(content="",idx=0) == (None, 0)
    assert t.scan_once(content="a",idx=0) == (None, 0)
    assert t.scan_once(content="abcdf",idx=0) == (None, 0)


# Generated at 2022-06-22 06:19:47.556000
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # test constructor of parent class:
    json_decoder = JSONDecoder()
    # test constructor of current class:
    tokenizing_decoder = _TokenizingDecoder(content="hello")
    # test instance attributes:
    assert tokenizing_decoder.encoding == json_decoder.encoding
    assert tokenizing_decoder.object_hook == json_decoder.object_hook
    assert tokenizing_decoder.parse_float == json_decoder.parse_float
    assert tokenizing_decoder.parse_int == json_decoder.parse_int
    assert tokenizing_decoder.parse_constant == json_decoder.parse_constant
    assert tokenizing_decoder.strict == json_decoder.strict
    assert tokenizing_decoder.object_pairs_hook == json_decoder.object

# Generated at 2022-06-22 06:20:00.155004
# Unit test for function validate_json
def test_validate_json():
    """
    Function to test validate_json function
    """
    class MovieSchema(Schema):
        """
        movie schema
        """
        title = fields.String(min_length=2)
        year = fields.Integer(minimum=1900, maximum=2099)

    content = '{"title": "Star Wars", "year": 1977}'
    value, errors = validate_json(content, MovieSchema)
    assert value == {"title": "Star Wars", "year": 1977}
    assert not errors

    content = '{"title": "Star Wars Episode IV", "year": "1977"}'
    value, errors = validate_json(content, MovieSchema)
    assert value == {
        "title": "Star Wars Episode IV",
        "year": "1977",
    }

# Generated at 2022-06-22 06:20:02.543800
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder()
    return tokenizing_decoder

# Generated at 2022-06-22 06:20:19.464182
# Unit test for function validate_json
def test_validate_json():
    token = tokenize_json('{"name": "test", "age": 7}')
    class TestSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    validator = TestSchema()
    value, messages = validate_json(token, validator)
    assert value == {"name": "test", "age": 7}
    assert not messages

# Generated at 2022-06-22 06:20:27.173646
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar", "baz": [1, 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.children["foo"], ScalarToken)
    assert isinstance(token.children["baz"], ListToken)
    assert token.children["foo"].value == "bar"
    assert token.children["baz"].value == [1, 2, 3]



# Generated at 2022-06-22 06:20:37.273649
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test case for a JSON object without nested objects
    actual = tokenize_json('{"name": "Ran", "age": 30}')
    expected = DictToken.from_dict({"name": "Ran", "age": 30}, 0, 27, '{"name": "Ran", "age": 30}')
    assert actual ==  expected

    # Test case for a JSON object with nested objects
    actual = tokenize_json('{"name": "Ran", "location": {"lat": 30.044, "lon": 29.814}}')

# Generated at 2022-06-22 06:20:41.246776
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    content = '{"a":1}'

    try:
        _TokenizingDecoder(content=content)
    except JSONDecodeError as exc:
        assert False


if __name__ == "__main__":
    test__make_scanner()

# Generated at 2022-06-22 06:20:45.607000
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # The __init__ method of the JSONDecoder class is called, so the constructor
    # of _TokenizingDecoder is tested through that constructor.
    result = _TokenizingDecoder(content="content")
    assert type(result) == _TokenizingDecoder
    assert result.content == "content"


# Generated at 2022-06-22 06:20:49.970956
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_token(token):
        assert token.token_type in ['dict', 'list', 'scalar']
        for child in token.children:
            assert_token(child)

    token = tokenize_json('{"name": "Edgar"}')
    assert_token(token)

# Generated at 2022-06-22 06:21:00.545693
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    import types
    from json.decoder import JSONDecoder
    content = '{"name":"dk","age":23}'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)
    assert hasattr(decoder, 'scan_once')
    assert isinstance(decoder.scan_once, types.MethodType)
    value, position = decoder.scan_once(content, 0)
    assert isinstance(value, DictToken)
    assert isinstance(position, int)
    #assert isinstance(decoder.scan_once, types.MethodType)
    #assert decoder.scan_once(content, 0) == json.loads(content)



# Generated at 2022-06-22 06:21:10.561786
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for a basic dict
    content = '{"protocol_id": "SIP", "name": "SIP", "description": "SIP", "attributes": {"allow": ["INVITE", "ACK", "OPTIONS", "CANCEL", "BYE", "SUBSCRIBE", "NOTIFY", "INFO", "REFER", "UPDATE", "MESSAGE", "PING" ], "protocol_id": "SIP", "protocol_name": "SIP", "service_id": 4, "service_name": "SIP"} }'
    token = tokenize_json(content)
    assert token.start == 0
    assert token.end == len(content)
    assert token.type == "dict"

# Generated at 2022-06-22 06:21:21.809709
# Unit test for function validate_json
def test_validate_json():
    def validate_json(data, validator):
        try:
            value = validator.validate(data)
        except ValidationError as exc:
            return (False, exc.messages)
        else:
            return (True, None)

    validator = fields.Dict({"title": fields.String})
    data = {"title": "How To Train Your Dragon"}
    assert validate_json(data, validator) == (True, None)

    data = {"title": 3}

# Generated at 2022-06-22 06:21:26.064764
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "value"}'
    token = tokenize_json(content)
    assert token == DictToken(
        {"name": ScalarToken("value", 10, 15, content)}, 0, 14, content
    )



# Generated at 2022-06-22 06:21:47.197097
# Unit test for function validate_json
def test_validate_json():
    assert list(validate_json(content = '{"foo": 1, "bar": -2}', validator = {"foo": "integer", "bar": "integer"})) == [None, []]
    assert list(validate_json(content = '{"foo": 1, "bar": "baz"}', validator = {"foo": "integer", "bar": "integer"})) == [None, [Message(code='type_error', position=Position(line_no=1, column_no=14, char_index=13), text='Value must be an integer.')]]

# Generated at 2022-06-22 06:21:50.952331
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  decoder = _TokenizingDecoder(parse_int=int, parse_float=float, parse_array=JSONDecoder.raw_decode, parse_string=scanstring, strict=False, content="")
  assert(decoder.scan_once == _make_scanner(decoder, ""))


# Generated at 2022-06-22 06:21:54.196188
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name":"example.com"}'
    validator = Schema(
        {"name": Field(types="string")}
    )
    value, errors = validate_json(content, validator)
    assert value is not None
    assert errors is None


# Generated at 2022-06-22 06:21:59.746154
# Unit test for function validate_json
def test_validate_json():
    validator = Field(name="email", type='string')
    content = '{"email": "test@example.com"}'
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 0
    content = '{"email": 123}'
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1



# Generated at 2022-06-22 06:22:10.730346
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name": "John Smith", "age": 43}'
    validator = Schema(
        {
            "name": Field(description="Name of the person."),
            "age": Field(description="Age of the person."),
        }
    )
    value, error_messages = validate_json(content, validator)
    assert {
        "name": "John Smith",
        "age": 43,
    } == value
    assert 0 == len(error_messages)

    content = b'{"name": "John Smith", "age": "43"}'
    value, error_messages = validate_json(content, validator)

# Generated at 2022-06-22 06:22:23.562259
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ScalarToken
    from schemas import TestSchema

    # Test regular valid case
    json_string = '{"test": "hi"}'
    token = tokenize_json(json_string)
    assert token == DictToken(
        {
            ScalarToken("test", 1, 5, json_string): ScalarToken("hi", 9, 12, json_string)
        },
        0,
        13,
        json_string,
    )
    assert validate_json(json_string, TestSchema) == (
        {"test": "hi"},
        [],
    )
    # Test invalid value type
    json_string = '{"test": 1}'
   

# Generated at 2022-06-22 06:22:25.727153
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder()
    assert d.scan_once is not None

# Generated at 2022-06-22 06:22:35.840157
# Unit test for function tokenize_json
def test_tokenize_json():
    # Create test data with json string and expected output
    testData = {"{}": {"type": "dict", "start": 0, "end": 1},
                '{"key": 1}': {"type": "dict", "start": 0, "end": 9},
                '[1]': {"type": "list", "start": 0, "end": 2},
                '{"key": [1,2]}': {"type": "dict", "start": 0, "end": 14},
                '[{"key": 1}, {"key": 2}]': {"type": "list", "start": 0, "end": 28}}
    for jsonString, expectedValues in testData.items():
        # Get the tokens from the json string
        tokens = tokenize_json(jsonString)
        # Generate output string
        assert tokens.type == expectedValues["type"] and tokens

# Generated at 2022-06-22 06:22:45.600644
# Unit test for function validate_json
def test_validate_json():
    import json
    import typesystem
    from typesystem import fields

    class Person(typesystem.Schema):
        name = fields.String(format="name")
        age = fields.Integer(gte=18)
        data = fields.Dict(fields={"password": fields.String(min_length=10)})

    content_1 = json.dumps({"name": "Jane Doe", "age": 20})
    value, error_messages = validate_json(content_1, Person)

    assert value["data"] == {"password": "password"}
    assert error_messages == []

    content_2 = json.dumps({"name": "Jane Doe", "age": 17, "data": None})
    value, error_messages = validate_json(content_2, Person)


# Generated at 2022-06-22 06:22:47.934706
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = u""
    decoder = _TokenizingDecoder(content=content)
    assert (decoder.content == "")



# Generated at 2022-06-22 06:23:21.875309
# Unit test for function validate_json
def test_validate_json():
    test_cases = [
        (
            '{"address": "1234", "phone_numbers": ["456-7890", "123-4567"]}', 
            { 
                "address": str, 
                "phone_numbers": [str] 
            }
        ),
        (
            '{"address": "1234", "phone_numbers": ["456-7890", 123]}', 
            { 
                "address": str, 
                "phone_numbers": [str] 
            }
        ),
        (
            '{"address": "1234", "phone_numbers": "456-7890", "bar": null}', 
            { 
                "address": str, 
                "phone_numbers": [str] 
            }
        ),
    ]

# Generated at 2022-06-22 06:23:29.465737
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "Alice", "age": 21}'
    field = Field(type="string", required=True)
    value, err_msgs = validate_json(content, field)
    assert err_msgs[0].text == "Expected a string but found a dict"
    content = '{"name": "Alice", "age": 21}'
    err_msgs = validate_json(content, UserSchema).as_errors
    assert len(err_msgs) == 1
    assert err_msgs[0].position == Position(column_no=16, line_no=1, char_index=15)
    


# Generated at 2022-06-22 06:23:32.831996
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="{'a':1}")
    assert decoder.content == "{'a':1}"


# Generated at 2022-06-22 06:23:37.743494
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"a": 1}"""
    result = tokenize_json(content)
    assert result == DictToken(value={"a": ScalarToken(value=1, start=4, end=5, content=content)}, start=0, end=6, content=content)



# Generated at 2022-06-22 06:23:49.862138
# Unit test for function validate_json
def test_validate_json():
    json_str = '{"key" : "value"}'
    validator = Field(type="string", max_length=10)
    value, messages = validate_json(json_str, validator)
    assert value == 'value'
    assert not messages
    json_str = '{"key" : "extremely_long_value"}'
    value, messages = validate_json(json_str, validator)
    assert value == 'extremely_long_value'
    assert len(messages) == 1
    assert messages[0].code == "max_length"
    assert messages[0].position.column_no == 12
    json_str = '{"key" : {"key" : "value"}}'
    value, messages = validate_json(json_str, validator)
    assert value == {"key" : "value"}

# Generated at 2022-06-22 06:24:02.338347
# Unit test for function validate_json
def test_validate_json():
    """Testing validate_json()"""
    from typesystem import std
    import json
    import pytest
    # Testing success
    schema = std.Schema(
        properties={
            "foo": std.String(),
            "bar": std.Integer(),
            "baz": std.Boolean(),
            "bat": std.Dictionary(properties={"bam": std.Integer()}),
        }
    )
    obj = {
        "foo": "foo",
        "bar": 42,
        "baz": True,
        "bat": {"bam": 42},
    }
    content = json.dumps(obj)
    value, errors = validate_json(content, validator=schema)
    assert value == obj
    assert errors == []

    # Testing failures
    token = tokenize_json(content)


# Generated at 2022-06-22 06:24:04.494600
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizingDecoder = _TokenizingDecoder(None, None)
    assert tokenizingDecoder != None
    assert type(tokenizingDecoder) == _TokenizingDecoder


# Generated at 2022-06-22 06:24:15.811363
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(
        """{
            "name":"John Smith",
            "address":{
                "city": "Berkeley",
                "state": "CA"
            },
            "is_cool":true,
            "fav_nums": [1, 2.1, 3.14],
            "created_at": "2017-03-02T15:16:17+00:00",
            "has_children": false,
            "test_none": null
        }"""
    )
    assert type(token) == DictToken
    assert token.key == "content"
    assert token.position.column_no == 1
    assert token.position.line_no == 1

    assert len(token.value) == 7

# Generated at 2022-06-22 06:24:26.590841
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:37.134083
# Unit test for function validate_json
def test_validate_json():
    assert(validate_json('{"foo": "bar"}', Schema({'type': 'object'})) ==
           ({'foo': 'bar'}, []))
    assert(validate_json('{"foo": "bar"}', Schema({
        'type': 'object',
        'properties': {
            'foo': {
                'type': 'integer'
            }
        }
    })) == (
        {'foo': 'bar'},
        [
            Message(
                text='Must be an integer.',
                code='type',
                position=Position(
                    column_no=8,
                    line_no=0,
                    char_index=8,
                ),
            )
        ]
    ))

# Generated at 2022-06-22 06:24:50.022178
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '[{"test": [1, 2]}, {"test": [3]}]'
    token = tokenize_json(json_str)
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], DictToken)
    assert isinstance(token.value[0].value["test"], ListToken)
    assert token.value[0].value["test"].value == [1, 2]



# Generated at 2022-06-22 06:24:57.273708
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
            "name": "James",
            "age": 32
        }"""
    expected_token = DictToken(
        {
            "name": ScalarToken("James", 33, 38, content),
            "age": ScalarToken(32, 50, 51, content),
        },
        0,
        53,
        content,
    )
    token = tokenize_json(content)
    assert token == expected_token


# Generated at 2022-06-22 06:25:08.858192
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    schema = typesystem.Schema(
        fields={
            "username": typesystem.String(max_length=10),
            "password": typesystem.String(max_length=10),
            "age": typesystem.Integer(minimum=0, maximum=120),
            "is_active": typesystem.Boolean(),
        }
    )
    json_data = """{
        "username": "eddiegachet",
        "password": "supersecret",
        "age": 10,
        "is_active": true
    }"""
    clear_json_data = """{
        "username": "eddiegachet",
        "password": "supersecret",
        "age": 10
    }"""
    value, errors = validate_json(json_data, schema)
    assert len(errors) == 0

# Generated at 2022-06-22 06:25:10.182288
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder('{}')


# Generated at 2022-06-22 06:25:17.220490
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    Decoder = _TokenizingDecoder('""', object_pairs_hook=dict)
    assert Decoder.parse_string == scanstring
    assert Decoder.parse_array == JSONDecoder.parse_array
    assert Decoder.parse_float == JSONDecoder.parse_float
    assert Decoder.parse_int == JSONDecoder.parse_int
    assert Decoder.parse_object == _TokenizingJSONObject
    assert Decoder.strict is True
    assert Decoder.memo == {}



# Generated at 2022-06-22 06:25:20.483837
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key": "value"}'
    decoder = _TokenizingDecoder(object_hook=lambda key:key, content=content)
    assert(decoder.scan_once)
    
    

# Generated at 2022-06-22 06:25:32.827390
# Unit test for function validate_json
def test_validate_json():
    from . import verify
    # Invalid JSON
    with pytest.raises(ParseError):
        validate_json(b'{"foo": "bar"\nInvalid JSON', "string")
    # Valid JSON
    verify(validate_json(b'{"foo": "bar"}', "string"))
    # Valid JSON with a null
    verify(validate_json(b'{"foo": null}', "string"))
    # Valid JSON with a number
    verify(validate_json(b'{"foo": 100}', "string"))
    # Valid JSON with a boolean
    verify(validate_json(b'{"foo": true}', "string"))
    # Valid JSON with an array
    verify(validate_json(b'{"foo": ["bar"]}', "string"))
    # Valid JSON with an object

# Generated at 2022-06-22 06:25:41.960574
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import typesystem
    import json

    class SimpleSchema(typesystem.Schema):
        field = typesystem.String()

    content = '{"field": "baz"}'
    decoder = _TokenizingDecoder(content=content)
    try:
        assert content == json.loads(content)
        assert decoder.decode(content) == json.loads(content)
        assert SimpleSchema.validate(content) == json.loads(content)

    except JSONDecodeError as exc:
        print(exc)


# Generated at 2022-06-22 06:25:51.795165
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class User(Schema):
        id = Integer()
        name = String(max_length=5)

    content = b'{"id": "2", "name": "David Moss"}'
    value, msgs = validate_json(content, User)

    # The value returned by validate_json() is the parsed value
    assert value == {"id": 2, "name": "David"}

    # There should be two validation errors
    assert len(msgs) == 2

    # The first validation error is the 'id' field
    assert msgs[0].path == "id"
    assert msgs[0].text.startswith("Must be an integer")

# Generated at 2022-06-22 06:25:55.763837
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key":"value"}'
    decoder = _TokenizingDecoder(content = content)
    val = decoder.decode(content)
    return val


# Generated at 2022-06-22 06:26:19.645383
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({ScalarToken('foo', 2, 4): ScalarToken('bar', 8, 11)}, 0, 14, '{"foo": "bar"}')
    assert tokenize_json('{"foo": [1, 2, 4]}') == DictToken({ScalarToken('foo', 2, 4): ListToken([ScalarToken(1, 8, 8), ScalarToken(2, 10, 10), ScalarToken(4, 12, 12)], 7, 13, '{"foo": [1, 2, 4]}')}, 0, 17, '{"foo": [1, 2, 4]}')

# Generated at 2022-06-22 06:26:23.678772
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"field1\":3,\"field2\":true,\"field3\":false}"
    decoder = _TokenizingDecoder(content=content)
    actual = decoder.scan_once(content, 0)
    assert actual[1] == len(content)



# Generated at 2022-06-22 06:26:36.005340
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest

    field = Field(
        name="name",
        type="string",
        required=True,
        location="path",
        description="this is a description"
    )
    
    schema = Schema([field])
    with pytest.raises(ParseError, match=r".*No content.*"):
        tokenize_json('')
    
    with pytest.raises(ParseError, match=r".*parse_error.*"):
        tokenize_json('''{
            "type": "string",
            "name": "name",
            "required": true,
            "location": "path",
        }''')


# Generated at 2022-06-22 06:26:47.600990
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty input.
    try:
        tokenize_json('')
        assert False
    except ParseError as err:
        assert err.position.char_index == 0
        assert err.position.column_no == 1
        assert err.position.line_no == 1

    # Test for invalid input
    try:
        tokenize_json('{"foo": {')
        assert False
    except ParseError as err:
        assert err.position.char_index == 11
        assert err.position.column_no == 12
        assert err.position.line_no == 1

    # Test for valid input
    result = tokenize_json('{"foo": ["bar"]}')
    assert isinstance(result, DictToken)
    assert isinstance(result.value, dict)

# Generated at 2022-06-22 06:26:49.442605
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    JsonDecoder = _TokenizingDecoder
    assert type(JsonDecoder)


# Generated at 2022-06-22 06:27:00.398035
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    import builtins
    if hasattr(json, "JSONDecodeError"):
        JSONDecodeError = json.JSONDecodeError
    else:
        JSONDecodeError = ValueError

    test_cases = [
        ('{"a": "b"}', {"a": "b"})
    ]

    for i, (source, expected) in enumerate(test_cases):
        try:
            decoder = _TokenizingDecoder(content="")
            result = decoder.decode(source)
        except JSONDecodeError:
            print(i, "Expected:", expected)
            print(i, "Actual:", result)
            raise
        assert result == expected, result


# Generated at 2022-06-22 06:27:05.099460
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ListToken(
        [], line_no=1, column_no=1, char_index=0
    )
    assert tokenize_json("null") == ScalarToken(
        None, line_no=1, column_no=1, char_index=0
    )
    assert tokenize_json("[]") == DictToken({}, line_no=1, column_no=1, char_index=0)
    assert tokenize_json("{}") == ListToken(
        [], line_no=1, column_no=1, char_index=0
    )

# Generated at 2022-06-22 06:27:07.610990
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"title": "The Title", "description": "The Description"}')
    print(result)



# Generated at 2022-06-22 06:27:15.227609
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key1": "value1", "key2": "value2"}'
    # Call method __init__ in class _TokenizingDecoder
    assert _TokenizingDecoder(object_hook=(lambda x: x), content=content).scan_once(content, 0) == (DictToken({'key2': ScalarToken("value2", 16, 27, content), 'key1': ScalarToken("value1", 4, 15, content)}, 0, 27, content), 29)

# Generated at 2022-06-22 06:27:16.617601
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    
    c1 = _TokenizingDecoder(content = "string")
    assert c1.content == "string"
    

# Generated at 2022-06-22 06:27:34.421386
# Unit test for function validate_json
def test_validate_json():
    assert (
        validate_json(
            '{"a": "foo", "b": [1, 2, "bar"], "c": {"d": 3.14, "e": false, "f": null}}',
            {"a": str, "b": [int], "c": {"d": float, "e": bool}})
        == ({"a": "foo", "b": [1, 2, "bar"], "c": {"d": 3.14, "e": False, "f": None}}, [])
    )


# Generated at 2022-06-22 06:27:38.046371
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-22 06:27:46.667312
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class TestSchema(Schema):
        foo = Field(type="string")
        bar = Field(type="integer")
        baz = Field(type="object")
        qux = Field(type="array")

    assert _TokenizingDecoder.__doc__ == JSONDecoder.__doc__
    assert TestSchema.dump({"foo": "bar", "bar": 5, "baz": {}, "qux": []}) == {
        "foo": "bar",
        "bar": 5,
        "baz": {},
        "qux": [],
    }


# Generated at 2022-06-22 06:27:48.598059
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""{ "b": {} }""") == {
        "b": {}
    }



# Generated at 2022-06-22 06:28:00.283451
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"a": 1}'
    token = tokenize_json(json_str)
    assert token.children[0].children[1].value == 1
    assert token.children[0].children[0].value == "a"
    assert token.children[0].children[0].start_position.line_no == 1
    assert token.children[0].children[0].start_position.column_no == 2
    assert token.children[0].children[0].end_position.line_no == 1
    assert token.children[0].children[0].end_position.column_no == 3
    assert token.children[0].children[1].start_position.line_no == 1
    assert token.children[0].children[1].start_position.column_no == 6

# Generated at 2022-06-22 06:28:11.774298
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty json
    token = tokenize_json("")
    assert not token

    # Test for simple json
    token = tokenize_json("{}")
    assert token.typename == 'DictToken'
    assert not token.children

    # Test for simple json with string key
    token = tokenize_json('{"key": 1}')
    assert token.typename == 'DictToken'
    assert len(token.children) == 1
    assert token.children[0].typename == 'ScalarToken'
    assert token.children[0].index == 0
    assert token.children[0].value_index == 1
    assert token.children[0].value == "key"
    assert token.children[0].value_type == "string"

# Generated at 2022-06-22 06:28:22.567550
# Unit test for function validate_json
def test_validate_json():
    import pytest
    import typesystem

    def test_validate_string(data, validator_string, error_msg=None, **kwargs):
        value, messages = validate_json(data, typesystem.String(**kwargs))
        assert 'errors' in messages
        assert messages['errors'] == error_msg

    def test_validate_integer(data, validator_string, error_msg=None, **kwargs):
        value, messages = validate_json(data, typesystem.Integer(**kwargs))
        assert 'errors' in messages
        assert messages['errors'] == error_msg

    def test_validate_number(data, validator_string, error_msg=None, **kwargs):
        value, messages = validate_json(data, typesystem.Number(**kwargs))
        assert 'errors' in messages