

# Generated at 2022-06-22 06:18:50.572507
# Unit test for function validate_json
def test_validate_json():
    _schema = Schema(
        {"foo": int, "bar": {"baz": {"qux": [float], "qix": str}}},
        allow_extra_fields=False,
    )
    content = (
        "{\n"
        '"foo": 1,\n'
        '"bar": {\n'
        '    "baz": {\n'
        '        "qux": [1.1, 2.1, "not a float"],\n'
        '        "qix": "hello"\n'
        "    }\n"
        "}\n"
        "}"
    )
    data, messages = validate_json(content, _schema)
    assert len(messages) == 1
    assert messages[0].position.line_no == 7
    assert messages[0].position

# Generated at 2022-06-22 06:18:54.250006
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder({"a": 1})
    assert isinstance(decoder, JSONDecoder)
    assert decoder.strict is True
    assert not decoder.memo
    assert decoder.parse_float is float


# Generated at 2022-06-22 06:19:08.913803
# Unit test for function validate_json
def test_validate_json():
    import sys
    validator_string = """{
        "type": "string",
        "min_length": 1
    }"""
    validator_long_string = """{
        "type": "string",
        "min_length": 10
    }"""
    validator_int = """{
        "type": "integer",
        "max_value": 10
    }"""
    validator_float = """{
        "type": "number",
        "max_value": 10.0
    }"""
    validator_boolean = """{
        "type": "boolean",
        "blank": false
    }"""
    validator_null = """{
        "type": "null",
        "blank": false
    }"""

# Generated at 2022-06-22 06:19:11.866755
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenized_json = tokenize_json(b'{"f": "test"}')
    assert isinstance(tokenized_json, DictToken)
    assert tokenized_json.value["f"].value == "test"



# Generated at 2022-06-22 06:19:16.921654
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value["foo"], ScalarToken)
    assert token.value["foo"].value == "bar"



# Generated at 2022-06-22 06:19:18.374612
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content='test')


# Generated at 2022-06-22 06:19:26.221303
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '[null]'
    decoder = _TokenizingDecoder(content=content)
    assert(isinstance(decoder, _TokenizingDecoder))
    assert(decoder.parse_int == int)
    assert(decoder.parse_float == float)
    assert(decoder.parse_constant == JSONDecoder.parse_constant)
    assert(decoder.strict == True)
    assert(decoder.object_hook == JSONDecoder.object_hook)
    assert(decoder.object_pairs_hook == JSONDecoder.object_pairs_hook)
    # test the scan_once function
    assert(isinstance(decoder.scan_once, types.FunctionType))
    scan_once = decoder.scan_once
    value, end = scan_once(content, 0)

# Generated at 2022-06-22 06:19:32.415779
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"type": "integer", "minimum": 1, "maximum": 10}')
    value = {'type': 'integer', 'minimum': 1, 'maximum': 10}
    assert value == token.value

    type(token)
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 45



# Generated at 2022-06-22 06:19:34.825386
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class AddOne():
        pass

    decoder = _TokenizingDecoder(object_hook=AddOne)
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_string == scanstring
    assert decoder.strict == True
    assert decoder.object_hook == AddOne
    assert not isinstance(decoder, JSONDecoder)



# Generated at 2022-06-22 06:19:36.688189
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d=_TokenizingDecoder("", "")
    assert type(d)==JSONDecoder

# Generated at 2022-06-22 06:19:55.167989
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    global _TokenizingDecoder
    from typesystem.tokenize.tokens import tokenize_json
    content = '[{"name": "helloworld"}]'
    token = tokenize_json(content)
    assert token.value[0]['name'].value == 'helloworld'


# Generated at 2022-06-22 06:20:03.816011
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string case
    content = ''
    try:
        tokenize_json(content)
    except ParseError as e:
        assert str(e) == 'No content.'
        assert e.code == 'no_content'

    # Test JSONDecodeError case
    content = '{"foo": '
    try:
        tokenize_json(content)
    except ParseError as e:
        assert str(e) == 'Expecting value.'
        assert e.code == 'parse_error'


# Generated at 2022-06-22 06:20:13.293856
# Unit test for function validate_json
def test_validate_json():
    content = """
    {
        "name": "John",
        "age": 25
    }
    """
    class Person(Schema):
        name = "string"
        age = "integer"

    value, error_messages = validate_json(content, validator=Person)

    assert value == {"name": "John", "age": 25}
    assert len(error_messages) == 0

    content = """
    {
        "name": "John",
        "age": "twenty five"
    }
    """
    class Person(Schema):
        name = "string"
        age = "integer"

    value, error_messages = validate_json(content, validator=Person)

    assert value is None
    assert len(error_messages) == 1

# Generated at 2022-06-22 06:20:25.385640
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid json
    s = '{"foo": ["bar", 1]}'
    expected = DictToken(
        {
            ScalarToken("foo", 0, 3, s): ListToken(
                [ScalarToken("bar", 8, 11, s), ScalarToken(1, 13, 13, s)], 7, 14, s
            ),
        },
        0,
        15,
        s,
    )
    assert tokenize_json(s) == expected

    # Test invalid json
    s = '{"foo": ["bar", 1]'
    position = Position(column_no=15, line_no=1, char_index=14)
    with pytest.raises(ParseError) as excinfo:
        tokenize_json(s)
    assert excinfo.value.detail["position"] == position
   

# Generated at 2022-06-22 06:20:37.007263
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{}") == DictToken({})
    assert tokenize_json("{}") == DictToken({})
    assert tokenize_json("{}") == tokenize_json(b"{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken({"foo": ScalarToken("bar")})
    assert tokenize_json("[{}, []]") == ListToken([DictToken({}), ListToken([])])
    assert tokenize_json('"foo"') == ScalarToken("foo")
    assert tokenize_json("null") == ScalarToken(None)
    assert tokenize_json("true") == ScalarToken(True)
    assert tokenize_json("false") == ScalarToken(False)

# Generated at 2022-06-22 06:20:44.065338
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        repr(tokenize_json('{"test": 1.0}'))
        == repr(
            DictToken(
                {
                    ScalarToken("test", 1, 5, '{"test": 1.0}'): ScalarToken(
                        1.0, 9, 12, '{"test": 1.0}'
                    )
                },
                0,
                13,
                '{"test": 1.0}',
            )
        )
    )



# Generated at 2022-06-22 06:20:55.379516
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={
        "test_field": String(disallow_empty=True),
        "test_field2": String(disallow_empty=True),
    })
    input_json = textwrap.dedent("""
    {
        "test_field": "test_string",
        "test_field2": "test_string2"
    }
    """)
    parsed, messages = validate_json(input_json, schema)
    assert isinstance(parsed, dict)
    assert messages == {}
    input_json = textwrap.dedent("""
    {
        "test_field": 42
    }
    """)
    parsed, messages = validate_json(input_json, schema)
    assert isinstance(messages.get("test_field"), ValidationError)
    assert messages.get

# Generated at 2022-06-22 06:21:00.307505
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = '{"name": "foo"}')
    assert decoder.scan_once(content ='{"name": "foo"}', idx = 0) == (DictToken({'name': ScalarToken('foo', None, None, None)}, None, None, None), 20)


# Generated at 2022-06-22 06:21:10.488311
# Unit test for function validate_json
def test_validate_json():
    # Example content
    content = """{
        "name": "John Doe",
        "age": 25
    }"""

    class PersonSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    value, errors = validate_json(content, PersonSchema)
    print(f"value: {value}")  # value: {'name': 'John Doe', 'age': 25}
    print(f"errors: {errors}")  # errors: []

    # Example content
    content = """{
        "name": "John Doe",
        "age": "thirty-five"
    }"""

    value, errors = validate_json(content, PersonSchema)
    print(f"value: {value}")  # value: {'name

# Generated at 2022-06-22 06:21:21.725542
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Constructor of _TokenizingDecoder
    _TEST_INPUT = '{"a": {"b": 1.1, "c": "string"}, "d": ["1", 2]}'
    _TEST_OUTPUT = {'a': {'b': 1.1, 'c': 'string'}, 'd': ['1', 2]}

# Generated at 2022-06-22 06:21:43.179989
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == 0
    assert tokenize_json(''' {
  "number": 1,
  "string": "string",
  "array": [1, false, null],
  "nested_array": [[1,2], [3,4]],
  "object": { "foo": 1, "bar": true }
}
''') == {
        "number": 1,
        "string": "string",
        "array": [1, False, None],
        "nested_array": [[1, 2], [3, 4]],
        "object": {"foo": 1, "bar": True},
    }
# Test for function validate_json, it is similar to that of function validate_with_positions, only validator is different

# Generated at 2022-06-22 06:21:54.410467
# Unit test for function validate_json
def test_validate_json():
    validator = Field.string(title="test field")
    value, errors = validate_json('"test value"', validator)
    assert value == 'test value'
    assert not errors

    value, errors = validate_json('"test value"', type(validator))
    assert value == 'test value'
    assert not errors

    value, errors = validate_json('"test value', validator)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ParseError)

    value, errors = validate_json('"test value"', Field.string(min_length=3))
    assert value == 'test value'
    assert not errors

    value, errors = validate_json('"te"', Field.string(min_length=3))
    assert value is None

# Generated at 2022-06-22 06:22:04.573655
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('''
        {
            "list": [
                {
                    "key": {
                        "inner_key": "value"
                    }
                }
            ]
        }
    ''')
    assert(isinstance(token, Token))
    assert(isinstance(token.value, dict))

    list_token = token.value["list"]
    assert(isinstance(list_token, ListToken))
    assert(isinstance(list_token.value, list))
    assert(isinstance(list_token.value[0], DictToken))
    assert(isinstance(token.value["list"].value[0].value["key"].value["inner_key"], ScalarToken))

# Generated at 2022-06-22 06:22:05.658323
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(_TokenizingDecoder)


# Generated at 2022-06-22 06:22:17.897301
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:22:22.248444
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": "b"}'
    validator = typing.Dict[str, str]
    value, error_messages = validate_json(content, validator)
    assert value == {"a": "b"}
    assert error_messages == []


# Generated at 2022-06-22 06:22:23.320406
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
     assert _TokenizingDecoder()


# Generated at 2022-06-22 06:22:30.885167
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"foo"') == ScalarToken(value='foo', start=0, end=5, content='"foo"')
    assert tokenize_json('"foo \\" bar"') == ScalarToken(value='foo " bar', start=0, end=11, content='"foo \\" bar"')
    assert tokenize_json('"foo \\\n bar"') == ScalarToken(value='foo \n bar', start=0, end=13, content='"foo \\\n bar"')
    assert tokenize_json('"foo \\\r bar"') == ScalarToken(value='foo \r bar', start=0, end=13, content='"foo \\\r bar"')

# Generated at 2022-06-22 06:22:32.722521
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content="content").scan_once, type(_TokenizingDecoder.scan_once))

# Generated at 2022-06-22 06:22:44.042304
# Unit test for function validate_json
def test_validate_json():
    # Test unit - input is invalid, output should be None
    content = '{"name": 10, "age": 10}'
    validator = Field.make(name="person", types=Schema)
    assert validate_json(content, validator) == (None, [
        ValidationError(
            text="Must be of type 'Person'.",
            code="invalid_type",
            position=Position(
                column_no=1,
                line_no=1,
                char_index=0
            )
        )
    ])

    # Test unit - input is invalid, output should be None
    content = '{"name": "John", "age": "10"}'
    validator = Field.make(name="person", types=Schema)

# Generated at 2022-06-22 06:22:47.977699
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder


# Generated at 2022-06-22 06:22:49.341734
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    x = _TokenizingDecoder(content="")
    assert True


# Generated at 2022-06-22 06:22:57.677528
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json function
    """
    content = """{"item": [1, 2, 3]}"""
    validator = Schema.of({"item": List[int]})
    assert validate_json(content, validator) == ({'item': [1, 2, 3]}, [])

    content = """{"item": [1, 2, false]}"""
    validator = Schema.of({"item": List[int]})
    errors = [
        ValidationError(
            messages=[
                Message(
                    text="Must be of type `integer`",
                    code="invalid_type",
                    context={"type": "boolean"},
                )
            ],
            code="invalid_type",
        ),
    ]
    assert validate_json(content, validator) == (None, errors)



# Generated at 2022-06-22 06:23:09.624134
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"value"') == ScalarToken(value="value", start=0, end=7, content='"value"')
    assert tokenize_json('{"name": "value"}') == DictToken({"name": ScalarToken(value="value", start=8, end=15, content='"value"')}, start=0, end=16, content='{"name": "value"}')
    assert tokenize_json('["value0", "value1"]') == ListToken([ScalarToken(value="value0", start=1, end=8, content='"value0"'), ScalarToken(value="value1", start=10, end=17, content='"value1"')], start=0, end=18, content='["value0", "value1"]')

# Generated at 2022-06-22 06:23:12.274580
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test case at some low level of constructor (__init__)
    assert _TokenizingDecoder.__init__.__name__ == "__init__"    


# Generated at 2022-06-22 06:23:16.874515
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '["foo", "bar", "baz"]'
    assert tokenize_json(content) == ListToken(['foo', 'bar', 'baz'], 0, 23, content)



# Generated at 2022-06-22 06:23:24.892654
# Unit test for function tokenize_json
def test_tokenize_json():
    # empty data
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    # invalid data
    try:
        tokenize_json("{[}")
        assert False
    except ParseError:
        assert True
    try:
        tokenize_json("{\"key\":}")
        assert False
    except ParseError:
        assert True


# Generated at 2022-06-22 06:23:34.563217
# Unit test for function validate_json
def test_validate_json():
    # Create a JSON string to parse and validate
    json_content = """{
        "name": "example_schema",
        "version": "1.0",
        "type": "record",
        "fields": [
            {
                "name": "id",
                "type": "integer"
            },
            {
                "name": "name",
                "type": "string"
            }
        ]
    }"""

    # Create a validator for the schema above
    from typesystem.types import Schema
    import typesystem
    class MySchema(Schema):
        type = typesystem.String(enum=["record"])
        fields = typesystem.List(items={"name": typesystem.String,
                                        "type": typesystem.String})


# Generated at 2022-06-22 06:23:46.322804
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": null, "b": 1}') == DictToken([
        (ScalarToken("a", 0, 3, '{"a": null, "b": 1}'), ScalarToken(None, 7, 11, '{"a": null, "b": 1}')),
        (ScalarToken("b", 13, 15, '{"a": null, "b": 1}'), ScalarToken(1, 19, 20, '{"a": null, "b": 1}')),
    ], 0, 22, '{"a": null, "b": 1}')


# Generated at 2022-06-22 06:23:54.637237
# Unit test for function validate_json
def test_validate_json():
    content = u'{"a":"a","b":"b","c":"c"}'
    class TestSchema(Schema):
        a = Field(key=True)
        b = Field()
        c = Field()
    try:
        value, _ = validate_json(content, validator=TestSchema)
        assert value == {"a": "a", "b": "b", "c": "c"}
    except ValidationError as e:
        assert False, "ValidationError raised, details: " + repr(e)



# Generated at 2022-06-22 06:24:02.932633
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello"') == ScalarToken('hello', 0,6,'hello')
    assert tokenize_json('{"name": "hello"}') == DictToken({'name': ScalarToken('hello', 10,16,'hello')}, 0,21,'{"name": "hello"}')



# Generated at 2022-06-22 06:24:08.352929
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == DictToken({ScalarToken("hello", 1, 7): ScalarToken("world", 10, 17)}, 0, 18)



# Generated at 2022-06-22 06:24:20.811768
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.positional_validation import Position
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    schema = Schema(fields={"value": Integer()})

    class TestCase:
        code: str
        valid: bool
        error_messages: typing.List[Message]


# Generated at 2022-06-22 06:24:29.953962
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test on valid json string
    content = '{"test": {"a": [1, 2, 3]}}'
    token = tokenize_json(content)
    assert token.type == "dict"
    assert token.keys == {"test"}

    test = token["test"]
    assert test.type == "dict"
    assert test.keys == {"a"}

    a = test["a"]
    assert a.type == "list"
    assert list(a) == [
        ScalarToken(1, content=content, start_position=10, end_position=11),
        ScalarToken(2, content=content, start_position=12, end_position=13),
        ScalarToken(3, content=content, start_position=14, end_position=15),
    ]

    # Test on invalid json string

# Generated at 2022-06-22 06:24:41.233321
# Unit test for function validate_json
def test_validate_json():
    content = '{"first_name":"Austin", "last_name":"Kendall", "age":20, "bmi":20.1}'
    schema = Schema(
        {"first_name": Field(type="string"), "age": Field(type="integer"), "bmi": Field(type="number")}
    )
    # test success
    try:
        value, error_messages = validate_json(content, schema)
        assert not error_messages
    except ValidationError:
        assert True
    # test failure
    content = '{"first_name":"Austin", "last_name":"Kendall", "age":20, "bmi":20.1}'

# Generated at 2022-06-22 06:24:44.017210
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content=None)
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-22 06:24:51.303004
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = Field(required=True)
        age = Field(required=True, type='integer')

    content = '{"name": "John Doe", "age": 30}'
    value, errors = validate_json(content, Person)
    assert value == value
    assert not len(errors)
    assert isinstance(value, dict)

    content = '{"name": "John Doe"}'
    value, errors = validate_json(content, Person)
    assert not value
    assert len(errors)
    assert isinstance(errors, list)
    assert isinstance(errors[0], ValidationError)

    content = '{"name": "John Doe", "age": "INVALID"}'
    value, errors = validate_json(content, Person)
    assert not value
    assert len(errors)
   

# Generated at 2022-06-22 06:24:56.622785
# Unit test for function validate_json
def test_validate_json():
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    content = """
    {
        "name": "Monty",
        "age": 42
    }
    """
    value, messages = validate_json(content, PersonSchema)

    assert value == {"name": "Monty", "age": 42}
    assert messages == []

# Generated at 2022-06-22 06:25:00.021945
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert isinstance(decoder, _TokenizingDecoder)


# Generated at 2022-06-22 06:25:11.490963
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("")
    assert tokenize_json("[]")
    assert tokenize_json("{}")
    assert tokenize_json("null")
    assert tokenize_json("false")
    assert tokenize_json("true")
    assert tokenize_json("0")
    assert tokenize_json("0.0")
    assert tokenize_json("1")
    assert tokenize_json("1.0")
    assert tokenize_json("-1")
    assert tokenize_json("-1.0")
    assert tokenize_json("2")
    assert tokenize_json("2.0")
    assert tokenize_json("1e10")
    assert tokenize_json("1.0e10")
    assert tokenize_json("1e+10")

# Generated at 2022-06-22 06:25:21.940169
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json("[]"), ListToken)

    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
    else:
        assert False, "ParseError was not raised when trying to tokenize an empty string."

    try:
        tokenize_json("{]")
    except ParseError as exc:
        assert exc.position.column_no == 3
        assert exc.position.line_no == 1
        assert exc.position.char_index == 2
    else:
        assert False, "ParseError was not raised when trying to parse invalid JSON."




# Generated at 2022-06-22 06:25:34.227808
# Unit test for function validate_json
def test_validate_json():
    content = """ {"a": ["b", "c"]} """
    validator = Schema(fields={"a": ListToken})
    value, error_message = validate_json(
        content=content, validator=validator
    )
    assert not error_message
    assert value == {"a": ["b", "c"]}
    content = """ {"a": ["b", "c"]} """
    validator = Schema(fields={"a": DictToken})
    value, error_message = validate_json(
        content=content, validator=validator
    )
    assert error_message
    assert "at line 1, column 8" in error_message[0].text
    assert "at line 1, column 8" in error_message[0].position.code
    assert not value

# Generated at 2022-06-22 06:25:46.794519
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"int_field": 0, "string_field": "string"}')
    assert isinstance(token, DictToken)
    assert token.value == {"int_field": 0, "string_field": "string"}

    token = tokenize_json('{"int_field": 0, "string_field": "string"}')
    assert isinstance(token, DictToken)
    assert token.value == {"int_field": 0, "string_field": "string"}

    token = tokenize_json('{"list_field": [1, 2, 3], "string_field": "string"}')
    assert isinstance(token, DictToken)
    assert token.value == {"list_field": [1, 2, 3], "string_field": "string"}


# Generated at 2022-06-22 06:25:57.970963
# Unit test for function validate_json
def test_validate_json():
    import sys
    import io
    import json

    field = Field(type="string")
    result = validate_json("foo", field)
    assert result == ("foo", [])

    valid_json_bytes = b'{"a":{"b":1}}'
    result = validate_json(valid_json_bytes, field)
    assert result == ({"a":{"b":1}}, [])

    field = Field(type="integer")
    valid_json_bytes = b'{"a":{"b":1}}'
    result = validate_json(valid_json_bytes, field)
    assert result == ({"a":{"b":1}}, [])

    field = Field(type="number")
    valid_json_bytes = b'{"a":{"b":1.1}}'
    result = validate_json(valid_json_bytes, field)

# Generated at 2022-06-22 06:25:59.971108
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder1 = _TokenizingDecoder(content="")
    assert decoder1.scan_once is not None

# Generated at 2022-06-22 06:26:04.303679
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Create an instance of _TokenizingDecoder(with content)
    decoder = _TokenizingDecoder(content="test.txt")
    # Get the attribute "scan_once"
    result = decoder.scan_once # type: ignore
    assert result


# Generated at 2022-06-22 06:26:07.407692
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(JSONDecoder().decode('{"a":null}'), dict)
    assert isinstance(_TokenizingDecoder(content='').decode('{"a":null}'), DictToken)


# Generated at 2022-06-22 06:26:09.068450
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.content == ""

# Generated at 2022-06-22 06:26:20.663819
# Unit test for function validate_json
def test_validate_json():
    # validator - a Field instance or Schema class to validate against
    validator = Field(type="integer")
    # content - a JSON string or byte string
    content = '{"data":1}'
    # valid
    assert validate_json(content=content, validator=validator)[1] == []
    content = '{"data":1.0}'
    # invalid
    assert validate_json(content=content, validator=validator)[1] == [
        ValidationError(
            message=Message(
                code="invalid_type", info={"type": "float", "value": 1.0}
            ),
            position=Position(column_no=8, line_no=1, char_index=7),
        )
    ]
    # content - a JSON string or byte string

# Generated at 2022-06-22 06:26:32.420190
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={'author': Field(name='author', label='Author', required=True, description='Name of the author', type='text')})
    s = '{"author": "tyler"}'
    res = validate_json(content=s, validator=schema)
    assert len(res[1]) == 0

    s = '{"author": "tyler"}'
    res = validate_json(content=s, validator=schema.fields["author"])
    assert len(res[1]) == 0

    s = '{"author": "tyler"}'
    res = validate_json(content='{"author": "tyler"}', validator=schema.fields["author"])
    assert len(res[1]) == 0

    s = '{"author": "tyler"}'
    res = validate_json

# Generated at 2022-06-22 06:26:38.336276
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__() != None

# Generated at 2022-06-22 06:26:48.671191
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert(decoder.memo == {})
    assert(decoder.strict == True)
    assert(decoder.parse_array(("[]", 0), None) == ([], 2))
    assert(decoder.parse_float("123.456") == 123.456)
    assert(decoder.parse_float("-123.456") == -123.456)
    assert(decoder.parse_float("123.456e0") == 123.456)
    assert(decoder.parse_float("123.456e+0") == 123.456)
    assert(decoder.parse_float("123.456e-0") == 123.456)
    assert(decoder.parse_float("123.456e1") == 1234.56)

# Generated at 2022-06-22 06:26:52.365322
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    data = '{"a":123, "b":"def"}'
    parser = _TokenizingDecoder(content=data)
    res = parser.decode(data)
    assert(res == {"a":123, "b":"def"}), "Wrong class instantiation"


# Generated at 2022-06-22 06:26:53.922326
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
	assert _TokenizingDecoder

# Generated at 2022-06-22 06:27:05.997071
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("123", None) == (123, None)
    assert validate_json("123", int) == (123, None)
    assert (
        validate_json("123", str)
        == ("expected str, got 123", ["expected str, got 123"])
    )
    assert validate_json("{}", dict) == ({}, None)
    assert validate_json("[]", list) == ([], None)
    assert (
        validate_json("", int)
        == ("No content.", ["No content."])
    )
    assert (
        validate_json("", None)
        == ("No content.", ["No content."])
    )
    assert (
        validate_json("", dict)
        == ("No content.", ["No content."])
    )

# Generated at 2022-06-22 06:27:10.967575
# Unit test for function tokenize_json
def test_tokenize_json():
    # Trivial valid JSON
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.to_json() == {"foo": "bar"}

    # Trivial invalid JSON
    with pytest.raises(ParseError) as excinfo:
        tokenize_json('{"foo": "bar"')
        assert isinstance(excinfo, ParseError)

    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:27:22.483713
# Unit test for function validate_json
def test_validate_json():
    import json
    import pytest


# Generated at 2022-06-22 06:27:23.382430
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:27:34.734058
# Unit test for function validate_json
def test_validate_json():
    # Failed parse
    content = '{"foo": "bar", "doom": 2, '
    field = {"foo": fields.String(), "doom": fields.Integer()}
    validation = validate_json(content, field)
    assert isinstance(validation[1], Message)
    assert validation[1].code == "parse_error"
    assert validation[1].position.column_no == 28
    assert validation[1].position.line_no == 1
    assert validation[1].position.char_index == 27

    # Failed validation
    content = '{"foo": "bar", "doom": "duck"}'
    field = {"foo": fields.String(), "doom": fields.Integer()}
    validation = validate_json(content, field)
    assert isinstance(validation[1], Message)

# Generated at 2022-06-22 06:27:46.810473
# Unit test for function validate_json
def test_validate_json():
    schema = Schema.of({
        'first': Field(type=str),
        'second': Field(type=str),
        'third': Field(type=str),
    })

    input1 = '''
    {
        "first": "first",
        "third": "third",
        "second": "second"
    }
    '''

    assert validate_json(input1, schema)

    input2 = '''
    {
        "first": "first",
        "third": 3,
        "second": "second"
    }
    '''

    assert not validate_json(input2, schema)
    assert validate_json(input2, schema)[1][0].text == "'third' is not of type 'string'"

# Generated at 2022-06-22 06:27:54.337063
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()

    assert(decoder.strict is True)
    assert(decoder.parse_int is int)

# Generated at 2022-06-22 06:27:57.798884
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string", required=True)
    content = '""'
    value, errors = validate_json(content, validator)
    assert value == ""
    assert len(errors) == 0


# Generated at 2022-06-22 06:27:59.579980
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content="string"), _TokenizingDecoder)



# Generated at 2022-06-22 06:28:07.729960
# Unit test for function validate_json
def test_validate_json():
    mock_content = '{"x": "y"}'
    mock_decoded_content = {"x": "y"}
    mock_validator = typing.TypeVar("Field")
    mock_validator.validate = lambda value: "Success"
    mock_validator.serialize = lambda value: value
    mock_validator.name = "field"

    validation_result = validate_json(mock_content, mock_validator)
    expected_result = (mock_decoded_content, "Success")
    assert validation_result == expected_result

# Generated at 2022-06-22 06:28:10.577599
# Unit test for function tokenize_json
def test_tokenize_json():
    json = tokenize_json('{"foo": "bar"}')
    assert json.value["foo"].value == "bar"
    assert json is not None



# Generated at 2022-06-22 06:28:21.467814
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Arrange
    test_content_1 = '{"key":"value"}'
    test_content_2 = '{"key":1}'
    test_content_3 = '{"key":null}'
    test_content_4 = '{"key":true}'
    test_content_5 = '["value",2,false]'

    # Act
    tokenize_decoder_1 = _TokenizingDecoder(object_hook=lambda x: x, content=test_content_1)
    tokenize_decoder_2 = _TokenizingDecoder(object_hook=lambda x: x, content=test_content_2)
    tokenize_decoder_3 = _TokenizingDecoder(object_hook=lambda x: x, content=test_content_3)