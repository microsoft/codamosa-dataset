

# Generated at 2022-06-22 06:18:49.314205
# Unit test for function validate_json
def test_validate_json():
    # verify that validate_json returns a list of errors
    empty_schema = Schema()
    content = "not-valid-json"
    value, errors = validate_json(content, empty_schema)
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], ParseError)

    # verify that validate_json returns a list of errors
    empty_schema = Schema()
    content = "[\"not-a-valid-value\"]"
    value, errors = validate_json(content, empty_schema)
    assert isinstance(errors, list)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-22 06:18:53.084581
# Unit test for function validate_json
def test_validate_json():
    json_content = b'''[{"name": "jenny", "age":17}]'''
    schema = {'name': str, 'age': int}
    assert validate_json(json_content, schema) == ([{'name': 'jenny', 'age': 17}], None)

# Generated at 2022-06-22 06:18:54.882292
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    c = _TokenizingDecoder(content = "test")
    assert c.content == "test"

# Generated at 2022-06-22 06:19:05.124112
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_decoder = _TokenizingDecoder("test", False, {})
    assert(json_decoder.scan_once("[123,false,\"hello\"]", 0) ==
           ([ScalarToken(123, 1, 3, "[123,false,\"hello\"]"),
             ScalarToken(False, 8, 13, "[123,false,\"hello\"]"),
             ScalarToken("hello", 14, 21, "[123,false,\"hello\"]")],
            22))


# Generated at 2022-06-22 06:19:10.215257
# Unit test for function validate_json
def test_validate_json():
    json_schema = Schema({"name": "string", "age": "integer"})
    my_json = "{'name': 'Bob', 'age': '23'}"
    validated_json, errors = validate_json(validator=json_schema, content=my_json)
    assert(isinstance(errors,list))
    pass

# Generated at 2022-06-22 06:19:21.481089
# Unit test for function validate_json
def test_validate_json():
    test_schema = Schema(
        {
            "title": str,
            "number": int,
            "values": [
                {"value": str, "percentage": float}
            ],
            "dict": {"first": str, "second": str},
            "nested": [
                {"value": str, "count": int}
            ],
            "optional": str
        }
    )

# Generated at 2022-06-22 06:19:28.998497
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder
    assert hasattr(decoder, 'parse_array')
    assert hasattr(decoder, 'parse_float')
    assert hasattr(decoder, 'parse_int')
    assert hasattr(decoder, 'parse_string')
    assert hasattr(decoder, 'strict')
    assert hasattr(decoder, 'scan_once')


# Generated at 2022-06-22 06:19:33.307475
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Field(types=str)

    value, error_messages = validate_json(content, validator)
    assert error_messages == []
    assert value == {"foo": "bar"}



# Generated at 2022-06-22 06:19:44.462888
# Unit test for function tokenize_json
def test_tokenize_json():
    res = tokenize_json("{'int':1,'float':42.0,'str':'str','true':True,'false':False,'None':null,'dict':{},'list':[]}")

# Generated at 2022-06-22 06:19:49.209745
# Unit test for function tokenize_json
def test_tokenize_json():
	content="""
		{
			"name":"John Doe",
			"friends":[{"name":"Bob"}, {"name":"Alice", "age": 30}]
		}
	"""
	result = tokenize_json(content)
	print(result)



# Generated at 2022-06-22 06:20:05.551444
# Unit test for function tokenize_json
def test_tokenize_json():
    assert ScalarToken(42, 0, 1, "42") == tokenize_json("42")
    assert ScalarToken("foo", 0, 4, '"foo"') == tokenize_json('"foo"')
    assert DictToken({"foo": 42}, 0, 8, '{"foo": 42}') == tokenize_json('{"foo": 42}')
    assert ListToken([42], 0, 3, "[42]") == tokenize_json("[42]")



# Generated at 2022-06-22 06:20:13.315748
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"content": "Hello"}')
    assert isinstance(result, DictToken)
    assert result.start == 0
    assert result.end == 17
    assert result.content == '{"content": "Hello"}'
    assert result.children[0].start == 2
    assert result.children[0].end == 14
    assert result.children[0].content == '"content"'
    assert result.children[1].start == 14
    assert result.children[1].end == 17
    assert result.children[1].content == '"Hello"'

# Unit tests for function validate_json

# Generated at 2022-06-22 06:20:21.333252
# Unit test for function tokenize_json
def test_tokenize_json():
    from unittest import TestCase
    from typesystem.tokenize.tokens import Token

    json_input_normal = '{"name": "John Doe"}'
    json_input_normal_with_line = '{"name": "John Doe", "age": 35, "married": true, "kids": [{"name": "Mary Doe", "age": 5}, {"name": "Peter Doe", "age": 3}]}'
    json_input_number = '{"price": 9.99}'
    json_input_null = '{"name": null}'

    class TokenizeJsonTestCase(TestCase):
        def tokenize_json_test(self):
            json_result_normal = tokenize_json(json_input_normal)
            self.assertEqual(json_result_normal.value, {"name": "John Doe"})

# Generated at 2022-06-22 06:20:24.295240
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with pytest.raises(TypeError):
        JSONDecoder(content="test")
    decoder = _TokenizingDecoder(content="test")
    assert isinstance(decoder, _TokenizingDecoder)

# Unit tests for function _TokenizingJSONObject

# Generated at 2022-06-22 06:20:35.512859
# Unit test for function validate_json
def test_validate_json():
    class SampleSchema(Schema):
        foo = Field(type="string")
        bar = Field(type='integer')
    json_data = '{"foo": "myfoo", "bar": 42}'
    value, error_messages = validate_json(json_data, SampleSchema)
    assert error_messages == []
    assert value == {'foo': 'myfoo', 'bar': 42}
    json_data = '{"foo": "myfoo", "bar": abc}'
    value, error_messages = validate_json(json_data, SampleSchema)
    assert error_messages == [
        ValidationError(text=f"Could not parse `integer`.", code="parse_error", position=Position(
            line_no=1, column_no=15, char_index=14))
        ]


# Generated at 2022-06-22 06:20:41.857877
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("[]", ListField(StringField())) == ([], None)
    assert validate_json("[1.1,2.2,3.3]", ListField(NumberField())) == ([], None)
    assert validate_json("[1.1,1,3.3]", ListField(NumberField())) == ([], None)
    assert validate_json("[1.1,1,3.3]", ListField(FloatField())) == ([], None)
    assert validate_json("[1.1,2,3.3]", ListField(IntegerField())) == ([], None)
    assert validate_json("", StringField()) == (None, None)
    assert validate_json("{}", DictField(StringField())) == ({}, None)

# Generated at 2022-06-22 06:20:47.120073
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json(b'{"foo": "bar", "baz": 1}')
    print(type(result))
    print(type(result.value))
    print(type(result.value.value))
    #assert type(result) == dict
    #assert result["foo"] == "bar"
    #assert result["baz"] == 1



# Generated at 2022-06-22 06:20:49.244812
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="test")

# Unit tests for _TokenizingJSONObject

# Generated at 2022-06-22 06:21:00.694035
# Unit test for function validate_json
def test_validate_json():
    # test case 1
    # input: {"a": 1, "b": "2"}
    # output: 
    #   ({"a": 1, "b": "2"}, [])
    json_input = '{"a": 1, "b": "2"}'
    validator = Schema.of({
        "a": Field.of(int),
        "b": Field.of(str)
    })
    assert validate_json(json_input, validator) == ({"a": 1, "b": "2"}, [])

    # test case 2
    # input: {"a": "wrong", "b": "2"}
    # output:
    #   (None, [ValidationError
    #           ('a',
    #           '"wrong" is not a valid int',
    #           {'code': 'invalid

# Generated at 2022-06-22 06:21:06.224981
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    It's not possible to test the constructor of _TokenizingDecoder.
    So it is tested that the constructor does not raise errors
    """
    decoder = _TokenizingDecoder(content = "content")


# Generated at 2022-06-22 06:21:22.762870
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""{
        "aString": "foobar",
        "anInteger": 1234,
        "aFloat": 123.4,
        "aBoolean": true,
        "aNull": null,
        "aList": [1, "foo", false, null],
        "aDict": {
            "foo": "bar",
            "baz": 42
        }
    }""")
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert token.value["aString"] == "foobar"
    assert token.value["aInteger"] == 1234
    assert token.value["aFloat"] == 123.4
    assert token.value["aBoolean"]
    assert token.value["aNull"] is None

# Generated at 2022-06-22 06:21:31.977644
# Unit test for function validate_json
def test_validate_json():
    # Basic invalid JSON (string is missing end quote).
    content = b"""{
        "color": "red
    }"""
    validator = Schema({"color": str})
    (value, error_msgs) = validate_json(content, validator)
    assert error_msgs == [
        Message(
            "Enclosing double quote is missing.",
            code="quote_missing",
            detail="Enclosing double quote is missing at line 2, column 18.",
            line_no=2,
            column_no=18,
            char_index=30,
        )
    ]
    assert value is None

    # Basic valid JSON
    content = b"""{
        "type": "Point",
        "coordinates": [0, 0]
    }"""

# Generated at 2022-06-22 06:21:43.408943
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    position = Position(column_no=1, line_no=1, char_index=0)
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.text == "No content."
    assert exc_info.value.position == position

    # Unexpected character
    position = Position(column_no=1, line_no=1, char_index=0)
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("1")
    assert exc_info.value.text == 'Expecting property name enclosed in double quotes.'
    assert exc_info.value.position == position

    # Expecting value

# Generated at 2022-06-22 06:21:50.799790
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('10', Field(type="integer")) == (10, [])
    assert validate_json('10', Field(type="integer", max_value=1))[1] == [
        ({
            "position": {"column_no": 1, "char_index": 1, "line_no": 1},
            "text": "This value is greater than the allowed maximum of 1.",
            "code": "max_value"
        },)
    ]


# Generated at 2022-06-22 06:21:53.284982
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "test_content"
    decoder = _TokenizingDecoder(content=test_content)
    assert decoder.content == test_content


# Generated at 2022-06-22 06:21:58.563203
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"hello": "world"}'
    token = tokenize_json(content)
    assert token.value == {"hello": "world"}
    assert token.start_position == Position(1, 1, 0)
    assert token.end_position == Position(13, 1, 12)
    assert token.content == content



# Generated at 2022-06-22 06:22:08.686687
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "")
    assert tokenize_json('{"foo": 1}') == DictToken({"foo": ScalarToken(1, 6, 6, "")}, 0, 10, "")
    assert tokenize_json('{"foo": [1, true]}') == DictToken({"foo": ListToken([ScalarToken(1, 6, 6, ""), ScalarToken(True, 9, 12, "")], 6, 12, "")}, 0, 15, "")

# Generated at 2022-06-22 06:22:19.305639
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": [1,2,3]}'
    validator = Schema([
                    {"a": "integer"},
                    {
                        "a": [
                            {
                                "key1": "integer",
                                "key2": "string"
                            },
                            {
                                "key1": "integer",
                                "key3": "string"
                            },
                        ]
                    }
                ])
    result = validate_json(content, validator)
    expected_value = {
        "a": [
            {"key1": 1},
            {"key1": 2}
        ]
    }
    assert result[0] == expected_value

# Generated at 2022-06-22 06:22:24.034478
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from typesystem import types

    class Search(typesystem.Schema):
        page_size = types.Integer(validators=[types.Range(min=10)])

    value, errors = validate_json('{"page_size":5}', Search)
    assert errors
    assert not value



# Generated at 2022-06-22 06:22:29.142456
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("content")
    assert len(decoder.__dict__) == 4
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_object == JSONDecoder.parse_object
    assert decoder.parse_array == JSONDecoder.parse_array


# Generated at 2022-06-22 06:22:47.326687
# Unit test for function validate_json
def test_validate_json():
    from typesystem.json_schema import JSONSchema

    json_str = """
    {
        "favorites": ["Spam", "Eggs", "Bacon"],
        "bacon": true,
        "spam": 42,
        "eggs": null,
        "name": {
            "first": "Tom",
            "last": "Ate"
        },
        "stuff": [
            {
                "title": "Book One",
                "author": "Bob",
            },
            {
                "title": "Book Two",
                "author": "Bob",
            }
        ]
    }
    """

# Generated at 2022-06-22 06:22:50.885352
# Unit test for function validate_json
def test_validate_json():
    sample = """{ "name": "John Smith", "number": "0987654321" }"""
    errors = validate_json(content=sample, validator=Schema)
    assert len(errors) == 2
    assert errors[0].code == "type_error"
    assert errors[1].code == "type_error"

# Generated at 2022-06-22 06:22:53.261678
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"test": "true"}'
    decoder = _TokenizingDecoder(content=content)
    result = decoder.scan_once(content,0)
    assert isinstance(result[0],DictToken)


# Generated at 2022-06-22 06:22:56.344170
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key":"value"}'
    decoded = _TokenizingDecoder(content = content)
    assert isinstance(decoded, _TokenizingDecoder)


# Generated at 2022-06-22 06:23:07.948792
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json function.
    """
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    # Get the test content from a data file.
    from os.path import dirname, join
    from typesystem.tokenize import __file__ as tokenize__file__
    from typesystem.tokenize.tests import __file__ as tests__file__
    import json
    data_dir = dirname(dirname(dirname(tokenize__file__)))
    file_path = join(data_dir, "tests", "data", "valid_json.json")
    valid_json_data = json.load(open(file_path))

    # Start with a valid field.
    valid_integer_field = Integer()

    # Setup a class which inherits from Schema which can handle the


# Generated at 2022-06-22 06:23:18.284242
# Unit test for function validate_json
def test_validate_json():
    content = '"abc" '
    validator = Field(type=str, default='abc')
    value, error_messages = validate_json(content, validator)
    #print(value, error_messages)

    content = '{"a":1, "b":2} '
    validator = Field(type=dict, default={})
    value, error_messages = validate_json(content, validator)
    #print(value, error_messages)

    content = '{"a":1, "b":2} '
    validator = Field(type=dict, default={'a':1, 'b':2})
    value, error_messages = validate_json(content, validator)
    #print(value, error_messages)

    content = '{"b":2} '
    validator = Field

# Generated at 2022-06-22 06:23:23.931800
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder(content="abc")
    assert isinstance(d.scan_once, typing.Callable)
    assert len(d.memo) == 0
    assert d.parse_float == float
    assert d.parse_int == int

# Unit tests for function tokenize_json()

# Generated at 2022-06-22 06:23:30.706938
# Unit test for function validate_json
def test_validate_json():
    import json
    import pprint

    content = '''{
      "name": "John Doe",
      "age": 30,
      "address": {
        "city": "New York",
        "state": "NY"
      },
      "phones": ["987654321", "123456789"]
    }'''
    # Generate a schema containing fields and types of the keys and values
    # given in the dictionary
    schema = json.loads(content)
    schema = Schema.from_dict(schema)

    result = validate_json(content, validator=schema)
    assert result != None
    value, messages = result
    pprint.pprint(messages)


# Generated at 2022-06-22 06:23:32.251508
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "123"
    try:
        _TokenizingDecoder(content=content)
    except:
        raise

# Generated at 2022-06-22 06:23:44.056420
# Unit test for function validate_json
def test_validate_json():
    content = """{
        "a": 1
    }"""
    assert validate_json(content, {"a": int}) == ({'a': 1}, [])

    content = """{
        "a": "hi",
        "b": "there"
    }"""
    errors = validate_json(content, {"a": int, "b": int})[1]
    assert len(errors) == 2
    assert errors[0].code == "invalid_type"
    assert errors[1].code == "invalid_type"
    assert errors[0].context == {"validator": int, "value": "hi"}
    assert errors[1].context == {"validator": int, "value": "there"}

    content = """{
        "a": 1,
        "b": 2
    }"""

# Generated at 2022-06-22 06:24:00.515275
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"simple": 1}'
    json_decoder = JSONDecoder.decode
    token = _TokenizingDecoder.decode
    assert json_decoder(content) == token(content, content=content)
    content = '{"simple": [1, 2]}'
    assert json_decoder(content) == token(content, content=content)
    # tokenize_json has the additional functionality that it can also
    # parse and validate a json structure.
    try:
        tokenize_json(content.replace('"', ''))
    except ParseError:
        pass
    else:
        raise AssertionError
    content = '{"simple": 1, "simple2": 2}'
    assert json_decoder(content) == token(content, content=content)

# Generated at 2022-06-22 06:24:11.762897
# Unit test for function validate_json
def test_validate_json():
    # Test that it can handle empty content
    (value, error_messages) = validate_json("", Field(type="string"))
    assert value is None
    assert error_messages.as_summary() == {"parse_error": 1}

    # Test that it can parse a valid JSON string
    (value, error_messages) = validate_json("\"bob\"", Field(type="string"))
    assert value == "bob"
    assert error_messages is None

    # Test that it can produce positional errors for a JSON parse failure
    (value, error_messages) = validate_json("123", Field(type="string"))
    assert value is None

# Generated at 2022-06-22 06:24:13.714396
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    return decoder



# Generated at 2022-06-22 06:24:18.164115
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{}'
    decoder = _TokenizingDecoder(content=content)

    assert isinstance(decoder, _TokenizingDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-22 06:24:25.079466
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tests the tokenize_json function
    """
    t1 = tokenize_json('{"key":"value"}')
    assert isinstance(t1, DictToken)
    assert t1.keys_values == [('key', 'value')]

    t2 = tokenize_json('[1,2,3]')
    assert isinstance(t2, ListToken)
    assert t2.elements == [1, 2, 3]


# Generated at 2022-06-22 06:24:26.873115
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder != None


# Generated at 2022-06-22 06:24:31.870046
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    This function is only used for unit test.
    """
    try:
        _TokenizingDecoder(content='')
    except (ParseError):
        pass
    except:
        raise Exception('init _TokenizingDecoder failed')


# Generated at 2022-06-22 06:24:37.925853
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    content = '{"tt":1}'
    decoder = _TokenizingDecoder(content=content)
    res = decoder.decode('{"tt":1}')
    assert res == DictToken({ScalarToken(1, 6, 7, '{"tt":1}'): ScalarToken("tt", 1, 3, '{"tt":1}')}, 0, 8, '{"tt":1}')



# Generated at 2022-06-22 06:24:41.958084
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder(content="{\"key\":1}")
    except AssertionError:
        assert False, "Failed to render _TokenizingDecoder"


# Generated at 2022-06-22 06:24:49.990172
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    print("Testing _TokenizingDecoder class...")
    print("Testing json.decoder.scanstring...")
    content = '''
{
  "name": "string",
  "email": "string",
  "password": "string",
  "age": 5,
  "height": 6.0,
  "is_good_man": true,
  "is_cowboy": false,
  "favorite_foods": [
    "string",
    "string",
    "string"
  ],
  "scores": {
    "a": 1,
    "b": 2
  }
}
    '''
    decoder = _TokenizingDecoder(content=content)
    print("Testing decoder.scan_once...")
    token, index = decoder.scan_once(content, 0)
    print

# Generated at 2022-06-22 06:25:03.492791
# Unit test for function validate_json
def test_validate_json():
    content = '{"a" : ["123", 456, [789], {"b" : 123}]}'
    validator = Field(type="dict", fields={"a": Field(type="list", items=Field(type=["number", "string"]))})
    value, errors = validate_json(content, validator)
    print(value, errors)



# Generated at 2022-06-22 06:25:10.009448
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert  token.get_value() == {ScalarToken('foo', 0, 6, '{"foo": "bar"}'): ScalarToken('bar', 11, 16, '{"foo": "bar"}')}


# Generated at 2022-06-22 06:25:20.235296
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.types import Object
    from typesystem import ValidationError
    import json
    import pytest
    import enum

    class Color(enum.Enum):
        Red = 1
        Green = 2
        Blue = 3

    class FavoriteColor(Object):
        color = String(enum=Color, enum_strict=False)

    class Person(Schema):
        name = String()
        age = Integer()
        favorite_colors = FavoriteColor[:]

    # (expected_value, input_value, expected_exception)

# Generated at 2022-06-22 06:25:23.447006
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"answer": 42}'
    token = tokenize_json(content)
    assert str(token) == '{"answer": 42}'


# Generated at 2022-06-22 06:25:35.792270
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"string": "hello", "int": 123, "float": 3.14, "null": null, "true": true, "false": false, "list": [1, 2, 3], "dict": {"key": "value"}}'
    test_token = tokenize_json(json_str)
    assert test_token.value == {
        "string": "hello",
        "int": 123,
        "float": 3.14,
        "null": None,
        "true": True,
        "false": False,
        "list": [1, 2, 3],
        "dict": {"key": "value"},
    }

    assert test_token.start_position.column_no == 1
    assert test_token.start_position.line_no == 1

# Generated at 2022-06-22 06:25:38.087436
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("", content="").scan_once("", 0) == (None, 0)

# Generated at 2022-06-22 06:25:43.952863
# Unit test for function validate_json
def test_validate_json():
    # tests python csv module
    return validate_json('{"name": "jet", "age": 10, "is_pet": 1}', Schema.of({
        'name': fields.String(),
        'age': fields.Integer(),
        'is_pet': fields.Boolean(),
    }))

# Generated at 2022-06-22 06:25:48.601509
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    expected = '{"a":2.2},{"b":[1,2,3]}'

    content = '{"a":2.2},{"b":[1,2,3]}'
    decoder = _TokenizingDecoder(content=content)

    actual = decoder.decode(content)
    assert expected == actual


# Generated at 2022-06-22 06:26:00.218199
# Unit test for function validate_json
def test_validate_json():

    class Address(Schema):
        city = Field(type="string")
        street = Field(type="string")
        zipcode = Field(type="string")

    class User(Schema):
        username = Field(type="string")
        address = Field(type="object", schema=Address)
        age = Field(type="integer")

    def check_result(
        validator: typing.Union[Field, typing.Type[Schema]],
        content: str,
        expected_errors: typing.List[Message],
    ) -> None:
        value, errors = validate_json(content.encode(), validator=validator)
        assert errors == expected_errors
        assert errors != [] or isinstance(value, dict)


# Generated at 2022-06-22 06:26:04.710341
# Unit test for function validate_json
def test_validate_json():
    expected_result = (None, [Message(
        message_text='Value is required.',
        message_code='required',
        position=Position(line_no=1, column_no=1, char_index=0)
    )])

    assert expected_result == validate_json('', validator=Schema(fields={'hi': make_field()}))



# Generated at 2022-06-22 06:26:26.810987
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder().parse_float('12.2'), float)
    assert isinstance(_TokenizingDecoder().parse_int('12'), int)
    assert isinstance(_TokenizingDecoder().parse_array(('[{"hello": "world"}]', 0), _make_scanner({"strict": True, "parse_float": float, "parse_int": int, "parse_array": _TokenizingDecoder().parse_array, "parse_string": _TokenizingDecoder().parse_string, "memo": {}}, 'content'))[0], list)
    assert isinstance(_TokenizingDecoder().parse_string('"{"hello": "world"}"', 0, True)[0], str)

# Generated at 2022-06-22 06:26:36.260188
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String

    field = String(max_length=3)
    content = b'{"data": "hello"}'
    result = validate_json(content, field)
    assert result[0] == None
    assert type(result[1]) == list and len(result[1]) == 0

    field = String(max_length=3)
    content = b'{"data": "h"}'
    result = validate_json(content, field)
    assert result[0] == None
    assert type(result[1]) == list and len(result[1]) == 0

    field = String(max_length=3)
    content = b'{"data": "h"}'
    result = validate_json(content, field)
    assert result[0] == None

# Generated at 2022-06-22 06:26:38.592699
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert(decoder == _TokenizingDecoder(content=content))


# Generated at 2022-06-22 06:26:48.974124
# Unit test for function validate_json
def test_validate_json():
    content = '{"url": "https://google.com"}'
    validator = Field(type=str)
    assert validate_json(content, validator) == ({"url": "https://google.com"}, [])

    content = '{"url": "https://google.com"}'
    validator = Field(type=str)
    content = '{"url": "https://google.com"}'
    validator = Field(type=str)
    assert validate_json(content, validator) == ({"url": "https://google.com"}, [])

    content = '{"url": "https://google.com"}'
    validator = Field(type=str)
    content = '{"url": "https://google.com"}'
    validator = Field(type=str)

# Generated at 2022-06-22 06:26:50.679707
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.scan_once


# Generated at 2022-06-22 06:26:55.355720
# Unit test for function tokenize_json
def test_tokenize_json():
    obj = {"foo": "bar"}
    obj_str = '{"foo": "bar"}'
    token = tokenize_json(obj_str)
    assert token.value == obj
    assert token.start == 0
    assert token.end == 11



# Generated at 2022-06-22 06:27:00.672007
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    test_tokenizer_with_custom_constructor
    """
    context = _TokenizingDecoder(content="i am a JSON")
    assert context.content == "i am a JSON"
    assert context.scan_once == _make_scanner(context, "i am a JSON")



# Generated at 2022-06-22 06:27:09.698751
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema.of(
        {"name": str, "age": int, "todo": [{"description": str, "priority": int}]}
    )
    assert (
        len(
            validate_json(
                b"""{
            "name": "Ada Lovelace",
            "age": 37,
            "todo": [
                {
                    "description": "Analyze the Analytical Engine",
                    "priority": 37
                }
            ]
        }""",
                schema,
            )[1]
        )
        == 0
    )

# Generated at 2022-06-22 06:27:21.746765
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import typesystem
    from typesystem import fields

    def check_token(token, expected, expected_type):
        assert isinstance(token, expected_type)
        assert token == expected


    # Empty string
    with pytest.raises(typesystem.ParseError):
        tokenize_json("")

    # Empty dictionary
    token = tokenize_json("{}")
    check_token(token, {}, DictToken)

    # Empty list
    token = tokenize_json("[]")
    check_token(token, [], ListToken)

    # Empty string
    token = tokenize_json('""')
    check_token(token, '', ScalarToken)

    # Non-empty string
    token = tokenize_json('"hello"')

# Generated at 2022-06-22 06:27:31.628650
# Unit test for function tokenize_json
def test_tokenize_json():
    good_json = '''{
  "name": "John",
  "age": 30,
  "cars": [
    { "name": "Ford", "models": ["Fiesta", "Focus", "Mustang"] },
    { "name": "BMW", "models": ["320", "X3", "X5"] },
    { "name": "Fiat", "models": ["500", "Panda"] }
  ]
}'''
    assert isinstance(tokenize_json(good_json), DictToken)

    # Valid JSON but not empty.
    with pytest.raises(ParseError, match=r"No content."):
        tokenize_json("   ")

    # Valid JSON but not whitespace.
    with pytest.raises(ParseError, match=r"No content."):
        token

# Generated at 2022-06-22 06:27:46.189131
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content='{"a":[1, 2, {"b":1}]}')


# Generated at 2022-06-22 06:27:48.144784
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder('content')
    assert decoder.scan_once


# Generated at 2022-06-22 06:27:54.438969
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test function tokenize_json
    """
    token = tokenize_json('{"a":1, "b": 2}')
    assert token.children[0].value == "a"
    assert token.children[1].value == 1
    assert token.children[2].value == "b"
    assert token.children[3].value == 2


# Generated at 2022-06-22 06:28:05.585014
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = """
    {
        "a": "b",
        "c": {
            "d": "e"
        },
        "f": ["g", "h"],
        "i": [
            {
                "j": "k"
            }
        ]
    }
    """

# Generated at 2022-06-22 06:28:10.197022
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '"key": "value"'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    assert len(token.keys) == 1
    assert "key" in token
    assert str(token["key"]) == '"value"'

# Generated at 2022-06-22 06:28:21.150550
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tests for function tokenize_json
    """
    # Test simple JSON
    json = r'"str"'
    token = tokenize_json(json)
    assert token == ScalarToken('str', 0, 5, json)

    json = r'1'
    token = tokenize_json(json)
    assert token == ScalarToken(1, 0, 1, json)

    json = r'{"a": "b"}'
    token = tokenize_json(json)
    assert token == DictToken({'a': ScalarToken('b', 4, 7, json)}, 0, 9, json)

    json = r'{"a": {"b": "c"}}'
    token = tokenize_json(json)