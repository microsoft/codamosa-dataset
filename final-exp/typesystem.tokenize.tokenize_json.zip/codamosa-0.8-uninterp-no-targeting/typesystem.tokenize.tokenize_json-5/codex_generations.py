

# Generated at 2022-06-22 06:18:50.201129
# Unit test for function validate_json
def test_validate_json():
    # json to test
    json_doc = b'{"firstName": "John", "lastName": "Smith", "age": 25}'
    v = {
        'firstName': {'type': 'string'},
        'lastName': {'type': 'string'},
        'age': {'type': 'number'},
    }
    
    # expected output
    expected_value = {"firstName": "John","lastName": "Smith","age": 25}
    expected_errors = []

    # actual output from validate_json
    (actual_value, actual_errors) = validate_json(json_doc, v)

    assert actual_value == expected_value
    assert actual_errors == expected_errors
    
test_validate_json()

# Generated at 2022-06-22 06:18:51.189306
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="")


# Generated at 2022-06-22 06:19:00.784796
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.fields import IntegerField, StringField
    from typesystem.schemas import Schema

    class User(Schema):
        name = StringField()
        age = IntegerField()

    js = r"""{
        "name": "peter",
        "age": 27
    }"""

    (value, errors) = validate_json(js, User)
    assert value == json.loads(js)
    assert not errors
    assert isinstance(value, dict)

    js = r"""{
        "name": "peter",
        "age": "27"
    }"""

    (value, errors) = validate_json(js, User)
    assert value == json.loads(js)
    assert errors
    assert isinstance(value, dict)


# Generated at 2022-06-22 06:19:02.355631
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content='{}')


# Generated at 2022-06-22 06:19:08.226645
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"str": "str", "num": 123}')
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert len(token) == 2
    assert isinstance(token.value['str'], ScalarToken)
    assert isinstance(token.value['num'], ScalarToken)
    
    

# Generated at 2022-06-22 06:19:14.996791
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"x":10, "y":20}') == DictToken({ScalarToken('x', 2, 4, '{"x":10, "y":20}'): ScalarToken(10, 8, 11, '{"x":10, "y":20}'), ScalarToken('y', 15, 17, '{"x":10, "y":20}'): ScalarToken(20, 21, 24, '{"x":10, "y":20}')}, 0, 26, '{"x":10, "y":20}')

# Generated at 2022-06-22 06:19:21.482178
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import unittest.mock
    content = "{\"test\": 1234}"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, idx=0) == (DictToken({ScalarToken("test", 1, 7, content): ScalarToken(1234, 11, 16, content)}, 0, 17, content), 18)



# Generated at 2022-06-22 06:19:29.027099
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "foo": [1, 2, 3],
        "bar": {
            "baz": "qux"
        }
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {
        "foo": [1, 2, 3],
        "bar": {"baz": "qux"},
    }



# Generated at 2022-06-22 06:19:37.637178
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"string": "value", "int": 10, "float": 1.10, "null": null, "boolean": false, "list": [1, 2, 3]}'
    tokens = tokenize_json(json_string)
    assert isinstance(tokens, DictToken)
    assert isinstance(tokens, Token)
    assert isinstance(tokens.value, dict)
    assert isinstance(tokens.value["string"], ScalarToken)
    assert isinstance(tokens.value["float"], ScalarToken)
    assert isinstance(tokens.value["list"], ListToken)
    assert isinstance(tokens.value["list"].value, list)
    assert tokens.value["int"].value == 10
    assert tokens.value["null"].value == None
   

# Generated at 2022-06-22 06:19:47.557841
# Unit test for function validate_json
def test_validate_json():
    # test for content not empty nor blank
    content_1 = '{"name": "John", "age": 30}'
    validator_1 = Schema
    result_1 = validate_json(content_1, validator_1)
    assert result_1[1] == []

    # test for content empty
    content_2 = ''
    validator_2 = Schema
    result_2 = validate_json(content_2, validator_2)
    assert type(result_2[1][0]) == ValidationError

    # test for content blank
    content_3 = ' '
    validator_3 = Schema
    result_3 = validate_json(content_3, validator_3)
    assert type(result_3[1][0]) == ValidationError

# Generated at 2022-06-22 06:20:02.168030
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": [1, "two", ["three", "four", 5.0, null], {"aa": "bb"}, []]}'
    assert isinstance(tokenize_json(content), DictToken)
    # Test error conditions
    context = '{"foo":1, '
    with pytest.raises(ParseError) as excinfo:
        tokenize_json(context)
    assert str(excinfo.value) == "Expecting '}' delimiter."



# Generated at 2022-06-22 06:20:06.829056
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken(
        {ScalarToken("key", 0, 3, '{"key": "value"}'):
         ScalarToken("value", 8, 14, '{"key": "value"}')},
        0, 14, '{"key": "value"}'
    )



# Generated at 2022-06-22 06:20:15.828172
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.strict is True
    assert decoder.parse_float is float
    assert decoder.parse_int is int
    assert decoder.parse_constant is None
    assert decoder.object_pairs_hook is None
    assert decoder.object_hook is None
    assert decoder.memo == dict()
    assert decoder.content == ''
    assert decoder.parse_object == _TokenizingJSONObject
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_string == scanstring

# Unit tests for constructor of class _TokenizingJSONObject

# Generated at 2022-06-22 06:20:17.853253
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = b'{"key": "value"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0)


# Generated at 2022-06-22 06:20:29.953014
# Unit test for function tokenize_json
def test_tokenize_json():
    input_data = '[1, 2, "abcd", "ab", true, false, null, 4.245]'
    expected_output = ListToken(
        [
            ScalarToken(1, 0, 0, input_data),
            ScalarToken(2, 2, 2, input_data),
            ScalarToken("abcd", 4, 10, input_data),
            ScalarToken("ab", 11, 15, input_data),
            ScalarToken(True, 16, 20, input_data),
            ScalarToken(False, 21, 27, input_data),
            ScalarToken(None, 28, 32, input_data),
            ScalarToken(4.245, 33, 39, input_data),
        ],
        0,
        39,
        input_data,
    )

# Generated at 2022-06-22 06:20:36.561828
# Unit test for function tokenize_json
def test_tokenize_json():
  content = """{
        "a": 1,
        "b": 2,
        "c": 3
    }"""
  token = tokenize_json(content)
  assert token.as_dict() == {'a': 1, 'b': 2, 'c': 3}
  assert len(token) == 3
  assert token[0] == "a"
  assert token[1] == "b"
  assert token[2] == "c"



# Generated at 2022-06-22 06:20:41.591765
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='"[[1, 2, 3], [4, 5, 6]]"')
    assert decoder._TokenizingDecoder__dict__['content'] == '"[[1, 2, 3], [4, 5, 6]]"'


# Generated at 2022-06-22 06:20:46.143269
# Unit test for function tokenize_json
def test_tokenize_json():
    input_data = '{"a": 1, "b": 2}'
    token = tokenize_json(content=input_data)
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    children = [(k.value, v.value) for k, v in token.value.items()]
    assert children == [('a', 1), ('b', 2)]

# Generated at 2022-06-22 06:20:57.833493
# Unit test for function validate_json
def test_validate_json():
    assert(None, []) == validate_json("{}", field.Dict())
    assert({"a": 1}, []) == validate_json(
        '{"a": 1}',
        field.Dict({"a": field.Integer()}),
    )
    assert(
        {"a": 1},
        [
            ValidationError(
                text="Additional properties are not allowed",
                code="additional_properties",
                position=Position(char_index=4, line_no=1, column_no=5),
            )
        ],
    ) == validate_json(
        '{"a": 1, "b": 2}',
        field.Dict({"a": field.Integer()}),
    )

# Generated at 2022-06-22 06:21:07.233315
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.children == {}

    token = tokenize_json('{"key": "value"}')
    assert token.children[ScalarToken("key", 1, 3, '{"key": "value"}')] == ScalarToken(
        "value", 10, 15, '{"key": "value"}'
    )

    token = tokenize_json('{"key": []}')
    assert token.children[ScalarToken("key", 1, 3, '{"key": []}')] == ListToken(
        [], 10, 12, '{"key": []}'
    )



# Generated at 2022-06-22 06:21:13.942141
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json('{"key": "value"}')
    assert(value.value == {"key": "value"})
    assert(value.start_position.char_index == 0)
    assert(value.end_position.char_index == 15)


# Generated at 2022-06-22 06:21:24.788019
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Setups
    content = '{"field1": "value1", "field2": 2, "field3": null}'
    class TestDecoder(_TokenizingDecoder):
        pass
    decoder = TestDecoder(content=content)
    
    # Test
    assert isinstance(decoder, _TokenizingDecoder)
    assert decoder.parse_string == scanstring
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.strict == True
    assert decoder.memo == {}
    assert decoder.scan_once("", 0) == (
        ScalarToken(value=None, start=0, end=3, content=''),
        4
    )

# Generated at 2022-06-22 06:21:36.947607
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    from json import JSONDecodeError
    from pprint import pprint

    from .tokens import Token, DictToken, ListToken, ScalarToken

    def type_check(token, *expected_types):
        types = tuple((t.__name__ for t in expected_types))
        assert isinstance(token, expected_types), f"Expected token to be one of {types}, but was {token.__class__.__name__}"

    def test_token(data, token):
        assert data == token.value
        return token

    assert tokenize_json("{}") == test_token({}, DictToken({}, 0, 1, "{}"))


# Generated at 2022-06-22 06:21:42.503072
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '''{
                    "test_key_1" : "test_value_1",
                    "test_key_2" : "test_value_2"
                }'''

    result = _TokenizingDecoder(content=content)
    assert isinstance(result, _TokenizingDecoder)


# Generated at 2022-06-22 06:21:53.698221
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = (
        '{"somekey": "somevalue", "somekey2": {"anotberkey": "anothervalue"}}'
    )
    assert _TokenizingDecoder(content=content).scan_once(
        content, 0
    ) == (DictToken({
        ScalarToken(
            "somekey", 0, 8, content
        ): ScalarToken(
            "somevalue", 10, 19, content
        ),
        ScalarToken(
            "somekey2", 21, 29, content
        ): DictToken({
            ScalarToken(
                "anotberkey", 31, 41, content
            ): ScalarToken(
                "anothervalue", 43, 54, content
            )
        }, 31, 54, content)
    }, 0, 54, content), 55)


# Generated at 2022-06-22 06:21:57.942007
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name":"jane","age":30}'
    tokens = tokenize_json(content)
    expected_value = {
        'name': 'jane',
        'age': 30,
    }
    assert tokens.value == expected_value



# Generated at 2022-06-22 06:22:08.820384
# Unit test for function validate_json
def test_validate_json():
    content = b'{"integer": 1, "float": 1.1, "string": "abc", "bool": true, "list": [1, 2, 3]}'
    errors = validate_json(content, {
        "integer": "integer",
        "float": "float",
        "string": "string",
        "bool": "boolean",
        "list": "list"
    })
    assert len(errors) == 0
    # Test edge case with multiple errors
    errors = validate_json(content, {
        "integer": "float",
        "float": "float",
        "string": "float",
        "bool": "float",
        "list": "float"
    })
    assert len(errors) == 5



# Generated at 2022-06-22 06:22:10.731138
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("")

# Generated at 2022-06-22 06:22:23.501683
# Unit test for function validate_json
def test_validate_json():
    str_content = '''{
        "id": 11,
        "title": "A story about the future",
        "body": "The body of the article...\nMostly filler text.",
        "publication_date": "2018-06-20",
        "published": true,
        "author": {
            "id": 12,
            "name": "John Doe",
            "email": "john.doe@example.com",
            "organization": "The Example Company"
        },
        "tags": ["future", "fiction", "story", "example"],
        "suggestions": []
    }
    '''

    class Article(Schema):
        id = Field(type="integer")
        title = Field(type="string", max_length=50)
        body = Field(type="string")
        publication_date

# Generated at 2022-06-22 06:22:33.770762
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"number": 1.23}')
    assert type(token) == DictToken
    assert token.value == {"number": 1.23}
    assert token.start == 0
    assert token.end == len(b'{"number": 1.23}') - 1

    token = tokenize_json(b'{"number": 1.23}')
    assert type(token) == DictToken
    assert token.value == {"number": 1.23}
    assert token.start == 0
    assert token.end == len(b'{"number": 1.23}') - 1

    token = tokenize_json(b'{"number": 1.23}')
    assert type(token) == DictToken
    assert token.value == {"number": 1.23}
    assert token.start == 0
   

# Generated at 2022-06-22 06:22:37.305061
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder("")  # pass

# Generated at 2022-06-22 06:22:39.496125
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="some string")
    # Check that the scan_once callable is properly set
    assert callable(decoder.scan_once)

# Generated at 2022-06-22 06:22:41.320511
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert type(_TokenizingDecoder()) == _TokenizingDecoder


# Generated at 2022-06-22 06:22:46.261101
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = ""
    decoder = _TokenizingDecoder(content=content)
    assert decoder.strict is True
    assert decoder.parse_float is float
    assert decoder.parse_int is int
    assert decoder.parse_constant is JSONDecoder.parse_constant
    assert decoder.object_hook is None
    assert decoder.object_pairs_hook is None



# Generated at 2022-06-22 06:22:49.451171
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    #test 1
    decoder = _TokenizingDecoder(content="{\"a\":1}")
    print(decoder)
    #test 2
    decoder = _TokenizingDecoder(content="{\"a\":1}")
    print(decoder)


# Generated at 2022-06-22 06:22:55.805154
# Unit test for function validate_json
def test_validate_json():
    # Successful validation
    validator = Field(type="string", pattern=r"\d{3}-\d{2}-\d{4}")
    content = '"111-22-3333"'
    assert validate_json(content, validator) == ('111-22-3333', [])

    # Parse error results in a ParseError message
    content = '"111-22-3333'
    (value, error_messages) = validate_json(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == "parse_error"

    # Validation error results in a ValidationError message
    content = '"111-2233"'
    (value, error_messages) = validate_json(content, validator)

# Generated at 2022-06-22 06:22:56.589791
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="asdf")


# Generated at 2022-06-22 06:23:08.514597
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"a"') == ScalarToken(value="a", start=0, end=2, content='"a"')
    assert tokenize_json('"a"') != ScalarToken(value="b", start=0, end=2, content='"b"')
    assert tokenize_json('"a"') != ScalarToken(value="a", start=2, end=4, content='"a"')
    assert tokenize_json('"a"') != ScalarToken(value="a", start=0, end=4, content='"a"')
    assert tokenize_json('"a"') != ScalarToken(value="a", start=1, end=3, content='"a"')

# Generated at 2022-06-22 06:23:11.527006
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    #pylint: disable=protected-access
    parser = _TokenizingDecoder()

    assert parser.scan_once is not None


# Generated at 2022-06-22 06:23:17.331339
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"hello": "world"}'
    decoder = _TokenizingDecoder(content=content)
    token, _ = decoder.scan_once(content, 0)
    assert token == DictToken({"hello": "world"}, 0, len(content) - 1, content)


# Generated at 2022-06-22 06:23:27.735037
# Unit test for function validate_json
def test_validate_json():
    mean_schema = Schema.from_dict({"x": {"mean": 0}})
    field = Field.from_dict({"mean": 0})

    assert validate_json(b'{"x": 1}', mean_schema) == ({"x": 1}, [])
    assert validate_json(b'{"x": "abc"}', mean_schema) == ({"x": "abc"}, [])

    x_mean = Message(code="mean", field="x", position=Position(column_no=3))
    assert validate_json(b'{"x": 1}', field) == (1, [x_mean])
    assert validate_json(b'{"x": "abc"}', field) == ("abc", [x_mean])

# Generated at 2022-06-22 06:23:28.735385
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="a")

# Generated at 2022-06-22 06:23:41.551319
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    A function to unit test the tokenize_json function.
    """
    import json

    text1 = "{'a': 1, 'b': 2}"
    text2 = '{"a": 1, "b": 2}'
    text3 = '{"a": 1}'
    text4 = '{"a": {"b": {"c": {"d": 1}}}}'
    text5 = '{}'
    text6 = '{"a": 1}{"a": 2}'
    text_error = '{"a": 1'

    dict1 = {'a':1,'b':2}
    dict2 = {'a':1}
    dict4 = {'a':{'b':{'c':{'d':1}}}}
    dict5 = {}

# Generated at 2022-06-22 06:23:53.461421
# Unit test for function validate_json
def test_validate_json():
    class Person(Field):
        type = "object"
        properties = {"name": {"type": "string"}}
    input = """{
        "name": "Alice"
    }"""
    expected = ({'name' : 'Alice'}, [])
    assert validate_json(input, Person) == expected
    assert validate_json(input.encode("utf-8"), Person) == expected
    non_json = 'validate_json(input.encode("utf-8"), Person)'
    try:
        validate_json(non_json, Person)
    except ParseError:
        pass
    else:
        raise AssertionError("ParseError expected")
    assert validate_json("", Person) == (None, [])
    assert validate_json("\n", Person) == (None, [])
    assert validate_json

# Generated at 2022-06-22 06:24:02.181551
# Unit test for function tokenize_json
def test_tokenize_json():
    # It should convert a JSON string to a token sequence
    content = '{"key": ["value", "value2"]}'
    token = tokenize_json(content)
    assert token.start_index == 0
    assert token.end_index == 23
    assert type(token) == DictToken
    assert token.position.line_no == 1
    assert token.position.column_no == 1
    assert token.position.char_index == 0
    assert token.values[0][0].start_index == 2
    assert token.values[0][0].end_index == 6
    assert type(token.values[0][0]) == ScalarToken

    # It should throw an exception if the string is a malformed JSON
    content = '{"akey": ["value", "value2"]}'

# Generated at 2022-06-22 06:24:03.727765
# Unit test for constructor of class _TokenizingDecoder

# Generated at 2022-06-22 06:24:06.899563
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content=""), _TokenizingDecoder)


# Generated at 2022-06-22 06:24:10.677542
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json(content='{"foo": "bar"}')
    assert token.value == {"foo": "bar"}
    assert token.start == 0
    assert token.end == 13


# Generated at 2022-06-22 06:24:20.813548
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for default value
    content1 = ""
    try:
        token1 = tokenize_json(content1)
    except:
        assert True
    else:
        assert False

    # Test for string
    content2 = '"test"'
    try:
        token2 = tokenize_json(content2)
    except:
        assert False
    else:
        assert token2.python_value == "test"

    # Test for integer
    content3 = "123"
    try:
        token3 = tokenize_json(content3)
    except:
        assert False
    else:
        assert token3.python_value == 123

    # Test for float
    content4 = "123.456"
    try:
        token4 = tokenize_json(content4)
    except:
        assert False
   

# Generated at 2022-06-22 06:24:27.637030
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = "{\"name\":\"sai\",\"age\":6,\"male\":false}"
    decoder = _TokenizingDecoder(json_str, content = "mock_file_name")
    decoder.strict = False
    decoder.parse_int = int
    decoder.parse_float = float
    decoder.parse_array = JSONDecoder.parse_array
    result = decoder.scan_once(json_str, 0)
    assert result[0]


# Generated at 2022-06-22 06:24:33.094342
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with pytest.raises(TypeError):
        _TokenizingDecoder()


# Generated at 2022-06-22 06:24:40.601476
# Unit test for function validate_json
def test_validate_json():
    content = '{"show_in_menu": true, "name": "foo"}'
    expected_value = {'show_in_menu': True, 'name': 'foo'}
    schema = schema_class({"show_in_menu": Boolean, "name": String})
    value, errors = validate_json(content, schema)
    assert errors == []
    assert value == expected_value
    value, errors = validate_json(content, schema)
    assert errors == []
    assert value == expected_value


# Generated at 2022-06-22 06:24:41.957632
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__

# Generated at 2022-06-22 06:24:48.912948
# Unit test for function tokenize_json
def test_tokenize_json():
    validator = Field(type="string")
    content = '{"value": "This is a string"}'
    token = tokenize_json(content)
    assert token.children[0].children[0].value == "value"
    assert token.children[0].children[1].value == "This is a string"
    assert validate_with_positions(token=token, validator=validator) == (
        validator.deserialize("This is a string"),
        [],
    )



# Generated at 2022-06-22 06:24:51.484377
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    validator = Field(type="string")
    json_str = "'hello'"
    with pytest.raises(ParseError):
        value, _ = validate_json(json_str, validator)

# Generated at 2022-06-22 06:24:57.198012
# Unit test for function validate_json
def test_validate_json():
    content = b'{"username": "johndoe4", "password": "p@ssw0rd"}'
    validator = Schema.define({"username": str, "password": str})

    value, error_messages = validate_json(content, validator)

    assert value == {"username": "johndoe4", "password": "p@ssw0rd"}
    assert error_messages == []


# Generated at 2022-06-22 06:25:08.813876
# Unit test for function validate_json
def test_validate_json():

    #### Test Functionality ####

    # Create a simple schema.
    schema = Schema({"name": "str", "weight": "int"})

    # Create a valid JSON string.
    valid_json = '{"name": "Kuro", "weight": 47}'

    # Decode and validate the string against the schema.
    value, errors = validate_json(content=valid_json, validator=schema)

    # The value will be a validated data structure.
    assert value == {"name": "Kuro", "weight": 47}

    # There will be no errors.
    assert errors == []

    #### Test Invalid JSON ####

    # Create an invalid JSON string.  Note that the string is not wrapped in
    # quotation marks.
    invalid_json = "{name: 'Kuro', weight: 47}"

    # Try to

# Generated at 2022-06-22 06:25:13.893224
# Unit test for function validate_json
def test_validate_json():
    schema = {"name": "test", "fields": [{"name": "test", "type": "string"}]}
    content = b'{"test": "ok"}'
    value, errors = validate_json(content, schema)
    assert value == {"test": "ok"}
    assert not errors

# Generated at 2022-06-22 06:25:20.324353
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = b"{'yes':'no'}"
    test_strict = True
    test_scanstring = scanstring
    test_memo = {}
    decoder = _TokenizingDecoder(strict=test_strict,
                                 scan_once=test_scanstring,
                                 memo=test_memo,
                                 content=test_content)
    assert decoder.strict == test_strict
    assert decoder.scan_once == test_scanstring
    assert decoder.memo == test_memo


# Generated at 2022-06-22 06:25:21.391572
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == {'a': 'b'} # type: ignore



# Generated at 2022-06-22 06:25:26.097192
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{}'), type(Token()))



# Generated at 2022-06-22 06:25:31.728863
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float
    from .simple import SimpleNestedSchema

    for field in (String(), Integer(), Float()):
        # Test decode with a value that is valid for the field.
        value = field.validate_with_position(field.example())
        assert value == tokenize_json(field.example())

        # Test decode with a value that is not valid for the field.
        with pytest.raises(ValidationError):
            tokenize_json({"type": field.primitive_type, "name": "field", "required": True})

    # Test decode with a schema that is valid.
    schema = SimpleNestedSchema

# Generated at 2022-06-22 06:25:45.087828
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    
    # Testing for input as string.
    decoder = _TokenizingDecoder(strict=False, content="input")
    assert decoder.strict == False and decoder.scan_once == _make_scanner(decoder, "input")
    
    # Testing for input as json object.
    input_object = {
        "name": "John",
        "age": 30,
        "address": {
            "streetAddress": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "postalCode": "10021",
        },
    }
    decoder = _TokenizingDecoder(strict=True, content=input_object)
    assert decoder.strict == True and decoder.scan_once == _make_scanner(decoder, input_object)

# Generated at 2022-06-22 06:25:57.191600
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_tokenize_json(content: str, expected: Token) -> None:
        """
        Helper function to generically test tokenize_json function
        """
        actual = tokenize_json(content)
        assert actual == expected

    # simple token (int)
    assert_tokenize_json(
        '{"a": 1}', DictToken({"a": ScalarToken(1, 2, 5, '{"a": 1}')}, 0, 7, '{"a": 1}')
    )
    assert_tokenize_json(
        '{"a": 2}', DictToken({"a": ScalarToken(2, 2, 5, '{"a": 2}')}, 0, 7, '{"a": 2}')
    )
    # simple token (float)

# Generated at 2022-06-22 06:26:08.093972
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 2}') == DictToken({ScalarToken('a', 1, 1, '{"a": 2}'): ScalarToken(2, 5, 5, '{"a": 2}')}, 0, 7, '{"a": 2}')

# Generated at 2022-06-22 06:26:13.727541
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 2}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": 2}'): ScalarToken(2, 5, 6, '{"a": 2}')},
        0, 8, '{"a": 2}'
    )


# Generated at 2022-06-22 06:26:24.905090
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo":"bar"}'
    validator = "text"
    token = tokenize_json(content)
    assert validate_json(content, validator) == (content, [])
    content = '{"foo":"bar"}'
    validator = "number"
    token = tokenize_json(content)
    assert validate_json(content, validator) == (content, [])
    content = '{"foo":"bar"}'
    validator = "boolean"
    token = tokenize_json(content)
    assert validate_json(content, validator) == (content, [])
    content = '{"foo":"bar"}'
    validator = "null"
    token = tokenize_json(content)
    assert validate_json(content, validator) == (content, [])

# Generated at 2022-06-22 06:26:28.029459
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    dec = _TokenizingDecoder(content = "some_content")
    print(dec.scan_once)
    print(dec.scan_once(s = "some_string", idx = 0))


# Generated at 2022-06-22 06:26:37.347162
# Unit test for function tokenize_json
def test_tokenize_json():
    # pylint: disable=redefined-outer-name
    with pytest.raises(ParseError):
        tokenize_json("")

    with pytest.raises(ParseError):
        tokenize_json("{")

    with pytest.raises(ParseError):
        tokenize_json('{"key": 1, ')

    with pytest.raises(ParseError):
        tokenize_json('{"key": foo}')

    with pytest.raises(ParseError):
        tokenize_json(
            '{"key": 1,\n"key2": 1,\n"key3": 1',
        )

    assert tokenize_json("{}") == {}

    assert tokenize_json('{"key": 1}') == {"key": 1}


# Generated at 2022-06-22 06:26:39.638854
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.scan_once("test", 0) == (None, 4)


# Generated at 2022-06-22 06:26:50.799534
# Unit test for function validate_json
def test_validate_json():
    content = '{"test": "value"}'
    validator = Schema(test=String(required=True))

    value, error_messages = validate_json(content, validator)

    assert isinstance(value, dict)
    assert value == {'test': 'value'}
    assert len(error_messages) == 0


# Generated at 2022-06-22 06:27:03.228753
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ScalarToken

    assert isinstance(tokenize_json('"foo"'), ScalarToken)
    assert isinstance(tokenize_json('42'), ScalarToken)
    assert tokenize_json('42').value == 42
    assert tokenize_json('null').value is None

    # Test the validation of JSON data against a typesystem type.
    try:
        validate_json('"foo"', String(max_length=1))
    except ValidationError as err:
        print(err.messages)
        assert len(err.messages) == 1
        assert err.messages[0].text == "Must have no more than 1 characters."
        assert err.messages[0].code == "max_length"
    else:
        assert False

# Generated at 2022-06-22 06:27:15.450196
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    def compare_tokens(test_token_list, test_content, library_token_list, library_content):
        test_token_list_index = 0
        library_token_list_index = 0
        while test_token_list_index < len(test_token_list) and library_token_list_index < len(library_token_list):
            test_token = test_token_list[test_token_list_index]
            library_token = library_token_list[library_token_list_index]
            test_content_index_start, test_content_index_end = test_token.content_indices
            test_name = test_content[test_content_index_start:test_content_index_end+1]
            library_content_index_start, library_content_index

# Generated at 2022-06-22 06:27:17.230252
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test a constructor with valid argument
    assert _TokenizingDecoder(content="str")
    # Test a constructor with invalid argument
    with pytest.raises(JSONDecodeError):
        _TokenizingDecoder()

# Generated at 2022-06-22 06:27:28.225117
# Unit test for function validate_json
def test_validate_json():
    content = b'{"a": 1}'
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.error_messages import ErrorMessage
    from typesystem.error_types import ErrorType

    class TestSchema(Schema):
        a = Integer(required=True)

    value, error_messages = validate_json(content, TestSchema)
    assert value == {"a": 1}
    assert error_messages == []

    content = b'{"a": null}'
    value, error_messages = validate_json(content, TestSchema)
    assert value == {"a": None}
    assert error_messages == []

    content = b'{"b": 1}'
    value, error_messages = validate_json(content, TestSchema)

# Generated at 2022-06-22 06:27:34.722052
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class Dummy(object):
        pass
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, JSONDecoder) is True
    decoder.scan_once("{}", 0)
    decoder2 = _TokenizingDecoder(content="{}")
    assert isinstance(decoder2, JSONDecoder) is True
    assert decoder2.scan_once("{}", 0) is not None


# Generated at 2022-06-22 06:27:39.924088
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content="[{\'name\': \'a\', \'age\': 34}]"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0) ==({'name': 'a', 'age': 34},27)

# Generated at 2022-06-22 06:27:51.069194
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class MySchema(Schema):
        name = String()

    class Error(Exception):
        pass

    class MyInvalidSchema(Schema):
        name = String()

        def validate_name(self, value):
            raise Error(value)

    # Test validator being a Field
    content = '{"name": "test"}'
    value, error_messages = validate_json(content, String())
    assert error_messages == []
    assert value == "test"

    # Test validator being a Schema
    content = '{"name": "test"}'
    value, error_messages = validate_json(content, MySchema())
    assert error_messages == []
    assert value == {"name": "test"}

    #

# Generated at 2022-06-22 06:27:57.652990
# Unit test for function validate_json
def test_validate_json():
    """
    >>> from typesystem import String
    >>> d = {'a': 1, 'b': 2}
    >>> v, e = validate_json(d, String())
    >>> e[0].code == "parse_error"
    True
    >>> v, e = validate_json('{"a": 1, "b": 2}', String())
    >>> e[0].code == "invalid_type"
    True
    """

# Generated at 2022-06-22 06:28:02.440693
# Unit test for function validate_json
def test_validate_json():
    content = "longitude"
    assert validate_json(content, validator=float) == (None, [
        {"code": "type_error", "position": {"line_no": 1, "column_no": 1, "char_index": 0}, "text": "Not a float."},
    ])