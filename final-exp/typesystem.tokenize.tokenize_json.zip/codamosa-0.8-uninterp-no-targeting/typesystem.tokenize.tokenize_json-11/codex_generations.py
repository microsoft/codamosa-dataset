

# Generated at 2022-06-22 06:18:55.983964
# Unit test for function tokenize_json
def test_tokenize_json():
    # test null, true, false, float, int
    assert tokenize_json(b'null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json(b'true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json(b'false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json(b'100.456') == ScalarToken(100.456, 0, 7, '100.456')
    assert tokenize_json(b'-100.456') == ScalarToken(-100.456, 0, 8, '-100.456')
    assert tokenize_json(b'100') == ScalarToken(100, 0, 2, '100')

    # test list and dict

# Generated at 2022-06-22 06:19:01.807904
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"name": "james"}', Schema({
                                                'fields': {
                                                    'name': String()
                                                }
                                            })) == ({'name': 'james'}, None)
    

# Generated at 2022-06-22 06:19:06.925911
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class MyDecoder(JSONDecoder):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any):
            kwargs.pop("content")
            super().__init__(*args, **kwargs)
            pass
    assert MyDecoder is not None


# Generated at 2022-06-22 06:19:12.014935
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"name": "Charminar"}')
    assert isinstance(result, DictToken)
    assert result.value == {"name": "Charminar"}

    result = tokenize_json('{"name": 1}')
    assert isinstance(result, DictToken)
    assert result.value == {"name": 1}


# Generated at 2022-06-22 06:19:23.051552
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"x": [1,2,3],"y": {"a": {}}}'
    token = tokenize_json(content)
    assert token.kind == "dict"
    assert token.start == 0
    assert token.end == len(content) - 1
    assert token.content == content
    assert token.value == {"x": [1,2,3],"y": {"a": {}}}

# Generated at 2022-06-22 06:19:32.682884
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
    "key": "value",
    "key2": "another value"
}
"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"key": "value", "key2": "another value"}
    assert token.start_position.char_index == 0
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.char_index == len(content) - 1
    assert token.end_position.line_no == 8
    assert token.end_position.column_no == 1


# Generated at 2022-06-22 06:19:42.786752
# Unit test for function validate_json
def test_validate_json():
    '''
    Test a successful validation.

    >>> class TestSchema(Schema):
    ...     name = String()
    ...     age = Integer()
    ...     title = String()
    >>> value, error_messages = validate_json(b'{"name": "John", "age": 30, "title": "Manager"}', TestSchema)
    >>> assert error_messages == []
    >>> assert value == {"name": "John", "age": 30, "title": "Manager"}
    '''


# Generated at 2022-06-22 06:19:46.502409
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar", "baz": {"qux": [1, 2, 3]}}') == {
        "foo": "bar",
        "baz": {"qux": [1, 2, 3]},
    }

test_tokenize_json()

# Generated at 2022-06-22 06:19:54.107743
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.fields import String

    schema = String(min_length=1)
    assert validate_json(json.dumps("a"), schema) == ("a", None)
    assert validate_json(json.dumps(""), schema) == (
        None,
        [
            Message(
                code=None,
                text="Must be at least 1 characters.",
                position=Position(column_no=1, line_no=1, char_index=1),
            )
        ],
    )

# Generated at 2022-06-22 06:20:02.059225
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': 'bar'}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json('[]') == ListToken([], 0, 1, '[]')
    assert tokenize_json('[1, 2]') == ListToken([1, 2], 0, 5, '[1, 2]')

# Generated at 2022-06-22 06:20:19.529599
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content=""), JSONDecoder)

# Generated at 2022-06-22 06:20:31.867921
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Check the results of tokenize_json
    """
    token = tokenize_json('{"hello":"world"}')
    assert isinstance(token, DictToken)
    assert token.children == {
        ScalarToken('hello', 1, 7, '{"hello":"world"}'): ScalarToken(
            'world', 10, 17, '{"hello":"world"}'
        )
    }

    token = tokenize_json('[1, 2, 3]')
    assert isinstance(token, ListToken)
    assert token.children == [
        ScalarToken(1, 1, 2, '[1, 2, 3]'),
        ScalarToken(2, 4, 5, '[1, 2, 3]'),
        ScalarToken(3, 7, 8, '[1, 2, 3]'),
    ]


# Generated at 2022-06-22 06:20:42.341091
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{\"a\": 1}") == DictToken(
        {"a": ScalarToken(1, 2, 4, "{\"a\": 1}")}, 0, 7, "{\"a\": 1}"
    )
    assert tokenize_json("[1, 2]") == ListToken(
        [ScalarToken(1, 1, 2, "[1, 2]"), ScalarToken(2, 5, 6, "[1, 2]")],
        0,
        7,
        "[1, 2]",
    )
    assert tokenize_json("{}") == DictToken({}, 0, 2, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 2, "[]")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")

# Generated at 2022-06-22 06:20:50.392691
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class ExampleSchema(Schema):
        name = String(min_length=1)
        description = String()

    json_str = b"""
    {
      "name": "Bike",
      "description": "A shiny new bike."
    }
    """
    value, error_messages = validate_json(json_str, ExampleSchema)
    assert value == {"name": "Bike", "description": "A shiny new bike."}
    assert error_messages == []


# Generated at 2022-06-22 06:20:53.382991
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    if _TokenizingDecoder.__init__.__doc__ is None:
        raise Exception("No __doc__ for _TokenizingDecoder.__init__")



# Generated at 2022-06-22 06:21:03.853353
# Unit test for function validate_json
def test_validate_json():
    import pytest
    from typesystem.fields import String, Integer, Map
    from typesystem.lib.cbor import CBORField

    schema = Map(
        {
            "title": String(),
            "age": Integer(),
            "phone_number": CBORField(allow_empty=True),
        }
    )

    # Test successful validation
    payload = """
    {
        "title": "Mr.",
        "age": 27,
        "phone_number": "414-214-1245"
    }
    """
    value, errors = validate_json(payload, schema)
    assert not errors
    assert value == {"title": "Mr.", "age": 27, "phone_number": b"414-214-1245"}

    # Test failed validation

# Generated at 2022-06-22 06:21:07.588153
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(r'{"a": 42}')
    assert token.properties["a"].value == 42



# Generated at 2022-06-22 06:21:11.694971
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = '{"a":1}'
    decoder = _TokenizingDecoder(content=test_content)
    assert decoder.scan_once == _make_scanner(decoder, test_content)


# Generated at 2022-06-22 06:21:22.684036
# Unit test for function tokenize_json
def test_tokenize_json():
    # Testing with a simple string
    str_string = '"string"'
    value, error_messages = validate_json(str_string, validator=Field())
    assert value == "string"
    assert error_messages == []

    # Testing with a boolean (True)
    bool_string = "true"
    value, error_messages = validate_json(bool_string, validator=Field())
    assert value is True
    assert error_messages == []

    # Testing with a boolean (False)
    bool_string = "false"
    value, error_messages = validate_json(bool_string, validator=Field())
    assert value is False
    assert error_messages == []

    # Testing with None
    null_string = "null"

# Generated at 2022-06-22 06:21:31.809330
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function
    """
    # Test valid json content
    json_content = '{"int_val": 1, "str_val": "a string", "float_val": 1.3}'
    json_schema = Schema(
        fields={
            "int_val": Field(description="an integer"),
            "str_val": Field(description="a string"),
            "float_val": Field(description="a float"),
        }
    )
    value, error_messages = validate_json(json_content, json_schema)
    assert not error_messages
    assert value['int_val'] == 1
    assert value['str_val'] == 'a string'
    assert value['float_val'] == 1.3

    # Test invalid json content

# Generated at 2022-06-22 06:21:50.375107
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String
    from typesystem.schemas import Schema
    from freezegun import freeze_time
    from datetime import datetime

    class SampleSchema(Schema):
        class Meta:
            position_markers = True
        name = String()
        age = String()
        timestamp = String()
        deleted = String()

    sample_good_data = {
        "name": "John Doe",
        "age": "30",
        "timestamp": "2020-07-10T13:37:00.000000Z",
        "deleted": "0",
    }


# Generated at 2022-06-22 06:21:53.013189
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class test_Decoder(JSONDecoder):
        def __init__():
            pass 
    assert(test_Decoder) == _TokenizingDecoder


# Generated at 2022-06-22 06:22:03.119614
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="Dummy")
    assert decoder.parse_float("1.0") == 1.0
    assert decoder.parse_float("10e10") == 10000000000.0
    assert decoder.parse_float("10.0e10") == 10000000000.0
    assert decoder.parse_float("10.0e-10") == 0.0000000001
    assert decoder.parse_int("10") == 10
    assert decoder.parse_int("-10") == -10
    assert decoder.parse_int("True") == 1
    assert decoder.parse_int("False") == 0
    assert decoder.strict is False
    assert decoder.parse_constant("True") is True
    assert decoder.parse_constant("False") is False

# Generated at 2022-06-22 06:22:14.574651
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, fields
    from typesystem.validators import max_length

    class Person(Schema):
        id = fields.Integer(required=True)
        name = fields.String(required=True, validators=[max_length(10)])
        age = fields.Integer(required=True)

        class Meta:
            ordered = True

    source = b'{"id": 1, "name": "John Doe", "age": 55}'
    value, errors = validate_json(source, Person())
    assert value == {"id": 1, "name": "John Doe", "age": 55}
    assert len(errors) == 0

    # invalid data
    source = b'{"id": 1, "name": "John Doe", "age": "55"}'
    value, errors = validate_json(source, Person())


# Generated at 2022-06-22 06:22:26.660786
# Unit test for function validate_json
def test_validate_json():
    content = '[1, 2, 3]'
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_json(content, validator)
    assert error_messages == []
    assert value == [1, 2, 3]

    content = '[1, 2, "3"]'
    validator = Field(type="array", items=Field(type="integer"))
    value, error_messages = validate_json(content, validator)
    assert error_messages == [
        ValidationError(
            text="wrong_type",
            code="wrong_type",
            position=Position(
                char_index=6, column_no=7, line_no=1,
            ),
        )
    ]
    assert value is None


# Generated at 2022-06-22 06:22:29.710304
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = '"test content"'
    test_decoder = _TokenizingDecoder(content=test_content)
    assert test_decoder.content == test_content


# Generated at 2022-06-22 06:22:34.401709
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that it can recognize valid JSON
    """
    import json
    import re

    json_samples = json.loads(open('./json-samples.json').read())
    for sample in json_samples:
        if re.match(r'^\[.*\]$', sample):
            sample = json.loads(sample)
        assert tokenize_json(sample)



# Generated at 2022-06-22 06:22:37.891091
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": [1, 2, {"bar": true}]}'
    decoder = _TokenizingDecoder(content = content)
    assert isinstance(decoder,_TokenizingDecoder)

# Generated at 2022-06-22 06:22:44.083467
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenized_dict = {"a": "1", "b": "2"}
    assert tokenize_json('{"a":"1","b":"2"}') == tokenized_dict
    assert tokenize_json(b'{"a":"1","b":"2"}') == tokenized_dict
    with pytest.raises(ParseError):
        tokenize_json('')
    with pytest.raises(ParseError):
        tokenize_json('[')


# Generated at 2022-06-22 06:22:52.155735
# Unit test for function validate_json
def test_validate_json():
    test_schema_json = b'{"name": "Test", "type": "object", "properties": {"prop1": {"type": "string"}}}'
    test_valid_json = b'{"prop1": "hello"}'
    test_invalid_json = b'{"prop1": 123}'

    value, errors = validate_json(test_schema_json, Schema)
    schema = value

    value, errors = validate_json(test_valid_json, schema)
    assert value == {"prop1": "hello"}
    assert errors == []

    value, errors = validate_json(test_invalid_json, schema)
    assert value == {"prop1": 123}

# Generated at 2022-06-22 06:23:06.176611
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String
    from typesystem import Schema

    # Test that tokenize_json can parse a simple JSON object
    json_string = r"""
    {
        "test": "ok"
    }
    """
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert token.to_dict() == {"test": "ok"}

    # Test that tokenize_json can parse a simple JSON list
    json_string = r"""
    [
        "ok",
        "ok"
    ]
    """
    token = tokenize_json(json_string)
    assert isinstance(token, ListToken)
    assert token.to_list() == ["ok", "ok"]

    # Test that tokenize_json can parse a simple JSON array
    json_string

# Generated at 2022-06-22 06:23:18.120624
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import BooleanField, TextField, IntegerField, ObjectField

    token = tokenize_json('{"text": ["this is a string"]}')
    assert token.value == {"text": ["this is a string"]}, "tokenized json"

    def test_validate_json():
        my_schema = Schema(fields={"my_bool": BooleanField(), "my_text": TextField()})
        value, error_messages = validate_json(
            content='{"my_bool": true, "my_text": "hello"}', validator=my_schema
        )

        assert value == {"my_bool": True, "my_text": "hello"}, "value"

        assert error_messages == [], "error_messages"


# Generated at 2022-06-22 06:23:29.071706
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields=[
        Field(name="string", type="string"),
        Field(name="array", type="array", items=Field(type="string"))
    ])

    content = '{"string": "my string", "array": ["my", "array"]}'
    value, error_messages = validate_json(content, schema)
    assert value == {"string": "my string", "array": ["my", "array"]}
    assert error_messages == []

    content = '{"string": "my string", "array": ["my", 1]}'
    with pytest.raises(ValidationError) as e:
        validate_json(content, schema)

# Generated at 2022-06-22 06:23:42.006801
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema, fields as f
    from json import loads

    class Post(Schema):
        title = f.String(title="Title", max_length=100)
        like_count = f.Integer(title="Like Count", minimum=0, maximum=1000)
        is_published = f.Boolean(title="Is Published")
        author = f.String(title="Author", max_length=50)

    schema = Post()

    json_input = """
        {
            "title" : "Title",
            "like_count" : 500,
            "is_published" : true,
            "author" : "Author"
        }
    """
    json_loads = loads(json_input)
    results = validate_json(json_input, schema)
    assert len(results) == 1

# Generated at 2022-06-22 06:23:51.469769
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.test_tokens import test_DictToken, test_ListToken, test_ScalarToken
    from typesystem.tokenize.test_positional_validation import test_ValidationError, test_Message

    # Test case for object
    _TokenizingDecoder(content='{"first": "hello", "second": 123}')
    assert test_DictToken.value == {ScalarToken("first", 0, 4, '{"first": "hello", "second": 123}'): ScalarToken("hello", 9, 14, '{"first": "hello", "second": 123}'), ScalarToken("second", 18, 24, '{"first": "hello", "second": 123}'): ScalarToken(123, 29, 31, '{"first": "hello", "second": 123}')}
    test_D

# Generated at 2022-06-22 06:24:00.863118
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import validator

    class JSONSchema(Schema):
        """
        A simple schema for testing only.
        """

        name = validator.String(min_length=1, max_length=10)
        age = validator.Integer(gte=18)

    # Test both the Base64 and string API.
    valid_input = '{"name": "John", "age": 20}'
    value, errors = validate_json(valid_input, JSONSchema())
    assert len(errors) == 0
    assert value == {"name": "John", "age": 20}

    invalid_input = '{"name": "John", "age": 15}'
    value, errors = validate_json(invalid_input, JSONSchema())
    assert len(errors) == 1

# Generated at 2022-06-22 06:24:12.710146
# Unit test for function tokenize_json
def test_tokenize_json():
    # Verify error handling
    try:
        tokenize_json("abcd")
        assert False
    except ParseError:
        pass

    # Verify correct handling of basic JSON types
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json('"hello"') == ScalarToken("hello", 0, 7, '"hello"')
    assert tokenize_json("42") == ScalarToken(42, 0, 2, "42")
    assert tokenize_json("42.0") == ScalarToken(42.0, 0, 4, "42.0")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")

   

# Generated at 2022-06-22 06:24:21.990783
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    assert (
        excinfo.value.position
    ) == Position(column_no=1, line_no=1, char_index=0)

    # Test for empty string with comment
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("   # Comment   \n")
    assert excinfo.value.text == "No content."
    assert (
        excinfo.value.position
    ) == Position(column_no=1, line_no=1, char_index=0)

    # Test for single string
    result = tokenize_json('"Hello World"')

# Generated at 2022-06-22 06:24:30.289125
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('""') == ScalarToken("", 0, 1, '""')
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 4, "3.14")

# Generated at 2022-06-22 06:24:31.450917
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-22 06:24:47.078702
# Unit test for function validate_json
def test_validate_json():
    import pprint
    import pytest
    from typesystem.fields import String
    from json import loads

    validator = String()

    content = b'{"x": "1"}'
    value, messages = validate_json(content, validator)
    assert value == {"x": "1"}
    assert messages == []

    content = b'{"x": 1}'
    value, messages = validate_json(content, validator)
    assert value == {}
    assert messages == [
        {
            "code": "type_mismatch",
            "text": "Must be a string.",
            "position": {"column_no": 8, "line_no": 1, "char_index": 7},
            "name": "x",
        }
    ]


# Generated at 2022-06-22 06:24:57.718171
# Unit test for function validate_json

# Generated at 2022-06-22 06:25:09.243759
# Unit test for function validate_json
def test_validate_json():

    validator = Schema(fields=[
        Field(name="text", validators=["str"]),
        Field(name="number", validators=["int"]),
    ])

    content = '{"text":"valid_string", "number": 50}'
    token = tokenize_json(content)
    assert token == {'text': 'valid_string', 'number': 50}

    value, messages = validate_json(content, validator)
    assert value == {"text": "valid_string", "number": 50}
    assert messages == [], messages

    # error message if the content doesn't match the validator structure
    content = '{"text":"wrong_structure", "extra":"not_in_validator"}'
    token = tokenize_json(content)

# Generated at 2022-06-22 06:25:19.661946
# Unit test for function validate_json
def test_validate_json():
    # Test when called with a valid json string
    input_json_string = '{"test"}'
    actual = validate_json(input_json_string, Field())
    expected = ({}, [])
    assert(actual == expected)

    # Test when called with a valid json string and a Schema
    input_json_string = '{"test"}'
    class MyTestSchema(Schema):
        test = Field()
    
    actual = validate_json(input_json_string, MyTestSchema)
    expected = ({}, [])
    assert(actual == expected)

    # Test when called with a valid json string and a Schema
    input_json_string = '{"test":1}'
    class MyTestSchema(Schema):
        test = Field(key_type=int)
    
    actual = validate_json

# Generated at 2022-06-22 06:25:24.291141
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"bacon": 22}')
    assert isinstance(token, DictToken)
    assert token.value == {"bacon": ScalarToken(22, 10, 11, '{"bacon": 22}')}


# Unit tests for function validate_json

# Generated at 2022-06-22 06:25:24.787578
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert True



# Generated at 2022-06-22 06:25:36.635774
# Unit test for function validate_json
def test_validate_json():
    class MySchema(Schema):
        text = Field(
            str,
            required=True,
            max_length=30,
            validate_with=lambda text: text != "bad_input",
            error_code="bad",
            error_message="Don't do that.",
        )

    text = """{
        "text": "bad_input"
    }"""

    value, error_messages = validate_json(text, MySchema)
    assert error_messages == {
        "text": ValidationError(
            message="Don't do that.",
            code="bad",
            position=Position(column_no=33, line_no=2, char_index=32),
            validator=MySchema.text,
        )
    }

# Generated at 2022-06-22 06:25:38.877875
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder('content')
    assert decoder.content == 'content'

# Generated at 2022-06-22 06:25:44.836698
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    _TokenizingDecoder()
    _TokenizingDecoder(object_pairs_hook=json.loads)
    _TokenizingDecoder(parse_float=json.loads)
    _TokenizingDecoder(parse_int=json.loads)
    _TokenizingDecoder(object_hook=json.loads)
    _TokenizingDecoder(object_hook=json.loads,
                       parse_float=json.loads,
                       parse_int=json.loads,
                       parse_constant=json.loads,
                       strict=True,
                       object_pairs_hook=json.loads)
    _TokenizingDecoder(content="test")
    _TokenizingDecoder(object_pairs_hook=json.loads, content="test")
    _TokenizingDecoder(parse_float=json.loads, content="test")

# Generated at 2022-06-22 06:25:52.498547
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.scan_once.__code__.co_argcount == 2
    assert decoder.scan_once.__code__.co_varnames == ('string', 'idx')
    assert decoder.scan_once.__code__.co_names == ('parse_object', 'parse_array', 'parse_string', 'match_number', 'strict', 'parse_float', 'parse_int', 'memo', '_', '')


# Use python -m pytest tests/test_tokenizer.py -k test__TokenizingJSONObject to run this unit test

# Generated at 2022-06-22 06:26:06.089268
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = Integer()

    invalid_json = '''{
      "name": "tal",
      "age": "ten"
    }''';
    (_,error_messages) = validate_json(invalid_json, MySchema())
    assert(error_messages[0].code=="invalid_type")

    invalid_json = '''{
      "name": "tal",
    }''';
    (_,error_messages) = validate_json(invalid_json, MySchema())
    assert(error_messages[0].code=="required")

# Generated at 2022-06-22 06:26:09.550645
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(object_hook=None, parse_float=None, parse_int=None,
                       parse_constant=None, strict=True, object_pairs_hook=None)


# Generated at 2022-06-22 06:26:20.890029
# Unit test for function validate_json
def test_validate_json():
    def make_token(token_type, value, start, end):
        token = token_type(value, start, end, "content")
        return token

    # Testing a couple of different error cases

    validator = Field(required=True, primitive_type=str)
    token = make_token(ScalarToken, None, 0, 2)
    _, error_messages = validate_json(token, validator)
    message_texts = [message.text for message in error_messages]

    assert "Missing required value." in message_texts
    assert "Must be of type str." in message_texts

    validator = Field(required=True, primitive_type=int)
    token = make_token(ScalarToken, "abc", 0, 2)

# Generated at 2022-06-22 06:26:32.704059
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key1": "value1", "key2": ["value2", {"key3": "value3", "key4": ["value4", "value5"], "key6": "value6", "key7": "value7", "key8": "value8"}], "key9": true}'
    test_tokenize_json_result = tokenize_json(content)
    assert test_tokenize_json_result.val["key1"] #test_tokenize_json_result should be a valid json

# Generated at 2022-06-22 06:26:44.814411
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"foo":10}', {'foo': 'integer'}) == ({'foo': 10}, [])
    assert validate_json(b'{"foo":10.1}', {'foo': 'number'}) == ({'foo': 10.1}, [])
    assert validate_json(b'{"foo":"10"}', {'foo': 'string'}) == ({'foo':'10'}, [])

    validator = {"foo": "integer"}
    value, error_messages = validate_json(b'{"foo":10.1}', validator)
    assert error_messages[0].text=="10.1 is not of type 'integer'"
    assert error_messages[0].code=="type_mismatch"

    validator = {"foo": "integer", "bar": "string"}
   

# Generated at 2022-06-22 06:26:53.425642
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    validator = Field(type="string", max_length=20)
    content = '''{
    "name": "Pete"
    }'''

    decoder = _TokenizingDecoder(content=content)
    try:
        return decoder.decode(content)
    except JSONDecodeError as exc:
        # Handle cases that result in a JSON parse error.
        position = Position(column_no=exc.colno, line_no=exc.lineno, char_index=exc.pos)
        raise ParseError(text=exc.msg + ".", code="parse_error", position=position)

# Generated at 2022-06-22 06:27:01.011855
# Unit test for function validate_json
def test_validate_json():
    class PersonSchema(Schema):
        name = Field(type="string", min_length=2)
        age = Field(type="integer", required=False)

    data, errors = validate_json(
        """
        {
            "name": "lisa",
            "age": 12
        }
        """,
        PersonSchema,
    )

    assert data["name"] == "lisa"
    assert data["age"] == 12
    assert errors == []



# Generated at 2022-06-22 06:27:08.511729
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": 1, "b": "hi"}'
    validator = Schema({"a": int, "b": str})
    try:
        value, errors = validate_json(content, validator)
    except ParseError as exc:
        errors = [Message(text=exc.text, code=exc.code, position=exc.position)]
    assert not errors
    assert isinstance(value, dict)
    assert value["a"] == 1
    assert value["b"] == "hi"

# Generated at 2022-06-22 06:27:20.357559
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    # An empty JSON document.
    with pytest.raises(ParseError):
        tokenize_json("")

    # An invalid JSON document.
    with pytest.raises(ParseError):
        tokenize_json("[")

    # A valid JSON document.
    token = tokenize_json("[1, 2, 3]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]
    assert token.start == 0
    assert token.end == 8

    # A valid JSON document with whitespace around it.
    token = tokenize_json("\n\t[1, 2, 3]\n\n")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2, 3]

# Generated at 2022-06-22 06:27:28.797529
# Unit test for function validate_json
def test_validate_json():
    content = b'{"foo": "bar"}'
    field = Field(key="foo", required=True)
    assert validate_json(content, field) == ({'foo': "bar"}, None)

    content = b'{"foo": "bar"}'
    field = Field(key="foo_bar", required=True)
    assert validate_json(content, field) == (None, [Message(
        code='missing_required_fields',
        text='Missing required fields: foo_bar.',
        pointer='/foo_bar',
        field_names=['foo_bar'])])


# Generated at 2022-06-22 06:27:37.635538
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
    content='[true,false,null]',
    validator=Field(type="array", items=[Field(type="boolean"),Field(type="boolean"),Field(type="null")])
    )==([True,False,None],[])

# Generated at 2022-06-22 06:27:48.566884
# Unit test for function tokenize_json
def test_tokenize_json():
    import sys
    import json

# Generated at 2022-06-22 06:28:00.196083
# Unit test for function validate_json
def test_validate_json():
    msg = """{
        "name": {
            "first": "Emmett Lathrop",
            "last": "Brown"
        },
        "age": 82
    }"""
    schema = Schema({
        "name": Schema({
            "first": "text",
            "last": "text"
        }),
        "age": "number"
    })

    value, errs = validate_json(msg, schema)
    print(f"value: {value}")
    print(f"errs: {errs}")

    assert value == {
        "name": {
            "first": "Emmett Lathrop",
            "last": "Brown"
        },
        "age": 82
    }
    assert errs == []


if __name__ == "__main__":
    test

# Generated at 2022-06-22 06:28:01.729692
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # create decoder object
    tokenizer = _TokenizingDecoder()


# Generated at 2022-06-22 06:28:04.578072
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    msg = 'Can\'t construct class _TokenizingDecoder as it has abstract methods'
    assert issubclass(_TokenizingDecoder, JSONDecoder), msg

# Generated at 2022-06-22 06:28:12.042212
# Unit test for function validate_json
def test_validate_json():
    import typesystem

    class TestSchema(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        alive = typesystem.Boolean()

    content = r'{"name": "John Smith", "age": 42, "alive": true}'
    value, errors = validate_json(content, TestSchema)
    assert isinstance(value, dict)
    assert not errors
    assert value == {"name": "John Smith", "age": 42, "alive": True}



# Generated at 2022-06-22 06:28:23.207768
# Unit test for function validate_json
def test_validate_json():
    content = '{"country": "usa", "state": "CA", "test": 321, "test2": "abc"}'
    validator = Schema.of(
        {"country": str, "state": str, "test": int, "test2": Field(type=str)}
    )
    value, error_msgs = validate_json(content, validator)
    print(value)
    print(error_msgs)
    content = {"country": "usa", "state": "CA", "test": 321, "test2": "abc"}
    validator = Schema.of(
        {"country": str, "state": str, "test": int, "test2": Field(type=str)}
    )
    value, error_msgs = validate_json(content, validator)
    print(value)