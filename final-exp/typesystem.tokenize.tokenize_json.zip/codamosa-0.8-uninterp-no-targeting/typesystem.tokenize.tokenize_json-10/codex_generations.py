

# Generated at 2022-06-22 06:18:43.381852
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.scanner import _TokenizingDecoder
    from typesystem import String
    d = _TokenizingDecoder()
    assert isinstance(d.parse_string, JSONDecodeError)
    assert isinstance(d.parse_float, JSONDecodeError)
    assert isinstance(d.parse_array, JSONDecodeError)
    assert isinstance(d.parse_int, JSONDecodeError)
    assert isinstance(d.scan_once, type(validate_json))


# Generated at 2022-06-22 06:18:48.901592
# Unit test for function validate_json
def test_validate_json():
    content = "[{'foo': 'a', 'bar': 'b'}]"
    validator = Field(list_of=Schema({"foo": Field(type=str), "bar": Field(type=str)}))
    value, error_messages = validate_json(content, validator)
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 2
    assert error_messages[0].position.char_index == 1
    assert error_messages[0].text is not None



# Generated at 2022-06-22 06:18:51.728051
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(), _TokenizingDecoder)


# Generated at 2022-06-22 06:18:52.745019
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="some content")

# Generated at 2022-06-22 06:19:02.163430
# Unit test for function validate_json
def test_validate_json():
    content = tokenize_json("""
    {
      "title": "Example Schema",
      "type": "object",
      "properties": {
        "firstName": {
          "type": "string"
        },
        "lastName": {
          "type": "string"
        },
        "age": {
          "description": "Age in years",
          "type": "integer",
          "minimum": 0
        }
      },
      "required": ["firstName", "lastName"]
    }
    """.strip())
    errors = validate_with_positions(token=content, validator=Schema)
    assert errors[0].code == "object"
    assert errors[0].position.column_no == 3
    assert errors[0].position.line_no == 2



# Generated at 2022-06-22 06:19:10.215491
# Unit test for function validate_json
def test_validate_json():
    val_schema = Schema(fields={
        "name": Field(type="string"),
        "balance": Field(type="number"),
    })
    content = """
        {
            "name": "John Doe",
            "balance": 12.34
        }
    """
    expected_value = {"name": "John Doe", "balance": 12.34}
    value, error_messages = validate_json(content=content, validator=val_schema)
    assert value == expected_value
    assert error_messages == []


# Generated at 2022-06-22 06:19:13.548255
# Unit test for function validate_json
def test_validate_json():
    content = '{"number_value": 123.456}'
    schema = Schema(fields={"number_value": "number"})
    value, error_messages = validate_json(content=content, validator=schema)
    assert not error_messages


# Generated at 2022-06-22 06:19:23.687835
# Unit test for function tokenize_json
def test_tokenize_json():
    token_empty_object = tokenize_json("{ }")
    assert isinstance(token_empty_object, DictToken)
    assert token_empty_object.value == {}
    token_empty_list = tokenize_json("[ ]")
    assert isinstance(token_empty_list, ListToken)
    assert token_empty_list.value == []
    token_true = tokenize_json("true")
    assert isinstance(token_true, ScalarToken)
    assert token_true.value == True
    token_false = tokenize_json("false")
    assert isinstance(token_false, ScalarToken)
    assert token_false.value == False
    token_null = tokenize_json("null")
    assert isinstance(token_null, ScalarToken)
    assert token_null.value == None
   

# Generated at 2022-06-22 06:19:32.147908
# Unit test for function tokenize_json
def test_tokenize_json():
    with open("inputs/example.json") as f:
        content = f.read()
    d = tokenize_json(content)

    assert isinstance(d, DictToken)
    assert d.value == {
        "name": "John Smith",
        "phone": "5551234567",
        "age": 42,
        "latitude": 40.741895,
        "longitude": -73.989308,
        "address": "100 5th Ave, New York, NY 10011",
    }


# Unit tests for function validate_json

# Generated at 2022-06-22 06:19:33.672966
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{}')
    assert decoder.parse_object == _TokenizingJSONObject

# Generated at 2022-06-22 06:19:58.645891
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string and for no content
    with pytest.raises(ParseError) as e:
        tokenize_json('')
    assert e.value.text == 'No content.'
    with pytest.raises(ParseError) as e:
        tokenize_json('')
    assert e.value.text == 'No content.'
    # Test simple cases
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('"test"') == ScalarToken('test', 0, 5, '"test"')

# Generated at 2022-06-22 06:20:08.602545
# Unit test for function validate_json
def test_validate_json():
    # Valid content with validator
    assert validate_json(content="42", validator=Field(type='integer')) == (42, [])
    # Valid content with schema
    assert validate_json(content="42", validator=Schema) == (42, [])
    # Valid content but invalid validator
    assert validate_json(content="42", validator=Field(type='number')) == (None, [{"code": "type_error", "text": "'42' is not a number.", "position": {"column_no": 1, "line_no": 1, "char_index": 0}}])
    # Invalid content with validator

# Generated at 2022-06-22 06:20:11.683091
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="some_content")
    token, _ = decoder.scan_once("[0]", 0)
    assert (token.value == [0])


# Generated at 2022-06-22 06:20:20.965268
# Unit test for function validate_json
def test_validate_json():
    content = '{"A": "B"}'
    field = Field(name="A")
    value, errors = validate_json(content, field)
    assert errors == []
    assert value == "B"

    value, errors = validate_json('{"B": "C"}', field)
    assert len(errors) == 1

    value, errors = validate_json('{"B": "C", "A": "B"}', field)
    assert len(errors) == 1

    value, errors = validate_json('{"B": "C"}', field.as_dict())
    assert len(errors) == 0

    value, errors = validate_json('{"A": "B"}', field.as_dict())
    assert len(errors) == 1

# Generated at 2022-06-22 06:20:31.637967
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:20:40.022839
# Unit test for function validate_json
def test_validate_json():
    #
    # Test the case where we have a successfully (or partially) validated schema.
    #
    schema_class = typing.TypeVar("schema_class", bound=Schema)

    def get_validator(schema_or_field: typing.Any) -> typing.Union[schema_class, Field]:
        if hasattr(schema_or_field, "schema_class"):
            return schema_or_field.schema_class
        return schema_or_field

    content = '{"age": 50}'
    validator = typing.Type[Schema]
    validator.age = typing.cast(Field, Field(int))
    value, error_messages = validate_json(content=content, validator=validator)
    assert len(error_messages) == 0

# Generated at 2022-06-22 06:20:41.057382
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="My First String")

# Generated at 2022-06-22 06:20:47.846801
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '''{
  "age": 10,
  "first_name": "Test",
  "last_name": "name"
}
'''
    decoder = _TokenizingDecoder(content=content)
    value, end = _TokenizingJSONObject(
        (content, 0), True, decoder.scan_once, decoder.memo, content
    )
    token = DictToken(value, 0, end - 1, content)
    return token


# Generated at 2022-06-22 06:20:59.418231
# Unit test for function validate_json
def test_validate_json():
    class SimpleSchema(Schema):
        name = Field(type_name="string", required=True)
        age = Field(type_name="integer", required=False)

    # Test with bytes as input
    json_bytes = b'{"name": "John Doe"}'
    value, errors = validate_json(
        content=json_bytes, validator=SimpleSchema
    )
    assert value == {"name": "John Doe"}
    assert not errors

    # Test with string as input
    json_str = '{"name": "John Doe"}'
    value, errors = validate_json(
        content=json_str, validator=SimpleSchema
    )
    assert value == {"name": "John Doe"}
    assert not errors

    # Test with empty string as input

# Generated at 2022-06-22 06:21:06.142794
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"name": "John Doe", "age": 40}'
    tokenizing_decoder = _TokenizingDecoder(content=content)
    assert (isinstance(tokenizing_decoder, JSONDecoder))



# Generated at 2022-06-22 06:21:30.964695
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    {
        "int": 123,
        "float": 3.14159,
        "list": [
            true
        ],
        "dict": {
            "foo": "bar"
        }
    }
    """
    token = tokenize_json(json_string)

# Generated at 2022-06-22 06:21:41.261146
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    json = ""
    _token = tokenize_json(json)
    
    # Passing null
    json = 'null'
    _token = tokenize_json(json)
    assert _token.value == None
    
    # Passing boolean values
    json = 'true'
    _token = tokenize_json(json)
    assert _token.value == True
    
    json = 'false'
    _token = tokenize_json(json)
    assert _token.value == False

    # Passing string values
    json = '"Test"'
    _token = tokenize_json(json)
    assert _token.value == 'Test'
    
    # Passing integer values
    json = '10'
    _token = tokenize_json(json)
    assert _token.value == 10
    
   

# Generated at 2022-06-22 06:21:49.753849
# Unit test for function validate_json
def test_validate_json():
    # Intentionally bad JSON
    # Expect a list of ValidationErrors
    with pytest.raises(ValidationError) as e:
        value, errors = validate_json('{ hi: "there" }', Text)
    assert e.value.messages[0].code == 'parse_error'

    # Valid JSON
    # Expect a list of 0 ValidationErrors
    value, errors = validate_json('{ "hi": "there" }', Text)
    assert not errors

    # Valid JSON
    # Expect a list of 0 ValidationErrors
    value, errors = validate_json('{ "hi": "there" }', Field)
    assert not errors

# Generated at 2022-06-22 06:21:52.151440
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    '''
    test for class _TokenizingDecoder
    '''
    return;


# Generated at 2022-06-22 06:22:00.262276
# Unit test for function validate_json
def test_validate_json():
    content = "{'a': 1, 'b': 2}"
    validator = Field(type="object", fields={"a": Field(type="integer"),
                                             "b": Field(type="integer")})
    expected = ({"a": 1, "b": 2}, [])
    assert validate_json(content, validator) == expected

    content = "{'a': 1, 'b': 'string'}"
    validator = Field(type="object", fields={"a": Field(type="integer"),
                                             "b": Field(type="integer")})

# Generated at 2022-06-22 06:22:05.869862
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    content = '"test"'
    value, errors = validate_json(content, validator)
    assert errors == []
    assert value == "test"
    content = 'test'
    value, errors = validate_json(content, validator)
    assert errors[0]["code"] == "invalid_type"


# Generated at 2022-06-22 06:22:14.574074
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    schema = Schema({"name": Field(str, required=True)})
    content = """
{
    "name": "foo"
}
"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value.keys() == {"name"}
    assert token.value["name"].value == "foo"

    value, errors = validate_json(content, schema)
    assert not errors
    assert value == {"name": "foo"}



# Generated at 2022-06-22 06:22:26.659994
# Unit test for function tokenize_json
def test_tokenize_json():
    # Check that we raise the correct error for empty content.
    with pytest.raises(ParseError):
        tokenize_json("")

    # Check that we raise the correct error for invalid JSON content.
    with pytest.raises(ParseError):
        tokenize_json('{"foo": bar}')

    # Check that we tokenize valid JSON content correctly.
    expected_json_token = DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": "b"}'): ScalarToken(
                "b", 5, 6, '{"a": "b"}'
            )
        },
        0,
        10,
        '{"a": "b"}',
    )

    json_token = tokenize_json('{"a": "b"}')
    assert json_token == expected_

# Generated at 2022-06-22 06:22:36.579193
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "id": "abcd",
        "name": "foo",
        "desc": "This is a test."
    }
    """

    token = tokenize_json(content)
    assert token.content == content
    assert token.start_pos == Position(line_no=2, column_no=9, char_index=9)
    assert token.end_pos == Position(line_no=13, column_no=4, char_index=76)

    assert isinstance(token.value, dict)
    assert token.value["id"] == "abcd"
    assert token.value["name"] == "foo"
    assert token.value["desc"] == "This is a test."

    assert isinstance(token.value["id"], ScalarToken)

# Generated at 2022-06-22 06:22:40.819556
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder()
    assert context.parse_float('1.0') == 1.0
    assert context.parse_int('1') == 1
    assert context.strict is True
    assert context.scan_once('{}', 0) == ({}, 2)

# Generated at 2022-06-22 06:22:55.360965
# Unit test for function validate_json
def test_validate_json():
    # Test Field
    email_field = Field(type="string", format="email")
    value, errors = validate_json(content='"foo@example.com"', validator=email_field)
    assert(value == "foo@example.com")
    assert(errors == [])

    value, errors = validate_json(content='"fooexample.com"', validator=email_field)
    assert(value == "fooexample.com")
    assert(len(errors) == 1)
    assert(errors[0].code == "bad_format")
    assert(errors[0].position.line_no == 1)
    assert(errors[0].position.column_no == 1)
    assert(errors[0].position.char_index == 0)

# Generated at 2022-06-22 06:23:04.762005
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string.
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")

    # Test string with whitespace and no content.
    with pytest.raises(ParseError, match="No content."):
        tokenize_json(" ")

    # Test valid scalar.
    assert tokenize_json('"Hello, World!"') == ScalarToken("Hello, World!", 0, 16, '"Hello, World!"')

    # Test valid list.
    tokens = tokenize_json("[1, 2, 3]")
    assert len(tokens.value) == 3
    for i, x in enumerate(tokens.value):
        assert isinstance(x, ScalarToken)
        assert x.value == i + 1

    # Test invalid list with null.

# Generated at 2022-06-22 06:23:06.272597
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="Hello World").content == "Hello World"

# Generated at 2022-06-22 06:23:18.169664
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert (exc.position.line_no, exc.position.column_no) == (1, 1)
        assert exc.code == "no_content"

    # Test valid string
    token = tokenize_json('["foobar", { "foo": "bar" }]')
    assert token == tokenize_json('["foobar", { "foo": "bar" }]')
    assert token == tokenize_json('[  "foobar" , { "foo" : "bar" }  ]')

    # Test ill-formed strings.
    # noinspection PyBroadException

# Generated at 2022-06-22 06:23:29.070468
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema, fields
    from datetime import datetime

    class Counter(Schema):
        tokens = fields.List(Integer(), min_items=1)

    counter = Counter({"tokens": [1, 2, 3]})
    errors = counter.validate(None)
    assert errors == []
    counter = Counter({"tokens": [1, 2, 3.6]})
    errors = counter.validate(None)
    assert errors == [ValidationError(
        text="Value '3.6' is not of type 'integer'.",
        code="type_error.integer",
        position=Position(column_no=11, line_no=1, char_index=9),
    )]

# Generated at 2022-06-22 06:23:42.007138
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import Message, Position, ValidationError
    from typesystem.fields import (
        Array,
        Boolean,
        Integer,
        Number,
        Object,
        Schema,
        String,
    )
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class CatSchema(Schema):
        name = String(max_length=100)
        age = Integer()
        is_happy = Boolean()
        weight_lbs = Number()

    class CatObject(Object):
        name = String(max_length=100)
        age = Integer()
        is_happy = Boolean()
        weight_lbs = Number()


# Generated at 2022-06-22 06:23:45.693054
# Unit test for function tokenize_json
def test_tokenize_json():
    assert type(tokenize_json('{"a": 1}')) is DictToken
    assert type(tokenize_json('["a", 1]')) is ListToken
    assert type(tokenize_json('1')) is ScalarToken


# Generated at 2022-06-22 06:23:58.119709
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"name": "Miles"}') == DictToken({ScalarToken("name", 1, 5, '{"name": "Miles"}'): ScalarToken("Miles", 9, 15, '{"name": "Miles"}')}, 0, 18, '{"name": "Miles"}')
    assert tokenize_json(b'{}') == DictToken({}, 0, 2, '{}')
    assert tokenize_json(b'{null}') == DictToken({ScalarToken(None, 1, 5, '{null}'): ScalarToken(None, 1, 5, '{null}')}, 0, 6, '{null}')

# Generated at 2022-06-22 06:24:07.587050
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{ "a": "foo", "b": "bar"}, true, null, 1.1, 2, ["hello", "world" ]]'
    tokens = tokenize_json(content)
    assert type(tokens) == ListToken
    assert len(tokens.value) == 6

    tokens = tokens.value

    assert type(tokens[0]) == DictToken
    assert tokens[0].value == {
        ScalarToken("a", 2, 3, content): ScalarToken("foo", 7, 9, content),
        ScalarToken("b", 12, 13, content): ScalarToken("bar", 16, 18, content),
    }

    assert type(tokens[1]) == ScalarToken
    assert tokens[1].value == True

    assert type(tokens[2]) == ScalarToken


# Generated at 2022-06-22 06:24:18.445567
# Unit test for function validate_json
def test_validate_json():
    content = '{"name":"Ripley","hero":false,"age":15,"team":"space"}'
    schema = Schema(
        {"name": str, "hero": bool, "age": int, "team": ["space", "xmen", "avengers"]}
    )

    value, errors = validate_json(content, schema)

    assert value == {
        "name": "Ripley",
        "hero": False,
        "age": 15,
        "team": "space",
    }
    assert errors == []

    content = '{"name":"Ripley","hero":false,"age":15,"team":"jedi"}'
    value, errors = validate_json(content, schema)

    assert value is None

# Generated at 2022-06-22 06:24:24.138235
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder({"content": "foo"})


# Generated at 2022-06-22 06:24:26.089286
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    mydecoder = _TokenizingDecoder()
    assert type(mydecoder.scan_once) == type(_make_scanner)


# Generated at 2022-06-22 06:24:37.979350
# Unit test for function validate_json
def test_validate_json():
    content = '{ "property" : [1, 2, 3], "other" : 4 }'
    validator = {
        "property": [int],
        "other": {"type": int, "required": True},
        "other_optional": int,
    }
    assert validate_json(content, validator) == ({
        'property': [1, 2, 3],
        'other': 4,
    }, [])
    validator = {
        "property": float,
        "other": {"type": int, "required": True},
        "other_optional": int,
    }

# Generated at 2022-06-22 06:24:49.519214
# Unit test for function validate_json
def test_validate_json():
    content = '[{"name":"Joe","age":12}, {"name":"Joe","age":12, "pet": "snoopy"}]'
    class CustomerSchema(Schema):
        name = String(max_length=100)
        age = Integer(min_value=12, max_value=100)
        pet = String(max_length=100, required=False)
    validator = List(CustomerSchema())
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 0
    assert type(value) is list
    assert len(value) == 2
    for customer in value:
        assert customer['name'] == 'Joe'
        assert customer['age'] == 12


# Generated at 2022-06-22 06:24:55.954222
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={"name": String(max_length=1)})
    content = '{"name": "John"}'
    messages = validate_json(content, schema)
    assert messages[0].code == "max_length"
    assert messages[0].position.column_no == 10
    assert messages[0].position.line_no == 1
    assert messages[0].position.char_index == 9

# Generated at 2022-06-22 06:25:07.669686
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Compound, fields

    def validator(content):
        val, errors = validate_json(content, String(max_length=5))
        return errors

    assert validator('"abc"') == []
    assert validator('"abcdef"') == [
        {
            "code": "max_length",
            "field_name": "",
            "field_path": [],
            "message": "max_length violation for value 'abcdef'",
            "row_index": 0,
            "type": "failure",
        }
    ]

    class AddressSchema(Compound):
        city = fields.String()

    class PersonSchema(Compound):
        name = fields.String()
        age = fields.Integer()

# Generated at 2022-06-22 06:25:08.336634
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert True

# Generated at 2022-06-22 06:25:10.052096
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = _TokenizingDecoder(content = "a")
    assert "a" == a.content



# Generated at 2022-06-22 06:25:20.270942
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, fields
    content = ""
    validator = fields.String()
    value, error_messages = validate_json(content, validator)
    assert value is None
    assert error_messages == [Message(text="No content.", code="no_content", position=Position(0, 1, 1))]
    content = "{}"
    value, error_messages = validate_json(content, validator)
    assert value is None
    assert error_messages == [Message(text="Expected a string.", code="invalid_type", position=Position(0, 1, 1))]
    content = '{"foo": 1}'
    value, error_messages = validate_json(content, validator)
    assert value is None

# Generated at 2022-06-22 06:25:32.519552
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert (
        _TokenizingDecoder.__init__.__defaults__
        == JSONDecoder.__init__.__defaults__
    )


NUMBER_STRING = b"57.8878"
NUMBER_STRING_DECODED = '57.8878'
BYTE_JSON = b'{"f": 56.8, "k": "v"}'
BYTE_JSON_DECODED = {"f": 56.8, "k": "v"}
EMPTY_BYTE_JSON = b'{}'
EMPTY_BYTE_JSON_DECODED = {}
EMPTY_BYTE_JSON_TOKEN = DictToken(
    EMPTY_BYTE_JSON_DECODED, 0, len(EMPTY_BYTE_JSON) - 1
)
NON_STRING_BYTE_JSON

# Generated at 2022-06-22 06:25:38.207348
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:25:39.865603
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("content")


# Generated at 2022-06-22 06:25:45.200254
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(r'{"key":"value","nested":{"key":"value"},"list":[1,2,3]}')
    assert token.value, {"key": "value", "nested": {"key": "value"}, "list": [1, 2, 3]}

# Generated at 2022-06-22 06:25:47.736377
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='example.json')
    print('Testing _TokenizingDecoder')
    print(decoder.scan_once)

# Generated at 2022-06-22 06:25:59.632355
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, '"foo"')
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 6, 10, '"bar"')}, 0, 13, '{"foo": "bar"}'
    )
    assert tokenize_json('{"foo": "bar"') == DictToken(
        {"foo": ScalarToken("bar", 6, 10, '"bar"')}, 0, 12, '{"foo": "bar"'
    )

# Generated at 2022-06-22 06:26:07.671972
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, fields, validate_json

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    valid_json = '{"name": "test", "age": 100}'
    invalid_json = '{"name": "test", "age": "1"}'

    result, messages = validate_json(valid_json, Person)
    if messages:
        raise AssertionError("No error messages should be present")

    result, messages = validate_json(invalid_json, Person)
    if not messages:
        raise AssertionError("Error messages should be present")
    print(messages)
    assert messages[0]["message"] == "must be an integer"

if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-22 06:26:19.354988
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json_dict = {
        "name": "test_dict",
        "dummy_key": "dummy_value",
        "nested_dict": {"nested_dict_key": "nested_dict_value"},
        "nested_list": ["nested_list_value_1", "nested_list_value_2"],
        "nested_list_of_dicts": [
            {"nested_list_of_dicts_key": "nested_list_of_dict_value"},
            {"nested_list_of_dicts_key": "nested_list_of_dict_value_2"},
        ],
    }
    tok = tokenize_json(
        json.dumps(test_json_dict),
    )

# Generated at 2022-06-22 06:26:30.163092
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json function
    """
    assert validate_json(
        '{"id": 1, "words": ["this", "is", "a", "test"]}',
        Schema(
            {"id": int, "words": [str]},
            error_messages={
                "id": {"type": "Must be an integer."},
                "words": {"type": "Must be a list.", "items": {"type": "Must be a string."}},
            },
        ),
    ) == (
        {"id": 1, "words": ["this", "is", "a", "test"]},
        [],
    )


# Generated at 2022-06-22 06:26:33.538390
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = u'{"comment":"dict_comment","cost":10}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0)[0].value == {'comment': 'dict_comment', 'cost': 10}


# Generated at 2022-06-22 06:26:43.119129
# Unit test for function validate_json
def test_validate_json():

    test_cases = [
        ("{}", {"type": "object", "required": ["foo"]}, []),
        ('{"foo": "bar"}', {"type": "object", "required": ["foo"]}, []),
        ("{}", {"type": "object", "required": ["foo"]}, [ValidationError()]),
    ]

    for json_string, json_schema, expected_errors in test_cases:
        validator = Schema(json_schema)
        _, errors = validate_json(json_string, validator)
        assert len(errors) == len(expected_errors)

# Generated at 2022-06-22 06:26:57.143234
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_content = '{"abc": "def"}'
    decoder = _TokenizingDecoder(content=json_content)
    list_tokens = [t for t in decoder.tokenize(json_content)]
    assert len(list_tokens) == 3
    assert list_tokens[0].value == "{"
    assert list_tokens[0].position == 0
    assert list_tokens[1].value == "def"
    assert list_tokens[2].value == "}"

# Generated at 2022-06-22 06:27:09.079226
# Unit test for function validate_json
def test_validate_json():
    """Test validate_json"""
    assert validate_json(b"false", bool) == (False, [])
    assert validate_json(b"", bool) == (None, [Message(text="No content.",
                                                      code="no_content",
                                                      position=Position(
                                                          char_index=0,
                                                          line_no=1,
                                                          column_no=1))])

# Generated at 2022-06-22 06:27:14.429309
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"a": "hello", "b": "world"}]'
    token = tokenize_json(content)
    expected_token = ListToken(children=[{'a': 'hello', 'b': 'world'}], start=0, end=33, content=content)
    assert token == expected_token

# Generated at 2022-06-22 06:27:17.203472
# Unit test for function tokenize_json
def test_tokenize_json():
  data = json.loads('{"foo": "bar", "baz": [2, 3]}')
  token = tokenize_json('{"foo": "bar", "baz": [2, 3]}')
  assert token.value == data



# Generated at 2022-06-22 06:27:28.226284
# Unit test for function validate_json
def test_validate_json():
    token = tokenize_json('[{"name": "John Doe", "age": 42}]')
    errors = validate_json(token, 'Person')
    assert not errors

    token = tokenize_json('[{"name": "Jane Doe", "age": "forty two"}]')
    errors = validate_json(token, 'Person')
    assert len(errors) == 2

    [error_1, error_2] = errors
    assert error_1.path == '["age"]'
    assert error_1.position.line_no == 1
    assert error_1.position.column_no == 30
    assert error_1.message == 'Must be an integer'

    assert error_2.path == '["name"]'
    assert error_2.position.line_no == 1
    assert error_2.position.column_

# Generated at 2022-06-22 06:27:37.233631
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = '{"title": "hello world", "rating": 4}'
    token = tokenize_json(valid_json)
    assert token.start == 0
    assert token.end == len(valid_json)
    assert token.content == valid_json
    assert token.value["title"].value == "hello world"
    assert token.value["rating"].value == 4
    assert token.type == "dict"

    invalid_json = '{"title": "hello world", "rating": 4] }'
    with pytest.raises(ParseError) as error:
        tokenize_json(invalid_json)
    assert error.value.position == Position(line_no=1, column_no=39, char_index=38)
    assert error.value.code == "parse_error"

# Generated at 2022-06-22 06:27:40.038480
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Construct __TokenizingDecoder with params
    obj = _TokenizingDecoder(content='some content')
    assert obj is not None

# Generated at 2022-06-22 06:27:49.453573
# Unit test for function tokenize_json
def test_tokenize_json():
    dict_1 = {
        "a": 1,
        "b": {
            "x": 2,
            "y": 3,
            "z": [4, 5, 6]
        },
        "c": "hello"
    }
    dict_token = tokenize_json(json.dumps(dict_1))
    assert dict(dict_token) == dict_1

    arr = [1, 2, 3, 4, 5]
    arr_token = tokenize_json('[1,2,3,4,5]')
    assert arr_token == arr

    str_token = tokenize_json('"hello"')
    assert str_token == "hello"

    int_token = tokenize_json('1')
    assert int_token == 1

    float_token = tokenize_json('2.5')

# Generated at 2022-06-22 06:28:00.905978
# Unit test for function validate_json
def test_validate_json():
    class SampleSchema(Schema):
        integer = Field(type="integer")
        string = Field(type="string")
        required = Field(type="string", required=True)
        list = Field(type="array")
        dict = Field(type="dict")

    data = {
        "integer": "not_an_int",
        "string": "foo bar",
        "required": "this is a required string",
        "list": ["a", "b", "c"],
        "dict": {"key": "value"}
    }

    v, e = validate_json(json.dumps(data), validator=SampleSchema)

    assert e
    assert e[0].position.line_no == 3
    assert str(e[0]) == "Invalid value for 'integer': 'not_an_int'."
    assert str

# Generated at 2022-06-22 06:28:10.360381
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = dict(foo=None, bar=dict(baz=None))
    token = tokenize_json(json.dumps(schema))
    assert isinstance(token, DictToken)
    assert token.value == schema
    assert token.position.line_no == 1
    assert token.position.column_no == 1

    field = Field(type="string")
    token = tokenize_json('"foo"')
    assert isinstance(token, ScalarToken)
    assert token.value == "foo"
    assert token.position.line_no == 1
    assert token.position.column_no == 1

