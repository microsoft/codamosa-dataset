

# Generated at 2022-06-22 06:19:01.373925
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(None).__repr__() == 'DictToken(content={}, start_index=0, end_index=0)'
    assert tokenize_json("").__repr__() == 'DictToken(content={}, start_index=0, end_index=0)'
    assert tokenize_json('{"number": 1, "string1": "str", "string2": str}').__repr__() == 'DictToken(content={"number": ScalarToken(content=1, start_index=2, end_index=4), "string1": ScalarToken(content="str", start_index=9, end_index=14), "string2": ScalarToken(content=str, start_index=19, end_index=21)}, start_index=0, end_index=40)'
    assert tokenize

# Generated at 2022-06-22 06:19:12.166998
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == b''
    assert tokenize_json('""') == b'""'
    assert tokenize_json('{"x":"x"}') == b'{"x":"x"}'
    assert tokenize_json('{"x":"x","y":"y"}') == b'{"x":"x","y":"y"}'
    assert tokenize_json('{"x":{"x":"x","y":"y"}}') == b'{"x":{"x":"x","y":"y"}}'
    assert tokenize_json('{"x":[{"x":"x"},{"x":"x"}]}') == b'{"x":[{"x":"x"},{"x":"x"}]}'
    assert tokenize_json('{"x":[{"x":"x"}]}') == b'{"x":[{"x":"x"}]}'


# Generated at 2022-06-22 06:19:15.592233
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Field(type="string")
    assert validate_json(content, validator) == ({"foo": "bar"}, [])


# Generated at 2022-06-22 06:19:25.113438
# Unit test for function validate_json
def test_validate_json():
    validator = Schema(fields=[
        Field(name='name', validators=[Length(max_length=2)])
    ])

    # Valid content
    content = '{"name": "Jill"}'
    value, errors = validate_json(content, validator)
    assert value == {'name': 'Jill'}
    assert errors == []

    # Valid content is a bytestring
    content = b'{"name": "Jill"}'
    value, errors = validate_json(content, validator)
    assert value == {'name': 'Jill'}
    assert errors == []

    # Invalid content
    content = '{"name": "Jill"}'
    value, errors = validate_json(content, validator)

# Generated at 2022-06-22 06:19:26.067523
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('')



# Generated at 2022-06-22 06:19:31.817153
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":1}'
    decoder = JSONDecoder(content=content)
    scanner = _make_scanner(decoder, content)
    assert isinstance(scanner, typing.Callable)
    assert scanner.__defaults__ == (WHITESPACE, WHITESPACE_STR)

# Generated at 2022-06-22 06:19:33.791764
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(r'{"a": "b"}') == {'a': 'b'}

# Generated at 2022-06-22 06:19:40.306544
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """Test constructor of class _TokenizingDecoder."""
    context = _TokenizingDecoder(content="")
    assert context.strict == True
    assert context.parse_float == float
    assert context.parse_int == int
    assert context.parse_constant == JSONDecoder.parse_constant
    assert hasattr(context, "_scan_once") == False
    assert context.scan_once == _make_scanner(context, "")
    assert context.memo == dict()



# Generated at 2022-06-22 06:19:45.340133
# Unit test for function tokenize_json
def test_tokenize_json():
    results = tokenize_json("""{"key": 1}""")
    assert results == DictToken(
        {"key": ScalarToken(1, 5, 5, '{"key": 1}')}, 0, 8, '{"key": 1}'
    )


# Unit tests for function validate_json

# Generated at 2022-06-22 06:19:51.180893
# Unit test for function tokenize_json
def test_tokenize_json():
    import typesystem
    token = tokenize_json('{"a": 1}')
    assert token.type == 'dict'
    value, position = token.value[0]
    assert isinstance(value, ScalarToken)
    assert isinstance(value, typesystem.ScalarToken)
    assert value.type == 'scalar'
    assert value.value == 'a'


# Generated at 2022-06-22 06:20:10.838828
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":1, "b":2}'
    context = _TokenizingDecoder(content=content)
    assert content == context.content

# Generated at 2022-06-22 06:20:20.940498
# Unit test for function validate_json
def test_validate_json():
    validator = fields.Object(
        {
            "first_name": fields.String(max_length=20),
            "last_name": fields.String(max_length=20),
            "age": fields.Integer(),
            "height": fields.Float(max_value=10),
        },
        required=True,
    )
    content = """
{
    "first_name": "John",
    "last_name": "Smith",
    "age": 20,
    "height": 5.11
}"""
    value, errors = validate_json(content, validator)
    assert not errors

    content = """
{
    "first_name": "John",
    "last_name": "Smith",
    "age": 20,
    "height": 12
}"""

# Generated at 2022-06-22 06:20:31.594610
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    raise NotImplementedError()

# Unit tests for the function tokenize_json
# TODO: Verify that the function throws a ParseError with a position of line=1, column=1, char_index=0 for the empty string.
# TODO: Verify that the function throws a ParseError with a position of line=10, column=5, char_index=N (where N is the number of characters before the 10th line) for a JSON string that starts with valid JSON and then has an invalid character on the 10th line.
# TODO: Verify that the function throws a ParseError with a position of line=10, column=5, char_index=N (where N is the number of characters before the 10th line) for a JSON string that starts with valid JSON, has a comma at the end of the line, has an invalid character on the 10th line, and then

# Generated at 2022-06-22 06:20:34.270135
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    invalid_str = '{"key": "value"}'
    try:
        tokenize_json(invalid_str)
    except ParseError:
        pass

# Generated at 2022-06-22 06:20:36.108834
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.scan_once is not None

# Generated at 2022-06-22 06:20:41.930489
# Unit test for function validate_json
def test_validate_json():
    content = '{ "a": "b" }'
    class CustomSchema(Schema):
        a = Field(type="string", required=True)
    value, errors = validate_json(content=content, validator=CustomSchema)
    assert errors == []
    assert value == {"a": "b"}



# Generated at 2022-06-22 06:20:47.178521
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"test":"test2"}'
    args = [content]
    kwargs = {"content": content}
    td = _TokenizingDecoder(*args, **kwargs)
    assert td is not None, "object not created"
    assert td.scan_once is not None, "scanner not created"

# Unit tests for tokenize_json

# Generated at 2022-06-22 06:20:58.834990
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """{"key": "value"}"""
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.at_position(1, 1)
    json_str = """
    {
        "key": "value"
    }
    """
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.at_position(3, 5)
    json_str = """
    [
        "value1",
        "value2"
    ]
    """
    token = tokenize_json(json_str)
    assert isinstance(token, ListToken)
    assert token.at_position(3, 5)

# Generated at 2022-06-22 06:21:05.114019
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    dummy_content = '{"a": "b"}'
    dummy_strict = True
    decoder = _TokenizingDecoder(dummy_content=dummy_content)
    assert decoder.strict == dummy_strict

# Generated at 2022-06-22 06:21:16.991975
# Unit test for function tokenize_json
def test_tokenize_json():
    import re
    import random
    import typesystem
    import typesystem_json

    random.seed(1)

    # Create values
    number_of_objects = 2
    number_of_nested_objects = 2
    number_of_lists = 2
    number_of_nested_lists = 2
    number_of_fields_per_object = 2
    number_of_fields_per_nested_object = 2
    number_of_elements_per_list = 2
    number_of_elements_per_nested_list = 2
    min_value = -10000
    max_value = 10000

# Generated at 2022-06-22 06:21:29.697893
# Unit test for function tokenize_json
def test_tokenize_json():
    json_file = open('../typesystem/tests/fixtures/json_data.json')
    json_data = json_file.read()
    json_file.close()
    json_byte_data = bytes(json_data, 'utf-8')
    token = tokenize_json(json_data)
    assert type(token) == DictToken
    token = tokenize_json(json_byte_data)
    assert type(token) == DictToken
    token = tokenize_json('')
    assert type(token) == DictToken


# Generated at 2022-06-22 06:21:37.623058
# Unit test for function validate_json
def test_validate_json():
    import unittest

    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema2(Schema):
        name = Field(type="string")
        age = Field(type="float")

    class TestSchema3(Schema):
        job = Field(type="string")
        age = Field(type="integer")

    class TestSchema4(Schema):
        name = Field(type="string")
        age = Field(type="integer", optional=True)
        job = Field(type="string", optional=True)

    class TestSchema5(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        job = Field(type="string", optional=True)


# Generated at 2022-06-22 06:21:48.869183
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unit test for function tokenize_json
    """
    assert tokenize_json("{}") == DictToken(dict(), 0, 1, "{}")
    assert tokenize_json("[]") == ListToken(list(), 0, 1, "[]")
    assert tokenize_json("[\"a\"]") == ListToken(
        [ScalarToken("a", 1, 3, "[\"a\"]")], 0, 5, "[\"a\"]"
    )

# Generated at 2022-06-22 06:21:52.884426
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="[1,2,3]")
    tokens = decoder.scan_once("[1,2,3]", 0)
    assert len(tokens)==2
    assert tokens[0].value == [1,2,3]

# Generated at 2022-06-22 06:21:56.829422
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_obj = _TokenizingDecoder(content = "test_content")
    assert test_obj.parse_string("", 0, False) == '', 0
    assert test_obj.parse_float("0") == 0.0
    assert test_obj.parse_int("0") == 0


# Generated at 2022-06-22 06:22:06.809892
# Unit test for function validate_json
def test_validate_json():
    def test(validator, content, expected_value, expected_errors=None):
        """
        Test validate_json against a validator, with a valid JSON string,
        expected value, and expected list of errors.
        """
        value, errors = validate_json(content, validator)
        assert value == expected_value
        if expected_errors is not None:
            assert errors == expected_errors

    test(
        validator=Field(),
        content=b'{"foo": ["a", "b"], "bar": 3}',
        expected_value={"foo": ["a", "b"], "bar": 3},
    )

# Generated at 2022-06-22 06:22:08.826813
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    value = JSONDecoder(strict=True).decode('{"key": "value"}')
    assert value["key"] == "value"

# Generated at 2022-06-22 06:22:18.453441
# Unit test for function validate_json
def test_validate_json():
    import json
    import typesystem
    from typesystem import types

    class Person(typesystem.Schema):
        name = types.String(required=True)
        age = types.Integer(minimum=0, maximum=150)

    content = json.dumps({"name": "Joe Schmoe", "age": 200})
    token = tokenize_json(content)
    value, error_messages = validate_json(content, Person)
    
    assert value == {"name": "Joe Schmoe", "age": 200}
    assert isinstance(value, dict)
    assert len(error_messages) == 1
    assert error_messages[0].code == "maximum"
    assert error_messages[0].position.char_index == 35

# Generated at 2022-06-22 06:22:23.213056
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test that _TokenizingDecoder constuctor actually has access to the argument.
    try:
        decoder = _TokenizingDecoder({"a": "b"}, content="test")
        assert decoder.scan_once("{}",0)[0].content == "test"
    except:
        assert False


# Generated at 2022-06-22 06:22:25.892339
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_obj = _TokenizingDecoder(content="test content")
    assert test_obj.content == "test content"


# Generated at 2022-06-22 06:22:36.124333
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello world"') == ScalarToken('hello world', 0, 12, '"hello world"')


# Generated at 2022-06-22 06:22:47.682194
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{}") == DictToken(value={}, start_position=0, end_position=1, content=b"{}")
    assert tokenize_json(b'{"a": 1}') == DictToken(value={'a': ScalarToken(1, 4, 5, b'{"a": 1}')}, start_position=0, end_position=8, content=b'{"a": 1}')
    assert tokenize_json(b'[1, 2]') == ListToken(value=[ScalarToken(1, 1, 2, b'[1, 2]'), ScalarToken(2, 4, 5, b'[1, 2]')], start_position=0, end_position=6, content=b'[1, 2]')

# Generated at 2022-06-22 06:22:57.034943
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == \
           {'foo': 'bar'}
    assert tokenize_json('[1, 2, 3]') == [1, 2, 3]
    assert tokenize_json('{"foo": {"bar": "baz"}}') == \
           {'foo': {'bar': 'baz'}}
    assert tokenize_json('{"foo": null}') == {'foo': None}
    assert tokenize_json('{"foo": true}') == {'foo': True}
    assert tokenize_json('{"foo": false}') == {'foo': False}
    assert tokenize_json('{"foo": 1.0}') == {'foo': 1.0}

# Generated at 2022-06-22 06:23:09.270761
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": [{"bar": 1}, {"baz": 2}]}'
    validator = Schema(
        fields=[
            Field("foo", type="list", items=Field("bar", type="integer")),
        ]
    )
    value, error_messages = validate_json(content=content, validator=validator)

    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].code == "invalid_type"
    assert error_messages[0].position.line_no == 3
    assert error_messages[0].position.column_no == 11
    assert error_messages[0].position.char_index == 31
    assert isinstance(error_messages[0].message, Message)

# Generated at 2022-06-22 06:23:19.489649
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 3, "b": 4}') == DictToken(
        {
            ScalarToken("a", 1, 2, '{"a": 3, "b": 4}'): ScalarToken(
                3, 6, 7, '{"a": 3, "b": 4}'
            ),
            ScalarToken("b", 10, 11, '{"a": 3, "b": 4}'): ScalarToken(
                4, 15, 16, '{"a": 3, "b": 4}'
            ),
        },
        0,
        18,
        '{"a": 3, "b": 4}',
    )



# Generated at 2022-06-22 06:23:24.397017
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test param *args
    tokenizer = _TokenizingDecoder()
    assert tokenizer.parse_array == JSONDecoder.parse_array

    # Test param **kwargs
    tokenizer = _TokenizingDecoder(content="abc")
    assert tokenizer.scan_once is not None


# Generated at 2022-06-22 06:23:27.724063
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder is not None


# Generated at 2022-06-22 06:23:40.383603
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String

    def assert_errors(result: typing.Any, text: str, error_code: str) -> None:
        assert isinstance(result, ValidationError)
        assert result.text == text
        assert result.code == error_code

    # Basic tokenization
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert token.value == {"foo": "bar"}

    # Parse and tokenize an empty document
    token = tokenize_json('')
    assert isinstance(token, Token)
    assert token.value == ''

    # Parse and tokenize a simple null value
    token = tokenize_json('null')
    assert isinstance(token, Token)
    assert token.value is None

    # Parse and token

# Generated at 2022-06-22 06:23:48.000959
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
      "integer": 1234,
      "float": 12.34,
      "true_boolean": true,
      "false_boolean": false,
      "null": null,
      "string": "hello world",
      "empty_string": "",
      "list": [1, 2, 3],
      "dict": {
        "foo": "bar"
      }
    }"""
    assert isinstance(tokenize_json(content), DictToken)



# Generated at 2022-06-22 06:23:58.603596
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello"') == ScalarToken("hello", 0, 6, '"hello"')
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")
    assert tokenize_json("true") == ScalarToken(True, 0, 4, "true")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("2.5") == ScalarToken(2.5, 0, 3, "2.5")
    assert tokenize_json("{}") == DictToken({}, 0, 2, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 2, "[]")

# Generated at 2022-06-22 06:24:06.048096
# Unit test for function tokenize_json
def test_tokenize_json():
    value, error_messages = validate_json('{"a":[1,2]}', Schema({'a':[int]}))
    assert value == {'a':[1,2]}
    assert len(error_messages) == 0

    value, error_messages = validate_json('{"a":2}', Schema({'a':[int]}))
    assert value == {'a':2}
    assert len(error_messages) == 1

    value, error_messages = validate_json('{"a":{"b":2}}', Schema({'a':{'b':int}}))
    assert value == {'a':{'b':2}}
    assert len(error_messages) == 0


# Generated at 2022-06-22 06:24:16.929238
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_string = '{"a": 1, "b": "text", "c": [1,2],"d":{"a":"b"}}'
    test_json_decoder = _TokenizingDecoder(content=test_string)
    result = test_json_decoder.scan_once(test_string, 0)
    assert result[1] == len(test_string)

    test_string = '{"a": 1, "c": [1,2],"d":{"a":"b"}}'
    test_json_decoder = _TokenizingDecoder(content=test_string)
    result = test_json_decoder.scan_once(test_string, 0)
    assert result[1] == len(test_string)


# Generated at 2022-06-22 06:24:27.455816
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")

    token, error_messages = validate_json('"abc"',field)
    assert error_messages == []

    token, error_messages = validate_json('"ab"',field)
    assert error_messages == []

    token, error_messages = validate_json('"a"',field)
    assert error_messages == []

    token, error_messages = validate_json('"123"',field)
    assert error_messages == []

    token, error_messages = validate_json('"a=4"',field)
    assert error_messages == []

    token, error_messages = validate_json('"true"',field)
    assert error_messages == []


# Generated at 2022-06-22 06:24:31.681770
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test content")
    scanner = decoder.scan_once
    assert scanner
    try:
        scanner("", 0)
    except StopIteration as err:
        assert err.value == 0



# Generated at 2022-06-22 06:24:35.654389
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "first_name": "a"
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["first_name"].value == "a"



# Generated at 2022-06-22 06:24:44.071353
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize import tokenize_json

    token = tokenize_json('{"test": "value"}')
    assert type(token) is DictToken
    dict_val = token.value
    assert len(dict_val) == 1
    assert type(dict_val) is dict
    for key, value in dict_val.items():
        assert type(key) is ScalarToken
        assert key.value == "test"
        assert type(value) is ScalarToken
        assert value.value == "value"



# Generated at 2022-06-22 06:24:53.238324
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:59.571720
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{}', Schema) == (
        {},
        Message(
            code='validation_error',
            text="'Schema' is not valid under any of the given schemas",
            position=Position(
                line_no=1, column_no=2, char_index=1
            )
        )
    )



# Generated at 2022-06-22 06:25:02.826347
# Unit test for function tokenize_json
def test_tokenize_json():
    content = r"""
    {
        "name": "John Doe",
        "age": 54
    }
    """
    token = tokenize_json(content)
    print(token.children)


# Generated at 2022-06-22 06:25:14.466349
# Unit test for function validate_json
def test_validate_json():
    schema = Schema()
    schema.add_field('a', String())
    schema.add_field('b', String())

    try:
        validate_json('{"a": "foo"}', schema)
    except ValidationError as e:
        assert len(e.error_messages) == 1
        assert e.error_messages[0].message_text == "Missing property 'b'"
        assert e.error_messages[0].error_code == 'missing_property'
        assert e.error_messages[0].position.column_no == 1
        assert e.error_messages[0].position.line_no == 1
        assert e.error_messages[0].position.char_index == 1
    else:
        assert False, "Expected validation error."


# Generated at 2022-06-22 06:25:24.204931
# Unit test for function validate_json
def test_validate_json():
    with open(unit_test_path + '/test_jsons/test1.json', 'r') as f:
        content = f.read()
        print(content)
        print(type(content))
        print(type(bytes(content.encode('utf-8'))))
        result_tuple = validate_json(bytes(content.encode('utf-8')), validator=CategorySchema)
        print(result_tuple)
        print(type(result_tuple))
        print(type(result_tuple[0]))
        print(type(result_tuple[1]))
        result = result_tuple[0]
        print(result) # just print the value
        print(type(result))

if __name__ == '__main__':
    test_validate_json()

# Generated at 2022-06-22 06:25:25.446618
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:25:37.906979
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    #_TokenizingJSONObject
    s = '{"key": "value"}'
    strict = 0
    scan_once = None
    memo = {}
    content = '{"key": "value"}'

    parse_object = _TokenizingJSONObject
    value, end = parse_object((s, 0), strict, scan_once, memo, content)
    assert value == {'key': 'value'}
    assert end == len(s)

    # test _make_scanner
    context = None
    content = '{"key": "value"}'
    scan_once = _make_scanner(context, content)
    # test scan_once
    value, end = scan_once(s, 0)
    assert value.value == {'key': 'value'}
    assert value.start == 0
    assert value

# Generated at 2022-06-22 06:25:39.581964
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    c = _TokenizingDecoder("")
    pass


# Generated at 2022-06-22 06:25:51.393306
# Unit test for function validate_json
def test_validate_json():
    # Test when validating against a Field.

    # Test when validating against a Schema.
    schema_type = typing.TypeVar("schema_type", bound=Schema)

    class TestSchema(Schema):
        pass

    @singledispatch
    def _get_schema_type(validator: Validator) -> schema_type:
        raise TypeError("Unsupported validator type.")
    _get_schema_type.register(TestSchema)(lambda _: TestSchema)

    def _get_schema(validator: Validator) -> schema_type:
        schema_class = _get_schema_type(validator)
        return schema_class()

    validator = _get_schema(TestSchema)
    value, errors = validate_json(b'"hello"', validator)
   

# Generated at 2022-06-22 06:26:03.212392
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest

    # Empty string.
    with pytest.raises(Exception) as ex:
        tokenize_json("")

    assert ex.value.message == "No content."
    assert ex.value.code == "no_content"

    # Primitive values.
    assert tokenize_json('"Test"') == ScalarToken("Test", 0, 5, '"Test"')
    assert tokenize_json("True") == ScalarToken(True, 0, 4, "True")
    assert tokenize_json("True") == ScalarToken(True, 0, 4, "True")
    assert tokenize_json("1.1") == ScalarToken(1.1, 0, 3, "1.1")

    # Arrays.

# Generated at 2022-06-22 06:26:05.823889
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    JSONDecoder = _TokenizingDecoder
    assert JSONDecoder is not None
    assert _TokenizingDecoder is not None


# Generated at 2022-06-22 06:26:15.420982
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo", 1, 4, '{"foo": "bar"}'): ScalarToken("bar", 10, 13, '{"foo": "bar"}')},1,13,'{"foo": "bar"}')
    assert tokenize_json('"hello"') == ScalarToken("hello", 1, 7, '"hello"')
    assert tokenize_json('42') == ScalarToken(42, 1, 2, '42')
    assert tokenize_json('[1, 2]') == ListToken([ScalarToken(1, 2, 2, '[1, 2]'), ScalarToken(2, 5, 5, '[1, 2]')],1,6,'[1, 2]')
    assert tokenize_json('[]') == ListToken

# Generated at 2022-06-22 06:26:27.323309
# Unit test for function tokenize_json
def test_tokenize_json():
    c1 = '{"a": 1, "b": 2}'
    assert tokenize_json(c1) == {"a": 1, "b": 2}
    c2 = {"a": [{"b": 1}, {"b": 2}]}
    assert tokenize_json(c2) == {"a": [{"b": 1}, {"b": 2}]}
    c3 = """
    {
        "a": {
            "b": 1
        },
        "c": 3
    }
    """
    assert tokenize_json(c3) == {"a": {"b": 1}, "c": 3}

# Generated at 2022-06-22 06:26:39.738361
# Unit test for function validate_json
def test_validate_json():
    contents = [
        (
            """
                {
                    "field": "hello"
                }
            """,
            {"field": "hello"},
        ),
        (
            """
                {
                    "field": "hello",
                    "field2": "world"
                }
            """,
            {
                "field": "hello",
                "field2": "world",
            },
        ),
        (
            """
                {
                    "field": "hello",
                    "field2": [
                        "a",
                        "b",
                        "c"
                    ]
                }
            """,
            {
                "field": "hello",
                "field2": ["a", "b", "c"],
            },
        ),
    ]

    for content, expected_result in contents:
        assert validate_json

# Generated at 2022-06-22 06:26:54.339693
# Unit test for function tokenize_json
def test_tokenize_json():
    test_string = '''
{
  "ds_id" : "ds_id",
  "db_name" : "db_name",
  "query" : "SELECT * FROM orders WHERE order_date > '2019-01-01'",
  "first_row" : 1,
  "increment" : 100,
  "last_row" : 1000,
  "parameters" : {
    "key1" : "value1",
    "key2" : "value2"
  }
}

'''
    print(tokenize_json(test_string))

# Generated at 2022-06-22 06:27:06.440379
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json ="""
        {
            "str_field":"str value",
            "int_field":50,
            "bool_field":true,
            "float_field":3.14,
            "null_field":null,
            "list_field":[1,2,3,4],
            "dict_field":{"key":"value"},
            "nested_list_field":[[1,2],[3,4]],
            "nested_dict_field":{"key":{"inner_key": "inner_value"}}
        }
    """
    root_token = tokenize_json(test_json)

# Generated at 2022-06-22 06:27:12.850140
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:27:23.751869
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == Token(None, 0, 0, '')
    assert tokenize_json('[]') == ListToken([], 0, 1, '[', ']')
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{', '}')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('[true]') == ListToken([ScalarToken(True, 1, 4, 'true')], 0, 5, '[', ']')
    assert tokenize_json('[1,2]') == ListToken([ScalarToken(1, 1, 1, '1'), ScalarToken(2, 3, 3, '2')], 0, 5, '[', ']')

# Generated at 2022-06-22 06:27:34.970519
# Unit test for function validate_json
def test_validate_json():

    # Test that the function raises an error when the document is empty
    raises_error = False
    try:
        validate_json('', Field)
    except ParseError:
        raises_error = True
    assert raises_error

    # Test that the function raises an error when a validator is not a Field/Schema
    raises_error = False
    try:
        validate_json('{"asdf": "qwer"}', dict)
    except TypeError:
        raises_error = True
    assert raises_error

    # Test that the function handles a valid JSON string
    schema = Schema([Field(name='asdf', type='string'), Field(name='qwer', type='string')], name='Sample Schema')
    from typesystem import Schema
    token, messages = validate_json('{"asdf": "qwer"}', schema)

# Generated at 2022-06-22 06:27:47.003348
# Unit test for function validate_json
def test_validate_json():
    valid_json_string = '''
    {
        "name": "John Doe",
        "age": 30,
        "is_active": false,
        "address": {
            "street": "123 Main Street",
            "city": "New York",
            "state": "NY"
        },
        "phone_numbers": [
            "+1234567890",
            "+0987654321"
        ]
    }
    '''

# Generated at 2022-06-22 06:27:53.753551
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = True
        age = True

    content = b'{"name": "Jane Doe", "age": 12}'
    value, messages = validate_json(content=content, validator=Person)
    assert value == {'name': 'Jane Doe', 'age': 12}
    assert len(messages) == 0

    content = b'{"name": "Jane Doe"}'
    value, messages = validate_json(content=content, validator=Person)
    assert value == {}
    assert len(messages) == 1

# Generated at 2022-06-22 06:28:03.115050
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # This test consists of two parts.
    # 1) Test whether the constructor of class _TokenizingDecoder is working properly.
    #    It can be achieved by checking the attributes of the constructed object.

    # By default, the context is utf-8
    decoder = _TokenizingDecoder(content="test")
    assert decoder.strict == False
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant == JSONDecoder.parse_constant
    assert decoder.object_hook == JSONDecoder.object_hook
    assert decoder.object_pairs_hook == JSONDecoder.object_pairs_hook
    assert decoder.memo == None
    assert decoder.content == "test"

    # With other context
    decoder = _Token

# Generated at 2022-06-22 06:28:06.514648
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    string = '{"test": null, "foo": "bar"}'
    decoder = _TokenizingDecoder(content=string)
    assert isinstance(decoder.scan_once, _make_scanner)

# Generated at 2022-06-22 06:28:16.916590
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test values
    test_object_string = '{"a":1}'
    test_list_string = '[1, 2, 3]'
    test_float_string = '0.1'
    test_int_string = '3'
    test_null_string = 'null'
    test_true_string = 'true'
    test_false_string = 'false'
    test_empty_string = ''

    # Define testing function
    def test_decoder(test_string : str, expected: typing.Any, expected_token: Token):
        # Create new decoder instance
        test_decoder = _TokenizingDecoder(content=test_string)
        # Get the test value
        value = test_decoder.decode(test_string)
        # Assert the test value is the expected value