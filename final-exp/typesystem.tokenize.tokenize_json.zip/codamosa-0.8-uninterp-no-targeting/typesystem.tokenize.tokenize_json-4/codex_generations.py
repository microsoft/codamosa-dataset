

# Generated at 2022-06-22 06:18:48.190198
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    import json

    # Simple field test
    class UserSchema(typesystem.Schema):
        name = typesystem.String(max_length=100)
        
    content = json.dumps({"name": "Max Mustermann"})
    result = validate_json(content, UserSchema)

    assert isinstance(result[0].value, str)

    # Test multiple errors
    class UserSchema(typesystem.Schema):
        name = typesystem.String(max_length=5)
        
    content = json.dumps({"name": "Max Mustermann"})
    result = validate_json(content, UserSchema)

    assert len(result[1]) == 1

# Generated at 2022-06-22 06:18:58.603988
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class PersonSchema(Schema):
        name = String(min_length=2)

    content = '{"name": "Jon"}'
    value, error_messages = validate_json(content, PersonSchema)
    assert isinstance(value, dict)
    assert not error_messages

    content = '{"name": "Jo"}'
    value, error_messages = validate_json(content, PersonSchema)
    assert isinstance(value, dict)
    assert len(error_messages) == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 11


# Generated at 2022-06-22 06:19:10.455082
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key":"value"}')
    assert isinstance(token, Token) is True
    assert isinstance(token, DictToken) is True
    assert token.start_position.char_index == 0
    assert token.start_position.line_no == 1
    assert token.start_position.column_no == 1
    assert token.end_position.char_index == 13
    assert token.end_position.line_no == 1
    assert token.end_position.column_no == 14
    assert token.children[0][0].content == 'key'
    assert token.children[0][0].start_position.char_index == 2
    assert token.children[0][0].start_position.line_no == 1

# Generated at 2022-06-22 06:19:17.418496
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """{
    "items": {
        "1": {
            "name": "example1"
        },
        "2": {
            "name": "example2"
        }
    },
    "property": "test"
}"""
    token = tokenize_json(json_str)
    assert token.value['property'].value == "test"
    assert token.value['items'].value['2'].value['name'].value == "example2"


# Generated at 2022-06-22 06:19:19.649648
# Unit test for function validate_json
def test_validate_json():
    f = Field()
    validate_json(b'{"foo": "bar"}', f)

# Generated at 2022-06-22 06:19:26.677782
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token, ScalarToken, DictToken, ListToken

    def test(
        content: str,
        expected_type: typing.Type[Token],
        expected_value: typing.Any,
        expected_position: Position,
    ) -> None:
        token = tokenize_json(content)
        assert isinstance(token, expected_type)
        assert token.value == expected_value
        assert token.start == expected_position.char_index
        assert token.end == expected_position.char_index + len(content) - 1
        assert token.content == content

    test(content="null", expected_type=ScalarToken, expected_value=None, expected_position=Position(char_index=0))

# Generated at 2022-06-22 06:19:38.139037
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import String, Int
    from typesystem import validate, ValidationError
    from typesystem.fields import String as StringField

    # Test expected success
    content = '{"name": "1"}'
    validator = StringField()
    value, error_messages = validate_json(content, validator)
    assert value == "1"
    # No error messages expected
    assert not error_messages

    # Test expected failure for parse error
    content = '{"name": "1", "age": "not_a_number"}'
    validator = StringField()
    try:
        value, error_messages = validate_json(content, validator)
    except ParseError as exc:
        # Assert that we get a ParseError 
        assert exc.code == "parse_error"
       

# Generated at 2022-06-22 06:19:47.917386
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Runs all of the unit tests required for the function, tokenize_json.
    '''
    # Test 1:
    # Given a simple json string, create a token object.
    content1 = '{"firstName":"John","lastName":"Smith","age":25}'
    token = tokenize_json(content1)
    if(type(token) != DictToken):
        raise AssertionError(
            'test_tokenize_json failed on test 1. '
            'Expected type DictToken but got {}.'.format(type(token)))

    # Test 2:
    # Given a simple json string, create a token object.
    content2 = '[1,2,3,4]'
    token = tokenize_json(content2)
    if(type(token) != ListToken):
        raise Assertion

# Generated at 2022-06-22 06:20:00.540843
# Unit test for function validate_json
def test_validate_json():
    content = """
        {
            "title": "blah",
            "foo": {
                "x" : "x",
                "y" : "y",
                "z" : "z"
            },
            "bar": [1,2,3,4,5],
            "baz": "baz",
            "spam": "eggs"
        }"""

    # Test with a schema
    from typesystem import Schema, fields
    from tests.schemas import TestItemSchema

    value, errors = validate_json(content, TestItemSchema)
    assert isinstance(value, dict)
    assert errors == []

    # Test with a field

# Generated at 2022-06-22 06:20:04.903717
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    content= '{}'
    decoder = _TokenizingDecoder(content=content)
    assert str(decoder) ==  '_TokenizingDecoder()'
    assert isinstance(decoder,JSONDecoder)
    assert isinstance(decoder.scan_once,typing.Callable)


# Generated at 2022-06-22 06:20:23.412470
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='content of the parsed file')
    assert type(decoder.scan_once) == type(_make_scanner(decoder, 'content of the parsed file'))


# Generated at 2022-06-22 06:20:25.972540
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder().parse_string is not None
    assert _TokenizingDecoder().parse_float is not None


# Generated at 2022-06-22 06:20:35.776505
# Unit test for function validate_json
def test_validate_json():

    class Person(Schema):
        first = str
        last = str
        age = int

    content = '{"first": "John", "last": "Doe", "age": "42"}'
    # validate_json takes a string and returns a tuple of (value, [error messages or None])
    result = validate_json(content, Person)
    # for this test we are expecting an age error message
    assert result[1][0].text == "'age' field must be integer."
    assert result[1][0].position.column_no == 11
    assert result[1][0].position.line_no == 1
    assert result[1][0].position.char_index == 115



# Generated at 2022-06-22 06:20:41.767685
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "foo": "bar",
        "baz": 42,
        "quux": [
            "a",
            "b"
        ],
        "quuz": null
    }
    """

    token = tokenize_json(content)

    assert isinstance(token, DictToken)
    assert len(token.value) == 4
    fields = token.value.keys()
    assert isinstance(next(fields), ScalarToken)
    assert next(fields).value == "foo"



# Generated at 2022-06-22 06:20:44.012888
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(None, None)
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-22 06:20:55.869562
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = "string"

    class PersonWithErrors(Schema):
        name = "string"
        age = "float"

    result = validate_json(Person, '{"name": "Bob"}')
    assert (result[1]) == None

    result2 = validate_json(Person, '{"name": 1}')
    assert (result2[1][0] == ValidationError("Not a valid string.", "invalid_type"))

    result3 = validate_json(Person, "{}")
    assert (result3[1][0] == ValidationError("This field is required.", "required"))

    result4 = validate_json(PersonWithErrors, '{"name": "Bob", "age": "24"}')

# Generated at 2022-06-22 06:21:02.268188
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = b'{\n\t"name": "John",\n\t"age": 30\n}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once() == (DictToken({"name": "John", "age": 30}, 0, 11, '{"name": "John",\n\t"age": 30\n}'), 12)
    assert decoder.scan_once() == ({'name': 'John', 'age': 30}, 12)


# Generated at 2022-06-22 06:21:09.614349
# Unit test for function tokenize_json
def test_tokenize_json():
    # Assert that tokenize_json properly tokenizes a JSON-formatted string.

    # Test case
    content = '{"key": "value"}'

    # The correct tokens
    correct = DictToken(
        {"key": ScalarToken("value", 1, 10, content)}, 0, 14, content
    )

    # The result of applying tokenize_json to content
    result = tokenize_json(content)

    assert result == correct
    assert result.to_native() == {"key": "value"}



# Generated at 2022-06-22 06:21:16.930573
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key1": "value1", "key2": ["value2", "value3"]}')
    assert (token.value == {"key1": "value1", "key2": ["value2", "value3"]})
    assert token.start_pos == (0, 0)
    assert token.end_pos == (0, 44)
    assert isinstance(token.value, dict)
    assert isinstance(token.value['key2'], list)

# Generated at 2022-06-22 06:21:27.478159
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json("{}")
    assert isinstance(result, dict)
    assert result == {}

    result = tokenize_json("[]")
    assert isinstance(result, list)
    assert result == []

    result = tokenize_json("null")
    assert isinstance(result, ScalarToken)
    assert result.value is None

    result = tokenize_json("true")
    assert isinstance(result, ScalarToken)
    assert result.value is True

    result = tokenize_json("false")
    assert isinstance(result, ScalarToken)
    assert result.value is False

    result = tokenize_json("123")
    assert isinstance(result, ScalarToken)
    assert result.value == 123

    result = tokenize_json("-123")

# Generated at 2022-06-22 06:21:45.229554
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Check a valid constructor
    decoder = _TokenizingDecoder(content="my content")
    assert decoder.memo == {}
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_float == JSONDecoder.parse_float
    assert decoder.parse_int == JSONDecoder.parse_int
    assert decoder.parse_string == JSONDecoder.parse_string
    assert decoder.strict == True
    assert decoder.scan_once == _make_scanner(decoder, "my content")


# Generated at 2022-06-22 06:21:49.155116
# Unit test for function validate_json
def test_validate_json():
    schema = Schema()
    value, messages = validate_json(
        content=b'{"string": "foo", "number": 42}',
        validator=schema,
    )
    assert value == {"string": "foo", "number": 42}
    assert messages == []


# Generated at 2022-06-22 06:21:56.182148
# Unit test for function validate_json
def test_validate_json():
    content = b'{"a":1}'
    validator = Schema({"a": IntegerField()})
    value, messages = validate_json(content, validator)

    assert value == {"a": 1}
    assert len(messages) == 0

    content = b'"a"'
    validator = Schema({"a": IntegerField()})
    value, messages = validate_json(content, validator)
    assert value == "a"
    assert len(messages) == 1
    assert messages[0].code == "type_error"



# Generated at 2022-06-22 06:21:57.075695
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="")

# Generated at 2022-06-22 06:21:58.369664
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder != None


# Generated at 2022-06-22 06:22:08.519400
# Unit test for function validate_json
def test_validate_json():
    from typesystem.error_messages import ErrorMessage, ErrorMessageType
    from typesystem.fields import Integer, String, Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ListToken, DictToken

    class Color(Schema):
        name = String()

    class Palette(Schema):
        name = String(required=True)
        colors = List(of=Color)
        locked = Boolean(default=False)

    good_palette = """
    {
        "colors": [
            {"name": "blue"},
            {"name": "green"}
        ],
        "locked": true,
        "name": "Best palette ever"
    }
    """


# Generated at 2022-06-22 06:22:19.192410
# Unit test for function validate_json
def test_validate_json():
    _schema = Schema(
        {
            "field1": int,
            "field2": str,
        }
    )
    content = "'{'field1': '1', 'field2': 'foo'}'"
    value, messages = validate_json(content, _schema)
    assert value == {'field1': 1, 'field2': 'foo'}
    assert messages[0].text == "'1' cannot be parsed as int"
    assert messages[0].position.line_no == 1
    assert messages[0].position.column_no == 9
    content = "'{'field1': 1, 'field2': 'foo'}'"
    value, messages = validate_json(content, _schema)
    assert value == {'field1': 1, 'field2': 'foo'}

# Generated at 2022-06-22 06:22:29.321585
# Unit test for function validate_json
def test_validate_json():
    """
    Test function validate_json():
    """
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    # Regression: document that validate_json, unlike .validate(), will raise
    # a ValueError for invalid numbers.
    class MySchema(Schema):
        field = Integer()

    error_messages = validate_json('{"field": "invalid"}', MySchema)
    assert isinstance(error_messages[1][0], ValueError)

    class Product(Schema):
        name = String()
        price = Integer()

    json_string = '{"name": "iPhone", "price": 999}'
    valid_product, errors = validate_json(json_string, Product)

    assert valid_product
    assert len(errors) == 0

    json_string

# Generated at 2022-06-22 06:22:41.365821
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "foo": "bar",
        "answer": 42,
        "bool": true,
        "nullvar": null,
        "falsy": false
    }
    """
    tokens = tokenize_json(content)
    assert isinstance(tokens, DictToken)
    assert tokens.value == {
        "foo": ScalarToken("bar", 11, 14, content),
        "answer": ScalarToken(42, 35, 38, content),
        "bool": ScalarToken(True, 55, 58, content),
        "nullvar": ScalarToken(None, 75, 79, content),
        "falsy": ScalarToken(False, 98, 102, content),
    }


# Generated at 2022-06-22 06:22:50.166469
# Unit test for function validate_json
def test_validate_json():
    content = "{ 'foo': 1, 'bar': 2}"
    value = validate_json(content, validator={"foo": int, "bar": int})
    assert value == ({"foo": 1, "bar": 2}, [])

    content = "{ 'foo': 1, 'bar': 'two' }"
    value = validate_json(content, validator={"foo": int, "bar": int})
    assert value[0] is None and len(value[1]) == 1

    content = "{ 'foo': 1, 'bar': 'two' }"
    value = validate_json(content, validator={"foo": int, "bar": str})
    assert value == ({"foo": 1, "bar": 'two'}, [])

    content = "{ 'foo': 1, 'bar': 2, 'baz': 3 }"
   

# Generated at 2022-06-22 06:22:57.404581
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="foo")
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-22 06:23:09.574828
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizer = _TokenizingDecoder(content='{"x":"y"}')
    obj = tokenizer.decode('{"x":"y"}')
    assert isinstance(obj, Token)
    assert isinstance(obj, DictToken)
    assert obj.start_position.char_index == 0
    assert obj.end_position.char_index == 8

    assert len(obj.value) == 1
    assert isinstance(obj.value[0], ScalarToken)
    assert obj.value[0].start_position.char_index == 2
    assert obj.value[0].end_position.char_index == 3
    # Note: to test the different code paths in scan_once (see the pragma: no cover statement
    # in the code), use the following line in place of the two lines above:
    # assert obj.value[0

# Generated at 2022-06-22 06:23:15.689987
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    file_content = open('examples/test.json', mode='r', encoding='utf-8')
    content = file_content.read()
    # when
    decoder = _TokenizingDecoder(content=content)
    # then
    assert decoder.strict == False
    assert decoder.scan_once != None



# Generated at 2022-06-22 06:23:19.212801
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    data = '{"a": "b", "c": 1, "d": {"e": 2, "f": [1, 2, 3]}}'
    assert data == str(_TokenizingDecoder(content=data).decode(data))


# Generated at 2022-06-22 06:23:29.321668
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        fields=[
            Field(name="name", type="string", required=True),
            Field(name="age", type="integer", required=True),
        ]
    )

    json_input = '{"name": "John", "age": 42}'
    value, error_messages = validate_json(json_input, schema)

    assert value == {"name": "John", "age": 42}
    assert error_messages == []

    json_input = '{"name": "John", "age": "forty-two"}'
    value, error_messages = validate_json(json_input, schema)

    assert value == {}

# Generated at 2022-06-22 06:23:42.118575
# Unit test for function validate_json
def test_validate_json():
    import io
    import typesystem
    from typesystem_json import JSONSchema
    from typesystem.types import String, Integer

    class UserSchema(JSONSchema):
        name = String(required=True)
        age = Integer(required=True)

    # Create a schema that takes a JSON string and decodes it into python types
    class User(typesystem.types.JSON):
        schema = UserSchema

    # Create an example of the class
    user = User(
        {
            "name": "John",
            "age": 25,
        }
    )

    # Serialize the class into json
    serialized = user.serialize()
    print(serialized)

    # Validate the JSON.
    value, error_messages = validate_json(serialized, UserSchema)

# Generated at 2022-06-22 06:23:45.900283
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json("{\"a\":1,\"b\":2}")
    assert isinstance(token, DictToken)
    tokens = token.value
    assert isinstance(tokens["a"], ScalarToken)
    assert isinstance(tokens["b"], ScalarToken)


# Generated at 2022-06-22 06:23:49.055111
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert type(token) is DictToken



# Generated at 2022-06-22 06:23:52.865364
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"asf": "asdf"}'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)
    assert decoder.scan_once is not None



# Generated at 2022-06-22 06:24:01.718098
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:25.919907
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer, Float
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import ValidationError as PositionedValidationError
    import json

    f = String()
    assert validate_json("hello world", f) == ("hello world", [])
    assert validate_json("", f) == (None, [])
    assert validate_json("123", f) == (None, [])
    assert validate_json("null", f) == (None, [])
    assert validate_json("false", f) == (None, [])
    assert validate_json("[123,234]", f) == (None, [])
    assert validate_json("{'one':123}", f) == (None, [])

# Generated at 2022-06-22 06:24:29.850671
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": [1,2,"3"]}') == {
        "a": [1, 2, "3"]
    }



# Generated at 2022-06-22 06:24:41.133438
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid cases
    string = "{}"
    result = tokenize_json(string)
    assert result == DictToken(value={}, start=0, end=1, content=string)

    string = '{"k1":"v1","k2":[],"k3":3,"k4":3.1,"k5":false,"k6":true,"k7":null}'
    result = tokenize_json(string)
    assert result == DictToken(
        value={"k1": "v1", "k2": [], "k3": 3, "k4": 3.1, "k5": False, "k6": True, "k7": None},
        start=0,
        end=len(string) - 1,
        content=string,
    )

    # Error cases

# Generated at 2022-06-22 06:24:51.563740
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:24:55.082392
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"hello": "world"}')
    assert decoder.parse_int == int
    assert decoder.parse_float == float
    assert decoder.parse_array == JSONDecoder.parse_array

# Generated at 2022-06-22 06:25:07.241188
# Unit test for function validate_json
def test_validate_json():
    # Test that a JSON parse error is correctly transformed into a
    # ParseError.
    try:
        value, error_messages = validate_json('{"attr": invalid}', fields.String())
        assert False
    except ParseError as exc:
        assert "Expecting value" == exc.text
        assert "parse_error" == exc.code
        assert (1, 11) == (exc.position.line_no, exc.position.char_index)

    # Test a simple valid case.
    value, error_messages = validate_json('{"attr": "value"}', fields.String())
    assert {"attr": "value"} == value
    assert [] == error_messages

    # Test a simple invalid case.
    value, error_messages = validate_json('{"attr": "value"}', fields.Boolean())
   

# Generated at 2022-06-22 06:25:11.610812
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key": "value"}'
    decoder = _TokenizingDecoder(content=content)
    token, end = decoder.scan_once(content, 0)
    assert token != None
    assert end == 15


# Generated at 2022-06-22 06:25:19.557951
# Unit test for function validate_json
def test_validate_json():
    content_str = """[
        {
            "name": "John",
            "age": 36,
            "children": [
                "Jane",
                "Michael"
            ]
        },
        {
            "name": "Alice",
            "age": 45,
            "children": [
                "Mallory"
            ]
        }
    ]"""

    class Person(Schema):
        name = String()
        age = Integer()
        children = Array(String())

    class PersonList(Schema):
        items = Array(Person)

    try:
        validate_json(content_str, PersonList())
    except ValidationError as error:
        print(error.messages)



# Generated at 2022-06-22 06:25:21.081897
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="test")


# Generated at 2022-06-22 06:25:33.497750
# Unit test for function validate_json
def test_validate_json():
    """
    Test the validate_json function.
    We create a validator for JSOn with a particular structure and then test
    validation with valid and invalid inputs.
    """
    content = '{"float_list": [1.1, 2.1], "int_list": [1,2], "int": 2}'

# Generated at 2022-06-22 06:25:52.635094
# Unit test for function validate_json
def test_validate_json():
    # test validate_json: case: valid json
    valid_json = '{"name": "John Doe", "age": 42}'
    validation = validate_json(
        valid_json, 
        {
            "name": "text", 
            "age": "integer"
        }
    )
    assert not validation[1]

    # test validate_json: case: invalid json
    invalid_json = '{"name": John Doe, "age": 42'
    validation = validate_json(
        invalid_json, 
        {
            "name": "text", 
            "age": "integer"
        }
    )
    assert validation[1]
    assert len(validation[1]) == 1

    # test validate_json: case: invalid json and valid json

# Generated at 2022-06-22 06:26:04.654433
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test parsing an empty json string
    try:
        result = tokenize_json("")
    except ParseError as parse_error:
        assert parse_error.position.line_no == 1
        assert parse_error.position.column_no == 1
        assert parse_error.position.char_index == 0
        assert parse_error.code == "no_content"

    # Test parsing an empty json object
    result = tokenize_json("{}")
    assert isinstance(result, DictToken)
    assert result.raw == "{}"

    # Test parsing an empty json array
    result = tokenize_json("[]")
    assert isinstance(result, ListToken)
    assert result.raw == "[]"

    # Test parsing a string
    result = tokenize_json('"hello world"')

# Generated at 2022-06-22 06:26:16.329605
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class JSONSchema(Schema):
        name = String(max_length=5)
        age = Integer()

    content1 = '{"name":"David"}'
    token1 = tokenize_json(content1)
    value1, error_messages = validate_with_positions(token=token1, validator=JSONSchema)

    assert value1 == {"name": "David"}
    assert error_messages["age"][0].text == "Missing value."

    content2 = '{"name":"David","age":29}'
    token2 = tokenize_json(content2)
    value2, error_messages = validate_with_positions(token=token2, validator=JSONSchema)


# Generated at 2022-06-22 06:26:19.643456
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name":"nawaz","age":25}') == {
            "name": "nawaz",
            "age": 25
        }


# Generated at 2022-06-22 06:26:25.587997
# Unit test for function validate_json
def test_validate_json():
    # test invalid json
    try:
        validate_json('{{}', str)
    except ValueError as e:
        assert e
    # test valid json
    try:
        res, msgs = validate_json('{"name": "123"}', {
            "name": str
        })
        assert res == {"name": "123"}
    except ValueError as e:
        assert False



# Generated at 2022-06-22 06:26:30.933985
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    print(_TokenizingDecoder("a"))
    print(_TokenizingDecoder("a","b"))
    print(_TokenizingDecoder("a","b","c"))
    print(_TokenizingDecoder("a","b","c","d"))
    print(_TokenizingDecoder("a","b","c","d","e"))


# Generated at 2022-06-22 06:26:39.676475
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "jane", "age": 30, "occupation": "lawyer"}'
    class PersonSchema(Schema):
        name = fields.String(max_length=20)
        age = fields.Integer(maximum=65)
        occupation = fields.String(choices=["lawyer", "plumber"])
    assert validate_json(content, PersonSchema) == (
        {"name": "jane", "age": 30, "occupation": "lawyer"}, []
    )

    # Invalid JSON
    content = '"name": "jane", "age": 30, "occupation": "lawyer"}'
    value, errors = validate_json(content, PersonSchema)
    assert not value
    assert len(errors) == 1
    assert errors[0].type == ParseError.TYPE
   

# Generated at 2022-06-22 06:26:50.181613
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    result = validate_json('"foo"', field)
    assert result == ("foo", {})

    result = validate_json('"hello world"', field)
    assert result == ("hello world", {})

    field = Field(type="integer")
    result = validate_json('123', field)
    assert result == (123, {})

    result = validate_json('123', field)
    assert result == (123, {})

    # Failure to parse
    field = Field(type="string")
    result = validate_json('"hello, world"', field)

# Generated at 2022-06-22 06:27:00.138416
# Unit test for function validate_json
def test_validate_json():
    # This is a test for the validate_json function
    # First, we create a schema to validate the content
    class Person(Schema):
        name = String(max_length=20)
        age = Integer(minimum=0, maximum=99)
    # Next, we create a json string that is valid content
    valid_content = '{"name":"George","age":55}'
    # We use our validate_json function to validate the content
    # It should return a tuple of (value, error_messages)
    # We check the value and error_messages to ensure that there are no errors
    value, error_messages = validate_json(valid_content, Person)
    assert value == {"name": "George", "age": 55}
    assert len(error_messages) == 0
    # Next, we create invalid content
    invalid

# Generated at 2022-06-22 06:27:09.565325
# Unit test for function validate_json
def test_validate_json():
    import json
    import sys

    def load_json(json_content):
        """
        A json.loads function that returns a two tuple of (value, error_messages)
        """
        token = tokenize_json(json_content)
        return token.value, token.validate()

    def validate_fail(json_content, validator):
        """
        A json.loads function that returns a two tuple of (value, error_messages)
        """
        value, messages = validate_json(json_content, validator)
        assert len(messages) > 0
        return value, messages


# Generated at 2022-06-22 06:27:30.444269
# Unit test for function tokenize_json
def test_tokenize_json():
    tok = tokenize_json('{"a": "hello", "b": [1, 2, 3]}')
    assert tok.column == 0
    assert tok.line == 0
    assert len(tok.elements) == 2
    assert tok.elements[0].key.value == "a"
    assert tok.elements[0].value.column == 6
    assert tok.elements[0].value.line == 0
    assert tok.elements[0].value.value == "hello"
    assert tok.elements[1].key.value == "b"
    assert tok.elements[1].value.column == 16
    assert tok.elements[1].value.line == 0
    assert len(tok.elements[1].value.elements) == 3
    assert to

# Generated at 2022-06-22 06:27:31.957796
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    Check that _TokenizingDecoder is an instance of JSONDecoder
    """
    decoder = _TokenizingDecoder("config.json")
    assert isinstance(decoder, JSONDecoder)

# Generated at 2022-06-22 06:27:35.465834
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def testfunc():
        test = _TokenizingDecoder("", "", "", "", "")
        assert test.scan_once("")

    testfunc()

# Generated at 2022-06-22 06:27:47.381534
# Unit test for function validate_json
def test_validate_json():
    data = b'{"first_name":"John","last_name":"Doe","email":"john.doe@example.com"}'
    schema = Schema(fields={"first_name": str, "last_name": str, "email": str})

    try:
        value, errors = validate_json(data, schema)
    except ParseError as e:
        value, errors = None, [e]
    assert value and not errors

    schema = Schema(fields={"first_name": str, "last_name": str, "email": int})

    try:
        value, errors = validate_json(data, schema)
    except ParseError as e:
        value, errors = None, [e]
    assert value is None and errors

    schema = Schema(fields={"first_name": str, "email": int})

# Generated at 2022-06-22 06:27:49.125274
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder(content='hi')
    assert context.content == 'hi'


# Generated at 2022-06-22 06:27:56.024645
# Unit test for function tokenize_json
def test_tokenize_json():
    json1 = """{
        "foo": "bar",
        "baz": [
            1,
            2,
            3
        ]
    }"""
    expected = {'foo': 'bar', 'baz': [1, 2, 3]}
    obtained = tokenize_json(json1)
    test_equal(type(obtained), type(expected))
    test_equal(obtained, expected)



# Generated at 2022-06-22 06:27:58.121516
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="").content == ""


# Generated at 2022-06-22 06:28:04.956222
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String
    from typesystem.schemas import Schema

    content = b'{"name": "John"}'

    class UserSchema(Schema):
        name = String(max_length=128)

    assert validate_json(content, UserSchema()) == (
        {"name": "John"},
        [],
    )

    content = b''

    with pytest.raises(ParseError) as excinfo:
        validate_json(content, UserSchema())
    e = excinfo.value

    assert e.code == "no_content"
    assert e.text == "No content."
    assert e.position == Position(column_no=1, line_no=1, char_index=0)

    content = b'{"name": "John"'


# Generated at 2022-06-22 06:28:15.592888
# Unit test for function validate_json

# Generated at 2022-06-22 06:28:25.817356
# Unit test for function validate_json
def test_validate_json():

    # Valid JSON string
    json_string = '{"first_name":"John","last_name":"Doe",' \
                  '"email":"john.doe@example.com"}'
    result = validate_json(json_string, None)
    print("Correct JSON string", json_string)
    print("Parsed value: ", result[0])
    print("Errors: ", result[1])
    print("\n")

    # Invalid JSON string (unquoted keys)
    json_string = '{first_name:"John","last_name":"Doe",' \
                  '"email":"john.doe@example.com"}'
    result = validate_json(json_string, None)
    print("Invalid JSON string", json_string)
    print("Parsed value: ", result[0])