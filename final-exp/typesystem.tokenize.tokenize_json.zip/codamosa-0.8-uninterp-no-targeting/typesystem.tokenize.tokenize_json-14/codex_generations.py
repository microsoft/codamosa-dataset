

# Generated at 2022-06-22 06:18:58.983896
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function.
    """
    import json

    # Test Parse Error.
    content = '{"name":"John", "age": "30", "city": "New York"}'
    validator = Schema(
        name=Field(required=True),
        age=Field(type=int, required=True),
        city=Field(),
    )
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].text == 'Could not parse JSON.'
    assert error_messages[0].code == 'parse_error'
    assert error_messages[0].position.char_index == 9
    assert error_messages[0].position.column_no == 10

# Generated at 2022-06-22 06:19:08.913384
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"user": {"age": "12", "device": "ipad"}}'
    result = tokenize_json(content)
    assert(isinstance(result, DictToken))
    assert(isinstance(result.content['user'], DictToken))
    assert(isinstance(result.content['user'].content['age'], ScalarToken))
    assert(result.content['user'].content['age'].content == '12')
    assert(result.content['user'].content['device'].content == 'ipad')

    # empty string
    result = tokenize_json('')
    assert(result is None)



# Generated at 2022-06-22 06:19:20.555663
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("100") == ScalarToken(100, 0, 2, "100")
    assert tokenize_json("[100]") == ListToken([ScalarToken(100, 1, 3, "100")], 0, 4, "[100]")
    assert tokenize_json("[100, 200]") == ListToken([ScalarToken(100, 1, 3, "100"), ScalarToken(200, 5, 7, "200")], 0, 8, "[100, 200]")

# Generated at 2022-06-22 06:19:21.440745
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    return True


# Generated at 2022-06-22 06:19:23.884011
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    assert(isinstance(decoder, JSONDecoder))


# Generated at 2022-06-22 06:19:35.281708
# Unit test for function tokenize_json
def test_tokenize_json(): 
    assert isinstance(tokenize_json(b''), Token) == True
    assert isinstance(tokenize_json('{"foo": "bar"}'), Token) == True
    assert isinstance(tokenize_json(''), Token) == True
    assert tokenize_json('{ "foo": "bar" }') == { "foo": "bar" }
    assert tokenize_json('{ "foo": "bar", "moo": "mar" }') == { "foo": "bar", "moo": "mar" }
    assert tokenize_json('{ "foo": [1,2,3] }') == { "foo": [1,2,3] }

# Generated at 2022-06-22 06:19:40.647238
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type_name="string")
    value, errors = validate_json('{"hello":"world"}', validator)
    assert errors is not None
    value, errors = validate_json('"hello"', validator)
    assert type(value) == str

# Generated at 2022-06-22 06:19:41.718249
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decode()
    assert True

# Generated at 2022-06-22 06:19:46.693670
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo":{"foo": {"bar": 123}}}'
    token = tokenize_json(content)
    assert token == DictToken({'foo': DictToken({'foo': DictToken({'bar': ScalarToken(123, 32, 35, content)})})}, 0, 36, content)



# Generated at 2022-06-22 06:19:52.515503
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    validator = Field(name="test")
    content = '{"test": 1}'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)

# Generated at 2022-06-22 06:20:03.820820
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingJSONObject(("abc", 0), True, scan_once, memo, "abc")
 

# Generated at 2022-06-22 06:20:11.792015
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "items": [
            {
                "name": "ham",
                "price": 10,
                "quantity": 1
            },
            {
                "name": "eggs",
                "price": 20,
                "quantity": 1
            },
            {
                "name": "spam",
                "price": 30,
                "quantity": 1
            }
        ],
        "tax": "10%",
        "total": 60,
        "shipping": "Type of shipping"
    }"""
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-22 06:20:23.619955
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Integer, String

    class Person(Schema):
        age = Integer()
        name = String()

    errors: typing.List[Message] = []
    data, errors = validate_json(b'{"age":12, "name": "bob"}', Person)
    assert len(errors) == 0
    assert data == {"age": 12, "name": "bob"}

    data, errors = validate_json(b'{"age":12, "name": false, "last": "jones"}', Person)
    assert len(errors) == 2
    assert errors[0].text == "Invalid value."
    assert errors[0].code == "invalid"
    assert errors[1].text == "Unexpected key."
    assert errors[1].code == "unexpected_key"

# Generated at 2022-06-22 06:20:27.861356
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_file = open('test_data/validate_json_input.json', 'r')
    content = json_file.read()
    decoder = _TokenizingDecoder(content=content)
    json_file.close()
    assert content == decoder.content


# Generated at 2022-06-22 06:20:37.813649
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:20:40.027611
# Unit test for function tokenize_json
def test_tokenize_json():
    # This is a function to test the function tokenize_json.
    import doctest
    doctest.testmod()


test_tokenize_json()

# Generated at 2022-06-22 06:20:42.682187
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "matt"}'
    field = Field(key="name")
    assert validate_json(content, field) == ("matt", [])




# Generated at 2022-06-22 06:20:51.300882
# Unit test for function tokenize_json
def test_tokenize_json():
    # json_str = '{"name": "AAAA"}'
    json_str = '{"name": "A"}'
    # json_str = '{"name": "A"}}}}}}}}}}}}}}}}}}}}}'
    # json_str = '{"name": "A"}}}'
    json_str = json_str.strip()
    token = tokenize_json(json_str)
    assert type(token) == DictToken
    assert token.value == {'name': 'A'}
    assert token.start == 0
    assert token.end == len(json_str)


# Generated at 2022-06-22 06:21:02.003014
# Unit test for function validate_json
def test_validate_json():
    from marshmallow import fields
    from typesystem.fields import String

    # Test for two cases - an example of a type mismatch and invalid data.
    # Both cases should return errors.
    with open("tests/example.json") as in_file:
        content = in_file.read()
    error_list, _ = validate_json(
        content=content, validator=fields.Integer(name="integer")
    )
    assert len(error_list) == 1
    assert error_list[0].text == 'Expected type "integer" but got type "string".'

    error_list, _ = validate_json(content=content, validator=String(name="integer"))
    assert len(error_list) == 1
    assert error_list[0].text == "Must be a string."

# Generated at 2022-06-22 06:21:11.158121
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": "b"}'
    validator = Schema({"a": True})
    result = validate_json(content, validator)
    assert result == ({'a': 'b'}, None)

    content = '{"a": "b"'
    validator = Schema({"a": True})
    result = validate_json(content, validator)
    assert result == ({'a': 'b'}, [Message('Incomplete JSON structure', {'type': 'error', 'code': 'parse_error'}, 140, 7)])

    content = '{"a": "b"}'
    validator = Schema({"a": False})
    result = validate_json(content, validator)

# Generated at 2022-06-22 06:21:27.691277
# Unit test for function validate_json
def test_validate_json():
    # Test for successful validation
    token, errors = validate_json(content=b"10", validator=int)
    assert not errors
    assert token == 10

    token, errors = validate_json(content=b'10', validator=int)
    assert not errors
    assert token == 10

    token, errors = validate_json(content=b'{"key": 10}', validator={"key": int})  # type: ignore
    assert not errors
    assert token == {"key": 10}

    # Test for failure of validation

    # Test for invalid type
    token, errors = validate_json(content=b'10', validator={"key": int})  # type: ignore
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 1
    assert errors[0].position

# Generated at 2022-06-22 06:21:31.428593
# Unit test for function validate_json
def test_validate_json():
    simple_schema = Schema(
        fields={'name': Field(type='string', required=True)})
    content = '{"name": "clem"}'
    value, errors = validate_json(content, simple_schema)
    assert value == {'name': 'clem'}
    assert len(errors) == 0
    return

# Generated at 2022-06-22 06:21:40.105114
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function
    """
    from typesystem.schemas import Schema, fields

    class ValidatorSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    error_messages, value = validate_json(
        content=b'{"name": "test", "age": "test"}',
        validator=ValidatorSchema(),
    )
    assert (
        error_messages == [
            ValidationError(
                text="Not a valid integer.",
                code="invalid_type",
                position=Position(column_no=7, line_no=1, char_index=6,),
            )
        ]
    )

# Generated at 2022-06-22 06:21:50.233992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "array": [1,2,3],
        "object": {"x": "y"},
        "string": "hello",
        "float": 3.14,
        "boolean": true,
        "null": null
    }
    """

    result = tokenize_json(content)
    assert isinstance(result, Token)
    assert isinstance(result, DictToken)

    array_token = result.value["array"]
    assert isinstance(array_token, ListToken)
    assert [t.value for t in array_token.value] == [1, 2, 3]

    obj_token = result.value["object"]
    assert isinstance(obj_token, DictToken)
    assert isinstance(obj_token.value["x"], ScalarToken)
    assert obj_token

# Generated at 2022-06-22 06:21:58.198036
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''\
    [
        "a",
        "b",
        "c"
    ]
    '''
    token = tokenize_json(content)
    assert token.position == Position(
        column_no=1, line_no=1, char_index=0
    ), "Wrong starting position"
    assert token.end_position == Position(
        column_no=5, line_no=9, char_index=29
    ), "Wrong ending position"
    assert len(token.value) == 3, "Wrong number of list values"
    assert repr(token.value[0].value) == "'a'"

    content = '''\
    {
        "a": "b"
    }
    '''
    token = tokenize_json(content)
    assert token.position == Position

# Generated at 2022-06-22 06:21:59.503345
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(object_hook=lambda x: x)


# Generated at 2022-06-22 06:22:07.009061
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(type='object', properties={
        'name': {'type': 'string'},
        'coordinates': {'type': 'array', items: {'type': 'number'}},
        'age': {'type': 'integer'}
    })
    content = '''{
        "name": "John Doe",
        "coordinates": [0, 0],
        "age": 28
    }'''
    errors = validate_json(content, schema)
    assert errors is None



# Generated at 2022-06-22 06:22:09.661969
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"foo": "bar"}')
    assert token.children[0][0].start == 2
    assert token.children[0][1].start == 10

# Generated at 2022-06-22 06:22:18.232884
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")



# Generated at 2022-06-22 06:22:25.536966
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class _Person(Schema):
        name = CharField()
        age = IntegerField()
        birthday = DateField()
    j = '''{"name": "John Doe", "age": 42, "birthday": "2019-09-15"}'''
    c = _Person(j)
    token = tokenize_json(j)
    c = _Person(token)
    decoder = _TokenizingDecoder(content = j)
    assert callable(decoder.scan_once)==True


# Generated at 2022-06-22 06:22:34.237497
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"test": "content"}'
    result = tokenize_json(content)
    assert result.raw == content
    assert result.positions["test"].line_no == 1
    assert result.positions["test"].column_no == 1
    assert result.positions["test"].char_index == 0
    assert result.positions["content"].line_no == 1
    assert result.positions["content"].column_no == 11
    assert result.positions["content"].char_index == 10



# Generated at 2022-06-22 06:22:37.305220
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = {}
    with pytest.raises(TypeError):
        _TokenizingDecoder(content)


# Generated at 2022-06-22 06:22:46.751624
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "mother": {
    "name": "Jane",
    "age": 35
  },
  "father": {
    "name": "Bob",
    "age": 36
  },
  "children": [
    {
      "name": "Jimmy"
    },
    {
      "name": "Wendy"
    }
  ],
  "pets": null
}
"""

# Generated at 2022-06-22 06:22:51.982617
# Unit test for function tokenize_json
def test_tokenize_json():
    data = "{'key1': 'value1', 'key2': 'value2'}"
    token = tokenize_json(data)
    assert token == DictToken(
        {
            ScalarToken("key1", 2, 7, data): ScalarToken("value1", 10, 17, data),
            ScalarToken("key2", 20, 25, data): ScalarToken("value2", 28, 35, data),
        },
        0,
        35,
        data,
    )



# Generated at 2022-06-22 06:22:56.485925
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert isinstance(decoder, JSONDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-22 06:23:00.708620
# Unit test for function validate_json
def test_validate_json():
    json = b'{"name": "John", "age": 30}'
    json = json.decode("utf-8")
    schema = Schema([
        Field(name="name", type="string"),
        Field(name="age", type="number")
    ])
    errors = validate_json(json, schema)
    assert errors.errors == []
    json = b'{"name": "John", "age": abc}'
    json = json.decode("utf-8")
    schema = Schema([
        Field(name="name", type="string"),
        Field(name="age", type="number")
    ])
    errors = validate_json(json, schema)

# Generated at 2022-06-22 06:23:05.622338
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    assert tokenize_json(json.dumps({"foo": "bar"})) == {'foo': 'bar'}
    assert (tokenize_json(json.dumps([{"foo": "bar"}, {"baz": "qux"}])) ==
            [{'foo': 'bar'}, {'baz': 'qux'}])
    

# Generated at 2022-06-22 06:23:17.585737
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON, returning a value
    assert validate_json(b'{"price": "100"}', Field(type="number")) == (
        100,
        None,
    )
    assert validate_json(
        b'{"price": "100", "name": "My Product"}',
        Schema({"name": Field(type="string"), "price": Field(type="number")}),
    ) == ({"name": "My Product", "price": 100}, None)
    # Test invalid JSON
    with pytest.raises(ParseError) as e:
        validate_json(b'{"price": 100, "name": "My Product"}', Field(type="boolean"))
    assert e.value.code == "parse_error"
    # Test valid JSON, returning invalid value

# Generated at 2022-06-22 06:23:21.964114
# Unit test for function tokenize_json
def test_tokenize_json():
    tok = tokenize_json('[{"a":1}]')
    assert isinstance(tok, ListToken)
    assert len(tok.value[0]) == 1
    assert isinstance(tok.value[0], DictToken)
    assert tok.value[0].value["a"].value == 1



# Generated at 2022-06-22 06:23:24.841487
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, JSONDecoder)


# Unit tests for method _make_scanner


# Generated at 2022-06-22 06:23:32.665019
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "hello", "b": "goodbye"}'
    result = tokenize_json(content)
    dict_result = dict(result)
    assert dict_result["a"] == "hello"
    assert dict_result["b"] == "goodbye"
    
    

# Generated at 2022-06-22 06:23:44.431241
# Unit test for function tokenize_json
def test_tokenize_json():
    content = json.dumps({"a": "b"})
    assert tokenize_json(content) == {"a": "b"}
    assert tokenize_json('"abc"') == "abc"
    assert tokenize_json("42") == 42
    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("[1, 2]") == [1, 2]
    assert tokenize_json("[]") == []
    assert tokenize_json("[{}]") == [{}]
    assert tokenize_json("{}") == {}
    assert tokenize_json('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert tokenize_

# Generated at 2022-06-22 06:23:49.106322
# Unit test for function tokenize_json
def test_tokenize_json():
    # Given
    content = '{"id": "9b0c5817-8d42-43e1-b09f-e12c4bb4ce4f", "name": "Bertram"}'
    # When
    token = tokenize_json(content)
    # Then
    assert repr(token) == "<DictToken at L1:C1-L3:C20>"



# Generated at 2022-06-22 06:23:56.060877
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": "str", "b": 1, "c": "3"}'
    validator = Field()
    _, error_messages = validate_json(content, validator)
    assert error_messages == []
    content = '{"a": "str", "b": 1, "c": "3'
    _, error_messages = validate_json(content, validator)
    assert isinstance(error_messages[0], ParseError)

# Generated at 2022-06-22 06:24:03.336878
# Unit test for function validate_json
def test_validate_json():
    validator = Field(required=True, type="string")
    assert validate_json("abba", validator) == ("abba", None)
    assert validate_json("\t \n", validator) == ("\t \n", [
        ValidationError(
            message=Message(code="required", text="This field is required."),
            position=Position(line_no=1, column_no=1, char_index=1),
        )
    ])

# Generated at 2022-06-22 06:24:15.583273
# Unit test for function tokenize_json
def test_tokenize_json():
    def make_positional_error(**kwargs: typing.Any) -> ValidationError:
        return ValidationError(
            code="type",
            text="Invalid value.",
            position=Position(**kwargs),
        )

    assert tokenize_json("""{
        "age": 28,
        "name": "John Doe",
        "address": {
            "street": "123 House St",
            "city": "Denver",
            "state": "CO",
            "zipcode": 80023
        }
    }""") == {
        'age': 28,
        'name': "John Doe",
        'address': {
            'street': "123 House St",
            'city': "Denver",
            'state': "CO",
            'zipcode': 80023,
        },
    }


# Generated at 2022-06-22 06:24:26.388793
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"age": 44}') == DictToken({
        "age": ScalarToken(44, 4, 5, '{"age": 44}')
    }, 3, 6, '{"age": 44}')

# Generated at 2022-06-22 06:24:32.422684
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"one": 1, "two": 2}'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.scan_once(content, 0)
    assert isinstance(token, tuple)
    assert isinstance(token[0], DictToken)
    assert isinstance(token[1], int)

# Generated at 2022-06-22 06:24:44.179726
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # An uninstantiated object must be returned if initialisation with an 
    # empty/None content argument is attempted
    assert _TokenizingDecoder(content = "") is None, \
        "An uninstantiated object should be returned if initialisation with an empty/None content argument."
    
    # An object with properties scanner, scan_once and parse_string must be
    # returned if initialisation with a string argument is attempted
    assert type(_TokenizingDecoder(content = "content")) == _TokenizingDecoder, \
        "An object of class _TokenizingDecoder should be returned if initialisation with a string argument is attempted."
    assert hasattr(_TokenizingDecoder(content = "content"), "scanner"), \
        "An object of class _TokenizingDecoder should have a scanner property."

# Generated at 2022-06-22 06:24:51.362701
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

# Generated at 2022-06-22 06:25:05.704272
# Unit test for function tokenize_json
def test_tokenize_json():
    input_str = """
    {
        "name": "Bobby Tables",
        "email": "bobbytables@example.com",
        "age": 25,
        "is_active": true
    }
    """

    expected_tokens = [
        DictToken(
            {"name": ScalarToken("Bobby Tables", 11, 25, input_str),
             "email": ScalarToken("bobbytables@example.com", 30, 53, input_str),
             "age": ScalarToken(25, 58, 60, input_str),
             "is_active": ScalarToken(True, 66, 73, input_str)},
            0,
            78,
            input_str
        )
    ]

    tokens = tokenize_json(input_str)
    assert tokens == expected_tok

# Generated at 2022-06-22 06:25:08.807204
# Unit test for function tokenize_json
def test_tokenize_json():
    tree = tokenize_json('{"foo": "bar"}')
    assert tree.key == "foo"
    assert tree.value == "bar"


# Generated at 2022-06-22 06:25:19.339289
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":1, "b":[1,2,3]}')
    assert isinstance(token, DictToken)
    assert len(token) == 2
    assert token.get("a").value == 1
    assert token.get("b").value == [1, 2, 3]

    token = tokenize_json('{"b":[1,2,3]}')
    assert token.get("b").value == [1, 2, 3]

    token = tokenize_json('{"b":{"a":1}}')
    assert token.get("b").get("a").value == 1

    token = tokenize_json('{"b":[{"a":1}]}')
    assert token.get("b").value[0].get("a").value == 1


# Generated at 2022-06-22 06:25:22.868828
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content="hello world"
    decoder=_TokenizingDecoder(content=content)
    assert(decoder.scan_once("hello world", 0))
    assert(not decoder.scan_once("hello world", 1))

# Generated at 2022-06-22 06:25:35.165491
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({
        "name": str,
        "age": int,
        "friends": [{
            "name": str,
        }],
    })
    payload = {
        "name": "john",
        "age": 31,
        "friends": [
            {"name": "alice", "age": 34},
            {"name": "bob"},
        ],
    }
    expected_response = {
        "friends": {
            1: {
                "age": {
                    "__all__": [
                        "Unknown field."
                    ]
                }
            }
        }
    }

# Generated at 2022-06-22 06:25:48.036505
# Unit test for function tokenize_json

# Generated at 2022-06-22 06:25:52.529218
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder('{"k": "v"}')
    assert(decoder.parse_int == int)
    assert(decoder.parse_float == float)


# Generated at 2022-06-22 06:26:04.505185
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    # Create a schema
    class ContactSchema(Schema):
        name = String(max_length=100)
        email = String(max_length=100)
    validator = ContactSchema()

    # Valid JSON
    json_text = '{"name": "Lorem", "email": "ipsum@dolor.com"}'
    value, error_messages = validate_json(json_text, validator)
    assert not error_messages
    assert value == {"name": "Lorem", "email": "ipsum@dolor.com"}

    # Invalid JSON
    json_text = '{"name": "Lorem", "email": "ipsum@dolor.com"'

# Generated at 2022-06-22 06:26:05.568778
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder()



# Generated at 2022-06-22 06:26:12.670650
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"test": [1, 2, 3]}') == DictToken(
        {"test": ListToken([1, 2, 3])}, 0, 17, '{"test": [1, 2, 3]}'
    )
    assert_raises(ParseError, tokenize_json, "{")



# Generated at 2022-06-22 06:26:20.151944
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"foo": [1, 2, 3]}', {'foo': [int]}) == (
        {'foo': [1, 2, 3]},
        [],
    )
    class TestSchema(Schema):
        foo = 'foo'
        bar = 'bar'

    assert validate_json(
        b'{"foo": [1, 2, 3], "bar": [1, 2, 3]}', TestSchema
    ) == ({'foo': [1, 2, 3], 'bar': [1, 2, 3]}, [])

    _, error_messages = validate_json(
        b'{"foo": [1, 2, 3], "bar": [1, 2, 3]}',
        TestSchema(required=['bar']),
    )

# Generated at 2022-06-22 06:26:26.462938
# Unit test for function validate_json
def test_validate_json():
    from typesystem.errors import ErrorMessage
    from typesystem.fields import String
    from typesystem.schemas import Schema

    content = '{ "name": "tom" }'
    name = String()

    class UserSchema(Schema):
        name = name
        age = String()

    res, err = validate_json(content, UserSchema)
    assert res == {"name": "tom"}
    assert isinstance(err, ErrorMessage)

# Generated at 2022-06-22 06:26:28.307616
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(), JSONDecoder)


# Generated at 2022-06-22 06:26:29.411179
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # TODO
    pass


# Generated at 2022-06-22 06:26:41.869644
# Unit test for function validate_json

# Generated at 2022-06-22 06:26:48.493547
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = Field(String)
        age = Field(Integer)
        sex = Field(String, enum=["Male", "Female", "Unknown"])

    input_json = b'{"name":"Tushar","age":32,"sex":"Male"}'
    value, errors = validate_json(input_json, Person)
    if errors:
        raise ValidationError(errors=errors)
    assert value == {"name": "Tushar", "age": 32, "sex": "Male"}



# Generated at 2022-06-22 06:26:49.587758
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
	pass


# Generated at 2022-06-22 06:26:53.159455
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '"hello"'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0) == (ScalarToken('hello', 0, 6, content), 7)

# Generated at 2022-06-22 06:26:54.801735
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None


# Generated at 2022-06-22 06:26:57.873527
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test constructor with 2 arguments
    decoder = _TokenizingDecoder(False, content='')
    assert type(decoder) == _TokenizingDecoder


# Generated at 2022-06-22 06:27:02.468842
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    This test case tests whether the constructor of _TokenizingDecoder is
    working as expected.
    """
    assert True



# Generated at 2022-06-22 06:27:10.266251
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer, Float, Boolean
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()
        weight = Float()
        is_admin = Boolean()

    content = '{"name": "Tony", "age": 21, "weight": 175.5, "is_admin": "true"}'

    val, errors = validate_json(content, Person)

    assert val == {
        "name": "Tony",
        "age": 21,
        "weight": 175.5,
        "is_admin": True,
    }, "values are not equal"
    assert len(errors) == 0, "errors is not empty"



# Generated at 2022-06-22 06:27:15.787838
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder(content="")
    class_name = context.__class__
    try:
        assert class_name.__name__ == "TokenizingDecoder"
    except AssertionError:
        raise AssertionError(f"{class_name.__name__} != TokenizingDecoder")
    return True


# Generated at 2022-06-22 06:27:25.945677
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # We expect the _TokenizingDecoder constructor to call _make_scanner with
    # the same arguments that are passed to _TokenizingDecoder, plus an
    # additional arguments "content", which represents the content argument to
    # _TokenizingDecoder.
    content = '{"test":12}'
    strict = True
    parse_array = JSONDecoder.parse_array
    parse_float = JSONDecoder.parse_float
    parse_int = JSONDecoder.parse_int
    parse_string = JSONDecoder.parse_string
    memo = dict()
    expected_mock_args = (content, strict, parse_array, parse_float, parse_int, parse_string, 
        memo)
    # Mock _make_scanner so we can check that it was called correctly

# Generated at 2022-06-22 06:27:35.755589
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": [1, 2, 3]}'
    token = tokenize_json(content)
    # After parsing, we expect the content to have been parsed into a
    # DictToken containing a ScalarToken with a string value and a ListToken
    # containing three ScalarTokens with int values.
    assert isinstance(token, DictToken)
    assert isinstance(token.value["key"], ListToken)
    assert token.value["key"].value[0].value == 1
    # We also expect the content to be available at the first position.
    assert token.value["key"].value[0].content == content
    # We should have the original content in each of the tokens.
    assert token.value["key"].value[1].content == content
    assert token.value["key"].value[2].content == content

# Generated at 2022-06-22 06:27:40.830856
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_string = '{"a":1, "b":2}'
    content = json_string
    args = ()
    kwargs = {"content": content}
    decoder = _TokenizingDecoder(*args, **kwargs)
    return decoder


# Generated at 2022-06-22 06:27:43.807909
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(0, '', '', '', '', '', '')
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-22 06:27:53.713558
# Unit test for function validate_json
def test_validate_json():
    import json
    import typesystem
    from typesystem.schemas import Schema

    schema = typesystem.Schema(
        title="test_schema",
        properties=[
            typesystem.String(name="test_key", max_length=5),
            typesystem.Array(items=typesystem.Integer()),
        ],
    )

    # test valid case
    valid_content = '{"test_key": "good", "test_key2": [1,2,3]}'
    value, messages = validate_json(valid_content, schema)
    assert len(messages) == 0
    assert value == json.loads(valid_content)

    # test invalid case
    invalid_content = '{"test_key": "badddd", "test_key2": ["a",2,3]}'
    value, messages

# Generated at 2022-06-22 06:28:04.928405
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{}') == DictToken({}, 0, 1, "{}")

    assert tokenize_json(b'[]') == ListToken([], 0, 1, "[]")

    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 4, '"foo"')

    assert tokenize_json(b'1.0') == ScalarToken(1.0, 0, 3, "1.0")

    assert tokenize_json(b'-1.0') == ScalarToken(-1.0, 0, 4, "-1.0")

    assert tokenize_json(b'true') == ScalarToken(True, 0, 4, "true")

    assert tokenize_json(b'false') == ScalarToken(False, 0, 5, "false")

    assert tokenize

# Generated at 2022-06-22 06:28:06.078592
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")



# Generated at 2022-06-22 06:28:10.916300
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"key": "value"}') == {'key': 'value'}
    assert tokenize_json(b'{"key": "value"}') == {'key': 'value'}
    assert tokenize_json('{"key": "value"}') == {'key': 'value'}


# Generated at 2022-06-22 06:28:18.972999
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo" : "bar", "baz" : "quux"}')
    dict_token = token
    assert dict_token.__class__ == DictToken
    assert dict_token.start_pos == (1,1)
    assert dict_token.end_pos == (2,21)
    assert dict_token.value['foo'] == 'bar'
    assert dict_token.value['baz'] == 'quux'
    print(dict_token.value)