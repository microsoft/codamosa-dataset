

# Generated at 2022-06-22 06:18:58.961333
# Unit test for function tokenize_json
def test_tokenize_json():
    if not isinstance(tokenize_json(""), Token):
        raise AssertionError()
    if isinstance(tokenize_json("{}"), Token):
        raise AssertionError()
    if isinstance(tokenize_json("{}")(ScalarToken(1)), ScalarToken):
        raise AssertionError()
    if isinstance(tokenize_json("{}"), ScalarToken):
        raise AssertionError()
    if isinstance(tokenize_json("{}"), ListToken):
        raise AssertionError()
    if not isinstance(tokenize_json("[]"), Token):
        raise AssertionError()
    if isinstance(tokenize_json("[]")(ScalarToken(1)), ScalarToken):
        raise AssertionError()

# Generated at 2022-06-22 06:19:04.604045
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":true,"b":false,"c":1,"d":"x","e":[],"f":{}}'
    decoder = _TokenizingDecoder(content=content)
    assert(isinstance(decoder, JSONDecoder))
    assert(isinstance(decoder.scan_once, typing.Callable))


# Generated at 2022-06-22 06:19:15.440687
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that tokenize_json works as expected
    """
    # Test with various inputs
    content = '{"name": "Eden", "age": 17}'
    tokenizer = tokenize_json(content)
    assert tokenizer.type == 'dict'
    assert tokenizer.value == {'name': 'Eden', 'age': 17}

    content = '[{"name": "Eden", "age": 17}, {"name": "Sage", "age": 18}]'
    tokenizer = tokenize_json(content)
    assert tokenizer.type == 'list'
    assert tokenizer.value == [
        {'name': 'Eden', 'age': 17},
        {'name': 'Sage', 'age': 18}
    ]


# Generated at 2022-06-22 06:19:22.886975
# Unit test for function tokenize_json
def test_tokenize_json():
    # test tokenize_json on string
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content="{}")

    # test tokenize_json on bytes
    assert tokenize_json(b"{}") == DictToken(value={}, start=0, end=1, content="{}")

    # test tokenize_json on empty string
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")



# Generated at 2022-06-22 06:19:23.468709
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass

# Generated at 2022-06-22 06:19:31.873626
# Unit test for function validate_json
def test_validate_json():

    from typesystem.primitives import String, Integer

    class MySchema(Schema):
        name = String()
        age = Integer()

    assert validate_json('{"name": "Aaron", "age": 100}', MySchema) == (
        {"name": "Aaron", "age": 100},
        [],
    )

    assert (
        validate_json('{"name": "Aaron", "age": "100"}', MySchema)
        == (None, [ValidationError(text='Expected int.', code='invalid', path=["age"])])
    )

# Generated at 2022-06-22 06:19:33.844017
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder("", content = "")

# Unit tests for private function _make_scanner

# Generated at 2022-06-22 06:19:34.643020
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder("{}", content="1"), _TokenizingDecoder)


# Generated at 2022-06-22 06:19:45.530768
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{"expires_in":36000,"token_type":"Bearer","access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"}'
    content = "text"
    decoder = _TokenizingDecoder(content=content)
    scan_once = _make_scanner(decoder, content)

# Generated at 2022-06-22 06:19:49.310739
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
	# Positive test 1 - test with any kind of content and give result as expected with no error
    try:
        _TokenizingDecoder(content='content')
    except Exception:
    	assert False
    else:
    	assert True


# Generated at 2022-06-22 06:20:09.434810
# Unit test for function tokenize_json
def test_tokenize_json():
    value, _ = validate_json(b'{"name": "John"}', type("User", (Schema,), {"name": str}))
    assert value == {"name": "John"}

    try:
        validate_json(b'{"name": "John"}', type("User", (Schema,), {"name": float}))
        raise AssertionError("Unexpected success")
    except ValidationError as exc:
        message = exc.messages[0]
        assert message.position.line_no == 1
        assert message.position.column_no == 10
        assert message.position.char_index == 9
        assert message.text == "Must be a float."
        assert message.code == "type_error.float"


# Generated at 2022-06-22 06:20:14.096025
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{}')
    assert decoder is not None


# Generated at 2022-06-22 06:20:19.242403
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": [{"b": "21"}, {"d": 22}]}'
    validator = {
        "a": [
            {"b": "integer"},
            {"c": "string", "optional": True},
            {"d": "integer"},
        ]
    }
    value, error_messages = validate_json(content, validator)
    assert error_messages == []
    assert value == {"a": [{"b": 21}, {"d": 22}]}



# Generated at 2022-06-22 06:20:31.614974
# Unit test for function validate_json
def test_validate_json():
    content = '{"id": 1, "foo": "bar"}'
    validator = Field(name = "foo", type=str)
    try:
        validate_json(content, validator)
        assert False
    except ValidationError as e:
        pass

    content = '{"id": 1, "foo": "bar"}'
    validator = Field(name = "foo", type=str)
    try:
        validate_json(content, validator)
        assert False
    except ValidationError as e:
        message = e.error_messages[0]
        assert message.position.line_no == 1
        assert message.position.column_no == 2

    content = ""
    validator = Field(name = "foo", type=str)

# Generated at 2022-06-22 06:20:41.240640
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test tokenize_json.  This is a white-box test that tests the path of the
    # tokenizer where the JSON is valid.
    #
    # We validate the output of tokenize_json by comparing it to the output of
    # json.loads.  We do not use json.loads directly to validate the input
    # because json.loads is broken and will not detect some errors (see
    # https://github.com/python/cpython/blob/3.6/Lib/json/decoder.py#L334
    # for an example).
    from json import loads as json_loads
    import random

    def get_int():
        return random.randrange(0, 100)

    def get_string():
        length = get_int()

# Generated at 2022-06-22 06:20:52.421437
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{ \"string\": \"hello\", \"number\": 42 }") == {
        "string": "hello",
        "number": 42,
    }
    assert tokenize_json("{\"string\":\"hello\",\"number\":42}") == {
        "string": "hello",
        "number": 42,
    }
    assert tokenize_json("  {  \"string\":  \"hello\",  \"number\":  42  }  ") == {
        "string": "hello",
        "number": 42,
    }
    assert tokenize_json("{}") == {}
    assert tokenize_json("[]") == []
    assert tokenize_json("[1]") == [1]
    assert tokenize_json("[1, 2]") == [1, 2]

# Generated at 2022-06-22 06:20:56.020101
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"name": "Django", "age": 30}'
    token = tokenize_json(json_string)
    assert token.value == {"name": "Django", "age": 30}


# Generated at 2022-06-22 06:20:59.576769
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":1}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once('"a"', 0) == ('a', 3)



# Generated at 2022-06-22 06:21:10.360580
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    {
        "foo": [
            [
                {"a": 1, "b": 2},
                {"c": 3, "d": 4}
            ]
        ],
        "bar": [5,6,7,8]
    }
    """
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["bar"], ListToken)
    assert isinstance(token.value["foo"].value[0], ListToken)
    assert isinstance(token.value["foo"].value[0].value[0], DictToken)
    assert token.value["foo"].value[0].value[0].value["b"] == ScalarToken(2, 23, 26, json_string)



# Generated at 2022-06-22 06:21:16.926153
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    import marshmallow
    
    def get_messages(value, type_):
        schema = typesystem.Schema(fields={"value": type_("value")})
        return validate_json(value, schema)
    
    assert get_messages(b'{"value":1}', typesystem.Integer) == (({"value": 1}, []))
    assert get_messages(b'{"value":1}', typesystem.String) == (({"value": "1"}, []))
    
    assert get_messages(b'{"value":1}', marshmallow.fields.Integer) == (({"value": 1}, []))
    assert get_messages(b'{"value":1}', marshmallow.fields.String) == (({"value": "1"}, []))

# Generated at 2022-06-22 06:21:31.912445
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    >>> tokenize_json('{"some_string": "string123", "some_int": 123, "some_bool": true, "some_null": null, "some_float": 2.5, "some_dict": {"some_key": "some_value"}, "some_list": ["item1", "item2", "item3"]}')
    {
      "some_bool": True,
      "some_dict": {
        "some_key": "some_value"
      },
      "some_float": 2.5,
      "some_int": 123,
      "some_list": [
        "item1",
        "item2",
        "item3"
      ],
      "some_null": null,
      "some_string": "string123"
    }
    """
    raise NotImple

# Generated at 2022-06-22 06:21:34.521124
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"name": "John Doe", "age": 42}') == {
        "name": "John Doe",
        "age": 42
    }



# Generated at 2022-06-22 06:21:39.028719
# Unit test for function tokenize_json
def test_tokenize_json():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder.decode('"hello"'), ScalarToken)
    assert isinstance(decoder.decode('{"a": "hello"}'), DictToken)
    assert isinstance(decoder.decode('["hello"]'), ListToken)


# Generated at 2022-06-22 06:21:41.415811
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(JSONDecoder(), content="Test")
    print(decoder.scan_once("Test", 0))


# Generated at 2022-06-22 06:21:52.600993
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    import glob
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), "test"))

    for filename in glob.glob("./test/test_json/*.json"):
        with open(filename, encoding="utf-8") as f:
            content = f.read()
            json_data = json.loads(content)
            token = tokenize_json(content)
            assert token.data == json_data

    # Empty JSON string
    content = ""
    try:
        token = tokenize_json(content)
    except ParseError as exc:
        # Handle cases that result in a JSON parse error.
        assert exc.code == "no_content"

# Generated at 2022-06-22 06:21:53.441255
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()



# Generated at 2022-06-22 06:22:03.291380
# Unit test for function validate_json
def test_validate_json():

    # Testing with Field
    field = Field(name="a", type="string")
    assert validate_json(b'', field) == (
        None,
        [
            Message(code="missing_value", text="Missing value.", pointer="/a")
        ],
    )

    assert validate_json(b'null', field) == (
        None,
        [
            Message(code="type_mismatch", text="Type must be string.", pointer="/a")
        ],
    )

    assert validate_json(b'"a"', field) == (
        "a",
        [],
    )

    # Testing with Schema
    class SomeSchema(Schema):
        class Meta:
            strict = True

        a = Field(type="string")


# Generated at 2022-06-22 06:22:14.358202
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{"test": 1}'
    tokens = _TokenizingDecoder(
        parse_int=int, parse_float=float, content=json_str
    ).decode(json_str)
    assert tokens._children[0]._children[0].value == "test"
    assert tokens._children[0]._children[0].position.line_no == 1
    assert tokens._children[0]._children[0].position.column_no == 2
    assert tokens._children[0]._children[1].value == 1
    assert tokens._children[0]._children[1].position.line_no == 1
    assert tokens._children[0]._children[1].position.column_no == 8


# Unit tests for json_decode

# Generated at 2022-06-22 06:22:26.465064
# Unit test for function validate_json
def test_validate_json():
    # Structure of the validator Schema
    validator = {
        "name": "person",
        "type": "object",
        "fields": [
            {"name": "name", "type": "string", "required": True},
            {"name": "age", "type": "integer"},
        ],
    }
    # Json Input
    content = """
    {
     "name":"Tom",
     "age":"18"
    }"""
    json_input = content
    # Tokenize input Json
    token = tokenize_json(json_input)
    # Validate the tokenize json input with the validator Schema
    value, error_messages = validate_with_positions(token=token, validator=validator)
    assert error_messages[0]["code"] == "invalid_type"

# Generated at 2022-06-22 06:22:28.517458
# Unit test for function tokenize_json
def test_tokenize_json():
    assert type(tokenize_json('{"hello": "world", "here": true}')) == DictToken

# Generated at 2022-06-22 06:22:49.074739
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Number, Integer, Dict
    from typesystem import Boolean, Object, List, Any

    class StringSchema(Schema):
        field1 = String()
        field2 = String(min_length=1)

    class NumberSchema(Schema):
        field1 = Number()
        field2 = Number(max_value=1.0)

    class IntegerSchema(Schema):
        field1 = Integer()

    class BooleanSchema(Schema):
        field1 = Boolean()

    class ListSchema(Schema):
        field1 = List(String())

    class DictSchema(Schema):
        field1 = Dict(String())

    class AnySchema(Schema):
        field1 = Any()

    class Inner(Schema):
        foo = String()


# Generated at 2022-06-22 06:22:53.497478
# Unit test for function validate_json
def test_validate_json():
    from typing import Dict, Any
    from pprint import pprint

    validator = Dict[str, Any]
    res = validate_json({"foo": "bar"}, validator)
    pprint(res)  # output: ({'foo': 'bar'}, [])
    res = validate_json({"foo": "bar", "baz": False}, validator)
    pprint(res)  # output: ({'foo': 'bar', 'baz': False}, [])

# Generated at 2022-06-22 06:23:03.086511
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test invalid characters
    content = '[1, 2, 3, "asdf\x00asdf", 4]'
    decoder = _TokenizingDecoder(content=content)
    try:
        decoder.decode(content)
        assert False
    except JSONDecodeError as exc:
        assert (exc.msg == "Invalid control character at: line 1 column 17 (char 16)")

    # Test null character
    content = '[1, 2, 3, null, 4]'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    assert isinstance(token, ListToken)
    assert len(token.value) == 5
    assert token.value[0] == ScalarToken(1, 0, 0, content)

# Generated at 2022-06-22 06:23:14.917512
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"one": 1, "two": 2, "three": 3}'
    token = tokenize_json(json_string)

    assert token.key == "one"
    assert token.value == 1
    assert token.start_column_no == 3
    assert token.end_column_no == 5
    assert token.start_line_no == 1
    assert token.end_line_no == 1
    assert token.start_char_index == 3
    assert token.end_char_index == 5
    assert token.content == '{"one": 1, "two": 2, "three": 3}'
    assert token.type == "dict"

    token = token.value_as_token

    assert token.key == "two"
    assert token.value == 2

# Generated at 2022-06-22 06:23:26.653875
# Unit test for function tokenize_json
def test_tokenize_json():
    data = {
        "name": "John Doe",
        "email": "john@doe.com",
        "permissions": ["user", "superuser"],
        "date_joined": "2019-02-19T00:00:00Z",
        "settings": {
            "units": "english",
            "timezone": "UTC",
        },
    }

    token = tokenize_json(json.dumps(data))

    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(json.dumps(data)) - 1
    assert token.value == data

    name = token.value["name"]
    assert isinstance(name, ScalarToken)
    assert name.value == "John Doe"
    assert name.start == 10

# Generated at 2022-06-22 06:23:38.905096
# Unit test for function validate_json
def test_validate_json():
    # Create validator to validate each field. These are just
    # the built in typesystem validators, with the 'required'
    # keyword set to False for the object fields.
    validator1 = Field(type="integer", required=False)
    validator2 = Field(type="string", required=False)
    validator3 = Field(type="string", required=False)
    validator4 = Field(type="number", required=False)
    
    content = '''
        {
            "Test Integer": 123,
            "Test String": "Hello",
            "Null Field": null,
            "No Field":
        }
        '''
    
    token = tokenize_json(content)
    value, errors = validate_with_positions(token=token, validator=validator1)
    assert value == 123
   

# Generated at 2022-06-22 06:23:47.958484
# Unit test for function validate_json
def test_validate_json():

    content = """
    {
      "name": "Alice",
      "age": 20
    }
    """
    token = tokenize_json(content)
    error_messages = validate_with_positions(token=token, validator=PersonSchema)

    assert not error_messages

    content = """
    {
      "name": "Alice",
      "age": 20
      "gender": "female"
    }
    """
    token = tokenize_json(content)
    error_messages = validate_with_positions(token=token, validator=PersonSchema)

    assert len(error_messages) == 1
    assert error_messages[0].code == "invalid_field"
    assert error_messages[0].text == 'Failed to parse "gender".'
    assert error_

# Generated at 2022-06-22 06:23:55.525950
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Check that the function tokenize_json works correctly.
    """
    assert tokenize_json('{"key": "value"}') == tokenize_json(b'{"key": "value"}')
    content = b'{"key": "value"}'
    print(tokenize_json(content))
    print(tokenize_json(content.decode('utf-8')))
    print(tokenize_json(''))
    print(tokenize_json(b''))


# Generated at 2022-06-22 06:24:03.368080
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    obj = _TokenizingDecoder()
    assert 'strict' not in obj.__dict__
    assert obj.object_hook is not None
    assert obj.object_pairs_hook is not None
    assert obj.parse_float is not None
    assert obj.parse_int is not None
    assert obj.parse_constant is not None
    assert obj.scan_once is not None
    assert obj.Memo is not None
    # with strict set to true
    obj = _TokenizingDecoder(strict=True)
    assert obj.strict is True
    assert obj.object_hook is not None
    assert obj.object_pairs_hook is not None
    assert obj.parse_float is not None
    assert obj.parse_int is not None
    assert obj.parse_constant is not None

# Generated at 2022-06-22 06:24:15.583560
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import Field, Schema
    from typesystem.types import String
    from typesystem.tokenize.tokens import ListToken, DictToken, ScalarToken

    class References(Schema):
        references = ListToken(String)

    class Name(Schema):
        name = String()

    class Person(Schema):
        age = String(validators=["is_valid_age"])
        name = Name()
        parents = ListToken(Person)
        references = References()

    def is_valid_age(data: str, value: str) -> None:
        if not value.isdigit():
            raise ValidationError(
                "is_valid_age", message="Age must be a valid integer."
            )

# Generated at 2022-06-22 06:24:29.981920
# Unit test for function validate_json
def test_validate_json():
    field = Field.any_type(required=True)
    schema = Schema({"field": field})

    # A successful parse and validation.
    content = '"This is a string."'
    value, error_messages = validate_json(content, schema)
    assert value == "This is a string."
    assert not error_messages

    # An unsuccessful parse.
    content = '"This is a string.'
    with pytest.raises(ParseError) as exc_info:
        validate_json(content, schema)
    exc = exc_info.value
    assert exc.code == "parse_error"

    # An unsuccessful validation.
    field = Field.any_type(required=False)
    schema = Schema({"field": field})
    content = 'False'
    value, error_messages = validate

# Generated at 2022-06-22 06:24:35.544713
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"message":"hello"}'
    decoder = _TokenizingDecoder(content = content)
    assert(decoder.scan_once("{\"message\":\"hello\"}", 0) == (DictToken({'message': 'hello'}, 0, 22, '{"message":"hello"}'), 23))

# Generated at 2022-06-22 06:24:47.362434
# Unit test for function validate_json
def test_validate_json():
    content = """{"name": "Jane Doe", "age": 66}"""
    # usa_states = [
    #     "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
    #     "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
    #     "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
    #     "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
    #     "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",


# Generated at 2022-06-22 06:24:50.121310
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    example_json ='{ "key" : "value"}'
    example_decoder = _TokenizingDecoder(content=example_json)
    example_tokens = example_decoder.decode(example_json)

# Generated at 2022-06-22 06:25:01.702963
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "a", "b": "b"}')
    assert token.get('a') == ScalarToken('a', 3, 6, '{"a": "a", "b": "b"}')
    assert token.get('b') == ScalarToken('b', 13, 16, '{"a": "a", "b": "b"}')

    token = tokenize_json('{"a": 1, "b": 2}')
    assert token.get('a') == ScalarToken(1, 3, 5, '{"a": 1, "b": 2}')
    assert token.get('b') == ScalarToken(2, 11, 13, '{"a": 1, "b": 2}')

    token = tokenize_json('{"a": [1,2], "b": [3,4]}')

# Generated at 2022-06-22 06:25:06.397292
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.base import Context  # type: ignore
    from typesystem.json import JSONSchema  # type: ignore

    context = Context(JSONSchema({"name": "Field"}))
    JSONDecoder.__init__(context, "ignored", "content")

# Generated at 2022-06-22 06:25:08.174752
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")

# Generated at 2022-06-22 06:25:18.091799
# Unit test for function validate_json
def test_validate_json():
    '''
    Test for function validate_json
    '''
    from typesystem import String, Integer, Dict, Array, Boolean
    json = """{
        "c": 1,
        "items": [true, false],
        "a": "foo",
        "b": "bar"
    }"""
    validator = Dict(
        {"a": String, "b": String, "c": Integer, "items": Array(Boolean, min_items=2)}
    )
    value, errors = validate_json(json, validator)
    assert value == {
        "a": "foo",
        "b": "bar",
        "c": 1,
        "items": [True, False],
    }
    assert errors == []



# Generated at 2022-06-22 06:25:18.998618
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-22 06:25:30.937349
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({"name": String(), "age": Integer(), "is_human": Boolean()})
    content = '{"name": "Rick", "age": 100, "is_human": true}'
    value, error_messages = validate_json(content, schema)
    assert not error_messages
    assert value == {"name": "Rick", "age": 100, "is_human": True}

    content = '{"name": "Rick", "age": "100", "is_human": true}'
    value, error_messages = validate_json(content, schema)
    assert error_messages
    assert len(error_messages) == 1
    assert error_messages[0] == Message(
        text="Expected a number.", code="type_error", position=Position(0, 100)
    )



# Generated at 2022-06-22 06:25:46.043206
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        first_name = fields.String(max_length=300)
        last_name = fields.String(max_length=300)
        age = fields.Int()

    errors = validate_json(
        b"""{
            "first_name": "John",
            "age": 4
        }""",
        Person
    )

    assert errors.errors["last_name"] == [
        Message("Value is required.", code="value_is_required", position=Position(column_no=4, line_no=4, char_index=29))
    ]

# Generated at 2022-06-22 06:25:53.979730
# Unit test for function validate_json
def test_validate_json():
    content = '{"name":"John Doe","age":30,"city":"New York"}'
    validator = Schema(
        {
            "name": str,
            "age": int,
            "city": str,
        }
    )
    value, errors = validate_json(content=content, validator=validator)
    assert errors == []
    assert value["name"] == "John Doe"
    assert value["age"] == 30
    assert value["city"] == "New York"
    content = '{"name": ["John Doe", "Jane Doe"], "age":30,"city":"New York"}'
    value, errors = validate_json(content=content, validator=validator)
    assert len(errors) == 1
    assert errors[0].position.line_no == 1 and errors[0].position.column_no == 9

# Generated at 2022-06-22 06:26:05.112733
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") is None
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert tokenize_json("1") == 1
    assert tokenize_json("1.0") == 1.0
    assert tokenize_json("10e100") == 10e100
    assert tokenize_json("10e-100") == 10e-100
    assert tokenize_json("""{"a": "b"}""") == {"a": "b"}
    assert tokenize_json("""{"a": "b", "c": "d"}""") == {"a": "b", "c": "d"}

# Generated at 2022-06-22 06:26:16.809304
# Unit test for function tokenize_json
def test_tokenize_json():
    content_1 = '{"key1": "value1", "key2": "value2"}'
    token_1 = tokenize_json(content_1)
    assert isinstance(token_1, DictToken)
    assert token_1.content == content_1
    # Dict token should have two children
    assert isinstance(list(token_1.value.items())[0][0], ScalarToken)
    # Dict tokens should have a start and end
    assert token_1.start == 0
    assert token_1.end == 39
    # Dict tokens should have the original content
    assert isinstance(token_1.content, str)
    assert token_1.content == content_1
    # Get the first child of the first child

# Generated at 2022-06-22 06:26:17.886987
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  decoder = _TokenizingDecoder()

# Generated at 2022-06-22 06:26:29.224893
# Unit test for function validate_json
def test_validate_json():
    # empty string
    try:
        validate_json("", str)
    except ParseError as e:
        assert e.position == Position(column_no=1, line_no=1, char_index=0)
        assert e.code == "no_content"

    # single string
    value, errors = validate_json(r'"abc"', str)
    assert value == "abc"
    assert not errors

    # JSONDecodeError
    try:
        validate_json("{", str)
    except ParseError as e:
        assert e.code == "parse_error"
        assert e.position == Position(column_no=2, line_no=1, char_index=1)

    # Validation error
    value, errors = validate_json("1", str)
    assert value == "1"
   

# Generated at 2022-06-22 06:26:41.708728
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        fields={"name": String(max_length=10), "color": String(max_length=10)}
    )

    assert(
        validate_json(
            content=b'{"name":"Darth Vader", "color":"Red"}',
            validator=schema,
        )
        == (
            # Value is correct
            {"color": "Red", "name": "Darth Vader"},
            [],
        )
    )

    assert(
        validate_json(
            content=b'{"name":"Darth Vader", "color":"Red"}', validator=schema,
        )
        == (
            # Value is correct
            {"color": "Red", "name": "Darth Vader"},
            [],
        )
    )


# Generated at 2022-06-22 06:26:46.179466
# Unit test for function tokenize_json
def test_tokenize_json():
    message = tokenize_json("[]")
    assert message.value == []

    validator = Field(type="integer")
    token = tokenize_json("[1, 2, 3]")
    assert validate_with_positions(token, validator) == ([1, 2, 3], [])



# Generated at 2022-06-22 06:26:57.650601
# Unit test for function validate_json
def test_validate_json():
    validator = Field(required=True, type="string")
    content = "\"hello world\""
    value, error_messages = validate_json(content, validator)
    assert value == "hello world"
    assert error_messages == []

    content = "{}"
    value, error_messages = validate_json(content, validator)
    assert error_messages == [
        Message(
            code="required",
            text="This field is required.",
            source=None,
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

    # Validator bails out on the first error.
    validator = Field(required=True, type="string", max_length=5)
    content = "\"hello world\""
    value, error_mess

# Generated at 2022-06-22 06:27:08.753504
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    content = '"hello"'
    value, error_messages = validate_json(content=content, validator=validator)
    assert error_messages == []
    assert value == "hello"

    content = '"hel"lo"'
    value, error_messages = validate_json(content=content, validator=validator)
    assert(len(error_messages) == 1)
    assert(isinstance(error_messages[0], ValidationError))
    assert(error_messages[0].position.char_index == 2)
    assert(error_messages[0].position.column_no == 3)
    assert(error_messages[0].position.line_no == 1)

# Generated at 2022-06-22 06:27:16.011371
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "content")
    assert(decoder.scan_once == _make_scanner(decoder, "content"))


# Generated at 2022-06-22 06:27:23.204903
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{"a": 1, "b": "2"}'
    def_scanner_once = _make_scanner(
        _TokenizingDecoder(), json_str
    )
    assert isinstance(def_scanner_once, typing.Callable)

    json_decoder = _TokenizingDecoder(content=json_str)
    assert isinstance(json_decoder.scan_once, typing.Callable)
    assert isinstance(json_decoder.decode(json_str), Token)


# Generated at 2022-06-22 06:27:33.610634
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def parse_int(val: str) -> int:
        return int(val)
    # This test is for _TokenizingDecoder
    d = _TokenizingDecoder(parse_float=float, parse_int=parse_int, parse_constant=bool, strict=True,
                           parse_object=_TokenizingJSONObject, parse_array=list,
                           content="")
    assert d.parse_int(2) == 2
    assert d.parse_float(2.2) == 2.2
    assert d.parse_constant(1) == True
    assert d.parse_constant(0) == False
    assert d.parse_array([2, 2]) == [2, 2]

# Generated at 2022-06-22 06:27:36.201944
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == {'hello': 'world'}


# Generated at 2022-06-22 06:27:47.652632
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
        "foo_bar": ["a", "b", "c"],
        "simple": {
            "string": "A string",
            "integer": 1,
            "float": 1.0,
            "list": [],
            "dict": {},
            "boolean": true,
            "null": null
        }
    }
    '''
    tok = tokenize_json(content)
    assert isinstance(tok, DictToken)
    assert isinstance(tok.value.get("foo_bar"), ListToken)
    assert isinstance(tok.value.get("simple"), DictToken)
    assert isinstance(
        tok.value.get("simple").value.get("string"), ScalarToken
    )

# Generated at 2022-06-22 06:27:58.646204
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"return": true}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.key == {"return"}
    assert token.value["return"] is True

    content = '{"return": false}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.key == {"return"}
    assert token.value["return"] is False

    content = '{"x": "y"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.key == {"x"}
    assert token.value["x"] == "y"

    content = '{"foo": ["bar"]}'
    token = tokenize_json(content)

# Generated at 2022-06-22 06:28:05.233973
# Unit test for function validate_json
def test_validate_json():
    import json
    import io
    import typesystem
    from typesystem.types import String, Integer, Object, Array

    class TestSchema(typesystem.Schema):
        name = String()
        age = Integer()
        hobbies = Array(items=String)
        position = Object(properties={
            'x': Integer(),
            'y': Integer(minimum=0)
        })

    # Same JSON as used in unit test for function validate_with_positions
    text = '{ "name": "Dora", "age": 12, "hobbies": [ "exploring", "cartography" ], "position": { "x": 4, "y": 3 } }'

    # Use the decoder to parse the JSON string
    decoder = _TokenizingDecoder()
    data = decoder.decode(text)

    # Use validate_json

# Generated at 2022-06-22 06:28:09.548897
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = r'{"name": "john", "age": 15}'
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert isinstance(token.value['name'], ScalarToken)
    assert token.value['name'].value == 'john'
    assert isinstance(token.value['age'], ScalarToken)
    assert token.value['age'].value == 15


# Generated at 2022-06-22 06:28:13.912168
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.types import String
    schema = Schema(
        {
            "first_name": String(max_length=10),
            "last_name": String(max_length=10),
            "phone": String(max_length=10),
            "email": String(max_length=30),
        }
    )
    content = (
        '{"first_name": "Arnold", "last_name": "Tester", "phone": "619-123-4567", "email": "test@test.com"}'
    )
    value, error_messages = validate_json(content, schema)

# Generated at 2022-06-22 06:28:17.771678
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    expected_scan_once = _make_scanner(decoder, "")

    assert decoder.scan_once == expected_scan_once
