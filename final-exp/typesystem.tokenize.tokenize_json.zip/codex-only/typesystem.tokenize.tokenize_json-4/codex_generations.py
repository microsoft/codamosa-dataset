

# Generated at 2022-06-24 11:10:41.239480
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="string")
    assert decoder.scan_once is not None
    assert decoder._scan_once is not None

# Generated at 2022-06-24 11:10:46.135858
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder("", "", "")
    except Exception as e:
        assert(type(e) == TypeError and  str(e) == "__init__() takes 2 positional arguments but 3 were given")

    _TokenizingDecoder("", "")

# Generated at 2022-06-24 11:10:55.743087
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test for tokenize_json
    """
    assert tokenize_json('{}') == DictToken(
        {}, start_position=Position(column_no=1, line_no=1, char_index=0),
        end_position=Position(column_no=2, line_no=1, char_index=1), content='{}'
    )

# Generated at 2022-06-24 11:10:58.030413
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert JSONDecoder != _TokenizingDecoder  # test subclassing
    assert not callable(_TokenizingDecoder)  # test is abstract



# Generated at 2022-06-24 11:11:00.804020
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    >>> tokenize_json(b'{"key": "value"}')
    {'key': 'value'}
    """

# Generated at 2022-06-24 11:11:08.090660
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='Test Content')
    assert (decoder.content == 'Test Content')
    assert (decoder.memo == dict())
    assert (decoder.scan_once != None)
    # _make_scanner does not have test coverage
    # decoder.scan_once == _make_scanner()
    # assert (decoder.parse_float == lambda arg: float(arg))
    assert (decoder.parse_int == int)
    # assert (decoder.parse_array == None)
    # assert (decoder.parse_string == None)
    assert (decoder.strict == True)



# Generated at 2022-06-24 11:11:16.296949
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:11:21.907522
# Unit test for function validate_json
def test_validate_json():
    # Creating a test JSON string
    test_json = {"cat": 1, "dog": 2, "mouse": 3}
    json_string = json.dumps(test_json)

    # Creating a schema to test validation
    schema_dict = {
        "cat": "string",
        "dog": "number",
        "mouse": ["number", "null", "boolean"],
    }
    test_schema = Schema(fields=schema_dict)
    try:
        validate_json(json_string, test_schema)
    except Exception as e:
        print(f"Got exception: {e}")

# Generated at 2022-06-24 11:11:28.809992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": {"bar": "baz"}, "baz": ["a", "b", "c"]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["foo"], DictToken)
    assert token.value["foo"].value["bar"].value == "baz"



# Generated at 2022-06-24 11:11:40.028955
# Unit test for function validate_json
def test_validate_json():
    schema = {
        "title": "Foobar",
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "integer"},
        },
        "required": ["foo", "bar"],
    }
    validator = Schema.from_dict(schema)

    canonical_error = Message(
        title="Foobar",
        text="This field is required.",
        code="required",
        position=Position(column_no=1, line_no=1, char_index=0),
    )
    canonical_error_list = [canonical_error]

    assert validate_json('{"bar": null}', validator) == (
        ValidationError(errors=canonical_error_list),
        canonical_error_list,
    )


# Generated at 2022-06-24 11:11:50.347537
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Test tokenize_json function returns expected results for different JSON text
    '''

# Generated at 2022-06-24 11:11:59.760574
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    validator = Field(type="string")
    value, messages = validate_json('"Hello World"', validator)
    assert value == "Hello World"
    assert not messages

    # Invalid JSON
    value, messages = validate_json('{"key": "value"', validator)
    assert messages
    assert messages[0].code == "parse_error"

    # Unknown parse error
    value, messages = validate_json("", validator)
    assert messages
    assert messages[0].code == "no_content"

    # Failed validation
    value, messages = validate_json('{"key": "value"}', validator)
    assert messages
    assert messages[0].code == "invalid_type"

# Generated at 2022-06-24 11:12:07.961557
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": [1, "foo"]}') == DictToken(
        {ScalarToken('a', 1, 2, '{"a": [1, "foo"]}'): ListToken(
            [ScalarToken(1, 7, 8, '{"a": [1, "foo"]}'),
            ScalarToken('foo', 11, 14, '{"a": [1, "foo"]}')],
            6, 16, '{"a": [1, "foo"]}')},
        0, 17, '{"a": [1, "foo"]}')


# Generated at 2022-06-24 11:12:10.321522
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert isinstance(decoder, JSONDecoder)
    assert hasattr(decoder, "scan_once")

# Generated at 2022-06-24 11:12:11.604630
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert False


# Generated at 2022-06-24 11:12:18.503771
# Unit test for function validate_json
def test_validate_json():
    """
    Example: Handling JSON parse errors
    """
    content = '{abc}'
    validator = Field(type="string")

    # Example: Parses the string and returns with the validation error.
    actual = validate_json(content=content, validator=validator)
    assert actual == (
        None,
        [
            Message(
                code="parse_error",
                text="Expecting property name enclosed in double quotes.",
                position=Position(column_no=2, line_no=1, char_index=1),
            )
        ],
    )



# Generated at 2022-06-24 11:12:28.692106
# Unit test for function validate_json
def test_validate_json():
    from datetime import date
    from decimal import Decimal
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class OrderSchema(Schema):
        product = Field(description="The product name")
        quantity = Field(description="The quantity", type="Integer")
        price = Field(description="The cost", type="Number")
        created_at = Field(description="The order date", type="DateTime")

        class Meta:
            title = "Order"
            description = "An order form."

    schema = OrderSchema()
    content = """
    {
        "product": "Awesome widget",
        "quantity": 42,
        "price": 1.23,
        "created_at": "2017-05-30"
    }
    """
    data, error_messages = validate_

# Generated at 2022-06-24 11:12:30.658501
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="hi this is a test")


# Generated at 2022-06-24 11:12:32.138718
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert token == {'a': 1}

# Generated at 2022-06-24 11:12:40.124310
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    import os
    import sys
    
    """
    _TokenizingDecoder(escape_unicode=True, content="json_string")
    """
    try:
        # Testing None Type
        _TokenizingDecoder(escape_unicode=None, content="json_string")
    except TypeError:
        pass
    
    try:
        # Testing None Type
        _TokenizingDecoder(escape_unicode=True, content=None)
    except TypeError:
        pass
    
    # Testing Bool Type
    _TokenizingDecoder(escape_unicode=True, content="json_string")
    
    # Testing Bool Type
    _TokenizingDecoder(escape_unicode=False, content="json_string")
    
    # Testing JSON/Byte Type

# Generated at 2022-06-24 11:12:49.148380
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for some trivial cases - empty string, lots of whitespace, etc.
    assert tokenize_json("") == ScalarToken(value=None, start=0, end=0)
    assert (
        tokenize_json(" \t\n") == ScalarToken(value=None, start=0, end=4)  # type: ignore
    )
    # Test for various substrings starting with curly braces.
    assert tokenize_json("{}") == DictToken(
        value={}, start=0, end=2
    )  # type: ignore
    assert tokenize_json(" {}") == DictToken(value={}, start=1, end=3)
    assert tokenize_json("{ }") == DictToken(value={}, start=0, end=3)

# Generated at 2022-06-24 11:12:50.381745
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()


# Generated at 2022-06-24 11:12:58.106039
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b"", str) == ("", [])
    assert validate_json(b"null", str) == (None, [])
    assert validate_json(b"1", str) == ("1", [])
    assert validate_json(b"null", int) == (0, [])
    assert validate_json(b"1", int) == (1, [])
    assert validate_json(b"null", float) == (0.0, [])
    assert validate_json(b"1", float) == (1.0, [])
    assert validate_json(b"null", bool) == (False, [])
    assert validate_json(b"true", bool) == (True, [])
    assert validate_json(b"false", bool) == (False, [])

# Generated at 2022-06-24 11:13:03.481638
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String

    empty_content = ""
    small_content = '{"message": "Hello"}'
    complex_content = '{"message": "Hello", "info": {"address": "123"}'
    errors = validate_json(empty_content, String())
    errors = validate_json(small_content, String())
    errors = validate_json(complex_content, String())


# Generated at 2022-06-24 11:13:10.367998
# Unit test for function validate_json
def test_validate_json():
    class UserSchema(Schema):
        id = Field(format="uuid")
        name = Field(type="string")

    user = {
        "id": "de305d54-75b4-431b-adb2-eb6b9e546014",
        "name": "Alice",
    }
    try:
        error_messages = validate_json(json.dumps(user), UserSchema)
    except ValidationError as exc:
        error_messages = exc.messages
    assert error_messages == []

    user["id"] = "not-a-uuid"
    try:
        error_messages = validate_json(json.dumps(user), UserSchema)
    except ValidationError as exc:
        error_messages = exc.messages
    assert error_messages

# Generated at 2022-06-24 11:13:13.622373
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert token == {'a': 1}
    token = tokenize_json('[1, 2, 3]')
    assert token == [1,2,3]

# Generated at 2022-06-24 11:13:23.951617
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "restaurants": [
    {
      "id": 1,
      "name": "Foo",
      "location": {
        "city": "Seattle",
        "state": "Washington"
      },
      "price_range": "$$"
    },
    {
      "id": 2,
      "name": "Bar",
      "location": {
        "city": "Portland",
        "state": "Oregon"
      },
      "price_range": "$$$"
    }
  ]
}
"""
    token = tokenize_json(content)
    print(token.to_data())

# Generated at 2022-06-24 11:13:33.374120
# Unit test for function validate_json
def test_validate_json():
    def _check(
        validator: typing.Union[Field, typing.Callable],
        content: typing.Union[str, bytes],
        expected: typing.Any,
    ) -> None:
        if isinstance(validator, Field):
            validator = validator.validate
        actual, error_messages = validate_json(content, validator)
        assert error_messages == expected
        if expected:
            assert actual is None
        else:
            assert actual is not None

    from typesystem import Integer, String, Type, validators

    _check(
        Integer(), b"123", []
    )  # Should succeed.
    _check(
        Integer(minimum=4), b"123", [ValidationError(text='Value must be at least 4.', code='minimum_value')]
    )  # Should produce

# Generated at 2022-06-24 11:13:40.394967
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema(
        {
            "required": ["people", "number_of_people"],
            "properties": {
                "people": List(items=Dict(
                    {
                        "properties": {
                            "first_name": String,
                            "last_name": String,
                            "age": Integer,
                            "gender": Enum(["Male", "Female"])
                        }
                    }
                )),
                "number_of_people": Integer
            }
        }
    )
    content = '{"people": [{"first_name": "John", "last_name": "Doe", "age": 40, "gender": "Male"}], "number_of_people": 1}'

    token = tokenize_json(content)

# Generated at 2022-06-24 11:13:52.619380
# Unit test for function validate_json
def test_validate_json():
    """
    Tests the function validate_json
    """
    # test for empty content
    try:
        validate_json(content="", validator=Field())
    except ParseError as exc:
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.code == 'no_content'
        assert exc.text == 'No content.'

    # test for malformed json document
    try:
        validate_json(content='{"name": "jack}', validator=Field())
    except ParseError as exc:
        assert exc.position.column_no == 13
        assert exc.position.line_no == 1
        assert exc.position.char_index == 12
        assert exc.code == 'parse_error'

# Generated at 2022-06-24 11:13:53.753189
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="abc")

# Generated at 2022-06-24 11:13:56.438530
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(), JSONDecoder)
    assert isinstance(_TokenizingDecoder(content="content"), JSONDecoder)
    assert isinstance(_TokenizingDecoder(content="content", strict=True), JSONDecoder)


# Generated at 2022-06-24 11:14:02.026901
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Tests for class attributes
    # call with content
    validator = _TokenizingDecoder(content="")
    assert validator.content == ""
    # call without content
    validator = _TokenizingDecoder()
    assert validator.content == None


# Generated at 2022-06-24 11:14:13.365097
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": [1, "b"], "b": {"a": "b", "c": [1, 2]}}'
    tokens = tokenize_json(content)
    assert tokens.content == content
    assert tokens.position_range.start == (1, 1)
    assert tokens.position_range.stop == (7, 17)
    # assert tokens.value == {
    #     "a": [1, "b"],
    #     "b": {"a": "b", "c": [1, 2]},
    # }

    assert tokens[0].content == '"a"'
    assert tokens[0].value == "a"
    assert tokens[0].position_range.start == (1, 2)
    assert tokens[0].position_range.stop == (1, 4)


# Generated at 2022-06-24 11:14:23.912527
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.fields import String

    test_cases = (
        ("", ValueError),
        ("a", ValueError),
        ("{}", {}),
        ('{"a": "b", "c": "d"}', {"a": "b", "c": "d"}),
        ('{"a": 12}', {"a": 12}),
        ('{"a": true, "b": false}', {"a": True, "b": False}),
        ('{"a": null}', {"a": None}),
        ('[12, "d", null, true]', [12, "d", None, True]),
    )

    for json, expected in test_cases:
        token = tokenize_json(json)
       

# Generated at 2022-06-24 11:14:32.022103
# Unit test for function tokenize_json
def test_tokenize_json():
    # Unit test for function _TokenizingJSONObject
    # Parse simple object
    foo = '{ "bar": 1 }'
    token = tokenize_json(foo)
    assert token.as_python == {"bar": 1}

    # Parse simple array
    bar = '[1, 2]'
    token = tokenize_json(bar)
    assert token.as_python == [1, 2]

    # Parse simple array of objects
    baz = '[{"a": 1}, {"b": 2}]'
    token = tokenize_json(baz)
    assert token.as_python == [{"a": 1}, {"b": 2}]



# Generated at 2022-06-24 11:14:41.114529
# Unit test for function validate_json
def test_validate_json():
    content = '{ "name" : "John" }'
    schema = Schema.build({"name": {"type": "string"}})
    value, messages = validate_json(content, schema)
    assert value == {"name": "John"}
    assert len(messages) == 0

    schema = Schema.build({"name": {"type": "string", "required": True}})
    value, messages = validate_json(content, schema)
    assert value == {"name": "John"}
    assert len(messages) == 0

    content = '{ "name" : 10 }'
    schema = Schema.build({"name": {"type": "string", "required": True}})
    value, messages = validate_json(content, schema)
    assert value is None
    assert len(messages) == 1
    assert messages

# Generated at 2022-06-24 11:14:46.177638
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test file '__main__.py'
    # Test function test_tokenize_json(self)
    # Test class TestTokenizeJson
    # Test class TestTokenizeJson # Test method test_basic
    content = """
    {
        "foo": "foo",
        "bar": true,
        "baz": [1, 2, 3],
        "qux": {
            "foo": "foo"
        }
    }
    """
    token = tokenize_json(content)
    assert type(token) is DictToken
    assert token.value["foo"].value == "foo"
    assert type(token.value["foo"]) is ScalarToken
    assert token.value["bar"].value is True
    assert type(token.value["bar"]) is ScalarToken
    assert token.value

# Generated at 2022-06-24 11:14:54.536817
# Unit test for function validate_json
def test_validate_json():
    content = r'{"a":1}'
    schema = Schema({
        "a": int
    })
    value, messages = validate_json(content=content, validator=schema)
    assert value == {'a': 1}
    assert messages == []

    content = r'{"b":2}'
    with raises(ValidationError):
        validate_json(content=content, validator=schema)

    content = r'{"a":2}'
    with raises(ValidationError):
        validate_json(content=content, validator=schema)


# Generated at 2022-06-24 11:15:04.686940
# Unit test for function validate_json
def test_validate_json():
    error_message = "Expecting content to be of type integer."
    error_code = "type_error"
    # Validate an incorrect value.
    value, messages = validate_json(content='"hello"', validator=Field(type=int))
    assert(len(messages) == 1)
    message = messages[0]
    assert(message.text == error_message)
    assert(message.code == error_code)
    assert(value == None)
    # Validate a correct value.
    value, messages = validate_json(content='20', validator=Field(type=int))
    assert(len(messages) == 0)
    assert(value == 20)

# Generated at 2022-06-24 11:15:15.637918
# Unit test for function tokenize_json
def test_tokenize_json():
    content1 = '{"name": "name", "age": 2}'
    token = tokenize_json(content1)
    assert isinstance(token, dict)
    token1 = token.get('name')
    assert isinstance(token1, ScalarToken)
    content2 = '{"name": "name", "age": 2}]'
    with pytest.raises(ParseError) as e:
        tokenize_json(content2)
    assert e.value.position.column_no == 28
    assert e.value.position.line_no == 1
    assert e.value.position.char_index == 27
    assert e.value.code == "parse_error"
    assert e.value.text == "Expecting end of value"
    assert token1.content is content1

# Generated at 2022-06-24 11:15:23.433771
# Unit test for function tokenize_json
def test_tokenize_json():
    list_token = tokenize_json("[1,2,3]")
    assert type(list_token) == ListToken
    assert list_token.value == [1, 2, 3]

    dict_token = tokenize_json('{"a": 1}')
    assert type(dict_token) == DictToken
    assert dict_token.value == {"a": 1}

    scalar_token = tokenize_json('"a"')
    assert type(scalar_token) == ScalarToken
    assert scalar_token.value == "a"

# Generated at 2022-06-24 11:15:26.685096
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {"a":1}
    json_str = json.dumps(content)
    assert tokenize_json(json_str) == DictToken(content, 0, -1)


# Generated at 2022-06-24 11:15:30.477461
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"test": 12}'
    token = tokenize_json(content)

    assert isinstance(token, Token)
    assert token.start == 0
    assert token.stop == 11



# Generated at 2022-06-24 11:15:37.639560
# Unit test for function validate_json
def test_validate_json():
    content = '{"title": "Version 1", "version": "1.0"}'
    validator = Schema.of(
        {
            "title": Field(description="The title of the version."),
            "version": Field(description="The version number."),
        }
    )
    # Check that the value returned is correct.
    value, error_messages = validate_json(content, validator)
    assert value == {"title": "Version 1", "version": "1.0"}
    assert error_messages == Message.none()

    # Check that validation errors are handled.
    content = '{"title": "Version 1", "version": "1.0", "weights": [0, -1, 1]}'

# Generated at 2022-06-24 11:15:48.493001
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, errors = validate_json('"text"', validator)
    assert value == "text"
    assert isinstance(errors, list)
    assert not errors

    validator = Field(type="string", required=True)
    value, errors = validate_json('"text"', validator)
    assert value == "text"
    assert isinstance(errors, list)
    assert len(errors) == 0

    value, errors = validate_json(b'"text"', validator)
    assert value == "text"
    assert isinstance(errors, list)
    assert len(errors) == 0

    value, errors = validate_json("", validator)
    assert value == None
    assert isinstance(errors, list)
    assert errors
    assert len(errors[0].position)

# Generated at 2022-06-24 11:15:59.234612
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test that the decoder has the following properties
    # __init__ - initialiser
    # parse_object() - Decode a JSON document from string.
    # parse_array() - Decode a JSON document from string.
    # parse_string() - Decode a JSON document from string.
    # parse_int() - Decode a JSON document from string.
    # parse_float() - Decode a JSON document from string.
    # strict - If true (the default), invalid JSON strings will raise an exception.
    # scan_once() - Return the Python representation of string.
    # memo - The set of object that have already been seen. This prevents infinite
    # recursion.

    decoder = _TokenizingDecoder()
    assert hasattr(decoder, "__init__")
    assert hasattr(decoder, "parse_object")
   

# Generated at 2022-06-24 11:16:00.263184
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder() is not None

# Generated at 2022-06-24 11:16:10.731903
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert str(token.data[0]) == '"foo"'
    assert str(token.data[1]) == '{"bar":["baz",null,1.0,2]}'

    content = "{'foo': 'bar'}"
    with pytest.raises(ParseError) as exc_info:
        tokenize_json(content)
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.column_no == 2


# Generated at 2022-06-24 11:16:19.302549
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    s = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    assert _TokenizingDecoder(content="").scan_once(s, 0) == (
        ScalarToken(b"foo", 1, 5, content=""),
        6,
    )

# Generated at 2022-06-24 11:16:28.667445
# Unit test for function validate_json
def test_validate_json():
    class User(Schema):
            username = Field()

    validator = User()
    # Test invalid JSON
    try:
        validate_json('{"username": "davebloggs"', validator)
    except ParseError as exc:
        assert exc.code == "parse_error"
        assert exc.position.char_index == 23
        assert exc.text == "Expecting value"
    # Test a failed validation
    try:
        validate_json('{"username": 1}', validator)
    except ValidationError as exc:
        assert not exc.context
        assert exc.code == "invalid"
        assert exc.messages[0].position.char_index == 12
        assert exc.messages[0].text == "Incorrect type."
        assert exc.messages[0].type == "error"
   

# Generated at 2022-06-24 11:16:35.594794
# Unit test for function validate_json
def test_validate_json():
    content_str = '{"name": "Jane Doe", "age": "unknown"}'
    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()
    value, errors = validate_json(content_str, PersonSchema)

    assert(value == {"name": "Jane Doe", "age": "unknown"})
    assert(len(errors) == 1)
    assert(errors[0].code == 'invalid_type')
    assert(errors[0].position.char_index == 23)
    assert(errors[0].position.line_no == 1)
    assert(errors[0].position.column_no == 22)

# Generated at 2022-06-24 11:16:42.318626
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string case.
    with pytest.raises(ParseError):
        tokenize_json('')
    # Test for incorrect JSON.
    with pytest.raises(ParseError):
        tokenize_json('{"hello": 1, "world": 2')
    # Test for correct JSON.
    assert tokenize_json('{"hello": 1, "world": 2}') == {
        'hello': 1,
        'world': 2,
    }



# Generated at 2022-06-24 11:16:48.273585
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    schema = Schema(properties={"name": String()}, title="Student")
    content = '{"name": "Jürgen"}'
    value, errors = validate_json(content, schema)
    assert value == {"name": "Jürgen"}
    assert not errors
    content = '{"name": "Jürgen", "age": 21}'
    value, errors = validate_json(content, schema)
    assert value == {"name": "Jürgen", "age": 21}

# Generated at 2022-06-24 11:16:49.391534
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder is not None

# Generated at 2022-06-24 11:17:00.964652
# Unit test for function validate_json
def test_validate_json():
    body = """
    {
        "name": "bob",
        "age": 10,
        "likes": ["tacos", "cheese"],
        "height": "180cm",
        "type": "bob"
    }
    """
    validator = PersonSchema()
    value, errors = validate_json(body, validator)
    assert errors[0].text == "Is a required property."
    assert errors[0].code == 'required'


# Generated at 2022-06-24 11:17:11.428020
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Number, String
    from typesystem.schemas import Schema, fields
    from typesystem.typing import Dict, Float, Optional, Union, List

    class BookSchema(Schema):
        title = fields.String(max_length=100)
        author = fields.String(max_length=100)
        pages = fields.Integer(minimum=1)
        is_book_on_autobiography = fields.Boolean()

    raw_json = """
    {
        "title": "My Little Pony: Friendship is Magic",
        "author": "Lauren Faust",
        "pages": 100,
        "is_book_on_autobiography": true
    }
    """.strip()

    book_json_schema = BookSchema()
    book_value, book_errors = validate_

# Generated at 2022-06-24 11:17:16.203103
# Unit test for function validate_json
def test_validate_json():
    class MySchema(Schema):
        name = 'MySchema'
        age = 'integer'
    value, errors = validate_json('{"age": 3, "name": "x"}', MySchema)
    assert value == {'age': 3, 'name': 'x'}
    assert len(errors) == 0

# Generated at 2022-06-24 11:17:17.773616
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder([])
    assert decoder.scan_once



# Generated at 2022-06-24 11:17:23.146562
# Unit test for function validate_json
def test_validate_json():
    valid_object = {
        "field1": "value1",
        "field2": ["value2", "value3"],
        "field3": {"field4": "value4"},
    }

    valid_content = json.dumps(valid_object)

    result, errors = validate_json(valid_content, Schema)

    assert result == valid_object
    assert errors == []

# Generated at 2022-06-24 11:17:34.560048
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = String()
        age = Integer(maximum=200)

    response, errors = validate_json(
        '{"name": "John Doe", "age": -5}', validator=Person
    )
    assert response == {
        "name": "John Doe",
        "age": -5,
    }
    assert errors == [
        Message(
            text="less than the minimum of 0.",
            code="minimum",
            position=Position(char_index=21, line_no=1, column_no=21),
        )
    ]

    response, errors = validate_json(
        '{"name": "John Doe", "age": "a lot"}', validator=Person
    )
    assert response is None

# Generated at 2022-06-24 11:17:44.101447
# Unit test for function validate_json
def test_validate_json():
    def _get_token(content: typing.Union[str, bytes]) -> Token:
        return tokenize_json(content)

    class Model(Schema):
        name = Field(required=True)

    # text='No content.', code='no_content', position=Position(column_no=1, line_no=1, char_index=0)
    content = ""
    with pytest.raises(ParseError) as excinfo:
        _get_token(content)
    excinfo.match(
        "ParseError: text='No content.', code='no_content', position=Position\(column_no=1, line_no=1, char_index=0\)"
    )

    content = '{"name":""}'
    token, errors = validate_json(content, Model)
    assert errors == []

# Generated at 2022-06-24 11:17:55.234710
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that tokenize_json handles the empty string case.
    try:
        tokenize_json(" ")
    except ParseError as error:
        assert error.code == "no_content"
        assert error.message == "No content."
        assert error.position.column_no == 1
        assert error.position.line_no == 1
        assert error.position.char_index == 0
    else:
        assert False, "No parse error was raised."

    # Test that tokenize_json handles invalid JSON cases.
    try:
        tokenize_json("{")
    except ParseError as error:
        assert error.code == "parse_error"
        assert error.message == "Expecting property name enclosed in double quotes."
        assert error.position.column_no == 1

# Generated at 2022-06-24 11:17:57.364979
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    manager = _TokenizingDecoder()
    assert manager is not None


# Generated at 2022-06-24 11:18:06.203729
# Unit test for function tokenize_json
def test_tokenize_json():
    import json
    test_input = json.dumps({"a": 1, "b": [2, 3]})

# Generated at 2022-06-24 11:18:16.066853
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    class List(typesystem.Schema):
        items = typesystem.Array(item=typesystem.String())

    class Object(typesystem.Schema):
        name = typesystem.String(pattern="^[A-Z][a-z]+$")
        age = typesystem.Integer()

    class Root(typesystem.Schema):
        strings = typesystem.Array(item=typesystem.String())
        numbers = typesystem.Array(item=typesystem.Number())
        booleans = typesystem.Array(item=typesystem.Boolean())
        dicts = typesystem.Array(item=typesystem.Dict(properties={"name": typesystem.String()}))
        objects = typesystem.Array(item=typesystem.Object(properties={"name": typesystem.String()}))
        lists = types

# Generated at 2022-06-24 11:18:19.554138
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_string = '{"key1":"value1","key2":"value2"}'
    tokenize_json(json_string)

# Generated at 2022-06-24 11:18:28.977968
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "id": 1,
  "name": "A green door",
  "price": 12.5,
  "tags": ["home", "green"]
}
"""
    result = tokenize_json(content)
    assert result == DictToken(
        {
            "id": ScalarToken(1, 19, 20, content),
            "name": ScalarToken("A green door", 31, 41, content),
            "price": ScalarToken(12.5, 51, 54, content),
            "tags": ListToken(["home", "green"], 64, 77, content),
        },
        0,
        77,
        content,
    )



# Generated at 2022-06-24 11:18:36.857099
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "x": "a",
        "y": "b",
        "z": "c"
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"x": "a", "y": "b", "z": "c"}
    assert token.start_position == Position(line_no=3, column_no=9, char_index=17)
    assert token.end_position == Position(line_no=7, column_no=5, char_index=83)



# Generated at 2022-06-24 11:18:44.923299
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_token_type(token: Token, token_type: str):
        assert isinstance(token, token_type)

    def assert_scalar_token(
        token: Token,
        value: typing.Union[str, int, float],
        position: Position = Position(column_no=0, line_no=0, char_index=0),
        content: str = "",
    ):
        assert_token_type(token, ScalarToken)
        assert token.value == value
        assert token.position == position
        if content:
            assert token.content == content


# Generated at 2022-06-24 11:18:55.562322
# Unit test for function validate_json
def test_validate_json():
    schema = typesystem.Schema(fields={"name": typesystem.String(required=True)})
    assert validate_json(
        content='{"name":"a"}',
        validator=schema
    ) == ({
        "name":"a"
    }, [])
    assert validate_json(
        content='{}',
        validator=schema
    ) == (
        {},
        [
            Message(
                text='This field is required.',
                code='required',
                position=Position(
                    line_no=1,
                    column_no=2,
                    char_index=1
                )
            )
        ]
    )

# Generated at 2022-06-24 11:19:00.048298
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _get_const_dict = _TokenizingDecoder.__init__.__code__.co_consts[3]
    assert isinstance(_get_const_dict, dict)
    assert _get_const_dict["key"] == "value"



# Generated at 2022-06-24 11:19:08.313982
# Unit test for function validate_json
def test_validate_json():
    # Positive tests
    content = '{"test": "Hello, World!"}'
    validator = {
        "test": {"type": "string", "required": True}
    }
    value, error_messages = validate_json(content, validator)
    assert value == {"test": "Hello, World!"}
    assert error_messages == []

    content = '{"test": "Hello, World!"}'
    validator = {
        "test": {"type": "string", "required": True}
    }
    value, error_messages = validate_json(content, validator)
    assert value == {"test": "Hello, World!"}
    assert error_messages == []

    content = '{"test": "Hello, World!", "test2": "Hello, World!"}'

# Generated at 2022-06-24 11:19:09.972559
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({'a': 'b'}, 1, 9, '{"a": "b"}')



# Generated at 2022-06-24 11:19:15.574187
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import MessageSchema
    from typesystem.fields import String, Integer, Float
    from typesystem.tokenize.tokens import ScalarToken, DictToken, ListToken

    example_1 = b'{"id":123, "amount":456.78, "name":"foo"}'
    example_2 = b'{"id":123, "amount":abc, "name":"bar"}'
    example_3 = b'{"id":123, "amount":456.78, "name":"foo", "extra":"field"}'
    example_4 = b'{"id":123, "amount":456.78, "name":"foo", "amount":456.78}'
    example_5 = b'{"id":123, "name":[1, 2, 3]}'

# Generated at 2022-06-24 11:19:22.605425
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with pytest.raises(json.decoder.JSONDecodeError) as exc:
        _TokenizingDecoder().decode(b"not JSON")
    assert exc.value.lineno == 1
    assert exc.value.colno == 1
    assert exc.value.pos == 0
    assert exc.value.msg == "Expecting value"
    assert exc.value.doc == b"not JSON"
    assert exc.value.end == 0

# Generated at 2022-06-24 11:19:25.800151
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This function will test the tokenize_json function in tokenize.json
    """
    assert tokenize_json("{}") == DictToken({})


# Generated at 2022-06-24 11:19:33.896799
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer, Object

    schema = Object(properties={"integer": Integer()})

    value, messages = validate_json(b'{"integer": "abc"}', schema)
    assert value is None
    message = messages[0]
    assert message.text == "Value must be an integer."
    assert message.code == "type_error.integer"
    assert message.position.column_no == 11
    assert message.position.line_no == 1
    assert message.position.char_index == 10

    value, messages = validate_json(b'{"integer": "3"}', schema)
    assert value == {"integer": 3}
    assert messages == []

# Generated at 2022-06-24 11:19:36.879292
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "content"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, _TokenizingDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)



# Generated at 2022-06-24 11:19:43.921041
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test the tokenize_json function.
    """
    token = tokenize_json("{}")
    assert isinstance(token, DictToken)
    assert token.value == {}
    token = tokenize_json("[]")
    assert isinstance(token, ListToken)
    assert token.value == []
    assert token.start_index == 0
    assert token.end_index == len("[]") - 1
    token = tokenize_json('"hello world"')
    assert isinstance(token, ScalarToken)
    assert token.value == "hello world"
    assert token.start_index == 0
    assert token.end_index == len('"hello world"') - 1
    token = tokenize_json("null")
    assert isinstance(token, ScalarToken)
    assert token.value is None


# Generated at 2022-06-24 11:19:47.669974
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key": 1}'
    decoder = _TokenizingDecoder(content=content)
    actual_result = decoder.scan_once(content, 0)
    expected_result = (
        DictToken(
            {
                ScalarToken("key", 1, 4, content): ScalarToken(
                    1, 9, 9, content
                )
            }, 0, 11, content
        ),
        12,
    )
    assert actual_result == expected_result


# Generated at 2022-06-24 11:19:51.943693
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Given
    content = '{"key": "value"}'
    # When
    decoder = _TokenizingDecoder(content=content)
    # Then
    assert decoder.scan_once.__name__ == '_make_scanner.<locals>.scan_once'


# Generated at 2022-06-24 11:20:00.192896
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test tokenize_json on a JSON string and JSON bytestring.
    """
    json_doc = '{"key1": 1234, "key2": "value2", "key3": true, "key4": null}'
    json_doc_byte = '{"key1": 1234, "key2": "value2", "key3": true, "key4": null}'.encode('utf-8')
    json_doc_null = 'null'
    json_doc_number = '123'
    json_doc_bool = 'true'
    json_doc_string = '"This is a string"'
    json_doc_list = '[null, true, 123, "This is a string"]'
    json_doc_empty_list = '[]'

    token_doc = tokenize_json(json_doc)

# Generated at 2022-06-24 11:20:11.052337
# Unit test for function validate_json
def test_validate_json():
    """
    This is a simple test that validates a json string against a validator
    Schema class.
    """
    class ExampleSchema(Schema):
        age = Field(type="integer")
        name = Field(type="string")

    content = """
    {
        "age": 1,
        "name": "Bob"
    }
    """
    token = tokenize_json(content)
    value, error_messages = validate_with_positions(token=token, validator=ExampleSchema)
    assert error_messages == []
    assert value == {"age": 1, "name": "Bob"}

    # Test with invalid content
    content = """
    {
        "age": "1",
        "name": 10
    }
    """
    token = tokenize_json(content)
    value

# Generated at 2022-06-24 11:20:18.791084
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
        "hello": {"name": "world"},
        "foo": [
            123,
            "bar",
            "baz"
        ]
    }
    '''
    token = tokenize_json(content)
    assert token.value == {
        "hello": {"name": "world"},
        "foo": [
            123,
            "bar",
            "baz",
        ],
    }
    assert token.start == 1
    assert token.end == 73
    assert token.content == content.splitlines()
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert isinstance(token.value["hello"], DictToken)
    assert token.value["hello"].value == {"name": "world"}

# Generated at 2022-06-24 11:20:28.539314
# Unit test for function validate_json
def test_validate_json():
    # Create and validate a valid JSON input
    json_in = '{"foo": "bar", "baz": 5, "qux": 1.23456789, "quux": true, "corge": false, "grault": null}'
    validator = {
        "foo": Field(type="string"),
        "baz": Field(type="integer"),
        "qux": Field(type="number"),
        "quux": Field(type="boolean"),
        "corge": Field(type="boolean"),
        "grault": Field(type="null"),
    }

    value, error_messages = validate_json(json_in, validator)

# Generated at 2022-06-24 11:20:33.625218
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    Test to ensure the object is of the correct type
    """
    decoder = _TokenizingDecoder("{}", content="{}")
    result = decoder.scan_once("\n", 0)
    assert type(result[0]) is DictToken
    assert result[1] == 1

# Generated at 2022-06-24 11:20:36.323801
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    s = "ab"
    decoder = _TokenizingDecoder(s)
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_string == scanstring
    assert decoder.strict == True
    assert decoder.memo == {}
    assert decoder.scan_once == _make_scanner(decoder, s)

# Generated at 2022-06-24 11:20:44.703818
# Unit test for function validate_json
def test_validate_json():
    # Make sure exception has positional information for parse errors.
    with pytest.raises(ParseError) as exc_info:
        validate_json("[1, 2, 3", int)
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.meta["position"] == Position(column_no=8, line_no=1, char_index=7)

    # Make sure exception has positional information for validation errors.
    with pytest.raises(ValidationError) as exc_info:
        validate_json("[1, 2, 3]", int)
    assert exc_info.value.code == "invalid_type"
    assert exc_info.value.meta["position"] == Position(column_no=1, line_no=1, char_index=0)

    # Make sure invalid