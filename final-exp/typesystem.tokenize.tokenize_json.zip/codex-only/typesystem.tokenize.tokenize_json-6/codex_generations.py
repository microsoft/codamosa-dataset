

# Generated at 2022-06-24 11:10:46.008842
# Unit test for function tokenize_json
def test_tokenize_json():
    data = """{
    "name": "John Smith",
    "age": 27,
    "eye_color": "brown",
    "languages_spoken": [
        "English",
        "French",
        "Spanish"
    ],
    "is_married": false
}"""
    token = tokenize_json(data)
    assert type(token) == DictToken



# Generated at 2022-06-24 11:10:52.668574
# Unit test for function validate_json
def test_validate_json():
    class TestSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)
    schema = TestSchema()

    errors = validate_json(content=b'{"name": "foo", "age": "not and int"}',
                           validator=schema)
    #print(errors)
    assert len(errors) == 1
    assert errors[0].text == "not and int is not of type 'integer'."
    assert errors[0].position.column_no == 27
    assert errors[0].position.line_no == 1
    assert errors[0].position.char_index == 26

# Generated at 2022-06-24 11:11:04.109060
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"x": "y", "z": [{"a": "b"}]}'
    token = tokenize_json(content)
    assert isinstance(token, dict)
    assert isinstance(token["x"], str)
    assert isinstance(token["z"], list)
    assert isinstance(token["z"][0], dict)
    assert isinstance(token["z"][0]["a"], str)
    try:
        token = tokenize_json("")
        assert False
    except ParseError as exc:
        assert exc.text == "No content."
    try:
        token = tokenize_json("{")
        assert False
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."


# Generated at 2022-06-24 11:11:06.480759
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "")

# Generated at 2022-06-24 11:11:11.184704
# Unit test for function validate_json
def test_validate_json():

    schema = Schema(fields={
        "additionalProperties": {"type": "string"},
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "string"},
        },
        "required": ["foo", "bar"],
        "type": "object",
    })

    content = '{"foo": "a", "bar": "b", "extra": "c"}'
    result = validate_json(content, schema)
    assert result[0] == {'foo': 'a', 'bar': 'b', 'extra': 'c'}
    assert result[1].messages == {'additionalProperties': None}

# Generated at 2022-06-24 11:11:22.782271
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:11:33.779109
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:11:45.442123
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('{"foo": "bar"}') == DictToken({'foo': 'bar'}, 0, 15, '{"foo": "bar"}')
    assert tokenize_json('{"foo": {"bar": "baz"}}') == DictToken({'foo': {'bar': 'baz'}}, 0, 25, '{"foo": {"bar": "baz"}}')

# Generated at 2022-06-24 11:11:46.459056
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-24 11:11:49.066732
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "blah"}'
    value = tokenize_json(content)
    assert isinstance(value, Token)
    assert len(value.errors) == 0


# Generated at 2022-06-24 11:11:56.265521
# Unit test for function tokenize_json
def test_tokenize_json():
    test_string = """{"key": "Hello World"}"""
    expected_token = DictToken(
        {"key": ScalarToken(value="Hello World",start=2,end=16,content=test_string)},start=0,end=19,content=test_string)
    assert(expected_token == tokenize_json(test_string))

    test_string = """[{"key": "Hello World"}]"""
    expected_token = ListToken(
        [DictToken({"key": ScalarToken(value="Hello World",start=3,end=17,content=test_string)},start=1,end=20,content=test_string)],start=0,end=21,content=test_string)
    assert(expected_token == tokenize_json(test_string))

    # Test exception handling
    test

# Generated at 2022-06-24 11:12:05.860625
# Unit test for function validate_json
def test_validate_json():
    class UserSchema(Schema):
        username = Field(min_length=1, max_length=10)
        age = Field(cast=int)
    
    data = '{"username": "rater317", "age": 42}'
    expected = ([], {'username': 'rater317', 'age': 42})
    result = validate_json(data, UserSchema())
    assert result == expected
    
    data = '{"username": "l", "age": 42}'

# Generated at 2022-06-24 11:12:15.027546
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.references import Reference

    validator = Field(
        type="string", reference_to=Reference("/schema/Question"),
    )

    content = tokenize_json('{"hello":"world"}')
    content.validate()

    content = tokenize_json('[{"hello":"world"}]')
    content.validate()

    content = tokenize_json('{"hello":"world","goodbye":"world"}')
    content.validate()

    content = tokenize_json('[{"hello":"world"},{"goodbye":"world"}]')
    content.validate()

    content = tokenize_json('{"hello":"world","goodbye":1}')
    with pytest.raises(ValidationError):
        content.validate()

    content = tokenize_json('{"hello":"world","goodbye":1}')

# Generated at 2022-06-24 11:12:21.001620
# Unit test for function validate_json
def test_validate_json():
    json_string = r"""
    {
        "name": "test",
        "value": 123.4,
        "valid": true,
        "nested": {
            "code": "002",
            "data": null
        },
        "items": [
            {
                "name": "John",
                "id": "001"
            },
            {
                "name": "Jane",
                "id": "002"
            }
        ]
    }
    """
    json_string = json_string.strip()

# Generated at 2022-06-24 11:12:23.291949
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        assert _TokenizingDecoder().object_hook
        return True
    except AttributeError:
        return False


# Generated at 2022-06-24 11:12:26.973622
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    s: str = '"12345"'
    decoder = _TokenizingDecoder(content=s)
    assert(decoder.scan_once(s, 0) == ((5, 9), (ScalarToken('12345', 0, 6, s), 9)))


# Generated at 2022-06-24 11:12:35.215126
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == {'a': 1}
    assert tokenize_json('{"a": 1}') == {'a': 1}
    assert tokenize_json('{ "a":1 }') == {'a': 1}
    assert tokenize_json('[{"b":2},{"b":2}]') == [{'b': 2}, {'b': 2}]
    assert tokenize_json('[{"b": 2},{"b":2}]') == [{'b': 2}, {'b': 2}]
    assert tokenize_json('[ { "b":2 },{ "b":2 } ]') == [{'b': 2}, {'b': 2}]

# Generated at 2022-06-24 11:12:40.018811
# Unit test for function validate_json
def test_validate_json():
    from typesystem.tests.test_fields import PersonSchema
    from typesystem.tests.test_schemas import UserSchema

    class CompositeSchema(Schema):
        user = UserSchema(required=True)
        person = PersonSchema(required=True)

    content = """
        {
          "user": {
            "username": "jane",
            "email": "jane@example.com",
            "password": "secret"
          },
          "person": {
            "username": "jane",
            "email": "jane@example.com",
            "password": "secret"
          }
        }
    """
    value, messages = validate_json(content, CompositeSchema)
    assert value is None
    assert len(messages) == 5

# Generated at 2022-06-24 11:12:43.586359
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"key": "value"}
    assert token.start_pos == (1, 2)
    assert token.end_pos == (1, 16)



# Generated at 2022-06-24 11:12:54.846102
# Unit test for function tokenize_json
def test_tokenize_json():

    assert tokenize_json("") == {}
    assert tokenize_json("{}") == {}
    assert tokenize_json("[]") == []
    assert tokenize_json("null") == {}
    assert tokenize_json('"foo"') == "foo"
    #assert tokenize_json("0") == 0
    assert tokenize_json("123") == 123
    assert tokenize_json("-123") == -123
    assert tokenize_json("1.23") == 1.23
    assert tokenize_json("-1.23") == -1.23
    assert tokenize_json("1e23") == 1e23
    assert tokenize_json("-1e23") == -1e23
    assert tokenize_json("1.2e3") == 1.2e3

# Generated at 2022-06-24 11:13:00.411501
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    validator = Field(name="name", primitive_type=str, required=True)
    content = '{"name":"Hello"}'
    token = tokenize_json(content)
    assert_token = DictToken(
        {ScalarToken("Hello", 9, 14, content): ScalarToken("name", 2, 6, content)},
        0, 16,
        content)
    assert token == assert_token
    result = validate_with_positions(token=token, validator=validator)
    assert result[0] == {"name": "Hello"}
    assert result[1] == []

# Generated at 2022-06-24 11:13:07.971351
# Unit test for function validate_json
def test_validate_json():
    validator = String(max_length=5)
    content = '{"a": "short string"}'
    value, error_messages = validate_json(content, validator)
    assert value['a'] == "short string"
    assert len(error_messages) == 0
    content = '{"a": "long string"}'
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1
    assert "a" in error_messages
    assert "maximum length" in error_messages["a"].as_json()

if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-24 11:13:13.623662
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # validate the constructor of _TokenizingDecoder
    decoder = _TokenizingDecoder()

    assert decoder.parse_float('1.1') == 1.1
    assert decoder.parse_int('1') == 1
    assert decoder.strict == True
    assert decoder.parse_array((None, None)) == []
    assert isinstance(decoder.memo, dict)


# Generated at 2022-06-24 11:13:23.950740
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert repr(_TokenizingDecoder()) == """\
{}"""
    assert repr(_TokenizingDecoder({})) == """\
{}"""
    assert repr(_TokenizingDecoder({}, {})) == """\
{{}, {}}"""
    assert repr(_TokenizingDecoder({}, object_hook={})) == """\
{{}, object_hook={}}"""
    assert repr(_TokenizingDecoder({}, parse_float={})) == """\
{{}, parse_float={}}"""
    assert repr(_TokenizingDecoder({}, parse_int={})) == """\
{{}, parse_int={}}"""
    assert repr(_TokenizingDecoder({}, parse_constant={})) == """\
{{}, parse_constant={}}"""

# Generated at 2022-06-24 11:13:25.026935
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    is_instance(_TokenizingDecoder(), _TokenizingDecoder)
 

# Generated at 2022-06-24 11:13:25.987349
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '"string"'
    decoder = _TokenizingDecoder(content=content)

    assert decoder.content == content

# Generated at 2022-06-24 11:13:34.182839
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    field = String()
    schema = Schema(fields={'foo': field})
    value, errors = validate_json('{"foo": "bar"}', schema)
    assert value == {'foo': "bar"}
    assert errors == []
    value, errors = validate_json('{"foo": 1 }', schema)
    assert value is None
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.value == 1
    assert error.path == ["foo"]
    assert error.position.line_no == 1
    assert error.position.column_no == 7

# Generated at 2022-06-24 11:13:37.389243
# Unit test for function validate_json
def test_validate_json():
    from typesystem.types import String

    content = '{"name":"Donald Knuth","age":84}'
    result = validate_json(content, String(required=True))
    content = '[]'
    result1 = validate_json(content, String(required=True))
    assert isinstance(result, typing.Tuple)  # noqa
    assert isinstance(result1, typing.Tuple)  # noqa

# Generated at 2022-06-24 11:13:43.320949
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tests.utils import TestCase

    class TestSchema(Schema):
        value = String()
        position = Integer()

    class TestTokenizer(TestCase):
        def test_success(self):
            data = TestSchema.validate({"value": "x", "position": 1})
            token = tokenize_json(TestSchema.dump(data))
            validator = TestSchema()
            value, error_messages = validate_with_positions(
                token=token, validator=validator
            )
            assert isinstance(value, dict)
            assert value == data
            assert error_messages == []

        def test_parse_error(self):
            token = tokenize_

# Generated at 2022-06-24 11:13:55.905855
# Unit test for function tokenize_json
def test_tokenize_json():
    from unittest import TestCase
    from unittest.mock import patch

    from typesystem.exceptions import ParseError as TypeSystemParseError
    from typesystem.tokenize.tokens import (
        DictToken,
        ListToken,
        ScalarToken,
    )

    class DecodeError(JSONDecodeError):
        """
        A hack to make sure that we can still test the proper error case
        even though we're not calling json.loads.
        """
        pass

    class TestTokenizingJSONObject:
        def test_empty_object(self):
            s = "{}"
            end = 1

# Generated at 2022-06-24 11:14:05.917000
# Unit test for function validate_json
def test_validate_json():
    content = '{ "name":"John", "age":30, "address":[{"city":"New York"},{"city":"Los Angeles"}]}'
    schema = {"age": {"type": "integer"}}
    value, errors = validate_json(content, schema)
    assert value["age"] == 30
    assert not errors
    content = '{ "name":"John", "age":"30", "address":[{"city":"New York"},{"city":"Los Angeles"}]}'
    value, errors = validate_json(content, schema)
    assert errors[0].text == "Must be of type 'integer'."
    assert errors[0].position.column_no == 8
    assert errors[0].position.line_no == 1



# Generated at 2022-06-24 11:14:07.595687
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(content="test_content").scan_once, typing.Callable)



# Generated at 2022-06-24 11:14:12.286362
# Unit test for function validate_json
def test_validate_json():
    content = "{\"foo\": \"bar\"}"
    validator = Schema({"foo": str})
    value, errors = validate_json(content, validator)
    assert value == {"foo": "bar"}
    assert not errors

# Generated at 2022-06-24 11:14:13.651182
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder('test.json') != None


# Generated at 2022-06-24 11:14:24.156362
# Unit test for function validate_json
def test_validate_json():

    validator = Field(type="string")

    value, errors = validate_json(b"test", validator)
    assert value == "test"
    assert not errors

    value, errors = validate_json(b'{"name": "test"}', Field(type="string"))
    assert value is None
    assert len(errors) == 1
    error = errors[0]
    assert error.code == "invalid_type"
    assert error.text == "Expected a string value."
    assert error.position.line_no == 1
    assert error.position.column_no == 1
    assert error.position.char_index == 0

    value, errors = validate_json(b"null", Field(type="string"))
    assert value is None
    assert len(errors) == 1
    error = errors[0]

# Generated at 2022-06-24 11:14:32.561369
# Unit test for function tokenize_json
def test_tokenize_json():
    content_data = """
    {
    "test": [1, 2, 3]
    }
    """
    json_token = tokenize_json(content_data)
    # Test dictionary
    assert isinstance(json_token, DictToken)
    # Test the content of dictionary
    assert isinstance(json_token.dictionary["test"], ListToken)
    # Test the content of list
    assert isinstance(json_token.dictionary["test"].list[0], ScalarToken)

    # Test ScalarToken
    assert json_token.dictionary["test"].list[0].scalar == 1
    # Test Position
    assert json_token.position.column_no == 1
    assert json_token.dictionary["test"].position.column_no == 6

    # Test ParseError

# Generated at 2022-06-24 11:14:33.455327
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content='test_content')

# Generated at 2022-06-24 11:14:42.244739
# Unit test for function validate_json
def test_validate_json():
    import pytest
    from typesystem import parse, types
    name = types.String(max_length=10)
    age = types.Integer()
    schema = types.Schema(name=name, age=age)
    data = parse('{"name": "Joe", "age": 12}', schema)
    assert data == {"name": "Joe", "age": 12}
    with pytest.raises(ValidationError) as exc:
        parse('{"name": "Joe", "age": "twelve"}', schema)

# Generated at 2022-06-24 11:14:53.188500
# Unit test for function tokenize_json
def test_tokenize_json():
    # Parse a scalar value
    tokenize_json('"foo"')
    # Parse a simple object
    tokenize_json('{"foo": "bar"}')
    # Parse a nested object
    tokenize_json('{"foo": {"bar": "baz"}}')
    # Parse a list
    tokenize_json('["foo", "bar", "baz"]')
    # Parse a nested list
    tokenize_json('["foo", ["bar", "baz"]]')
    # Parse a mixed object and list
    tokenize_json('[{"foo": "bar"}, {"baz": "qux"}]')
    # Parse an empty object
    tokenize_json('{}')
    # Parse an empty list
    tokenize_json('[]')
    # Parse a null
    token

# Generated at 2022-06-24 11:14:59.153892
# Unit test for function tokenize_json
def test_tokenize_json():
    test_data = '{"name": "ryan", "age": "27"}'
    t = tokenize_json(test_data)
    assert isinstance(t, DictToken)
    assert t.value['name'].value == 'ryan'
    assert t.value['age'].value == '27'



# Generated at 2022-06-24 11:15:03.484587
# Unit test for function validate_json
def test_validate_json():
    field = Field(name="root")
    value, errors = validate_json("", field)
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].position.char_index == 0

test_validate_json()



# Generated at 2022-06-24 11:15:08.231611
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="object")
    assert decoder.scan_once("string", 0) == (ScalarToken(value="string", start=0, end=6, content="object"), 7)


# Generated at 2022-06-24 11:15:10.480232
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenize_json(content="{}")
    decoder = _TokenizingDecoder(content="test")
    assert(decoder.content == "test")

# Generated at 2022-06-24 11:15:12.007464
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert JSONDecodeError.__name__ == "_TokenizingDecoder"

# Generated at 2022-06-24 11:15:14.246895
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 3, "b": "foo"}')
    assert token.as_dict() == {"a": 3, "b": "foo"}


# Generated at 2022-06-24 11:15:24.749760
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    import sys
    import os
    import typesystem.tokenize.tokenizer as tokenizer
    if sys.version_info >= (3, 5):
        with open(os.path.dirname(tokenizer.__file__) + '/test_json/test_json_parser_python35.json',encoding='utf-8') as f:
            decoded = json.load(f)
    elif sys.version_info >= (3, 4):
        with open(os.path.dirname(tokenizer.__file__) + '/test_json/test_json_parser_python34.json',encoding='utf-8') as f:
            decoded = json.load(f)

# Generated at 2022-06-24 11:15:34.926120
# Unit test for function tokenize_json
def test_tokenize_json():
    # test parsing
    token = tokenize_json("[1, 2]")
    assert isinstance(token, ListToken)
    assert token.value == [1, 2]
    assert token.start_char_index == 0
    assert token.end_char_index == 5

    token = tokenize_json("[1, true, null]")
    assert isinstance(token, ListToken)
    assert token.value == [1, True, None]
    assert token.start_char_index == 0
    assert token.end_char_index == 14

    token = tokenize_json("{\"a\": true, \"b\": null}")
    assert isinstance(token, DictToken)
    assert token.value == {"a": True, "b": None}
    assert token.start_char_index == 0

# Generated at 2022-06-24 11:15:44.227594
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '''
    {
        "a": "b",
        "b": "c",
        "c": [
            {
                "d": "e"
            }
        ]
    }
'''
    expected = DictToken(
        {
            ScalarToken("a", 5, 6, json): ScalarToken("b", 9, 10, json),
            ScalarToken("b", 13, 14, json): ScalarToken("c", 17, 18, json),
            ScalarToken("c", 21, 22, json): ListToken(
                [
                    DictToken(
                        {ScalarToken("d", 42, 43, json): ScalarToken("e", 46, 47, json)}
                    )
                ]
            ),
        }
    )
    result = tokenize_json(json)

# Generated at 2022-06-24 11:15:53.161243
# Unit test for function validate_json
def test_validate_json():
    # Valid data, valid field
    data = '{"field":"data"}'
    field = Field(type="string")
    value, errors = validate_json(data, field)
    assert value == {"field": "data"}
    assert len(errors) == 0

    # Valid data, invalid field
    data = '{"field":"data"}'
    field = Field(type="integer")
    value, errors = validate_json(data, field)
    assert value == {"field": "data"}
    assert len(errors) == 1
    assert type(errors[0]) == ValidationError
    assert errors[0].position.char_index == 7
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 8
    assert errors[0].text == "is not an integer"
    assert errors

# Generated at 2022-06-24 11:15:58.761378
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken

    class UserSchema(Schema):
        email = String(max_length=250)
        age = Integer(minimum=0)
    content = """
        {"email": "james@example.com", "age": 20}
        """
    token = tokenize_json(content)  # type: DictToken
    success, errors = validate_json(content=content, validator=UserSchema)
    assert success == {"email": "james@example.com", "age": 20}

# Generated at 2022-06-24 11:16:09.368024
# Unit test for function validate_json
def test_validate_json():
    # Setup classes for validator
    class DummyField(Field):
        def validate(self, value):
            if value != "hello":
                raise ValidationError()

    class DummySchema(Schema):
        field = DummyField()

    # No content validation error
    no_content_validation_error = ParseError(
        text="No content", code="no_content", position=Position(column_no=1, line_no=1, char_index=0)
    )
    assert validate_json() == ([no_content_validation_error], None)

    # Parse error
    parse_error = ParseError(
        text="Expecting value", code="parse_error", position=Position(column_no=1, line_no=1, char_index='""')
    )
    assert validate_

# Generated at 2022-06-24 11:16:17.093010
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:16:27.102791
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content='{"name":"abc","age":20,"degrees":{"ed1":"abc","ed2":"def"}}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content,0) == (DictToken({'name': ScalarToken('abc', 6, 9, content), 'age': ScalarToken(20, 13, 15, content), 'degrees': DictToken({'ed1': ScalarToken('abc', 30, 33, content), 'ed2': ScalarToken('def', 37, 40, content)}, 23, 40, content)}, 1, 40, content), 41)

# Generated at 2022-06-24 11:16:30.375174
# Unit test for function validate_json
def test_validate_json():
    token = tokenize_json("[1, 2, 3, 4]")
    value, errors = validate_json(token, "array[int]")
    assert not errors
    assert value == [1, 2, 3, 4]


# Generated at 2022-06-24 11:16:37.643570
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    class MySchema(Schema):
        name = String()
        age = Integer()

    validator = MySchema()

    content = b'{"name": "Joe", "age": 22}'
    value, errors = validate_json(content, validator)
    assert value == {'name': 'Joe', 'age': 22}
    assert not errors

    content = b'{"name": "Joe"}'
    value, errors = validate_json(content, validator)
    assert errors[0].code == 'required'
    assert errors[0].position.path == ['age']

    content = b'{"name": "Joe", "age": "22"}'
    value, errors = validate_json(content, validator)

# Generated at 2022-06-24 11:16:44.683088
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"b": true, "a": null, "c": 3.1415, "d": ["foo", 234]}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.parse_int == int
    assert decoder.parse_float == float
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_object == JSONDecoder.parse_object
    assert decoder.parse_string == JSONDecoder.parse_string
    assert decoder.strict == True

# Generated at 2022-06-24 11:16:47.323432
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__

# Generated at 2022-06-24 11:16:49.197688
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.content == "test"

# Generated at 2022-06-24 11:17:00.763484
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.positional_validation import (
        _TokenizingDecoder,
    )
    import json
    import typesystem

    decoder = _TokenizingDecoder("{}", object_pairs_hook=json.loads, content="{}")
    assert decoder.scan_once("{}", 0) == (
        DictToken({}, 0, 1, "{" "}"),
        2,
    )
    decoder = _TokenizingDecoder(
        "[1]", object_pairs_hook=json.loads, content="[1]"
    )
    assert decoder.scan_once("[1]", 0) == (ListToken([1], 0, 2, "[1]"), 3)

# Generated at 2022-06-24 11:17:03.430215
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(parse_float=str, parse_int=str, content="")
    assert decoder.parse_float == str
    assert decoder.parse_int == str



# Generated at 2022-06-24 11:17:08.159589
# Unit test for function validate_json
def test_validate_json():
    class SimpleSchema(Schema):
        title = "Simple"
        name = Field(type="string")

    content = '{"name": "foo"}'
    value, errors = validate_json(content, SimpleSchema)

    assert value == {"name": "foo"}
    assert not errors



# Generated at 2022-06-24 11:17:12.939400
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("""{"key": "value"}""")
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")
    with pytest.raises(ParseError, match="Expecting value"):
        tokenize_json("""{"key":}""")


# Unit tests for function validate_json

# Generated at 2022-06-24 11:17:14.517323
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder
    assert _TokenizingDecoder(content="")


# Generated at 2022-06-24 11:17:24.070948
# Unit test for function validate_json
def test_validate_json():
    field = Field(primitive_type=str, required=False)
    validator = Schema(properties={"test": field})

    message_list = validate_json(content=b'{"test": "test"}', validator=validator)
    assert message_list == ([], {"test": "test"})

    message_list = validate_json(content=b'{"test": 1}', validator=validator)
    message = message_list[0][0]
    assert isinstance(message, ValidationError)
    assert message.position.char_index == 9

    message_list = validate_json(content=b'{"test": 1}', validator=field)
    message = message_list[0][0]
    assert isinstance(message, ValidationError)
    assert message.position.char_index == 7

   

# Generated at 2022-06-24 11:17:35.464106
# Unit test for function validate_json
def test_validate_json():
    """
    Tests the function validate_json

    Cases:
    - Validation passes if json string is valid
    - Validation fails if json string is invalid
    - Parse error is raised if json can't be parsed
    """
    # Test passes
    json = '{"title": "check", "name":"the", "age": 22}'
    content = bytes(json, 'utf-8')
    validator = Schema([
        Field(name="title", type="string", required=True),
        Field(name="name", type="string", required=True),
        Field(name="age", type="integer", required=True),
    ])

    value, error_messages = validate_json(content, validator)
    assert error_messages == []

# Generated at 2022-06-24 11:17:38.389846
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="{}")
    assert decoder.scan_once("{}", 0) == (DictToken({}, 0, 1, "{}"), 2)

# Generated at 2022-06-24 11:17:46.696405
# Unit test for function validate_json
def test_validate_json():
    # Test '{"foo": 4}'
    schema = Schema(properties={"foo": Field(minimum=0)})
    result = validate_json(content=b'{"foo":4}', validator=schema)
    assert result.error_messages is None
    assert result.value == {"foo": 4}
    # Test '{"foo": -4}'
    with pytest.raises(ValidationError) as exc:
        result = validate_json(content=b'{"foo": -4}', validator=schema)
    assert result is None
    assert exc.value.error_messages == []
    # Test '{"foo": 4, "bar": "baz"}'

# Generated at 2022-06-24 11:17:56.897955
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"x": "y"}') == {'x': 'y'}
    assert tokenize_json('{"x": {"y": "z"}}') == {'x': {'y': 'z'}}

    # Inline comments
    assert tokenize_json('{"x": /* comment */ "y"}') == {'x': 'y'}

    # Multi-line comments
    assert tokenize_json('{"a": "b", /* comment */ "c": "d"}') == {'a': 'b', 'c': 'd'}

    # Comments must be closed before EOF
    with pytest.raises(ParseError):
        tokenize_json('{"x": "y" /* comment')

    # Extra commas are allowed at the end of lists

# Generated at 2022-06-24 11:18:05.326557
# Unit test for function validate_json
def test_validate_json():
    # Good JSON string
    content = b'{"a":["2", 3, 4]}'
    validator = {"a": [str, int, int]}
    value, error_messages = validate_json(content, validator)
    assert value == {"a": ["2", 3, 4]}
    assert error_messages == []

    # Bad JSON string
    content = b'{"a":["3", 4, 5]}'
    validator = {"a": [str, int, int]}
    value, error_messages = validate_json(content, validator)
    assert value == {"a": ["3", 4, 5]}
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 4

    # Bad JSON string

# Generated at 2022-06-24 11:18:11.521718
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = JSONDecoder()
    b = _TokenizingDecoder(content="")
    assert a.parse_array  ==  b.parse_array
    assert a.parse_float  ==  b.parse_float
    assert a.parse_int  ==  b.parse_int
    assert a.parse_string  ==  b.parse_string


# Unit tests for _make_scanner

# Generated at 2022-06-24 11:18:12.471521
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass


# Generated at 2022-06-24 11:18:16.254129
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    print("test__TokenizingDecoder")
    test_json = '{"a": 1, "b": 2, "c": 3}'
    decoder = _TokenizingDecoder(content=test_json)
    assert(decoder.scan_once)
    print("test__TokenizingDecoder passed")


# Generated at 2022-06-24 11:18:18.794966
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None


# Generated at 2022-06-24 11:18:19.460543
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert True

# Generated at 2022-06-24 11:18:20.879474
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="test content") is not None


# Generated at 2022-06-24 11:18:29.399230
# Unit test for function validate_json
def test_validate_json():
    # A valid JSON string
    content = '{"a": 3, "b": [1, 2, 3, 4]}'
    # JSON schema to validate against
    validator = Schema({"a": int, "b": [int]})
    # Parse and validate the JSON string with validate_json
    validated_tuple = validate_json(content, validator)
    # Check that the first element of the tuple is the validated object
    assert validated_tuple[0] == {"a": 3, "b": [1, 2, 3, 4]}
    # Check that the second element of the tuple is an empty messages list
    assert validated_tuple[1] == []

# Generated at 2022-06-24 11:18:31.762804
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        decoder = _TokenizingDecoder(content="")
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 11:18:37.692635
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    This tests the constructor of the class _TokenizingDecoder.
    """
    with pytest.raises(TypeError):
        _TokenizingDecoder.__init__(
            s_and_end="", strict=True, scan_once="", memo="", content=""
        )
    decoder = _TokenizingDecoder(s_and_end=[""], strict=True)
    type(decoder.scan_once)



# Generated at 2022-06-24 11:18:45.343152
# Unit test for function tokenize_json
def test_tokenize_json():
    json1 = '{"int": 1, "float": 1.0, "string": "foo"}'
    json2 = '{"bool": true, "null": null, "list": [1,2,3]}'
    token1 = tokenize_json(json1)
    token2 = tokenize_json(json2)
    assert isinstance(token1, DictToken)
    assert isinstance(token2, DictToken)
    assert token1.value['int'] == ScalarToken('1', 10, 10, json1)
    assert token1.value['float'] == ScalarToken('1.0', 21, 23, json1)
    assert token1.value['string'] == ScalarToken('foo', 34, 37, json1)

# Generated at 2022-06-24 11:18:46.996919
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="foo").scan_once

# Generated at 2022-06-24 11:18:48.964103
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert(isinstance(decoder, JSONDecoder))


# Generated at 2022-06-24 11:19:00.054203
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": {"b": ["c", null, false]}}'
    schema = Schema({"a": {"b": Field.list(items=Field.union(of=[str, int, bool]))}})

    error_messages = validate_json(content, schema)
    assert error_messages == []

    content = '{"a": {"b": "c"}}'
    schema = Schema({"a": {"b": Field.list(items=Field.union(of=[str, int, bool]))}})

    error_messages = validate_json(content, schema)
    assert [] == error_messages

    content = '{"a": {"b": ["c", 5, false]}}'

# Generated at 2022-06-24 11:19:11.207773
# Unit test for function validate_json
def test_validate_json():
    result = validate_json(b'{"test_value": 123, "test_value2": "hello world"}', Schema)
    assert len(result[1]) == 0
    result = validate_json(b'{"test_value": 123, "test_value2": "hello world"}', Field)
    assert len(result[1]) == 1
    assert result[1][0].code == 'invalid_schema'
    result = validate_json(b'{"test_value": "123", "test_value2": "hello world"}', Schema)
    assert len(result[1]) == 1
    assert result[1][0].code == 'invalid_type'

# Generated at 2022-06-24 11:19:12.396858
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    print(repr(_TokenizingDecoder))


# Generated at 2022-06-24 11:19:15.424678
# Unit test for function validate_json
def test_validate_json():
    content = '{"a":1}'
    validator = Schema({'a': int})
    validate_json(content=content, validator=validator)

# Generated at 2022-06-24 11:19:18.167594
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.scan_once("", 0) == None



# Generated at 2022-06-24 11:19:22.778958
# Unit test for function tokenize_json
def test_tokenize_json():
    assert type(tokenize_json('{"a": "b"}')) == DictToken
    assert type(tokenize_json('["b"]')) == ListToken
    with pytest.raises(ParseError):
        tokenize_json('')


# Generated at 2022-06-24 11:19:32.770257
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.schemas import Schema
    from typesystem.schemas.components import BaseComponent
    from typesystem.components import Object, String
    from typing import cast

    class Post(BaseComponent):
        title = String()

    class Posts(BaseComponent):
        posts = Object(Post)

    json_string = '{"posts": {"title": "Hello, World!"}}'
    schema = Posts()
    schema = cast(Schema, schema)
    post = tokenize_json(json_string)

    # Checking if tokenized JSON is empty
    assert post is not None

    # Checking if tokenized JSON contains all the attributes
    assert post.get("posts").get("title").text == "Hello, World!"

    # Checking if JSON is valid and raise an error if not

# Generated at 2022-06-24 11:19:41.463568
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.tests import TestSchema
    from typesystem.fields import Integer

    schema = TestSchema()
    schema.add_fields(
        {"age": Integer(maximum=100), "name": Integer()}
    )
    data = json.dumps({'age': 32, 'name': 'John'})
    (validated_data, errors) = validate_json(data, schema)
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 8
    assert errors[0].position.char_index == 7

    data = json.dumps({'age': 99})
    (validated_data, errors) = validate_json(data, schema)
    assert len(errors) == 1
    assert errors[0].position.line_no == 1
   

# Generated at 2022-06-24 11:19:52.034020
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""{"a":1}""") == DictToken({'a': ScalarToken(1, 3, 3, '{"a":1}')}, 0, 5, '{"a":1}')
    assert tokenize_json("""{}""") == DictToken({}, 0, 1, '{}')
    assert tokenize_json("""{"a":true}""") == DictToken({'a': ScalarToken(True, 3, 7, '{"a":true}')}, 0, 9, '{"a":true}')
    assert tokenize_json("""{"a":false}""") == DictToken({'a': ScalarToken(False, 3, 8, '{"a":false}')}, 0, 10, '{"a":false}')

# Generated at 2022-06-24 11:19:56.707551
# Unit test for function validate_json
def test_validate_json():
    schema = Field(name="test", type="string")
    content = '{"test": "good", "test2": "bad"}'
    value, errs = validate_json(content, schema)
    assert value == "good"
    assert errs.messages[0].text == "Field 'test2' is not valid."
    assert errs.messages[0].position.char_index == 19

# Generated at 2022-06-24 11:19:59.695762
# Unit test for function tokenize_json
def test_tokenize_json():
    f = open("./uploads/graph.json")
    content = f.read()
    token = tokenize_json(content)
    assert True # If execution reaches this point then test passes

# Generated at 2022-06-24 11:20:08.032900
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(properties={"number": Field(number=True)})
    content = '{"number": "2"}'
    token = tokenize_json(content)
    value, errors = validate_json(content=content, validator=schema)
    assert errors[0].text == "number is not a number."
    assert errors[0].code == "not_number"
    assert errors[0].position.char_index == 15
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 16
    assert value["number"] == "2"

# Generated at 2022-06-24 11:20:10.275549
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.scan_once == _make_scanner(decoder, "test")
    assert decoder.parse_object == _TokenizingJSONObject


# Generated at 2022-06-24 11:20:18.340433
# Unit test for function validate_json
def test_validate_json():
    valid_json = """{"name":"Jane Doe","profile":{"email":"jane@doe.com"},"typesystem": { "age":42 }}"""
    invalid_json = """{"name":"Jane Doe","profile":{"email":"jane@doe.com"},"typesystem": { "age":"forty two" }}"""
    assert validate_json(valid_json, validator=User) == (None, None)
    assert validate_json(invalid_json, validator=User) != (None, None)

    errors = validate_json(invalid_json, validator=User)
    assert isinstance(errors, tuple)
    assert isinstance(errors[0], typing.List)
    assert isinstance(errors[1], typing.List)
    assert len(errors[0]) == 0
    assert len(errors[1]) == 2
    assert errors

# Generated at 2022-06-24 11:20:28.179792
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import IntegerField
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import validate_with_positions

    class TestSchema(Schema):
        age = IntegerField(description="Age")
        name = IntegerField(description='Name', required=False)

    failure_cases = [
        ('', 'invalid_json', 'ParseError', ParseError),
        ('{"age": "invalid"}', 'invalid_type', 'ValidationError', ValidationError),
    ]

    for failure_case in failure_cases:
        value, expected_code, expected_text, exception_class = failure_case
        try:
            validate_json(value, TestSchema)
        except exception_class as exception:
            message = exception.messages[0]

# Generated at 2022-06-24 11:20:36.329685
# Unit test for function validate_json
def test_validate_json():
    content = """
[
    {"name": "First Schema", "age": 10},
    {"name": "First Schema", "age": "12"},
    {"name": "First Schema", "age": -10}
]"""
    validator = Schema(name=str, age=int)
    tokens, error_messages = validate_json(content=content, validator=validator)
    assert len(error_messages) == 1
    assert error_messages[0].position.column_no == 27

# Generated at 2022-06-24 11:20:40.026701
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder(): # type: () -> None
    """
    Test of constructor of class _TokenizingDecoder.
    """
    decoder = _TokenizingDecoder(content="Test String")
    assert decoder.scan_once == _make_scanner(decoder, "Test String")