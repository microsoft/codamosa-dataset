

# Generated at 2022-06-24 11:10:46.701387
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"test\":{\"test2\":{\"test3\":\"1990-11-13\"},\"test2\":1.0}}"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once == _make_scanner(decoder, content)


# Generated at 2022-06-24 11:10:49.312002
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    output = _TokenizingDecoder('{}').decode('{}')
    expected_output = DictToken({}, 1, 1, "{}")
    assert output == expected_output



# Generated at 2022-06-24 11:10:53.769567
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json.
    """
    from typesystem.types import String

    results = validate_json(
        b'\n  {  "foo": "bar"  }\n   ',
        Schema({"foo": String()}),
    )
    value, error_messages = results
    assert value == {"foo": "bar"}
    assert not error_messages



# Generated at 2022-06-24 11:11:02.010247
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_tokenizer = _TokenizingDecoder(content='{"foo": "bar"}')
    assert test_tokenizer.scan_once('{"foo": "bar"}', 0) == (DictToken({
        ScalarToken('foo', 1, 3, '{"foo": "bar"}'): ScalarToken('bar', 8, 11, '{"foo": "bar"}')
    }, 0, 11, '{"foo": "bar"}'), 12)

if __name__ == "__main__":
    test__TokenizingDecoder()

# Generated at 2022-06-24 11:11:06.248585
# Unit test for function validate_json
def test_validate_json():
    import os
    import json
    import unittest
    from typesystem import types

    class AnimalSchema(Schema):
        name = types.String()
        age = types.Number()

    class PersonSchema(Schema):
        address = types.String()
        domestic_animal = AnimalSchema()

    validator = PersonSchema()

    class TestValidationJSON(unittest.TestCase):
        def test_validate_json(self):
            json_content = '{"address": "London", "domestic_animal": {"name": "Bruno", "age": 3.2}}'
            try:
                result = validate_json(json_content, validator)
                print(result)
            except ValidationError as err:
                print(err.messages)

# Generated at 2022-06-24 11:11:15.278667
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{}'), Token)
    assert isinstance(tokenize_json('""'), Token)
    assert isinstance(tokenize_json('1'), Token)
    assert isinstance(tokenize_json('"abc"'), Token)
    assert isinstance(tokenize_json('[1, 2, 3]'), Token)
    assert isinstance(tokenize_json('{"a": 1}'), Token)
    with pytest.raises(ParseError) as err:
        tokenize_json("{")
    assert err.value.code == "parse_error"
    with pytest.raises(ParseError) as err:
        tokenize_json("[1, 2")
    assert err.value.code == "parse_error"

# Generated at 2022-06-24 11:11:26.708759
# Unit test for function validate_json
def test_validate_json():
    import typesystem

    class Company(typesystem.Schema):
        id = typesystem.Integer()
        name = typesystem.String()
        url = typesystem.String()

    class User(typesystem.Schema):
        id = typesystem.Integer()
        email = typesystem.String()
        profile = typesystem.Object(properties={"age": typesystem.Integer()})
        company = typesystem.Object(properties={"company": Company})
        roles = typesystem.Array(items=typesystem.String())


# Generated at 2022-06-24 11:11:28.376400
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(isinstance(_TokenizingDecoder(content = "test").scan_once("test", 1), typing.Tuple))



# Generated at 2022-06-24 11:11:29.218150
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content='')

# Generated at 2022-06-24 11:11:32.263905
# Unit test for function validate_json
def test_validate_json():
    from typesystem.types import String, Integer
    from typesystem.fields import Array


    schema = Array(items=String)
    validate_json([1, 2, 3], schema)



# Generated at 2022-06-24 11:11:39.721717
# Unit test for function validate_json
def test_validate_json():
    def validate_result(result, expected_value, expected_error_messages):
        assert expected_value == result.value
        assert expected_error_messages == result.message_list

    schema = Schema(
        fields={
            "name": Field(required=True, max_length=10),
            "age": Field(type="integer", min_value=0, max_value=99),
            "siblings": ListField(
                item_field=Field(type="integer", min_value=0, max_value=99),
            ),
        }
    )
    valid_content = b'{"name": "John", "age": 30, "siblings": [1, 2, 3]}'

# Generated at 2022-06-24 11:11:50.346755
# Unit test for function validate_json
def test_validate_json():
    # Test that valid JSON parses.
    (value, messages) = validate_json('{"a": 1, "b": 2}', Schema)
    assert len(messages) == 0
    assert value == {"a": 1, "b": 2}

    # Test that invalid JSON does not parse.
    (value, messages) = validate_json('{"a": 1, "b": 2,}', Schema)
    assert len(messages) == 1
    assert messages[0].code == "parse_error"

    # Test that invalid JSON parses and then fails to validate.
    (value, messages) = validate_json('{"a": "one", "b": "two"}', Schema)
    assert len(messages) == 2
    assert messages[0].code == "required_field"

# Generated at 2022-06-24 11:12:00.812516
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "b", "c": "d"}')
    assert isinstance(token, DictToken)
    assert token.value["c"] == "d"
    assert token.line_no == 1
    assert token.column_no == 1
    assert token.end_line_no == 1
    assert token.end_column_no == 17
    assert token.char_index == 0
    assert token.end_char_index == 16
    assert token.sub_tokens[0][0].value == "a"
    assert token.sub_tokens[0][0].line_no == 1
    assert token.sub_tokens[0][0].column_no == 2
    assert token.sub_tokens[0][0].end_line_no == 1

# Generated at 2022-06-24 11:12:08.878507
# Unit test for function validate_json
def test_validate_json():
    response = validate_json("""
    [
        {"name": "Joe", "age": "one hundred"},
        {"name": "Jane", "age": "twenty"}
    ]
    """, [
        {"name": str, "age": int}
    ])

# Generated at 2022-06-24 11:12:12.441546
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        decoder = _TokenizingDecoder("Test content")
    except TypeError as e:
        assert True
    #except Exception as e:
    #    assert False


# Generated at 2022-06-24 11:12:21.554975
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("""
    [
      {
        "item1": "test1"
      },
      {
        "item2": "test2",
        "item3": "test3"
      }
    ]
    """)
    assert isinstance(token, ListToken)
    assert len(token.value) == 2
    assert isinstance(token.value[0], DictToken)
    assert len(token.value[0].value) == 1
    assert isinstance(token.value[0].value["item1"], ScalarToken)
    assert token.value[0].value["item1"].value == "test1"
    assert isinstance(token.value[1], DictToken)
    assert len(token.value[1].value) == 2

# Generated at 2022-06-24 11:12:29.461539
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    class MySchema(typesystem.Schema):
        email = typesystem.String()

    content = '{"email":"invalid_email"}'
    value, messages = validate_json(content, validator=MySchema)

    assert len(messages) == 1
    assert messages[0] is not None
    assert isinstance(messages[0], typesystem.Message)
    assert isinstance(messages[0].code, str)
    assert isinstance(messages[0].position, Position)
    assert isinstance(messages[0].text, str)


# Generated at 2022-06-24 11:12:37.298549
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": [1, "2.2", 3.3, {"four": "4"}, null]}'
    validator_schema = Schema.from_dict(
        {"a": [int, float, {"four": str}, None]}
    )
    validator_field = Field.from_dict({"type": [int, float, {"four": str}, None]})
    value, msg = validate_json(content, validator_schema)
    # assert type(value) is dict
    # assert len(msg) == 0
    # value, msg = validate_json(content, validator_field)
    # assert type(value) is dict
    # assert len(msg) == 0

# Generated at 2022-06-24 11:12:45.995574
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import TokenType

    json_string = '{"name":"Saurav", "age":27, "languages":["English","Hindi"]}'
    token = tokenize_json(json_string)
    assert token.type is TokenType.Dict
    assert len(token.value) == 3
    for key, value in token.value.items():
        assert key == "name" or key == "age" or key == "languages"
        if key == "name":
            assert value.value == "Saurav"
            assert value.type is TokenType.Scalar
        elif key == "age":
            assert value.value == 27
            assert value.type is TokenType.Scalar
        elif key == "languages":
            assert len(value.value) == 2

# Generated at 2022-06-24 11:12:51.618471
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder
    assert decoder.scan_once
    decoder.scan_once(
        '{"entry":{ "id": "2","title": "Example entry","body": "Here is the body","published": true}}', 0
    )
    assert decoder.scan_once


# Generated at 2022-06-24 11:13:02.310760
# Unit test for function validate_json
def test_validate_json():
    content = "[1, 2, 3]"
    validator = Field.list_of(Field.integer())
    assert (validate_json(content, validator) == ([1, 2, 3], []))
    content = "[1, \"2\", 3]"
    assert (validate_json(content, validator) == ([1, '2', 3], []))
    content = "[1, 2, 3, 4]"
    assert (validate_json(content, validator) == ([1, 2, 3, 4], []))
    content = "{\"name\": \"fake-name\", \"age\": 18}"
    validator = Field.dict_of(
        {
            "name": Field.string(),
            "age": Field.integer(),
        }
    )

# Generated at 2022-06-24 11:13:07.720651
# Unit test for function validate_json
def test_validate_json():
    """
    Test that the function validate_json() returns the expected values
    """
    assert validate_json("{}", Schema) == ({}, [])
    assert validate_json("{}", Field) == ({}, [])
    assert validate_json("{}", Field(type=str)) == ({}, [])
    assert validate_json(
        '{"f1": "value1", "f2": "value2"}',
        Schema({"f1": Field(type=str), "f2": Field(type=str)}),
    ) == ({"f1": "value1", "f2": "value2"}, [])

# Generated at 2022-06-24 11:13:12.826072
# Unit test for function tokenize_json
def test_tokenize_json():
    res = tokenize_json('{"a": 1, "b": 2}')
    assert len(res.children) == 2
    assert res.children[0].value == "a"
    assert res.children[0].children[0].value == 1
    assert res.children[1].value == "b"
    assert res.children[1].children[0].value == 2

# Generated at 2022-06-24 11:13:23.388425
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b"{")
    assert token.__class__.__name__ == "DictToken"
    assert token.token_position == (1, 1, 0)
    assert token.text == "{"
    assert token.value == {}

    token = tokenize_json(b"[]")
    assert token.__class__.__name__ == "ListToken"
    assert token.token_position == (1, 1, 0)
    assert token.text == "[]"
    assert token.value == []

    token = tokenize_json(b"[1, 2, 3]")
    assert token.__class__.__name__ == "ListToken"
    assert token.token_position == (1, 1, 0)
    assert token.text == "[1, 2, 3]"

# Generated at 2022-06-24 11:13:24.591221
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="") is not None


# Generated at 2022-06-24 11:13:31.533131
# Unit test for function validate_json
def test_validate_json():
    data = '{"a": {"b":["d", "e", "f"], "g": {"f": {"h":"i"}}}}'
    json_schema = typing.Dict[str, typing.Dict[str, typing.List[str]]]
    value, error_msgs = validate_json(data, json_schema)
    assert value == {'a': {'b': ['d', 'e', 'f'], 'g': {'f': {'h': 'i'}}}}
    assert error_msgs == []

# Generated at 2022-06-24 11:13:35.733245
# Unit test for function tokenize_json
def test_tokenize_json():
    value, messages = validate_json(b'{"field_string" :"abcdefg"}', Field(format="abc"))
    assert value == {"field_string": "abcdefg"}
    assert len(messages) == 0



# Generated at 2022-06-24 11:13:42.441480
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_json = {
        "key1": "value1",
        "key2": "value2"
    }
    token = tokenize_json(json.dumps(test_json))
    decoder = _TokenizingDecoder(token)
    assert decoder._parse_object == _TokenizingJSONObject
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_string == scanstring
    assert decoder.strict == True

# Unit tests for private method _TokenizingJSONObject

# Generated at 2022-06-24 11:13:55.223345
# Unit test for function tokenize_json
def test_tokenize_json():
    content1 = '''
    {
        "a": 123,
        "b": [4, 5, 6],
        "c": {
            "ca": 42,
            "cb": true
        }
    }
    '''

    # Parse an example JSON document.
    token = tokenize_json(content1)

    # This token is a dict.
    assert isinstance(token, DictToken)

    # The document contains one key, "a".
    assert len(token) == 3

    a = token["a"]
    assert isinstance(a, ScalarToken)
    assert a.value == 123

    b = token["b"]
    assert isinstance(b, ListToken)
    assert len(b) == 3
    assert b[0].value == 4
    assert b[1].value == 5
   

# Generated at 2022-06-24 11:14:01.079089
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "name" : "shounak",
        "surname" : "sengupta"
    }"""
    print(tokenize_json(content))



# Generated at 2022-06-24 11:14:02.743119
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    This function test the creation of a _TokenizingDecoder object
    :return: None
    """
    _TokenizingDecoder("test_content")

# Generated at 2022-06-24 11:14:14.472287
# Unit test for function validate_json
def test_validate_json():
    # Test valid case
    json_string = '''{
        "first_name": "John",
        "last_name": "Smith",
        "age": 25,
        "address": {
            "streetAddress": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "postalCode": "10021"
        },
        "phoneNumbers": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "fax",
                "number": "646 555-4567"
            }
        ]
    }'''
    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer(minimum=0)

# Generated at 2022-06-24 11:14:24.812569
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"user":{"first_name":"Jane","last_name":"Doe","email": "janedoe@example.com","phone_number":"555-123-4567"}}'
    token = tokenize_json(content)
    assert token.content == content
    assert token.value["user"]["first_name"] == "Jane"
    assert isinstance(token, DictToken)
    assert isinstance(token.value["user"], DictToken)
    assert token.value["user"]["first_name"].position.char_index == 24

    content = '[1, 2, 3]'
    token = tokenize_json(content)
    assert token.content == content
    assert token.value == [1, 2, 3]
    assert isinstance(token, ListToken)

# Generated at 2022-06-24 11:14:32.949450
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo":"bar"}'
    schema = typing.Type[Schema]
    validator = schema({"foo": Field()})
    value, errors = validate_json(content, validator)
    assert value == {"foo": "bar"}
    assert errors == []

    content = '{"foo":"bar"}'
    schema = typing.Type[Schema]
    schema1 = schema({"foo": Field(validators=[lambda x: 1/0 if x=="bar" else x])})
    value, errors = validate_json(content, schema1)
    assert value == None
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)
    assert errors[0].position.column_no == 8
    assert errors[0].position.text == "Invalid value."



# Generated at 2022-06-24 11:14:37.983728
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import pdb
    pdb.set_trace()
    a = _TokenizingDecoder("", [1,2,3], {"a":3, "b": 5})
    print(a.scan_once("[1, 2, 3 ]", 0))
    _TokenizingDecoder("", [2, 2, 3], {"a":3, "b": 5})
    print("hello")


# Generated at 2022-06-24 11:14:44.223902
# Unit test for function tokenize_json
def test_tokenize_json():
    # Should be able to parse basic JSON
    content = b'{"a": 1, "b": "x"}'
    token = tokenize_json(content)
    assert type(token) is DictToken
    assert token.value == {"a": 1, "b": "x"}

    # Should handle unicode characters correctly
    content = b'{"a": 1, "b": "x", "c": "\\u0066oo"}'
    token = tokenize_json(content)
    assert type(token) is DictToken
    assert token.value == {"a": 1, "b": "x", "c": "foo"}

    # Should handle special characters correctly
    content = b'{"a": 1, "b": "x", "c": "\b\f\n\r\t"}'

# Generated at 2022-06-24 11:14:49.700912
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "lisa", "age": 45}'
    validator = Schema(fields={"name": String, "age": Integer})

    value, errors = validate_json(content, validator=validator)

    assert errors == []

    assert value == {"name": "lisa", "age": 45}

# Generated at 2022-06-24 11:14:57.726985
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function.
    """
    from typesystem import Integer

    # Test good input
    validated_value, errors = validate_json(b'42', Integer)
    assert validated_value == 42
    assert errors == []

    # Test bad input
    validated_value, errors = validate_json(b'42', Integer(max_value=10))
    assert validated_value == 42
    assert len(errors) == 1
    assert errors[0].code == "max_value"
    assert errors[0].message.startswith("Value may not be greater than")
    assert errors[0].position.column_no == 2
    assert errors[0].position.line_no == 1
    assert errors[0].position.char_index == 1

    # Test good input

# Generated at 2022-06-24 11:14:59.194928
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="test").content == "test"


# Generated at 2022-06-24 11:15:03.045071
# Unit test for function tokenize_json
def test_tokenize_json():
    original = "[[2, 3], {\"a\": 5}]"
    token = tokenize_json(original)
    assert token.value == [[2, 3], {"a": 5}]
    assert token.index_start == 0
    assert token.index_end == 18



# Generated at 2022-06-24 11:15:05.590761
# Unit test for function validate_json
def test_validate_json():
    validator = Field(name="Test", type=str)
    value, error_messages = validate_json(content="x", validator=validator)
    assert value == "x"
    assert error_messages is None
    value, error_messages = validate_json(content="", validator=validator)
    assert value is None
    assert type(error_messages[0]) == Message


# Generated at 2022-06-24 11:15:08.996332
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder()
    assert d.strict == True
    assert d.parse_float == float
    assert d.parse_int == int
    assert d.memo == {}
    assert d.content == ''



# Generated at 2022-06-24 11:15:14.343721
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder(content='test')
    assert context.parse_float == float
    assert context.parse_int == int
    assert context.parse_string == scanstring
    assert context.parse_array == JSONDecoder.parse_array
    assert context.strict == True
    assert context.memo == {}


# Generated at 2022-06-24 11:15:19.763863
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string", min_length=5)
    content = "{\"key\": \"value\"}"
    value, messages = validate_json(content, validator)
    assert value == 'value'
    assert len(messages) == 1
    msg = messages[0]
    assert isinstance(msg, ValidationError)
    assert msg.code == "min_length"
    assert msg.text == "Must be at least 5 characters."
    assert msg.position.line_no == 1
    assert msg.position.column_no == 11
    assert msg.position.char_index == 10

# Generated at 2022-06-24 11:15:30.874909
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "the content"
    args = "the args"
    kwargs = "the kwargs"
    decoder = _TokenizingDecoder(args, content=content, kwargs=kwargs)
    assert decoder.args == args
    assert decoder.kwargs == kwargs
    assert decoder.content == content
    assert decoder.scan_once is not None

# Unit tests for function _make_scanner
# These tests cover both the function itself and the underlying _TokenizingJSONObject
# We test both DictToken and ListToken
# We test ScalarToken for int, float, and string
# We test for null, true and false
# We test each of the scan_once function return values

# Generated at 2022-06-24 11:15:33.712636
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="abcd")
    if not (decoder is not None):
        raise ValueError("decoder is None")

    assert decoder.scan_once is not None


# Generated at 2022-06-24 11:15:43.483288
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """
    {
        "hello": "world",
        "foo"  :    "bar",
        "baz"  :    {
            "test": "123"
        },
        "another array": [
            "one",
            "two",
            "three"
        ]
    }
    """


# Generated at 2022-06-24 11:15:44.393895
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    JSONDecoder()


# Generated at 2022-06-24 11:15:51.488956
# Unit test for function tokenize_json
def test_tokenize_json():
    # Given
    content = '{"type": "list", "items": {"type": "integer"}}'
    print("\nGiven:\ncontent = {}".format(content))

    # When
    actual_result = tokenize_json(content)
    keys = list(actual_result.keys())
    print("actual_result = {}".format(actual_result))

    # Then
    assert isinstance(actual_result, dict)
    assert len(keys) == 2
    assert isinstance(actual_result["type"], ScalarToken)
    assert isinstance(actual_result["items"], DictToken)



# Generated at 2022-06-24 11:16:03.514332
# Unit test for function validate_json
def test_validate_json():
    # if input string is empty
    try:
        validate_json("", "")
    except ParseError:
        pass

    # if tokenize_json raises an exception
    try:
        validate_json("{}", "")
    except ParseError as e:
        assert e.text == "Parse error at '[1:1]' (line 1, column 1) : Unexpected character."

    # if validator is not type of Schema
    try:
        validate_json("{}", object())
    except TypeError as e:
        assert str(e) == "Validator must be an instance of Field or Schema"

    # if validation is successful
    schema = Schema({"name": String()})
    try:
        validate_json('{"name": "Jack"}', schema)
    except ValidationError:
        pass

# Generated at 2022-06-24 11:16:12.559716
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
      "name": "John Smith",
      "age": 25,
      "sex": "Male",
      "married": false,
      "address": {
        "street": "10 Downing Street",
        "city": "London"
      },
      "friends": [
        {
          "name": "Dave Smith",
          "age": 25
        },
        {
          "name": "John Smith",
          "age": 25
        }
      ],
      "null_field": null
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert len(token.value) == 8


# Generated at 2022-06-24 11:16:23.423381
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = '{\
        "key1": "value1",\
        "key2": "value2",\
        "key3": "value3"\
    }'
    token = tokenize_json(json_content)

    assert(token.__class__.__name__ == 'DictToken')
    assert(len(token.value) == 3)
    assert(token.value["key1"].value == "value1")
    assert(token.value["key2"].value == "value2")
    assert(token.value["key3"].value == "value3")

    assert(token.value["key1"].__class__.__name__ == 'ScalarToken')
    assert(token.value["key1"].start == 16)

# Generated at 2022-06-24 11:16:32.604003
# Unit test for function validate_json
def test_validate_json():
    content = '[{"name": "John", "age": 10, "pets": ["Fish"]}]'
    value, error_messages = validate_json(content, Person)
    assert len(error_messages) == 0

    content = "[]t"
    value, error_messages = validate_json(content, Person)
    assert len(error_messages) == 1
    assert error_messages[0].position.char_index == 3
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 4

    content = '["name": "John"]'
    value, error_messages = validate_json(content, Person)
    assert len(error_messages) == 1
    assert error_messages[0].position.char_index == 1

# Generated at 2022-06-24 11:16:43.631226
# Unit test for function validate_json
def test_validate_json():
    """
    Unit test for function validate_json()
    """
    # Test: string input
    value, err = validate_json(
        """
        {
            "name":"John",
            "age":30,
            "cars":
            [
                {"car1":"Ford","car2":"BMW"},
                {"car1":"Tesla","car2":"Audi"}
            ]
        }
        """,
        Field(field_type=typing.Any),
    )

    assert value is not None
    assert err is None


# Generated at 2022-06-24 11:16:44.548838
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder({}, content="hello world") != ''


# Generated at 2022-06-24 11:16:48.365313
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-24 11:16:59.732095
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (tokenize_json('') == None)

# Generated at 2022-06-24 11:17:06.267463
# Unit test for function validate_json
def test_validate_json():
    child = Field(type="string")
    parent = Schema([("key", child)])

    payload1 = r'{"key": "value"}'  # Valid JSON.
    assert validate_json(payload1, parent) == ([], None)

    payload2 = r'{"key": "value"'  # Incomplete JSON.
    assert validate_json(payload2, parent) == (
        None,
        Message(
            text="Unterminated string starting at line 1 column 13 (char 12).",
            code="parse_error",
            position=Position(column_no=13, line_no=1, char_index=12),
        ),
    )

    payload3 = r'{"key": ""}'  # Valid JSON, invalid Schema.

# Generated at 2022-06-24 11:17:16.275596
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1, "b": [1, 2, 3], "c": ["1", 2, 3]}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 45
    assert token.char_start == 0
    assert token.char_end == 45
    
    expected_keys = ['a', 'b', 'c']
    keys = sorted([key.value for key in token.value.keys()])
    assert keys == expected_keys
    for key in token.value.keys():
        value_token = token.value[key]
        assert isinstance(value_token, Token)
        assert value_token.content == content
    assert isinstance(token.value['a'], ScalarToken)
    assert token

# Generated at 2022-06-24 11:17:25.375405
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import TokenValidationError

    class Person(Schema):
        name = String()

    content = b'{"name": "John"}'
    value, messages = validate_json(content, Person)
    assert value["name"] == "John"
    assert messages == []

    content = b'{"name": 1}'
    value, messages = validate_json(content, Person)
    assert value == {}
    assert len(messages) == 1
    assert messages[0]["code"] == "invalid_type"
    assert messages[0]["data"]["expected_type"] == "string"
    assert messages[0]["data"]["actual_type"] == "integer"

    content

# Generated at 2022-06-24 11:17:26.945168
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-24 11:17:29.621505
# Unit test for function tokenize_json
def test_tokenize_json():
    content="{\"test\": [\"test\", \"test1\"]}"
    token = tokenize_json(content)
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:17:34.036214
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with open('test_json/test.json') as test_file:
        content = test_file.read()
        decoder = _TokenizingDecoder(content=content)
        assert decoder.scan_once('[1, 2, 3]', 0) == ([1, 2, 3], 8)


# Generated at 2022-06-24 11:17:38.629445
# Unit test for function tokenize_json
def test_tokenize_json():
    tok = tokenize_json('{"foo": 123, "bar": [4, 5, 6]}')
    assert tok.is_dict()
    assert len(tok.items()) == 2
    assert tok.get("foo").is_scalar()
    assert tok.get("bar").is_list()


# Generated at 2022-06-24 11:17:46.906950
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingJSONObject(
        s_and_end=('{"a":1, "b":2}', 0),
        strict=True,
        scan_once=_make_scanner(
            context={
                "parse_array": scanstring,
                "parse_float": float,
                "parse_int": int,
                "parse_object": _TokenizingJSONObject,
                "parse_string": scanstring,
                "memo": {},
                "strict": True,
            },
            content="",
        ),
        memo={"a": "a", "b": "b"},
        content="",
        _w=WHITESPACE.match,
        _ws=WHITESPACE_STR,
    )

# Generated at 2022-06-24 11:17:56.981822
# Unit test for function validate_json
def test_validate_json():
    expected_error = Message(
        text="Value must be at least 10.",
        code="min_value",
        position=Position(line_no=1, column_no=9, char_index=8),
    )
    value, errors = validate_json('{"field": 1}', dict(field=dict(type="integer", minimum=10)))
    assert value == {'field': 1}
    assert errors == [expected_error]
    value, errors = validate_json('{"field": 1}', dict(field=dict(type="integer", minimum=10)))
    assert value == {'field': 1}
    assert errors == [expected_error]
    value, errors = validate_json('{"field": 1}', dict(field=dict(type="integer", minimum=10)))
    assert value == {'field': 1}

# Generated at 2022-06-24 11:17:58.780682
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test_content")
    assert decoder.scan_once == _make_scanner(decoder, "test_content")


# Generated at 2022-06-24 11:18:08.754231
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String

    JSON_STRING = '{"foo1": "bar1", "foo2": "bar2"}'
    schema = Schema(properties={key: String() for key in ("foo1", "foo2")})

    value, error_messages = validate_json(content=JSON_STRING, validator=schema)

    expected_value = {"foo1": "bar1", "foo2": "bar2"}
    expected_error_messages = []

    assert value == expected_value
    assert error_messages == expected_error_messages

    JSON_STRING = '{"foo1": "bar1", "foo2": "bar2", "foo3": "bar3"}'

    value, error_messages = validate_json(content=JSON_STRING, validator=schema)

   

# Generated at 2022-06-24 11:18:17.725895
# Unit test for function tokenize_json
def test_tokenize_json():
    # Empty string
    content = ""
    assert tokenize_json(content) == {}

    # Empty object
    content = "{}"
    assert tokenize_json(content) == {}

    # Empty list
    content = "[]"
    assert tokenize_json(content) == []

    # Scalar token
    content = '"test"'
    assert tokenize_json(content) == 'test'

    # Object token
    content = '{"test": "test"}'
    assert tokenize_json(content) == {"test": "test"}

    # List token
    content = '["test", "test"]'
    assert tokenize_json(content) == ["test", "test"]

    # Complex structure token
    content = '{"test": ["test", "test"]}'

# Generated at 2022-06-24 11:18:28.559030
# Unit test for function validate_json
def test_validate_json():
    class User(Schema):
        name = Field(type=str)
        age = Field(type=int)

    content1 = """
        {
            "name": "John Doe",
            "age": 20
        }
    """

    content2 = """
        {
            "name": "John Doe",
            "age": "20"
        }
    """

    content3= '{"name": "John Doe"}'

    content4 = '{"age": 20}'

    content5 = '{"name": "John Doe", "age": "20", "height": 173.3}'

    data, errors = validate_json(content1, User)
    assert errors == []
    assert data['name'] == 'John Doe'
    assert data['age'] == 20

    data, errors = validate_json(content2, User)

# Generated at 2022-06-24 11:18:35.531066
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content="{}")
    assert tokenize_json("[]") == ListToken(value=[], start=0, end=1, content="[]")
    assert tokenize_json("42") == ScalarToken(value=42, start=0, end=1, content="42")
    assert tokenize_json("true") == ScalarToken(
        value=True, start=0, end=3, content="true"
    )



# Generated at 2022-06-24 11:18:44.136357
# Unit test for function validate_json
def test_validate_json():
    from .examples import Person

    content = '{"name": "Foo", "age": 25}'
    value, errors = validate_json(content, Person)
    assert value.name == "Foo"

    content = '{"name": "Foo", "age": "25"}'
    value, errors = validate_json(content, Person)
    assert errors[0][0].code == "invalid_type"

    content = '{"name": "Foo", "age": 25, "dob": "2001-01-01"}'
    value, errors = validate_json(content, Person)
    assert errors[0][0].code == "unknown_field"

    content = '{"name": "Foo"}'
    value, errors = validate_json(content, Person)

# Generated at 2022-06-24 11:18:52.208183
# Unit test for function tokenize_json
def test_tokenize_json():
    def check_json(content, expected):
        assert tokenize_json(content) == expected
    check_json('"foo"', 'foo')
    check_json('[]', [])
    check_json('[1, 2]', [1, 2])
    check_json('{"key": "value"}', {'key': 'value'})
    check_json('{"key": [1, 2]}', {'key': [1, 2]})
    check_json('{"key": {"key2": [3, 4]}}', {'key': {'key2': [3, 4]}})


# Generated at 2022-06-24 11:19:00.436672
# Unit test for function validate_json
def test_validate_json():
    import unittest
    from typesystem import String 

    validator = String(format='url')

    content = '"http://www.example.com"' 
    value, errors = validate_json(content, validator)
    assert not errors

    content = '"not_a_valid_url"'
    value, errors = validate_json(content, validator)
    assert len(errors) == 1

    content = '["not_a_valid_url"]'
    value, errors = validate_json(content, validator)
    assert len(errors) == 1

# Generated at 2022-06-24 11:19:03.783603
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test that _TokenizingDecoder subclasses JSONDecoder and calls JSONDecoder.__init__
    decoder = _TokenizingDecoder(content="lorem ipsum")
    assert isinstance(decoder, JSONDecoder)
    assert decoder.scan_once is not None

# Unit tests for function tokenize_json

# Generated at 2022-06-24 11:19:07.156410
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder is not None


# Generated at 2022-06-24 11:19:08.401550
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder([1,2,3])

# Generated at 2022-06-24 11:19:13.685106
# Unit test for function validate_json
def test_validate_json():
    schema = Field(required=True, type="string")
    value, errors = validate_json(b"abc", schema)
    assert errors == []
    value, errors = validate_json(b'{"value": "abc"}', schema)
    assert errors == [{"code": "invalid_type", "position": Position(char_index=1, line_no=1, column_no=1)}]



# Generated at 2022-06-24 11:19:16.627205
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(parse_int=lambda x: 1, parse_float=lambda x: 1.1)

# Generated at 2022-06-24 11:19:27.061311
# Unit test for function tokenize_json
def test_tokenize_json():

    token = tokenize_json('{"a": 1, "b": [2], "c": {"d": [1.1, 2.2, -3.3]}}')
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:19:36.530952
# Unit test for function validate_json
def test_validate_json():
    def assert_equal(token, validator, content):
        """
        Helper function that tests the value, error messages, and positions
        returned from validate_json.

        token (Token) - A JSON token.
        validator (Field or Schema) - A Field or Schema that contains the
                                      validator to test.
        content (str) - The JSON string used to create the token.
        """
        value, messages = validate_json(token, validator)
        assert value == token.value
        if isinstance(token, ScalarToken):
            assert len(messages) == 0
        elif isinstance(token, DictToken):
            for message in messages:
                assert isinstance(message, ValidationError)

# Generated at 2022-06-24 11:19:42.075137
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"name": "John"}')
    assert result.kind == "dict"
    assert result.value["name"].value == "John"
    assert result.value["name"].start_position.column_no == 9
    assert result.value["name"].end_position.column_no == 14
    # test_type = tokenize_json('{"name": "type"}')
    # test_type_result = test_type.value["name"].value
    # assert result.value["name"].value == test_type_result


# Generated at 2022-06-24 11:19:52.481083
# Unit test for function validate_json
def test_validate_json():
    """Test validate_json."""
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class PersonSchema(Schema):
        name = String()
        age = String()

    content1 = '{ "name": "Bob", "age": "123" }'
    content2 = '{ "name": "Bob" }'
    content3 = '{ "name": "Bob", "age": "abc" }'

    assert validate_json(content1, PersonSchema) == (
        {'name': 'Bob', 'age': '123'},
        None,
    )

# Generated at 2022-06-24 11:20:01.609345
# Unit test for function validate_json
def test_validate_json():
    content = r'{"name": "test", "size": 12}'
    schema = Schema(
        {"name": {"type": str, "description": "Name of the object."}, "size": int}
    )
    value, error_messages = validate_json(content, schema)
    assert error_messages == []
    assert value == {"name": "test", "size": 12}

    content = r'{"name": "test", "size": 12.2}'
    value, error_messages = validate_json(content, schema)

# Generated at 2022-06-24 11:20:11.280257
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json = '{"a":1, "b":2, "c":3}'
    assert _TokenizingJSONObject((json, 0), True, _scan_once, {}, json) == ({'a': 1, 'b': 2, 'c': 3}, 25)
    assert _TokenizingDecoder(content=json).scan_once('{"a":1, "b":2, "c":3}', 0) == ({'a': 1, 'b': 2, 'c': 3}, 25)
    assert tokenize_json(json) == ({'a': 1, 'b': 2, 'c': 3}, 25)
    # assert validate_json(json, )
    assert len(json) == 25


# Generated at 2022-06-24 11:20:18.919601
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Field(key='foo')
    value, errors = validate_json(content, validator)
    assert isinstance(value, dict)
    assert isinstance(errors, Message)
    assert bool(errors) is False
    assert value == {'foo': 'bar'}

    content = '{"foo": 1}'
    validator = Field(key='foo')
    value, errors = validate_json(content, validator)
    assert isinstance(value, dict)
    assert isinstance(errors, Message)
    assert bool(errors) is False
    assert value == {'foo': 1}

    content = '{"foo": "bar"}'
    validator = Field(key='foo', max_length=2)

# Generated at 2022-06-24 11:20:20.906740
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    tester = _TokenizingDecoder(content=content)
    assert tester.content == content


# Generated at 2022-06-24 11:20:23.448403
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_string == JSONDecoder.parse_string
    assert decoder.memo == {}
    assert decoder.strict == True
    

# Generated at 2022-06-24 11:20:28.619955
# Unit test for function tokenize_json
def test_tokenize_json():
    # Successful parse
    assert tokenize_json('{"a": "b"}').value == {'a': 'b'}

    # Parse error
    with pytest.raises(ParseError) as e:
        tokenize_json('{a: "b"}')
    assert e.value.code == 'parse_error'
    assert e.value.position.line_no == 1

# Generated at 2022-06-24 11:20:34.093907
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "field-a": "hello world",
  "field-b": ["foo", "bar"]
}
"""
    token = tokenize_json(content)
    assert token.as_dict() == {
        "field-a": "hello world",
        "field-b": ["foo", "bar"]
    }



# Generated at 2022-06-24 11:20:36.840470
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = """
    {
        "hello": "world"
    }
    """
    decoder = _TokenizingDecoder(content=test_content)
    assert isinstance(decoder, JSONDecoder)



# Generated at 2022-06-24 11:20:38.877318
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.scan_once("{", 0) == ({}, 1)



# Generated at 2022-06-24 11:20:44.114742
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "\"Content\""
    decoder = _TokenizingDecoder(content=content)
    assert decoder.strict == True
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant == JSONDecoder.parse_constant
