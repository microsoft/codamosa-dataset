

# Generated at 2022-06-24 11:10:50.183866
# Unit test for function validate_json
def test_validate_json():

    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=False)

    errors = validate_json(
        """
        {
            "name": "John Doe"
        }
        """,
        validator=PersonSchema,
    )
    assert not errors.get("name")
    assert errors.get("age")
    assert errors.get("age").char_index == len("""
        {
            "name": "John Doe"
        }
        """)

# Generated at 2022-06-24 11:10:53.372146
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar", "baz": [1, 2, 3]}')
    assert isinstance(token, DictToken)
    assert(token.value == {"foo": "bar", "baz": [1, 2, 3]})

# Generated at 2022-06-24 11:10:55.996980
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    js = {}
    _TokenizingDecoder(None, object_hook=js.update)

# Generated at 2022-06-24 11:10:57.874944
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("\"", content="") == JSONDecoder("\"")


# Generated at 2022-06-24 11:11:07.566652
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = {"a": int, "b": str, "c": {"d": list}}
    content = '{"a": 1, "b": "bar", "c": {"d": [1, 2, 3]}}'
    token = tokenize_json(content)
    schema_token = tokenize_json(json.dumps(schema))
    fields, _ = validate_with_positions(token=token, validator=schema_token)
    #print(token)
    #print(json.dumps(fields))



# Generated at 2022-06-24 11:11:16.145345
# Unit test for function validate_json
def test_validate_json():
    class PersonSchema(Schema):
        name = Field(required=True, max_length=100)
        age = Field(required=True, type="integer")
        gender = Field(required=True, enum=["male", "female"])

    schema = PersonSchema()

    content = b'{"name": "Paige", "age": "23", "gender": "female"}'
    value, errors = validate_json(content=content, validator=schema)
    assert not errors
    assert value == {
        "name": "Paige",
        "age": 23,
        "gender": "female",
    }

    content = b'{"name": "Paige", "age": 23, "gender": "female"}'
    value, errors = validate_json(content=content, validator=schema)

# Generated at 2022-06-24 11:11:19.977234
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": 1}'
    decoder = _TokenizingDecoder(content=content)
    result = decoder.scan_once(content, 0)
    # the output is expected to be a token and its end_index
    assert result == (DictToken({'a': 1}, 0, 8, content), 9)


# Generated at 2022-06-24 11:11:22.831071
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        decoder = _TokenizingDecoder("")
    except Exception as exc:
        print(exc)
    assert decoder is not None


# Generated at 2022-06-24 11:11:34.109062
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"a": "b"}')
    assert(isinstance(token, DictToken))
    assert(token.value["a"] == "b")
    assert(token.value["a"].start_position == Position(1,9,8) )
    assert(token.value["a"].end_position == Position(1,9,10) )
    assert(token.value["a"].value == "b" )
    assert(token.start_position == Position(1,1,0))
    assert(token.end_position == Position(1,10,10))

    # Error messages
    try:
        validate_json("{'a', 'b'}", str)
    except ParseError as error:
        assert(str(error) == 'Expecting property name enclosed in double quotes.')


# Generated at 2022-06-24 11:11:40.659470
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key1":"value1", "key2":10, "key3":true, "key4":[11, 12, 13]}')
    assert token.to_json_value() == {'key1':'value1', 'key2':10, 'key3':True, 'key4':[11, 12, 13]}


# Generated at 2022-06-24 11:11:50.384662
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b"}') == DictToken(
        {"a": ScalarToken(value="b", start=2, end=5, content='{"a":"b"}')},
        start=0,
        end=6,
        content='{"a":"b"}',
    )

    assert tokenize_json('{"a":1}') == DictToken(
        {"a": ScalarToken(value=1, start=2, end=4, content='{"a":1}')},
        start=0,
        end=5,
        content='{"a":1}',
    )


# Generated at 2022-06-24 11:12:00.163052
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Integer, Schema, String

    class SimpleSchema(Schema):
        name = String()
        age = Integer()

    content = '{"name": "Jim", "age": 34}'
    value, errors = validate_json(content, SimpleSchema)

    assert value == {"name": "Jim", "age": 34}
    assert errors == []

    content = '{"name": "Jim", "age": "34"}'
    value, errors = validate_json(content, SimpleSchema)

    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 22
    assert errors[0].position.char_index == 21



# Generated at 2022-06-24 11:12:10.695614
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('"hello"') == ScalarToken('hello', 0, 6, '"hello"')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')


# Generated at 2022-06-24 11:12:11.639613
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("content")

# Generated at 2022-06-24 11:12:21.176126
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String

    from .tokenize.tokens import ListToken, DictToken

    decoded = tokenize_json(
        '[["a", "b", "c"], ' '{"key1": "value1", "key2": "value2", "key3": "value3"}]'
    )

    assert isinstance(decoded, ListToken)
    assert isinstance(decoded.items[0], ListToken)
    assert isinstance(decoded.items[1], DictToken)

    # Validation test
    string_field = String(min_length=1, max_length=3)
    with pytest.raises(ValidationError) as exc_info:
        string_field.validate_token(decoded.items[0].items[0])
    assert exc_info.type == Validation

# Generated at 2022-06-24 11:12:22.679995
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder({"content": "test"})



# Generated at 2022-06-24 11:12:32.176995
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, any_type

    result = validate_json(b"{}", String())
    assert result[0] is None
    assert isinstance(result[1], Message)
    assert result[1].text == "This field may not be blank."
    assert result[1].position.line_no == 1
    assert result[1].position.column_no == 1

    content = """
    {
      "foo": 1,
      "bar": "abc",
      "baz": 3.14
    }
    """

    def validate(value, _):
        return value

    result = validate_json(content, any_type(validate=validate))
    assert isinstance(result[0], dict)
    assert "foo" in result[0]
    assert result[0]["foo"] == 1
   

# Generated at 2022-06-24 11:12:35.634904
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test the tokenize_json function

    :return:
    """
    # Test JSON parse error
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{a}")
    assert excinfo.value.code == "parse_error"

    # Test empty string case
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.code == "no_content"



# Generated at 2022-06-24 11:12:38.410353
# Unit test for function validate_json
def test_validate_json():
    # TODO: Complete this (see corresponding tests in typesystem/test_tokenize.py)
    pass

# Generated at 2022-06-24 11:12:46.039282
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, error_message = validate_json('"hello"', validator)
    assert value == "hello"
    assert error_message == []

    validator = Field(type="string")
    value, error_message = validate_json('null', validator)
    assert value is None
    assert error_message == [ValidationError(
        text="This field does not allow a null value.",
        code="null",
        position=Position(column_no=1, line_no=1, char_index=0),
    )]


# Generated at 2022-06-24 11:12:51.658760
# Unit test for function tokenize_json
def test_tokenize_json():
    print(tokenize_json('{"a":1}'))
    print(tokenize_json('[1]'))
    print(tokenize_json('true'))
    print(tokenize_json('1'))
    print(tokenize_json('"abc"'))
    print(tokenize_json(''))


# Generated at 2022-06-24 11:12:58.772065
# Unit test for function validate_json
def test_validate_json():
    validator = Field(
        type="string",
        description="Some description",
        example="Some example",
        required=True,
    )
    value, messages = validate_json(content="test string", validator=validator)
    assert value == "test string"
    assert len(messages) == 0

    value, messages = validate_json(content='"test string"', validator=validator)
    assert value == "test string"
    assert len(messages) == 0

    value, messages = validate_json(content="123", validator=validator)
    assert len(messages) == 1
    assert isinstance(messages[0], Message)

    value, messages = validate_json(content="", validator=validator)
    assert len(messages) == 1

# Generated at 2022-06-24 11:13:01.729686
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":"a","b":1}'
    decoder = _TokenizingDecoder(content=content)
    assert content == decoder.decode(content)


# Generated at 2022-06-24 11:13:08.823129
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("{", "{")
    assert repr(decoder) == repr({"{": "{"})
    # It has attributes:
    attributes = ['parse_array', 'parse_object', 'parse_float', 'parse_int', 'strict', 'memo', 'parse_string']
    for attr in attributes:
        assert hasattr(decoder, attr)
    # It has methods:
    methods = ['decode', 'raw_decode', 'scan_once']
    for method in methods:
        assert hasattr(decoder, method)
        assert callable(getattr(decoder, method))


# Generated at 2022-06-24 11:13:20.134861
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        {
            "name": Field(type_name="string"),
            "age": Field(type_name="integer"),
            "favourite_colours": Field(type_name="list", items=Field(type_name="string")),
        }
    )
    # Test for a valid json
    json_data = r'{"name": "john", "age": 20, "favourite_colours": ["red", "green"]}'
    value, error_messages = validate_json(json_data, schema)
    assert not error_messages

    # Test for an invalid json
    json_data = r'{"name": "john", "age": "20", "favourite_colours": ["red", "green"]}'

# Generated at 2022-06-24 11:13:30.383069
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(content="{}") == ({}, [])
    assert validate_json(content='{"test": "hello"}') == ({'test': 'hello'}, [])
    assert validate_json(content='{"test": 2') == (None, [ValidationError(code='parse_error', text='Expecting value.', position=Position(column_no=16, line_no=1, char_index=15))])
    assert validate_json(content='{"test": "hello"') == (None, [ValidationError(code='parse_error', text='Expecting value.', position=Position(column_no=16, line_no=1, char_index=15))])

# Generated at 2022-06-24 11:13:35.456209
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token, DictToken, ListToken, ScalarToken

    assert tokenize_json(b'{}') == DictToken({})
    assert tokenize_json(b'[[]]') == ListToken([])
    assert tokenize_json(b'["hello"]') == ListToken([ScalarToken("hello")])
    assert tokenize_json(b'{"hello": "world"}') == DictToken(
        {"hello": ScalarToken("world")}
    )



# Generated at 2022-06-24 11:13:41.951282
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{'a':1}")
    assert isinstance(token, DictToken)

    token = tokenize_json("{'a':1}")
    assert isinstance(token, DictToken)

    # assert that an error is thrown
    with pytest.raises(ParseError):
        tokenize_json("{'a':1")

    # assert that an error is thrown
    with pytest.raises(ParseError):
        tokenize_json("")



# Generated at 2022-06-24 11:13:54.747254
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schema import Schema
    from typesystem.fields import Integer, Text
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    import json

    class Book(Schema):
        title = Text(required=True, max_length=200)
        pages = Integer(required=True)

    content = '{"title": "The Moon is a Harsh Mistress", "pages": 341}'
    value, error = validate_json(content, validator=Book)

    assert value is not None
    assert error is None

    value, error = validate_json(content, validator=Book.as_nullable())

    assert value is not None
    assert error is None


    content = '{"title": "The Moon is a Harsh Mistress", "pages": "invalid"}'
   

# Generated at 2022-06-24 11:14:00.729861
# Unit test for function tokenize_json
def test_tokenize_json():
    json_token = tokenize_json("""{
        "key": 5,
        "key2": 5,
        "key3": [0, 1],
        "key4": {
            "key5": true,
            "key6": "value"
        }
    }""")
    assert (json_token.key == 5)
    assert (json_token.key2 == 5)
    assert (json_token.key3 == [0, 1])
    assert (json_token.key4.key5 == True)
    assert (json_token.key4.key6 == "value")


# Generated at 2022-06-24 11:14:07.293769
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    [
        {
            "first_name": "John",
            "last_name": "Doe"
        }, {
            "first_name": "Jane",
            "last_name": "Doe"
        }
    ]
    """
    tok = tokenize_json(json_string)
    assert tok.is_list
    assert len(tok.value) == 2
    assert tok.value[0]["first_name"].value == "John"
    assert tok.value[1]["last_name"].value == "Doe"


# Generated at 2022-06-24 11:14:19.463985
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.utilities import json_dumps

    assert tokenize_json(json_dumps(12.3)) == ScalarToken(12.3, 0, 4, json_dumps(12.3))
    assert tokenize_json(json_dumps(True)) == ScalarToken(True, 0, 4, json_dumps(True))
    assert (
        tokenize_json(json_dumps(False)) == ScalarToken(False, 0, 5, json_dumps(False))
    )
    assert tokenize_json(json_dumps(None)) == ScalarToken(None, 0, 4, json_dumps(None))

# Generated at 2022-06-24 11:14:21.618126
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder('', "")
    except Exception as e:
        assert False, 'Exception while create _TokenizingDecoder: %s' % e
    assert True


# Unit tests for tokenize_json
# Error cases


# Generated at 2022-06-24 11:14:28.522561
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={"first_name": {"type": "string"}, "last_name": {"type": "string"}})
    validator = schema.as_field()
    content = '{"first_name": "John", "last_name": "Doe"}'
    value, error_messages = validate_json(content, validator)
    assert not error_messages
    assert value == {"first_name": "John", "last_name": "Doe"}
    # Test a malformed schema
    content = '{"first_name: "John", "last_name": "Doe"}'
    _, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == "parse_error"

# Generated at 2022-06-24 11:14:39.294340
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="integer", required=True)
    value, error_messages = validate_json(b"123", validator)
    assert value == 123
    assert len(error_messages) == 0
    
    value, error_messages = validate_json(b"123.456", validator)
    assert value == 123.456
    assert len(error_messages) == 0
    
    value, error_messages = validate_json(b"true", validator)
    assert value == True
    assert len(error_messages) == 0
    
    value, error_messages = validate_json(b"false", validator)
    assert value == False
    assert len(error_messages) == 0
    
    value, error_messages = validate_json(b"null", validator)


# Generated at 2022-06-24 11:14:50.594544
# Unit test for function tokenize_json
def test_tokenize_json():
    # parse integer
    json_content = str("123")
    assert isinstance(tokenize_json(json_content), ScalarToken)

    # parse string
    json_content = str("\"mystring\"")
    assert isinstance(tokenize_json(json_content), ScalarToken)

    # parse float
    json_content = str("123.33")
    assert isinstance(tokenize_json(json_content), ScalarToken)

    # parse dict
    json_content = str("{\"a\": \"bbb\"}")
    assert isinstance(tokenize_json(json_content), DictToken)

    # parse list
    json_content = str("[1,2,3]")
    assert isinstance(tokenize_json(json_content), ListToken)



# Generated at 2022-06-24 11:15:01.788295
# Unit test for function validate_json
def test_validate_json():

    data = """
    {
        "name": "Scooby-Do",
        "address":  {
          "address": "123 Fake Street",
          "city": "Springfield",
          "state": "NV"
        },
        "foods": ["Burgers", "Fries", "Shakes"],
        "age": 5,
        "siblings": [
          {
            "name": "Scrappy-Do",
            "age": 3
          },
          {
            "name": "Snoop",
            "age": 1
          }
        ]
    }
    """


# Generated at 2022-06-24 11:15:03.463039
# Unit test for function tokenize_json
def test_tokenize_json():
  content = "[1, 2, 3]"
  funcResult = _TokenizingDecoder(content=content).decode(content)
  assert funcResult[0] == 1
  assert funcResult[1] == 2
  assert funcResult[2] == 3

# Generated at 2022-06-24 11:15:07.988954
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": "b"}'
    decoder = _TokenizingDecoder(content=content)
    result = decoder.decode(content)
    expected = DictToken({ScalarToken("a", 0, 1, content): ScalarToken("b", 3, 5, content)}, 0, 8, content)
    assert result == expected

# Generated at 2022-06-24 11:15:13.499244
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = """
    {
        "key": 123,
        "key2": "value"
    }
    """
    decoder = _TokenizingDecoder(content=content)
    assert (
        decoder.scan_once.__doc__
        == "Decode an object from string in JSON format."
    )


# Generated at 2022-06-24 11:15:24.225509
# Unit test for function validate_json
def test_validate_json():
    # This is the JSON we will validate
    JSON_STRING = '{"name": "Anna Friel", "age": "32"}'
    
    # This is the schema used to validate the JSON
    class UserSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=18, maximum=99)

    # We call the function and store the tuple returned in variables
    schema_instance, error_messages = validate_json(JSON_STRING, UserSchema)
    
    # If no errors then print the validated JSON
    if len(error_messages) == 0:
        print(schema_instance)

    # If there are errors then print the error messages
    else:
        for error in error_messages:
            print(error.text)

# Generated at 2022-06-24 11:15:34.589140
# Unit test for constructor of class _TokenizingDecoder

# Generated at 2022-06-24 11:15:37.314491
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="hello")
    assert isinstance(decoder.scan_once, typing.Callable)

# Generated at 2022-06-24 11:15:45.208885
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b"{1}") == DictToken({}, 0, 2, "{1}")
    with pytest.raises(ParseError) as excinfo:
        tokenize_json(b"{")
    assert excinfo.value.code == "parse_error"
    assert excinfo.value.position == Position(column_no=2, line_no=1, char_index=1)
    assert tokenize_json(b"{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json(b"{\"a\": 1}") == DictToken(
        {"a": ScalarToken(1, 4, 4, "{\"a\": 1}")}, 0, 8, "{\"a\": 1}"
    )



# Generated at 2022-06-24 11:15:51.568860
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function
    """
    from typesystem import String
    from typesystem.exceptions import ValidationError
    from typesystem.json import JSONField

    field = JSONField(type=String)
    try:
        value, errors = validate_json("foobar", field)
    except ValidationError as error:
        assert error.messages[0].message == "Expected data of type 'list',"
    value, errors = validate_json("[1]", field)
    assert value == ["1"]
    assert errors is None

# Generated at 2022-06-24 11:16:03.564300
# Unit test for function validate_json
def test_validate_json():
    field = Field(subtype="string")
    assert validate_json(b'"foo"', field) == ("foo", [])
    assert validate_json(b'"foo"', field) == ("foo", [])
    assert validate_json(b'42', field) == (42, [])
    assert validate_json(b'null', field) == (None, [])
    assert validate_json(b'{"foo": "bar"}', field) == ({"foo": "bar"}, [])
    assert validate_json(b'{"foo": "bar"}', field) == ({"foo": "bar"}, [])
    assert validate_json(b'{"foo": "bar"}', field) == ({"foo": "bar"}, [])

    # Test validation
    field.subtype = "number"

# Generated at 2022-06-24 11:16:07.547379
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    print("Test Start")
    strict = True
    content = "This is a string"
    decoder = _TokenizingDecoder(strict=strict, content=content)
    assert decoder.context is None
    assert decoder.parse_float is math.log
    assert decoder.strict == strict
    assert decoder.parse_int is int
    assert decoder.parse_constant == {"true": True, "false": False, "null": None}
    assert decoder.scan_once is not None  # since content is not empty
    print("Test Stop")


# Generated at 2022-06-24 11:16:15.311025
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token
    from .examples import (
        dict_obj,
        EMPTY_ARRAY_RESPONSE,
        EMPTY_OBJECT_RESPONSE,
        SIMPLE_DICT_OBJ_RESPONSE,
        SIMPLE_LIST_RESPONSE,
        SIMPLE_RESPONSE,
    )
    assert tokenize_json(SIMPLE_RESPONSE) == Token(123, 0, 4, SIMPLE_RESPONSE)
    assert tokenize_json(SIMPLE_DICT_OBJ_RESPONSE) == Token(
        dict_obj, 0, len(SIMPLE_DICT_OBJ_RESPONSE) - 1, SIMPLE_DICT_OBJ_RESPONSE
    )
    assert token

# Generated at 2022-06-24 11:16:20.542042
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"name": "Max", "age": 11}'
    token = tokenize_json(json)
    assert isinstance(token, DictToken)
    assert len(token) == 2
    assert isinstance(token["name"], ScalarToken)
    assert token["name"] == 'Max'
    assert isinstance(token["age"], ScalarToken)
    assert token["age"] == 11


# Generated at 2022-06-24 11:16:26.723776
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(title="Test", properties={"type": String()})
    result = validate_json('{"type": "test"}', schema)
    assert result == ({"type": "test"}, [])
    result = validate_json('{"type": 1}', schema)
    assert result == (
        {"type": 1},
        [
            Message(
                type="error",
                text="Expected type 'string' for property 'type', got 1.",
                code="type_error",
                pointer="/type",
            )
        ],
    )

# Generated at 2022-06-24 11:16:35.325066
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
        {
            "one": 1,
            "two": 2,
            "three": {
                "four": {
                    "five": [
                        1,
                        2
                    ],
                    "six": [
                    ]
                }
            }
        }
    """
    token = tokenize_json(content)

    assert isinstance(token, DictToken)
    assert isinstance(token.data, dict)

    assert token.data["one"] == 1
    assert token.data["two"] == 2
    assert isinstance(token.data["three"], dict)
    assert isinstance(token.data["three"]["four"], dict)
    assert isinstance(token.data["three"]["four"]["five"], list)

# Generated at 2022-06-24 11:16:42.078601
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
      "array": [
        1,
        2,
        3,
        4
      ],
      "boolean": true,
      "null": null
    }
    """
    expected = {
        "array": [1, 2, 3, 4],
        "boolean": True,
        "null": None
    }
    actual_token = tokenize_json(content)
    assert actual_token == expected



# Generated at 2022-06-24 11:16:48.056893
# Unit test for function validate_json
def test_validate_json():

    json_valid = '{"a": "value"}'
    json_invalid = '{"a": value}'
    
    class TestSchema(Schema):
    
        a = Field(type="string")

    try:
        value, messages = validate_json(json_valid, TestSchema)
        assert value == {"a": "value"}
        assert messages is None
    except ValidationError:
        assert False

    try:
        value, messages = validate_json(json_invalid, TestSchema)
        assert False
    except ValidationError as e:
        assert e.context["line_no"] == 1
        assert e.context["column_no"] == 10
        assert e.context["char_index"] == 9
        assert e.code == "parse_error"


# Generated at 2022-06-24 11:16:51.017027
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="fake-content")
    assert decoder.content == "fake-content"



# Generated at 2022-06-24 11:16:52.059138
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()


# Generated at 2022-06-24 11:17:01.428875
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"a": 1}', {"a": int}) == ({'a': 1}, [])
    assert validate_json('{"a": "a"}', {"a": str}) == ({'a': 'a'}, [])
    assert validate_json(json.dumps({"a": "a"}), {"a": str}) == ({'a': 'a'}, [])
    assert validate_json({"a": "a"}, {"a": str}) == ({'a': 'a'}, [])

    # invalid type
    messages = validate_json('{"a": 1}', {"a": str})[1]
    assert len(messages) == 1
    assert messages[0].text == "Invalid value 1."

# Generated at 2022-06-24 11:17:03.150680
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    c = _TokenizingDecoder.__init__(0, 0)
    assert c == None

# Generated at 2022-06-24 11:17:09.003679
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"id": [1, 2, 3]}'
    result = tokenize_json(content)
    assert result.children[0].children == [1, 2, 3]
    assert result.children[0].pos.column_no == 7
    assert result.children[0].pos.line_no == 1
    assert result.children[0].pos.char_index == 7



# Generated at 2022-06-24 11:17:17.758204
# Unit test for function validate_json
def test_validate_json():
    # type: () -> None
    # Schema definition
    class PersonSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer()
        hobbies = fields.Array(fields.String())
        address = fields.String()

    # Validate basic json input and check if it returns the correct values
    valid_json = """
        {
            "name" : "Test",
            "age" : 12,
            "hobbies" : [ "reading", "writing" ],
            "address" : "404 Not found."
        }
    """
    errors = validate_json(valid_json, PersonSchema)
    assert errors is True

    # Validate basic json input, but with empty address and check
    # if it returns the correct values

# Generated at 2022-06-24 11:17:26.395780
# Unit test for function tokenize_json
def test_tokenize_json():
    json_test = """{
        "field1": "foo",
        "field2": "bar",
        "nested_json": {
            "nested_field1": "foo",
            "nested_field2": "bar"
        }
    }"""
    token = tokenize_json(json_test)
    assert isinstance(token, DictToken)

    json_test = """
    [
        "foo",
        "bar",
        {
            "nested_field1": "foo",
            "nested_field2": "bar"
        }
    ]
    """
    token = tokenize_json(json_test)
    assert isinstance(token, ListToken)


# Generated at 2022-06-24 11:17:28.650242
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder.scan_once, typing.Callable)

# Generated at 2022-06-24 11:17:30.951939
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert isinstance(decoder.scan_once, typing.Callable)



# Generated at 2022-06-24 11:17:41.141981
# Unit test for function tokenize_json
def test_tokenize_json():
    for content in ["{}", "{\"foo\": 1}"]:
        token = tokenize_json(content)
        assert isinstance(token, DictToken)
    for content in ["[]", "[1, 2, 3]"]:
        token = tokenize_json(content)
        assert isinstance(token, ListToken)
    for content in ["\"string\"", "null", "true", "false", "1", "1.1", "1e2"]:
        token = tokenize_json(content)
        assert isinstance(token, ScalarToken)

    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    errors = exc_info.value.errors
    assert len(errors) == 1
    error = errors.pop()
    assert error.code == "no_content"


# Generated at 2022-06-24 11:17:53.519812
# Unit test for function validate_json
def test_validate_json():
    content = '''{
        "id": "c1",
        "name": "c1",
        "description": "description",
        "latitude": 23.12345,
        "longitude": 63.12345,
        "environment": [
            {
                "id": "e1",
                "name": "e1",
                "description": "haha"
            },
            {
                "id": "e2",
                "name": "e2",
                "description": "hoho"
            }
        ]
    }'''
    import json

    schema = json.loads(content)
    # print(schema)

# Generated at 2022-06-24 11:18:04.888792
# Unit test for function tokenize_json
def test_tokenize_json():
    # type: () -> None
    content = '{"a": "b"}'
    # The outer dict token should contain a key dict token and a key scalar token
    token_dict_positions = list(tokenize_json(content))[0].dict_positions
    assert token_dict_positions[0].start == Position(line_no=1, column_no=1, char_index=0)
    assert token_dict_positions[0].end == Position(line_no=1, column_no=9, char_index=8)
    assert token_dict_positions[0].key.data == "a"
    assert token_dict_positions[0].value.data == "b"

    # Invalid JSON should raise a tuple of (Validation Error, Error Message)

# Generated at 2022-06-24 11:18:15.503888
# Unit test for function validate_json
def test_validate_json():
    schema = {
            "title": "Example Schema",
            "type": "object",
            "properties": {
                "firstName": {
                    "type": "string"
                },
                "lastName": {
                    "type": "string"
                },
                "age": {
                    "description": "Age in years",
                    "type": "integer",
                    "minimum": 0
                }
            },
            "required": ["firstName", "lastName"]
        }
    valid_person = """{
                        "firstName": "John",
                        "lastName": "Smith",
                        "age": 25
                    }"""
    reply = validate_json(content=valid_person, validator=schema)
    assert isinstance(reply,tuple)
    assert len(reply) == 2
    value, error_mess

# Generated at 2022-06-24 11:18:21.204349
# Unit test for function validate_json
def test_validate_json():
    payload = r'[1,2,3,4]'
    validator = List[Int]
    value, errors = validate_json(payload, validator)

    assert len(errors) == 0
    assert value == [1, 2, 3, 4]

payload = {"name": "Alice", "age": 18, "friends": []}

# Generated at 2022-06-24 11:18:22.161684
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-24 11:18:32.000950
# Unit test for function validate_json
def test_validate_json():
    field = String.as_field()
    tokens, errors = validate_json(b'[1]', field)
    assert len(tokens) == 1
    assert tokens[0].value == 1
    assert len(errors) == 1
    assert errors[0]["column_no"] == 2
    assert errors[0]["line_no"] == 1
    assert errors[0]["type"] == "invalid_type"

    tokens, errors = validate_json(b'[1]', List[String].as_field())
    assert len(tokens) == 1
    assert tokens[0].value[0].value == 1
    assert len(errors) == 1
    assert errors[0]["column_no"] == 3
    assert errors[0]["line_no"] == 1

# Generated at 2022-06-24 11:18:34.683354
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        test = _TokenizingDecoder('[', ']', ':', ',')
        assert test
    except Exception:
        assert False



# Generated at 2022-06-24 11:18:42.505025
# Unit test for function validate_json
def test_validate_json():
    content = b'[1, 2, 3]'
    validator = Field(type=int)
    assert validate_json(content, validator) == ([1, 2, 3], [])

    content = b'[1, "two", 3]'
    validator = Field(type=int)
    assert validate_json(content, validator) == (
        [1, ValidationError(text="Must be a valid integer."), 3],
        [Message(
            text="Must be a valid integer.",
            code="type_error.integer",
            position=Position(column_no=7, line_no=1, char_index=6)
        )],
    )

# Generated at 2022-06-24 11:18:44.466156
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1, "b": ["1", 2]}') # Should not throw an error



# Generated at 2022-06-24 11:18:55.038742
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fundamentals import String
    from typesystem.validators import Length
    field = String(validators=[Length(min_length=2)])
    content = '{"foo": "a", "bar": "a"}'
    value, error_messages = validate_json(content, field)
    assert len(error_messages) == 2
    assert error_messages[0] == Message(
        text='Value "a" is too short. It must contain at least 2 characters.',
        code="min_length",
        field='bar',
        position=Position(column_no=10, line_no=1, char_index=9),
    )

# Generated at 2022-06-24 11:19:02.162984
# Unit test for function validate_json
def test_validate_json():
    # validator: Field
    validator = Field(
        key="key_foo",
        description="key_foo description",
        type="string",
    )
    # content: str
    content = '{"key_foo": "value_foo", "key_bar": "value_bar"}'
    
    # actual result
    actual_result = validate_json(content, validator)
    # expected result
    expected_result = (ValueError(), [])
    
    assert actual_result == expected_result

# Generated at 2022-06-24 11:19:07.499578
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder(strict=True, content="this is a test string")
    assert context.scan_once
    assert context.parse_array
    assert context.parse_string
    assert context.parse_float
    assert context.parse_int
    assert context.memo


# Generated at 2022-06-24 11:19:15.803944
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Integer

    field = String(name="my_string")
    content = '{"my_string": "test"}'
    result = validate_json(content, field)
    assert result == ("test", [])

    field = String(name="my_string")
    content = '{"my_string": 123}'
    _, errors = validate_json(content, field)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"
    assert errors[0].text == "Value must be a string."

    field = String(name="my_string")
    content = '{"my_string": null}'
    _, errors = validate_json(content, field)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"


# Generated at 2022-06-24 11:19:26.257838
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_json = """
        {
            "x": "this is an x",
            "y": {"a": "this is an a", "b": "this is an b"},
            "z": [1, 2, 3, 4]
        }
    """
    decoder = _TokenizingDecoder(content=test_json)

    assert decoder.parse_array.__name__ == "parse_array"
    assert decoder.parse_string.__name__ == "scanstring"
    assert decoder.parse_int.__name__ == "parse_int"
    assert decoder.parse_float.__name__ == "parse_float"
    assert decoder.strict == True
    assert decoder.parse_object == _TokenizingJSONObject
    assert decoder.memo == dict()
    assert decoder.scan_

# Generated at 2022-06-24 11:19:35.877652
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Check that a _TokenizingDecoder is actually an instance of JSONDecoder
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert(isinstance(decoder, JSONDecoder)), (
            "_TokenizingDecoder is not an instance of JSONDecoder"
    )
    # Check that the content attribute is set correctly
    assert(decoder.content == content), (
            "Content attribute of _TokenizingDecoder instance was not set correctly"
    )
    # Check that the JSONDecoder.scan_once attribute was replaced with the
    # proper _make_scanner callable

# Generated at 2022-06-24 11:19:42.067940
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"number": 10, "numbers": [1, 2, 3]}'
    token = tokenize_json(content)
    assert "number" in token.value
    assert token.value["number"].value == 10
    assert "numbers" in token.value
    assert token.value["numbers"].value == [1, 2, 3]
    assert token.value["numbers"][0].value == 1
    assert token.value["numbers"][1].value == 2
    assert token.value["numbers"][2].value == 3


# Generated at 2022-06-24 11:19:51.722866
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"Name": "John", "Age": 24}, {"Name": "Peter", "Age": 38}]'

    assert tokenize_json(content) == ListToken(
        [
            DictToken(
                {ScalarToken("Name", 15, 20, content): ScalarToken("John", 23, 27, content)},
                1,
                28,
                content,
            ),
            DictToken(
                {
                    ScalarToken("Name", 34, 39, content): ScalarToken(
                        "Peter", 42, 47, content
                    )
                },
                29,
                53,
                content,
            ),
        ],
        0,
        54,
        content,
    )



# Generated at 2022-06-24 11:19:53.701035
# Unit test for function validate_json
def test_validate_json():
    result = validate_json(b'{"hello": "world"}', validator=Field())
    assert result == ({"hello": "world"}, [])



# Generated at 2022-06-24 11:19:55.942210
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test constructor of class _TokenizingDecoder
    content = "content 1"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.content == content

# Generated at 2022-06-24 11:20:02.481724
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') is not None
    assert tokenize_json('{"foo": {"bar": "baz"}}') is not None
    assert tokenize_json('{"foo": 7}') is not None
    assert tokenize_json('{"foo": [1, 2, 3]}') is not None
    assert tokenize_json('{"foo": [1, {"bar": "baz"}, 3]}') is not None
    assert tokenize_json('{"foo": [1, {"bar": [4, 5, 6], "baz": "boo"}, 3]}') is not None
    assert tokenize_json('{"foo": true}') is not None
    assert tokenize_json('{"foo": null}') is not None
    assert tokenize_json('{"foo": null, "bar": "baz"}')

# Generated at 2022-06-24 11:20:08.032546
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with pytest.raises(TypeError):
        assert _TokenizingDecoder()
    with pytest.raises(TypeError):
        assert _TokenizingDecoder([1, 2, 3])
    with pytest.raises(TypeError):
        assert _TokenizingDecoder(False)
    assert isinstance(_TokenizingDecoder(content=""), JSONDecoder)



# Generated at 2022-06-24 11:20:16.894040
# Unit test for function validate_json
def test_validate_json():
    
    # Test valid json
    assert validate_json(b'{"name":"louis", "age":22}', {
        "name": str,
        "age": int
    }) == ({
        "name": "louis",
        "age": 22
    }, [])
    
    # Test invalid json
    error_messages = validate_json(b'{"name":"louis", "age":22}', {
        "name": int,
        "age": int
    })[1]
    assert error_messages[0].position == Position(line_no=1, column_no=9, char_index=9)
    assert error_messages[0].text == "Expected int."
    assert error_messages[0].code == "invalid_type"

    # Test invalid json with multiple errors

# Generated at 2022-06-24 11:20:27.826293
# Unit test for function validate_json
def test_validate_json():
    """This function tests the function validate_json"""
    import typesystem
    from json import loads

    class Color(typesystem.String):
        enum = ["red", "green", "blue"]

    class ColorSchema(typesystem.Schema):
        color = Color(required=True)

    class PersonSchema(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(required=True)
        favorite_colors = typesystem.Array(items=Color)
        best_friends = typesystem.Array(items=ColorSchema)

    # Test with a simple schema and no errors
    json_string = '{ "name":"Joe", "age":20, "favorite_colors":["red","green"] }'
    json_dict = loads(json_string)
    schema = PersonSche

# Generated at 2022-06-24 11:20:37.559954
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({"fields": {"foo": {"type": "string", "required": True}}})
    try:
        value, errors = validate_json(b"{}", schema)
    except ParseError as exc:
        assert exc.code == "no_content"
    else:  # pragma: no cover
        assert False, "Expected ParseError"

    try:
        value, errors = validate_json("{}", schema)
    except ValidationError as exc:
        assert exc.code == "value_error.missing"
    else:  # pragma: no cover
        assert False, "Expected ValidationError"

# Generated at 2022-06-24 11:20:43.774999
# Unit test for function validate_json
def test_validate_json():
    content, validator = '[{"value": "2"}, {"value": "3"}]', type('', (), {'fields': {'value': int}})()
    value, err = validate_json(content, validator)
    assert value == [{'value': 2}, {'value': 3}]
    assert err == []
    content, validator = '[{"value": "2"}, {"value": "a"}]', type('', (), {'fields': {'value': int}})()
    value, err = validate_json(content, validator)
    assert value is None
    assert [str(e) for e in err] == ['"a" is not of type "integer"']
    content, validator = '[{"name": "a"}, {"name": "3"}]', type('', (), {'fields': {'name': str}})