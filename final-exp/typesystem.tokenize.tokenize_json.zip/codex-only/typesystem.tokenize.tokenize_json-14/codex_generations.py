

# Generated at 2022-06-24 11:10:48.200103
# Unit test for function tokenize_json
def test_tokenize_json():
    # test empty string
    try:
        tokenize_json('')
    except:
        pass
    # test empty object
    assert (tokenize_json('{}') == DictToken({}, 0, 1, '{}'))
    # test empty list
    assert (tokenize_json('[]') == ListToken([], 0, 1, '[]'))
    # test null
    assert (tokenize_json('null') == ScalarToken(None, 0, 3, 'null'))
    # test true
    assert (tokenize_json('true') == ScalarToken(True, 0, 3, 'true'))
    # test false
    assert (tokenize_json('false') == ScalarToken(False, 0, 4, 'false'))
    # test string

# Generated at 2022-06-24 11:10:51.524111
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This test justs assert that the file "test_tokenize_json.json"
    can be properly tokenized.
    """
    import json

    path = os.path.join(os.path.dirname(__file__), "data", "test_tokenize_json.json")
    with open(path, "r") as f:
        json_input = json.load(f)
    token = tokenize_json(json.dumps(json_input))
    json_output = token.to_python()
    assert json_output == json_input


# Generated at 2022-06-24 11:10:57.319169
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema, String
    from typesystem.fields import String as StringField
    from typesystem.fields import Dict
    from typesystem.fields.base import FieldError
    from typesystem.json_ import parse_json, validate_json
    import json

    # An example of using parse_json, then validate_json with a single field
    string_field = String(
        name="string_field",
    )
    good_value = parse_json('"string_value"')
    good_value, errors = validate_json(good_value, string_field)
    assert errors is None
    print(json.dumps(errors, indent=2))
    bad_value = parse_json('123')
    _, errors = validate_json(bad_value, string_field)

# Generated at 2022-06-24 11:11:00.485986
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json("{'a': 1}")
    assert token[0]["value"] == "'a'"
    assert token[1]["value"] == 1


# Generated at 2022-06-24 11:11:04.584817
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    result = _TokenizingDecoder(content="content",strict=True)
    assert result.scan_once is not None
    assert result.parse_object is not None
    assert result.parse_array is not None
    assert result.parse_string is not None
    assert result.match_number is not None

# Generated at 2022-06-24 11:11:10.988091
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Field(required=True, type_class=str, allow_none=False)
    value, errors = validate_json(content, validator)
    # validate_json returns a (value, error_messages) tuple, where
    # error_messages is a list of either ValidationError or ParseError messages
    assert value == {"foo": "bar"}
    assert not errors

    # Here's an example where the user passes in a bad json string
    content = '{"foo": "bar"'
    value, errors = validate_json(content, validator)
    # errors is a list of ParseError messages, each one providing a position
    # within the string where the error occured
    assert not value
    assert len(errors) == 1

# Generated at 2022-06-24 11:11:12.395534
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    if not callable(_TokenizingDecoder):
        print('Failed')

# Generated at 2022-06-24 11:11:13.157044
# Unit test for function validate_json
def test_validate_json():
    pass

# Generated at 2022-06-24 11:11:24.624113
# Unit test for function tokenize_json
def test_tokenize_json():
    def test(should: Token, content: str):
        """
        Test that tokenizing the given content creates an equivalent token.
        """
        actual = tokenize_json(content)
        assert actual == should

    test(_int(123), "123")
    test(_float(12.3), "12.3")

    test(_str('"\'"'), '"\\"\'"')
    test(_str('"\'"'), "'\\'\"'")

    test(_list([_int(1)]), "[1]")
    test(_list([_int(1), _int(2)]), "[1, 2]")
    test(_list([_int(1), _int(2), _int(3)]), "[1, 2, 3]")


# Generated at 2022-06-24 11:11:29.747414
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class MyJSONDecoder(JSONDecoder):
        # Override the default parse_float (parse_int is handled by
        # JSONArray and JSONObject, because the main JSONDecoder is not
        # used for those):
        parse_float = float

    _make_scanner(MyJSONDecoder(), "content")

# Generated at 2022-06-24 11:11:32.304972
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"a\":{\"b\":1}}"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once == _make_scanner(decoder, content)


# Generated at 2022-06-24 11:11:39.502832
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Schema({
        "foo": str
    })
    value, messages = validate_json(content, validator)
    assert value == {'foo': 'bar'}
    assert messages == []
    content = '{"foo": "bar", "baz": "qux"}'
    with pytest.raises(ValidationError) as exc:
        value, messages = validate_json(content, validator)
    assert exc.value.messages == [
        Message(
            text=": contains additional properties [::foo]",
            code="properties_validator.additional_properties",
            position=Position(column_no=2, line_no=1, char_index=1),
        )
    ]

# Generated at 2022-06-24 11:11:45.717222
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '[{"a": 1, "b": 2}, {"c": 0, "d": 9}, {"e": "2", "f": "3"}]'
    decoder = _TokenizingDecoder(content=content)
    token, _ = decoder.scan_once(content, 0)
    assert isinstance(token, ListToken)



# Generated at 2022-06-24 11:11:52.582145
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(value={}, start=0, end=1, content="{}")
    assert tokenize_json('{"a": 1}') == DictToken(
        value={"a": ScalarToken(value=1, start=3, end=3, content='{"a": 1}')},
        start=0,
        end=6,
        content='{"a": 1}',
    )
    assert tokenize_json("[]") == ListToken(value=[], start=0, end=1, content="[]")
    assert tokenize_json("null") == ScalarToken(value=None, start=0, end=3, content="null")
    assert tokenize_json("true") == ScalarToken(value=True, start=0, end=3, content="true")


# Generated at 2022-06-24 11:11:54.504759
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with assert_raises(TypeError):
        _TokenizingDecoder(content = "Hello World!")


# Generated at 2022-06-24 11:12:04.294563
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    This test aims to check if the tokenize_json function works properly
    '''

    # Input json file for this test
    with open('tests/test_json.json') as json_file:
        json_data = json.load(json_file)


    # Check different input types
    assert type(tokenize_json(json_data['empty'])) == DictToken
    assert type(tokenize_json(json_data['valid'])) == DictToken
    assert type(tokenize_json(json_data['int'])) == DictToken
    assert type(tokenize_json(json_data['float'])) == DictToken
    assert type(tokenize_json(json_data['bool'])) == DictToken
    assert type(tokenize_json(json_data['string'])) == DictToken


# Generated at 2022-06-24 11:12:13.232427
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_string = '{"x": 1, "y": [2, 3]}'
    json_obj = {"x": 1, "y": [2, 3]}
    scanner = _TokenizingDecoder(content=json_string)

    assert scanner.strict == True
    assert scanner.parse_float("3.14") == float(3.14)
    assert scanner.parse_int("12") == int(12)
    assert scanner.parse_array((json_string, 1), R=scanner.scan_once) == ([2,3],19)
    assert scanner.parse_object((json_string,1),strict=scanner.strict,scanner=scanner.scan_once,m={},content=json_string) == (json_obj,18)



# Generated at 2022-06-24 11:12:17.275860
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "Bob"}'
    class PersonSchema(Schema):
        name = Field(type="string")
    token = tokenize_json(content)
    assert validate_with_positions(token, PersonSchema) == ({"name": "Bob"}, [])



# Generated at 2022-06-24 11:12:27.818936
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    assert validate_json("42", int) == (42, [])

    # Invalid JSON
    line_no = 1
    column_no = 3
    char_index = 2
    position = Position(column_no=column_no, line_no=line_no, char_index=char_index)
    message = Message(
        code="parse_error",
        message="Expecting value.",
        position=position,
        text="""Expecting value."""
    )
    assert validate_json("n u", int) == (None, [message])

    # Parse error for value different than expected
    line_no = 1
    column_no = 2
    char_index = 1
    position = Position(column_no=column_no, line_no=line_no, char_index=char_index)

# Generated at 2022-06-24 11:12:34.311178
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
        '{"value": "string"}',
        Schema({"value": Field(type="string")}),
    ) == ({'value': 'string'}, [])

    value, messages = validate_json(
        '{"value": "string"}',
        Schema({"value": Field(type="integer")}),
    )

    assert value is None
    assert len(messages) == 1
    assert messages[0].text == "Integer expected."
    assert messages[0].position.line_no == 1
    assert messages[0].position.column_no == 4
    assert messages[0].position.char_index == 4

# Generated at 2022-06-24 11:12:39.471422
# Unit test for function validate_json
def test_validate_json():
   from typesystem import Field, Number, String, Schema, Message

   class Product(Schema):
       title = String(max_length=100)
       price = Number(minimum=0)

   validator = Product()
   content = '{"title": "Shoe", "price": 100.0}'
   value, errors = validate_json(content, validator)
   assert not errors
   assert value == {"title": "Shoe", "price": 100.0}  # type: ignore

   content = '{"title": "Shoe", "price": -1}'
   _, errors = validate_json(content, validator)

# Generated at 2022-06-24 11:12:43.155042
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{    "deduce": "inferences",        "marvel": true}'
    assert tokenize_json(content) == {
        "deduce": "inferences",
        "marvel": True,
    }



# Generated at 2022-06-24 11:12:45.488999
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.content == "content"

# Generated at 2022-06-24 11:12:55.959153
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"foo":"bar"}', {"type": "object"}) == ('{"foo":"bar"}', [])
    assert validate_json('{"foo":"bar"}', {"type": "object", "extra": "ignore"}) == ('{"foo":"bar"}', [])

    assert validate_json('{"foo":"bar"}', {"type": "object", "properties": {"foo": {"type": "string"}}}) == ('{"foo":"bar"}', [])
    assert validate_json('{"foo":"bar", "baz": 1}', {"type": "object", "properties": {"foo": {"type": "string"}}}) == ('{"foo":"bar", "baz": 1}', [])

# Generated at 2022-06-24 11:12:59.465925
# Unit test for function tokenize_json
def test_tokenize_json():

    jsonString = '[{"a":"b"},{"c":"d"}]'
    assert isinstance(tokenize_json(jsonString), ListToken)

    jsonString = '{"a":"b"}'
    assert isinstance(tokenize_json(jsonString), DictToken)

# Generated at 2022-06-24 11:13:08.383423
# Unit test for function validate_json
def test_validate_json():
    """
    This function uses a json string and validates the string by
    creating a schema and passing it to the validate_json function.
    """
    json_string = '''{
        "product": "Hiexl",
        "price": {
            "base": 500,
            "vat": 24,
            "discount": 0.2
        },
        "availability": [ ]
    }'''

    class ProductSchema(Schema):
        price = {"base": int, "vat": float, "discount": float}
        availability = [str]

    res, err = validate_json(json_string, ProductSchema)

    assert err == []
    assert res["price"]["base"] == 500
    assert res["price"]["vat"] == 24.0

# Generated at 2022-06-24 11:13:19.676655
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder()
    assert context.parse_float('.5') == .5
    assert context.parse_float('1.5') == 1.5
    assert context.parse_int('1') == 1
    assert context.parse_int('1.1') is None
    assert context.parse_string('""') == ''
    assert context.parse_string('"ab"') == 'ab'
    assert context.strict is True
    assert context.memo == {}
    assert context.content == ''

    context = _TokenizingDecoder(content='test')
    assert context.parse_string('""') == ''
    assert context.parse_string('"ab"') == 'ab'
    assert context.memo == {}
    assert context.content == 'test'


# Generated at 2022-06-24 11:13:30.159013
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions

    token = tokenize_json("""
    {
        "a": [1, "Hello", true],
        "b": 2
    }
    """)
    assert isinstance(token, DictToken)
    assert token.start_position.char_index == 0
    assert token.end_position.char_index == 67

    assert token.value == {
        "a": [1, "Hello", True],
        "b": 2
    }

    a_token = token.value["a"]
    assert isinstance(a_token, ListToken)
    assert a_token.start_position.char_index == 13
    assert a_token

# Generated at 2022-06-24 11:13:41.605292
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    test_json = """
    {
        "name":"John",
        "age":31,
        "pets":[{"name":"Doggo","type":"dog"}]
    }
    """

    json_token = tokenize_json(test_json)
    assert json_token == {
        "name": "John",
        "age": 31,
        "pets": [{"name": "Doggo", "type": "dog"}],
    }

    # Check for equality of built-in json.loads and tokenize_json
    first_json = json.loads(test_json)
    second_json = tokenize_json(test_json)
    assert first_json == second_json
    # Test case for an empty string
    # No valid json can come from an empty string.
    test_empty_string = ""

# Generated at 2022-06-24 11:13:43.171584
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  # This is a dummy test. More tests are needed.
  assert True



# Generated at 2022-06-24 11:13:55.774563
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from typesystem.base import Message, MessageType, Position, ValidationError
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions

    class TestSchema(typesystem.Schema):
        class Meta:
            strict = True

        field = typesystem.String()

    def get_tokens(json_string: str) -> typing.Tuple[Token, int]:
        token = tokenize_json(json_string)
        assert isinstance(token, (ScalarToken, DictToken, ListToken))
        return token

    token, error_messages = validate_json('{"field": "value"}', TestSchema)
    assert isinstance(token, DictToken)
   

# Generated at 2022-06-24 11:14:02.272981
# Unit test for function validate_json
def test_validate_json():
    validator = Field(name = "test_name",
                      target_type = int,
                      required = True)
    try:
        validate_json(b'{"test_name": 10}', validator)
    except ValidationError as e:
        print(e)
        return False
    return True

# Generated at 2022-06-24 11:14:03.497670
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizingDecoder = _TokenizingDecoder()
    assert tokenizingDecoder is not None

# Generated at 2022-06-24 11:14:14.517258
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "Dmitri",
        "age": 32,
        "car": null,
        "weight": 184.5,
        "earnings": [500, 2000],
        "is_employed": true
    }
    """
    token = tokenize_json(content)
    # The entire content is transformed into this JSON dict:
    assert token.to_native() == {
        'name': "Dmitri",
        'age': 32,
        'car': None,
        'weight': 184.5,
        'earnings': [500, 2000],
        'is_employed': True,
    }

    # Nested values are also tokens:
    assert type(token) == DictToken
    assert type(token['age']) == ScalarToken

# Generated at 2022-06-24 11:14:23.915090
# Unit test for function tokenize_json
def test_tokenize_json():
    # valid json
    content = '{"username": "oguzcan", "password": "12345"}'
    token = tokenize_json(content)
    assert token.keys() == {"username", "password"}
    assert type(token) is DictToken
    value, errors = validate_json(content, DictToken())
    assert not errors

    # invalid json
    content = '{"username": "oguzcan", "password": "12345"'
    token = tokenize_json(content)
    assert token.keys() == {"username", "password"}
    assert type(token) is DictToken
    value, errors = validate_json(content, DictToken())
    assert len(errors) == 1



# Generated at 2022-06-24 11:14:25.370336
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert (_TokenizingDecoder([1, 2, 3], content=[1, 2, 3]) != None)


# Generated at 2022-06-24 11:14:29.077032
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"data": [{"id": "1"}, {"id": "2"}]}'
    token = tokenize_json(json_string)
    assert token.value == {'data': [{'id': '1'}, {'id': '2'}]}


# Generated at 2022-06-24 11:14:36.117940
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Example 1
    tokenizing_decoder = _TokenizingDecoder("content")
    assert(tokenizing_decoder.scan_once) == _make_scanner(tokenizing_decoder, "content")[0]
    # Example 2
    tokenizing_decoder = _TokenizingDecoder("content", strict=True)
    assert(tokenizing_decoder.scan_once) == _make_scanner(tokenizing_decoder, "content")[0]
    assert(tokenizing_decoder.strict)

# Generated at 2022-06-24 11:14:41.035929
# Unit test for function validate_json
def test_validate_json():
    """
    Tests the validate_json function
    """
    # Test 1: Sould return a JSON parse error
    bad_content = """
    {
        "name": "Jack",
        "age": "38",
        "friends": [
            {
                "name": "Ronny",
                "age": 41
            }
        ]
    }
    """

    class PersonSchema(Schema):
        name = String(max_length=10)
        age = Integer(gte=0)

    class FriendsSchema(Schema):
        name = String(max_length=10)
        age = Integer(gte=0)

    class ChildSchema(Schema):
        name = String(max_length=10)
        age = Integer(gte=0)
        friend = Schema(FriendsSchema)



# Generated at 2022-06-24 11:14:44.085860
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "id": "1", "name": "test"}'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-24 11:14:45.456378
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="Hellow World") is not None

# Generated at 2022-06-24 11:14:55.734631
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = '{"valid": true, "nums": [1, 2, "three"]}'
    invalid_json = '{"valid": true, invalid: false, "nums": [1, 2, "three"]}'
    tokenized_valid_json = tokenize_json(valid_json)
    with pytest.raises(ParseError):
        tokenize_json(invalid_json)
    assert tokenized_valid_json == {
        "valid": True,
        "nums": [1, 2, "three"],
    }
    assert tokenized_valid_json.to_dict() == {
        "valid": True,
        "nums": [1, 2, "three"],
    }
    assert str(tokenized_valid_json.to_dict()) == valid_json


# Generated at 2022-06-24 11:15:06.591086
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":1}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once("'", 0) == (None, 0)
    assert decoder.scan_once('"', 0) == (None, 0)
    assert decoder.scan_once("{", 0) == (None, 0)
    assert decoder.scan_once("[", 0) == (None, 0)
    assert decoder.scan_once("n", 0) == (None, 0)
    assert decoder.scan_once("t", 0) == (None, 0)
    assert decoder.scan_once("f", 0) == (None, 0)
    assert decoder.scan_once("1", 0) == (None, 0)

# Generated at 2022-06-24 11:15:09.845856
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":"b"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0) == ({'a':'b'},10)

# Generated at 2022-06-24 11:15:12.640537
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert(decoder.scan_once() == None)

# Generated at 2022-06-24 11:15:24.354173
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, validators

    class PersonSchema(Schema):
        first = String(min_length=1)
        last = String(required=True)
        is_active = String(validators=[validators.IsTrue()])

    content = b'{"first": "James", "last": "Tiberius", "is_active": "True"}'
    value, errors = validate_json(content=content, validator=PersonSchema)
    assert value == {"first": "James", "last": "Tiberius", "is_active": "True"}
    assert errors == []

    content = b'{"first": "James", "last": "Tiberius", "is_active": "False"}'
    value, errors = validate_json(content=content, validator=PersonSchema)
    assert value is None


# Generated at 2022-06-24 11:15:27.895213
# Unit test for function tokenize_json
def test_tokenize_json():
    data = '{"key":"value"}'
    token = tokenize_json(data)
    assert isinstance(token, DictToken)
    assert token.value == {"key": "value"}


# Generated at 2022-06-24 11:15:38.701880
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"name": "Jane"}', Field(type="string", required=True)) == (
        {"name": "Jane"},
        [],
    )
    assert validate_json(
        b'{"name": "Jane"}',
        Schema({"name": Field(type="string", required=True)}),
    ) == ({"name": "Jane"}, [])

    assert validate_json(b'{"name": "Joe"}', Field(type="string", required=True)) == (
        {"name": "Joe"},
        [],
    )
    assert validate_json(b'{"name": "Joe"}', Field(type="string")) == (
        {"name": "Joe"},
        [],
    )

# Generated at 2022-06-24 11:15:49.412985
# Unit test for function tokenize_json
def test_tokenize_json():
    json = "[1,2,12.2,true]"
    token = tokenize_json(json)
    assert isinstance(token, ListToken)
    assert token.value == [1,2,12.2,True]
    assert token.start == 0
    assert token.end == 17

    json = '{"key":true}'
    token = tokenize_json(json)
    assert isinstance(token, DictToken)
    assert token.value == {"key":True}
    assert token.start == 0
    assert token.end == 12

    json = '{"key1":{"key2":1}}'
    token = tokenize_json(json)
    assert isinstance(token, DictToken)
    assert token.value == {"key1":{"key2":1}}
    assert token.start == 0

# Generated at 2022-06-24 11:15:51.651315
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": 1, "b": "abcd"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder is not None, "decoder should not be None"

# Generated at 2022-06-24 11:15:54.461453
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test_content")
    assert isinstance(decoder, _TokenizingDecoder)


# Generated at 2022-06-24 11:16:04.726865
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(content='null', validator=float) == (None, ValidationError(message='Cannot parse value "null" as a float.'))

from pprint import pprint
from typing import Any

from typesystem.tokenize.tokens import Token
from typesystem.tokenize.validation import validate_with_positions
from typesystem.validators import String, Number

schema = String | Number

data = '"Hello"'
print(type(data))
token = tokenize_json(data)
assert isinstance(token, Token)
value, errors = validate_with_positions(token, schema)
if errors:
    pprint(errors)
else:
    print(value)

# Generated at 2022-06-24 11:16:14.182189
# Unit test for function tokenize_json
def test_tokenize_json():
    content = r'{"a": 5, "b": [1, 3, 5, 7]}'
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert result.as_dict() == {"a": 5, "b": [1, 3, 5, 7]}
    assert result.as_dict(include_positions=True) == {
        "a": ScalarToken(5, 3, 5, content),
        "b": ListToken(
            [ScalarToken(1, 12, 13, content),
            ScalarToken(3, 15, 16, content),
            ScalarToken(5, 18, 19, content),
            ScalarToken(7, 21, 22, content)],
            11, 22, content
        ),
    }


# Generated at 2022-06-24 11:16:19.348752
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class Test(JSONDecoder):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            content = kwargs.pop("content")
            super().__init__(*args, **kwargs)
            self.scan_once = _make_scanner(self, content)
    
    Test(content="hello")


# Generated at 2022-06-24 11:16:20.753122
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("test")


# Generated at 2022-06-24 11:16:22.037880
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decode = _TokenizingDecoder(content="")



# Generated at 2022-06-24 11:16:31.212559
# Unit test for function validate_json
def test_validate_json():
    """
    Test output of JSON validation of valid and invalid content.
    """
    # Valid JSON should return None if errors is empty
    valid_json = '{"foo": 42, "bar": "baz"}'
    valid_json_errors = validate_json(
        content = valid_json,
        validator = Schema.from_dict({"foo": int, "bar": str})
    )[1]
    assert valid_json_errors == None

    # invalid JSON should return a non-empty errors list
    invalid_json = '{"foo": 42}'
    invalid_json_errors = validate_json(
        content = invalid_json,
        validator = Schema.from_dict({"foo": int, "bar": str})
    )[1]
    assert invalid_json_errors[0].code == "required"



# Generated at 2022-06-24 11:16:43.136494
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test a simple example to confirm the function works.
    """
    test_json = '{"string": "hello", "integer": 123, "float1": 1.23, "float2": -1.23e-10, "boolean":false}'
    test_json2 = '{"array": ["hello", 123, 1.23, null, false]}'

    expected_result_string = ScalarToken('hello', 12, 18, test_json)
    expected_result_integer = ScalarToken(123, 28, 31, test_json)
    expected_result_float1 = ScalarToken(1.23, 40, 44, test_json)
    expected_result_float2 = ScalarToken(-1.23e-10, 54, 63, test_json)

# Generated at 2022-06-24 11:16:45.543969
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class TestDecoder(JSONDecoder):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            content = kwargs.pop("content")
            super().__init__(*args, **kwargs)
            self.scan_once = _make_scanner(self, content)
    assert TestDecoder


# Generated at 2022-06-24 11:16:54.899973
# Unit test for function validate_json
def test_validate_json():
    input_json = '{"first": "wonderful", "second": "amazing"}'
    json_schema = Schema(fields={"first": str, "second": str})
    result, _ = validate_json(input_json, json_schema)
    assert result == {"first": "wonderful", "second": "amazing"}

    input_json = '{"first": "wonderful", "second": "amazing", "third": "not_defined"}'
    json_schema = Schema(fields={"first": str, "second": str})
    _, errors = validate_json(input_json, json_schema)

# Generated at 2022-06-24 11:17:00.376952
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"foo\":1}"
    decoder = _TokenizingDecoder(content=content)
    
    assert type(decoder) == _TokenizingDecoder
    assert decoder.strict == True
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant == JSONDecoder.parse_constant
    
    

# Generated at 2022-06-24 11:17:08.569870
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"a":1, "b": [1, 2], "c": null}'
    tokens = tokenize_json(json)
    assert isinstance(tokens, DictToken)
    assert tokens.value == {'a': 1, 'b': [1, 2], 'c': None}
    assert tokens.start == 0
    assert tokens.end == len(json) - 1

    for key in tokens.value.keys():
        assert isinstance(key, ScalarToken)
        assert key.value == key
        assert isinstance(tokens.value[key], Token)



# Generated at 2022-06-24 11:17:13.536528
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_token_equal(
        got: Token, expected_value: typing.Any, expected_pos: Position
    ) -> None:
        assert got.value == expected_value
        assert got.start_pos == expected_pos
        assert got.end_pos == expected_pos
        assert got.content == expected_content
        assert isinstance(got, type(expected_token))

    # Test for empty JSON strings
    for empty_json in ["", "     "]:
        expected_pos = Position(column_no=1, line_no=1, char_index=0)
        try:
            tokenize_json(empty_json)
        except ParseError as exc:
            assert exc.code == "no_content"
            assert exc.position == expected_pos

# Generated at 2022-06-24 11:17:18.586107
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_string = "{\"a\": 1}"
    decoder = _TokenizingDecoder(json_string)
    assert decoder.scan_once(json_string, 0)[0].value == '{'
    # decoder.scan_once(json_string, 0)[0].value.__repr__() == "{'a': 1}"



# Generated at 2022-06-24 11:17:21.188670
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json(content='{"first":"value1","second":"value2"}')
    assert isinstance(token, DictToken)


# Generated at 2022-06-24 11:17:31.702397
# Unit test for function tokenize_json
def test_tokenize_json():
    # Given
    json_content = """
        {
            "name": "Timmy",
            "age": "9",
            "favourite_things": [
                "birds",
                "flowers",
                "worms"
            ],
            "favourite_thing": {
                "description": "cute",
                "name": "bird",
                "special_powers": ["flying", "chirping", "pooping"]
            }
        }
    """

    # When
    token = tokenize_json(json_content)

    # Then

# Generated at 2022-06-24 11:17:41.603937
# Unit test for function tokenize_json
def test_tokenize_json():
    json = """
    {
        "name": "Jonathan",
        "age": 30,
        "likes": [
            "Python",
            "Django"
        ]
    }
    """
    token = tokenize_json(json)
    assert type(token) == DictToken
    assert token.key_at(0) == "name"
    assert token.value_at(0) == "Jonathan"
    assert token.key_at(1) == "age"
    assert token.value_at(1) == 30
    assert token.key_at(2) == "likes"
    assert type(token.value_at(2)) == ListToken
    assert token.value_at(2).value_at(0) == "Python"

# Generated at 2022-06-24 11:17:53.768874
# Unit test for function validate_json
def test_validate_json():
    content = """
    {
        "name": "John",
        "age": 40,
        "hobbies": ["gardening", "football"],
        "address": {
            "street": "123 Example Street",
            "city": "Some City",
            "state": "Some State",
            "postal_code": "1234"
        },
        "other_names": ["Johnny", "Johnny Boy"]
    }
    """

# Generated at 2022-06-24 11:17:59.309792
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    testinput = b'{"foo": 42}'
    testcontent = testinput.decode("utf-8", "ignore")
    decoder = _TokenizingDecoder(content=testcontent)
    assert hasattr(decoder, 'scan_once')


# Generated at 2022-06-24 11:18:09.123813
# Unit test for function tokenize_json
def test_tokenize_json():

    test_string = '{"foo": 12, "bar": "baz"}'

# Generated at 2022-06-24 11:18:17.955792
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{}', Schema) == (
        {},
        [],
    )
    assert validate_json('{}', Schema(fields={})) == (
        {},
        [],
    )
    assert validate_json('{"x":1}', Schema(fields={"x":Field(required=True)})) == (
        {"x":1},
        [],
    )
    assert validate_json('{"x":1}', Schema(fields={})) == (
        {},
        [
            ValidationError(
                code="unknown_field",
                text="Unexpected field 'x'.",
                position=Position(column_no=1, char_index=0, line_no=1),
            ),
        ],
        )

# Generated at 2022-06-24 11:18:25.049477
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Tests if tokenize_json works as expected, both successful and unsuccessful
    """
    content = '{"foo": "bar", "baz": "qux"}'
    token = tokenize_json(content)
    assert (token.keys() == {'foo', 'baz'})
    assert (token.values() == {ScalarToken("bar", 4, 8, content),
                               ScalarToken("qux", 18, 22, content)})



# Generated at 2022-06-24 11:18:29.768715
# Unit test for function validate_json
def test_validate_json():
    # Arrange
    validator = Schema(fields={"name": Field(type="string"), "age": Field(type="integer")})

    # Act
    (value, error_messages) = validate_json('{"name": "foo", "age": 42}', validator)

    # Assert
    assert value['name'] == 'foo'
    assert value['age'] == 42
    assert not error_messages

# Generated at 2022-06-24 11:18:40.072013
# Unit test for function tokenize_json
def test_tokenize_json():
    def check_token(text, token):
        assert tokenize_json(text) == token
    check_token('""', ScalarToken(value="", start=0, end=1, content='""'))
    check_token(
        '"test"', ScalarToken(value="test", start=0, end=5, content='"test"')
    )
    check_token('false', ScalarToken(value=False, start=0, end=5, content='false'))
    check_token('true', ScalarToken(value=True, start=0, end=4, content='true'))
    check_token('null', ScalarToken(value=None, start=0, end=4, content='null'))

# Generated at 2022-06-24 11:18:42.472307
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''{
        "foo": "bar",
        "fizzbuzz": 10
    }
    '''
    tokens = tokenize_json(content)
    assert isinstance(tokens, DictToken)



# Generated at 2022-06-24 11:18:45.010981
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"name": 0}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0) == ({'name': 0}, 9)



# Generated at 2022-06-24 11:18:46.603147
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content='test')

# Generated at 2022-06-24 11:18:51.675882
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"title": "hello world"}'

    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)

    assert token.start_column_no == 0
    assert token.start_line_no == 0

    assert token.end_column_no == 24
    assert token.end_line_no == 0



# Generated at 2022-06-24 11:18:52.868270
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass


# Generated at 2022-06-24 11:19:03.463010
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.tokens import Token

    token = DictToken(
        {
            ScalarToken("a", 1, 5, '{"a": 1, "b": 2}'): ScalarToken(
                1, 7, 8, '{"a": 1, "b": 2}'
            ),
            ScalarToken("b", 10, 14, '{"a": 1, "b": 2}'): ScalarToken(
                16, 17, '{"a": 1, "b": 2}'
            ),
        },
        0,
        19,
        '{"a": 1, "b": 2}',
    )

# Generated at 2022-06-24 11:19:11.452615
# Unit test for function tokenize_json
def test_tokenize_json():
    json = r'{ "name": "Jack", "age": 42 }'
    token = tokenize_json(json)
    assert token.value == {"name": "Jack", "age": 42}
    assert isinstance(token, dict)
    assert isinstance(token["name"], ScalarToken)
    assert token["name"].value == "Jack"
    assert token["name"].start_pos == 10
    assert token["name"].end_pos == 15



# Generated at 2022-06-24 11:19:20.018763
# Unit test for function validate_json
def test_validate_json():
    import typesystem

    class User(typesystem.Schema):
        username = typesystem.String(max_length=255)
        password = typesystem.String(max_length=255)

    user_data = {
        "username": "nick+test@nickw.me",
        "password": "password",
    }

    json_data = json.dumps(user_data)

    value, errors = validate_json(json_data, User)
    assert errors == []
    assert value == user_data

# Generated at 2022-06-24 11:19:28.764978
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken({"foo": "bar"}, 0, 12, '{"foo": "bar"}')
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, "[1, 2, 3]")
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')

#

# Generated at 2022-06-24 11:19:31.548738
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder(): 
    decoder = _TokenizingDecoder("content")
    assert decoder.scan_once("_scan_once")

# Generated at 2022-06-24 11:19:35.551824
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = _TokenizingDecoder(content='{"a":1, "b":2}')
    assert a.scan_once("{\"a\":1, \"b\":2}", 0)[0].value == {"a": 1, "b": 2}


# Generated at 2022-06-24 11:19:43.061955
# Unit test for function tokenize_json
def test_tokenize_json():
    simple_dict = {
        "foo": "bar",
    }

    complex_dict = {
        "foo": "bar",
        "baz": {
            "x": 23,
            "y": [1,2,3]
        },
        "banana": False,
        "papi": [
            12,
            {
                "a": "b",
                "c": ["d","e"]
            }
        ]
    }

    simple_list = [1,2,3]

    complex_list = [
        {
            "foo": "bar"
        },
        ["baz", 23],
        {"banana": False},
        [
            {"x": "y"},
            [3,4,5]
        ]
    ]


# Generated at 2022-06-24 11:19:53.529550
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({
        'name': String(),
        'age': Integer,
    })
    value, errors = validate_json(b'{"name": "Bob", "age": 21}', schema)
    assert {} == errors
    assert {'name': 'Bob', 'age': 21} == value

    value, errors = validate_json(b'{"name": "Bobby", "age": 25}', schema)
    assert {} == errors
    assert {'name': 'Bobby', 'age': 25} == value

    schema = Schema({
        'first_name': String(),
        'last_name': String()
    })
    value, errors = validate_json(
        b'{"first_name": "Alex", "last_name": "Smith"}', schema)
    assert {} == errors

# Generated at 2022-06-24 11:19:59.488357
# Unit test for function tokenize_json
def test_tokenize_json():
    assert(tokenize_json('') == "")
    assert(tokenize_json('{}') == {})
    assert(tokenize_json('{"a": 1}') == {"a": 1})
    assert(tokenize_json('[1, 2, 3]') == [1, 2, 3])
    assert(tokenize_json('null') == None)
    assert(tokenize_json('true') == True)
    assert(tokenize_json('false') == False)

    with pytest.raises(ParseError):
        tokenize_json('{"a": 1')

# Generated at 2022-06-24 11:20:00.911230
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder([], 0, 0)


# Generated at 2022-06-24 11:20:11.740000
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unittest for tokenize_json
    """
    content_1 = '{"prop1": [2, 3], "prop2": null}'
    content_2 = '{"prop1": {"prop3": 4.5}, "prop2": true}'
    content_3 = '{"prop1": [2, 3], "prop2": 5}'
    content_4 = '{"prop1": [2, 3], "prop2": 5.0}'
    content_5 = '{"prop1": [2, 3], "prop2": 5.1}'
    content_6 = '{"prop1": [2, 3], "prop2": "text"}'

    token_1 = tokenize_json(content_1)
    token_2 = tokenize_json(content_2)
    token_3 = tokenize

# Generated at 2022-06-24 11:20:21.642533
# Unit test for function tokenize_json
def test_tokenize_json():
    test_tokenize_json.token = tokenize_json(b'[{"d": true}, {"a": 123, "b": "true"}, 1.0, [0, 1, 2]]')
    assert isinstance(test_tokenize_json.token, ListToken)
    assert len(test_tokenize_json.token) == 4
    for item in test_tokenize_json.token:
        assert isinstance(item, Token)
        if isinstance(item, ListToken):
            assert len(item) == 3
            for subitem in item:
                assert isinstance(subitem, ScalarToken) and isinstance(subitem.value, int)
        elif isinstance(item, ScalarToken):
            assert isinstance(item.value, float) and item.value == 1.0

# Generated at 2022-06-24 11:20:24.918302
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder("abc")
    assert d.scan_once("abc", 0) == (ScalarToken("abc", 0, 2, "abc"), 3)



# Generated at 2022-06-24 11:20:26.705947
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    result = _TokenizingDecoder(content='{"a":"test"}')
    assert result != None


# Generated at 2022-06-24 11:20:33.609783
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Int
    from typesystem.types import Array
    from typesystem.tokenize.positional_validation import positional_error_format

    errors = validate_json(b"[1, 2]", Array[Int]())
    assert positional_error_format(errors) == ""

    errors = validate_json(b"[1, 2", Array[Int]())
    assert positional_error_format(errors) == "Line 1, character 6:\n    Unexpected end of JSON input.\n"

    errors = validate_json(b"[1, 3]", Array[Int]())
    assert positional_error_format(errors) == "Line 1, character 2:\n    [1] should be <type 'int'>\n"



# Generated at 2022-06-24 11:20:43.226960
# Unit test for function validate_json
def test_validate_json():
    class ListSchema(Schema):
        items = Field(type=int)

    content = '["one", "two", "three"]'