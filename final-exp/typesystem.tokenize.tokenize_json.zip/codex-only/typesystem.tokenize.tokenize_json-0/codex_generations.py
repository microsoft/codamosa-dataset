

# Generated at 2022-06-24 11:10:42.339077
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token, ScalarToken, DictToken, ListToken
    assert isinstance(tokenize_json(""), Token)
    assert isinstance(tokenize_json("{}"), DictToken)
    assert isinstance(tokenize_json("[]"), ListToken)
    assert isinstance(tokenize_json("7"), ScalarToken)
    with pytest.raises(ParseError):
        tokenize_json("{")



# Generated at 2022-06-24 11:10:53.405526
# Unit test for function validate_json
def test_validate_json():
    """
    This unit test makes sure that validate_json properly validates a given
    example (in this case, a simple JSON string).
    """
    # This defines an example JSON string.
    # Note that the starting and ending quotes are deliberately omitted!
    # Furthermore, you may have to manually add quotes if you want to paste
    # this string into Python code.
    example_string = \
        r"""
        {
            "name": "John Doe",
            "age": 19,
            "is_cool": true
        }
        """

    # This defines a simple Schema class (with fields) that we want to test with validate_json.
    class TestSchema(Schema):
        name = Field(type_name="string")
        age = Field(type_name="integer")

# Generated at 2022-06-24 11:10:58.541421
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": 1}')
    assert type(token) == DictToken
    assert token.value == {"a": 1}

    with pytest.raises(ParseError):
        tokenize_json("")


# Generated at 2022-06-24 11:11:07.501505
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 100}') == tokenize_json('{"a": 100}')
    assert tokenize_json('{"a": [100, 200]}') != tokenize_json('{"a": [100, 200, 300]}')
    assert tokenize_json('{"a": 100}') != tokenize_json('{"a": 200}')
    assert tokenize_json('{"a": "value"}') != tokenize_json('{"a": "value!"}')
    assert tokenize_json('{"a": [true, false]}') == tokenize_json('{"a": [true, false]}')
    assert tokenize_json('{"a": null}') == tokenize_json('{"a": null}')


# Generated at 2022-06-24 11:11:12.703886
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
        b'{"foo": "hello", "bar": false, "baz": [1, "qux", 3.14]}',
        {
            "foo": str,
            "bar": bool,
            "baz": list
        }
    ) == ({"foo": "hello", "bar": False, "baz": [1, "qux", 3.14]}, [])

# Generated at 2022-06-24 11:11:16.451513
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "a": 1 }'
    token = tokenize_json(content)
    assert token.value == {'a': 1}


# Generated at 2022-06-24 11:11:21.792425
# Unit test for function tokenize_json
def test_tokenize_json():
    ch = ",".join(['{'] + [' '] * 500 + [' "title" : "Foo" '] + [' '] * 500 + ['}',])
    token = tokenize_json(ch)
    assert isinstance(token, DictToken)
    assert type(token.value) == dict
    assert token.value["title"] == "Foo"


# Generated at 2022-06-24 11:11:29.927784
# Unit test for function validate_json
def test_validate_json():
    import json
    import typesystem
    from typesystem import fields

    class Post(typesystem.Schema):
        title = fields.String(max_length=200, required=True)
        body = fields.String(max_length=2000, required=True)

    json_string = json.dumps({"title": "test", "body": "test"})
    value, _ = validate_json(json_string, Post)
    assert value == {"title": "test", "body": "test"}

    json_string = json.dumps({"title": "test"})
    _, errors = validate_json(json_string, Post)
    assert len(errors) == 1
    assert errors[0].text == "This field is required."

# Generated at 2022-06-24 11:11:31.425301
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(None)
    assert(decoder != None)


# Generated at 2022-06-24 11:11:39.040482
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("1", Field(type="number")) == (
        1,
        [],
    )

    assert validate_json("1", Field(type="string")) == (
        None,
        [
            Message(
                text="Value is not of type 'string'.",
                code="type_mismatch",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

    assert validate_json("[{}]", Field(type="array", items=Field(type="object"))) == (
        [{}],
        [],
    )


# Generated at 2022-06-24 11:11:40.978859
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="Hello")


# Generated at 2022-06-24 11:11:44.934008
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": 1}'
    validator = {"foo": int}
    value, errors = validate_json(content=content, validator=validator)
    assert [] == errors
    assert {'foo': 1} == value



# Generated at 2022-06-24 11:11:52.271314
# Unit test for function validate_json
def test_validate_json():
    validator = Schema.of(
        {"a": Field(int), "b": Field()}
    )
    value, error_messages = validate_json('{"a": 3, "b": "test"}', validator)
    assert value == {"a": 3, "b": "test"}
    assert error_messages == []

    value, error_messages = validate_json('{"a": "not an int", "b": "test"}', validator)
    assert value == {"a": "not an int", "b": "test"}
    assert error_messages[0].text == 'Must be an int.'

    value, error_messages = validate_json('{"a": 3, "b": 1}', validator)
    assert value == {"a": 3, "b": 1}

# Generated at 2022-06-24 11:11:56.125423
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '''{
          "name": "John Smith",
          "hometown": {
            "name": "New York",
            "id": 123
          }
        }'''
    decoder = _TokenizingDecoder(content=content)
    print(decoder)

# Generated at 2022-06-24 11:11:59.463844
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{\"key1\": [1, 2]}"
    decoder = _TokenizingDecoder(content=content)
    assert(isinstance(decoder, _TokenizingDecoder))

# Generated at 2022-06-24 11:12:07.970450
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Number

    field = Number(min_value=1, required=True)
    schema = Schema({"name": String(required=True)})
    data = '{"name": "spam", "age": 2}'
    value = [{"name": "spam", "age": 2}, []]
    with pytest.raises(ValidationError):
        field.validate({"name": "spam", "age": 2})
    with pytest.raises(ValidationError):
        schema.validate('{"name": "spam", "age": 2}')
    assert validate_json(data, schema) == (value, [])
    assert validate_json(data, field) == (2, [])

# Generated at 2022-06-24 11:12:08.933212
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="") is not None

# Generated at 2022-06-24 11:12:11.539595
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='test content')
    assert decoder.content == 'test content'


# Generated at 2022-06-24 11:12:21.081896
# Unit test for function tokenize_json
def test_tokenize_json():
    # Happy case
    test_json = """{
        "a": "b",
        "c": "d",
        "e": "f",
        "g": {
          "h": 1,
          "i": "j"
        },
        "k": ["l", "m", "n"],
        "o": null,
        "p": true,
        "q": false
      }"""
    token = tokenize_json(test_json)
    assert(token.value.get("a").value == "b")
    assert(token.value.get("c").value == "d")
    assert(token.value.get("e").value == "f")
    assert(token.value.get("g").value.get("h").value == 1)

# Generated at 2022-06-24 11:12:24.933761
# Unit test for function validate_json
def test_validate_json():
    content = '{"hello": "world"}'
    schema = Schema(
        fields={
            "hello": Field(type="string"),
        }
    )
    value, error_messages = validate_json(content, validator=schema)


# Generated at 2022-06-24 11:12:29.587175
# Unit test for function validate_json
def test_validate_json():
    class MySchema(Schema):
        name = Field(max_length=20)

    content = b'{"name":"my name is longer than 20 characters"}'
    value, errors = validate_json(content, MySchema)
    assert "name" in errors
    assert "too_long" in errors["name"]


# Generated at 2022-06-24 11:12:38.373979
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":123}') == DictToken({ScalarToken("a", 0, 2, '{"a":123}'): ScalarToken(123, 5, 7, '{"a":123}')}, 0, 8, '{"a":123}')

# Generated at 2022-06-24 11:12:40.414514
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json = '{"a": "b", "c": "d"}'
    _TokenizingDecoder(content=json).decode(json)

# Generated at 2022-06-24 11:12:42.647634
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(
        _TokenizingDecoder("{}", content="{}"),
        JSONDecoder,
    ), "Should be a JSONDecoder"

# Generated at 2022-06-24 11:12:48.611367
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # test wrong class status
    with pytest.raises(TypeError, match="object() takes no parameters"):
        _TokenizingDecoder()

    # test correct input
    decoder = _TokenizingDecoder(content='string')
    assert isinstance(decoder, _TokenizingDecoder)



# Generated at 2022-06-24 11:12:57.294511
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "prop1": "string",
        "prop2": 1,
        "prop3": true,
        "prop4": [1, 2, 3],
        "prop5": {},
        "prop6": null
    }"""
    token = tokenize_json(content)
    assert type(token) == DictToken

# Generated at 2022-06-24 11:13:00.430545
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  content = "content"

  decoder = _TokenizingDecoder(content=content)
  assert(decoder.scan_once == _make_scanner(decoder, content))


# Generated at 2022-06-24 11:13:08.957530
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Integer
    from typesystem.fields import String, Boolean
    from typesystem.schemas import Schema


    class TestSchema(Schema):
        the_bool = Boolean()
        the_int = Integer()
        the_string = String()

    json = '{ "the_bool": true, "the_int": 0, "the_string": "text" }'
    value, errors = validate_json(json, TestSchema)
    assert len(errors.errors) == 0

    json = '{ "the_bool": "Not a bool", "the_int": 0, "the_string": "text" }'
    value, errors = validate_json(json, TestSchema)
    assert len(errors.errors) == 1
    assert isinstance(errors.errors[0], ValidationError)
   

# Generated at 2022-06-24 11:13:20.228643
# Unit test for function tokenize_json
def test_tokenize_json():
    # test for valid JSON
    content = '{"a":1, "b":[1, 2, 3], "c": {"a":1, "b":2}}'
    expected = DictToken(
        {
            "a": ScalarToken(1, 4, 5, content),
            "b": ListToken([1, 2, 3], 11, 18, content),
            "c": DictToken(
                {"a": ScalarToken(1, 25, 26, content), "b": ScalarToken(2, 30, 31, content)},
                23, 32,
                content,
            ),
        },
        0,
        33,
        content,
    )
    assert tokenize_json(content) == expected

    # test for valid JSON with a string

# Generated at 2022-06-24 11:13:24.096890
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='a dict object')
    assert decoder.scan_once.__name__ == '_scan_once'
    # scan_once is a generator
    assert decoder.scan_once('abcd', 0) is not None


# Generated at 2022-06-24 11:13:33.483154
# Unit test for function tokenize_json
def test_tokenize_json():

    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 5, 9, '{"foo": "bar"}')}, 0, 13, '{"foo": "bar"}'
    )

    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.text == "No content."
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
    else:
        assert False, "expected an exception"


# Generated at 2022-06-24 11:13:36.984996
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for valid JSON content
    try:
        assert tokenize_json("{}") == {"type": "dict", "value": {}}
    except ValidationError:
        pass
    # Test for invalid JSON content
    with pytest.raises(ParseError) as e:
        assert tokenize_json("Hello World!") == {}
        assert e.args[0] == "Could not parse json: Hello World!"  # pragma: no cover

# Generated at 2022-06-24 11:13:44.939007
# Unit test for function tokenize_json
def test_tokenize_json():
    field = Field(format="tokenized_json")
    json_input = '{"a":1,"b":2,"c":3}'
    json_expected = {"a": 1, "b": 2, "c": 3}
    token, error_messages = validate_json(json_input, field)
    json_obtained = token.value
    assert json_obtained == json_expected
    assert error_messages is None

    json_invalid_input = '{"a":1"b":2,"c":3}'
    token, error_messages = validate_json(json_invalid_input, field)
    assert token is None
    assert len(error_messages) == 1
    assert error_messages[0].code == "parse_error"
    assert error_messages[0].position.column_no

# Generated at 2022-06-24 11:13:49.548053
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.tokens import DictToken
    decoder = _TokenizingDecoder(content="This is a test")
    token, _ = decoder.scan_once("null", 0)
    assert(isinstance(token, DictToken))

# Generated at 2022-06-24 11:13:52.376366
# Unit test for function validate_json
def test_validate_json():
    value = validate_json( b'{"a": 0}', { 
    "a": Field(primitive_type=int)
    })
    assert value == ({'a': 0}, {}), value


# Generated at 2022-06-24 11:13:53.781044
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-24 11:14:01.642808
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('[1,2,3,4]')
    assert token.start == 0 and token.end == 8
    assert token.value == [1,2,3,4]
    token = tokenize_json('{"abc": "abc", "def": 123, "ghi": {"abc": "abc", "def": 123}}')
    assert token.start == 0 and token.end == 53
    assert token.value == {"abc": "abc", "def": 123, "ghi": {"abc": "abc", "def": 123}}
    token = tokenize_json('[{"abc": "abc", "def": 123, "ghi": {"abc": "abc", "def": 123}}, {"abc": "abc", "def": 123, "ghi": {"abc": "abc", "def": 123}}]')

# Generated at 2022-06-24 11:14:06.224781
# Unit test for function validate_json
def test_validate_json():
    validator =  Field(type="string")
    content = bytes('"test"', 'utf-8')
    assert validate_json(content, validator) == ("test", [])
    
    content = bytes('[{"id":true}]', 'utf-8')
    assert validate_json(content, validator) == None

# Generated at 2022-06-24 11:14:13.960484
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"name": "value1"}') == {'name': 'value1'}

    content = """
    {
        "name": [
            "value1",
            "value2",
            "value3"
        ]
    }
    """
    assert tokenize_json(content) == {
        'name': ['value1', 'value2', 'value3']
    }
    assert tokenize_json(content) == tokenize_json(content.lower())



# Generated at 2022-06-24 11:14:23.394637
# Unit test for function validate_json
def test_validate_json():
    class X(Schema):
        foo = Field(type=int)
    content = '{"foo": "bar"}'
    (value, error_messages) = validate_json(content, X)
    assert value["foo"] == "bar"
    assert error_messages[0].text == "Expected value foo to be of type 'int'."
    assert error_messages[0].code == "type_error"
    assert error_messages[0].position.column_no == 8
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.char_index == 7
    assert error_messages[0].position.indent == 4

# Generated at 2022-06-24 11:14:28.964786
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == None
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 8, "[1, 2, 3]")
    assert tokenize_json('["1", "2", "3"]') == ListToken(
        ["1", "2", "3"], 0, 12, '["1", "2", "3"]'
    )
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

# Generated at 2022-06-24 11:14:33.757866
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="[1, 2, 3]")
    expected = ListToken([1, 2, 3], 0, 9, content="[1, 2, 3]")
    assert decoder.scan_once("[1, 2, 3]", 0) == (expected, 10)

# Generated at 2022-06-24 11:14:41.649408
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, validate, Number

    class TestSchema(Schema):
        name = String(max_length=10)
        age = Number()

    result = validate_json(content='{"name": "Paul", "age": 18}', validator=TestSchema)
    assert result == TestSchema(name='Paul', age=18), 'parse and validate a JSON string'

    result = validate_json(content='{"name": "Paul Thomas", "age": 18}', validator=TestSchema)
    assert result == ([('name', ['Ensure this field has no more than 10 characters.'])], TestSchema(name='Paul', age=18)), 'return positionally marked error messages on parse or validation failures'

# Generated at 2022-06-24 11:14:46.663571
# Unit test for function validate_json
def test_validate_json():
    class SimplePersonSchema(Schema):
        name = Field(type="string", max_length=100)
        age = Field(type="number", minimum=0)

    content = '{\n"name": "John Smith",\n"age": 35\n}'
    value, messages = validate_json(content, SimplePersonSchema)
    print(messages)

# Generated at 2022-06-24 11:14:55.694836
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test compatible with __init__
    validator = Field(required=True, type="integer")
    content = '{"number": 4}'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    try:
        value, errors = validate_with_positions(token=token, validator=validator)
    except Exception as e:
        print("test_tokenize: [ERROR] Value or error has not been returned.")
        return 0

    if value is not None:
        print("test_tokenize: [OK] Value and error is returned.")
        return 1
    else:
        print("test_tokenize: [ERROR] Value is not returned.")
        return 0

# Generated at 2022-06-24 11:15:04.057411
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"a": 1}'), DictToken)
    assert isinstance(tokenize_json('"string"'), ScalarToken)
    assert isinstance(tokenize_json('1'), ScalarToken)
    assert isinstance(tokenize_json('[1,2,3]'), ListToken)
    assert isinstance(tokenize_json('null'), ScalarToken)
    assert isinstance(tokenize_json('true'), ScalarToken)
    assert isinstance(tokenize_json('[1, 2, [3]]'), ListToken)


# Generated at 2022-06-24 11:15:06.608215
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert(decoder is not None)

# Generated at 2022-06-24 11:15:16.749035
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import String
    from typesystem.fields import Object
    from typesystem.schemas import Schema

    content = '{"name": "Random"}'
    token = tokenize_json(content)

    assert token.value == {'name': 'Random'}
    assert type(token) == DictToken

    content = '{"name": "Random", "age": "20"}'
    token = tokenize_json(content)

    assert token.value == {'name': 'Random', 'age': '20'}
    assert type(token) == DictToken

    class UserSchema(Schema):
        name = String()
        age = String()

    try:
        validate_json(content, UserSchema)
    except ParseError as e:
        print(e)


# Generated at 2022-06-24 11:15:24.127771
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"number": 123.4, "string": "Hello, world!", "list": [1, 2, 3], "dict": {"a": "b", "c": "d"}}'
    content_token = tokenize_json(content)
    assert content_token.token_type == "dict"
    assert content_token.value == {"number": 123.4, "string": "Hello, world!", "list": [1, 2, 3], "dict": {"a": "b", "c": "d"}}
    

# Generated at 2022-06-24 11:15:31.706793
# Unit test for function validate_json
def test_validate_json():
    field_schema = Field(type="string")
    content = '"hello"'
    value, error_messages = validate_json(content, field_schema)
    assert value == "hello"
    assert error_messages == []
    content = "123"
    value, error_messages = validate_json(content, field_schema)
    assert value is None
    assert len(error_messages) == 1
    assert error_messages[0].text.startswith("Expected string")



# Generated at 2022-06-24 11:15:39.238993
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = r'{"test": "abc"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.parse_string == scanstring
    assert decoder.parse_object == _TokenizingJSONObject
    assert decoder.parse_array == context.parse_array
    assert decoder.strict == context.strict
    assert isinstance(decoder.scan_once, type(test__make_scanner()))
    assert decoder.parse_float == context.parse_float
    assert decoder.parse_int == context.parse_int


# Generated at 2022-06-24 11:15:49.544007
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = """
    {
        "nested_list": [
            1, 2, 3,
            {
                "inner_key": "value"
            }
        ],
        "nested_dict": {
            "key_1": "value_1",
            "key_2": "value_2"
        },
        "nested_string": "string",
        "nested_number": 1.2345,
        "nested_integer": 0,
        "nested_boolean": true,
        "nested_null": null
    }
    """
    token = tokenize_json(valid_json)
    assert isinstance(token, DictToken)
    assert isinstance(token.value["nested_list"], ListToken)

# Generated at 2022-06-24 11:15:53.400393
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder()
    assert tokenizing_decoder.memo == {}
    assert tokenizing_decoder.strict == True
    assert tokenizing_decoder.parse_int == int
    assert tokenizing_decoder.parse_float == float

# Generated at 2022-06-24 11:16:04.779523
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('[{"m": 3}]')
    assert isinstance(token, ListToken)
    assert token.value == [DictToken({'m': ScalarToken(3, 1, 3, '[{"m": 3}]')}, 1, 8, '[{"m": 3}]')]

    token = tokenize_json('{"m": 3}')
    assert isinstance(token, DictToken)
    assert token.value == {'m': ScalarToken(3, 1, 3, '{"m": 3}') }

    token = tokenize_json('{"m": "xx"}')
    assert isinstance(token, DictToken)
    assert token.value == {'m': ScalarToken("xx", 1, 6, '{"m": "xx"}') }


# Generated at 2022-06-24 11:16:05.811070
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == []



# Generated at 2022-06-24 11:16:10.817079
# Unit test for function validate_json
def test_validate_json():
    json_string = b'{"name":"testing"}'

    class NameSchema(Schema):
        name = Field(type="string")

    value, error_messages = validate_json(json_string, NameSchema)
    assert(value.get("name", None) == "testing")
    assert(len(error_messages) == 0)

# Generated at 2022-06-24 11:16:21.880940
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'') == None
    assert tokenize_json(' null ') == ScalarToken(None,1,5,' null ')
    assert tokenize_json(' true ') == ScalarToken(True,1,5,' true ')
    assert tokenize_json(' false ') == ScalarToken(False,1,6,' false ')
    assert tokenize_json(' "hello" ') == ScalarToken('hello',1,8,' "hello" ')
    assert tokenize_json(' " \\n\\r\\t\\"\\b\\f\\\\\\/ " ') == ScalarToken(' \n\r\t"\b\f\\/ ',1,20,' " \\n\\r\\t\\"\\b\\f\\\\\\/ " ')

# Generated at 2022-06-24 11:16:23.951622
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "")
    assert decoder.scan_once is not None


# Generated at 2022-06-24 11:16:28.263304
# Unit test for function validate_json
def test_validate_json():
    content = json.dumps([1, 2, 4, 8, 16, 32, 64, 128])
    validator = Fields.list(Fields.integer())
    expected = [[], []]

    [value, errors] = validate_json(content, validator)
    assert value == [1, 2, 4, 8, 16, 32, 64, 128]
    assert errors == expected

# Generated at 2022-06-24 11:16:36.404935
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    [
        null,
        true,
        false,
        "string",
        1,
        1.0,
        -1,
        -1.0,
        {
            "true": true,
            "false": false,
            "null": null,
            "number": 1,
            "string": "string",
            "object": { "one": 1, "two": 2}
        },
        [1, 2, 3.0]
    ]
    """
    token = tokenize_json(content)
    assert isinstance(token, ListToken)

# Generated at 2022-06-24 11:16:37.548879
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="abc")

# Generated at 2022-06-24 11:16:38.630563
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder is not None

# Generated at 2022-06-24 11:16:41.778144
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"a": [1, 2, "c"]}')
    # Only check that the constructor does not raise any exception
    # The scan_once method is tested separately

# Generated at 2022-06-24 11:16:49.603256
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "name": "An example",
        "items": [
            {
                "name": "this is the first item",
                "value": 1.0
            },
            {
                "name": "this is the second item",
                "value": 2.0
            }
        ]
    }
    """
    token = tokenize_json(content)

# Generated at 2022-06-24 11:16:54.473449
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_text = '{"foo": [null, false, true, "bar"]}'
    c = _TokenizingDecoder(content=json_text)
    assert len(c.scan_once(json_text, 0)) == 2


# Generated at 2022-06-24 11:16:58.835470
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"a": "b"}')
    assert(token.value == {"a": "b"})
    assert(token.start == 0)
    assert(token.end == 8)
    assert(token.content == '{"a": "b"}')



# Generated at 2022-06-24 11:17:02.285618
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.token_utils import print_token

    json_str = '{"k1": 1}'
    token = tokenize_json(json_str)

    # print token to console
    print_token(token)



# Generated at 2022-06-24 11:17:08.317983
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:17:16.386307
# Unit test for function tokenize_json
def test_tokenize_json():
    '''
    Unit test for tokeize_json
    '''
    string1 = 'tokeize_json'
    token = tokenize_json(string1)
    assert token is None

    string2 = '''{"Name": "Zara", "Age": 7, "Class": "First",
              "Subjects": [
                    "English",
                    "Maths",
                    "Science"
                    ]}'''
    token = tokenize_json(string2)
    assert token.value == {
        "Name": "Zara",
        "Age": 7,
        "Class": "First",
        "Subjects": ["English", "Maths", "Science"],
    }



# Generated at 2022-06-24 11:17:20.588279
# Unit test for function validate_json
def test_validate_json():
    content = '''{
  "boolean": true,
  "integer": 3,
  "float": 3.14159,
  "array": [1, 2, 3],
  "object": {
    "name": "Bob",
    "age": 20
  }
}'''
    print(validate_json(content, Field()))

# Generated at 2022-06-24 11:17:26.385787
# Unit test for function validate_json
def test_validate_json():
    # Test handling of JSONDecodeErrors (parse errors)
    # Test that error messages contain all required info
    content = '{"abc": "123"}'
    try:
        validate_json(content=content, validator=Field(required=True))
    except ParseError as exc:
        assert exc.text == "Expecting value", "Invalid error message content"
        assert exc.code == "parse_error", "Invalid error code"
        assert exc.position.char_index == 14, "Invalid char index"
        assert exc.position.column_no == 15, "Invalid column number"
        assert exc.position.line_no == 1, "Invalid line number"

    # Test that exception is thrown if content is empty

# Generated at 2022-06-24 11:17:30.641047
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Setup part
    content = '{"msg":"Hello","number":3}'
    decoder = _TokenizingDecoder(content=content)

    # Assert part
    assert decoder.scan_once(content,0)[0] == {'msg':'Hello','number':3}


# Generated at 2022-06-24 11:17:40.968165
# Unit test for function tokenize_json
def test_tokenize_json():
    test_field = Field(callback=lambda x: x)
    result = tokenize_json("{}")
    assert isinstance(result, DictToken)
    assert result.data == {}

    result = tokenize_json("[]")
    assert isinstance(result, ListToken)
    assert result.data == []

    result = tokenize_json("{\"foo\" : 1, \"bar\" : \"banana\"}")
    assert isinstance(result, DictToken)
    assert result.data == {"foo": ScalarToken(1, 6, 6, "{\"foo\" : 1, \"bar\" : \"banana\"}"), "bar": ScalarToken("banana", 18, 24, "{\"foo\" : 1, \"bar\" : \"banana\"}")}

    result = tokenize_json("[1, 2]")


# Generated at 2022-06-24 11:17:44.720569
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder({}, content="test")
    assert isinstance(decoder, JSONDecoder)
    assert hasattr(decoder, "scan_once")


# Generated at 2022-06-24 11:17:55.570214
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({ScalarToken('key', 1, 7, '{"key": "value"}'):
                                                            ScalarToken('value', 11, 19, '{"key": "value"}')}, 0, 19,
                                                           '{"key": "value"}')

    try:
        tokenize_json('{"key": "value}')
    except ParseError as exc:
        assert exc.args == (
            "Unexpected character '}' at position 18.", "parse_error", Position(19, 1, 18)
        )
    else:
        assert False


# Generated at 2022-06-24 11:17:59.223571
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    if not hasattr(JSONDecoder, "parse_string"):
        raise AssertionError()
    try:
        JSONDecoder(strict=False)
    except TypeError:
        pass

# Generated at 2022-06-24 11:18:07.876543
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """{"x":1, "y":[2, 3], "z": {"abc": "xyz"}}"""
    json_str_tokenized = tokenize_json(json_str)

    # Testing the type of python object returned
    assert isinstance(json_str_tokenized, DictToken)

    # Testing the number of items (keys) in the dictionary
    assert len(json_str_tokenized.value) == 3

    # Testing the type of object in the list
    assert isinstance(json_str_tokenized["y"].value[1], ScalarToken)

    # Testing the value in the list
    assert json_str_tokenized["y"].value[1].value == 3


# Generated at 2022-06-24 11:18:17.183143
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function with correct json input
    """
    # test field and value
    field_value = {
      "type": "string",
      "description": "text that has no length restriction"
    }
    field = Field.from_representation(field_value)

    # correct json
    correct_json = '{"description": "text that has no length restriction"}'
    assert validate_json(correct_json, field) == (
        {"description": "text that has no length restriction"},
        [],
    )
    # wrong field type
    wrong_field_json = '{"description": 1}'

# Generated at 2022-06-24 11:18:26.941848
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Structure, Validator

    class UserSchema(Structure):
        name = String(format="first_and_last_name")

    validator = UserSchema()
    content = '{"name": "Jane Smith"}'
    result, errors = validate_json(content, validator)
    assert result == {"name": "Jane Smith"}
    assert not errors

    content = '{"name": "Jane"}'
    result, errors = validate_json(content, validator)
    assert not result
    assert errors

    content = "Jane"
    result, errors = validate_json(content, validator)
    assert not result
    assert errors



# Generated at 2022-06-24 11:18:34.208264
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"name": "john", "age": 30, "city": "London", "active": true}')
    assert isinstance(token, dict)
    assert token.__class__.__name__ == "DictToken"
    assert isinstance(token["age"], int)
    assert token["age"].__class__.__name__ == "ScalarToken"
    assert token["age"].value == 30
    assert isinstance(token["name"], str)
    assert token["name"].__class__.__name__ == "ScalarToken"
    assert token["name"].start == 10
    assert token["name"].end == 15
    assert isinstance(token["city"], str)
    assert isinstance(token["active"], bool)


# Generated at 2022-06-24 11:18:43.302155
# Unit test for function tokenize_json
def test_tokenize_json():
    content =  '''{"name": "value", "herp":["derp","blarg"]}'''
    # Verify expected tokenization
    token = tokenize_json(content)
    assert token.start_pos.line_no == 1
    assert token.start_pos.column_no == 1
    assert token.start_pos.char_index == 0
    assert token.end_pos.line_no == 1
    assert token.end_pos.column_no == 37
    assert token.end_pos.char_index == 36

    assert token.value == {
        "name": "value", "herp": ["derp", "blarg"]
    }

    # Verify error and position tracking
    content =  '''{"name": "value", "herp":["derp","blarg"]'''

# Generated at 2022-06-24 11:18:46.105259
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "test"
    dc = _TokenizingDecoder(content = test_content)
    assert dc.content == "test"
    assert dc.parse_float == float
    assert dc.parse_int == int
    assert dc.memo == {}


# Generated at 2022-06-24 11:18:57.028305
# Unit test for function validate_json
def test_validate_json():
    assert (
        validate_json(
            '{"id": 1, "name": "foo", "friend": null}',
            typing.Optional[typing.Dict[str, int]],
        )
        == ({'id': 1, 'name': 'foo', 'friend': None}, [])
    )
    assert validate_json(
        '{"id": 1, "name": "foo", "friend": null}',
        typing.Dict[str, int],
    ) == (
        None,
        [
            Message(
                code='missing',
                field_name='friend',
                text='This field is required',
                position=Position(column_no=13, line_no=1, char_index=12),
            ),
        ],
    )

# Generated at 2022-06-24 11:19:01.900297
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key1":"value1","key2":2}') == \
           DictToken({
               'key1': ScalarToken('value1', 2, 12, '{"key1":"value1","key2":2}'),
               'key2': ScalarToken(2, 13, 17, '{"key1":"value1","key2":2}')
           }, 0, 21, '{"key1":"value1","key2":2}')



# Generated at 2022-06-24 11:19:12.967660
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == ScalarToken(None, 0, 0, "")
    assert tokenize_json('  ') == ScalarToken(None, 0, 2, "  ")
    assert tokenize_json(' \n ') == ScalarToken(None, 0, 4, " \n ")

    assert tokenize_json('42') == ScalarToken(42, 0, 2, "42")
    assert tokenize_json('42.0') == ScalarToken(42.0, 0, 4, "42.0")
    assert tokenize_json('42e-2') == ScalarToken(0.42, 0, 5, "42e-2")
    assert tokenize_json('42E+2') == ScalarToken(4200, 0, 5, "42E+2")

    assert tokenize_

# Generated at 2022-06-24 11:19:24.805755
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"a": [1, 2], "b": {"c": "3", "d": 4}}')
    assert isinstance(result, DictToken)
    assert result.value["a"] == [ScalarToken(1, 6, 8), ScalarToken(2, 10, 11)]
    assert result.value["b"] == {
        "c": ScalarToken("3", 16, 20),
        "d": ScalarToken(4, 22, 24),
    }

    result = tokenize_json("[[]]")
    assert isinstance(result, ListToken)
    inner = result.value[0]
    assert isinstance(inner, ListToken)

    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.code

# Generated at 2022-06-24 11:19:28.029655
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder().scan_once(""",["a"]""", 1) == (
        ListToken([ScalarToken("a", 2, 3, '["a"]')], 1, 4, '["a"]'),
        5,
    )

# Generated at 2022-06-24 11:19:28.921377
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="mock content")

# Generated at 2022-06-24 11:19:38.585037
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test JSONDecodeError
    content = "{"
    a = {1,2,3}
    b = _TokenizingDecoder(content=content)
    def scan_once(string, idx):
        return a, 2
    b.scan_once = scan_once
    try:
        b.decode(content)
    except JSONDecodeError as exc:  # NoCover
        assert exc.msg == "Expecting value"
        assert exc.pos == 1
        assert exc.lineno == 1
        assert exc.colno == 2
    try:
        content = '{"hi": 5, "hi": 6}'
        b.decode(content)
    except JSONDecodeError as exc:  # NoCover
        assert exc.msg == "Expecting property name enclosed in double quotes"

# Generated at 2022-06-24 11:19:43.734838
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'"[1,2,3]"', bool) == ([True], [])
    assert validate_json(b'null', bool) == (None, [])
    assert validate_json(b'"hello"', int) == (
        [],
        [
            ValidationError(
                text="does not match the expected type of 'int'.",
                code="type_error.int",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )



# Generated at 2022-06-24 11:19:50.135322
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('2') == ScalarToken(2, 0, 0, '2')
    assert tokenize_json('-2.5') == ScalarToken(-2.5, 0, 3, '-2.5')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 4, 'false')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('"abcd"') == ScalarToken('abcd', 0, 5, '"abcd"')
    assert tokenize_json('"a\"cd"') == ScalarToken('a"cd', 0, 5, '"a\"cd"')
    assert tokenize_json

# Generated at 2022-06-24 11:19:51.501015
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    pass

# Generated at 2022-06-24 11:19:56.185004
# Unit test for function tokenize_json
def test_tokenize_json():
    """Asserts that tokenize_json returns expected DictToken for given json string."""

    content = '{"test": "value"}'
    token = tokenize_json(content)

    assert isinstance(token, DictToken)
    assert token.children == {
        ScalarToken("test", 0, 4, content): ScalarToken("value", 11, 18, content)
    }



# Generated at 2022-06-24 11:20:07.296565
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{'foo': 1}"
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.text == "Expecting property name enclosed in double quotes."
        assert exc.code == "parse_error"
        assert exc.position.line_no == 1
        assert exc.position.column_no == 2
        assert exc.position.char_index == 1

    content = '{"foo": 1}'
    token = tokenize_json(content)
    assert token.__class__._token_class == DictToken
    assert token["foo"].__class__._token_class == ScalarToken
    assert token["foo"].value == 1
    assert token["foo"].start.line_no == 1
    assert token["foo"].start.column_no == 8

# Generated at 2022-06-24 11:20:16.410642
# Unit test for function validate_json
def test_validate_json():
    # valid json string
    content = '{"id": 1, "name": "hello"}'
    # init a schema
    class PersonSchema(Schema):
        id = fields.Integer()
        name = fields.String()

    # validate the json string with the schema
    result, message = validate_json(content, PersonSchema)

    # validate the result
    assert result == {"id": 1, "name": "hello"}
    assert message is None

    # invalid json string
    content = '{"id": 1, "name": 10}'
    result, message = validate_json(content, PersonSchema)

    assert result is None

# Generated at 2022-06-24 11:20:20.864147
# Unit test for function validate_json
def test_validate_json():
    with open('test_data/test_samples.json','r') as f:
        data = json.loads(f.read())
    for i in range(len(data)):
        print(validate_json(data[i]['name'], str))

# Generated at 2022-06-24 11:20:21.460845
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")

# Generated at 2022-06-24 11:20:30.896991
# Unit test for function validate_json
def test_validate_json():
    validator = Schema(fields=[
        Field(name="title", required=True),
        Field(name="director", required=True),
        Field(name="year", required=True, validators=[validators.is_integer()])
    ])
    valid_json = u'{"title": "Interstellar", "director": "Christopher Nolan", "year": 2014}'
    invalid_json = u'{"title": "Interstellar", "director": "Christopher Nolan", "year": "2014"}'
    value, messages = validate_json(content=valid_json, validator=validator)
    assert value == {'title': 'Interstellar', 'director': 'Christopher Nolan', 'year': 2014}

    value, messages = validate_json(content=invalid_json, validator=validator)
    assert len(messages) == 1
    message

# Generated at 2022-06-24 11:20:33.917104
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="hello")
    assert decoder.parse_float == float
    assert decoder.parse_int == int


# Generated at 2022-06-24 11:20:37.220665
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='content')
    assert decoder.scan_once == _make_scanner(decoder, 'content'),\
        "_TokenizingDecoder failed to properly initialize"
