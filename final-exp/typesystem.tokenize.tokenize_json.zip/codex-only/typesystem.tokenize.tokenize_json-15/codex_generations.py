

# Generated at 2022-06-24 11:10:44.163953
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    decoder = _TokenizingDecoder(content = content)

    assert decoder.scan_once(content, 0)[0].content == content

# Unit tests for function _make_scanner

# Generated at 2022-06-24 11:10:45.491856
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    json.loads('true', cls=_TokenizingDecoder, content='{"a": "b"}')


# Generated at 2022-06-24 11:10:55.655666
# Unit test for function validate_json
def test_validate_json():
    # test case 1: invalid json:
    content = '{"name": "Anastasia" "id": "123"}'
    validator = Schema({"name": str, "id": str})
    expected_errors = [
        Message(
            text="Expecting ',' delimiter.",
            code="parse_error",
            position=Position(column_no=25, line_no=1, char_index=24),
        )
    ]
    assert validate_json(content, validator) == (None, expected_errors)
    # test case 2: json with invalid field:
    content = '{"name": "Anastasia", "id": 123}'

# Generated at 2022-06-24 11:10:56.975885
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(hasattr(_TokenizingDecoder(), 'scan_once'))


# Generated at 2022-06-24 11:11:07.049772
# Unit test for function tokenize_json
def test_tokenize_json():
    from unittest import TestCase, main
    from .test_utils import make_validator
    from typesystem.tokenize.positional_validation import validate_with_positions

    class TestJsonTokenizing(TestCase):
        def test_empty_input(self):
            with self.assertRaises(ParseError) as context:
                tokenize_json("")

            exc = context.exception
            self.assertEqual(exc.code, "no_content")
            self.assertEqual(exc.position.line_no, 1)
            self.assertEqual(exc.position.column_no, 1)
            self.assertEqual(exc.position.char_index, 0)


# Generated at 2022-06-24 11:11:15.811856
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key1": "value1"}') == DictToken(
        {"key1": ScalarToken("value1", 2, 11, '{"key1": "value1"}')},
        0,
        15,
        '{"key1": "value1"}',
    )

# Generated at 2022-06-24 11:11:24.413349
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 3, 4, '{"a": 1}')}, 0, 7, '{"a": 1}'
    )
    assert tokenize_json("") == ScalarToken("", 0, 0, "")
    assert tokenize_json("  ") == ScalarToken("  ", 0, 2, "  ")



# Generated at 2022-06-24 11:11:34.566635
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unit test function that validates that a valid JSON string is properly read into a
    hierarchical structure of tokens.
    """
    json_string =  \
        '''{
            "name": "John",
            "address": {
                "street": "123 Market Street",
                "city": "Somewhere"
            },
            "phoneNumbers": [
                {
                    "type": "home",
                    "number": "111-1111"
                },
                {
                    "type": "cell",
                    "number": "222-2222"
                }
            ]
        }'''
    token = tokenize_json(json_string)
    assert token.type == "object"
    assert token.keys == ["name", "address", "phoneNumbers"]
    # Test the values of the token at each level

# Generated at 2022-06-24 11:11:37.801362
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-24 11:11:43.446358
# Unit test for function validate_json
def test_validate_json():
    validator = Field()
    # Test JSON error

# Generated at 2022-06-24 11:11:52.319752
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 1}') == DictToken({ScalarToken('a', 0, 1, '{"a": 1}'): ScalarToken(1, 5, 5, '{"a": 1}')}, 0, 8, '{"a": 1}')
    assert tokenize_json('{"a": 1, "b": 2}') == DictToken({ScalarToken('a', 0, 1, '{"a": 1, "b": 2}'): ScalarToken(1, 5, 5, '{"a": 1, "b": 2}'), ScalarToken('b', 11, 11, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 15, '{"a": 1, "b": 2}')}, 0, 18, '{"a": 1, "b": 2}')


# Generated at 2022-06-24 11:11:54.260540
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    obj = _TokenizingDecoder()
    assert isinstance(obj,_TokenizingDecoder)


# Generated at 2022-06-24 11:11:56.013758
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, _TokenizingDecoder)


# Generated at 2022-06-24 11:11:58.917634
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    TokenizingDecoder = _TokenizingDecoder
    content = "content"
    decoder = TokenizingDecoder(content=content)
    assert decoder.scan_once is not None

# Generated at 2022-06-24 11:12:01.614640
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"date": "2015-01-01"}', Field(type="string", format="date")) == (
        "2015-01-01",
        [],
    )



# Generated at 2022-06-24 11:12:09.392853
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json = """
    [
        {
            "Name": "Alpha",
            "Number": 1
        },
        {
            "Name": "Beta",
            "Number": 2
        },
        {
            "Name": "Gamma",
            "Number": 3
        }
    ]
    """

# Generated at 2022-06-24 11:12:19.401600
# Unit test for function validate_json
def test_validate_json():
    # Assert positional parse error reporting on empty string
    content = ""
    try:
        validate_json(content=content, validator=Field())
        assert False
    except ParseError as error:
        assert error.position.line_no == 1
        assert error.position.column_no == 1
        assert error.position.char_index == 0
        assert error.text == "No content."
        assert error.code == "no_content"

    content = '{"foo": "bar"}'
    token, errors = validate_json(content=content, validator=Field())
    assert token.value == {"foo": "bar"}
    assert errors == []

    content = '["foo" , "bar"]'
    token, errors = validate_json(content=content, validator=Field(array=True))
    assert token.value

# Generated at 2022-06-24 11:12:24.747360
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '{ "a": "a", "b": "b", "c": "c" }'

    try:
        token = tokenize_json(test_content)

        assert token.get("a").value == "a"
        assert token.get("b").value == "b"
        assert token.get("c").value == "c"
    except ParseError:
        assert False


# Generated at 2022-06-24 11:12:33.741972
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[{"name":"David"},{"name":"Clyde"},{"name":"Betty"}]'

# Generated at 2022-06-24 11:12:34.615597
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass


# Generated at 2022-06-24 11:12:41.724124
# Unit test for function tokenize_json
def test_tokenize_json():
    # Unit test for function tokenize_json
    import json
    assert json.loads(tokenize_json('{ "name": { "first": "John", "last": "Mayer"} }').value) == \
           json.loads('{ "name": { "first": "John", "last": "Mayer"} }')
    assert json.loads('{"foo": [1, 2, 3]}').items() == tokenize_json('{"foo": [1, 2, 3]}').value.items()
    assert json.loads('{"foo": [1, 2, 3]}').items() == tokenize_json('{"foo": [1, 2, 3]}').value.items()

# Generated at 2022-06-24 11:12:43.839473
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_decoder = _TokenizingDecoder("{a:b}")
    assert test_decoder is not None


# Generated at 2022-06-24 11:12:48.148840
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test content")
    assert isinstance(decoder, JSONDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)
    return



# Generated at 2022-06-24 11:12:57.035537
# Unit test for function validate_json
def test_validate_json():
    # Validate successful json
    valid_json = '{"a": 5.5, "b": true, "c": "hello", "d": [1, 2, 3], "e": {"f": 3}}'
    schema = Schema({"a": Field(float), "b": Field(bool), "c": Field(str), "d": Field(typing.List), "e": Field(typing.Dict)})
    value, error_messages = validate_json(valid_json, schema)
    assert value == {"a": 5.5, "b": True, "c": "hello", "d": [1, 2, 3], "e": {"f": 3}}
    assert error_messages == []

    # Validate unsuccesful json

# Generated at 2022-06-24 11:12:58.333369
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()


# Generated at 2022-06-24 11:13:03.699635
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{\"hello\": \"world\"}"
    expected = DictToken(
        value={"hello": ScalarToken(value="world", start=9, stop=15, content=content)},
        start=0,
        stop=18,
        content=content,
    )
    assert tokenize_json(content) == expected
    assert tokenize_json(content.encode("utf-8")) == expected



# Generated at 2022-06-24 11:13:09.777451
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String

    content = '{"field": "value"}'
    token = tokenize_json(content)
    assert token.get("field") == "value"
    schema = Schema([String(name="field")])
    value, messages = validate_json(content, schema)
    assert len(messages) == 0
    assert value == {
        "field": "value"
    }

# Generated at 2022-06-24 11:13:11.287300
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content='{"a": "b"}')

# Generated at 2022-06-24 11:13:18.092083
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, error_message_instance = validate_json(
        content='"value"', validator=validator)
    assert value == "value"
    assert error_message_instance is None

    value, error_message_instance = validate_json(
        content="invalid", validator=validator
    )
    assert value == "invalid"
    assert type(error_message_instance) is ValidationError

# Generated at 2022-06-24 11:13:22.121600
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def _test_init_scanner_func():
        return None
    decoder = _TokenizingDecoder(scan_once=_test_init_scanner_func, content='content')
    assert decoder.scan_once == _test_init_scanner_func
    assert decoder.content == 'content'

# Generated at 2022-06-24 11:13:31.614903
# Unit test for function tokenize_json
def test_tokenize_json():
    T = tokenize_json('{"a": 2}')
    assert T.start == 0
    assert T.end == 7
    assert T.data == [
        (ScalarToken('a', 1, 2, '{"a": 2}'), ScalarToken(2, 5, 5, '{"a": 2}'))
    ]
    assert len(T.data) == 1
    assert T.data[0][0].data == 'a'
    assert T.data[0][1].data == 2
    T = tokenize_json('[1, 2.3, false, null]')
    assert T.data[0][0] == 1
    assert T.data[0][1] == 2.3
    assert T.data[0][2] is False
    assert T.data[0][3] is None

# Generated at 2022-06-24 11:13:42.336965
# Unit test for function validate_json
def test_validate_json():
    json_schema_v4 = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {
            "one": {"type": "string"},
            "two": {"type": "string"},
            "three": {"type": "string"},
            "four": {"type": "string"},
        },
        "required": ["one", "two", "three"],
    }
    json_schema_v4_content = json.dumps(json_schema_v4)

    assert validate_json(json_schema_v4_content, Schema) == ({
        "one": "",
        "two": "",
        "three": "",
        "four": ""
    }, None)

    json_schema_v

# Generated at 2022-06-24 11:13:45.546264
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-24 11:13:56.342516
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import SchemaError

    field = String(required=True)
    error = None
    try:
        validate_json(content=b"", validator=field)
    except SchemaError as err:
        error = err

    assert error is not None
    assert len(error.messages) == 1
    assert error.messages[0].message == "This field is required."
    assert error.messages[0].code == "required"
    assert error.messages[0].position is not None
    assert error.messages[0].position.line_no == 1
    assert error.messages[0].position.column_no == 1
    assert error.messages[0].position.char_index == 0

# Generated at 2022-06-24 11:14:03.983013
# Unit test for function validate_json
def test_validate_json():
    content = '{"hello": "world", "foo": "bar"}'
    schema = type("Schema", (Schema,), {"hello": Field(), "foo": Field(required=False)})
    value, error_messages = validate_json(content, schema)
    assert error_messages == []
    assert value == {"hello": "world", "foo": "bar"}

    schema = type("Schema", (Schema,), {"hello": Field(required=False)})
    value, error_messages = validate_json(content, schema)
    assert error_messages == []
    assert value == {"hello": "world", "foo": "bar"}

    # Missing a required field
    content = '{"foo": "bar"}'
    value, error_messages = validate_json(content, schema)
    assert error_messages

# Generated at 2022-06-24 11:14:14.743097
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")

    assert tokenize_json("{\"hello\":123}") == DictToken(
        {"hello": ScalarToken(123, 10, 12, "{\"hello\":123}")}, 0, 13, "{\"hello\":123}"
    )

    assert (
        tokenize_json("[true,false,null]") == ListToken(
            [
                ScalarToken(True, 1, 5, "[true,false,null]"),
                ScalarToken(False, 7, 12, "[true,false,null]"),
                ScalarToken(None, 14, 18, "[true,false,null]"),
            ],
            0,
            19,
            "[true,false,null]",
        )
    )


# Generated at 2022-06-24 11:14:25.000176
# Unit test for function validate_json
def test_validate_json():

    x = """
        {
            "a": 1,
            "b": [1.1, "hi", true, null],
            "c": {
                "d": false,
                "e": "bye",
                "f": "hi",
                "g": "hi"
            }
        }
    """

    class Schema(typesystem.Schema):
        a = typesystem.Integer(description="an integer")
        b = typesystem.Array(of=typesystem.String(description="a string"))
        c = typesystem.Dictionary(of=typesystem.String(description="a string"))

    data, messages = validate_json(x, Schema)


# Generated at 2022-06-24 11:14:25.870751
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-24 11:14:33.762367
# Unit test for function validate_json
def test_validate_json():
    """
    Test case to validate the validate_json() function
    """
    validator = Field(validators=[IsInteger()])
    value, error_messages = validate_json('123', validator)
    assert value == 123
    assert not error_messages

    value, error_messages = validate_json('"abc"', validator)
    assert not value
    assert error_messages
    assert error_messages[0].text == ''
    assert error_messages[0].code == 'invalid_type'
    assert error_messages[0].position.column_no == 1
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.char_index == 0
    assert error_messages[0].position.byte_index == 0



# Generated at 2022-06-24 11:14:34.897818
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()


# Generated at 2022-06-24 11:14:36.572281
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder('a')
    assert decoder.scan_once

# Generated at 2022-06-24 11:14:43.983525
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import io
    import types
    __author__ = "Parth Kolekar"
    __credits__ = ["Parth Kolekar"]
    __email__ = ["kolekar.parth@gmail.com"]
    __status__ = "Prototype"
    json_str = '"{\\"name\\": 1, \\"age\\": 2}"'
    check_json_str = json_str[1:-1].encode().decode('unicode-escape')
    stream = io.StringIO(json_str)
    decoder = _TokenizingDecoder(stream, content=json_str)
    assert decoder.memo == {}
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.strict == True

# Generated at 2022-06-24 11:14:54.647011
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:15:04.595791
# Unit test for function validate_json
def test_validate_json():
    class DecodeError(Message):
        code = "decode_error"
        description = "Error decoding JSON."

    class ValidateError(Message):
        code = "validate_error"
        description = "Error validating JSON."

    class SimpleField(Field):
        message_class = ValidateError

    # Test single parse error in a single string.
    message = "Error decoding JSON."
    error_code = "parse_error"
    column_no = 4
    line_no = 1
    char_index = 3
    position = Position(column_no=column_no, line_no=line_no, char_index=char_index)
    value = '{"key": 1'
    try:
        validate_json(value, validator=SimpleField())
    except ParseError as exc:
        assert exc.text

# Generated at 2022-06-24 11:15:15.564704
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # test for normal and strict

    # normal
    b = '{"a":1}'
    dec = _TokenizingDecoder(b)
    assert dec.scan_once(b, 0) == (DictToken({'a':1}, 0, 6, '{"a":1}'), 7)

    # strict
    dec1 = _TokenizingDecoder(strict=True)
    assert dec1.scan_once(b, 0) == (DictToken({'a':1}, 0, 6, '{"a":1}'), 7)

    # content
    c = b'{"a":1}'
    dec2 = _TokenizingDecoder(c)
    assert dec2.scan_once(c, 0) == (DictToken({'a':1}, 0, 6, '{"a":1}'), 7)

#

# Generated at 2022-06-24 11:15:21.126165
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key1": ["item1", "item2"]}'
    dict_token = DictToken(
        {"key1": ListToken(["item1", "item2"], 13, 26, content)},
        0,
        26,
        content,
    )
    assert tokenize_json(content) == dict_token


# Generated at 2022-06-24 11:15:24.821288
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = ""
    try:
        tokenize_json(content)
    except ParseError as e:
        assert e.position == Position(1, 1, 0)
    else:
        assert False


# Generated at 2022-06-24 11:15:34.956299
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[1,2,3,4]'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    for element in token:
        assert isinstance(element, ScalarToken)
        assert element.value == element.raw_value

    content = '{"key1":1, "key2":"value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    for key, value in token:
        if key.value == "key1":
            assert isinstance(value, ScalarToken)
            assert value.value == 1
        elif key.value == "key2":
            assert isinstance(value, ScalarToken)
            assert value.value == "value"

    content = '["key1", "key2"]'

# Generated at 2022-06-24 11:15:44.229509
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
        content='{"key1": "value1", "key2": "value2"}',
        validator={
            "key1": str,
            "key2": str,
        }
    )[0] == {
        "key1": "value1",
        "key2": "value2"
    }

    errors = validate_json(
        content='{"key1": "value1", "key2": 42}',
        validator={
            "key1": str,
            "key2": str,
        }
    )[1]

    assert len(errors) == 1
    assert errors[0] is not None
    assert errors[0].position is not None
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 18
   

# Generated at 2022-06-24 11:15:50.546333
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test that invalid JSON will throw a ParseError.
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("{{{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}")
    assert (
        excinfo.value.text
        == "Expecting ',' delimiter. line 1 column 91 (char 90)"
    )

    # Test that large JSON will throw a ParseError.

# Generated at 2022-06-24 11:16:02.194629
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Field, Text, Integer

    class Address(Schema):
        street_address = Text()
        zip_code = Integer()

    class Person(Schema):
        full_name = Text(required=True)
        date_of_birth = Text()
        personal_address = Address()

    class Company(Schema):
        company_name = Text(required=True)
        company_address = Address()

    class Job(Schema):
        job_title = Text()
        company = Field(type=Company)

    class PersonWithJobs(Schema):
        full_name = Text(required=True)
        date_of_birth = Text()
        jobs = Field(type=Job, min_length=1)


    # missing required field

# Generated at 2022-06-24 11:16:12.485776
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = """\
{
  "hobbies": [
    "diving",
    "ice skating",
    "rafting"
  ],
  "name": "Alice",
  "age": 15
}
"""
    decoder = _TokenizingDecoder(content=content)
    root = tokenize_json(content)
    # Unit test for constructor of class _TokenizingJSONObject
    def test__TokenizingJSONObject():
        s, end = '({"name":"Alice","age":15})', 1
        strct, scan_once, memo, content, _w, _ws = True, decoder.scan_once, {}, "", WHITESPACE.match, " \t\n\r"
        # Use a slice to prevent IndexError from being raised, the following
        # check will raise a more specific ValueError if the string

# Generated at 2022-06-24 11:16:15.907328
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": "b"}')
    assert isinstance(token, DictToken)


# Generated at 2022-06-24 11:16:20.414761
# Unit test for function validate_json
def test_validate_json():
    """
    Test function validate_json by running through all tests in the same
    file.
    """
    from typesystem.tokenize.positional_validation import test_validate_with_positions
    test_validate_with_positions()

if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-24 11:16:29.552962
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"data": [{"id":123, "value": "this is a string"}]}'
    token = tokenize_json(content)
    assert token.value()['data'][0]['id'] == 123
    assert token.value()['data'][0]['value'] == "this is a string"
    assert token.value()['data'][0].get_token('id').position.line_no == 1
    assert token.value()['data'][0].get_token('value').position.line_no == 1
    assert token.value()['data'][0].get_token('value').position.column_no == 40
    assert token.value()['data'][0].get_token('id').content == content
    assert token.value()['data'][0].get_token('value').content == content


# Generated at 2022-06-24 11:16:36.493476
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value", "key2": "value2"}'
    json_token = tokenize_json(content)
    assert type(json_token) == DictToken
    assert json_token["key"] == ScalarToken('value', 17, 26, content)
    assert json_token.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert json_token.end_position == Position(column_no=35, line_no=1, char_index=34)
    assert len(json_token) == 2
    assert json_token["key"] == 'value'
    assert json_token["key2"] == 'value2'


# Generated at 2022-06-24 11:16:46.435233
# Unit test for function validate_json
def test_validate_json():
    json_string = """
    {
      "a": 1,
      "b": [2, 3, "4"],
      "c": {
        "d": 5,
        "e": null
      },
      "f": false,
      "g": true
    }
    """

# Generated at 2022-06-24 11:16:55.276923
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json()
    """
    import typesystem
    import json

    class PetSchema(typesystem.Schema):
        name = typesystem.String()
        owner = typesystem.String()
        age = typesystem.Integer(minimum=0, maximum=30)

    schema_data = {
        "name": "Doggie",
        "owner": "John",
        "age": -5,
    }

# Generated at 2022-06-24 11:17:05.398003
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": 1, "bar": "a"}'
    validator = create_schema(
        foo = Integer(),
        bar = Text(),
    )
    value, errors = validate_json(content, validator)
    assert not errors
    assert value == {"foo": 1, "bar": "a"}
    
    content = '{"foo": "1", "bar": "a"}'
    value, errors = validate_json(content, validator)
    assert not errors
    assert value == {"foo": 1, "bar": "a"}
    
    content = '{"foo": "1", "bar": 2}'
    value, errors = validate_json(content, validator)
    assert errors
    error = errors[0]
    assert error.code == "type_error"
    assert error.position == Position

# Generated at 2022-06-24 11:17:15.436494
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test the tokenize_json function.
    """
    assert tokenize_json(b'{"name": "xxx"}') == DictToken({'name': ScalarToken('xxx', 10, 12, '{"name": "xxx"}')}, 0, 15, '{"name": "xxx"}')

# Generated at 2022-06-24 11:17:18.293398
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"abc": 123, "xyz": 456}'
    tokens = tokenize_json(content)
    assert tokens.as_python() == {"abc": 123, "xyz": 456}


# Generated at 2022-06-24 11:17:26.522632
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    for content in [b"", b"\x00", b"\x00\x00", b"\x00\x00\x00"]:
        # Check that the call to decoder.decode raises a json.decoder.JSONDecodeError
        # when the content byte string is empty in the following ways:
        # 1) The byte string ends with '0'
        # 2) The byte string ends with '00'
        # 3) The byte string ends with '000'
        decoder = _TokenizingDecoder(content=content)
        assert decoder is not None
        with raises(JSONDecodeError, match="Expecting property name enclosed in double quotes"):
            decoder.decode(content)

# Unit tests for constructor of class _make_scanner

# Generated at 2022-06-24 11:17:27.482252
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder()


# Generated at 2022-06-24 11:17:37.970659
# Unit test for function tokenize_json
def test_tokenize_json():
    # Arrange
    test_json = '{"key1": {"sub_key1": "value1", "sub_key2": "value2"},' \
                '"key2": [{"sub_key3": "value3"}, {"sub_key4": "value4"}]}'
    # Act
    doc = tokenize_json(test_json)

    # Assert
    assert isinstance(doc, DictToken)
    assert doc.start == 0
    assert doc.end == len(test_json) - 1
    assert len(doc.value) == 2
    assert doc.value['key1'].value['sub_key1'].value == 'value1'
    assert doc.value['key2'].value[0].value['sub_key3'].value == 'value3'


# Generated at 2022-06-24 11:17:42.436247
# Unit test for function validate_json
def test_validate_json():
        # Handles the empty string case explicitly for clear error messaging
        content = ""
        try:
            validate_json(content, 2)
        except ParseError as exc:
            assert exc.code == "no_content"
            assert exc.text == "No content."
            assert exc.position == Position(char_index=0, line_no=1, column_no=1)

# Generated at 2022-06-24 11:17:54.399977
# Unit test for function tokenize_json
def test_tokenize_json():
    str_json = """{"key1":1,"key2":"2","key3":[3],"key4":{"key5":5}}"""
    token_type, token_value = tokenize_json(str_json)
    assert token_type == Token.DICT
    assert len(token_value) == 4
    for key, value in token_value.items():
        key_type, key_value = value[0]
        value_type, value_value = value[1]
        assert key_type == Token.STRING
        assert key_value == key
        if isinstance(value_value, list):
            for item_type, item_value in value_value:
                assert item_type == Token.NUMBER
            assert value_type == Token.LIST
        elif isinstance(value_value, dict):
            assert value_type

# Generated at 2022-06-24 11:18:04.633900
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert hasattr(_TokenizingDecoder, "parse_string") == True
    assert hasattr(_TokenizingDecoder, "parse_array") == True
    assert hasattr(_TokenizingDecoder, "parse_float") == True
    assert hasattr(_TokenizingDecoder, "parse_int") == True
    assert hasattr(_TokenizingDecoder, "parse_constant") == True
    assert hasattr(_TokenizingDecoder, "strict") == True
    assert hasattr(_TokenizingDecoder, "object_hook") == True
    assert hasattr(_TokenizingDecoder, "object_pairs_hook") == True
    assert hasattr(_TokenizingDecoder, "parse_object") == True

# Generated at 2022-06-24 11:18:07.530668
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert_response = _TokenizingDecoder("content")
    assert_response.scan_once == {"1": "2"}


# Generated at 2022-06-24 11:18:10.481387
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)
    assert isinstance(decoder.scan_once, typing.Callable)

# Generated at 2022-06-24 11:18:12.385563
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder.scan_once is None


# Generated at 2022-06-24 11:18:15.198023
# Unit test for function validate_json
def test_validate_json():
  content = "{\"foo\": \"bar\"}"
  validator = Field(type=str)
  assert validate_json(content, validator) == ({"foo": "bar"}, [])

# Generated at 2022-06-24 11:18:20.742116
# Unit test for function validate_json
def test_validate_json():
    content = "test"
    # This validator is invalid and should not be used in real code
    field = Field(validators=[lambda value: "Is valid"])
    value, error_messages = validate_json(content, field)
    assert value == "test"
    assert error_messages == []

# Generated at 2022-06-24 11:18:25.435612
# Unit test for function validate_json
def test_validate_json():
    json = '{"name1": "John Doe", "name2": "John Doe"}'
    object_type = type("TestType", (Schema,), { "name": Text() })
    errors = validate_json(json, object_type)
    assert not errors

# Generated at 2022-06-24 11:18:35.583331
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"a": 2}')
    assert type(token) == DictToken

    token = tokenize_json('{"a": "fdsafsda"}')
    assert type(token) == DictToken

    token = tokenize_json('{"a": "fdsafsda", "b": 1}')
    assert type(token) == DictToken

    token = tokenize_json('{"a": [2, 3]}')
    assert type(token) == DictToken

    content_1 = '{"a": []}'
    token = tokenize_json(content_1)
    assert type(token) == DictToken

# Generated at 2022-06-24 11:18:36.891355
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    decoder = _TokenizingDecoder(content=content)
    return decoder

# Generated at 2022-06-24 11:18:38.524140
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo":"bar"}'
    token = tokenize_json(content)
    assert token.value == {"foo": "bar"}



# Generated at 2022-06-24 11:18:45.771475
# Unit test for function tokenize_json
def test_tokenize_json():
    value_expected = [1,2,3]
    value_validator = [int]

    value_actual, error_messages = validate_json(b'[1, "2", true]', value_validator)
    assert value_actual == value_expected
    assert error_messages == []

    value_validator = Field(type=int, validators=[lambda x: x > 2])

    value_actual, error_messages = validate_json(b'[1,2,3]', value_validator)
    assert value_actual == value_expected
    assert [str(e) for e in error_messages] == [
        "invalid_type: 3 is not of type 'int' @ (2, 2)",
        "validator_failed: 3 is not greater than 2 @ (2, 2)",
    ]

# Generated at 2022-06-24 11:18:56.770903
# Unit test for function tokenize_json
def test_tokenize_json():
    from json import loads
    from typesystem.fields import String
    from typesystem.tokenize.tokens import DictToken, ScalarToken

    valid_json = '{"foo": "bar"}'
    valid_token = tokenize_json(valid_json)

    expected_token = DictToken(
        {ScalarToken("bar", 8, 11, valid_json): ScalarToken("foo", 2, 5, valid_json)}
    )
    assert valid_token.value == expected_token.value
    assert valid_token.position == expected_token.position

    invalid_json = '{"foo": "bar"}{"foo": "bar"}'

    with pytest.raises(ParseError) as exc_info:
        tokenize_json(invalid_json)

    exc = exc_info.value
    assert exc

# Generated at 2022-06-24 11:19:06.137741
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('') == ScalarToken(None, 0, 0, '')
    assert tokenize_json('{"key": "value"}') == DictToken({ScalarToken('key', 1, 4, '{"key": "value"}'): ScalarToken('value', 10, 15, '{"key": "value"}')}, 0, 16, '{"key": "value"}')
    assert tokenize_json('["value"]') == ListToken([ScalarToken('value', 2, 7, '["value"]')], 0, 8, '["value"]')
    assert tokenize_json('null') == ScalarToken(None, 0, 3, 'null')
    assert tokenize_json('true') == ScalarToken(True, 0, 3, 'true')

# Generated at 2022-06-24 11:19:15.043236
# Unit test for function validate_json
def test_validate_json():

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    import unittest

    # Create a Schema class to validate against
    TestSchema = Schema.define(
        name=String(),
        age=Integer(minimum=1),
    )

    class TestValidateJson(unittest.TestCase):

        def test_1(self):
            """Whitespace is not allowed"""
            content = '\n \r\n \r \n \r'
            value, messages = validate_json(content, TestSchema)
            self.assertEqual(messages, [
                Message(
                    text="No content.", code="no_content",
                    position=Position(line_no=1, column_no=1, char_index=0),
                )
            ])

       

# Generated at 2022-06-24 11:19:22.019428
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"field1": 1, "field2": {"field3": 3, "field4": [ "array", 1, 2, 3 ] } }')
    assert(token.value['field1'] == '1')
    assert(token.value['field2'].value['field3'] == '3')
    assert(len(token.value['field2'].value['field4']) == 4)

# Generated at 2022-06-24 11:19:31.829925
# Unit test for function validate_json
def test_validate_json():
    content = '[{"a":1},{"a":2}]'
    field = Field()
    value = validate_json(content, validator=field)
    assert value == ([{'a':1},{'a':2}], [])

    field = Field(type=int)
    value = validate_json(content, validator=field)
    assert value == (None, [])

    field = Field(type=[int])
    value = validate_json(content, validator=field)
    assert value == (None, [])

    field = Field(type=[list])
    value = validate_json(content, validator=field)
    assert value == ([], [Message(code='type_error', text="Expected type 'list', found type 'dict'.", position=Position(0, 1, 0, 4))])

    field = Field

# Generated at 2022-06-24 11:19:40.705185
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        tokenize_json('{"key": "value"}') == {"key": "value"}
    )
    assert tokenize_json("null") is None
    assert tokenize_json("1") == 1
    assert tokenize_json("1.0") == 1.0
    assert tokenize_json("1e2") == 100.0
    assert tokenize_json("true") is True
    assert tokenize_json("false") is False
    assert (
        tokenize_json('[{"a": "b"}, {"c": "d"}]')
        == [{"a": "b"}, {"c": "d"}]
    )
    assert (
        tokenize_json('\t  {"key": "value"}\n') == {"key": "value"}
    )

# Generated at 2022-06-24 11:19:44.392189
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    >>> tokenize_json("")
    Traceback (most recent call last):
        ...
    ParseError: No content.
    """



# Generated at 2022-06-24 11:19:47.229657
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = r'{"a": "1"}'
    decoder = _TokenizingDecoder(content=content)
    assert hasattr(decoder, "scan_once")

test__TokenizingDecoder()

# Generated at 2022-06-24 11:19:53.210917
# Unit test for function validate_json
def test_validate_json():
    class Object(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Object(name="Test", age=40) == validate_json(
        '{"name": "Test", "age": 40}', validator=Object
    )

    assert (None, [Message(path=["age"], code="type_mismatch")]) == validate_json(
        '{"name": "Test", "age": "40"}', validator=Object
    )

# Generated at 2022-06-24 11:20:01.011624
# Unit test for function validate_json
def test_validate_json():
    content = """
        {
            "name": "John",
            "age": 56,
            "spouse": {
                "name": "Mary"
            },
            "children": [
                {
                    "name": "Alice",
                    "age": 18
                },
                {
                    "name": "Bob",
                    "age": 16
                },
                {
                    "name": "Carol",
                    "age": 13
                }
            ]
        }
    """
    value, messages = validate_json(content, PersonSchema)
    assert not messages, messages
    assert value["name"] == "John"
    assert value["age"] == 56
    assert value["spouse"]["name"] == "Mary"
    assert len(value["children"]) == 3

# Generated at 2022-06-24 11:20:02.108495
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder({}, content="test")

# Generated at 2022-06-24 11:20:12.709021
# Unit test for function validate_json
def test_validate_json():
    content = '''
    {
        "name": "test-three",
        "email": "test@test.com",
        "from": "London"
    }
    '''

    validator = Schema(
        {
            "from": str,
            "name": str,
            "email": str,
            "age": int,
        },
    )

    result, error_messages = validate_json(content, validator)

    assert len(error_messages) is 2
    assert error_messages[0].message == 'missing required field "age"'
    assert error_messages[1].message == 'field "age" must be of type "int"'

    assert result["from"] == "London"
    assert result["name"] == "test-three"

# Generated at 2022-06-24 11:20:15.150453
# Unit test for function tokenize_json
def test_tokenize_json():
    # assert tokenize_json('[]')==[]
    assert tokenize_json('{"a":[1,2,"c"]}')=={'a' : [1,2,'c']}


# Generated at 2022-06-24 11:20:17.577156
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder.scan_once, typing.Callable)


# Generated at 2022-06-24 11:20:18.606794
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = _TokenizingDecoder()
    assert type(a) == JSONDecoder
    assert type(a).__bases__ == (object,)

# Generated at 2022-06-24 11:20:22.694536
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Any  # noqa
    from typesystem.schemas import Schema  # noqa

    schema = Schema({"foo": Any()})
    value, errors = validate_json('{"foo": "a"}', schema)
    assert errors == {}
    assert value == {"foo": "a"}



# Generated at 2022-06-24 11:20:31.892886
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"id":"Dt15","type":"SENSOR","value":0.0,"unit":"null","timestamp":1588457354854}'
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert isinstance(result.items, list)
    assert len(result.items) == 5
    assert result.items[0][0].value == 'id'
    assert result.items[0][1].value == 'Dt15'
    assert result.items[1][0].value == 'type'
    assert result.items[1][1].value == 'SENSOR'
    assert result.items[2][0].value == 'value'
    assert result.items[2][1].value == 0.0

# Generated at 2022-06-24 11:20:34.564385
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('', None) == (None, [])
    assert validate_json('1', None) == (1, [])


# Generated at 2022-06-24 11:20:36.073873
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert decoder != None

# Generated at 2022-06-24 11:20:42.712299
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1, "b": 2}') == DictToken({
        ScalarToken("a", 1, 3, '{"a": 1, "b": 2}'): ScalarToken(1, 7, 8, '{"a": 1, "b": 2}'),
        ScalarToken("b", 11, 13, '{"a": 1, "b": 2}'): ScalarToken(2, 15, 16, '{"a": 1, "b": 2}')
    }, 0, 17, '{"a": 1, "b": 2}')

