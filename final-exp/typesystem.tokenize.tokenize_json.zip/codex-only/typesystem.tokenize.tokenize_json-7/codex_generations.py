

# Generated at 2022-06-24 11:10:46.093591
# Unit test for function validate_json
def test_validate_json():
    x = [
        {
            "field": "first_name",
            "text": "First name is required.",
            "code": "required",
            "position": {"column_no": 1, "line_no": 1, "char_index": 0},
        },
        {
            "field": "age",
            "text": "Invalid number.",
            "code": "invalid_number",
            "position": {"column_no": 3, "line_no": 1, "char_index": 2},
        },
    ]
    y = validate_json('["Jane","Smith", {"age": "invalid"}]', ListToken)
    assert x == y[1]

# Generated at 2022-06-24 11:10:51.288137
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": "value", "key1": "value1", "key2": "value2"}')
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(token.content)-1
    assert len(token.value) == 3
    key_token = token.value[0][0]
    assert key_token.start == 2
    assert key_token.end == 6



# Generated at 2022-06-24 11:10:58.078643
# Unit test for function tokenize_json
def test_tokenize_json():
    content = b'''
    { "foo": 123, "bar": "baz", "baz": 1.23 }
    '''
    result = tokenize_json(content)
    assert isinstance(result, DictToken)
    assert result.value == {"foo": ScalarToken(123, 24, 26, content),
                            "bar": ScalarToken("baz", 34, 38, content),
                            "baz": ScalarToken(1.23, 46, 50, content)}

# Generated at 2022-06-24 11:11:00.486839
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content="{name: \"john\"}"
    _TokenizingDecoder(content=content)


# Generated at 2022-06-24 11:11:01.500531
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "string"
    assert _TokenizingDecoder(content=content.encode("utf-8"))


# Generated at 2022-06-24 11:11:05.064479
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken({"foo": ScalarToken("bar", 3, 8, '{"foo": "bar"}')}, \
                                                         0, 13, '{"foo": "bar"}')



# Generated at 2022-06-24 11:11:06.301125
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{}')
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-24 11:11:08.919285
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    data = '{"a": 1, "b": 2}'
    decoder = _TokenizingDecoder(content=data)
    assert "content" in decoder.__dict__

# Generated at 2022-06-24 11:11:15.930389
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": [1, 2, 3]}') == DictToken({
        ScalarToken('key', 0, 3, '{"key": [1, 2, 3]}'): ListToken([
            ScalarToken(1, 10, 10, '{"key": [1, 2, 3]}'),
            ScalarToken(2, 13, 13, '{"key": [1, 2, 3]}'),
            ScalarToken(3, 16, 16, '{"key": [1, 2, 3]}')
        ], 9, 17, '{"key": [1, 2, 3]}')
    }, 0, 17, '{"key": [1, 2, 3]}')



# Generated at 2022-06-24 11:11:26.820483
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import *

    class MySchema(Schema):
        int_field = Integer()
        string_field = String(format="email")

    json_str = '{"int_field": "4.4", "string_field": "gmail.com"}'
    data, errors = validate_json(json_str, MySchema)

# Generated at 2022-06-24 11:11:28.157093
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="{}")


# Generated at 2022-06-24 11:11:38.336409
# Unit test for function validate_json
def test_validate_json():
    content = u'{"name":"foo","age":19}'
    class Person(Schema):
        name = fields.String(max_length=40)
        age = fields.Integer()

    value, errors = validate_json(content, Person)
    assert errors == []
    assert type(value) == dict, 'type(value) is dict'
    assert value['name'] == 'foo', 'value["name"] is foo'
    assert value['age'] == 19, 'value["age"] is 19'

    content = u'{"name":"foo","age":19,"weight":99.9}'
    value, errors = validate_json(content, Person)
    assert len(errors) == 1, 'len(errors) is 1'

# Generated at 2022-06-24 11:11:48.207566
# Unit test for function validate_json
def test_validate_json():
    # Test with various validators and content
    def test_valid(content, validator):
        value, errors = validate_json(content, validator)
        assert value is not None
        assert errors is None

    test_valid('{"x": "a string", "y": 1}', Schema.of({"x": str, "y": int}))
    test_valid('1.0', float)
    test_valid('"a string"', str)
    test_valid('true', bool)
    test_valid('["one", "two", "three"]', ListToken)

    # Test with invalid content
    def test_invalid(content, validator):
        value, errors = validate_json(content, validator)
        assert value is None
        assert errors is not None

    # Test invalid JSON

# Generated at 2022-06-24 11:11:49.721411
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder.__init__("a", "b", "c")


# Generated at 2022-06-24 11:12:00.293017
# Unit test for function validate_json
def test_validate_json():
    class Todo(Schema):
        id = typesystem.Integer(minimum=1)
        title = typesystem.String(min_length=1)
        completed = typesystem.Boolean()
        created_at = typesystem.DateTime()

    valid_json = '{"id": 1, "title": "Hello", "completed": false, "created_at": "2018-01-01"}'
    value, errors = validate_json(valid_json, Todo)
    assert value == {
        "id": 1,
        "title": "Hello",
        "completed": False,
        "created_at": datetime.datetime(2018, 1, 1),
    }
    assert errors == []


# Generated at 2022-06-24 11:12:08.524887
# Unit test for function tokenize_json
def test_tokenize_json():
    key = '"12345"'
    value1 = '"value1"'
    value2 = '"value2"'
    value3 = '"value3"'
    value4 = '"value4"'
    value5 = '"value5"'
    value6 = '"value6"'
    value7 = '"value7"'
    value8 = '"value8"'
    value9 = '"value9"'
    value10 = '"value10"'
    value11 = '"value11"'
    value12 = '"value12"'
    key_value1 = key + ':' + value1
    key_value2 = key + ':' + value2
    key_value3 = key + ':' + value3
    key_value4 = key + ':' + value4
    key_value5 = key + ':' + value5


# Generated at 2022-06-24 11:12:17.033356
# Unit test for function validate_json
def test_validate_json():
    from .types import Person

    valid_input = '{"name": "John Doe", "age": 35}'
    invalid_input = '{"age": 35}'
    expected_errors = [
        ValidationError(
            text='Missing required value.',
            code='required',
            path=['name'],
            position=Position(char_index=9, column_no=10, line_no=1),
        ),
    ]
    (value, errors) = validate_json(valid_input, Person)
    try:
        (value, errors) = validate_json(invalid_input, Person)
    except ParseError:
        # An unexpected ParseError is raised.
        raise
    if errors != expected_errors:
        # Unexpected validation errors.
        raise AssertionError(errors)

# Generated at 2022-06-24 11:12:23.747082
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test content")
    assert decoder.parse_int is int
    assert decoder.parse_float is float
    assert decoder.parse_constant is None
    assert decoder.strict is True
    assert decoder.parse_array is JSONDecoder.parse_array
    assert decoder.parse_string is JSONDecoder.parse_string
    assert decoder.scan_once is not None
    assert decoder.memo is not None



# Generated at 2022-06-24 11:12:33.000080
# Unit test for function validate_json
def test_validate_json():
    # Test valid JSON inputs
    assert validate_json(
        "1", u"1",
    )
    assert validate_json(
        "null", u"null",
    )
    assert validate_json(
        '"foo"', u"foo",
    )
    assert validate_json(
        "{}", {},
    )
    assert validate_json(
        '{"opt": 1}', {"opt": 1},
    )
    assert validate_json(
        '{"opt": 1, "opt2": 1, "req": 1}', validator=Schema(
        fields={
            "opt": u"1",
            "opt2": u"1",
            "req": u"1"
        },
        required=["req"],
    ),
    )

    # Test invalid JSON

# Generated at 2022-06-24 11:12:34.682249
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test case 1
    context = _TokenizingDecoder(content="a")
    assert context.content == "a"
    assert context.scan_once == _make_scanner(context, "a")



# Generated at 2022-06-24 11:12:37.255348
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import types
    decoder = _TokenizingDecoder()
    assert isinstance(decoder.parse_float, types.MethodType)
    assert isinstance(decoder.parse_int, types.MethodType)

# Generated at 2022-06-24 11:12:40.130348
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{ "test": "test" }'
    decoder = _TokenizingDecoder(content=content)

    assert content == decoder.decode(content)


# Generated at 2022-06-24 11:12:46.613821
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string", description="some description")
    value, errors = validate_json(content='"some_string"', validator=field)
    assert value == "some_string"
    assert len(errors) == 0

    value, errors = validate_json(content='"some_string', validator=field)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ParseError)

    value, errors = validate_json(content='"some_string"', validator=Schema)
    assert value is None
    assert len(errors) == 1
    assert isinstance(errors[0], ValidationError)

# Generated at 2022-06-24 11:12:49.654011
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder.scan_once, typing.Callable)



# Generated at 2022-06-24 11:12:51.455758
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("content")
    assert (decoder.content == "content")



# Generated at 2022-06-24 11:12:56.898565
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.strict is False
    assert decoder.parse_float is float
    assert decoder.parse_int is int
    assert decoder.parse_constant is JSONDecoder.parse_constant
    assert decoder.scan_once is not None
    assert decoder.memo is not None



# Generated at 2022-06-24 11:13:00.527823
# Unit test for function validate_json
def test_validate_json():
    validator = fields.String()
    content_str = '"Hello World"'
    value, error_messages = validate_json(content_str, validator)

    assert value == "Hello World"
    assert error_messages == []

# Generated at 2022-06-24 11:13:07.513439
# Unit test for function validate_json
def test_validate_json():
    json_content_valid = "{}"
    json_content_invalid = "{}"
    field = Field(any_of=[int, bool])
    json_content_valid, errors_valid = validate_json(
        json_content_valid, field
    )
    json_content_invalid, errors_invalid = validate_json(
        json_content_invalid, field
    )
    # Test valid JSON
    assert len(errors_valid) == 0
    # Test invalid JSON
    assert len(errors_invalid) == 1
    assert errors_invalid[0].code == "invalid_choice"



# Generated at 2022-06-24 11:13:09.872962
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = ""
    decoder = _TokenizingDecoder(content=content)
    assert decoder is not None


# Generated at 2022-06-24 11:13:14.872832
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"number":42}', Field(type="number"))==(42, [])
    assert validate_json(b'{"number":42}', Field(type="string"))==(None, [Message(code='type_error', position=Position(line_no=1, column_no=11, char_index=10))])

# Generated at 2022-06-24 11:13:18.182700
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("content");
    scan_once = decoder.scan_once("abc", 0)
    assert not scan_once is None


# Generated at 2022-06-24 11:13:26.512850
# Unit test for function tokenize_json
def test_tokenize_json():
    # Basic test
    assert tokenize_json(b'[1, 2, 3]') == [1,2,3]
    assert tokenize_json(b'{"a": 1}') == {'a': 1}

    # JSONDecodeError cases
    with pytest.raises(ParseError, match="No content."):
        tokenize_json(b"")

    with pytest.raises(ParseError, match="Expecting value"):
        tokenize_json(b"invalid")

    with pytest.raises(ParseError, match="Expecting property name enclosed in double quotes"):
        tokenize_json(b'{ 42 : 1 }')


# Generated at 2022-06-24 11:13:29.438060
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key": "value"}'
    decoder = _TokenizingDecoder(content=content)
    value = decoder.decode(content)
    assert value.get("key") == "value"


# Generated at 2022-06-24 11:13:36.575756
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest
    with pytest.raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.position.char_index == 0
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert not excinfo.value.position.end
    assert excinfo.value.code == "no_content"
    assert excinfo.value.text == "No content."

    with pytest.raises(ParseError) as excinfo:
        tokenize_json("}")
    assert excinfo.value.position.char_index == 0
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert not excinfo.value.position.end


# Generated at 2022-06-24 11:13:44.837216
# Unit test for function tokenize_json
def test_tokenize_json():
    def test(content: str, expected: Token) -> None:
        assert tokenize_json(content) == expected

    test('"abc"', ScalarToken(value="abc", start=0, end=4, content='"abc"'))
    test(
        '{"a": 1.1, "b": "23"}',
        DictToken(
            value={
                "a": ScalarToken(value=1.1, start=5, end=8, content="1.1"),
                "b": ScalarToken(value="23", start=13, end=16, content='"23"'),
            },
            start=0,
            end=18,
            content='{"a": 1.1, "b": "23"}',
        ),
    )

# Generated at 2022-06-24 11:13:56.341798
# Unit test for function tokenize_json
def test_tokenize_json():
    assert(tokenize_json('"hello"') == "hello")
    assert(tokenize_json("{}") == {})
    assert(tokenize_json("1") == 1)
    assert(tokenize_json("[]") == [])
    assert(tokenize_json("{}") == {})
    assert(tokenize_json("null") == None)
    assert(tokenize_json("false") == False)
    assert(tokenize_json("true") == True)
    assert(tokenize_json("1.2") == 1.2)
    assert(tokenize_json("3e3") == 3000)
    assert(tokenize_json("4E4") == 40000)
    assert(tokenize_json("-5E5") == -500000)


# Generated at 2022-06-24 11:14:04.745550
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        tokenize_json(b'"name"') == ScalarToken(value="name", idx=0, end=5, content="name")
    )
    assert (
        tokenize_json(b"{}")
        == DictToken(value={}, idx=0, end=1, content="{}")
    )
    assert (
        tokenize_json(b"[]") == ListToken(value=[], idx=0, end=1, content="[]")
    )

# Generated at 2022-06-24 11:14:06.277460
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert isinstance(decoder, JSONDecoder)



# Generated at 2022-06-24 11:14:17.325055
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar", "baz": [1, 2, 3]}'
    token = tokenize_json(content)
    assert token.string() == content
    assert token.value == {'foo': 'bar', 'baz': [1, 2, 3]}
    assert token.type == "dict"

    assert token.value == {'foo': 'bar', 'baz': [1, 2, 3]}
    assert token.type == "dict"

    # test nested token
    nested_token = token.items[1]
    assert nested_token.value == [1, 2, 3]
    assert nested_token.type == "list"
    assert nested_token.items[0].value == 1
    assert nested_token.items[0].type == "scalar"

# Generated at 2022-06-24 11:14:26.520495
# Unit test for function validate_json
def test_validate_json():
    content = u"{ \"name\": \"John Doe\" }"
    validator = Field(name='name', required=True, type="string")

    (value, error_messages) = validate_json(content, validator)
    assert value == { 'name': 'John Doe' }
    assert error_messages == []

    bad_content = u"{ \"name\": 5 }"
    (value, error_messages) = validate_json(bad_content, validator)
    assert error_messages == [
        ValidationError(
            code='invalid',
            field='name',
            message='Expected a string value.',
            path=['name'],
            position=Position(column_no=9, line_no=1, char_index=8),
        )
    ]


# Generated at 2022-06-24 11:14:32.131191
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"hello": "world"}'
    context = _TokenizingDecoder(content=content)
    assert context.content == content
    assert type(context.scan_once) == _make_scanner
    assert context.parse_array == JSONDecoder.parse_array
    assert context.parse_int == JSONDecoder.parse_int
    assert context.parse_float == JSONDecoder.parse_float
    assert context.parse_string == JSONDecoder.parse_string
    assert context.strict == JSONDecoder.strict 



# Generated at 2022-06-24 11:14:37.637265
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a":1}') == DictToken({ScalarToken('a'): ScalarToken(1)}, 0, 5, '{"a":1}')
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a'): ScalarToken(1)}, 0, 5, '{"a":1}')
    assert tokenize_json(b'{"a":1}') == tokenize_json('{"a":1}')
    assert tokenize_json(b'{"a":1}') != DictToken({ScalarToken('a'): ScalarToken(1)}, 0, 5, '{"a":2}')
    assert tokenize_json('') == ''
    assert tokenize_json(b'') == ''

# Generated at 2022-06-24 11:14:40.294607
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="a")
    assert decoder.scan_once("a",0) == (ScalarToken("a", 0, 0, "a"), 1)


# Generated at 2022-06-24 11:14:51.659066
# Unit test for function validate_json
def test_validate_json():
    message = Message(
        errors=[
            ValidationError(
                code="parse_error",
                pointer="",
                text="Unterminated string starting at: line 1 column 3 (char 2)",
                schema=(),
            )
        ]
    )
    assert validate_json('"abc', Field()) == (None, message)

    message = Message(
        errors=[
            ValidationError(
                code="parse_error",
                pointer="",
                text="Expecting ',' delimiter: line 1 column 5 (char 4)",
                schema=(),
            )
        ]
    )
    assert validate_json('{"a": 42 "b": 23}', Field()) == (None, message)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 11:14:59.082538
# Unit test for function validate_json
def test_validate_json():
    content = '''
    {
        "name":"Jack",
        "age":15,
        "phone":"123456"
    }
    '''
    class UserSchema(Schema):
        name = String(max_length=128, min_length=1)
        age = Integer(max_value=100, min_value=1)
        phone = String(max_length=15, min_length=1)

    (value, errors) = validate_json(content, UserSchema)
    assert len(errors)==0
    assert value["name"]=="Jack"
    assert value["age"]==15
    assert value["phone"]=="123456"


# Generated at 2022-06-24 11:15:10.645587
# Unit test for function validate_json
def test_validate_json():
    from typesystem import fields, schemas
    from typing import Any, List

    class Person(schemas.Schema):
        first_name = fields.String(max_length=100, required=True)
        last_name = fields.String(max_length=100, required=True)
        twitter = fields.String(max_length=100, required=True)

    class PersonQueryParams(schemas.Schema):
        q = fields.String(required=True)
        count = fields.Integer(required=True)

    class PeopleQueryParams(schemas.Schema):
        query = fields.Array(fields.Nested(PersonQueryParams), required=True)

    class People(schemas.Schema):
        person = fields.Nested(Person, required=True)

# Generated at 2022-06-24 11:15:11.606843
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = _TokenizingDecoder()
    assert a

# Generated at 2022-06-24 11:15:19.612092
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    expected = {
        "one": 1,
        "two": 2.2,
        "three": "",
        "four": True,
        "five": False,
        "six": None,
        "seven": {"eight": "nine"},
        "ten": ["eleven", 12],
    }
    content = """
        {
            "one": 1,
            "two": 2.2,
            "three": "",
            "four": true,
            "five": false,
            "six": null,
            "seven": {
              "eight": "nine"
            },
            "ten": [
              "eleven",
              12
            ]
        }"""
    data = None
    exc = None
    try:
        data = tokenize_json(content)
    except Exception as e:
        exc

# Generated at 2022-06-24 11:15:31.884376
# Unit test for function tokenize_json
def test_tokenize_json():
    """test for function tokenize_json"""
    content = """
{
  "integer": 1,
  "float": 3.14,
  "string": "hello world",
  "true": true,
  "false": false,
  "null": null,
  "array": [1, 2, 3],
  "array_of_objects": [
    {
      "id": 1,
      "name": "Foo"
    },
    {
      "id": 2,
      "name": "Bar"
    }
  ],
  "object": {
    "id": 1,
    "name": "Foo"
  },
  "object_in_array": [
    {
      "id": 1,
      "name": "Foo"
    }
  ]
}
"""

# Generated at 2022-06-24 11:15:34.464582
# Unit test for function validate_json
def test_validate_json():
    content = b'{"email": "test@example.com"}'
    validator = ValidateJson.schema
    value, error_messages = validate_json(content, validator)

# Generated at 2022-06-24 11:15:36.774753
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo": "bar"}') == {'foo': 'bar'}



# Generated at 2022-06-24 11:15:40.577506
# Unit test for function validate_json
def test_validate_json():
    content = '{"int": 1}'
    validator = Schema(fields = {"int": "integer"})
    result = validate_json(content=content, validator=validator)
    assert result[0] == {"int": 1}
    assert result[1] == []


# Generated at 2022-06-24 11:15:42.163412
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.content == ""

# Generated at 2022-06-24 11:15:43.191149
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(True)


# Generated at 2022-06-24 11:15:44.616291
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    obj = _TokenizingDecoder()
    assert obj is not None


# Generated at 2022-06-24 11:15:53.421825
# Unit test for function validate_json
def test_validate_json():
    from typesystem.primitives import String
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.utils import load_json

    # Test a JSON string with a primitive field
    field = String(name='test field')
    test_schema = Schema([field])
    json_str = r'{"test field": "xxx"}'
    value, error_messages = validate_json(content=json_str, validator=test_schema)
    assert len(error_messages) == 0
    assert value == {'test field': 'xxx'}

    # Test a JSON string with a primitive field and nested errors
    test_schema = Schema({"field": Field(name="field")})

# Generated at 2022-06-24 11:15:57.349393
# Unit test for function tokenize_json
def test_tokenize_json():
    """Assert that function tokenize_json returns a token."""
    token = tokenize_json('{"key": "value"}')

    assert token is not None
    assert isinstance(token, Token)


# Generated at 2022-06-24 11:16:08.283974
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema, fields
    from typesystem.tokenize.positional_validation import PositionError

    class MySchema(Schema):
        one = String(max_length=10)
        two = String(max_length=10)
        three = String(max_length=10)

    content = '{"one": "this is a long string", "two": "this is shorter", "three": "three"}'
    _, errors = validate_json(content, validator=MySchema)
    error_msg = errors[0]
    assert error_msg.text == "String length must be less than or equal to 10."
    assert error_msg.position.line_no == 1
    assert error_msg.position.column_no == 10
    assert error_msg

# Generated at 2022-06-24 11:16:12.325587
# Unit test for function validate_json
def test_validate_json():
    validator=Field(date_format="iso",format="date-time")
    content = '"2019-06-13T18:47:37Z"'
    value, errors = validate_json(content, validator)
    assert value == "2019-06-13T18:47:37Z"
    assert len(errors) == 0

# Generated at 2022-06-24 11:16:23.204522
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({ScalarToken('a', 0, 2, '{"a":1}'): ScalarToken(1, 5, 6, '{"a":1}')}, 0, 8, '{"a":1}')
    assert tokenize_json('[1,2,3]') == ListToken([ScalarToken(1, 1, 2, '[1,2,3]'), ScalarToken(2, 4, 5, '[1,2,3]'), ScalarToken(3, 7, 8, '[1,2,3]')], 0, 10, '[1,2,3]')
    assert type(tokenize_json('"a"')[0].value) == str
    assert type(tokenize_json('1')[0].value) == int

# Generated at 2022-06-24 11:16:24.658113
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder("content"), _TokenizingDecoder)

# Generated at 2022-06-24 11:16:26.889465
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": "b"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once is not None 



# Generated at 2022-06-24 11:16:29.426066
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{'a': 'b'}"
    decoder = _TokenizingDecoder(content=content)
    assert (decoder.content == content)


# Generated at 2022-06-24 11:16:32.682525
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenize_json("""
    {
      "a": 1,
      "b": [
        {"c": 2}
      ]
    }
    """)

if __name__ == "__main__":
    print(test_tokenize_json())

# Generated at 2022-06-24 11:16:38.871791
# Unit test for function validate_json
def test_validate_json():
    """
    Test function validate_json in validator.py
    """
    # Test case 1: valid field and schema
    field = Field(name="field", type="string")
    schema = Schema(fields=[field])
    content = '{"field": "text"}'
    assert validate_json(content, field)[0] == {"field": "text"}
    assert validate_json(content, schema)[0] == {"field": "text"}

    # Test case 2: invalid field, should raise a ValidationError
    field = Field(name="field", type="string", required=True)
    content = '{"field": ""}'
    try:
        validate_json(content, field)
    except ValidationError as exc:
        assert True
        with pytest.raises(ValidationError) as exc_info:
            validate_

# Generated at 2022-06-24 11:16:45.904387
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {""}
    assert tokenize_json("{\"a\":1}") == {'a': 1}
    assert tokenize_json("{\"a\":1,\"b\":2}") == {'a': 1, 'b': 2}
    assert tokenize_json("{\"a\":1,\"b\":\"foo\"}") == {'a': 1, 'b': "foo"}
    assert tokenize_json("{\"a\":1,\"b\":null}") == {'a': 1, 'b': None}



# Generated at 2022-06-24 11:16:53.656937
# Unit test for function validate_json
def test_validate_json():
    class ArtistSchema(Schema):
        name = 'string'
        year_born = 'integer'
    
    content = '{"name":"Keith Jarrett","year_born":1945}'
    result = validate_json(content, ArtistSchema)
    assert len(result[1]) == 0

    content = '{"name":"Keith Jarrett","year_born":"1945"}'
    result = validate_json(content, ArtistSchema)
    assert len(result[1]) == 1
    assert result[1][0].text == '\'1945\' is not of type \'integer\''
    assert result[1][0].position.line_no == 1
    assert result[1][0].position.column_no == 33


# Generated at 2022-06-24 11:17:03.666878
# Unit test for function validate_json
def test_validate_json():
    import pytest
    content = '{"name": "Tim"}'
    schema = type('Schema', (Schema,), {'name': {'type': 'string'}})
    value, errors = validate_json(content, schema)
    assert 'name' in value
    assert errors == []
    content = '{"name": 123}'
    schema = type('Schema', (Schema,), {'name': {'type': 'string'}})
    value, errors = validate_json(content, schema)
    assert errors[0]['code'] == 'invalid_type'
    assert errors[0]['position']['start']['line_no'] == 1
    assert errors[0]['position']['start']['column_no'] == 11
    content = '{"name":'

# Generated at 2022-06-24 11:17:14.022662
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json with a simple validator
    """
    import typesystem
    import json

    class MyValidator(typesystem.Schema):
        s = typesystem.String(max_length=1)
        i = typesystem.Integer(minimum=0, maximum=2)

    example_json = json.dumps({'s': 'abc', 'i': -1})
    example_value = {'s': 'a', 'i': 1}
    example_error_code = 'max_length'
    example_error_message = 'Must have no more than 1 characters.'

    value, errors = validate_json(example_json, MyValidator)

    assert value == example_value

# Generated at 2022-06-24 11:17:16.608312
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test cases
    tests = [
        (
            '{"foo": {"bar": "baz"}}',
            {
                "foo": {
                    "bar": "baz"
                }
            },
        ),
        (
            "[1,2,3]",
            [1, 2, 3],
        )
    ]

    for test in tests:
        assert tokenize_json(test[0]) == test[1]

# Unit tests for function validate_json

# Generated at 2022-06-24 11:17:20.442526
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"one": 1, "two": 2}')
    assert isinstance(token, DictToken)
    assert token.key_value_pairs[0][0].value == 'one'
    assert token.value == {'one': 1, 'two': 2}



# Generated at 2022-06-24 11:17:23.186379
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'{"key": "value"}', Schema({
        "key": Field(str)
    }))[1] == []



# Generated at 2022-06-24 11:17:28.161272
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '{"t": 5}'
    token = tokenize_json(json_string)
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert token.value["t"] is 5



# Generated at 2022-06-24 11:17:29.185753
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="test")

# Generated at 2022-06-24 11:17:29.939250
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()

# Generated at 2022-06-24 11:17:40.537696
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """{
            "name": "John",
            "age": 30,
            "cars": [
                { "name": "Ford", "models": ["Fiesta", "Focus", "Mustang"] },
                { "name": "BMW", "models": ["320", "X3", "X5"] },
                { "name": "Fiat", "models": ["500", "Panda"] }
            ],
            "favorites": {
                "song": "Moonlight Sonata",
                "food": "Pizza"
            }
        }"""
    token = tokenize_json(json_str)
    assert token.start == 0
    assert token.end == 390

# Generated at 2022-06-24 11:17:48.123384
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        field = Integer()

    token, messages = validate_json(
        content=b'{"field": "notanint"}', validator=MySchema
    )

    assert isinstance(token, DictToken)
    assert isinstance(token.value["field"], ScalarToken)
    assert token.value["field"].value == "notanint"

    assert isinstance(messages, list)
    assert len(messages) == 1

    assert isinstance(messages[0], Message)
    assert messages[0].text == "Value must be an integer."
    assert messages[0].code == "integer"
    assert messages[0].detail == "notanint"
    assert messages[0].position

# Generated at 2022-06-24 11:17:57.242878
# Unit test for function validate_json
def test_validate_json():
    """Unit test for function validate_json"""

    class SimpleSchema(Schema):
        name = "Simple"
        fields = {"id": "integer"}

    class ComplexSchema(Schema):
        fields = {"id": "string", "children": {"type": "array", "items": "Simple"}}

    # Test for empty content
    value, errors = validate_json("", ComplexSchema)
    assert (
        len(errors) == 1
        and errors[0] == Message(
            text="No content.", code="no_content", position=Position(1, 1, 0)
        )
    )

    # Test for empty object
    value, errors = validate_json("{}", ComplexSchema)

# Generated at 2022-06-24 11:18:00.307636
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    c = '{"b":1, "a":2}'
    t = _TokenizingDecoder(content=c)
    assert t.scan_once == _make_scanner(t, c)


# Generated at 2022-06-24 11:18:10.298969
# Unit test for function validate_json
def test_validate_json():
    # Example Schema
    class Pet(Schema):
        id = fields.UUID()
        name = fields.String()
        age = fields.Integer()
        type = fields.String(enum=["cat", "dog", "bird"])
        owner = fields.String()

    # Valid Response
    valid_json = '{"id": "1234", "name": "Scooby", "age": 2, "type": "dog", "owner": "Daphne"}'
    # Invalid Response
    invalid_json = '{"id": "1234", "name": "Scooby", "age": "two"}'
    # Obtain value and error messages
    value, error_messages = validate_json(valid_json, Pet)
    value, error_messages = validate_json(invalid_json, Pet)
    # Error

# Generated at 2022-06-24 11:18:18.612247
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest

# Generated at 2022-06-24 11:18:29.173568
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty string
    try:
        tokenize_json("")
    except ParseError as e:
        assert e.code == "no_content"
        assert e.text == "No content."
        assert e.position.column_no == 1
        assert e.position.line_no == 1
        assert e.position.char_index == 0
    # Test for json parse error (this should be JSONDecodeError)
    try:
        tokenize_json('{ "this": "is not json")')
    except ParseError as e:
        assert e.code == "parse_error"
        assert e.text == "Expecting value."
        assert e.position.column_no == 21
        assert e.position.line_no == 1
        assert e.position.char_index == 20
    # Test for a

# Generated at 2022-06-24 11:18:39.436127
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    constructor = _TokenizingDecoder("{}")
    expected_inheritance = "<class 'typesystem.tokenize.tokens._TokenizingDecoder'> is a subclass of <class 'json.decoder.JSONDecoder'>"
    assert constructor.__class__.__bases__.__str__() == expected_inheritance, "__class__.__bases__"
    assert constructor.strict == True, "strict"
    assert constructor.parse_float == float, "parse_float"
    assert constructor.parse_int == int, "parse_int"
    assert constructor.parse_constant == JSONDecoder.parse_constant, "parse_constant"
    assert constructor.strict_number_policy == False, "strict_number_policy"
    assert constructor.object_hook == JSONDecoder.object_hook

# Generated at 2022-06-24 11:18:40.649624
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(["name"], content="content")


# Generated at 2022-06-24 11:18:41.679766
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder

# Unit tests for _TokenizingJSONObject

# Generated at 2022-06-24 11:18:46.709295
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem import types
    from typesystem.types import Dict, List, String
    from typesystem.schemas import Schema

    #Test for input type checking
    assert(tokenize_json(b"{}") is not None)
    assert(tokenize_json("{}") is not None)

    #Test for input validatity checking
    try:
        tokenize_json(b"{")
    except ParseError:
        assert(1)
    except Exception as e:
        assert(0)
        raise e

    #Test for input validatity checking with line number
    try:
        tokenize_json(b'{"a": 1\n}')
    except ParseError as err:
        assert(err.position.line_no == 2)
    except Exception as e:
        assert(0)

# Generated at 2022-06-24 11:18:52.307797
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Schema(properties={
        "a": {
            "type": "array",
            "items": {
               "type": "string"
            }
        }
    })
    validator = schema.as_json_schema()
    value, errors = validate_json('{"a": ["a"]}', validator)
    assert value == {u"a": [u"a"]}
    assert errors == []

# Generated at 2022-06-24 11:18:55.090897
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder({"hello": "world"}, content="content")
    assert d.scan_once == _make_scanner(d, "content")

# Generated at 2022-06-24 11:19:00.000553
# Unit test for function validate_json
def test_validate_json():
    """Ensure validate_json correctly processes valid data."""
    valid_data = '{"field1":1}'
    schema = Schema({"field1": fields.Integer()})
    value, errors = validate_json(valid_data, schema)
    assert value["field1"] == 1
    assert errors == []


# Generated at 2022-06-24 11:19:08.276588
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test the code that parses a JSON string to the internal data
    my_json = '{"key1":2,"key2":3,"key3":4}'
    my_parsed_json = {"key1": 2, "key2": 3, "key3": 4}
    assert tokenize_json(my_json) == my_parsed_json

    my_json = "[1, 2, 3, 4]"
    my_parsed_json = [1, 2, 3, 4]
    assert tokenize_json(my_json) == my_parsed_json

    my_json = '{"key1":2,"key2":3,"key3":{"key4":5}}'

# Generated at 2022-06-24 11:19:16.231906
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ScalarToken
    from typesystem.tokenize.positional_validation import validate_with_positions

    content = '{"a": 1, "b": {"c": [0, 1]}}'
    json_tokens = tokenize_json(content)
    assert isinstance(json_tokens, Token)
    assert isinstance(json_tokens, DictToken)
    assert json_tokens.value == {'a': 1, 'b': {'c': [0, 1]}}
    assert len(json_tokens.children) == 2
    assert json_

# Generated at 2022-06-24 11:19:22.993642
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_example = '{"name":"Mowgli","age":10,"species":"human"}'
    result = tokenize_json(valid_example)
    assert result.as_dict() == {"name":"Mowgli","age":10,"species":"human"}
    invalid_example = '{"name":"Mowgli","age":10,"species":"'
    with pytest.raises(ParseError):
        tokenize_json(invalid_example)

# Generated at 2022-06-24 11:19:25.156897
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder()
    print(context)


# Generated at 2022-06-24 11:19:27.639797
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "content"
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder.scan_once, typing.Callable)



# Generated at 2022-06-24 11:19:38.044572
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        fields={
            "text": Field(description="a text string", primitive_type=str),
            "boolean": Field(description="a boolean value", primitive_type=bool),
        }
    )
    valid_cases = [
        ('{"text": "hello", "boolean": true}', {'text': 'hello', 'boolean': True}),
        ('{"text": "hello", "boolean": false}', {'text': 'hello', 'boolean': False}),
    ]

# Generated at 2022-06-24 11:19:45.423177
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": {"b": "c"}, "d": "e", "f": ["g", "h", "i"], "j": "k"}'
    token = tokenize_json(content)
    assert token.items()[0] == (
        ScalarToken("a", 1, 2, content),
        DictToken({"b": ScalarToken("c", 10, 11, content)}, 5, 19, content),
    )
    assert token.items()[1] == (
        ScalarToken("d", 21, 22, content),
        ScalarToken("e", 25, 26, content),
    )

# Generated at 2022-06-24 11:19:52.480627
# Unit test for function validate_json
def test_validate_json():
    token = {"hello":"world","goodbye":"mars"}
    validator = {
        "hello": Type.string,
        "goodbye": Type.string
    }
    (value, error_messages) = validate_json(token, validator)
    assert value == {"hello":"world","goodbye":"mars"}
    assert type(error_messages) == list
    (value, error_messages) = validate_json(token, validator)
    assert value == {"hello":"world","goodbye":"mars"}
    assert type(error_messages) == list

# Generated at 2022-06-24 11:20:00.545265
# Unit test for function tokenize_json
def test_tokenize_json():
    tokenized = tokenize_json('{"foo": "bar"}')
    assert isinstance(tokenized, DictToken)

    assert isinstance(tokenized["foo"], ScalarToken)
    assert tokenized["foo"].value == "bar"

    assert tokenized["foo"].position.column_no == 8
    assert tokenized["foo"].position.line_no == 1
    assert tokenized["foo"].position.char_index == 7

    assert isinstance(tokenized["foo"].to_simple_value(), str)
    assert tokenized["foo"].to_simple_value() == "bar"

    assert isinstance(tokenized["foo"].to_primitive_value(), str)
    assert tokenized["foo"].to_primitive_value() == "bar"

    assert tokenized.to_primitive_value()

# Generated at 2022-06-24 11:20:11.420934
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test that valid json strings parse correctly and invalid strings raise
    an error.
    """
    #  Valid JSON
    json_string = '{"string": "This is a string", "number": 42.0, "bool": true, "null": null}'
    token = tokenize_json(json_string)
    assert token.value == {"string": "This is a string", "number": 42.0, "bool": True, "null": None}
    assert len(token.errors) == 0
    
    #  Valid JSON
    json_string = '[true, 123, {"hello": "world"}]'
    token = tokenize_json(json_string)
    assert token.value == [True, 123, {"hello": "world"}]
    assert len(token.errors) == 0
    
    #  Invalid JSON
   

# Generated at 2022-06-24 11:20:21.100878
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '  { "name": "John Smith", "age": 42, "birthday": "1970-01-01T00:00:00Z" }'
    tok = tokenize_json(content)
    assert(isinstance(tok, dict))
    assert(len(tok) == 3)
    assert(list(tok.keys())[0] == 'name')
    assert(list(tok.keys())[1] == 'age')
    assert(list(tok.keys())[2] == 'birthday')
    assert(isinstance(list(tok.values())[0], ScalarToken))
    assert(isinstance(list(tok.values())[1], ScalarToken))
    assert(isinstance(list(tok.values())[2], ScalarToken))

# Generated at 2022-06-24 11:20:30.598603
# Unit test for function tokenize_json
def test_tokenize_json():
    json_content = """
    {
        "phones": [
            {
                "number": "1234",
                "type": "work"
            },
            {
                "number": "555-1212",
                "type": "home",
                "twilio_sid": "Hid"
            }
        ],
        "name": "John Doe",
        "birthday": "1990-01-09"
    }
    """
    content = json_content.replace('\n', '').replace('\r', '').replace(' ', '')
    data = tokenize_json(content)

# Generated at 2022-06-24 11:20:32.124702
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="foo").content == "foo"



# Generated at 2022-06-24 11:20:42.242809
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String

    def test_field(field: Field) -> Message:
        value, errors = validate_json('"test value"', field)
        assert value == "test value"
        assert not errors
        return errors

    field = String(min_length=4, max_length=5)
    errors = test_field(field)
    assert not errors

    field = String(min_length=6, max_length=7)
    errors = test_field(field)
    assert len(errors) == 1
    error_message = errors[0]
    assert error_message.code == "min_length"
    assert error_message.position.line_no == 1
    assert error_message.position.column_no == 3
    assert error_message.position.char_index == 2