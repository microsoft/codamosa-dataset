

# Generated at 2022-06-24 11:10:45.282188
# Unit test for function validate_json
def test_validate_json():
    """Unit test for function validate_json"""
    content = '[{"name": "Steve", "age": 20}, {"name": "Sue", "age": 99}]'
    schema = Schema({"name": str, "age": int})
    value, error_messages = validate_json(content, schema)
    print(value, error_messages)



# Generated at 2022-06-24 11:10:54.722365
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json function

    Test cases:

    1. No content
    2. Parse error
    3. Validation error
    """
    schema = Schema("TestSchema", fields={
        "foo": Field("foo", required=True),
        "bar": Field("bar", required=True),
        "baz": Field("baz", required=True),
    })

    # test case 1
    # No content
    with pytest.raises(ParseError):
        validate_json("", schema)

    # test case 2
    # Parse error
    with pytest.raises(ParseError):
        validate_json("{", schema)

    # test case 3
    # Validation error
    value, messages = validate_json("{}", schema)
    assert value == {}

# Generated at 2022-06-24 11:11:02.928292
# Unit test for function tokenize_json
def test_tokenize_json():
    result=tokenize_json('[1,2,3]')
    expected=ListToken(value=[1, 2, 3], start_position=0, end_position=6,content='[1,2,3]')
    assert(result.content == expected.content)
    assert(result.value == expected.value)
    assert(result.start_position == expected.start_position)
    assert(result.end_position == expected.end_position)
    assert(result.type == expected.type)
    assert(result.representation == expected.representation)



# Generated at 2022-06-24 11:11:10.093088
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer, String
    from typesystem import Schema

    # Invalid JSON
    with pytest.raises(ParseError) as excinfo:
        validate_json(b'{"foo" 1}', Schema({"foo": Integer()}))
    assert "parse_error" in str(excinfo.value)

    with pytest.raises(ParseError) as excinfo:
        validate_json(b'{"foo" null}', Schema({"foo": Integer()}))
    assert "parse_error" in str(excinfo.value)

    # Schema mismatch
    value, messages = validate_json(b'{"foo": "bar"}', Schema({"foo": Integer()}))
    assert value == {"foo": "bar"}
    assert len(messages) == 1

# Generated at 2022-06-24 11:11:17.326281
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"test": "foo", "test1": "test", "test2": 123}'
    token = tokenize_json(json_str)

    assert isinstance(token, DictToken)
    assert token.start_index == 0
    assert token.end_index == 48
    assert token.value == {
        "test": "foo",
        "test1": "test",
        "test2": 123
    }

    assert isinstance(token.children[0], ScalarToken)
    assert token.children[0].start_index == 1
    assert token.children[0].end_index == 6
    assert token.children[0].value == "test"

    assert isinstance(token.children[1], ScalarToken)
    assert token.children[1].start_index == 10

# Generated at 2022-06-24 11:11:27.809880
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    person_schema = Person()
    content = '{"name": "foo", "age": 18}'
    value, error_messages = validate_json(content, person_schema)
    assert value == {'name': 'foo', 'age': 18}
    assert error_messages == []

    content = '{"name": "foo bar", "age": "baz"}'
    value, error_messages = validate_json(content, person_schema)
    assert len(error_messages) == 2
    assert error_messages[0].position.line_no == 1

# Generated at 2022-06-24 11:11:29.177819
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    assert(isinstance(_TokenizingDecoder(content="content"), _TokenizingDecoder))

# Generated at 2022-06-24 11:11:37.808129
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b"}') == DictToken({ScalarToken('a', 0, 1, '{"a": "b"}') : ScalarToken('b', 7, 8, '{"a": "b"}')}, 0, 8, '{"a": "b"}')

# Generated at 2022-06-24 11:11:43.424950
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Integer
    from typesystem.tests.factories import PostFactory

    schema = PostFactory(
        content=String(min_length=15, max_length=25),
        rating=Integer(minimum=1, maximum=5),
    )

    value, messages = validate_json(
        content=b'{"content": "the value", "rating": "5"}', validator=schema
    )
    assert not messages  # no errors
    assert value == {"content": "the value", "rating": 5}
    assert value.token.position.lineno == 1
    assert value.token.position.column_no == 1

    value, messages = validate_json(
        content=b'{"content": "the value", "rating": "7"}', validator=schema
    )

# Generated at 2022-06-24 11:11:52.319496
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = "['hello', 'kristian']"
    token = tokenize_json(json_string)
    assert token.position.column_no == 1
    assert token.position.line_no == 1
    assert token.position.char_index == 0
    assert token.end_position.column_no == 21
    assert token.end_position.line_no == 1
    assert token.end_position.char_index == 21

    assert token.value[0].value == "hello"
    assert token.value[0].position.column_no == 2
    assert token.value[0].position.line_no == 1
    assert token.value[0].position.char_index == 1
    assert token.value[0].end_position.column_no == 8

# Generated at 2022-06-24 11:11:52.932437
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert True

# Generated at 2022-06-24 11:11:54.794616
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='Hello')
    assert decoder.content == 'Hello'


# Generated at 2022-06-24 11:11:59.990655
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(content=b"{}", validator=Schema) == ({}, [])
    assert validate_json(content=b'{"a": 1}', validator=Schema) == ({"a": 1}, [])

    with pytest.raises(ValidationError) as exc:
        validate_json(content=b"{}", validator=Field(type=str))

    assert exc.value.messages == [Message(code="required", text="This field is required.")]

# Generated at 2022-06-24 11:12:10.459383
# Unit test for function validate_json
def test_validate_json():
    good_json = '''
        {
            "a": 1,
            "b": 2,
            "c": [1, 2, 3],
            "d": [
                {"a": 1},
                {"b": 2}
            ],
            "e": {
                "f": 1,
                "g": [1, 2]
            }
        }
    '''
    schema = Schema(
        fields={
            "a": Field(type="integer"),
            "b": Field(type="number"),
            "c": Field(type="array[number]"),
            "d": Field(type="array[object]"),
            "e": Field(type="object"),
        }
    )
    value, errors = validate_json(good_json, schema)
    assert not errors

# Generated at 2022-06-24 11:12:14.289295
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem import Object, Array, Union
    from typesystem.typing import Mapping, Sequence, Optional

    class Person(Schema):
        name = String()
        age = String()

    class Vehicle(Schema):
        name = String()
        age = String()

    class Element(Schema):
        name = String()
        data = Union[Array[Union[Person, Vehicle]], Object[Mapping[str, Person]]]
        owner = Union[Person, Vehicle]
        age = String()

    class Root(Schema):
        instructions = Array[Union[Person, Vehicle, Element]]
        age = String()

    root_schema = Root()

    # invalid json

# Generated at 2022-06-24 11:12:19.210683
# Unit test for function tokenize_json
def test_tokenize_json():
    with open(os.path.join(os.path.dirname(__file__), "example.json")) as f:
        content = f.read()
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert len(token.value) == 2
    assert type(token.value["name"]) == ScalarToken
    assert token.value["name"].value == "Jane"
    assert type(token.value["age"]) == ScalarToken
    assert token.value["age"].value == 23



# Generated at 2022-06-24 11:12:29.334448
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="number")

    # Test content is string
    content = "5"
    assert validate_json(content, validator) == (5, [])

    # Test content is byte format
    content = b'5'
    assert validate_json(content, validator) == (5, [])

    content = "[true, 3]"
    assert validate_json(content, validator) == ([True, 3], [])

    content = '[1, "abcd"]'
    assert validate_json(content, validator) == ([1, "abcd"], [])

    content = "[1, 2, 3, 4]"
    validator = Field(type="number", multiple_of=2)
    assert validate_json(content, validator) == ([1, 2, 3, 4], [])

    content = "[]"

# Generated at 2022-06-24 11:12:38.139316
# Unit test for function validate_json
def test_validate_json():
    import typesystem.schema
    import typesystem.fields

    class AddressSchema(typesystem.Schema):
        class Meta:
            strict = True

        zipcode = typesystem.fields.String(max_length=5)

    class PersonSchema(typesystem.Schema):
        class Meta:
            strict = True

        name = typesystem.fields.String(max_length=8)
        age = typesystem.fields.Integer()
        address = typesystem.fields.Object(schema=AddressSchema)

    validator = PersonSchema()

    # Test for valid json
    json_str = """
    {
        "name": "John Doe",
        "age": 50,
        "address":
        {
            "zipcode": "12345"
        }
    }
    """


# Generated at 2022-06-24 11:12:46.312622
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Unit tests for tokenize_json
    """
    empty_content = ""
    position = Position(column_no=1, line_no=1, char_index=0)
    with pytest.raises(ParseError) as error:
        tokenize_json(empty_content)
    assert len(error.value.messages) == 1
    message = error.value.messages[0]
    assert message.text == "No content."
    assert message.code == "no_content"
    assert message.position == position
    assert message.meta == {}

    invalid_content = "{"
    position = Position(column_no=1, line_no=1, char_index=1)
    with pytest.raises(ParseError) as error:
        tokenize_json(invalid_content)


# Generated at 2022-06-24 11:12:50.782920
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"FirstName": "Jane", "LastName": "Dane"}"""
    token = tokenize_json(content)
    assert token.value == {"FirstName": "Jane", "LastName": "Dane"}



# Generated at 2022-06-24 11:12:52.366023
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder("content")
    assert d.context == "content"

# Generated at 2022-06-24 11:12:57.181138
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"key": "value"}'
    decoder = _TokenizingDecoder("utf-8", "strict", "object_pairs_hook", False, None, None, None, None, content)
    assert decoder.scan_once("string", 0) == (DictToken({'key': 'value'}, 0, 14, content), 15)

# Generated at 2022-06-24 11:12:58.383527
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="test")

# Generated at 2022-06-24 11:13:07.655543
# Unit test for function validate_json
def test_validate_json():

    json_str = '{"name": "John"}'
    json_str_invalid = '{"name": "John", "age": "Bob"}' # additional attribute
    json_str_invalid_non_utf8 = '\xe2\x82\xac "John"}' # invalid byte
    class MySchema(Schema):
        name = Field(key="name")
    my_schema = MySchema()
    
    (value, error_messages) = validate_json(content=bytes(json_str , encoding = 'utf-8'), validator=my_schema)
    assert value == {'name': 'John'}
    assert len(error_messages) == 0


# Generated at 2022-06-24 11:13:10.346005
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '{"name": "Test", "age":23}'
    test_token = tokenize_json(test_content)
    assert test_token._value == {'name': 'Test', 'age': 23}
    assert test_token.start == 0
    assert test_token.end == 20
    assert test_token.content == test_content



# Generated at 2022-06-24 11:13:21.496933
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    assert validate_json(content='"bob"',validator=field) == ('bob', None)
    assert validate_json(content='123',validator=field)[1].messages == [
        Message(
            code="invalid_type",
            text="Must be a string.",
            position=Position(line_no=1, char_index=0, column_no=1),
        )
    ]
    assert validate_json(content='null',validator=field)[1].messages == [
        Message(
            code="invalid_type",
            text="Must be a string.",
            position=Position(line_no=1, char_index=0, column_no=1),
        )
    ]

# Generated at 2022-06-24 11:13:24.018187
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(None, None)
    assert isinstance(decoder.scan_once, typing.Callable)


# Unit tests for the tokenize_json function, with focus on parse errors.

# Generated at 2022-06-24 11:13:33.409717
# Unit test for function validate_json
def test_validate_json():
    # Errors returned from validate_json are instances of Message, which
    # have useful attributes. For example, this can be used to
    # show the location of the validation error in the file:
    #     print("line {}:{}".format(error.line, error.column))
    json_str = '{"name": "Bob"}'
    validator = Schema({
        'name': str
    })
    value, errors = validate_json(json_str, validator)
    assert errors == []
    assert value == {'name': 'Bob'}

    # Fail due to wrong value
    json_str = '{"age": 25}'
    value, errors = validate_json(json_str, validator)
    assert len(errors) == 1
    assert errors[0].type == 'type_mismatch'

# Generated at 2022-06-24 11:13:40.424594
# Unit test for function tokenize_json
def test_tokenize_json():

    from json.decoder import JSONDecodeError, JSONDecoder
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    from typesystem.tokenize.positional_validation import validate_with_positions

    content = '''
            {
                "a": 1,
                "b": "2",
                "c": [
                    1,
                    2
                ],
                "d": {
                        "e": 1
                }
            }
        '''

    def value_equals(value: typing.Any, expected: typing.Any) -> bool:
        if isinstance(expected, Token):
            if not isinstance(value, Token):
                return False
            if value.index_range != expected.index_range:
                return False

# Generated at 2022-06-24 11:13:52.621026
# Unit test for function validate_json
def test_validate_json():
    # Check that a dict with a string field is validated successfully
    validator = Field(type=str)
    content = '{"foo": "bar"}'
    value, errors = validate_json(content, validator)
    assert not errors
    assert value == {"foo": "bar"}

    # Check that a dict with a non-string field is validated successfully
    content = '{"foo": 0}'
    value, errors = validate_json(content, validator)
    assert len(errors) == 1
    assert errors[0].text == '"foo" should be a string.'
    assert errors[0].code == 'invalid_type'
    assert value == {"foo": "0"}

    # Check that a dict with a non-string field is validated successfully
    content = '{"foo": [0, 1]}'
    value, errors = validate

# Generated at 2022-06-24 11:14:00.512361
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken(
        {ScalarToken("key", 0, 3, '{"key": "value"}') : ScalarToken("value", 8, 15, '{"key": "value"}')}, 
        0, 15, '{"key": "value"}')


# Generated at 2022-06-24 11:14:01.883972
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="Testing")
    assert decoder.content == "Testing"


# Generated at 2022-06-24 11:14:13.181106
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert_equal(
        _TokenizingDecoder.__init__.__doc__, "Initialize self.  See help(type(self)) for accurate signature."
    )

    # __init__()
    d = _TokenizingDecoder()
    assert_equal(
        str(d),
        '{"parse_float": <built-in function float>, "parse_int": <built-in function int>, "parse_constant": None, "strict": true, "object_hook": null, "object_pairs_hook": null, "memo": {}, "scan_once": <function _make_scanner.<locals>._scan_once at 0x7f10de88cf28>}',
    )

    # __init__(object_hook=)

# Generated at 2022-06-24 11:14:23.742665
# Unit test for function validate_json
def test_validate_json():
    """
    Function validate_json can handle the following cases:
    1. string is not empty
    2. string is empty
    3. value is valid
    4. value is invalid
    """
    # Case 1: string is not empty
    field = Field(validators=[])
    value, error_message = validate_json('""', field)
    assert value == '' and error_message == {}
    # Case 2: string is empty
    try:
        validate_json('', field)
    except ParseError as err:
        assert err.text == 'No content.' and err.code == 'no_content'
    # Case 3: value is valid
    field = Field(validators=[])
    value, error_message = validate_json('"value"', field)
    assert value == 'value' and error_message == {}
   

# Generated at 2022-06-24 11:14:30.475778
# Unit test for function validate_json
def test_validate_json():
    schema = Schema({"name": str, "age": int}, meta={"title": "Person"}, name="Person")

    assert len(validate_json(b'{"age": "a"}', schema)[1]) != 0
    assert len(validate_json(b'{"age": "a"}', schema)[1]) != 0

    assert len(validate_json(b'{"name": "bob"}', schema)[1]) != 0

    assert len(validate_json(b'{"name": "bob", "age": "18"}', schema)[1]) == 0



# Generated at 2022-06-24 11:14:36.117637
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder()
    assert context.parse_float == float
    assert context.parse_int == int
    assert context.parse_array == JSONDecoder.scan_once
    assert context.parse_object == JSONDecoder.scan_once
    assert context.parse_string == scanstring
    assert context.strict
    assert context.scan_once is not None
    assert context.memo is not None


# Generated at 2022-06-24 11:14:42.515916
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'["hello", "world"]', Field(type="array", items=Field())) == (
        ['hello', 'world'],
        [],
    )
    assert (
        validate_json(b'{"a": "hello", "b": "world"}', Field(type="object", properties={"a": Field(), "b": Field()}))
        == ({'a': 'hello', 'b': 'world'}, [])
    )
    assert validate_json(b'"some string"', Field(type="string")) == (
        'some string',
        [],
    )

# Generated at 2022-06-24 11:14:53.453999
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import SchemaMeta
    from typesystem.fields import String, Integer, Number, Boolean, Array

    assert validate_json(b'{"a": 32}', SchemaMeta("SomeSchema", (), {'a': Integer()})) == (
        {'a': 32}
        ,
        None,
    )

    try:
        assert validate_json(b"", SchemaMeta("SomeSchema", (), {"a": Integer()}))
    except ParseError as e:
        assert e.code == "no_content"


# Generated at 2022-06-24 11:14:57.566042
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{"a": 1}'
    decoder = _TokenizingDecoder(content=json_str)
    assert(type(decoder) == _TokenizingDecoder)

# Generated at 2022-06-24 11:15:06.919151
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder(content="some string")
    assert tokenizing_decoder.encoding == "utf-8"
    assert tokenizing_decoder.content == "some string"
    assert tokenizing_decoder.object_hook == None
    assert tokenizing_decoder.parse_float == float
    assert tokenizing_decoder.parse_int == int
    assert tokenizing_decoder.parse_constant == None
    assert tokenizing_decoder.strict == True
    assert tokenizing_decoder.object_pairs_hook == None
    assert tokenizing_decoder.memo == {}
    assert tokenizing_decoder.scan_once != None


# Generated at 2022-06-24 11:15:16.694428
# Unit test for function validate_json
def test_validate_json():
    field_name = "some_name"
    validator = Field(name=field_name, required=True)

    # Valid data
    content = '{"some_name": "something valid"}'
    expected_data = {"some_name": "something valid"}
    expected_errors = []
    data, errors = validate_json(content, validator)
    assert data == data
    assert errors == errors

    # Malformed JSON
    content = '{"some_name": bad}'
    expected_data = None

# Generated at 2022-06-24 11:15:25.940133
# Unit test for function validate_json
def test_validate_json():
    # valid form
    (value, error_messages) = validate_json(
        b'{"key1": "value1", "key2": 5 }',
        validator=Schema({"key1": str, "key2": int}),
    )
    assert len(error_messages) == 0
    assert value == {"key1": "value1", "key2": 5}

    # invalid form
    (value, error_messages) = validate_json(
        b'{"key1": "value1", "key2": "5" }',
        validator=Schema({"key1": str, "key2": int}),
    )
    assert len(error_messages) == 1
    assert error_messages[0].code == ValidationError.CODE_TYPE_ERROR
    assert error_messages

# Generated at 2022-06-24 11:15:30.413830
# Unit test for function validate_json
def test_validate_json():
    json = """
        {
          "person": {
            "name": "John Doe",
            "age": 27
          },
          "cities": [
            "Amsterdam",
            "Los Angeles",
            "New York"
          ]
        }
    """
    json = json.replace("\n", "")
    try:
        result = validate_json(content=json, validator=TestSchema)
    except ValidationError as exc:
        error = exc
    assert error.data == [{
        "type": "object",
        "position": {
            "column_no": 13,
            "line_no": 3,
            "char_index": 67
        },
        "message": "Expected object, but got number."
    }]


# Generated at 2022-06-24 11:15:37.595534
# Unit test for function validate_json
def test_validate_json():
    schema = {
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "age": {"type": "integer", "minimum": 0, "maximum": 130},
            "secret": {"type": "string"},
        },
        "required": ["first_name", "last_name"],
    }
    validator = Schema(schema)

# Generated at 2022-06-24 11:15:48.448558
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON objects
    content = '{"name": "Tom"}'
    messages = validate_json(content, Field(type=str))
    assert not messages.errors()

    # Invalid JSON objects
    content = '{"name": "Tom"}'
    messages = validate_json(content, Field(type=int))
    assert len(messages.errors()) == 1
    error = messages.errors()[0]
    assert error.code == "invalid_type"
    assert error.text == "Invalid type. Expected int but got str."
    assert error.position.line_no == 1
    assert error.position.column_no == 11

    # Valid JSON array
    content = '["Tom", "Jerry", "Spike"]'
    messages = validate_json(content, ListToken(type=str))
    assert not messages.errors

# Generated at 2022-06-24 11:15:59.132111
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:16:03.563999
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.parse_float("1.0") == 1.0
    assert decoder.parse_int("0") == 0
    assert decoder.strict == False
    assert decoder.scan_once("content", 0)[0].content == "content"


# Generated at 2022-06-24 11:16:06.669321
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema, fields

    class UserSchema(Schema):
        name = fields.String(max_length=50)
        age = fields.Integer()

    content = '{"name": "Will", "age": 25}'
    value, error_messages = validate_json(content, UserSchema)
    assert value == {"name": "Will", "age": 25}
    assert error_messages == []

# Generated at 2022-06-24 11:16:12.522344
# Unit test for function tokenize_json
def test_tokenize_json():
    test_json_string = r'{"key1":"value1","key2":"value2"}'
    json_list = tokenize_json(test_json_string)
    assert isinstance(json_list, dict)
    assert len(json_list) == 2
    for k, v in json_list.items():
        assert isinstance(k, ScalarToken)
        assert isinstance(v, ScalarToken)


# Generated at 2022-06-24 11:16:23.388563
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.types import JSON
    from typing import List

    data = '{"name": "foo", "age": "bar"}'
    (value, errors) = validate_json(data, JSON())
    assert value == json.loads(data)
    assert isinstance(errors, List)

    data = '{"name": "foo", "age": "bar", "foo": "bar"}'
    (value, errors) = validate_json(data, JSON())
    assert value == json.loads(data)
    assert isinstance(errors, List)

    data = '{"name": "foo", "age": "bar"}'
    (value, errors) = validate_json(data, JSON(min_length=1))
    assert value == json.loads(data)
    assert isinstance(errors, List)
    assert len

# Generated at 2022-06-24 11:16:25.166953
# Unit test for function tokenize_json
def test_tokenize_json():
    assert isinstance(tokenize_json('{"abc": "def"}'), dict)



# Generated at 2022-06-24 11:16:27.530421
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "Alice", "age": 20}')
    assert isinstance(token, DictToken)
    assert len(token.value) == 2
    assert token.value["age"].value == 20


# Generated at 2022-06-24 11:16:35.977186
# Unit test for function tokenize_json
def test_tokenize_json():
    def assert_tokens(json_string, expected_tokens):
        tokens = tokenize_json(json_string)
        assert_tokens_equal(tokens, json_string, expected_tokens)

    assert_tokens('', [])
    assert_tokens('{}', [DictToken({}, 0, 1, '{}')])
    assert_tokens('[]', [ListToken([], 0, 1, '[]')])
    assert_tokens('"hello"', [ScalarToken('hello', 0, 6, '"hello"')])

# Generated at 2022-06-24 11:16:46.059870
# Unit test for function validate_json
def test_validate_json():
    json_validator = Field(name="JSON Validator", validators=["json"])
    json_string = '{ "model": "json.jsonvalidator", "pk": 0, "fields": { "json": "{\\"bad\\": \\"json\\"}" } }'
    # json_string = '{ "model": "json.jsonvalidator", "pk": 0, "fields": { "json": "{\"bad\": \"json\"}" } }'
    # json_string = '{ "model": "json.jsonvalidator", "pk": 0, "fields": { "json": "{\\"bad\\": \\"json\\"}" } }'

    value, errors = validate_json(json_string, json_validator)

    # FIXME: This does not work with python 3.6
    # assert len(errors)

# Generated at 2022-06-24 11:16:47.829521
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__

# Generated at 2022-06-24 11:16:56.370093
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'"foo"') == ScalarToken("foo", 0, 4, "foo")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 4, "foo")
    with raises(ParseError) as excinfo:
        tokenize_json("")
    assert excinfo.value.text == "No content."
    with raises(ParseError) as excinfo:
        tokenize_json("---")
    assert excinfo.value.text == "Expecting property name enclosed in double quotes."



# Generated at 2022-06-24 11:16:58.176865
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='')
    assert isinstance(decoder, JSONDecoder)

# Generated at 2022-06-24 11:17:04.414019
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    content = '[{"name": "Bob", "age": "30"}, {"name": "Alice"}]'
    success, errors = validate_json(content, Array(of=Person))
    assert len(errors) == 1, errors
    assert errors[0].text == "This field is required.", errors


# Generated at 2022-06-24 11:17:08.867771
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{}'
    decoder = _TokenizingDecoder(content=content)
    token, _ = decoder.scan_once(content, 0)
    assert token.start == 0
    assert token.end == 1
    assert token.type == "dict"

# Generated at 2022-06-24 11:17:17.667786
# Unit test for function validate_json
def test_validate_json():
    # Test valid default content
    content = '{"dummy_key": "dummy_value"}'
    validator = type('TestSchema', (Schema,), {"dummy_key": str})
    value, error_messages = validate_json(content, validator)
    assert value == {"dummy_key": "dummy_value"}
    assert error_messages == []

    # Test invalid default content
    content = '{"dummy_key": "dummy_value", "dummy_key2": "dummy_value2"}'
    validator = type('TestSchema', (Schema,), {"dummy_key": str})
    value, error_messages = validate_json(content, validator)
    assert value == None

# Generated at 2022-06-24 11:17:26.343761
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert issubclass(_TokenizingDecoder, JSONDecoder)
    assert (_TokenizingDecoder.__init__.__code__.co_argcount == 5)
    assert (
        _TokenizingDecoder.__init__.__code__.co_varnames
        == ("self", "*args", "**kwargs", "content")
    )
    assert (_TokenizingDecoder.scan_once.__code__.co_varnames == ("string", "idx"))
    assert (_TokenizingDecoder.scan_once.__code__.co_argcount == 2)
    assert (_TokenizingDecoder.scan_once.__code__.co_flags & 0x0008)
    assert not (_TokenizingDecoder.scan_once.__code__.co_flags & 0x0020)

# Generated at 2022-06-24 11:17:36.400580
# Unit test for function tokenize_json
def test_tokenize_json():
    expected = [
        {"a": 1, "b": "two"},
        {"a": 1, "b": "two"},
        {"a": 1, "b": "two"},
        {"a": 1, "b": "two"},
        {"a": 1, "b": "two"},
        {"a": 1, "b": "two"},
    ]

# Generated at 2022-06-24 11:17:42.271133
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    content = '{ "key": "value" }'
    value, error_messages = validate_json(content, validator)
    assert error_messages.text == "Expected string value."
    assert error_messages.position.char_index == 2
    assert error_messages.position.column_no == 3
    assert error_messages.position.line_no == 1
    assert error_messages.code == "invalid_type"

# Generated at 2022-06-24 11:17:54.284907
# Unit test for function validate_json
def test_validate_json():
    data = {
        "a": "abc",
        "b": "abc",
        "c": "abc",
        "d": "abc",
        "e": "abc",
        "f": "abc",
        "g": "abc",
        "h": "abc",
        "i": "abc",
    }
    result, messages = validate_json(
        json.dumps(data),
        {
            "a": "string",
            "b": "string",
            "c": "string",
            "d": "string",
            "e": "string",
            "f": "string",
            "g": "string",
            "h": "string",
            "i": "string",
        },
    )
    assert result == data
    assert not messages


# Generated at 2022-06-24 11:18:05.363141
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("")
    assert decoder.scan_once("{}", 0) == (DictToken({}, 0, 1, "{}"), 2)
    decoder = _TokenizingDecoder("", parse_float="int")
    assert decoder.scan_once("{}", 0) == (DictToken({}, 0, 1, "{}"), 2)
    assert decoder.parse_float("3.0") == 3
    decoder = _TokenizingDecoder("", parse_float="int", parse_int="float")
    assert decoder.scan_once("{}", 0) == (DictToken({}, 0, 1, "{}"), 2)
    assert decoder.parse_float("3.0") == 3.0
    assert decoder.parse_int("3") == 3.0
    dec

# Generated at 2022-06-24 11:18:14.556668
# Unit test for function validate_json
def test_validate_json():
    import sys
    sys.path.append('/Users/nick/Desktop/')
    from xyz.fields import String
    from xyz.schemas import Schema
    from xyz.validation import validate
    from xyz.exceptions import ValidationError

    class JSONExample(Schema):
        name = String(required=True)

    try:
        result = validate_json('{"name": "Nick"}', validator=JSONExample)
        assert (result[0]['name'] == "Nick")
        assert (len(result[1]) == 0)
    except ValueError:
        # Expected to fail, but failure is not due to parse error.
        assert(False)



# Generated at 2022-06-24 11:18:19.154933
# Unit test for function validate_json
def test_validate_json():
    content = '{"text": "foo"}'
    validator = {
        "text": "string",
    }

    result = validate_json(content, validator)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], typing.List)

# Generated at 2022-06-24 11:18:20.973365
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="one\ntwo")
    assert isinstance(decoder, JSONDecoder)

# Generated at 2022-06-24 11:18:30.936942
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name":"parth","address":{"city":"ahemdabad","city":"junagadh"}}')
    assert token != None
    # print(token)
    token = tokenize_json('"parth"')
    assert token != None
    error_messages = None
    # print(token)
    token = tokenize_json('[1,2,3,]')
    assert token != None
    # print(token)
    token = tokenize_json('[1,2,3,]')
    assert token != None
    # print(token)
    token = tokenize_json(r'''{"name":"parth","address":{"city":"ahemdabad",   "city":"junagadh"}}''')
    assert token != None
    # print(token)
    token = tokenize_

# Generated at 2022-06-24 11:18:40.890509
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"a": "all"}', '{"a": "all"}') == ({'a': 'all'}, None)

    # Test a type error
    field = Field(type='object')
    assert validate_json('1', field)[1] == [Message(text="Value is not an object.", code='type_error', position=Position(column_no=1, line_no=1, char_index=0))]

    # Test a property error
    field = Field(type='object', properties={'a': 'all'})
    assert validate_json('{"a": "all"}', field) == ({"a": "all"}, None)

# Generated at 2022-06-24 11:18:44.503371
# Unit test for function tokenize_json
def test_tokenize_json():
    data = '{"a": 12, "b": "test"}'
    token = tokenize_json(data)
    print(token)
    print(token['a'])
    print(token['a'].value)
    print(token['a'].array)
    print(token['a'].array[0].array[0])


# Generated at 2022-06-24 11:18:55.095770
# Unit test for function validate_json
def test_validate_json():
    # Test empty string error
    try:
        validate_json("", True)
        assert False
    except ParseError as exc:
        assert True
        assert exc.code == "no_content"
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
        assert exc.position.char_index == 0
        assert exc.text == "No content."

    # Test JSON parse error
    try:
        validate_json("{}<", True)
        assert False
    except ParseError as exc:
        assert True
        assert exc.code == "parse_error"
        assert exc.position.column_no == 3
        assert exc.position.line_no == 1
        assert exc.position.char_index == 2
        assert exc.text == "Unexpected end of JSON input."

# Generated at 2022-06-24 11:19:01.485544
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String
    from typesystem.exceptions import ValidationError

    try:
        validate_json("{}", String(required=True))
        assert False, "this should raise a ValidationError"
    except ValidationError as exc:
        messages = exc.messages
        assert len(messages) == 1
        msg = messages[0]
        assert msg.code == "required"
        assert "is required" in msg.text

# Generated at 2022-06-24 11:19:04.401006
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name":"Peter"}'
    token = tokenize_json(content)
    assert token.as_dict == {"name": "Peter"}
    assert token["name"] == "Peter"
    # Unit test for function validate_json

# Generated at 2022-06-24 11:19:11.392047
# Unit test for function validate_json
def test_validate_json():
    import pytest
    content = b"""
    {
        "key": "value",
        "key2": 2,
        "key3": true,
        "key4": false,
        "key5": null
    }
    """
    validator = {}
    result = validate_json(content, validator)
    expected_value = {
        "key": "value",
        "key2": 2,
        "key3": True,
        "key4": False,
        "key5": None,
    }
    assert result[0] == expected_value
    # Should not have an error message
    assert result[1] == []
    # Test with a bad key in the content

# Generated at 2022-06-24 11:19:23.417695
# Unit test for function validate_json
def test_validate_json():
    
    # 1. Test for an incorrect json string - should return a message 'parse_error'
    content = """{
        name: 'james',
        age: 35
    }"""
    validator = Field(name='name', required=True)
    value, error_msg = validate_json(content, validator)
    expected_msg = Message(text="Expecting value.", code="parse_error", position=Position(line_no=2, column_no=18, char_index=37))
    assert error_msg == [expected_msg]

    # 2. Test for a valid json string
    content = """{
        "name": "james",
        "age": 35
    }"""
    value, error_msg = validate_json(content, validator)

# Generated at 2022-06-24 11:19:25.399028
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "{}"
    _TokenizingDecoder(content=content)

# Generated at 2022-06-24 11:19:33.982725
# Unit test for function tokenize_json
def test_tokenize_json():
    for input_str, expected_json in [
        ('{"a": 1}', {'a': 1}),
        ('{"a": "b"}', {'a': 'b'}),
        ('{"a": null}', {'a': None}),
        ('{"a": [1]}', {'a': [1]}),
        ('{"a": 1, "b": 2}', {'a': 1, 'b': 2}),
        ('{"a": 1, "b": 2, "c": 3}', {'a': 1, 'b': 2, 'c': 3})
    ]:
        assert tokenize_json(input_str).data == expected_json



# Generated at 2022-06-24 11:19:42.013817
# Unit test for function validate_json
def test_validate_json():

    content = '{"a": "a", "b": "b"}'
    schema = Schema({
        "a": str,
        "b": str
    })
    value, error_messages = validate_json(content=content, validator=schema)
    assert value == {"a": "a", "b": "b"}
    assert len(error_messages) == 0

    content = '{"a": "a", "b": "b"}'
    schema = Schema({
        "a": str,
        "b": str,
        "c": str
    })
    value, error_messages = validate_json(content=content, validator=schema)
    assert value == {"a": "a", "b": "b"}
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:19:50.588206
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": "b", "c": "d"}') == DictToken(
        {ScalarToken('a', 0, 2, '{"a": "b", "c": "d"}'): ScalarToken('b', 6, 8, '{"a": "b", "c": "d"}'), ScalarToken('c', 11, 13, '{"a": "b", "c": "d"}'): ScalarToken('d', 17, 19, '{"a": "b", "c": "d"}')}, 0, 22, '{"a": "b", "c": "d"}'
        )


# Generated at 2022-06-24 11:19:52.159811
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    constructor = _TokenizingDecoder(content='test_content')
    assert isinstance(constructor, JSONDecoder)
    assert constructor.scan_once == _make_scanner(constructor, 'test_content')


# Generated at 2022-06-24 11:19:57.102893
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem import errors

    class Movie(Schema):
        title = String()

    content = '{"title": 123}'
    value, messages = validate_json(content, validator=Movie)

    assert value is None
    assert len(messages) == 1
    assert messages[0]["code"] == errors.ERROR_INVALID_TYPE



# Generated at 2022-06-24 11:20:03.747075
# Unit test for function tokenize_json
def test_tokenize_json():
    test_cases = [
        # test inputs, expected output
        ("", ParseError),
        ("{}", dict),
        ('{"key":"value"}', dict),
        ("[]", list),
        ("[{}]", list),
        ('["foo", "bar"]', list),
    ]
    for test_input, expected_output in test_cases:
        result = tokenize_json(test_input)
        assert type(result) == expected_output



# Generated at 2022-06-24 11:20:10.110390
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key1": "value1", "key2": {"key3": ["value4", "value5"]}, "key6": "value6"}')

    expected_value = {
        "key1": "value1",
        "key2": {"key3": ["value4", "value5"]},
        "key6": "value6"
    }

    assert token.value == expected_value


# Generated at 2022-06-24 11:20:14.550910
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "JSON string"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.content == "JSON string"
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_float == JSONDecoder.parse_float
    assert decoder.parse_int == JSONDecoder.parse_int
    assert decoder.parse_string == JSONDecoder.parse_string
    assert decoder.strict == JSONDecoder.strict
    assert decoder.scan_once != JSONDecoder.scan_once

# Unit tests for method _TokenizingJSONObject, _TokenizingDecoder.scan_once, and tokenize_json

# Generated at 2022-06-24 11:20:19.248392
# Unit test for function tokenize_json
def test_tokenize_json():
    res = tokenize_json(content='{"key": "value"}')
    assert isinstance(res, dict)
    assert isinstance(res['key'], str)
    assert res['key'] == 'value'
    assert isinstance(res, DictToken)
    assert isinstance(res['key'], ScalarToken)



# Generated at 2022-06-24 11:20:28.948191
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:20:39.690829
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"a": 1}'
    res = tokenize_json(json_str)
    assert res.value == {"a": 1}

    json_str = "{\"a\": {\"b\": 1}}"
    res = tokenize_json(json_str)
    assert res.value == {"a": {"b": 1}}

    json_str = '{"a": {"b": [1, 2, 3]}}'
    res = tokenize_json(json_str)
    assert res.value == {"a": {"b": [1, 2, 3]}}

    json_str = '{"a": {"b": [1, 2, 3]}}'
    res = tokenize_json(json_str)
    assert res.value == {"a": {"b": [1, 2, 3]}}

    json_str