

# Generated at 2022-06-24 11:10:53.303009
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = '{"key1":1, "key2":["val1","val2"],"key3":{"key4":null}}'

# Generated at 2022-06-24 11:10:58.414727
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = b'{"a": 1, "b": 2}'
    
    decoder = _TokenizingDecoder(content=content)
    assert(decoder.scan_once(content, 0)) == (DictToken({}, 0, 13, content), 14)

# Generated at 2022-06-24 11:11:07.945278
# Unit test for function tokenize_json
def test_tokenize_json():
    # This test will fail if we change the implementation of
    # JSONDecoder so that it no longer accepts bytes, and we
    # have not updated this test to pass a str instead.
    result = tokenize_json(b'{"key":"value", "anotherKey": "anotherValue"}')

# Generated at 2022-06-24 11:11:09.593818
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # pylint:disable=unused-variable
    decoder = _TokenizingDecoder(content="")

# Generated at 2022-06-24 11:11:12.066719
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert type(_TokenizingDecoder(content=None)) == _TokenizingDecoder
    assert type(_TokenizingDecoder(content="")) == _TokenizingDecoder


# Generated at 2022-06-24 11:11:17.751872
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "key": "value",
        "key2": "value2"
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token[0], ScalarToken)
    assert token[0].data == "value"


# Generated at 2022-06-24 11:11:28.122189
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import (
        Boolean,
        Date,
        DateTime,
        Dict,
        Integer,
        List,
        MultipleChoice,
        Number,
        Object,
        Scalar,
        Schema,
        String,
        Time,
    )
    from typesystem.types import BooleanType, Choice, DateType, DateTimeType
    from typesystem.types import FloatType, IntegerType, ListType, SchemaType
    from typesystem.types import StringType, TimeType

    # Basic validations
    schema = Object.of(
        {
            "name": String,
            "age": Integer,
        }
    )


# Generated at 2022-06-24 11:11:30.983327
# Unit test for function validate_json
def test_validate_json():
    content = ""
    validator = "hello"
    with pytest.raises(ValidationError):
        validate_json(content=content, validator=validator)



# Generated at 2022-06-24 11:11:32.214221
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="testing")


# Generated at 2022-06-24 11:11:39.655208
# Unit test for function validate_json
def test_validate_json():
    from dataclasses import dataclass
    from typesystem import String, Integer, Array

    @dataclass
    class Number:
        value: int

    @dataclass
    class Point:
        x: int
        y: int

    @dataclass
    class CoordinateSystem:
        points: typing.List[Point]

    @dataclass
    class NumberSchema(Schema):
        values: Array[Number]

    @dataclass
    class Scheme(Schema):
        coordinate_system: CoordinateSystem
        number_schema: NumberSchema

    @dataclass
    class PointSchema(Schema):
        x: Integer
        y: Integer

    @dataclass
    class CoordinateSystemSchema(Schema):
        points: Array[PointSchema]


# Generated at 2022-06-24 11:11:48.831105
# Unit test for function validate_json
def test_validate_json():
    json_str = '{ "objNested": { "arr": [ 0, 1 ] } }'
    schema = Schema(fields={
        "objNested": {
            "type": "object",
            "fields": {
                "arr": {
                    "type": "array",
                    "items": {
                        "type": "integer"
                    }
                }
            }
        }
    })
    # an object is passed for the schema and the json string is validated recursively
    # to check for the object. Thus, the contents are treated as a whole and not individually
    from typesystem.schemas import Schema
    schema = Schema()

# Generated at 2022-06-24 11:11:56.149391
# Unit test for function tokenize_json
def test_tokenize_json():
    json = '{"hello": "world", "arr": [1, 2, 3], "obj": {"more": "stuff"}}'
    result = tokenize_json(json)
    assert isinstance(result, DictToken)
    assert result.char_index == 0
    assert result.end_index == len(json) - 1
    assert isinstance(result.children, dict)

    assert isinstance(result.children["hello"], ScalarToken)
    assert result.children["hello"].char_index == 2
    assert result.children["hello"].end_index == 12
    assert result.children["hello"].value == "world"

    assert isinstance(result.children["arr"], ListToken)
    assert result.children["arr"].char_index == 14
    assert result.children["arr"].end_index == 26
   

# Generated at 2022-06-24 11:12:05.743030
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("1", int) == (1, None)
    assert validate_json("null", int) == (
        None,
        [
            Message(
                text="null is not an integer.",
                code="type_error.integer",
                position=Position(
                    column_no=1, line_no=1, char_index=0, index=0
                ),
            )
        ],
    )
    assert validate_json("bad", int) == (
        None,
        [
            Message(
                text="bad is not an integer.",
                code="type_error.integer",
                position=Position(
                    column_no=1, line_no=1, char_index=0, index=0
                ),
            )
        ],
    )

# Generated at 2022-06-24 11:12:12.109644
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder("{}")
    assert tokenizing_decoder.memo == {} and tokenizing_decoder.strict == True
    assert tokenizing_decoder.parse_object == _TokenizingJSONObject
    assert tokenizing_decoder.object_hook == None
    assert tokenizing_decoder.object_pairs_hook == None
    assert tokenizing_decoder.parse_array == JSONDecoder.parse_array
    assert tokenizing_decoder.parse_string == JSONDecoder.parse_string


# Generated at 2022-06-24 11:12:21.356982
# Unit test for function tokenize_json
def test_tokenize_json():
    test_text1 = '{ "key1": [1,2,3] }'
    token = tokenize_json(test_text1)
    assert isinstance(token, DictToken)

    test_text2 = '{ "key1": [1,2,3], \n"key2": [4,5,6] }'
    token = tokenize_json(test_text2)
    assert isinstance(token, DictToken)

    test_text3 = '{ "key1": [1,2,3], \n"key2": [4,5,6] }'
    token = tokenize_json(test_text3)
    assert isinstance(token, DictToken)
    children = [child for child in token.children()]
    assert len(children) == 2


# Generated at 2022-06-24 11:12:24.090676
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name":"Sanjay", "age":27}')
    assert token.data['name'].data == 'Sanjay'



# Generated at 2022-06-24 11:12:33.255060
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{}')
    assert isinstance(decoder.scan_once, _scan_once)
    class _Gather:
        def __init__(self) -> None:
            self.tokens = []

        def __call__(self, string: str, idx: int) -> typing.Tuple[Token, int]:
            value, end = _scan_once(string, idx)
            self.tokens.append(value)
            return value, end

    gather = _Gather()
    decoder.scan_once = gather.__call__
    decoder.decode('{"a": "b"}')
    assert isinstance(gather.tokens[0], DictToken)

# Generated at 2022-06-24 11:12:37.907939
# Unit test for function tokenize_json
def test_tokenize_json():
    class Schema1(Schema):
        a = Field(type=int)

    class Schema2(Schema):
        b = Field(type=int)

    class Schema3(Schema):
        c = Field(type=int)

    def test_tokenize_json(data: typing.Union[str, bytes], schema: Schema) -> None:
        try:
            _, errors = validate_json(data, schema)
        except (ParseError, ValidationError) as exc:
            errors = exc.error_messages

        assert not errors

    test_tokenize_json("{}", Schema1)
    test_tokenize_json("{\"a\": 1}", Schema1)
    test_tokenize_json("{\"a\": 1}", Schema2)
    test_tokenize_json

# Generated at 2022-06-24 11:12:47.384710
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:12:56.711003
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Number
    from typesystem import schema, schema_errors

    class Person(schema.Object):
        name = String()
        age = Number(minimum=0, maximum=120)

    json_data = """
        {
            "name": "Marty McFly",
            "age": 17
        }
    """

    value, errors = validate_json(json_data, Person)
    assert value == {
        "name": "Marty McFly",
        "age": 17,
    }
    assert not errors

    json_data = """
        {
            "name": "Marty McFly",
            "age": -1
        }
    """

    value, errors = validate_json(json_data, Person)

# Generated at 2022-06-24 11:13:06.622470
# Unit test for function tokenize_json
def test_tokenize_json():
    # known good input
    content = """
    {
        "a": [
            {
                "b": {
                    "c": "c1"
                }
            },
            {
                "b": {
                    "c": "c2"
                }
            },
            {
                "b": {
                    "c": "c3"
                }
            }
        ]
    }
    """
    # convert to JSON object
    obj = json.loads(content)
    # convert JSON to token tree
    token = tokenize_json(content)
    # ensure the token tree matches the input
    assert token.value == obj
    # ensure conversion from value back to tree is a no-op
    assert token == list(token.flatten())[0]
    # ensure conversion from value back to string is a no-op

# Generated at 2022-06-24 11:13:18.417829
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.tokenize.positional_validation import validate_with_positions
    content = """{"timezone": "America/New_York", "date": "2017-09-18T03:00:00.000Z", "date_hour": "2017-09-18T03:00:00.000Z"}"""
    token = tokenize_json(content)

    class TestSchema(Schema):
        timezone = Field(required=True, format="timezone")
        date = Field(required=True, format="date-time")
        date_hour = Field(required=True, format="date-time")

    value, error_messages = validate_with_positions(token, TestSchema)
    assert len(error_messages) == 1
    error_message = error_messages[0]
    assert error

# Generated at 2022-06-24 11:13:26.659466
# Unit test for function validate_json
def test_validate_json():
    class UserSchema(Schema):
        name = String()
        age = Integer()
    user = '{"name": "Adam", "age": "12"}'
    result, error_messages = validate_json(content=user, validator=UserSchema)
    assert result == {'name': 'Adam', 'age': 12}
    assert len(error_messages) == 0
    user = '{"name": "Adam", "age": "abc"}'
    result, error_messages = validate_json(content=user, validator=UserSchema)
    assert result is None
    assert len(error_messages) == 1
    assert error_messages[0].text == 'not_valid'
    assert error_messages[0].position.line_no == 1


# Generated at 2022-06-24 11:13:30.734639
# Unit test for function validate_json
def test_validate_json():
    content = """{
        "toppings": ["Cheese", "Pepperoni", "Tomatoes"],
        "customer": {
            "name": "Yuri",
            "email": "yuri@example.com",
        },
        "orderedAt": "2020-07-01T12:00:00Z",
        "delivery": true,
        "mustBeDeliveredBy": "2020-07-01T14:00:00Z",
    }"""
    error_messages = validate_json(content, PizzaOrderSchema())
    assert error_messages == []


# Generated at 2022-06-24 11:13:35.038594
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Trivial test, since _TokenizingDecoder is only a constructor
    content = """ {"a":"b"} """
    decoder = _TokenizingDecoder(content=content)
    assert decoder.content == content


# Generated at 2022-06-24 11:13:43.897616
# Unit test for function validate_json
def test_validate_json():
    content = '{"item": "thing"}'
    result = validate_json(content, lambda: None)
    assert result == ({"item": "thing"}, [])

    content = '{"item": "thing"}}'
    result = validate_json(content, lambda: None)
    assert len(result[1]) == 1

    validation_error = result[1][0]
    assert validation_error.code == "parse_error"
    assert validation_error.position == Position(1, 1, 1)

    content = '{"item": "thing",}'
    result = validate_json(content, lambda: None)
    assert len(result[1]) == 1

    validation_error = result[1][0]
    assert validation_error.code == "parse_error"

# Generated at 2022-06-24 11:13:52.330746
# Unit test for function validate_json
def test_validate_json():
    json_str = '{"name": "Eric", "age": 25, "likes": ["hiking", "pool"]}'
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="number")
        likes = Field(type="list", items=Field(type="string"))
    result, errors = validate_json(json_str, Person)
    assert result == {"name": "Eric", "age": 25, "likes": ["hiking", "pool"]}
    assert errors == {}

# Generated at 2022-06-24 11:13:55.313387
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_str = '{"a": "foo", "b": [1, 2, 3], "c": {"foo": "bar"}}'
    decoder = _TokenizingDecoder(content = json_str)
    assert callable(decoder.scan_once) == True


# Generated at 2022-06-24 11:13:59.032242
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    obj = _TokenizingDecoder(content="test")
    assert obj is not None


# Generated at 2022-06-24 11:14:08.434224
# Unit test for function validate_json
def test_validate_json():
    """
    A simple test for function validate_json.
    """
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.message import Message
    from typesystem.error_messages import ErrorMessage

    content = b'{"first_name": "John"}'
    validator = Schema([String()])
    value, errors = validate_json(content=content, validator=validator)

    expected_value = {"first_name": "John"}
    expected_errors = Message(
        text="Must be of type <class 'str'>",
        code="invalid_type",
        position=Position(
            column_no=1,
            line_no=1,
            char_index=0,
        ),
    )

    assert value == expected_value

# Generated at 2022-06-24 11:14:15.410657
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{"my_dict": "some_str", "other_key": ["a", "b", "c"], "nested": {"key": 1}}'
    result = tokenize_json(json_str)
    assert isinstance(result, DictToken)
    assert result.value == {
        "my_dict": "some_str",
        "other_key": ["a", "b", "c"],
        "nested": {"key": 1},
    }



# Generated at 2022-06-24 11:14:22.872643
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    content = "bla"
    value, errors = validate_json(content, field)
    assert value == "bla"
    assert not errors

    content = '"bla"'
    value, errors = validate_json(content, field)
    assert value == "bla"
    assert not errors

    content = '{"a":"b"}'
    value, errors = validate_json(content, field)
    assert value is None
    assert errors[0].code == "type_error"



# Generated at 2022-06-24 11:14:26.373086
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"name": "Juan", "age": "34"}'
    decoder = _TokenizingDecoder(content=content)
    token, end = decoder.scan_once(content, 0)
    assert token.value == {"name": "Juan", "age": "34"}, "Test failed!"


# Generated at 2022-06-24 11:14:28.728549
# Unit test for function validate_json
def test_validate_json():
    error_msg = validate_json("{}", str)
    assert(error_msg[1].messages[0].text == 'Expecting type str')
    return True

# Generated at 2022-06-24 11:14:29.856125
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="{}")


# Generated at 2022-06-24 11:14:39.664503
# Unit test for function validate_json
def test_validate_json():
    content = '{"test": [{"test": [1, 2, 3]}]}'
    validator = Schema.of({
        "test": List[Dict[{
            "test": List[int]
        }]]
    })
    assert validate_json(content, validator) == (
        {'test': [{'test': [1, 2, 3]}]},
        Message([], "Token validated successfully.", "success"),
    )
    try:
        validate_json(content, Schema.of({"test": int}))
    except ValidationError as e:
        assert (
            e.messages.text
            == "Expected type 'int' for field 'test', received type 'list'."
        )
    content = '{"test" : "value", "test2" : "value2"'

# Generated at 2022-06-24 11:14:44.369813
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"foo": "bar"}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert isinstance(list(token.value.keys())[0], ScalarToken)
    assert isinstance(list(token.value.values())[0], ScalarToken)


# Generated at 2022-06-24 11:14:45.374788
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context._TokenizingDecoder()


# Generated at 2022-06-24 11:14:53.619099
# Unit test for function validate_json
def test_validate_json():
    content = b'{"a": [1, 2, 3], "b": {"c": "abcd", "d": [{"e": "efgh"}]}}'
    schema = Schema({
        "a": [int],
        "b": {
            "c": str,
            "d": [{
                "e": str
            }]
        }
    })

    result = validate_json(content, schema)
    value, messages = result
    assert messages and len(messages) == 0


if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-24 11:14:58.447441
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        isinstance(tokenize_json('{"a": 3.2, "b": "hello", "c": [1, 2, 3]}'), dict)
    )
    with pytest.raises(ParseError):
        tokenize_json("howdy")


# Generated at 2022-06-24 11:15:09.984498
# Unit test for function validate_json
def test_validate_json():
    # pylint: disable=no-member
    #  Works when run directly, but package is not set up well for testing
    #  via import at the moment.
    from typesystem import fields

    def validate_with_custom_errors(
        token: Token, value: typing.Any, path: typing.Any
    ) -> typing.Any:
        """
        A function that can be passed to the validator to raise custom
        ValidationError instances with positions that are used in the resulting
        error dict.
        """
        raise ValidationError(
            [f"{path[-1]} contains the string 'foo'."],
            value=value,
            path=path,
            token=token,
        )

    class Post(Schema):
        title = fields.String()

# Generated at 2022-06-24 11:15:16.528346
# Unit test for function validate_json
def test_validate_json():
    json_str = """
    {
        "id": "test",
        "description": "desc"
    }
    """

    jsonSchema = Schema(
        {
            "id": str,
            "description": str,
            "metadata": dict
        },
        partial=True
    )

    value, errors = validate_json(json_str, jsonSchema)
    assert type(value) is dict
    assert len(errors) == 0

# Unit tests for function tokenize_json

# Generated at 2022-06-24 11:15:18.339468
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content=1)
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-24 11:15:20.260805
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder("", content="")

# Generated at 2022-06-24 11:15:32.097523
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
        content='{"foo":42,"bar":false}', validator=Schema({
            "foo": Integer(),
            "bar": Boolean(),
        })) == ({'foo': 42, 'bar': False}, [])

    assert validate_json(
        content='{"bar":false}', validator=Schema({
            "foo": Integer(),
            "bar": Boolean(),
        })) == (
        {'bar': False}, [ValidationError('Missing required field.', code='required', position=Position(column_no=1, line_no=1, char_index=0), pointer='/foo')]
    )


# Generated at 2022-06-24 11:15:41.988459
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""
        {
            "foo": "bar",
            "baz": [1, 2, 3]
        }
    """) == {"foo": "bar", "baz": [1, 2, 3]}

    assert tokenize_json("""
        {
            "foo": "bar",
            "baz": [1, 2, 3]
        }
    """) == {"foo": "bar", "baz": [1, 2, 3]}

    # Test a schema that does not exist.
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("""
        {
            "foo": "bar",
            "baz": [1, 2, 3]
        }
        """)
    assert exc_info.value.code == "no_content"

# Generated at 2022-06-24 11:15:51.449907
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"hello": "world"}') == DictToken({ScalarToken('hello'): ScalarToken('world')}, 0, 21, '{"hello": "world"}')
    assert tokenize_json('{"id": 5}') == DictToken({ScalarToken('id'): ScalarToken(5)}, 0, 8, '{"id": 5}')
    assert tokenize_json('{"age": 25, "score": 0.7}') == DictToken({ScalarToken('age'): ScalarToken(25), ScalarToken('score'): ScalarToken(0.7)}, 0, 26, '{"age": 25, "score": 0.7}')

# Generated at 2022-06-24 11:16:03.515103
# Unit test for function validate_json
def test_validate_json():
    schema = Schema.from_fields(
        id=field.Int(),
        parent=field.Int(required=False),
        name=field.String(),
        children=field.Array(items=field.Int(required=False)),
    )
    valid_data = {
        "id": 5,
        "name": "parent",
        "children": [
            {"id": 6, "name": "first child", "children": [{"id": 8, "name": "grandchild"}]},
            {"id": 7, "name": "second child"},
        ],
    }


# Generated at 2022-06-24 11:16:07.876887
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import pytest
    from typesystem.tokenize.json_tokens import JSONDecodeError

    # test __init__()
    decoder = _TokenizingDecoder(content="content")
    assert decoder.parse_string == scanstring
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant == JSONDecoder.parse_constant
    assert decoder.strict == True
    assert decoder.memo == {}
    assert decoder.scan_once == _make_scanner(decoder, "content")

# Generated at 2022-06-24 11:16:09.091761
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder()



# Generated at 2022-06-24 11:16:18.783313
# Unit test for function validate_json
def test_validate_json():
    # Test empty string
    content = ""
    validator = Field(type="string")
    expected_value = None
    expected_error_messages = [Message(text="No content.", code="no_content", position=Position(column_no=1, line_no=1, char_index=0))]
    actual_value, actual_error_messages = validate_json(content, validator)
    assert actual_value == expected_value
    assert actual_error_messages == expected_error_messages

    # Test single string
    content = '"hello"'
    validator = Field(type="string")
    expected_value = "hello"
    expected_error_messages = []
    actual_value, actual_error_messages = validate_json(content, validator)
    assert actual_value == expected_value


# Generated at 2022-06-24 11:16:22.908403
# Unit test for function tokenize_json
def test_tokenize_json():
    json=r'{"a":1,"b":{},"c":{"d":4,"e":6},"f":[]}'
    token=tokenize_json(json)
    assert token.as_dict() == {"a":1,"b":{},"c":{"d":4,"e":6},"f":[]}



# Generated at 2022-06-24 11:16:32.118071
# Unit test for function validate_json
def test_validate_json():
    valid_string = """{
            "user": {
                "name": "John Doe",
                "is_superuser": true,
                "age": 30,
                "address": {
                    "street": "123 Fake St.",
                    "city": "Springfield",
                    "state": "IL"
                },
                "favorite_numbers": [1, 2, 3, 4, 5]
            }
        }"""


# Generated at 2022-06-24 11:16:38.802403
# Unit test for function tokenize_json
def test_tokenize_json():
  assert tokenize_json("[1, 2, 3]") == ListToken([ScalarToken(1, 0, 0, "[1, 2, 3]"), ScalarToken(2, 0, 3, "[1, 2, 3]"), ScalarToken(3, 0, 6, "[1, 2, 3]")], 0, 10, "[1, 2, 3]")

# Unit test function validate_json

# Generated at 2022-06-24 11:16:47.845475
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with open("test_json.txt", "r", encoding="utf-8") as f:
        content = f.read() 
    decode = _TokenizingDecoder(content=content)
    assert decode.scan_once("{}", 0) == (DictToken({}, 0, 1, content), 2)
    assert decode.scan_once("[]", 0) == (ListToken([], 0, 1, content), 2)
    assert decode.scan_once('"2"', 0) == (ScalarToken("2", 0, 3, content), 4)
    assert decode.scan_once("true", 0) == (ScalarToken(True, 0, 4, content), 5)
    assert decode.scan_once("false", 0) == (ScalarToken(False, 0, 5, content), 6)
    assert decode.scan

# Generated at 2022-06-24 11:16:55.761801
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:17:04.247874
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"id": "this is a string", "size": 2.43, "active": true, "labels": ["array", "of", "strings"]}'
    assert tokenize_json(content) == {'id': 'this is a string', 'size': 2.43, 'active': True, 'labels': ['array', 'of', 'strings']}
    assert tokenize_json(b'{"id": "this is a string", "size": 2.43, "active": true, "labels": ["array", "of", "strings"]}') == {'id': 'this is a string', 'size': 2.43, 'active': True, 'labels': ['array', 'of', 'strings']}
    assert tokenize_json('I am not a json string') == 'I am not a json string'
    assert tokenize

# Generated at 2022-06-24 11:17:07.172539
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.parse_int("10") == 10


# Generated at 2022-06-24 11:17:10.240699
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"hello":"world"}')
    assert token == DictToken({"hello": "world"}, 0, 16, '{"hello":"world"}')


# Generated at 2022-06-24 11:17:15.278564
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema
    from typesystem.fields import IntegerField

    try:
        validate_json("{}", IntegerField())
        assert False
    except ValidationError as e:
        assert len(e.error_messages) == 1
    try:
        validate_json("{}", Schema)
        assert False
    except ValidationError as e:
        assert len(e.error_messages) == 1



# Generated at 2022-06-24 11:17:18.121435
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": null, "b": [1, 2], "c": "d"}'
    decoder = _TokenizingDecoder(content=content)
    print(decoder)
    return decoder


# Generated at 2022-06-24 11:17:21.820473
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "test"}')
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 14
    assert token.data["name"].value == "test"


### Unit tests for JSON validation ###


# Generated at 2022-06-24 11:17:24.544391
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Set up test data
    content = '{"key": "value"}'
    decodedContent = _TokenizingDecoder(content=content)

    # Check value
    assert content == decodedContent._content


# Generated at 2022-06-24 11:17:34.553615
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a": 2}') == DictToken(
      {ScalarToken('a', 1, 2, '{"a": 2}'): ScalarToken(2, 5, 6, '{"a": 2}')},
      0,
      9,
      '{"a": 2}',
    )
    assert tokenize_json('{"a": 2}') == DictToken(
      {ScalarToken('a', 1, 2, '{"a": 2}'): ScalarToken(2, 5, 6, '{"a": 2}')},
      0,
      9,
      '{"a": 2}',
    )



# Generated at 2022-06-24 11:17:36.563249
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(content="a")


# Generated at 2022-06-24 11:17:38.172904
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import typesystem
    x = _TokenizingDecoder(content="")
    assert type(x) is _TokenizingDecoder

# Generated at 2022-06-24 11:17:44.556807
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a": "b"}'
    decoder = _TokenizingDecoder(content=content)
    token = decoder.decode(content)
    assert isinstance(token, DictToken)
    assert token.parse_position.line_no == 1
    assert token.parse_position.column_no == 1
    assert token.parse_position.char_index == 0
    assert token.access_position.line_no == 1
    assert token.access_position.column_no == 7
    assert token.access_position.char_index == 6
    assert isinstance(token.value, dict)
    assert isinstance(token.value['a'], ScalarToken)
    assert token.value['a'].value == 'b'
    assert token.value['a'].parse_position.column_no == 3
   

# Generated at 2022-06-24 11:17:47.834894
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Constructor of class _TokenizingDecoder
    actual = _TokenizingDecoder()
    assert actual != None


# Generated at 2022-06-24 11:17:51.611331
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    TokenizingDecoder = _TokenizingDecoder()
    assert isinstance(TokenizingDecoder, _TokenizingDecoder), \
        'TokenizingDecoder is not an instance of the class _TokenizingDecoder'

# Unit test scanner function

# Generated at 2022-06-24 11:17:55.916289
# Unit test for function validate_json
def test_validate_json():
    example_json = '{"name": "John", "age": 31}'  # Make JSON string
    schema = {  # Make Schema for JSON string
        'name': 'string',
        'age': 'integer'
    }
    value, error_messages = validate_json(example_json, schema)  # Use function validate_json
    assert value['name'] == 'John'  # Assert correct name
    assert value['age'] == 31  # Assert correct age
    assert error_messages == {}  # Assert no errors



# Generated at 2022-06-24 11:18:00.220728
# Unit test for function tokenize_json
def test_tokenize_json():
    expected_output = {
        "value": "a",
        "position": {"char_index": 0, "line_no": 1, "column_no": 1}
    }

    output = tokenize_json("\"a\"")

    assert output == expected_output

# Generated at 2022-06-24 11:18:10.209343
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import (
        Array,
        Boolean,
        DateTime,
        Float,
        Integer,
        Object,
        String,
    )

    # Common test schema
    class CommonSchema(Schema):
        a = String(max_length=3)
        b = Integer(minimum=2)

    # JSON String that should validate with the above schema
    json_string = '{"a": "abc", "b": 2}'
    value, errors = validate_json(json_string, validator=CommonSchema)
    assert errors == []

    # JSON String that should not validate with the above schema
    json_string = '{"a": "abcdef", "b": 2}'
    value, errors = validate_json(json_string, validator=CommonSchema)

# Generated at 2022-06-24 11:18:18.561171
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == {"type": "dict", "value": {}}
    assert tokenize_json("{\"foo\":\"bar\"}") == {
        "type": "dict",
        "value": {"foo": {"type": "scalar", "value": "bar"}},
    }
    assert tokenize_json("{\"foo\":{\"bar\":\"baz\"}}") == {
        "type": "dict",
        "value": {
            "foo": {
                "type": "dict",
                "value": {"bar": {"type": "scalar", "value": "baz"}},
            }
        },
    }
    # No content.
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"

# Generated at 2022-06-24 11:18:20.414357
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder(content="")
        assert False
    except TypeError:
        pass

# Generated at 2022-06-24 11:18:24.699590
# Unit test for function validate_json
def test_validate_json():
    print("\ntest_validate_json")
    j = '{"x": "hello"}'
    v = validate_json(j, Field(str))
    print(v)
    assert v[0] == {'x': 'hello'}

# Generated at 2022-06-24 11:18:32.926780
# Unit test for function validate_json
def test_validate_json():
    # Test for parse error
    content = b'{"test": 1\n, "test2": 2}'
    validator = {
        "test": int,
        "test2": int
    }
    # Parse error should be returned here
    value = validate_json(content, validator)
    assert value[0] == None
    assert value[1]
    assert value[1][0]
    assert value[1][0].position
    assert value[1][0].text == "Expecting ':' delimiter."
    assert value[1][0].code == "parse_error"

    # Test for validation error
    content = b'{"test": 1, "test2": 2}'
    validator = {
        "test": str,
        "test2": int
    }
    # Validation error should be returned

# Generated at 2022-06-24 11:18:42.392949
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json('"value"') == ScalarToken("value", 0, 6, '"value"')
    assert tokenize_json('{"key": "value"}') == DictToken(
        {
            ScalarToken("key", 1, 5, '"key"'): ScalarToken("value", 8, 14, '"value"')
        },
        0,
        16,
        '{"key": "value"}',
    )
    assert tokenize_json("[true, false]") == ListToken(
        [ScalarToken(True, 1, 4, "true"), ScalarToken(False, 7, 11, "false")],
        0,
        13,
        "[true, false]",
    )


# Generated at 2022-06-24 11:18:42.946886
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass

# Generated at 2022-06-24 11:18:45.106859
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name": "William", "address": "1420 Walnut St."}'
    validator = Schema(name = Field(type = "string"), address = Field(type = "string"))
    errors = validate_json(content, validator)[1]
    assert(len(errors) == 0)


# Generated at 2022-06-24 11:18:55.826840
# Unit test for function validate_json
def test_validate_json():
    # Error if there's no content
    with pytest.raises(ParseError) as excinfo:
        result = validate_json("", "")
    assert excinfo.value.text == "No content."
    assert excinfo.value.position.column_no == 1
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0

    # Parse errors get positional info
    with pytest.raises(ParseError) as excinfo:
        result = validate_json("[", "")
    assert excinfo.value.text == "Expecting value."
    assert excinfo.value.position.column_no == 0
    assert excinfo.value.position.line_no == 1
    assert excinfo.value.position.char_index == 0

    # Returns positional errors

# Generated at 2022-06-24 11:19:05.725027
# Unit test for function tokenize_json
def test_tokenize_json():
    # No content
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.code == "no_content"
    assert exc_info.value.line_no == 1
    assert exc_info.value.column_no == 1
    assert exc_info.value.char_index == 0

    # Trivial JSON object
    assert isinstance(tokenize_json('{}'), DictToken)

    # Parse errors
    with pytest.raises(ParseError) as exc_info:
        tokenize_json('{')
    assert exc_info.value.code == "parse_error"
    assert exc_info.value.line_no == 1
    assert exc_info.value.column_no == 1
    assert exc_info.value

# Generated at 2022-06-24 11:19:08.276349
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = '"Hello" : { "something" : "Something else" }'
    decoder = _TokenizingDecoder(content=test_content)
    return decoder

# Generated at 2022-06-24 11:19:16.242723
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_tokens = [
        None,
        [{"name": "test"}, 1],
        {"name": "test", "number": 1},
        {"name": "test"},
        [{"name": "test"}, 1],
        {"name": "test", "number": 1},
        {"name": "other_test"},
        [{"name": "other"}, 2],
        {"name": "other", "number": 2},
        {"name": "other_test"},
        [{"name": "other"}, 2],
        {"name": "other", "number": 2},
    ]


# Generated at 2022-06-24 11:19:19.276998
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _make_scanner("{}", '{}')
    for i in range(10):
        assert _make_scanner

# Generated at 2022-06-24 11:19:28.394917
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String as StringField
    from typesystem.schemas import Schema

    class BasicSchema(Schema):
        title = StringField(required=True)
        number = StringField()

    schema = BasicSchema()
    content = """{
    "title": "Foo",
    "number": "1234"
}"""
    errors = validate_json(content, schema)
    assert len(errors) == 0


# Unit cases for validate_json
# 1. valid content
# 2. everything's required
# 3. zero key value pairs
# 4. only one required key value pair
# 5. unrecognized fields in message
# 6. empty lines
# 7. empty message with leading space
# 8. empty message with trailing space
# 9. empty message with leading and trailing space
# 10. empty message with leading

# Generated at 2022-06-24 11:19:31.232790
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo": 1}') == {'foo': 1}


# Generated at 2022-06-24 11:19:40.350382
# Unit test for function tokenize_json
def test_tokenize_json():
    token_to_string = lambda token: token.value
    assert token_to_string(tokenize_json("null")) is None
    assert token_to_string(tokenize_json("true")) is True
    assert token_to_string(tokenize_json("false")) is False
    assert token_to_string(tokenize_json("123")) == 123
    assert token_to_string(tokenize_json("1.23")) == 1.23
    str_token = tokenize_json("\"foo\"")
    assert isinstance(str_token, ScalarToken)
    assert str_token.value == "foo"
    assert token_to_string(tokenize_json("[]")) == []
    assert token_to_string(tokenize_json("[1,2]")) == [1, 2]
    assert token_to_

# Generated at 2022-06-24 11:19:41.196089
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder()


# Generated at 2022-06-24 11:19:51.853289
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.examples.json_schema import JSONSchema
    json_str = '{ "foo": "hello", "bar": 2.4 }'
    token = tokenize_json(json_str)
    schema = JSONSchema("{}")
    validator = schema.validator()
    validate_with_positions(token, validator)
    json_str = '{ "foo": "hello", "bar": "2.4" }'
    token = tokenize_json(json_str)
    schema = JSONSchema("{}")
    validator = schema.validator()

# Generated at 2022-06-24 11:19:54.868815
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    dcdr = _TokenizingDecoder(object_hook=lambda x: x, parse_int=lambda x: int(x))
    assert dcdr.parse_float == float
    assert dcdr.parse_string == scanstring



# Generated at 2022-06-24 11:20:04.734889
# Unit test for function tokenize_json
def test_tokenize_json():
    # Valid input
    assert isinstance(tokenize_json('{"a":"b"}'), DictToken)
    assert isinstance(tokenize_json('["a",1]'), ListToken)
    assert isinstance(tokenize_json('"a"'), ScalarToken)
    assert tokenize_json('"a"').value == "a"
    assert tokenize_json('1').value == 1
    assert tokenize_json('1.0').value == 1.0
    assert tokenize_json('true').value == True
    assert tokenize_json('false').value == False
    assert tokenize_json('null').value == None

    # Error for invalid input
    with pytest.raises(ParseError):
        tokenize_json('{"a"=>"b"}')


# Generated at 2022-06-24 11:20:14.572781
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_data = {
        "text": "this is a test"
    }
    json_string = json.dumps(json_data)
    decoder = _TokenizingDecoder(content=json_string)
    assert decoder.object_hook == json.JSONDecoder.object_hook
    assert decoder.object_pairs_hook == json.JSONDecoder.object_pairs_hook
    assert decoder.parse_float == json.JSONDecoder.parse_float
    assert decoder.parse_int == json.JSONDecoder.parse_int
    assert decoder.parse_constant == json.JSONDecoder.parse_constant
    assert decoder.strict == json.JSONDecoder.strict
    assert decoder.memo == {}


# Generated at 2022-06-24 11:20:16.411801
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert True
    # json_content = '{"foo": 1234}'
    # decoder = _TokenizingDecoder(content=json_content)
    # assert decoder

# Generated at 2022-06-24 11:20:27.256403
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''{
        "first": "A string",
        "second": 23,
        "third": [
            null,
            true,
            false
        ]
    }'''


# Generated at 2022-06-24 11:20:31.824987
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="{}")
    assert type(decoder) == _TokenizingDecoder
    assert type(decoder.parse_string) == classmethod
    assert type(decoder.parse_float) == float
    assert type(decoder.parse_int) == int
    assert type(decoder.strict) == bool
    assert type(decoder.scan_once) == function


# Generated at 2022-06-24 11:20:37.420790
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "{\"test\":\"testing\"}"
    test_decoder = _TokenizingDecoder(content=test_content)
    test_scanner = test_decoder.scan_once
    test_scanner_output = _scan_once(test_content, 0)
    assert test_scanner_output == test_scanner(test_content, 0)



# Generated at 2022-06-24 11:20:45.357576
# Unit test for function tokenize_json
def test_tokenize_json():
    expected_dict_token = DictToken(
        {
            ScalarToken("name", 1, 4, '{"name": "value"}'): ScalarToken(
                "value", 10, 16, '{"name": "value"}'
            )
        },
        0,
        17,
        '{"name": "value"}',
    )
    assert tokenize_json('{"name": "value"}') == expected_dict_token

    expected_list_token = ListToken(
        [ScalarToken(1, 2, 2, "[1, 2, 3]"), ScalarToken(2, 6, 6, "[1, 2, 3]")],
        0,
        8,
        "[1, 2, 3]",
    )
    assert tokenize_json("[1, 2, 3]") == expected_list_token