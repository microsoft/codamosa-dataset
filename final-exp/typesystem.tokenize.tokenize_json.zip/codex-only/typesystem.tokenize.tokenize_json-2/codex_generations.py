

# Generated at 2022-06-24 11:10:45.425886
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("content", "strict", "parse_float", "parse_int")
    assert decoder.parse_float == "parse_float"
    assert decoder.parse_int == "parse_int"
    assert decoder.strict == "strict"

# Generated at 2022-06-24 11:10:49.328688
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.data == {"key": "value"}



# Generated at 2022-06-24 11:10:51.071188
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="")

# Unit tests for method _TokenizingJSONObject

# Generated at 2022-06-24 11:10:56.311167
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Integer
    from typesystem.schemas import Schema

    class ObjectSchema(Schema):
        name = String()
        age = Integer()

    string_content = '{"name":"John Doe",  "age": "this isn\'t a number"}'

    value, error_messages = (
        validate_json(string_content, validator=ObjectSchema)
    )
    assert error_messages[0] == (
        'Value at line 1, column 37 is not of type "integer".',
        {'column_no': 37, 'char_index': 36, 'line_no': 1},
    )



# Generated at 2022-06-24 11:11:04.966891
# Unit test for function tokenize_json
def test_tokenize_json():
    input_content = '{"key1":1, "key2":2}'
    expected_output = [
        DictToken(
            {
                "key1": ScalarToken(1, 10, 11, '{"key1":1, "key2":2}'),
                "key2": ScalarToken(2, 19, 20, '{"key1":1, "key2":2}'),
            },
            0,
            21,
            '{"key1":1, "key2":2}',
        )
    ]
    output = tokenize_json(input_content)
    assert output == expected_output



# Generated at 2022-06-24 11:11:09.015602
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="abc")
    assert decoder.scan_once("abc", 0) == (ScalarToken(value="abc", start=0, end=2, content="abc"), 3)
    assert decoder.scan_once("abc", 0) == (ScalarToken(value="abc", start=0, end=2, content="abc"), 3)


# Unit tests for the _TokenizingJSONObject function

# Generated at 2022-06-24 11:11:16.769997
# Unit test for function validate_json
def test_validate_json():
    validator = Field(field_type="string")
    value, errors = validate_json('"John"', validator)
    assert value == "John"
    assert errors == []

    value, errors = validate_json('{"nested": {"value": "John"}}', validator)
    assert value == {"nested": {"value": "John"}}
    assert errors == []

    value, errors = validate_json('"John"123', validator)
    assert value == None
    assert errors == [ValidationError(
        message=Message(
            code="type_mismatch",
            text="Must be a valid string.",
            position=Position(column_no=7, line_no=1, char_index=6),
        )
    )]

    value, errors = validate_json('{}', validator)

# Generated at 2022-06-24 11:11:27.418837
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": 1}') == DictToken({"a": 1}, 0, 7, b'{"a": 1}')
    assert tokenize_json(b'false') == ScalarToken(False, 0, 4, b'false')
    assert tokenize_json(b'1.0') == ScalarToken(1.0, 0, 2, b'1.0')
    assert tokenize_json(b'[]') == ListToken([], 0, 1, b'[]')
    assert tokenize_json(b'[{"a": 1}]') == ListToken([DictToken({"a": 1}, 1, 8, b'[{"a": 1}]')], 0, 9, b'[{"a": 1}]')

# Generated at 2022-06-24 11:11:37.446116
# Unit test for function validate_json
def test_validate_json():
    import pdb
    # pdb.set_trace()
#     validator = Field(default="foo")
#     value, errors = validate_json('""', validator)
#     assert value == "foo"
#     assert not errors

#     validator = Field(required=True)
#     value, errors = validate_json('""', validator)
#     assert value is None
#     assert [err.text for err in errors] == ["This value is required."]

#     validator = Field(type="string", min_length=5, max_length=10)
#     value, errors = validate_json('"hello"', validator)
#     assert value == "hello"
#     assert not errors

#     validator = Field(type="string", min_length=5, max_length=10)
#

# Generated at 2022-06-24 11:11:43.148033
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, validators

    schema = String(
        description="string",
        validators=[validators.MaxLengthValidator(20), validators.RegexValidator("[a-zA-Z]+")]
    )
    result = validate_json('"This is a string"', schema)
    assert result == ('This is a string', None)

    result = validate_json('"This is a very long string"', schema)

# Generated at 2022-06-24 11:11:45.640125
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content = "hello world")
    assert decoder.scan_once == _make_scanner(decoder, "hello world")


# Generated at 2022-06-24 11:11:53.945942
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import Schema
    from typesystem.fields import Integer, Object, String

    class TestSchema(Schema):
        name = String()
        description = String()
        number = Integer()

    """
    Test Empty content
    """
    try:
        print("Test Empty content")
        validate_json("", validator=TestSchema)
    except ParseError as exc:
        print("Basic parse error", exc.position, exc.text)

    """
    Test Basic parse error
    """
    try:
        print("Test Basic parse error")
        validate_json("{", validator=TestSchema)
    except ParseError as exc:
        print("Basic parse error", exc.position, exc.text)

    """
    Test Basic success
    """

# Generated at 2022-06-24 11:11:59.958581
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('"abc"') == ScalarToken("abc", 0, 4, '"abc"')
    assert tokenize_json("1") == ScalarToken(1, 0, 1, "1")
    assert tokenize_json("[1, 2]") == ListToken([1, 2], 0, 5, "[1, 2]")



# Generated at 2022-06-24 11:12:04.007532
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    test_content = "{\n\t\"test\": [\n\t\t1,\n\t\t2,\n\t\t3\n\t]\n}"
    decoder = _TokenizingDecoder(content=test_content)
    assert(decoder.content == test_content)


# Generated at 2022-06-24 11:12:06.242749
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder([], content='"test"') == _TokenizingDecoder([], content='"test"')


# Generated at 2022-06-24 11:12:12.500649
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    scan_once = _make_scanner(
        {
            "parse_array": JSONDecoder().parse_array,
            "parse_float": JSONDecoder().parse_float,
            "parse_int": JSONDecoder().parse_int,
            "parse_string": JSONDecoder().parse_string,
            "strict": True,
            "memo": {},
        },
        "",
    )
    decoder = _TokenizingDecoder(content="")
    assert(scan_once == decoder.scan_once)


# Generated at 2022-06-24 11:12:20.063256
# Unit test for function validate_json
def test_validate_json():
    content = b'{"foo": "bar"}'
    validator = Field(type="string", required=True)

    assert validate_json(content, validator) == ({"foo": "bar"}, [])
    content = b'{"foo": {"bar": "baz"}}'

    result = [
        Message(
            text="Invalid type. Expected string but got object.",
            code="invalid",
            position=Position(column_no=16, line_no=1, char_index=15),
        )
    ]
    assert validate_json(content, validator) == ({}, result)

# Generated at 2022-06-24 11:12:26.500737
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.composite import Dict

    field = Dict({"foo": Dict({"bar": Dict({"baz": Dict({"a": int})})})})
    content = '{"foo": {"bar": {"baz": {"a": 5}}}}'
    parsed = tokenize_json(content)
    assert isinstance(parsed, dict)
    assert isinstance(parsed["foo"]["bar"]["baz"]["a"], int)



# Generated at 2022-06-24 11:12:34.932193
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("  null  ") == ScalarToken(None, 2, 7, "  null  ")
    assert tokenize_json("  null") == ScalarToken(None, 2, 6, "  null")
    assert tokenize_json("null  ") == ScalarToken(None, 0, 4, "null  ")
    assert tokenize_json("null") == ScalarToken(None, 0, 4, "null")

    assert tokenize_json("  true  ") == ScalarToken(True, 2, 8, "  true  ")
    assert tokenize_json("  true") == ScalarToken(True, 2, 7, "  true")
    assert tokenize_json("true  ") == ScalarToken(True, 0, 5, "true  ")

# Generated at 2022-06-24 11:12:39.800986
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test with empty string
    assert _TokenizingDecoder(content="").scan_once == _TokenizingJSONObject
    assert _make_scanner(_TokenizingDecoder(content=""),"") == _scan_once
    # Test with string with quotes
    assert _TokenizingDecoder(content='"').scan_once == _TokenizingJSONObject
    assert _make_scanner(_TokenizingDecoder(content='"'),"") == _scan_once
    # Test with string with curly braces
    assert _TokenizingDecoder(content="{").scan_once == _TokenizingJSONObject
    assert _make_scanner(_TokenizingDecoder(content="{"),"") == _scan_once
    # Test with string with brackets
    assert _TokenizingDecoder(content="[").scan_once == _TokenizingJSONObject
    assert _make_scanner

# Generated at 2022-06-24 11:12:47.299580
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == ScalarToken(None, 0, -1, "")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_json("4.2") == ScalarToken(4.2, 0, 3, "4.2")
    assert tokenize_json("-42") == ScalarToken(-42, 0, 2, "-42")

# Generated at 2022-06-24 11:12:56.792681
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("") == {}
    assert tokenize_json("{}") == {}
    assert tokenize_json('{"foo": "bar"}') == {"foo": "bar"}

    with pytest.raises(ParseError):
        tokenize_json("{")

    with pytest.raises(ParseError):
        tokenize_json("}")

    with pytest.raises(ParseError):
        tokenize_json("{")

    assert tokenize_json('{"foo": {"bar": [1, 2, "3"]}}') == {
        "foo": {"bar": [1, 2, "3"]}
    }

    with pytest.raises(ParseError):
        tokenize_json('{"foo": {"bar": [1, 2, "3"]')


# Generated at 2022-06-24 11:13:06.693879
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"test": 1}', {"test": int}) == ({'test': 1}, [])
    assert validate_json('{"test": 1, "test_2": 2}', [{"test": int}, "test_2"]) == ({'test': 1, 'test_2': 2}, [])
    assert validate_json('{"test": 1, "test_2": 2}', {"test": int, "test_2": int}) == ({'test': 1, 'test_2': 2}, [])
    assert validate_json('{"test": 1, "test_2": 2}', {"test": int}) == ({'test': 1}, [])

# Generated at 2022-06-24 11:13:11.111813
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "Ed"}'
    validator = fields.Object({
        'name': fields.String(),
    })
    result = validate_json(content, validator)
    assert result == ({"name": 'Ed'}, None)

# Case for invalid input

# Generated at 2022-06-24 11:13:15.615854
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": [1, 2, {"b": {"c": 3}}, [4], 5]}')
    assert token.value == {'a': [1, 2, {'b': {'c': 3}}, [4], 5]}



# Generated at 2022-06-24 11:13:24.952013
# Unit test for function tokenize_json
def test_tokenize_json():
    d = tokenize_json('{"a": [1, 2, "3"], "b": {"c": true, "d": false}}')
    assert d.value == {"a": [1, 2, "3"], "b": {"c": True, "d": False}}
    assert d.start == 0
    assert d.end == 39
    # Test post-validation behavior
    assert d.is_valid == True
    assert d.value == {"a": [1, 2, "3"], "b": {"c": True, "d": False}}
    assert d.content == '{"a": [1, 2, "3"], "b": {"c": true, "d": false}}'
    assert str(d) == '{"a": [1, 2, "3"], "b": {"c": true, "d": false}}'
   

# Generated at 2022-06-24 11:13:34.178095
# Unit test for function validate_json
def test_validate_json():
    # A valid JSON string with nulls, unicode, lists, tuples, and dictionaries
    valid_content = (
        '{ "a": null, "b": "A unicode string: \u2018 \u2019", '
        '"c": [1,2,3,4], "d": (5,6,7,8), "e": {"a": "A", "b": "B"} }'
    )
    # An invalid JSON string
    invalid_content = (
        '{ "a": null, "b" => "A unicode string: \u2018 \u2019", '
        '"c": [1,2,3,4], "d": (5,6,7,8), "e": {"a": "A", "b": "B"} }'
    )
    # A JSON string with an optional field

# Generated at 2022-06-24 11:13:42.606274
# Unit test for function tokenize_json
def test_tokenize_json():
    # Use a regular JSON encoder to produce some test input data.
    import json

    # Simple, one level object and list
    obj1 = {
        "string": "value",
        "list": [1, 2, 3],
        "float": 3.3,
        "int": 1,
        "bool": False,
        "null": None,
    }
    json_obj1 = json.dumps(obj1)
    token_obj1 = tokenize_json(json_obj1)
    assert obj1 == token_obj1.data

    # Nested object and list

# Generated at 2022-06-24 11:13:55.413448
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test null value
    assert tokenize_json('{"test": null}') == {'test': None}
    # Test string value
    assert tokenize_json('{"test": "test"}') == {'test': 'test'}
    # Test list value
    assert tokenize_json('{"test": ["test", "test", 3]}') == {'test': ['test', 'test', 3]}
    # Test float value
    assert tokenize_json('{"test": 3.14}') == {'test': 3.14}
    # Test int value
    assert tokenize_json('{"test": 7}') == {'test': 7}
    # Test boolean value
    assert tokenize_json('{"test": true}') == {'test': True}
    # Test true 

# Generated at 2022-06-24 11:14:07.153839
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder("", content="")
    assert decoder.parse_float("5") == 5
    assert decoder.parse_int("5") == 5
    assert decoder.strict
    s, end = decoder.parse_string('"123"', 0, True)
    assert s == "123"
    assert end == 5
    s, end = decoder.parse_string('"123"', 0, False)
    assert s == "123"
    assert end == 5
    assert decoder.parse_array(("[123]", 1), lambda x: (123, 3)) == ([123], 4)
    token, end = decoder.parse_object(('{"a":123}', 1), True, lambda x: (123, 4), {}, "")

# Generated at 2022-06-24 11:14:19.197318
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ListToken
    from typesystem.tokenize.tokens import ScalarToken
    import json
    content1 = """{
        "foo": "bar",
        "numbers": [1, 2, 3, 4, 5],
        "obj": {"a": "b"}
    }"""
    content2 = """{"foo": "bar"}"""
    content3 = json.dumps({"foo": "bar"})
    value1 = {
        "foo": "bar",
        "numbers": [1, 2, 3, 4, 5],
        "obj": {"a": "b"},
    }
    value2 = {"foo": "bar"}
    value3 = {"foo": "bar"}

# Generated at 2022-06-24 11:14:22.232971
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"op": "add", "nodes": {"id": "123"}}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["op"].value == "add"
    assert token.value["nodes"].value["id"].value == "123"
    
    

# Generated at 2022-06-24 11:14:23.323853
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder()
    assert isinstance(d.parse_array, object)


# Generated at 2022-06-24 11:14:24.204180
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="").content == ""


# Generated at 2022-06-24 11:14:25.624092
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-24 11:14:31.626492
# Unit test for function tokenize_json
def test_tokenize_json():
    valid_json = "{\n    \"key1\":\"value1\",\n    \"key2\":\"value2\"\n}"
    result = tokenize_json(valid_json)
    assert isinstance(result, DictToken)
    assert len(result) == 2
    assert result["key1"].value == "value1"
    assert result["key2"].value == "value2"

    invalid_json = "{3:3}\n"
    with pytest.raises(ParseError):
        tokenize_json(invalid_json)



# Generated at 2022-06-24 11:14:40.857806
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"image":{"width":800,"height":600,"title":"View from 15th Floor","thumbnail":{"url":"http://www.example.com/image/481989943","height":125,"width":100},"ids":[116,943,234,38793]}}'
    token = tokenize_json(content)
    assert token.value == {'image': {'thumbnail': {'height': 125, 'width': 100, 'url': 'http://www.example.com/image/481989943'}, 'width': 800, 'title': 'View from 15th Floor', 'height': 600, 'ids': [116, 943, 234, 38793]}}

    content = '{ "name": "John Smith", "age": 43 }'
    token = tokenize_json(content)

# Generated at 2022-06-24 11:14:52.047869
# Unit test for function tokenize_json
def test_tokenize_json():
    """Unit test for function tokenize_json"""

    from os import path
    from typesystem import Schema, fields
    from typesystem.schemas import _get_schema_type

    # Define a schema based on https://vega.github.io/schema/vega-lite/v2.json
    # pattern is a string like '^(?!((scale|projection)\\.))[a-z][\\w]*$' which JSON
    # doesn't support, so only test the subset that it can handle :(
    schema_fields = {
        "description": {"type": "string"},
        "required": {"type": "boolean"},
        "type": {"enum": ["string", "boolean"]},
        "default": fields.Any(),
    }

# Generated at 2022-06-24 11:14:55.375757
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert isinstance(decoder, JSONDecoder)
    
    

# Generated at 2022-06-24 11:14:58.746666
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "a": 1,
        "b": "b"
    }
    """
    context = _TokenizingDecoder(content=content)
    token, _ = context.scan_once(content, 0)
    assert token._value == {
        "a": 1,
        "b": "b"
    }


# Generated at 2022-06-24 11:15:03.224945
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": 1, "b": 2}'
    validator = Schema({"a": int, "b": int})
    token = tokenize_json(content)
    result = validate_with_positions(token=token, validator=validator)
    assert result == ({'a': 1, 'b': 2}, [])

# Generated at 2022-06-24 11:15:14.387822
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '[["a", 1], [2,3], {"key": "value"}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert token.string_start == 0
    assert token.string_end == len(content)
    assert len(token.value) == 3
    assert isinstance(token.value[0], ListToken)
    assert isinstance(token.value[1], ListToken)
    assert isinstance(token.value[2], DictToken)
    # Test empty string
    content = ''
    try:
        tokenize_json(content)
    except ParseError as exc:
        assert exc.code == 'no_content'
        assert exc.text == 'No content.'
        assert exc.position.char_index == 0
    else:
        assert False

# Generated at 2022-06-24 11:15:18.915954
# Unit test for function validate_json
def test_validate_json():
    with open("tests/smokes.json") as fout:
        json_str = fout.read()
    _, errors = validate_json(json_str, "smoke")
    assert not errors
    _, errors = validate_json(json_str, "smoke_wrong")
    assert len(errors) == 1

# Generated at 2022-06-24 11:15:31.618614
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "[1,2]"

    expected = ListToken([
        ScalarToken(1, 1, 1, content),
        ScalarToken(2, 4, 4, content)
    ], 0, 5, content)

    assert tokenize_json(content) == expected

    content = """{ "a": [1, 2], "b": { "c": { "d": [3, 4] } } }"""


# Generated at 2022-06-24 11:15:40.112409
# Unit test for function validate_json
def test_validate_json():
    schema = Field(type=int)
    value, errors = validate_json("5", schema)
    assert value == 5
    assert not errors
    value, errors = validate_json("foo", schema)
    assert errors[0].code == "invalid_type"
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 1
    assert errors[0].position.char_index == 0
    value, errors = validate_json("{}", schema)
    assert errors[0].code == "invalid_type"
    value, errors = validate_json("1.5", schema)
    assert errors[0].code == "invalid_type"

# Generated at 2022-06-24 11:15:44.081565
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"title": "Hello, world!"}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once(content, 0)[0] == \
        {'title': 'Hello, world!'}



# Generated at 2022-06-24 11:15:53.018049
# Unit test for function validate_json
def test_validate_json():
    # case 1
    content = '{"key1":"I am a string", "key2": true, "key3": 3.1}'
    schema = Schema(
        definition={
            "key1": fields.String(max_length=5),  # I am a string has 14 char
            "key2": fields.Boolean(),
            "key3": fields.Number(minimum=0, maximum=100),
        }
    )
    value, errors = validate_json(content, schema)
    assert value == {
        "key1": "I am a string",
        "key2": True,
        "key3": 3.1,
    }

# Generated at 2022-06-24 11:15:59.628007
# Unit test for function tokenize_json
def test_tokenize_json():
    json_input = '''
{
    "a": [0, 1],
    "b": {
        "d": 2,
        "f": 3
    }
}
    '''
    tokenized = tokenize_json(json_input)
    assert tokenized.value == {"a": [0,1], "b": {"d": 2, "f": 3}}


# Generated at 2022-06-24 11:16:00.982988
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder('test')


# Generated at 2022-06-24 11:16:04.429965
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"name":"Anjay"}')
    assert(decoder.scan_once('{"name":"Anjay"}',0)[0].value == {"name":"Anjay"} )


# Generated at 2022-06-24 11:16:09.191432
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo":1}'
    token = tokenize_json(content)
    result = validate_with_positions(token=token, validator=Schema)
    assert isinstance(result, tuple) and len(result) == 2
    return result

# Test that validate_json raises correct errors

# Generated at 2022-06-24 11:16:18.957812
# Unit test for function validate_json
def test_validate_json():
    class Person(Schema):
        name = ScalarField(str)
        age = ScalarField(int)

    # Passing case
    content = '[{"name": "Leo", "age": 25}, {"name": "John", "age": 24}]'
    value, error_messages = validate_json(content, ListField(Person))
    assert error_messages == []
    assert value == [
        {"name": "Leo", "age": 25},
        {"name": "John", "age": 24},
    ]

    # Failing case
    content = '[{"name": "Leo", "age": 25}, {"age": "John", "age": 24}]'
    value, error_messages = validate_json(content, ListField(Person))

# Generated at 2022-06-24 11:16:22.882934
# Unit test for function validate_json
def test_validate_json():
    class ColorSchema(Schema):
        name = 'ColorSchema'
        fields = [
            ('red', Integer()),
            ('green', Integer()),
            ('blue', Integer())
        ]

    # Valid content, verify that values are available.
    data = '{"red": 255, "green": 0, "blue": 0}'
    value, error_messages = validate_json(data, ColorSchema)
    assert isinstance(value, dict)
    assert value['red'] == 255
    assert value['green'] == 0
    assert value['blue'] == 0
    assert len(error_messages) == 0

    # Invalid content, should not be valid data.
    data = '{"red": "255", "green": true, "blue": "255"}'

# Generated at 2022-06-24 11:16:29.295305
# Unit test for function validate_json
def test_validate_json():
    content = b'{"k": "v"}'
    validator = Field(required=True, name="k", type="str")

    value, errors = validate_json(content, validator)
    print (value, errors)
    assert (value == {"k": "v"})
    assert (errors == [])

    content = b'{"k": 42}'
    value, errors = validate_json(content, validator)
    print (value, errors)
    assert (value == None)
    assert (len(errors) > 0)



# Generated at 2022-06-24 11:16:30.248485
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder(None, 'True')

# Generated at 2022-06-24 11:16:37.567375
# Unit test for function tokenize_json
def test_tokenize_json():
    content = {
        "foo": [
            100.0,
            {"bar": [1, 2]},
            [{"_id": "id-1", "name": "Foo One"}, {"_id": "id-2", "name": "Foo Two"}],
            {
                "bar": [
                    {"_id": "id-3", "name": "Bar One"},
                    {"_id": "id-4", "name": "Bar Two"},
                ]
            },
            "baz",
        ]
    }
    assert tokenize_json("{}") == {}

# Generated at 2022-06-24 11:16:44.279058
# Unit test for function validate_json
def test_validate_json():
    class PostSchema(Schema):
        title = Field(description="title of post", type="string")
        body = Field(description="body of post", type="string")
    validated_data, errors = validate_json(
        content=b'{"title":"My title", "body":"The body of my post"}', validator=PostSchema
    )
    assert errors == []
    assert validated_data == {"title": "My title", "body": "The body of my post"}


# Generated at 2022-06-24 11:16:47.870616
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert '__init__'
    
    

# Generated at 2022-06-24 11:16:59.651797
# Unit test for function validate_json
def test_validate_json():
    content = '{"a": 0.0, "b": 1.0, "c": 2.0}'
    validator = {
        "type": "dict",
        "properties": {
            "a": {"type": "float"},
            "b": {"type": "float"},
            "c": {"type": "float"},
        },
    }
    value, error_msgs = validate_json(content=content, validator=validator)
    assert value == {"a": 0.0, "b": 1.0, "c": 2.0}
    assert len(error_msgs) == 0

    validator = {"type": "dict", "properties": {}}
    value, error_msgs = validate_json(content=content, validator=validator)

# Generated at 2022-06-24 11:17:04.409715
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"a":{"b":"c"}}'
    decoder = _TokenizingDecoder(content=content)
    got = decoder.decode(content)
    expected = [
        b'{"a":{"b":"c"}}'
    ]
    assert got == expected, f"got: {got!r}, expected: {expected!r}"

# Generated at 2022-06-24 11:17:14.680322
# Unit test for function validate_json
def test_validate_json():
    array = [1, 'a', True, 5, 0.5, None]
    string = json.dumps(array)
    assert array == validate_json(string, List(items=Scalar()))[0]
    assert [] == validate_json(string, List(items=Scalar(min_length=100)))[1]
    assert [] == validate_json(string, List(items=Scalar(), min_items=100))[1]
    assert [] == validate_json(string, List(items=Scalar(), max_items=3))[1]
    assert [] == validate_json(string, List(items=Scalar(max_length=100)))[1]
    assert [] == validate_json(string, List(items=Scalar(), max_items=100))[1]
    assert [] == validate

# Generated at 2022-06-24 11:17:17.430143
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": 3, "bar": 4}'
    decoder = _TokenizingDecoder(content=content)
    assert content == decoder.content
    assert callable(decoder.scan_once)


# Generated at 2022-06-24 11:17:23.464279
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"answer": 42, "pi": 3.14, "is_domo_awake": true}'
    result = tokenize_json(content)
    assert result.to_dict() == {"answer": ScalarToken(42, 7, 11, content),
                                "pi": ScalarToken(3.14, 19, 25, content),
                                "is_domo_awake": ScalarToken(True, 31, 45, content)}



# Generated at 2022-06-24 11:17:25.424394
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder is not None

# Generated at 2022-06-24 11:17:36.108942
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    string = "{}"

    decoder = _TokenizingDecoder(content=string)

    token = decoder.decode(string)

    assert isinstance(token, DictToken) and token.value == {}

    string = "[]"

    decoder = _TokenizingDecoder(content=string)

    token = decoder.decode(string)

    assert isinstance(token, ListToken) and token.value == []

    string = '{"foo":"bar"}'

    decoder = _TokenizingDecoder(content=string)

    token = decoder.decode(string)

    assert isinstance(token, DictToken) and token.value == {'foo': 'bar'}

    string = '{"foo":"bar","baz":4}'

    decoder = _TokenizingDecoder(content=string)

    token = dec

# Generated at 2022-06-24 11:17:41.532740
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  # _TokenizingDecoder.__init__
  # assert isinstance(decoder, JSONDecoder),
  # assert (not hasattr(decoder, 'decode'))
  decoder = _TokenizingDecoder.__init__
  assert isinstance(decoder, JSONDecoder), "decoder is an instance of JSONDecoder"
  assert not hasattr(decoder, "decode"), "decoder has no attribute 'decode'"



# Generated at 2022-06-24 11:17:45.825772
# Unit test for function tokenize_json
def test_tokenize_json():
    # empty string case
    assert tokenize_json(content='') == {}

    # Non-empty string case
    assert tokenize_json(content='{"a": "b"}') == {"a": "b"}



# Generated at 2022-06-24 11:17:56.555732
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("1") == ScalarToken(1, 0, 0, "1")
    assert tokenize_json("12.00") == ScalarToken(12.00, 0, 5, "12.00")
    assert tokenize_json("12.1") == ScalarToken(12.1, 0, 4, "12.1")
    assert tokenize_json("12.1e2") == ScalarToken(1210.0, 0, 6, "12.1e2")
    assert tokenize_json("1.2/3") == ScalarToken(0.4, 0, 4, "1.2/3")
    assert tokenize_json("-1") == ScalarToken(-1, 0, 2, "-1")

# Generated at 2022-06-24 11:18:06.002526
# Unit test for function validate_json
def test_validate_json():
    content = b"""{
    "test": "A string"
    "test2": "Another String",
    "test3": {
        "test4": "This is a string too!"
    }
}"""
    validator = Field(
        sub_fields=[
            Field("test", type=str, required=True),
            Field("test2", type=str, required=True),
            Field("test3", type=Field(sub_fields=Field("test4", type=str, required=True)), required=True)
        ]
    )
    result, error_messages = validate_json(content, validator)

# Generated at 2022-06-24 11:18:15.952209
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '''
    {
        "foo": 1,
        "bar": 2.1,
        "baz": 3
    }
    '''
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {"foo": 1, "bar": 2.1, "baz": 3}
    inner_token = token.value["bar"]
    assert isinstance(inner_token, ScalarToken)
    assert inner_token.value == 2.1
    assert inner_token.start_pos.column_no == 10
    assert inner_token.start_pos.line_no == 3
    assert inner_token.end_pos.column_no == 13
    assert inner_token.end_pos.line_no == 3


# Generated at 2022-06-24 11:18:22.116695
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.strict
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_string == scanstring
    assert decoder.parse_array == JSONDecoder.scan_once
    assert decoder.scan_once



# Generated at 2022-06-24 11:18:31.969171
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo":"this is a test"}'
    validator = Schema({
        "foo": String(),
    })

    value, error_messages = validate_json(content, validator)
    assert(len(error_messages) == 0)
    assert(value == {"foo": "this is a test"})

    content = '{"foo":"this is a test"}'
    validator = Schema({
        "foo": String(max_length=4),
    })

    value, error_messages = validate_json(content, validator)
    assert(len(error_messages) == 1)
    assert(error_messages[0].code == "max_length")
    assert(error_messages[0].text == "Value is too long.")


# Generated at 2022-06-24 11:18:41.670100
# Unit test for function validate_json
def test_validate_json():
    s = '{"foo": "bar"}'
    v = Field(name="foo", type="string")
    result, messages = validate_json(s, v)
    assert result == {"foo": "bar"}
    assert not messages

    s = '{"foo": "bar"}'
    v = Field(name="foo", type="string", required=True)
    result, messages = validate_json(s, v)
    assert result == {"foo": "bar"}
    assert not messages

    s = '{"foo": "bar"}'
    v = Field(name="foo", type="string", required=True, default="baz")
    result, messages = validate_json(s, v)
    assert result == {"foo": "bar"}
    assert not messages

    s = '{"foo": "bar"}'

# Generated at 2022-06-24 11:18:43.057852
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"a": "b"}') == {
        "a": "b"
    }

# Generated at 2022-06-24 11:18:50.445844
# Unit test for function validate_json
def test_validate_json():
    #valid json
    json_string = '{"name":"mitesh","age":30,"city":"kochi"}'
    try:
        validate_json(json_string, Field(type="text"))
        print("valid json")
    except :
        print("invalid json")

    #invalid json
    json_string = '{"name":"mitesh","age":30,"city":"kochi"'
    try:
       validate_json(json_string, Field(type="text"))
       print("valid json")
    except :
       print("invalid json")

# Generated at 2022-06-24 11:19:01.489611
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    import functools
    import typesystem
    from typesystem.fields import String
    content = b'{"string": "value"}'
    decoder = _TokenizingDecoder(content=content)
    _dict = b'{"string": "value"}'
    assert hasattr(decoder, "scan_once")
    assert hasattr(decoder, "context")
    assert hasattr(decoder, "strict")
    assert hasattr(decoder, "scan_once")
    assert hasattr(decoder, "parse_array")
    assert hasattr(decoder, "parse_float")
    assert hasattr(decoder, "parse_int")
    assert hasattr(decoder, "parse_object")
    assert hasattr(decoder, "parse_string")

# Generated at 2022-06-24 11:19:11.490957
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, errors = validate_json(b'"test"', validator)
    assert value == "test"
    assert len(errors) == 0

    value, errors = validate_json(b'"test', validator)
    assert value is None
    assert len(errors) == 1

    value, errors = validate_json(b'', validator)
    assert value is None
    assert len(errors) == 1

    value, errors = validate_json(b'{"test":"test"}', validator)
    assert value is None
    assert len(errors) == 1

# Test code
if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-24 11:19:15.426161
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Just use the simplest case
    decoder = _TokenizingDecoder("content")
    assert decoder.scan_once
    assert isinstance(decoder.scan_once, typing.Callable)

# Verify that tokenize_json returns a token

# Generated at 2022-06-24 11:19:26.162192
# Unit test for function tokenize_json
def test_tokenize_json():
    import pytest

    content = "{\"a\": 1, \"b\": 2, \"c\": 3}"
    result = tokenize_json(content)

    assert isinstance(result, DictToken)
    assert result.start_position == Position(column_no=1, line_no=1, char_index=0)
    assert result.end_position == Position(column_no=19, line_no=1, char_index=18)
    assert result.value["a"] == ScalarToken(1, column_no=5, line_no=1, char_index=4)
    assert result.value["b"] == ScalarToken(2, column_no=11, line_no=1, char_index=10)

# Generated at 2022-06-24 11:19:35.800270
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test no content
    with pytest.raises(ParseError) as exc_info:
        tokenize_json("")
    assert exc_info.value.code == "no_content"
    assert exc_info.value.position.column_no == 1
    assert exc_info.value.position.line_no == 1
    assert exc_info.value.position.char_index == 0

    # Test the simple scalar cases
    assert tokenize_json("true") == ScalarToken(True, idx=0, end_idx=3, content="true")
    assert tokenize_json("false") == ScalarToken(False, idx=0, end_idx=4, content="false")

# Generated at 2022-06-24 11:19:39.997148
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "fred", "age": 43}'
    validator = Schema({"name": str, "age": int})
    token = tokenize_json(content)
    value, error_messages = validate_with_positions(token=token, validator=validator)
    assert value == {"name": "fred", "age": 43}
    assert error_messages == []

# Generated at 2022-06-24 11:19:43.787081
# Unit test for function tokenize_json
def test_tokenize_json():

    assert tokenize_json(b'{"test_key1":"test_value1, "test_key2":"test_value2"}') == {'test_key1': 'test_value1', 'test_key2':'test_value2'}
    assert tokenize_json('{"test_key1":"test_value1, "test_key2":"test_value2"}') == {'test_key1': 'test_value1', 'test_key2':'test_value2'}
    assert tokenize_json('{"test_key1":42, "test_key2":"test_value2"}') == {'test_key1': 42, 'test_key2':'test_value2'}

# Generated at 2022-06-24 11:19:46.151467
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="hello!")
    assert decoder.strict == True
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.scan_once != None



# Generated at 2022-06-24 11:19:47.090346
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="{}")

# Generated at 2022-06-24 11:19:48.344478
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    dec = _TokenizingDecoder(strict=True)
    assert dec.scan_once

# Generated at 2022-06-24 11:19:57.611413
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
    "first_name": "Joe",
    "last_name": "Williams",
    "dob": "01/01/2001",
    "address": {
        "address_1": "22 john street",
        "address_2": "",
        "city": "London",
        "country": "England"
    },
    "phones": [
        {
            "number": "0123456789",
            "type": "home"
        },
        {
            "number": "9876543210",
            "type": "work"
        }
    ]
}"""

    token = tokenize_json(content)

    assert token.get_value_by_path("first_name") == "Joe"

# Generated at 2022-06-24 11:19:59.966620
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder, "The unit test for _TokenizingDecoder is not implemented."


# Generated at 2022-06-24 11:20:10.843835
# Unit test for function validate_json
def test_validate_json():
    from .conftest import UserSchema, AddressSchema
    from typesystem import ValidationError

    # test for validator which does not contain `required` fields
    schema = UserSchema()
    value, errors = validate_json(b'{"age": 15}', schema)
    assert errors == []
    assert value == {"age": 15}

    # test for validator which contains `required` fields
    schema = AddressSchema()
    value, errors = validate_json(b'{"address": "123\n456"}', schema)
    assert errors == []
    assert value == {"address": "123\n456"}

    # test for incorrect type of validator
    with pytest.raises(TypeError):
        validate_json(b'{"address": "123\n456"}', 'AddressSchema')

    # test for parse error

# Generated at 2022-06-24 11:20:16.230465
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key":"value"}') == DictToken({'key': 'value'}, 0, 15, '{"key":"value"}')
    assert tokenize_json('{"key":[1,2,3]}') == DictToken({'key': [1,2,3]}, 0, 13, '{"key":[1,2,3]}')
    assert tokenize_json('{"key":1}') == DictToken({'key': 1}, 0, 7, '{"key":1}')


# Generated at 2022-06-24 11:20:25.184948
# Unit test for function validate_json
def test_validate_json():
    expected_messages = [
        Message(
            text="Extra data.",
            code="extra_data",
            position=Position(line_no=1, column_no=6, char_index=5),
        )
    ]

    expected_value = {"hello": "world"}
    test_s = '{"hello":"world", "foo": "bar"}'

    validator = Field(type="string", max_length=10)
    value, error_messages = validate_json(test_s, validator)
    assert value == expected_value
    assert error_messages == expected_messages

test_validate_json()

# Generated at 2022-06-24 11:20:29.339214
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    JSON_TEXT = '{"name":"apple", "color":"red"}'
    dict_token = _TokenizingDecoder(content=JSON_TEXT).decode(JSON_TEXT)
    assert isinstance(dict_token, DictToken)
    assert dict_token.value == {"name": "apple", "color": "red"}


# Generated at 2022-06-24 11:20:39.770080
# Unit test for function validate_json
def test_validate_json():
    '''Tests the function validate_json.
    '''
    from typesystem.schemas import Schema

    class MySchema(Schema):
        bool = "boolean"
        int = "integer"
        float = "number"
        string = "string"
        list = "array"
        dict = "object"
        nested = "object"
        nested.properties = {
            "a": "integer",
            "b": "number",
            "c": "string",
        }

    # Valid objects

# Generated at 2022-06-24 11:20:43.918931
# Unit test for function validate_json
def test_validate_json():
    msg = Message("error message")
    validator = Field(name="foo", type="string")
    v = validate_json("", validator)
    assert v[0] is None
    assert v[1][0] == msg
    v = validate_json("foo", validator)
    assert v[0] == "foo"
    assert v[1] == []