

# Generated at 2022-06-24 11:10:52.905487
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key-one": "value", "key_two": {"nested-key": [ "another value", "yet another value" ]} }'
    token = tokenize_json(content)
    assert token == {
        "key-one": "value",
        "key_two": {"nested-key": ["another value", "yet another value"]},
    }
    assert token.content == content

    assert (
        token["key_two"]["nested-key"].char_index
        == content.index("[")
        - 1
        - (content.index("{") + 1)
    )


# Generated at 2022-06-24 11:11:04.713975
# Unit test for function validate_json
def test_validate_json():
    # Parse and validate a JSON string, returning positionally marked error
    # messages on parse or validation failures.
    content = """
        {
            "name": "example.com",
            "description": "An example website.",
            "links": [
                {
                    "href": "https://example.com",
                    "rel": "home"
                },
                {
                    "href": "https://example.com/api",
                    "rel": "api"
                }
            ]
        }
        """
    class SiteSchema(Schema):
        name = Field(type=str, description="Name of the site")
        description = Field(
            type=str, description="Description of the site.", required=False
        )

# Generated at 2022-06-24 11:11:14.547366
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(
        "{}", Schema({"key": Field(str, required=True)})
    )[0] == ParseError(
        code="no_content",
        position=Position(column_no=1, line_no=1, char_index=0),
        text="No content.",
    )
    assert validate_json(
        "{}", Schema({"key": Field(str, required=True)})
    )[1] == [
        Message(
            "Value required for 'key' but it was not found.",
            code="required",
            position=Position(column_no=1, line_no=1, char_index=0),
        )
    ]

# Generated at 2022-06-24 11:11:26.595364
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("abc") == ScalarToken("abc", 0, 2, "abc")
    assert tokenize_json('"abc"') == ScalarToken("abc", 0, 5, '"abc"')
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"a": 1}') == DictToken(
        {"a": ScalarToken(1, 4, 5, '{"a": 1}')}, 0, 8, '{"a": 1}'
    )

# Generated at 2022-06-24 11:11:36.059784
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String
    from typesystem.parsers.json import validate_json
    from typesystem.schemas import Schema
    from typesystem.tokenize.positional_validation import PositionalValidationError

    class TestSchema(Schema):
        name = String(max_length=3)
        age = String(min_length=5)

    class TestSchema2(Schema):
        name = String(max_length=49)

    # Test Schema validate: min_length error
    content = """{
        "name": "Bob",
        "age": "1"
    }"""
    value, error_messages = validate_json(content, TestSchema)
    assert value == None

# Generated at 2022-06-24 11:11:45.036887
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"field": "value"}'
    token = tokenize_json(content)
    str(token)
    assert token.content == content
    assert token.is_dict
    assert token.token_type == "dict"
    assert token.position_start == 0
    assert token.position_end == 15
    assert token.children["field"].token_type == "scalar"
    assert token.children["field"].content == '"value"'
    assert token.children["field"].position_start == 8
    assert token.children["field"].position_end == 15
    assert token.children["field"].value == "value"


# Generated at 2022-06-24 11:11:48.013455
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("null", Field(type="string")) == ("", [{'message': "Expected type 'string', but got 'null'.", 'code': 'type', 'field': None, 'position': '1:1'}])

# Generated at 2022-06-24 11:11:55.608524
# Unit test for function validate_json
def test_validate_json():
    # Define a schema to validate the input data.
    # This is a somewhat limited subset of the JSON schema standard.
    class TestSchema(Schema):
        name = Field(type="string", min_length=2, max_length=20)
        age = Field(type="integer", min_value=0, max_value=120)  # Can't be negative.
        active = Field(type="boolean")
        comments = Field(type="string", required=False)

        def validate_name(self, name: str) -> bool:
            # We can't be named "admin".
            return name != "admin"

    with open('example.json', 'r') as json_file:
      content = json_file.read()
      print(content)

# Generated at 2022-06-24 11:12:05.200273
# Unit test for function tokenize_json
def test_tokenize_json():
    # Perform a simple tokenization test.
    content = '{"lat": 40.7128, "lon": 74.0060}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value["lat"].value == 40.7128
    assert token.value["lon"].value == 74.0060
    assert token.value["lat"].start == len(content)
    assert token.value["lon"].start == len(content)

    # Test a simple nested structure.
    content = '[{"lat": 40.7128, "lon": 74.0060}]'
    token = tokenize_json(content)
    assert isinstance(token, ListToken)
    assert isinstance(token.value[0], DictToken)

# Generated at 2022-06-24 11:12:06.559971
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    JSONDecoder.__init__()

# Generated at 2022-06-24 11:12:11.529275
# Unit test for function validate_json
def test_validate_json():
    import json
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    
    schema = Schema(
        foo=Integer(),
        bar=String(),
    )

    data = {"foo": "42", "bar": 42}
    json_data = json.dumps(data)
    value, messages = validate_json(json_data, schema)
    assert len(messages) == 2

    data = {"foo": 42, "bar": "42"}
    json_data = json.dumps(data)
    value, messages = validate_json(json_data, schema)
    assert len(messages) == 0

# Generated at 2022-06-24 11:12:17.446401
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b'"1"', Field(type="string", max_length=1)) == (
        "1",
        [
            Message(
                text="Length must be less than or equal to 1.",
                code="max_length",
                type="validation_error",
                position=Position(
                    column_no=1, line_no=1, char_index=1, absolute_index=1
                ),
            )
        ],
    )



# Generated at 2022-06-24 11:12:28.060430
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(properties={"name": String()})
    schema.validate_json(b'{"name": "foo"}') == {'name': 'foo'}

    # If the object is invalid, function will throw an exception
    exc = pytest.raises(ValidationError, schema.validate_json, b'{"name": 1}')
    assert exc.errors == [
        Message(text="Not a valid string.", code="type_error", position=Position(column_no=12, line_no=1, char_index=11))
    ]

    # If the property is missing, function will throw an exception
    exc = pytest.raises(ValidationError, schema.validate_json, b'{}')

# Generated at 2022-06-24 11:12:33.109775
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():

    # Arrange
    string = '{"a": 1, "b":2}'
    args = []
    kwargs = dict(content=string)
    expected_result = Token(value={'a': 1, 'b': 2}, start=0, end=10)

    # Act
    decoder = _TokenizingDecoder(*args, **kwargs)
    result = decoder.decode(string)

    # Assert
    assert result == expected_result


# Generated at 2022-06-24 11:12:36.312828
# Unit test for function validate_json
def test_validate_json():
    class MySchema(Schema):
        prop = int

    schema = MySchema()
    assert validate_json('{"prop": "10"}', schema) == (
        {'prop': 10},
        [ValidationError(
            value=10,
            field_name='prop',
            code='invalid',
            validator=int,
            position=Position(1, 1, 2, 3),
            value_type=int,
        )],
    )

# Generated at 2022-06-24 11:12:45.512070
# Unit test for function validate_json
def test_validate_json():
    content = '[1, 2]'
    token = tokenize_json(content)
    validator = [int]
    value, error_message = validate_json(content, validator)
    assert value == [1, 2]
    assert error_message == []

    content = '[1, "a"]'
    value, error_message = validate_json(content, validator)
    assert value == [1, "a"]
    assert len(error_message) == 1
    assert error_message[0].text == "Not a valid integer."

    content = '["a", "b"]'
    value, error_message = validate_json(content, validator)
    assert value == ["a", "b"]
    assert len(error_message) == 2
    assert error_message[0].text == "Not a valid integer."
   

# Generated at 2022-06-24 11:12:50.029006
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = MultiTypedField(str) #'foo': str
    value = validate_json(content, validator)['foo']
    assert value == 'bar'
    

# Generated at 2022-06-24 11:12:57.940831
# Unit test for function validate_json
def test_validate_json():
    # TODO: Using Unicode characters in below is causing Python 2.7 to fail.
    #       Fix that and use Unicode characters in the string.
    content = '{"a": "string", "b": ["1", "2", "3"], "c": {"d": "e"}}'
    validator = Schema(fields={"a": str, "b": list, "c": dict})
    value, error_messages = validate_json(content, validator)
    assert value == {'a': 'string', 'b': ['1', '2', '3'], 'c': {'d': 'e'}}
    assert not error_messages

    validator = Schema(fields=[{"a": str, "b": int}])
    value, error_messages = validate_json(content, validator)

# Generated at 2022-06-24 11:13:01.291718
# Unit test for function validate_json
def test_validate_json():
    json_data = '{"a":1,"b":2,"c":3}'
    assert validate_json(json_data, {}) == ({'a': 1, 'b': 2, 'c': 3}, [])


# Generated at 2022-06-24 11:13:04.264821
# Unit test for function validate_json
def test_validate_json():
    token = tokenize_json('{"name":"Loki"}')
    value, errors = validate_json(token=token, validator={"name": str})
    print(len(errors))



# Generated at 2022-06-24 11:13:15.041373
# Unit test for function tokenize_json
def test_tokenize_json():
    # Unit test for function tokenize_json
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizer import tokenize_json
    for case in (
        "['foo', {'bar': ['baz', null, True, 1.23, 2e10]}]",
        '["foo", {"bar": ["baz", null, true, 1.23, 2e10]}]',
        '["foo", {"bar": ["baz", null, true, 1.23, 2e10]}]',
        '["foo", {"bar": ["baz", null, true, 1.23, 2e10]}]',
    ):
        json = tokenize_json(case)

        assert isinstance(json, ListToken)

# Generated at 2022-06-24 11:13:17.003260
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(_TokenizingDecoder(content="content") is not None)


# Generated at 2022-06-24 11:13:17.765039
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _make_scanner(object(), "")

# Generated at 2022-06-24 11:13:26.109605
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem import types
    from typesystem.tokenize.tokens import ScalarToken, ListToken
    data = '["ciao", "come va"]'
    
    class MySchema(Schema):
        value = types.Array(of=String)
        
    value, msg = validate_json(data, MySchema)
    assert value == ['ciao', 'come va']
    assert not msg
    
    data = '["ciao", 3]'
    value, msg = validate_json(data, MySchema)
    assert value == ['ciao', 3]

# Generated at 2022-06-24 11:13:31.224254
# Unit test for function validate_json
def test_validate_json():
    valid_json = "{\"a\": 1}"
    result = validate_json(valid_json, Field(type="string", required=True))

    assert result[0] == {'a': 1}
    assert result[1] == []
    assert isinstance(result[1], list)

    invalid_json = "{\"a\": \"\"}"
    result = validate_json(invalid_json, Field(type="string", required=True))

    assert result[0] is None
    assert isinstance(result[1][0], ValidationError)
    assert isinstance(result[1], list)

    invalid_json = "{\"a\": \"\"}"
    result = validate_json(invalid_json, Field(type="string"))

    assert result[0] == {'a': ''}
    assert isinstance(result[1], list)

# Generated at 2022-06-24 11:13:42.021036
# Unit test for function tokenize_json
def test_tokenize_json():
    schema = Field(type_name="object")
    validator = schema.validator
    assert validator.validate(validate_json("{}", schema)[0])[0]
    assert validate_json("", schema)[1][0].text == "No content."

    schema = Field(type_name="integer")
    validator = schema.validator
    assert validator.validate(validate_json("1", schema)[0])[0]
    assert validate_json("a", schema)[1][0].text == "a is not a valid integer."

    schema = Field(type_name="number")
    validator = schema.validator
    assert validator.validate(validate_json("1", schema)[0])[0]

# Generated at 2022-06-24 11:13:47.166761
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder(content='{"a": 3.0}')
    assert tokenizing_decoder.scan_once('{"a": 3.0}',0)[0].value == {"a": 3.0}



# Generated at 2022-06-24 11:13:55.414655
# Unit test for function tokenize_json
def test_tokenize_json():
    assert str(tokenize_json('{}')) == "DictToken(items={}, start=0, end=1, source='{}')"
    assert str(tokenize_json('{ "a" : 1 }')) == "DictToken(items={ScalarToken(value='a', start=2, end=3, source='{ \"a\" : 1 }'): ScalarToken(value=1, start=6, end=7, source='{ \"a\" : 1 }')}, start=0, end=12, source='{ \"a\" : 1 }')"



# Generated at 2022-06-24 11:13:57.690296
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        decoder = _TokenizingDecoder(content="{}")
        assert decoder.scan_once is not None
    except TypeError:
        exit(-1)
    exit(0)



# Generated at 2022-06-24 11:14:04.928128
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"name": "john doe"}')
    assert isinstance(token, DictToken) == True
    assert isinstance(token.value, dict) == True
    assert token.value['name'] == 'john doe'

    token = tokenize_json('{"name": "john doe", "age": 32}')
    assert isinstance(token, DictToken) == True
    assert isinstance(token.value, dict) == True
    assert token.value['name'] == 'john doe'
    assert token.value['age'] == 32

    token = tokenize_json('["Name"]')
    assert isinstance(token, ListToken) == True
    assert isinstance(token.value, list) == True
    assert token.value[0] == 'Name'



# Generated at 2022-06-24 11:14:16.077691
# Unit test for function validate_json
def test_validate_json():
    assert validate_json(b"true", bool) == (True, [])

    validator = Schema.create_schema(
        type="object",
        properties={
            "a": {"type": "string"},
            "b": {"type": "number"},
            "c": {"type": "array", "items": {"type": "number"}},
        },
    )

    # Valid
    result = validate_json(
        """{
            "a": "hello",
            "b": 1,
            "c": [2, 3]
        }""",
        validator,
    )
    assert result == (
        {"a": "hello", "b": 1, "c": [2, 3]},
        [],
    )

    # Invalid

# Generated at 2022-06-24 11:14:19.414234
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder('content')
    assert decoder.context.memo == {}
    assert decoder.context.object_pairs_hook is not None


# Generated at 2022-06-24 11:14:23.992371
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"b": [1, 2, 3], "a": function () { for (var i = 0; i < 1; i++) { console.log(i) }}, "c": {"a": 1, "b": 2}}'
    instance = _TokenizingDecoder(content=content)
    assert isinstance(instance, _TokenizingDecoder)



# Generated at 2022-06-24 11:14:33.885019
# Unit test for function tokenize_json
def test_tokenize_json():
    test_1 = '{"a": 1, "b": "c"}'
    test_2 = '[1, 2, 3]'
    test_3 = 'null'
    test_4 = '"abcd"'
    test_5 = '{"a": 1, "b": "c"}'  # No space after colon
    test_6 = '{"a": 1}'  # No space after colon
    test_7 = '{"a": 1, }'  # Space after comma
    test_8 = '[1, 2, 3 ]'
    test_9 = '[1, 2, 3, ]'
    test_10 = '{ null: 1 }'
    test_11 = '{ null : 1 }'
    test_12 = '{ "a": 1, "b": 1, }'
    test_13 = '{ }'

# Generated at 2022-06-24 11:14:35.297505
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="test")



# Generated at 2022-06-24 11:14:38.123306
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder, type)
    assert hasattr(_TokenizingDecoder, '__init__')
    assert isinstance(_TokenizingDecoder.__init__, types.FunctionType)


# Generated at 2022-06-24 11:14:39.744934
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    string = '{"hey": 2}'
    _TokenizingDecoder(content=string).decode(string)

# Generated at 2022-06-24 11:14:51.107762
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    import inspect
    import re

    # check whether validate_json is a function
    assert inspect.isfunction(validate_json), "validate_json is not a function, but a {}.".format(
        type(validate_json))

    # check whether the return type is a tuple

# Generated at 2022-06-24 11:14:57.197010
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder()
    assert len(decoder.parse_string('"test"', 0, True)) == 2
    assert decoder.strict == 0
    assert len(decoder.parse_object(('{"test":"test"}', 1))) == 2
    assert len(decoder.parse_array(('["test"]', 1))) == 2
    assert len(decoder.parse_int('1')) == 2
    assert len(decoder.parse_float('1.1')) == 2
    assert len(decoder.scan_once('"test"')) == 2


# Generated at 2022-06-24 11:15:07.577446
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    assert validate_json(b'{"name": "Steve", "age": 35}', ExampleSchema) == (
        {"name": "Steve", "age": 35},
        [],
    )
    # Invalid JSON
    assert validate_json(b'{"name": "Steve", "age": 35, "favorite_color": "red"', ExampleSchema) == \
            ({"name": "Steve", "age": 35},
            [{"code": "unexpected_property",
              "message": "Unexpected property 'favorite_color'.",
              "path": "/favorite_color",
              "position": {"column_no": 33, "line_no": 1, "char_index": 32}}])

    # Invalid schema

# Generated at 2022-06-24 11:15:14.112411
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def _test(decoder):
        if decoder.parse_string == scanstring:
            decoder = _test(decoder.py_scanner)
        return decoder
    context = JSONDecoder()
    result = _test(_TokenizingDecoder(context=context))
    assert result.parse_string == _TokenizingJSONObject
    assert result.parse_int == int
    assert result.parse_float == float

# Generated at 2022-06-24 11:15:17.912332
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert hasattr(_TokenizingDecoder, '__init__')
    assert callable(_TokenizingDecoder.__init__)
    assert isinstance(_TokenizingDecoder.__init__, types.MethodType)


# Generated at 2022-06-24 11:15:26.613857
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, "{}")
    assert tokenize_json('"a"') == ScalarToken('a', 0, 2, '"a"')
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')
    assert tokenize_json('[1, 2]') == ListToken([1, 2], 0, 6, '[1, 2]')

    token = tokenize_json('{"a": 1, "b": 2}')
    assert token == DictToken({"a": 1, "b": 2}, 0, 16, '{"a": 1, "b": 2}')
    assert token["a"] == ScalarToken(1, 5, 6, '1')

# Generated at 2022-06-24 11:15:30.826009
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test variable initialization
    test_decoder = _TokenizingDecoder("test", True)
    assert test_decoder.parse_string("test", 1, True) == (JSONDecodeError("test", 1, 1), 1)



# Generated at 2022-06-24 11:15:35.717914
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "maria", "age": 31}\n'
    token = tokenize_json(content)
    assert token == DictToken({'name': ScalarToken("maria", 3, 8, content), 'age': ScalarToken(31, 18, 19, content)}, 1, 24, content)



# Generated at 2022-06-24 11:15:45.393574
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test tokenize_json function
    """
    result = tokenize_json("{}")
    assert isinstance(result, DictToken)
    assert len(result.value) == 0
    assert result.pos_start == 0
    assert result.pos_end == 1

    result = tokenize_json("[1, 2, [3, 4], 5]")
    assert isinstance(result, ListToken)
    assert len(result.value) == 4
    assert result.pos_start == 0
    assert result.pos_end == 20

    result = tokenize_json("[1, 2, [3, 4], 5]")
    assert isinstance(result, ListToken)



# Generated at 2022-06-24 11:15:53.963042
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from typesystem import String
    from typesystem.schemas import Schema

    schema = Schema(
        properties={"name": String(max_length=5, title="User name")},
    )
    # Test with valid content
    payload = b'{"name": "Luke"}'
    value, errors = validate_json(payload, schema)
    assert value == {"name": "Luke"}
    assert len(errors) == 0

    # Test with invalid content
    payload = b'{"name": "Luke Skywalker"}'
    value, errors = validate_json(payload, schema)
    assert value is None
    assert len(errors) == 1
    assert "Name is too long" in errors[0].text

    # Test with content not a JSON
    payload = b'{"name": "Luke'

# Generated at 2022-06-24 11:15:56.039528
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test_content")
    assert decoder.content == "test_content"

# Generated at 2022-06-24 11:16:00.117054
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"foo": [1, 2, 3]}"""
    toke = {"foo": [1, 2, 3]}
    assert tokenize_json(content) == toke


# Generated at 2022-06-24 11:16:02.738486
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": ["bar", "baz"]}'
    class MySchema(Schema):
        foo = Field(type="string", max_length=100, min_length=2)

    value, errors = validate_json(content, validator=MySchema)
    errors_texts = [error.text for error in errors]
    assert errors_texts == ["Expected string."]



# Generated at 2022-06-24 11:16:12.889751
# Unit test for function validate_json
def test_validate_json():
    from typesystem.types import String, Array

    class Person(Schema):
        name = String()
        friends = Array(items=String())

    validator = Person()
    token = tokenize_json('{"name":"John Doe","friends":["Jane"]}')
    value, errors = validate_with_positions(token=token, validator=validator)

    # Test valid case with no errors
    assert errors == []
    assert value == {'name': 'John Doe', 'friends': ['Jane']}

    # Test invalid case with errors
    token = tokenize_json('{"name":false,"friends":["Jane"]}')
    _, errors = validate_with_positions(token=token, validator=validator)
    assert len(errors) == 1
    assert errors[0].position.line_no == 1

# Generated at 2022-06-24 11:16:16.720773
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": 1}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    content = '["a", 1]'
    token = tokenize_json(content)
    assert type(token) == ListToken
    content = '{"a": "hello"}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    content = '[1]'
    token = tokenize_json(content)
    assert type(token) == ListToken
    content = '[1,2]'
    token = tokenize_json(content)
    assert type(token) == ListToken
    content = '[1,2,3]'
    token = tokenize_json(content)
    assert type(token) == ListToken

    # Test string, boolean, and nulls


# Generated at 2022-06-24 11:16:25.228116
# Unit test for function validate_json
def test_validate_json():
    import typesystem
    from itertools import chain
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken, Token
    from typesystem.schemas import Schema

    # Flatten an arbitrary token hierarchy.
    def flatten(root_token: Token) -> typing.Iterator[Token]:
        yield root_token
        if isinstance(root_token, (DictToken, ListToken)):
            # TODO: Support ordered dictionaries?
            for child_token in chain(*root_token.children.values()):
                yield from flatten(child_token)

    class Pet(Schema):
        name = typesystem.String(max_length=50)
        age = typesystem.Integer(minimum=0, maximum=30)

    class Person(Schema):
        name = typesystem.String

# Generated at 2022-06-24 11:16:29.810437
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields={"foo": {"type": "string"}})
    validator = schema.as_field()
    value, errors = validate_json(b'{"foo": "bar"}', validator)
    assert len(errors) == 0
    value, errors = validate_json(b'{"foo": 1}', validator)
    assert len(errors) == 1

# Generated at 2022-06-24 11:16:37.284883
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Test the json decoder so we know it works
    """

# Generated at 2022-06-24 11:16:46.947616
# Unit test for function tokenize_json
def test_tokenize_json():
    inp = '{"message": "hi", "number": 10, "array": [1, 2, 3], "another_array": [{"key": "val"}]}'
    out = '''DictToken(
    {"message": "hi", "number": 10, "array": [1, 2, 3], "another_array": [{"key": "val"}]},
    0,
    76,
    "{"message": "hi", "number": 10, "array": [1, 2, 3], "another_array": [{"key": "val"}]}",
)'''
    assert repr(tokenize_json(inp)) == out
    inp = '''[{ "key": "val" }]'''

# Generated at 2022-06-24 11:16:55.383551
# Unit test for function validate_json
def test_validate_json():
    # Example adapted from https://github.com/jaytaylor/python-typesystem
    class Author(Schema):
        name = Field(type="string")
        email = Field(type="string")

    class Post(Schema):
        title = Field(type="string")
        rating = Field(type="integer")
        content = Field(type="string")
        published = Field(type="boolean")
        author = Field(type="object", sub_schema=Field(type="object", sub_schema=Author))


# Generated at 2022-06-24 11:16:57.266026
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    with pytest.raises(JSONDecodeError):
        _TokenizingDecoder("{'a': 'b'}", content="")

# Generated at 2022-06-24 11:17:00.593387
# Unit test for function validate_json
def test_validate_json():
    content = '{"x":"hello"}'
    validator = Schema({"x": String()})

    value, error_messages = validate_json(content, validator)
    assert value == {"x": "hello"}
    assert error_messages == []

# Generated at 2022-06-24 11:17:03.762398
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class A:
        def __init__(self, *args, **kwargs):
            print(args)
            print(kwargs)
            super().__init__(*args, **kwargs)

    a = A(object_hook=1, parse_float=lambda x: 2)
    print(a)

test__TokenizingDecoder()

# Generated at 2022-06-24 11:17:08.159246
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "hello", "b": "world"}'
    token = tokenize_json(content)
    assert token.type == 'dict'
    assert token.value == {'a': 'hello', 'b': 'world'}



# Generated at 2022-06-24 11:17:13.171183
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test with two level nested objects
    content = '{"obj1":{"key1":10,"key2":20},"obj2":{"key3":30,"key4":40}}'
    token = tokenize_json(content)
    assert token.children[0].value == 10
    assert token.children[1].children[0].value == 30

    # Test with arrays nested within objects
    content = '{"obj1":["list1",["list2",10],"list3"],"obj2":{"key1":100}}'
    token = tokenize_json(content)
    assert token.children[0].children[1].children[0].value == 10
    assert token.children[1].children[0].value == 100

    # Test with an empty string
    content = ''

# Generated at 2022-06-24 11:17:20.560012
# Unit test for function validate_json
def test_validate_json():
    # Valid string
    schema = {'number': {'type': 'number'}}
    validator1 = Schema(schema)
    str1 = '{"number": 3.14}'
    value1, errors1 = validate_json(str1, validator1)
    assert value1['number'] == 3.14
    assert errors1 == []
    # Invalid string
    str2 = '{"number": "x"}'
    value2, errors2 = validate_json(str2, validator1)
    assert value2['number'] is None
    assert errors2[0].code == 'not_a_number'
    assert errors2[0].line_no == 1
    assert errors2[0].column_no == 15
    # Empty string
    str3 = ''

# Generated at 2022-06-24 11:17:21.568115
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(type(_TokenizingDecoder().scan_once('{}', 0)) == tuple)


# Generated at 2022-06-24 11:17:32.562816
# Unit test for function validate_json
def test_validate_json():
    # test for a json that does not validate
    content = '{"foo": "bar"}'
    validator = Field(type="integer")
    value, error_messages = validate_json(content=content, validator=validator)
    assert(len(error_messages) == 1)
    assert(error_messages[0].code == "invalid_type")
    assert(error_messages[0].text == 'Expected {"foo": "bar"} to be an integer.')

    # test for a json that validates
    content = '2'
    validator = Field(type="integer")
    value, error_messages = validate_json(content=content, validator=validator)
    assert(len(error_messages) == 0)

    # test empty string case

# Generated at 2022-06-24 11:17:41.865655
# Unit test for function validate_json
def test_validate_json():
    from typesystem import String, Schema
    from typesystem.fields import Array

    class CastSchema(Schema):
        cast_list = Array(String())

    json_content = """
        {"cast_list": ["Bree", "Erika", "James", "Omar", "Thomas"]}
    """.strip()

    value, error_messages = validate_json(content=json_content,
                                          validator=CastSchema)
    assert isinstance(value, dict)
    assert value == {"cast_list": ["Bree", "Erika", "James", "Omar", "Thomas"]}
    assert len(error_messages) == 0

    json_content = """
        {"cast_list": ["Bree", "Erika", "James", "Omar", "Thomas", {}]}
    """.strip()



# Generated at 2022-06-24 11:17:43.593331
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder("content"), JSONDecoder)

# Generated at 2022-06-24 11:17:54.167751
# Unit test for function tokenize_json
def test_tokenize_json():
    string = '{"name": "Bob", "age": 10}'
    token = tokenize_json(string)

    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == 18

    assert isinstance(token.value["age"], ScalarToken)
    assert token.value["age"].start == 15
    assert token.value["age"].end == 18
    assert token.value["age"].value == 10

    assert isinstance(token.value["name"], ScalarToken)
    assert token.value["name"].start == 7
    assert token.value["name"].end == 13
    assert token.value["name"].value == "Bob"



# Generated at 2022-06-24 11:18:03.494210
# Unit test for function validate_json
def test_validate_json():
    from typesystem.string_types import String
    try:
        validate_json('{"name": "name", "email": "email@example.com"}', String())
    except ValidationError as exc:
        assert exc.messages[0] == 'Value "{u\'name\': u\'name\', u\'email\': u\'email@example.com\'}" is not a valid string.'
    try:
        validate_json('{}', String())
    except ValidationError as exc:
        assert exc.messages[0] == 'Value "{}" is not a valid string.'

# Generated at 2022-06-24 11:18:06.720070
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    s = '{"hello": 1, "world": 2}'
    new_decoder = _TokenizingDecoder(content=s)
    assert new_decoder is not None


# Generated at 2022-06-24 11:18:16.435342
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert set(_TokenizingDecoder.__dict__) == set(['scan_once', '__init__'])
    assert set(_TokenizingDecoder.__init__.__dict__) == set(['__code__', '__name__', '__qualname__'])
    assert _TokenizingDecoder.__init__.__code__.co_varnames == ('self', '*args', '**kwargs')
    assert set(_TokenizingDecoder.scan_once.__dict__) == set(['__code__', '__name__', '__qualname__'])
    assert _TokenizingDecoder.scan_once.__code__.co_varnames == ('string', 'idx')
    assert _TokenizingDecoder.scan_once.__code__.co_argcount == 2


# Generated at 2022-06-24 11:18:19.602731
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"foo": "bar"}'
    t = _TokenizingDecoder(content=content)
    assert t.scan_once

# Generated at 2022-06-24 11:18:21.388711
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("{\"foo\": [\"bar\", \"baz\"]}", parse_float=float)

# Generated at 2022-06-24 11:18:24.950734
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    token = tokenize_json('{"key": "value"}')
    assert(token.value == {"key": "value"})

# Unit tests for function validate_json

# Generated at 2022-06-24 11:18:32.123361
# Unit test for function validate_json
def test_validate_json():
    with open("./tests/fixtures/simple_json.json", "r") as f:
        content = f.read()


    class MySchema(Schema):
        number = Field(format=int, min_value=5)
        string = Field(max_length=5)

    tokens, errors = validate_json(content, validator=MySchema)
    assert tokens == {"number": 10, "string": "Hello"}
    assert errors == [ValidationError(
        text="String length should not be greater than 5.",
        code="max_length",
        position=Position(char_index=26, column_no=12, line_no=2)
    )]



# Generated at 2022-06-24 11:18:33.898432
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json_obj = '{"a": "b"}'
    decoder = _TokenizingDecoder(content=json_obj)
    assert type(decoder) is _TokenizingDecoder


# Generated at 2022-06-24 11:18:42.466949
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '{"name":"1"}'
    test_data = [['name', 'token_type', 'start_position', 'end_position'],
                 ['"name"', 'ScalarToken', 0, 5],
                 ['"1"', 'ScalarToken', 11, 12]]

    token = tokenize_json(test_content)
    token_dict = token.value
    test_res = []
    for key in token_dict:
        test_res.append([key, type(token_dict[key]).__name__, token_dict[key].start,
                         token_dict[key].end])
    assert test_res[0] in test_data
    assert test_res[1] in test_data



# Generated at 2022-06-24 11:18:49.148561
# Unit test for function tokenize_json
def test_tokenize_json():
    from copy import copy
    from typesystem.tokenize.positional_validation import validate_with_positions
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    def test_strict(
        content: str, token_test: typing.Callable[[Token], None]
    ) -> None:
        token_strict = tokenize_json(content)
        token_test(token_strict)

    def test_relaxed(
        content: str, token_test: typing.Callable[[Token], None]
    ) -> None:
        token_relaxed = tokenize_json(content)
        token_test(token_relaxed)


# Generated at 2022-06-24 11:18:53.482795
# Unit test for function tokenize_json
def test_tokenize_json():
    test_dict = {'key1': 'value1', 
                 'key2': 'value2'}

    test_json = json.dumps(test_dict)
    test_token = tokenize_json(test_json)

    assert test_token.data == test_dict



# Generated at 2022-06-24 11:18:55.875624
# Unit test for function validate_json
def test_validate_json():
    content = ""
    validator = Field(type="integer")

    value, messages = validate_json(content, validator)

    assert False



# Generated at 2022-06-24 11:19:05.763409
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("", str) == ("", [])
    assert validate_json("\"a\"", str) == ("a", [])
    assert validate_json("\"a\"", "a") == (None, [])
    assert validate_json("\"a\"", "b") == (None, [])
    assert validate_json("\"a\"", {"name": "a"}) == (None, [])
    assert validate_json("{\"name\": \"a\"}", {"name": "a"}) == ({}, [])
    assert validate_json("{\"name\": \"a\"}", {"name": str}) == ({"name": "a"}, [])
    assert validate_json("{\"name\": \"a\"}", {"name": "a"}) == (None, [])

# Generated at 2022-06-24 11:19:12.470353
# Unit test for function validate_json
def test_validate_json():
    class UserSchema(Schema):
        name = Field(type="string")

    json_content_string = """
        {
            "name": "joe"
        }
    """
    json_content_bytes = json_content_string.encode("utf-8")

    assert validate_json(json_content_string, UserSchema) == ([], {"name": "joe"})
    assert validate_json(json_content_bytes, UserSchema) == ([], {"name": "joe"})

    not_json_string = "invalid json"
    not_json_bytes = not_json_string.encode("utf-8")

    try:
        validate_json(not_json_string, UserSchema)
        assert False
    except ParseError as e:
        assert e.position.line_

# Generated at 2022-06-24 11:19:16.364690
# Unit test for function validate_json
def test_validate_json():
    print(validate_json(content="true", validator=BooleanField()))
    assert validate_json(content="true", validator=BooleanField())==(None, None)


# Generated at 2022-06-24 11:19:26.913917
# Unit test for function validate_json
def test_validate_json():
    from typesystem.base import String, Number

    content = "[1, 2, 3]"
    validator = ListToken([Number()])
    value, errors = validate_json(content, validator)
    assert value == [1, 2, 3]
    assert not errors

    validator = ListToken([String()])
    value, errors = validate_json(content, validator)
    assert errors

    content = '{"a": 1, "b": 2, "c": "hello"}'
    validator = DictToken({"a": Number(), "b": Number()})
    value, errors = validate_json(content, validator)
    assert value == {"a": 1, "b": 2, "c": "hello"}
    assert not errors

    validator = DictToken({"b": Number(), "a": Number()})
   

# Generated at 2022-06-24 11:19:32.770208
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = '{ "a": 1, "b": "c" }'
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1, "b": "c"}
    assert token.start_pos.column_no == 1
    assert token.start_pos.line_no == 1
    assert token.end_pos.column_no == 21
    assert token.end_pos.line_no == 1



# Generated at 2022-06-24 11:19:35.634381
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"foo": "bar"}'
    token = tokenize_json(content)
    assert token.get_value() == {"foo": "bar"}



# Generated at 2022-06-24 11:19:43.124947
# Unit test for function validate_json
def test_validate_json():

    @dataclass
    class Car:
        """
        Defines a car model for the purpose of demonstrating tokenization.
        """
        year: int
        model: str
        make: str
        options: typing.List[str]

    class CarSchema(Schema):
        """
        Defines a schema for the car model.
        """
        year = Field(type=str)
        model = Field(type=str)
        make = Field(type=str)
        options = Field(type=str, many=True)
        class Options:
            unknown = "EXCLUDE"

    # Test that an error code is returned as an error message on an invalid JSON string.
    content1 = "{"
    value1, error_messages1 = validate_json(
        content1, validator=CarSchema
    )


# Generated at 2022-06-24 11:19:49.358083
# Unit test for function validate_json
def test_validate_json():
    field = Field(key="test", required=True)
    error_messages = validate_json(content=b"{}", validator=field)
    assert error_messages == [
        Message(
            error_type="required",
            error_message="This field is required.",
            code="required",
            position=Position(column_no=2, line_no=1, char_index=1),
        )
    ]



# Generated at 2022-06-24 11:19:52.390381
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    from typesystem.testing import get_fake_decoder
    decoder = _TokenizingDecoder
    assert isinstance(decoder, object)
    assert decoder == get_fake_decoder()


# Generated at 2022-06-24 11:20:00.486220
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.tokenize.tokens import DictToken, ScalarToken, Token
    from typesystem.tokenize.tokens import ListToken, Token

    """
    Test that a test file can be turned into a token
    """
    with open("test_json.json") as json_file:
        data = json_file.read()
    token = tokenize_json(data)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.position.line_no == 1
    assert token.position.column_no == 1
    assert token.position.char_index == 0

    """
    Test that a scalar field is a token with no children
    """
    assert isinstance(token.children["test_key"], Token)

# Generated at 2022-06-24 11:20:02.009468
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass

# Unit test function for function _make_scanner

# Generated at 2022-06-24 11:20:06.923684
# Unit test for function validate_json
def test_validate_json():
    content: str = '{"foo": "bar"}'
    class MySchema(Schema):
        foo = Field(type="string")
    my_schema = MySchema()
    value, errors = validate_json(content, my_schema)
    assert value == {"foo": "bar"}
    assert errors == []


# Generated at 2022-06-24 11:20:08.990058
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder


# Generated at 2022-06-24 11:20:13.001686
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"list1":[1,2,3],"dict1":{"dict2":2}}'
    token = tokenize_json(content)
    assert(token.value == {'list1':[1,2,3],'dict1': {'dict2': 2}})



# Generated at 2022-06-24 11:20:16.412752
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    assert validate_json(b'"foo"', validator=validator) == ("foo", [])
    assert validate_json(b'"foo"', validator=validator) != (123, [])
    assert validate_json(b'"foo"', validator=validator) != ("foo", ["bar"])

# Generated at 2022-06-24 11:20:27.301747
# Unit test for function validate_json
def test_validate_json():
    validator = Field(
        type="integer", minimum=10, maximum=100
    )
    value, errors = validate_json("100", validator)
    assert value == 100

    content = "2"

    value, errors = validate_json(content, validator)

    error = errors[0]
    assert error.text == "Must be greater than or equal to 10."
    assert error.code == "min_value"
    assert error.position.column_no == 1
    assert error.position.line_no == 1
    assert error.position.char_index == 0

    content = "1000"

    value, errors = validate_json(content, validator)

    error = errors[0]
    assert error.text == "Must be less than or equal to 100."
    assert error.code == "max_value"
   

# Generated at 2022-06-24 11:20:28.867145
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a=_TokenizingDecoder(content="123")
    assert a is not None


# Generated at 2022-06-24 11:20:39.689509
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import StructureSchema
    from typesystem.fields import IntegerField, StringField
    from typesystem.exceptions import ValidationError

    class SampleSchema(StructureSchema):
        foo = IntegerField()
        bar = StringField()

    # Successful validation
    value, error_messages = validate_json('{"foo": 42, "bar": "baz"}', SampleSchema)
    assert value == {"foo": 42, "bar": "baz"}
    assert not error_messages

    # Invalid JSON
    with pytest.raises(ParseError) as exc_info:
        validate_json('{"foo": [42, "bar": "baz"]}', SampleSchema)
    assert exc_info.value.position.column_no == 11

# Generated at 2022-06-24 11:20:46.923163
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Test basic functionality
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once("{}", 0) == (DictToken({}, 0, 1, content), 2)
    # Test import of class name outside of class body
    assert decoder.JSONDecodeError
    # Test that the class does not contain any state
    _TokenizingDecoder(content=content)
    _TokenizingDecoder(content="test2")
    # Test that the class is not re-initialized when a new object is created
    old_scan_once = decoder.scan_once
    new_decoder = _TokenizingDecoder(content=content)
    new_scan_once = new_decoder.scan_once
    assert old_scan_once == new_scan_once
    # Test