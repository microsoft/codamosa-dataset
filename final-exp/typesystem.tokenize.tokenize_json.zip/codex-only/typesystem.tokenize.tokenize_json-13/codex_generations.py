

# Generated at 2022-06-24 11:10:49.933139
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("""
    {
        "foo": "bar",
        "baz": "biz",
    }
    """,) == DictToken({
        ScalarToken("foo", 7, 10, "\"foo\""): ScalarToken("bar", 15, 18, "\"bar\""),
        ScalarToken("baz", 23, 26, "\"baz\""): ScalarToken("biz", 31, 34, "\"biz\""),
    })



# Generated at 2022-06-24 11:10:56.718026
# Unit test for function validate_json
def test_validate_json():
    content = """
{
  "foo": "bar",
  "baz": ["abc", "def", "ghi", "jkl"],
  "qux": [0, 1, 2, 3, 4]
}
"""
    class MySchema(Schema):
        foo = Field(type="string")
        baz = Field(type="list", items=Field(type="string", length=3))
        qux = Field(type="list", items=Field(type="integer", minimum=1))

    value, messages = validate_json(content, MySchema)
    assert value == {"qux": [1, 2, 3, 4], "baz": ["abc", "def", "ghi"], "foo": "bar"}

# Generated at 2022-06-24 11:10:59.630680
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="This is a test string")
    assert decoder.content == "This is a test string"


# Generated at 2022-06-24 11:11:07.853695
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.children[0] == (
        ScalarToken(
            'key',
            Position(column_no=2, line_no=1, char_index=1),
            Position(column_no=5, line_no=1, char_index=4),
            content
        ),
        ScalarToken(
            'value',
            Position(column_no=8, line_no=1, char_index=7),
            Position(column_no=14, line_no=1, char_index=13),
            content
        )
    )

# Unit tests for validate_json

# Generated at 2022-06-24 11:11:18.643089
# Unit test for function validate_json
def test_validate_json():
    def do_test(field, content, expected_errors):
        value, error_messages = validate_json(content, field)
        assert error_messages == expected_errors

    # Test integer validation
    field = Field(type='integer')
    do_test(field, '[1,2,3]', [])
    do_test(field, '[1, 2.3, 3]', [ValidationError(text='Value must be an integer.', code='invalid_type', position=Position(column_no=4, line_no=1, char_index=4), value=2.3)])

    # Test string validation
    field = Field(type='string')
    do_test(field, '["test", "test2"]', [])

# Generated at 2022-06-24 11:11:28.756610
# Unit test for function validate_json
def test_validate_json():
    # Get a dummy schema to validate the input against
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String(max_length=3)

    def test_validation(content: str, valid: bool) -> None:
        try:
            values, error_messages = validate_json(
                content, schema_class=MySchema
            )
            assert error_messages == []

            assert values["name"] == "bob"
            assert valid, f"String {content} was marked as invalid."
        except ValidationError:
            assert not valid, f"String {content} was marked as valid."

    # Test a valid input
    test_validation('{"name": "bob"}', True)

    # Test an invalid input
    test

# Generated at 2022-06-24 11:11:37.175136
# Unit test for function tokenize_json
def test_tokenize_json():
    query_json_string = '{"foo": "bar", "baz": ["hello", "world", "!"]}'
    object = tokenize_json(query_json_string)
    assert isinstance(object, DictToken)
    assert object.keys == ["foo", "baz"]
    assert isinstance(object["foo"], ScalarToken)
    assert object["foo"].value == "bar"
    assert isinstance(object["baz"], ListToken)
    assert len(object["baz"]) == 3
    assert isinstance(object["baz"][0], ScalarToken)
    assert object["baz"][0].value == "hello"
    assert object["baz"][1].value == "world"
    assert object["baz"][2].value == "!"

# Generated at 2022-06-24 11:11:47.410796
# Unit test for function validate_json
def test_validate_json():
    content = """
    {
        "key1" : "val1"
    }"""
    validator = Schema(
        {
            "key1": "string",
            "key2": "string",
        }
    )
    expected_value, expected_errors = {
        "key1": "val1",
    }, [
        ValidationError("Missing  a value for the key 'key2'.", code="required_field"),
    ]
    value, errors = validate_json(content, validator)
    assert (
        value == expected_value
    ), "Failed to parse correctly and return the expected value"
    assert (
        errors == expected_errors
    ), "Failed to parse correctly and return the expected errors"

    content = b"\x00\x00"

# Generated at 2022-06-24 11:11:49.274840
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
  c = _TokenizingDecoder('{}', content='{}')
  assert(isinstance(c, _TokenizingDecoder))

# Generated at 2022-06-24 11:11:59.713784
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "Nilabja", "age": 24}'
    validator = Schema.of({"name": str, "age": int})
    value, errors = validate_json(content, validator)
    assert not errors
    assert value == {"name": "Nilabja", "age": 24}
    assert value.name == value["name"] == "Nilabja"
    assert value.age == value["age"] == 24
    assert str(value) == '{"name": "Nilabja", "age": 24}'
    assert repr(value) == "<ValidatedDict {'name': 'Nilabja', 'age': 24}>"
    content = '{"name": "Nilabja", "age": 24, "hobbies": ["cricket", "green"]}'
    value,

# Generated at 2022-06-24 11:12:01.727278
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "Hello"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.content == content

# Generated at 2022-06-24 11:12:09.478212
# Unit test for function validate_json
def test_validate_json():
    simple_json = '{"firstname": "John", "lastname": "Doe"}'
    simple_schema = Schema({"firstname": str, "lastname": str})
    value, error_messages = validate_json(simple_json, simple_schema)
    assert len(error_messages) == 0
    assert value == {
        "lastname": "Doe",
        "firstname": "John",
    }

    invalid_json = '{"firstname": "John", "lastname": 3}'
    value, error_messages = validate_json(invalid_json, simple_schema)
    assert len(error_messages) == 1
    assert error_messages[0].text == "Must be a string"

# Generated at 2022-06-24 11:12:17.404503
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    def parse_int(val):
        return int('13')

    def parse_float(val):
        return 13.0
    class Context:
        parse_int = parse_int
        parse_float = parse_float
        strict = True

    context = Context()
    content = "{'text': 'test'}"
    decoder = _TokenizingDecoder(context,content=content)

    assert decoder.parse_int('13') == 13
    assert decoder.parse_float('13.0') == 13.0
    assert decoder.strict == True
    assert decoder.scan_once == _make_scanner(context,content)


# Generated at 2022-06-24 11:12:28.008978
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"a": "hello", "b": "world", "c": {"d": ["a", "b"]}}'
    token = tokenize_json(content)
    
    print("\nCASE 1:\n")
    print("Content: " + content)
    print("\nToken: " + str(token))
    print("\nToken to JSON: " + str(token.to_json()))
    print("\nToken to Dict: " + str(token.to_dict()))
    print("\nToken to JSON to Dict: " + str(token.to_json().to_dict()))

    content = '{"a": "hello", "b": "world", "c": {"d": ["a", "b"]}}'

    print("\nCASE 2:\n")

# Generated at 2022-06-24 11:12:34.694863
# Unit test for function tokenize_json
def test_tokenize_json():
    data = '''
    {
        "key": "value",
        "key2": {
            "key3": "value3"
        },
        "key4": [
            {
                "key5": "value5"
            },
            {
                "key6": "value6"
            }
        ]
    }
    '''
    token = tokenize_json(data)
    assert token.value == {"key": "value", "key2": {"key3": "value3"}, "key4": [{"key5": "value5"}, {"key6": "value6"}]}
    assert token.start == 1
    assert token.end == 61


# Generated at 2022-06-24 11:12:39.542277
# Unit test for constructor of class _TokenizingDecoder

# Generated at 2022-06-24 11:12:45.479992
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "field": [
            "a",
            "b",
            "c"
        ]
    }
    """
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert isinstance(token.items["field"], ListToken)
    assert isinstance(token.items["field"].items[0], ScalarToken)
    assert token.items["field"].items[0].value == "a"
    assert token.items["field"].items[2].value == "c"



# Generated at 2022-06-24 11:12:49.025456
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    Check correct initialization of the constructor of class _TokenizingDecoder
    """
    # check that constructor not throws exception
    _TokenizingDecoder(content="")



# Generated at 2022-06-24 11:12:57.559457
# Unit test for function tokenize_json
def test_tokenize_json():
    def test_valid(content: str) -> None:
        token = tokenize_json(content)
        assert isinstance(token, Token)

    def test_invalid(content: str, code: str, text: str) -> None:
        try:
            tokenize_json(content)
            assert False
        except ParseError as error:
            assert error.code == code and error.text == text

    test_invalid("", "no_content", "No content.")
    test_invalid("  ", "no_content", "No content.")
    test_invalid("{", "parse_error", "Expecting property name enclosed in double quotes")
    test_invalid("{abc}", "parse_error", "Expecting property name enclosed in double quotes")

# Generated at 2022-06-24 11:13:01.056993
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{ "a": 1 }') == DictToken(
        {"a": ScalarToken(1, 6, 7, '{ "a": 1 }')}, 0, 12, '{ "a": 1 }')



# Generated at 2022-06-24 11:13:09.290671
# Unit test for function tokenize_json
def test_tokenize_json():
    empty = '   \n  \t  \r \n \n \r '
    res = tokenize_json(empty)
    assert res == ListToken([], 0, len(empty) - 1, empty)

    content = "[1,2,[3,4,5],6]"
    res = tokenize_json(content)

# Generated at 2022-06-24 11:13:16.393294
# Unit test for function validate_json
def test_validate_json():
    content = "{'k': 'v'}"
    validator = Field(name="field", type="string")

    value, errors = validate_json(content, validator)

    assert value is None
    assert len(errors) == 1
    assert errors[0].position.line_no == 1
    assert errors[0].position.column_no == 2
    assert errors[0].code == "invalid_type"
    assert errors[0].text == "Must be of type(s) string."

# Generated at 2022-06-24 11:13:25.324504
# Unit test for function validate_json
def test_validate_json():
    import io
    import sys

    content = b'{"number": 42, "string": "hello"}'
    validator = Schema({
        "number": int,
        "string": str},
        unknown=None)

    token, errors = validate_json(content, validator)

    assert isinstance(token, DictToken)
    assert token.value == {"number": 42, "string": "hello"}

    assert len(errors) == 0

    content = b'{"number": 42, "string": ["hello", "world"]}'

    token, errors = validate_json(content, validator)

    assert isinstance(token, DictToken)
    assert token.value == {"number": 42, "string": ["hello", "world"]}

    assert len(errors) == 1


# Generated at 2022-06-24 11:13:31.891255
# Unit test for function tokenize_json
def test_tokenize_json():
    # normal case
    assert tokenize_json('{ "a": 2 }') == { "a": 2 }
    assert tokenize_json(b'{ "a": 2 }') == { "a": 2 }
    # empty input
    try:
        tokenize_json('')
    except ParseError as exc:
        assert exc.position.char_index == 0
        assert exc.position.column_no == 1
        assert exc.position.line_no == 1
    else:
        assert False, "Expected ParseError"



# Generated at 2022-06-24 11:13:39.089171
# Unit test for function validate_json
def test_validate_json():
    validator = Field(title='name', type='string')
    value, errors = validate_json('{"name": "John"}', validator)
    assert value == {"name": "John"}
    assert errors == []

    validator = Field(title='name', type='string', required=True)
    value, errors = validate_json('{"name": "John"}', validator)
    assert value == {"name": "John"}
    assert errors == []


# Generated at 2022-06-24 11:13:44.042598
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test for empty content
    with pytest.raises(ParseError, match="No content."):
        tokenize_json("")

    # Test for invalid JSON
    with pytest.raises(ParseError, match="Expecting ',' delimiter"):
        tokenize_json("{ 'foo': 'bar' }")

    # Test for valid JSON
    token = tokenize_json("[1,2,3]")
    assert token.value == [1,2,3]



# Generated at 2022-06-24 11:13:46.631431
# Unit test for function validate_json
def test_validate_json():
    import json
    import aux_main

    content1 = b'{ "name": "John", "age": 30, "city": "New York" }'
    schema_ = aux_main.UserSchema()
    value1, error_messages = validate_json(content1, schema_)
    print(value1)
    print(json.dumps(error_messages))



# Generated at 2022-06-24 11:13:57.171736
# Unit test for function validate_json
def test_validate_json():
    valid_json = '''{"name": "mandy","age": 20,"pets": [{"name": "caty","type": "cat"},{"name": "dogy","type": "dog"}]}'''
    invalid_json = '''{"name": "mandy","age": 20,}'''
    invalid_json_2 = '''{]'''
    schema_class = Schema.from_dict({"name": str, "age": int})
    try:
        value, errors = validate_json(valid_json,validator=schema_class)
        assert value == {'name':'mandy','age':20}
        assert errors is None
    except ValidationError:
        print("test failed")
        raise

# Generated at 2022-06-24 11:13:59.794915
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    if _TokenizingDecoder({"content":""}) :
        return False
    return True

# Generated at 2022-06-24 11:14:06.256211
# Unit test for function validate_json
def test_validate_json():
    from io import StringIO
    from unittest import TestCase, main
    from typesystem.schemas import Schema, fields
    import json

    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    class Input(Schema):
        person = fields.Nested(Person, required=True)
        role = fields.String(required=True)

    class Output(Schema):
        person_id = fields.String(required=True)

    class MessageError(Message):
        text: str
        code: str
        position: Position

    def serialize(message: MessageError) -> str:
        obj = {"text": message.text, "code": message.code, "position": message.position}
        return json.dumps(obj)


# Generated at 2022-06-24 11:14:07.197980
# Unit test for function validate_json
def test_validate_json():
    pass


# Generated at 2022-06-24 11:14:13.788072
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"Tengfei": [1, 2, 3]}')
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_string == scanstring
    assert decoder.strict == True
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.memo == {}


# Generated at 2022-06-24 11:14:18.860845
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"Hello": "World!"}')
    assert result == DictToken({ScalarToken("Hello", 1, 8, '{"Hello": "World!"}'): ScalarToken("World!", 10, 19, '{"Hello": "World!"}'),}, 0, 20, '{"Hello": "World!"}')

# Generated at 2022-06-24 11:14:25.013306
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")
    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("""
        {
            "hello": "world"
        }
    """).token == {"hello": "world"}
    assert tokenize_json("""
        [
            "foo",
            "bar"
        ]
    """).token == ["foo", "bar"]



# Generated at 2022-06-24 11:14:33.155498
# Unit test for function validate_json
def test_validate_json():
    # First success case
    content = '[{"a":"1"}, {"a": "2"}]'
    validator = [
        {
            "type": "object",
            "properties": {
                "a": {"type": "string"}
            }
        }
    ]
    expected = ([
        {
            'a': '1'
        },
        {
            'a': '2'
        }
    ], [])
    assert validate_json(content, validator) == expected
    # Second success case
    validator = Field(properties={"a": Field(type="string")})
    expected = [
        {
            'a': '1'
        },
        {
            'a': '2'
        }
    ]
    assert validate_json(content, validator) == expected
    # First failure case


# Generated at 2022-06-24 11:14:42.004034
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import List, String
    from typesystem.schemas import Schema

    class UserSchema(Schema):

        name = String()
        friends = List(of=String())

    json_content = '{"name": "John Doe", "friends": ["Alice", "Bob"]}'
    token = tokenize_json(json_content)
    assert (
        token.json_serialize()
        == '{"name": "John Doe", "friends": ["Alice", "Bob"]}'
    )

    try:
        tokenize_json("")
    except ParseError:
        assert True, "Empty string should raise a ParseError"
    else:
        assert False, "Empty string should raise a ParseError"


# Generated at 2022-06-24 11:14:43.895707
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    a = {}
    b = "content"
    _TokenizingDecoder(a,content=b)


# Generated at 2022-06-24 11:14:51.490470
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json('{"a": 1, "b": "Test"}')
    assert isinstance(value, Token)
    assert isinstance(value, DictToken)
    assert len(value) == 2
    assert value.keys() == {'a', 'b'}
    assert isinstance(value['a'], ScalarToken)
    assert value['a'] == 1
    assert isinstance(value['b'], ScalarToken)
    assert value['b'] == 'Test'



# Generated at 2022-06-24 11:14:58.973683
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("", str) == (None, [])
    assert validate_json("nope", str) == (None, [])
    assert validate_json("{}", str) == (None, [])
    assert validate_json("[]", str) == (None, [])
    assert validate_json("{]", str) == (None, [])
    assert validate_json("[}", str) == (None, [])
    assert validate_json("[1, 2, 3]", str) == (None, [])
    assert validate_json("[1, {}, 3]", str) == (None, [])
    assert validate_json("1", str) == (None, [])
    assert validate_json("3.14159", str) == (None, [])

# Generated at 2022-06-24 11:15:06.965350
# Unit test for function validate_json
def test_validate_json():
    """
    This method tests the validate_json function.
    """
    from typesystem import Schema, fields, types
    from typesystem.tokenize.positional_validation import (
        clear_position_messages,
        get_position_messages,
    )

    class User(Schema):
        name = fields.String(max_length=10)
        email = fields.String(format="email")
        age = fields.Integer(minimum=18)

    user_json = '{"name": "John Doe", "email": "john@example.com", "age": 20}'
    (user, errors) = validate_json(user_json, User)
    assert (errors == [])

    user_json = '{"name": "John Doe", "email": "john@example.com", "age": 17}'
   

# Generated at 2022-06-24 11:15:14.656271
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b"}') == Token(
        data={"a": "b"}, start_index=0, end_index=7, content='{"a":"b"}'
    )

    assert tokenize_json("[1,2,3]") == Token(
        data=[1, 2, 3], start_index=0, end_index=7, content="[1,2,3]"
    )

    with pytest.raises(ParseError):
        tokenize_json("")



# Generated at 2022-06-24 11:15:24.877386
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
{
  "a": 1,
  "b": [2]
}
"""
    token = tokenize_json(content)
    assert token.start == 0
    assert token.end == len(content) - 1

    key = token.value.keys[0]
    assert key.start == 5
    assert key.end == 6
    assert key.value == "a"

    value = token.value.values[0]
    assert isinstance(value, ScalarToken)
    assert value.start == 9
    assert value.end == 9
    assert value.value == 1

    key = token.value.keys[1]
    assert key.start == 15
    assert key.end == 16
    assert key.value == "b"

    value = token.value.values[1]

# Generated at 2022-06-24 11:15:30.426844
# Unit test for function validate_json
def test_validate_json():
    # Setup
    field = Field(validators=[lambda x: (x == 2)], allow_null=True)
    content = '{"test": 2}'
    # Exercise
    value, error_messages = validate_json(content, field)
    # Verify
    assert len(error_messages) == 0
    # Cleanup - none necessary



# Generated at 2022-06-24 11:15:40.299426
# Unit test for function tokenize_json
def test_tokenize_json():

    with pytest.raises(ParseError):
        tokenize_json("{")

    with pytest.raises(ParseError):
        tokenize_json("{}}")

    with pytest.raises(ParseError):
        tokenize_json('{"a": 1')

    with pytest.raises(ParseError):
        tokenize_json('{"a": 1 "b": 2}')

    with pytest.raises(ParseError):
        tokenize_json('{"a": "b}')

    with pytest.raises(ParseError):
        tokenize_json('{"a": "b" "c": "d"}')

    with pytest.raises(ParseError):
        tokenize_json('{"a": "b": "c"}')


# Generated at 2022-06-24 11:15:50.193811
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """
    {
        "foo": "bar",
        "list": [1, 2, 3],
        "nested": {
            "yes": true,
            "no": false
        },
        "null": null
    }
    """
    token = tokenize_json(json_str)
    assert isinstance(token, DictToken)

    token_value = token.value
    assert isinstance(token_value, dict)
    assert len(token_value) == 4
    assert "foo" in token_value
    assert "list" in token_value
    assert "nested" in token_value
    assert "null" in token_value

    assert isinstance(token_value["foo"], ScalarToken)
    assert token_value["foo"].value == "bar"


# Generated at 2022-06-24 11:15:53.476649
# Unit test for function validate_json
def test_validate_json():
    content = "[\"foo\", \"bar\"]"
    # TODO: Fix this test
    with pytest.raises(ValidationError):
        validate_json(content, List(items=String()))

# Generated at 2022-06-24 11:15:59.279925
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    tokenizing_decoder = _TokenizingDecoder()
    assert isinstance(tokenizing_decoder, JSONDecoder)
    assert len(tokenizing_decoder.parse_array.__code__.co_varnames) == 2
    assert len(tokenizing_decoder.parse_object.__code__.co_varnames) == 5

# Generated at 2022-06-24 11:16:00.303814
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-24 11:16:10.775285
# Unit test for function validate_json
def test_validate_json():
    import json

    class Person(Schema):
        name = StringField(max_length=50)
        age = IntegerField(minimum=0)
        height = FloatField(minimum=0)
        edu = StringField(choices=["primary", "high", "college", "postgraduate"])

    person = {
        "name": "John Doe",
        "age": 120,
        "edu": "postgraduate",
        "height": 1.75,
    }
    person_json_string = json.dumps(person)

    value, error_messages = validate_json(
        content=person_json_string, validator=Person
    )

    assert value == person
    assert error_messages == []

    class InvalidPerson(Schema):
        name = StringField(minimum_length=50)

# Generated at 2022-06-24 11:16:18.956940
# Unit test for function tokenize_json
def test_tokenize_json():
    #Test malformed json
    try:
      tokenize_json("{")
      assert False
    except ParseError:
      assert True
    #Test incomplete json
    try:
      tokenize_json("{\"foo\" : { \"bar\" : \"baz\"}")
      assert False
    except ParseError:
      assert True
    #Test valid json
    token = tokenize_json("{\"foo\" : { \"bar\" : \"baz\"}}")
    assert isinstance(token, Token)


# Generated at 2022-06-24 11:16:20.172386
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder(), _TokenizingDecoder)


# Generated at 2022-06-24 11:16:22.412717
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json('{"a":1}')
    assert isinstance(result, DictToken)
    assert result.value == {"a": 1}


# Generated at 2022-06-24 11:16:31.586359
# Unit test for function validate_json
def test_validate_json():
    content = '{"x": "string", "y": 1}'
    validator = Schema({"x": str, "y": int})
    value, error_messages = validate_json(content, validator)
    assert value == {"x": "string", "y": 1}
    assert error_messages == []

    content = '{"x": "string", "y": true}'
    validator = Schema({"x": str, "y": int})
    value, error_messages = validate_json(content, validator)
    assert value == {}
    assert len(error_messages) == 1

# Generated at 2022-06-24 11:16:41.029332
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": [1, "string", {"b": 2}]}')
    assert token.type == 'dict'
    token = tokenize_json('{"a": [1, "string", {"b": 2}]}')
    assert token.type == 'dict'
    token = tokenize_json('{"a": [1, "string", {"b": 2}]}')
    assert token.type == 'dict'
    token = tokenize_json('{"a": [1, "string", {"b": 2}]}')
    assert token.type == 'dict'


# Generated at 2022-06-24 11:16:49.204817
# Unit test for function tokenize_json
def test_tokenize_json():  # pragma: no cover
    from typesystem import fields
    from typesystem.tests.fixtures import fields_json

    # Test with CRLF and LF line endings

# Generated at 2022-06-24 11:16:52.260500
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content")
    assert decoder.scan_once == _make_scanner(decoder, content="content")

# Generated at 2022-06-24 11:17:02.417544
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"1":{"2":3}', "invalid_json") == \
        DictToken({"1": DictToken({"2": ScalarToken(3, 12, 12, "invalid_json")}, 8, 17, "invalid_json")}, 1, 17, "invalid_json")
    assert tokenize_json('{"1":[{"2":3}', "invalid_json") == \
        DictToken({"1": ListToken([DictToken({"2": ScalarToken(3, 15, 15, "invalid_json")}, 13, 20, "invalid_json")], 9, 20, "invalid_json")}, 1, 20, "invalid_json")

# Generated at 2022-06-24 11:17:08.484048
# Unit test for function validate_json
def test_validate_json():
    schema = {
        "type": "object",
        "properties": {
            "prop1": {
                "type": "object",
                "properties": {
                    "prop2": {
                        "type": "object",
                        "properties": {
                            "prop3": {
                                "type": "array",
                                "items": {"type": "integer"},
                            }
                        },
                    }
                },
            }
        },
    }

    content = "{\"prop1\": {\"prop2\": {\"prop3\": [1,2,3]}}}"
    message = Message(
        text="Missing value.",
        code="missing_value",
        position=Position(line_no=1, column_no=4, char_index=4),
    )
    token = tokenize_json(content)


# Generated at 2022-06-24 11:17:10.889440
# Unit test for function validate_json
def test_validate_json():
    schema = type('schema', (schema,), {'type': 'object', 'properties': {'name': {'type': 'string'}}})
    assert isinstance(validate_json('{"name": "test"}', schema), tuple)
    assert len(validate_json('{"name": "test"}', schema)) == 2


# Generated at 2022-06-24 11:17:18.816308
# Unit test for function tokenize_json
def test_tokenize_json():
    context = '{"user":"toto", "messages": [{"foo": "bar"}, {"baz": "quux"}]}'

# Generated at 2022-06-24 11:17:23.464791
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name": "Shubham"}'
    validator = Field(type="object", properties={
        "name": Field(type="string")
    })
    result = validate_json(content, validator)
    assert result[0] is not None
    assert result[1] is None

# Test case for invalid json

# Generated at 2022-06-24 11:17:34.876165
# Unit test for function validate_json
def test_validate_json():
    validator = Field(name="foo", type="string", pattern="^[a-z]+$")
    value, errors = validate_json(b'"hello there"', validator)
    assert value == "hello there"
    assert not errors
    value, errors = validate_json(b'"hello there"', "string")
    assert value == "hello there"
    assert not errors
    value, errors = validate_json(b"12345", validator)
    assert value == "12345"
    assert not errors
    value, errors = validate_json(b"12345", "string")
    assert value == "12345"
    assert not errors
    value, errors = validate_json(b'"hello there"', Field(type="number"))
    assert value == "hello there"
    assert len(errors) == 1
    assert isinstance

# Generated at 2022-06-24 11:17:37.088821
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test content")

# Generated at 2022-06-24 11:17:45.632562
# Unit test for function validate_json
def test_validate_json():
    values = [
        None,
        True,
        False,
        "string",
        u"unicode string",
        100,
        100.0,
        3.2e10,
        [[1, 2, 3], [4, 5, 6]],
        {"1": 1, "2": 2},
        [1, True, None, [], {"a": 1}, "b"],
        {"a": 1, "b": True, "c": None, "d": [], "e": {"a": 1}, "f": "b"},
    ]
    for value in values:
        # Test with string input
        svalue = json.dumps(value)
        actual_value, errors = validate_json(svalue, Field())
        assert errors == []
        assert actual_value == value
        # Test with byte input


# Generated at 2022-06-24 11:17:46.957997
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder("content")

# Generated at 2022-06-24 11:17:53.949264
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:17:56.735124
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert(_TokenizingDecoder.__init__)


# Generated at 2022-06-24 11:18:06.054186
# Unit test for function validate_json
def test_validate_json():
    '''
    Validate the results of function validate_json
    '''
    # import schema and field classes
    from typesystem.fields import String
    from typesystem.schemas import Schema

    # define test schema
    class TestSchema(Schema):
        name = String()
        age = String()

    # test validation on valid json
    assert validate_json(
        b'{"name": "John Doe", "age": "42"}', TestSchema) == (
            {'name': 'John Doe', 'age': '42'}, []
            )
    # test validation on valid json that contains extra fields

# Generated at 2022-06-24 11:18:09.584593
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d1 = _TokenizingDecoder(content="abc")
    assert d1.content == "abc"
    d2 = _TokenizingDecoder(content="def")
    assert d2.content == "def"


# Generated at 2022-06-24 11:18:14.513719
# Unit test for function validate_json
def test_validate_json():
    """
    Testing to check if validation works as expected.
    """
    assert validate_json("{}", Schema) == ({}, [])
    assert validate_json("{}", Schema(fields={"foo": Field()})) == ({}, [])
    with pytest.raises(ParseError):
        validate_json("{", Schema)



# Generated at 2022-06-24 11:18:17.425933
# Unit test for function validate_json
def test_validate_json():
    json = b'{"a": 1}'
    schema = Schema({"a": Field(type="number")})
    value, error_messages = validate_json(json, schema)
    assert value == {"a": 1}
    assert error_messages == []



# Generated at 2022-06-24 11:18:19.908516
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="{}")
    assert decoder.scan_once("{}", 0)[0].value == {}


# Generated at 2022-06-24 11:18:28.621004
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":1, "b":[1, 2, 3], "c":{"c1":"hello", "c2":true, "c3":1.23}}')
    assert isinstance(token, DictToken)
    assert len(token) == 3
    assert token["a"].value == 1
    assert token["b"].value == [1, 2, 3]
    assert token["c"].value["c1"].value == "hello"
    assert token["c"].value["c2"].value == True
    assert token["c"].value["c3"].value == 1.23



# Generated at 2022-06-24 11:18:38.804656
# Unit test for function validate_json
def test_validate_json():
    class UserSchema(Schema):
        name = Field(type="string", max_length=100)
        birth_date = Field(type="date")
        age = Field(type="integer")

    from typesystem import String, Integer, Date

    schema = UserSchema()

    # Test: Valid content
    content = '{"name": "Tyler", "birth_date": "1991-02-27", "age": 27}'
    assert validate_json(content, schema) == ({
        "name": "Tyler",
        "birth_date": datetime(year=1991, month=2, day=27),
        "age": 27,
    }, [])

    # Test: Invalid content
    content = '{"name": "Tyler", "birth_date": "1991-02-27", "age": 27}'
    assert validate_json

# Generated at 2022-06-24 11:18:40.218405
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        _TokenizingDecoder(content="test")
    except AttributeError:
        assert False


# Generated at 2022-06-24 11:18:42.900538
# Unit test for function validate_json
def test_validate_json():
    content = b'{"name": "john"}'
    validator = Field(type="string")
    assert validate_json(content, field) == (None, [
        Message(code="wrong_type", text="Must be of type 'string'", field="name", position=None),
    ])

# Generated at 2022-06-24 11:18:48.292628
# Unit test for function validate_json
def test_validate_json():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    schema = Schema(
        properties=[
            Field(name="name", type="string"),
            Field(name="age", type="integer"),
            Field(name="city", type="string"),
        ]
    )
    value, messages = validate_json(content, schema)
    assert len(messages) == 0
    assert isinstance(value, dict)
    assert value["name"] == "John"
    assert value["age"] == 30
    assert value["city"] == "New York"

    content = '{"name": "John", "age": 30, "city": "New York"}'

# Generated at 2022-06-24 11:18:59.701060
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name":"test", "age": 18, "isActive": true, "points": [1,2,3], "address":{"city":"city X", "street":"street Y"}}'
    token = tokenize_json(content)

# Generated at 2022-06-24 11:19:02.160228
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json(b'{"foo": ["bar", "baz"]}') == tokenize_json('{"foo": ["bar", "baz"]}')

# Generated at 2022-06-24 11:19:04.034565
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":1}') == DictToken({'a': 1}, 0, 6, '{"a":1}')

# Generated at 2022-06-24 11:19:14.873292
# Unit test for function validate_json
def test_validate_json():
    res = validate_json(b'{"foo": "bar"}', Field)
    assert res[1] == []

    res = validate_json(b'{"foo": "bar"}', Schema)
    assert res[1] == []

    res = validate_json(b'{"foo": "bar"}', Field(required=True))
    assert res[1] == [{
        'code': 'required',
        'position': Position(line_no=1, column_no=1, char_index=0),
        'text': 'This field is required.',
    }]

    res = validate_json(b'{"foo": "bar"}', Schema(required=True))

# Generated at 2022-06-24 11:19:25.788299
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    context = _TokenizingDecoder(
        content="test"
    )
    assert context.parse_array(("null", 0), context.scan_once) == ([], 4)
    assert context.parse_float("12.34") == 12.34
    assert context.parse_int("12") == 12
    assert context.parse_string(r'"test\n1234"', 0, True) == "test\n1234"
    assert context.memo == {}
    context.memo = {"test": "test"}
    assert context.memo == {"test": "test"}
    position = Position(column_no=1, line_no=1, char_index=0)
    assert context.strict == True
    assert context.content == "test"

# Generated at 2022-06-24 11:19:27.621102
# Unit test for function validate_json
def test_validate_json():
    import doctest
    doctest.run_docstring_examples(validate_json, globals())


# Generated at 2022-06-24 11:19:37.031787
# Unit test for function validate_json
def test_validate_json():
    schema = Schema("Test", {"foo": {"type": "integer"}})
    validator = schema()

    # Test a valid piece of data
    content = '{"foo": 42}'
    value, error_messages = validate_json(content, validator)
    assert value == {"foo": 42}
    assert not error_messages

    # Test with an invalid piece of data
    content = '{"foo": false}'
    value, error_messages = validate_json(content, validator)
    assert value is None
    assert len(error_messages) == 1
    error_message = error_messages[0]
    assert error_message.text == "Value is not of type 'integer'."
    assert error_message.code == "type_error.integer"
    position = error_message.position
    assert position

# Generated at 2022-06-24 11:19:41.275771
# Unit test for function validate_json
def test_validate_json():
    content = "{\n \"id\": 1,\n \"name\": \"foo\"\n}"
    schema = Schema({"id": "int", "name": "str"})
    value, errors = validate_json(content, schema)
    assert value == {"id": 1, "name": "foo"}
    assert len(errors) == 0


# Generated at 2022-06-24 11:19:51.893327
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = '''
    {
        "name": "Matt",
        "age": 31,
        "siblings": [
            {
                "name": "Paul",
                "age": 34,
                "is_younger": false
            },
            {
                "name": "Sarah",
                "age": 33,
                "is_younger": false
            }
        ]
    }
    '''
    token = tokenize_json(json_string)
    data = token.encode()
    assert data['name'] == 'Matt'
    assert data['age'] == 31
    assert isinstance(data['siblings'], list)
    assert data['siblings'][0]['name'] == 'Paul'
    assert data['siblings'][0]['age'] == 34

# Generated at 2022-06-24 11:20:00.166104
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:20:08.938161
# Unit test for function tokenize_json
def test_tokenize_json():
    test_content = '{"a":1}'
    token = tokenize_json(test_content)
    assert token.match_type({"a": 1})
    test_content2 = '{"a":null}'
    token2 = tokenize_json(test_content2)
    assert token2.match_type({"a": None})
    test_content3 = '{"a":[null,null]}'
    token3 = tokenize_json(test_content3)
    assert token3.match_type({"a": [None, None]})


if __name__ == "__main__":
    test_tokenize_json()

# Generated at 2022-06-24 11:20:17.450188
# Unit test for function validate_json
def test_validate_json():
    # Returns the value and the list of messages
    value, messages = validate_json('{"hello": 12}', Field(type="object"))
    assert "hello" not in messages
    assert value == {"hello": 12}

    # Returns the value and the list of messages
    value, messages = validate_json('{"hello": 12}', Field(type="object", required=["hello"]))
    assert "hello" not in messages
    assert value == {"hello": 12}

    # Returns the value and the list of messages
    value, messages = validate_json('{"hello": 12}', Field(type="object", properties={"hello": Field(type="string")}))
    assert "hello" in messages
    assert isinstance(messages["hello"], list)
    assert len(messages["hello"]) > 0

# Generated at 2022-06-24 11:20:26.572077
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{ "key": "value" }'
    token = tokenize_json(content)
    assert token.as_dict() == {"key": "value"}, "token should be correct"

    content = '{ "key": 0.1 }'
    token = tokenize_json(content)
    assert token.as_dict() == {"key": 0.1}, "token should be correct"

    content = '{ "key": { "subkey": "subvalue" } }'
    token = tokenize_json(content)
    assert token.as_dict() == {
        "key": {"subkey": "subvalue"}
    }, "token should be correct"


# Generated at 2022-06-24 11:20:34.043726
# Unit test for function tokenize_json
def test_tokenize_json():
    # Happy path
    content = '{"key": "value"}'
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(content) - 1

    # Empty string errors
    for content in ("", "{}", "{]", "{[}", "{} invalid", "{[]}"):
        try:
            tokenize_json(content)
        except ParseError:
            continue
        assert False, "Content is invalid but didn't raise an error"

    # Invalid JSON
    content = '{"key": "value"} invalid'
    try:
        tokenize_json(content)
    except ParseError as err:
        assert err.code == "parse_error"
        assert err.text == "Expecting end of value."

# Generated at 2022-06-24 11:20:43.440154
# Unit test for function validate_json
def test_validate_json():
    data = '[1, 2, 3]'
    validator = '[Integer()]'

    result = validate_json(data, validator)
    assert result[0] == [1, 2, 3]
    assert not result[1]

    data = '[1, 2, "3"]'
    validator = '[Integer()]'

    result = validate_json(data, validator)
    assert result[0] == [1, 2, 3]
    assert len(result[1]) == 1
    assert result[1][0].code == "type_error"
    assert result[1][0].position.line_no == 1
    assert result[1][0].position.column_no == 7
    assert result[1][0].position.char_index == 6

    data = '[[1], [2], [3]]'
    validator