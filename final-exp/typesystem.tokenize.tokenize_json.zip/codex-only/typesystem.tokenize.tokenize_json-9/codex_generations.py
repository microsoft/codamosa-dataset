

# Generated at 2022-06-24 11:10:45.928318
# Unit test for function tokenize_json
def test_tokenize_json():
    string_contents = {
        "flat_string": '{"a": "b", "c": [1, 2, 3], "x": "y"}',
        "pretty_string": """
            {
              "a": "b",
              "c": [
                1,
                2,
                3
              ],
              "x": "y"
            }
        """.strip()
    }

    for name, content in string_contents.items():
        yield check_tokenize_json, name, content



# Generated at 2022-06-24 11:10:51.788424
# Unit test for function tokenize_json
def test_tokenize_json():
    value = tokenize_json('{"a": "b"}')
    assert isinstance(value, dict)
    assert isinstance(value.get('a'), str)
    assert value.get('a') == 'b'

    with pytest.raises(ParseError):
        tokenize_json('{"a": "b"')

    with pytest.raises(ParseError):
        tokenize_json('{a: "b"}')

    with pytest.raises(ParseError):
        tokenize_json('')


# Generated at 2022-06-24 11:11:01.861984
# Unit test for function validate_json
def test_validate_json():

    # Create some json
    json_string = """{
  "ID": 3,
  "Name": "Mary",
  "Age": 20,
  "City": "Paris"
}"""

    # Create a schema that validates the json we created
    class Person(Schema):
        id = Field(type="number")
        name = Field(type="string")
        age = Field(type="number", minimum=0, maximum=125)
        city = Field(type="string")
        address = Field(type="string")

    # Validate the json against the schema
    result = Person(json_string)

    # Expect no errors
    assert len(result.errors) == 0

# Generated at 2022-06-24 11:11:02.498185
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass

# Generated at 2022-06-24 11:11:07.601671
# Unit test for function validate_json
def test_validate_json():
    field = Field(type="string")
    content = '{"type": "string", "min_length": 1}'
    value, messages = validate_json(content, field)
    assert messages == [
        Message(
            text="Additional properties are not allowed ('min_length' was unexpected)",
            code="additional_property",
            position=Position(column_no=2, line_no=2, char_index=19),
        )
    ]
    assert value == "string"

# Generated at 2022-06-24 11:11:14.376145
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[1, 2, 3]") == ListToken([1, 2, 3], 0, 9, "[1, 2, 3]")
    assert tokenize_json("42") == ScalarToken(42, 0, 1, "42")
    assert tokenize_json("true") == ScalarToken(True, 1, 4, "true")
    assert tokenize_json("false") == ScalarToken(False, 0, 5, "false")



# Generated at 2022-06-24 11:11:24.709033
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    sep = (", ", ": ")
    decoder = _TokenizingDecoder(sep=sep)
    assert decoder.parse_float == float
    assert decoder.parse_int == int
    assert decoder.parse_constant is None
    assert decoder.strict == True
    assert decoder.parse_array == JSONDecoder.parse_array
    assert decoder.parse_object == JSONDecoder.parse_object
    assert decoder.parse_string == scanstring
    assert decoder.memo is None
    assert decoder.object_hook is None
    assert decoder.object_pairs_hook is None
    
    
# Test for method make_scanner()

# Generated at 2022-06-24 11:11:31.310249
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('"abc"')
    assert isinstance(token, ScalarToken)
    assert token.value == 'abc'

    token = tokenize_json('"abc",')
    assert token.value == 'abc'

    with pytest.raises(ParseError):
        tokenize_json('')

    with pytest.raises(ParseError):
        tokenize_json('  ')


# Generated at 2022-06-24 11:11:34.711686
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a":1}')
    assert isinstance(token, DictToken)
    assert len(token.children) == 1
    assert isinstance(token.children[0], (ScalarToken,))
    assert token.content == '{"a":1}'



# Generated at 2022-06-24 11:11:38.870857
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = JSONDecoder()
    assert decoder.parse_float('3.14') == 3.14
    assert decoder.parse_int('42') == 42
    assert decoder.strict == True


# Generated at 2022-06-24 11:11:42.590202
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder(content="") == JSONDecoder()
    assert _make_scanner(JSONDecoder(), "") == _make_scanner(
        _TokenizingDecoder(content=""), ""
    )

# Generated at 2022-06-24 11:11:45.978188
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = "{\"a\": 2, \"b\": [1, 2], \"c\": {\"d\": [\"hi \u2603\", \"yay\"]}}"
    token = tokenize_json(json_string)
    assert token.value == json.loads(json_string)

# Generated at 2022-06-24 11:11:54.263499
# Unit test for function validate_json
def test_validate_json():
    # validator field: a ScalarField with a min val
    validator1 = Field(type="integer", min_value=2)
    # validator field: a StringField with a max length
    validator2 = Field(type="string", max_length=3)
    # validator schema: a union of both the above fields
    validator3 = Schema(fields=[validator1, validator2], type="anyOf")

    # Case 1: Valid JSON content, validating against a Field
    json_content_valid = '{"age":25}'
    value_valid, errors_valid = validate_json(json_content_valid, validator1)
    assert errors_valid == []

    # Case 2: Valid JSON content, validating against a Schema

# Generated at 2022-06-24 11:11:58.749646
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer

    content = '{"the_text": "hello", "the_int": 5}'
    json_dict, errors = validate_json(content, {"the_text": String(), "the_int": Integer()})
    assert errors == []
    assert json_dict["the_text"] == "hello"
    assert json_dict["the_int"] == 5


# Generated at 2022-06-24 11:12:07.472139
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()
        age = String()

    def get_from_dict(dic, key, default=None):
        try:
            return dic[key]
        except KeyError:
            return default

    json_string = '{"name": "Tom", "age": "29"}'
    token = tokenize_json(json_string)
    value = token.value
    assert value['name'] == get_from_dict(value, 'name')
    assert value['age'] == get_from_dict(value, 'age')
    assert validate_with_positions(token, MySchema) == ({'name': 'Tom', 'age': '29'}, [])


# Generated at 2022-06-24 11:12:08.051473
# Unit test for function validate_json
def test_validate_json():
    pass


# Generated at 2022-06-24 11:12:10.409885
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="content_test")
    assert decoder.scan_once.__name__ == "_scan_once"


# Generated at 2022-06-24 11:12:12.024406
# Unit test for function validate_json
def test_validate_json():
    from . import schema_tests

    schema_tests.run_validate_json()


# Generated at 2022-06-24 11:12:18.425098
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == tokenize_json('{"x": 1}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('[]') == tokenize_json('[1]') == ListToken([], 0, 1, '[]')
    assert tokenize_json('[1, "2", true]') == ListToken([ScalarToken(1, 1, 1, '[1, "2", true]'), ScalarToken('2', 4, 6, '[1, "2", true]'), ScalarToken(True, 9, 13, '[1, "2", true]')], 0, 16, '[1, "2", true]')

# Generated at 2022-06-24 11:12:28.649633
# Unit test for function validate_json
def test_validate_json():
    # Test the valid case
    content = '''
    {
        "int_field": 1,
        "string_field": "testing",
        "list_field": ["one", "two", "three"]
    }'''
    validator = Schema(
        properties=[
            Field(type="integer"),
            Field(type="string"),
            Field(type="string", items={"type": "string"}),
        ]
    )
    value, error_messages = validate_json(content, validator)
    assert value == {
        "int_field": 1,
        "string_field": "testing",
        "list_field": ["one", "two", "three"],
    }
    assert len(error_messages) == 0

    # Test the invalid case

# Generated at 2022-06-24 11:12:35.501957
# Unit test for function validate_json
def test_validate_json():
    validator = Field(key="test",type="string",required=True)
    assert validate_json("{}",validator) == (None,[{"code": "required", "message": "This field is required.", "path": ["test"], "position": {"charIndex": 2, "columnNo": 3, "lineNo": 1}}])
    assert validate_json('"abc"',validator) == ("abc",[])
    # Check for numeric conversions
    assert validate_json("123",validator) == ("123",[])
    assert validate_json("\"123\"",validator) == ("123",[])

# Generated at 2022-06-24 11:12:43.237308
# Unit test for function tokenize_json
def test_tokenize_json():
    with open("./typesystem/tests/testdata/json_validator.json", "r") as f:
        content = f.read()
        token = tokenize_json(content)
        assert isinstance(token, DictToken)
        assert len(token.value) == 3
        assert token.value["type"] == "string"
        assert token.value["format"] == "date-time"
        assert isinstance(token.value["schema"], DictToken)
        assert token.value["schema"].value["name"] == "datetime"



# Generated at 2022-06-24 11:12:49.335611
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(b'{"Number": 1234, "Name": "Alice", "Pets": ["A", "B", "C"]}')
    assert token == DictToken({'Pets': ListToken(['A', 'B', 'C'], ), 'Number': 1234, 'Name': 'Alice'}, )


# Generated at 2022-06-24 11:12:57.692838
# Unit test for function validate_json
def test_validate_json():
    schema=Schema([
        Field(name="a", type="integer"),
        Field(name="b", type="dict"),
        Field(name="c", type="string")
    ])
    content={ "a": 1, "b": { "x": 1 }, "c": "1" }
    res=validate_json(content, schema)
    assert res==({'a': 1, 'b': {'x': 1}, 'c': '1'}, []) 

    content={ "a": 1, "b": { "x": 1 }, "c": 1 }
    _, errors=validate_json(content, schema)
    assert errors!=[]
    for error in errors:
        error_key="".join(error.key)

# Generated at 2022-06-24 11:13:07.198503
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.base import String
    from typesystem.tokenize.tokens import DictToken
    import sys
    import pytest
    from io import StringIO

    # Handle empty string.
    assert tokenize_json("") == {}

    # Handle invalid JSON.
    with pytest.raises(ParseError):
        tokenize_json('{"key": "value}')

    # Test the output.
    string = '{"key": "value"}'
    value = tokenize_json(string)
    assert value.start == 0
    assert value.end == len(string) - 1
    assert isinstance(value.value, dict)
    assert len(value.value) == 1
    assert list(value.value.keys())[0].start == 2

# Generated at 2022-06-24 11:13:18.706997
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("[]") == ListToken([], index=0, end=1, raw_content="[]")

# Generated at 2022-06-24 11:13:20.634929
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert callable(_TokenizingDecoder(1,2,3,args=4).scan_once)

# Generated at 2022-06-24 11:13:25.481052
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Create instance of class _TokenizingDecoder
    content = "Hello World!"
    tokenizing_decoder = _TokenizingDecoder(content=content)
    # Test for constructor of class _TokenizingDecoder
    assert tokenizing_decoder.scan_once == _make_scanner(
        tokenizing_decoder, content
    )


# Generated at 2022-06-24 11:13:34.350542
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Schema
    from typesystem.fields import StringField, DictField
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        example_field = StringField()

    class ExampleDictSchema(Schema):
        dict_schema = DictField(schema=ExampleSchema)

    # Validate invalid JSON
    try:
        value, error_messages = validate_json(
            b'{"example_field": "test", "example_field": "test"}', ExampleSchema
        )
        assert False
    except ParseError as error:
        assert error.position.line_no == 1
        assert error.position.column_no == 1
        assert error.position.char_index == 0

    # Validate valid JSON
    value, error_messages = validate

# Generated at 2022-06-24 11:13:41.286255
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"a": [1, 2, 3], "b": {"c": 4}}')
    assert token.value == {'a': [1, 2, 3], 'b': {'c': 4}}
    assert token.token_type == "dict"
    assert token.key_tokens == [("a", 0), ("b", 13)]
    assert token.start == 0
    assert token.end == 35
    assert token.source == '{"a": [1, 2, 3], "b": {"c": 4}}'



# Generated at 2022-06-24 11:13:53.703092
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:14:01.571225
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(properties={"a": {"type": "string"}})
    content = '{"a":1}'
    result, error_messages = validate_json(content, schema)
    assert result is None
    assert len(error_messages) == 1
    assert error_messages[0]["text"] == "Failed to match 'a' against 'string'."
    assert error_messages[0]["code"] == "not_of_type"
    assert error_messages[0]["position"].__dict__ == {"line_no": 1, "column_no": 4, "char_index": 4}

    content = '{"a":"b"}'
    result, error_messages = validate_json(content, schema)
    assert result == {"a": "b"}

# Generated at 2022-06-24 11:14:04.471411
# Unit test for function tokenize_json
def test_tokenize_json():
    input = '{"foo": "bar"}'
    expected = {'foo': 'bar'}
    result = tokenize_json(input)
    assert result.json() == expected



# Generated at 2022-06-24 11:14:15.461467
# Unit test for function validate_json
def test_validate_json():
    import pytest
    class TestSchema(Schema):
        name = 'test'
        fields = [
            Field(name='name', type='string'),
            Field(name='age', type='integer'),
            Field(name='address', type='json'),
        ]
    validator = TestSchema()
    json_string = '{"name": "Yihui", "age": "24", "address": "123" }'
    value, error_messages = validate_json(json_string, validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == 'type_mismatch'
    assert error_messages[0].position.char_index == 5

# Generated at 2022-06-24 11:14:20.802831
# Unit test for function tokenize_json
def test_tokenize_json():
    content = "{'a': 'b'}"
    token = tokenize_json(content)
    assert isinstance(token, DictToken)
    assert token.value == {'a': 'b'}
    assert token.start == 0
    assert token.end == len(content)
    assert token.content == content

# Generated at 2022-06-24 11:14:28.136829
# Unit test for function validate_json
def test_validate_json():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "is_alive": {"type": "boolean"},
        },
    }

# Generated at 2022-06-24 11:14:39.252248
# Unit test for function validate_json
def test_validate_json():
    import sys, os
    sys.path.append(".")
    sys.path.append("..")
    import json
    import numpy as np
    from typing import List, Union, Optional, Any
    from typesystem import Schema, fields, validate
    from typesystem.schemas.base_schema import message, convert_value
    from typesystem.schemas.base_schema import _is_sequence, _is_mapping, _is_scalar
    from typesystem.schemas.base_schema import _is_sequence_of_scalars, _is_mapping_of_scalars
    from typesystem.schemas.base_schema import _is_non_sequence_of_scalars, _is_non_mapping_of_scalars

# Generated at 2022-06-24 11:14:40.436808
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    actual = _TokenizingDecoder(content='test')
    assert actual


# Generated at 2022-06-24 11:14:43.266303
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    json.dumps("")
    json.dump("")
    json.dumps("", indent=4)
    json.dump("", indent=4)


# Generated at 2022-06-24 11:14:45.808349
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    q = _TokenizingDecoder(content="mycontent")
    assert type(q.scan_once) == _make_scanner.__call__.__func__

# Generated at 2022-06-24 11:14:52.165876
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
      "name": "test_name",
      "description": "test_description",
      "fields": [
        {
          "name": "email",
          "description": "email field",
          "type": "string"
        }
      ]
    }
    """
    token = tokenize_json(content)
    assert type(token) == DictToken

# Generated at 2022-06-24 11:14:55.245338
# Unit test for function tokenize_json
def test_tokenize_json():
    raw_content = '{"name": "Bob"}'
    token = tokenize_json(raw_content)
    assert token == {'name': 'Bob'}



# Generated at 2022-06-24 11:14:59.082544
# Unit test for function tokenize_json
def test_tokenize_json():
    result = tokenize_json(b'{"a":1,"b":2,}')
    assert isinstance(result,DictToken)
    assert result.value == {'a':1,'b':2}
    assert result.start == 0
    assert result.end == 15

    result = tokenize_json(b'[1,2,3]')
    assert isinstance(result,ListToken)
    assert result.value == [1,2,3]

# Generated at 2022-06-24 11:15:10.647629
# Unit test for function validate_json
def test_validate_json():
    """
    Test to validate the function validate_json for the following
    1. Valid json file
    2. Invalid json file
    3. Json file without content
    4. Invalid file for the given type(in this case string)
    """
    # Test 1: Valid Json File
    content = '{"name":"ABC"}'
    validator = {"type": "object", "properties": {"name": {"type": "string"}}}
    value, error_messages = validate_json(content,validator)
    assert error_messages == []

    # Test 2: Invalid Json File with trailing comma
    content = '{"name":"ABC",}'
    validator = {"type": "object", "properties": {"name": {"type": "string"}}}
    #value, error_messages = validate_json(content,validator)
   

# Generated at 2022-06-24 11:15:18.790510
# Unit test for function validate_json
def test_validate_json():
    try:
        validate_json(b'{"a": 1}', validator={"a": int})
    except TypeError as e:
        assert e.__str__() == "Validators must be a Field or Schema class."
    except BaseException:
        assert False
    else:
        assert True

    class MySchema(Schema):
        a = int
        b = float
        c = "hello"

    try:
        validate_json(b'{"a": 1}', validator=MySchema())
    except ValueError as e:
        assert e.__str__() == "MySchema.b: This field is required."
    except BaseException:
        assert False
    else:
        assert True


# Generated at 2022-06-24 11:15:22.889340
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String

    assert(
        validate_json(
            content='{"hello": "world"}',
            validator=String(),
        ) == (
            "world",
            []
        )
    )

# Generated at 2022-06-24 11:15:24.919079
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder.__init__ is not JSONDecoder.__init__

# Generated at 2022-06-24 11:15:33.314387
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test_content"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once("test_string", 0)[1] == len("test_string")
    assert decoder.scan_once("test_string, more_test_string", 0)[1] == len("test_string")
    assert (
        decoder.scan_once("test_string, more_test_string", 6)[1]
        == len("more_test_string")
    )
    assert decoder.scan_once("{'a': 1}", 0)[1] == 4


# Generated at 2022-06-24 11:15:43.041820
# Unit test for function validate_json
def test_validate_json():
    content = '{"qty": 2, "price": 5.99, "name": "toothbrush"}'
    validator = {
        "qty": int,
        "price": float,
        "name": str,
        "currency": str,
        "value": float,
    }

    value, error_messages = validate_json(content=content, validator=validator)

    expected_value = {"qty": 2, "price": 5.99, "name": "toothbrush"}

    # The "currency" and "value" fields should not be present in the value
    # returned by the validator since they are not present in the content.
    assert value == expected_value
    assert len(error_messages) == 2
    assert error_messages[0].text == "Missing 'currency': field is required."


# Generated at 2022-06-24 11:15:52.285526
# Unit test for function tokenize_json
def test_tokenize_json():
    tests = [
        ('{"foo":1,"bar":"baz","nest":{"quux":123}}',
         {'foo': 1, 'bar': 'baz', 'nest': {'quux': 123}}),
        ('[["foo",1],{"bar":"baz","quux":123}]',
         [['foo', 1], {'bar': 'baz', 'quux': 123}]),
        ('{"foo":1,"bar":"baz","nest":{"quux":123}} \n {"foo":1,"bar":"baz","nest":{"quux":123}}',
         {'foo': 1, 'bar': 'baz', 'nest': {'quux': 123}})
    ]
    for test in tests:
        assert tokenize_json(test[0]) == test[1]

# Unit test

# Generated at 2022-06-24 11:15:58.418602
# Unit test for function tokenize_json
def test_tokenize_json():
    message = tokenize_json('{"name": "Foo"}')
    assert message == {
        "name": {
            "type": "scalar",
            "line_no": 1,
            "column_no": 10,
            "char_index": 9,
            "value": "Foo",
            "value_type": str,
        }
    }


# Generated at 2022-06-24 11:16:01.167289
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="")
    assert decoder.memo == {}
    assert decoder.scan_once != None
    assert decoder.strict == True

# Generated at 2022-06-24 11:16:02.853862
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "Hello world"
    _TokenizingDecoder(content=content)


# Generated at 2022-06-24 11:16:12.995047
# Unit test for function validate_json
def test_validate_json():
    """
    >>> json_str = '{"key1": "value1"}'
    >>> val = validate_json(json_str, {"key1": str})
    >>> val[0]
    {'key1': 'value1'}

    Missing required key
    >>> val = validate_json("{}", {"key1": str.as_required()})
    >>> len(val[1])
    1

    Test invalid JSON string
    >>> val = validate_json("{'key1': 'value1'}", {"key1": str})
    >>> isinstance(val[1][0], ParseError)
    True

    Test validation errors
    >>> val = validate_json(json_str, {"key1": int})
    >>> isinstance(val[1][0], ValidationError)
    True

    """


# Generated at 2022-06-24 11:16:17.846102
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"key": "value"}')
    assert token.token_type == "dict"
    assert isinstance(token, Token)
    assert token.start_pos.line_no == 1
    assert token.start_pos.column_no == 1
    assert token.start_pos.char_index == 0
    assert token.end_pos.line_no == 1
    assert token.end_pos.column_no == 15
    assert token.end_pos.char_index == 14

# Generated at 2022-06-24 11:16:21.131910
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(object_hook=lambda x: x, content='test')
    assert decoder.scan_once('test', 0)[0].value == 'test'

# Generated at 2022-06-24 11:16:24.282789
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder1 = _TokenizingDecoder(content = '{"name": "dog"}')
    decoder2 = _TokenizingDecoder(content = '{"name": "dog"}')
    assert decoder1.scan_once == decoder2.scan_once

# Generated at 2022-06-24 11:16:33.190350
# Unit test for function validate_json
def test_validate_json():
    """
    Test basic functionality of function validate_json,
    without having to worry about implementation details of tokenize_json.
    """
    import typesystem
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Union

    class Test(Schema):
        name = String()
        name_age = String(name="age")
        age = Integer()

    schema = Test()
    json_str = '{ "name": "Harry", "age": "17" }'
    result = validate_json(json_str, schema)
    assert isinstance(result, tuple)
    assert len(result) == 2
    value, errors = result
    assert isinstance(value, dict)
    assert value == {"name": "Harry", "name_age": "17", "age": 17}

# Generated at 2022-06-24 11:16:43.916545
# Unit test for function validate_json
def test_validate_json():

    schema = typesystem.Schema(
        {
            "username": typesystem.String(),
            "password": typesystem.String(),
            "admin_info": typesystem.Dict(
                {
                    "year": typesystem.String(),
                    "salary": typesystem.String(),
                    "skills": typesystem.List(items=typesystem.String()),
                }
            ),
        }
    )

    # Check valid data
    value, errs = validate_json(
        content='{"username": "a", "password": "b", "admin_info": {"year": "c", "salary": "d", "skills": ["e", "f"]}}',
        validator=schema,
    )
    assert not errs

# Generated at 2022-06-24 11:16:50.780398
# Unit test for function validate_json
def test_validate_json():
    content = """
{
    "name": "Jane Doe",
    "age": 32,
    "identifications": [
        {
            "file_reference": "file-reference-1",
            "file_url": "file-url-1",
            "id_type": "driver_license"
        },
        {
            "file_reference": "file-reference-2",
            "file_url": "file-url-2",
            "id_type": "passport"
        }
    ]
}
"""
    fields = {"name": "string", "age": "integer", "identifications": "list"}

    validator = Schema(fields=fields)


# Generated at 2022-06-24 11:17:01.390557
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {ScalarToken("foo"): ScalarToken("bar")}, 0, 13, '{"foo": "bar"}'
    )

    assert tokenize_json('[1, 2, 3]') == ListToken(
        [ScalarToken(1), ScalarToken(2), ScalarToken(3)], 0, 7, '[1, 2, 3]'
    )

    assert tokenize_json('42') == ScalarToken(42, 0, 1, '42')
    assert tokenize_json('1.0') == ScalarToken(1.0, 0, 3, '1.0')
    assert tokenize_json('1.0e5') == ScalarToken(1.0e5, 0, 5, '1.0e5')

# Generated at 2022-06-24 11:17:11.923756
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test empty string
    try:
        tokenize_json("")
    except ParseError as exc:
        assert exc.code == "no_content"
    else:
        assert False

    # Test basic, valid JSON
    try:
        token = tokenize_json('{"foo": "bar"}')
    except ParseError as exc:
        assert not exc
    else:
        assert isinstance(token, DictToken)
        assert token["foo"] == "bar"

    # Test invalid JSON
    try:
        tokenize_json('{"foo": "bar"')
    except ParseError as exc:

        # Check that error message has line number and column number
        assert "line" in exc.text.lower()
        assert "column" in exc.text.lower()
        assert exc.code == "parse_error"

# Generated at 2022-06-24 11:17:22.382884
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"field": "test","field_two": 2}'
    token = tokenize_json(content)
    assert token == DictToken(
        {
            ScalarToken("field", 1, 5, content): ScalarToken(
                "test", 11, 15, content
            ),
            ScalarToken("field_two", 16, 24, content): ScalarToken(
                2, 26, 27, content
            ),
        },
        0,
        28,
        content,
    )

    content = '["field", "test","field_two", 2]'
    token = tokenize_json(content)

# Generated at 2022-06-24 11:17:28.284039
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Array, Integer, String

    schema = Array(
        items=Integer(), max_items=3, min_items=3,
    )
    json_string = "[1, 2, 3]"
    json_string_invalid = "[1, 2]"
    value, error_messages = validate_json(json_string, schema)
    assert value == [1, 2, 3]
    assert not error_messages

    _, error_messages = validate_json(json_string_invalid, schema)
    assert len(error_messages) == 1
    assert error_messages[0].code == 'array_min_items'
    assert error_messages[0].position.column_no == 2
    assert error_messages[0].position.line_no == 1

# Generated at 2022-06-24 11:17:30.116145
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    TODO: write unit test for function tokenize_json
    """
    pass


# Generated at 2022-06-24 11:17:40.667352
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(fields=[
        Field(name="number", type="number"),
        Field(name="string", type="string"),
        Field(name="integer", type="integer"),
        Field(name="boolean", type="boolean"),
        Field(name="object", type="object"),
        Field(name="list", type="array"),
        Field(name="null", type="null")
    ])

    data = {
        "number": "1.0",
        "string": "hello",
        "integer": 1,
        "boolean": True,
        "object": {},
        "list": [],
        "null": None
    }


# Generated at 2022-06-24 11:17:45.945063
# Unit test for function validate_json
def test_validate_json():
    assert validate_json('{"a": "a"}', {"a": str}) == ({'a': 'a'}, [])
    assert validate_json('{"a": 1}', {"a": str}) == (None, ['"a must be of type str."'])
    assert validate_json('{}', {"a": str}) == (None, ['"a is required."'])
    assert validate_json('{"a": 1}', {"a": int}) == ({'a': 1}, [])



# Generated at 2022-06-24 11:17:56.379558
# Unit test for function validate_json
def test_validate_json():
    """
    Utilize validate_json to successfully validate valid JSON
    """

    # Define test JSON content
    content = b'''
    {
        "name": "jane doe",
        "age": 33,
        "favorite_colors": ["blue", "red", "green"]
    }
    '''

    # Define test validator
    class TestSchema(Schema):
        name = Field(type="string", max_length=30)
        age = Field(type="integer", minimum=0, maximum=100)
        favorite_colors = Field(type="array", items=Field(type="string"))

    # Test for successful validation
    value, error_messages = validate_json(content, TestSchema)
    assert error_messages == []

# Generated at 2022-06-24 11:18:03.930764
# Unit test for function validate_json
def test_validate_json():
    test_content = '{"email": "bob@example.com"}'
    test_validator = Schema({"email": "email"})

    result = validate_json(test_content, test_validator)
    assert result == ({'email': 'bob@example.com'}, None)
    assert isinstance(result, typing.Tuple)
    assert isinstance(result[0], dict)
    assert (isinstance(result[1], list)
            or isinstance(result[1], typing.List)
            or result[1] == None)

# Generated at 2022-06-24 11:18:14.427304
# Unit test for function validate_json
def test_validate_json():
    def test_validate_json_with_schema(
        content: str,
        validator: Schema,
        error_messages: typing.List[Message],
    ) -> None:
        value, messages = validate_json(content, validator)
        assert len(messages) == len(error_messages)
        for message, expected_message in zip(messages, error_messages):
            assert message == expected_message
        if not messages:
            assert value == VALID_DATA

    def test_validate_json_exception(
        content: str,
        validator: Schema,
        code: str,
        position: Position,
        message: str,
    ) -> None:
        with pytest.raises(ValidationError) as excinfo:
            validate_json(content, validator)

# Generated at 2022-06-24 11:18:21.247675
# Unit test for function validate_json
def test_validate_json():
    schema = Schema(
        {
            "first_name": Field(type="string")(),
            "last_name": Field(type="string")(),
            "age": Field(type="number")(),
        }
    )
    content = """{"first_name":"Brian", "last_name":"Okken", "age":40}"""
    # Both value and errors should return None
    value, errors = validate_json(content=content, validator=schema)

# Generated at 2022-06-24 11:18:31.142022
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    This function tests the tokenize_json function
    """
    with pytest.raises(ParseError):
        # Testing empty string
        tokenize_json('')
    with pytest.raises(ParseError):
        # Testing string of whitespace
        tokenize_json(' ')
    # Testing simple empty json object
    token = tokenize_json('{}')
    assert isinstance(token, DictToken)
    # Testing simple json object with one property
    token = tokenize_json('{"prop": "data"}')
    assert isinstance(token, DictToken)
    assert token[ScalarToken('prop')] == ScalarToken('data')
    # Testing json parsing with a list of values
    token = tokenize_json('["data1", "data2"]')

# Generated at 2022-06-24 11:18:41.054015
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{}') == DictToken({}, 0, 1, '{}')
    assert tokenize_json('{"boo": 1}') == DictToken(
        {"boo": ScalarToken(1, 7, 7, '{"boo": 1}')}, 0, 12,
        '{"boo": 1}'
    )
    assert tokenize_json('["foo", "bar"]') == ListToken(
        [
            ScalarToken('foo', 2, 5, '["foo", "bar"]'),
            ScalarToken('bar', 8, 11, '["foo", "bar"]'),
        ],
        0, 14, '["foo", "bar"]'
    )

# Generated at 2022-06-24 11:18:41.609622
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder()



# Generated at 2022-06-24 11:18:44.687562
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"one":2}'
    assert tokenize_json(content) == DictToken(
        {ScalarToken('one', 1, 3, content): ScalarToken(2, 7, 7, content)}, 0, 9, content
    )


# Generated at 2022-06-24 11:18:55.295638
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"key": "value"}') == DictToken({ScalarToken('key', 0, 8): ScalarToken('value', 13, 23)}, 0, 23, '{"key": "value"}')
    assert tokenize_json('{"key": null}') == DictToken({ScalarToken('key', 0, 8): ScalarToken(None, 13, 18)}, 0, 18, '{"key": null}')
    assert tokenize_json('{"key": true}') == DictToken({ScalarToken('key', 0, 8): ScalarToken(True, 13, 19)}, 0, 19, '{"key": true}')

# Generated at 2022-06-24 11:19:05.331240
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test valid JSON types
    json_dict = "{\"foo\":\"bar\"}"
    json_list = "[\"foo\",\"bar\"]"
    json_str = "\"bar\""
    json_num = "4.25"
    json_bool_true = "true"
    json_bool_false = "false"
    json_null = "null"
    # Test valid JSON string
    tokens = tokenize_json(json_dict)
    assert isinstance(tokens, Message) == True
    assert tokens.kind == Token.DICT_KIND
    assert len(tokens) == 1
    assert tokens["foo"].kind == Token.SCALAR_KIND
    assert tokens["foo"] == "bar"
    # Test valid JSON list
    tokens = tokenize_json(json_list)

# Generated at 2022-06-24 11:19:14.901905
# Unit test for function tokenize_json
def test_tokenize_json():
    def _test_json(json):
        tokens = tokenize_json(json)
        assert tokens
    # Denotes a Python2-style `unicode` object.
    _u = type(u"")
    # Denotes a Python3-style `str` object.
    _s = type("")

    # String
    _test_json(u'"foo"')
    _test_json(_u("\"\\u00A0\""))
    _test_json(_u("\"\\ubcf4\""))
    _test_json(_u("\"\\U0001D11E\""))

    # Numbers
    _test_json(u"0")
    _test_json(u"-1")
    _test_json(u"1.1")
    _test_json(u"1.0e10")
    _test_

# Generated at 2022-06-24 11:19:25.823368
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String, Dict, List, Boolean, Integer, Float
    from typesystem.tokenize.tokens import DictToken, ListToken, ScalarToken

    class TestSchema(Schema):
        text = String()
        num = Float()
        bool = Boolean()
        list = List(Integer())
        dict = Dict(
            {
                "id": Integer(),
                "text": String(),
                "bool": Boolean(),
                "list": List(String()),
            }
        )

    schema = TestSchema()


# Generated at 2022-06-24 11:19:28.245815
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="hi")
    assert decoder.scan_once
    assert decoder.parse_int, "Expect parse_int to be defined"

# Generated at 2022-06-24 11:19:31.591617
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content='{"f": "p" }')
    assert decoder.parse_array is not None

# Generated at 2022-06-24 11:19:40.519103
# Unit test for function tokenize_json
def test_tokenize_json():
    assert (
        {
            "key1": "value1",
            "key2": "value2",
            "key3": 100,
            "key4": False,
            "key5": None,
            "key6": [1, 2, 3, 4, 5],
            "key7": {},
            "key8": [],
        },
        [],
    ) == validate_json(
        """
        {
            "key1": "value1",
            "key2": "value2",
            "key3": 100,
            "key4": false,
            "key5": null,
            "key6": [1, 2, 3, 4, 5],
            "key7": {},
            "key8": []
        }
        """,
        Schema,
    )

# Generated at 2022-06-24 11:19:46.627334
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json('{"foo": "bar"}') == DictToken(
        {"foo": ScalarToken("bar", 4, 9, '{"foo": "bar"}')}, 0, 12, '{"foo": "bar"}'
    )
    assert tokenize_json('{"foo": 42}') == DictToken(
        {"foo": ScalarToken(42, 4, 7, '{"foo": 42}')}, 0, 10, '{"foo": 42}'
    )
    # Test error messaging
    try:
        tokenize_json("")
    except ParseError as error:
        assert error.position == Position(1, 1, 0)
        assert error.code == "no_content"

# Generated at 2022-06-24 11:19:49.183279
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"test": 1}'
    decoder = _TokenizingDecoder(content=content)
    assert isinstance(decoder, JSONDecoder)


# Generated at 2022-06-24 11:19:53.571850
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class Test(JSONDecoder):
        pass
    _TokenizingDecoder(object_hook=Test().object_hook, parse_float=Test().parse_float, parse_int=Test().parse_int, parse_constant=Test().parse_constant, strict=Test().strict, object_pairs_hook=Test().object_pairs_hook)

# Generated at 2022-06-24 11:19:58.346447
# Unit test for function validate_json
def test_validate_json():
    content_list = ['{"field": 1234}', '{"field": 1234.5678}', '{"field": "1234"}']
    for content in content_list:
        value, error_messages = validate_json(content=content, validator=Field(type="integer"))
        assert value == {"field": 1234}
        assert error_messages == []

if __name__ == "__main__":
    test_validate_json()

# Generated at 2022-06-24 11:20:01.921956
# Unit test for function tokenize_json
def test_tokenize_json():
    """ Unit tests for tokenize_json"""
    test_value = '{"key": "value"}'
    test_result = tokenize_json(test_value)
    assert test_result.start == 0
    assert test_result.end == 16


# Generated at 2022-06-24 11:20:07.370600
# Unit test for function validate_json
def test_validate_json():
    # Assert function validate_json return a two-tuple of (value, error_messages)
    assert len(validate_json("{'key': 'value'}", str)) == 2
    # Assert function validate_json return a two-tuple of (None, None)
    assert validate_json("{'key': 'value'}", str) == (None, None)



# Generated at 2022-06-24 11:20:16.446003
# Unit test for function validate_json
def test_validate_json():
    # Test a successful validation.
    content = '{"a": "b"}'
    validator = Schema({
        "a": String()
    })
    value, errors = validate_json(content, validator)
    assert value == {"a": "b"}
    assert errors == []

    # Test a type validation failure.
    content = '{"a": "b"}'
    validator = Schema({
        "a": Integer()
    })
    value, errors = validate_json(content, validator)
    assert value is None
    assert len(errors) == 1

    error = errors[0]
    assert isinstance(error, ValidationError)
    assert error.code == "invalid_type"
    assert error.text == "Expected an integer value."
    assert error.position.column_no == 8
   

# Generated at 2022-06-24 11:20:27.301600
# Unit test for function validate_json
def test_validate_json():
    class PetSchema(Schema):
        id = Field(type=int)
        name = Field(type=str)

    class StoreSchema(Schema):
        id = Field(type=int)
        pets = Field(type="array", items=PetSchema)

    data = r'{"id": 5, "pets": [{"id": 1, "name": "Bob"}, {"id": 2, "name": null}]}'
    value, errors = validate_json(content=data, validator=StoreSchema)
    assert value == {"id": 5, "pets": [{"id": 1, "name": "Bob"}, {"id": 2, "name": None}]}

# Generated at 2022-06-24 11:20:31.118400
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "test"
    decoder = _TokenizingDecoder(content=content)
    scan_once = decoder.scan_once

    assert str(scan_once('"test"', 0)[0].value) == "test"



# Generated at 2022-06-24 11:20:32.745754
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass



# Generated at 2022-06-24 11:20:40.336302
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    import json

    schema = Schema({"name": String, "age": Integer})
    jsn = '{"name": "Jim", "age": 99}'
    content = json.dumps(jsn)
    (value, error_messages) = validate_json(content, schema)
    assert value == {"name": "Jim", "age": 99}
    assert not error_messages
    print("test_validate_json passed")

if __name__ == '__main__':
    test_validate_json()

# Generated at 2022-06-24 11:20:47.312446
# Unit test for function validate_json
def test_validate_json():
    content = """{"foo": "bar", "number": 123, "null": null, "true": true, "false": false}"""
    class TestSchema(Schema):
        foo = Field(type="string")
        number = Field(type="integer")
        null = Field(type="null")
        true = Field(type="boolean")
        false = Field(type="boolean")
        extra = Field(type="string")
    value, messages = validate_json(content, validator=TestSchema)
    assert messages == [
        {
            "type": "missing",
            "position": {"column_no": 3, "char_index": 27, "line_no": 1},
            "text": "Missing attribute `extra`.",
            "code": "missing",
        }
    ]