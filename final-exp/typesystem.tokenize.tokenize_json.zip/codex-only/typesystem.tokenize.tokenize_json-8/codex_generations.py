

# Generated at 2022-06-24 11:10:45.380720
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder().scan_once, typing.Callable)
    assert isinstance(_TokenizingDecoder().parse_int, typing.Callable)
    assert isinstance(_TokenizingDecoder().parse_string, typing.Callable)
    assert isinstance(_TokenizingDecoder().parse_array, typing.Callable)



# Generated at 2022-06-24 11:10:46.421884
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content={})
    assert type(decoder.content) is dict


# Generated at 2022-06-24 11:10:48.185807
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="[1, \"foo\"]")
    assert isinstance(decoder, _TokenizingDecoder)

# Generated at 2022-06-24 11:10:56.122137
# Unit test for function tokenize_json
def test_tokenize_json():
    """Unit test for function tokenize_json."""

    # Valid JSON strings
    assert tokenize_json('""') == ScalarToken('', 0, 1, '""')
    assert tokenize_json('"test"') == ScalarToken('test', 0, 5, '"test"')
    assert tokenize_json('true') == ScalarToken(True, 0, 4, 'true')
    assert tokenize_json('false') == ScalarToken(False, 0, 5, 'false')
    assert tokenize_json('null') == ScalarToken(None, 0, 4, 'null')
    assert tokenize_json('1') == ScalarToken(1, 0, 1, '1')
    assert tokenize_json('1.23') == ScalarToken(1.23, 0, 4, '1.23')
    assert token

# Generated at 2022-06-24 11:10:59.782492
# Unit test for function validate_json
def test_validate_json():
    content = '{"foo": "bar"}'
    validator = Schema({"foo": Field()})
    value, error_messages = validate_json(content, validator)
    assert error_messages == []

# Generated at 2022-06-24 11:11:06.572804
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"Foo":"Baar","Bar":"Foo","Baar":true}'
    decoder = _TokenizingDecoder(content=content)
    try:
        decoder.decode(content)
    except JSONDecodeError as exc:
        # Handle cases that result in a JSON parse error.
        position = Position(column_no=exc.colno, line_no=exc.lineno, char_index=exc.pos)
        raise ParseError(text=exc.msg + ".", code="parse_error", position=position)

test__TokenizingDecoder()

# Generated at 2022-06-24 11:11:09.552125
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    d = _TokenizingDecoder()
    assert isinstance(d, JSONDecoder)
    assert d.strict == True
    assert isinstance(d.scan_once, typing.Callable)


# Generated at 2022-06-24 11:11:13.365540
# Unit test for function tokenize_json
def test_tokenize_json():

    # Test empty string error
    with pytest.raises(ParseError) as error:
        tokenize_json("")

    expected_message = "No content."
    assert expected_message == str(error.value)
    assert "no_content" == error.value.code


# Generated at 2022-06-24 11:11:24.837957
# Unit test for function validate_json
def test_validate_json():
    schema = Schema.of({
        "bool": Field(bool),
        "int": Field(int),
        "float": Field(float),
        "str": Field(str),
        "none": Field(None),
        "list": Field(list),
        "object": Field(dict)
    })
    content = '{"bool": true, "int": 666, "float": 6.66, "str": "666", "none": null, "list": [], "object": {}}'
    value, messages = validate_json(content, schema)
    assert not messages
    assert value == {
        "bool": True,
        "int": 666,
        "float": 6.66,
        "str": "666",
        "none": None,
        "list": [],
        "object": {}
    }
   

# Generated at 2022-06-24 11:11:32.658327
# Unit test for function tokenize_json
def test_tokenize_json():
    tokens = tokenize_json(json_string)
    assert isinstance(tokens,DictToken)
    assert isinstance(tokens.value,dict)

# Generated at 2022-06-24 11:11:39.939506
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    value, errors = validate_json(b'{"hello":"world"}', validator)
    assert value is None
    assert len(errors) == 1
    assert type(errors[0]) == ValidationError
    assert [{'type': 'string', 'required': True}] == errors[0].meta['allowed_types']
    assert [1, 1, 1, 1] == errors[0].meta['positions']
    value, errors = validate_json(b'"hello"', validator)
    assert errors == []
    assert value == "hello"

    class SimpleSchema(Schema):
        text = Field(type="string")

    value, errors = validate_json(b'{"hello":"world"}', SimpleSchema)
    assert len(errors) == 1

# Generated at 2022-06-24 11:11:44.896011
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = json.dumps({"name": "sam", "age": 3})
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once == _make_scanner(decoder, content)

# Generated at 2022-06-24 11:11:53.350463
# Unit test for function tokenize_json
def test_tokenize_json():
    correct_validator = Field(type="string")
    correct_value = "val"
    wrong_validator = Field(type="boolean")
    wrong_value = True

    content = '"val"'
    value, error_messages = validate_json(content, correct_validator)
    assert error_messages == []
    assert value == correct_value

    value, error_messages = validate_json(content, wrong_validator)
    assert error_messages != []
    assert value == wrong_value

    content = '{"a": 5}'
    value, error_messages = validate_json(content, {"a": Field(type="number")})
    assert error_messages == []
    assert value == {"a": 5}

    content = '{"a": "b"}'
    value, error_messages

# Generated at 2022-06-24 11:11:58.684425
# Unit test for function validate_json
def test_validate_json():
    simple_schema = Schema(fields={"a": int})

    # invalid
    value, errors = validate_json('{"a": "1"}', simple_schema)
    assert errors[0].index == 2

    # valid
    value, errors = validate_json('{"a": 1}', simple_schema)
    assert errors[0].index == -1


# Generated at 2022-06-24 11:12:06.550457
# Unit test for function tokenize_json
def test_tokenize_json():
    # Arrange
    content = '{"foo": [1, 2, 3, 4, 5], "bar": {"foo": "bar", "baz": "qux"}}'
    expected = {
        "type": "dict",
        "children": {
            "foo": {"type": "list", "children": [1, 2, 3, 4, 5]},
            "bar": {
                "type": "dict",
                "children": {"foo": "bar", "baz": "qux"},
            },
        },
        "position": {"char_index": 0},
    }

    # Act
    actual = tokenize_json(content)

    # Assert
    assert actual == expected



# Generated at 2022-06-24 11:12:13.951344
# Unit test for function validate_json
def test_validate_json():
    # Passing test
    field = Field(type="string")
    value, error_messages = validate_json(b'"hello"', validator=field)
    assert value == "hello"
    assert error_messages.data == []

    # Parse Error test
    field = Field(type="string")
    with pytest.raises(ParseError):
        value, error_messages = validate_json(b'"hello', validator=field)

    # Validation Error test
    field = Field(type="integer")
    with pytest.raises(ValidationError):
        value, error_messages = validate_json(b'"hello"', validator=field)

# Generated at 2022-06-24 11:12:17.657818
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    value, error_messages = validate_json(content=b'{"valid":true, "invalid":1}', validator=Schema())
    assert not error_messages
    assert value == {"valid": True, "invalid": 1}
    assert error_messages == []

# Generated at 2022-06-24 11:12:23.990776
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    decoder = _TokenizingDecoder()
    assert(decoder.decode('[1, 2, 3]') == [1, 2, 3])
    assert(decoder.decode('[1, 2, 3]') == [1, 2, 3])
    assert(decoder.decode('[1, 2, 3]') == [1, 2, 3])
    assert(decoder.decode('[1, 2, 3]') == [1, 2, 3])

# Generated at 2022-06-24 11:12:33.183759
# Unit test for function tokenize_json
def test_tokenize_json():

    import json
    import collections
    import random

    # Heavily modified version of https://stackoverflow.com/a/10566666/3458302

    def compare_recursive(o1: typing.Union[int, str, list, dict, tuple], o2: typing.Union[int, str, list, dict, tuple]) -> None:
        if isinstance(o1, int) and isinstance(o2, ScalarToken):
            assert o1 == o2.value
            assert o2.start == o2.end
            assert o2.token_type is int
        elif isinstance(o1, (float, bool)) and isinstance(o2, ScalarToken):
            assert o1 == o2.value
            assert o2.start == o2.end

# Generated at 2022-06-24 11:12:33.612503
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    pass

# Generated at 2022-06-24 11:12:41.114815
# Unit test for function tokenize_json
def test_tokenize_json():
    # Test a generic object
    obj = '{ "name": "Jane", "age": 42, "favColors": ["blue", "green", "orange"] }'
    tokens = tokenize_json(obj)
    assert tokens.field_tokens[0].value.key == "name"
    assert tokens.field_tokens[0].value.value == "Jane"
    assert tokens.field_tokens[1].value.key == "age"
    assert tokens.field_tokens[1].value.value == 42
    assert tokens.field_tokens[2].value.key == "favColors"
    assert tokens.field_tokens[2].value.value[0].value == "blue"

# Generated at 2022-06-24 11:12:46.882953
# Unit test for function validate_json
def test_validate_json():
    token = tokenize_json('{"name":"juno"}')
    # Test a valid schema
    schema = Schema({
        "name": Str()
    })
    data, errors = validate_with_positions(token=token, validator=schema)
    assert data["name"] == "juno"
    assert errors == []
    # Test an invalid schema
    schema = Schema({
        "name": Int()
    })
    data, errors = validate_with_positions(token=token, validator=schema)
    assert errors == ['{"name": "juno"} is not of type u\'integer\'']

# Generated at 2022-06-24 11:12:51.629382
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"test": {"name": "test", "price": 1.0, "active": true}}'
    token = tokenize_json(content)
    assert token.value['test']['name'] == 'test'
    assert token.value['test']['active'] is True


# Generated at 2022-06-24 11:13:02.301506
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{
        "field1": 1,
        "list": [1, 2, 3, 4],
        "dict": {
            "key1": "value1",
            "null": null,
            "true": true,
            "false": false,
            "scientific": 2.3e3
        }
    }"""
    token = tokenize_json(content)
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)

# Generated at 2022-06-24 11:13:07.125406
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # Checking if the tokenization is done properly
    content = """{"firstName": "John", "lastName": "Smith", "age": 25}"""
    decoder = _TokenizingDecoder(content=content)
    token = decoder.scan_once(content, 0)[0]

    assert isinstance(token, Token)
    assert token.start == 0
    assert token.end == len(content)-1



# Generated at 2022-06-24 11:13:10.497264
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert isinstance(_TokenizingDecoder.__init__, type(object.__init__))
    assert _TokenizingDecoder.scan_once
    assert _TokenizingDecoder.parse_object


# Generated at 2022-06-24 11:13:15.889105
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = '{"name": "value", "number": 25, "true": true, "false": false, "null": null, "object": {"level": 1}, "array": [1,2,3,4]}'
    decoder = _TokenizingDecoder(content=content)
    assert decoder is not None


# Generated at 2022-06-24 11:13:21.117982
# Unit test for function validate_json
def test_validate_json():
    schema = Schema([Field('name', required=True)])
    content = tokenize_json('{}')
    errors = validate_with_positions(token=content, validator=schema)
    assert errors[0].position == Position(column_no=1, line_no=1, char_index=0)
    assert errors[0].code == "required"

# Generated at 2022-06-24 11:13:30.913942
# Unit test for function validate_json
def test_validate_json():
    validator = Field(name="foo", types=[str])
    value, errors = validate_json(b'{"foo": "bar"}', validator)
    print(f"value: {value}")
    print(f"errors: {errors}")
    assert value == {"foo": "bar"}
    assert not errors
    #
    value, errors = validate_json(b'{"foo": "bar", "baz": true}', validator)
    print(f"value: {value}")
    print(f"errors: {errors}")
    assert value == {"foo": "bar", "baz": "true"}
    assert not errors
    #
    value, errors = validate_json(b'{"foo": "bar", "baz": "qux"}', validator)
    print(f"value: {value}")

# Generated at 2022-06-24 11:13:34.053028
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = "Sample JSON string"
    decoder = _TokenizingDecoder(content=content)
    assert decoder.scan_once

# Generated at 2022-06-24 11:13:37.828344
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(content="test")
    assert decoder.scan_once(string=json.dumps(
        'test'), idx=0) == ({'test': {'test': 'test'}}, len(json.dumps('test')))

# Generated at 2022-06-24 11:13:45.393910
# Unit test for function validate_json
def test_validate_json():
    # valid content
    content = '''{
        "name": "Hello",
        "age": 10,
        "verified": true,
        "score": [1.0, 2.0, 3.0],
        "user": {
            "name": "Bob",
            "age": 20
        }
    }'''

    class User(Schema):
        name = Field(str)
        age = Field(int)

    class TestSchema(Schema):
        name = Field(str)
        age = Field(int)
        verified = Field(bool)
        score = Field(ListType(float))
        user = Field(User)

    value, error_messages = validate_json(content, TestSchema)
    assert len(error_messages) == 0

# Generated at 2022-06-24 11:13:56.547404
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "Joe", "age": 15, "things": ["a", "b", "c"]}'
    token = tokenize_json(content)
    

# Generated at 2022-06-24 11:14:04.117495
# Unit test for function validate_json
def test_validate_json():
    """
    Test validate_json.
    """
    # -----------------------------------------------------------------------
    content = "true"
    validator = Field(Boolean)
    value, errors = validate_json(content, validator)
    assert value is True
    assert len(errors) == 0

    content = "false"
    validator = Field(Boolean)
    value, errors = validate_json(content, validator)
    assert value is False
    assert len(errors) == 0

    # -----------------------------------------------------------------------
    content = "null"
    validator = Field(String)
    value, errors = validate_json(content, validator)
    assert value is None
    assert len(errors) == 0

    # -----------------------------------------------------------------------
    content = ""
    validator = Field(String)
    value, errors = validate_json(content, validator)

# Generated at 2022-06-24 11:14:15.010960
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("3.14") == ScalarToken(3.14, 0, 3, "3.14")
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json('"foo"') == ScalarToken("foo", 0, 5, '"foo"')
    assert tokenize_json('{"bar": 1}')[1] == ScalarToken(
        1, 7, 8, '{"bar": 1}'
    )

# Generated at 2022-06-24 11:14:21.814269
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json('{"a":"b"}') == DictToken({"a": "b"}, 0, 10, '{"a":"b"}')
    assert tokenize_json('{"a":[{"b":true}]}') == DictToken({"a": [DictToken({"b": True}, 5, 12, '{"a":[{"b":true}]}')]}, 0, 17, '{"a":[{"b":true}]}')


# Demonstrate the use of the tokenize_json function

# Generated at 2022-06-24 11:14:27.510606
# Unit test for function validate_json
def test_validate_json():
    # Test valid json
    result = validate_json("{}", Field(type="dict"))
    assert result == ({}, [])
    # Test invalid json
    result = validate_json("]", Field(type="dict"))
    assert result == (
        None,
        [
            Message(
                text="Expecting property name enclosed in double quotes.",
                code="parse_error",
                position=Position(column_no=1, line_no=1, char_index=1),
            )
        ],
    )
    # Test missing json
    result = validate_json("", Field(type="dict"))

# Generated at 2022-06-24 11:14:39.123299
# Unit test for function validate_json
def test_validate_json():
    from typesystem import Boolean, Number, String
    from typesystem.schemas import Schema
    class TestSchema(Schema):
        x = Boolean()
        y = String()
        z = Number()
    json = """
    { "x": true, "y": "hello", "z": 3.14 }
    """
    value, errors = validate_json(json, TestSchema)
    assert value == {"x": True, "y": "hello", "z": 3.14}
    assert errors == []

    json = """
    { "x": true, "y": "world", "z": 2.718 }
    """
    value, errors = validate_json(json, TestSchema)
    assert value == {"x": True, "y": "world", "z": 2.718}
    assert errors == []



# Generated at 2022-06-24 11:14:50.383064
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # _TokenizingDecoder is a subclass of JSONDecoder, which takes keyword arguments
    # construct_float, parse_float, parse_int, parse_constant, strict,
    # object_pairs_hook, and object_hook
    # default value of these keyword arguments:
    # constructor_float = float,
    # parse_float = float,
    # parse_int = int,
    # parse_constant = (lambda o: o),
    # strict = True,
    # object_pairs_hook = None,
    # object_hook = None
    # reset constructor_float to lambda o: o, so that we can test the correctness of
    # _TokenizingDecoder by comparing it to the result from JSONDecoder
    content = "hello"
    construct_float_lambda_o = (lambda o: o)
    arg_

# Generated at 2022-06-24 11:14:56.077522
# Unit test for function tokenize_json
def test_tokenize_json():
    import json

    d_json = {
        "name": "John Doe",
        "age": 50,
        "dogs": [
            {"name": "Chocolate", "breed": "Lab"},
            {"name": "Vanilla", "breed": "Pitbull"},
        ],
        "employer": None,
    }
    d_str = json.dumps(d_json)
    token = tokenize_json(d_str)
    assert isinstance(token, DictToken)
    assert token.value == d_json

# Generated at 2022-06-24 11:15:04.554173
# Unit test for function validate_json
def test_validate_json():
    validator = Field(type="string")
    assert validate_json('"Hello World"', validator) == ("Hello World", [])
    json_error_dict = {
        "text": "String value expected.  Got None.",
        "code": "invalid",
        "params": {},
        "position": {
            "char_index": 0,
            "line_no": 1,
            "column_no": 1,
        },
    }
    assert validate_json("", validator)[1][0].to_json_dict() == json_error_dict

# Generated at 2022-06-24 11:15:12.642239
# Unit test for function validate_json
def test_validate_json():
    field = Field(name="username")
    schema = Schema(fields={"username": field})
    content = '{"username": "ilya"}'
    value, error_messages = validate_json(content, schema)
    assert error_messages == []
    assert value == {"username": "ilya"}
    content = '{"username": 1}'
    value, error_messages = validate_json(content, schema)
    assert isinstance(error_messages[0], ValidationError)
    assert value is None

# Generated at 2022-06-24 11:15:20.564651
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    class _TokenizingDecoderTest(JSONDecoder):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
        def object_hook(self, obj: dict) -> dict:
            return obj
    decoder = _TokenizingDecoderTest()
    assert decoder.object_hook({}) == {}


# Generated at 2022-06-24 11:15:32.352154
# Unit test for function validate_json
def test_validate_json():
    assert validate_json("{}", dict) == ({}, None)
    assert validate_json("{}", int) == (
        None,
        [Message("Expected integer.", code="type_error", position=Position(1, 1, 1))],
    )
    assert validate_json("[1, 2, 3]", int) == (
        None,
        [Message("Expected integer.", code="type_error", position=Position(1, 1, 1))],
    )
    assert validate_json("{}", dict) == ({}, None)
    assert validate_json("{}", int) == (
        None,
        [Message("Expected integer.", code="type_error", position=Position(1, 1, 1))],
    )

# Generated at 2022-06-24 11:15:40.894940
# Unit test for function validate_json
def test_validate_json():
    content = '{"key1":"value1"}'
    validator = {
        "key1": {
            "type": "string",
            "min_length": 8
        }
    }
    value, error_messages = validate_json(content, validator)
    assert len(error_messages) == 1
    assert error_messages[0].code == "min_length"
    assert error_messages[0].position.line_no == 1
    assert error_messages[0].position.column_no == 9
    assert error_messages[0].position.char_index == 9
    assert error_messages[0].text == 'Must be at least 8 characters.'

# Generated at 2022-06-24 11:15:44.438262
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    c = _TokenizingDecoder("test content")
    assert c.content == "test content"
    assert c.scan_once("{'key':1}", 0)[0].token_type == "dict"


# Generated at 2022-06-24 11:15:48.888400
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """{"one": 1, "two": "2"}"""
    expected = {
        "one": ScalarToken(1, 7, 8, content),
        "two": ScalarToken("2", 17, 19, content),
    }
    value = tokenize_json(content)
    assert expected == value



# Generated at 2022-06-24 11:15:50.226170
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    x = _TokenizingDecoder([])
    assert isinstance(x.scan_once, typing.Callable)

# Generated at 2022-06-24 11:15:51.035040
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _TokenizingDecoder


# Generated at 2022-06-24 11:15:55.152047
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():  # type: ignore
    print("all tests passed!")
    warn = warnings.warn
    warnings.warn = lambda *args, **kwargs: None
    _TokenizingDecoder(content="test")
    warnings.warn = warn


# Generated at 2022-06-24 11:16:00.118547
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    assert _make_scanner is not None
    assert _TokenizingJSONObject is not None
    assert _TokenizingDecoder is not None
    assert JSONDecoder is not None

    tokenizer = _TokenizingDecoder()
    assert tokenizer is not None


# Generated at 2022-06-24 11:16:03.361743
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    content = """{
    "key": "value",
    "key2": "value2",
    "key3": "value3"
}"""
    c = _TokenizingDecoder(content=content)
    assert c.content == content

# Generated at 2022-06-24 11:16:09.045183
# Unit test for function tokenize_json
def test_tokenize_json():
    """Unit test the tokenize_json function"""
    json = '{"test":"test"}'
    tokens = tokenize_json(json)
    assert tokens.value["test"].value == "test"
    assert tokens.value["test"].start == 2
    assert tokens.value["test"].end == 8
    assert tokens.value["test"].content == json



# Generated at 2022-06-24 11:16:18.694436
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken(
        {}, char_index=0, end_char_index=1, content="{}"
    )
    assert tokenize_json("1") == ScalarToken(1, char_index=0, end_char_index=1, content="1")
    assert tokenize_json("1.1") == ScalarToken(
        1.1, char_index=0, end_char_index=3, content="1.1"
    )
    assert tokenize_json("[]") == ListToken([], char_index=0, end_char_index=2, content="[]")

# Generated at 2022-06-24 11:16:25.430815
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json(json.dumps({"list": [1, 2, 3], "text": "foo", "nested": {"a": "b"}}))
    assert isinstance(token, DictToken)
    assert len(token.value) == 3
    assert isinstance(token.value["list"], ListToken)
    assert len(token.value["list"].value) == 3
    assert isinstance(token.value["nested"], DictToken)
    assert len(token.value["nested"].value) == 1
    assert token.value["text"].value == "foo"
    assert token.value["list"].value[0].value == 1



# Generated at 2022-06-24 11:16:36.199735
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("{}") == DictToken({}, 0, 1, "{}")
    assert tokenize_json("{ }") == DictToken({}, 0, 2, "{ }")
    assert tokenize_json('''{
  "foo": "bar"
}''') == DictToken({"foo": "bar"}, 0, 31, '''{
  "foo": "bar"
}''')
    assert tokenize_json("[]") == ListToken([], 0, 1, "[]")
    assert tokenize_json("[ ]") == ListToken([], 0, 2, "[ ]")

# Generated at 2022-06-24 11:16:40.888836
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name": "Kobe Bryant", "points": 32.2}'
    token = tokenize_json(content)
    assert type(token) == DictToken
    assert token == {
        "name": "Kobe Bryant",
        "points": 32.2
    }
    

# Generated at 2022-06-24 11:16:49.120940
# Unit test for function validate_json
def test_validate_json():
    # Trivial case
    assert validate_json("{}", Schema) == ({}, [])

    # Basic validation error
    field = Field(required=True)
    assert validate_json("{}", field) == (
        {},
        [
            ValidationError(
                text="A value is required.",
                code="required",
                position=Position(column_no=1, line_no=1, char_index=0),
            )
        ],
    )

    # Handle no content
    try:
        validate_json("", Schema)
    except ParseError as exc:
        assert exc.code == "no_content"
        assert exc.position == Position(column_no=1, line_no=1, char_index=0)
        assert str(exc) == "No content."

# Generated at 2022-06-24 11:16:52.158181
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    decoder = _TokenizingDecoder(strict=True, content="")
    assert decoder.strict



# Generated at 2022-06-24 11:16:57.432804
# Unit test for function tokenize_json
def test_tokenize_json():
    content = '{"name":"Andrew","age":29,"height":null,"employer":false}'
    token = tokenize_json(content=content)
    assert token.type == 'DictToken'
    assert isinstance(token, DictToken)
    assert token.start == 0
    assert token.end == len(content) - 1



# Generated at 2022-06-24 11:17:05.145380
# Unit test for function validate_json
def test_validate_json():
    # Arrange
    content = """
    [
        {
            "user": {
                "name": "John Smith"
            }
        },
        {
            "user": {
                "name": "John Doe",
                "age": 42
            }
        }
    ]
    """
    UserSchema = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
        }
    )
    validator = Schema(
        {
            "user": Field(type=UserSchema),
        }
    )
    # Act
    result, error_messages = validate_json(content, validator=validator)
    # Assert

# Generated at 2022-06-24 11:17:11.569161
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    import json
    decoder = _TokenizingDecoder(content="foo")
    assert isinstance(decoder, json.JSONDecoder)
    # Test the content attribute
    assert decoder.content == "foo"
    # Test the scan_once attribute
    scan_once = decoder.scan_once
    token, end = scan_once("true", 0)
    assert token.value == True
    assert end == 4


# Generated at 2022-06-24 11:17:21.818762
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    p = patch(
        "json.decoder._TokenizingJSONObject",
        wraps=_TokenizingJSONObject,
        return_value=(
            {
                ScalarToken("foo.bar.baz", 1, 12, "foo.bar.baz"): ScalarToken(
                    "baz.bar.foo", 13, 26, "foo.bar.baz"
                )
            },
            27,
        ),
    )
    p.start()
    decoder = _TokenizingDecoder(content="foo.bar.baz")

# Generated at 2022-06-24 11:17:27.717457
# Unit test for function validate_json
def test_validate_json():
    # Valid JSON
    valid_json = '{  "name": "foo", "price": 1.99, "tags": ["bar", "baz"]}'
    s = BookSchema()
    value, errors = validate_json(valid_json, s)
    print("value = ", value)
    print("errors = ", errors)
    assert len(errors) == 0
    assert value["name"] == "foo"
    assert value["tags"] == ["bar", "baz"]
    assert value["price"] == 1.99

    # Invalid JSON
    invalid_json = '{  "name": "foo", "price": 1.99, "tags":"bar" }'
    s = BookSchema()
    value, errors = validate_json(invalid_json, s)
    print("value = ", value)

# Generated at 2022-06-24 11:17:38.154567
# Unit test for function validate_json
def test_validate_json():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize import validate_json

    class User(object):
        def __init__(self, username, password):
            self.username = username
            self.password = password

    class UserSchema(Schema):
        username = String()
        password = String()

    schema = UserSchema()
    content = """{
        "username": "joe",
        "password": "secret"
    }"""
    content_bytes = content.encode("utf-8")

    for content_type in [content, content_bytes]:
        instance, error_messages = validate_json(content_type, schema)

        assert not error_messages
        assert instance


# Generated at 2022-06-24 11:17:46.535834
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    # If a non-JSONDecoder object is provided, the object should be returned
    # unchanged and nothing should be done to the parent object.
    class NonJSONDecoder(object):
        def __init__(self):
            pass

    njd = NonJSONDecoder()
    d = _TokenizingDecoder(njd)
    assert isinstance(d, _TokenizingDecoder)
    assert d.parse_float is njd.parse_float

    # If a JSONDecoder object is provided, the object should be returned
    # unchanged and nothing should be done to the parent object.
    class JSONDecoder(object):
        def __init__(self):
            self.parse_float = 0

    jd = JSONDecoder()
    d = _TokenizingDecoder(jd)

# Generated at 2022-06-24 11:17:50.545397
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder(): 
    d = _TokenizingDecoder(content='abc')
    assert d.scan_once("abc",0) == (ScalarToken('abc', 0, 2, 'abc'), 3)


# Generated at 2022-06-24 11:17:56.812180
# Unit test for function tokenize_json
def test_tokenize_json():
    json_str = """{
        "first_level": {
            "second_level": {
                "third_level": [
                    0,
                    1,
                    2
                ]
            }
        }
    }"""
    assert(
        tokenize_json(json_str)
        == DictToken(
            {
                "first_level": DictToken(
                    {
                        "second_level": DictToken(
                            {
                                "third_level": ListToken(
                                    [ScalarToken(0, None, None, json_str),
                                     ScalarToken(1, None, None, json_str),
                                     ScalarToken(2, None, None, json_str)]
                                )
                            }
                        )
                    }
                )
            }
        )
    )

# Generated at 2022-06-24 11:18:05.193624
# Unit test for function tokenize_json

# Generated at 2022-06-24 11:18:15.749663
# Unit test for function tokenize_json
def test_tokenize_json():
    content = """
    {
        "first_name": "John",
        "last_name": "Smith",
        "age": 25,
        "address": {
            "streetAddress": "21 2nd Street",
            "city": "New York",
            "state": "NY",
            "postalCode": 10021
        },
        "phoneNumber": [
            {
                "type": "home",
                "number": "212 555-1234"
            },
            {
                "type": "fax",
                "number": "646 555-4567"
            }
        ],
        "email": {
            "type": "work",
            "email": "john.smith@example.com"
        }
    }
    """
    token = tokenize_json(content)


# Generated at 2022-06-24 11:18:27.728113
# Unit test for function validate_json
def test_validate_json():
    # Set up a validator object
    class User(Schema):
        name = String()
        age = Integer()

    # Test a valid JSON string
    test_str = '{"name": "Bob", "age": 42}'
    test_val, err_msgs = validate_json(content=test_str, validator=User)
    assert test_val == {'name': 'Bob', 'age': 42}
    assert err_msgs == {}

    # Test a JSON string with additional fields not included in validator
    test_str = '{"name": "Bob", "age": 42, "extra": "fields are ignored"}'
    test_val, err_msgs = validate_json(content=test_str, validator=User)
    assert test_val == {'name': 'Bob', 'age': 42}

# Generated at 2022-06-24 11:18:32.111084
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    Test to check if _TokenizingDecoder is constructed properly
    """
    content = '["a", "b"]'
    decoder = _TokenizingDecoder(content=content)
    assert type(decoder.scan_once) == type(test__TokenizingDecoder)


# Generated at 2022-06-24 11:18:33.132867
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    _TokenizingDecoder('{}')

# Generated at 2022-06-24 11:18:40.397324
# Unit test for function tokenize_json
def test_tokenize_json():
    token = tokenize_json('{"alpha":"beta","gamma":[1,2,3]}')
    assert isinstance(token, DictToken)
    assert isinstance(token.value, dict)
    assert "alpha" in token.value
    assert "gamma" in token.value
    assert isinstance(token.get("alpha"), ScalarToken)
    assert isinstance(token.get("gamma"), ListToken)
    assert token.get("alpha").text == "beta"
    assert token.get("gamma").value == [1, 2, 3]


# Generated at 2022-06-24 11:18:46.842711
# Unit test for function tokenize_json
def test_tokenize_json():
    """
    Simple unit test for function to ensure that it can parse valid JSON.
    
    If the content is not valid JSON, the function should fail with a json.decoder.JSONDecodeError
    """
    
    try:
        tokenize_json(content='''{"name":"John"}''')
    except Exception:
        assert False

    try:
        tokenize_json(content="""{}""")
    except Exception:
        assert False

    try:
        tokenize_json(content='''{"name":"John", "age":30}''')
    except Exception:
        assert False
        
    try:
        tokenize_json(content='''["apple", "banana"]''')
    except Exception:
        assert False
        

# Generated at 2022-06-24 11:18:57.442456
# Unit test for function tokenize_json
def test_tokenize_json():
    json_string = """
    {
        "name": "John",
        "age": 30,
        "car": null
    }
"""
    result = tokenize_json(json_string)
    assert isinstance(result, DictToken)
    result = result.value
    assert len(result) == 3
    for i in result:
        assert isinstance(i, ScalarToken)
    assert result[0].value == "John"
    assert isinstance(result[0].start, Position)
    assert result[0].start.line_no == 3
    assert result[0].start.column_no == 12

    assert isinstance(result[1].value, int)
    assert isinstance(result[2].value, type(None))



# Generated at 2022-06-24 11:19:06.609805
# Unit test for function validate_json
def test_validate_json():

    def check(
        *,
        json_content: typing.Union[str, bytes],
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_value: typing.Any,
        expected_errors: typing.List[Message],
    ) -> None:
        value, errors = validate_json(content=json_content, validator=validator)
        assert value == expected_value
        assert errors == expected_errors

    def check_error(
        *,
        json_content: typing.Union[str, bytes],
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_error_code: str,
    ) -> None:
        with pytest.raises(ValidationError) as excinfo:
            validate_json(json_content, validator)
       

# Generated at 2022-06-24 11:19:15.295973
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String, Integer

    class TestSchema(Schema):
        name = String(min_length=3)
        age = Integer(minimum=18, maximum=99)

    data = '{"name": "Al", "age": 75}'
    expected_message_text = 'The field "name" needs to be 3 characters or more.'
    expected_message_code = 'field_too_short'

    actual_value, actual_error_messages = validate_json(
        content=data,
        validator=TestSchema,
    )

    expected_value = {"name": "Al", "age": 75}

# Generated at 2022-06-24 11:19:24.926562
# Unit test for function validate_json
def test_validate_json():
    field = typesystem.Object(
        properties={"foo": typesystem.String(max_length=2), "bar": typesystem.String()}
    )
    value, errors = validate_json(
        b'{"foo": "hi", "bar": "world", "baz": "test"}', validator=field
    )
    assert not errors
    assert value == {"foo": "hi", "bar": "world"}

    value, errors = validate_json(b'{"foo": "foo", "bar": "world"}', validator=field)
    assert len(errors) == 1
    assert errors[0].code == "max_length"



# Generated at 2022-06-24 11:19:29.489883
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    """
    This unit test is to check the consturctor of class _TokenizingDecoder.
    """
    content = '""'
    _tk = _TokenizingDecoder(content=content)
    assert _tk.content == content
    assert _tk.parse_float is float
    assert _tk.parse_int is int
    assert _tk.strict == True

# Generated at 2022-06-24 11:19:34.460324
# Unit test for function validate_json
def test_validate_json():
    from typesystem.fields import String as StringField

    json_string = "{\"str1\": \"value1\", \"str2\": \"value2\"}"
    field = StringField(max_length=10)

    result = validate_json(json_string, field)

    assert not result.errors
    assert result.value == json.loads(json_string)


# Generated at 2022-06-24 11:19:39.894239
# Unit test for constructor of class _TokenizingDecoder
def test__TokenizingDecoder():
    cd = _TokenizingDecoder()
    assert cd.object_hook == None
    assert cd.strict == True
    assert cd.parse_float == float
    assert cd.parse_int == int
    assert cd.parse_constant == None
    assert cd.object_pairs_hook == None
    assert cd.content == None
    assert cd.scan_once == _make_scanner(cd, None)


# Generated at 2022-06-24 11:19:41.596451
# Unit test for function tokenize_json
def test_tokenize_json():
    assert validate_json('{"a":1}', Schema({'a': int})) == ({'a':1}, [])


# Generated at 2022-06-24 11:19:49.710917
# Unit test for function tokenize_json
def test_tokenize_json():
    expected_data = [1, 2, 3]
    expected_token = ListToken(expected_data, 0, 2, "[1,2,3]")
    assert tokenize_json("[1,2,3]") == expected_token

    expected_data = {"first_name": "John", "last_name": "Doe"}
    expected_token = DictToken(expected_data, 0, 17, '{"first_name":"John","last_name":"Doe"}')
    assert tokenize_json('{"first_name":"John","last_name":"Doe"}') == expected_token


# Generated at 2022-06-24 11:19:58.608497
# Unit test for function validate_json
def test_validate_json():
    import pytest

    class UserSchema(Schema):
        name = String()
        age = Integer()
        email = String()

    class UserSchemaWithRequiredFields(Schema):
        name = String(required=True)

    class UserSchemaWithRequiredFieldsAndSubSchema(Schema):
        name = String(required=True)
        address = SubSchema(
            Schema, required=True, validator=UserSchemaWithRequiredFields
        )

    class UserSchemaWithRequiredFieldsAndSubSchemaWithArray(Schema):
        name = String(required=True)
        address = SubSchema(
            Schema, required=True, validator=UserSchemaWithRequiredFields
        )
        emails = Array(items=String(required=True))


# Generated at 2022-06-24 11:20:03.497308
# Unit test for function validate_json
def test_validate_json():
    from typesystem.decorators import schema

    @schema
    class UserSchema:
        id = "integer"
        name = "string"

    errors = validate_json('{"id": "1", "name": "Todd"}', UserSchema)
    assert len(errors) == 1
    assert errors[0].code == "invalid_type"



# Generated at 2022-06-24 11:20:13.541275
# Unit test for function tokenize_json
def test_tokenize_json():
    example_json = '{"title": "Looking for Alaska", "author": "John Green"}'
    token = tokenize_json(example_json)
    from pprint import pprint
    pprint(token)
    # Output:
    # DictToken({'title': ScalarToken('Looking for Alaska', 11, 32, '{\n  "title": "Looking for Alaska",\n  "author": "John Green"\n}'),
    #  'author': ScalarToken('John Green', 48, 61, '{\n  "title": "Looking for Alaska",\n  "author": "John Green"\n}')},
    #  0, 61, '{\n  "title": "Looking for Alaska",\n  "author": "John Green"\n}')



# Generated at 2022-06-24 11:20:23.035302
# Unit test for function tokenize_json
def test_tokenize_json():
    assert tokenize_json("null") == ScalarToken(None, 0, 3, "null")

    assert tokenize_json("true") == ScalarToken(True, 0, 3, "true")

    assert tokenize_json("false") == ScalarToken(False, 0, 4, "false")

    assert tokenize_json("-25") == ScalarToken(-25, 0, 3, "-25")

    assert tokenize_json('"hello world\\n"') == ScalarToken(
        "hello world\n", 0, 13, '"hello world\\n"'
    )


# Generated at 2022-06-24 11:20:32.150832
# Unit test for function tokenize_json
def test_tokenize_json():

    def compare_json_pretty(left_json_str, right_json_str):
        left_json = json.loads(left_json_str)
        right_json = json.loads(right_json_str)
        assert left_json == right_json
        print(json.dumps(left_json, indent=4))

    compare_json_pretty(
        "{\"a\": \"b\"}", "{\"a\": \"b\"}"
    )  # Test dict with simple data
    compare_json_pretty(
        "{\"a\": [\"b\", \"c\", \"d\"]}", "{\"a\": [\"b\", \"c\", \"d\"]}"
    )  # Test dict with list

# Generated at 2022-06-24 11:20:42.242435
# Unit test for function tokenize_json
def test_tokenize_json():
    from typesystem.fields import String

    content = '{"name": "Derek", "age": 30}'
    json = tokenize_json(content=content)
    assert [
        (field.name, field.value) for field in json.values()
    ] == [("name", "Derek"), ("age", 30)]
    field = String()
    value, errors = validate_json(content=content, validator=field)
    assert value == content, "validate_json should return the content"
    assert errors == [], "errors should be empty"

    content = '{"name": "Derek", "age": "thirty"}'
    value, errors = validate_json(content=content, validator=field)
    assert len(errors) == 1, "One error should be returned"
    error = errors[0]
   