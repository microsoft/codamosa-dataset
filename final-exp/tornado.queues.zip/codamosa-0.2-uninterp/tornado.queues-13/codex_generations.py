

# Generated at 2022-06-18 10:36:32.638172
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()
    assert q.qsize() == 0


# Generated at 2022-06-18 10:36:37.980319
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    future = q.put(2)
    assert future.result() is None
    future = q.put(3)
    assert future.exception() is QueueFull
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is True


# Generated at 2022-06-18 10:36:41.153233
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:36:45.058715
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:36:55.143088
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:37:06.992341
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    assert q.get_nowait() == 5
    q.put_nowait(6)
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:37:17.057704
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import time
    import tornado.ioloop
    import tornado.queues
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.locks
    import tornado.options
    import tornado.queues
    import tornado.template
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.queues
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape

# Generated at 2022-06-18 10:37:23.046485
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    # Start consumer without waiting (since it never finishes).
    IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')
    return True


# Generated at 2022-06-18 10:37:27.844779
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:37:32.271697
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()


# Generated at 2022-06-18 10:37:46.415159
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:37:56.278575
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    q.put(3)
    q.get()
    q.put(4)
    q.get()
    q.put(5)
    q.get()
    q.put(6)
    q.get()
    q.put(7)
    q.get()
    q.put(8)
    q.get()
    q.put(9)
    q.get()
    q.put(10)
    q.get()
    q.put(11)
    q.get()
    q.put(12)
    q.get()
    q.put(13)
    q.get()

# Generated at 2022-06-18 10:38:05.449574
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import random
    import tornado.ioloop
    import tornado.queues
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import threading
    import logging
    import sys
    import os
    import traceback
    import unittest
    import warnings
    import contextlib
    import functools
    import collections
    import datetime
    import typing
    import typing_extensions
    import typing_inspect
    import types
    import weakref
    import abc
    import numbers
    import decimal
    import fractions
    import enum
    import io
    import re
    import ssl
    import base64
    import binascii
    import hashlib
    import hmac


# Generated at 2022-06-18 10:38:10.246433
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()
    assert q.qsize() == 0
    assert q.full() == False
    assert q.maxsize == 2


# Generated at 2022-06-18 10:38:14.941853
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:38:19.422661
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:38:29.563285
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    q.put(3)
    assert q.qsize() == 3
    assert q.full() == False
    assert q.empty() == False
    q.put(4)
    assert q.qsize() == 4
    assert q.full() == False
    assert q.empty() == False
    q.put(5)
    assert q.qsize() == 5
    assert q.full() == False
    assert q.empty() == False
    q.put(6)
    assert q.qsize() == 6
    assert q.full() == False
    assert q.empty() == False

# Generated at 2022-06-18 10:38:33.925526
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:39.999827
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:38:44.503960
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:39:13.196191
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:39:18.368973
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-18 10:39:22.408568
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False


# Generated at 2022-06-18 10:39:35.172752
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:39:47.344634
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    future = q.put(2)
    assert future.result() == None
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    future = q.put(3)
    assert future.result() == None
    assert q.qsize() == 3
    assert q.empty() == False
    assert q.full() == True
    future = q.put(4)
    assert future.result() == None
    assert q.qsize() == 4
    assert q.empty() == False
    assert q.full() == True

# Generated at 2022-06-18 10:39:57.976016
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    try:
        q.put(3)
    except QueueFull:
        assert q.qsize() == 2
        assert q.empty() == False
        assert q.full() == True
    else:
        assert False


# Generated at 2022-06-18 10:40:00.247181
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:40:11.046736
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:40:21.673071
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:40:26.748659
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-18 10:41:10.459727
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:41:19.897030
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    future = q.put(2)
    assert future.result() is None
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    future = q.put(3)
    assert future.exception() is QueueFull
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True


# Generated at 2022-06-18 10:41:23.057323
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:41:28.504106
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:41:41.604370
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    assert q.maxsize == 2
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.get_nowait() == 1

# Generated at 2022-06-18 10:41:47.368316
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:41:53.513671
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full() == True
    try:
        q.put_nowait(3)
    except QueueFull:
        assert q.qsize() == 2
        assert q.full() == True
    else:
        assert False


# Generated at 2022-06-18 10:41:59.411189
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:42:04.291935
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:42:08.975089
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:43:32.953763
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:43:44.245016
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()

# Generated at 2022-06-18 10:43:52.672817
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:43:57.015965
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:44:01.333175
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:06.495123
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:17.628786
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:44:25.571016
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.queues
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest
    class QueueTest(tornado.testing.AsyncTestCase):
        def test_queue_get(self):
            q = tornado.queues.Queue()
            q.put_nowait(42)
            q.put_nowait(43)
            self.assertEqual(q.qsize(), 2)
            self.assertEqual(q.get_nowait(), 42)
            self.assertEqual(q.qsize(), 1)
            self.assertEqual(q.get_nowait(), 43)
            self.assertEqual(q.qsize(), 0)

# Generated at 2022-06-18 10:44:29.761511
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:39.035094
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test