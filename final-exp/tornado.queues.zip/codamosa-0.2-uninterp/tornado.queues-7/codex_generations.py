

# Generated at 2022-06-18 10:36:38.425059
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")


# Generated at 2022-06-18 10:36:43.826300
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:36:47.568016
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:36:52.941799
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:36:57.064157
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5

# Generated at 2022-06-18 10:37:09.525348
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    q.put_nowait(6)
    assert q.get_nowait() == 5
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    q.put_nowait(9)
    assert q.get_nowait()

# Generated at 2022-06-18 10:37:18.351354
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:37:29.531302
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:37:34.813189
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass

# Generated at 2022-06-18 10:37:39.905185
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    assert q.qsize() == 1
    future = q.put(2)
    assert future.result() == None
    assert q.qsize() == 2
    future = q.put(3)
    assert future.exception() == QueueFull
    assert q.qsize() == 2


# Generated at 2022-06-18 10:38:00.980794
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(4) == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(5) == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False

# Generated at 2022-06-18 10:38:10.759476
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-18 10:38:21.085592
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:38:30.710826
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.maxsize == 2
    assert q.get_nowait() == QueueEmpty
    assert q.get() == QueueEmpty
    assert q.task_done() == ValueError
    assert q.join() == None
    assert q.put_nowait(1) == None
    assert q.put_nowait(2) == None
    assert q.put_nowait(3) == QueueFull
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == QueueEmpty
    assert q.task_done() == None
    assert q.join() == None

# Generated at 2022-06-18 10:38:34.321110
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True


# Generated at 2022-06-18 10:38:42.207251
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:38:47.782600
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:58.748771
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:39:04.106226
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:39:15.829659
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.done()
    assert future.result() is None
    assert q.qsize() == 1
    future = q.put(2)
    assert future.done()
    assert future.result() is None
    assert q.qsize() == 2
    future = q.put(3)
    assert not future.done()
    assert q.qsize() == 2
    assert q.putters[0][0] == 3
    assert q.putters[0][1] == future
    assert q.putters[1][0] == 3
    assert q.putters[1][1] == future
    assert q.getters == []
    assert q.unfinished_tasks == 2
    assert not q.finished.is_set

# Generated at 2022-06-18 10:39:39.215780
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
   

# Generated at 2022-06-18 10:39:45.382223
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()
    assert q.qsize() == 0
    assert q.full() == False


# Generated at 2022-06-18 10:39:51.298713
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:39:55.654725
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        return True
    return False


# Generated at 2022-06-18 10:40:06.447711
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    q.put_nowait(6)
    q.put_nowait(7)
    q.put_nowait(8)
    q.put_nowait(9)
    q.put_nowait(10)
    q.put_nowait(11)
    q.put_nowait(12)
    q.put_nowait(13)
    q.put_nowait(14)
    q.put_nowait(15)
    q.put_nowait(16)
    q.put_nowait(17)
    q.put_

# Generated at 2022-06-18 10:40:17.133922
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize()

# Generated at 2022-06-18 10:40:27.185478
# Unit test for method get of class Queue
def test_Queue_get():
    # test_Queue_get_1
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False

    # test_Queue_get_2
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get() == 1
    assert q.get() == 2
    try:
        q.get()
    except QueueEmpty:
        pass
    else:
        assert False

    # test_Queue_get_3


# Generated at 2022-06-18 10:40:29.987913
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2


# Generated at 2022-06-18 10:40:38.482204
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()

# Generated at 2022-06-18 10:40:41.468783
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:41:11.787424
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:41:17.142727
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:41:23.204110
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:28.631481
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:41:35.217680
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:41:41.178072
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:41:52.727603
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:56.159815
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:42:06.866635
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:42:10.851529
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:43:06.893348
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False
    q.put(4)
    q.put(5)
    assert q.full() == True
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-18 10:43:12.006436
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-18 10:43:13.335675
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    assert q.get() == 1


# Generated at 2022-06-18 10:43:24.709052
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("QueueFull not raised")
    q.get_nowait()
    q.get_nowait()
    try:
        q.get_nowait()
    except QueueEmpty:
        print("QueueEmpty")
    else:
        print("QueueEmpty not raised")
    q.put_nowait(4)
    q.put_nowait(5)
    try:
        q.put_nowait(6)
    except QueueFull:
        print("QueueFull")
    else:
        print("QueueFull not raised")
   

# Generated at 2022-06-18 10:43:31.013257
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()
    assert q.qsize() == 0
    assert not q.full()


# Generated at 2022-06-18 10:43:42.587916
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    q.put_nowait(3)
    q.put_nowait(4)
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    q.put_nowait(5)
    q.put_nowait(6)
    assert q.get_nowait() == 5
    assert q.get_nowait() == 6
    q.put_nowait(7)
    q.put_nowait(8)
    assert q.get_nowait() == 7
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:43:51.729855
# Unit test for method get of class Queue
def test_Queue_get():
    # Test that Queue.get() returns the correct value
    q = Queue()
    q.put(1)
    assert q.get() == 1
    q.put(2)
    assert q.get() == 2
    q.put(3)
    assert q.get() == 3
    q.put(4)
    assert q.get() == 4
    q.put(5)
    assert q.get() == 5
    q.put(6)
    assert q.get() == 6
    q.put(7)
    assert q.get() == 7
    q.put(8)
    assert q.get() == 8
    q.put(9)
    assert q.get() == 9
    q.put(10)
    assert q.get() == 10
    q.put(11)


# Generated at 2022-06-18 10:43:57.159122
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:04.775821
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    future = q.put(2)
    assert future.result() == None
    future = q.put(3)
    assert future.result() == None
    assert q.qsize() == 2
    assert q._queue == collections.deque([2, 3])
    assert q._putters == collections.deque([])
    assert q._getters == collections.deque([])
    assert q._unfinished_tasks == 2
    assert q._finished.is_set() == False


# Generated at 2022-06-18 10:44:16.280918
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    future = q.put(2)
    assert future.result() is None
    future = q.put(3)
    assert future.result() is None
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()
    future = q.put(4)
    assert future.result() is None
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()

# Unit