

# Generated at 2022-06-18 10:36:36.061008
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    q.put(3)
    assert q.qsize() == 2
    q.put(4)
    assert q.qsize() == 2


# Generated at 2022-06-18 10:36:42.679836
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    assert q.get_nowait() == 5
    q.put_nowait(6)
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:36:53.297828
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:37:00.424714
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:37:04.219289
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2


# Generated at 2022-06-18 10:37:08.594656
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:37:12.082078
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:37:15.162442
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:37:20.296822
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:37:31.100822
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    future = q.put(2)
    assert future.result() == None
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    future = q.put(3)
    assert future.result() == None
    assert q.qsize() == 3
    assert q.empty() == False
    assert q.full() == True
    future = q.put(4)
    assert future.result() == None
    assert q.qsize() == 4
    assert q.empty() == False
    assert q.full() == True

# Generated at 2022-06-18 10:37:44.711948
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:37:54.830015
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    q.put_nowait(6)
    q.put_nowait(7)
    q.put_nowait(8)
    q.put_nowait(9)
    q.put_nowait(10)
    q.put_nowait(11)
    q.put_nowait(12)
    q.put_nowait(13)
    q.put_nowait(14)
    q.put_nowait(15)
    q.put_nowait(16)
    q.put_nowait(17)
    q.put_

# Generated at 2022-06-18 10:38:03.544560
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:38:07.734260
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:17.814844
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:38:27.969086
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:38:32.324168
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:40.173891
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:46.368464
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:51.964290
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:39:20.439794
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:39:32.538108
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:39:45.275820
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    q.put(3)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    q.put(4)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    q.put(5)
    assert q.qsize()

# Generated at 2022-06-18 10:39:51.198998
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:39:55.424024
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:40:00.789104
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:40:06.097907
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:40:09.773160
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:40:20.464805
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import time
    import random
    import threading
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback

# Generated at 2022-06-18 10:40:24.391719
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
    except QueueFull:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:41:13.881703
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    future = q.put(2)
    assert future.result() is None
    future = q.put(3, timeout=0.1)
    assert future.result() is None
    future = q.put(4, timeout=0.1)
    assert future.result() is None
    future = q.put(5, timeout=0.1)
    assert future.result() is None
    future = q.put(6, timeout=0.1)
    assert future.result() is None
    future = q.put(7, timeout=0.1)
    assert future.result() is None
    future = q.put(8, timeout=0.1)
    assert future.result() is None

# Generated at 2022-06-18 10:41:19.893350
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:24.013373
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.full() == False
    assert q.empty() == True
    assert q.maxsize == 2
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.get_nowait() == 1

# Generated at 2022-06-18 10:41:28.624657
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:41:41.714776
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:47.105246
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:41:56.031333
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:42:02.567960
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "Queue.get_nowait() should raise QueueEmpty"


# Generated at 2022-06-18 10:42:05.894740
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:42:13.522604
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    assert q.get_nowait() == 5
    q.put_nowait(6)
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:43:26.729764
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:43:30.162887
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2


# Generated at 2022-06-18 10:43:36.251098
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get() == 1
    assert q.get() == 2
    assert q.get() == 3
    assert q.qsize() == 0


# Generated at 2022-06-18 10:43:46.672392
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:43:54.160864
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:43:58.793028
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:09.072592
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    assert q.get_nowait() == 5
    q.put_nowait(6)
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:44:16.636138
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5


# Generated at 2022-06-18 10:44:21.040165
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:27.802729
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    future = q.put(2)
    assert future.result() == None
    future = q.put(3)
    assert future.result() == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q._queue == collections.deque([1,2])
    assert q._getters == collections.deque([])