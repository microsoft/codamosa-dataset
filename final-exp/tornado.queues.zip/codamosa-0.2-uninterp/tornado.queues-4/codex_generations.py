

# Generated at 2022-06-18 10:36:41.866564
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:36:52.514214
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    q.put_nowait(6)
    q.put_nowait(7)
    q.put_nowait(8)
    q.put_nowait(9)
    q.put_nowait(10)
    q.put_nowait(11)
    q.put_nowait(12)
    q.put_nowait(13)
    q.put_nowait(14)
    q.put_nowait(15)
    q.put_nowait(16)
    q.put_nowait(17)
    q.put_

# Generated at 2022-06-18 10:36:55.575036
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:37:01.052587
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:37:12.915775
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
   

# Generated at 2022-06-18 10:37:17.784957
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:37:21.223629
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.get() == None


# Generated at 2022-06-18 10:37:25.902263
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2


# Generated at 2022-06-18 10:37:30.427270
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:37:36.714590
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:37:58.501706
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    assert q.qsize() == 1
    assert q.empty() is False
    assert q.full() is False
    future = q.put(2)
    assert future.result() is None
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is True
    future = q.put(3)
    assert future.exception() is not None
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is True
    future = q.put(4, timeout=0.01)
    assert future.exception() is not None
    assert q.qsize() == 2

# Generated at 2022-06-18 10:38:05.182001
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:38:10.289500
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:15.314723
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:22.529716
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    assert q.empty()
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.empty()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:25.721307
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    assert q.get_nowait() == 1
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:29.799908
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:38:37.313794
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:38:43.366002
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:47.782600
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:39:16.920276
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:39:29.467102
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.put(4) == None
    assert q.put(5) == None
    assert q.put(6) == None
    assert q.put(7) == None
    assert q.put(8) == None
    assert q.put(9) == None
    assert q.put(10) == None
    assert q.put(11) == None
    assert q.put(12) == None
    assert q.put(13) == None
    assert q.put(14) == None

# Generated at 2022-06-18 10:39:35.426402
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass


# Generated at 2022-06-18 10:39:47.683915
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.maxsize == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.maxsize == 2
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.maxsize == 2
    assert q.get_nowait() == 1
    assert q.get_nowait

# Generated at 2022-06-18 10:39:59.421608
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:40:10.132158
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:40:13.538241
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:40:18.568856
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:40:28.392499
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:40:31.542440
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:41:27.053081
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:41:39.613853
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)
    q.put(24)


# Generated at 2022-06-18 10:41:51.897355
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:56.332304
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:42:01.743044
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:42:10.654465
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    assert q.maxsize == 2
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0

# Generated at 2022-06-18 10:42:15.281508
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0


# Generated at 2022-06-18 10:42:19.125143
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    q.put(3)
    assert q.get_nowait() == 3
    assert q.empty()


# Generated at 2022-06-18 10:42:21.895895
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0


# Generated at 2022-06-18 10:42:31.568391
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()
    assert q.qsize() == 0
    assert q.full() == False
    assert q.maxsize == 2
    assert q.task_done() == None
    assert q.join() == None
    assert q.__repr__() == "<Queue at 0x7f9c9f9f7d68 maxsize=2 queue=[1, 2]>"
    assert q.__str__() == "<Queue maxsize=2 queue=[1, 2]>"
    assert q._format() == "maxsize=2 queue=[1, 2] tasks=2"

# Generated at 2022-06-18 10:44:12.386766
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()
    q.put_nowait(3)
    assert q.get_nowait() == 3
    assert q.empty()


# Generated at 2022-06-18 10:44:17.847542
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:20.522282
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2

# Generated at 2022-06-18 10:44:23.205398
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:44:32.768070
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:44:40.156852
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    q.put(3)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    q.put(4)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    q.put(5)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2

# Generated at 2022-06-18 10:44:43.926149
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:44:48.259153
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:44:55.769976
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:45:04.346458
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() is None
    assert q.qsize() == 1
    assert q.empty() is False
    assert q.full() is False
    future = q.put(2)
    assert future.result() is None
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is True
    future = q.put(3)
    assert future.exception() is not None
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is True
