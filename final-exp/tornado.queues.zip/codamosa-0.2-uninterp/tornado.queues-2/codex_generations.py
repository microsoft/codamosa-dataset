

# Generated at 2022-06-18 10:36:36.224300
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()


# Generated at 2022-06-18 10:36:42.032876
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:36:52.700934
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:37:00.102593
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3
    q.put_nowait(4)
    assert q.get_nowait() == 4
    q.put_nowait(5)
    assert q.get_nowait() == 5
    q.put_nowait(6)
    assert q.get_nowait() == 6
    q.put_nowait(7)
    assert q.get_nowait() == 7
    q.put_nowait(8)
    assert q.get_nowait() == 8

# Generated at 2022-06-18 10:37:12.128488
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    q.put(2)
    assert q.full() == True
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    q.put(1)

# Generated at 2022-06-18 10:37:23.930208
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:37:30.548008
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.put(4) == None
    assert q.qsize() == 4
    assert q.empty() == False
    assert q.full() == True
    assert q.maxsize == 2


# Generated at 2022-06-18 10:37:36.067848
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-18 10:37:39.460935
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()


# Generated at 2022-06-18 10:37:44.577980
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:37:57.861298
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 3
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.qsize() == 0


# Generated at 2022-06-18 10:38:01.442278
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:38:11.269107
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import time
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        asyncio.get_event_loop().create_task(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    asyncio

# Generated at 2022-06-18 10:38:16.289647
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:20.272232
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-18 10:38:30.204797
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:38:33.910432
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:38:39.998658
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2


# Generated at 2022-06-18 10:38:46.649972
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError("QueueEmpty not raised")


# Generated at 2022-06-18 10:38:51.486317
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    try:
        q.put(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:39:18.038804
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(4) == None
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2


# Generated at 2022-06-18 10:39:24.262731
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:39:29.467153
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:39:35.887564
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise Exception("QueueEmpty not raised")


# Generated at 2022-06-18 10:39:40.901290
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True


# Generated at 2022-06-18 10:39:53.336731
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:39:58.395466
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:40:09.276465
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.put(4) == None
    assert q.put(5) == None
    assert q.put(6) == None
    assert q.put(7) == None
    assert q.put(8) == None
    assert q.put(9) == None
    assert q.put(10) == None
    assert q.put(11) == None
    assert q.put(12) == None
    assert q.put(13) == None
    assert q.put(14) == None

# Generated at 2022-06-18 10:40:19.820034
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:40:23.163571
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2


# Generated at 2022-06-18 10:40:43.670023
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.get() == None


# Generated at 2022-06-18 10:40:49.176821
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass


# Generated at 2022-06-18 10:40:58.291520
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:11.233354
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:41:18.389196
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:41:21.589191
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    assert q.empty()


# Generated at 2022-06-18 10:41:29.046257
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    q.get_nowait()
    assert q.qsize() == 1

# Generated at 2022-06-18 10:41:42.047217
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:41:46.402329
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1)
    assert future.result() == None
    future = q.put(2)
    assert future.result() == None
    future = q.put(3)
    assert future.result() == None
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.empty() == True
    assert q.full() == False
    future = q.put(1)
    assert future.result() == None
    assert q.get_nowait() == 1
    assert q.empty() == True
    assert q.full() == False
    future = q.put(1)

# Generated at 2022-06-18 10:41:51.985772
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:42:29.437465
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:42:34.023748
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print('Queue is full')
    else:
        print('Queue is not full')


# Generated at 2022-06-18 10:42:38.953140
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:42:45.454712
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5
    assert q.empty()
    assert q.qsize() == 0


# Generated at 2022-06-18 10:42:52.617528
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5


# Generated at 2022-06-18 10:43:01.823225
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    assert q.put(3) == None
    assert q.put(4) == None
    assert q.put(5) == None
    assert q.put(6) == None
    assert q.put(7) == None
    assert q.put(8) == None
    assert q.put(9) == None
    assert q.put(10) == None
    assert q.put(11) == None
    assert q.put(12) == None
    assert q.put(13) == None
    assert q.put(14) == None

# Generated at 2022-06-18 10:43:06.055051
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2


# Generated at 2022-06-18 10:43:10.313966
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:43:22.029144
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:43:27.785499
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:44:44.280838
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
    else:
        print("Queue not full")


# Generated at 2022-06-18 10:44:51.924729
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:44:55.700587
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-18 10:45:00.871576
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-18 10:45:09.431845
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-18 10:45:19.720224
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2
    q.put(3)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    assert q.maxsize == 2

# Generated at 2022-06-18 10:45:28.462957
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    q.put(7)
    q.put(8)
    q.put(9)
    q.put(10)
    q.put(11)
    q.put(12)
    q.put(13)
    q.put(14)
    q.put(15)
    q.put(16)
    q.put(17)
    q.put(18)
    q.put(19)
    q.put(20)
    q.put(21)
    q.put(22)
    q.put(23)

# Generated at 2022-06-18 10:45:35.553354
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()
    q.get()

# Generated at 2022-06-18 10:45:39.806103
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full")
    else:
        print("Queue is not full")


# Generated at 2022-06-18 10:45:43.628518
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
