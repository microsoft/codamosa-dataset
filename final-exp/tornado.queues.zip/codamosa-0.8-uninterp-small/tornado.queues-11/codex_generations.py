

# Generated at 2022-06-26 08:41:08.936032
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue(maxsize=1)
    queue_1 = Queue(maxsize=0)
    queue_2 = Queue(maxsize=-3)
    queue_3 = Queue(maxsize=4)
    queue_4 = Queue(maxsize=5)
    try:
        obj_0 = queue_0.get_nowait()
        print(obj_0)
    except QueueEmpty as e_0:
        print(e_0)

    try:
        obj_0 = queue_1.get_nowait()
        print(obj_0)
    except QueueEmpty as e_1:
        print(e_1)


# Generated at 2022-06-26 08:41:14.621923
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    assert queue_0.empty() == True
    assert queue_0.full() == False
    queue_0.put_nowait(10)
    assert queue_0.empty() == False
    assert queue_0.full() == False


# Generated at 2022-06-26 08:41:24.854594
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue object
    queue_0 = Queue(maxsize=2)
    # Test that the __init__ method of Queue initializes the maxsize attribute
    assert queue_0.maxsize is 2, 'Expected value: 2, Actual value: %d' % queue_0.maxsize

    # Test that the empty method of Queue returns false
    assert queue_0.empty() is False, 'Expected value: False, Actual value: %s' % queue_0.empty()

    # Test that the full method of Queue returns false
    assert queue_0.full() is False, 'Expected value: False, Actual value: %s' % queue_0.full()

    # Invoke method put of Queue
    future_0 = queue_0.put(item=5, timeout=None)

    # Test that the get

# Generated at 2022-06-26 08:41:31.445941
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue(maxsize = 0)
    if (queue.qsize() != 0):
        raise Exception("AssertionError")
    item = queue.get()
    if (item is None or False):
        raise Exception("AssertionError")
    try:
        item = queue.get()
        raise Exception("AssertionError")
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:41:34.774741
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()

    val = q.get()
    assert isinstance(val, Awaitable)


# Generated at 2022-06-26 08:41:39.222280
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_full_1 = QueueFull()

    q = Queue()

    try:
        q.put_nowait(1)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:41:41.928768
# Unit test for method get of class Queue
def test_Queue_get():
    # Queue test_Queue_get
    # test_Queue_get :
    #   Given  :
    #   Then   :
    pass


# Generated at 2022-06-26 08:41:44.573418
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put()



# Generated at 2022-06-26 08:41:47.947720
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = q.get()
    class TimeoutError: pass
    future.set_exception(TimeoutError())


# Generated at 2022-06-26 08:41:54.411756
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.maxsize = maxsize
    item = item
    timeout = timeout
    q.put(item, timeout=timeout)


# Generated at 2022-06-26 08:42:10.330193
# Unit test for method get of class Queue
def test_Queue_get():
    test_case_0()
    queue_0 = Queue()
    queue_0.put(1)
    queue_0.put(2)
    queue_0.put(3)
    queue_0.get()
    queue_0.get()
    queue_0.get()
    queue_0.get()
    if not queue_0.get() is None:
        return False
    return True

test_Queue_get()

# Generated at 2022-06-26 08:42:14.244950
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Tested __put_internal
    queue_0 = Queue()
    queue_0._init()
    queue_0.__put_internal(1)


# Generated at 2022-06-26 08:42:22.408579
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    assert type(queue_0) is Queue
    queue_0._consume_expired()
    # Test 1:
    queue_0._queue.append(4)
    queue_0._queue.append(4)
    queue_0.__put_internal(4)


# Generated at 2022-06-26 08:42:29.558340
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Maximum queue size is 10
    queue_10 = Queue(10)

    # Put element into queue 10 times
    for _ in range(10):
        assert(queue_10.qsize() < 10)
        queue_10.put_nowait(1)

    # When queue is full, put_nowait should raise QueueFull
    try:
        queue_10.put_nowait(1)
    except QueueFull as e:
        assert(str(e) == "")
    else:
        assert(False)


# Generated at 2022-06-26 08:42:35.638611
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(5)
    assert queue_0.qsize() == 1

test_case_0()
test_Queue_put_nowait()


# Generated at 2022-06-26 08:42:49.461893
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future = Future()
    _set_timeout(future, 0.00026)
    future_0 = queue_0.get(timeout=(float)('0'))
    try:
        future_0.set_result(future_0)
    except:
        raise Exception
    forward_future = Future()
    _set_timeout(forward_future, 0.00026)
    future_0 = queue_0.get(timeout=(float)('0'))
    try:
        future_0.set_result(forward_future)
    except:
        raise Exception
    future_1 = queue_0.get(timeout=(float)('0'))
    try:
        future_1.set_result(future_1)
    except:
        raise Exception
    future_2 = queue_0

# Generated at 2022-06-26 08:42:59.651146
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(10)
    future_0 = queue_0.put("")
    future_1 = queue_0.put("")
    future_2 = queue_0.put("")
    future_3 = queue_0.put("")
    future_4 = queue_0.put("")
    future_5 = queue_0.put("")
    future_6 = queue_0.put("")
    future_7 = queue_0.put("")
    future_8 = queue_0.put("")
    future_9 = queue_0.put("")
    future_10 = queue_0.put("")
    future_11 = queue_0.put("")
    future_12 = queue_0.put("")
    future_13 = queue_0.put("")
    future_14 = queue

# Generated at 2022-06-26 08:43:13.151387
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.locks import Event
    from tornado.queues import Queue
    from tornado.gen import coroutine, Future, sleep
    from tornado.ioloop import IOLoop

    @coroutine
    def case_1():
        queue_0 = Queue()
        for x in range(0, 100):
            yield queue_0.put(x)
            assert queue_0.qsize() == x + 1, "Error, qsize=" + str(queue_0.qsize()) + " != " + str(x + 1)
        assert queue_0.full() == True, "Error, full=" + str(queue_0.full()) + " != " + str(True)
        yield queue_0.put(x, timeout=1.0)

# Generated at 2022-06-26 08:43:14.148523
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait("Test")
    assert queue_0.qsize() == 1


# Generated at 2022-06-26 08:43:23.652574
# Unit test for method put of class Queue
def test_Queue_put():
    import random
    import string
    import TypesUtil
    import QueueUtil

    queue_0 = Queue()

    value_0 = TypesUtil.get_value(queue_0)
    value_1 = TypesUtil.get_value(queue_0)
    value_2 = TypesUtil.get_value(queue_0)
    value_3 = TypesUtil.get_value(queue_0)
    value_4 = TypesUtil.get_value(queue_0)
    value_5 = TypesUtil.get_value(queue_0)
    value_6 = TypesUtil.get_value(queue_0)
    value_7 = TypesUtil.get_value(queue_0)
    value_8 = TypesUtil.get_value(queue_0)
    value_9 = TypesUt

# Generated at 2022-06-26 08:43:42.832399
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    
    # Case 0
    future_0 = queue_0.put("");
    assert isinstance(future_0, Future)
    assert future_0.done()
    
    # Case 1
    queue_1 = Queue()
    future_0 = queue_1.put("", 1);
    assert isinstance(future_0, Future)
    assert future_0.done()
    
    # Case 2
    try:
        queue_2 = Queue(0)
        future_0 = queue_2.put("", 1);
        assert False
    except QueueFull:
        assert True



# Generated at 2022-06-26 08:43:54.121848
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(3)

    print(queue_1.qsize())
    print(queue_1.empty())
    print(queue_1.full())

    queue_1.put_nowait(1)
    queue_1.put_nowait(2)

    print(queue_1.qsize())
    print(queue_1.empty())
    print(queue_1.full())

    queue_1.put_nowait(3)

    print(queue_1.qsize())
    print(queue_1.empty())
    print(queue_1.full())



# Generated at 2022-06-26 08:43:57.121617
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)


# Generated at 2022-06-26 08:44:05.342092
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    assert q.get_nowait() == 0
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4


# Generated at 2022-06-26 08:44:10.815054
# Unit test for method put of class Queue
def test_Queue_put():
    # Initialize a queue
    queue_1 = Queue()
    # Put a new item into the queue. The method would block until there is room.
    queue_1.put(1)



# Generated at 2022-06-26 08:44:20.024822
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(0)
    queue_0.put(1)
    queue_0.put(2)
    queue_0.put(3)
    queue_0.put(4)
    queue_0.put(5)
    queue_0.put(6)
    queue_0.put(7)
    queue_0.put(8)
    queue_0.put(9)
    queue_0.put(10)
    queue_0.put(11)
    queue_0.put(12)
    queue_0.put(13)
    queue_0.put(14)
    queue_0.put(15)
    queue_0.put(16)
    queue_0.put(17)
    queue_0.put(18)


# Generated at 2022-06-26 08:44:24.492552
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1._queue.append(10)
    res = queue_1._get()
    expected_res = 10
    assert res == expected_res


# Generated at 2022-06-26 08:44:33.922070
# Unit test for method get of class Queue
def test_Queue_get():
    print("Start test Queue.get on generic Queue")
    print("test Queue.get with Queue")
    queue = Queue()
    for i in range(10):
        queue.put(i)
    for i in range(10):
        f = queue.get()
        val = f.result()
        assert val == i, "Queue.get error"
    queue.join()
    print("Queue.get without exception")


# Generated at 2022-06-26 08:44:41.799203
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    test_case_0()
    queue_1 = Queue(1)
    assert queue_1.put_nowait(1) == None
    try:
        queue_1.put_nowait(222)
    except QueueFull:
        assert queue_1.full() == True # We have put one element, and the Queue is full
    else:
        assert False
    queue_2 = Queue()
    assert queue_2.put_nowait(1) == None
    assert queue_2.put_nowait(222) == None
    assert queue_2.qsize() == 2
    assert queue_2.put_nowait(333) == None
    assert queue_2.put_nowait(444) == None
    assert queue_2.qsize() == 4 
    assert queue_2.full() == False

# Generated at 2022-06-26 08:44:44.601972
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    future = q.put(1)
    assert future.result() == None


# Generated at 2022-06-26 08:44:55.447102
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(10)


# Generated at 2022-06-26 08:44:57.890471
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    try:
        queue_1.get_nowait()
    except QueueEmpty:
        return True
    return False


# Generated at 2022-06-26 08:45:06.056559
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # get_nowait is not supported with None argument
    queue_0 = Queue()
    try:
        result = queue_0.get_nowait(None)
        raise AssertionError("AssertionError expected, but not raised")
    except TypeError:
        pass
    except:
        raise AssertionError("Unexpected exception was raised")


# Generated at 2022-06-26 08:45:13.875848
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case 0
    queue_0 = Queue()
    sleep_time_0 = datetime.timedelta(seconds=2)
    future_0 = queue_0.put(None, timeout=sleep_time_0)
    assert isinstance(future_0, Future)
    assert future_0.done()

# Case 1
# simple usage
if __name__ == "__main__":
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    # setup the asynchronous loop
    AsyncIOMainLoop().install()
    test_case_0()
    test_Queue_put()
    asyncio.get_event_loop().run_forever()

# Generated at 2022-06-26 08:45:17.034949
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait({})


# Generated at 2022-06-26 08:45:23.579147
# Unit test for method put of class Queue
def test_Queue_put():
    async def async_put(qq: Queue):
        await qq.put(1)
        await qq.put(2)
        await qq.put(3)
        await qq.put(4)
        await qq.put(5)
        await qq.put(6)

    queue_: Queue[str] = Queue()
    f0 = async_put(queue_)
    import asyncio
    asyncio.get_event_loop().run_until_complete(f0)


# Generated at 2022-06-26 08:45:25.900845
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get_nowait()



# Generated at 2022-06-26 08:45:35.286221
# Unit test for method get of class Queue
def test_Queue_get():
    # Testcase: get() raises QueueEmpty if the empty is empty
    queue_1 = Queue()
    if not queue_1.empty():
        try:
            queue_1.get()
        except QueueEmpty:
            print("Testcase 0 passed")
        else:
            print("Testcase 0 failed")

    # Testcase: get() returns an item from the queue if the queue is not empty
    queue_2 = Queue()
    queue_2.put("A")
    queue_2.put("B")
    queue_2.put("C")
    item = queue_2.get()
    if item == "A" and not queue_2.empty():
        queue_2.get()
        if queue_2.qsize() == 1:
            print("Testcase 1 passed")

# Generated at 2022-06-26 08:45:45.506335
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    # Test that put_nowait raises QueueEmpty if there are no getters waiting
    # (as long as the queue isn't full).
    # Test that put_nowait raises QueueFull if the queue is full.
    # Test that put_nowait adds an item to the queue and wakes up a waiting getter.
    queue_0.put_nowait(2)
    queue_0.put_nowait(1)
    queue_0.put_nowait(4)
    queue_0.put_nowait(3)
    queue_0.put_nowait(3)
    queue_0.put_nowait(2)
    queue_0.put_nowait(1)
    queue_0.put_nowait(4)

# Generated at 2022-06-26 08:45:48.929174
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put(1)
    queue_0.get()


# Generated at 2022-06-26 08:46:03.618941
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = PriorityQueue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.put_nowait(100)


# Generated at 2022-06-26 08:46:11.317181
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = Future()
    try:
        q.put_nowait(f)
    except QueueFull:
        pass
    else:
        f.set_result(None)
    q._put(f)
    assert f.done()



# Generated at 2022-06-26 08:46:15.193718
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.put(1)
    queue_1.put(2)
    queue_1.get()
    queue_1.get_nowait()
    print(queue_1)

# Generated at 2022-06-26 08:46:28.445213
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0._init()
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._queue.append(1)
    queue_0._getters.append(1)
    queue_0._getters.append(1)


# Generated at 2022-06-26 08:46:34.041707
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    Futures = [queue_0.put(123)]
    print(Futures[0])
    assert queue_0.qsize() == 1
    assert queue_0._putters == []


# Generated at 2022-06-26 08:46:44.046535
# Unit test for method get of class Queue
def test_Queue_get():
    @gen.coroutine
    def consumer():
        async for item in queue_test:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                queue_test.task_done()
    @gen.coroutine
    def producer():
        for item in range(5):
            await queue_test.put(item)
            print('Put %s' % item)
    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        # Wait for producer to put all tasks.
        await producer()
        # Wait for consumer to finish all tasks.
        await queue_test.join()
        print('Done')

    queue_test = Que

# Generated at 2022-06-26 08:46:49.231095
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    try:
        queue_1.get_nowait()
    except QueueEmpty:
        print('Queue is empty!')



# Generated at 2022-06-26 08:46:53.801869
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.get_nowait()


# Generated at 2022-06-26 08:47:00.420686
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # Empty queue
    assert q.empty() == True
    assert q.qsize() == 0
    assert q.full() == False

    # Put one
    q.put_nowait(1)
    assert q.empty() == False
    assert q.qsize() == 1
    assert q.full() == False

    # Get one
    assert q.get_nowait() == 1


# Generated at 2022-06-26 08:47:01.737005
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put('a')


# Generated at 2022-06-26 08:47:13.302219
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    item = object()
    future = Future()
    q._getters.append(future)
    q._put(item)
    assert not q._getters
    assert future.done()
    assert future.result() is item



# Generated at 2022-06-26 08:47:24.678213
# Unit test for method put of class Queue
def test_Queue_put():
    queue_object = Queue()
    # for now assume item is always of type int
    item = 1
    timeout = 1  # type: Optional[Union[float, datetime.timedelta]]

    # get the queue's current size
    cur_max_size = queue_object.qsize()

    future_object = queue_object.put(item, timeout)

    # get the queue's current size
    cur_max_size_1 = queue_object.qsize()

    # check if the queue's size increased after putting an item
    assert (cur_max_size < cur_max_size_1)


# Generated at 2022-06-26 08:47:26.277634
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()



# Generated at 2022-06-26 08:47:29.470569
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    future = queue.get()

    assert future # yield tornado.gen.Task(queue.get)


# Generated at 2022-06-26 08:47:32.976026
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    can_be_awaitable_0 = queue_0.get()
    assert (can_be_awaitable_0 is not None)


# Generated at 2022-06-26 08:47:48.061332
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put('abcd')
    assert queue_0.qsize() == 1
    queue_0.put(1234)
    assert queue_0.qsize() == 2
    queue_0.put(1.234)
    assert queue_0.qsize() == 3
    queue_0.put(1.2 + 3j)
    assert queue_0.qsize() == 4
    queue_0.put(True)
    assert queue_0.qsize() == 5

    if queue_0.qsize() > 0:
        data = queue_0.get()
        assert data == 'abcd'
    if queue_0.qsize() > 0:
        data = queue_0.get()
        assert data is 1234

# Generated at 2022-06-26 08:47:51.498295
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(6)
    queue_0.put_nowait("L{u)\7f")
    item_0 = queue_0.get_nowait()
    assert item_0 == "L{u)\7f"


# Generated at 2022-06-26 08:47:53.107485
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1, 2)


# Generated at 2022-06-26 08:47:58.307819
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)



# Generated at 2022-06-26 08:48:02.862758
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put(1)
    queue_0.put(2)
    queue_0.get()
    queue_0.get()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:48:24.148456
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Case 0: Simple case
    queue_0 = Queue(maxsize=5)
    queue_0.put_nowait(1)
    assert 1 == queue_0.get_nowait()

    # Case 1: Queue is full
    queue_1 = Queue(maxsize=0)
    with pytest.raises(QueueFull):
        queue_1.put_nowait(1)

    # Case 2: put item when there is waiting getter
    queue_2 = Queue()
    get = queue_2.get()
    queue_2.put_nowait(1)
    with pytest.raises(RuntimeError):
        get.result()


# Generated at 2022-06-26 08:48:34.008420
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future = queue_0.get()
    print(future)
    i = 0
    while i < 1000:
        awaitable = queue_0.get()
        queue_0.put_nowait(i)
        i = i + 1
    queue_0.get()
    queue_0.get()
    queue_0.get()

    assert(queue_0 not in [1, 2, 3])
    assert(queue_0 not in [0, 2, 3])
    assert(queue_0 not in [0, 1, 3])
    assert(queue_0 not in [0, 1, 2])
    return


# Generated at 2022-06-26 08:48:39.589721
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()

    # Test expected paths
    assert queue.put('my item') is not None
    assert queue.put('my item', timeout=0.1) is not None
    assert queue.put('my item', timeout=datetime.timedelta(days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0, weeks=0)) is not None


# Generated at 2022-06-26 08:48:48.232520
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    print("Test Queue_get_nowait:")

    queue_get_nowait = Queue()

    before = time()
    task0 = queue_get_nowait.get_nowait()
    diff = time() - before
    print("Queue is empty, get_nowait waits for {}s ".format(diff))

    before = time()
    queue_get_nowait.put(1)
    task1 = queue_get_nowait.get_nowait()
    diff = time() - before
    assert task1 == 1
    print("Queue is not empty, get_nowait does not wait.")



# Generated at 2022-06-26 08:48:49.725708
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 08:48:53.941870
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(maxsize=1)
    future_0 = queue_0.put(1)
    future_0.set_result(1)


# Generated at 2022-06-26 08:48:56.545219
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get() is None
    assert q.get().done() == False


# Generated at 2022-06-26 08:48:58.473562
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.qsize() == 0


# Generated at 2022-06-26 08:49:08.200144
# Unit test for method put of class Queue
def test_Queue_put():
    @gen.coroutine
    def _callback():
        print("put")

    @gen.coroutine
    def _callback_2():
        print("put_2")
        raise gen.Return()

    inq = Queue()

    @gen.coroutine
    def _test():
        print("test0")
        #yield inq.put()
        yield inq.put(None)
        print("test1")
        inq.put(None)
        yield inq.put(None, None)
        print("test")
        inq.put(_callback())
        print("test2")
        inq.put(None, None)
        yield inq.put(None, None)
        print("test3")
        yield inq.put(None, _callback_2())

# Generated at 2022-06-26 08:49:15.400870
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        queue_1 = Queue()
        queue_1.get_nowait()
    except QueueEmpty as e:
        print('Raised expected exception: ', e)


# Generated at 2022-06-26 08:49:55.142530
# Unit test for method get of class Queue
def test_Queue_get():
    # create a queue
    queue_0 = Queue()
    # verify the type of the queue
    assert isinstance(queue_0, Queue)
    # put item "test_1" into the queue
    queue_0.put_nowait('test_1')
    # put item "test_2" into the queue
    queue_0.put_nowait('test_2')
    # put item "test_3" into the queue
    queue_0.put_nowait('test_3')
    # put item "test_4" into the queue
    queue_0.put_nowait('test_4')
    # get an item from the queue
    item_1 = queue_0.get_nowait()
    # make sure the item is "test_1"
    assert item_1 == 'test_1'
   

# Generated at 2022-06-26 08:50:06.455831
# Unit test for method put of class Queue
def test_Queue_put():
    print("Unit test for method put of class Queue")
    # make a queue
    queue_1 = Queue()
    # put item into the queue
    queue_1.put("Hello")
    queue_1.put("H")
    queue_1.put("W")
    queue_1.put("O")
    queue_1.put("R")
    queue_1.put("L")
    queue_1.put("D")
    assert queue_1.full() == True
    try:
        queue_1.put("1")
    except QueueFull:
        print("Error, cannot put more items into the queue")
    assert queue_1.qsize() == 7


# Generated at 2022-06-26 08:50:08.826566
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    timeout_0 = 5
    
    print(queue_0.get(timeout_0))


# Generated at 2022-06-26 08:50:10.728709
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(2)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:50:12.801673
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)



# Generated at 2022-06-26 08:50:16.208896
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)

    queue_1 = Queue()
    queue_1.put(
        0,
        timeout=None,
    )
    queue_1.put(
        0,
        timeout=datetime.timedelta(
            microseconds=0
        ),
    )


# Generated at 2022-06-26 08:50:19.380178
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait(0)
    except QueueFull:
        pass
    else:
        print("test failed")


# Generated at 2022-06-26 08:50:22.515504
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    #testcase 1
    queue.put(10)
    queue.get_nowait()
    queue.task_done()

    #testcase 2
    queue.empty()



# Generated at 2022-06-26 08:50:27.252838
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except Exception as e:
        if isinstance(e,QueueEmpty):
            print("QueueEmpty Exception is happenned")
            return
    assert False


# Generated at 2022-06-26 08:50:30.442920
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    with pytest.raises(QueueEmpty):
        queue_0.get_nowait()
