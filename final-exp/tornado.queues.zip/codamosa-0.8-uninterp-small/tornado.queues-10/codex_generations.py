

# Generated at 2022-06-26 08:41:13.975430
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        queue_0 = Queue()
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:41:17.501327
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    item_0 = 'item'
    timeout_0 = None
    future_0 = queue.put(item_0, timeout_0)


# Generated at 2022-06-26 08:41:27.635147
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(0)  
    # Test case 1
    # Case description: test put a item into a queue
    # Expected result: return a Future object
    future_0 = queue_0.put(3)
    future_1 = queue_0.put(4)
    future_2 = queue_0.put(5) 
    

# Generated at 2022-06-26 08:41:31.798044
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    item = 0
    try:
        queue_0.put_nowait(item) # Expects no exception
        state = 1
    except QueueFull:
        state = 2

    if state == 1:
        print("Success")
    else:
        print("Test Failed")


# Generated at 2022-06-26 08:41:40.276975
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("begin method")
    maxsize=int()
    queue_0 = Queue(maxsize)
    item=int()
    queue_0.put_nowait(item)
    item=float()
    queue_0.put_nowait(item)
    item=str()
    queue_0.put_nowait(item)
    return queue_0


# Generated at 2022-06-26 08:41:45.625204
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:41:51.855939
# Unit test for method get of class Queue
def test_Queue_get():
    # call method get of class Queue
    try:
        test_queue = Queue()
        test_queue.get()
    except QueueEmpty:
        # correct, do nothing
        pass
    except Exception:
        # wrong, raise an exception
        raise Exception("wrong")


# Generated at 2022-06-26 08:42:02.383045
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_empty_0 = QueueEmpty()
    queue_1 = Queue()
    #assert queue_1.put_nowait(1) == None
    print(queue_1)
    print(queue_1.qsize())
    print(queue_1.empty())
    print(queue_1.full())
    print(queue_1.put(1))
    print(queue_1)
    #assert queue_1.get_nowait() == 1
    print(queue_1.task_done())
    print(queue_1.join())
    print(queue_1.__repr__())
    print(queue_1.__str__())
    print(queue_1._format())


if __name__ == '__main__':
    test_case_0()
    test_Queue_put_nowait()

# Generated at 2022-06-26 08:42:05.433653
# Unit test for method put of class Queue
def test_Queue_put():
    A = Queue(maxsize = 0)
    B = Queue(maxsize = 0)
    B.put_nowait(2)

# Generated at 2022-06-26 08:42:17.619684
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize = 10)
    q.__put_internal("1")
    q.__put_internal("2")
    q.__put_internal("3")
    q.__put_internal("4")
    q.__put_internal("5")
    q.__put_internal("6")
    q.__put_internal("7")
    q.__put_internal("8")
    q.__put_internal("9")
    q.__put_internal("10")
    assert q.get_nowait() == "1"
    q.task_done()
    assert q.get_nowait() == "2"
    q.task_done()
    assert q.get_nowait() == "3"
    q.task_done()

# Generated at 2022-06-26 08:42:31.429338
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = Future()
    q._getters.append(future)
    future_set_result_unless_cancelled(future, q._get())


# Generated at 2022-06-26 08:42:37.691139
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    test_case_0()
    try:
        queue_0.put_nowait(1)
    except Exception as e:
        x = e
    else:
        x = None
    assert x is None


# Generated at 2022-06-26 08:42:42.002894
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    x:Awaitable[_T] = q.get() # normally returns Future
    assert x is not None
    #assert x == 'value'



# Generated at 2022-06-26 08:42:54.393081
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize = 2
    if maxsize is None:
        # print('TypeError')
        queue_empty_0 = QueueEmpty()
        queue_empty_0.__init__()
        # return

    if maxsize < 0:
        # print('ValueError')
        queue_empty_0 = QueueEmpty()
        queue_empty_0.__init__()
        # return

    _maxsize = maxsize
    _init = 0
    _getters = collections.deque([])  # type: Deque[Future[_T]]
    _putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
    _unfinished_tasks = 0
    _finished = Event()
    _finished.set()


# Generated at 2022-06-26 08:42:57.611057
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test: Put an item into the queue without blocking.
    # If no free slot is immediately available, raise QueueFull.
    queue_0 = Queue(0)
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:43:00.648267
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    _T = TypeVar("_T")
    queue_0 = Queue[QueueEmpty]()
    _T_0 = TypeVar("_T_0")
    queue_2 = Queue[_T_0]()
    test_case_0()


# Generated at 2022-06-26 08:43:06.825511
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    _queue = Queue(maxsize=0)
    try:
        _queue.put_nowait(1)
    except QueueEmpty as e1:
        return e1
    except Exception as e2:
        return e2


# Generated at 2022-06-26 08:43:17.127548
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    io_loop = ioloop.IOLoop.current()

    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    gen.convert_yielded(main())

    #

# Generated at 2022-06-26 08:43:21.816253
# Unit test for method get of class Queue
def test_Queue_get():
    try:
        queue_getter_0 = Queue()
        try:
            queue_getter_1 = queue_getter_0.get()
        except QueueEmpty:
            pass
    except Exception as e:
        raise ValueError('No such exception has be caught: {0}'.format(e))
    else:
        raise ValueError('Expected exception has not be raised')


# Generated at 2022-06-26 08:43:28.038586
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(None)
    queue_0.put_nowait(None)
    queue_0.put_nowait(None)
    queue_0.put_nowait(None)


# Generated at 2022-06-26 08:43:46.381748
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    print("Testing for Queue class - put() method")
    q.put(1)
    q.put(2)
    assert q.qsize() == 2, "Wrong Size"


# Generated at 2022-06-26 08:43:57.029008
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an instance of class Queue
    queue_0 = Queue()
    # Invoke method get of queue_0
    future_0 = queue_0.get()
    # Invoke method get of queue_0
    future_1 = queue_0.get(timeout=4.01191)
    # Invoke method get of queue_0
    future_2 = queue_0.get()
    # Invoke method put_nowait of queue_0
    queue_0.put_nowait(item=743.32)
    # Invoke method get of queue_0
    future_3 = queue_0.get()
    # Invoke method task_done of queue_0
    queue_0.task_done()
    # Invoke method put_nowait of queue_0

# Generated at 2022-06-26 08:44:04.097318
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except Exception as e:
        if(not isinstance(e, QueueFull)):
            return False
    else:
        return False
    return True


# Generated at 2022-06-26 08:44:17.761807
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    awaitable = queue.get()
    #  Return an awaitable which resolves once an item is available, or raises
    #  tornado.util.TimeoutError after a timeout.
    #  
    #  ``timeout`` may be a number denoting a time (on the same
    #  scale as tornado.ioloop.IOLoop.time, normally time.time), or a
    #  datetime.timedelta object for a deadline relative to the
    #  current time.
    #  
    #  .. note::
    #  
    #     The ``timeout`` argument of this method differs from that
    #     of the standard library's queue.Queue.get. That method
    #     interprets numeric values as relative timeouts; this one
    #     interprets them as absolute deadlines and requires
    #     timedelta objects

# Generated at 2022-06-26 08:44:20.221031
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    #
    queue_0.get()


# Generated at 2022-06-26 08:44:25.303274
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    future = queue.put(1, timeout=None)

    io_loop = ioloop.IOLoop.current()
    future.add_done_callback(lambda _: io_loop.stop())
    io_loop.start()



# Generated at 2022-06-26 08:44:33.542666
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test case 0
    queue_0 = Queue()
    queue_0.put_nowait(1)

    # Test case 1
    queue_1 = Queue(maxsize=1)
    queue_1.put_nowait(1)
    try:
        queue_1.put_nowait(2)
    except QueueFull:
        pass



# Generated at 2022-06-26 08:44:35.678634
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=100)
    q.get_nowait()


# Generated at 2022-06-26 08:44:49.035558
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(maxsize = 5)
    item = "str_0"
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 1
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 2
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 3
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 4
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 5
    queue_0.put_nowait(item)
    assert queue_0.qsize() == 5

    queue_1 = Queue(maxsize = 3)
    queue_1.put_nowait(item)

# Generated at 2022-06-26 08:44:52.722042
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    print(future_0)


# Generated at 2022-06-26 08:45:12.521682
# Unit test for method put of class Queue
def test_Queue_put(): 
    queue_0 = Queue()
    queue_1 = Queue()
    queue_2 = Queue()
    queue_2.maxsize = 2147483647
    queue_3 = Queue()
    queue_3.maxsize = 1
    queue_0.put("value")
    queue_1.put("value")
    queue_2.put("value")
    queue_3.put("value")
    queue_4 = Queue()
    queue_4.put("value", datetime.timedelta(days = 1))


# Generated at 2022-06-26 08:45:16.955775
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    # test return type of Queue.put
    f = q.put(1234)
    assert isinstance(f, Future)


# Generated at 2022-06-26 08:45:22.873303
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    # Test case 1: Call get_nowait when the queue is empty
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    # Test case 2: Call get_nowait when the queue is not empty
    q.put('test')
    data1 = q.get_nowait()
    if data1 == 'test':
        pass
    

# Generated at 2022-06-26 08:45:31.398573
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()

    def my_put():
        try:
            q.put('hello')
        except Exception as e:
            print(e)
            return e
        else:
            return 1

    future_error = my_put()
    if isinstance(future_error, Exception):
        print('Test method put of class Queue fails!')
    else:
        print('Test method put of class Queue passes!')



# Generated at 2022-06-26 08:45:40.772998
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test case: get a value when empty queue
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty as e:
        pass

    # Test case: get a value when queue has a value
    queue_1 = Queue(3)
    queue_1.__put_internal(8)
    assert(queue_1.get_nowait() == 8)


# Generated at 2022-06-26 08:45:48.007790
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:45:51.681257
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q_0 = Queue(0)
    try:
        q_0.put_nowait('item_0')
        assert False
    except:
        assert True


# Generated at 2022-06-26 08:45:58.625505
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(1)
    f = Future()
    print(q.put(1))
    # assert isinstance(q.put(1), Future) == True
    print(q.put(1))
    print(q.qsize())
    print(q.put(1))



# Generated at 2022-06-26 08:46:02.491069
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(item=12, timeout=1)
    queue_0.put_nowait(item=12)


# Generated at 2022-06-26 08:46:16.412277
# Unit test for method get of class Queue
def test_Queue_get():
    Q = Queue(maxsize = 6)
    Q.put("a")
    Q.put("b")
    Q.put("c")
    Q.put("d")
    Q.get()
    Q.get()
    Q.get()
    Q.get()
    #Q.task_done()
    #Q.task_done()
    #Q.task_done()
    #Q.task_done()
    '''
    Q.task_done()
    Q.task_done()
    Q.task_done()
    Q.task_done()
    '''
    #Q.join()
    #Q.get()
    #Q.task_done()
    #print(Q.__repr__)
    print(Q.__str__)


# Generated at 2022-06-26 08:46:48.710021
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Initializer
    queue = Queue()
    item1 = queue._get()
    item2 = queue._get()
    queue.task_done()
    queue._getters.append(Future())
    item3 = queue.get()
    queue._putters.append((item1, Future()))
    queue._putters.append((item2, Future()))
    queue._unfinished_tasks = 3
    queue.qsize()
    queue.empty()
    queue.full()
    queue.get_nowait()


# Generated at 2022-06-26 08:46:52.081479
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.get()


# Generated at 2022-06-26 08:46:59.746345
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an instance of Queue
    queue_0 = Queue()
    # Make the Queue empty
    queue_0.get_nowait()

    # Call method get of Queue
    result_0 = queue_0.get()
    assert result_0 != None

    # Call method get of Queue with argument timeout
    result_1 = queue_0.get(timeout=0)
    assert result_1 != None


# Generated at 2022-06-26 08:47:14.807512
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    
    async def consumer():
        # async for item in q:
        item = await q.get()
        try:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
        finally:
            q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    
    ioloop

# Generated at 2022-06-26 08:47:18.321147
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)

    future = q.get(timeout=0)
    assert future.result() == 1


# Generated at 2022-06-26 08:47:20.788029
# Unit test for method put of class Queue
def test_Queue_put():
    # test case 0
    q = Queue(maxsize=0)
    result = q.put(item=1, timeout=None)
    assert result == None


# Generated at 2022-06-26 08:47:24.175082
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 0     # default
    q = Queue(maxsize)
    q.put(1, 1)


# Generated at 2022-06-26 08:47:29.472989
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    first_result = q.get() # type: Future
    q.put(1)
    second_result = q.get() # type: Future
    third_result = q.get() # type: Future
    q.put(2)


# Generated at 2022-06-26 08:47:43.307306
# Unit test for method put of class Queue
def test_Queue_put():
    task_done_2 = QueueEmpty()
    task_done_1 = QueueEmpty()
    queue_empty_0 = QueueEmpty()
    _queue_1 = Queue(maxsize=2)
    _unfinished_tasks_0 = 0
    _maxsize_0 = 0
    ioloop_2 = ioloop.IOLoop
    ioloop_3 = ioloop.IOLoop
    ioloop_4 = ioloop.IOLoop
    ioloop_5 = ioloop.IOLoop
    ioloop_6 = ioloop.IOLoop
    ioloop_7 = ioloop.IOLoop
    ioloop_1 = ioloop.IOLoop
    future_5 = Future()
    future_2 = Future()
    future_3 = Future

# Generated at 2022-06-26 08:47:52.343195
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    print("Queue size: " + str(q.qsize()))
    print(q)

    # save the original value of putters
    putters_0 = q._putters

    # call put method
    item = 1
    q.put(item)

    # check that qsize and putters have been correctly updated
    assert q.qsize() == 1, "expected qsize 1, but got " + str(q.qsize())
    #assert q._putters == putters_0, "expected _putters " + str(putters_0) + ", but got " + str(q._putters)


# Generated at 2022-06-26 08:48:40.432721
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = q.get()
    if isinstance(f, Future):
        return
    raise Exception("Failed")


# Generated at 2022-06-26 08:48:47.520301
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        a = Queue(maxsize=0)
        try:
            a.put_nowait(1)
            assert a.qsize() == 1
            a.put_nowait(2)
            assert a.qsize() == 2
            a.put_nowait(3)
            assert a.qsize() == 3
        except QueueFull:
            assert False
    except AssertionError:
        assert False
    assert True


# Generated at 2022-06-26 08:49:00.002475
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=0)
    b = q.empty()
    b = q.full()
    i = q.qsize()
    try:
        i = q.task_done()
        i = q.get_nowait()
        b = q.join()
    except QueueEmpty:
        i = -1
    except Exception:
        i = -2
    else:
        i = -3
    try:
        i = q.task_done()
        i = q.get_nowait()
        b = q.join()
    except QueueEmpty:
        i = -1
    except Exception:
        i = -2
    else:
        i = -3
    b = q.full()
    b = q.empty()
    i = q.qsize()


# Generated at 2022-06-26 08:49:09.051268
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop

    q = Queue()

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)



# Generated at 2022-06-26 08:49:15.706167
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue(maxsize=0)
    queue_empty = QueueEmpty()
    item = queue.get_nowait()


# Generated at 2022-06-26 08:49:29.924366
# Unit test for method get_nowait of class Queue

# Generated at 2022-06-26 08:49:43.452173
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado.locks import Event
    from tornado.gen import Future, TimeoutError
    from tornado.concurrent import future_set_result_unless_cancelled
    from tornado.concurrent import Future
    import time
    import datetime
    import uuid
    import typing
    from typing import Deque, Tuple, Any

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print("Doing work on {}".format(item))
                await gen.sleep(0.01)
            finally:
                q.task_done()
    # End function consumer

    async def producer():
        for item in range(5):
            await q.put(item)

# Generated at 2022-06-26 08:49:56.369142
# Unit test for method put of class Queue
def test_Queue_put():
    """
    Test case 0: 
    """
    queue_0 = Queue()
    # A timeout of 0 is ignored...
    future_0 = queue_0.put(1, None)
    assert future_0 == None
    # ...but we can use a timedelta instead
    future_1 = queue_0.put(1, datetime.timedelta(0))
    assert future_1 == None
    # ...and if we instantiate a timedelta with an integer,
    # it is interpreted as a number of seconds.
    future_2 = queue_0.put(1, datetime.timedelta(seconds=0))
    assert future_2 == None
    # The __enter__ method returns self to support the context manager protocol:
    with queue_0 as queue_02:
        assert queue_02 == queue_0
   

# Generated at 2022-06-26 08:49:58.929585
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future = queue_0.get()
    future_0 = Future()
    assert isinstance(future_0, Future)


# Generated at 2022-06-26 08:50:02.973059
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    async def async_main():
        q = Queue()
        q.get_nowait()
    ioloop.IOLoop.current().run_sync(async_main)
