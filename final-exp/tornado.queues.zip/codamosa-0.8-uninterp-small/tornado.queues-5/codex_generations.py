

# Generated at 2022-06-26 08:41:23.678994
# Unit test for method put of class Queue
def test_Queue_put():
    # Test the case which will raise QueueFull
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main_test():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       #

# Generated at 2022-06-26 08:41:32.365640
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test the following conditions
    # q.empty()==True
    # q.full()==False
    # self._getters is not empty
    # queue is empty
    # self.full()==False
    # self._putters is empty
    # q.qsize()!=0
    async def foo():
        q = Queue(maxsize=2)
        try:
            q.put_nowait(1)
        except Exception as e:
            print(e)

    ioloop.IOLoop.current().run_sync(foo)


# Generated at 2022-06-26 08:41:35.806777
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)


# Generated at 2022-06-26 08:41:41.639486
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    item = 0
    timeout = 0.01
    q.put_nowait(item)
    assert q
    q.put_nowait(item)
    assert q
    q.put_nowait(item)
    assert q


# Generated at 2022-06-26 08:41:54.224105
# Unit test for method put of class Queue
def test_Queue_put():
    """
    Inputs:
    - item: _T, timeout: Optional[Union[float, datetime.timedelta]],
    """
    # Initialise local variables
    __tracebackhide__ = True
    item        = 2 # int()
    timeout     = datetime.timedelta(seconds=1)

    # Initialise class
    queue = Queue(maxsize=2) # Queue()

    # Call method
    future = queue.put(item, timeout) # Future[None]

    # Test correctness of future returned by method
    # Assert future is done
    assert future.done()

    # Assert future has a result
    assert future.result() is None

    # Assert future does not have an exception
    assert future.exception() is None

    # Test correctness of other return types

# Generated at 2022-06-26 08:42:06.535349
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        await gen.sleep(0.01)
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-26 08:42:17.960883
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                # await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    io_loop = ioloop.IOLoop.current()

# Generated at 2022-06-26 08:42:29.788672
# Unit test for method put of class Queue
def test_Queue_put():
    # 一个队列一个值
    q = Queue()
    # 获取队列第一个值
    val = q.get()
    # 将值放入队列的尾部
    q.put(val)
    # 队列的长度
    len(q)
    # 删除队列的第一个值
    del q[0]
    # 获取队列的第一个值
    q[0]
    # 队列的第一个值
    q.popleft()
    # 给

# Generated at 2022-06-26 08:42:42.004651
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)




# Generated at 2022-06-26 08:42:54.393514
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_1 = Queue()
    queue_2 = Queue()
    queue_3 = Queue()
    queue_4 = Queue()
    queue_5 = Queue()
    queue_6 = Queue()
    queue_6.get_nowait()
    queue_7 = Queue()
    queue_7.put_nowait(0)
    queue_8 = Queue()
    queue_9 = Queue()
    queue_10 = Queue()
    queue_11 = Queue()
    queue_11.put_nowait(0)
    queue_12 = Queue()
    queue_12.put_nowait(0)
    queue_13 = Queue()
    queue_13.task_done()
    queue_14 = Queue()
    queue_15

# Generated at 2022-06-26 08:43:10.225712
# Unit test for method get of class Queue
def test_Queue_get():
    test_object_0 = Queue()
    test_timeout_0 = None
    result_0 = test_object_0.get(test_timeout_0)
    assert True
    # Test for __str__ and __repr__
    assert test_object_0.__str__() is not None
    assert test_object_0.__repr__() is not None


# Generated at 2022-06-26 08:43:17.488897
# Unit test for method get of class Queue
def test_Queue_get():
    if __name__ == '__main__':
        # Create an instance
        test_q = Queue()
        # Call the method
        test_q.get()
        # Check the result
        if test_q.empty():
            print("Queue is empty")
        else:
            print("Queue is not empty")
        print(test_q)


# Generated at 2022-06-26 08:43:21.446271
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()

    # Empty Queue
    try:
        q.put_nowait(None)
    except QueueFull as e:
        queue_full_0 = e

test_case_0()
test_Queue_put_nowait()

# vim:ts=4:sw=4:et:ft=python

# Generated at 2022-06-26 08:43:23.410153
# Unit test for method get of class Queue
def test_Queue_get():
    # Instantiate a Queue
    q = Queue(0)

    # Call the method get
    timeout = None
    result = q.get(timeout)


# Generated at 2022-06-26 08:43:31.952175
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_1 = Queue()
    print(queue_0.qsize())
    print(queue_0.full())
    print(queue_1.full())
    queue_1.put_nowait(2)
    try:
        queue_1.put_nowait(5)
    except QueueFull:
        pass
    queue_0.put(2)
    queue_0.put(2)
    try:
        queue_0.put_nowait(1)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:43:39.852291
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print('\n')
    print('---- Running test_case_1 for Queue.put_nowait() ----')
    queue_full_0 = QueueFull()
    print('-- Type of queue_full_0 is :%s' % type(queue_full_0))
    print(queue_full_0.args)


# Generated at 2022-06-26 08:43:41.966098
# Unit test for method get of class Queue
def test_Queue_get():
    ioloop.IOLoop.current().run_sync(test_case_0)


# Generated at 2022-06-26 08:43:55.286502
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

    future = q.get()
    try:
        future.result()
    except Exception as e:
        assert str(e) == 'QueueEmpty: qsize is 0'
    future = q.get(timeout=0.01)
    try:
        future.result()
    except Exception as e:
        assert str(e) == 'TimeoutError'

    q.put_nowait(0)
    q.put_nowait(1)

    future = q.get()
    assert future.result() == 0
    future.cancel()

    future = q.get(timeout=0.01)
    assert future.result() == 1
    future.cancel

# Generated at 2022-06-26 08:44:07.658640
# Unit test for method get of class Queue
def test_Queue_get():
    value = None
    item = value
    timeout = None
    future = Future()
    queue = Queue()
    from tornado.gen import TimeoutError
    from tornado.util import TimeoutError
    from concurrent.futures import TimeoutError
    from tornado.util import TimeoutError
    from concurrent.futures import TimeoutError
    from concurrent.futures import TimeoutError
    if type(timeout) is datetime.timedelta:
        timeout = timeout.total_seconds()
    if timeout is not None:
        if not isinstance(timeout, numbers.Real):
            raise TypeError("timeout must be a real number, not %r" % timeout)
        elif timeout < 0:
            raise ValueError("timeout must be non-negative, not %r" % timeout)
    from tornado.locks import Event

# Generated at 2022-06-26 08:44:11.022357
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    try:
        timeout = None
        q.put(item=None, timeout=timeout)
    except Exception as e:
        print(e)
    try:
        q.put_nowait(item=None)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:44:21.884220
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue = Queue()
    # item = queue.get_nowait()
    # item = queue.get_nowait(timeout=0.2)
    return


# Generated at 2022-06-26 08:44:24.673760
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    try:
        queue.put()
    except:
        pass


# Generated at 2022-06-26 08:44:34.341590
# Unit test for method put of class Queue
def test_Queue_put():
    buffer_len = 1
    queue_0 = Queue(buffer_len)
    ioloop_0 = ioloop.IOLoop()
    item = 0
    timeout = 0.1
    future = queue_0.put(item, timeout)
    future.add_done_callback(ioloop_0.stop)
    ioloop_0.start()
    if (future.result() is not None):
        raise RuntimeError


# Generated at 2022-06-26 08:44:45.789763
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """class Queue
    |  Method get_nowait(self)
    |
    |  Remove and return an item from the queue without blocking.
    |
    |  Return an item if one is immediately available, else raise
    |  QueueEmpty.
    """
    # def __init__(self, maxsize: int = 0) -> None:
    queue = Queue(maxsize=0)
    # queue.empty() -> bool
    if queue.empty():
        test_case_0()
    
    


# Generated at 2022-06-26 08:44:56.521148
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    a_queue = Queue(maxsize=2)
    a_queue.put_nowait(0)
    a_queue.put_nowait(1)
    b_queue = Queue(maxsize=0)
    b_queue.put_nowait(0)
    c_queue = Queue(maxsize=1)
    try:
        c_queue.put_nowait(0)
        c_queue.put_nowait(1)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:45:06.967246
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_1 = Queue()

    queue_2 = Queue()
    queue_2.put(int, float)

    queue_3 = Queue()
    queue_3.empty()
    queue_3.put(float)

    queue_4 = Queue()
    queue_4.empty()
    queue_4.put(int)
    queue_4.put(float, float)


# Generated at 2022-06-26 08:45:14.603387
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    promise_0 = Future()
    future_0 = queue_0.get(timeout=2.969)
    # Unit test for method get_nowait of class Queue
    queue_1 = Queue()
    promise_1 = Future()
    # Unit test for method put of class Queue
    queue_2 = Queue()
    promise_2 = Future()
    future_1 = queue_2.put(3, timeout=1.0)
    # Unit test for method put_nowait of class Queue
    queue_3 = Queue()
    promise_3 = Future()
    queue_4 = Queue(maxsize=5)
    promise_4 = Future()
    queue_4.put_nowait(4)
    # Unit test for method qsize of class Queue
    queue_

# Generated at 2022-06-26 08:45:17.883638
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue(maxsize = 1)
    f = queue.get(timeout = 1) 



# Generated at 2022-06-26 08:45:22.062314
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(2);
    gen_0 = gen.sleep(0.01);
    future_0 = queue_0.put(0, timeout = gen_0);

    # test gen.sleep
    #gen_0 = gen.sleep(0.01);



# Generated at 2022-06-26 08:45:34.004936
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import sys
    import os
    import unittest
    path = os.path.dirname(os.path.dirname(__file__))
    sys.path.insert(0, path)
    from tornado.queues import Queue, QueueFull
    try:
        import asyncio
    except ImportError:
        asyncio = None
    else:
        from tornado.platform.asyncio import BaseAsyncIOLoop
    import tornado
    import types
    @gen.coroutine
    def test_case():
        queue = Queue(2)
        future = Future()
        try:
            queue.put_nowait(1)
            queue.put_nowait(2)
            queue.put_nowait(3)
        except QueueFull:
            future.set_result(True)

# Generated at 2022-06-26 08:45:55.687220
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    obj_Queue_put_nowait = Queue()

    obj_Queue_put_nowait.put_nowait(0)

    assert obj_Queue_put_nowait._queue == [0,]


# Generated at 2022-06-26 08:45:59.071025
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(5)
    fault_0 = q.put(5)
    assert fault_0.result() == None


# Generated at 2022-06-26 08:46:06.916357
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1.
    priority_queue_1 = PriorityQueue()
    priority_queue_1.put_nowait(1)
    assert priority_queue_1.qsize() == 1
    assert len(priority_queue_1._queue) == 1
    assert priority_queue_1._putters == []
    assert priority_queue_1._getters == []
    assert priority_queue_1._unfinished_tasks == 1
    assert priority_queue_1._finished.is_set() == False
    # 2.
    priority_queue_1.put_nowait(2)
    assert priority_queue_1.qsize() == 2
    assert len(priority_queue_1._queue) == 2
    assert priority_queue_1._putters == []
    assert priority_queue_1._getters == []
    assert priority_queue

# Generated at 2022-06-26 08:46:17.775576
# Unit test for method put of class Queue
def test_Queue_put():
    # Tested case: put a new item into the queue.
    q_put1 = Queue()
    # Tested case: put a fulled queue.
    q_put2 = Queue(1)
    q_put2.put_nowait(1)

    # Tested case: put a fresh item into the queue.
    item1 = 1
    future1 = q_put1.put(item1)
    assert future1.done()
    assert future1.result() == None
    assert q_put1.empty() == False

    # Tested case: put a fulled queue.
    item2 = 2
    future2 = q_put2.put(item2, timeout=1)
    assert future2.done() == False
    assert q_put2.full() == True


# Generated at 2022-06-26 08:46:29.121189
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    try:
        queue.get_nowait()
        print("queue is empty")
        assert False
    except QueueEmpty as e:
        print("queue is empty")
    queue.put(1)
    queue.put(2)
    assert 1 == queue.get_nowait()
    assert 2 == queue.get_nowait()
    try:
        queue.get_nowait()
        print("queue is empty")
        assert False
    except QueueEmpty as e:
        print("queue is empty")
    queue.task_done()
    queue.task_done()
    print("queue is empty")
    assert queue.empty()
    assert 1 == queue.get_nowait()
    assert 2 == queue.get_nowait()


# Generated at 2022-06-26 08:46:33.569592
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    if q.qsize() == 1:
        return True
    else:
        return False


# Generated at 2022-06-26 08:46:42.825085
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create a Queue object
    q_0 = Queue()
    # Create an empty Queue object
    q_1 = Queue(5)

    # Verify that the queue get_nowait method raises QueueEmpty error when
    # called on an empty queue object
    try:
        q_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError("q_0.get_nowait() should have raised QueueEmpty")

    # Verify that the queue get_nowait method raises QueueEmpty error when
    # called on an empty queue object
    try:
        q_1.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError("q_1.get_nowait() should have raised QueueEmpty")


#

# Generated at 2022-06-26 08:46:50.541824
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise ValueError()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise ValueError()


# Generated at 2022-06-26 08:46:51.679103
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait('0')


# Generated at 2022-06-26 08:46:53.624746
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()  # type: Queue[None]
    future = q.put(None)
    if future.done():
        future.result()
    else:
        future.set_result(None)


# Generated at 2022-06-26 08:47:13.664649
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-26 08:47:26.394313
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue(0)
    ioloop_current = ioloop.IOLoop.current()
    with pytest.raises(QueueEmpty):
        queue_0.get_nowait()
    queue_1 = Queue(10)
    with pytest.raises(QueueEmpty):
        queue_1.get_nowait()
    queue_2 = Queue(7)
    with pytest.raises(QueueEmpty):
        queue_2.get_nowait()
    queue_3 = Queue(3)
    with pytest.raises(QueueEmpty):
        queue_3.get_nowait()
    queue_4 = Queue(2)
    with pytest.raises(QueueEmpty):
        queue_4.get_nowait()
    queue_5 = Queue(3)


# Generated at 2022-06-26 08:47:40.234317
# Unit test for method get of class Queue
def test_Queue_get():
    # queue_0 = Queue()
    # queue_0.get()

    # queue_1 = Queue()
    # queue_1.get()

    # queue_2 = Queue()
    # queue_2.get()

    # queue_3 = Queue()
    # queue_3.get()

    # queue_4 = Queue()
    # queue_4.get()

    # queue_5 = Queue()
    # queue_5.get()

    # queue_6 = Queue()
    # queue_6.get()

    # queue_7 = Queue()
    # queue_7.get()

    # queue_8 = Queue()
    # queue_8.get()
    pass


# Generated at 2022-06-26 08:47:51.694689
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q0 = Queue()
    q1 = Queue()
    q2 = Queue()
    q3 = Queue()
    q4 = Queue()
    q5 = Queue()
    q6 = Queue()
    q7 = Queue()
    q8 = Queue()
    queue_full_list = [q0, q1, q2, q3, q4, q5, q6, q7, q8]
    q0.maxsize = 1
    q1.maxsize = 1
    q2.maxsize = 1
    q3.maxsize = 1
    q4.maxsize = 1
    q5.maxsize = 1
    q6.maxsize = 1
    q7.maxsize = 1
    q8.maxsize = 1

# Generated at 2022-06-26 08:47:57.662024
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_0 = PriorityQueue()
    priority_queue_0.put_nowait("1.23")
    priority_queue_0.put_nowait("-3.15")


# Generated at 2022-06-26 08:48:02.384671
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_0 = PriorityQueue()
    priority_queue_0.put_nowait(3)
    priority_queue_0.put_nowait(2)
    priority_queue_0.put_nowait(1)


# Generated at 2022-06-26 08:48:09.745746
# Unit test for method put of class Queue
def test_Queue_put():
    # Test default case
    my_queue = Queue()
    my_queue.put("hello")
    assert my_queue.qsize() == 1
    assert my_queue.get() == "hello"

    # Test maxsize option
    my_queue = Queue(3)
    my_queue.put("hello")
    my_queue.put("world")
    my_queue.put("!")
    assert my_queue.qsize() == 3
    assert my_queue.get() == "hello"
    assert my_queue.get() == "world"
    assert my_queue.get() == "!"
    assert my_queue.empty() == True
    my_queue.put("first full")
    my_queue.put("second full")
    my_queue.put("third full")
    assert my_queue.full

# Generated at 2022-06-26 08:48:21.734165
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(1)
    timeout_0 = datetime.timedelta()
    try:
        queue_0.put((1), timeout_0)
    except QueueFull:
        pass
    try:
        queue_0.put((2), timeout_0)
    except QueueFull:
        pass
    queue_0.get()
    try:
        queue_0.put((3), timeout_0)
    except QueueFull:
        pass
    try:
        queue_0.put((4), timeout_0)
    except QueueFull:
        pass
    queue_0.get()
    try:
        queue_0.put((5), timeout_0)
    except QueueFull:
        pass

# Generated at 2022-06-26 08:48:31.368625
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    queue.put_nowait(4)
    queue.put_nowait(5)
    assert queue.qsize() == 5
    assert queue._queue == collections.deque([1, 2, 3, 4, 5])
    assert len(queue._getters) == 0
    assert len(queue._putters) == 0
    assert queue._unfinished_tasks == 5
    assert queue.empty() == False
    assert queue.full() == True


# Generated at 2022-06-26 08:48:42.720857
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q1 = Queue()
    ##q1.put_nowait(9)
    q2 = Queue()
    q2.put_nowait(10)
    q1.put_nowait(9)
    (test_elem1, test_elem2) = (11, 12)
    print(test_elem1,test_elem2)
    print(q1.qsize(),q2.qsize())
    q1.put_nowait(test_elem1)
    q2.put_nowait(test_elem2)
    print(q1.qsize(),q2.qsize())
    print(q1.get_nowait(),q2.get_nowait())
    print(q1.qsize(),q2.qsize())
# get_nowait method is called to

# Generated at 2022-06-26 08:48:53.202267
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    assert queue_0.get_nowait() == None


# Generated at 2022-06-26 08:49:03.965796
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print(__name__)
    q = Queue()
    print("This is the Queue object: ", q)
    print("This is the Queue object's put_nowait method: ", q.put_nowait)
    print("This is the Queue object's put_nowait method's first parameter: ", q.put_nowait.__code__.co_varnames[0])
    print("This is the Queue object's put_nowait method's co_varnames: ", q.put_nowait.__code__.co_varnames)
    print("This is the Queue object's put_nowait method's co_varnames: ", q.put_nowait.__code__.co_varnames[1:])

# Generated at 2022-06-26 08:49:04.596795
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass


# Generated at 2022-06-26 08:49:08.381789
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=3)
    queue.put_nowait(0)
    queue.put_nowait(1)
    queue.put_nowait(2)
    assert queue.qsize() == 3
    assert queue.full()
    assert queue.empty() == False


# Generated at 2022-06-26 08:49:25.308679
# Unit test for method put of class Queue
def test_Queue_put():
    async def async_put_test():
        # initialization
        q = Queue()
        assert q.qsize() == 0
        assert q.empty() == True
        assert q.full() == False
        assert q.maxsize == 0

        # put one item
        q.put_nowait(1)
        assert q.qsize() == 1
        assert q.empty() == False
        assert q.full() == False
        assert q.maxsize == 0

        # put more items than maxsize
        q2 = Queue(2)
        assert q2.qsize() == 0
        assert q2.empty() == True
        assert q2.full() == False
        assert q2.maxsize == 2
        q2.put_nowait(1)
        assert q2.qsize() == 1
        assert q2

# Generated at 2022-06-26 08:49:34.636208
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    queue_0 = Queue()

    queue_0.put_nowait(None)

    queue_1 = Queue()

    queue_1.put_nowait(1)

    queue_2 = Queue()

    queue_2.put_nowait(None)

    queue_3 = Queue()

    queue_3.put_nowait(None)

    queue_4 = Queue()

    queue_4.put_nowait(None)

    queue_5 = Queue()

    queue_5.put_nowait(None)

    queue_6 = Queue()

    queue_6.put_nowait(None)

    queue_7 = Queue()

    queue_7.put_nowait(None)

    queue_8 = Queue()

    queue_8.put_nowait(None)

   

# Generated at 2022-06-26 08:49:47.970682
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case description:
    # 1. Put an item when the queue is empty.
    # 2. Put a item when the queue is full.
    # 3. Put a item when the getter is in the queue
    # 4. Put a item when the putter is in the queue
    
    q = Queue(maxsize = 3)
    q.put(1)
    q.put(2)
    q.put(3)
    try:
        q.put(4)
    except QueueFull:
        pass
    getter = Future()  # type: Future[None]
    q._getters.append(getter)
    q.put(4)
    putter = Future()  # type: Future[None]
    q._putters.append((4, putter))
    q.put(5)


# Generated at 2022-06-26 08:49:50.621897
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_1 = PriorityQueue()
    priority_queue_1.maxsize = -1
    priority_queue_1.put_nowait(0)


# Generated at 2022-06-26 08:50:00.578792
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
 
    # Put six strings into the queue
    # PriorityQueue is a subclass of Queue
    q.put(1)
    q.put(2)
    print(q)
    assert q.qsize() == 2

    # Get an item from the queue
    #get() method returns an awaitable which resolves once an item is available
    #or raises tornado.util.TimeoutError after a timeout.
    # q.get().
    # q.get_nowait()
    print(q.get_nowait())
    print(q.get_nowait())
    assert q.qsize() == 0


# Generated at 2022-06-26 08:50:02.843082
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    print(q)


# Generated at 2022-06-26 08:50:29.065728
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)


# Generated at 2022-06-26 08:50:39.587469
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # test case 1
    queue_0 = Queue()
    queue_1 = Queue(maxsize = 0)
    queue_2 = Queue(maxsize = 0)
    QueueEmpty_0 = QueueEmpty()
    queue_1.put_nowait(2)
    queue_1.put_nowait(2)
    queue_2.put_nowait(1)
    queue_2.put_nowait(1)
    # self.assertIsInstance(QueueEmpty_0, Exception, 'Assertion failed.')
    QueueEmpty_1 = QueueEmpty()
    # self.assertIsInstance(QueueEmpty_1, Exception, 'Assertion failed.')

# Generated at 2022-06-26 08:50:44.224237
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    try:
        assert q.empty()
        assert not q.full()
        q.put_nowait(1)
        assert q.full()
        q.put_nowait(2)
    except QueueFull:
        pass
    q.get_nowait()
    q.get_nowait()
    assert q.empty()
