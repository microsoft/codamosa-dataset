

# Generated at 2022-06-26 08:41:08.825749
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_1 = Queue()
    queue_1.put(0)
    queue_1.put(10)
    queue_1.put(1)
    queue_1.put(2)
    queue_1.put(3)
    queue_1.put(4)
    queue_0.put(queue_1)
    queue_0.put(queue_0)


# Generated at 2022-06-26 08:41:09.992795
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(1)
    future = queue_0.put("foo")
    future = queue_0.put("bar")


# Generated at 2022-06-26 08:41:15.746753
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    assert queue.empty()
    queue.put_nowait(1)
    assert not queue.empty()
    assert queue.qsize() == 1
    assert queue.maxsize == 0
    assert not queue.full()


# Generated at 2022-06-26 08:41:17.827130
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    assert  queue_0.put_nowait(1) == None



# Generated at 2022-06-26 08:41:22.069465
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    print(queue_0.get)


# Generated at 2022-06-26 08:41:33.720964
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q_0 = Queue(maxsize=2)

    # TestCase 1:
    # 1, 2, 3, 4, 5
    # Doing work on 1
    # Putting 1
    # Doing work on 2
    # Putting 2
    # Doing work on 3
    # Putting 3
    # Doing work on 4
    # Putting 4
    # Doing work on 5
    # Putting 5
    # Done

    async def consumer_0():
        async for item_0 in q_0:
            try:
                print("Doing work on %s" % item_0)
                await gen.sleep(0.01)
            finally:
                q_0.task_done()


# Generated at 2022-06-26 08:41:42.574804
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue object
    queue_0 = Queue()
    # Put an item into the queue
    # Return a future object
    future_0 = queue_0.put(1)
    queue_0.task_done()
    # Block until all items in the queue are processed 
    future_1 = queue_0.join()
    # Return an awaitable, which raises tornado.util.TimeoutError after a timeout
    future_2 = queue_0.join(10)


# Generated at 2022-06-26 08:41:50.054681
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put_nowait(1)

    future_future = queue_0.get()
    result_result = future_future.result()
    assert result_result == 1, "queue_0.put_nowait(1) + queue_0.get().result() != 1"
 

# Generated at 2022-06-26 08:41:53.192123
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)

    assert queue_0.qsize() == 2
    assert queue_0.maxsize == 0


# Generated at 2022-06-26 08:42:01.615625
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import pytest
    from tornado.queues import Queue, QueueEmpty
    queue_0 = Queue()
    # Exception: QueueEmpty:
    with pytest.raises(QueueEmpty):
        try:
            queue_0.get_nowait()
        except Exception as e:
            print("Exception: " + str(type(e)))
            raise



# Generated at 2022-06-26 08:42:15.305955
# Unit test for method get of class Queue
def test_Queue_get():
    args = [0.5]
    ret = 0
    if type(args[0]) is int or type(args[0]) is float:
        assert isinstance(args[0], datetime.timedelta)
    # TODO: implement test

    assert ret == 0


# Generated at 2022-06-26 08:42:29.222642
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(maxsize = 5)

    # Test case 1
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 2
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 3
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 4
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 5
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 6
    # queue_0.put(item = 1, timeout = 0.01)

    # Test case 7
    future_0 = queue_0.put(item = 1, timeout = 0.01)

# Generated at 2022-06-26 08:42:41.761974
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    '''
    Test case 1: Put data that is valid, expected to return result successfully.
    '''
    queue_0 = Queue()
    try:
        queue_0.put_nowait(1)
        item = queue_0.get_nowait()
        print(item)
        assert(item == 1)
    except QueueFull as e:
        print("Exception: " + str(e))
        assert(False)
    except QueueEmpty:
        print("Exception: QueueEmpty")
        assert(False)
    '''
    Test case 2: Put data that is invalid, expected to raise exception QueueFull.
    '''
    try:
        queue_0.put(2)
        assert(False)
    except QueueFull as e:
        assert(True)


# Generated at 2022-06-26 08:42:54.236095
# Unit test for method get of class Queue
def test_Queue_get():
    import random

    @gen.coroutine
    def _consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(random.choice([0.01,0.02,0.03]))
            finally:
                q.task_done()

    @gen.coroutine
    def _producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def _main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(_consumer)
        yield _producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for

# Generated at 2022-06-26 08:42:56.400303
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    future_0 = queue_1.put("cQ6BC", None)
    assert future_0.done() is True


# Generated at 2022-06-26 08:43:00.513658
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    result = queue_0.put(1)
    queue_0.put(result)
    queue_0.put(1)
    queue_0.put(result)


if __name__ == "__main__":
    #test_Queue_put()
    test_case_0()

# Generated at 2022-06-26 08:43:13.536800
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.put_nowait(0)
    queue_0.task_done()
    queue_0.join()
    queue_0.get()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.put_nowait(0)
    queue_0.task_done()
    queue_0.join()
    queue_0.get()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.put_nowait(0)
    queue_0.task_done()
    queue_0.join()
    queue_0.get()

# Generated at 2022-06-26 08:43:21.754341
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    while True:
        item = 0
        if (item == 0):
            if (True):
                # State 0
                print("item = %i" % item)
                if (True):
                    # State 0
                    pass
                return None
            elif (queue_0.empty()):
                # State 1
                pass
        elif (queue_0.qsize() > 0):
            # State 2
            print("item = %i" % item)
            if (True):
                # State 2
                pass
            return None
        else:
            # State 3
            pass


# Generated at 2022-06-26 08:43:24.903936
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:43:30.348706
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    exception_0 = None
    try:
        queue_1.put_nowait(1)
    except Exception as exc:
        exception_0 = exc
    if isinstance(exception_0, QueueEmpty):
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 08:43:44.628144
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    array_0 = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    for i in range(20):
        q.put_nowait(array_0[i])
    assert q.qsize() == 20


# Generated at 2022-06-26 08:43:53.759864
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)

    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.put_nowait(1)
    queue_1.put_nowait(1)
    queue_1.put_nowait(1)
    queue_1.put_nowait(1)
    queue_1.put_nowait(1)


# Generated at 2022-06-26 08:44:02.645181
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a new Queue instance
    queue_0 = Queue()

    # Put a new item into the queue_0
    queue_0.put_nowait('test_string')
    # Get an item from the queue_0
    item = queue_0.get_nowait()
    # Check if item is equal to test_string
    assert item == 'test_string'



# Generated at 2022-06-26 08:44:07.753998
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        queue = Queue()
        queue.put_nowait("item")
    except Exception as e:
        print("test_Queue_put_nowait failed")
        raise e


# Generated at 2022-06-26 08:44:19.181866
# Unit test for method get of class Queue
def test_Queue_get():
    print("test_Queue_get")
    q = Queue()
    q.put(1)
    r = q.get()
    print(r)
    q.task_done()
    print("test_Queue_get done")

test_case_0()
test_Queue_get()

# class PriorityQueue(Queue[_T]):
#     """A ``Queue`` subclass that retrieves entries in priority order
#     (lowest first).
#
#     Entries are typically tuples of the form::
#
#         (priority_number, data)
#
#     .. testcode::
#
#         from tornado.queues import PriorityQueue
#         from tornado import gen
#         from tornado.ioloop import IOLoop
#
#         q = PriorityQueue()
#
#         async def consumer():
#             async

# Generated at 2022-06-26 08:44:28.997344
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)
    value_1 = queue_1.get_nowait()
    assert value_1 == 1, "queue_1.get_nowait() returns %r but should be 1" % value_1
    value_2 = queue_1.get_nowait()
    assert value_2 == 2, "queue_1.get_nowait() returns %r but should be 2" % value_2
    value_3 = queue_1.get_nowait()
    assert value_3 == 3, "queue_1.get_nowait() returns %r but should be 3" % value_3
    raise Exception("Not reached")


# Generated at 2022-06-26 08:44:34.343205
# Unit test for method put of class Queue
def test_Queue_put():
    instance_1 = Queue()
    future_0 = instance_1.put(item=1)
    assert isinstance(future_0, Future) and future_0.done() and future_0.result() is None



# Generated at 2022-06-26 08:44:35.410201
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()


# Generated at 2022-06-26 08:44:43.641027
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue
    queue_0 = Queue(maxsize=0)
    item = "string"
    try:
        queue_0.get_nowait()
    except:
        pass
    queue_0.put_nowait(item)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:44:46.028335
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    queue_1.put(5)


# Generated at 2022-06-26 08:45:04.818814
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.locks import Condition
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop

    q = Queue()

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print("Put %s" % item)


# Generated at 2022-06-26 08:45:06.276520
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass


# Generated at 2022-06-26 08:45:13.357065
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    item = 1
    queue_1.put_nowait(item)
    item_out = queue_1.get()
    assert item == item_out
    #  /home/ling/PycharmProjects/tornado_test/test/concurrent_tests.py:534: UserWarning: get() has no return statement, but returns value of type Future[int]
    #  return
    assert type(item_out) == Future


# Generated at 2022-06-26 08:45:24.579518
# Unit test for method put of class Queue
def test_Queue_put():
    import unittest
    import mock
    from tornado import gen, ioloop

    class TestQueuePut(unittest.TestCase):
        @mock.patch.object(Queue, 'put_nowait')
        @mock.patch.object(Queue, '_set_timeout')
        @mock.patch.object(Future, 'set_result')
        @mock.patch.object(Future, 'done')
        def test_put_0(self, mock_done, mock_set_result, mock_set_timeout, mock_put_nowait):
        #
            # -!- test 0 -!-
            mock_done.return_value = False
            mock_put_nowait.return_value = None

            queue_0 = Queue()

            future_0 = Future()

# Generated at 2022-06-26 08:45:34.858383
# Unit test for method put of class Queue
def test_Queue_put():
    """
    # test_Queue_put is the unit test function for method put of class Queue
    # The following is the trace generated by the unit test function
    # ../lib-python/3.7/test/test_queue.py:101:(test_Queue_put)
    # <- ../lib-python/3.7/queue.py:87:(put)
    #    <- ../lib-python/3.7/queue.py:55:(_put)
    #       <- ../lib-python/3.7/queue.py:35:(__init__)
    #          -> ../lib-python/3.7/queue.py:35:(__init__)
    # ../lib-python/3.7/test/test_queue.py:101:(test_Queue_put)

    """

# Generated at 2022-06-26 08:45:36.923951
# Unit test for method get of class Queue
def test_Queue_get():
    # Test cases for Queue.__init__()
    print("----------------------------------------------------------")
    print("Test case 0")
    queue_0 = Queue()
    print(queue_0)

    print("----------------------------------------------------------")
    print("Test case 1")
    queue_1 = Queue(maxsize = 5)
    print(queue_1)


# Generated at 2022-06-26 08:45:42.270937
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_2 = Queue()
    queue_2._getters.append(Future())

    assert (queue_1.get_nowait() == QueueEmpty)
    assert (queue_2.get_nowait() == QueueEmpty)


# Generated at 2022-06-26 08:45:46.222488
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.qsize()
    queue.maxsize
    queue.empty()
    queue.full()


# Generated at 2022-06-26 08:45:48.998742
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    await q.put(10)
    assert await q.get() == 10


# Generated at 2022-06-26 08:45:56.647625
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    def test_case_0():

        # Test for case 0
        q = Queue()
        q.put_nowait(1)
        assert q.qsize() == 1
        q.put_nowait(2)
        assert q.qsize() == 2
        q.put_nowait(3)
        assert q.qsize() == 3

        try:
            # On Python 3.7, the order is not guaranteed, but on
            # Python 3.6 and earlier, it is.
            assert q.get_nowait() == 1
            assert q.get_nowait() == 2
            assert q.get_nowait() == 3
        except AttributeError:
            pass
        assert q.qsize() == 0

        # Test for case 1

# Generated at 2022-06-26 08:46:22.982120
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait("test_value_1")
    queue_0.put_nowait("test_value_2")
    queue_0.put_nowait("test_value_3")
    queue_0.put_nowait("test_value_4")



# Generated at 2022-06-26 08:46:26.414414
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)

    # AssertionError: queue non-empty, why are getters waiting?
    # q.put_nowait(2)

    # AssertionError: queue not full, why are putters waiting?
    # q.put_nowait(2)

    # QueueFull
    # q.put_nowait(2)


# Generated at 2022-06-26 08:46:28.688358
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    item = queue.get()
    return item


# Generated at 2022-06-26 08:46:30.535822
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:46:41.820279
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Queue.get_nowait is a instance method. It needs to be called with an instance of
    # Queue.
    queue_1 = Queue()

    # Calling Queue.get_nowait with an empty queue
    try:
        queue_1.get_nowait()
        assert (False)
    except QueueEmpty:
        assert (True)

    # Calling Queue.get_nowait with an non-full queue
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    assert (queue_1.get_nowait() == 1)
    assert (queue_1.get_nowait() == 2)

    # Calling Queue.get_nowait with a full queue
    queue_1 = Queue(1)

# Generated at 2022-06-26 08:46:48.504877
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue_0 is the Queue object
    queue_0 = Queue()
    # Expected failure of method get_nowait of class Queue:
    # maxsize = 0, ...
    try:
        res_0 = queue_0.get_nowait()
    except Exception:
        pass
      # okay, this part is okay.


# Generated at 2022-06-26 08:47:00.240770
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue(maxsize=2)
    queue_1._queue = collections.deque([1,2])
    queue_1._unfinished_tasks = 2
    queue_1._finished.set()
    queue_1._getters = collections.deque([])
    queue_1._putters = collections.deque([])
    queue_1._consume_expired()
    assert queue_1.get_nowait() == 1
    assert queue_1.get_nowait() == 2
    try:
        queue_1.get_nowait()
        return False
    except:
        pass


# Generated at 2022-06-26 08:47:07.297952
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q_0 = Queue()
    # Verify that exception QueueEmpty is raised when queue is empty
    try:
        result_0 = q_0.get_nowait()
    except (QueueEmpty,) as e_0:
        pass


# Generated at 2022-06-26 08:47:17.365001
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_2 = Queue(10)
    queue_2.put_nowait(0)
    queue_2.put_nowait(1)
    queue_2.put_nowait(2)
    queue_2.put_nowait(3)
    queue_2.put_nowait(4)
    queue_2.put_nowait(5)
    queue_2.put_nowait(6)
    queue_2.put_nowait(7)
    queue_2.put_nowait(8)
    queue_2.put_nowait(9)

    # Test throwing QueueFull exception
    try:
        queue_2.put_nowait(0)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:47:20.776400
# Unit test for method get of class Queue
def test_Queue_get():
    # test get timeout
    queue_1 = Queue()
    assert queue_1.get(timeout=1) == None


# Generated at 2022-06-26 08:47:46.226465
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put("xzgfZ")
    queue_0.put("xzgfZ")
    queue_0.put("xzgfZ")
    print("Queue size is:", queue_0.qsize())
    print("Queue is empty:", queue_0.empty())
    print("Queue is full:", queue_0.full())
    print("put done!")


# Generated at 2022-06-26 08:47:49.485942
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    timeout = datetime.timedelta()
    queue_0.put(timeout)
    test_case_0()


# Generated at 2022-06-26 08:47:57.991735
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue for testing put method
    queue = Queue(4)
    queue.put(5)
    queue.put(5)
    queue.put(5)
    queue.put(5)
    assert queue.qsize() == 4
    assert queue.empty() == False
    queue.put(5)


# Generated at 2022-06-26 08:48:02.297581
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    # Test #1
    print("")
    print("test #1")
    queue_1 = Queue()
    test_result_1 = queue_1.get_nowait()


# Generated at 2022-06-26 08:48:09.699359
# Unit test for method get of class Queue
def test_Queue_get():
    # Test for method get(self) of class Queue
    from tornado.testing import gen_test, AsyncTestCase

    class TestQueueGet(AsyncTestCase):
        @gen_test
        async def test_get(self):
            q = Queue()
            await q.put(42)
            self.assertEqual(await q.get(), 42)

        @gen_test
        async def test_get_timeout(self):
            q = Queue()
            with self.assertRaises(gen.TimeoutError):
                await q.get(timeout=0.01)

        @gen_test
        async def test_get_timeout_command(self):
            q = Queue()

# Generated at 2022-06-26 08:48:21.184414
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put(2)
    queue_0.put(3)
    queue_0.put(4)
    queue_0.put(5)
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    pass



# Generated at 2022-06-26 08:48:28.545310
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    future_1 = queue_0.get()

    print("type(future_0) = ",)
    print(type(future_0))
    print("future_0.done() = ",)
    print(future_0.done())
    print("future_1.done() = ",)
    print(future_1.done())


# Generated at 2022-06-26 08:48:30.772930
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:48:42.097490
# Unit test for method put of class Queue
def test_Queue_put():
    # type: () -> None
    queue_0 = Queue()
    assert queue_0.maxsize == 0, f'expected queue_0.maxsize == {0}. got {queue_0.maxsize}'
    assert queue_0.qsize() == 0, f'expected queue_0.qsize() == {0}. got {queue_0.qsize()}'
    assert queue_0.empty() == True, f'expected queue_0.empty() == {True}. got {queue_0.empty()}'
    assert queue_0.full() == False, f'expected queue_0.full() == {False}. got {queue_0.full()}'
    queue_0.put('0')

# Generated at 2022-06-26 08:48:43.683291
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future: Future[None] = queue_0.get()


# Generated at 2022-06-26 08:49:24.242199
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    future = queue.put("Hello World")
    assert future is not None

# Generated at 2022-06-26 08:49:27.887744
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(99)
    queue_0.put_nowait(100)
    queue_0.put_nowait(101)



# Generated at 2022-06-26 08:49:30.803273
# Unit test for method get of class Queue
def test_Queue_get():
    queue1 = Queue()
    assert queue1.get() is not None


# Generated at 2022-06-26 08:49:33.990104
# Unit test for method put of class Queue
def test_Queue_put():
    # Create an instance of type Queue
    queue_0 = Queue()

    # Call method put
    queue_0.put(1)
    # Method put finished


# Generated at 2022-06-26 08:49:36.974868
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    f1 = q.put(item=1)
    pass




# Generated at 2022-06-26 08:49:47.175186
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    assert 0 == queue_0.qsize()
    queue_0.put(3)
    assert 1 == queue_0.qsize()
    queue_0.put(4)
    assert 2 == queue_0.qsize()
    queue_0.put(5)
    assert 3 == queue_0.qsize()
    queue_0.get()
    assert 2 == queue_0.qsize()
    queue_0.get()
    assert 1 == queue_0.qsize()
    queue_0.get()
    assert 0 == queue_0.qsize()


# Generated at 2022-06-26 08:49:52.557816
# Unit test for method get of class Queue
def test_Queue_get():
    q_0 = Queue()  # type: Queue[int]
    f_0 = Future()  # type: Future[int]
    f_0.set_result(None)
    q_0._getters.append(f_0)
    assert q_0.get() is f_0
    return 0

# Generated at 2022-06-26 08:50:01.878854
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    try:
        q.put(1)
    except:
        pass
    try:
        q.put_nowait(1)
    except:
        pass
    try:
        q.task_done()
    except:
        pass
    try:
        q.join()
    except:
        pass
    try:
        q.join(timeout=1)
    except:
        pass
    try:
        q.get()
    except:
        pass
    try:
        q.get(timeout=1)
    except:
        pass


# Generated at 2022-06-26 08:50:12.766561
# Unit test for method get of class Queue
def test_Queue_get():
    # The test code will be here.
    # Initialize the queue
    queue = Queue()

    # Check the initial size of the queue
    assert queue.qsize() == 0, "The initial size of the queue has not been correctly initialized"

    # Fill the queue with integers from 1 to 5
    for i in range(1, 6):
        queue.put(i)

    # Check the size of the queue
    assert queue.qsize() == 5, "The size of the queue has not been correctly updated"

    # Check the contents of the queue
    for i in range(1, 6):
        assert queue.get_nowait() == i, "The item popped from the queue is not the one expected"

    # __str__ method
    print(str(queue))

    # __repr__ method
    print(repr(queue))


# Generated at 2022-06-26 08:50:17.798393
# Unit test for method put of class Queue
def test_Queue_put():
    ioloop_current = ioloop.IOLoop.current()
    def my_callback():
        queue_0.put(2)
        queue_0.put(1)
        queue_0.put(0)
        async def consumer_0():
            async for item in queue_0:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            consumer_0.__code__
        ioloop_current.spawn_callback(consumer_0)
    ioloop_current.add_callback(my_callback)


test_case_1queue_0 = Queue()
