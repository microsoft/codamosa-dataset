

# Generated at 2022-06-26 08:41:22.545189
# Unit test for method put of class Queue
def test_Queue_put():
    # Test for __init__ of Queue
    q = Queue(maxsize=2)

    # Test for get of Queue
    # Test for put_nowait of Queue
    # Test for put of Queue
    async def producer():
        for item in range(5):
            await q.put(item)
            print ('Put %s' % item)

    ioloop.IOLoop.current().spawn_callback(producer)
    ioloop.IOLoop.current().start()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:41:33.901345
# Unit test for method put of class Queue
def test_Queue_put():
    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_0(self):
        pass

    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_1(self):
        pass

    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_2(self):
        pass

    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_3(self):
        pass

    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_4(self):
        pass

    # Note: parameters of the following function are mocked.
    def _gen_sleep_yield_5(self):
        pass

    # Note: parameters of the following function are mocked.


# Generated at 2022-06-26 08:41:45.144987
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    ioloop.IOLoop.configure('tornado.platform.asyncio.AsyncIOLoop')
    io_loop = ioloop.IOLoop.current()

    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    q = Queue(maxsize=2)

    coroutine = functools.partial(producer)
    future = io_loop.run_coroutine(coroutine())

    # Example call to put_nowait
    def call_put_nowait(self):
        self.put_nowait(item)

    nb_iterations = 100
    max_value = 1000
    max_queue_size = 2

    # We test the method on random inputs

# Generated at 2022-06-26 08:41:51.572377
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


# Generated at 2022-06-26 08:41:54.778434
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    # Call method put_nowait of object q
    q.put_nowait(0)


# Generated at 2022-06-26 08:42:06.785093
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_1 = Queue()
    queue_2 = Queue()
    queue_3 = Queue()
    queue_4 = Queue()
    queue_5 = Queue()
    queue_6 = Queue()
    queue_7 = Queue()
    queue_8 = Queue()
    queue_9 = Queue()

    val_0 = queue_0.put_nowait(queue_0)
    val_1 = queue_1.put_nowait(queue_5)
    val_2 = queue_2.put_nowait(queue_3)
    val_3 = queue_3.put_nowait(queue_7)
    val_4 = queue_4.put_nowait(queue_6)

# Generated at 2022-06-26 08:42:18.064158
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:42:25.433585
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(item=1)
    except QueueFull:
        print("q.put_nowait(item=1) raises QueueFull")
    else:
        print("q.put_nowait(item=1) does not raise QueueFull")


# Generated at 2022-06-26 08:42:30.871441
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()  # type: Queue
    try:
        queue_0.put_nowait(3)
    except QueueFull:
        print('QueueFull')


# Generated at 2022-06-26 08:42:41.910471
# Unit test for method put of class Queue
def test_Queue_put():
    print("Unit test case for method put of class Queue")
    queue_0 = Queue(5)
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.put_nowait(4)
    queue_0.put_nowait(5)
    #queue_0.put_nowait(6)
    future = queue_0.put(11, timeout = None)
    future_0 = future
    assert future_0.done()
    try:
        future_0.result()
    except:
        err = sys.exc_info()[1]
        print(err)


# Generated at 2022-06-26 08:43:00.288499
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Notes:
    Args:
    Return:
    """
    # Case 0
    print("-" * 80)
    queue_0 = Queue()
    output_str_0 = queue_0.get()
    print("output_str_0: ", output_str_0)

    # Case 1
    print("-" * 80)
    queue_1 = Queue()
    output_str_1 = queue_1.get(10)
    print("output_str_1: ", output_str_1)

    # Case 2
    print("-" * 80)
    queue_2 = Queue()
    output_str_2 = queue_2.get(None)
    print("output_str_2: ", output_str_2)

    # Case 3
    print("-" * 80)
    queue_3

# Generated at 2022-06-26 08:43:13.466356
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_2 = Queue()
    queue_2.put(0)
    queue_1.put(queue_2, timeout=None)
    queue_1.get()
    await queue_2.get()
    queue_2 = Queue()
    queue_2.put(1)
    queue_1.put(queue_2, timeout=None)
    queue_1.get()
    await queue_2.get()
    queue_2 = Queue()
    queue_2.put(2)
    queue_1.put(queue_2, timeout=None)
    queue_1.get()
    await queue_2.get()
    queue_2 = Queue()
    queue_2.put(3)
    queue_1.put(queue_2, timeout=None)

# Generated at 2022-06-26 08:43:21.189790
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(3)
    queue_0.put(3)
    queue_0.put(1)
    queue_0.put(4)
    queue_0.join()

    # Test for case 0
    assert queue_0.get() == 3
    assert queue_0.get() == 1
    assert queue_0.get() == 4
    # Test for case 1
    try:
        queue_0.get()
        assert False
    except QueueEmpty as e:
        assert True



# Generated at 2022-06-26 08:43:24.904065
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    assert queue_0.qsize() == 1


# Generated at 2022-06-26 08:43:27.371741
# Unit test for method put of class Queue
def test_Queue_put():
    queue1 = Queue()
    queue1.put(1)
    queue1.put(2)
    queue1.put(3)


# Generated at 2022-06-26 08:43:32.335114
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(maxsize=0)
    queue_0.put_nowait('q')
    queue_0 = Queue(maxsize=1)
    queue_0.put_nowait('q')
    queue_0.__put_internal('w')
    queue_0 = Queue(maxsize=3)
    queue_0._maxsize=1
    queue_0.put_nowait('q')


# Generated at 2022-06-26 08:43:45.020235
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1

    @gen.coroutine
    def wait_for_get():
        item = yield q.get()
        assert item == 2

    q.put_nowait(2)
    ioloop.IOLoop.current().spawn_callback(wait_for_get)

    assert len(q._getters) == 0
    assert q.qsize() == 1

    # Handle timeout, check that we don't spin forever
    future = q.get(timeout=0.1)
    ioloop.IOLoop.current().run_sync(lambda: future)

    q.put_nowait(3)
    assert q.get_nowait() == 3
    assert q.empty()
    future = q.get

# Generated at 2022-06-26 08:43:46.802151
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # if queue_0.empty():
    #     assert queue_0.get_nowait() == (
    #         gen.TimeoutError
    #     )  # raise QueueEmpty
    pass


# Generated at 2022-06-26 08:43:50.586927
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:44:04.317283
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_1 = QueueFull() # TODO: Create test case with concrete value
    queue_2 = QueueEmpty() # TODO: Create test case with concrete value
    queue_3 = QueueEmpty() # TODO: Create test case with concrete value
    queue_4 = QueueEmpty() # TODO: Create test case with concrete value
    queue_5 = QueueEmpty() # TODO: Create test case with concrete value
    queue_6 = QueueEmpty() # TODO: Create test case with concrete value
    queue_7 = QueueEmpty() # TODO: Create test case with concrete value
    queue_8 = QueueEmpty() # TODO: Create test case with concrete value
    queue_9 = QueueEmpty() # TODO: Create test case with concrete value
    queue_10 = QueueEmpty() #

# Generated at 2022-06-26 08:44:28.795675
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    def mock__init():
        queue_0._maxsize = 5
        mock__init.called = 1
        mock__init.mock_calls = 1
        mock__init.expected_calls = 1

    def mock_join(timeout = None):
        mock_join.called = 1
        mock_join.mock_calls = 1
        mock_join.expected_calls = 1
        return mock_join.result

    def mock__get():
        mock__get.called = 1
        mock__get.mock_calls = 1
        mock__get.expected_calls = 1
        return mock__get.result

    def mock__consume_expired():
        mock__consume_expired.called = 1
        mock__consume_expired.mock_calls = 1
        mock__consume

# Generated at 2022-06-26 08:44:34.214952
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    exception_0 = None
    try:
        queue_0.put_nowait(11)
    except Exception as exception:
        exception_0 = exception

    assert exception_0 is None


# Generated at 2022-06-26 08:44:36.664960
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    data_0 = Queue()
    data_0.put(1)
    data_1 = data_0.get_nowait()
    return data_1


# Generated at 2022-06-26 08:44:44.296288
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = q.get()  # type: Future[_T]
    #q.put_nowait(1)
    #assert future.result() == 1



if __name__ == "__main__":
    test_Queue_get()
    print("All tests passed!")

# Generated at 2022-06-26 08:44:49.239058
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future1 = queue_0.get()
    future2 = queue_0.get()

    ioloop.IOLoop.current().add_callback(lambda : queue_0.put_nowait(0))
    ioloop.IOLoop.current().add_callback(lambda : queue_0.put_nowait(0))

    ioloop.IOLoop.current().close()


# Generated at 2022-06-26 08:44:55.522508
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(2)
    int_1 = 1
    queue_0.put_nowait(int_1)
    queue_0.put_nowait(int_1)
    queue_0.put_nowait(int_1)


# Generated at 2022-06-26 08:45:04.969550
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(2)
    queue_0.put_nowait(2)
    queue_0.put_nowait(0)
    queue_0.put_nowait(0)
    queue_0.put_nowait(1)
    queue_0.put_nowait(1)
    queue_0.put_nowait(0)
    queue_0.put_nowait(0)
    queue_0.put_nowait(2)
    queue_0.put_nowait(2)
    queue_0.put_nowait(1)
    queue_0.put_nowait(1)
    # Test that the method put_nowait has added items to Queue
    print(len(queue_0._queue))



# Generated at 2022-06-26 08:45:09.166481
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q_put = q.put
    assert callable(q_put), "q.put is callable"


# Generated at 2022-06-26 08:45:19.323473
# Unit test for method put of class Queue
def test_Queue_put():
    print("begin to run test")
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.put_nowait(4)
    queue_0.put_nowait(5)
    queue_0.put_nowait(6)
    queue_0.put_nowait(7)

# Generated at 2022-06-26 08:45:24.298051
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    put1 = q.put("MESSAGE")
    assert put1._log_traceback is True
    assert put1._callbacks == []


# Generated at 2022-06-26 08:45:41.402081
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get(None)


# Generated at 2022-06-26 08:45:54.092947
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    q = Queue(maxsize=2)

    result = None

    @gen.coroutine
    def consumer():
        nonlocal result
        while True:
            item = yield q.get()
            try:
                #print('Doing work on %s' % item)
                yield gen.sleep(0.01)
                result = item
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(10):
            #print('Put %s' % item)
            yield gen.sleep(0.01)
            q.put_nowait(item)


# Generated at 2022-06-26 08:45:57.553547
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    try:
        queue_0.put(1)
    except:
        pass


# Generated at 2022-06-26 08:46:02.536594
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put('1')
    q.put('2')
    q.put('3')
    q.get()
    q.get()
    q.get()
    
    

# Generated at 2022-06-26 08:46:09.064653
# Unit test for method get of class Queue
def test_Queue_get():
    print('test_Queue_get')
    queue_0 = Queue()
    future_0 = queue_0.get()
    future_0.add_done_callback(lambda x: print(x.result()))
    #queue_0.get_nowait()


# Generated at 2022-06-26 08:46:14.967017
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    print(queue_0)
    
    

# Generated at 2022-06-26 08:46:28.347313
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put('/1KK2QNvl3Nw3oJlWEkbEi/X/fAHl+/p0J')
    future_1 = queue_0.put(';')
    future_2 = queue_0.put('<+')
    future_0 = queue_0.put('z')
    future_1 = queue_0.put('-')
    future_2 = queue_0.put('1')
    future_0 = queue_0.put('#')
    future_1 = queue_0.put('>')
    future_2 = queue_0.put('%')
    future_0 = queue_0.put('|')
    future_1 = queue_0.put('RkyXb&')
    future_

# Generated at 2022-06-26 08:46:40.451701
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.__put_internal(1)
    queue_0.__put_internal(2)
    queue_0.__put_internal(3)
    queue_0.__put_internal(4)
    queue_0.__put_internal(5)

    assert queue_0.get_nowait() == 1
    assert queue_0.get_nowait() == 2
    assert queue_0.get_nowait() == 3
    assert queue_0.get_nowait() == 4
    assert queue_0.get_nowait() == 5

    exception = None
    try:
        queue_0.get_nowait()
    except Exception as e:
        exception = e

    assert isinstance(exception, QueueEmpty)

# Generated at 2022-06-26 08:46:47.258898
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    queue_0.__put_internal(3)
    res = queue_0.get_nowait()
    assert res == 3


# Generated at 2022-06-26 08:46:49.148519
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(10)
    queue_0.put(20)
    

# Generated at 2022-06-26 08:47:22.277442
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)

    res = [queue_1.get_nowait(), queue_1.get_nowait(), queue_1.get_nowait()]
    assert res == [1, 2, 3], "Fail"


# Generated at 2022-06-26 08:47:24.521588
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    result = q.put("a")
    print("result = ", result)


# Generated at 2022-06-26 08:47:26.657749
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    print("Item taken from the queue:", queue_0.get())


# Generated at 2022-06-26 08:47:29.408405
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    assert (queue_0.get() is None)


# Generated at 2022-06-26 08:47:36.764922
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty as e:
        print("Test case 0 (Queue.get_nowait): Error message is: " + str(e))
    print("Test case 0 (Queue.get_nowait) passed")


# Generated at 2022-06-26 08:47:39.143807
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:47:51.124336
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.put(2)
    queue_1.put_nowait(3)
    queue_1.put_nowait(4)
    queue_1.put(1)
    print(queue_1.qsize())
    task_1 = queue_1.get()
    print(task_1.result())
    task_2 = queue_1.get()
    print(task_2.result())
    print(queue_1.qsize())
    queue_1.task_done()
    print(queue_1.empty())
    queue_1.task_done()
    print(queue_1.empty())
    queue_1.join()

if __name__ == "__main__":
    # test_case_0()
    test_Queue_get()

# Generated at 2022-06-26 08:48:02.122188
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    # The call Queue.get_nowait()
    # raises:
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass

    # The call Queue.get_nowait()
    # raises:
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass

if __name__ == '__main__':
    test_case_0()
    test_Queue_get_nowait()

# Generated at 2022-06-26 08:48:08.404276
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.put_nowait(4)
    queue_0.put_nowait(5)
    assert queue_0._queue[0] == 1
    assert queue_0._queue[1] == 2
    assert queue_0._queue[2] == 3
    assert queue_0._queue[3] == 4
    assert queue_0._queue[4] == 5


# Generated at 2022-06-26 08:48:13.218792
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = q.put(1)
    # f.result()
    # q.put(1, timeout=1)
    # q.put(1, timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-26 08:49:15.460255
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    item = 1
    queue.put_nowait(item)


# Generated at 2022-06-26 08:49:24.458738
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1, "queue get_nowait() failed"
    assert q.get_nowait() == 2, "queue get_nowait() failed"
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "queue get_nowait() failed"


# Generated at 2022-06-26 08:49:28.090007
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    ioloop.IOLoop.current().spawn_callback(put)
    ioloop.IOLoop.current().run_sync(lambda: async_get(q))


# Generated at 2022-06-26 08:49:31.167919
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:49:43.994273
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.empty()
    q.put_nowait(0)
    assert(len(q._getters)==0)
    assert(len(q._putters)==0)
    assert(not q.empty())
    assert(q.qsize() == 1)
    assert(q._unfinished_tasks == 1)
    assert(not q._finished.is_set())
    future = q.put(1, None)
    assert(future.done())
    assert(len(q._getters)==0)
    assert(len(q._putters)==0)
    assert(not q.empty())
    assert(q.qsize() == 2)
    assert(q._unfinished_tasks == 2)
    assert(not q._finished.is_set())
    future

# Generated at 2022-06-26 08:49:49.114989
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    def wrapper(future_object):
        print('Put done!')
        future_object.set_result(True)
    # Put an element into the queue
    queue.put(element = 'Hello', timeout = None).add_done_callback(wrapper)


# Generated at 2022-06-26 08:49:50.101373
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()


# Generated at 2022-06-26 08:49:53.211910
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put_nowait(0)
    assert q.get_nowait() == 0


# Generated at 2022-06-26 08:49:55.374240
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get_nowait()



# Generated at 2022-06-26 08:50:07.716029
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get_nowait()  # throws KeyError
    queue_0.get_nowait()  # throws QueueEmpty
    queue_0.get_nowait()  # throws KeyError
    queue_0.get_nowait()  # throws QueueEmpty
    queue_0.get_nowait()  # throws KeyError
    queue_0.get_nowait()  # throws QueueEmpty
    queue_0.get_nowait()  # throws KeyError
    queue_0.put(1)
    queue_0.get_nowait()  # throws QueueEmpty
    queue_0.get_nowait()  # throws KeyError
    queue_0.put(1)
    queue_0.get_nowait()  # throws QueueEmpty