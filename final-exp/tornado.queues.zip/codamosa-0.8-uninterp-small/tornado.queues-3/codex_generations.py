

# Generated at 2022-06-26 08:41:20.699969
# Unit test for method put of class Queue
def test_Queue_put():
    pass


# Generated at 2022-06-26 08:41:33.122832
# Unit test for method get of class Queue
def test_Queue_get():
    
    sleep_time = 0.1
    num_items = 1000
    maxsize = 10
    queue = Queue(maxsize=maxsize)
    queue.maxsize = maxsize
    queue2 = Queue(maxsize=maxsize)
    queue2.maxsize = maxsize
    getters = collections.deque([])
    putters = collections.deque([])
    unfinished_tasks = 0
    finished = Event()
    queue._getters = getters
    queue._putters = putters
    queue._unfinished_tasks = unfinished_tasks
    queue._finished = finished
    queue._queue = queue2._queue = collections.deque([])

    @gen.coroutine
    def  producer(i):
        for item in range(i):
            yield gen.sleep(sleep_time)

# Generated at 2022-06-26 08:41:38.119029
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise RuntimeError("Expected exception not raised")



# Generated at 2022-06-26 08:41:43.357267
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue(maxsize=3)

    queue_1.put_nowait(3)
    queue_1.put_nowait(4)
    queue_1.put_nowait(5)
    queue_1.get_nowait()
    queue_1.get_nowait()
    queue_1.get_nowait()

# Generated at 2022-06-26 08:41:46.735673
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(2)
    assert q.get_nowait() == 2


# Generated at 2022-06-26 08:41:48.314937
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put("")


# Generated at 2022-06-26 08:41:54.461427
# Unit test for method put of class Queue
def test_Queue_put():
    # call method put
    queue_1 = Queue(0)
    queue_1.put(0)
    queue_1.put(1)
    

# Generated at 2022-06-26 08:41:56.552793
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    queue_1.put(1)



# Generated at 2022-06-26 08:42:08.278151
# Unit test for method put of class Queue
def test_Queue_put():
    # queue_0 of class Queue is instantiated
    queue_0 = Queue()
    # queue_0_0 of type Future is assigned to the result of the call to put of queue_0 of class Queue
    queue_0_0 = queue_0.put("q")
    # queue_0_1 of type Future is assigned to the result of the call to put of queue_0 of class Queue
    queue_0_1 = queue_0.put("i")
    # queue_0_2 of type Future is assigned to the result of the call to put of queue_0 of class Queue
    queue_0_2 = queue_0.put("l")

    # queue_0_3 of type Future is assigned to the result of the call to put of queue_0 of class Queue

# Generated at 2022-06-26 08:42:12.360152
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    timeout = 0.0
    result = queue_0.get(timeout)


# Generated at 2022-06-26 08:42:29.704812
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    queue_0.put_nowait(1)
    assert queue_0.get_nowait() == 0, "Expected [0], got {0}".format(queue_0.get_nowait())
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    except Exception:
        assert False, "Unexpected exception"
    else:
        assert False, "Expected Exception"
    
    
    

# Generated at 2022-06-26 08:42:32.104428
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)

# Generated at 2022-06-26 08:42:38.757721
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    assert q.empty() is False
    assert q.full() is False
    assert q.maxsize == 0
    assert q.qsize() == 2
    assert q.put(3) is None
    assert q.put(4) is None


# Generated at 2022-06-26 08:42:46.564587
# Unit test for method get of class Queue
def test_Queue_get():
    # Initialize queue_0 of type Queue
    # import Queue
    queue_0 = Queue()
    # Initialize timeout of type None
    timeout = None
    # Return type of method get is Awaitable
    assert isinstance(queue_0.get(timeout), Awaitable)
    # print('Method get in class Queue tested successfully')



# Generated at 2022-06-26 08:42:50.422475
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test the put_nowait method of class Queue
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    assert queue_1.qsize() == 2


# Generated at 2022-06-26 08:42:54.235110
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait("string_0")
    queue_0.put_nowait("string_1")
    queue_0.put_nowait("string_2")



# Generated at 2022-06-26 08:42:59.226486
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        queue_0 = Queue(maxsize=5)
        # queue_0.get_nowait()
        raise Exception('')
    except QueueEmpty:
        pass
    queue_0 = Queue(maxsize=5)
    value_0 = queue_0.get_nowait()
    return queue_0, value_0


# Generated at 2022-06-26 08:43:02.090868
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q_0 = Queue()
    q_0.put_nowait('item_internal_0')


# Generated at 2022-06-26 08:43:11.599131
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    async def main():
        q = Queue()
        await q.put(42)

        assert (await q.get()) == 42
        with pytest.raises(QueueEmpty):
            # _QueueIterator explicitly catches QueueEmpty
            async for item in q:
                pass

        assert q.qsize() == 0
        # get_nowait
        with pytest.raises(QueueEmpty):
            q.get_nowait()
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(main)

# Generated at 2022-06-26 08:43:19.389470
# Unit test for method get of class Queue
def test_Queue_get():
    # Put the test case here
    queue_test = Queue()
    queue_test.maxsize = 1
    future_0 = queue_test.put(item=2)
    result_0 = queue_test.get()
    assert result_0 == 2
    future_1 = queue_test.put(item=3)
    result_1 = queue_test.get()
    assert result_1 == 3


# Generated at 2022-06-26 08:43:43.124724
# Unit test for method get of class Queue
def test_Queue_get():
    # Base case
    queue_0 = Queue()

    # Branch case 1
    queue_0 = Queue()
    timeout_0 = None

    with pytest.raises(Exception): queue_0.get(timeout_0)

    # Branch case 2
    queue_0 = Queue()
    timeout_0 = datetime.timedelta(5, 0, 0)

    with pytest.raises(Exception): queue_0.get(timeout_0)

    # Branch case 3
    queue_0 = Queue()
    timeout_0 = 0.0

    with pytest.raises(Exception): queue_0.get(timeout_0)



# Generated at 2022-06-26 08:43:55.953395
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.put_nowait(4)
    queue_0.put_nowait(5)
    queue_0.put_nowait(6)
    queue_0.put_nowait(7)
    queue_0.put_nowait(8)
    queue_0.put_nowait(9)
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.get_

# Generated at 2022-06-26 08:44:07.630588
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    print("queue_1 =", queue_1)
    item_0 = 1
    queue_1.put(item_0)
    fut_0 = Future()
    timeout_0 = 0.5
    queue_1.put(item_0, timeout=timeout_0)
    queue_1.put_nowait(item_0)
    print("queue_1 =", queue_1)
    print("queue_1.maxsize =", queue_1.maxsize)
    print("queue_1.qsize() =", queue_1.qsize())
    print("queue_1.empty() =", queue_1.empty())
    print("queue_1.full() =", queue_1.full())
test_Queue_put()


# Generated at 2022-06-26 08:44:12.871952
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    item_0 = ""
    timeout_0 = None
    future_0 = queue_0.put(item_0, timeout_0)


# Generated at 2022-06-26 08:44:14.824843
# Unit test for method get of class Queue
def test_Queue_get():
    # queue_0 = Queue()
    # queue_0.get([timeout])
    pass


# Generated at 2022-06-26 08:44:19.524166
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    # Call method get_nowait with correct arguments
    assert queue_0.get_nowait() == Queue()



# Generated at 2022-06-26 08:44:24.802782
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put_nowait(2)
    try:
        item = queue_0.get()
        print(item)
    except Exception as e:
        print(e)
        print("Get fail")


# Generated at 2022-06-26 08:44:29.439120
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue2 = Queue()
    queue2.put_nowait(None)
    queue.put_nowait(None)
    return


# Generated at 2022-06-26 08:44:32.763170
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put(5)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:44:37.549185
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put_nowait(2)
    q.put_nowait(1)
    q.put_nowait(4)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 4


# Generated at 2022-06-26 08:45:01.722410
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    assert queue_0.qsize() == 1


# Generated at 2022-06-26 08:45:09.167535
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    assert len(queue_0._queue) == 1
    assert queue_0._unfinished_tasks == 1
    assert queue_0._finished.is_set() == False
    queue_0.task_done()


# Generated at 2022-06-26 08:45:22.728590
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_2 = Queue(3)
    queue_3 = Queue()
    queue_3.put_nowait(0)
    queue_3.put_nowait(1)
    queue_3.put_nowait(2)

    # Test if QueueFull is raised when get_nowait is called on a full queue
    try:
        queue_3.get_nowait()
        queue_3.get_nowait()
        queue_3.get_nowait()
        queue_3.get_nowait()
    except QueueFull:
        pass
    else:
        raise AssertionError

    # Test if QueueEmpty is raised when get_nowait is called on an empty queue

# Generated at 2022-06-26 08:45:28.201110
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()
    queue_0.qsize()
    queue_0.empty()
    queue_0.full()


# Generated at 2022-06-26 08:45:30.868018
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    future = q.put("data", timeout=None)
    print(future)



# Generated at 2022-06-26 08:45:40.266597
# Unit test for method put of class Queue
def test_Queue_put():
    print("==================================")
    queue_0 = Queue()
    print(queue_0.maxsize)
    print(queue_0.qsize())
    print(queue_0.empty())
    print(queue_0.full())
    print("==================================")
    future_0 = queue_0.put(item=0, timeout=None)
    print(future_0.done())
    print(future_0.result())


# Generated at 2022-06-26 08:45:44.101250
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    try:
        queue.put_nowait('s')
        if queue.qsize() == 1:
            print('queue.put_nowait success!')
    except QueueFull as e:
        print(e)
    else:
        print('put_nowait exception')
    return


# Generated at 2022-06-26 08:45:51.292735
# Unit test for method put of class Queue
def test_Queue_put():
    print("Testing put method for Queue class")
    queue_0 = Queue()
    queue_0.qsize()
    queue_0.empty()
    queue_0.full()
    queue_0.put(1)
    queue_0.qsize()
    queue_0.empty()
    print("Successful")


# Generated at 2022-06-26 08:46:04.675678
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:46:17.146649
# Unit test for method get of class Queue
def test_Queue_get():
    print("Test get")
    queue = Queue()
    # Put to queue 2 elements
    queue.put(1)
    queue.put(2)
    # Check size of queue
    assert(queue.qsize() == 2)
    assert(queue.empty() == False)
    assert(queue.get_nowait() == 1)
    assert(queue.get_nowait() == 2)
    assert(queue.qsize() == 0)
    assert(queue.empty() == True)
    # Check join
    queue.put(1)
    queue.put(2)
    assert(queue.get_nowait() == 1)
    join_future = queue.join()
    assert(queue.get_nowait() == 2)
    assert(join_future.done() == True)
    # Check get with timeout
   

# Generated at 2022-06-26 08:47:00.715513
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(None)

if __name__ == '__main__':
    test_Queue_put_nowait()

# Generated at 2022-06-26 08:47:05.279169
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(43)
    assert queue_0.get() == 43


# Generated at 2022-06-26 08:47:14.167023
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    # future_1 is Future[None]: future_0.set_result(None)
    future_1 = Future()
    future_1.set_result(None)
    try:
        future_1.set_exception(Future())
        raise AssertionError("Expect an exception to be thrown")
    except TypeError as e:
        pass
    future_2 = Future()
    future_2.set_exception(Exception('test'))


# Generated at 2022-06-26 08:47:20.699711
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    for i in range(2):
        q.put_nowait(i)
    try:
        q.put_nowait(2)
        assert False
    except QueueFull:
        print("QueueFull")
        assert True


# Generated at 2022-06-26 08:47:24.716567
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except Exception as e:
        assert type(e) == QueueEmpty
    else:
        assert False



# Generated at 2022-06-26 08:47:28.290750
# Unit test for method put of class Queue
def test_Queue_put():
    queue_put = Queue()
    queue_put.put(1)
    queue_put.put(2)
    queue_put.put(3)


# Generated at 2022-06-26 08:47:31.538765
# Unit test for method get of class Queue
def test_Queue_get():
    # Arrange
    queue_0 = Queue()
    # Act
    act_result = queue_0.get()

    # Assert
    assert isinstance(act_result, Future)


# Generated at 2022-06-26 08:47:33.867759
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    assert queue_0.get_nowait()


# Generated at 2022-06-26 08:47:48.862531
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    
    try:
        queue_1.get_nowait()  # raises QueueEmpty
    except QueueEmpty:
        pass
    else:
        assert 0, 'Queue.get_nowait did not raise QueueEmpty'
    
    queue_2 = Queue()
    
    queue_2.put("one")
    queue_2.put("two")
    assert queue_2.get_nowait() == "one"
    assert queue_2.get_nowait() == "two"
    try:
        queue_2.get_nowait()  # raises QueueEmpty
    except QueueEmpty:
        pass
    else:
        assert 0, 'Queue.get_nowait did not raise QueueEmpty'
    
    queue_3 = Queue()
    queue_3

# Generated at 2022-06-26 08:47:51.010711
# Unit test for method get of class Queue
def test_Queue_get():
    str_0 = Queue()
    str_0.put(1)
    str_0.get()


# Generated at 2022-06-26 08:48:32.455574
# Unit test for method put of class Queue
def test_Queue_put():
    myqueue = Queue()
    myqueue.put('dog')
    myqueue.put(5)


# Generated at 2022-06-26 08:48:38.017703
# Unit test for method put of class Queue
def test_Queue_put():
    print ("test_Queue_put")

    queue_0 = Queue()

    future = queue_0.put('item_0', 10)
    print ("future = queue_0.put(\"item_0\", 10)")

    future.set_result(None)
    print ("future.set_result(None)")


# Generated at 2022-06-26 08:48:48.785206
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import time

    q = asyncio.Queue()

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        for i in range(4):
            asyncio.ensure_future(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-26 08:48:57.820195
# Unit test for method put of class Queue
def test_Queue_put():

    q = Queue(maxsize=2)
    f = Future()
    assert q.empty()
    try:
        q.put(-1, timeout=None)
        assert False
    except AssertionError:
        assert True
    try:
        q.put(-1, timeout=0)
    except AssertionError:
        assert True
    try:
        q.put(1)
    except AssertionError:
        assert True
    assert q.qsize() == 1
    assert not q.full()


# Generated at 2022-06-26 08:49:03.381242
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    for i in [1, 2, 3, 4, 5]:
        q.put_nowait(i)

    for i in [1, 2, 3, 4, 5]:
        assert q.qsize() == (5 - i)
        q.get_nowait()
        assert q.qsize() == (5 - i - 1)

    q.get_nowait()


# Generated at 2022-06-26 08:49:08.160538
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future = queue_0.get(timeout=0.3)
    # async def _get_future_result(future: Future[_T]) -> _T:
    #     return await future
    # result = IOLoop.current().run_sync(_get_future_result(future))


if __name__ == "__main__":
    test_Queue_get()

# Generated at 2022-06-26 08:49:25.040419
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.httsclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()
    url = 'http://127.0.0.1:8888/'

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     #

# Generated at 2022-06-26 08:49:32.004625
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case variables
    item = 0
    timeout = None
    future = Future()

    queue_0 = Queue()
    queue_1 = Queue(maxsize=0)
    queue_2 = Queue(maxsize=1)

    # Test code
    future = queue_0.put(item, timeout)
    future = queue_1.put(item, timeout)
    future = queue_2.put(item, timeout)


# Generated at 2022-06-26 08:49:33.949810
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()


# Generated at 2022-06-26 08:49:36.488908
# Unit test for method get of class Queue
def test_Queue_get():
    for x in range(10):
        test_Queue_get_x(x)
