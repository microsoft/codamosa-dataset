

# Generated at 2022-06-26 08:41:02.196866
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    future = queue_1.put(1)


# Generated at 2022-06-26 08:41:05.768453
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    assert queue_1.get_nowait() == 1


# Generated at 2022-06-26 08:41:07.576890
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(maxsize=0)
    queue_0.put_nowait(123)
    assert queue_0.get_nowait() == 123


# Generated at 2022-06-26 08:41:13.449300
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = Future()
    timeout_0 = None
    timeout_1 = None
    future_0 = queue_0.put(timeout_0, timeout_1)
    print(future_0)


# Generated at 2022-06-26 08:41:23.431212
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Instantiate a Queue object with pre-defined data
    queue_1 = Queue()
    queue_1.put(1)
    queue_1.put(2)
    queue_1.put(3)
    queue_1.put(4)

    # Call get_nowait
    val = queue_1.get_nowait()
    assert val == 1
    val = queue_1.get_nowait()
    assert val == 2
    val = queue_1.get_nowait()
    assert val == 3
    val = queue_1.get_nowait()
    assert val == 4


# Generated at 2022-06-26 08:41:29.992557
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue(5)

    # Test case 0
    future_0 = queue_1.get()
    future_0.set()

    # Test case 1
    future_1 = queue_1.get()
    future_1.set_exception(Exception())



# Generated at 2022-06-26 08:41:36.860024
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(5)
    queue_1.put_nowait(3)
    queue_1.put_nowait(7)
    return queue_1.qsize() == 3


# Generated at 2022-06-26 08:41:39.364019
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # q.get()



# Generated at 2022-06-26 08:41:45.584928
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.empty() == True
    assert q.full() == False
    q.put_nowait(1)
    assert q.empty() == False
    assert q.full() == False
    q.put_nowait(2)
    assert q.empty() == False
    assert q.full() == False
    q.put_nowait(3)
    assert q.empty() == False
    assert q.full() == False
    q.put_nowait(4)
    assert q.empty() == False
    assert q.full() == False



# Generated at 2022-06-26 08:41:54.898973
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Case 0
    print("\nCase 0:")
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty as e:
        print(type(e))
    # Case 1
    print("\nCase 1:")
    queue_1 = Queue(maxsize=0)
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)
    try:
        queue_1.get_nowait()
        queue_1.get_nowait()
        queue_1.get_nowait()
    except QueueEmpty as e:
        print(type(e))


# Generated at 2022-06-26 08:42:14.545983
# Unit test for method put of class Queue
def test_Queue_put():
    # test case number: 1
    queue_obj = Queue(maxsize=0)
    # test case number: 2
    queue_obj = Queue(maxsize=0)
    # test case number: 3
    queue_obj = Queue(maxsize=0)
    # test case number: 4
    queue_obj = Queue(maxsize=0)

    def __put_internal(self, item): pass
    Queue._put = __put_internal

    # test case number: 1
    try:
        queue_obj.put(item=1)
    except (QueueFull, StopIteration):
        pass


# Generated at 2022-06-26 08:42:28.759141
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    control_flag = True
    try:
        queue_1.get_nowait()
        control_flag = False
    except QueueEmpty as e:
        print('Exception caught:', e)
    assert control_flag == True

    queue_2 = Queue()
    queue_2.put_nowait(1)
    assert queue_2.get_nowait() == 1

    # test for the case when queue is full
    queue_2 = Queue(maxsize = 1)
    queue_2.put_nowait(1)
    control_flag = True
    try:
        queue_2.put_nowait(2)
        control_flag = False
    except QueueFull as e:
        print('Exception caught:', e)
    assert control_flag == True

#

# Generated at 2022-06-26 08:42:37.057453
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(20)
    future_0 = queue_0.put(1, None)
    future_1 = queue_0.put(1, None)
    future_2 = queue_0.put(1, None)
    future_3 = queue_0.put(1, None)
    future_4 = queue_0.put(1, None)
    future_5 = queue_0.put(1, None)
    future_6 = queue_0.put(1, None)
    future_7 = queue_0.put(1, None)
    future_8 = queue_0.put(1, None)
    future_9 = queue_0.put(1, None)
    future_10 = queue_0.put(1, None)

# Generated at 2022-06-26 08:42:42.303353
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    # queue.put_nowait(4)
    # queue.put_nowait(5)

    assert queue.qsize()==3
    assert queue.get_nowait()==1
    assert queue.get_nowait()==2
    assert queue.get_nowait()==3
    assert queue.qsize()==0


# Generated at 2022-06-26 08:42:49.964232
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    try:
        queue_1.put_nowait(1)
    except Exception as e:
        print(e)
    try:
        queue_1.put_nowait(1)
    except Exception as e:
        print(e)
    try:
        queue_1.put_nowait(1)
    except Exception as e:
        print(e)



# Generated at 2022-06-26 08:42:58.315550
# Unit test for method get of class Queue
def test_Queue_get():
    async def async_for_aiter(q):
        async for item in q:
            print("Doing work on %d" % item)


    # Testcase 1:
    print("\nTestcase 1: Async for, as a consumer")
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)

    ioloop.IOLoop.current().spawn_callback(async_for_aiter, q)
    ioloop.IOLoop.current().start()


# Generated at 2022-06-26 08:43:12.417887
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    try:
        queue.get_nowait()
    except QueueEmpty:
        print("The queue is empty")
    else:
        print("The queue is not empty")
    queue.put("item")
    queue.put("item1")
    queue.put("item2")
    assert queue.qsize() == 3, print("The size of the queue is not 3.")

    # Extracting each element from the queue and comparing with the elements in the queue
    assert queue.get_nowait() == "item", print("The element is not extracted properly from the queue.")
    assert queue.get_nowait() == "item1", print("The element is not extracted properly from the queue.")
    assert queue.get_nowait() == "item2", print("The element is not extracted properly from the queue.")


# Generated at 2022-06-26 08:43:23.020633
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put(0)
    future_1 = queue_0.put(0)
    future_2 = queue_0.put(0)
    future_3 = queue_0.put(0)
    future_4 = queue_0.put(0)
    future_5 = queue_0.put(0)
    future_6 = queue_0.put(0)
    future_7 = queue_0.put(0)
    future_8 = queue_0.put(0)
    future_9 = queue_0.put(0)
    future_10 = queue_0.put(0)
    future_11 = queue_0.put(0)
    future_12 = queue_0.put(0)
    future_13 = queue_0

# Generated at 2022-06-26 08:43:33.264841
# Unit test for method put of class Queue
def test_Queue_put():
    import random
    import json
    max_size = random.randint(0, 10)

    # Generate test cases
    test_cases = []
    num_test_cases = random.randint(1, 10)

    for _ in range(num_test_cases):
        queue_0 = Queue(maxsize=max_size)
        put_data = [random.random() for _ in range(10)]
        put_arr = [queue_0.put(data) for data in put_data]
        put_data.reverse()
        put_data.append('None')
        put_data.reverse()
        put_data.pop()
        put_data.reverse()
        put_arr.append(put_data)

        test_cases.append(put_arr)

    # Dump test cases into test_case

# Generated at 2022-06-26 08:43:45.252105
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado
    import random
    import time
    from tornado.ioloop import IOLoop, PeriodicCallback

    # define a function for callback in get
    def callback(queue):
        print("queue is empty, callback is fired.")
        IOLoop.instance().stop()

    # init the queue
    queue = Queue()

    # put random numbers into the queue
    random_int = random.randint(1, 10)
    print("Random number is: " + str(random_int))
    queue.put(random_int)

    # create an IOLoop instance
    io_loop = IOLoop.instance()

    # start the IOLoop, which immediately enters its run loop.
    io_loop.start()
    callback(queue) 
    # get the number from the queue
    result = queue.get()

   

# Generated at 2022-06-26 08:44:02.215343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(2345)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:44:04.263798
# Unit test for method get of class Queue
def test_Queue_get():
    for i in range(10):
        queue_0 = Queue()
        result_0 = queue_0.get()


# Generated at 2022-06-26 08:44:13.191614
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
  queue_0 = Queue()
  queue_0.maxsize
  # Normal, 1
  try:
    queue_0.get_nowait()
  except Exception as err:
    print("[test_Queue_get_nowait] Excepted: ", type(err), err)

if __name__ == "__main__":
    test_Queue_get_nowait()

# Generated at 2022-06-26 08:44:15.001551
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:44:19.168287
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.put_nowait(1)
    assert queue.get_nowait() == 1


# Generated at 2022-06-26 08:44:25.545693
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    @gen.coroutine
    def _get(*args, **kwargs) -> None:
        return_value = q.get(*args, **kwargs)
        print(type(return_value))
        #assert type(return_value) == type(Future)
    try:
        _get()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:44:36.693528
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()

    future_0 = q.put('Hello')
    future_0.result()
    assert q.qsize() == 1
    
    future_1 = q.put('World')
    future_1.result()
    assert q.qsize() == 2

    future_2 = q.put('Tornado')
    assert not future_2.done()

    future_3 = q.get()
    assert future_3.result() == 'Hello'

    assert future_2.done()
    assert future_2.result() is None

    assert q.qsize() == 2


# Generated at 2022-06-26 08:44:40.554458
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:44:50.358494
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # test1: set _getters of Queue
    _getters_0 = collections.deque([])
    q_0 = Queue()
    q_0._getters = _getters_0
    def __get_internal(self, item: _T) -> None:
        self._unfinished_tasks += 1
        self._finished.clear()
        self._put(item)
    Queue.__get_internal = __get_internal
    __get_internal(q_0, 4)

    # test2: set _getters, _putters of Queue, then get first element in _putters
    _getters_1 = collections.deque([])
    _queue_0 = collections.deque([1, 2, 3, "hello,world"])

# Generated at 2022-06-26 08:44:56.042981
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.empty()
    assert q.qsize() == 0
    assert q.full() == False
    assert q.maxsize == 0
    assert q.get_nowait() == 0


# Generated at 2022-06-26 08:45:22.751958
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()

    # Test case where self.qsize is False
    # Case: self.qsize is False
    try:
        queue_0.get_nowait()
        # Negative test for exception QueueEmpty
        assert False
    except QueueEmpty:
        pass
    except:
        assert False

    # Test case where self.qsize is True
    # Case: self.qsize is True
    try:
        queue_0._queue = [0, 1, 2, 3]
        queue_0.get_nowait()
    except QueueEmpty:
        assert False
    except:
        assert False
    # Test case where self.qsize is True
    # Case: self.qsize is True

# Generated at 2022-06-26 08:45:29.362896
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_instance = Queue()
    is_e = None
    try:
        queue_instance.get_nowait()
    except QueueEmpty as e:
        is_e = type(e) == QueueEmpty
    assert is_e == True


# Generated at 2022-06-26 08:45:32.372944
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(3)
    # Get the first element
    elem = queue_0._queue.popleft()
    assert elem == 3


# Generated at 2022-06-26 08:45:35.178528
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:45:37.905004
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    item = queue_0.get(1.6)


# Generated at 2022-06-26 08:45:42.782227
# Unit test for method put of class Queue
def test_Queue_put():
    print("Running test_Queue_put()")
    queue_0 = Queue()
    is_instance = isinstance(queue_0, Queue)
    print("Type of queue_0", is_instance)
    future = queue_0.put(1)
    print("future", future)


# Generated at 2022-06-26 08:45:46.987168
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:45:50.223482
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Init a Queue object
    queue_1 = Queue()
    # Invoke method put_nowait with parameter (item)
    queue_1.put_nowait(12)
    # Check if the return value of method put_nowait of object queue_1 is equal to None
    assert queue_1.put_nowait(12) == None
    print("Method put_nowait of class Queue invoked successfully!")
    pass

# Generated at 2022-06-26 08:45:52.150895
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    result = q.get()
    assert result


# Generated at 2022-06-26 08:46:03.182031
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """
    Check for the cases where Queue is not full

    Python version of CP-Abstraction:
    https://github.com/sapstheories/cp-abstraction/blob/master/verification/test/_test_cp_abstraction_test_cases/test_case_0.py

    """
    maxsize = 3
    queue = Queue(maxsize=maxsize)
    assert queue.empty() == True
    assert queue.full() == False

    # The next line is an assumption
    assert queue.qsize() <= maxsize


# Generated at 2022-06-26 08:46:25.841783
# Unit test for method put of class Queue
def test_Queue_put():
    test_0_queue = Queue()
    test_0_item = 1
    test_0_timeout = 0.1
    test_0_future = test_0_queue.put(test_0_item, test_0_timeout)

    test_1_queue = Queue()
    test_1_item = 1
    test_1_future = test_1_queue.put(test_1_item)



# Generated at 2022-06-26 08:46:28.688881
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.qsize()


# Generated at 2022-06-26 08:46:38.069551
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    r"""
    test case for get_nowait() of class Queue
    """
    queue_0 = Queue()
    item_0 = queue_0.get_nowait()
    assert queue_0.qsize() == 0
    assert item_0 == None
    print("No exception in test_Queue_get_nowait")
    print("queue_1 size, %s" % queue_0.qsize())
    print("item_1, %s" % item_0)


# Generated at 2022-06-26 08:46:42.242605
# Unit test for method put of class Queue
def test_Queue_put():
    # Setup
    queue_0 = Queue()
    # Verification
    queue_0.put(1)


# Generated at 2022-06-26 08:46:45.346620
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put("abc")



# Generated at 2022-06-26 08:46:53.607617
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()

    if queue_1.maxsize == 0:
        assert queue_1.maxsize == 0
    else:
        assert queue_1.maxsize > 0

    if queue_1.empty():
        assert queue_1.empty()
    else:
        assert not queue_1.empty()

    if queue_1.full():
        assert queue_1.full()
    else:
        assert not queue_1.full()

    queue_1.__put_internal(1)
    assert queue_1.qsize() == 1 and not queue_1.empty() and not queue_1.full()
    queue_1.__put_internal(2)
    assert queue_1.qsize() == 2 and not queue_1.empty() and not queue_1.full()
    queue_1.__

# Generated at 2022-06-26 08:46:57.280869
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(True)

# Test unit test for method put of class Queue

# Generated at 2022-06-26 08:47:10.543566
# Unit test for method get of class Queue
def test_Queue_get():
    print("start testing 'get' method of class Queue")
    queue_0 = Queue()
    # normal case
    cur_val = None
    try:
        cur_val = queue_0.get()
    except QueueEmpty:
        print("Exception in your code:")
        traceback.print_exc()
    # special case
    try:
        queue_0.maxsize = -1
        queue_0.get()
    except ValueError:
        print("Exception in your code:")
        traceback.print_exc()
    try:
        queue_0.maxsize = None
        queue_0.get()
    except TypeError:
        print("Exception in your code:")
        traceback.print_exc()
    print("finish testing 'get' method of class Queue")

# sub class of

# Generated at 2022-06-26 08:47:14.095269
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)


# Generated at 2022-06-26 08:47:16.783991
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put('test')



# Generated at 2022-06-26 08:47:44.570687
# Unit test for method get of class Queue
def test_Queue_get():
    print("************ test_Queue_get ************")
    def test_get_0(timeout=None):
        q_0 = Queue()
        q_0.put(7)
        assert q_0.get(timeout=timeout) == 7

    test_get_0()
    test_get_0(timeout=None)
    test_get_0(None)

    def test_get_1(timeout=None):
        q_1 = Queue()
        q_1.put(7)
        q_1.put(8)
        assert q_1.get(timeout=timeout) == 7
        assert q_1.get(timeout=timeout) == 8

    test_get_1()
    test_get_1(timeout=None)
    test_get_1(None)


# Generated at 2022-06-26 08:47:51.981259
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create a Queue object
    queue_0 = Queue()
    # Call method get_nowait
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    # Call method get_nowait
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    # Call method get_nowait
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:47:53.540374
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)



# Generated at 2022-06-26 08:48:02.817494
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait(0)
        queue_0.put_nowait(1)
        queue_0.put_nowait(2)
    except QueueFull as e:
        print(e)
    except QueueEmpty as e:
        print(e)


# Generated at 2022-06-26 08:48:06.417407
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue(2)
    queue_1._queue.append(1)
    actual_value_1 = queue_1.get_nowait()
    expected_value_1 = 1
    assert actual_value_1 == expected_value_1


# Generated at 2022-06-26 08:48:19.349758
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue, QueueEmpty

    q = Queue()

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        #await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:48:31.139289
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:48:33.498892
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:48:36.471357
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    res = q.put(1, 2)
    if not isinstance(res, Future):
        raise Exception("Queue.put() returned incorrect result.")


# Generated at 2022-06-26 08:48:40.640631
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()

    queue_0.put_nowait(object())
    try:
        assert True # TODO: implement your test here
    except AssertionError as e:
        print(e)
        #raise e


# Generated at 2022-06-26 08:48:56.928203
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:49:00.423634
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    assert isinstance(queue_0, Queue)
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:49:02.224856
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue size is 0
    # queue size is larger than 0
    pass



# Generated at 2022-06-26 08:49:04.172573
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 08:49:17.898784
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create an instance of Queue
    queue_0 = Queue()

    # Invoke method get_nowait with parameter item
    try:
        queue_0_ret_0 = queue_0.get_nowait()
    except QueueEmpty as e:
        pass

    # Check if there is one getter in queue_0._getters
    if (1 > len(queue_0._getters)):
        raise RuntimeError("Unexpected value for queue_0._getters")

    # Create an instance of Future
    future_0 = Future()

    # Create an item of object type
    object_0 = object()

    # Put future_0 and object_0 into queue_0._getters
    queue_0._getters.append(future_0)

    # Invoke method get_nowait with parameter item

# Generated at 2022-06-26 08:49:23.686474
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case 1:
    queue_1 = Queue()

    # Test case 2:
    queue_2 = Queue(4)

    # Test case 3:
    queue_3 = Queue(maxsize=0)


# Generated at 2022-06-26 08:49:27.189518
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(None)
    # Check here the number of tasks
    assert queue_0._unfinished_tasks == 0


# Generated at 2022-06-26 08:49:30.342086
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:49:33.950279
# Unit test for method get of class Queue
def test_Queue_get():
    '''
    Function test_Queue_get tests method get of class Queue.
    Precondition: 
    Postcondition: 
    '''
    pass

# Generated at 2022-06-26 08:49:42.338987
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(10)
    q.put(2)
    q.put(2)
    q.put(3)
    q.put(3)
    q.put(3)
    q.put(3)
    q.put(3)
    q.put(3)
    q.put(3)
    q.put(5)
    assert q.get() == 2
    assert q.get() == 2



# Generated at 2022-06-26 08:50:07.938223
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:50:13.818366
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from random import randint
    print("Test for function get_nowait of class Queue")

    def start_queue():
        queue_0 = Queue()
        for i in range(10):
            queue_0.put_nowait(i)

        for i in range(10):
            queue_0.get_nowait()

        print(queue_0)
        print(queue_0.get_nowait())

    start_queue()

# Unit tests for method get of class Queue

# Generated at 2022-06-26 08:50:22.875847
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait({})
    queue_0.put_nowait(True)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(False)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0.put_nowait(queue_0)
    queue_0

# Generated at 2022-06-26 08:50:35.928676
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # test 1:
    q = Queue()
    async def put(q):
        await q.put(42)
        await q.put(43)
        await q.put(44)
        await q.put(None)

    async def get(q):
        while True:
            x = await q.get()
            if x:
                print('Got:', x)
            if x is None:
                print('Done')
                return

    async def _test():
        await gen.multi([put(q), get(q)])

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(_test)
    # test 2:
    q2 = Queue()
    io_loop.run_sync(lambda : put(q2))
    io_loop.run_sync

# Generated at 2022-06-26 08:50:37.132693
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()


# Generated at 2022-06-26 08:50:41.108289
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    # Test 1: queue_size=0
    q.put_nowait(3)
    q.put_nowait(4)
    # Test 2: queue_size=2
    q.put_nowait(5)
    # Test 3: queue_size=3
    for i in range(100):
        q.put_nowait(i)
    # Test 4: queue_size=103
    # Test 5: queue_size > maxsize
