

# Generated at 2022-06-26 08:41:22.495502
# Unit test for method get of class Queue
def test_Queue_get():
    ioloop.IOLoop.current().run_sync(test_case_get)

async def test_case_get():
    q = Queue()
    await q.put(42)
    await q.join()
    assert await q.get() == 42


# Generated at 2022-06-26 08:41:29.806137
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    future = queue_1.put(1)
    future = queue_1.put(2)
    future = queue_1.put(3)
    future = queue_1.put(4)
    future = queue_1.put(5)
    future = queue_1.put(6)



# Generated at 2022-06-26 08:41:36.621674
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    assert queue_1.get_nowait() == 1
    assert queue_1.get_nowait() == 2


# Generated at 2022-06-26 08:41:46.124236
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(maxsize=-1)
    future_0 = Future()
    queue_0._getters.append(future_0)
    _set_timeout(future_0, None)
    queue_0._consume_expired()
    if queue_0._putters:
        assert queue_0.full(), "queue not full, why are putters waiting?"
        queue_0._putters.popleft()
        queue_0.__put_internal(None)
        _async_0 = Future() # type: Future[None]
        _async_0.set_result(None)
        future_set_result_unless_cancelled(_async_0, None)
        future_0.set_result(queue_0._get())
    elif queue_0.qsize:
        future

# Generated at 2022-06-26 08:41:48.857208
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:41:55.922565
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()

    async def test():
        await q.put(1)
        assert await q.get() == 1

    ioloop.IOLoop.current().run_sync(test)

# Generated at 2022-06-26 08:42:07.403762
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    print(queue_1.qsize())
    print(queue_1.empty())
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)
    queue_1.put_nowait(4)
    queue_1.put_nowait(5)
    print(queue_1.qsize())
    print(queue_1.empty())
    print(queue_1.get_nowait())
    print(queue_1.get_nowait())
    print(queue_1.get_nowait())
    print(queue_1.get_nowait())
    print(queue_1.get_nowait())
    print(queue_1.qsize())

# Generated at 2022-06-26 08:42:12.738468
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        pass
test_case_0()
test_Queue_get_nowait()

# Generated at 2022-06-26 08:42:15.812948
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    queue_1 = Queue()
    queue_1.put(10)
    queue_1.put(5)
    assert queue_1.get() == 10


# Generated at 2022-06-26 08:42:20.335481
# Unit test for method get of class Queue
def test_Queue_get():
    # Data setup
    queue = Queue()
    # Main function call
    get_result = queue.get()
    # Assist function call


# Generated at 2022-06-26 08:42:36.573111
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.get_nowait()
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    q.put_nowait(4)
    q.put_nowait(5)
    assert q.qsize() == 2
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5
    return


if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Run the tornado.queues.Queue unit tests"
    )

# Generated at 2022-06-26 08:42:39.123052
# Unit test for method get of class Queue
def test_Queue_get():
    print("Start to test Queue's get method")
    queue = Queue()


# Generated at 2022-06-26 08:42:50.127781
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # 1. input: queue is empty
    queue_1 = Queue()
    try:
        queue_1.get_nowait()
    except Exception as e:
        if isinstance(e, QueueEmpty):
            pass
        else:
            raise AssertionError("1.1")
    else:
        raise AssertionError("1.2")

    # 2. input: queue is not empty
    queue_2 = Queue()
    queue_2._put(1)
    if queue_2.get_nowait() == 1:
        pass
    else:
        raise AssertionError("2.1")


# Generated at 2022-06-26 08:42:52.958067
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()
    queue_0.get()
    queue_0.get()
    queue_0.get()
    queue_0.get()


# Generated at 2022-06-26 08:42:55.486174
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()
    print('Passed')


# Generated at 2022-06-26 08:42:57.823036
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    result = queue_1.get()
    assert result is None


# Generated at 2022-06-26 08:43:06.072205
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Unit test for Queue_get_nowait
    # Create an empty Queue
    queue_0 = Queue()
    try:
        # Try to call get_nowait() without any elements in the queue
        queue_0.get_nowait()
    except QueueEmpty:
        return True
    return False


# Generated at 2022-06-26 08:43:16.642894
# Unit test for method put of class Queue
def test_Queue_put():
    print()

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.2)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            # print('Put %s' % item)
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join

# Generated at 2022-06-26 08:43:18.060348
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert False



# Generated at 2022-06-26 08:43:21.935132
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(5)
    queue_0.put_nowait(123)
    queue_0.put_nowait(234)
    queue_0.put_nowait(345)
    queue_0.put_nowait(456)
    queue_0.put_nowait(567)
    queue_0.put_nowait(678)


# Generated at 2022-06-26 08:43:34.195674
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    with pytest.raises(QueueFull):
        queue_0.put_nowait(1)



# Generated at 2022-06-26 08:43:36.484393
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put('a')    # TODO: Add the input for Tornado's method
    future_0.result()


# Generated at 2022-06-26 08:43:40.483352
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    timeout = "0.01"
    print(queue_1.get(timeout))


# Generated at 2022-06-26 08:43:45.058147
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.__put_internal(None)
    # The downstream Queue.get could raise QueueEmpty.
    queue_0.get_nowait()
    # The downstream Queue.get could throw an exception.


# Generated at 2022-06-26 08:43:51.139362
# Unit test for method get of class Queue
def test_Queue_get():
    print("Testing Queue.get..")
    queue_0 = Queue()
    queue_0.put("Please")
    queue_0.put("Assume")
    queue_0.put("True")
    queue_0.put("This")
    queue_0.put("Is")
    queue_0.put("A")
    queue_0.put("Queue")
    queue_0.put("Otherwise")
    queue_0.put("This")
    queue_0.put("Test")
    queue_0.put("Will")
    queue_0.put("Fail")
    queue_0.put("Not")
    queue_0.put("Very")
    queue_0.put("Nice")
    queue_0.put("At")
    queue_0.put("All")

# Generated at 2022-06-26 08:43:55.468584
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    print('queue_0.get_nowait() = %d' % queue_0.get_nowait())
    queue_0.put_nowait(2)
    print('queue_0.get_nowait() = %d' % queue_0.get_nowait())


# Generated at 2022-06-26 08:44:07.713990
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    # Put 1
    queue_0.put_nowait(1)
    # Get 1
    assert queue_0.get_nowait() == 1, "The method get of class Queue returned incorrect value"
    queue_1 = Queue()
    queue_1.put(1)
    assert queue_1.get() == 1, "The method get of class Queue returned incorrect value"
    queue_2 = Queue()
    queue_2.put_nowait(1)
    assert queue_2.get() == 1, "The method get of class Queue returned incorrect value"
    queue_3 = Queue()
    queue_3.put(1)
    assert queue_3.get_nowait() == 1, "The method get of class Queue returned incorrect value"



# Generated at 2022-06-26 08:44:13.579079
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(0)
    result_1 = queue_1.get_nowait()
    assert result_1 == 0, 'result_1 == 0'



# Generated at 2022-06-26 08:44:15.862248
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(5)


# Generated at 2022-06-26 08:44:28.125052
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine, Return

    @coroutine
    def wait(queue, value):
        item = yield queue.put(value)
        raise Return(item)

    @coroutine
    def worker(queue):
        item = yield queue.get()
        raise Return(item)

    class TestQueue(AsyncTestCase):
        @gen_test
        def test_put(self):
            queue = Queue(maxsize=5)
            self.assertEqual(5, queue.maxsize)
            self.assertEqual(0, queue.qsize())

            yield wait(queue, 1)
            self.assertEqual(1, queue.qsize())

            yield wait(queue, 2)
            self

# Generated at 2022-06-26 08:44:37.957290
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.qsize()
    queue_0.get()


# Generated at 2022-06-26 08:44:45.533961
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(10)
    queue.put_nowait(20)
    queue.put_nowait(30)
    queue.put_nowait(40)
    queue.put_nowait(50)
    queue.put_nowait(60)


# Generated at 2022-06-26 08:44:48.717524
# Unit test for method get of class Queue
def test_Queue_get():
    print("\nStart test_Queue_get()")
    queue_0 = Queue()


# Generated at 2022-06-26 08:44:56.884435
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    #assert q.qsize() == 3
    q.task_done()
    q.task_done()
    q.task_done()
    #assert q.qsize() == 0


if __name__ == "__main__":
    test_Queue_put()

# Generated at 2022-06-26 08:45:00.979017
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()


# Generated at 2022-06-26 08:45:10.153505
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    # Put a value in the Queue
    queue_0.put_nowait(41)
    # Put another value in the Queue
    queue_0.put_nowait(42)
    # Put a third value in the queue
    queue_0.put_nowait(43)
    # Get the value of the queue
    return queue_0.get_nowait()



# Generated at 2022-06-26 08:45:13.351071
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    item = queue.get_nowait()
    assert item == 3


# Generated at 2022-06-26 08:45:24.581413
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """
    Test the method get_nowait of class Queue.
    """
    # Case 0:
    print("\nCase 0:")
    try:
        queue_0 = Queue()
        res_0 = queue_0.get_nowait()
    except IndexError:
        print("Should raise IndexError!")
    except QueueEmpty:
        print("Should raise QueueEmpty!")
    except:
        print("Unexpected error happened!")
    else:
        print("Should not return value:")
        print(res_0)

    # Case 1:
    print("\nCase 1:")

# Generated at 2022-06-26 08:45:26.116802
# Unit test for method put of class Queue
def test_Queue_put():
    pass


# Generated at 2022-06-26 08:45:35.367888
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue(maxsize=0)
    empty_result = queue_1.empty()
    assert empty_result == True
    queue_1.put(1)
    result_0 = queue_1.qsize()
    assert result_0 == 1
    result_1 = queue_1.get()
    assert result_1 == 1
    get_result_0 = queue_1.get_nowait()
    assert get_result_0 == 1
    empty_result = queue_1.empty()
    assert empty_result == True
    queue_1.put(2)
    result_2 = queue_1.qsize()
    assert result_2 == 1
    result_3 = queue_1.get()
    assert result_3 == 2
    get_result_1 = queue_1.get_nowait()

# Generated at 2022-06-26 08:46:02.186817
# Unit test for method put of class Queue
def test_Queue_put():
    print("begin")
    q = Queue()
    # q.put(5)
    # q.put(15)
    # q.put(25)
    #
    # q.put(35)


    async def producer():
        for item in range(5):
            await q.put(item)
            # print('Put %s' % item)
            print( q.get_nowait())

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()
                # print('Put %s' % item)
                print(q.get_nowait())

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOL

# Generated at 2022-06-26 08:46:04.385965
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(1)
    q.put_nowait("hello")


# Generated at 2022-06-26 08:46:10.145685
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q_0 = Queue()
    try:
        q_0.get_nowait()
        assert False
    except QueueEmpty:
        assert True

# Unit test of method get(timeout=None) of class Queue

# Generated at 2022-06-26 08:46:12.380415
# Unit test for method put of class Queue
def test_Queue_put():
    coroutine = Queue.put()


# Generated at 2022-06-26 08:46:15.643839
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()

    # Put a new item into the queue.
    queue.put_nowait(0)

    # Get the item that inserted before.
    item = queue.get_nowait()

    assert item == 0


# Generated at 2022-06-26 08:46:22.653615
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait(0)
        queue_0.put_nowait(1)
        queue_0.put_nowait(2)
    except QueueFull:
        return
    print("wtf?")



# Generated at 2022-06-26 08:46:30.300370
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)

    async def producer():
        for item in range(5):
            await q.put(item)
            print('put %s' % item)

    async def main():
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:46:35.531188
# Unit test for method put of class Queue
def test_Queue_put():
    print("Test put a item into queue")
    q = Queue() # create a Queue object
    q.put(1) # put 1 into queue
    print(q.qsize()) # print the size of queue should be 1


# Generated at 2022-06-26 08:46:37.607725
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)


# Generated at 2022-06-26 08:46:43.805486
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0._init()
    try:
        queue_0.put(1)
        assert True
    except QueueFull:
        assert False


# Generated at 2022-06-26 08:47:00.123580
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future = queue_0.put('abc')
    assert future.result(1) == None


# Generated at 2022-06-26 08:47:06.639469
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    for i in range(10):
        q.put_nowait(i)
    for i in range(10):
        print(q.get_nowait())


# Generated at 2022-06-26 08:47:11.466107
# Unit test for method get of class Queue
def test_Queue_get():
    # Put
    out = queue_0.put(0)
    out = queue_0.put(1)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)
    out = queue_0.put(2)

# Generated at 2022-06-26 08:47:25.372340
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()

    if not isinstance(q.put, collections.Callable):
        raise TypeError("put() is not a method of Queue")

    if len(q.put.__code__.co_varnames) != 3:
        raise TypeError("put() takes too many arguments")

    if not isinstance(q.put.__code__.co_varnames[0], str):
        raise TypeError("put()'s first argument is not a string")

    if not isinstance(q.put.__code__.co_varnames[1], str):
        raise TypeError("put()'s second argument is not a string")

    if not isinstance(q.put.__code__.co_varnames[2], str):
        raise TypeError("put()'s third argument is not a string")

# Generated at 2022-06-26 08:47:28.466053
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    assert queue.empty() == True
    assert queue.full() == False
    assert queue.qsize() == 0


# Generated at 2022-06-26 08:47:36.700649
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait(2)
        queue_0.put_nowait(3)
        queue_0.put_nowait(4)
    except QueueFull:
        assert 0, "The QueueFull exception was not expected here"
    else:
        assert 1, "The put_nowait method was not called"



# Generated at 2022-06-26 08:47:42.725604
# Unit test for method get of class Queue
def test_Queue_get():
    # Set up
    queue_0 = Queue()
    # Testing if the call queue_0.get() raises a AttributeError
    try:
        queue_0.get()
    except AttributeError:
        # Exception was raised (expected)
        pass
    else:
        # Exception was not raised (unexpected)
        assert False
    # Unit test end


# Generated at 2022-06-26 08:47:46.327439
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a Queue
    queue_0 = Queue()
    # Create a variable of type Future
    future: Future = queue_0.get()


# Generated at 2022-06-26 08:47:54.902777
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue, QueueFull, QueueEmpty
    import time

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for

# Generated at 2022-06-26 08:47:58.743928
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()


# Generated at 2022-06-26 08:48:29.412905
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)



# Generated at 2022-06-26 08:48:36.573635
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    assert queue_0.qsize() == 0, "Queue.qsize() == 0"
    assert queue_0.empty() == True, "Queue.empty() == True"
    assert queue_0.full() == False, "Queue.full() == False"
    queue_0._queue = collections.deque([8, 3, 6, 3, 5, 4])
    assert queue_0.get_nowait() == 8, "Queue.get_nowait() == 8"


# Generated at 2022-06-26 08:48:42.761105
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue
    # Create an instance of Queue class
    queue_0 = Queue()
    # When calling Queue.get_nowait() if queue is empty, raise `QueueEmpty`
    raise_QueueEmpty = False
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        raise_QueueEmpty = True
    assert raise_QueueEmpty



# Generated at 2022-06-26 08:48:46.335979
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-26 08:48:48.647553
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    item = queue_1.get()
    return item

# test_case_1 is the same as test_case_3


# Generated at 2022-06-26 08:48:54.523229
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    assert queue.qsize() == 1
    queue.put_nowait(2)
    assert queue.qsize() == 2
    queue.put_nowait(3)
    assert queue.qsize() == 3


# Generated at 2022-06-26 08:48:57.917398
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put(0)
    queue_0.put(1)
    queue_0.put(2)
    queue_0.get()


# Generated at 2022-06-26 08:49:03.824363
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Initialize an object of Queue
    queue = Queue()
    # Test when the queue is not empty, pop the first element in queue
    queue.put_nowait(1)
    assert queue.get_nowait() == 1

    # Test when the queue is empty, raise QueueEmpty
    try:
        queue.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False



# Generated at 2022-06-26 08:49:15.081496
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    timeout: Optional[Union[float, datetime.timedelta]] = 1
    obj = queue_0.put(1, timeout)
    assert obj._timeout == 1
    assert obj._log_traceback is True
    assert obj._delegate_stack_context is True
    assert obj._stack_context_handle is None
    assert obj._state == 0
    assert obj._exception is None
    assert obj._result is None
    assert obj._result_list == []
    assert obj._result_dict == {}
    assert obj._callbacks == []


# Generated at 2022-06-26 08:49:17.731966
# Unit test for method put of class Queue
def test_Queue_put():
    # Create an instance of Queue
    queue_0 = Queue()
    # Call method put with item = 2
    queue_0.put(2)


# Generated at 2022-06-26 08:49:49.838920
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue object.
    queue_0 = Queue(100)
    # Create a variable of type str.
    str_0 = None
    # Invoke method put of queue_0.
    queue_0.put('str_0', None)


# Generated at 2022-06-26 08:49:56.188719
# Unit test for method get of class Queue
def test_Queue_get():
    # Get a Queue object
    queue_0 = Queue()
    # Get a task from the queue.
    task_0 = queue_0.get()
    # Get a timeout
    timeout_0 = datetime.timedelta()
    # Get a task from the queue.
    task_1 = queue_0.get(timeout_0)


# Generated at 2022-06-26 08:50:08.345814
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(2)
    future = Future()
    timeout = None
    timeout_0 = None
    if (future.done()):
        timeout_0 = None
    else:
        timeout_0 = None
    timeout = timeout_0
    timeout_0 = timeout
    if ((timeout_0 is None) and (queue_0.qsize() >= queue_0.maxsize)):
        raise QueueFull()
    elif (queue_0._getters):
        getter = queue_0._getters.popleft()
        queue_0.__put_internal(future)
        future_set_result_unless_cancelled(getter, queue_0._get())
    elif (queue_0.full()):
        raise QueueFull()
    else:
        queue_0.__put

# Generated at 2022-06-26 08:50:12.891478
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Unit test for method get_nowait of class Queue
    queue = Queue()
    # Example of use of get_nowait.
    # If a "QueueEmpty" exception is raised, then it will be caught by 'except'
    try:
        print(queue.get_nowait())
    except QueueEmpty:
        print("queue is empty, no item to get")


# Generated at 2022-06-26 08:50:21.498697
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(maxsize=0)
    queue_1.put_nowait(0)
    assert queue_1.qsize() == 1, "queue_1.qsize() == 1"
    queue_1.put_nowait(1)
    assert queue_1.qsize() == 2, "queue_1.qsize() == 2"
    queue_1.put_nowait(2)
    assert queue_1.qsize() == 3, "queue_1.qsize() == 3"
    queue_1.put_nowait(3)
    assert queue_1.qsize() == 4, "queue_1.qsize() == 4"
    queue_1.put_nowait(4)
    assert queue_1.qsize() == 5, "queue_1.qsize() == 5"


# Generated at 2022-06-26 08:50:34.512284
# Unit test for method get of class Queue
def test_Queue_get():
    def test_Queue_get_0():
        queue_0 = Queue(maxsize=1000)
        item = queue_0.get()
        assert(item is None)

    def test_Queue_get_1():
        queue_0 = Queue(maxsize=2)
        queue_0.put_nowait('test_str_0')
        item = queue_0.get()
        assert(item == "test_str_0")
        item = queue_0.get()
        assert(item is None)

    def test_Queue_get_2():
        queue_0 = Queue(maxsize=2)
        queue_0.put_nowait('test_str_0')
        queue_0.put_nowait('test_str_1')

# Generated at 2022-06-26 08:50:36.242892
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a queue
    queue = Queue()
    queue.put("test")
    # Get an object from the queue
    assert queue.get() == "test"



# Generated at 2022-06-26 08:50:42.212253
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()

    queue_0.put_nowait(0)
    queue_0.put_nowait(1)

if __name__ == "__main__":
    q = Queue()
    q.put_nowait(0)
    n = q.qsize()
    print(q)
    q.put_nowait(1)
    q.get_nowait()
    n = q.task_done()
    n = q.full()
    n = q.empty()
    n = q.maxsize
    future = q.put(2, timeout=10)
    future = q.get(timeout=10)

    q = Queue()

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()

# Generated at 2022-06-26 08:50:47.393587
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    aiter = queue_0.__aiter__()
    x = aiter.__anext__()
    if isinstance(x, Awaitable):
        # Get object from which Awaitable was created.
        cnt_1 = 0
        cnt_1 += 1
        # Check for expected attribute in Awaitable.
        if hasattr(x, '__await__'):
            if x.__await__() is not None:
                cnt_1 += 1
        y = x.__await__()
        if y is not None:
            cnt_1 += 1
    pass # test passed
