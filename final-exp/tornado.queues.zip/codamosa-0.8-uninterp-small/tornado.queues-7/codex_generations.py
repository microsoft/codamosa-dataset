

# Generated at 2022-06-26 08:40:59.264229
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put(4)
    except QueueFull as e:
        e


# Generated at 2022-06-26 08:41:08.847549
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1. Test for LifoQueue
    print("1. Test for LifoQueue")
    lifo_queue = LifoQueue()
    print("lifo_queue.maxsize = %d" % (lifo_queue.maxsize))
    item_0 = "item_0"
    item_1 = "item_1"
    item_2 = "item_2"
    lifo_queue.put_nowait(item_0)
    lifo_queue.put_nowait(item_1)
    lifo_queue.put_nowait(item_2)
    print("lifo_queue.qsize() = %d" % (lifo_queue.qsize()))

    # 2. Test for PriorityQueue
    print("2. Test for PriorityQueue")
    priority_queue = PriorityQueue()

# Generated at 2022-06-26 08:41:12.084181
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put_nowait('test_Queue_put')
    print(q.qsize())


# Generated at 2022-06-26 08:41:21.913865
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put_nowait(42)
    queue_0.put(43, timeout=(0.3))
    queue_0.put_nowait(44)
    queue_0.put(45, timeout=(0.3))
    queue_0.put_nowait(46)
    queue_0.put(47, timeout=(0.3))
    try:
        queue_0.put_nowait(47)
    except QueueFull:
        assert True
    else:
        assert False


# Generated at 2022-06-26 08:41:23.508229
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()


# Generated at 2022-06-26 08:41:34.881249
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # Check if get_nowait raises QueueEmpty when self._queuw is empty
    # This condition is not met, should raise AssertionError
    # assert q.get_nowait() == None, 'This test case should fail'
    # Test if qsize() is zero, otherwise Queue is not empty
    assert q.qsize() == 0, "qsize() is not zero"
    # Test if self.empty() returns True
    assert q.empty() == True, "self.empty() does not return True"
    # Test that self._getters is empty
    assert not q._getters and q._getters == [], "self._getters is not empty"
    # Test that self._unfinished_tasks is zero

# Generated at 2022-06-26 08:41:40.472450
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    top_0 = Queue()

    try:
        top_0._get()

    except IndexError:
        pass

    top_0.put_nowait(0)
    top_0.get_nowait()
    return



# Generated at 2022-06-26 08:41:52.306940
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Test the case in which when the number of unfinished tasks is zero
    queue_0 = Queue()
    try:
        queue_0.task_done()
        print("task_done: test_case_0: passed")
    except ValueError:
        print("task_done: test_case_0: failed")
    # Test the case in which when the number of unfinished tasks is not zero
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.get_nowait()
    queue_1.task_done()



# Generated at 2022-06-26 08:42:03.534126
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # Testcase 1: Get an item from an empty queue.
    # Should raise QueueEmpty
    try:
        q.get_nowait()
    except QueueEmpty as ex:
        print("QueueEmpty raised as expected.")
    # Testcase 2: Get an item from a non-empty queue.
    q.put("foo")
    res = q.get_nowait()
    print("Result of get_nowait: " + str(res))


# Generated at 2022-06-26 08:42:04.527309
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get_nowait()


# Generated at 2022-06-26 08:42:20.177576
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get_nowait()


# Generated at 2022-06-26 08:42:30.488291
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_queue_0 = Queue(1)
    test_queue_1 = Queue(0)
    test_queue_2 = Queue(2)
    test_queue_3 = Queue(1)
    test_queue_4 = Queue(3)
    test_queue_5 = Queue(0)
    test_queue_6 = Queue(2)
    test_queue_7 = Queue(1)
    test_queue_8 = Queue(3)
    test_queue_9 = Queue(2)
    test_queue_10 = Queue(3)
    test_queue_11 = Queue(1)
    test_queue_12 = Queue(0)
    test_queue_13 = Queue(2)
    test_queue_14 = Queue(1)

    test_queue

# Generated at 2022-06-26 08:42:32.893673
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(3)



# Generated at 2022-06-26 08:42:41.086935
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # get(timeout=None)
    # Remove and return an item from the queue.
    # Returns a awaitable which resolves once an item is available, or raises
    # gen.TimeoutError after a timeout.
    #
    # timeout may be a number, a float or a timedelta. If it is a float, then it
    # is the number of milliseconds to wait, while if it is a timedelta, then it
    # is the maximum number of milliseconds to wait (can be negative).
    #
    # If timeout is None, the call blocks until an item is available.
    g_result = q.get()


# Generated at 2022-06-26 08:42:44.179163
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:42:49.125630
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    x = q.get_nowait()  # type: ignore
    return x


# Generated at 2022-06-26 08:42:59.784163
# Unit test for method put of class Queue
def test_Queue_put():
    # Test whether the type is consistent with self.put_nowait
    lifo_queue_1 = LifoQueue()
    lifo_queue_1.put(1)
    assert isinstance(lifo_queue_1._putters[0], tuple) is True
    # Test whether TimeoutError is correct
    lifo_queue_2 = LifoQueue()
    future_put = lifo_queue_2.put(1)
    assert isinstance(future_put.exception(), QueueFull) is True
    # Test whether set_result is correct
    lifo_queue_3 = LifoQueue()
    lifo_queue_3.put(1)
    assert lifo_queue_3.get_nowait() == 1

# Generated at 2022-06-26 08:43:13.223138
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case with no stack overflow
    queue_0 = Queue()
    queue_0.put([0])
    assert queue_0.qsize() == 1
    assert queue_0.empty() == False
    assert queue_0.full() == False
    # Test case with stack overflow
    queue_1 = Queue(1)
    queue_1.put([1])
    queue_1.put([2])
    assert queue_1.qsize() == 1
    assert queue_1.empty() == False
    assert queue_1.full() == True
    # Test case with stack overflow
    queue_2 = Queue(1)
    queue_2.put([[0.5, [], 0], 1])
    assert queue_2.qsize() == 1
    assert queue_2.empty() == False
    assert queue

# Generated at 2022-06-26 08:43:16.910510
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue = LifoQueue()
    lifo_queue.put_nowait(100)
    lifo_queue.put_nowait(200)
    assert lifo_queue.qsize() == 2



# Generated at 2022-06-26 08:43:20.644712
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # arrange
    queue = Queue()

    # act
    queue.put_nowait(3)
    expected = [3]
    actual = queue._queue
    print("Expected: ", expected)
    print("Actual: ", actual)
    assert actual == expected


# Generated at 2022-06-26 08:43:37.802201
# Unit test for method get of class Queue
def test_Queue_get():
    # Queue initialization
    q = Queue()
    q.put("item 1")
    q.put("item 2")

    # Call method get
    item = q.get()
    print("item = {0}".format(item))
    item = q.get()
    print("item = {0}".format(item))


# Generated at 2022-06-26 08:43:46.874976
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    if q.qsize() != 0:
        raise AssertionError
    if not q.empty():
        raise AssertionError
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    if not q.full():
        raise AssertionError
    if q.qsize() != 3:
        raise AssertionError
    if q.get_nowait() != 1:
        raise AssertionError
    if q.get_nowait() != 2:
        raise AssertionError
    if q.get_nowait() != 3:
        raise AssertionError
    if q.qsize() != 0:
        raise AssertionError
    if q.full():
        raise AssertionError
   

# Generated at 2022-06-26 08:43:57.127868
# Unit test for method get of class Queue
def test_Queue_get():
    # 0. Queue()
    queue = Queue()

    # 1. Queue(0)
    queue = Queue(0)

    # 2. -> QueueFul
    queue = Queue(1)
    queue.put(1)
    queue.put(2)
    try:
        queue.put(3)
    except QueueFull:
        print("QueueFull")

    # 3. QueueEmpty
    queue = Queue()
    try:
        print(queue.get_nowait())
    except QueueEmpty:
        print("QueueEmpty")

    # 4. timeout
    queue = Queue()
    timeout = 2
    future = Future()
    try:
        future.set_result(queue.get_nowait())
    except QueueEmpty:
        _set_timeout(future, timeout)

# Generated at 2022-06-26 08:43:58.761442
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = Queue()
    value = lifo_queue_0.put(lifo_queue_0)
    value = lifo_queue_0.put(lifo_queue_0)


# Generated at 2022-06-26 08:44:02.560688
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    lifo_queue_0 = LifoQueue()
    if False:
        lifo_queue_0.get_nowait()


# Generated at 2022-06-26 08:44:07.680456
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put_nowait(1)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:44:16.976902
# Unit test for method get of class Queue
def test_Queue_get():
    # Init a tornado queue
    q = Queue(maxsize=5)
    # put some items into the queue
    q.put("a")
    q.put("b")
    q.put("c")
    q.put("d")
    q.put("e")
    # get the items
    print(q.get())
    print(q.get())
    print(q.get())
    print(q.get())
    print(q.get())
    # The queue is empty now, get again should raise an exception
    print(q.get())


# Generated at 2022-06-26 08:44:28.396731
# Unit test for method get_nowait of class Queue

# Generated at 2022-06-26 08:44:39.323302
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_queue_0 = Queue()

    # lambda function for testing get_nowait
    test_queue_0_get_nowait_lambda_0 = lambda: test_queue_0.get_nowait()

    # Set test starting time.
    test_queue_0_get_nowait_startTime_0 = time.time()

    # Put test code here.
    def test_Queue_get_nowait_0():
        # Put test code here
        assert 0 == 1

    try:
        test_Queue_get_nowait_0()
    except AssertionError as test_case_Queue_get_nowait_AssertionError:
        # Set test end time.
        test_queue_0_get_nowait_endTime_0 = time.time()
        # Test duration
        test_queue_0

# Generated at 2022-06-26 08:44:47.951625
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=5)
    assert q.qsize() == 0
    q.put_nowait("1")
    assert q.qsize() == 1
    q.put_nowait("2")
    assert q.qsize() == 2
    q.put_nowait("3")
    assert q.qsize() == 3
    q.put_nowait("4")
    assert q.qsize() == 4
    q.put_nowait("5")
    assert q.qsize() == 5


# Generated at 2022-06-26 08:45:04.994377
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-26 08:45:06.471716
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    lifo_queue_0.put_nowait(1)
    assert True



# Generated at 2022-06-26 08:45:11.949672
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    test_0 = 0
    try:
        q.put_nowait(0)
        q.put_nowait(1)
        q.put_nowait(2)
    except Exception as e:
        test_0 = 1
    assert test_0 == 0, "Error: Queue_put_nowait"


# Generated at 2022-06-26 08:45:15.296439
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    # TODO need to implement test here


# Generated at 2022-06-26 08:45:17.035329
# Unit test for method put of class Queue
def test_Queue_put():
    # TODO
    pass


# Generated at 2022-06-26 08:45:21.375754
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    queue.put_nowait(10)
    queue.put(20)
    # The following changes the maxsize of the test queue
    # queue.maxsize = 10
    # queue.put(30, queue.maxsize)
    
    

# Generated at 2022-06-26 08:45:26.734558
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # call get_nowait() with empty queue
    queue_0 = Queue()
    result = False
    try:
        queue_0.get_nowait()
    except QueueEmpty as e:
        result = True
    assert result


# Generated at 2022-06-26 08:45:39.347575
# Unit test for method put of class Queue
def test_Queue_put():

    for maxsize in [0, 1, 10]:

        # no timeout
        q = Queue(maxsize=maxsize)

        # put an item
        assert q.put(None)

        # put a second item, if supported
        if maxsize > 1:
            assert q.put(None)

            # try to put one more item
            assert q.put(None).result(0) == None

        # get an item
        assert q.get().result(0) == None

        # try to get one more item, if supported
        if maxsize > 0:
            assert q.get().result(0) == None
        else:
            assert q.get().result(0) == None

        # put and get an item
        assert q.put(None)
        assert q.get().result(0) == None

        # try

# Generated at 2022-06-26 08:45:42.229429
# Unit test for method get of class Queue
def test_Queue_get():
    # Queue
    queue_0 = Queue()
    queue_0.get()
    t_0 = Queue.get(queue_0)


# Generated at 2022-06-26 08:45:48.120546
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait("a")
    q.put_nowait("b")

    # LifoQueue.put_nowait("b")
    # LifoQueue.put_nowait("a")


# Generated at 2022-06-26 08:46:00.568822
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    assert lifo_queue_0.put('foo', timeout=datetime.datetime.now()) is not None


# Generated at 2022-06-26 08:46:03.544813
# Unit test for method get of class Queue
def test_Queue_get():
    lifo_queue_0 = LifoQueue()
    tornado.ioloop.IOLoop.current().run_sync(lifo_queue_0.get)


# Generated at 2022-06-26 08:46:13.657466
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    test_queue = Queue()
    print('test_queue.put_nowait(''abc'')')
    test_queue.put_nowait('abc')
    print('test_queue.put_nowait(''efg'')')
    test_queue.put_nowait('efg')
    print('test_queue.put_nowait(''hij'')')
    test_queue.put_nowait('hij')



# Generated at 2022-06-26 08:46:16.046109
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert Queue(1).put_nowait(1) == None


# Generated at 2022-06-26 08:46:27.758164
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize = 0)

    print("enqueue element = " + "a")
    queue.put_nowait("a")

    print("enqueue element = " + "b")
    queue.put_nowait("b")

    print("enqueue element = " + "c")
    queue.put_nowait("c")

    print("dequeue element = " + queue.get_nowait())
    print("dequeue element = " + queue.get_nowait())
    print("dequeue element = " + queue.get_nowait())


if __name__ == '__main__':
    test_case_0()
    test_Queue_put()

# Generated at 2022-06-26 08:46:37.985264
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    future_1 = queue_0.get(1, 2)
    future_2 = queue_0.get(timeout = 1, a = 2)
    future_3 = queue_0.get(a = 1, timeout = 2)
    future_4 = queue_0.get(timeout = 1, a = 2)
    future_5 = queue_0.get(a = 1, timeout = 2)
    future_6 = queue_0.get()


# Generated at 2022-06-26 08:46:46.092675
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    #part 1:
    q = Queue()
    q.put_nowait(2)

    #part 2:
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)


# Generated at 2022-06-26 08:46:48.936816
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue(1)

    try:
        queue.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:46:56.301565
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test for default argument maxsize of function __init__
    queue_0 = Queue()
    # Test for function get_nowait of class Queue
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        return


# Generated at 2022-06-26 08:47:01.718394
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    assert queue_0.qsize() == 0
    queue_0.__init__(10)
    assert queue_0.maxsize == 10
    assert queue_0.empty() == True
    assert queue_0.full() == False
    #print(queue_0.__repr__())
    #print(queue_0.__str__())
    
    

# Generated at 2022-06-26 08:47:11.737720
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize=0)


# Generated at 2022-06-26 08:47:16.407194
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a Test Queue of size 2
    Queue_v = Queue(2)
    # Call Queue's get method to get a value from it.
    ret_get_0 = Queue_v.get()


# Generated at 2022-06-26 08:47:18.715688
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get()


# Generated at 2022-06-26 08:47:25.856265
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    assert len(lifo_queue_0._queue) == 0
    lifo_queue_0.put_nowait(34)
    assert len(lifo_queue_0._queue) == 1
    assert len(lifo_queue_0._putters) == 0
    assert len(lifo_queue_0._getters) == 0
    assert lifo_queue_0._unfinished_tasks == 1
    assert lifo_queue_0._finished.is_set()


# Generated at 2022-06-26 08:47:33.543819
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import random
    import time

    # Test data generated by random
    item = random.randint(3, 100)
    maxsize = random.randint(100, 500)
    queue = Queue(maxsize)

    start_time = time.time()
    # Tested method call
    queue.put_nowait(item)

    end_time = time.time()
    print ("Execution Time: ", end_time - start_time)


# Generated at 2022-06-26 08:47:40.451210
# Unit test for method get of class Queue
def test_Queue_get():

    async def coroutine_get_0() -> None:
        q = Queue()
        # await q.get()
        q.task_done()
        q.join()

    ioloop.IOLoop.current().run_sync(coroutine_get_0)


# Generated at 2022-06-26 08:47:43.128749
# Unit test for method get of class Queue
def test_Queue_get():
    maxsize = 0
    q = Queue(maxsize)
    future_0 = q.get()
    future_0.set_result(None)
    return q


# Generated at 2022-06-26 08:47:45.294261
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:47:48.414644
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    lifo_queue = LifoQueue()
    lifo_queue.get_nowait()



# Generated at 2022-06-26 08:47:49.865000
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()


# Generated at 2022-06-26 08:48:08.083076
# Unit test for method get of class Queue
def test_Queue_get():
    # Test for method get( ... ) of class Queue
    # Case 0

    class TestClass(object):
        def __init__(self):
            self.test_queue_0 = Queue()
            self.test_queue_0.put("lemon")
            self.test_future_0 = self.test_queue_0.get()

        def __anext__(self) -> Awaitable:
            return self.test_future_0

    test_class_0 = TestClass()

    # Case 1
    class TestClass1(object):
        def __init__(self):
            self.test_queue_1 = Queue()
            self.test_queue_1.put("lemon")

# Generated at 2022-06-26 08:48:20.867925
# Unit test for method get of class Queue
def test_Queue_get():
    print("[Test] test_Queue_get")
    def get_from_queue(q) -> None:
        while True:
            print("[worker] get")
            x = q.get()
            if x == "EOF":
                print("[EOF] exiting from worker")
                return
            else:
                print("[worker] got element: ", x)

    @gen.coroutine
    def test_case():
        q = Queue()
        q.put_nowait(1)
        yield q.put(2)
        yield q.put(3)
        print("[main] got element: ", q.get_nowait())
        print("[main] got element: ", (yield q.get()))
        print("[main] got element: ", q.get_nowait())
        q.put

# Generated at 2022-06-26 08:48:26.433764
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case for exception QueueFull
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    try:
        q.put(3, timeout=0.01)
        print("no exception")
    except QueueFull as e:
        print("got exception")



# Generated at 2022-06-26 08:48:32.173836
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    print(queue)
    queue.put(3)
    print(queue)
    queue.put(5)
    print(queue)
    queue.put(7)
    print(queue)
    queue.put(9)
    print(queue)
    queue.put(1)
    print(queue)


# Generated at 2022-06-26 08:48:43.444957
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue(0)
    q_0 = Queue()
    future_0 = lifo_queue_0.put(0, 0)
    future_1 = lifo_queue_0.put(1, 1)
    future_2 = q_0.put(0, 0)
    future_3 = q_0.put(1, 1)
    future_4 = q_0.put(2)
    future_5 = q_0.put(3)
    future_6 = q_0.put(4)
    future_7 = q_0.put(4, datetime.timedelta(days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0, weeks=0))

# Generated at 2022-06-26 08:48:47.562228
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(5)
    test_Queue_get_0(queue_0)
    queue_0 = Queue()
    test_Queue_get_1(queue_0)

# Positive test case for method get of class Queue

# Generated at 2022-06-26 08:49:00.003450
# Unit test for method put of class Queue
def test_Queue_put():
    @gen.coroutine
    def queue_put_coroutine(expect_queue_size, q, t):
        await gen.sleep(t)
        assert q.qsize() == expect_queue_size
        yield [q.put(i) for i in range(expect_queue_size)]
        assert q.qsize() == expect_queue_size

    def test_case_0():
        q = Queue()
        tornado.ioloop.IOLoop.current().spawn_callback(queue_put_coroutine, 5, q, 0.01)
        tornado.ioloop.IOLoop.current().spawn_callback(queue_put_coroutine, 5, q, 0.02)
        tornado.ioloop.IOLoop.current().spawn_callback(queue_put_coroutine, 5, q, 0.03)


# Generated at 2022-06-26 08:49:02.856111
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put_nowait(1)
    except QueueFull:
        print("Caught QueueFull")


# Generated at 2022-06-26 08:49:06.091936
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    w1 = q.get()
    w2 = q.get()
    w3 = q.get()
    w4 = q.get()
    assert(w1 != w2 != w3 != w4)


# Generated at 2022-06-26 08:49:07.930693
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get(timeout=0) is None


# Generated at 2022-06-26 08:49:19.636187
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 08:49:23.686404
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue
    lifo_queue = Queue()
    lifo_queue.empty()



# Generated at 2022-06-26 08:49:33.829725
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    lifo_queue_0.maxsize = 2
    future_0 = lifo_queue_0.put(2, timeout)
    dt = datetime.datetime(1, 1, 1, 0, 1)
    future_0 = lifo_queue_0.put(5, dt)
    future_0 = lifo_queue_0.put(2, timeout_0)
    try:
        future_0 = lifo_queue_0.put(0, timeout_0)
        future_0 = lifo_queue_0.put(0, timeout)
    except QueueEmpty:
        pass

# Generated at 2022-06-26 08:49:42.245942
# Unit test for method put of class Queue
def test_Queue_put():
    test_q = Queue(maxsize=2)
    test_q.put(1)
    assert(test_q.qsize() == 1)
    assert(test_q.empty() == False)
    assert(test_q.full() == False)
    test_q.put(2)
    assert(test_q.qsize() == 2)
    assert(test_q.empty() == False)
    assert(test_q.full() == True)


# Generated at 2022-06-26 08:49:44.946017
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put_nowait(False)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:49:49.157684
# Unit test for method put of class Queue
def test_Queue_put():
    #self, item: _T, timeout: Optional[Union[float, datetime.timedelta]] = None
    #) -> "Future[None]":
    # Returns a Future, which raises `tornado.util.TimeoutError` after a
    # timeout.
    queue_0 = Queue()
    future_1 = queue_0.put('a', 4)
    future_1 = queue_0.put(2, 3)
    future_1 = queue_0.put(3, 2)
    future_1 = queue_0.put(4, 1)
    future_1 = queue_0.put(5, 0)
    queue_0.qsize()
    queue_0.empty()
    queue_0.full()
    queue_1 = Queue()


# Generated at 2022-06-26 08:50:01.379664
# Unit test for method put of class Queue
def test_Queue_put():
    print("Executing test_Queue_put")
    queue_0 = Queue()
    assert queue_0.qsize() == 0
    assert queue_0.maxsize == 0
    
    queue_1 = Queue(maxsize=0)
    assert queue_1.maxsize == 0
    queue_2 = Queue(maxsize=1)
    assert queue_2.maxsize == 1
    try:
        queue_3 = Queue(maxsize=-1)
        raise Exception("Expected ValueError exception")
    except ValueError:
        pass
    try:
        queue_4 = Queue(maxsize=None)
        raise Exception("Expected TypeError exception")
    except TypeError:
        pass

    queue_5 = Queue(maxsize=1)
    future_0 = queue_5.put(1)

# Generated at 2022-06-26 08:50:06.455741
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    lifo_queue_0 = LifoQueue()
    lifo_queue_0.empty()
    lifo_queue_0.get_nowait()
    lifo_queue_0.empty()
    lifo_queue_0.full()


# Generated at 2022-06-26 08:50:08.150642
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:50:08.695833
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-26 08:50:22.303019
# Unit test for method get of class Queue
def test_Queue_get():
    # Expected value
    expected_value = 1
    # Actual value
    actual_value = None
    # Setup queue
    queue = Queue()
    queue.put(expected_value)
    # Get an item from the queue
    actual_value = queue.get_nowait()
    assert expected_value == actual_value and True or False


# Generated at 2022-06-26 08:50:25.156835
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    with pytest.raises(QueueEmpty):
        queue_0.get_nowait()


# Generated at 2022-06-26 08:50:27.252908
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    queue.put(1)
    queue.put(2)



# Generated at 2022-06-26 08:50:31.219638
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    future = Future()
    queue._getters.append(future)
    queue._consume_expired()
    assert queue._getters == []



# Generated at 2022-06-26 08:50:40.466025
# Unit test for method get of class Queue
def test_Queue_get():
    lifo_queue_0 = LifoQueue()
    # self.assertIsInstance(lifo_queue_0, Queue, "Type check for 'lifo_queue_0' fails.")
    lifo_queue_0._getters.append(None)
    # self.assertTrue(lifo_queue_0.qsize() == 0, "Expected value is 0, actual value is " + str(lifo_queue_0.qsize()))
    lifo_queue_0.task_done()
    lifo_queue_0._unfinished_tasks += 1
    # self.assertTrue(lifo_queue_0.qsize() == 0, "Expected value is 0, actual value is " + str(lifo_queue_0.qsize()))
    lifo_queue_0._finished.clear()
    # self