

# Generated at 2022-06-26 08:41:13.237701
# Unit test for method put of class Queue
def test_Queue_put():
    q_0 = Queue()
    q_0.put(1)
    q_0.put(2)
    print('test_Queue_put: ', q_0)


# Generated at 2022-06-26 08:41:16.056708
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    queue.put(2)
    queue.put(3)


# Generated at 2022-06-26 08:41:17.961583
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = q.get()
    print(future)


# Generated at 2022-06-26 08:41:20.865395
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-26 08:41:33.161220
# Unit test for method put of class Queue

# Generated at 2022-06-26 08:41:42.256240
# Unit test for method get of class Queue
def test_Queue_get():
    class test_Queue(Queue):
        def _init(self) -> None:
            pass
            # self._queue = collections.deque()
        def _get(self) -> _T:
            return self._queue.popleft()
    queue = test_Queue()
    queue.get()
    queue.empty()
    queue.full()
    queue.maxsize
    queue.qsize()
    queue.task_done()
    queue.put(1)
    queue.get_nowait()


# Generated at 2022-06-26 08:41:44.884903
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = q.get()


# Generated at 2022-06-26 08:41:50.122341
# Unit test for method put of class Queue
def test_Queue_put():
    # Define the Queue object
    q = Queue()
    try:
        q.put(1)
    except Exception as e:
        # Assert the excepted outcome
        assert type(e) == QueueFull


# Generated at 2022-06-26 08:41:56.018961
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test 0
    # Constructs a test Queue with the following items
    # Items: '(test_item_0,test_item_1)'
    test_queue_0 = Queue()
    test_item_0 = 'test_item_0'
    test_item_1 = 'test_item_1'
    test_queue_0._put(test_item_0)
    test_queue_0._put(test_item_1)

    # Invokes the method under test
    result_0 = test_queue_0.get_nowait()

    # Asserts that the value passed to the method equals to the expected value
    assert result_0 == test_item_0


# Generated at 2022-06-26 08:41:59.662454
# Unit test for method get of class Queue
def test_Queue_get():
    with pytest.raises(QueueEmpty):
        q0 = Queue()
        v0 = q0.get()


# Generated at 2022-06-26 08:42:17.910374
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Create an empty Queue object with no maximum size
    q = Queue()
    assert(q.empty() == True)
    assert(q.full() == False)
    assert(q.qsize() == 0)

    # Add one item
    item_1 = "item_1"
    q.put_nowait(item_1)
    assert(q.empty() == False)
    assert(q.full() == False)
    assert(q.qsize() == 1)

    # Add one more item, the queue should still not be full
    item_2 = "item_2"
    q.put_nowait(item_2)
    assert(q.empty() == False)
    assert(q.full() == False)
    assert(q.qsize() == 2)

    # Create a Queue object with

# Generated at 2022-06-26 08:42:21.077785
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_queue = Queue()
    #test_queue.get_nowait()
    #test_queue.get_nowait()
    pass

if __name__ == "__main__":
    test_Queue_get_nowait()
    #test_case_0()
    pass



# Generated at 2022-06-26 08:42:30.176721
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    try:
        q.get()
    except QueueEmpty:
        pass

    q.put(1)
    q.get()

    q.put(1)
    q.put(2)
    q.get()
    q.get()

    q.put(1)
    q.put(2)
    q.get_nowait()
    q.get_nowait()

    try:
        q.get_nowait()
    except QueueEmpty:
        pass

    # Test that this method can be called when there are getters waiting.
    q.put(1)
    q.get()
    q.get()



# Generated at 2022-06-26 08:42:32.576378
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get() == None


# Generated at 2022-06-26 08:42:34.046791
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass


# Generated at 2022-06-26 08:42:35.789820
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)



# Generated at 2022-06-26 08:42:39.411004
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait() # get_nowait(self) -> _T
        raise AssertionError
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:42:41.397918
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()


# Generated at 2022-06-26 08:42:53.414550
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        priority_queue_0 = PriorityQueue()
        (priority_queue_0.get_nowait())
    except QueueEmpty:
        pass
    QueueEmpty()
    try:
        _T('\x00')
        (priority_queue_0.get_nowait())
    except QueueEmpty:
        pass
    QueueEmpty()
    try:
        (priority_queue_0.get_nowait())
    except QueueEmpty:
        pass
    QueueEmpty()
    try:
        (priority_queue_0.get_nowait())
    except QueueEmpty:
        pass
    QueueEmpty()
    try:
        (priority_queue_0.get_nowait())
    except QueueEmpty:
        pass
    QueueEmpty()

# Generated at 2022-06-26 08:42:57.528847
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    q.put_nowait(1)
    assert q.get_nowait() == 1
    

# Generated at 2022-06-26 08:43:14.840714
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q0 = Queue()
    future0 = q0.put(((1, 1) + (1,),))
    assert future0.done()
    assert future0.result() is None

    # Example 1
    q1 = Queue(2)
    try:
        q1.put_nowait(((1, 1) + (1,),))
        q1.put_nowait(((1, 1) + (1,),))
        q1.put_nowait(((1, 1) + (1,),))
    except QueueFull:
        assert True
    else:
        assert False

    # Example 2
    q2 = Queue()

# Generated at 2022-06-26 08:43:18.621562
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    value = 1
    assert queue_0.put(value) and queue_0.qsize() == 1
    return True


# Generated at 2022-06-26 08:43:32.019798
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_cases = [
        [{"input": {"class_name": "Queue", "params": [None], "method": "empty", "self": None}, "args": None, "kwargs": None}, []],
        [{"input": {"class_name": "Queue", "params": [None], "method": "qsize", "self": None}, "args": None, "kwargs": None}, []],
        [{"input": {"class_name": "Queue", "params": [None], "method": "put_nowait", "self": None}, "args": ["input_0"], "kwargs": None}, []],
        [{"input": {"class_name": "Queue", "params": [None], "method": "get_nowait", "self": None}, "args": None, "kwargs": None}, []],
    ]
    queue_

# Generated at 2022-06-26 08:43:37.484076
# Unit test for method put of class Queue
def test_Queue_put():
    expected = None
    # Create an instance of Queue
    queue_0 = Queue()
    # Call method put of queue_0
    result = queue_0.put(expected)
    assert result == expected



# Generated at 2022-06-26 08:43:46.778783
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import datetime

    def get_time_now_in_s():
        return time.time()

    def get_datetime_now():
        return datetime.datetime.now()

    def get_timedelta_from_ms(ms):
        return datetime.timedelta(milliseconds=ms)

    # Case 0: no timeout
    test_case_0()

    # Case 1: timeout as a number
    q_1 = Queue()
    time_now_1 = get_time_now_in_s()
    future_1 = q_1.put(1, timeout=2)
    time_delta_1 = get_time_now_in_s() - time_now_1

# Generated at 2022-06-26 08:43:49.971334
# Unit test for method put of class Queue
def test_Queue_put():
    #q.put()
    q = Queue(maxsize=2)


# Generated at 2022-06-26 08:43:52.365326
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_0 = PriorityQueue()
    priority_queue_0.put_nowait(2)

# Generated at 2022-06-26 08:44:05.627267
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test case 0, QueueEmpty is raised
    try:
        priority_queue_0 = PriorityQueue()
        priority_queue_0.get_nowait()
    except QueueEmpty:
        print("Test case 0: Pass")
    else:
        print("Test case 0: Fail")

    # Test case 1

# Generated at 2022-06-26 08:44:18.294832
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a queue with maxsize=5, then put 4 items into the queue.
    q = Queue(maxsize=5)
    for i in range(4):
        q.put_nowait(i)

    # Get 3 items from the queue with timeout specified.
    timeout = 0.1
    i = 0
    while i < 3:
        try:
            future = q.get(timeout)
            print("Get item %s" % future)
        except gen.TimeoutError:
            assert (i != 2), "Exception thrown prematurely"
            assert (i == 2), "Exception should be thrown"
            print("No item got in time")
        else:
            future.set_result(i)
        finally:
            i = i + 1

    # Get 3 more items from the queue with timeout specified. It should
    # always

# Generated at 2022-06-26 08:44:28.630639
# Unit test for method get of class Queue
def test_Queue_get():
    test_Queue_get_queue = Queue(maxsize = 1000)
    # AssertionError: Unexpected exception raised.
    # Expected: <class 'tornado.util.TimeoutError'>
    # Actual: <class 'tornado.queues.QueueFull'>
    # assertRaises( test_Queue_get_queue.put(1), QueueFull )
    # assertRaises( test_Queue_get_queue.put(1), QueueFull )
    # assertRaises( test_Queue_get_queue.put(1), QueueFull )
    # assertRaises( test_Queue_get_queue.put(1), QueueFull )
    # assertRaises( test_Queue_get_queue.put(1), QueueFull )
    # assertRaises( test_Queue_get_queue.put(1), Que

# Generated at 2022-06-26 08:44:37.500980
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=3)
    q.get_nowait()


# Generated at 2022-06-26 08:44:41.927504
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:44:48.805331
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize= 2)
    q.put_nowait(1)
    q.put_nowait(5)
    # q.put_nowait(6)
    # q.put_nowait(0.5)
    # q.put_nowait(0.1)
    future = q.put(2)
    future.add_done_callback(lambda _: print('done'))
    future.add_done_callback(lambda _: print('ok'))



# Generated at 2022-06-26 08:45:00.766716
# Unit test for method get of class Queue
def test_Queue_get():
    # The test case plan:
    # 1. Create a Queue instance
    # 2. Use get to get some items, and then check the size of queue
    # 3. Use put to put some items, and then check the size of queue
    # 4. Use put_nowait to put some items, and then check the size of queue
    # 5. Use get_nowait to get some items, and then check the size of queue
    # 6. Use put_nowait to put some items, and then check the size of queue when queue if full
    # 7. Use get_nowait to get some items, and then check the size of queue when queue is empty
    # 8. Use get to get some items, and then check the size of queue
    # 9. Use task_done
    # 10. Use join

    # Create a Queue instance
    q = Que

# Generated at 2022-06-26 08:45:12.794049
# Unit test for method put of class Queue

# Generated at 2022-06-26 08:45:23.948785
# Unit test for method get of class Queue
def test_Queue_get():
    # Test 1: basic scenario
    queue_0 = Queue()
    print(queue_0)
    print(queue_0.get())

    # Test 2: basic scenario
    queue_1 = Queue()
    print(queue_1.get(None))

    # Test 3: basic scenario
    queue_2 = Queue()
    print(queue_2.get(timeout=0.0))

    # Test 4: basic scenario
    queue_3 = Queue()
    print(queue_3.get(timeout=datetime.timedelta()))

    # Test 5: basic scenario
    queue_4 = Queue()
    print(queue_4.get(timeout=datetime.timedelta(days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0)))



# Unit

# Generated at 2022-06-26 08:45:34.642345
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado.testing import gen_test

    class Queue(tornado.queues.Queue):
        def __init__(self, maxsize: int = 0) -> None:
            self._maxsize = maxsize
            self._queue = collections.deque()
            self._getters = collections.deque()
            self._putters = collections.deque()
            self._unfinished_tasks = 0
            self._finished = tornado.locks.Event()
            self._finished.set()

        @property
        def maxsize(self) -> int:
            return self._maxsize

        def qsize(self) -> int:
            return len(self._queue)

        def empty(self) -> bool:
            return not self._queue

        def full(self) -> bool:
            if self.maxsize == 0:
                return

# Generated at 2022-06-26 08:45:44.631602
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    if __name__ == "__main__":
        q = Queue(maxsize=2)
        q.put_nowait(1)
        q.put_nowait(2)
        try:
            q.put_nowait(3)
        except QueueFull:
            print("Put 3 failed")
            pass
        except:
            print("Unexpected exception:", sys.exc_info())
            raise

        #print(f"Queue {q}")
        #print(f"queue size {q.qsize()}")

# Test case for class Queue
if __name__ == "__main__":
    test_case_0()
    test_Queue_put_nowait()

# Generated at 2022-06-26 08:45:54.614675
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q1 = Queue()
    try:
        q1.put_nowait(1)
        q1.put_nowait(2)
        q1.put_nowait(3)
        q1.put_nowait(4)
        q1.put_nowait(5)
        q1.put_nowait(6)
        q1.put_nowait(7)
        q1.put_nowait(8)
        q1.put_nowait(9)
        q1.put_nowait(10)
        q1.put_nowait(11)
        q1.put_nowait(12)
    except QueueFull:
        print("The queue is full")
    else:
        pass


# Generated at 2022-06-26 08:46:05.677272
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    print('Starting test test_Queue_get_nowait')
    print('Testing case 1')
    queue_0 = Queue()
    value = queue_0.get_nowait()
    print('Testing case 2')
    queue_1 = Queue()
    value = queue_1.get_nowait()
    print('Testing case 3')
    queue_2 = Queue()
    value = queue_2.get_nowait()
    print('Testing case 4')
    queue_3 = Queue()
    value = queue_3.get_nowait()
    print('Testing case 5')
    queue_4 = Queue()
    value = queue_4.get_nowait()
    print('Testing case 6')
    queue_5 = Queue()
    value = queue_5.get_nowait()

# Generated at 2022-06-26 08:46:20.763266
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty as e:
        pass


# Generated at 2022-06-26 08:46:31.005195
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Initializing queue_0 with default maxsize = 0
    queue_0 = Queue()
    # Enqueuing string 'item_0' into queue_0
    queue_0.put_nowait('item_0')
    # Enqueuing string 'item_1' into queue_0
    queue_0.put_nowait('item_1')
    # Enqueuing string 'item_2' into queue_0
    queue_0.put_nowait('item_2')
    # Swapping item at index 0 with item at index 2
    queue_0._queue[0], queue_0._queue[2] = queue_0._queue[2], queue_0._queue[0]

    # Expected output of queue_0._queue is a deque object with three items:
    # item_2, item_1, item_0

# Generated at 2022-06-26 08:46:42.021796
# Unit test for method put of class Queue
def test_Queue_put():
    #  Queue<Integer> pq = new PriorityQueue<Integer>();
    #  Queue<Integer> q = pq;
    _maxsize = 10
    pq = Queue(_maxsize);
    q = pq;
    # int num_operations = 10;
    num_operations = 10;
    #  for (int i = 0; i < num_operations; i++) {
    #      int rnd = new Random().nextInt(3);
    #      if (rnd == 0) {
    #          int val = new Random().nextInt(10);
    #          q.put(val);
    #      } else if (rnd == 1) {
    #          q.get();
    #      } else {
    #          break;
    #      }
    #  }

# Generated at 2022-06-26 08:46:48.060037
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    case_0_queue = Queue()

    try:
        case_0_queue.get_nowait()
    except QueueEmpty:
        print("PASSED test_Queue_get_nowait")
    else:
        print("FAILED test_Queue_get_nowait")


# Generated at 2022-06-26 08:46:50.371213
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)


# Generated at 2022-06-26 08:46:56.006315
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:47:09.221661
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create Queue
    queue_0 = Queue()
    queue_1 = Queue()

    # check if putter is empty
    assert len(queue_0._putters) == 0

    # check if getter is empty
    assert len(queue_0._getters) == 0

    # check if Queue is not full
    assert queue_0.full() == False

    # check if Queue is empty
    assert queue_0.empty() == True

    # check if qsize of Queue is 0
    assert queue_0.qsize() == 0

    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass

    # consume putter and getter
    queue_0._consume_expired()

    # check if the queue is empty
    assert queue_0.qsize()

# Generated at 2022-06-26 08:47:12.531578
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = PriorityQueue()
    try:
        q.put_nowait(10)
    except QueueFull:
        print("Queue full")


# Generated at 2022-06-26 08:47:15.684378
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  assert True
  # priority_queue_0 = PriorityQueue()
  # priority_queue_0.put_nowait(0)


# Generated at 2022-06-26 08:47:21.688318
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create a Queue object
    queue_object_0 = Queue()

    try:
        # Call method get_nowait
        queue_object_0.get_nowait()
        # Should not reach here
        assert False
    except QueueEmpty:
        # This is expected
        pass
    except:
        # Unexpected exception
        print("Exception: " + sys.exc_info()[0])
        assert False


# Generated at 2022-06-26 08:47:41.889318
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    queue_0.put(None)
    queue_0.put(None)
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    queue_0.put(None)
    queue_0.put_nowait(None)
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    queue_0.task_done()
    queue_0.task_done()
    queue_0.task_done()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass

# Generated at 2022-06-26 08:47:52.591677
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    val_0 = queue_0.put(1, None)
    val_1 = queue_0.put_nowait(3)
    val_2 = queue_0.put_nowait(3)
    val_3 = queue_0.put_nowait(3)
    val_4 = queue_0.put_nowait(3)
    val_5 = queue_0.put_nowait(3)
    val_6 = queue_0.put_nowait(3)
    val_7 = queue_0.put_nowait(3)
    val_8 = queue_0.put_nowait(3)
    val_9 = queue_0.put_nowait(3)
    val_10 = queue_0.put_nowait(3)
    val_11

# Generated at 2022-06-26 08:48:02.817099
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue object to test
    qu = Queue()
    # Enqueue an item to the queue
    qu.put_nowait(1)
    print(qu._queue)
    # Invoke method put with a timedelta object
    qu.put(1, datetime.timedelta(seconds=15))
    # Invoke method put with a float value
    qu.put(1, 15.0)



# Generated at 2022-06-26 08:48:05.416614
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_Queue = Queue()
    with pytest.raises(QueueEmpty):
        test_Queue.get_nowait()


# Generated at 2022-06-26 08:48:09.402661
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "queue.get_nowait() with an empty queue must raise an exception"



# Generated at 2022-06-26 08:48:15.855201
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=1)
    future = Future()  # type: Future[_T]
    q.put_nowait(future)
    q.get_nowait()
    # >>> here
    # import time
    # time.time()
    # 1499186900.171446
    pass


# Generated at 2022-06-26 08:48:23.001609
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue = PriorityQueue()
    priority_queue.put_nowait(1)
    priority_queue.put_nowait(2)
    priority_queue.put_nowait(3)
    priority_queue.put_nowait(4)
    priority_queue.put_nowait(5)
    priority_queue.put_nowait(6)
    priority_queue.put_nowait(7)
    priority_queue.put_nowait(8)
    priority_queue.put_nowait(9)
    priority_queue.put_nowait(10)
    priority_queue.put_nowait(11)


# Generated at 2022-06-26 08:48:28.081587
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_1 = PriorityQueue(maxsize=1)
    priority_queue_1.put_nowait(0)
    try:
        priority_queue_1.put_nowait(1)
        assert(False)
    except QueueFull:
        assert(True)


# Generated at 2022-06-26 08:48:34.511943
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get()
    with pytest.raises(QueueEmpty):
        q.get()
    q.put_nowait(0)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 0
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2


# Generated at 2022-06-26 08:48:45.069502
# Unit test for method put of class Queue
def test_Queue_put():
    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop = ioloop.IOLoop.current()
        io_loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    q = Queue(maxsize=2)
    io_loop = ioloop.IOLoop

# Generated at 2022-06-26 08:48:59.908437
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    priority_queue_0 = PriorityQueue()
    try:
        priority_queue_0.get_nowait()
    except QueueEmpty:
        assert False


# Generated at 2022-06-26 08:49:03.088041
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()

    def callback(f):
        print(f.result())

    f = q.get()
    print("start")
    f.add_done_callback(callback)
    q.put_nowait("1")



# Generated at 2022-06-26 08:49:16.814052
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import sys
    print("Unit test for method put_nowait of class Queue")
    priority_queue_0 = PriorityQueue()
    assert priority_queue_0.empty()
    assert len(priority_queue_0._queue) == 0
    assert not len(priority_queue_0._queue)
    # Test case 0: insert an item into PriorityQueue instance priority_queue_0
    priority_queue_0.put_nowait(0)
    assert not priority_queue_0.empty()
    assert priority_queue_0.qsize() == 1
    assert priority_queue_0._queue
    priority_queue_1 = PriorityQueue(maxsize=2)
    assert priority_queue_1.empty()
    assert len(priority_queue_1._queue) == 0
    assert not len(priority_queue_1._queue)
   

# Generated at 2022-06-26 08:49:19.122826
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = q.get()
    future.set_result(1)


# Generated at 2022-06-26 08:49:25.308466
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    priority_queue_0 = PriorityQueue()

    for num in range(50):
        try:
            priority_queue_0.put_nowait(num)
            print(priority_queue_0.qsize())
        except QueueFull:
            print("QueueFull")

    return QueueFull


# Generated at 2022-06-26 08:49:34.660155
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop

# Generated at 2022-06-26 08:49:42.380436
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a queue with maxsize as 3
    queue_0 = Queue(maxsize=3)
    # Add 4 items to the queue
    q_size = queue_0.qsize()
    queue_0.put(1)
    queue_0.put(2)
    queue_0.put(3)
    queue_0.put(4)
    # Verify that the queue is full
    assert queue_0.full() == True

# Generated at 2022-06-26 08:49:46.229532
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test for expected exception
    priority_queue_1 = PriorityQueue()
    try:
        priority_queue_1.put_nowait(2)
    except QueueFull:
        pass




# Generated at 2022-06-26 08:49:51.874109
# Unit test for method get of class Queue
def test_Queue_get():
    test_queue_0 = Queue()
    test_timeout_0 = None
    test_future_0 = test_queue_0.get(test_timeout_0)
    try:
        test_future_0.set_result(None)
    except Exception:
        print("Exception raised when calling Future.set_result")


# Generated at 2022-06-26 08:50:03.615972
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(10)

    assert queue_0.qsize() == 0, "queue_0.qsize() == 0"

    assert queue_0.maxsize == 10, "queue_0.maxsize == 10"

    # TODO1: set the item in queue_0
    queue_0.put_nowait(50)

    assert queue_0.qsize() == 1, "queue_0.qsize() == 1"

    # TODO1: set the item in queue_0
    queue_0.put_nowait(20)

    assert queue_0.qsize() == 2, "queue_0.qsize() == 2"

    # TODO1: set the item in queue_0
    queue_0.put_nowait(5)


# Generated at 2022-06-26 08:50:17.956548
# Unit test for method put of class Queue
def test_Queue_put():
    n = 0
    priority_queue_0 = PriorityQueue()
    priority_queue_0.put(n)
    assert priority_queue_0.qsize() == 1


# Generated at 2022-06-26 08:50:21.877809
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create an instance of Queue with maxsize=0
    q = Queue(maxsize=0)
    # Try to get items from the queue without blocking
    try:
        result = q.get_nowait()
    except QueueEmpty:
        pass
    assert q.empty()


# Generated at 2022-06-26 08:50:24.603032
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-26 08:50:26.529734
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get(timeout=1)


# Generated at 2022-06-26 08:50:38.533471
# Unit test for method get of class Queue
def test_Queue_get():
    try:
        queue = Queue(1)
        q_len = queue.qsize()
        assert queue.qsize() == 0

        # Get an item from the queue without blocking.
        # Return an item if one is immediately available, else raise QueueEmpty.
        res = queue.get_nowait()
        assert False
    except QueueEmpty as e:
        pass
    assert queue.qsize() == 0

    # Put an item into the queue, perhaps waiting until there is room.
    # Returns a Future, which raises tornado.util.TimeoutError after a timeout.
    # item = 'abc'
    # timeout = 2
    # future = queue.put(item, timeout)
    # print(future)
    # assert len(queue._putters) == 1
    # assert queue._putters[0][0] == item


# Generated at 2022-06-26 08:50:39.798594
# Unit test for method get of class Queue
def test_Queue_get():
    _queue = PriorityQueue()
    _queue.join()


# Generated at 2022-06-26 08:50:43.647406
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize_0 = 42
    queue_0 = Queue(maxsize_0)
    num_0 = '<wrong return value>'
    try:
        num_0 = queue_0.put_nowait(5)
    except:
        pass
    assert(False)
