

# Generated at 2022-06-26 08:41:23.461020
# Unit test for method get of class Queue
def test_Queue_get():
    test_data = Queue()
    timeout_0 = 1.1817743350557655
    timeout_1 = 2.9973234116773678
    timeout_2 = 1.680281955422078
    timeout_3 = 1.7451168661763543
    timeout_4 = 3.1998899548850526
    timeout_5 = 2.453064488847401
    timeout_6 = 1.327129467243647
    timeout_7 = 1.742029225706899
    timeout_8 = 1.846332632134506
    timeout_9 = 3.865302645444418
    test_0 = test_data.get(timeout=timeout_0)
    test_1 = test_data.get(timeout=timeout_1)
    test

# Generated at 2022-06-26 08:41:28.605882
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue(maxsize=2)
    assert isinstance(queue_1.put(item=1, timeout=1), Future)


# Generated at 2022-06-26 08:41:30.176453
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    ret_val_0 = queue_0.get_nowait()


# Generated at 2022-06-26 08:41:43.830751
# Unit test for method put of class Queue
def test_Queue_put():
    @gen.coroutine
    def timeout_callback(q, timeout):
        try:
            q.put('a', timeout=0.1)
        except gen.TimeoutError:
            return 'pass'
    @gen.coroutine
    def test_put_0():
        q = Queue()
        r = yield q.put('a')
        return r
    @gen.coroutine
    def test_put_1():
        q = Queue()
        r = yield q.put('a', timeout=0.1)
        return r
    
    # set up event loop
    io_loop = ioloop.IOLoop.current()
    test_put_0_future = test_put_0()

# Generated at 2022-06-26 08:41:47.799405
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)
    timeout = 1
    future = q.get(timeout)
    print(future.result())


# Generated at 2022-06-26 08:41:55.895124
# Unit test for method put of class Queue
def test_Queue_put():
    print("test_Queue_put")
    maxsize = 3
    q = Queue(maxsize)
    t = 0
    assert not q.full(), "Queue full"
    try:
        q.put_nowait(t)
    except QueueFull:
        assert False
    assert not q.empty(), "Queue empty"
    t = 1
    try:
        q.put_nowait(t)
    except QueueFull:
        assert False
    assert not q.empty(), "Queue empty"
    t = 2
    try:
        q.put_nowait(t)
    except QueueFull:
        assert False
    assert q.full(), "Queue not full"
    assert not q.empty(), "Queue empty"
    test_case_0()

# Generated at 2022-06-26 08:41:58.394475
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(())


# Generated at 2022-06-26 08:42:00.494735
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue(maxsize = 10)
    queue.get()


# Generated at 2022-06-26 08:42:03.478619
# Unit test for method put of class Queue
def test_Queue_put():
    q0 = Queue(5)
    # Run put method
    result = q0.put("", )
    pass


# Generated at 2022-06-26 08:42:07.056015
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    try:
        queue.get_nowait()
    except QueueEmpty:
        None
    else:
        assert False

# Generated at 2022-06-26 08:42:35.599996
# Unit test for method put of class Queue
def test_Queue_put():
    #testing for the case that maxsize != None and qsize() < maxsize
    q0 = Queue(2)
    q0.put(1)
    assert q0.qsize() == 1

    #testing for the case that maxsize != None and qsize() == maxsize
    try:
        q0.put(2)
        q0.put(3)
        raise AttributeError("queue is full.Can't Put")
    except QueueFull:
        pass

    #testing for the case that maxsize == None
    q1 = Queue()
    q1.put(1)
    assert q1.qsize() == 1
    q1.put(3)
    assert q1.qsize() == 2


# Generated at 2022-06-26 08:42:37.872681
# Unit test for method put of class Queue
def test_Queue_put():
    IOLoop.current().spawn_callback(test_case_0)

test_Queue_put()


# Generated at 2022-06-26 08:42:45.461304
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    q.put_nowait(3)
    try:
        assert not q.full()
    except QueueFull as e:
        print('test_case_1')
        return


# Generated at 2022-06-26 08:42:58.093214
# Unit test for method get of class Queue
def test_Queue_get():
    '''
    This test deals with the get method of class Queue in the
    tornado.queues module.
    '''
    from typing import Optional
    from tornado.queues import Queue
    import datetime
    # Call get method of Queue with parameter timeout of type Optional[Union[float, datetime.timedelta]].
    q_0 = Queue()
    timeout_0 = None
    get_0 = q_0.get(timeout=timeout_0)
    # Call get method of Queue with parameter timeout of type Optional[Union[float, datetime.timedelta]].
    q_1 = Queue()
    timeout_1 = 3.2
    get_1 = q_1.get(timeout=timeout_1)
    # Call get method of Queue with parameter timeout of type Optional[Union[float, datetime

# Generated at 2022-06-26 08:43:01.054476
# Unit test for method put of class Queue
def test_Queue_put():
    my_queue = Queue()
    my_future = my_queue.put(0)


# Generated at 2022-06-26 08:43:05.987946
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait("a")
    q.put_nowait("b")
    q.put_nowait("c")

# Generated at 2022-06-26 08:43:07.595409
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.maxsize == 0
    q.put(1)
    q.put_nowait(2)


# Generated at 2022-06-26 08:43:09.430770
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)


# Generated at 2022-06-26 08:43:21.478599
# Unit test for method put of class Queue
def test_Queue_put():
    async def async_producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def async_main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await async_producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    q = Queue(maxsize=2)
    IOLoop.current().run_sync(async_main)




# Generated at 2022-06-26 08:43:24.019506
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull as qf:
        assert isinstance(qf, QueueFull)


# Generated at 2022-06-26 08:43:49.015456
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()

    def test_function() -> None:
        with pytest.raises(QueueEmpty):
            queue_0.get_nowait()

    test_function()
    queue_1 = Queue(maxsize=0)
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)
    assert queue_1.get_nowait() == 1
    assert queue_1.get_nowait() == 2
    assert queue_1.get_nowait() == 3
    queue_1 = Queue(maxsize=0)
    queue_1.put_nowait(1)

# Generated at 2022-06-26 08:43:51.909971
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize = 0)
    queue.put_nowait("item")


# Generated at 2022-06-26 08:43:58.872106
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    # check that _consume_expired is called by put_nowait
    f = Future()
    q._putters.append((None, f))
    q.put_nowait(1)
    assert q.qsize() == 1
    assert f in q._putters


# Generated at 2022-06-26 08:44:02.124105
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:44:10.590013
# Unit test for method put of class Queue
def test_Queue_put():
    queue_put_0 = Queue(maxsize=0)
    queue_put_1 = queue_put_0.put_nowait("")
    queue_put_2 = queue_put_0.put_nowait("")
    queue_put_3 = queue_put_0.put_nowait("")
    queue_put_4 = queue_put_0.put_nowait("")
    queue_put_5 = queue_put_0.put_nowait("")
    queue_put_6 = queue_put_0.put_nowait("")
    queue_put_7 = queue_put_0.qsize()
    queue_put_8 = queue_put_0.put_nowait("")
    queue_put_9 = queue_put_0.put_nowait("")
    queue_put_10

# Generated at 2022-06-26 08:44:19.956524
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 10

    # case 0:
    q0 = Queue(maxsize)
    assert q0.qsize() == 0, "queue size should be 0"
    assert q0.maxsize == maxsize, "queue max size should be 10"
    assert q0.empty() == True, "queue should be empty"
    assert q0.full() == False, "queue should not be full"

    # case 1:
    try:
        q0.put_nowait(1)
    except Exception:
        raise AssertionError("QueueFull should not be raised")
    assert q0.qsize() == 1, "queue size should be 1"
    assert q0.maxsize == maxsize, "queue max size should be 10"
    assert q0.empty() == False, "queue should not be empty"
    assert q

# Generated at 2022-06-26 08:44:29.314493
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
        q.task_

# Generated at 2022-06-26 08:44:34.574088
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1, "Queue.put_nowait: test case failed"

test_Queue_put_nowait()


# Generated at 2022-06-26 08:44:41.397281
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Arrange
    queue = Queue()
    queue.__put_internal("item")
    # Act
    item = queue.get_nowait()
    # Assert
    assert item == "item"
    assert queue.qsize() == 0


# Generated at 2022-06-26 08:44:50.014337
# Unit test for method get of class Queue
def test_Queue_get():
    # Test a list of Queue object get
    # Test object type
    # Test object type with a list of object
    # Test create Queue object with a list of object
    # Test Queue object with a list of object
    q = Queue()
    # Get the value of Queue object q
    result_get_1 = q.get()
    # Test file operation on Queue object q
    with open("test_Queue.txt", 'w') as f:
        f.write(str(q))
    # Test ioloop operation on Queue object q
    ioloop.IOLoop.current().run_sync(lambda: result_get_1)
    # Test ioloop operation on Queue object q
    ioloop.IOLoop.current().run_sync(q.get)
    # Test string operation on Queue

# Generated at 2022-06-26 08:45:25.900177
# Unit test for method put of class Queue
def test_Queue_put():
    m = Queue()
    assert m.put(1) == None


# Generated at 2022-06-26 08:45:33.218967
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an instance of class Queue
    test_queue_0 = Queue(10)
    # Get method get of class Queue
    test_queue_0_get = test_queue_0.get
    # Call method get with arguments
    # test_queue_0_get()
    test_queue_0_get(3.5)
    test_queue_0_get(1.2)
    test_queue_0_get(datetime.datetime.now())


# Generated at 2022-06-26 08:45:40.402162
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_1 = Queue(maxsize=0)
    try:
        future_0 = queue_1.get()
    except gen.TimeoutError:
        pass
    
    queue_0.task_done()
    future_1 = queue_0.get()
    pass


# Generated at 2022-06-26 08:45:45.560615
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    def get_nowait_0():
        q = Queue(5)
        msg_0 = "Queue.get_nowait()'method raise QueueEmpty exception when the queue is empty"
        v_0 = 0
        while True:
            try:
                q.get_nowait()
                v_0 += 1
            except QueueEmpty as e_0:
                msg_0 += str(e_0)
                break
        return v_0 + len(msg_0)
    print(get_nowait_0())


# Generated at 2022-06-26 08:45:47.418783
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert(type(q.put(1)) == type(Future()))


# Generated at 2022-06-26 08:45:55.361163
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
            # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(producer)

# Generated at 2022-06-26 08:46:04.194977
# Unit test for method put of class Queue
def test_Queue_put():
    loop_0 = ioloop.IOLoop.current()
    q_0 = Queue[int](0)
    f_0 = q_0.put(1, 1)
    loop_0.run_sync(lambda : f_0)
    f_0 = q_0.put(10, None)
    loop_0.run_sync(lambda : f_0)
    f_0 = q_0.put(2, 2)
    loop_0.run_sync(lambda : f_0)
    # no exception


# Generated at 2022-06-26 08:46:17.064149
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run

# Generated at 2022-06-26 08:46:29.182928
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.qsize()
    q.empty()
    q.full()
    q.put(0)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    q.get()
    q.get()
    q.task_done()
    q.join()
    q.qsize()
    q.empty()
    q.full()
    q.put(0)
    q.put(1)
    q.put(2)
    q.full()
    q.qsize()
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.task_done()
    q.join()
    f = Future()

# Generated at 2022-06-26 08:46:31.407204
# Unit test for method get of class Queue
def test_Queue_get():
    def get_test(self):
        self.get()

    def get_test_timeout(self):
        self.get(timeout=1.0)


# Generated at 2022-06-26 08:47:08.037500
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue(3)
    future_0 = Future()
    queue_1.put(0, future_0)


# Generated at 2022-06-26 08:47:11.125635
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future = queue_0.put(1)


# Generated at 2022-06-26 08:47:17.439498
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    res = queue_1.get()
    print(res)
    res = queue_1.get(timeout=2.0)
    print(res)
    res = queue_1.get(timeout=datetime.timedelta(seconds=3))
    print(res)


# Generated at 2022-06-26 08:47:22.307243
# Unit test for method get of class Queue
def test_Queue_get():
    print('-----in test_Queue_get------')
    test_queue = Queue()
    test_queue_get = test_queue.get()
    print(test_queue_get)



# Generated at 2022-06-26 08:47:25.436993
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(maxsize=0)
    item_1 = None
    try:
        queue_1.put_nowait(item_1)
    except QueueFull:
        assert False


# Generated at 2022-06-26 08:47:29.920510
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    item = ""
    try:
        queue_0.get_nowait()
    except QueueEmpty as e:
        item = e.args[0]
    return item


# Generated at 2022-06-26 08:47:33.818137
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    future_0 = queue_1.get()

    assert isinstance(future_0, Future)
    assert future_0.done()
    assert not future_0.result()



# Generated at 2022-06-26 08:47:38.828561
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    f = queue_1.put(0)
    assert f.result() == None


# Generated at 2022-06-26 08:47:50.933194
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen

    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    queue_1 = Queue(maxsize=1)


    async def consumer_0():
        async for item in queue_1:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                queue_1.task_done()


    async def producer_0():
        for item in range(5):
            await queue_1.put(item)
            print('Put %s' % item)


    async def main_0():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer_0)
        await producer_0()     # Wait for producer to put all tasks.
       

# Generated at 2022-06-26 08:47:52.825822
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait('a')


# Generated at 2022-06-26 08:48:28.684043
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_case_0()
    queue_1 = Queue()
    v = queue_1.get_nowait()


# Generated at 2022-06-26 08:48:30.930097
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put(res)
    future_0.set_result


# Generated at 2022-06-26 08:48:33.669206
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.put(1)
    future = queue.get()
    assert future.result() == 1


# Generated at 2022-06-26 08:48:36.975413
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """Test case for method get_nowait of class Queue"""
    queue_0 = Queue(1)
    queue_0.put_nowait(1)
    assert(queue_0.get() == 1)



# Generated at 2022-06-26 08:48:44.914039
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    future = Future()
    future.set_result("test")
    queue._getters.append(future)

    if queue._getters:
        assert queue.empty(), "queue non-empty, why are getters waiting?"
        getter = queue._getters.popleft()
        queue.__put_internal("test2")
        future_set_result_unless_cancelled(getter, queue._get())
    elif queue.full():
        raise QueueFull
    else:
        queue.__put_internal("test2")



# Generated at 2022-06-26 08:48:57.567914
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    # Test bool type
    bool_0 = bool
    bool_0 = queue_0.empty()
    queue_0.put_nowait(0)
    # Test int type
    int_0 = int
    int_0 = queue_0.qsize()
    # Test Exception type
    exception_0 = QueueFull()
    exception_1 = QueueEmpty()
    queue_0.put_nowait(0)
    queue_0.put_nowait(0)
    try:
        queue_0.put_nowait(0)
    except Exception as exception_1:
        exception_0 = exception_1
    int_0 = queue_0.qsize()
    try:
        queue_0.get_nowait()
    except Exception as exception_2:
        exception

# Generated at 2022-06-26 08:49:04.493526
# Unit test for method put of class Queue
def test_Queue_put():
    queue_complete = True
    queue_0 = Queue()
    
    i = 0
    while (i < 1):
        try:
            
            queue_0.put(1.0, None)
            
        except Exception as e0:
            queue_complete = False
            print("TEST_FAILED: test_Queue_put")
            print(e0)
            
        i += 1
    
    if (queue_complete):
        print("TEST_PASSED: test_Queue_put")


# Generated at 2022-06-26 08:49:18.518194
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def producer():
        for item in range(5):
            print('Put %s' % item)
            await q.put(item)
        print("put done")
    test_case_1 = producer()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    test_case_2 = consumer()

    async def main():
        IOLoop.current().spawn_callback(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       #

# Generated at 2022-06-26 08:49:25.861982
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.qsize()
    queue_0.empty()
    queue_0.full()
    queue_0.put()
    queue_0.put_nowait()
    queue_0.get()
    queue_0.get_nowait()
    queue_0.task_done()
    queue_0.join()



# Generated at 2022-06-26 08:49:34.863964
# Unit test for method put of class Queue
def test_Queue_put():
    try:
        queue_1 = Queue(maxsize=2)
        if queue_1.qsize() != 0:
            raise AssertionError("Expected {} to be {}".format(queue_1.qsize(), 0))
    except AssertionError as ae:
        print("AssertionError raised in test_case_1: " + str(ae))
        return
    
    try:
        queue_1.put(1)
        if queue_1.qsize() != 1:
            raise AssertionError("Expected {} to be {}".format(queue_1.qsize(), 1))
    except AssertionError as ae:
        print("AssertionError raised in test_case_2: " + str(ae))
        return
    