

# Generated at 2022-06-26 08:41:30.470875
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Method setUp is called before any test
    q = Queue()
    # Unit test the method
    str ='a'
    input_put_nowait = q.put_nowait(str)
    output_get_nowait = q.get_nowait()
    assert input_put_nowait == None, "The unit test for method get_nowait of class Queue is failed"
    assert output_get_nowait == str, "The unit test for method get_nowait of class Queue is failed"
    # Method tearDown is called after any test


# Generated at 2022-06-26 08:41:33.603466
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    item = Future()
    future = queue.get(timeout=item)


# Generated at 2022-06-26 08:41:35.291422
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()


# Generated at 2022-06-26 08:41:45.616554
# Unit test for method put_nowait of class Queue

# Generated at 2022-06-26 08:41:48.191078
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    print(q.put_nowait(3))


# Generated at 2022-06-26 08:42:00.713933
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 0
    timeout = None
    q = Queue(maxsize=maxsize)
    future = q.put(0,timeout=timeout)
    # if put is succeed, future will set result
    assert future.result() == None
    assert q.qsize() == 1
    # if queue is full, put will raise QueueFull
    assert q.full() == True
    maxsize = 2
    timeout = None
    q = Queue(maxsize=maxsize)
    future = q.put(0,timeout=timeout)
    assert future.result() == None
    assert q.qsize() == 1
    assert q.full() == False
    future = q.put(1,timeout=timeout)
    assert future.result() == None
    assert q.qsize() == 2
    assert q.full() == True

# Generated at 2022-06-26 08:42:15.254586
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Get an instance of Queue, with maxsize = 0
    obj = Queue(maxsize=0)
    # Call method put_nowait with parameter: item

# Generated at 2022-06-26 08:42:20.096573
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    timeout_0 = None
    awaitable_0 = queue_0.get(timeout_0)


# Generated at 2022-06-26 08:42:28.464835
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize = 0)
    future = queue.put(item = 0, timeout = None)
    # can't catch QueueFull exception:
    # 1 QueueFull exception is handled by the put method
    # 2 the future object isn't returned to the caller until the future object is done
    # so QueueFull exception won't be raised
    queue_full = QueueFull()
    future_err = queue.put(item = 0, timeout = None, raise_exception = queue_full)
    return
    pass


# Generated at 2022-06-26 08:42:35.857835
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue_0 = Queue()
    # queue_0.put(item=0)
    # print(queue_0)
    # queue_1= queue_0.get_nowait()
    # print(queue_1)
    # print(queue_0)
    queue_0 = Queue()
    queue_0.put(item=0)
    print(queue_0)
    queue_1= queue_0.get_nowait()
    print(queue_1)
    print(queue_0)

if __name__ == "__main__":
    # print("Unit test for Queue")
    # test_case_0()
    test_Queue_get_nowait()

# Generated at 2022-06-26 08:42:46.773315
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = q.get()
    assert future is not None


# Generated at 2022-06-26 08:42:56.844704
# Unit test for method put of class Queue
def test_Queue_put():
    def init_instance_0():
        instance_0 = Queue()

    def init_instance_1():
        instance_1 = Queue(maxsize=42)

    @gen.coroutine
    def test_put_0():
        yield instance_0.put(item=6, timeout=6)

    @gen.coroutine
    def test_put_1():
        yield instance_1.put(item=6, timeout=6)

    def test_put_2():
        instance_0.put(item=6, timeout=6)

    def test_put_3():
        instance_1.put(item=6, timeout=6)

    def test_put_4():
        instance_0.put(item=6, timeout=6)


# Generated at 2022-06-26 08:42:59.432653
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1.0: maxsize = None
    try:
        test_case_0()
    except TypeError as e:
        pass


# Generated at 2022-06-26 08:43:12.997207
# Unit test for method put of class Queue
def test_Queue_put():
    """
    func = lambda arg1, arg2: arg1 * arg2
    # func: <class 'function'>
    # func.__name__: '<lambda>'
    # func(2, 3): 6
    expected = 6
    actual = func(2, 3)
    assert actual == expected
    """
    import datetime
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.concurrent import Future
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


# Generated at 2022-06-26 08:43:15.679087
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize = 0)
    queue.put(item = 1, timeout = None)


# Generated at 2022-06-26 08:43:24.161057
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Queue is at maximum size
    throw_Queue_get_nowait = QueueFull()
    Queue_get_nowait = Queue(maxsize=0)
    assert Queue_get_nowait.put_nowait(1) == None
    assert Queue_get_nowait.put_nowait(2) == None
    assert Queue_get_nowait.put_nowait(3) == None
    assert Queue_get_nowait.qsize() == 3
    assert Queue_get_nowait.get_nowait() == 1
    assert Queue_get_nowait.get_nowait() == 2
    assert Queue_get_nowait.get_nowait() == 3
    assert Queue_get_nowait.empty() == True


# Generated at 2022-06-26 08:43:29.761512
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(0)
    queue_0.get()
    try:
        queue_0.get()
    except QueueEmpty:
        print("QueueEmpty Exception handled")
    except TimeoutError:
        print("TimeoutError Exception handled")


# Generated at 2022-06-26 08:43:35.812421
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_empty_0 = QueueEmpty()
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-26 08:43:39.696956
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    queue_0 = Queue(maxsize=0)
    queue_0.qsize()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:43:42.559388
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
    except QueueEmpty:
        print('Queue is Empty!')



# Generated at 2022-06-26 08:43:58.049060
# Unit test for method get of class Queue
def test_Queue_get():
    # Asynchronous

    q = Queue()

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()  # Wait for producer to put all tasks.
        yield q.join()  # Wait for consumer to finish all tasks.

# Generated at 2022-06-26 08:44:03.972800
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    result = queue_0.get()
    # should raise some exception of type QueueEmpty on an empty queue
    assert result is None or result is False or isinstance(result, Exception) or isinstance(result, Future) or isinstance(result, Awaitable)


# Generated at 2022-06-26 08:44:05.997785
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()


# Generated at 2022-06-26 08:44:11.347728
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    # queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)


# Generated at 2022-06-26 08:44:13.498803
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    s = "test_Queue_put"
    q.put(s)
    return


# Generated at 2022-06-26 08:44:20.778365
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    print("maxsize of this queue is ",q.maxsize)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()
    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-26 08:44:29.613546
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """
    Get an item from the queue without blocking.

    Only get an item if one is immediately available. Otherwise
    raise the Empty exception.

    Returns
    -------
    object
        The object that got removed from the queue.

    Raises
    ------
    Empty
        If the queue is empty.
    """

    q = Queue()
    try:
        print(q.empty())
        a = q.get_nowait()
        print(a)
    except Exception as e:
        print(e)

    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    print(q.empty())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
   

# Generated at 2022-06-26 08:44:33.542801
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.empty()
    queue_0.full()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:44:41.719699
# Unit test for method get of class Queue
def test_Queue_get():
    loop = ioloop.IOLoop.current()

    def handle_result():
        pass

    @gen.coroutine
    def test_Func():
        queue_0 = Queue()
        queue_0.put_nowait(0)
        queue_0.put_nowait(1)
        queue_0.put_nowait(2)
        queue_0.put_nowait(3)
        queue_0.put_nowait(4)
        queue_0.task_done()
        yield queue_0.get()
        res=queue_0.get()
        assert not res is None, "Defect detected in Queue.get"
        if res==1 or res==2 or res==3 or res==4:
            handle_result()

# Generated at 2022-06-26 08:44:51.319934
# Unit test for method put of class Queue
def test_Queue_put():
    # test case 0
    queue_0 = Queue()
    future_0 = Future()
    _set_timeout(future_0, None)
    assert not future_0.done()
    future_0 = None
    # test case 1
    queue_1 = Queue()
    future_1 = Future()
    _set_timeout(future_1, None)
    assert not future_1.done()
    future_1 = None
    # test case 2
    queue_2 = Queue()
    future_2 = Future()
    _set_timeout(future_2, None)
    assert not future_2.done()
    future_2 = None
    # test case 3
    queue_3 = Queue()
    future_3 = Future()
    _set_timeout(future_3, None)
    assert not future

# Generated at 2022-06-26 08:45:11.448248
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()    # initializer

    # producer
    for i in range(10):
        queue_0.put_nowait(i)

    # consumer
    while not queue_0.empty():
        print(queue_0.get_nowait())


# Generated at 2022-06-26 08:45:23.606786
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put("hello")
    assert queue_0.qsize() == 1
    assert queue_0._unfinished_tasks == 1
    queue_0.put("world")
    assert queue_0.qsize() == 2
    assert queue_0._unfinished_tasks == 2
    queue_0.put("!")
    assert queue_0.qsize() == 3
    assert queue_0._unfinished_tasks == 3
    queue_0.put("world")
    assert queue_0.qsize() == 4
    assert queue_0._unfinished_tasks == 4
    queue_0.put("!")
    assert queue_0.qsize() == 5
    assert queue_0._unfinished_tasks == 5

    # Expecting queue is not full.


# Generated at 2022-06-26 08:45:30.566216
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Define a queue with a maxsize 0.
    queue_0 = Queue()
    # Put items into the queue using method put_nowait.
    queue_0_put_nowait_result_1 = queue_0.put_nowait(1)
    queue_0_put_nowait_result_2 = queue_0.put_nowait(2)
    queue_0_put_nowait_result_3 = queue_0.put_nowait(3)
    queue_0_put_nowait_result_4 = queue_0.put_nowait(4)
    queue_0_put_nowait_result_5 = queue_0.put_nowait(5)
    # Check if the items are put into the queue.
    assert queue_0.qsize() == 5


# Generated at 2022-06-26 08:45:32.432142
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass



# Generated at 2022-06-26 08:45:41.861936
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue() # q is a Queue object
    future = Future() # future is a Future object
    item = 1; timeout = 0.01
    # ???????????????????????????????????????????????????????????????????????????????
    q.put(item, timeout)
    assert isinstance(future, Future)
    assert future.result() is None
    # ???????????????????????????????????????????????????????????????????????????????
    q.put_nowait(item)
    assert isinstance(q, Queue)


# Generated at 2022-06-26 08:45:49.791123
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.gen import coroutine, sleep
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop

    @coroutine
    def get_nowait():
        queue_0 = Queue()
        ret = queue_0.get_nowait()
    IOLoop.current().run_sync(get_nowait)



# Generated at 2022-06-26 08:45:54.802300
# Unit test for method get of class Queue
def test_Queue_get():
    print("Unit test for Queue.get")
    queue_0 = Queue(5)
    queue_0.put(5)
    try:
        # assert(queue_0.get() == 5)
        print("queue_0.get() = ", queue_0.get().result())
    except:
        print("Unit test failed")
        print("Unit test for Queue.get failed")
    else:
        print("Unit test passed")
        print("Unit test for Queue.get passed")


# Generated at 2022-06-26 08:46:03.182271
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(maxsize=5)

    for item in [0,1,2,3,4]:
        queue_1.put_nowait(item)
        assert queue_1.qsize() == item+1, "qsize does not match"

    try:
        queue_1.put_nowait(5)
        assert False, "should raise QueueFull"
    except QueueFull:
        pass


# Generated at 2022-06-26 08:46:15.723270
# Unit test for method put of class Queue
def test_Queue_put():
    import unittest
    from tornado.testing import AsyncTestCase

    class TestQueue(AsyncTestCase):
        def test_put(self):
            queue_1 = Queue()
            future_1 = queue_1.put('abc')
            future_2 = queue_1.put('def')
            future_3 = queue_1.put('ghi')
            self.assertEqual(queue_1.qsize(), 3)
            future_4 = queue_1.put('jkl')
            self.assertEqual(queue_1.qsize(), 4)

    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-26 08:46:18.915353
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    future_0 = q.put('str_0');



# Generated at 2022-06-26 08:46:52.910037
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, ("queue_0.get_nowait() should throw QueueEmpty exception, but "
                       "it didn't")


# Generated at 2022-06-26 08:46:59.343986
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.put('test')
    assert queue_1.get_nowait() == 'test'
    queue_1.put('test')
    future = queue_1.get(1)
    if future.done():
        assert future.result() == 'test'


# Generated at 2022-06-26 08:47:04.659666
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(123);
    assert queue_0.qsize() == 1



# Generated at 2022-06-26 08:47:15.824315
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    # Test that Queue.get will not block when queue size is greater than 0
    queue.put_nowait(0)
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    queue.put_nowait(4)
    assert queue.get_nowait() == 0
    assert queue.get_nowait() == 1
    assert queue.get_nowait() == 2
    # Test that Queue.get will block when queue size is 0
    assert queue.empty()
    future = Future()
    queue._getters.append(future)
    assert not future.done()
    future.set_result(0)
    queue.__put_internal(3)
    assert not queue.empty()


# Generated at 2022-06-26 08:47:24.205361
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.put_nowait(0)
    queue_1.put_nowait(1)
    queue_1.put_nowait(2)
    t = queue_1.get()
    t = queue_1.get()
    t = queue_1.get()
    t = queue_1.get()
    return


# Generated at 2022-06-26 08:47:26.123151
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    q_item = "q_item"
    queue_0.put(q_item, 1.00000000)



# Generated at 2022-06-26 08:47:40.921794
# Unit test for method get of class Queue
def test_Queue_get():
    # Test case with predefined input
    queue_0 = Queue(maxsize=0)
    timeout_0 = None
    awaitable_0 = queue_0.get(timeout_0)
    future_0 = Future()
    try:
        try:
            future_0.set_result(queue_0.get_nowait())
        except QueueEmpty:
            future_0.set_exception(QueueEmpty)
            future_0.set_exception(gen.TimeoutError())
    finally:
        future_0.done()
        future_0.done()
        future_0.set_result(queue_0._get())
        func_0(future_0, timeout_0)
        future_0.set_exception(gen.TimeoutError())
    awaitable_0.done()


# Generated at 2022-06-26 08:47:42.814227
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_1 = Queue()
    queue_1.get()


# Generated at 2022-06-26 08:47:44.931536
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:47:49.275424
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    queue_1 = Queue()
    try:
        queue_1.put_nowait([1,2,3])
    except QueueFull as e:
        print(e)


# Generated at 2022-06-26 08:48:59.115752
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q_0 = Queue()
    test_val = "Test Value"
    q_0.put_nowait(test_val)
    if q_0.empty():
        raise Exception('Queue is empty after put_nowait')
    actual = q_0.get_nowait()
    if actual != test_val:
        raise Exception('Test Value not in Queue')


# Generated at 2022-06-26 08:49:08.569714
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import random
    from tornado import gen
    from tornado.ioloop import IOLoop

    async def test_case_1(queue_1):
        assert(queue_1.qsize() == 0)
        assert(queue_1.empty() == True)
        assert(queue_1.full() == False)
        queue_1.put_nowait(42)
        assert(queue_1.qsize() == 1)
        assert(queue_1.empty() == False)
        assert(queue_1.full() == False)
        queue_1.put_nowait(42)
        assert(queue_1.qsize() == 2)
        assert(queue_1.empty() == False)
        assert(queue_1.full() == True)


# Generated at 2022-06-26 08:49:15.011688
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.qsize()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:49:18.272579
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    error = QueueEmpty()
    try:
        queue = Queue()
        queue.get_nowait()
    except QueueEmpty as e:
        print("Get QueueEmpty exception")


# Generated at 2022-06-26 08:49:21.102454
# Unit test for method put of class Queue
def test_Queue_put():
    timeout = 1000
    queue_0 = Queue()
    a = queue_0.put(timeout)
    assert a



# Generated at 2022-06-26 08:49:33.255200
# Unit test for method get of class Queue
def test_Queue_get():
    queue_get_0 = Queue()
    queue_get_0.maxsize = 5
    tup_0 = queue_get_0._getters
    queue_get_1 = Queue()
    queue_get_1.maxsize = 7
    tup_1 = queue_get_1._getters
    queue_get_2 = Queue()
    queue_get_2.maxsize = 3
    tup_2 = queue_get_2._getters
    queue_get_3 = Queue()
    queue_get_3.maxsize = 1
    tup_3 = queue_get_3._getters
    queue_get_4 = Queue()
    queue_get_4.maxsize = 0
    tup_4 = queue_get_4._getters
    queue_get_5 = Queue

# Generated at 2022-06-26 08:49:35.670452
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:49:38.263277
# Unit test for method put of class Queue
def test_Queue_put():
    # test for public method Queue.put
    queue_0 = Queue()
    queue_0.put("hello")


# Generated at 2022-06-26 08:49:42.504845
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put('F#')
    assert future_0
    future_1 = queue_0.put('No')
    assert future_1


# Generated at 2022-06-26 08:49:43.450426
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass
