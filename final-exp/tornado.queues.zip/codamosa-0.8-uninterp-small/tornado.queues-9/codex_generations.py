

# Generated at 2022-06-26 08:41:12.949373
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    future = q.put(1)
    assert future == None


# Generated at 2022-06-26 08:41:20.991824
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    assert not queue_0.full(), "full when it is empty"
    queue_0.put_nowait(2)
    assert queue_0.full(), "Not full when i should be full"
    queue_1 = Queue(maxsize=0)
    queue_1.put_nowait(1)


# Generated at 2022-06-26 08:41:23.223214
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    print(q.put(10))


# Generated at 2022-06-26 08:41:31.785337
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert queue_0.maxsize == 0
    assert queue_0.full() == False
    assert queue_0.empty() == True
    queue_0.put_nowait(2)
    queue_0.put_nowait(4)
    queue_0.put_nowait(6)
    assert queue_0._queue == deque([2,4,6])
    assert queue_0.qsize() == 3
    assert queue_0.full() == False
    assert queue_0.empty() == False


# Generated at 2022-06-26 08:41:39.059321
# Unit test for method get of class Queue
def test_Queue_get():
    print("Test #0")
    queue_0 = Queue()
    timeout = None
    future = queue_0.get(timeout)
    print("Test #1")
    queue_1 = Queue()
    timeout = None
    future = queue_1.get(timeout)


# Generated at 2022-06-26 08:41:48.918756
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    def loop_0():
        future_1 = queue_0.get()
        print(str(future_1))

        # The parent function returns a Future type
        return future_1

    loop = ioloop.IOLoop.current()
    future = loop.run_sync(loop_0)
    print(str(future))
    print(str(type(future)))

    # Put some items into the queue
    for i in range(3):
        queue_0.put_nowait(i)



# Generated at 2022-06-26 08:41:56.194940
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(35)
    queue_0.put_nowait(28.0)
    queue_0.put_nowait(0)
    queue_0.put_nowait('r')
    queue_0.put_nowait(28.0)
    queue_0.put_nowait(0)
    queue_0.put_nowait(0)
    queue_0.put_nowait(35)
    queue_0.put_nowait('0')
    queue_0.put_nowait(35)
    queue_0.put_nowait(35)
    queue_0.put_nowait('v')
    queue_0.put_nowait(0)
    queue_0.put_nowait(35)
    queue_0

# Generated at 2022-06-26 08:42:02.286689
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except Exception as e:
        if not isinstance(e, QueueEmpty):
            raise
    else:
        raise Exception("Expected Exception")


# Generated at 2022-06-26 08:42:11.582088
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.put("foo")
    queue_0.put("bar")
    queue_0.get()
    queue_0.get()
    #queue_0.get("delta")
    queue_1 = Queue()
    #queue_1.put("delta")
    queue_1.put("bar")
    queue_1.get()
    queue_1.get()



# Generated at 2022-06-26 08:42:15.720915
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.empty() == True
    q.put(1)
    assert q.empty() == False
    assert q.qsize() == 1
    get_value = q.get()
    assert type(get_value) == Future


# Generated at 2022-06-26 08:42:40.490424
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado.queues import Queue

    # queue m_Queue
    m_Queue: Queue = Queue()

    # prep for use within the m_Queue.put_nowait(item)
    # String item
    item: str = 'tacos'

    # try-catch-finally block (in Python we can use
    # try-except-else-finally instead)
    try:
        try:
            # call function queue.put_nowait(item)
            m_Queue.put_nowait(item)
        except QueueEmpty:
            # QueueEmpty error
            pass
    # if no QueueEmpty error occurs,
    # then execute this code
    finally:
        # call function queue.task_done()
        m_Queue.task_done()


# Generated at 2022-06-26 08:42:45.385506
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Preconditions
    queue_0 = Queue()
    queue_1 = Queue()
    queue_0.get_nowait()
    queue_1.get_nowait()
test_case_0()

# Generated at 2022-06-26 08:42:47.578129
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    for i in range(5):
        q.put(i)
    assert q.qsize() == 5


# Generated at 2022-06-26 08:42:50.632259
# Unit test for method get of class Queue
def test_Queue_get():
    # test normal case
    queue_0 = Queue()
    queue_0.put(10)
    queue_0.get()

    # test boundary case
    queue_1 = Queue()
    queue_1.get()


# Generated at 2022-06-26 08:43:00.559330
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Queue_instance_0, Queue_instance_1 and Queue_instance_2 are needed for the template.
    # Rename these names if they are not suitable for your case.
    queue_instance_0 = Queue()
    queue_instance_1 = Queue()
    queue_instance_2 = Queue()

    # Template code below
    # Specification
    # def get_nowait(self) -> _T:
    #     """Remove and return an item from the queue without blocking.
    #
    #     Return an item if one is immediately available, else raise
    #     `QueueEmpty`.
    #     """
    #     self._consume_expired()
    #     if self._putters:
    #         assert self.full(), "queue not full, why are putters waiting?"
    #         item, put

# Generated at 2022-06-26 08:43:04.179603
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(0)
    assert q.qsize() == 1



# Generated at 2022-06-26 08:43:06.975013
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(0)


# Generated at 2022-06-26 08:43:10.835741
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    for i in range(5):
        q.put(i)
    assert q.qsize() == 5

    for i in range(5):
        assert q.get() == i


# Generated at 2022-06-26 08:43:22.107939
# Unit test for method put of class Queue
def test_Queue_put():
    async def test_case_1():
        q = Queue(maxsize=2)
        list_0 =[]
        def on_future_done(future):
            list_0.append(future.result())

        f1 = q.put(1)
        f1.add_done_callback(on_future_done)
        assert len(list_0) == 0
        assert q.qsize() == 1
        assert f1.done() == True
        assert f1.result() == None

        f2 = q.put(2)
        f2.add_done_callback(on_future_done)
        assert len(list_0) == 0
        assert q.qsize() == 2
        assert f2.done() == True
        assert f2.result() == None


# Generated at 2022-06-26 08:43:29.798164
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    assert queue_0.qsize() == 1
    queue_0.put_nowait(2)
    assert queue_0.qsize() == 2
    queue_0.put_nowait(3)
    assert queue_0.qsize() == 3


# Generated at 2022-06-26 08:43:55.031199
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test for maxsize = 0
    print("Starting test for maxsize = 0")
    success = True

    # Test for maxsize = 0
    """Test case for maxsize = 0"""
    queue_0 = Queue(0)

    # Test for maxsize = 0
    """Test case for maxsize = 0"""
    queue_1 = Queue(0)
    assert queue_1.put_nowait(1)==None, "put_nowait(1) for maxsize = 0 does not work"

    # Test for maxsize = 0
    """Test case for maxsize = 0"""
    queue_2 = Queue(0)
    assert queue_2.put_nowait(1)==None, "put_nowait(1) for maxsize = 0 does not work"

# Generated at 2022-06-26 08:44:01.624493
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a new Queue object
    queue = Queue()
    # Add some items to the queue
    for index in range(10):
        queue.put(index)
    # Get some items from the queue
    item = queue.get()
    print(item)


# Generated at 2022-06-26 08:44:04.925785
# Unit test for method get of class Queue
def test_Queue_get():
    def get_test():
        queue_1 = Queue()
        queue_1.get()
    queue_1 = Queue()
    if isinstance(queue_1, Queue):
        get_test()


# Generated at 2022-06-26 08:44:08.767069
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(3)



# Generated at 2022-06-26 08:44:19.407338
# Unit test for method get of class Queue
def test_Queue_get():
    # Test case for basic functionalities
    queue_0 = Queue()
    queue_0.put_nowait(2)
    assert queue_0.get_nowait() == 2 
    queue_0.put_nowait(4)
    assert queue_0.get_nowait() == 4
    # Test case for the case when the queue is empty
    queue_0 = Queue()
    # Test case for the case when the queue is full
    queue_1 = Queue(3)
    queue_1.put_nowait(2)
    queue_1.put_nowait(3)
    queue_1.put_nowait(5)
    assert queue_1.get_nowait() == 2
    assert queue_1.get_nowait() == 3
    assert queue_1.get_nowait() == 5

# Generated at 2022-06-26 08:44:26.633782
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(11)
    queue_0.put_nowait(12)
    queue_0.put_nowait(13)
    queue_0.put_nowait(14)
    assert queue_0.qsize() == 4
    queue_0.get_nowait()
    assert queue_0.qsize() == 3
    print("test Queue method put_nowait passed")


# Generated at 2022-06-26 08:44:34.482338
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest.mock as mock
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0._maxsize = 10
    queue_0.qsize = mock.Mock(side_effect=QueueEmpty)
    queue_0.put_nowait(1)



# Generated at 2022-06-26 08:44:39.845587
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    def _callback(future):
        assert future.result() == None

    future = q.put(1)
    future.add_done_callback(_callback)


# Generated at 2022-06-26 08:44:50.152994
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Instantiate a queue of max size None
    queue_0 = Queue(None)
    # Put an item into the queue
    queue_0.put_nowait(None)
    # Check if the queue is not full
    assert (queue_0.full() == False)
    # Check size of the queue
    assert (queue_0.qsize() == 1)
    # Put an item into the queue
    queue_0.put_nowait(None)
    # Check if the queue is not full
    assert (queue_0.full() == False)
    # Check size of the queue
    assert (queue_0.qsize() == 2)
    # Put an item into the queue
    queue_0.put_nowait(None)
    # Check if the queue is not full

# Generated at 2022-06-26 08:44:54.058843
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:45:08.148761
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue()
    queue_1.get()
    queue_1.get(timeout=0.5)


# Generated at 2022-06-26 08:45:09.732011
# Unit test for method put of class Queue
def test_Queue_put():
    pass



# Generated at 2022-06-26 08:45:18.359685
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(1)

    # The Queue has not reached the maxsize, so we can put an item into the queue.
    queue_1.put_nowait(1)

    # The Queue reached the maxsize, so we cannot put another item into the queue.
    assert_raises(QueueFull, queue_1.put_nowait, 1)


# Generated at 2022-06-26 08:45:20.928504
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    # Test exceptions
    try:
        queue_0.get_nowait()
    except:
        pass


# Generated at 2022-06-26 08:45:33.505202
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = Future()
    future_0.set_result(None)
    future_1 = Future()
    future_1.set_result(None)
    future_2 = Future()
    future_2.set_result(None)
    future_3 = Future()
    future_3.set_result(None)
    future_4 = Future()
    future_4.set_result(None)
    queue_0.put_nowait(1)
    queue_0.put_nowait(3)
    queue_0.put(1, None)
    queue_0.put(3, None)
    queue_0.get_nowait()
    queue_0.get_nowait()
    queue_0.task_done()
    queue_0.task_done

# Generated at 2022-06-26 08:45:37.703343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty as e:
        assert True
    return


# Generated at 2022-06-26 08:45:42.666061
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(maxsize=2)
    assert queue_1.empty() is True
    queue_1.put_nowait(1)
    assert queue_1._queue[0] == 1
    assert queue_1.empty() is False
    assert queue_1.qsize() == 1



# Generated at 2022-06-26 08:45:45.683308
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:45:51.752205
# Unit test for method get of class Queue
def test_Queue_get():
    # Initialization
    queue_0 = Queue()
    # Invoke method
    awaitable = queue_0.get()
    # Assertions
    # Check if the returned value is correct
    if not (awaitable==None):
        raise Exception("Returned value is incorrect")



# Generated at 2022-06-26 08:45:56.764844
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue(maxsize=2)
    queue_1.put(1)
    queue_1.put(2)
    assert(queue_1.qsize() == 2)


# Generated at 2022-06-26 08:46:11.621783
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(10)
    print(queue_0.qsize())


# Generated at 2022-06-26 08:46:14.076664
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:46:28.103388
# Unit test for method put of class Queue
def test_Queue_put():
    try:
        # Initialization
        # --------------------------------------------------
        q = Queue(maxsize=2)

        # Execute function
        # --------------------------------------------------
        future = Future()
        def on_timeout():
            if not future.done():
                future.set_exception(gen.TimeoutError())
        io_loop = ioloop.IOLoop.current()
        timeout_handle = io_loop.add_timeout(future, on_timeout)
        future.add_done_callback(lambda _: io_loop.remove_timeout(timeout_handle))
        future = q.put(1, future)
        assert future.set_result(None) == None
        return future

    except Exception as e:
        # Output expected TimeoutErrors.
        if e is not None:
            assert e is gen.TimeoutError()


# Generated at 2022-06-26 08:46:33.103254
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    def wrapper():
        q.put_nowait(0)
        q.put_nowait(1)
        q.put_nowait(2)
    wrapper()


# Generated at 2022-06-26 08:46:38.257581
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("Starting a test case of test_Queue_put_nowait")
    queue_1 = Queue()
    queue_1.put_nowait(1)
    assert queue_1._queue[0] == 1
    print("Finished a test case of test_Queue_put_nowait")


# Generated at 2022-06-26 08:46:41.849778
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(5)


# Generated at 2022-06-26 08:46:47.868026
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    item = 123
    queue_0.put_nowait(item)
    # Assert here.
    assert(queue_0._queue[0] == item)


# Generated at 2022-06-26 08:46:55.486272
# Unit test for method get of class Queue
def test_Queue_get():
    _TEST_QUEUE = Queue()
    # Test get, 20 times
    for _ in range(20):
        # Test if the method raises exceptions
        try:
            bool_0 = _TEST_QUEUE.get()
        except Exception as e:
            print(e)


# Generated at 2022-06-26 08:47:00.196601
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)


# Generated at 2022-06-26 08:47:09.117040
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    await(queue_0.put(1))
    await(queue_0.put(2))
    await(queue_0.put(3))
    try:
        await(queue_0.put(4))
    except QueueFull as e:
        print(e)


# Generated at 2022-06-26 08:47:28.196187
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    async def consumer():
        async for item in queue_0:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                queue_0.task_done()

    async def producer():
        for item in range(5):
            await queue_0.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await queue_0.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOL

# Generated at 2022-06-26 08:47:31.881297
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue(maxsize=2)
    queue_1.put(1)
    queue_1.put(2)
    queue_1.put(3)
    queue_1.put(4)


# Generated at 2022-06-26 08:47:40.868961
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future_0 = queue_0.put(42)
    # print(future_0)
    # print(future_0.done())
    future_0.add_done_callback(lambda _: print(_.result()))
    # future_0.add_done_callback(lambda _: print(_))
    print(future_0.result())


# Generated at 2022-06-26 08:47:48.016410
# Unit test for method put of class Queue
def test_Queue_put():
    # Case-0
    queue_0 = Queue()
    # Case-1
    queue_1 = Queue(maxsize=0)
    
    # Case-2
    queue_2 = Queue(maxsize=1)

    # Case-3
    queue_3 = Queue(maxsize=2)

    # Case-4
    queue_4 = Queue(maxsize=3)


# Generated at 2022-06-26 08:47:55.709238
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    if queue_0.empty():
        queue_0.put_nowait("nn")
        queue_0.put_nowait("bb")
        queue_0.put_nowait("cc")
        queue_0.put_nowait("dd")
        queue_0.put_nowait("ee")
        queue_0.put_nowait("ff")
        print(queue_0)
        print(queue_0.get_nowait())
        print(queue_0.get_nowait())
        print(queue_0.get_nowait())
        queue_0.task_done()
        print(queue_0)
        print(queue_0.get_nowait())
        print(queue_0.get_nowait())
        print(queue_0.get_nowait())

# Generated at 2022-06-26 08:47:58.787577
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = Future()
    try:
        future.set_result(q.get_nowait())
    except QueueEmpty:
        pass
    except:
        future = None
        print("Unexpected error:", sys.exc_info()[0])
    finally:
        return future


# Generated at 2022-06-26 08:48:02.864021
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    item = 1;
    timeout = None;
    ret = q.put(item, timeout)
    print(repr(ret))
    assert ret.done() == False



# Generated at 2022-06-26 08:48:05.406237
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.qsize()
    queue.empty()
    queue.full()
    queue.get()


# Generated at 2022-06-26 08:48:12.871418
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    # Create a Future, which will be passed to the coroutine of Queue.put as the second parameter
    future_put_1 = Future()
    # Call method get of class Queue and store the returned result
    result = queue_0.get()
    # Get the first element of the queue
    item = queue_0.get_nowait()
    # Return Future of Queue.put
    return future_put_1



# Generated at 2022-06-26 08:48:15.464942
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.qsize()


# Generated at 2022-06-26 08:48:39.734235
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future = queue_0.get()



# Generated at 2022-06-26 08:48:44.472427
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert isinstance(e, QueueEmpty)
    else:
        assert False, "QueueEmpty exception not raised"



# Generated at 2022-06-26 08:48:57.090273
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue instance
    queue_0 = Queue()

    # Call method put of queue_0

    # Check queue_0._getters
    if (len(queue_0._getters) != 0):
        print("The value of queue_0._getters after executing put() is %s, which does not equal the expected result ()" % queue_0._getters)
        return False
    else:
        print("The value of queue_0._getters after executing put() equals the expected result ()")

    # Check queue_0._putters
    if (len(queue_0._putters) != 0):
        print("The value of queue_0._putters after executing put() is %s, which does not equal the expected result ()" % queue_0._putters)
        return False

# Generated at 2022-06-26 08:48:59.859445
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(5)
    for i in range(5):
        q.put_nowait(i)


# Generated at 2022-06-26 08:49:03.740768
# Unit test for method put of class Queue
def test_Queue_put():
    future_0 = Future()
    queue_0 = Queue()
    try:
        queue_0.put_nowait(1)
    except QueueFull:
        future_0.set_result(None)
    else:
        future_0.set_result(None)



# Generated at 2022-06-26 08:49:07.525225
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Create instance of class Queue(using constructor)
    queue_0 = Queue()
    # Try to put an element (string) into queue
    queue_0.put_nowait('Instance_0')
    # Verify if the queue contains any elements
    assert queue_0.empty() == False


# Generated at 2022-06-26 08:49:13.490734
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import queue
    queue0 = queue.Queue()
    print(queue0.qsize())
    queue1 = queue.Queue()
    queue2 = Queue()


# Generated at 2022-06-26 08:49:17.816376
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    # case 1: no timeout
    future = queue_0.put(1)
    future.result()
    # case 2: timeout
    future = queue_0.put(2, timeout = 1)
    future.result()


# Generated at 2022-06-26 08:49:20.844055
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future = queue_0.put(1)
    # queue_0.put(1)
    return 1


# Generated at 2022-06-26 08:49:25.262000
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    if future_0 != None:
        raise RuntimeError("get function returns incorrect results")


# Generated at 2022-06-26 08:50:11.299082
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(1)
    queue_1.get_nowait()

# Unit tests for method put_nowait of class Queue

# Generated at 2022-06-26 08:50:19.248752
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    # Create a Queue with maxsize = 3
    test_queue = Queue(maxsize=3)
    assert test_queue.maxsize == 3
    assert test_queue.qsize() == 0
    test_queue.put_nowait("e1")
    assert test_queue.qsize() == 1
    test_queue.put_nowait("e2")
    assert test_queue.qsize() == 2
    test_queue.put_nowait("e3")
    assert test_queue.qsize() == 3
    # Case 1: maxsize < qsize()
    try:
        test_queue.put_nowait("e4")
    except QueueFull:
        assert test_queue.qsize() == 3
        assert test_queue.full() == True
        assert test_queue.empty() == False
   

# Generated at 2022-06-26 08:50:23.061958
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    queue_0.put('str')
    assert queue_0.get_nowait() == 'str'
    queue_0.put(1)
    assert queue_0.get_nowait() == 1
    queue_0.put(1.0)
    assert queue_0.get_nowait() == 1.0
    queue_0.put(queue_0)
    assert queue_0.get_nowait() == queue_0


# Generated at 2022-06-26 08:50:26.791444
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    try:
        queue_0.get()
    except Exception as e:
        print(e)
        print("test_Queue_get succeeded")



# Generated at 2022-06-26 08:50:34.314311
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(3)
    queue_0.put_nowait("1")
    print("Queue )(0 after put_nowait (1): ",queue_0)
    tasks = [queue_0.put("1")]
    gen.multi(tasks)
    tasks[0].wait()
    print("Queue )(0 after put (1): ",queue_0)


# Generated at 2022-06-26 08:50:36.443777
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait("_item_0")
    except QueueFull:
        queue_0.put_nowait("_item_0")


# Generated at 2022-06-26 08:50:38.068802
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    timeout = None
    queue_0.put(None, timeout)


# Generated at 2022-06-26 08:50:44.062175
# Unit test for method get of class Queue
def test_Queue_get():
    # Python 3.5.3
    queue_a = Queue()

    # Python 3.5.3
    #queue_a.get()
    await queue_a.get()

    # Python 3.5.3
    #queue_a.get(timeout=None)
    await queue_a.get(timeout=None)

    # Python 3.5.3
    timeout_0 = None
    #queue_a.get(timeout=timeout_0)
    await queue_a.get(timeout=timeout_0)
