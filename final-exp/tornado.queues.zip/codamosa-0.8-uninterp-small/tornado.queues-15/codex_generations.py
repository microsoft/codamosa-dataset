

# Generated at 2022-06-26 08:41:07.121415
# Unit test for method get of class Queue
def test_Queue_get():

    q = Queue()

    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

    assert q.maxsize == 0

    timeout = datetime.timedelta(seconds=5)

    f = q.get(timeout)
    assert isinstance(f, Future) is True

    f = q.get_nowait()
    assert isinstance(f, Future) is True



# Generated at 2022-06-26 08:41:17.741888
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put(datetime.datetime(datetime.datetime.MINYEAR, 1, 1, 1, 1, 1, 1))
        assert False
    except ValueError:
        assert True
    except:
        assert False

    try:
        lifo_queue_0.put(datetime.datetime.now())
        assert False
    except ValueError:
        assert True
    except:
        assert False



# Generated at 2022-06-26 08:41:23.875156
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(0)
    queue_0.put_nowait(None)
    queue_1 = Queue(0)
    queue_1.put_nowait(None)



# Generated at 2022-06-26 08:41:33.162021
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    item = -1
    # Test for Exception raised
    try:
        lifo_queue_0.put_nowait(item)
    except Exception:
        raise AssertionError("Unexpected Exception")
    # Test for no Exception raised
    try:
        lifo_queue_0.put_nowait(item)
    except Exception:
        raise AssertionError("Unexpected Exception")
    # Test for Exception raised
    try:
        lifo_queue_0.put_nowait(item)
    except Exception:
        raise AssertionError("Unexpected Exception")


# Generated at 2022-06-26 08:41:35.216334
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = Future()
    res = q.put(f)
    assert res is None


# Generated at 2022-06-26 08:41:45.113056
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Push 3 items into the queue
    queue = Queue()

    # Push 3 items into the queue
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)

    # Check the results
    assert queue.qsize() == 3
    assert queue._unfinished_tasks == 3
    assert queue._finished.is_set() == False
    assert queue._getters == collections.deque([])
    assert queue._putters == collections.deque([])
    assert len(queue._queue) == 3
    assert queue._queue[0] == 1
    assert queue._queue[1] == 2
    assert queue._queue[2] == 3


# Generated at 2022-06-26 08:41:57.952170
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # qsize() should return 0 when queue is empty
    lifo_queue = LifoQueue()
    assert lifo_queue.qsize() == 0
    # get_nowait() should raise QueueEmpty when queue is empty
    try:
        lifo_queue.get_nowait()
    except QueueEmpty:
        assert True
    # qsize() should return 1 after put_nowait()
    lifo_queue = LifoQueue()
    lifo_queue.put_nowait(10)
    assert lifo_queue.qsize() == 1
    # get_nowait() should return the item put in by put_nowait()
    lifo_queue = LifoQueue()
    lifo_queue.put_nowait(10)
    assert lifo_queue.get_nowait() == 10



# Generated at 2022-06-26 08:42:10.813463
# Unit test for method put of class Queue
def test_Queue_put():
    async def asyncTask_put(item):
        await lifo_queue_0.put(item)
        print(item)
    
    async def asyncTask_get():
        print(await lifo_queue_0.get())

    lifo_queue_0 = Queue()
    test_case_0()
    ioloop.IOLoop.current().run_sync(lambda: asyncTask_put(1))
    ioloop.IOLoop.current().run_sync(lambda: asyncTask_put(2))
    ioloop.IOLoop.current().run_sync(lambda: asyncTask_put(3))
    ioloop.IOLoop.current().run_sync(lambda: asyncTask_get())
    ioloop.IOLoop.current().run_sync(lambda: asyncTask_get())
   

# Generated at 2022-06-26 08:42:15.575151
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert(q.get_nowait() == 1)
    assert(q.get_nowait() == 2)
    assert(q.get_nowait() == 3)



# Generated at 2022-06-26 08:42:29.337601
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    # Testing with timeout
    # Tested: 1
    # Timeout: 0
    # Tested with timeout
    # Tested: 2
    # Timeout: 1
    # Tested with timeout
    # Tested: 3
    # Timeout: 2
    # Tested with timeout
    # Tested: 4
    # Timeout: 3

    test_timeout_list_0 = [0, 1, 2, 3]
    for i in range(4):
        # Tested: 1
        queue_0.put(1, timeout=test_timeout_list_0[i])
        # Tested: 1, 2
        queue_0.put(2, timeout=test_timeout_list_0[i])
        # Tested: 1, 2, 3

# Generated at 2022-06-26 08:42:37.902588
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False



# Generated at 2022-06-26 08:42:40.561487
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.get()
    queue.get_nowait()
    queue.task_done()
    queue.join()
# End of test for method get of class Queue


# Generated at 2022-06-26 08:42:44.259825
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-26 08:42:57.822866
# Unit test for method put of class Queue
def test_Queue_put():
    # Define parameters for test case 0
    q0 = Queue(maxsize=2)

    # Define parameters for test case 1
    q1 = Queue(maxsize=2)

    # Define parameters for test case 2
    q2 = Queue(maxsize=2)

    # Define parameters for test case 3
    q3 = Queue(maxsize=2)

    # Define parameters for test case 4
    q4 = Queue(maxsize=2)

    # Define parameters for test case 5
    q5 = Queue(maxsize=2)


    # Call function, check returned value(s) and/or side effects
    timeout_0 = 0.1
    future_0 = q0.put("item_0", timeout=timeout_0)
    assert isinstance(future_0, Future)
   

# Generated at 2022-06-26 08:43:07.523896
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)
    print(queue_0.qsize())
    queue_0.put(2)
    print(queue_0.qsize())
    queue_0.get_nowait()
    print(queue_0.qsize())
    queue_0.put(3)
    print(queue_0.qsize())



# Generated at 2022-06-26 08:43:17.374110
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # test_case_0, 向空队列加入一个元素
    # 预期结果：插入成功
    _q = Queue()
    _q.put_nowait(1)
    assert 1 == len(_q._queue)
    assert _q.qsize() == 1

    # test_case_1, 向满队列加入一个元素
    # 预期结果：插入失败，QueueFull异常抛出
    _q = Queue(maxsize=1)
    _q.put_nowait(1)
   

# Generated at 2022-06-26 08:43:18.750580
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass


# Generated at 2022-06-26 08:43:22.745497
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put("abc")
    assert q.get_nowait() == "abc"


# Generated at 2022-06-26 08:43:27.759028
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=0)
    item = 1
    assert queue.empty() is True
    assert queue.full() is False
    queue.put_nowait(item)


# Generated at 2022-06-26 08:43:32.466752
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Constructing the object
    queue0 = Queue()

    # Invoking method put_nowait of object 'queue0'
    queue0.put_nowait(2)

    # Invoking method put_nowait of object 'queue0'
    queue0.put_nowait(2)

    # Invoking method put_nowait of object 'queue0'
    queue0.put_nowait(2)


# Generated at 2022-06-26 08:43:42.182779
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    lifo_queue_0.put_nowait(1)
    assert 1 == lifo_queue_0.qsize()


# Generated at 2022-06-26 08:43:43.525649
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()



# Generated at 2022-06-26 08:43:49.146596
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)

    # Expect q._queue = collections.deque([1])
    assert q._queue == collections.deque([1])


# Generated at 2022-06-26 08:43:53.398843
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # Test get_nowait when queue is empty
    try:
        q.get_nowait()
        raise Exception("Expected QueueEmpty")
    except QueueEmpty:
        pass
    # Test get_nowait when queue is not empty
    q.put_nowait(2)
    assert(q.get_nowait() == 2)


# Generated at 2022-06-26 08:43:56.844822
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty as e:
        pass


# Generated at 2022-06-26 08:44:08.114386
# Unit test for method put of class Queue
def test_Queue_put():
    # LifoQueue
    lifo_queue_0 = LifoQueue()
    future_0 = lifo_queue_0.put(1)
    future_1 = lifo_queue_0.put(2)
    future_1 = lifo_queue_0.put(3)

    # Queue
    queue_0 = Queue()
    future_2 = queue_0.put(1)
    future_3 = queue_0.put(2)
    future_4 = queue_0.put(3)
    future_5 = queue_0.put(4)
    future_6 = queue_0.put(5)

    # LiftingQueue
    lifo_queue_1 = LiftingQueue()
    future_7 = lifo_queue_1.put(1)
    future_8 = lifo_queue

# Generated at 2022-06-26 08:44:16.422625
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    #Test for empty queue
    queue_0 = Queue()
    try:
        retval = queue_0.get_nowait()
    except QueueEmpty:
        print("Queue is empty")
        
    #Test for non empty queue
    queue_0.put("A")
    retval_0 = queue_0.get_nowait()
    assert "A" == retval_0, "Expected: A - Actual: {}".format(retval_0)
    

# Generated at 2022-06-26 08:44:18.737103
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()



# Generated at 2022-06-26 08:44:23.763294
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        q = Queue()
        q.put_nowait(1)
        print(q.qsize(), q.empty(), q.full())
    except QueueFull as e:
        print(e)



# Generated at 2022-06-26 08:44:28.032513
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    result = q.get()
    assert isinstance(result, Future)

    q = Queue()
    result = q.get(timeout=0.01)
    assert isinstance(result, Future)

    q = Queue()
    result = q.get(timeout=datetime.timedelta(seconds=0.01))
    assert isinstance(result, Future)



# Generated at 2022-06-26 08:44:41.504464
# Unit test for method get of class Queue
def test_Queue_get():
   # Initializing maxsize to zero
   q = Queue() 
   # Putting the element in the queue 
   put1 = q.put(5) 
   # Assigning result of QueueEmpty exception
   try:
       get1 = q.get_nowait() 
   except QueueEmpty as ex:
       assert ex.args[0] == 'Queue is empty'
   # Assigning result of QueueEmpty exception
   try:
       get2 = q.get(timeout=5) 
   except QueueEmpty as ex:
       assert ex.args[0] == 'Queue is empty'
   # Assigning result of QueueEmpty exception
   try:
       get3 = q.get(timeout=datetime.timedelta(seconds=5)) 
   except QueueEmpty as ex:
       assert ex.args[0]

# Generated at 2022-06-26 08:44:43.717300
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.get_nowait()


# Generated at 2022-06-26 08:44:51.367106
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:45:01.940698
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    class_name_0 = "Queue"
    attribute_name_0 = "_getters"
    attribute_name_1 = "qsize"
    expected_result_0 = False
    expected_result_1 = True
    expected_result_2 = ()

    queue_0._init()
    attribute_value_0 = queue_0.__getattribute__(attribute_name_0)
    attribute_value_1 = queue_0.__getattribute__(attribute_name_1)
    if attribute_value_0 != expected_result_2:
        raise AssertionError("Expected %s, got %s" % (expected_result_2, attribute_value_0))

# Generated at 2022-06-26 08:45:06.820378
# Unit test for method get of class Queue
def test_Queue_get():

    # Construct an object of class Queue
    queue_0 = Queue()

    # using method get with args (timeout=0.0) of class Queue
    future = queue_0.get(timeout=0.0)
    read = future.result()

    # Check type of read == "tornado.concurrent.Future"
    if read:
        return True
    else:
        return False


# Generated at 2022-06-26 08:45:10.619026
# Unit test for method put of class Queue
def test_Queue_put():
    # Create an instance of class Queue
    queue = Queue()

    # Check the put method
    queue.put(9)
    assert queue.qsize() == 1



# Generated at 2022-06-26 08:45:13.270983
# Unit test for method get of class Queue
def test_Queue_get():
    io_loop = ioloop.IOLoop.current()
    

# Generated at 2022-06-26 08:45:19.414636
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Typical usage
    lifo_queue_0 = LifoQueue()
    lifo_queue_0.put_nowait(5)
    # Stop at this line, then adjust the code.
    print("Reached the end of test_Queue_put_nowait")


# Generated at 2022-06-26 08:45:27.975252
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put_nowait("test_value_0")
        print("Test Case 0: PASS: test_Queue_put_nowait")
    except Exception as inst:
        print("Test Case 0: FAIL")
        print("Unexpected Exception:", inst)



# Generated at 2022-06-26 08:45:35.731990
# Unit test for method put of class Queue
def test_Queue_put():
    lifo_queue_0 = LifoQueue()
    try:
        lifo_queue_0.put(None, 0)
    except QueueFull as e:
        assert isinstance(e, QueueFull)
    else:
        raise Exception("Unexpected exception")
    test_Queue_put_0()
    try:
        lifo_queue_0.put(None)
    except QueueFull as e:
        assert isinstance(e, QueueFull)
    else:
        raise Exception("Unexpected exception")
    try:
        lifo_queue_0.put(None, 0.0)
    except QueueFull as e:
        assert isinstance(e, QueueFull)
    else:
        raise Exception("Unexpected exception")
    test_Queue_put_1()



# Generated at 2022-06-26 08:45:42.705092
# Unit test for method put of class Queue
def test_Queue_put():
    q0 = Queue()
    q0.put(1)
    assert q0.qsize() == 1



# Generated at 2022-06-26 08:45:54.316931
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    # Test 1
    q = Queue(maxsize=0)
    def f():
        return q.get_nowait()
    def f1():
        print("put item")
        q.put_nowait(1)
    f2 = tornado.concurrent.Future()
    f2.add_done_callback(f1)
    f2.set_result(None)

    io_loop_0 = tornado.ioloop.IOLoop()
    io_loop_0.add_callback(f)

    io_loop_0.start()
    io_loop_0.close()

    # Test 2
    q = Queue(maxsize=0)
    def f():
        return q.get_nowait()
    def f1():
        print("put item")
        q.put_nowait(1)

# Generated at 2022-06-26 08:46:01.565666
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait("6716")
    queue_0.put_nowait("q3p")
    queue_0.put_nowait("-2")
    queue_0.put_nowait("5")
    queue_0.put_nowait("0")


# Generated at 2022-06-26 08:46:07.408403
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize_0 = 0

    # Test case 0
    q_0 = Queue(maxsize=maxsize_0)

    # Test case 1
    q_1 = Queue(maxsize=maxsize_0)

    # Test case 2
    q_2 = Queue(maxsize=maxsize_0)

    # Test case 3
    q_3 = Queue(maxsize=maxsize_0)

    # Test case 4
    q_4 = Queue(maxsize=maxsize_0)

    # Test case 5
    q_5 = Queue(maxsize=maxsize_0)

    # Test case 6
    q_6 = Queue(maxsize=maxsize_0)

    # Test case 7
    q_7 = Queue(maxsize=maxsize_0)

    # Test case 8
   

# Generated at 2022-06-26 08:46:17.908140
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    #ut_Queue_get.test_case_0() #None
    #ut_Queue_get.test_case_1() #None
    #ut_Queue_get.test_case_2() #None
    #ut_Queue_get.test_case_3() #None
    #ut_Queue_get.test_case_4() #None
    #ut_Queue_get.test_case_5() #None
    #ut_Queue_get.test_case_6() #None
    #ut_Queue_get.test_case_7() #None
    #ut_Queue_get.test_case_8() #None
    #ut_Queue_get.test_case_9() #None
    #ut_Queue_get.test_case_10() #None
    #ut

# Generated at 2022-06-26 08:46:19.136392
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    awaitable = q.get()


# Generated at 2022-06-26 08:46:25.092167
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty as exc:
        if type(exc).__name__ != 'QueueEmpty':
            raise Exception()



# Generated at 2022-06-26 08:46:39.276664
# Unit test for method put of class Queue
def test_Queue_put():
    # Test type of arguement 1 of method put: item
    q = Queue()
    item = 1
    try:
        q.put(item)
    except BaseException:
        raise AssertionError("method put of Queue with arguement 1 with type 'int' failed")

    # Test type of arguement 2 of method put: timeout
    q = Queue()
    item = 1
    timeout = 1.0
    try:
        q.put(item, timeout)
    except BaseException:
        raise AssertionError("method put of Queue with arguement 2 with type 'float' failed")

    timeout = (1,2)
    try:
        q.put(item, timeout)
    except TypeError:
        pass

# Generated at 2022-06-26 08:46:41.934514
# Unit test for method get of class Queue
def test_Queue_get():
    pass
    # lifo_queue_0 = LifoQueue()
    # get_return_value_0 = lifo_queue_0.get()
    # print(get_return_value_0)


# Generated at 2022-06-26 08:46:45.094923
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    assert type(queue.get_nowait()) == None


# Generated at 2022-06-26 08:47:26.816825
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    QueueEmpty
    QueueFull
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    q.put(6)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5
    assert q.get_nowait() == 6
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 08:47:29.508855
# Unit test for method get of class Queue
def test_Queue_get():
    x_ = Queue()
    assert isinstance(x_.get(), Awaitable)


# Generated at 2022-06-26 08:47:30.327835
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # TODO
    # Fix this by add mocking to tornado.queues
    print("Not implemented yet")


# Generated at 2022-06-26 08:47:32.559033
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert not q.empty()
    q.get_nowait()


# Generated at 2022-06-26 08:47:47.495442
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case 1
    list_0 = [0, 1, 2, 0, 1]
    queue_0 = Queue()
    for i in list_0:
        queue_0.put(i)

    # Test case 2
    queue_1 = Queue(1)
    queue_1.put(0)
    queue_1.put(1)
    queue_1.put(2)

    # Test case 3
    queue_2 = Queue(1)
    queue_2.put(0)
    queue_2.put(0)
    queue_2.put(0)

    # Test case 4
    queue_3 = Queue()
    queue_3.put(0)
    queue_3.put(0)
    queue_3.put(0)

    # Test case 5
    queue_

# Generated at 2022-06-26 08:47:55.462667
# Unit test for method put of class Queue
def test_Queue_put():
    # 1. Test put_nowait function
    queue_0 = Queue(maxsize=0)
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    # print(queue_0)
    assert queue_0.qsize() == 3

    # 2. Test put function with timeout
    from datetime import timedelta
    import time
    queue_1 = Queue(maxsize=0)
    queue_1.put(1)
    timeout_1 = queue_1.put(2,timeout=timedelta(milliseconds=500))
    timeout_1.add_done_callback(lambda x:print("Consumer 1 is done"))
    assert queue_1.qsize() == 1

# Generated at 2022-06-26 08:48:00.789803
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import random
    import time
    from tornado.gen import sleep
    from . import Queue
    from . import QueueEmpty
    from . import QueueFull

    async def consumer(q: "Queue"):
        while True:
            await sleep(random.random())
            item = q.get_nowait()
            try:
                print('Doing work on %s' % item)
                await sleep(.01)
            finally:
                q.task_done()

    async def producer(q: "Queue"):
        for item in range(5):
            await sleep(random.random())
            q.put_nowait(item)
            print('Put %s' % item)

    async def main():
        q = Queue(maxsize=2)
        # Start consumer without waiting (since it never finishes).
        i

# Generated at 2022-06-26 08:48:05.278470
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue(10)
    queue.put_nowait(1)
    assert queue.get_nowait() == 1
    try:
        queue.get_nowait()
        assert False, "No exception"
    except QueueEmpty:
        pass

# Unit tests for method put_nowait.

# Generated at 2022-06-26 08:48:10.703549
# Unit test for method put of class Queue
def test_Queue_put():
    io_loop = ioloop.IOLoop.current()

    async def main():
        q = Queue()
        await q.put(3)
        await q.put(4)

        print(q._queue)
        print(q.qsize())

    io_loop.run_sync(main)


# Generated at 2022-06-26 08:48:22.176842
# Unit test for method get of class Queue
def test_Queue_get():
    #This test is for None timeout
    
    print("********This is test get********")

    queue_get_0 = Queue(maxsize=10)
    #self._init(self)
    queue_get_0._queue = collections.deque()
    
    #self._getters = collections.deque([]) #type: Deque[Future[_T]]
    queue_get_0._getters = collections.deque([])
    
    #self._putters = collections.deque([]) #type: Deque[Tuple[_T, Future[None]]]
    queue_get_0._putters = collections.deque([])

    #self._unfinished_tasks = 0
    queue_get_0._unfinished_tasks = 0
    
    #self._finished = Event()
    queue_get_0._

# Generated at 2022-06-26 08:49:01.882733
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = q.put("foo")
    assert f.result() == None
    assert q.get_nowait() == "foo"
    assert q.qsize() == 0


# Generated at 2022-06-26 08:49:04.495074
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(0)
    q.put(1)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == False


# Generated at 2022-06-26 08:49:18.582102
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q
    assert q.qsize() == 0

    def set_result(self):
        self.set_result(None)

    def set_result_unless_cancelled(self):
        return future_set_result_unless_cancelled(self, None)

    # Check if a Queue is empty , 
    # there will be no QueueEmpty exception
    # if a Queue is not empty, there will be no QueueFull exception
    assert q.empty() == True
    assert q.full() == False

    def _set_timeout(self, timeout):
        if timeout:
            def on_timeout():
                if not self.done():
                    self.set_exception(gen.TimeoutError())
            io_loop = ioloop.IOLoop.current()
            timeout_

# Generated at 2022-06-26 08:49:32.102708
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    timeout_0 = 0.0
    assert_true(queue_0.put(timeout_0) == None, "put() returned unexpected result")
    assert_true(queue_0.maxsize == 0, "queue_0.maxsize returned unexpected result")
    assert_true(queue_0.qsize() == 0, "queue_0.qsize() returned unexpected result")
    assert_true(queue_0.empty(), "queue_0.empty() returned unexpected result")
    assert_true(not queue_0.full(), "queue_0.full() returned unexpected result")
    queue_1 = Queue(timeout_0)
    assert_true(queue_1.maxsize == 0, "queue_1.maxsize returned unexpected result")

# Generated at 2022-06-26 08:49:43.579113
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Arrange
    queue_0 = Queue(maxsize=2)
    queue_1 = Queue(maxsize=2)
    queue_2 = Queue()

    # Assert
    try:
        queue_2.put_nowait(None)
    except QueueFull:
        # test the QueueFull exception
        pass

    try:
        queue_0.put_nowait(None)
        queue_0.put_nowait(None)
    except QueueFull:
        pass

    # Assert
    try:
        queue_1.put_nowait(None)
        queue_1.put_nowait(None)
    except QueueFull:
        pass



# Generated at 2022-06-26 08:49:56.393189
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test case 1
    queue_0 = Queue(5)
    msg_0 = queue_0.qsize()
    print(msg_0)

    # Test case 3
    # queue_1 = Queue()
    # msg_1 = queue_1.get_nowait()
    # print(msg_1)

    # Test case 4
    # queue_2 = Queue(5)
    # msg_2 = queue_2.get_nowait()
    # print(msg_2)

    # Test case 5
    # queue_3 = Queue()
    # msg_3 = queue_3.full()
    # print(msg_3)

    # Test case 6
    # queue_4 = Queue()
    # msg_4 = queue_4.full()
    # print(msg_4)



# Generated at 2022-06-26 08:50:01.379817
# Unit test for method put of class Queue
def test_Queue_put():
    item = None
    try:
        queue_0 = Queue()
        queue_0.put(item)
        item = None
        queue_0.put(item)
    except:
        print("test put of Queue failed")

if __name__ == '__main__':
    test_Queue_put()

# Generated at 2022-06-26 08:50:03.031707
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue(maxsize=2)
    queue.put(1)
    queue.put(2)
    queue.get_nowait()
    print("queue get nowait succeeded")
    pass

#Unit test for method put of class Queue

# Generated at 2022-06-26 08:50:13.618245
# Unit test for method put of class Queue
def test_Queue_put():
    #Test the first branch in method put
    q = Queue(maxsize=0)
    future01 = Future()
    future01.set_result(None)
    future02 = Future()
    future02.set_result(None)
    future03 = Future()
    future03.set_result(None)
    q._getters.append(future01)
    q._getters.append(future02)
    q._getters.append(future03)

    q.put(1, timeout=10)

    #Test the second branch in method put
    q = Queue(maxsize=0)
    future01 = Future()
    future01.set_result(None)
    future02 = Future()
    future02.set_result(None)
    future03 = Future()
    future03.set_result(None)

# Generated at 2022-06-26 08:50:22.645279
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.put_nowait("1")
    queue.put_nowait("2")
    queue.put_nowait("3")
    queue.put_nowait("4")
    queue.put_nowait("5")
    print("qsize() : " + str(queue.qsize()))

    print("get_nowait() from queue : " + str(queue.get_nowait()))
    print("get_nowait() from queue : " + str(queue.get_nowait()))
    print("get_nowait() from queue : " + str(queue.get_nowait()))
    print("get_nowait() from queue : " + str(queue.get_nowait()))
    print("get_nowait() from queue : " + str(queue.get_nowait()))