

# Generated at 2022-06-26 08:41:06.903124
# Unit test for method put of class Queue
def test_Queue_put():
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        
if __name__ == "__main__":
    test_Queue_put()

# Generated at 2022-06-26 08:41:11.432295
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.maxsize = 5
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert True


# Generated at 2022-06-26 08:41:14.835106
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(10)

    assert q._queue[0] == 10
    return q


# Generated at 2022-06-26 08:41:24.938422
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_1 = Queue(1)
    queue_full_0 = QueueFull()
    queue_full_0 = QueueFull()
    queue_empty_0 = QueueEmpty()
    queue_empty_0 = QueueEmpty()
    queue_empty_0 = QueueEmpty()
    try:
        queue_1.get_nowait()
        raise ValueError("Exception not raised")
    except QueueEmpty:
        pass
    queue_1.put_nowait(100)
    queue_0.put_nowait(100)
    try:
        queue_1.get_nowait()
        raise ValueError("Exception not raised")
    except QueueEmpty:
        pass
    queue_0.put_nowait(100)

# Generated at 2022-06-26 08:41:29.587397
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    q.put_nowait(0)
    q.put_nowait(1)

    try:
        q.put_nowait(2)
        # Should not be reached
        assert False
    except QueueFull:
        pass
    else:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_Queue_put_nowait()

# Generated at 2022-06-26 08:41:43.622119
# Unit test for method put of class Queue
def test_Queue_put():
    # Method put
    # Scenario 1.
    queue1 = Queue()
    test_var1 = queue1.put("test_item_1")
    assert test_var1.result() is None

    # Scenario 2.
    queue2 = Queue()
    future2 = Future()
    queue2._putters = collections.deque()
    queue2._putters.append((future2, "test_item_2"))
    queue2._consume_expired()
    queue2._putters = collections.deque()
    queue2.__put_internal("test_item_2")
    assert queue2._putters == collections.deque([(future2, "test_item_2")])

    # Scenario 3.
    queue3 = Queue()
    queue3._putters = collections.deque()


# Generated at 2022-06-26 08:41:52.093021
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize = 0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3(q)
    test_case_4(q)
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()


# Generated at 2022-06-26 08:41:55.528052
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.get()


# Generated at 2022-06-26 08:42:02.203638
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    assert len(q._queue) == 2



# Generated at 2022-06-26 08:42:12.738141
# Unit test for method get of class Queue
def test_Queue_get():
    #Test 1: queue_get_0
    q_get_0 = Queue()
    timeout_0 = 0.1
    f_get_0 = q_get_0.get(timeout_0)
    q_get_0.put_nowait(3)
    value_get_1 = q_get_0.get_nowait()
    value_get_2 = f_get_0.result()
    assert value_get_1 == value_get_2


# Generated at 2022-06-26 08:42:30.442169
# Unit test for method get of class Queue
def test_Queue_get():
    queue_full_0 = QueueFull()
    queue_full_1 = QueueFull()
    queue_full_2 = QueueFull()
    queue_full_3 = QueueFull()
    queue_full_4 = QueueFull()
    queue_full_5 = QueueFull()
    queue_full_6 = QueueFull()
    queue_full_7 = QueueFull()
    queue_full_8 = QueueFull()
    queue_full_9 = QueueFull()
    queue_full_10 = QueueFull()
    queue_full_11 = QueueFull()
    queue_full_12 = QueueFull()
    queue_full_13 = QueueFull()
    queue_full_14 = QueueFull()
    queue_full_15 = QueueFull()

# Generated at 2022-06-26 08:42:38.305425
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-26 08:42:41.544531
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(maxsize=5)
    queue_0.put_nowait(1)


# Generated at 2022-06-26 08:42:47.128863
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    q.get()
    return

if __name__ == "__main__":
    test_Queue_get()

# Generated at 2022-06-26 08:42:57.032561
# Unit test for method get of class Queue
def test_Queue_get():
    # Test case with a given time out.
    queue_0 = Queue(maxsize=10)
    future_0 = queue_0.get(timeout=10)
    print(future_0)

    # Test case with default time out.
    queue_0_0 = Queue(maxsize=10)
    future_0_0 = queue_0_0.get()
    print(future_0_0)

    # Test case with a given time out.
    queue_1 = Queue(maxsize=10)
    future_1 = queue_1.get(timeout=None)
    print(future_1)

    # Test case with a given time out.
    queue_2 = Queue(maxsize=10)
    future_2 = queue_2.get(timeout=10)
    print(future_2)



# Generated at 2022-06-26 08:43:02.107000
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)

    # testcase 1
    try:
        q.put_nowait(2)
        assert False, "put_nowait should raise QueueFull"
    except QueueFull:
        pass

    q.task_done()
    q.task_done()

    # testcase 2
    try:
        q.task_done()
        assert False, "task_done should raise ValueError"
    except ValueError:
        pass



# Generated at 2022-06-26 08:43:14.482084
# Unit test for method put of class Queue
def test_Queue_put():
    # Test calling the put method without passing in any parameters
    maxsize=0
    q = Queue(maxsize)

    # Test calling the put method with parameters timeout=None
    maxsize=0
    q = Queue(maxsize)
    future = q.put(item=None, timeout=None)

    # Test calling the put method with parameters timeout=0.0
    maxsize=0
    q = Queue(maxsize)
    future = q.put(item=None, timeout=0.0)

    # Test calling the put method with parameters timeout=1.0
    maxsize=0
    q = Queue(maxsize)
    future = q.put(item=None, timeout=1.0)

    # Test calling the put method with parameters timeout=datetime.timedelta(0)
    maxsize=0


# Generated at 2022-06-26 08:43:18.498040
# Unit test for method get of class Queue
def test_Queue_get():

    # Arrange
    queue_0 = Queue()
    timeout_0 = 0

    # Act
    result_0 = queue_0.get(timeout_0)
    # assert
    if type(result_0) == Future:
        assert result_0.done()
        assert result_0.result() == None
    else:
        assert False

# Generated at 2022-06-26 08:43:21.414160
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = Future()  # type: Future[None]
    try:
        q.put_nowait(1)
    except QueueFull:
        return
    else:
        future.set_result(None)
    return


# Generated at 2022-06-26 08:43:23.557126
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    future = q.put(-1)


# Generated at 2022-06-26 08:43:40.318816
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(0)
    timeout = None
    q.get(timeout)
    q.get_nowait()


# Generated at 2022-06-26 08:43:42.871370
# Unit test for method get of class Queue
def test_Queue_get():
    def test_Queue_get_0(self):
        queue_0 = Queue()
        queue_0.get()
    test_case_0()

test_Queue_get()

# Generated at 2022-06-26 08:43:45.109632
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull:
        pass


# Generated at 2022-06-26 08:43:51.163005
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    if (q.qsize() != 0):
        raise Exception('qsize() != 0')
    if (q.empty() != True):
        raise Exception('empty() != True')
    if (q.full() != False):
        raise Exception('full() != False')
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise Exception('get_nowait() does not raise QueueEmpty')
    q.put(1)
    if (q.qsize() != 1):
        raise Exception('qsize() != 1')
    if (q.empty() != False):
        raise Exception('empty() != False')
    if (q.full() != False):
        raise Exception('full() != False')

# Generated at 2022-06-26 08:44:04.345561
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    class Queue_put_nowait():
        def __init__(self):
            # queue_full_0 = QueueFull()
            queue_full_0 = QueueFull

        def test_Queue_put_nowait_0(self):
            queue = Queue(maxsize=0)
            # queue.put_nowait(1)
            queue.put_nowait(item=1)

    queue_put_nowait_0 = Queue_put_nowait()
    queue_put_nowait_0.test_Queue_put_nowait_0()

if __name__=='__main__':
    test_case_0()

    test_Queue_put_nowait()

# Generated at 2022-06-26 08:44:11.348475
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()
    if (q.put_nowait(1)):
        for i in range(1000):
            if (q.get_nowait()):
                pass
    else:
        pass


# Generated at 2022-06-26 08:44:18.930624
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue(0)
    queue_0.put_nowait('item')
    queue_full_0 = QueueFull()
    queue_full_1 = QueueFull()
    # Test for empty queue
    queue_full_0 = QueueFull()
    queue_full_1 = (QueueFull())
    queue_full_2 = QueueFull()
    queue_full_3 = QueueFull()
    queue_full_4 = QueueFull()
    queue_full_5 = QueueFull()
    queue_full_6 = QueueFull()
    # Test for full queue



# Generated at 2022-06-26 08:44:21.130416
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = q.get()
    assert f.done() is False


# Generated at 2022-06-26 08:44:29.728025
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize=2)
    item = 'A'
    # Put an item into the queue without blocking.
    # If no free slot is immediately available, raise `QueueFull`.
    timeout = 1
    future = queue.put(item, timeout)
    future.set_result(None)
    assert queue.qsize() == 1
    queue.put_nowait(item)
    assert queue.qsize() == 2
    # Put an item into the queue, perhaps waiting until there is room.
    # Returns a Future, which raises `tornado.util.TimeoutError` after a timeout.
    # `timeout` may be a number denoting a time (on the same
    # scale as `tornado.ioloop.IOLoop.time`, normally `time.time`), or a
    # `datetime.timedelta`

# Generated at 2022-06-26 08:44:34.857864
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = Future()
    q._putters.append((1, f))

    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    assert f.result() == None


# Generated at 2022-06-26 08:44:59.632140
# Unit test for method get of class Queue
def test_Queue_get():
    q_queue = Queue(maxsize=2)
    consumer_gather = []
    @gen.coroutine
    def consumer():
        async for item in q_queue:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
                consumer_gather.append(item)
            finally:
                q_queue.task_done()

    producer_gather = []
    async def producer():
        for item in range(5):
            await q_queue.put(item)
            producer_gather.append(item)
            print('Put %s' % item)
        await q_queue.join()


# Generated at 2022-06-26 08:45:02.961743
# Unit test for method get of class Queue
def test_Queue_get():
    """test for method get of class Queue"""
    
    # Constructor test
    # Case 0
    test_case_0()



# Generated at 2022-06-26 08:45:06.497552
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    assert queue.qsize() == 1


# Generated at 2022-06-26 08:45:09.412642
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q_1 = Queue(maxsize=0)
    t_1 = test_case_0()
    try:
        q_1.get_nowait()
    except QueueEmpty:
        print("Pass")


# Generated at 2022-06-26 08:45:22.812688
# Unit test for method put_nowait of class Queue

# Generated at 2022-06-26 08:45:32.510602
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Initialize an object of class Queue
    queue_0 = Queue()
    # Sentinel value for parameter 'item' of method Queue.put_nowait
    item_0 = None
    # Invoke method put_nowait on object 'queue_0' with parameter 'item' set to 'item_0'
    try:
        queue_0.put_nowait(item_0)
        assert False, "Expected exception of type QueueFull"
    except QueueFull:
        # Expected exception
        assert True, "QueueFull is expected"


# Generated at 2022-06-26 08:45:44.413239
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Unit test

# Generated at 2022-06-26 08:45:51.858041
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a default Queue object
    queue = Queue()

    # Make sure it is empty
    assert queue.empty()

    # Put some data in queue
    queue.put_nowait(2)

    # Get data out of queue
    data = queue.get_nowait()

    # Make sure data is the same as what we put in
    assert data == 2


# Generated at 2022-06-26 08:45:56.864653
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a default Queue object
    queue = Queue()
    
    # Call method put of Queue object
    queue.put(1)
    queue.put(2, timeout=5)


# Generated at 2022-06-26 08:46:05.952534
# Unit test for method put of class Queue
def test_Queue_put():
    """Test "put" method of class Queue"""
    import tornado.ioloop
    q = Queue()
    
    async def main():
        await q.put(1)
        await q.put(2)
        await q.put(3)
        await q.put(4)
        await q.put(5)

        res = await q.get()
        print(res)

        res = await q.get()
        print(res)

        res = await q.get()
        print(res)

        res = await q.get()
        print(res)

        res = await q.get()
        print(res)

    tornado.ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-26 08:46:29.121877
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 0
    queue_0 = Queue(maxsize)
    timeout = 10
    future = queue_0.put(1, timeout)
    assert timeout == 10
    assert future == None
    assert queue_0.empty()
    assert not queue_0.full()
    assert queue_0.maxsize == 0
    assert queue_0.qsize() == 1
    assert queue_0._finished
    assert not queue_0._finished.is_set()
    assert queue_0._getters == []
    assert queue_0._putters == []
    assert queue_0._queue == [1]
    assert queue_0._unfinished_tasks == 1
    assert queue_0.full()
    assert queue_0.get() == 1


# Generated at 2022-06-26 08:46:40.763105
# Unit test for method put of class Queue
def test_Queue_put():
    # Create an instance of a Queue class for testing
    _queue = Queue()
    _timeout = 0

    # Check if method put of Queue class returns a future
    # which raises tornado.util.TimeoutError after a
    # timeout.
    _future = _queue.put(_timeout)
    if not isinstance(_future, Future) or not issubclass(_future.exception(), gen.TimeoutError):
        print("Method put of Queue class does not return a future which raises tornado.util.TimeoutError after a timeout.")

    # Check if method put of Queue class returns a future
    # which raises tornado.util.TimeoutError after a
    # timeout.
    _future = _queue.put(_timeout, _timeout)

# Generated at 2022-06-26 08:46:45.844967
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=15)
    # Expected exception: queue.QueueEmpty
    with pytest.raises(QueueEmpty):
        q.get_nowait()


# Generated at 2022-06-26 08:46:47.988082
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=10)
    # TODO: add test cases


# Generated at 2022-06-26 08:46:55.658801
# Unit test for method get of class Queue
def test_Queue_get():
    queue_get_0 = Queue(1)
    result_0 = queue_get_0.qsize()
    assert result_0 == 0
    queue_get_1 = Queue(1)
    result_1 = queue_get_1.get()
    assert result_1 == ''


# Generated at 2022-06-26 08:47:01.472063
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = q.get()
    # Test for exception raised in `Queue.get`
    with pytest.raises(QueueEmpty) as st:
        raise QueueEmpty()
    # Test for exception raised in `Queue.get`
    with pytest.raises(QueueEmpty) as st:
        raise QueueEmpty("Test exception raising in Queue.get()")


# Generated at 2022-06-26 08:47:06.196254
# Unit test for method put of class Queue
def test_Queue_put():
    # obj = Queue(maxsize)
    # obj.put(item, timeout=None)
    pass



# Generated at 2022-06-26 08:47:19.385469
# Unit test for method get of class Queue
def test_Queue_get():
    # Call method get of Queue
    # Call method qsize of Queue
    queue_0 = Queue()
    assert queue_0.qsize() == 0
    # Call method get_nowait of Queue
    # Call method put_nowait of Queue
    # Call method get of Queue
    queue_0.put_nowait(1)
    try:
        queue_0.get_nowait()
        future_0 = queue_0.get()
        assert future_0.done() == False
        assert future_0.result() == 1
    except QueueEmpty:
        pass
    else:
        queue_0.put_nowait(1)
        future_0 = queue_0.get()
        assert future_0.done() == False
        assert future_0.result() == 1
    # Call

# Generated at 2022-06-26 08:47:24.734477
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = Future()
    future.set_result(None)
    q._getters.append(future)
    io_loop = ioloop.IOLoop.current()
    io_loop.remove_timeout(None)
    io_loop.add_timeout(None, lambda : None)
    future_set_result_unless_cancelled(future, None)



# Generated at 2022-06-26 08:47:39.254450
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2) 
    async def consumer():
        for item in range(5):
            await q.get()
            q.task_done()
        print('Done')
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)

if __name__ == '__main__':
    test_case_0()
    test

# Generated at 2022-06-26 08:47:58.865229
# Unit test for method put of class Queue
def test_Queue_put():
    test_queue = Queue()
    def put_callback(future: Future) -> None:
        item = future.result()
        print("got item: " + str(item) + " after put")
    future = test_queue.put("item_0")
    future.add_done_callback(put_callback)



# Generated at 2022-06-26 08:48:02.553722
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import pytest

    with pytest.raises(QueueEmpty):
        queue_0 = Queue()
        queue_0.get_nowait()


# Generated at 2022-06-26 08:48:08.456698
# Unit test for method get of class Queue
def test_Queue_get():
    # q = Queue(maxsize=0)
    # q.put_nowait(1)
    # assert q.qsize() == 1
    # #print(q.get(timeout=0.5))
    # assert q.get() == 1
    # assert q.empty()
    queue_0 = Queue()
    queue_1 = Queue()
    queue_2 = Queue()
    queue_3 = Queue()
    queue_4 = Queue()
    queue_5 = Queue()
    queue_6 = Queue()
    pass


# Generated at 2022-06-26 08:48:11.958218
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    t = q.put("message")
    print("Put:", t)
    print("Qsize", q.qsize())


# Generated at 2022-06-26 08:48:22.604138
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q0 = Queue(maxsize=2)

    async def consumer0():
        async for item in q0:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q0.task_done()

    async def producer0():
        for item in range(5):
            await q0.put(item)
            print('Put %s' % item)

    async def main0():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer0)
        await producer0()     # Wait for producer to put all tasks.
        await q0.join()       # Wait for consumer to

# Generated at 2022-06-26 08:48:32.375209
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(5.0)
    queue_0.put_nowait(4.2)
    queue_0.put_nowait(4.2)
    queue_0.put_nowait(6.0)
    queue_0.put_nowait(1.0)
    queue_0.put_nowait(3.0)
    queue_0.put_nowait(2.0)
    queue_0.put_nowait(1.4)
    queue_0.put_nowait(5.5)
    queue_0.put_nowait(9.9)


# Generated at 2022-06-26 08:48:34.977734
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put('c')


# Generated at 2022-06-26 08:48:36.684612
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    a = 0
    b = queue_0.put(a)


# Generated at 2022-06-26 08:48:42.097403
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    # case 0
    try:
        queue_0.get_nowait()
    except Exception as e:
        print(e)
        assert isinstance(e, QueueEmpty)
    queue_0._queue.append(None)
    queue_0.get_nowait()


# Generated at 2022-06-26 08:48:54.101398
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=9)
    try:
        queue._put(1)
    except:
        pass
    try:
        queue._put(9)
    except:
        pass
    try:
        queue._put(8)
    except:
        pass
    try:
        queue._put(7)
    except:
        pass
    try:
        queue._put(6)
    except:
        pass
    try:
        queue._put(5)
    except:
        pass
    try:
        queue._put(4)
    except:
        pass
    try:
        queue._put(3)
    except:
        pass
    try:
        queue._put(2)
    except:
        pass


# Generated at 2022-06-26 08:49:31.359903
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:49:38.537703
# Unit test for method get of class Queue
def test_Queue_get():
    # test_case_0
    queue_0 = Queue()
    try:
        a = queue_0.get()
    except Exception as e:
        raise e
    # test_case_1
    queue_1 = Queue()
    a = queue_1.get()
    # test_case_2
    queue_2 = Queue()
    a = queue_2.get(timeout=2)



# Generated at 2022-06-26 08:49:42.663806
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = q.put(1)
    assert(q.qsize() == 1)
    assert(f.done())
    assert(f.result() == None)


# Generated at 2022-06-26 08:49:55.335280
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                # q.task_done()
                print('task done')

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put

# Generated at 2022-06-26 08:49:57.297148
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue()
    queue_1.put_nowait(10)


# Generated at 2022-06-26 08:50:02.930688
# Unit test for method put of class Queue
def test_Queue_put():
    async def put_1(item):
        queue = Queue()
        await queue.put(item)
        assert queue.qsize() == 1
        assert queue.empty() == False
    ioloop.IOLoop.current().run_sync(lambda:put_1(4))

test_Queue_put()


# Generated at 2022-06-26 08:50:07.580733
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_1 = Queue(10)
    queue_1.put_nowait(2)
    assert queue_1.qsize() == 1
    assert queue_1._putters == collections.deque([])


# Generated at 2022-06-26 08:50:09.270364
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = Future()


# Generated at 2022-06-26 08:50:10.806451
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    future = queue_0.put(0)


# Generated at 2022-06-26 08:50:14.458227
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.maxsize = 1
    queue_0.put("Elixir")
    future_value = queue_0.get()
    print("Tornado Future = ", future_value)
    # The future_value is a Future Object


test_case_0()
test_Queue_get()