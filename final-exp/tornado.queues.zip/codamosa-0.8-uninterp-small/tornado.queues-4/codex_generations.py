

# Generated at 2022-06-26 08:41:03.540234
# Unit test for method put of class Queue
def test_Queue_put():
    var_0 = None
    timeout_0 = None
    future = Queue.put(var_0, timeout_0)
    print(future)


# Generated at 2022-06-26 08:41:07.446450
# Unit test for method get of class Queue
def test_Queue_get():
    try:
        queue = Queue(maxsize=0)
        queue.get()
    except:
        print("exception caught")
        print("exception info:{}".format(sys.exc_info()[0]))
    else:
        print("no exception")


# Generated at 2022-06-26 08:41:12.316901
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(maxsize=0)
    queue_0.put(item=None, timeout=None)
    future_1 = queue_0.get(timeout=None)


# Generated at 2022-06-26 08:41:16.437404
# Unit test for method get of class Queue
def test_Queue_get():
    ioloop_0 = ioloop.IOLoop.current()
    ioloop_0.spawn_callback(test_case_0)

test_Queue_get()

# Generated at 2022-06-26 08:41:25.315816
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-26 08:41:28.758798
# Unit test for method get of class Queue
def test_Queue_get():
    var_1 = Queue()
    var_2 = var_1.get()


# Generated at 2022-06-26 08:41:37.040062
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue(maxsize=0)
    try:
        queue_0.get_nowait()
        assert False
    except QueueEmpty:
        pass
    queue_1 = Queue(maxsize=0)
    queue_1._init()
    queue_1._getters.append(True)
    try:
        queue_1.get_nowait()
        assert False
    except QueueEmpty:
        pass
    queue_2 = Queue(maxsize=0)
    queue_2._init()
    queue_2._getters.append(True)
    queue_2._getters.append(False)
    queue_2._putters.append(tuple(tuple() for _ in range(2)))

# Generated at 2022-06-26 08:41:40.254510
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue(10)
    var_0 = queue_0.get()


# Generated at 2022-06-26 08:41:46.886041
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_empty_0 = QueueEmpty()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        # Expected exception
        pass


# Generated at 2022-06-26 08:41:50.265164
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    var_0 = Queue()
    var_1 = 0
    var_0.put_nowait(var_1)


# Generated at 2022-06-26 08:42:00.403154
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    queue_1.put(1)
    queue_1.put(2)
    queue_1.put(3)
    queue_1.put_nowait(4)


# Generated at 2022-06-26 08:42:02.485776
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(1)


# Generated at 2022-06-26 08:42:06.295576
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        elem_0 = queue_0.get_nowait()
    except QueueEmpty:
        pass    
    


# Generated at 2022-06-26 08:42:14.417019
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    try:
        queue_0._init()
        future = Future()
        future.set_result("")
        queue_0._getters.append(future)
    except QueueEmpty as e:
        print("QueueEmpty_0")
    except:
        print("Unknown error")
    else:
        print("Nothing")


# Generated at 2022-06-26 08:42:18.181738
# Unit test for method put of class Queue
def test_Queue_put():
    # Success case
    queue_0 = Queue()
    queue_0.put(None)


# Generated at 2022-06-26 08:42:22.331025
# Unit test for method get of class Queue
def test_Queue_get():
    print(__name__)
    queue = Queue()
    queue.put_nowait(3)
    print(queue.get_nowait())


# Generated at 2022-06-26 08:42:25.728711
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    awaitable_0 = queue_0.get()
    await awaitable_0


# Generated at 2022-06-26 08:42:37.648967
# Unit test for method get of class Queue
def test_Queue_get():
    print("Testing Queue.get()")
    queue = Queue(maxsize = 1)
    get_future = queue.get()
    print("Waiting for get_future to finish")
    # get_future is a coroutine, so we need to run it
    ioloop.IOLoop.current().run_sync(get_future)
    print("get_future is finished, queue:", queue)
    assert get_future.done()
    print("***** Success *****")

# A test case for the Queue class

# Generated at 2022-06-26 08:42:51.286179
# Unit test for method get of class Queue
def test_Queue_get():
    # Test 1:
    # Normal case, the queue is not empty.
    # The function should return the first item and put the queue in a
    # non-empty state.
    queue_0 = Queue()
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    item = queue_0.get()

    assert item == 1
    assert not queue_0.empty()

    # Test 2:
    # Normal case, the queue is empty.
    # The function should block and wait until the queue is non-empty.
    queue_1 = Queue()
    item = queue_1.get()
    assert not queue_0.empty()

    # Test 3:
    # Abnormal case, the queue is empty and there is no one who is putting
    # items.
    # The

# Generated at 2022-06-26 08:42:56.844004
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    class TestQueue(Queue):
        def __init__(self):
            Queue.__init__(self, 0)
        def _get(self):
            return self._queue.popleft()

    queue_1 = TestQueue()
    queue_1._queue = deque()
    queue_1._queue.append("hello")
    queue_1.put_nowait("hello")


# Generated at 2022-06-26 08:43:13.129563
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    res_0 = q.put(1)
    assert type(res_0).__name__ == 'Future', 'Expected type is Future'
    res_1 = future_set_result_unless_cancelled(res_0, None)
    assert res_1 == None, 'res_1=%s' % res_1
    res_2 = q.put(2)
    assert type(res_2).__name__ == 'Future', 'Expected type is Future'
    res_3 = future_set_result_unless_cancelled(res_2, None)
    assert res_3 == None, 'res_3=%s' % res_3
    res_4 = q.put(3)

# Generated at 2022-06-26 08:43:16.109114
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    res_0 = queue_0.get_nowait()
    assert res_0 == None, "Test failed for Queue.get_nowait()"


# Generated at 2022-06-26 08:43:29.250825
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0._queue.append(None)
    queue_0._queue.append(None)
    queue_0._consume_expired()
    assert not queue_0.empty()
    assert not queue_0.full()
    assert queue_0.qsize() == 2
    # Note: *Not* QueueEmpty
    assert queue_0._getters == collections.deque([])
    # Note: *Not* QueueEmpty
    try:
        queue_0.get_nowait()
        assert queue_0.qsize() == 1
        assert queue_0._getters == collections.deque([])
    except QueueEmpty:
        raise AssertionError
    except Exception:
        pass



# Generated at 2022-06-26 08:43:43.724240
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait()
    except QueueFull:
        raise AssertionError('Tornado raised QueueFull unexpectedly!')
    except:
        pass
    try:
        queue_0.put_nowait(1)
    except QueueFull:
        raise AssertionError('Tornado raised QueueFull unexpectedly!')
    except:
        pass
    try:
        queue_0.put_nowait(1, 2)
    except QueueFull:
        raise AssertionError('Tornado raised QueueFull unexpectedly!')
    except:
        pass

# Generated at 2022-06-26 08:43:53.956672
# Unit test for method put of class Queue
def test_Queue_put():
    # Instantiate object queue to be tested
    queue_0 = Queue()

    # Create variables for argument(s) of method put
    item = "Szefl1Xf0a"
    timeout = 4

    # Invoke method under test
    queue_0.put(item, timeout)

    # Print test result to console
    print("Test result: put(item,timeout): Expected: <>\n              Actual: <"
          + str(queue_0.put(item,timeout)) + ">")


# Generated at 2022-06-26 08:43:59.428673
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test 0
    queue_0 = Queue()
    try:
        value = queue_0.get_nowait()
    except Exception as error:
        print("[test_Queue_get_nowait] Test 0 FAILED")


# Generated at 2022-06-26 08:44:05.241496
# Unit test for method get of class Queue
def test_Queue_get():
    # test for Queue class
    for i in range (0,10):
        queue_0 = Queue()
        for i in range (0,10):
            queue_0.put(i)
        for i in range (0,10):
            assert queue_0.get() == i, "queue error: Queue.get() method failed"


# Generated at 2022-06-26 08:44:18.173778
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-26 08:44:21.376846
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait('')
    assert isinstance(queue_0, Queue)



# Generated at 2022-06-26 08:44:25.703415
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    assert isinstance(future_0, Future)
    assert isinstance(future_0, Awaitable)
    future_0.cancel()


# Generated at 2022-06-26 08:44:41.621486
# Unit test for method get of class Queue
def test_Queue_get():
    # Given
    queue_mock = cast(Queue, mock.MagicMock())
    future_mock = cast(Future, mock.MagicMock())
    timeout_mock = mock.MagicMock()
    stop_mock = mock.MagicMock()
    queue_mock.get_nowait.side_effect = [ValueError, stop_mock]
    queue_mock._getters.append(future_mock)
    io_loop_mock = mock.MagicMock()

    # When
    with mock.patch('tornado.ioloop.IOLoop.current', side_effect = [io_loop_mock]):
        Queue.get(queue_mock, timeout_mock)

    # Then
    #queue_mock.get_nowait.assert_called_with()
    #

# Generated at 2022-06-26 08:44:50.732968
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    task_done = False
    if queue_0.getters:
        assert queue_0.empty(), "queue non-empty, why are getters waiting?"
        getter = queue_0.getters.popleft()
        queue_0.__put_internal(item)
        future_set_result_unless_cancelled(getter, queue_0._get())
    elif queue_0.qsize():
        queue_0._get()
    else:
        raise QueueEmpty
    if task_done:
        try:
            queue_0.task_done()
            assert queue_0.unfinished_tasks == 0, "queue.unfinished_tasks can not be 0!"
        except ValueError:
            print("ValueError")


# Generated at 2022-06-26 08:44:52.022843
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    future_0 = queue_0.get()
    ioloop.IOLoop.current().run_sync(future_0)


# Generated at 2022-06-26 08:44:54.422751
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    queue_0.qsize()


# Generated at 2022-06-26 08:45:00.088306
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        queue_1 = Queue()
        queue_1.get_nowait()
    except QueueEmpty:
        print("Test passed")
    else:
        print("Test failed")
    try:
        queue_2 = Queue()
        queue_2.put_nowait(None)
        queue_2.get_nowait()
        print("Test passed")
    except QueueEmpty:
        print("Test failed")


# Generated at 2022-06-26 08:45:02.114721
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    try:
        queue_0.put_nowait("OK")
    except QueueFull:
        pass
    print("Done")


# Generated at 2022-06-26 08:45:03.651962
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()


# Generated at 2022-06-26 08:45:11.384735
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(1)
    assert queue_0._queue == deque(1)
    queue_0 = Queue(2)
    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    assert queue_0._queue == deque(2, 3)


# Generated at 2022-06-26 08:45:22.063462
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Case 0
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty:
        pass

    # Case 1
    queue_1 = Queue()
    queue_1._getters = []
    queue_1._putters = []
    queue_1._unfinished_tasks = 0
    queue_1._finished = Event()
    queue_1._finished.set()
    queue_1._queue = collections.deque()
    queue_1._queue.append(1)
    queue_1.get_nowait()


# Generated at 2022-06-26 08:45:25.678907
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()

if __name__ == "__main__":
    test_Queue_get()

# Generated at 2022-06-26 08:45:37.695363
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_0 = Queue()
    try:
        queue_0.get_nowait()
    except QueueEmpty as ex_0:
        print(ex_0)


# Generated at 2022-06-26 08:45:43.246550
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    print('[Test]Begin to test Queue.get_nowait() ...')

    queue_0 = Queue(16)

    queue_0.put_nowait(1)
    queue_0.put_nowait(2)
    queue_0.put_nowait(3)
    queue_0.put_nowait(4)
    queue_0.put_nowait(5)
    queue_0.put_nowait(6)

    print(queue_0)

    queue_0.get_nowait()

    print(queue_0)


# Generated at 2022-06-26 08:45:46.909478
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(4)
    q.put_nowait(1)
    future = q.get()



# Generated at 2022-06-26 08:45:52.028224
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(123)
    queue_0.put_nowait(234)
    queue_0.put_nowait(345)
    assert queue_0.qsize() == 3


# Generated at 2022-06-26 08:45:58.849949
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get()

    async def test_coroutine():
        q.put("test_str")
        val = await q.get()
        assert val == "test_str"

    ioloop.IOLoop.current().run_sync(test_coroutine)



# Generated at 2022-06-26 08:46:04.589800
# Unit test for method put of class Queue
def test_Queue_put():
    async def test_put(queue: Queue):
        queue.put_nowait(4)
        for i in range(5):
            await queue.put(i)
            print('Put %s' % i)

    queue_1 = Queue(maxsize=2)
    ioloop.IOLoop.current().run_sync(lambda: test_put(queue_1))


# Generated at 2022-06-26 08:46:07.817788
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)


# Generated at 2022-06-26 08:46:12.982778
# Unit test for method get of class Queue
def test_Queue_get():
    queue_1 = Queue(maxsize=0)
    print("Testing Queue_get")
    test_Queue_get_0(queue_1)
    test_Queue_get_1(queue_1)


# Generated at 2022-06-26 08:46:15.644228
# Unit test for method put of class Queue
def test_Queue_put():
    class TmpClass():
        def __init__(self) -> None:
            self.a = 0

    queue_1 = Queue()
    queue_1.put_nowait(TmpClass())



# Generated at 2022-06-26 08:46:18.837002
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put(0)


# Generated at 2022-06-26 08:46:39.602888
# Unit test for method get of class Queue
def test_Queue_get():
    #queue_a = Queue()
    queue_a = Queue(maxsize=5)
    print("queue_a: " + str(queue_a))
    print(queue_a.qsize())
    print(queue_a.empty())
    print(queue_a.full())
    queue_a.put_nowait(1)
    print(queue_a.qsize())
    print(queue_a.empty())
    print(queue_a.full())
    queue_a.put_nowait(2)
    queue_a.put_nowait(3)
    queue_a.put_nowait(4)
    queue_a.put_nowait(5)
    print(queue_a.qsize())
    print(queue_a.empty())
    print(queue_a.full())
   

# Generated at 2022-06-26 08:46:49.308743
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create a Queue object and put a value into the queue
    queue_0 = Queue()
    queue_0.put_nowait(1)

    # Call the method get_nowait of Queue to get the value from the queue
    result = queue_0.get_nowait()

    # Check that the value returned by the method get_nowait is equal to the value put into the queue
    if result == 1:
        print("The method get_nowait of class Queue works correctly!")
    else:
        print("The method get_nowait of class Queue doesn't work correctly!")



# Generated at 2022-06-26 08:47:01.587875
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado import gen

    # Test case 1:
    class Queue_test_case(AsyncTestCase):
        def setUp(self):
            self.queue = Queue(1)
            self.queue.put_nowait(2)
        @gen_test
        def test_0(self):
            result = self.queue.get_nowait()
            assert result == 2
    # Test case 2:
    class Queue_test_case_2(AsyncTestCase):
        def setUp(self):
            self.queue = Queue(1)
        @gen_test
        def test_0(self):
            with self.assertRaises(QueueEmpty):
                self.queue.get_nowait()
    # Test case 3:

# Generated at 2022-06-26 08:47:06.866430
# Unit test for method put of class Queue
def test_Queue_put():
    queue_1 = Queue()
    future_1 = queue_1.put(item=None, timeout=None)
    future_1.set_result(None)


# Generated at 2022-06-26 08:47:09.961195
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(10)
    try:
        assert queue.get_nowait() == 10
    except:
        assert False


# Generated at 2022-06-26 08:47:12.284678
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put("1")


# Generated at 2022-06-26 08:47:15.992343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        got = q.get_nowait()
        assert False
    except QueueEmpty:
        assert True



# Generated at 2022-06-26 08:47:18.940120
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    item = 1
    q.put(item)


# Generated at 2022-06-26 08:47:22.478560
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(5)
    q.put_nowait(2)
    # Already full so this should raise
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    pass


# Generated at 2022-06-26 08:47:26.062987
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """Test method put_nowait of class Queue."""
    q = Queue(5)
    try:
        q.put_nowait([1])
    except QueueFull as e:
        print("Queue is full, error stacktrace: %s" % e)


# Generated at 2022-06-26 08:47:52.167522
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(2)
    if (len(queue_0._queue) == 1):
        pass
    else:
        raise ValueError("Unexpected exception raised")
    queue_1 = Queue(0)
    queue_1.put_nowait(2)
    queue_1.put_nowait(2)
    if (len(queue_1._queue) == 2):
        pass
    else:
        raise ValueError("Unexpected exception raised")
    queue_2 = Queue(2)
    queue_2.put_nowait(1)
    queue_2.put_nowait(2)

# Generated at 2022-06-26 08:47:54.154942
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.put_nowait(1)
    print(queue.get_nowait())


# Generated at 2022-06-26 08:47:58.636402
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_1 = Queue(maxsize=0)
    try:
        queue_1.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    queue_0 = Queue(maxsize=2)
    queue_0.put_nowait(8)
    queue_0.put_nowait(9)
    queue_0.get_nowait()
    queue_0.get_nowait()


# Generated at 2022-06-26 08:48:03.414345
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    assert len(queue._queue) == 1
    assert queue._queue[0] == 1
    assert queue.maxsize == 0
    assert queue._unfinished_tasks == 0


# Generated at 2022-06-26 08:48:04.971320
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()
    queue_0.get(timeout=None)


# Generated at 2022-06-26 08:48:10.498964
# Unit test for method get of class Queue
def test_Queue_get():
    q_0 = Queue()
    try:
        q_0.put_nowait(5)
        print("put_nowait(5)")
    except QueueFull:
        print("expected QueueFull exception")
    val = q_0.get_nowait()
    print("val = {}".format(val))


# Generated at 2022-06-26 08:48:16.021561
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.empty() == True
    q.put(1)
    q.put(1)
    q.put(1)
    assert q.put_nowait(1) == None
    assert q.qsize() == 4


# Generated at 2022-06-26 08:48:24.124542
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue(10)
    future_0 = Future()
    try:
        queue_0.put_nowait(str)
    except QueueFull as exc_put_nowait:
        print("Exception: {}".format(exc_put_nowait))
    try:
        queue_0.put_nowait(str)
    except QueueFull as exc_put_nowait:
        print("Exception: {}".format(exc_put_nowait))
    try:
        queue_0.put_nowait(str)
    except QueueFull as exc_put_nowait:
        print("Exception: {}".format(exc_put_nowait))

# Generated at 2022-06-26 08:48:26.372958
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    q = Queue(1)
    q.put_nowait(0)
    q.put_nowait(1)



# Generated at 2022-06-26 08:48:30.979589
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    print(queue_0.qsize())
    future = Future()
    queue_0._getters.append(future)
    future.set_result(queue_0._get())
    assert future.done() == True


# Generated at 2022-06-26 08:49:02.936440
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass


# Generated at 2022-06-26 08:49:04.534509
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    f = q.get()
    assert f.result() == 0


# Generated at 2022-06-26 08:49:08.345902
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue_0 = Queue()
    queue_0.put_nowait(0)
    queue_0.put_nowait(1)
    queue_0.put_nowait(3)
    queue_0.put_nowait(4)

    assert queue_0.qsize() == 4



# Generated at 2022-06-26 08:49:10.091685
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()


# Generated at 2022-06-26 08:49:16.984467
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue_0 = Queue()
    # obj_0 = queue_0.get_nowait()
    pass

test_case_0()
test_Queue_get_nowait()



# Generated at 2022-06-26 08:49:31.049700
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    def producer(q: Queue):
        for i in range(10):
            time.sleep(1)
            q.put(i)


    @gen.coroutine
    def consumer(q):
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()


    @gen.coroutine
    def main():
        q = Queue()
        t1 = gen.spawn(consumer, q)
        t2 = gen.spawn(producer, q)
        yield t1
        yield t2

    # IOLoop.current()
    # IOLoop.current().run_sync(main,

# Generated at 2022-06-26 08:49:32.503880
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()
    queue_0.get()


# Generated at 2022-06-26 08:49:35.545101
# Unit test for method put of class Queue
def test_Queue_put():
    queue_0 = Queue()
    queue_0.put_nowait(False)



# Generated at 2022-06-26 08:49:36.593954
# Unit test for method get of class Queue
def test_Queue_get():
    queue_0 = Queue()


# Generated at 2022-06-26 08:49:49.567844
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Unit