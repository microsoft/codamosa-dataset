

# Generated at 2022-06-22 04:17:13.372792
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """
    Code cover
    :return:
    """
    q = Queue(maxsize=2)
    assert not q.full()
    try:
        q.put_nowait(object())
    except QueueFull:
        raise AssertionError("put_nowait(object()) raised QueueFull unexpectedly!")
    try:
        q.put_nowait(object())
    except QueueFull:
        raise AssertionError("put_nowait(object()) raised QueueFull unexpectedly!")
    try:
        q.put_nowait(object())
        raise AssertionError("put_nowait(object()) didn't raise QueueFull!")
    except QueueFull:
        pass



# Generated at 2022-06-22 04:17:23.369556
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    #unit test for get method of Queue
    q1 = Queue()
    q1.put_nowait(1)
    q1.put_nowait(2)
    q1.put_nowait(3)
    q1.put_nowait(4)
    q1.put_nowait(5)
    print("The queue is ")
    print(q1)
    print("The get_nowait method of queue has been called")
    print("The value returned is ")
    print(q1.get_nowait())
    print("The required value")
    print(q1.get_nowait())
    print("Queues are modified")
    print(q1)
    print("The queue is full")

# Generated at 2022-06-22 04:17:32.146764
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.qsize() == 0
    q.put(3)
    assert q.qsize() == 1
    assert q.get_nowait() == 3
    assert q.qsize() == 0
    q.put(5)
    q.put(6)
    q.put(7)
    assert q.qsize() == 3
    assert q.get_nowait() == 5
    assert q.get_nowait() == 6
    assert q.get_nowait() == 7
    assert q.qsize() == 0


# Generated at 2022-06-22 04:17:35.029679
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    #Act
    a = Queue()
    r = a.get_nowait()
    #Assert
    assert r == QueueEmpty


# Generated at 2022-06-22 04:17:41.319694
# Unit test for method put of class Queue
def test_Queue_put():
    def test1_0(q1):
        # Put an item into the queue without waiting.
        # return wait for put item success
        future = Future()
        try:
            q1.put_nowait(1)
            future.set_result(True)
        except QueueFull:
            future.set_result(False)
        return future
    def test1_1(q1):
        # Put an item into the queue, perhaps waiting until there is room.
        # return wait for put item success
        future = Future()
        try:
            q1.put(1)
            future.set_result(True)
        except QueueFull:
            future.set_result(False)
        return future

# Generated at 2022-06-22 04:17:49.922692
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    @gen.coroutine
    def consumer():
        try:
            while True:
                item = yield q.get()
                try:
                    print('Doing work on %s' % item)
                    yield gen.sleep(0.01)
                finally:
                    q.task_done()
        except Exception as e:
            print(str(e))

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)
        yield q.join()
        print('Done')

    ioloop = IOLoop()
    ioloop.spawn_callback(consumer)
    iol

# Generated at 2022-06-22 04:17:56.346180
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    """Method nnext() return an Awaitable[T]
    """
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    asyncio.set_event_loop(asyncio.new_event_loop())
    AsyncIOMainLoop().install()
    q = Queue()
    q.put_nowait('OK')
    iterator = _QueueIterator(q)
    yield from iterator.__anext__()



# Generated at 2022-06-22 04:18:08.316129
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import ioloop
    from tornado.testing import AsyncTestCase, gen_test
    import unittest
    import time

    class TestQueue(AsyncTestCase):
        @gen_test
        def test_Queue_qsize(self):
            q = queue.Queue(maxsize=2)
            async for item in q:
                try:
                    print("Doing work on " + str(item))
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
                    print("item done")

        @gen_test
        def test_Queue_qsize(self):
            q = queue.Queue(maxsize=2)
            q.put(1)
            q.put(2)
            self.assertEqual(q.qsize(), 2)
            time.sleep(2)

# Generated at 2022-06-22 04:18:15.907242
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q.empty()
    q.full()
    q.qsize()
    q.put(1)
    q.put_nowait(1)
    q.get()
    q.get_nowait()
    q.task_done()
    q.join()
    q.__aiter__()
    q.__put_internal(1)
    q.__repr__()
    q.__str__()
    q._format()


# Generated at 2022-06-22 04:18:24.940771
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:18:33.750333
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=3)
    assert q.full() == False



# Generated at 2022-06-22 04:18:38.144387
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")
        pass
    return True



# Generated at 2022-06-22 04:18:41.859664
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        print(e)
        print(e.__class__)
# Unit test end


# Generated at 2022-06-22 04:18:45.392018
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

test_PriorityQueue()



# Generated at 2022-06-22 04:18:49.964962
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    itr = _QueueIterator(q)
    assert itr.q.qsize() == 0
    q.put("Hi")
    q.put("world")
    assert itr.__anext__().result() == "Hi"
    assert itr.__anext__().result() == "world"



# Generated at 2022-06-22 04:18:56.847843
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:06.460343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True

    q.put_nowait(1)
    assert q.get_nowait() == 1

    q.put_nowait(2)
    q.put_nowait(3)
    try:
        q.put_nowait(4)
        assert False
    except QueueFull:
        assert True

    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-22 04:19:11.715253
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    queue = Queue()
    assert queue.qsize() == 0
    queue.put_nowait(1)
    assert queue.qsize() == 1
    queue._put(1)
    assert queue.qsize() == 2

# Generated at 2022-06-22 04:19:15.853398
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    """
    Simple unit test to check if constructors of class QueueEmpty 
    work as expected.
    """
    try:
        raise QueueEmpty
    except QueueEmpty:
        return 0
    else:
        return 1



# Generated at 2022-06-22 04:19:18.787460
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=0)
    assert q.maxsize == 0
    assert q.qsize() == 0
    assert q.empty() is True
    assert q.full() is False


# Generated at 2022-06-22 04:19:45.328557
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

# Generated at 2022-06-22 04:19:59.027218
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:20:02.019597
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        assert e
    else:
        assert False


# Generated at 2022-06-22 04:20:12.668236
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import collections
    import concurrent.futures
    import datetime
    import time
    import unittest

    class QueueTestCase(unittest.TestCase):

        def test_iterator_use_before_put(self):
            q = tornado.queues.Queue(maxsize=2)

            async def putter():
                await q.put(1)
                await q.put(2)

            async def getter():
                async for n in q:
                    self.assertEqual(n, 1)
                    self.assertEqual(q.qsize(), 1)

            t0 = time.time()
            future = concurrent.futures.Future()
            future.set_result(None)


# Generated at 2022-06-22 04:20:16.523503
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue(0)
    async for _ in _QueueIterator(q): # type: ignore
        pass
# Test finished



# Generated at 2022-06-22 04:20:27.550961
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    print("Queue size: ")
    print(q.qsize())
    print("Is queue empty? ")
    print(q.empty())
    print("Is queue full? ")
    print(q.full())
    print("Peeling queue: ")
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    print("Is queue empty? ")
    print(q.empty())
    print("Putting in queue: ")
    q.put_nowait((3, 'new medium-priority item'))
    q.put_nowait((2, 'new low-priority item'))
    q.put_nowait((1, 'new high-priority item'))
    print("Queue size: ")
    print(q.qsize())

# Generated at 2022-06-22 04:20:29.329920
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    return

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:20:32.144719
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq = PriorityQueue()
    assert pq._queue, "Empty Priority Queue"



# Generated at 2022-06-22 04:20:36.403017
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:20:39.052232
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q.get_nowait()
    q.task_done()
    q.task_done()
    q.task_done()
    return


# Generated at 2022-06-22 04:21:34.144843
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    assert queue.qsize()==3
    assert queue.get_nowait()==1
    assert queue.get_nowait()==2
    assert queue.get_nowait()==3
    assert queue.empty()
    assert queue.qsize()==0


# Generated at 2022-06-22 04:21:44.066253
# Unit test for constructor of class Queue
def test_Queue():
    # test for queue size
    q = Queue()
    assert q.qsize() == 0

    # test for queue element
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.empty() == False
    assert q.full() == True
    assert q.get_nowait() == 1

    # test for queue maxsize
    q = Queue(maxsize=1)
    with pytest.raises(QueueFull):
        q.put_nowait(1)
        q.put_nowait(2)

    with pytest.raises(QueueEmpty):
        q = Queue(maxsize=1)
        q.get_nowait()

    # test for task_done
    q = Queue()
    q.put_nowait(1)

# Generated at 2022-06-22 04:21:46.375699
# Unit test for method put of class Queue
def test_Queue_put():
    assert 'async' in dir(Queue.put)
    assert 'await' in inspect.getsource(Queue.put)
    return True


# Generated at 2022-06-22 04:21:58.593062
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Task done method without getting any tasks
    q1 = Queue(maxsize=10)
    try:
        q1.task_done()
    except ValueError:
        pass
    else:
        assert 0

    # Task done method after getting task
    q2 = Queue(maxsize=10)
    q2.put(1)
    assert q2.get_nowait() == 1
    q2.task_done()
    try:
        q2.task_done()
    except ValueError:
        pass
    else:
        assert 0

    # Task done method after getting task which is not completed
    q3 = Queue(maxsize=10)
    q3.put(1)
    assert q3.get_nowait() == 1

# Generated at 2022-06-22 04:22:02.231863
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

    q.join()
    print("test_PriorityQueue finished.")



# Generated at 2022-06-22 04:22:05.561331
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    def get_nowait():
        _____
        _____
    test_Queue_get_nowait()



# Generated at 2022-06-22 04:22:13.795726
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # Check if the return type of method get is correct
    assert isinstance(q.get(), Awaitable[None])
    # Check if the return type of method get_nowait is correct
    assert isinstance(q.get_nowait(), _T)
    # Check if the return type of method task_done is correct
    assert q.task_done() == None
    # Check if the return type of method join is correct
    assert isinstance(q.join(), Awaitable[None])
    # Check if the return type of method qsize is correct
    assert isinstance(q.qsize(), int)
    # Check if the return type of method empty is correct
    assert isinstance(q.empty(), bool)
    # Check if the return type of method full is correct
    assert isinstance(q.full(), bool)

# Generated at 2022-06-22 04:22:16.241061
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)



# Generated at 2022-06-22 04:22:22.843886
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(5)
    q.put_nowait(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    q.task_done()
    q.join()



# Generated at 2022-06-22 04:22:23.525299
# Unit test for method put of class Queue
def test_Queue_put():
    pass



# Generated at 2022-06-22 04:26:40.460259
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    #test with q.task_done() called less than .put()
    q = Queue()
    q.put(1)
    q.put(2)
    q.task_done()
    return True


# Generated at 2022-06-22 04:26:45.846403
# Unit test for constructor of class LifoQueue
def test_LifoQueue():

    # Test that the default constructor works with an empty list of items
    q = LifoQueue()
    assert q.empty() == True
    assert q.full() == False

    # Test that the default constructor works with a list of items
    q = LifoQueue(range(0, 10))
    assert q.empty() == False
    assert q.full() == False

