

# Generated at 2022-06-22 04:16:58.287434
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
   q = LifoQueue()
   #q.put(3)
   #q.put(2)
   #q.put(1)
   print(q.get())
   print(q.get())
   print(q.get())

# Generated at 2022-06-22 04:17:03.843636
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:17:15.115793
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import datetime
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-22 04:17:17.391337
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue

    result = Queue().__str__()
    assert isinstance(result, str)


# Generated at 2022-06-22 04:17:22.542960
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

#test_PriorityQueue()



# Generated at 2022-06-22 04:17:24.192136
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(2)
    q.put(3)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 3
    assert q.get_nowait() == 2

# Generated at 2022-06-22 04:17:27.591611
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-22 04:17:29.973031
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull()
    assert isinstance(q, Exception)
    assert q.args == ()



# Generated at 2022-06-22 04:17:33.515673
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:17:38.519160
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    q.get_nowait()
    assert not q.full()

# Generated at 2022-06-22 04:17:51.536616
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert QueueEmpty().__class__  == QueueEmpty



# Generated at 2022-06-22 04:18:01.042638
# Unit test for method get of class Queue
def test_Queue_get():
    # The get method should time out if waiting for an item to be put
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    assert q.qsize() == 2
    with pytest.raises(gen.TimeoutError):
        IOLoop.current().run_sync(lambda: q.get(timeout=0.01))
    assert q.empty()
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    assert q.qsize() == 2

# Generated at 2022-06-22 04:18:10.426367
# Unit test for method empty of class Queue
def test_Queue_empty():
    
    q = Queue(maxsize=2)

    # The queue is empty
    assert q.empty()
    assert not q.full()

    async def test():
        await q.put(1)
        assert not q.empty()
        assert not q.full()
        await q.put(1)
        assert not q.empty()
        assert q.full()
        await q.get()
        assert not q.empty()
        assert not q.full()
        await q.get()
        assert q.empty()
        assert not q.full()
    ioloop.IOLoop.current().run_sync(test)


# Generated at 2022-06-22 04:18:11.437464
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(-1)


# Generated at 2022-06-22 04:18:16.944479
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    s = str(q)
    # '<Queue at 0x7f1f7e96f9e8 maxsize=0 queue=deque([])>'
    assert s.find('<Queue at') >= 0
    assert s.find('maxsize=0') >= 0
    assert s.find('queue=deque([])') >= 0
    
    

# Generated at 2022-06-22 04:18:25.716193
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:18:29.946225
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-22 04:18:37.314701
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from .testing import AsyncTestCase, main, run_on_executor
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.queues import Queue, QueueEmpty

    class QueueTest(AsyncTestCase):
        def test_Queue___repr__(self):
            for maxsize in [0, 1, 2]:
                q = Queue(maxsize)
                self.assertEqual(str(q), "<Queue %r>" % (maxsize,))
                self.assertEqual(repr(q), "<Queue at %s %r>" % (hex(id(q)), maxsize))

                q.put_nowait(0)
                q.put_nowait(1)

# Generated at 2022-06-22 04:18:40.716472
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    QueueEmpty().args == ()



# Generated at 2022-06-22 04:18:50.533830
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import sys
    import os
    import queue
    import types
    import scipy.stats
    import random
    from .test_utils import is_equal_to, is_instance_of
    from .test_types import (
        get_int, get_str, get__T, get_float, get_int_or_float, get_str_or_None,
        get_number, get_number_or_None, get_str_or_number, get_str_or_number_or_None,
        get_str_or_int, get_str_or_int_or_None
    )

# Generated at 2022-06-22 04:19:05.666393
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    test_variable = Queue(maxsize=1)
    if test_variable.empty() == True:
        test_variable.put(item=0)
        if test_variable.qsize() == 1:
            try:
                test_variable.put_nowait(item=1)
            except QueueFull:
                return False
            else:
                return True
        else:
            return False
    else:
        return False

# Generated at 2022-06-22 04:19:15.944138
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0

test_Queue_qsize()

# Generated at 2022-06-22 04:19:17.614194
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-22 04:19:20.299399
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    global q
    q = Queue(4)
    for i in range(4):
        q.put_nowait(i)
    q.get_nowait()




# Generated at 2022-06-22 04:19:25.636294
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import itertools
    import re

    def test(maxsize):
        q = Queue(maxsize=maxsize)
        assert re.match(r"<Queue at \w+ maxsize=%r queue=\[]>" % maxsize, str(q))
        q.put_nowait(3)
        assert re.match(r"<Queue at \w+ maxsize=%r queue=\[3\]>" % maxsize, str(q))
        q.task_done()
        assert re.match(r"<Queue at \w+ maxsize=%r queue=\[\]>" % maxsize, str(q))
        q.put_nowait(3)
        q.put_nowait

# Generated at 2022-06-22 04:19:27.099800
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    print(q.empty())


# Generated at 2022-06-22 04:19:36.479613
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q._maxsize = 1
    assert str(q) == "<Queue maxsize=1 queue=deque([])>"
    q._queue = collections.deque([1, 2])
    assert str(q) == "<Queue maxsize=1 queue=deque([1, 2])>"
    q.task_done()
    assert str(q) == "<Queue maxsize=1 queue=deque([2]) tasks=1>"
    q.task_done()
    assert str(q) == "<Queue maxsize=1 queue=deque([2])>"
test_Queue___str__()



# Generated at 2022-06-22 04:19:39.440808
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    for i in range(10):
        q.put(i)
    assert q.qsize() == 10



# Generated at 2022-06-22 04:19:40.486648
# Unit test for method put of class Queue
def test_Queue_put():
    pass


# Generated at 2022-06-22 04:19:43.370879
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    q.put(2)
    assert q.qsize() == 2
    q.get()
    assert q.qsize() == 1
    q.get()
    assert q.qsize() == 0

# Generated at 2022-06-22 04:20:08.787571
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	#Test case 1
	q = Queue(maxsize=1)
	assert q.get_nowait() == None, "get_nowait returns None if queue is empty"
	#Test case 2
	q.put_nowait(1)
	assert q.get_nowait() == 1, "get_nowait return the oldest item in the queue"
	return True


# Generated at 2022-06-22 04:20:10.343368
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q=Queue()
    q._put(1)
    q.task_done()

# Generated at 2022-06-22 04:20:17.329349
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    @gen.coroutine
    def run():
        q = Queue()
        for i in range(0, 10):
            q.put_nowait(i)
        for i in _QueueIterator(q):
            print(i)

    import tornado
    tornado.ioloop.IOLoop.current().run_sync(run)



# Generated at 2022-06-22 04:20:19.351387
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)



# Generated at 2022-06-22 04:20:22.491522
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        assert(e.__class__ == QueueFull)


# Generated at 2022-06-22 04:20:29.978103
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import unittest

    from tornado.gen import TimeoutError

    from tornado.queues import Queue

    class MyTestCase(unittest.TestCase):

        def test_queue_join(self):
            q = Queue(0)
            now = time.time()

            def putter():
                for i in range(3):
                    yield q.put(i)
                    yield gen.sleep(0)

            p = putter()
            p.next()
            q.join()
            self.assertEqual(q.qsize(), 3)
            self.assertFalse(p.next().done())
            q.join()
            self.assertTrue(p.next().done())

            q = Queue(1)
            for i in range(5):
                yield q.put(i)
           

# Generated at 2022-06-22 04:20:31.325116
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))



# Generated at 2022-06-22 04:20:34.293584
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
    except QueueFull as e:
        print(e)


# Generated at 2022-06-22 04:20:38.976554
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=0)
    assert q.maxsize == 0

    # test for constructor exception
    try:
        q1 = Queue(maxsize=None)
    except TypeError:
        assert True

    try:
        q2 = Queue(maxsize=-1)
    except ValueError:
        assert True


# Generated at 2022-06-22 04:20:44.539728
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() is True
    q.task_done()
    assert q.empty() is True
    q.__put_internal(1)
    assert q.empty() is False
    q._put(2)
    assert q.empty() is False


# Generated at 2022-06-22 04:21:06.571772
# Unit test for method __str__ of class Queue
def test_Queue___str__():
  q = Queue()
  q.__str__()
  q._getters = collections.deque()
  q.__str__()


# Generated at 2022-06-22 04:21:08.201845
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    return q.empty()


# Generated at 2022-06-22 04:21:11.963445
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# test_PriorityQueue()



# Generated at 2022-06-22 04:21:23.697505
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    q = Queue(maxsize=0)
    qi = _QueueIterator(q)
    assert qi.__anext__().done() is False
    q.put_nowait(0)
    q.put_nowait(1)
    q.put_nowait(2)
    assert qi.__anext__().result() == 0
    assert qi.__anext__().result() == 1
    assert qi.__anext__().result() == 2
    with pytest.raises(StopAsyncIteration):
        qi.__anext__()
    q.put_nowait(3)
    assert qi.__anext__().result() == 3
    with pytest.raises(StopAsyncIteration):
        qi.__anext__()




# Generated at 2022-06-22 04:21:32.534529
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

    # Output:
    # (0, 'high-priority item')
    # (1, 'medium-priority item')
    # (10, 'low-priority item')


# Generated at 2022-06-22 04:21:34.524626
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=4)
    assert q.qsize() == 0

# Generated at 2022-06-22 04:21:38.180962
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    if q.qsize() == 0:
        print('Create an empty queue.')
    else:
        print('The queue has some elements.')

test_Queue_qsize()


# Generated at 2022-06-22 04:21:47.138100
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=3)
    q._queue = collections.deque([1,2,3])
    q._finished.set()
    assert q.put(4) == None
    assert q._queue == collections.deque([2,3,4])
    q._queue = collections.deque()
    q._getters = collections.deque([object(),object()])
    q.put(4)
    q.put(5)
    assert q._queue == collections.deque([3,4])
    assert q._getters == collections.deque([None,None])
    q = Queue()
    q._putters = collections.deque([(1,object())])
    q._getters = collections.deque([Future()])
    q._unfinished_tasks = 1
    q._putters

# Generated at 2022-06-22 04:21:59.347096
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import timeit
    from tornado.queues import Queue
    q = Queue()
    # initilizing the queue with 10000 items
    for i in range(10000):
        q.put_nowait(i)
    '''
    testing the get_nowait method
    qsize after each get is expected to decrease by 1
    '''
    try:
        while True:
            x = q.get_nowait()
            if q.qsize() == 0:
                break
            else:
                assert q.qsize() == x
            yield gen.sleep(0)
    except Exception as e:
        pass

if __name__ == '__main__':
    from tornado.ioloop import IOLoop
    #time for the test : 0.05223476000444444

# Generated at 2022-06-22 04:22:04.247242
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()
    # This test should pass
    return 


# Generated at 2022-06-22 04:22:27.938284
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    # (0, 'high-priority item')
    # (1, 'medium-priority item')
    # (10, 'low-priority item')
test_PriorityQueue()



# Generated at 2022-06-22 04:22:32.989744
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=1)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        while True:
            print('Putting')
            yield q.put(0)
            print('Put 0')
            yield gen.sleep(0.5)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()

# Generated at 2022-06-22 04:22:35.676809
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    qi = _QueueIterator(q)
    return (q, qi)



# Generated at 2022-06-22 04:22:38.223014
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado.queues import Queue

    q = Queue()
    q.task_done()
    q.put('item')
    q.task_done()


# Generated at 2022-06-22 04:22:46.032005
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-22 04:22:55.188759
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    # Test the method __repr__ of the class Queue with positive value
    q = Queue(maxsize=2)
    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    @gen.coroutine    
    def main():
        IOLoop.current().spawn_callback(consumer)
        yield producer()     
        yield q.join()       
        print('Done')
   

# Generated at 2022-06-22 04:22:58.960678
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)



# Generated at 2022-06-22 04:23:00.825147
# Unit test for method put of class Queue
def test_Queue_put():
    q1 = Queue(maxsize=2)
    q1.put(0)
    q1.put(1)
    assert q1.full(), 'test_Queue_put'

# Generated at 2022-06-22 04:23:05.532887
# Unit test for method get of class Queue
def test_Queue_get():
    """test_Queue_get : check that the get method of Queue returns the good value
    """
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get() == 1
    assert q.get() == 2
    print("Queue_get [OK]")


# Generated at 2022-06-22 04:23:09.504925
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-22 04:23:56.262813
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    assert q._unfinished_tasks == 0
    q._unfinished_tasks = 1
    q.task_done()
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()


# Generated at 2022-06-22 04:23:58.356801
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    print("TEST QSIZE")
    q = Queue(maxsize=10)
    for i in range(4):
        q.put_nowait(i)
    print(q.qsize())

# Generated at 2022-06-22 04:24:02.613759
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q._put(1)
    print(f"init queue iterator: q={q}, it={_QueueIterator(q)}")
    return _QueueIterator(q)


# Generated at 2022-06-22 04:24:10.057272
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    item = 1
    timeout = None
    future = Future()
    try:
        q.put_nowait(item=item)
    except QueueFull:
        q._putters.append((item, future))
    else:
        future.set_result(None)
    finally:
        return future
            

if typing.TYPE_CHECKING:
    from typing import Deque, Tuple, Any  # noqa: F401


# Generated at 2022-06-22 04:24:14.428053
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:24:16.386927
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert it.q == q



# Generated at 2022-06-22 04:24:20.295430
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.full() is False
    q.put_nowait(1)
    assert q.full() is False
    q.put_nowait(2)
    assert q.full() is True

# Generated at 2022-06-22 04:24:21.872963
# Unit test for constructor of class Queue
def test_Queue():
    Queue()



# Generated at 2022-06-22 04:24:34.632127
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2 queue=deque([]) getters[0] putters[0]>"
    q._queue.append(1)
    assert str(q) == "<Queue maxsize=2 queue=deque([1]) getters[0] putters[0] tasks=1>"
    q._getters.append(1)
    assert str(q) == "<Queue maxsize=2 queue=deque([1]) getters[1] putters[0] tasks=1>"
    q._putters.append((1, 2))
    assert str(q) == "<Queue maxsize=2 queue=deque([1]) getters[1] putters[1] tasks=1>"
    q._unfinished_tasks = 2
    assert str(q)

# Generated at 2022-06-22 04:24:36.705420
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait("s")
    it = _QueueIterator(q)
    future = it.__anext__()
    assert future.result() == "s"



# Generated at 2022-06-22 04:26:14.804215
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # maxsize != 0 && (queue is full || getters is not empty)
    q = Queue(maxsize = 3)
    q._getters.append(5)
    q._init()
    q._put(2)
    q._put(4)
    q._put(6)
    try:
        q.put_nowait(2)
        print("Test Queue.put_nowait 1: Success")
    except QueueFull:
        print("Test Queue.put_nowait 1: Fail")
    try:
        q.put_nowait(5)
        print("Test Queue.put_nowait 2: Success")
    except QueueFull:
        print("Test Queue.put_nowait 2: Fail")

    # maxsize != 0 && queue is not full && getters is empty
    q

# Generated at 2022-06-22 04:26:18.993176
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()
    exc_match = "task_done\(\) called too many times"
    with pytest.raises(ValueError, match=exc_match):
        q.task_done()

# Generated at 2022-06-22 04:26:22.025512
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(2)
    except QueueFull:
        return False
    return True


# Generated at 2022-06-22 04:26:23.647471
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(1)
    q.put_nowait(1)
    assert q.get().result() == 1


# Generated at 2022-06-22 04:26:24.597775
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:26:28.074192
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # @TODO write testcase for Queue.qsize()
    pass


# Generated at 2022-06-22 04:26:31.062684
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        pass
    print((e.args))



# Generated at 2022-06-22 04:26:37.751802
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q._format() == "maxsize=0 queue=deque([])"
    q.put_nowait("a")
    q.put_nowait("b")
    assert q._format() == "maxsize=0 queue=deque(['a', 'b'])"
    q.get_nowait()
    q.get_nowait()
    assert q._format() == "maxsize=0 queue=deque([])"
    q._putters.extend(["foo", "bar"])
    assert q._format() == "maxsize=0 queue=deque([]) putters[2]"
    q._getters.append("baz")
    assert q._format() == "maxsize=0 queue=deque([]) getters[1] putters[2]"

# Generated at 2022-06-22 04:26:39.915185
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = QueueEmpty()
    assert q.__str__() == 'QueueEmpty()'


# Generated at 2022-06-22 04:26:44.806756
# Unit test for constructor of class QueueFull
def test_QueueFull():
    import unittest
    class MyTestCase(unittest.TestCase):
        def test_QueueFull(self):
            qf = QueueFull("queue is full")
            self.assertEqual(str(qf), "queue is full")
    unittest.main(argv=[__file__])
