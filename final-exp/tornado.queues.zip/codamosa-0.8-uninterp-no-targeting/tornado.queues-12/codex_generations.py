

# Generated at 2022-06-22 04:17:09.051528
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()
    q.put_nowait(0)
    assert not q.empty()


# Generated at 2022-06-22 04:17:19.714786
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    item1 = 2
    item2 = 3
    item3 = 7
    print('q.put(item1)')
    q.put(item1)
    print('q.put(item2)')
    q.put(item2)
    print('q.put(item3)')
    q.put(item3)
    print('q.get()')
    print(q.get())
    print('q.get()')
    print(q.get())
    print('q.get()')
    print(q.get())




# Generated at 2022-06-22 04:17:20.780820
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert True


# Generated at 2022-06-22 04:17:32.662350
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    # Call method put_nowait of class Queue
    q = Queue(1)
    q.put_nowait(42)

    # Call method put_nowait of class Queue
    # AssertionError: queue not full, why are putters waiting?
    q = Queue(1)
    q.put_nowait(42)
    try:
        q.put_nowait(42)
    except QueueFull:
        pass

    # Call method put_nowait of class Queue
    # Raises an error to indicate the execution failed
    q = Queue(0)
    try:
        q.put_nowait(42)
    except QueueFull:
        pass

    # Call method put_nowait of class Queue
    # AssertionError: queue not full, why are putters waiting?


# Generated at 2022-06-22 04:17:34.741213
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    #TODO: Implement method test__QueueIterator___anext__
    pass



# Generated at 2022-06-22 04:17:44.925427
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 3
    _q = list(q._queue)
    assert _q == [1, 2, 3]
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.empty() == True


# Generated at 2022-06-22 04:17:52.737078
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[]>" % id(q)
    q = Queue(maxsize=10)
    assert repr(q) == "<Queue at 0x%x maxsize=10 queue=[]>" % id(q)
    q = Queue()
    q.put_nowait("a")
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=['a']>" % id(q)
    q = Queue(maxsize=0)
    q._getters.append(Future())
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[] getters[1]>" % id(q)
    q = Queue(maxsize=0)

# Generated at 2022-06-22 04:18:01.955798
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert str(q) == '<Queue maxsize=2 queue=deque([])>'
    assert repr(q) == '<Queue at 0x7fecb6f5f6a0 maxsize=2 queue=deque([])>'
    q.put_nowait(5)
    assert q.qsize() == 1
    assert str(q) == '<Queue maxsize=2 queue=deque([5])>'
    assert repr(q) == '<Queue at 0x7fecb6f5f6a0 maxsize=2 queue=deque([5])>'
    q.put_nowait(6)
    assert q.qsize() == 2

# Generated at 2022-06-22 04:18:07.252705
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')
    assert True

# Generated at 2022-06-22 04:18:10.808985
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:18:20.461425
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:18:22.012314
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = q._QueueIterator()
    assert it.__anext__()



# Generated at 2022-06-22 04:18:29.619508
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import random
    import time
    q = Queue(maxsize=10)
    ts = []
    for i in range(30):
        ts.append(time.time())
    for i in range(30):
        try:
            q.put_nowait(i)
            print('put {}'.format(i))
        except QueueFull:
            time.sleep(1)
    idx = 10
    while idx < 30:
        try:
            tt = time.time()
            print('get {} time {} idx {}'.format(q.get_nowait(), tt, idx))
            idx += 1
            dt = tt - ts[idx]
            print('dt {}'.format(dt))
        except QueueEmpty:
            time.sleep(1)
    print('finish')

# Generated at 2022-06-22 04:18:37.126630
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(2)
    assert str(q) == "<Queue maxsize=2 queue=deque([])>", str(q)
    q.put_nowait(10)
    assert str(q) == "<Queue maxsize=2 queue=deque([10])>", str(q)
    q.put_nowait(20)
    assert str(q) == "<Queue maxsize=2 queue=deque([10, 20])>", str(q)
    q.put_nowait(30)
    assert str(q) == "<Queue maxsize=2 queue=deque([30]) putters[1]>"
    assert q.get_nowait() == 30, q.get_nowait()
    assert q.get_nowait() == 20, q.get_nowait()

# Generated at 2022-06-22 04:18:44.153042
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    """
    >>> q = Queue()
    >>> q._queue.append(1)
    >>> q._queue.append(2)
    >>> q._queue.append(3)
    >>> q._queue.append(4)
    >>> [await i for i in _QueueIterator(q)]
    [1, 2, 3, 4]
    """



# Generated at 2022-06-22 04:18:48.034854
# Unit test for constructor of class QueueFull
def test_QueueFull():
    size = 3
    q = Queue(size)

    for i in range(size):
        q.put_nowait(i)

    print("Putting into a Queue full")
    try:
        q.put_nowait(3)
    except QueueFull as e:
        print(e)



# Generated at 2022-06-22 04:18:51.780323
# Unit test for method empty of class Queue
def test_Queue_empty():
    #  assert empty(self) == False
    __queue_empty = collections.deque()
    __queue_empty.append(1)
    q = Queue(maxsize=2)
    assert q.empty() == True
    q._queue = __queue_empty
    assert q.empty() == False

# Generated at 2022-06-22 04:19:03.486689
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    import asyncio
    import time

    @coroutine
    def test_handler():
        q = Queue()
        for i in range(10):
            yield q.put(i)
        async for i in q:
            assert i == 0
        async for i in q:
            assert i == 1
        async for i in q:
            assert i == 2
        async for i in q:
            assert i == 3
        async for i in q:
            assert i == 4
        async for i in q:
            assert i == 5
        async for i in q:
            assert i == 6
        async for i in q:
            assert i == 7
        async for i in q:
            assert i

# Generated at 2022-06-22 04:19:08.618893
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado
    import string
    from tornado import gen, ioloop
    from tornado.testing import AsyncTestCase, gen_test

    from tornado.queues import Queue

    q = Queue()

    for i in string.ascii_letters:
        q.put_nowait(i)

    for i in range(10):
        q.task_done()

    with self.assertRaises(ValueError):
        q.task_done()

    q._unfinished_tasks = 0
    q._finished.set()

    q.task_done()


# Generated at 2022-06-22 04:19:10.428617
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    x = QueueEmpty()


# Generated at 2022-06-22 04:19:18.332161
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    Queue()



# Generated at 2022-06-22 04:19:19.636950
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()
    

# Generated at 2022-06-22 04:19:20.355580
# Unit test for method put of class Queue
def test_Queue_put():
    pass



# Generated at 2022-06-22 04:19:23.384729
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    # Test_1
    try:
        for _ in range(4):
            q.put_nowait(_)
    except:
        assert True
    # Test_2
    try:
        for _ in range(4):
            q.put_nowait(_)
        assert False
    except:
        assert True


# Generated at 2022-06-22 04:19:25.873813
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    queue = LifoQueue()
    queue.put(3)
    queue.put(2)
    queue.put(1)
    assert queue.get_nowait() == 1
    assert queue.get_nowait() == 2
    assert queue.get_nowait() == 3

# Generated at 2022-06-22 04:19:35.155059
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    '''test_Queue___aiter__'''
    q = Queue()
    async def test():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def test_put():
        for i in range(10):
            await q.put(i)
    async def main():
        await gen.multi([test(), test_put()])
        await q.join()
        print('Done')
    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-22 04:19:43.346907
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q2 = Queue()
    q.get_nowait()
    q2.put_nowait(5)
    assert q._getters == []
    assert q._putters == []
    assert q._unfinished_tasks == 0
    assert q._finished == True
    assert q2._getters == []
    assert q2._putters == []
    assert q2._unfinished_tasks == 0
    assert q2._finished == True

# Generated at 2022-06-22 04:19:45.174538
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__()=="<Queue maxsize=0>"
test_Queue___str__()


# Generated at 2022-06-22 04:19:47.286609
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    i = 0
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    while i < 3:
        print(q.get_nowait())
        i += 1


# Generated at 2022-06-22 04:19:59.746656
# Unit test for method task_done of class Queue
def test_Queue_task_done():
  from tornado.queues import Queue
  q = Queue()
  q.put(1)
  q.get_nowait()
  q.task_done()
  q.get_nowait()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task_done()
  q.task

# Generated at 2022-06-22 04:20:20.498842
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    L = LifoQueue()
    L.put(3)
    L.put(2)
    L.put(1)
    a = L.get_nowait()
    b = L.get_nowait()
    c = L.get_nowait()
    assert(a == 1 and b == 2 and c == 3)

# Generated at 2022-06-22 04:20:29.144824
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import unittest
    
    
    
    
    
    
    
    
    
    
    ################################################################################
    class myQueue(Queue):
        def __init__(self, x):
            Queue.__init__(self, x)
            self.name = 'myQueue'
        def _format(self):
            return self.name
    ################################################################################
    class myQueue2(Queue):
        def __init__(self, x):
            Queue.__init__(self, x)
            self.my_queue = 'my_queue'
    ################################################################################
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 04:20:35.957209
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put("Hello")
    assert (q.qsize() == 1)
    assert (q.empty() == False)
    q.put("World")
    assert (q.get() == "Hello")
    assert (q.get() == "World")
    assert (q.empty() == True)
    assert (q.qsize() == 0)



# Generated at 2022-06-22 04:20:43.841521
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    queue = Queue()
    assert queue._queue is None
    queue._init()
    assert queue._queue == deque([])
    queue._put(1)
    assert queue._queue == deque([1])
    queue._put(2)
    assert queue._queue == deque([1,2])
    assert queue._get() == 1
    assert queue._queue == deque([2])
    queue._unfinished_tasks = 1
    queue._finished = Event()
    result = queue._format()
    assert result == "maxsize=0 queue=deque([2]) tasks=1"
    queue.__aiter__()
    assert queue.__aiter__() == _QueueIterator(queue)
    queue_ = _QueueIterator(queue)
    assert queue_._q == queue
    queue._task_done()

# Generated at 2022-06-22 04:20:45.563701
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        print(e)


# Generated at 2022-06-22 04:20:54.160731
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    def put(q, n):
        for i in range(n):
            q.put(i)
    q = Queue()
    put(q, 10)
    assert not q._finished.is_set()
    for _ in range(5):
        q.get_nowait()
        q.task_done()
    assert not q._finished.is_set()
    put(q, 10)
    assert not q._finished.is_set()
    q.join()
    assert q._finished.is_set()
    q.task_done() # raise ValueError


# Generated at 2022-06-22 04:21:05.461036
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time, json
    from collections import defaultdict

    # create queue instance and add a first item
    q = Queue()
    q.put("zero")
    q.put("three")
    assert q.qsize() > 0
    assert q.maxsize != 0
    assert not q.empty()
    assert not q.full()

    # add item and check the size of queue
    q.put("one")
    q.put("two")
    assert q.qsize() > 0

    # check if q is full
    assert q.full() 

    # fill the queue to full size
    for i in range(1, 100):
        q.put(str(i))


    # check the queue size
    assert q.qsize() == 102

    # check if queue is full
    assert q.full()

   

# Generated at 2022-06-22 04:21:13.693150
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    assert q.qsize() == 0

    async def push():
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)

    async def pop():
        await q.get()
        await q.get()
        await q.get()

    async def main():
        tasks = [IOLoop.current().spawn_callback(push), IOLoop.current().spawn_callback(pop)]
        await gen.multi(tasks)

    IOLoop.current().run_sync(main)



# Generated at 2022-06-22 04:21:19.361901
# Unit test for constructor of class Queue
def test_Queue():
    a = Queue()
    if a.qsize() != 0:
        raise Exception("Queue constructor test failed")
    a = Queue(10)
    if a.qsize() != 0:
        raise Exception("Queue constructor test failed")
    if a.maxsize != 10:
        raise Exception("Queue constructor test failed")


# Generated at 2022-06-22 04:21:20.041590
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass

# Generated at 2022-06-22 04:21:47.873179
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=2)
    print(queue)



# Generated at 2022-06-22 04:21:53.062213
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
	from tornado.queues import Queue

	q = Queue()
	del q._unfinished_tasks
	q.__repr__()
	del q._getters
	del q._putters
	q.__repr__()
	del q._queue



# Generated at 2022-06-22 04:22:01.678961
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    q = Queue[int]()
    q.put_nowait(1)
    q.put_nowait(2)
    it = _QueueIterator[int](q)
    future_1 = asyncio.ensure_future(it.__anext__())
    future_2 = asyncio.ensure_future(it.__anext__())
    asyncio.get_event_loop().run_until_complete(future_1)
    asyncio.get_event_loop().run_until_complete(future_2)
    assert future_1.result() == 1
    assert future_2.result() == 2



# Generated at 2022-06-22 04:22:12.320365
# Unit test for method join of class Queue
def test_Queue_join():
    def _test():
        import asyncio
        import time
        from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
        asyncio_loop = asyncio.get_event_loop()
        AsyncIOMainLoop().install()
        asyncio_loop.set_debug(True)
        queue = Queue(4)
        start_time = time.time()
        async def _test_1():
            for i in range(5):
                print("Producing task %d" % i)
                await queue.put(i)
        async def _test_2():
            while True:
                item = await queue.get()
                try:
                    print("Doing work on %d" % item)
                    await gen.sleep(0.01)
                finally:
                    queue.task

# Generated at 2022-06-22 04:22:18.814179
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q.put_nowait(1)
    q.put_nowait(2)
    assert str(q) == "<Queue maxsize=0 queue=deque([1, 2])>"
    q.get_nowait()
    assert str(q) == "<Queue maxsize=0 queue=deque([2])>"



# Generated at 2022-06-22 04:22:23.905850
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert(q.maxsize == 0)
    assert(q.qsize() == 0)
    assert (not q.full())
    assert q.empty()


# Prioritized Queue (pq)

# Generated at 2022-06-22 04:22:28.313307
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    class Queue_test(Queue):
        def _init(self):
            self._queue = collections.deque([2, 5, 3, 4])

    q = Queue_test(maxsize=3)
    print(q.__repr__())

test_Queue___repr__()

# Generated at 2022-06-22 04:22:29.771871
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert QueueEmpty.__new__(QueueEmpty) is not None
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:22:36.282709
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    async def async_test():
        q = Queue()
        assert q.empty() == True
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        q.put(5)
        assert q.empty() == False
        async for e in q:
            assert (e == 1) or  (e == 2) or (e == 3) or (e == 4) or (e == 5)
        assert q.empty() == True
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(async_test)



# Generated at 2022-06-22 04:22:42.707829
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0
    q = Queue(maxsize=10)
    assert q.maxsize == 10
    try:
        Queue(maxsize=-1)
        assert False
    except ValueError:
        pass
    try:
        Queue(maxsize=-1.5)
        assert False
    except ValueError:
        pass
    try:
        Queue(maxsize=None)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 04:23:51.066346
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q_ = PriorityQueue()
    q_.put((1, 'medium-priority item'))
    q_.put((0, 'high-priority item'))
    q_.put((10, 'low-priority item'))
    q_.put((2, 'lowest-priority item'))
    print(q_.get_nowait())
    print(q_.get_nowait())
    print(q_.get_nowait())
    print(q_.get_nowait())



# Generated at 2022-06-22 04:23:54.481696
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait('hello')
    q.put_nowait('world')
    assert q.qsize() == 2


# Generated at 2022-06-22 04:24:03.596787
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q_empty = Queue()
    try:
        q_empty.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    q_full = Queue(maxsize=0)
    try:
        q_full.put_nowait(0)
        assert False
    except QueueFull:
        assert True
    assert q._format() == 'maxsize=0 queue=deque([]) getters[0] putters[0] tasks=0'


# Generated at 2022-06-22 04:24:12.137485
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    class MyQueue(Queue):
        def _init(self):
            self._queue = collections.deque()
        def _get(self):
            return self._queue.popleft()
        def _put(self, item):
            self._queue.append(item)
    q = MyQueue(4)
    for i in range(4):
        q.put_nowait(i)
    assert(q.qsize() == 4)
    q.put_nowait(5)
    assert(q.qsize() == 5)
    q.put_nowait(5)


# Generated at 2022-06-22 04:24:14.220757
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    
    e = QueueEmpty()
    assert str(e) == ""
    assert repr(e) == "<QueueEmpty>"


# Generated at 2022-06-22 04:24:25.727506
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        try:
            async for item in q:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
        finally:
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:24:28.418621
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except:
        pass



# Generated at 2022-06-22 04:24:30.205007
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=2)


# Generated at 2022-06-22 04:24:36.800416
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test that Queue.get_nowait() raises QueueEmpty if the queue is empty.
    empty_q = Queue()
    with pytest.raises(QueueEmpty):
        empty_q.get_nowait()
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)
    q.get_nowait()
    q.get_nowait()
    with pytest.raises(QueueEmpty):
        q.get_nowait()


# Generated at 2022-06-22 04:24:46.639004
# Unit test for method get of class Queue
def test_Queue_get():
    import time

    q = Queue()

    # test 1: get a value
    q.put(10)
    assert q.get() == 10

    # test 2: try to get a value from an empty queue, then put something
    # in the queue, then get it
    f = q.get()
    q.put(20)
    assert f.result() == 20

    # test 3: try to get a value from an empty queue, then put something in the
    # queue, then use get_nowait() to get it
    f = q.get()
    q.put(30)
    assert q.get_nowait() == 30

    # test 4: test the timeout argument of method get
    f = q.get()
    start = time.time()