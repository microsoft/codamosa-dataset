

# Generated at 2022-06-22 04:17:27.345468
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    obj = _QueueIterator(Queue())


# Generated at 2022-06-22 04:17:37.989155
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize = 1)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

# Generated at 2022-06-22 04:17:46.042612
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    itr = _QueueIterator(q)
    e = itr.__anext__()
    assert type(e) == Awaitable
    assert q.get_nowait() == 1
    q.put(1)
    e = itr.__anext__()
    assert type(e) == Awaitable
    assert q.get_nowait() == 1

# Generated at 2022-06-22 04:17:50.822510
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 2)
    q.put_nowait(10)
    q.put_nowait(9)


# Generated at 2022-06-22 04:17:52.467293
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:17:54.982236
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    if __name__ == "__main__":
        q = LifoQueue()
        q.put(3)
        q.put(2)
        q.put(1)
        print(q.get_nowait())
        print(q.get_nowait())
        print(q.get_nowait())


# Generated at 2022-06-22 04:18:00.854516
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("\nUnit test for method put_nowait of class Queue")
    some_queue = Queue(maxsize=0)
    try:
        some_queue.put_nowait(4)
    except QueueFull:
        print("Caught QueueFull Exception")
    else:
        print("No Exception was caught")


# Generated at 2022-06-22 04:18:12.200836
# Unit test for method qsize of class Queue
def test_Queue_qsize():
	q = Queue()
	assert(q.qsize() == 0)
	q.put(1)
	assert(q.qsize() == 1)
	q.get()
	assert(q.qsize() == 0)
	q.put(0)
	assert(q.qsize() == 1)
	q.put(1)
	assert(q.qsize() == 2)
	q.put(2)
	assert(q.qsize() == 3)
	q.put(3)
	assert(q.qsize() == 4)
	q.get()
	assert(q.qsize() == 3)
	q.get()
	assert(q.qsize() == 2)
	q.get()
	assert(q.qsize() == 1)
	q.get()

# Generated at 2022-06-22 04:18:14.606062
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=10)
    print(queue.maxsize)


# Generated at 2022-06-22 04:18:16.604310
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue
    q = LifoQueue()
    q.put(1)
    assert q.empty() is False
    assert q.full() is False
    assert q.qsize() == 1
    assert q.get_nowait() == 1
    assert q.qsize() == 0
    assert q.empty() is True

# Generated at 2022-06-22 04:18:34.981606
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q

# Generated at 2022-06-22 04:18:36.083415
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    msg = Queue(maxsize=2)

# Generated at 2022-06-22 04:18:42.314155
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0

    q = Queue()
    q.put(1)
    assert q.qsize() == 1

    q = Queue()
    q.put(1)
    q.get()
    assert q.qsize() == 0


# Generated at 2022-06-22 04:18:51.843858
# Unit test for method __str__ of class Queue
def test_Queue___str__():
   from collections import deque
   from tornado.queues import Queue
   q = Queue()
   assert q.__str__() == '<Queue maxsize=0>'
   q._queue = deque()
   assert q.__str__() == '<Queue maxsize=0 queue=deque([])>'
   q._getters = deque()
   assert q.__str__() == '<Queue maxsize=0 queue=deque([]) getters[0]>'
   q._putters = deque()
   assert q.__str__() == '<Queue maxsize=0 queue=deque([]) getters[0] putters[0]>'
   q._unfinished_tasks = 0

# Generated at 2022-06-22 04:18:53.913944
# Unit test for method get of class Queue
def test_Queue_get():
    ioloop.IOLoop.current().run_sync(Queue_get_test)

# Generated at 2022-06-22 04:18:59.839049
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    try:
        q = Queue()
        q.put_nowait('a')
        it = _QueueIterator(q)
        await it.__anext__()
        q.get_nowait()
        res = True
    except:
        res = False
    assert(res)
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:19:01.592788
# Unit test for method get of class Queue
def test_Queue_get():
  x = Queue()
  x.get(0)


# Generated at 2022-06-22 04:19:05.559578
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full() == True
    try:
        q.put_nowait(3)
    except QueueFull:
        assert True
    else:
        assert False


# Generated at 2022-06-22 04:19:18.247149
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    assert q.qsize() == 0

    q.put(1)
    assert q.get_nowait() == 1
    assert q.qsize() == 0

    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0

    q = Queue(maxsize=0)
    for i in range(5):
        q.put(i)

    assert q.get_nowait() == 0
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 2
# end of test_Queue_qsize

#

# Generated at 2022-06-22 04:19:21.708948
# Unit test for method full of class Queue
def test_Queue_full():
    # Test for method full (line 179)
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait('value')
    assert not q.full()
    q.put_nowait('value2')
    assert q.full()

# Generated at 2022-06-22 04:19:38.105543
# Unit test for method qsize of class Queue
def test_Queue_qsize(): 
  q = Queue(maxsize=2)

  async def consumer():
    async for item in q:
      try:
        print('Doing work on %s' % item)
        await gen.sleep(0)
      finally:
        q.task_done()

  async def producer():
    for item in range(5):
      await q.put(item)
      print('Put %s' % item)

  async def main():
    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

  ioloop.IOLoop.current().run_sync(main)

  assert q.q

# Generated at 2022-06-22 04:19:42.785158
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    l = LifoQueue()
    l.put(3)
    l.put(2)
    l.put(1)
    assert l.qsize() == 3
    assert l.get_nowait() == 1
    assert l.get_nowait() == 2
    assert l.get_nowait() == 3

# Generated at 2022-06-22 04:19:44.247863
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull()
    assert isinstance(q, Exception)


# Generated at 2022-06-22 04:19:47.220138
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass
    except:
        assert False



# Generated at 2022-06-22 04:19:54.577429
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado.queues
    q = tornado.queues.Queue()
    q.task_done()
    q.put_nowait(1)
    q.put_nowait(2)
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
test_Queue_task_done()

# Generated at 2022-06-22 04:20:00.647918
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0>"
    q = Queue(10)
    assert str(q) == "<Queue maxsize=10>"
    q = Queue()
    q.put_nowait(0)
    assert str(q) == "<Queue maxsize=0 queue=[0]>"
    q.get_nowait()
    assert str(q) == "<Queue maxsize=0>"

# Generated at 2022-06-22 04:20:02.010777
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    _QueueIterator(Queue())



# Generated at 2022-06-22 04:20:05.748278
# Unit test for method join of class Queue
def test_Queue_join(): 
    q = Queue(maxsize = 2)
    q._unfinished_tasks = -1 
    with pytest.raises(ValueError):
        q.join()

    q.join()


# Generated at 2022-06-22 04:20:13.047044
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
        
    ioloop.IOLoop.current().run_sync(main)
    assert q.qsize() == 2
test_Queue_qsize()


# Generated at 2022-06-22 04:20:25.011977
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue, QueueEmpty
    q = Queue()
    q.put(1)
    assert q.get_nowait() == 1
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 3
    q.put_nowait(4)
    try:
        q.put_nowait(5)
    except QueueFull:
        assert q.qsize() == 4
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4

# Generated at 2022-06-22 04:20:37.457885
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(0)
    q._queue = [1, 2]
    assert str(q) == "<Queue maxsize=0 queue=[1, 2] tasks=2>"



# Generated at 2022-06-22 04:20:38.940021
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        assert True



# Generated at 2022-06-22 04:20:39.964273
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    assert q.qsize() == 0



# Generated at 2022-06-22 04:20:44.552697
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq = PriorityQueue()
    pq.put((1, 'medium-priority item'))
    pq.put((0, 'high-priority item'))
    pq.put((10, 'low-priority item'))
    assert pq.get_nowait() == (0, 'high-priority item')
    assert pq.get_nowait() == (1, 'medium-priority item')
    assert pq.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-22 04:20:45.989130
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0


# Generated at 2022-06-22 04:20:48.386210
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    a = Queue()
    assert isinstance(a.__str__(), str)

# Generated at 2022-06-22 04:20:55.253778
# Unit test for method empty of class Queue
def test_Queue_empty():
    import random
    q = Queue()
    assert q.empty()
    q.put_nowait(1)
    assert not q.empty()
    q.get_nowait()
    assert q.empty()
    q = Queue()
    assert q.empty()
    q.put_nowait(1)
    assert not q.empty()
    q.put_nowait(1)
    assert not q.empty()
    q.get_nowait()
    assert not q.empty()
    q.get_nowait()
    assert q.empty()
    q = Queue()
    assert q.empty()
    q.put_nowait(1)
    assert not q.empty()
    q.put_nowait(1)
    assert not q.empty()

# Generated at 2022-06-22 04:21:01.341211
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    with pytest.raises(TypeError):
        _QueueIterator()
        _QueueIterator(None)
        _QueueIterator(
            q="My Queue"
        )  # type: ignore[arg-type] # cannot be tested as will fail without typeddict or run-time checking
    from .queues import Queue
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)



# Generated at 2022-06-22 04:21:11.325383
# Unit test for method empty of class Queue
def test_Queue_empty():
    import tornado
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    # Start with a clean IOLoop
    print("cleaning IOLoop...")
    IOLoop.clear_instance()
    IOLoop.clear_current()
    ioloop_ = IOLoop.instance()

    # Create a queue with maxsize=2
    q = Queue(maxsize=2)
    # Put 0, 1 into the queue
    print("putting 0, 1 into the queue")
    q.put_nowait(0)
    q.put_nowait(1)
    # The queue is full, put 2 into the queue using put
    print("putting 2 into the queue")
    future = q.put(2)

# Generated at 2022-06-22 04:21:23.418703
# Unit test for method join of class Queue
def test_Queue_join():
    print('start test_Queue_join')
    #
    def consumer():
        print('consumer start')
        yield q.get()
        q.task_done()
        print('consumer done')
    #
    def producer():
        print('producer start')
        yield q.put(None)
        print('producer done')
    #
    def main():
        print('main start')
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks.
        print('main done')
    #
    q = Queue()
    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-22 04:21:35.521734
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue()
    print(queue)
    # <Queue at 0x7fa772cbcbe0 empty>



# Generated at 2022-06-22 04:21:43.338997
# Unit test for method join of class Queue
def test_Queue_join():
    test_result = None
    try:
        import asyncio
        import tornado
        import tornado.queues
        import tornado.platform.asyncio

        def finish(future):
            return future.result()

        async def waiter():
            await tornado.queues.Queue().join()
            return 1

        tornado.platform.asyncio.AsyncIOMainLoop().install()
        test_result = tornado.ioloop.IOLoop.current().run_sync(finish, waiter())
    except Exception as e:
        test_result = e
    finally:
        print("test_Queue_join() {}".format(test_result))


# Generated at 2022-06-22 04:21:47.210845
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()

    print("the type of q is ", type(q))

    test_dict = {'a': 1}
    q.put(test_dict)


    #assert q.get_nowait() == test_dict, "class Queue get_nowait test failed"


test_Queue_get_nowait()



# Generated at 2022-06-22 04:21:59.416317
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from . import Queue
    
    # Empty Queue.
    q = Queue()
    i = q.__aiter__()
    assert await i.__anext__() == None

    # Non-empty Queue.
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    i = q.__aiter__()
    assert await i.__anext__() == 1
    assert await i.__anext__() == 2
    assert await i.__anext__() == 3

    # Queue that is filled during iteration.
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    i = q.__aiter__()
    assert await i.__anext__

# Generated at 2022-06-22 04:22:03.990106
# Unit test for constructor of class Queue
def test_Queue():
    maxsize = 10
    q = Queue(maxsize)
    assert q.qsize() == 0



# Generated at 2022-06-22 04:22:11.730230
# Unit test for method full of class Queue
def test_Queue_full():
    """Unit test for method full of class Queue"""
    q = Queue()
    assert q.full() == False
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full() == False

    q = Queue(maxsize=3)
    assert q.full() == False
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.full() == True
    q.get_nowait()
    assert q.full() == False

# Generated at 2022-06-22 04:22:20.829668
# Unit test for method full of class Queue
def test_Queue_full():
    import time
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       #

# Generated at 2022-06-22 04:22:30.527164
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q._put(1)
    q._put(2)
    q._put(3)
    it = _QueueIterator(q)
    print(ioloop.IOLoop.current().run_sync(it.__anext__))
    print(ioloop.IOLoop.current().run_sync(it.__anext__))
    print(ioloop.IOLoop.current().run_sync(it.__anext__))
    try:
        print(ioloop.IOLoop.current().run_sync(it.__anext__))
    except QueueEmpty:
        print("QueueEmpty")
# test__QueueIterator()


# Generated at 2022-06-22 04:22:43.312225
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Test empty, no maxsize
    q = Queue()                                          # type: ignore
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"

    # Test empty, with maxsize
    q = Queue(maxsize=123)                               # type: ignore
    assert str(q) == "<Queue maxsize=123 queue=deque([])>"

    # Test non-empty, no maxsize
    q = Queue()                                          # type: ignore
    for i in range(10):
        q.put_nowait(i)
    assert str(q) == "<Queue maxsize=0 queue=deque([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])>"

    # Test non-empty, with maxsize
    q = Queue(maxsize=123)

# Generated at 2022-06-22 04:22:48.123826
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    result = assert_raises(QueueFull, lambda: put_nowait(q, 1))
    print("Test Value: ",result)

# Generated at 2022-06-22 04:23:01.453226
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    def p():
        print("Entering producer")
        print(q.put(1))
    p()



# Generated at 2022-06-22 04:23:03.555563
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:23:08.065301
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()

    def run():
        async def add():
            await q.put(1)
            await q.put(2)
            await q.put(3)
            await q.put(None)

        async def get():
            it = _QueueIterator(q)
            result = []
            async for i in it:
                result.append(i)
            assert result == [1, 2, 3]

        io_loop = ioloop.IOLoop.current()
        io_loop.run_sync(lambda: (add(), get()))

    run()



# Generated at 2022-06-22 04:23:11.970293
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    future = Future()
    try:
        q.put_nowait(future)
    except QueueFull:
        pass
    else:
        assert False



# Generated at 2022-06-22 04:23:15.339373
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    exception = QueueEmpty()
    assert isinstance(exception, Exception)
    assert str(exception) == ""



# Generated at 2022-06-22 04:23:16.828997
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2



# Generated at 2022-06-22 04:23:17.558193
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:23:18.423598
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    return q.empty()

# Generated at 2022-06-22 04:23:28.856988
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado import testing
    import unittest

    def assertIn(member, container):
        assert member in container

    @testing.gen_test
    def test_queue_iteration():
        q = Queue()
        q.put(1)
        q.put(2)
        # test iter
        q_iter = iter(q)
        assertIn(1, q_iter)
        assertIn(2, q_iter)

        # test anext
        # Note: cannot use assertIn here because anext is a coroutine
        q_iter = iter(q)
        assert (yield q_iter.__anext__()) == 1
        assert (yield q_iter.__anext__()) == 2

    if __name__ == "__main__":
        unittest.main()



# Generated at 2022-06-22 04:23:29.501728
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-22 04:23:48.483331
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    @gen.coroutine
    def test():
        yield q.put(1)
        assert (yield q.__aiter__().__anext__()) == 1
        q.task_done()


    IOLoop.current().run_sync(test)

# Generated at 2022-06-22 04:23:52.557700
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    assert queue.empty() == True
    queue.put_nowait(None)
    assert queue.empty() == False
    queue.put_nowait(None)
    assert queue.empty() == False


# Generated at 2022-06-22 04:23:53.721736
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull()
    assert(isinstance(q, Exception))


# Generated at 2022-06-22 04:23:59.622932
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        return "Fail"
    except QueueFull:
        pass
    try:
        q.put_nowait(4)
        return "Fail"
    except QueueFull:
        pass
    return "Pass"

print(test_Queue_put_nowait())


# Generated at 2022-06-22 04:24:02.701456
# Unit test for method __str__ of class Queue
def test_Queue___str__():

    # Test that Queue.__str__ method works

    assert True == True



# Generated at 2022-06-22 04:24:09.846768
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert q.__repr__() == "<Queue at 0x%x maxsize=0>" % id(q)
    assert q.__str__() == "<Queue maxsize=0>"
    q = Queue(maxsize=1)
    assert q.__repr__() == "<Queue at 0x%x maxsize=1>" % id(q)
    assert q.__str__() == "<Queue maxsize=1>"



# Generated at 2022-06-22 04:24:15.225785
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    try:
        q.put_nowait(1)
    except QueueFull:
        pass



# Generated at 2022-06-22 04:24:20.369153
# Unit test for method get of class Queue
def test_Queue_get():
    if True:
        import tornado.ioloop
        io_loop = tornado.ioloop.IOLoop.current()
        Queue_instance0 = Queue(maxsize=0)
        Queue_instance0._init()
        Queue_instance0._getters.append(Future())
        assert Queue_instance0._getters[0].result() == None


# Generated at 2022-06-22 04:24:31.843639
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert str(q) == "<Queue empty queue>"
    assert q.get_nowait() == None
    assert q.empty() == True
    assert q.qsize() == 0
    # assert len(q._getters) == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.full() == True
    assert q.qsize() == 1
    # assert len(q._getters) == 0
    # assert len(q._putters) == 0
    assert q.get_nowait() == 2
    assert q.empty() == True
    assert q.qsize() == 0



# Generated at 2022-06-22 04:24:34.593049
# Unit test for constructor of class QueueFull
def test_QueueFull():
    raise QueueFull('test Msg')


# Generated at 2022-06-22 04:25:06.043539
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.concurrent import Future
    from tornado.queues import Queue as Queue_
    from typing import Any
    # The inspection is able to resolve the generics.
    queue = Queue_()  # type: Queue_[Any]
    queue.__aiter__()  # type: _QueueIterator



# Generated at 2022-06-22 04:25:13.139936
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-22 04:25:15.485822
# Unit test for constructor of class Queue
def test_Queue():
    xs = Queue(maxsize=0)


# Generated at 2022-06-22 04:25:16.823043
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    iter = _QueueIterator(q)
    assert iter.q == q



# Generated at 2022-06-22 04:25:21.599131
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    myqueue = Queue()
    myqueue.put_nowait(1)
    assert myqueue.qsize() == 1
    myqueue.put_nowait(2)
    assert myqueue.qsize() == 2
    myqueue.put_nowait(3)
    assert myqueue.qsize() == 3


# Generated at 2022-06-22 04:25:32.763073
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=0 queue=deque([1])>"
    q.task_done()
    q.maxsize = 10
    q.put_nowait(2)
    q.get_nowait()
    assert str(q) == "<Queue maxsize=10 queue=deque([])>"
    q.put(1, tornado.ioloop.IOLoop.current().time()+10)
    q.put(1, tornado.ioloop.IOLoop.current().time()+10)
    assert str(q) == "<Queue maxsize=10 queue=deque([]) getters[1] putters[2] tasks=2>"

# Generated at 2022-06-22 04:25:38.652931
# Unit test for method get of class Queue
def test_Queue_get():
    pass
    ## tornado.testing.gen_test
    ## (gen.coroutine(self) -> typing.Generator[typing.Any, None, None])
    ## Coroutine that returns the result of this `.Future`.
    ##
    ## If the result isn't yet available, the coroutine will wait until it is.
    ## If the future was cancelled, raises `tornado.gen.CancelledError`.
    ## If the result is a failure, that exception will be raised.
    ##
    ## This method can be used in a ``with`` statement. If the coroutine exits
    ## without yielding, the `.Future` has completed successfully. If a yielded
    ## value is ``None``, the `.Future` has completed successfully. If a
    ## yielded value is not ``None``, it must be an exception subclass; this
    ## exception will be

# Generated at 2022-06-22 04:25:39.934931
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    assert(q.maxsize == 0)


# Generated at 2022-06-22 04:25:42.091203
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    q.qsize

# Generated at 2022-06-22 04:25:44.911853
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=0)
    print(q.qsize())


# Generated at 2022-06-22 04:26:15.014067
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import pytest
    from tornado.ioloop import IOLoop, PeriodicCallback
    from tornado.queues import QueueEmpty

    class QueueTestClass(Queue):
        def __init__(self, maxsize):
            super(QueueTestClass, self).__init__(maxsize)
            self.is_called = False
            self.get_nowait_called = 0

            self.get_nowait_called = 0

        def get_nowait(self):
            self.get_nowait_called += 1
            return super(QueueTestClass, self).get_nowait()

        def _get(self):
            return super(QueueTestClass, self)._get()

    # Test get_nowait when queue is empty.
    #   Pre-condition:
    #       queue is empty
    #   Operation:
    #

# Generated at 2022-06-22 04:26:17.095558
# Unit test for method __repr__ of class Queue
def test_Queue___repr__(): Queue().__repr__()
Queue().__repr__()


# Generated at 2022-06-22 04:26:21.643393
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3


# Generated at 2022-06-22 04:26:23.869039
# Unit test for constructor of class Queue
def test_Queue(): # type: ignore
    q = Queue(10)
    assert q.maxsize == 10
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()


# Generated at 2022-06-22 04:26:28.755236
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    for i in range(4):
        q.put_nowait(i)
    qi = _QueueIterator(q)
    assert [i async for i in qi] == list(range(4))
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:26:35.297073
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.full() == False
    assert q.qsize() == 0
    q._queue.append('a')
    assert q.full() == False
    assert q.qsize() == 1
    q.put_nowait('b')
    assert q.full() == False
    assert q.qsize() == 2
    q._getters.append(Future())
    try:
        q.put_nowait('c')
    except QueueFull:
        assert True
    else:
        assert False

# Generated at 2022-06-22 04:26:36.372570
# Unit test for method put of class Queue
def test_Queue_put():
    pass


# Generated at 2022-06-22 04:26:38.680654
# Unit test for method empty of class Queue
def test_Queue_empty():
    Queue()



# Generated at 2022-06-22 04:26:41.938041
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.qsize() == 0
    q.put_nowait(0)
    q.get_nowait() == 0
    q.get_nowait()
    q.join()
