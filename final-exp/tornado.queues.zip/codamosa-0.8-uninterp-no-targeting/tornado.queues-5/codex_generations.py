

# Generated at 2022-06-22 04:17:20.110075
# Unit test for constructor of class Queue
def test_Queue():

    q = Queue(maxsize=2)
    print(q.maxsize)
    print(q._queue)



# Generated at 2022-06-22 04:17:24.124470
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    
    
    q = Queue(maxsize=2)

    x = q.__repr__()
    
    assert x == "<Queue at 0x7f4b5411b598 maxsize=2>"




# Generated at 2022-06-22 04:17:27.223580
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.__put_internal(2)
    assert q.get_nowait()==2


# Generated at 2022-06-22 04:17:28.632528
# Unit test for method join of class Queue
def test_Queue_join():
 awaitable = Queue().join()
 awaitable.add_done_callback()



# Generated at 2022-06-22 04:17:40.871378
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()

    assert repr(q) == "<Queue at 0x%x maxsize=0>" % id(q)

    q.put_nowait(10)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[10]>" % id(q)

    q.__put_internal(20)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[10, 20]>" % id(q)

    q._getters.append(Future())
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[10, 20] getters[1]>" % id(q)

    q._putters.append((30, Future()))

# Generated at 2022-06-22 04:17:46.043632
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    global q
    global io_loop

# Generated at 2022-06-22 04:17:52.684872
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    q = None #singleton# Queue()
    it = _QueueIterator(q)
    res = it.__anext__()
    assert isinstance(res, Awaitable[_T])
    # TODO: __anext__ is async and cannot be tested yet.



# Generated at 2022-06-22 04:18:03.916935
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    def test_fn(q):
        q.put_nowait(1)
        q.put_nowait(2)
        #import pdb; pdb.set_trace()
        assert q._putters == deque([])
        assert q._getters == deque([])
        assert q.qsize() == 2

        item = q.get_nowait()
        assert item == 1
        assert q.qsize() == 1
        assert q._putters == deque([])
        assert q._getters == deque([])

        item = q.get_nowait()
        assert item == 2
        assert q.qsize() == 0
        assert q

# Generated at 2022-06-22 04:18:11.163161
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    maxsize = 10
    q.maxsize = maxsize
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() == False
    q.put(1)
    assert q.qsize() == 2
    assert q.empty() == False
    q.task_done()
    assert q.qsize() == 1
    assert q.empty() == False


# Generated at 2022-06-22 04:18:21.709920
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert q.full() == False
    assert q.empty() == True
    q.put("a")
    assert q.full() == False
    assert q.empty() == False
    q.put("b")
    assert q.full() == False
    assert q.empty() == False
    q = Queue(maxsize = 2)
    assert q.full() == False
    assert q.empty() == True
    q.put("a")
    assert q.full() == False
    assert q.empty() == False
    q.put("b")
    assert q.full() == True
    assert q.empty() == False
    q.get()
    assert q.full() == False
    assert q.empty() == False
    q.get()



# Generated at 2022-06-22 04:18:37.554175
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import tornado.concurrent
    import tornado.locks
    import tornado.platform.asyncio
    import asyncio
    import inspect
    import logging
    import unittest

    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future, is_future

    async def async_consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                # await gen.sleep(0.01)
            finally:
                q.task_done()
    
    


# Generated at 2022-06-22 04:18:40.321249
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    LifoQueue()

# Generated at 2022-06-22 04:18:45.592370
# Unit test for method put of class Queue
def test_Queue_put():
    print("test_Queue_put")
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    try:
        q.put(3)
    except QueueFull:
        print("Queue is full")
try:
    test_Queue_put()
except:
    print("test_Queue_put is crashed!")



# Generated at 2022-06-22 04:18:49.843536
# Unit test for method get of class Queue
def test_Queue_get():
    qq = Queue()
    def callback():
        print(qq.get())

    qq.put(1)
    qq.put(2)


    ioloop.IOLoop.current().add_callback(callback)
    ioloop.IOLoop.current().start()



# Generated at 2022-06-22 04:18:52.012459
# Unit test for constructor of class QueueFull
def test_QueueFull():
    def foo():
        try:
            raise QueueFull
        except Exception:
            pass

    foo()



# Generated at 2022-06-22 04:18:57.487675
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    async def async_test():
        q = Queue()
        for i in range(3): await q.put(i)
        async for n in q:
            assert n == 0 or n == 1 or n == 2
    ioloop.IOLoop.current().run_sync(async_test)
    print("test_test_Queue___aiter__()")
test_Queue___aiter__()


# Generated at 2022-06-22 04:19:07.577411
# Unit test for method get of class Queue
def test_Queue_get():
    import unittest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    class testQueue(unittest.TestCase):
        def setUp(self):
            print("Set up test environment.")

        def tearDown(self):
            print("Clear test environment.")

        def test_1(self):
            q = Queue(maxsize=2)

            async def consumer():
                async for item in q:
                    try:
                        print('Doing work on %s' % item)
                        await gen.sleep(0.01)
                    finally:
                        q.task_done()

            async def producer():
                for item in range(5):
                    await q.put(item)
                    print('Put %s' % item)


# Generated at 2022-06-22 04:19:12.278225
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    for i in range(2):
        q.put_nowait(i)
    assert q.full()
    with pytest.raises(QueueFull):
        q.put_nowait(None)

# Generated at 2022-06-22 04:19:16.388878
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    #print(q.maxsize)
    #print(q.qsize())
    #print(q.empty())
    #print(q.full())
    #print(q.put(1, timeout=-1))


# Generated at 2022-06-22 04:19:27.239671
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:52.197645
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    for x in range(0, 10):
        q = PriorityQueue()
        q.put((1, 'medium-priority item'))
        q.put((0, 'high-priority item'))
        q.put((10, 'low-priority item'))
        assert(q.get_nowait() == (0, 'high-priority item'))
        assert(q.get_nowait() == (1, 'medium-priority item'))
        assert(q.get_nowait() == (10, 'low-priority item'))

test_PriorityQueue()


# Generated at 2022-06-22 04:19:53.670210
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=4)
    print(q)


# Generated at 2022-06-22 04:19:54.976641
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception:
        pass



# Generated at 2022-06-22 04:20:01.037849
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

# Generated at 2022-06-22 04:20:02.048596
# Unit test for constructor of class QueueFull
def test_QueueFull():
    m = QueueFull()



# Generated at 2022-06-22 04:20:03.974444
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False



# Generated at 2022-06-22 04:20:07.598608
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    assert i.q is q

QueueType = typing.TypeVar("QueueType", bound=Queue)


# Generated at 2022-06-22 04:20:10.083380
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	print("Test method 'get_nowait'")
	q = Queue()
	q.put(1)
	assert q.get_nowait() == 1


# Generated at 2022-06-22 04:20:22.571104
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.gen import coroutine

    q = Queue(maxsize=2)

    @coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

   

# Generated at 2022-06-22 04:20:30.336617
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert (0, 'high-priority item') == q.get_nowait()
    assert (1, 'medium-priority item') == q.get_nowait()
    assert (10, 'low-priority item') == q.get_nowait()

test_PriorityQueue()



# Generated at 2022-06-22 04:21:04.092704
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    i = _QueueIterator(Queue())
    gen.convert_yielded(i.__anext__())


# Generated at 2022-06-22 04:21:09.595223
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Receive an expected value when the queue is not empty
    q = Queue()
    q.put_nowait(1)
    v = q.get_nowait()
    # TODO: Check "v == 1"
    # Receive nothing when the queue is empty
    q = Queue()
    # TODO: Check "q.get_nowait() raises exception QueueEmpty"




# Generated at 2022-06-22 04:21:12.978780
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # Test the method __anext__ of the class _QueueIterator
    # Return the value of the test
    return None


# Generated at 2022-06-22 04:21:14.866145
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # TODO: implements test_Queue_task_done
    raise NotImplementedError()


# Generated at 2022-06-22 04:21:19.983052
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    l = len(q._queue)
    assert q._unfinished_tasks == 0
    assert q._finished.is_set() == True
    q.task_done()
    assert q._unfinished_tasks == -1
    assert q._finished.is_set() == True



# Generated at 2022-06-22 04:21:32.118140
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import logging
    import tornado.gen
    import tornado.ioloop

    logger = logging.getLogger('test_Queue_task_done')
    @tornado.gen.coroutine
    def consumer():
        try:
            for n in range(4):
                item = yield q.get()
                logger.debug('Doing work on %d' %item)
                yield tornado.gen.sleep(0.01)
                q.task_done()
        except Exception as ex:
            print(ex)

    @tornado.gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            logger.debug('Put %d' % item)


# Generated at 2022-06-22 04:21:35.988270
# Unit test for constructor of class Queue
def test_Queue():
    from tornado.queues import Queue
    q = Queue(maxsize=3)
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()
    assert q.maxsize == 3


# Generated at 2022-06-22 04:21:44.570701
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    @gen.coroutine
    def foo():
        q = Queue()
        with pytest.raises(QueueEmpty):
            yield q.get()

        q.put_nowait(1)
        q.put_nowait(2)
        assert (yield q.get()) == 1
        assert (yield q.get()) == 2
        with pytest.raises(QueueEmpty):
            yield q.get()

        # Ensure that the queue is now empty.
        assert list(q) == []

        # Test the __aiter__ method of the class Queue
        for k in q:
            assert k == 1


if typing.TYPE_CHECKING:
    # For mypy type-checking.

    T = TypeVar("T")



# Generated at 2022-06-22 04:21:49.897014
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__() == '<Queue maxsize=0 queue=deque([])>'
    q.put_nowait(3)
    assert q.__str__() == '<Queue maxsize=0 queue=deque([3])>'

# Generated at 2022-06-22 04:21:59.998701
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)
    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()  # Wait for producer to put all tasks.
        yield q.join()  # Wait for consumer to finish all tasks.

# Generated at 2022-06-22 04:23:15.070225
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    task_done = []
    async def main(q,task_done):
        await q.put(1)
        await q.put(2)
        await q.put(3)
        while q.qsize():
            item = await q.get()
            print ("Doing work on %s \n" % item)
            task_done.append(item)
            await ioloop.IOLoop.current().sleep(0.1)

        print(task_done)
    ioloop.IOLoop.current().run_sync(lambda: main(q,task_done))


# Generated at 2022-06-22 04:23:16.567407
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    return q.__repr__()



# Generated at 2022-06-22 04:23:19.784676
# Unit test for method full of class Queue
def test_Queue_full():
    a = Queue(10)
    b = Queue(0)
    for i in range(11):
        a.put(i)
        b.put(i)
    assert a.full() == True
    assert b.full() == False

# Generated at 2022-06-22 04:23:20.901458
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()



# Generated at 2022-06-22 04:23:23.373331
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    for i in range(5):
        q.put(i)
        print('Put %s' % i)
test_Queue_put_nowait()


# Generated at 2022-06-22 04:23:29.699925
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    import random
    q = Queue(maxsize=2)
    assert q.full() == False
    q.put(1)
    q.put(2)
    assert q.full() == True
    q.get()
    assert q.full() == False
    q.put(3)
    assert q.full() == True


# Generated at 2022-06-22 04:23:34.144493
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    i = 1
    q: Queue[int] = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    for e in _QueueIterator(q):  
        assert e == i
        print(i)
        i += 1

test__QueueIterator()


# Generated at 2022-06-22 04:23:39.995444
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import pytest
    q = Queue()
    with pytest.raises(QueueEmpty):
        q.get_nowait()

    q2 = Queue()
    q2.put_nowait(1)
    assert q2.get_nowait() == 1
    with pytest.raises(QueueEmpty):
        q2.get_nowait()



# Generated at 2022-06-22 04:23:43.027535
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    
    
    
    
    
    
    
    
    
    
    
    pass


# Generated at 2022-06-22 04:23:43.905968
# Unit test for method empty of class Queue
def test_Queue_empty():
    pass


# Generated at 2022-06-22 04:26:13.557769
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    """A `.Queue` that retrieves entries in priority order, lowest first.

    Entries are typically tuples like ``(priority number, data)``.
    """

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 04:26:24.693367
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-22 04:26:34.013766
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    #@type: Future
    f = q.get(timeout=1)
    # Check type of Future in get.
    assert isinstance(f, Future)
    # Check that get returns a Future.
    assert f.done() == False
    # Check that the Future is not done when it is returned from get.
    q.put_nowait(1)
    # Put item into the queue to be able to get it.
    assert not f.done()
    # Check the Future returned from get is done now that an item has been putted into the queue.


# Generated at 2022-06-22 04:26:35.072974
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    assert str(Queue()) == "<Queue maxsize=0 tasks=0>"


# Generated at 2022-06-22 04:26:41.537620
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    assert q.qsize() == 1
    assert q._queue[0] == 1
    q.put(2)
    assert q.qsize() == 2
    assert q._queue[0] == 1
    assert q._queue[1] == 2
    assert q._unfinished_tasks == 2
    
    


# Generated at 2022-06-22 04:26:45.628683
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    try:
        res = q.get_nowait()
    except QueueEmpty as e:
        res = e
    return res == 1