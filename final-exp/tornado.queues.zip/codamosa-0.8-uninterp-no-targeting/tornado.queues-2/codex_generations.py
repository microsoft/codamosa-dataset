

# Generated at 2022-06-22 04:17:08.574038
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    print(q.qsize())
    q.put_nowait(1)
    q.put_nowait(2)
    print(q.qsize())
    q.put_nowait(3)
    print(q.qsize())



# Generated at 2022-06-22 04:17:20.563687
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # set parameters and expectations
    maxsize = 5
    q = Queue(maxsize)
    # execute methods and check returned values
    # check 1
    assert q.empty()
    assert not q.full()
    # put_nowait
    q.put_nowait(0)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    # check 2
    assert not q.empty()
    assert q.full()
    # put_nowait: raise QueueFull
    try:
        q.put_nowait(5)
        assert False
    except QueueFull:
        pass



# Generated at 2022-06-22 04:17:30.153767
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test

    class TestQueue(AsyncTestCase):
        @gen_test
        def test_full(self):
            q = Queue(maxsize=2)
            self.assertFalse(q.full())
            q.put_nowait(1)
            self.assertFalse(q.full())
            q.put_nowait(2)
            self.assertTrue(q.full())
            q.get_nowait()
            self.assertFalse(q.full())

    return unittest.main()

# Generated at 2022-06-22 04:17:33.322377
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    x = yield from it.__anext__()
    assert x == 1


# Generated at 2022-06-22 04:17:43.242684
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Create an instance of Queue
    queue = Queue()
    # Create an instance of tornado.testing.AsyncTestCase
    test = AsyncTestCase()
    try:
        # Call method, which should raise NotImplementedError
        queue.__aiter__()
    except NotImplementedError:
        # Success: __aiter__() raised NotImplementedError
        pass
    else:
        # Failure: __aiter__() did not raise NotImplementedError
        test.fail('Expected NotImplementedError not raised')

# Generated at 2022-06-22 04:17:47.737027
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import inspect
    #This is bad practice but otherwise I cant test it as it is a method of a class
    args = inspect.getfullargspec(_QueueIterator.__anext__)[0]
    assert args == ['self']#, 'q'], "__anext__ takes 2 arguments"


# Generated at 2022-06-22 04:17:57.480752
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    m = Queue(maxsize=10)
    assert m.qsize() == 0
    m.put(1)
    assert m.qsize() == 1
    m.put(2)
    m.put(3)
    assert m.qsize() == 3
    m.get()
    m.get()
    m.get()
    assert m.qsize() == 0
    m.put(1)
    m.put(2)
    m.put(3)
    assert m.qsize() == 3
    m.get()
    m.get()
    m.get()
    assert m.qsize() == 0

# Generated at 2022-06-22 04:18:00.562888
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    f = q.full()
    g = q.full()
    assert f == g == False

# Generated at 2022-06-22 04:18:06.512767
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    numOfItems=10
    q = Queue(numOfItems)
    counter=0
    while counter<numOfItems:
        q.put_nowait(counter)
        counter=counter+1
    counter=0
    while counter<numOfItems:
        q.get_nowait()
        counter=counter+1
    assert q.qsize()==0
test_Queue_qsize()



# Generated at 2022-06-22 04:18:07.898502
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)



# Generated at 2022-06-22 04:18:22.991832
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=0)
    assert q.full() == False
    q = Queue(maxsize=2)
    assert q.full() == False
    q.put(1)
    q.put(2)
    assert q.full() == True


# Generated at 2022-06-22 04:18:24.166618
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(2)
    q.qsize()


# Generated at 2022-06-22 04:18:34.918205
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test if Queue has the method put_nowait
    queue = Queue(maxsize=10)
    # if queue.put_nowait():
    #     print("Success")
    # else:
    #     print("Failure")

    # Test if the method put_nowait is raising exception QueueFull
    try:
        for i in range(queue.maxsize):
            queue.put_nowait(i)
        queue.put_nowait(6)
    except QueueFull as Q:
        print("Queue is Full")
    except:
        print("Exception")

    # Test if the method put_nowait is not raising exception QueueFull
    for i in range(queue.maxsize):
        try:
            queue.put_nowait(i)
        except QueueFull:
            print("Exception")
       

# Generated at 2022-06-22 04:18:46.431223
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future

    class MockQueue():
        def __init__(self, data: typing.List[typing.Any]):
            self.data = data
            self.get_future: Optional[asyncio.Future] = None

        async def get(self) -> typing.Any:
            data = self.data
            if not data:
                return
            else:
                return data.pop(0)

    data = list(range(5))
    q = MockQueue(data)
    it = _QueueIterator(q)
    loop = asyncio.get_event_loop()
    tasks = []
    for i in range(5):
        task = loop.create_task(it.__anext__())
        tasks.append(task)
   

# Generated at 2022-06-22 04:18:49.330801
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = gen.Queue(1)
    q.put('hello')
    try:
        q.put_nowait('world')
    except QueueFull:
        pass



# Generated at 2022-06-22 04:18:52.287746
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

test_PriorityQueue()



# Generated at 2022-06-22 04:18:56.097919
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    queue = Queue()
    queue._init()
    queue.put(1)
    queue.put(2)
    queue.get()
    queue.task_done()
    assert queue._unfinished_tasks == 1

# Generated at 2022-06-22 04:18:59.670976
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait("Hello")
    assert queue.get_nowait() == "Hello"

# Generated at 2022-06-22 04:19:04.946249
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    q._queue = collections.deque([1, 2, 3, 4, 5])
    q._getters = collections.deque([1])
    q._putters = collections.deque(['a'])
    assert str(q) == '<Queue maxsize=0 queue=deque([1, 2, 3, 4, 5]) getters[1] putters[1]>'



# Generated at 2022-06-22 04:19:12.367853
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()


# Generated at 2022-06-22 04:19:24.326556
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = QueueEmpty()



# Generated at 2022-06-22 04:19:27.005416
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    for x in range(5):
        q.put_nowait(x)
    assert q.qsize() == 2


# Generated at 2022-06-22 04:19:31.453986
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at 0x%x maxsize=2>" % id(q)



# Generated at 2022-06-22 04:19:35.528918
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q._maxsize == 0
    assert q._queue == None
    assert q._getters == collections.deque()
    assert q._putters == collections.deque()
    assert q._unfinished_tasks == 0
    assert q._finished == Event()
    assert q._finished.is_set() == True


# Generated at 2022-06-22 04:19:38.705052
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert len(q) == 0
    assert q.qsize() == 0


# Generated at 2022-06-22 04:19:41.525098
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as f:
        print("test QueueFull: ", f)


# Generated at 2022-06-22 04:19:47.963574
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


    ioloop.IOLoop.current().run_sync(main)
import typing


# Generated at 2022-06-22 04:19:52.801772
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()


# Generated at 2022-06-22 04:20:00.466952
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue()
    assert str(queue) == "<Queue maxsize=0 queue=[]>"
    queue.put('1')
    assert str(queue) == "<Queue maxsize=0 queue=['1']>"
    queue.put('2')
    assert str(queue) == "<Queue maxsize=0 queue=['1', '2']>"
    queue.get()
    assert str(queue) == "<Queue maxsize=0 queue=['2']>"
    queue.get()
    assert str(queue) == "<Queue maxsize=0 queue=[]>"



# Generated at 2022-06-22 04:20:03.337942
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("queue is full", 10)
    except QueueFull as ex:
        pass



# Generated at 2022-06-22 04:20:20.962429
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    st = '<Queue at 0x1d43b6e9410 maxsize=0 queue=deque([1, 2, 3])>'
    q = Queue(maxsize=0)
    q.__put_internal(1)
    q.__put_internal(2)
    q.__put_internal(3)
    assert q.__repr__() == st

# Generated at 2022-06-22 04:20:23.761009
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # must be async
    q = Queue()
    i = _QueueIterator(q)
    assert isinstance(i.__anext__(), Awaitable)



# Generated at 2022-06-22 04:20:25.079157
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=3)
    # print(q._putters)



# Generated at 2022-06-22 04:20:27.691959
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    assert str(qe) == "QueueEmpty"
    assert repr(qe) == "QueueEmpty()"



# Generated at 2022-06-22 04:20:29.411425
# Unit test for method empty of class Queue
def test_Queue_empty():
    maxsize = 0
    q = Queue(maxsize)
    assert q.empty() == True


# Generated at 2022-06-22 04:20:31.469580
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(0)
    it = _QueueIterator(q)
    print(it.q)



# Generated at 2022-06-22 04:20:32.760228
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()


# Generated at 2022-06-22 04:20:40.028957
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    str_of_Queue_empty = Queue().__str__()
    assert str_of_Queue_empty == '<Queue maxsize=0 queue=deque([])>'
    str_of_Queue_with_items = Queue(maxsize=2).__str__()
    assert str_of_Queue_with_items == '<Queue maxsize=2 queue=deque([])>'
    str_of_Queue_full = Queue(maxsize=2).__str__()
    assert str_of_Queue_full == '<Queue maxsize=2 queue=deque([])>'



# Generated at 2022-06-22 04:20:47.328844
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)

    assert str(q) == "<Queue at 0x%x maxsize=2>" % id(q)

    q = Queue(maxsize=None)

    def f():
        return "<Queue at 0x%x maxsize=None>" % id(q)
    assert str(q) == f()

    q = Queue(maxsize=0)

    def f():
        return "<Queue at 0x%x maxsize=0>" % id(q)
    assert str(q) == f()


# Generated at 2022-06-22 04:20:52.637304
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.maxsize == 0
    assert q.qsize() == 0
    assert not q.full()
    assert q.empty()
    try:
        q.put_nowait(1)
        assert True
    except QueueFull:
        assert False
    q.put(2)
    assert q.maxsize == 0
    assert q.qsize() == 2
    assert not q.full()
    assert not q.empty()

test_Queue_put()


# Generated at 2022-06-22 04:21:11.993503
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado.testing
    import tornado.gen
    import tornado.ioloop
    from tornado.queues import Queue
    from tornado.concurrent import Future

    def test_join():
        q = Queue(2)
        ready = Future()
        q.put_nowait(1)
        q.put_nowait(2)
        q.task_done()
        assert q.unfinished_tasks == 2
        f1 = q.join()
        assert q.full()
        assert q.unfinished_tasks == 2
        ready.set_result(None)
        tornado.testing.gen_test(f1)
        assert not q.full()
        assert q.unfinished_tasks == 1

# Generated at 2022-06-22 04:21:23.697207
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # test1
    try:
        q = Queue(maxsize=0)
        q.put_nowait(1)
        print(q._unfinished_tasks)
        q.task_done()
        print(q._unfinished_tasks)
    except QueueFull:
        print("Queue is full.")
    except ValueError:
        print("task_done() called too many times")
    except Exception as e:
        print(e)
    print("test 1 complete")

    # test2
    try:
        q = Queue(maxsize=0)
        print(q._unfinished_tasks)
        q.task_done()
        print(q._unfinished_tasks)
    except ValueError:
        print("task_done() called too many times")

# Generated at 2022-06-22 04:21:31.405939
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    L = [1, 2, 3]
    q = Queue(maxsize=len(L))
    for i in L:
        q.put_nowait(i)
    q_iterator = _QueueIterator(q)
    async def func():
        ans = []
        async for i in q_iterator:
            ans.append(i)
        return ans
    assert gen.convert_yielded(func()) == L



# Generated at 2022-06-22 04:21:34.478862
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty as e:
        assert str(e) == 'QueueEmpty'


# Generated at 2022-06-22 04:21:40.772254
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=0)
    q.put_nowait(1)
    assert q.empty() == False
    q.put_nowait(2)
    assert q.empty() == False
    q.put_nowait(3)
    assert q.empty() == False
    assert q.qsize() == 3


if __name__ == "__main__":
    test_Queue_put_nowait()
    print("Everything passed")

# Generated at 2022-06-22 04:21:47.405886
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    q_out = []

    q_out.append(q.get_nowait())
    q_out.append(q.get_nowait())
    q_out.append(q.get_nowait())

    return q_out == [(0, 'high-priority item'), (1, 'medium-priority item'), (10, 'low-priority item')]


# Generated at 2022-06-22 04:21:49.950694
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass



# Generated at 2022-06-22 04:21:59.998855
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import inspect
    import asyncio
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest


    def get_source_of_method(obj, _name: str) -> str:
        return inspect.getsource(getattr(obj, _name))


    # get_source_of_method(obj, _name: str) -> str
    arg0 = object()
    arg1 = ""
    obj = inspect
    _name = ""
    ret = get_source_of_method(obj, _name)
    assert type(ret) == str


    # __init__(self, q: 'Queue[_T]') -> None
    arg0 = object()
    obj = _QueueIterator
    q = Queue()

# Generated at 2022-06-22 04:22:05.694938
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    assert list(q._queue) == [1]



# Generated at 2022-06-22 04:22:13.871072
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado.escape

    q = Queue(maxsize=1)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-22 04:22:28.591978
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('code','message','path')
    except QueueFull as exp:
        assert exp.args[0]=='code'
        assert exp.args[1]=='message'
        assert exp.args[2]=='path'
    


# Generated at 2022-06-22 04:22:31.344428
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue(maxsize=1)
    i = _QueueIterator(q)
    q.put_nowait(1)
    i.__anext__()


# Generated at 2022-06-22 04:22:37.026367
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0>"

    q.put_nowait(None)
    assert str(q) == "<Queue maxsize=0 queue=[None]>"

# Generated at 2022-06-22 04:22:42.671083
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(5)
    q.put_nowait(6)
    q.put_nowait(7)
    #print(q.get_nowait())
    #print(q.get_nowait())
    #print(q.get_nowait())
test_Queue_get_nowait()
test_Queue_get_nowait()
test_Queue_get_nowait()


# Generated at 2022-06-22 04:22:54.877405
# Unit test for method put of class Queue
def test_Queue_put():
    class TestObj:
        def __init__(self, id):
            self.id = id
        def __str__(self):
            return "TestObj(%i)" % self.id
    q = Queue()
    q._queue = []
    q._maxsize = 10
    q._putters = collections.deque()
    q._getters = collections.deque()
    q._unfinished_tasks = 0
    q._finished = Event()
    
    
    q._putters.append((TestObj(0), Future()))
    q._putters.append((TestObj(1), Future()))
    q._putters.append((TestObj(2), Future()))
    q._putters.append((TestObj(3), Future()))

# Generated at 2022-06-22 04:22:59.481803
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty('QUEUE EMPTY')
    except QueueEmpty as e:
        print(e)
        assert e == 'QUEUE EMPTY' or e == 'QUEUE EMPTY'
        

# Generated at 2022-06-22 04:23:03.410792
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    #If no free slot is immediately available, return True
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full() == True



# Generated at 2022-06-22 04:23:04.494554
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()


# Generated at 2022-06-22 04:23:16.755165
# Unit test for method get of class Queue
def test_Queue_get():
    import types
    import asyncio
    from tornado.queues import Queue
    q = Queue()
    assert q.empty()
    q.put_nowait(1)
    assert not q.empty()
    q.put_nowait(2)
    assert not q.empty()
    q.put_nowait(3)
    assert not q.empty()
    q.put_nowait(4)
    assert not q.empty()
    q.put_nowait(5)
    assert not q.empty()
    q.put_nowait(6)
    assert not q.empty()
    q.put_nowait(7)
    assert not q.empty()
    q.put_nowait(8)
    assert not q.empty()
    q.put_nowait(9)

# Generated at 2022-06-22 04:23:18.202171
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()

    return q.empty() == True


# Generated at 2022-06-22 04:23:49.756399
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import pytest
    from tornado.generator import coroutine

    @coroutine
    def do_test__QueueIterator___anext__():
        q = Queue()
        item = "item"
        yield q.put(item)
        res = yield q.get()
        assert res == item

    ioloop.IOLoop.current().run_sync(do_test__QueueIterator___anext__)



# Generated at 2022-06-22 04:23:52.919244
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
  q = PriorityQueue()
  q.put((1, 'medium-priority item'))
  q.put((0, 'high-priority item'))
  q.put((10, 'low-priority item'))

  assert (q.get_nowait() == (0, 'high-priority item'))
  assert (q.get_nowait() == (1, 'medium-priority item'))
  assert (q.get_nowait() == (10, 'low-priority item'))


if __name__ == "__main__":
    test_PriorityQueue()

# Generated at 2022-06-22 04:23:54.403545
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    e = QueueEmpty()
    assert str(e) == repr(e)



# Generated at 2022-06-22 04:23:56.637141
# Unit test for method get of class Queue
def test_Queue_get():
    q=Queue()
    q.put_nowait(1)
    assert q.get_nowait()==1


# Generated at 2022-06-22 04:24:00.478205
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()

    q.put_nowait(1)
    q.put_nowait(2)

    assert q.maxsize == 0
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is False

    q.task_done()
    assert q.unfinished_tasks == 1

    q.task_done()
    assert q.unfinished_tasks == 0
    assert q.empty() is True

test_Queue_task_done()

# Generated at 2022-06-22 04:24:04.141106
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    if Queue.get_nowait() != QueueEmpty:
        print("Exception in Queue.get_nowait()")



# Generated at 2022-06-22 04:24:11.912511
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0
    q = Queue(maxsize=1)
    assert q.maxsize == 1
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    try:
        q = Queue(maxsize=None)
        assert False  # pragma: no cover
    except TypeError:
        pass
    try:
        q = Queue(maxsize=-1)
        assert False  # pragma: no cover
    except ValueError:
        pass



# Generated at 2022-06-22 04:24:18.019149
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    _q = Queue(maxsize=2)
    iter = _QueueIterator(_q)
    _q.put_nowait("a")
    _q.put_nowait("b")
    assert await iter.__anext__() == "a"
    assert await iter.__anext__() == "b"
    with pytest.raises(GenTimeoutError):
        await asyncio.wait_for(iter.__anext__(), timeout=0.01)

# Generated at 2022-06-22 04:24:20.036751
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty("message")
    except QueueEmpty as e:
        assert e.args == ("message",)



# Generated at 2022-06-22 04:24:24.972873
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(11)
    q.put_nowait(12)
    q_iter = iter(q)
    assert q_iter.__anext__() == 11
    assert q_iter.__anext__() == 12


# Generated at 2022-06-22 04:24:54.783620
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    model_Queue_put_nowait = Queue(maxsize=2)
    model_Queue_put_nowait.put_nowait(item=3)
    model_Queue_put_nowait.put_nowait(item=9)
    model_Queue_put_nowait.put_nowait(item=6)


# Generated at 2022-06-22 04:24:58.872845
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()

    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()


# Generated at 2022-06-22 04:25:10.738229
# Unit test for method join of class Queue
def test_Queue_join():
    queue = Queue()
    assert queue.empty()
    assert queue.maxsize == 0
    assert queue.qsize() == 0
    assert queue.full() == False
    # Put 2 item into queue
    queue.put_nowait(4)
    queue.put_nowait(5)
    # Get these 2 item 2 times
    assert queue.get_nowait() == 4
    assert queue.get_nowait() == 5
    assert queue.get_nowait() == 4
    assert queue.get_nowait() == 5
    # Queue is empty
    assert queue.empty() == True
    # Put 9 item into queue
    queue.put_nowait(9)
    # Queue is not empty and not full
    assert queue.empty() == False
    assert queue.full() == False
    # Get and process 2

# Generated at 2022-06-22 04:25:22.033590
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from asyncio import get_event_loop
    from tornado.ioloop import IOLoop
    from tornado.queues import QueueFull, Queue
    from unittest import mock
    import concurrent.futures
    import datetime
    import functools
    import math
    import pytest
    import sys
    import time

    with mock.patch.dict(sys.modules, {"asyncio": None}):
        q = Queue()
        itr = q.__aiter__()
        assert isinstance(itr, _QueueIterator)
        assert itr.q == q
    if sys.version_info < (3, 4):
        return None
    iol = IOLoop()
    iol.make_current()
    q = Queue(maxsize=1)
    fut = asyncio.ensure_

# Generated at 2022-06-22 04:25:23.645372
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    print("[test_QueueEmpty]")
    qe = QueueEmpty()
    assert qe is not None
    QueueEmpty()


# Generated at 2022-06-22 04:25:29.169824
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    q = Queue()

    async def provider():
        await q.put(42)

    async def consumer():
        item = await q.get()
        assert item == 42
        q.task_done()

    coro = asyncio.gather(provider(), consumer())
    asyncio.get_event_loop().run_until_complete(coro)

test_Queue_get()

# Generated at 2022-06-22 04:25:34.029195
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(8)
    assert q.qsize() == 1
    for i in _QueueIterator(q):
        assert i == 8
        break


# Generated at 2022-06-22 04:25:43.677234
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print( 'Doing work on {0}'.format(item) )
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put {0}'.format(item))

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-22 04:25:54.779867
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    # q.empty()
    assert q.qsize() == 0
    # q.put_nowait()
    q.put_nowait(1)
    assert q.qsize() == 1
    # q.get_nowait()
    q.get_nowait()
    assert q.qsize() == 0
    # q.put()
    future = q.put(1)
    future.result()
    assert q.qsize() == 1
    # q.get()
    q.get().result()
    assert q.qsize() == 0
    # q.put_nowait()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    # q.get_nowait()


# Generated at 2022-06-22 04:25:58.879193
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.full() == True 
    q.get()
    assert q.full() == False
    q.put(2)
    assert q.full() == True
