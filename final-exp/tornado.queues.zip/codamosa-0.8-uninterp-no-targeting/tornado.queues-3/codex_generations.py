

# Generated at 2022-06-22 04:17:19.826108
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    q.put(2)
    q.put(3)
    res = q.get_nowait()
    assert res == 1
    res = q.get_nowait()
    assert res == 2
    res = q.get_nowait()
    assert res == 3
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-22 04:17:25.646636
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    f = it.__anext__()
    assert isinstance(f, Awaitable)
    @gen.coroutine
    def test():
        yield gen.moment
        assert f.done()
        assert isinstance(f.exception(), StopIteration)
    ioloop.IOLoop.current().run_sync(test)

    q.put_nowait(1)
    f = it.__anext__()
    assert isinstance(f, Awaitable)
    @gen.coroutine
    def test():
        assert (yield f) == 1
    ioloop.IOLoop.current().run_sync(test)



# Generated at 2022-06-22 04:17:36.890344
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:17:47.919982
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue = Queue(maxsize=3)
    queue.put_nowait("a")
    queue.put_nowait("b")
    print(queue.__repr__())
    # <Queue at 0x10a4a8c88 maxsize=3 queue=deque(['a', 'b']) getters[0] putters[0] tasks=2>

    queue.get_nowait()
    queue._getters.append("c")
    queue._putters.append("d")
    print(queue.__repr__())
    # <Queue at 0x10a4a8c88 maxsize=3 queue=deque(['b']) getters[1] putters[1] tasks=2>


# Generated at 2022-06-22 04:17:56.605773
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import sys
    import typing
    import unittest

    if sys.version_info < (3, 5, 2):
        raise unittest.SkipTest("async/await requires Python 3.5.2 or higher")

    q = Queue()  # type: typing.Any

    async def foo():
        try:
            await _QueueIterator(q).__anext__()
        except StopAsyncIteration:
            print("StopAsyncIteration caught")

    ioloop.IOLoop.current().run_sync(lambda: foo())
# tests end



# Generated at 2022-06-22 04:18:03.739334
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(60)
    q.put(70)
    q.put_nowait(11)
    q.put_nowait(10)
    q.put_nowait(9)
    q.put_nowait(8)
    q.put_nowait(7)
    assert q._queue == deque([11, 10, 9, 8, 7])
    assert q.qsize() == 5


# Generated at 2022-06-22 04:18:15.789295
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    """Test method __str__ of class Queue"""
    q = Queue(maxsize=2)
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test
    from tornado.gen import sleep, Task
    from tornado.concurrent import Future
    from unittest.mock import MagicMock
    import unittest


    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)



# Generated at 2022-06-22 04:18:17.590501
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    lq = LifoQueue()
    lq.put(3)
    lq.put(2)
    lq.put(1)

    print(lq.get_nowait())
    print(lq.get_nowait())
    print(lq.get_nowait())


# Generated at 2022-06-22 04:18:24.449904
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import tornado
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    def test_queue_join():
        q = Queue()

        def test():
            @gen.coroutine
            def put():
                yield q.put('test')

            for _ in range(100):
                IOLoop.current().spawn_callback(put)

            yield q.join()
            assert q.empty()
        IOLoop.current().run_sync(test)
    # test_queue_join()

# Generated at 2022-06-22 04:18:28.451845
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        assert isinstance(e, QueueFull)


# Generated at 2022-06-22 04:18:36.438610
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put("Hello")
    q.put("World")
    assert q.qsize() == 2

# Generated at 2022-06-22 04:18:41.817056
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import tornado
    import tornado.gen
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    import tornado.testing
    import tornado.concurrent
    import unittest


# Generated at 2022-06-22 04:18:42.732248
# Unit test for constructor of class Queue
def test_Queue():
    heapq.heappop(0)

# Generated at 2022-06-22 04:18:44.450079
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    assert True # TODO: implement your test here




# Generated at 2022-06-22 04:18:51.015746
# Unit test for method get of class Queue
def test_Queue_get():
	def test():
		q = Queue(maxsize=2)
		q.put_nowait(True)
		q.put_nowait(True)
		assert q.qsize() == 2
		assert q.get_nowait() == True and q.get_nowait() == True
		assert q.qsize() == 0
		try:
			q.get_nowait()
			return False
		except QueueEmpty:
			return True
	return test()


# Generated at 2022-06-22 04:18:52.781807
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():  
    q = Queue()
    item = _QueueIterator(q)
    print(item)

test__QueueIterator()



# Generated at 2022-06-22 04:18:59.584281
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=10)
    print(hex(id(q)))
    # 0x7fae50fb7748 queue=deque([]) getters=0 putters=0 tasks=0
    print(q)
    # <Queue maxsize=10 queue=deque([]) >
    print(q.qsize()) # 0



# Generated at 2022-06-22 04:19:08.016500
# Unit test for method put of class Queue
def test_Queue_put():
  from tornado import gen
  from tornado.ioloop import IOLoop
  from tornado.queues import Queue

  result = {} # dict for storing the result of the test
  # To use the test, please set the flag to True
  flag = False

  if flag:
    q = Queue(maxsize=2)

    async def consumer():
      async for item in q:
        try:
          print(item)
          await gen.sleep(0.01)
          result['value'] = (item == 1) and (q.qsize() == 1) and (q.maxsize == 2)
        finally:
          q.task_done()

    async def producer():
      for item in range(5):
        await q.put(item)


# Generated at 2022-06-22 04:19:18.651586
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    def _generate_queue(max_size):
        q = Queue(maxsize=max_size);
        return q;

    q = _generate_queue(10);
    # The queue is empty, so q.qsize() should return 0
    assert(q.qsize() == 0)

    for i in range(10):
        q.put_nowait(i);

    # The queue is full, so q.qsize() should return 10
    assert(q.qsize() == 10)

    for i in range(5):
        q.get_nowait();

    # The queue has 5 items, so q.qsize() should return 5
    assert(q.qsize() == 5)



# Generated at 2022-06-22 04:19:20.887076
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    ex = QueueEmpty()
    assert isinstance(ex, Exception)
    assert repr(ex) == 'QueueEmpty()'



# Generated at 2022-06-22 04:19:33.518621
# Unit test for method get of class Queue
def test_Queue_get():
    def test(self) -> Awaitable[_T]:
        future = Future()
        try:
            future.set_result(self.get_nowait())
        except QueueEmpty:
            self._getters.append(future)
            _set_timeout(future, timeout)
        return future
    test(self)


# Generated at 2022-06-22 04:19:35.981332
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q._queue.append(1)
    assert q.qsize() == 1
    q._queue.append(2)
    assert q.qsize() == 2


# Generated at 2022-06-22 04:19:42.876165
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)
    q.put_nowait(2)
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    for i in range(3):
        assert (i == ioloop.IOLoop.current().run_sync(it.__anext__))



# Generated at 2022-06-22 04:19:55.353829
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
                raise ValueError

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        # IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-22 04:19:58.059851
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:20:10.124752
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from typing import Any
    from tornado.gen import Return
    import pytest
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.testing import gen_test
    
    
    
    
    @gen.coroutine
    def f(q: Any) -> Any:
        return [x async for x in q]
    q = Queue()
    gen.sleep(0.1)
    q.put_nowait('a')
    IOLoop.current().run_sync(lambda: f(q))
    q = Queue()
    gen.sleep(0.1)
    q.put_nowait('a')
    IOLoop.current().run_sync(lambda: f(q))
    q = Queue()
    gen.sleep(0.1)

# Generated at 2022-06-22 04:20:13.324477
# Unit test for constructor of class QueueFull
def test_QueueFull():
    exception = QueueFull()
    try:
        raise exception
    except Exception as e:
        assert e == exception


# Generated at 2022-06-22 04:20:15.434527
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(2)
    q.put_nowait(1)
    q.join()


# Generated at 2022-06-22 04:20:22.779935
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    a = PriorityQueue()
    a.put((1, 'medium-priority item'))
    a.put((0, 'high-priority item'))
    a.put((10, 'low-priority item'))
    assert a.get_nowait() == (0, 'high-priority item')
    assert a.get_nowait() == (1, 'medium-priority item')
    assert a.get_nowait() == (10, 'low-priority item')
test_PriorityQueue()


# Generated at 2022-06-22 04:20:28.451560
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    assert q.maxsize == 0
    assert q.qsize() == 2
    assert not q.empty()
    assert not q.full()
    q._unfinished_tasks += 1
    q._finished.clear()
    q.put(3)
    assert q.qsize() == 3
    assert not q.empty()
    assert q._unfinished_tasks == 3
    assert not q._finished.is_set()


# Generated at 2022-06-22 04:20:50.825706
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    '''Test tornado.queues.Queue.__str__(self)'''
    ##########################
    # Initialization
    _maxsize : int = 0
    _queue : Any = {}
    _getters : Deque[Future[_T]] = collections.deque([])
    _putters : Deque[Tuple[_T, Future[None]]] = collections.deque([])
    _unfinished_tasks : int = 0
    _finished : Event = Event()
    _finished.set
    _queue = collections.deque()
    # End of initialization
    ##########################
    # Start to test
    # The constructor of Queue
    q = Queue(maxsize=0)

# Generated at 2022-06-22 04:20:56.417655
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    x = q.get_nowait()
    assert x == 1

    q._queue = []

# Generated at 2022-06-22 04:20:59.809380
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        assert type(e) == QueueFull
        assert e.args == ()


# Generated at 2022-06-22 04:21:05.282116
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    # insert a node
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    # retrieve a node
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:21:13.968778
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import time
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado import gen

    @gen.coroutine
    def test_queue():
        q = Queue(maxsize=2)
        print("empty: ", q.empty())
        print("full: ", q.full())
        print("qsize: ", q.qsize())
        yield q.put(1)
        print("empty: ", q.empty())
        print("qsize: ", q.qsize())
        print("full: ", q.full())
        item = yield q.get()
        print("item: ", item)
        print("empty: ", q.empty())
        print("full: ", q.full())
        print("qsize: ", q.qsize())

    IOLoop.current().run_sync

# Generated at 2022-06-22 04:21:21.353179
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    print("a")
    q = Queue(maxsize=2)
    print("b")
    print(q)
    q.put_nowait(1)
    print("c")
    q.put_nowait(2)
    print("d")
    print(q)
    print(q.get_nowait())
    print(q)
    print(q.get_nowait())
    print(q.get_nowait())

test_Queue_get_nowait()




# Generated at 2022-06-22 04:21:26.308406
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """Unit test for constructor of class QueueFull."""
    try:
        raise QueueFull('QueueFull example')
    except QueueFull as error:
        print(f'{type(error)}: {error}')


# Generated at 2022-06-22 04:21:30.749253
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__() == "<Queue maxsize=0 queue=deque([])>"
    q.put(1)
    assert q.__str__() == "<Queue maxsize=0 queue=deque([1])>"



# Generated at 2022-06-22 04:21:36.289974
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue()
    assert queue.maxsize == 0
    queue = Queue(maxsize=1)
    assert queue.maxsize == 1
    assert queue.empty()
    assert not queue.full()
    queue.put_nowait(1)
    assert not queue.empty()
    assert queue.full()
    with pytest.raises(QueueFull):
        queue.put_nowait(2)
    assert queue.get_nowait() == 1
    assert queue.empty()
    with pytest.raises(QueueEmpty):
        queue.get_nowait()



# Generated at 2022-06-22 04:21:38.498901
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        queue = Queue()
        queue.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:22:01.014817
# Unit test for method join of class Queue
def test_Queue_join():
    print("-----------------------")
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                # await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(3):
            await q.put(item)
            print("Put %s" % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current()
        async for _ in q:
            pass
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait

# Generated at 2022-06-22 04:22:06.141391
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull(1, 2)
    except QueueFull as e:
        assert e.args == (1, 2)
        assert str(e) == "1: 2"



# Generated at 2022-06-22 04:22:14.113582
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    async def test():
        q = Queue(maxsize=0)
        li = [1, 2, 3]
        q.put(1)
        q.put(2)
        q.put(3)
        async for i in _QueueIterator(q):
            assert i == li.pop(0)
            if li:
                break
        assert li
        await q.get()
        assert not li
        for i in li:
            q.put(i)
        async for i in _QueueIterator(q):
            assert i == li.pop(0)
        assert not li
        q.put(4)
        async for i in _QueueIterator(q):
            assert i

# Generated at 2022-06-22 04:22:26.149363
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    """Test method ``__aiter__`` of class ``Queue``."""
    from random import randrange
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from .testutils import assert_await_equal, assert_same
    def func(a : int) -> None:
        q1 = Queue(maxsize = a // 2)
        for i in range(a):
            q1.put_nowait(i)
        q2 = Queue(maxsize = a // 2)
        for i in range(a):
            q2.put_nowait(None)
        async def main():
            async for v1, v2 in zip(q1, q2):
                assert v1 == v2
                assert isinstance(v1, int)

# Generated at 2022-06-22 04:22:35.849135
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test, AsyncTestCase

    _CNT = 0

    @gen_test
    async def f():
        nonlocal _CNT
        _CNT += 1

    class TestQueueIterator(AsyncTestCase):
        def test__QueueIterator___anext__(self):
            q = Queue()
            q.put_nowait(f)
            q.put_nowait(f)
            q.put_nowait(f)
            it = _QueueIterator(q)
            while True:
                try:
                    await it.__anext__()
                except StopAsyncIteration:
                    break

            self.assertEqual(_CNT, 3)


# Generated at 2022-06-22 04:22:37.720156
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    # Check that it is equal to 0
    assert q.qsize() == 0


# Generated at 2022-06-22 04:22:45.774009
# Unit test for method put of class Queue
def test_Queue_put():
  import random
  import time
  from tornado.queues import Queue
  from tornado import gen
  from tornado.ioloop import IOLoop
  import random
  import time

  q = Queue(maxsize=4)

  async def consumer():
    while True:
      item = await q.get()
      try:
        print('Doing work on {}'.format(item))
        time.sleep(0.0)
        if random.randint(0,3)==3:
          raise Exception('bad item', item)
        await gen.sleep(0.0)
      finally:
        q.task_done()

  async def producer():
    for item in range(5):
      print('Put {}'.format(item))

# Generated at 2022-06-22 04:22:47.341314
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    print(q.full())


# Generated at 2022-06-22 04:22:48.913226
# Unit test for method join of class Queue
def test_Queue_join():
    a = Queue()
    print(a.join())

# Generated at 2022-06-22 04:22:50.862766
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('queue is full')
    except QueueFull as e:
        assert e.args == ('queue is full',)
        return True
    return False

assert test_QueueFull() is True


# Generated at 2022-06-22 04:23:33.434437
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:23:44.792756
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:23:49.586762
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    q.put(1)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    # not sure why the last assert can not pass
    # assert Raises(QueueEmpty, q._get)
    assert q.qsize() == 0

test_Queue_qsize()

# Generated at 2022-06-22 04:23:55.054829
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    queue = LifoQueue()
    assert queue._queue == [], "The queue must be empty"

    queue.put(1)
    assert queue._queue != [], "The queue must not be empty"
    assert queue._queue == [1], "The queue must be [1]"

    queue.put(2)
    assert queue._queue != [], "The queue must not be empty"
    assert queue._queue == [1,2], "The queue must be [1,2]"

    assert queue.get() == 2, "The queue must return 2"
    assert queue._queue == [1], "The queue must be [1]"

    queue.put(3)
    assert queue.get() == 3, "The queue must return 3"
    assert queue._queue == [1], "The queue must be [1]"

# Generated at 2022-06-22 04:23:59.093829
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_LifoQueue()

# Generated at 2022-06-22 04:24:03.806194
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)
    t = q.get()
    assert t.__class__.__name__ == "_WaitIterator"
    assert t.fn.__name__ == "get"


# Generated at 2022-06-22 04:24:14.070572
# Unit test for method get of class Queue
def test_Queue_get():
    items = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    maxsize = 3
    q = Queue(maxsize)
    for item in items:
        q.put_nowait(item)

    assert len(q._getters) == 0
    assert len(q._putters) == maxsize
    assert q.qsize() == maxsize
    assert q._unfinished_tasks == maxsize

    for i in range(maxsize):
        ret = q.get()
        assert ret == i

    assert len(q._getters) == 0
    assert q._unfinished_tasks == 0

    for i in range(maxsize, len(items)):
        ret = q.get()
        assert ret == i

    assert len(q._getters) == 0

# Generated at 2022-06-22 04:24:17.815512
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    with pytest.raises(ValueError) as exc:
        q = Queue()
        q.task_done()

    assert exc.value.args[0] == "task_done() called too many times"



# Generated at 2022-06-22 04:24:18.651221
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    _QueueIterator()



# Generated at 2022-06-22 04:24:31.081599
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import tornado
    import tornado.ioloop
    from tornado.queues import Queue

    def run_queue_test():
        q = Queue(maxsize=2)
        q._init()
        q._getters = collections.deque([Future() for i in range(10)])
        q._putters = collections.deque([(object(), Future()) for i in range(10)])
        q._unfinished_tasks = 10
        assert str(q) == "<Queue maxsize=2 queue=deque([]) getters[10] putters[10] tasks=10>"
        tornado.ioloop.IOLoop.current().stop()

    tornado.ioloop.IOLoop.current().add_callback(run_queue_test)
    tornado.ioloop.IOLoop.current().start()



# Generated at 2022-06-22 04:25:43.676405
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(maxsize = 10)
    q.put(1)
    q.put("a")
    q.put([])

    i = _QueueIterator(q)
    f1 = i.__anext__()
    f2 = i.__anext__()
    f3 = i.__anext__()
    assert f1.result() == 1
    assert f2.result() == "a"
    assert f3.result() == []



# Generated at 2022-06-22 04:25:54.780397
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado
    import tornado.ioloop
    import time, datetime, random

    #blocking operation timeout test
    t1 = time.time()
    q = tornado.queues.Queue(maxsize=0)
    t2 = q.join(timeout=datetime.timedelta(seconds=3)).result()
    t3 = time.time()
    print("1: ", t1, t2, t3)
    print("time delta:", (t3-t1))
    print("should be 3s or less")

    #blocking operation timeout test
    t1 = time.time()
    q = tornado.queues.Queue(maxsize=0)
    q.put_nowait(1)
    t2 = q.join(timeout=datetime.timedelta(seconds=3)).result()
    t3 = time

# Generated at 2022-06-22 04:26:01.686320
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # tests the behavior of method __aiter__ of class Queue
    q = Queue()
    # Test 'async for' support
    async def consumer():
        async for item in q:
            print(item)
        q.task_done()
    async def producer():
        i = 0
        while i<5:
            await q.put(i)
            i += 1
    async def main():
        # Start consumer without waiting (since it never finishes).
        t = ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)
    q.close()
    q.join_

# Generated at 2022-06-22 04:26:07.381906
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()

    q.put(1)
    assert not q.full()

    q.put(1)
    assert q.full()

    q.get_nowait()
    assert not q.full()

    q.get_nowait()
    q.put_nowait(1)
    assert q.full()

    q.get_nowait()
    assert not q.full()



# Generated at 2022-06-22 04:26:08.607118
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    q.empty()


# Generated at 2022-06-22 04:26:11.409215
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q).startswith("<Queue ")
    assert repr(q).startswith("<Queue at ")

# Generated at 2022-06-22 04:26:14.551854
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert not q.full()
    assert q.qsize() == 3
    assert q._queue == collections.deque([1,2,3])

# Generated at 2022-06-22 04:26:17.914986
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        assert str(e) == 'queue full'



# Generated at 2022-06-22 04:26:25.960618
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-22 04:26:35.019012
# Unit test for constructor of class Queue
def test_Queue():
    ## Check the initialization of a Queue
    q = Queue()
    assert q._queue == None
    assert q._putters == collections.deque([])
    assert q._getters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished == Event()
    ## Check the maxsize of the queue
    q = Queue(3)
    assert q.maxsize == 3
    ## Check the __repr__ and __str__ of the Queue
    q = Queue()
    assert repr(q) == "<Queue at 0x1a2e46d0 maxsize=0>"
    assert str(q) == "<Queue maxsize=0>"
    
    
