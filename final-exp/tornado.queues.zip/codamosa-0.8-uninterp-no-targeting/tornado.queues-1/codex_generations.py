

# Generated at 2022-06-22 04:17:25.492354
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0>"
    q = Queue(maxsize=5)
    assert str(q) == "<Queue maxsize=5>"
    q = Queue()
    q.put_nowait(object())
    assert str(q) == "<Queue maxsize=0 queue=[<object object at 0x7f2030da6a10>]"
    q = Queue()
    q.get_nowait()
    assert str(q) == "<Queue maxsize=0 getters[1]>"
    q = Queue(maxsize=0)
    q.put_nowait(object())
    assert str(q) == "<Queue maxsize=0 tasks=1 putters[1]"
    q = Queue(maxsize=3)
    q.put_nowait

# Generated at 2022-06-22 04:17:35.905725
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q._unfinished_tasks == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q._unfinished_tasks == 2
    q.task_done()
    assert q.qsize() == 2
    assert q._unfinished_tasks == 1
    q.task_done()
    assert q.qsize() == 2
    assert q._unfinished_tasks == 0
    q.task_done()


# Generated at 2022-06-22 04:17:37.367031
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    assert i is not None


# Generated at 2022-06-22 04:17:43.066019
# Unit test for method full of class Queue
def test_Queue_full():
    obj = Queue(maxsize=10)
    assert obj.full() is False
    obj.qsize = Mock(return_value=3)
    assert obj.full() is False
    obj.qsize = Mock(return_value=10)
    assert obj.full() is True


# Generated at 2022-06-22 04:17:46.171345
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

    assert q.get_nowait() == False

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:17:47.612376
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()


# Generated at 2022-06-22 04:17:52.612456
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    a = Queue(maxsize = None)
    assert repr(a) == "<Queue at 0x%x maxsize=None queue=deque([])>" % id(a)


# Generated at 2022-06-22 04:17:56.720434
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import doctest
    doctest.run_docstring_examples(_QueueIterator.__anext__, {'self': _QueueIterator(Queue(1))})

    # If the method __anext__ is implemented, we have to have a __aiter__ method too
    def test__QueueIterator___aiter__():
        return self.q



# Generated at 2022-06-22 04:17:58.835227
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        pass


# Generated at 2022-06-22 04:18:01.534770
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass
    return



# Generated at 2022-06-22 04:18:11.795540
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = QueueEmpty()
    return q


# Generated at 2022-06-22 04:18:18.998420
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:18:21.973628
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at 0x7f8b45c3a5f8 maxsize=2>"


# Generated at 2022-06-22 04:18:31.609428
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert str(e) == "Queue is empty"
    assert repr(e) == "QueueEmpty()"
    e = QueueEmpty("hello")
    assert str(e) == "hello"
    assert repr(e) == "QueueEmpty(hello)"
    e = QueueEmpty(args = ("hello",))
    assert str(e) == "hello"
    assert repr(e) == "QueueEmpty(hello)"
    e = QueueEmpty(args = ("hello",), message = "message")
    assert str(e) == "message"
    assert repr(e) == "QueueEmpty(message)"


# Generated at 2022-06-22 04:18:43.141769
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    _QueueIterator = _QueueIterator()
    _QueueIterator._queue = collections.deque()
    _QueueIterator._future = Future()
    _QueueIterator._future.set_result(None)
    q = Queue()
    q._queue = collections.deque()
    q._getters = collections.deque()
    q._putters = collections.deque()
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    q.maxsize = 0
    q._getters.append(_QueueIterator._future)
    _QueueIterator._queue.append(1)
    __aiter__ = q.__aiter__()
    assert isinstance(__aiter__, _QueueIterator)
    assert __aiter__.q is q


# Generated at 2022-06-22 04:18:46.307145
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()



# Generated at 2022-06-22 04:18:50.155481
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    @gen.coroutine
    def _test__QueueIterator___anext__():
        b=_QueueIterator(None)
        r=yield from b.__anext__()
        pass
    _test__QueueIterator___anext__()



# Generated at 2022-06-22 04:18:56.684556
# Unit test for method put of class Queue
def test_Queue_put():
    # Default Arguments(maxsize=0, timeout=None):
    q = Queue()
    future = q.put(1)
    assert isinstance(future, Future)
    future = q.put(2, 0.1)
    assert isinstance(future, Future)
    future = q.put(3, timedelta(seconds=0.1))
    assert isinstance(future, Future)
    assert str(future) == "<Future pending>"


# Generated at 2022-06-22 04:19:02.131690
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(2)
    expected = "<Queue at 0x%x maxsize=2 queue=%r getters[0] putters[0] tasks=0>" % (id(q), q._queue)
    assert expected == repr(q)

# Generated at 2022-06-22 04:19:08.204790
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.full() == False
    assert q.empty() == True
    q.put_nowait(0)
    assert q.qsize() == 1
    assert q.full() == False
    assert q.empty() == False
    future = q.put(1, 1)
    assert q.qsize() == 2
    assert q.full() == True
    assert q.empty() == False
    try:
        q.put_nowait(2)
        assert False
    except QueueFull:
        pass

# Generated at 2022-06-22 04:19:20.007816
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-22 04:19:32.819213
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import collections
    import inspect
    from tornado.queues import Queue

    def get_attr(attr, default=None):
        return getattr(Queue, attr, default)

    assert Queue.__str__.__code__.co_argcount == 1

    Queue._format = lambda self: '_format()'
    queue = Queue()
    assert queue.__str__() == "<Queue _format()>"

    Queue._format = lambda self: "maxsize=%r queue=%r getters=%r putters=%r tasks=%r" % (
        queue.maxsize,
        get_attr('_queue', ''),
        get_attr('_getters', ''),
        get_attr('_putters', ''),
        get_attr('_unfinished_tasks', '')
    )


# Generated at 2022-06-22 04:19:37.175095
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(0)
    q.put(1)
    assert q.get_nowait() == 0
    assert q.get_nowait() == 1
    return None

# Generated at 2022-06-22 04:19:39.847054
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(1)
    assert q.get_nowait() is None
    assert q.get_nowait() is None


# Generated at 2022-06-22 04:19:42.740936
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.get()
    q.get()
    q.get()

# Generated at 2022-06-22 04:19:45.328272
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.queues import Queue
    q = Queue()
    q._unfinished_tasks = 1
    d = _QueueIterator(q).__anext__()
    assert d.__class__.__name__ == 'Awaitable[_T]'



# Generated at 2022-06-22 04:19:59.028311
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                # await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.


# Generated at 2022-06-22 04:20:10.654183
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    # End testcase of Queue
    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()
        yield q.join()
        print("Done")

    IOL

# Generated at 2022-06-22 04:20:14.891278
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except Exception as e:
        return True
    return False


# Generated at 2022-06-22 04:20:21.458543
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=10)
    q.put_nowait(5)
    assert q.qsize() == 1
    q.put_nowait(6)
    assert q.qsize() == 2
    q.put_nowait(7)
    assert q.qsize() == 3
    q.put_nowait(8)
    assert q.qsize() == 4


# Generated at 2022-06-22 04:20:39.252678
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    async def test():
        q = Queue()
        assert q.empty()
        assert not q.full()
        assert q.qsize() == 0
        with pytest.raises(QueueEmpty):
            q.get_nowait()
        q.put_nowait(2)
        assert not q.empty()
        assert q.qsize() == 1
        assert q.get_nowait() == 2
        assert q.empty()
        assert q.qsize() == 0
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        assert not q.empty()
        assert q.full()
        assert q.qsize() == 3
        with pytest.raises(QueueFull):
            q.put_nowait(4)
       

# Generated at 2022-06-22 04:20:41.063493
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    print(Queue().qsize())



# Generated at 2022-06-22 04:20:45.864178
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Test 1
    q = Queue(maxsize=0)
    assert(q.empty() == True)
    # Test 2
    q.put_nowait(0)
    assert(q.empty() == False)
    # Test 3
    q.get_nowait()
    assert(q.empty() == True)



# Generated at 2022-06-22 04:20:48.999730
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    assert isinstance(iter(Queue()), _QueueIterator)
    assert isinstance(iter(LifoQueue()), _QueueIterator)
    assert isinstance(iter(PriorityQueue()), _QueueIterator)



# Generated at 2022-06-22 04:20:51.488493
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    print (q.empty())
    q.put_nowait(1)
    q.put_nowait(2)
    print (q.full())


# Generated at 2022-06-22 04:20:58.991108
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q1 = Queue(maxsize=2)
    q2 = Queue(maxsize=0)
    try:
        q1.put_nowait(1)
        q1.put_nowait(2)
        q2.put_nowait(1)
        q2.put_nowait(2)
        assert False
    except QueueFull:
        assert True



# Generated at 2022-06-22 04:21:04.859730
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == '<Queue at %s maxsize=0 queue=deque([])>' % hex(id(q))
    q.put_nowait(1)
    q.put_nowait(2)
    assert repr(q) == '<Queue at %s maxsize=0 queue=deque([1, 2])>' % hex(id(q))



# Generated at 2022-06-22 04:21:13.767351
# Unit test for method get_nowait of class Queue

# Generated at 2022-06-22 04:21:26.303181
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    # Put 0
    q.put(0)
    assert q.test_queue == deque([0])
    assert q.test_putters == deque()
    assert q.test_finished._flag == False
    assert q.test_unfinished_tasks == 1
    # Put 1
    q.put(1)
    assert q.test_queue == deque([0,1])
    assert q.test_putters == deque()
    assert q.test_finished._flag == False
    assert q.test_unfinished_tasks == 2
    # Put 2
    q.put(2)
    assert q.test_queue == deque([0,1,2])
    assert q.test_putters == deque()
    assert q.test_finished._flag == False

# Generated at 2022-06-22 04:21:29.629675
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:21:42.001574
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=3)
    for i in range(4):
        q.put(i)
    assert q.qsize() == 3
    assert set(q._queue) == set([1,2,3])


# Generated at 2022-06-22 04:21:46.478395
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        assert isinstance(e, Exception)
        assert isinstance(e, QueueFull)
        # unit test for __str__ method
        assert str(e) == "Queue is full"


# Generated at 2022-06-22 04:21:58.698663
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    def __init__(self, maxsize: int = 0) -> None:
        if maxsize is None:
            raise TypeError("maxsize can't be None")

        if maxsize < 0:
            raise ValueError("maxsize can't be negative")

        self._maxsize = maxsize
        self._init()
        self._getters = collections.deque([])  # type: Deque[Future[_T]]
        self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
        self._unfinished_tasks = 0
        self._finished = Event()
        self._finished.set()

    @property
    def maxsize(self) -> int:
        """Number of items allowed in the queue."""
        return self._maxsize


# Generated at 2022-06-22 04:22:11.346714
# Unit test for method put of class Queue
def test_Queue_put(): 
    import random

    import tornado.gen
    import tornado.ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    items = []  # type: List[int]

    @tornado.gen.coroutine
    def consumer():
        try:
            while True:
                item = yield q.get()
                items.append(item)
                yield tornado.gen.sleep(random.random() * 0.01)
                q.task_done()
        except tornado.gen.Return:
            pass

    @tornado.gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)

    tornado.ioloop.IOLoop.current().run_sync(lambda: producer())
    

# Generated at 2022-06-22 04:22:20.764805
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:22:23.701455
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    assert isinstance(i, collections.Iterator)



# Generated at 2022-06-22 04:22:30.767836
# Unit test for method full of class Queue
def test_Queue_full():
    q1 = Queue(2)
    q2 = Queue(5)
    q3 = Queue(10)
    print(q1.full())
    q1.put(1)
    q1.put(1)
    print(q1.full())
    q2.put(1)
    q2.put(1)
    q2.put(1)
    q2.put(1)
    q2.put(1)
    print(q2.full())


# Generated at 2022-06-22 04:22:36.277820
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(_maxsize=0)
    assert str(q) == "<Queue maxsize=0 queue=deque([]) getters[] putters[] tasks=0>"



# Generated at 2022-06-22 04:22:36.875898
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass


# Generated at 2022-06-22 04:22:38.584822
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:22:53.495482
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=0)
    if q.qsize() != 0:
        return False
    if q.empty() != True:
        return False
    for i in range(5):
        q.put_nowait(i)
    if q.qsize() != 5:
        return False
    if q.empty() != False:
        return False
    return True


# Generated at 2022-06-22 04:22:55.115035
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    i = _QueueIterator(q)
    assert i.__anext__() == q.get()


# Generated at 2022-06-22 04:23:05.589459
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    _str = Queue()
    _str.put_nowait(4)
    _str.put_nowait(5)
    _str.put_nowait(6)
    _str.get_nowait()
    _str.get_nowait()
    _str.get_nowait()
    _str.put_nowait(1)
    _str.put_nowait(2)
    _str.put_nowait(3)
    _str.get_nowait()
    _str.get_nowait()
    _str.get_nowait()
    assert repr(_str) == "<Queue at 0x7f9a12e2fef0 queue=[1, 2, 3] getters[0] putters[0] tasks=0>"

# Unit test

# Generated at 2022-06-22 04:23:09.504671
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait('q')
    it = collections.AsyncIterator(_QueueIterator(q))
    yield from it



# Generated at 2022-06-22 04:23:13.421379
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    print(it.__anext__())   
    pass
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:23:21.873365
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.empty()
    assert q.qsize() == 2
    q.full()
    assert q.qsize() == 2
    q.task_done()
    assert q.qsize() == 1
    try:
        q.get_nowait()
        q.task_done()
        assert q.qsize() == 0
        q.join()
        assert q.qsize() == 0
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:23:27.694032
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    it = _QueueIterator(q)
    print(type(it))


# Generated at 2022-06-22 04:23:31.670380
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=10)
    for i in range(10):
        q.put(i)
    assert q.qsize() == 10
    for i in range(10):
        assert q.get_nowait() == i


# Generated at 2022-06-22 04:23:34.177642
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    q.put_nowait(3)


# Generated at 2022-06-22 04:23:43.465097
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    def test():
        q.put_nowait(1)
        assert q.qsize() == 1
        q.put_nowait(2)
        assert q.qsize() == 2
        q.get_nowait()
        assert q.qsize() == 1
        q.get_nowait()
        assert q.qsize() == 0

    IOLoop.current().run_sync(test)

# Generated at 2022-06-22 04:23:55.873140
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    actual = q.__str__()
    assert actual == "<Queue maxsize=0>"


# Generated at 2022-06-22 04:24:01.624724
# Unit test for method get of class Queue
def test_Queue_get():
    from typing import List
    import pytest
    import tornado.ioloop
    import tornado.queues

    def main():
        q = tornado.queues.Queue(maxsize=1)
        with pytest.raises(tornado.queues.QueueEmpty) as excinfo:
            q.get_nowait()
        assert "Queue empty" in str(excinfo.value)
        q.put_nowait(1)
        assert q.get_nowait() == 1
        q.put_nowait(2)
        io_loop = tornado.ioloop.IOLoop.current()

        @tornado.gen.coroutine
        def f():
            item = yield q.get()
            assert item == 2
        io_loop.run_sync(f)
    main()


# Generated at 2022-06-22 04:24:04.273759
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        print("Exception in test_QueueFull: ", e)



# Generated at 2022-06-22 04:24:09.932465
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:24:14.665284
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
	q = PriorityQueue()
	q.put((1, 'medium-priority item'))
	q.put((0, 'high-priority item'))
	q.put((10, 'low-priority item'))

	print(q.get_nowait())
	print(q.get_nowait())
	print(q.get_nowait())
if __name__=='__main__':
	test_PriorityQueue()

# Generated at 2022-06-22 04:24:15.838255
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    raise QueueEmpty()


# Generated at 2022-06-22 04:24:18.196503
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    # TODO: finish this
    assert not q.full()


# Generated at 2022-06-22 04:24:24.259589
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    @asyncio.coroutine
    def test():
        q = Queue()
        
        q.put('hi')

        i = iter(q)
        s = yield from i.__anext__()
        assert(s == 'hi')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-22 04:24:29.889245
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    iterator = _QueueIterator(q)
    item = yield from iterator.__anext__()
    assert item == 1
    q.put(2)
    item = yield from iterator.__anext__()
    assert item == 2



# Generated at 2022-06-22 04:24:40.168529
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:24:55.656849
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(repr(q))
    print(str(q))

test_Queue___repr__()



# Generated at 2022-06-22 04:25:01.530864
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Initialize class Queue.
    # The result of the function call is stored in the local variable q.
    q = Queue()
    # Check if the Queue is empty.
    print(q.empty())
    # Store the string 'Hello' in a local variable t.
    t = 'Hello'
    # Put t into q.
    q.put_nowait(t)
    # Store the result of calling the method q.get_nowait() in the local
    # variable result.
    result = q.get_nowait()
    # Print out the result.
    print(result)
    # Store the integer 123 in a local variable i.
    i = 123
    # Put i into q.
    q.put_nowait(i)
    # Store the result of calling the method q.get_nowait() in the

# Generated at 2022-06-22 04:25:07.109673
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:25:09.433138
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    '''Test empty queue exception'''
    try:
        raise QueueEmpty
    except QueueEmpty:
        print("Queue is empty")


# Generated at 2022-06-22 04:25:15.009268
# Unit test for method empty of class Queue
def test_Queue_empty():
    if __name__ == '__main__':
        # Construtor
        q = Queue(maxsize=2)

        # Method empty
        assert not q.empty()
        q._queue.clear()
        assert q.empty()



# Generated at 2022-06-22 04:25:22.717989
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Testing Queue.get_nowait() :
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
        assert False, "Exception not raised"
    except QueueEmpty:
        pass
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    q.put_nowait(3)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
        assert False, "Exception not raised"
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:25:33.934482
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:25:43.586319
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    import time
    #Test with an empty queue
    q = Queue()
    q.task_done()
    #Test with a filled queue
    q = Queue()
    q.put((1,1))
    q.put((2,2))
    q.task_done()
    q.task_done()
    #Test with a queue with getters waiting
    q = Queue()
    q.put((1,1))
    def f():
        q.task_done()
    f()
    #Test with a queue with putters waiting
    q = Queue()
    q.maxsize = 1
    q.put((1,1))
    q.put((2,2))
    q.task_done()
    #Test with a lot of tasks waiting
    q = Queue()


# Generated at 2022-06-22 04:25:45.441295
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    pass



# Generated at 2022-06-22 04:25:53.317305
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
	q = Queue()
	# Populate the queue with some items.
	q.put_nowait(1)
	q.put_nowait(2)
	q.put_nowait(3)
	assert_equal(q.get_nowait(), 1)
	assert_equal(q.get_nowait(), 2)
	assert_equal(q.get_nowait(), 3)
	# Make sure that it's empty.
	assert_raises(QueueEmpty, q.get_nowait)


# Generated at 2022-06-22 04:26:17.824594
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty('The queue has no items.')
    except QueueEmpty as e:
        print(e)


# Generated at 2022-06-22 04:26:20.536945
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    assert isinstance(qe, Exception)
    assert isinstance(qe, QueueEmpty)



# Generated at 2022-06-22 04:26:22.805331
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(maxsize=10)
    it = _QueueIterator(q)



# Generated at 2022-06-22 04:26:25.425190
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

#test_PriorityQueue()



# Generated at 2022-06-22 04:26:35.885246
# Unit test for method full of class Queue
def test_Queue_full():
    # pylint: disable=protected-access
    q = Queue()
    assert not q._queue
    assert not q._putters
    assert not q._getters
    assert not q.qsize()
    assert not q.empty()
    assert not q.full()
    q._queue.append(object())
    assert q.qsize() == 1
    assert not q.empty()
    assert not q.full()
    q._queue.append(object())
    assert q.qsize() == 2
    for _ in range(2):
        q._queue.append(object())
    assert q.qsize() == 4
    assert not q.empty()
    assert q.full()
    q._maxsize = 2
    assert not q.full()
    q._queue.append(object())
    assert q.full()

# Generated at 2022-06-22 04:26:40.376327
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() ==0
    q.__put_internal(1)
    assert q.qsize() ==1
    pass


# Generated at 2022-06-22 04:26:40.933298
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__(): pass

# Generated at 2022-06-22 04:26:43.752522
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass
