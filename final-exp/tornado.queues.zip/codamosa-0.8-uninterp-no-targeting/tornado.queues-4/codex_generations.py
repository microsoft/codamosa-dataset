

# Generated at 2022-06-22 04:17:18.333231
# Unit test for method full of class Queue
def test_Queue_full():
    import time
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=5)
    assert q.full() == False
    for i in range (5):
        q.put_nowait(i)
        assert q.full() == False
    q.put_nowait(i)
    assert q.full() == True



# Generated at 2022-06-22 04:17:20.448341
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True


# Generated at 2022-06-22 04:17:27.881318
# Unit test for method put of class Queue
def test_Queue_put():
    t = Queue(maxsize=0)
    assert(t.empty())
    assert(t.full() == False)
    assert(t.qsize() == 0)
    t.put(2)
    assert(t.empty() == False)
    assert(t.full() == False)
    assert(t.qsize() == 1)
    t.put(3)
    assert(t.qsize() == 2)


# Generated at 2022-06-22 04:17:29.533472
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-22 04:17:33.673257
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')


# Generated at 2022-06-22 04:17:40.525493
# Unit test for method get of class Queue
def test_Queue_get():
    def x():
        print("x")
    def y():
        print("y")
    q = Queue()
    z = q.get()
    z.add_done_callback(x)
    z.add_done_callback(y)
    q.put_nowait("abc")
# test get method of class Queue
test_Queue_get()


# Generated at 2022-06-22 04:17:42.434678
# Unit test for method empty of class Queue
def test_Queue_empty():
    test = Queue()
    assert test.empty() is True


# Generated at 2022-06-22 04:17:49.534481
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    @gen.coroutine
    def sample():
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)
        q = Queue()
        yield q.put(1)



# Generated at 2022-06-22 04:17:55.959233
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert(0, 'high-priority item') == q.get_nowait()
    assert(1, 'medium-priority item') == q.get_nowait()
    assert(10, 'low-priority item') == q.get_nowait()



# Generated at 2022-06-22 04:18:07.898913
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test cases
    q1 = Queue()
    q1.put_nowait(1)
    q1.put_nowait(2)

    q2 = Queue(3)
    q2.put_nowait(-1)
    q2.put_nowait(0)
    q2.put_nowait(1)
    q2.put_nowait(2)

    q3 = Queue(3)
    q3.put_nowait(1)
    q3.put_nowait(2)
    q3.put_nowait(3)
    try:
        q3.put_nowait(4)
    except QueueFull:
        pass

    q4 = Queue()
    q4.put_nowait(0)
    q4.put_nowait('a')



# Generated at 2022-06-22 04:18:24.716441
# Unit test for method get of class Queue
def test_Queue_get():
    # Tornado imports
    import tornado
    import tornado.web
    import tornado.ioloop
    import tornado.gen
    from tornado.queues import Queue 
    
    # Test imports
    import unittest
    import pytest
    from hypothesis import given
    from hypothesis import settings
    import hypothesis.strategies as st
    import logging
    import time
    import pickle
    
    class TestQueue(unittest.TestCase):
        """This class test the method get of class Queue"""
        

# Generated at 2022-06-22 04:18:32.656307
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    import tornado
    @asyncio.coroutine
    def async_coroutine_func():
        yield(2)
    @tornado.gen.coroutine
    def test_aiter():
        q = Queue()
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        for i in q:
            print(i)
    asyncio.get_event_loop().run_until_complete(test_aiter())

# Generated at 2022-06-22 04:18:35.727845
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3


# Generated at 2022-06-22 04:18:41.902852
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    q.put_nowait("abc")
    qi = _QueueIterator(q)
    assert isinstance(qi, _QueueIterator)
    assert isinstance(qi.q, Queue)
    assert qi.__anext__() == q.get()



# Generated at 2022-06-22 04:18:44.573337
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(next(it), Future)
test__QueueIterator___anext__()


# Generated at 2022-06-22 04:18:46.552714
# Unit test for constructor of class QueueEmpty

# Generated at 2022-06-22 04:18:55.144790
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    q = Queue(maxsize=2)
    async def consumer():
        while True:
            item = await q.get()
            try:
                print(('Doing work on %s' % item))
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            print(('Put %s' % item))
            await q.put(item)
    async def main():
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

# Generated at 2022-06-22 04:19:06.363582
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import unittest
    try:
        import concurrent.futures
    except ImportError:
        concurrent = None

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    class QueueTest(unittest.TestCase):
        def setUp(self):
            super(QueueTest, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            super(QueueTest, self).tearDown()


# Generated at 2022-06-22 04:19:13.120611
# Unit test for constructor of class Queue
def test_Queue():
    result_future = Queue(maxsize=2).put("a",None)
    print("hello")
    print("hello")
    print("hello")
    # print("result_future is %s" % result_future)
    print("result_future is %s" % result_future)

if __name__ == "__main__":
    test_Queue()

# Generated at 2022-06-22 04:19:18.017522
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    class MyQueueFull(QueueFull):
        def __str__(self):
            return "my queue full"

    # Check we can call the constructor and __str__.
    msg = str(MyQueueFull())
    assert msg == "my queue full"


# Generated at 2022-06-22 04:19:30.944087
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0
    q.__init__(5)
    assert q.maxsize == 5
    q.__init__()
    assert q.maxsize == 0


# Generated at 2022-06-22 04:19:32.776825
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert q.__repr__() == "<Queue object at 0x%x maxsize=2>" % id(q)


# Generated at 2022-06-22 04:19:34.839162
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = QueueEmpty('Queue is empty')
    print(q)
    assert str(q) == 'Queue is empty'



# Generated at 2022-06-22 04:19:38.939239
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    a = Queue(maxsize = 10)
    assert a.maxsize == 10, 'maxsize of Queue should be equal to its initialization parameter'


# Generated at 2022-06-22 04:19:42.950971
# Unit test for method get of class Queue
def test_Queue_get():
    print("cdjdjd")
    import asyncio
    q = Queue()
    async def f():
      print("jdjdj")
      await q.get()
      print("jdjdj")
    asyncio.run(f())

# Generated at 2022-06-22 04:19:48.687920
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    assert q.empty()
    assert not q.full()
    q.put_nowait(1)
    assert not q.empty()
    assert q.full()
    try:
        q.put_nowait(1)
        assert False
    except QueueFull:
        pass

# Generated at 2022-06-22 04:19:51.489419
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert hasattr(e, '__str__')


# Generated at 2022-06-22 04:20:01.377586
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    assert q.empty(), "queue is empty before put"
    assert q.qsize() == 0, "qsize before put"
    q.put_nowait(1)
    q.put_nowait(2)
    assert not q.empty(), "queue is not empty after put"
    assert q.qsize() == 2, "qsize after put"
    assert not q.full(), "queue is not full"
    q.get()
    q.task_done()
    assert q.qsize() == 1, "qsize before get"
    x = q.get()
    assert x == 2, "get 1 element"
    q.task_done()
    assert q.empty(), "queue is empty after get"

# Generated at 2022-06-22 04:20:08.427145
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    assert it.__anext__() == 1
    assert q.empty() is True
    assert q.qsize() == 0
    q.put_nowait(2)
    assert it.__anext__() == 2
    assert q.empty() is True
    assert q.qsize() == 0
    assert it.__anext__() == 1



# Generated at 2022-06-22 04:20:11.090009
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=0)

    assert q.empty() == True



# Generated at 2022-06-22 04:20:28.218824
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    x = _QueueIterator(Queue())
    typing.get_type_hints(x)

_Q = TypeVar("_Q", bound="Queue[_T]")



# Generated at 2022-06-22 04:20:39.162905
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest
    import sys
    global t
    import time
    import tornado
    import concurrent.futures

    class Test__QueueIterator(AsyncTestCase):

        def setUp(self):
            super().setUp()
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)

        def tearDown(self):
            self.loop.close()
            super().tearDown()

        class Future:

            def __init__(self, loop):
                self.loop = loop
                self._done = concurrent.futures.Future()
                # super().__init__()

            def result(self):
                return self._

# Generated at 2022-06-22 04:20:45.136328
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    pass
    # q = Queue[int](2)
    # q.put(1)
    # q.put(2)
    # q.put(3)
    # i = _QueueIterator[int](q)
    # i.__anext__()
    # i.__anext__()
    # i.__anext__()



# Generated at 2022-06-22 04:20:48.239987
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue[int]()
    q.put(1)
    q.put(2)
    it = _QueueIterator(q)
    assert await it.__anext__() == 1
    assert await it.__anext__() == 2



# Generated at 2022-06-22 04:20:52.103377
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-22 04:20:56.962964
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    while True:
        try:
            q.put_nowait(1)
        except QueueFull:
            break
    assert len(q._queue) == q._maxsize
    assert q._queue[0] == 1


# Generated at 2022-06-22 04:21:02.772582
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        assert(False)
    except QueueFull:
        assert(True)
    assert(q.qsize() == 2)


# Generated at 2022-06-22 04:21:04.049243
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    print(q.empty())


# Generated at 2022-06-22 04:21:12.076561
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    q._queue = [0,1]
    assert q.qsize() == 2
    q.__put_internal(1)
    assert q.qsize() == 3
    assert q._queue == [0,1,1]

    q = Queue(maxsize = 2)
    q.__put_internal(2)
    assert q.qsize()==1
    assert q._queue == [2]

    q = Queue(maxsize=1)
    q.__put_internal(1)
    q.__put_internal(2)
    assert q.qsize() == 2
    assert q._queue == [1,2]


# Generated at 2022-06-22 04:21:19.759771
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-22 04:21:53.799738
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=15)
    result = None
    try:
        q.put_nowait(10)
    except QueueFull:
        pass
    else:
        print('put succeed')
        result = True
    if result:
        return True
    else:
        return False


# Generated at 2022-06-22 04:22:02.360123
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.ioloop import IOLoop
    import time
    import functools
    import random
    import threading

    def _test_join():
        def _test_join_group(group, maxsize):
            q = Queue(maxsize)
            ioloop = IOLoop()
            ioloop.make_current()
            items = list(range(random.randint(2, maxsize * 2)))
            future = Future()
            ioloop.add_future(future, lambda f: ioloop.stop())
            q.join()
            for item in items:
                q.put(item)

            def consumer():
                for item in items:
                    assert item == q.get()
                    q.task_done()

            for thread in group:
                threading.Thread(target=consumer).start()

# Generated at 2022-06-22 04:22:04.635769
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        pass



# Generated at 2022-06-22 04:22:06.352602
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)


# Generated at 2022-06-22 04:22:14.238966
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    import asyncio
    loop = asyncio.get_event_loop()
    #
    async def f(q: tornado.queues.Queue) -> None:
        #
        class CustomQueue(tornado.queues.Queue):
            def __aiter__(self) -> tornado.queues.Queue:
                return self
        #
        q: CustomQueue[int]
        await q.put(10)
        await q.put(20)
        #
        async for i in q:
            assert i in {10, 20}
        #
        q.task_done()
        q.task_done()
    #
    q: tornado.queues.Queue[int] = tornado.queues.Queue()
    coro = f(q)
    loop.run_until_complete(coro)
#

# Generated at 2022-06-22 04:22:24.956757
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert(q.empty())
    q.put_nowait(3)
    assert(q.qsize()==1)
    assert(q.full()==False)
    assert(q.get_nowait()==3)
    assert(q.empty())
    assert(q.put_nowait(2)==None)
    assert(q.put_nowait(1)==None)
    assert(q.full())
    try:
        q.put_nowait(4)
    except QueueFull:
        pass
    else:
        raise AssertionError("Expected QueueFull")


# Generated at 2022-06-22 04:22:26.978481
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    print(q.task_done())
# test_Queue_task_done()



# Generated at 2022-06-22 04:22:30.060272
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=5)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)

    assert q.qsize() == 5
test_Queue_qsize()


# Generated at 2022-06-22 04:22:35.490998
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    producer = ioloop.IOLoop.current().spawn_callback(q.put, 1)
    consumer = ioloop.IOLoop.current().spawn_callback(q.get)
    time.sleep(1)
    assert producer.done()
    assert consumer.done()
    assert producer.result() == None
    assert consumer.result() == 1
    q.task_done()
    assert q.qsize() == 0    
    

# Generated at 2022-06-22 04:22:39.234600
# Unit test for constructor of class QueueFull
def test_QueueFull():
    exception = QueueFull(1, 2, 3)
    assert exception.args == (1, 2, 3)
    assert str(exception) == '1, 2, 3'

# ------------------------------------------------------------------------------
# Queue implementation with getters and putters return Future.
# ------------------------------------------------------------------------------



# Generated at 2022-06-22 04:23:25.630561
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    assert isinstance(q.__aiter__(), _QueueIterator)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join

# Generated at 2022-06-22 04:23:34.684246
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from datetime import datetime

    q = Queue(maxsize=2)

    async def consumer():
        print("Consumer is waiting for value")
        async for item in q:
            try:
                print("Consumer received value: ", item)
                # await gen.sleep(0.01)
            finally:
                print("Consumer finished task")
                q.task_done()

    async def producer():
        for item in range(5):
            # await q.put(item)
            q.put(item)
            print("Producer puts value: ", item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer

# Generated at 2022-06-22 04:23:38.053916
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Initialize input argument
    q = Queue()
    # Call method empty
    result = q.empty()
    assert result == True


# Generated at 2022-06-22 04:23:48.208745
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    if(q.qsize() != 0):
        raise Exception("Got: " + q.qsize())
    # Need to test put, push, get and get_nowait
    q.put_nowait(2)
    if(q.qsize() != 1):
        raise Exception("Got: " + q.qsize())
    q.put_nowait(3)
    if(q.qsize() != 2):
        raise Exception("Got: " + q.qsize())
    q.get_nowait()
    if(q.qsize() != 1):
        raise Exception("Got: " + q.qsize())


# Generated at 2022-06-22 04:23:50.421196
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    t = q.get()
    assert isinstance(t, Future)


# Generated at 2022-06-22 04:23:59.768010
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    def run_until_complete(coro):
        return ioloop.IOLoop.current().run_sync(coro)

    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert run_until_complete(gen.maybe_future(list(q))) == [1, 2, 3]
    assert run_until_complete(gen.maybe_future(list(q))) == [1, 2, 3]
    assert q.qsize() == 3
    assert q.get_nowait() == 1
    q.task_done()
    assert run_until_complete(gen.maybe_future(list(q))) == [2, 3]
    assert q.qsize() == 2


# Generated at 2022-06-22 04:24:06.864133
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from random import choice
    
    q = Queue()
    for i in range(10):
        q.put_nowait(i)
    
    for i in range(11):
        try:
            q.put_nowait(i)
        except QueueFull:
            print("Queue is full, so put_nowait(i) raises error")


# Generated at 2022-06-22 04:24:13.794119
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    # Insertion of a mid-priority item
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    assert q.qsize() == 1

    # Insertion of a high-priority item
    q = PriorityQueue()
    q.put((0, 'high-priority item'))
    assert q.qsize() == 1

    # Insertion of a low-priority item
    q = PriorityQueue()
    q.put((10, 'low-priority item'))
    assert q.qsize() == 1

    # Retrieval of a high-priority item
    q = PriorityQueue()
    q.put((0, 'high-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')

    # Retrieval of a mid-priority item
    q = Priority

# Generated at 2022-06-22 04:24:25.275756
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue()
    s = queue.__str__()
    assert s == "<Queue maxsize=0 queue=deque([])>" or s == "<Queue queue=deque([]) maxsize=0>", s
    queue.put_nowait(1)
    s = queue.__str__()
    assert s == "<Queue maxsize=0 queue=deque([1])>" or s == "<Queue queue=deque([1]) maxsize=0>", s
    queue = Queue(2)
    s = queue.__str__()
    assert s == "<Queue maxsize=2 queue=deque([])>" or s == "<Queue queue=deque([]) maxsize=2>", s
    queue.put_nowait(1)
    queue.put_nowait(2)
    s = queue.__str__()


# Generated at 2022-06-22 04:24:31.964648
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """Unit test for method get_nowait of class Queue"""
    q = Queue(maxsize=2)
    q._queue.appendleft(1)
    assert q.get_nowait() == 1
    q._queue.appendleft(2)
    q._getters.append(gen.Future())
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3



# Generated at 2022-06-22 04:25:50.432347
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=1)
    qsize = q.qsize()
    print(qsize)
#     for i in range(100):
#         q.put(1)
#         print(q.qsize())


# Generated at 2022-06-22 04:25:57.248903
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.locks import Lock
    from tornado.queues import Queue
    from tornado.iostream import StreamClosedError
    from tornado.tcpclient import TCPClient
    import asyncio
    lock = Lock()
    async with lock:
        self = Queue(maxsize=2)
        async with lock:
            await self.put('(self, maxsize=2)')
            await self.put('async with lock:')
            result = []
            async for item in self:
                result.append(item)
            assert result == ['(self, maxsize=2)', 'async with lock:']



# Generated at 2022-06-22 04:26:04.706463
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	# Create an instance of the Queue class
	# This class consists of `deque` and `getters`.
	q = Queue(maxsize = 2)
	# If the queue becomes empty, and the getters are not empty, the getter is popped, and the popped value is popped out.
	q._getters = collections.deque([1])
	q._queue = collections.deque([3])
	q._putters = collections.deque([])
	q.get_nowait()
	assert q._queue[0] == 1

# Generated at 2022-06-22 04:26:07.349329
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    temp = LifoQueue()
    temp._init()
    temp._put(1)
    assert temp._queue[0] == 1

    assert temp._get() == 1
    assert len(temp._queue) == 0

# Generated at 2022-06-22 04:26:09.448644
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    q.__put_internal(1)
    q.__put_internal(2)
    assert q.qsize() == 2


# Generated at 2022-06-22 04:26:11.750525
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-22 04:26:15.747752
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert not q.empty()
    assert  q.full()
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        assert True
    else:
        assert False

test_Queue_put_nowait()

# Generated at 2022-06-22 04:26:24.838835
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q = Queue(maxsize=3)
    assert str(q) == "<Queue maxsize=3 queue=deque([])>"
    q._queue = ["a", "b", "c"]
    assert str(q) == "<Queue maxsize=3 queue=deque(['a', 'b', 'c'])>"
    q._getters = ["g1", "g2"]
    assert str(q) == "<Queue maxsize=3 queue=deque(['a', 'b', 'c']) getters[2]>"
    q._putters = ["p1", "p2"]

# Generated at 2022-06-22 04:26:31.439891
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize = 2
    q = Queue(maxsize)
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull:
        print('Queue is full')


# Generated at 2022-06-22 04:26:33.743349
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    while not q.empty():
        pass