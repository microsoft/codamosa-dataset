

# Generated at 2022-06-22 04:17:14.000824
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False

# Generated at 2022-06-22 04:17:18.645006
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    for i in range(5):
        q.put(i)
    qsize = q.qsize()
    if qsize == 5:
        print(True)
    else:
        print(False)

test_Queue_qsize()


# Generated at 2022-06-22 04:17:27.441525
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0, 'qsize not zero'
    q.put_nowait(1)
    assert q.qsize() == 1, 'qsize not one'
    q.put_nowait(2)
    assert q.qsize() == 2, 'qsize not two'
    q.task_done()
    assert q.qsize() == 1, 'qsize not one'
    q.task_done()
    assert q.qsize() == 0, 'qsize not zero'


# Generated at 2022-06-22 04:17:29.948211
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test non-existing method put_nowait
    q = Queue()
    item = 1
    q.put_nowait(item)


# Generated at 2022-06-22 04:17:31.945163
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()


# Generated at 2022-06-22 04:17:33.368029
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        assert type(e) == QueueEmpty



# Generated at 2022-06-22 04:17:46.698600
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import pytest

    @gen.coroutine
    def test_IOLoop_current():
        return ioloop.IOLoop.current()

    @gen.coroutine
    def worker(q: "Queue"):
        while True:
            item = yield q.get()
            try:
                if item is None:
                    return
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def main():
        q = Queue(maxsize=2)
        # Start workers, without waiting (since they never finish).
        for _i in range(2):
            test_IOLoop_current().spawn_callback(worker, q)

# Generated at 2022-06-22 04:17:50.922842
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)  # type: ignore
    assert it.q == q


# Generated at 2022-06-22 04:17:53.332483
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        assert e.__class__.__name__ == QueueEmpty.__name__


# Generated at 2022-06-22 04:17:56.430822
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    q = Queue()
    expectedResult = "<Queue at 0x7fc8e4a10318 maxsize=0 queue=deque([])>"
    assert repr(q) == expectedResult

# Generated at 2022-06-22 04:18:19.621319
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))

if __name__ == "__main__":
    test_PriorityQueue()



# Generated at 2022-06-22 04:18:25.661893
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)

    # empty
    assert q.empty() == True
    assert q.full() == False

    q.put_nowait(1)

    # not empty
    assert q.empty() == False
    assert q.full() == False

    q.put_nowait(1)

    # empty
    assert q.empty() == False
    assert q.full() == True

    q.get_nowait()
    q.get_nowait()

    # empty
    assert q.empty() == True
    assert q.full() == False



# Generated at 2022-06-22 04:18:34.950270
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    print("inside test__QueueIterator___anext__")
    # 1. test case with three get
    q = Queue()
    q.put_nowait("X")
    q.put_nowait("Y")
    q.put_nowait("Z")
    qi = _QueueIterator(q)
    async def test__QueueIterator___anext___1():
        print("inside test__QueueIterator___anext___1")
        assert await qi.__anext__() is "X"
        assert await qi.__anext__() is "Y"
        assert await qi.__anext__() is "Z"
        asyncio.get_event_loop().stop()
    asyncio.ensure_future(test__QueueIterator___anext___1())
    asyncio.get_event_loop().run

# Generated at 2022-06-22 04:18:36.543984
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    global q1
    q1 = Queue(maxsize=0)
    print(q1.get_nowait())



# Generated at 2022-06-22 04:18:40.814297
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        x = QueueEmpty()
    except:
        pass



# Generated at 2022-06-22 04:18:49.329002
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    q.put_nowait(3)
    assert q.get_nowait() == 3



# Generated at 2022-06-22 04:18:51.496863
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    q.task_done()
    assert not q.full()
    q.task_done()
    assert not q.full()


# Generated at 2022-06-22 04:18:53.794337
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue() 
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:18:56.111580
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # Test constructor
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-22 04:18:57.954366
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')



# Generated at 2022-06-22 04:19:10.385069
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()

# Generated at 2022-06-22 04:19:12.012859
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:19:12.576904
# Unit test for constructor of class QueueFull
def test_QueueFull():
    pass


# Generated at 2022-06-22 04:19:24.057556
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:34.422811
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    queue = PriorityQueue()
    assert(queue.qsize() == 0)
    queue.put((1, 'medium-priority item'))
    assert(queue.qsize() == 1)
    queue.put((0, 'high-priority item'))
    assert(queue.qsize() == 2)
    queue.put((10, 'low-priority item'))
    assert(queue.qsize() == 3)
    assert(queue.get_nowait() == (0, 'high-priority item'))
    assert(queue.get_nowait() == (1, 'medium-priority item'))
    assert(queue.get_nowait() == (10, 'low-priority item'))

# Generated at 2022-06-22 04:19:37.355212
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        pass


# Generated at 2022-06-22 04:19:46.455762
# Unit test for method full of class Queue
def test_Queue_full():    
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    # Unit test for method put_nowait of class Queue
    def test_Queue_put_nowait():
        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)
    
        async def main():
            # Start consumer without waiting (since it never finishes).
            IOLoop.current().spawn_callback(consumer)
            await producer()     # Wait

# Generated at 2022-06-22 04:19:48.689127
# Unit test for method empty of class Queue
def test_Queue_empty():
  q = Queue()
  q._queue = collections.deque()
  assert q.empty()


# Generated at 2022-06-22 04:20:00.375564
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Check that empty returns false when the queue is not empty (i.e. not full)
    q = Queue()
    q.put(0)
    assert q.empty() == False
    # Check that empty returns True when the queue is empty and full
    q = Queue(maxsize=1)
    q.put(0)
    assert q.empty() == False
    # Check that putting None raises no error
    q.put(None)
    # Check that empty returns true when the queue is empty and not full
    q = Queue()
    assert q.empty() == True
    # Check that empty returns true when the queue is empty and not full
    q = Queue()
    q.put(None)
    q.get_nowait()
    assert q.empty() == True



# Generated at 2022-06-22 04:20:02.943416
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass


# Generated at 2022-06-22 04:20:26.562666
# Unit test for method join of class Queue
def test_Queue_join():
    import cProfile

# Generated at 2022-06-22 04:20:29.411819
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    try:
        raise QueueFull("Test")
    except QueueFull as e:
        print("Test constructor of class QueueFull", e)


# Generated at 2022-06-22 04:20:32.184588
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    LifoQueue()

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:20:36.402793
# Unit test for method full of class Queue
def test_Queue_full():
    queue = Queue(maxsize=2)
    assert queue.full() == False
    queue.put_nowait(1)
    assert queue.full() == False
    queue.put_nowait(1)
    assert queue.full() == True



# Generated at 2022-06-22 04:20:43.261888
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q._format() == "maxsize=0 queue=deque([]) tasks=0"
    q._unfinished_tasks = 1
    assert q._format() == "maxsize=0 queue=deque([]) tasks=1"
    q._getters = collections.deque(["abc"])
    assert q._format() == "maxsize=0 queue=deque([]) getters[1] tasks=1"
    q._putters = collections.deque(["abc"])
    assert q._format() == "maxsize=0 queue=deque([]) getters[1] putters[1] tasks=1"



# Generated at 2022-06-22 04:20:44.961134
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    exc=QueueEmpty()
    print(QueueEmpty.__doc__)
    print(exc)



# Generated at 2022-06-22 04:20:51.760292
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put(0)
    assert q.empty() == False
    assert q.full() == False
    assert q.get_nowait() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    assert q._queue == collections.deque([])
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished.is_set() == True


# Generated at 2022-06-22 04:20:53.940205
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    future = Future()
    try:
        future.set_result(q.get_nowait())
    except QueueEmpty:
        future = Future()
        try:
            future.set_result(q.get_nowait())
        except QueueEmpty:
            pass
    pass

# Generated at 2022-06-22 04:21:04.297410
# Unit test for method put of class Queue
def test_Queue_put():

    #testcase 1
    q = Queue(maxsize=0)
    time_now = time.time()
    result = q.put(1)
    time_end = time.time()
    assert(result.done() == True)
    assert(result.result() == None)
    assert(time_end - time_now < 0.5)

    #testcase 2
    q = QueueFull()
    time_now = time.time()
    result = q.put(1)
    time_end = time.time()
    assert(result.done() == True)
    assert(result.result() == None)
    assert(time_end - time_now < 0.5)


# Generated at 2022-06-22 04:21:11.784059
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert(q.get_nowait()) == (1, 'high-priority item')
    assert(q.get_nowait()) == (10, 'low-priority item')
    q.put((0, 'meduim-priority item'))
    q.put((1, 'some other meduim-priority item'))
    assert(q.get_nowait()) == (0, 'meduim-priority item')
    assert(q.get_nowait()) == (1, 'some other meduim-priority item')



# Generated at 2022-06-22 04:21:35.283001
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)


# Generated at 2022-06-22 04:21:44.950825
# Unit test for method join of class Queue
def test_Queue_join():
    # Tests the method Queue.join()
    import time
    import tornado
    from tornado.queues import Queue

    TEST_TIMEOUT = datetime.timedelta(milliseconds=20)
    TASK_TIME = datetime.timedelta(milliseconds=5)
    QUEUE_SIZE = 3

    q = Queue(maxsize=QUEUE_SIZE)
    start = time.time()
    result = q.join(timeout=TEST_TIMEOUT)
    assert result.exception() is None

    result = tornado.gen.sleep(TASK_TIME.total_seconds())
    for i in range(QUEUE_SIZE):
        q.put(result)
    result = q.join(timeout=TEST_TIMEOUT)
    assert result.exception() is None


# Generated at 2022-06-22 04:21:50.347690
# Unit test for method full of class Queue
def test_Queue_full():
    class test_class(Queue):

        def __init__(self, maxsize: int = 0) -> None:
            if maxsize is None:
                raise TypeError("maxsize can't be None")

            if maxsize < 0:
                raise ValueError("maxsize can't be negative")

            self._maxsize = maxsize
            self._init()
            self._getters = collections.deque([])  # type: Deque[Future[_T]]
            self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
            self._unfinished_tasks = 0
            self._finished = Event()
            self._finished.set()

    t = test_class(maxsize=3)
    assert t.full() == False
    t.put_nowait(1)


# Generated at 2022-06-22 04:21:56.352142
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:21:56.885721
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert Queue().empty()


# Generated at 2022-06-22 04:22:09.360713
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import itertools
    import logging
    import sys
    import time
    import unittest

    from tornado.log import enable_pretty_logging
    from tornado.queues import Queue

    iter_counter = itertools.count()

    async def async_get(q):
        await q.put(None)

    async def async_put(q):
        await q.get()

    async def async_put_get(q):
        await q.put(next(iter_counter))
        await q.get()

    class TestQueue(unittest.TestCase):

        def test_queue(self):
            q = Queue()
            self.assertEqual(str(q), "<Queue maxsize=0 queue=deque([])>")
            self.assertEqual(q.qsize(), 0)
            self

# Generated at 2022-06-22 04:22:17.063709
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    from tornado.queues import Queue
    q = Queue()
    for i in range(4):
        q.put_nowait(i)
    q.get_nowait()
    q.get_nowait()
    q.task_done()
    q.task_done()
    pytest.raises(Exception, q.task_done)


# Generated at 2022-06-22 04:22:25.080530
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue = Queue()
    print(queue)
    queue.put_nowait(1)
    print(queue)
    queue.put_nowait(2)
    print(queue)
    queue.put_nowait(3)
    print(queue)
    queue.get_nowait()
    print(queue)
    queue.get_nowait()
    print(queue)
    queue.get_nowait()
    print(queue)


# Generated at 2022-06-22 04:22:35.015812
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-22 04:22:37.347437
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert len(q._queue) == 0
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-22 04:23:09.207422
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # queue = [0,1,2,3,4]
    q = Queue()
    assert q.empty() == True
    assert q.full() == False
    # QueueEmpty:
    try:
        q.get_nowait()
    except QueueEmpty as e:
        print(e)
    else:
        print('Queue is not empty!')
        exit(1)
    try:
        q.put_nowait(0)
    except QueueFull as e:
        print(e)
        exit(1)
    else:
        print('put 0 in queue')
    assert q.get_nowait() == 0
    assert q.empty() == True
    for i in range(1,5):
        q.put_nowait(i)
        assert q.full() == False
    q

# Generated at 2022-06-22 04:23:13.584975
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-22 04:23:22.963267
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    # On python3 this is just assertEqual
    assert str(q) == "<Queue maxsize=%r queue=%r>" % (2, collections.deque([]))
    # Put 0
    q.put_nowait(0)
    assert str(q) == "<Queue maxsize=%r queue=%r>" % (2, collections.deque([0]))
    # Put 1
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=%r queue=%r>" % (2, collections.deque([0, 1]))
    assert repr(q) == "<Queue at %s maxsize=%r queue=%r>" % (hex(id(q)), 2, collections.deque([0, 1]))
    # Remove

# Generated at 2022-06-22 04:23:27.909370
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    for i in range(1,4):
        q.put(i)
    assert q._queue == collections.deque([1, 2, 3])
    assert q.qsize() == 3


# Generated at 2022-06-22 04:23:30.970974
# Unit test for constructor of class Queue
def test_Queue():
    Q = Queue()
    assert Q.maxsize == 0
    Q1 = Queue(3)
    assert Q1.maxsize == 3


# Generated at 2022-06-22 04:23:33.789253
# Unit test for method full of class Queue
def test_Queue_full():
    for maxsize in (-2, -1, 0, 1, 2):
        q = Queue(maxsize)
        for i in range(maxsize):
            q.put_nowait(object())
            assert not q.full()
        assert q.full()



# Generated at 2022-06-22 04:23:38.671549
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.empty(), "Queue is empty"
    assert q.qsize() == 0
    for i in range(1, 4):
        q.put(i)
    assert q.qsize() == 3
    assert not q.empty(), 'Queue is not empty'



# Generated at 2022-06-22 04:23:50.525418
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  from tornado.queues import Queue
  from tornado import gen
  from tornado.ioloop import IOLoop

  q = Queue(maxsize=2)

  async def consumer():
    async for item in q:
      try:
        print('Doing work on %s' % item)
        await gen.sleep(0.01)
      finally:
        q.task_done()

  async def producer():
    for item in range(5):
      await q.put(item)
      print('Put %s' % item)

  async def main():
    # Start consumer without waiting (since it never finishes).
    IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

# Generated at 2022-06-22 04:23:59.872989
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import time
    import threading
    q = Queue(0)
    # print(q.maxsize)
    # print(q.qsize())
    # print(q.empty())
    # print(q.full())
    # print(q.put_nowait(1))
    # print(q.put_nowait(2))
    # print(q.put_nowait(3))
    # print(q.qsize())
    # print(q.put_nowait(4))
    # print(q.put_nowait(5))
    # print(q.qsize())
    # print(q.get_nowait())
    # print(q.qsize())
    # print(q.get_nowait())
    # print(q.qsize())
    # print(q.get_now

# Generated at 2022-06-22 04:24:02.915846
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    _QueueIterator("a" or Queue("a")).__anext__()


# Generated at 2022-06-22 04:24:56.833282
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import asyncio
    async def consumer(q):
        while True:
            item = await q.get()
            try:
                print('doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()
    async def main():
        q = Queue()
        asyncio.ensure_future(consumer(q))
        for item in range(5):
            await q.put(item)
            print('put %s' % item)
        await q.join()
        print('Done')
    asyncio.run(main())

# Generated at 2022-06-22 04:24:58.324856
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('test')
    except QueueFull as e:
        print(e)


# Generated at 2022-06-22 04:25:08.498912
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    q._unfinished_tasks = 3
    assert (not q._finished.is_set())
    q.task_done()
    assert (not q._finished.is_set())
    q.task_done()
    assert (not q._finished.is_set())
    q.task_done()
    assert (q._finished.is_set())
    q.task_done()
    assert (q._finished.is_set())
    q._unfinished_tasks = 3
    assert (not q._finished.is_set())


# Generated at 2022-06-22 04:25:20.245153
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:25:27.248312
# Unit test for method put of class Queue
def test_Queue_put():
    q =  Queue(maxsize=2)
    async def consumer():
        while True:
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                finally:
                    q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    io_loop = ioloop.IOLoop.current()
    io_loop.add_callback(consumer)
    io_loop.add_callback(producer)
    io_loop.start()


# Generated at 2022-06-22 04:25:35.578250
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize = 42)
    assert q.__str__() == "<Queue maxsize=42 queue=deque([])>"
    q.put_nowait(42)
    assert q.__str__() == "<Queue maxsize=42 queue=deque([42])>"
    q.get_nowait()
    assert q.__str__() == "<Queue maxsize=42 queue=deque([])>"



# Generated at 2022-06-22 04:25:36.927724
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    obj = Queue()
    a = _QueueIterator(obj)
    b = a.__anext__()


# Generated at 2022-06-22 04:25:45.292820
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=5)
    print("maxsize is: {}".format(q.maxsize))
    print("qsize is: {}".format(q.qsize()))
    print("is empty? {}".format(q.empty()))
    print("is full? {}".format(q.full()))
    print("put(1)")
    q.put(1)
    print("put(2)")
    q.put(2)
    print("qsize is: {}".format(q.qsize()))
    print("get_nowait() is: {}".format(q.get_nowait()))
    print("get_nowait() is: {}".format(q.get_nowait()))
    print("is empty? {}".format(q.empty()))

# Generated at 2022-06-22 04:25:55.433629
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import Any
    from tornado.platform.asyncio import Awaitable
    from tornado.platform.asyncio import Iterable
    from typing import Any
    from typing import Iterator
    async def async_test():
        AsyncIOLoop().install()
        q = Queue()
        it = _QueueIterator(q)
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        assert await it.__anext__() == 1
        assert await it.__anext__() == 2
        assert await it.__anext__() == 3
        try:
            await it.__anext__()
        except QueueEmpty:
            pass

# Generated at 2022-06-22 04:25:58.096362
# Unit test for method join of class Queue
def test_Queue_join():
    # cpython starts sequential version of the test
    def _test_Queue_join(self, timeout: Optional[Union[float, datetime.timedelta]] = None) -> Awaitable[None]:
        return self._finished.wait(timeout)
    pass

