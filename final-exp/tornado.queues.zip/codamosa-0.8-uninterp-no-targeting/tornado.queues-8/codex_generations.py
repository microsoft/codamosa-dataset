

# Generated at 2022-06-22 04:17:20.482751
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(3):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

test_Queue

# Generated at 2022-06-22 04:17:25.054674
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # Tested in test_coroutine_queue
    pass
    #l: typing.List[typing.Any] = []
    #q: Queue[typing.Any] = Queue()
    #q.put(1)



# Generated at 2022-06-22 04:17:36.579414
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=5)
    assert str(q) == '<Queue maxsize=5>'
    q.put_nowait(1)
    assert str(q) == '<Queue maxsize=5 queue=[1]>'
    q.get()
    assert str(q) == '<Queue maxsize=5>'
    q.put_nowait(2)
    q.put_nowait(3)
    assert str(q) == '<Queue maxsize=5 queue=[2, 3]>'
    q._getters.append(Future())
    assert str(q) == '<Queue maxsize=5 queue=[2, 3] getters[1]>'
    q._putters.append((4, Future()))

# Generated at 2022-06-22 04:17:48.198602
# Unit test for method join of class Queue
def test_Queue_join():
    import datetime
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado import gen
    queue = Queue(maxsize=2)
    @gen.coroutine
    def consumer():
        while True:
            item = yield queue.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.1)
            finally:
                queue.task_done()
    @gen.coroutine
    def producer():
        for item in range(5):
            yield queue.put(item)
            print('Put %s' % (item,))
    @gen.coroutine
    def main():
        IOLoop.current().spawn_callback(consumer)
        yield producer()
        yield queue.join()
        print('Done')
       

# Generated at 2022-06-22 04:17:52.684126
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(1)
    assert q.maxsize == 1
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-22 04:18:01.926781
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:18:13.336611
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import time

    loop = asyncio.get_event_loop()
    q = Queue()

    @gen.coroutine
    def put(item):
        yield q.put(item)

    @gen.coroutine
    def put_done():
        yield q.put(item,done=True)

    @gen.coroutine
    def get():
        print(q.qsize())
        yield q.get()

    @gen.coroutine
    def test_join_1():
        for i in range(5):
            loop.run_sync(put,i)
            print(q.qsize())
        yield q.join()
        print(q.qsize())

    @gen.coroutine
    def test_join_2():
        for i in range(5):
            loop.run_

# Generated at 2022-06-22 04:18:17.259083
# Unit test for method join of class Queue
def test_Queue_join():
    # ...
    q = Queue()
    f = q.join()
    f.add_done_callback(lambda f: print("Queue join finished"))
    # Call the function in q.join
    f._callbacks[0][0](f)


# Generated at 2022-06-22 04:18:18.662856
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    q.empty()

# Generated at 2022-06-22 04:18:20.917265
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert q.qsize() == 0
    assert q.empty()

# Generated at 2022-06-22 04:18:37.101411
# Unit test for method put of class Queue
def test_Queue_put():
    import unittest

    import tornado.queues

    class QueueTest(unittest.TestCase):
        def test_put(self):

            class MyException(Exception):
                pass

            q = tornado.queues.Queue()

            async def put():
                await q.put(1)
                await q.put(2)
                await q.put(3)

            async def get():
                self.assertEqual(1, await q.get())
                self.assertEqual(2, await q.get())
                self.assertEqual(3, await q.get())

            ioloop = tornado.ioloop.IOLoop.current()
            ioloop.add_callback(put)
            ioloop.add_callback(get)
            ioloop.run_sync(lambda: q.join())



# Generated at 2022-06-22 04:18:39.108556
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:18:44.713064
# Unit test for constructor of class Queue
def test_Queue():
    print("Test Queue() constructor")
    queue = Queue()
    assert(queue._maxsize == 0)
    assert(queue._queue is None)
    assert(queue._getters == collections.deque())
    assert(queue._putters == collections.deque())
    assert(queue._unfinished_tasks == 0)
    assert(queue._finished is not None)
    

# Generated at 2022-06-22 04:18:52.728061
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0

    q = Queue()
    assert q.maxsize == 0
    assert q.qsize() == 0

    try:
        q = Queue(maxsize=-1)
        assert False
    except ValueError as e:
        assert str(e) == "maxsize can't be negative"

    try:
        q = Queue(maxsize=None)
        assert False
    except TypeError as e:
        assert str(e) == "maxsize can't be None"

    q = Queue(maxsize=2)
    assert not q.empty()
    assert not q.full()



# Generated at 2022-06-22 04:19:04.572709
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    import tornado.gen
    import tornado.ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks

# Generated at 2022-06-22 04:19:17.229481
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    t = q.qsize()
    print(t)
    q.put(1)
    q.put(2)
    q.put_nowait(3)
    print(q.maxsize)
    t = q.get()
    t1 = q.get_nowait()
    print(t)
    print(t1)
    q.task_done()
    q.task_done()
    q = Queue(maxsize=1)
    q.put_nowait(1)
    print(q.full())
    q.task_done()
    print(q.empty())
    q._init()
    print(q.empty())
    q._put(1)
    q._get()



# Generated at 2022-06-22 04:19:29.643681
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    loop = IOLoop.current()
    async def consumer():
        await q.get()
        await q.get()
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
        q.task_done()
        q.task_done()
        print('Done')
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-22 04:19:31.004345
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    repr_value = repr(q)
    assert repr_value == "<Queue at 0000000000000027 maxsize=0 queue=deque([])>"



# Generated at 2022-06-22 04:19:42.538680
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:54.841121
# Unit test for method join of class Queue
def test_Queue_join():
    import collections
    import datetime
    import queue
    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import concurrent.futures
    import typing


    def _set_timeout(
        future: tornado.concurrent.Future, timeout: typing.Optional[typing.Union[float, datetime.timedelta]]
    ) -> None:
        if timeout is not None:

            def on_timeout() -> None:
                if not future.done():
                    future.set_exception(tornado.gen.TimeoutError())

            io_loop = tornado.ioloop.IOLoop.current()
            timeout_handle = io_loop.add_timeout(timeout, on_timeout)

# Generated at 2022-06-22 04:20:14.416740
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    print('maxsize = %s'%q.maxsize)
    print('qsize = %s'%q.qsize())
    print('empty = %s'%q.empty())
    print('full = %s'%q.full())
    print('task_done = %s'%q.task_done())
    q.put(3)
    q.put(4)
    q.put(5)
    print(q._format())
    print('maxsize = %s'%q.maxsize)
    print('qsize = %s'%q.qsize())
    print('empty = %s'%q.empty())
    print('full = %s'%q.full())
    print('task_done = %s'%q.task_done())

# Generated at 2022-06-22 04:20:25.645885
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    
    q = Queue(maxsize=2)
    # Should be False
    assert q.full() == False

    async def consumer():
        async for item in q:
            try:
                assert item == 1
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
        # Should be True
        assert q.full() == True
    
    loop = IOLoop.current()
    loop.run_sync(consumer)
    loop.run_sync(producer)
    # Should be False
    assert q.full() == False

    q.task_done()
    


# Generated at 2022-06-22 04:20:27.563925
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    QueueFull()



# Generated at 2022-06-22 04:20:29.890192
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    if(q.qsize() != 0):
        return False
    else:
        return True


# Generated at 2022-06-22 04:20:37.535598
# Unit test for method full of class Queue
def test_Queue_full():
    import queue
    import datetime
    import time
    import numpy as np

    q = queue.Queue(maxsize=20)
    a= q.full()
    print(a)

    q.put(1)
    q.put(2)
    q.put(3)
    a = q.full()
    print(a)

    q.get()
    q.get()
    q.get()
    a = q.full()
    print(a)


# Generated at 2022-06-22 04:20:44.623326
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)

    print(q)
    assert str(q) == "<Queue maxsize=2 queue=deque([])>"

    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    assert not q.empty()

    print(q)
    assert str(q) == "<Queue maxsize=2 queue=deque([1, 2])>"



# Generated at 2022-06-22 04:20:47.567762
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[str]()
    q.put_nowait("a")
    q.put_nowait("b")
    it = _QueueIterator(q)
    assert it.__anext__() is not None



# Generated at 2022-06-22 04:20:49.627604
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)
print("test_Queue___str__: {}".format(test_Queue___str__()))



# Generated at 2022-06-22 04:20:50.772379
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True


# Generated at 2022-06-22 04:20:58.556675
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    from tornado.queues import Queue
    async def test_1():
        q = Queue()
        q.put_nowait(1)
        assert q.get_nowait() == 1
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.ensure_future(test_1()))


# Generated at 2022-06-22 04:21:11.397149
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:21:17.962983
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    async def main():
        q = Queue()
        q.put_nowait(0)
        try:
            q.task_done()
        except ValueError as ve:
            print("caught error: %s", ve)
    tornado.ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-22 04:21:27.287210
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest
    from asyncio import Future, gather

    class Test(_QueueIterator, AsyncTestCase):
        @gen_test
        def test__QueueIterator__anext__(self):
            def f():
                q = Queue()
                q.put_nowait(1)
                it = _QueueIterator(q)
                f = next(it)
                assert f.result() == 1
            f()
        test__QueueIterator__anext__.__no_skip__ = True

    unittest.main()



# Generated at 2022-06-22 04:21:30.662769
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Test Queue.__aiter__()
    q = Queue(maxsize=2)
    result = q.__aiter__()
    assert result is not None

# Generated at 2022-06-22 04:21:34.889913
# Unit test for method put of class Queue
def test_Queue_put():
    import tornado.ioloop
    import time
    import tornado.testing
    import inspect
    def run_test(method, arguments, expected):
        queue = Queue()
        result = getattr(queue, method)(*arguments)
        if expected != inspect.isawaitable(result):
            return False
        # FIXME: get a more robust comparison
        if isinstance(expected, Exception):
            try:
                result = result.result()
            except Exception as e:
                return type(e) == type(expected)
            return False
        else:
            return result.result() == expected
    def test_Queue_put_0():
        return run_test('put', [], False)
    def test_Queue_put_1():
        return run_test('put', [1], False)

# Generated at 2022-06-22 04:21:39.225054
# Unit test for method empty of class Queue
def test_Queue_empty():
    import asyncio
    from tornado.gen import coroutine

    q = Queue()
    @coroutine
    def put():
        yield q.put('a')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(put())
    assert q.empty() == False

# Generated at 2022-06-22 04:21:43.465264
# Unit test for method full of class Queue
def test_Queue_full():
    q=Queue(3)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert not q.full()
    q.put_nowait(3)
    assert q.full()
test_Queue_full()



# Generated at 2022-06-22 04:21:44.160638
# Unit test for method put of class Queue
def test_Queue_put():
    pass

# Generated at 2022-06-22 04:21:48.969423
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                do_work(item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            
    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()     
        await q.join()       
        print('Done')

    IOLoop.current().run_sync(main)



# Generated at 2022-06-22 04:21:53.495972
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull as e:
        assert "full" in str(e)


# Generated at 2022-06-22 04:22:05.027680
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)



# Generated at 2022-06-22 04:22:10.014191
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True

    q.put_nowait(1)
    assert q.empty() == False

    q.put_nowait(2)
    assert q.empty() == False

    q.get_nowait()
    assert q.empty() == False

    q.get_nowait()
    assert q.empty() == True


# Generated at 2022-06-22 04:22:20.256718
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:22:26.234165
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    q.put(2)
    it = _QueueIterator(q)
    assert it.__anext__().result() == 1
    assert it.__anext__().result() == 2
    with pytest.raises(StopAsyncIteration):
        it.__anext__().result()
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:22:31.894334
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    async def _test_Queue_qsize():
        pass
    def wrapper():
        # Create an event loop
        loop = ioloop.IOLoop.current()
        # Schedule a call to _test_Queue_qsize()
        loop.add_callback(_test_Queue_qsize)
        # Start the event loop
        loop.start()
    # Invoke the wrapper function
    wrapper()

# Generated at 2022-06-22 04:22:37.495409
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.empty()
    q.full()
    q.get()
    q.get_nowait()
    q.join()
    q.put()
    q.qsize()
    q.task_done()

# Generated at 2022-06-22 04:22:42.104859
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    import unittest
    class TestQueueEmpty(unittest.case.TestCase):

        def test_constructor(self):
            try:
                raise QueueEmpty()
            except QueueEmpty as e:
                assert str(e) == ''
    unittest.main()


# Generated at 2022-06-22 04:22:47.610551
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    import requests

    # q = Queue(maxsize=2)

    # async def consumer():
    #     async for item in q:
    #         try:
    #             print('Doing work on %s' % item)
    #             await gen.sleep(0.01)
    #         finally:
    #             q.task_done()

    # async def producer():

    #     for item in range(11):
    #         await q.put(item)
    #         print('Put %s' % item)

    #     # if q.full():
    #     #     print("full")
    #     #     time.sleep(5)

    #     #     if q.empty

# Generated at 2022-06-22 04:22:56.317216
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:22:59.623778
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q=Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2


# Generated at 2022-06-22 04:23:22.342067
# Unit test for constructor of class QueueFull
def test_QueueFull():
    def a():
        return 0
    try:
        raise QueueFull
    except QueueFull as e:
        a()



# Generated at 2022-06-22 04:23:31.056132
# Unit test for method full of class Queue
def test_Queue_full():
  q = Queue()
  assert not q.full()
  assert q.empty()
  q.put_nowait(1)
  assert not q.full()
  assert not q.empty()
  q.put_nowait(2)
  assert q.full()
  assert not q.empty()
  q.get()
  assert not q.full()
  assert not q.empty()
  q.get()
  assert not q.full()
  assert q.empty()
test_Queue_full()


# Generated at 2022-06-22 04:23:33.623328
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado.queues
    q = tornado.queues.Queue()
    try:
        q.get_nowait()
    except tornado.queues.QueueEmpty:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-22 04:23:39.006183
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    try:
        q = Queue(maxsize=None)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 04:23:45.734767
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(2)
    q.put_nowait(1)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty:
        pass

# Generated at 2022-06-22 04:23:48.204088
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass


# Generated at 2022-06-22 04:23:55.094972
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.full() == True
    assert (1,2) == (q.get_nowait(), q.get_nowait())
    assert q.empty() == True
    assert q.full() == False
    assert q.get_nowait() == ValueError
    assert q.join() == None


# Generated at 2022-06-22 04:23:58.494262
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Current test class
    test_class = Queue()
    # First assert to check the method signature, assert value for consistency
    assert test_class.empty() == False, "Method signature (argument types or return type) does not match"


# Generated at 2022-06-22 04:24:10.842538
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    # test on empty queue
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    # put an item
    q.put_nowait(1)
    # test on empty queue again
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    # put another item
    q.put_nowait(2)
    # test on full queue
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass
    # consume an item
    assert q.get_nowait() == 1
    # consume an item
    assert q.get_nowait() == 2

    q = Queue(maxsize=0)


# Generated at 2022-06-22 04:24:20.332520
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    print(0,q.qsize())
    q.put(1)
    print(1,q.qsize())
    q.put(2)
    print(2,q.qsize())

    print(3,q.get_nowait())
    print(4,q.qsize())

    print(5,q.get_nowait())
    print(6,q.qsize())

    q.put(3)
    print(7,q.qsize())
    q.put(4)
    print(8,q.qsize())

    print(9,q.get_nowait())
    print(10,q.qsize())

    print(11,q.get_nowait())
    print(12,q.qsize())

    # print(

# Generated at 2022-06-22 04:25:10.534497
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:25:18.921959
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get()
    assert q.get()
    assert q.get()

    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait()
    assert q.get_nowait()
    assert q.get_nowait()

# Generated at 2022-06-22 04:25:20.364535
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    qu = Queue()
    assert str(qu) == "<Queue maxsize=0 queue=deque([])>"



# Generated at 2022-06-22 04:25:22.970958
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        print(e)
    else:
        print("TypeError: raise missing except clause")


# Generated at 2022-06-22 04:25:25.852339
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)
    q = Queue(1)
    print(q)
    q.put_nowait(1)
    print(q)


# Generated at 2022-06-22 04:25:37.397515
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.qsize() == 2
    assert q.full()
    assert not q.empty()
    q.get_nowait()
    assert q.qsize() == 1
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    assert q.qsize() == 0
    assert not q.full()
    assert q.empty()
    #q.get_nowait()
    #assert q.qsize

# Generated at 2022-06-22 04:25:40.113376
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put_nowait(2)
    print(q.qsize())
    print(q.full())

# Generated at 2022-06-22 04:25:42.553655
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)

T = typing.TypeVar("T")



# Generated at 2022-06-22 04:25:45.065270
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()
    assert isinstance(qf, Exception)



# Generated at 2022-06-22 04:25:55.174273
# Unit test for method full of class Queue
def test_Queue_full():
    import time
    import unittest
    from tornado.ioloop import IOLoop


    class TestQueue(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.loop = IOLoop()
            cls.loop.make_current()

        @classmethod
        def tearDownClass(cls):
            cls.loop.clear_current()
            cls.loop.close(all_fds=True)

        def test_Queue_full(self):
            q = Queue(maxsize=1)
            self.assertFalse(q.full())
            q.put_nowait(None)
            self.assertTrue(q.full())
            q.get_nowait()
            self.assertFalse(q.full())


    unittest.main()


# Generated at 2022-06-22 04:26:36.559227
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        a = QueueFull()
        print("QueueFull constructed!")
        return a
    except Exception as e:
        print(e)

QueueFull()


# Generated at 2022-06-22 04:26:47.667591
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')