

# Generated at 2022-06-22 04:17:06.293316
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    assert q.empty() == False
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    assert q.empty() == True


# Generated at 2022-06-22 04:17:08.201517
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    t = Queue()
    t.task_done()

# Generated at 2022-06-22 04:17:20.765269
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import re
    import inspect
    import asyncio
    def function1():
        pattern = re.compile("^<Queue\sat\s[0-9a-fA-Fx]+\smaxsize=1\squeue=deque\(\['[a-zA-Z0-9]*'\]\)\stasks=0>$")
        q = Queue(maxsize=1)
        q.put_nowait('hello')
        assert pattern.match(q.__repr__()) is not None

# Generated at 2022-06-22 04:17:29.948680
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test
    import tornado.gen

    @gen.coroutine
    def aa():
        q = Queue(maxsize=3)
        for i in range(10):
            yield q.put(i)

        b = 0
        for i in q:
            assert b == i
            b += 1
            if b == 3:
                break

        q.put_nowait(b)
        q.put_nowait(b)
        q.put_nowait(b)


    IOLoop.current().run_sync(aa)

# Generated at 2022-06-22 04:17:42.732747
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    f1 = Future()
    f2 = Future()
    f3 = Future()
    io_loop = ioloop.IOLoop.current()
    io_loop.add_timeout(0.1, lambda: f1.set_result(1))
    io_loop.add_timeout(0.1, lambda: f2.set_result(2))
    io_loop.add_timeout(0.1, lambda: f3.set_result(3))
    q = Queue(maxsize=3)
    q.__put_internal(f1)
    q.__put_internal(f2)
    q.__put_internal(f3)
    q._consume_expired()
    assert len(q._getters) == 0
    assert len(q._putters) == 0

# Generated at 2022-06-22 04:17:45.355818
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q._Reader()
    x = _QueueIterator(q)


# Generated at 2022-06-22 04:17:55.085818
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q1 = Queue(maxsize=1)
    assert q1.empty()
    q1.put_nowait(1)
    assert not q1.empty()
    assert q1.maxsize == 1
    assert q1.qsize() == 1
    assert q1.full()
    try:
        q1.put_nowait(2)
        assert False
    except QueueFull:
        assert True
    try:
        q1.get_nowait()
    except QueueEmpty:
        assert False
    assert q1.qsize() == 0
    assert q1.empty()


# Generated at 2022-06-22 04:17:56.786261
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull(42)
    assert q.args[0] == 42


# Generated at 2022-06-22 04:18:02.184447
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get_nowait()
    q.put(3)
    q.get_nowait()
    q.get_nowait()
test_Queue_put()


# Generated at 2022-06-22 04:18:03.421254
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """
    A module level test.
    """
    q = QueueFull()
    print(q)



# Generated at 2022-06-22 04:18:12.995415
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')


# Generated at 2022-06-22 04:18:15.987807
# Unit test for constructor of class Queue
def test_Queue():
    q1=Queue(maxsize=2)
    q2=Queue(maxsize=None)
    print(q1.maxsize,q2.maxsize)


# Generated at 2022-06-22 04:18:17.847775
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()


# Generated at 2022-06-22 04:18:21.626894
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    # q.get() -> Future[_T], Awaitable[_T]
    a = _QueueIterator(q)
    assert isinstance(a, _QueueIterator)
    assert a.q == q



# Generated at 2022-06-22 04:18:23.866772
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
# test_PriorityQueue()



# Generated at 2022-06-22 04:18:27.311688
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import queue
    import time

    q = queue.Queue(maxsize = 10)
    q.put_nowait('123')
    #time.sleep(1)
    q.put_nowait('234')
    #time.sleep(1)
    q.put_nowait('321')
    print(q.qsize())


# Generated at 2022-06-22 04:18:30.418615
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True
    q.put(0)
    assert q.empty() == False
    q.task_done()
    assert q.empty() == True


# Generated at 2022-06-22 04:18:35.273294
# Unit test for constructor of class Queue
def test_Queue():
    ioloop.IOLoop.clear_current()
    ioloop.IOLoop.clear_instance()
    ioloop.IOLoop.instance()

    q = Queue(maxsize=2)
    assert q.maxsize == 2


# Generated at 2022-06-22 04:18:36.606293
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()
    assert isinstance(a, Exception)
    # dont raise an exception
    pass



# Generated at 2022-06-22 04:18:43.317974
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    for _ in range(1000):
        q = Queue(maxsize=2)
        assert q.put_nowait(1) is None
        assert q.put_nowait(2) is None
        # invoke: QueueFull @ line 85
        # assert q.put_nowait(3) is None
    return True



# Generated at 2022-06-22 04:19:04.823987
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q._maxsize == 0
    assert q._queue == collections.deque()
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert not q._finished.is_set()
    # TODO: AssertionError: <Event at 0x7f0eb4edcf98 waiters=set()> != <Event at 0x7f0eb4edcf98 waiters=set(<Future at 0x7f0eb4edc828 state=PENDING>)>
    # assert q._finished == Event(set())
    # assert q._finished == Event(set(Future()))
    q = Queue(5)
    assert q._maxsize == 5
    assert q._

# Generated at 2022-06-22 04:19:11.895830
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:19:22.623472
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=5)
    q._getters = collections.deque([Future(), Future()])
    q._putters = collections.deque([(3, Future()), (2, Future())])
    q._unfinished_tasks = 1
    q._queue = collections.deque([4])
    q._finished = Event()
    q._consume_expired()
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([(3, Future()), (2, Future())])
    assert q._unfinished_tasks == 1
    assert q._queue == collections.deque([4])
    assert q._finished == Event()
    q._consume_expired()
    q._getters = collections.deque([Future()])
    q._putters

# Generated at 2022-06-22 04:19:34.805138
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Imports
    from tornado.ioloop import IOLoop
    import time
    import asyncio
    import tornado.concurrent
    # Variables
    q = Queue(maxsize = 2)
    f = Future()
    f.set_result(None)
    tmp = True
    # Assignments
    # Function calls
    # assertions
    assert isinstance(q.get(), tornado.concurrent.Future)
    #Unit test for method put_nowait of class Queue
    def test_Queue_put_nowait():
        # Imports
        import time
        import asyncio
        import tornado.concurrent
        from tornado.queues import Queue
        from tornado.locks import Event
        from tornado import gen
        from tornado.queues import QueueFull
        # Variables

# Generated at 2022-06-22 04:19:45.149288
# Unit test for method get of class Queue
def test_Queue_get():
    print("test_Queue_get")
    # Start consumer without waiting (since it never finishes).
    q = Queue(maxsize=2)
    q.get()
    q.get()
    # Put 0
    q.put_nowait(0)
    # Put 1
    q.put_nowait(1)
    # Doing work on 0
    q.get()
    # Put 2
    q.put_nowait(2)
    # Doing work on 1
    q.get()
    q.get()
    q.get()
    # Put 4
    q.put_nowait(4)
    # Doing work on 3
    q.get()
    q.get()
    # Done


# Generated at 2022-06-22 04:19:57.634166
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    from tornado.ioloop import IOLoop

    async def test(q: "_QueueIterator[_T]") -> _T:
        return await q.__anext__()

    async def test1(q: Queue[_T]) -> _T:
        return await q.get()

    q = Queue()
    q.put_nowait(1)
    q_iter = _QueueIterator(q)
    run = test(q_iter)
    run_1 = test1(q)
    IOLoop.current().run_sync(run) # type: ignore
    IOLoop.current().run_sync(run_1) # type: ignore

    print(run, run_1)



# Generated at 2022-06-22 04:20:09.829392
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    import time
    random.seed(time.time())

    # Test data format

# Generated at 2022-06-22 04:20:14.940454
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    queue = Queue[int]()
    queue_iterator = _QueueIterator[int](queue)
    assert isinstance(queue_iterator, collections.abc.Iterator)
    assert isinstance(queue_iterator, Generic)
    assert queue_iterator.q == queue



# Generated at 2022-06-22 04:20:26.409679
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            q.put_nowait(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        # Wait for producer to put all tasks.
        producer()
        # Wait for consumer to finish all tasks.
        q.join()
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-22 04:20:29.891767
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    def f():
        yield None
    a = f()
    qi = _QueueIterator(Queue(maxsize=1))
    a.send(None)
    # qi.__anext__().send(None)



# Generated at 2022-06-22 04:20:50.015222
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    #from tornado import gen
    #from tornado.ioloop import IOLoop
    #from tornado.queues import Queue

    q = Queue(maxsize=2)

    gen.sleep(0.01)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                #await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop = IOLoop.current()
        ioloop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all

# Generated at 2022-06-22 04:20:59.234655
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import functools
    #! [queue_put]
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    asyncio.get_event_loop().run_until_complete(consumer())
    #! [queue_put]


# Generated at 2022-06-22 04:21:01.777219
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    c = Queue()
    assert c.empty() is True
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 3
    assert q.empty() is False
    assert q.full() is True



# Generated at 2022-06-22 04:21:03.748014
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception:
        pass



# Generated at 2022-06-22 04:21:13.072551
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:21:14.964792
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q.task_done()
    return True


# Generated at 2022-06-22 04:21:27.236105
# Unit test for method get of class Queue
def test_Queue_get():
    # Simple test
    q = Queue(maxsize=3)
    future = q.get()
    assert __debug__
    future.set_result("nonblocking")
    assert __debug__
    item = q.get_nowait()
    assert isinstance(item, str)
    assert __debug__
    assert item == "nonblocking"
    assert __debug__
    # Test order of enqueued gets
    q = Queue(maxsize=2)
    f1 = q.get()
    assert __debug__
    f2 = q.get()
    assert __debug__
    f3 = q.get()
    assert __debug__
    q.put_nowait("r2")
    assert __debug__
    q.put_nowait("r1")
    assert __debug__
    v1 = f1

# Generated at 2022-06-22 04:21:38.399362
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-22 04:21:41.649655
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q =Queue()
    assert q.qsize() ==0
    q.put_nowait(1)
    assert q.qsize() ==1
    q.task_done()
    assert q.qsize() ==0

# Generated at 2022-06-22 04:21:46.751794
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue

    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-22 04:22:14.164488
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:22:15.515365
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert "<Queue maxsize=2 tasks=0>" == str(q)


# Generated at 2022-06-22 04:22:17.709814
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put(3)
    i: _QueueIterator[int] = _QueueIterator(q)
    assert (await i.__anext__()) == 3



# Generated at 2022-06-22 04:22:18.942225
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    qsize = Queue().qsize()
    assert qsize == 0



# Generated at 2022-06-22 04:22:24.040507
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(2)
    assert q.qsize() == 0
    q.put_nowait(10)
    assert q.qsize() == 1
    q.task_done()
    assert q.qsize() == 0


# Generated at 2022-06-22 04:22:25.039858
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    raise NotImplementedError()

# Generated at 2022-06-22 04:22:25.508475
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    pass

# Generated at 2022-06-22 04:22:27.471219
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass



# Generated at 2022-06-22 04:22:32.735511
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    t = Queue()
    try:
        t.task_done()
    except ValueError:
        print("Success!")
    else:
        print("Error!")
    
    t.put(1)
    t.put(2)
    t.put(3)
    t.put(4)
    t.put(5)
    t.get()
    t.get()
    t.get()
    t.get()
    t.get()
    t.task_done()
    t.task_done()
    t.task_done()
    t.task_done()
    t.task_done()
    try:
        t.task_done()
    except ValueError:
        print("Success!")
    else:
        print("Error!")
        

# Generated at 2022-06-22 04:22:43.440556
# Unit test for method join of class Queue
def test_Queue_join():
    # These tests are not very good because they depend on time.sleep
    # and can't detect races.
    io_loop = ioloop.IOLoop.current()
    q = Queue()

    def putter():
        io_loop.add_callback(q.put, object())

    start = io_loop.time()
    putter()
    q.join()
    end = io_loop.time()
    assert end - start < 1, "join waited %f seconds" % (end - start)

    start = io_loop.time()
    q.join(1)
    end = io_loop.time()
    assert end - start < 1, "join waited %f seconds" % (end - start)

    start = io_loop.time()
    q.join(10)
    end = io_loop.time

# Generated at 2022-06-22 04:23:42.649669
# Unit test for method put of class Queue
def test_Queue_put():
    class Queue:
        def __init__(self, maxsize: int = 0) -> None:
            if maxsize is None:
                raise TypeError("maxsize can't be None")
            if maxsize < 0:
                raise ValueError("maxsize can't be negative")
            self._maxsize = maxsize
            self._init()
            self._getters = collections.deque([])
            self._putters = collections.deque([])
            self._unfinished_tasks = 0
            self._finished = Event()
            self._finished.set()

        @property
        def maxsize(self) -> int:
            """Number of items allowed in the queue."""
            return self._maxsize

        def qsize(self) -> int:
            """Number of items in the queue."""
            return len(self._queue)

# Generated at 2022-06-22 04:23:50.746402
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    ioloop.IOLoop.clear_instance()
    io_loop = ioloop.IOLoop.current()
    async def f1():
        n = await q.get()
        assert n == 2
        await q.task_done()
        try:
            n = await q.get_nowait()
        except QueueEmpty:
            io_loop.stop()
    q = Queue()
    q.put_nowait(1)
    io_loop.add_callback(f1)
    q.put_nowait(2)
    io_loop.start()

# Generated at 2022-06-22 04:24:00.087025
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import unittest
    from unittest import mock
    from tornado import gen
    from .utils import AsyncTestCase, Future, to_ioloop, ignore_exceptions, coroutine_return_value
    from .tests import AsyncMock


    class Test_QueueIterator___anext__(AsyncTestCase):
        def test_adelay(self):
            q = Queue()
            q.delay = mock.Mock()
            it = _QueueIterator(q)
            it.__anext__()
            self.assertEqual(q.delay.call_count, 1)
            self.assertEqual(q.delay.call_args, mock.call())
        def test_return_value(self):
            q = Queue()
            q.get = AsyncMock()
            it = _QueueIterator(q)

# Generated at 2022-06-22 04:24:12.465548
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:24:20.441004
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)

    # Check for empty queue
    def test_queue_size_0():
        assert q.full() == False

    # Check for non-empty queue
    def test_queue_size_non_0():
        q.put_nowait(1)   # queue is not null
        q.put_nowait(2)
        assert q.full() == True

    # Check for queue size = 0
    test_queue_size_0()

    # Test for queue size > 0
    test_queue_size_non_0()
    print("Queue - full: PASS")


# Generated at 2022-06-22 04:24:23.909421
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("source", "destination", 20)
    except Exception as e:
        print("error catched as expected")



# Generated at 2022-06-22 04:24:27.335855
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it.q, Queue)
    assert isinstance(_QueueIterator(EmptyQueue()), _QueueIterator)



# Generated at 2022-06-22 04:24:34.380430
# Unit test for method get of class Queue
def test_Queue_get():
    for i in range(10):
        q = Queue(maxsize=1)
        q._queue = [i]
        q._getters = collections.deque([])
        q._putters = collections.deque([])
        q._unfinished_tasks = 0
        q._finished = Event()
        q._finished.set()
        q.get(100)



# Generated at 2022-06-22 04:24:41.031259
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()


# Generated at 2022-06-22 04:24:45.054998
# Unit test for method empty of class Queue
def test_Queue_empty():
    def test():
        q = Queue(maxsize=5)
        print("is queue empty?:", q.empty())
        q.put(1)
        print("is queue empty?:", q.empty())
    test()

# Generated at 2022-06-22 04:26:24.738543
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
       

# Generated at 2022-06-22 04:26:35.697274
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    from __future__ import annotations
    import unittest
    
    import pytest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import Return
    from tornado.escape import native_str
    from tornado.concurrent import Future
    
    from typing import TypeVar

    _E = TypeVar("_E")


    class _PutFuture(Future):
        def __init__(self, queue: "Queue[_E]", item: _E) -> None:
            super().__init__()
            self._queue = queue
            self._item = item
        def put(self) -> None:
            self._queue._put(self._item)
    
    
    class Queue(_QueueIterator):
        def __init__(self, maxsize: int = 0) -> None:
            self.maxsize

# Generated at 2022-06-22 04:26:38.104200
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    assert Queue().qsize() == 0

# Generated at 2022-06-22 04:26:41.135069
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    obj = Queue(1)
    print(obj.qsize())
    print(obj.maxsize)
    obj.put_nowait(1)
    print(obj.get_nowait())


# Generated at 2022-06-22 04:26:47.565556
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    assert qe.args == ()
    assert qe.__str__() == ''
    qe = QueueEmpty('another exception')
    assert qe.args == ('another exception',)
    assert qe.__str__() == 'another exception'
    qe = QueueEmpty('another exception', 'another exception2')
    assert qe.args == ('another exception', 'another exception2')
    assert qe.__str__() == 'another exception'

