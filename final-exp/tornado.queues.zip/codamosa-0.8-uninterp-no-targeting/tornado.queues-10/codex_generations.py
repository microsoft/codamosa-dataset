

# Generated at 2022-06-22 04:17:04.486710
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    assert q.empty() == True
    q.put(1)
    q.task_done()


# Generated at 2022-06-22 04:17:05.709488
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:17:16.375656
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    class PQ(Queue[_T]):
        def __init__(self) -> None:
            super().__init__()

        def _init(self) -> None:
            self._queue = collections.deque()

        def _get(self) -> _T:
            return self._queue.popleft()

        def _put(self, item: _T) -> None:
            self._queue.append(item)

    # Queue.put_nowait(item)
    x = PQ()
    x.put_nowait(1)
    x.put_nowait(2)
    x.put_nowait(3)
    assert x.qsize() == 3



# Generated at 2022-06-22 04:17:18.376891
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:17:24.459020
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from datetime import datetime
    from tornado.concurrent import Future
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q._putters.append((1, Future()))
    q._getters.append(Future())
    q._unfinished_tasks = 1
    assert str(q) == "<Queue maxsize=0 queue=deque([]) getters[1] putters[1] tasks=1>"

# Generated at 2022-06-22 04:17:29.000141
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Put item
    # @return: None
    # @rtype: None
    q1 = Queue()
    q1.put_nowait(1)
    # Get item
    # @return: item
    # @rtype: object
    q1.get_nowait()



# Generated at 2022-06-22 04:17:37.073184
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    from collections import deque
    q = Queue(maxsize=5)
    q._queue = deque(range(4))
    q._getters = deque([])
    q._putters = deque([])
    q._unfinished_tasks = 1

    answer = "<Queue at 0x7f05cfeaf7f0 maxsize=5 queue=deque([0, 1, 2, 3]) tasks=1>"
    assert q.__repr__() == answer



# Generated at 2022-06-22 04:17:39.885094
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2>"

# Generated at 2022-06-22 04:17:40.871865
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-22 04:17:43.030532
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(1)
    print(queue._queue)


if __name__ == "__main__":
    test_Queue_put_nowait()

# Generated at 2022-06-22 04:17:51.952167
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=0)
    q._unfinished_tasks = 0
    q.task_done()


# Generated at 2022-06-22 04:17:56.032666
# Unit test for method put of class Queue
def test_Queue_put():
  # Test case data
  maxsize = 1
  item = 1
  timeout = 0.5
  # Perform the test
  obj = Queue.__new__(Queue)
  obj.__init__(maxsize)
  res = obj.put(item,timeout)
  return res


# Generated at 2022-06-22 04:17:58.403608
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        pass
    except Exception as e:
        print(e)



# Generated at 2022-06-22 04:18:03.737973
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-22 04:18:05.129794
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert QueueEmpty


# Generated at 2022-06-22 04:18:07.899888
# Unit test for method empty of class Queue
def test_Queue_empty():
	pass
	# note that this is a randomly generated test
	# it checks that the method returns the expected value
	# assert empty() == <some value>


# Generated at 2022-06-22 04:18:09.963362
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull()
    assert isinstance(q, Exception)



# Generated at 2022-06-22 04:18:11.708799
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    testObj = Queue(5)
    assert testObj.get_nowait() is None


# Generated at 2022-06-22 04:18:22.122569
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import unittest
    def test_set_result(self, ioloop):
        q = Queue()
        q.put_nowait(1)
        def future_set_result_unless_cancelled(future, result):
            return future.result == result if not future.done() else None
        assert future_set_result_unless_cancelled(q._getters.pop(), 1)
        assert q._unfinished_tasks == 1
        q.task_done()
        assert q._unfinished_tasks == 0
        assert q._finished.is_set()
    def test_join(self, ioloop):
        q = Queue()
        q.put_nowait(1)
        ioloop.spawn_callback(q.task_done)
        ioloop.run_

# Generated at 2022-06-22 04:18:29.687538
# Unit test for method get of class Queue
def test_Queue_get():
    # Unit test for method get of class Queue
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for

# Generated at 2022-06-22 04:18:40.023837
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass


# Generated at 2022-06-22 04:18:49.927520
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import time
    from typing import Text, Dict

    # Unit test for method __anext__ of class _QueueIterator
    def test__QueueIterator___anext__():
        class _Test(object):
            @classmethod
            async def get(cls) -> Text:
                return "test__QueueIterator___anext__"
        class _Queue(object):
            q = _Test()

            async def get(self) -> Text:
                return await self.q.get()

        q = _Queue()
        qi = _QueueIterator(q)
        a = await qi.__anext__()
        assert a == "test__QueueIterator___anext__"

        # Test to raise StopAsyncIteration
        qi2 = _QueueIterator(q)

# Generated at 2022-06-22 04:18:54.837118
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    item = 1
    q = Queue()

    def callback(future):
        return future.result()

    def _test():
        q.put_nowait(item)
        _QueueIterator(q).__anext__().add_done_callback(callback)

    ioloop.IOLoop.current().run_sync(_test)

# Generated at 2022-06-22 04:19:06.056547
# Unit test for method join of class Queue
def test_Queue_join():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:17.925242
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import unittest
    import asyncio
    from tornado.queues import Queue
    from tornado import testing, gen

    @testing.gen_test
    def test_queue():
        q = Queue()
        q.put_nowait(0)
        assert q.qsize() == 1
        count = 0
        for i in q:
            assert i == count
            count += 1
            assert q.qsize() == 0
        
    class TestQueue(unittest.TestCase):
        def test(self):
            io_loop = ioloop.IOLoop.current()
            io_loop.run_sync(test_queue)
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-22 04:19:30.569374
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    import random

    class Test(unittest.TestCase):

        def test(self):
            q = Queue(5)
            for i in range(6):
                q.put(i)
            self.assertTrue(q.full())
            self.assertFalse(q.empty())
            self.assertEqual(q.qsize(), 5)
            self.assertRaises(QueueFull, q.put, 1)
            for i in range(5):
                q.get()
            self.assertFalse(q.full())
            self.assertTrue(q.empty())
            self.assertEqual(q.qsize(), 0)
            self.assertRaises(QueueEmpty, q.get)
            q.put(1)
            self.assertFalse(q.full())

# Generated at 2022-06-22 04:19:31.858277
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 2

# Generated at 2022-06-22 04:19:42.995129
# Unit test for method full of class Queue
def test_Queue_full():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import tornado.gen
    import tornado.testing

    class TestQueueFull(tornado.testing.AsyncTestCase):
        __qualname__ = 'TestQueueFull'

        @tornado.testing.gen_test
        def test_full(self):
            q = Queue(maxsize=2)
            q.put_nowait('hello')
            q.put_nowait('world')
            self.assertTrue(q.full())
            q.get_nowait()
            self.assertFalse(q.full())

    asyncio.run(TestQueueFull().test_full())


# Generated at 2022-06-22 04:19:46.801215
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    x = yield from it.__anext__()
    assert x == 1


# Generated at 2022-06-22 04:19:59.434861
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    if q.empty():
        print('There are no tasks, so the queue is empty')
    try:
        print(q.get_nowait())
        print('Failed to throw QueueEmpty exception') 
    except QueueEmpty:
        print('Successfully threw QueueEmpty exception') 
    q.put_nowait(5)
    print(q.get_nowait())
    q.put_nowait(5)
    print(q.get_nowait())
    try:
        print(q.get_nowait())
        print('Failed to throw QueueEmpty exception') 
    except QueueEmpty:
        print('Successfully threw QueueEmpty exception') 

# Generated at 2022-06-22 04:20:21.661462
# Unit test for method put of class Queue
def test_Queue_put():

    q = Queue()
    future = Future()
    put = q.put(0, timeout=future)
    QueueFull_flag = 0
    QueueFull_msg = ""
    try:
        q.put_nowait(1)
    except QueueFull as msg:
        QueueFull_flag = 1
        QueueFull_msg = msg

    assert QueueFull_flag == 1 and QueueFull_msg.__class__.__name__ == "QueueFull"

    put = q.put(0)
    assert put == Future()


# Generated at 2022-06-22 04:20:23.181566
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    error = QueueEmpty
    assert error != None


# Generated at 2022-06-22 04:20:24.530469
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:20:29.891767
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    s = q.__repr__()
    assert s == "<Queue at %s maxsize=2>" % (hex(id(q)), ), '%s != %s' % (s, "<Queue at %s maxsize=2>" % (hex(id(q)), ))

# Generated at 2022-06-22 04:20:36.008556
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    async def test():
        q.put(1)
        q.put(2)
        q.put(3)
        assert await q.get() == 1
        assert (await q.get()) == 2
        assert (await q.get()) == 3
        await q.put(4)
        assert await q.get() == 4
        q.put(5)
        assert (await q.get()) == 5
    ioloop.IOLoop.current().run_sync(test)
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:20:40.603768
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    second_item = 1
    new_item = 2
    q = Queue()
    first_item = q.get_nowait()
    q.put_nowait(second_item)
    assert first_item == second_item
    q.task_done()
    q.put_nowait(new_item)
    assert q.get_nowait() == new_item
    q.task_done()


# Generated at 2022-06-22 04:20:46.113400
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert q.put_nowait(1) == None
    assert q.put_nowait(2) == None
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True

# Generated at 2022-06-22 04:20:47.931885
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()


# Generated at 2022-06-22 04:20:50.607735
# Unit test for constructor of class QueueFull
def test_QueueFull():
    my_exception = QueueFull()
    assert issubclass(QueueFull, Exception)
    assert isinstance(my_exception, Exception)
    assert isinstance(my_exception, QueueFull)



# Generated at 2022-06-22 04:20:52.508083
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert q.full() == False, "Queue.full() return value {0}, expected {1}".format(q.full(), True)
    

# Generated at 2022-06-22 04:21:09.198699
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:21:21.521300
# Unit test for method get of class Queue
def test_Queue_get():
    import itertools

    import pytest
    import tornado
    from tornado import gen
    from tornado.queues import Queue
    from tornado.testing import gen_test

    @gen.coroutine
    def producer(queue, n):
        for i in range(1, n + 1):
            yield queue.put(i)
            print("Produced %s" % i)
        # Stop consumers
        yield queue.put(None)
        for _ in range(n_consumers):
            yield queue.put(None)


    @gen.coroutine
    def consumer(queue, _id):
        while True:
            item = yield queue.get()
            if item is None:
                print("Consumer %s exit" % _id)
                break
            print("Consumer %s consumed %s" % (_id, item))
           

# Generated at 2022-06-22 04:21:33.641392
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:21:43.251958
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue, QueueEmpty
    from tornado.testing import gen_test

    q = Queue(maxsize = 0)

    async def consumer ():
        async for item in q:
            try:
                assert item == 'foo'
            finally:
                q.task_done()

    async def producer ():
        await q.put('foo')
    
    @gen_test
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-22 04:21:47.366051
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    assert it.q.get() == 1
    assert it.q.get() == 2
    assert it.q.get() == 3



# Generated at 2022-06-22 04:21:56.046189
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

#if __name__ == '__main__':
#    test_PriorityQueue()


# Generated at 2022-06-22 04:21:58.324027
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert q.__repr__() == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)

# Generated at 2022-06-22 04:21:59.462715
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-22 04:22:06.011631
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    lq = LifoQueue()
    lq.put(3)
    lq.put(2)
    assert lq.get_nowait() == 2
    assert lq.get_nowait() == 3

# Generated at 2022-06-22 04:22:12.070194
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    # test some basic variables
    assert q.maxsize == 0
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q._finished.is_set() == True
    # test the functions regarding put and get
    q.put_nowait(1)
    assert q.get_nowait() == 1
    test_future_1 = Future()
    test_future_1.set_result(1)
    q._getters.append(test_future_1)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

# Generated at 2022-06-22 04:22:26.897688
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q._unfinished_tasks = 2
    assert q._unfinished_tasks == 2
    q.task_done()
    assert q._unfinished_tasks == 1
    q.task_done()
    assert q._unfinished_tasks == 0



# Generated at 2022-06-22 04:22:36.307211
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado.ioloop import IOLoop
    from tornado.gen import (
        Future,
        TimeoutError,
    )

    q = Queue()
    q.put_nowait(1)

    f = Future()
    q.get()
    q.task_done()
    f.set_result(None)
    assert IOLoop.current().run_sync(lambda: f) is None

    f = Future()
    q.get()
    q.task_done()
    f.set_result(None)
    assert IOLoop.current().run_sync(lambda: f) is None

    q.put_nowait(1)
    q.put_nowait(2)

    f = Future()
    q.get()
    q.get()

# Generated at 2022-06-22 04:22:42.605976
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    class Job:
        def __init__(self, priority: int, description: str) -> None:
            self.priority = priority
            self.description = description
            print("New job:", description)
            return

        def __lt__(self, other) -> bool:
            return self.priority < other.priority

    q = PriorityQueue()

    def init():
        q.put(Job(3, "Mid-level job"))
        q.put(Job(10, "Low-level job"))
        q.put(Job(1, "Important job"))

    init()
    print("Starting with qsize = %s" % q.qsize())
    print(q.get_nowait().description)
    print(q.get_nowait().description)
    print(q.get_nowait().description)



# Generated at 2022-06-22 04:22:50.013766
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    print(q.get_nowait())
    q.put(2)
    print(q.get_nowait())
    q.put(1)
    print(q.get_nowait())
test_LifoQueue()

# Generated at 2022-06-22 04:22:53.037315
# Unit test for method put of class Queue
def test_Queue_put():
    # queue = Queue(maxsize=0)
    # queue._putters = collections.deque([])
    # queue._getters = collections.deque([])
    # queue.put(1,1)
    print('ok')


# Generated at 2022-06-22 04:22:59.140473
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # We can't use the random module here because the module
    # random.seed is not thread-safe.

    queue = Queue(maxsize=2)
    assert repr(queue) == "<Queue at 0x%x maxsize=2>" % id(queue)

    queue.put_nowait(1)
    queue.put_nowait(2)
    assert repr(queue) == "<Queue at 0x%x maxsize=2 queue=[1, 2]>" % id(queue)
    queue.get()
    assert repr(queue) == "<Queue at 0x%x maxsize=2 queue=[2]>" % id(queue)

    queue.put_nowait(3)
    assert repr(queue) == "<Queue at 0x%x maxsize=2 queue=[2, 3]>" % id(queue)

    queue.get()


# Generated at 2022-06-22 04:23:04.224904
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    li = [1,2,3,5]
    q = Queue()
    q.put(li[random.randint(0,3)])
    print("\nThe queue element is: ", q.get())
    print("\nThe queue elements are: ", q.get(), q.get(), q.get(), q.get())


# Generated at 2022-06-22 04:23:05.542034
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)
    q.get()

# Generated at 2022-06-22 04:23:13.907567
# Unit test for method full of class Queue
def test_Queue_full():
    import pytest
    # Create Queue object with maxsize
    q = Queue(maxsize=2)
    # Execute methods of Queue
    # testing if the returned values are correct
    assert q.full() == False
    q.put_nowait("a")
    assert q.full() == False
    q.put_nowait("b")
    assert q.full() == True
    with pytest.raises(QueueFull):
        q.put_nowait("c")


# Generated at 2022-06-22 04:23:21.188684
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.__put_internal(1)
    assert q.qsize() == 1
    q.__put_internal(2)
    assert q.qsize() == 2
    q.__put_internal(3)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    q.get_nowait()
    assert q.qsize() == 0

# Generated at 2022-06-22 04:23:55.212145
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    f1 = q.put_nowait(1)
    f2 = q.put_nowait(2)
    res = q.join()
    assert (res is None)
    res = q.join(timeout=1)
    assert (res is None)
    f3 = q.put_nowait(3)
    f4 = q.put_nowait(4)
    res = q.join()
    assert (res is None)
    res = q.join(timeout=1)
    assert (res is None)



# Generated at 2022-06-22 04:23:58.303935
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """
    >>> test_QueueFull()
    ..."""
    q = Queue(1)
    q.put(1)
    try:
        q.put(2)
    except QueueFull as ex:
        print(ex)


# Generated at 2022-06-22 04:24:10.691384
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    test_Queue_get_nowait.__wrapped__ = ioloop.IOLoop

# Generated at 2022-06-22 04:24:12.757086
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    #Create an instance of Queue
    pass #TODO
    #Use aiter(self) of Queue to do unit test
    pass #TODO


# Generated at 2022-06-22 04:24:14.510453
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    _m_Queue_get_nowait = q.get_nowait()
    pass

# Generated at 2022-06-22 04:24:17.535718
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: () -> None
    q = Queue()
    assert isinstance(_QueueIterator(q), _QueueIterator)


# Generated at 2022-06-22 04:24:19.019912
# Unit test for method join of class Queue
def test_Queue_join():
    test_instance = Queue()
    assert test_instance.join(timeout=None) is None


# Generated at 2022-06-22 04:24:22.875999
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q=Queue()
    q.get()
    for i in range(0,10):
        q.put(i)
    q.task_done()


# Generated at 2022-06-22 04:24:24.799741
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass



# Generated at 2022-06-22 04:24:34.935821
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # Create a queue of size zero
    q = Queue(0)
    # Test standard case
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    # Test case with negative maxsize
    q = Queue(-1)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    # Test case with maxsize of None
    q = Queue(None)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1



# Generated at 2022-06-22 04:25:32.812560
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize = 10)
    for i in range(10):
        q.put_nowait(i)
    assert q.full() == True


# Generated at 2022-06-22 04:25:42.702705
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # http://bugs.python.org/issue7980
    q = Queue(3)
    q.put_nowait(1)
    q.get_nowait()
    q.put_nowait(2)
    q.get_nowait()
    q.put_nowait(3)
    q.get_nowait()
    q.put_nowait(4)
    assert q.full()
    assert str(q) == "<Queue maxsize=3 queue=[4] tasks=1>"
    q.get_nowait()
    assert not q.full()
    assert str(q) == "<Queue maxsize=3>"
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()

# Generated at 2022-06-22 04:25:51.266953
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    def consumer():
        for item in q:
            try:
                print('Doing work on %s' % item)
                time.sleep(0.01)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            q.put_nowait(item)
            print('Put %s' % item)

    def main():
        consumer()
        producer()
        q.join()
        print('Done')

    main()

# Generated at 2022-06-22 04:26:00.276875
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado import testing
    from tornado.queues import Queue
    from tornado.locks import Condition
    from tornado.platform.asyncio import AsyncIOMainLoop

    cond = Condition()

    @testing.gen_test
    def wait_and_stop():
        yield cond.wait()
        q.stop()

    async def put():
        await cond.wait()
        for i in range(10):
            await q.put(i)
        cond.notify()

    q = Queue(10)
    i = 0

    async def it():
        nonlocal i
        async for j in q.iter():
            assert j == i
            i += 1
            await gen.sleep(1e-6)

    AsyncIOMainLoop().install()
    io_loop = ioloop.IOLoop.current()

# Generated at 2022-06-22 04:26:01.104256
# Unit test for method join of class Queue
def test_Queue_join():
    assert True



# Generated at 2022-06-22 04:26:02.097042
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
  pass

# Generated at 2022-06-22 04:26:11.905319
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)


    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-22 04:26:14.740866
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    async def run():
        await q.put(1)
        await q.put(2)
        await q.put(3)
    ioloop.IOLoop.current().run_sync(run)


# Generated at 2022-06-22 04:26:18.262037
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except Exception as e:
        assert isinstance(e, QueueEmpty), 'Bug in constructor of class QueueEmpty'


# Generated at 2022-06-22 04:26:20.708140
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = Queue()
    assert isinstance(q, Queue)
    assert q.qsize() == 0
