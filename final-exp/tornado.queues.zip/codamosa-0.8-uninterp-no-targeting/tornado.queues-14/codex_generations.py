

# Generated at 2022-06-22 04:17:13.561429
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
  pass

# Generated at 2022-06-22 04:17:23.457104
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    str_1 = '<Queue at 0x7f37bfa32128 maxsize=0>'
    str_2 = '<Queue at 0x7f37bfa32128 maxsize=0 queue=deque([]>'
    str_3 = '<Queue at 0x7f37bfa32128 maxsize=0 queue=deque([1,2> getters[2] tasks = 3'
    q = Queue()
    assert q.__repr__() == str_1
    q.put(1)
    q.put(2)
    assert q.__repr__() == str_2
    fut = q.get()
    fut_1 = q.get()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
   

# Generated at 2022-06-22 04:17:31.131241
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    assert q._unfinished_tasks == 0
    q.put_nowait(1)
    assert q._unfinished_tasks == 1
    q.put_nowait(1)
    assert q._unfinished_tasks == 2
    q.task_done()
    assert q._unfinished_tasks == 1
    q.task_done()
    assert q._unfinished_tasks == 0


# Generated at 2022-06-22 04:17:35.494621
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    testq = PriorityQueue()
    testq.put((1, 'medium-priority item'))
    testq.put((0, 'high-priority item'))
    testq.put((10, 'low-priority item'))
    assert testq.get_nowait() == (0, 'high-priority item')
    assert testq.get_nowait() == (1, 'medium-priority item')
    assert testq.get_nowait() == (10, 'low-priority item')

# Unit tests for methods of class Queue

# Generated at 2022-06-22 04:17:38.121728
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.get_nowait() == 1

# Generated at 2022-06-22 04:17:42.690742
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    it: _QueueIterator[int] = _QueueIterator(q)
    assert await it.__anext__() == 1



# Generated at 2022-06-22 04:17:44.956315
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:17:52.224090
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.ioloop import IOLoop
    from tornado.iostream import StreamClosedError
    q = Queue(10)

    async def waiting_for_none():
        try:
            await q.get()
        except StreamClosedError:
            return True

    a = IOLoop.current().run_sync(waiting_for_none)
    assert a == True
    return a


# Generated at 2022-06-22 04:17:54.330473
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    """Test method Queue.__str__"""
    assert Queue().__str__() == "<Queue maxsize=0 queue=deque([])>"



# Generated at 2022-06-22 04:17:57.396315
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.full() == False
    q.put(1)
    q.put(1)
    assert q.full() == True

# Generated at 2022-06-22 04:18:07.079728
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass


# Generated at 2022-06-22 04:18:17.715081
# Unit test for method join of class Queue
def test_Queue_join():
    io_loop = ioloop.IOLoop()
    io_loop.make_current()
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    io_loop.run_sync(main)
    io_loop.close()



# Generated at 2022-06-22 04:18:20.505736
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    if q.empty() != True:
        return False
    else:
        return True


# Generated at 2022-06-22 04:18:24.205394
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    with pytest.raises(QueueFull):
        q.put_nowait('hello')
    with pytest.raises(QueueFull):
        q.put('hello', timeout=1)
    assert q._putters == deque()
    q.put_nowait('hello')


# Generated at 2022-06-22 04:18:31.609850
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    from tornado.queues import Queue
    q = Queue()
    async def put():
        for x in range(3):
            await q.put(x)
    async def get():
        async for x in q:
            print(x)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.gather(put(), get()))


# Generated at 2022-06-22 04:18:33.014638
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()


# Generated at 2022-06-22 04:18:37.836427
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Return an iterator over the values in the queue.  This frees the
    # consumer (who normally uses get()) from needing to task_done().  It
    # should be used in a with statement, e.g.:
    #
    #     q = Queue()
    #     q.put(1)
    #     q.put(2)
    #     with q:
    #         for item in q:
    #             print(item)
    #
    # which would print 1 and 2.  This does not support timeout or
    # task_done().
    pass


# Generated at 2022-06-22 04:18:40.366296
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Test that the __aiter__ method works
    q = Queue(maxsize=2)
    q.put_nowait(2)
    q.put_nowait(3)
    it = iter(q)
    # Test that the __aiter__ method works
    assert next(it) == 2
    # Test that the __aiter__ method works
    assert next(it) == 3

# Generated at 2022-06-22 04:18:44.135238
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    #Expected result:
    #   (0, 'high-priority item')
    #   (5, 'medium-priority item')
    #   (10, 'low-priority item')

    q = PriorityQueue()
    q.put((5, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-22 04:18:47.728736
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    # Put 
    q.put_nowait(item)
    q.put_nowait(item)
    # get
    q.get()
    q.get()
    print(q.qsize())



# Generated at 2022-06-22 04:18:56.434318
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    m_Queue = PriorityQueue()
    assert( m_Queue.empty() == True)
    assert( m_Queue.full() == False)
    assert( m_Queue.qsize() == 0)
    assert( m_Queue.maxsize == 0)


# Generated at 2022-06-22 04:19:06.928348
# Unit test for method get of class Queue
def test_Queue_get():
  from tornado import gen
  from tornado.ioloop import IOLoop
  from tornado.queues import Queue
  q = Queue(maxsize=2)
  async def consumer():
    async for item in q:
      try:
        print('Doing work on %s' % item)
        await gen.sleep(0.01)
      finally:
        q.task_done()
  async def producer():
    for item in range(5):
      await q.put(item)
      print('Put %s' % item)
  async def main():
    # Start consumer without waiting (since it never finishes).
    IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

# Generated at 2022-06-22 04:19:19.214408
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from .unittest_mixins import AsyncTestCase
    from .testing import AsyncTestCaseNoLogCapture
    import asyncio
    class TestCase(_QueueIterator, AsyncTestCaseNoLogCapture):
        def test_get(self):
            test_coroutine = asyncio.coroutine(lambda: 1)
            self.assertEqual(self.loop.run_until_complete(self.__anext__()), 1)
            _QueueIterator.__init__(self, Queue())
            self.q._put(1)
            self.assertEqual(self.loop.run_until_complete(self.__anext__()), 1)
            self.q._put(2)
            self.assertEqual(self.loop.run_until_complete(self.__anext__()), 2)
    return TestCase

# Generated at 2022-06-22 04:19:21.200804
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    print(q.qsize())

# Generated at 2022-06-22 04:19:33.892023
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:19:44.868426
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    async def coro_consumer():
        q = Queue()
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    async def coro_producer():
        q = Queue(maxsize = 1)
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def coro_main():
        # Start consumer without waiting (since it never finishes).
        await asyncio.gather(coro_consumer(), coro_producer())
        print('Done')
    #asyncio.run(coro_main())


test_Queue_get()

print(test_Queue_get())

# Generated at 2022-06-22 04:19:47.451368
# Unit test for method full of class Queue
def test_Queue_full():
    queue = Queue()
    assert not queue.full()


# Generated at 2022-06-22 04:19:48.429937
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    pass



# Generated at 2022-06-22 04:20:00.219944
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    print(q)
    print(q.qsize())
    q.put(1)
    q.put(2)
    q.put(3)
    print("qsize: {}".format(q.qsize()))
    print("empty: {}".format(q.empty()))
    print("full: {}".format(q.full()))
    print("qsize: {}".format(q.qsize()))
    print("empty: {}".format(q.empty()))
    print("full: {}".format(q.full()))
    print(q)
    q.get()
    q.get()
    q.get()
    print("qsize: {}".format(q.qsize()))
    print("empty: {}".format(q.empty()))

# Generated at 2022-06-22 04:20:10.606538
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.full() == False
    assert q.empty() == True
    assert q.maxsize == 0
    assert q.qsize() == 0
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    def coroutine_func():
        return q.get()
    coroutine_func = gen.coroutine(coroutine_func)
    with pytest.raises(gen.TimeoutError):
        IOLoop.current().run_sync(lambda: coroutine_func(), timeout=1)
    assert q._init() is None
    assert q._get() is None
    assert q._put(None) is None





# Generated at 2022-06-22 04:20:22.345654
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.empty()
    assert q.qsize() == 0
    assert not q.full()



# Generated at 2022-06-22 04:20:23.470559
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0


# Generated at 2022-06-22 04:20:31.439738
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    @gen.coroutine
    def coroutine_work():
        while True:
            try:
                x = yield work_queue.get()
                print('worker received x = %s' % x)
                yield gen.sleep(0.01)
            finally:
                work_queue.task_done()
    
    work_queue = Queue()
    IOLoop.current().spawn_callback(coroutine_work)
    work_queue.put(10)
    work_queue.put(20)
    work_queue.put(30)
    time.sleep(1)
    print(work_queue.qsize())
    print(work_queue.empty())


# Generated at 2022-06-22 04:20:34.514495
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    item = q.get_nowait()
    assert(item == 1)
    item = q.get_nowait()
    assert(item == 2)

# Generated at 2022-06-22 04:20:37.579142
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % (id(q),)


# Generated at 2022-06-22 04:20:43.248648
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    empty = q.empty()
    assert(empty == True)
    q.put(1)
    empty = q.empty()
    assert(empty == False)
    q.task_done()
    empty = q.empty()
    assert(empty == True)


# Generated at 2022-06-22 04:20:46.977095
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: () -> None
    def f(q):
        # type: (Queue[_T]) -> None
        it = _QueueIterator(q)
        assert type(it) == _QueueIterator
        return it
    q = Queue()
    it = f(q) # type: ignore



# Generated at 2022-06-22 04:20:50.014244
# Unit test for constructor of class QueueFull
def test_QueueFull():
    print("Testing class QueueFull...")
    from tornado.log import gen_log

    try:
        raise QueueFull
    except QueueFull as e:
        gen_log.info(e)
    print()



# Generated at 2022-06-22 04:20:50.742962
# Unit test for method full of class Queue
def test_Queue_full():
    pass



# Generated at 2022-06-22 04:20:55.659673
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q._unfinished_tasks = 0
    q.task_done()
    assert  q._unfinished_tasks == 0

# Generated at 2022-06-22 04:21:18.990810
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(1)
    assert q.qsize() == 2
    q.put_nowait(1)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0

# Generated at 2022-06-22 04:21:21.438272
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    q.put_nowait(1)

    assert q.full() == False, 'put_nowait not work in Queue'


# Generated at 2022-06-22 04:21:26.003780
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize = 10)
    test = queue.__repr__()
    assert test == "<Queue at 0x1039dab70 maxsize=10 queue=deque([])>"


# Generated at 2022-06-22 04:21:37.200746
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
                if item == 23:
                    break
    def producer():
        for item in range(5):
            q.put(item)
            print('Put %s' % item)
    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield

# Generated at 2022-06-22 04:21:38.835623
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()
    assert isinstance(qf, Exception)
    return 


# Generated at 2022-06-22 04:21:47.658364
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    """
    def test_Queue___aiter__(self):
        io_loop = self.new_ioloop()
        q = Queue()

        @gen.coroutine
        def f():
            values = yield q.join()
            self.assertEqual(values, [0, 1, 2])

        t = threading.Thread(target=io_loop.run_sync, args=(f,))
        t.start()
        try:
            for i in range(3):
                q.put(i)
        finally:
            io_loop.add_callback(io_loop.stop)
            t.join()
            io_loop.close()
    """
    io_loop = ioloop.IOLoop()
    q = Queue()

    @gen.coroutine
    def f():
        values = yield

# Generated at 2022-06-22 04:21:59.715169
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

test_Queue

# Generated at 2022-06-22 04:22:06.355194
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    q.put_nowait(1)
    assert q.get_nowait() == 1



# Generated at 2022-06-22 04:22:13.368594
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Can put an item into the empty queue
    q = Queue(maxsize=0)
    q.put_nowait(1)

    # Can put an item into the queue in which there are already items
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)

    # Raises queue full
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-22 04:22:19.642235
# Unit test for method full of class Queue
def test_Queue_full():
    # Ensures that method full is working correctly
    q = Queue()
    assert q.full() == False
    q.__put_internal(1)
    assert q.full() == False
    q.__queue = [1, 2, 3]
    assert q.full() == False
    q.__queue = [1, 2, 3, 4, 5]
    assert q.full() == True
    print('test_Queue_full passed')

if __name__ == '__main__':
    test_Queue_full()



# Generated at 2022-06-22 04:22:36.868761
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    import unittest

    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:22:37.907510
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull("test")



# Generated at 2022-06-22 04:22:41.051214
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    lq = LifoQueue()
    lq.put(3)
    lq.put(2)
    lq.put(1)
    print(lq.get_nowait())
    print(lq.get_nowait())
    print(lq.get_nowait())


# Generated at 2022-06-22 04:22:45.181658
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import ioloop
    from tornado.queues import Queue
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    q.put_nowait(4)
    assert q.qsize() == 3
    q.get_nowait()
    assert q.qsize() == 2


# Generated at 2022-06-22 04:22:54.259850
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    import time
    # Create a queue with maxsize=2
    q = Queue(maxsize=2)
    ioloop = IOLoop.current()
    # add a callback
    ioloop.add_callback(q.put, "hello")

    print(q.qsize())
    # add another callback
    ioloop.add_callback(q.put, "hello2")
    print(q.qsize())
    # add another callback
    ioloop.add_callback(q.put, "hello3")
    print(q.qsize())
    time.sleep(10)


# Generated at 2022-06-22 04:22:58.564638
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type:()->None
    qe = QueueEmpty()
    assert qe.args == ()
    assert repr(qe) == "QueueEmpty()"
    assert str(qe) == "QueueEmpty()"


# Generated at 2022-06-22 04:23:05.290036
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # Queue.get(timeout=None)
    get_result = q.get()
    # Queue.get(timeout=0.1)
    get_result = q.get(0.1)
    # Queue.get(timeout=datetime.timedelta(seconds=0.1))
    get_result = q.get(datetime.timedelta(seconds=0.1))

    assert isinstance(get_result, Awaitable)
    assert issubclass(get_result.__class__, Awaitable)


# Generated at 2022-06-22 04:23:07.568270
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # TODO: implement unit test for method 'get_nowait' of class 'Queue'
    assert True

# Generated at 2022-06-22 04:23:11.929579
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait('1')
    q.put_nowait(2)
    assert q.full()

test_Queue_full()


# Generated at 2022-06-22 04:23:21.911153
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-22 04:23:54.829489
# Unit test for method put_nowait of class Queue

# Generated at 2022-06-22 04:23:56.675152
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True
    assert q.qsize() == 0


# Generated at 2022-06-22 04:24:04.636386
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    print(q.task_done())
    assert q.qsize() == 0
    for item in range(5):
        q.put_nowait(item)
    # The qsize should be 2
    assert q.qsize() == 2
    # The qsize should be 0
    print(q.task_done())
    assert q.qsize() == 0
try:
    test_Queue_task_done()
except:
    pass



# Generated at 2022-06-22 04:24:09.135722
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        print('get_nowait exception: ', e)
    except Exception as e:
        print('get_nowait exception error: ', e)


# Generated at 2022-06-22 04:24:17.494007
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import logging
    from tornado.platform.asyncio import AsyncIOMainLoop, to_tornado_future
    from tornado.testing import AsyncTestCase, gen_test

    class _TestQueue(AsyncTestCase):
        def test_Queue___aiter__(self):
            queue = Queue()
            for n in range(3):
                queue.put_nowait(n)

            i = 0
            async for item in queue:
                self.assertEqual(i, item)
                i += 1
            self.assertEqual(i, 3)

    AsyncIOMainLoop().install()
    _TestQueue().test_Queue___aiter__()



# Generated at 2022-06-22 04:24:20.148643
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass
    try:
        raise QueueFull("message")
    except QueueFull:
        pass


# Generated at 2022-06-22 04:24:22.797537
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    print(q.get_nowait())


# Generated at 2022-06-22 04:24:34.971995
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(0)

    # test when self.maxsize == 0
    future = q.put(1)
    assert future.result() is None

    # test if the queue is full
    q.put_nowait(1)
    with pytest.raises(QueueFull):
        q.put(1)

    # test if there is a getter
    q2 = Queue(10)
    future = q2.get()
    q2.put_nowait(1)
    q2.put(1)
    assert future.result() == 1
    with pytest.raises(QueueFull):
        q2.put(1)

    # test if there is a getter, but the queue is full.
    q3 = Queue(10)
    future = q3.get()

# Generated at 2022-06-22 04:24:44.891922
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        IOLoop.current().run_sync(producer)     # Wait for producer to put all tasks.

# Generated at 2022-06-22 04:24:46.422181
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2

# Generated at 2022-06-22 04:25:35.455483
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    import concurrent.futures
    import time
    import types
    import datetime
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import unittest
    import unittest.mock
    import asynctest
    import asynctest.mock
    e = tornado.gen.TimeoutError()
    class d(asynctest.TestCase):
        def setUp(self):
            pass

# Generated at 2022-06-22 04:25:37.116823
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-22 04:25:38.703081
# Unit test for constructor of class QueueFull
def test_QueueFull():
    queue_full = QueueFull()
    assert str(queue_full) == 'QueueFull()'


# Generated at 2022-06-22 04:25:40.536828
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert str(e) == 'QueueEmpty()'
    assert repr(e) == 'QueueEmpty()'



# Generated at 2022-06-22 04:25:43.877803
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    q.put(1)
    q.put(2)

    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True



# Generated at 2022-06-22 04:25:50.430282
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait("foo")
    it = _QueueIterator(q)
    
    future = q.get()
    assert isinstance(future, Awaitable)
    assert isinstance(future, Future)
    assert not future.done()

    assert future is next(it)
    assert future.done()
    assert future.result() == "foo"


# Generated at 2022-06-22 04:25:56.748847
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import testing
    from typing import AsyncGenerator

    async def test(aiter: AsyncGenerator[int, None], q: Queue) -> None:
        for i in aiter:
            assert i == 0
            await q.put(i)
            assert i == 1
            await q.put(i)
            assert i == 2
            await q.put(i)

    q = Queue()
    ioloop = ioloop.IOLoop.current()
    ioloop.run_sync(lambda: test(q, q))

# Generated at 2022-06-22 04:26:06.737029
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:26:08.580660
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q_iter = _QueueIterator(q)
    assert q == q_iter.q


# Generated at 2022-06-22 04:26:14.842338
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                assert item == 0
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(2):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.