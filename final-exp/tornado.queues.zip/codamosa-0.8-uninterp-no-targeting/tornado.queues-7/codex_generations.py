

# Generated at 2022-06-22 04:17:13.618519
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.001)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:17:23.485598
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import math
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 tasks=0>" % id(q)
    q.put_nowait(123)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[123] tasks=1>" % id(q)
    q.put_nowait(456)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[123, 456] tasks=2>" % id(q)
    q.task_done()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[456] tasks=1>" % id(q)
    q.task_done()

# Generated at 2022-06-22 04:17:27.928418
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2

# Generated at 2022-06-22 04:17:30.137649
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except Exception as e:
        assert e is not None


# Generated at 2022-06-22 04:17:33.719084
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1

    q = Queue()
    try:
        q.put_nowait(1)
        q.put_nowait(1)
        q.put_nowait(1)
    except QueueFull:
        print('QueueFull')


# Generated at 2022-06-22 04:17:46.737230
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import time
    q = Queue(maxsize=2)
    async def consumer():
        print("Started")
        async for item in q:
            try:
                print('Doing work on %s' % item)
                time.sleep(0.1)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        q.put(4)
        q.put(5)
        asyncio.get_event_loop().create_task(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-22 04:17:52.404816
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue(1)
    return q.put(1) and q.put(2), \
        _QueueIterator(q).__anext__().result(), \
        _QueueIterator(q).__anext__().result()
# __DONE__



# Generated at 2022-06-22 04:17:55.613061
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put("a")
    q.put("b")
    assert q.get_nowait() == "b"
    assert q.get_nowait() == "a"
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise AssertionError("Queue should be empty")
    return True

if __name__ == '__main__':
    print(test_LifoQueue())

# Generated at 2022-06-22 04:17:58.398364
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    def __anext__(self) -> None:
        res = yield self.q.get()
        return res
    __anext__(None)



# Generated at 2022-06-22 04:18:02.491491
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    print (q._queue)
    assert q._queue == deque([1, 2, 3])


# Generated at 2022-06-22 04:18:15.337226
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=0)
    f = Future()
    q._unfinished_tasks = 1
    q._finished = f
    q.task_done()
    f.set_result(None)
    return True


# Generated at 2022-06-22 04:18:18.165339
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    f = Future()
    f.set_result(42)
    q = Queue()
    q.put_nowait(42)
    iter = _QueueIterator(q)
    assert iter.__anext__() == f


# Generated at 2022-06-22 04:18:20.191983
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except:
        pass


# Generated at 2022-06-22 04:18:21.458370
# Unit test for constructor of class QueueFull
def test_QueueFull():
    a = QueueFull()
    assert isinstance(a, Exception)



# Generated at 2022-06-22 04:18:27.497172
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('queue is full')
    except QueueFull as e:
        assert str(e) == 'queue is full'
    try:
        raise QueueFull()
    except QueueFull as e:
        assert str(e) == ''


# Generated at 2022-06-22 04:18:33.417613
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Instance of class Queue
    q = Queue(maxsize=2)
    
    # Put an item into the queue, perhaps waiting until there is room.
    q.put(1)
    q.put(2)
    
    # Return an item if one is immediately available, else raise QueueEmpty
    get_nowait = q.get_nowait()
    assert get_nowait == 1
    assert q.qsize() == 1
    assert q.full() == True
    assert q.empty() == False



# Generated at 2022-06-22 04:18:33.994855
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    pass

# Generated at 2022-06-22 04:18:35.629553
# Unit test for method empty of class Queue
def test_Queue_empty():
    test_q = Queue()
    assert test_q.qsize() == 0
    assert test_q.empty() == True


# Generated at 2022-06-22 04:18:39.351755
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=0)
    assert q.full()==False



# Generated at 2022-06-22 04:18:41.203162
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        print(type(e))
        print(e.args)
        print(e)
    finally:
        pass

# test_QueueFull()


# Generated at 2022-06-22 04:18:52.713359
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    exc = QueueEmpty()
    assert str(exc) == "queue is empty"
    assert repr(exc) == ("QueueEmpty(message='queue is empty')")


# Generated at 2022-06-22 04:18:54.093537
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty


# Generated at 2022-06-22 04:19:05.310248
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(0)
    assert str(q) == "<Queue maxsize=0>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=0 queue=[1]>"
    assert q.empty() == False
    assert q.qsize() == 1
    q.put_nowait(2)
    assert str(q) == "<Queue maxsize=0 queue=[1, 2]>"
    q.put_nowait(3)
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3]>"
    assert q.empty() == False
    assert q.qsize() == 3
    assert q.get_nowait() == 1
    assert str(q) == "<Queue maxsize=0 queue=[2, 3]>"

# Generated at 2022-06-22 04:19:12.368333
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:19:16.124718
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    q.put_nowait(2)
    q.put_nowait(3)
    print("size of queue is ",q.qsize())


# Generated at 2022-06-22 04:19:26.958494
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop

# Generated at 2022-06-22 04:19:35.088656
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    assert queue.qsize() == 0
    queue.put(1)
    assert queue.qsize() == 1
    queue.put_nowait(2)
    assert queue.qsize() == 2
    future1 = queue.put(3, timeout=None)
    assert queue.qsize() == 3
    future2 = queue.put(4, timeout=0)
    assert queue.qsize() == 3
    assert isinstance(future1, Future)
    assert isinstance(future2, Future)


# Generated at 2022-06-22 04:19:40.486904
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Testing for proper execution
    q = Queue()
    assert q.__str__() == '<Queue maxsize=0 queue=deque([])>'
    q.put_nowait(42)
    assert q.__str__() == '<Queue maxsize=0 queue=deque([42])>'


# Generated at 2022-06-22 04:19:50.006899
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # 测试单元Queue的get_nowait方法
    def put_async(q,q_put,q_get):
        # 异步put
        q.put(q_put)
        print("put_async: " + "put " + str(q_put))
        q_get.set_result(None)
        print("put_async: " + "set_result_unless_cancelled " + str(q_get))
    def get_async(q,q_get,q_put):
        # 异步get
        q_put.set_result(None)
        print("get_async: " + "set_result_unless_cancelled " + str(q_put))
        c = q.get_nowait()


# Generated at 2022-06-22 04:19:55.866101
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:20:13.995465
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=3)
    assert q.qsize() == 0
    assert q.empty() == True
    q.put_nowait("a")
    q.put_nowait("b")
    q.put_nowait("c")
    assert q.full() == True
    q.get_nowait()
    assert q.empty() == False
    q.get_nowait()
    assert q.empty() == False
    q.get_nowait()
    assert q.empty() == True
    try:
        q.get_nowait()
    except QueueEmpty:
        assert q.empty() == True
    else:
        raise AssertionError("A queue empty exception has not been raised")

# Generated at 2022-06-22 04:20:17.277705
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    (x1) = _QueueIterator((_QueueIterator(None)))
    ret = x1.__anext__()
    assert False



# Generated at 2022-06-22 04:20:28.219021
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue = Queue()
    assert queue.__repr__() == "<Queue at 0x%x maxsize=0 >" % id(queue)
    queue.put("key")
    assert queue.__repr__() == "<Queue at 0x%x maxsize=0 queue=deque(['key'])>" \
                               % id(queue)
    queue.get()
    assert queue.__repr__() == "<Queue at 0x%x maxsize=0 >" % id(queue)
    queue = Queue(5)
    assert queue.__repr__() == "<Queue at 0x%x maxsize=5 >" % id(queue)
    queue.put("key")

# Generated at 2022-06-22 04:20:31.585191
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    import tornado.testing
    tornado.testing.gen_test(
        q.put(1) # type: ignore
    )
    import asyncio
    assert asyncio.get_event_loop().run_until_complete(
        q.get() # type: ignore
    ) is 1



# Generated at 2022-06-22 04:20:35.256595
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    yield q.put(1)
    assert (yield from it.__anext__()) == 1
    yield q.put(2)
    assert (yield from it.__anext__()) == 2
    yield q.put(3)
    assert (yield from it.__anext__()) == 3



# Generated at 2022-06-22 04:20:37.456746
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass



# Generated at 2022-06-22 04:20:40.317637
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-22 04:20:43.247533
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=5)
    q.put('1')
    q.get()
    assert q.empty()==True

# Generated at 2022-06-22 04:20:49.709772
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()      # maxsize is not specified, so Queue is of infinite size
    q.put_nowait(1)  # No exception is raised
    q.put_nowait(2)  # No exception is raised
    q.put_nowait(3)  # No exception is raised
    # q.put_nowait(4)  # QueueFull exception is raised
    # q.put_nowait(5)  # QueueFull exception is raised
    print("Queue size = {}".format(q.qsize()))  #3


# Generated at 2022-06-22 04:20:55.933444
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        q = Queue()
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True

    # It should be enough to use a queue of size 1
    # as the methods we test take care of the general case
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.get_nowait() == 1

    f = q.get()
    q.put_nowait(4)
    assert f.result() == 4

    # It shouldn't matter whether put or get is called first
    q = Queue()
    f = q.put(1)
    assert q.get_nowait() == 1;
    assert f.result() is None

    q = Queue()
    f = q.get()
    q.put_

# Generated at 2022-06-22 04:21:07.594389
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-22 04:21:10.516436
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    """
    Test method __repr__ of class Queue
    """
    lol = Queue(maxsize=2)
    assert str(lol) == '<Queue maxsize=2>'
    # TODO add more tests



# Generated at 2022-06-22 04:21:22.798053
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Create a basic Queue class
    queue1 = Queue(maxsize=2)
    
    print(queue1._format())
    # Test if the returned string is correct
    assert(queue1._format() == "maxsize=2 queue=deque([]) getters[0] putters[0] tasks=0")
    # Add a task to the queue
    queue1.__put_internal(1)
    # Check if the task was finished
    assert(queue1._unfinished_tasks != 0)
    # Check if the returned string is correct
    assert(queue1._format() == "maxsize=2 queue=deque([1]) getters[0] putters[0] tasks=1")
    # Finish the task
    queue1.task_done()
    # Check if the task was finished

# Generated at 2022-06-22 04:21:34.976900
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # test with default value 0
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True

    q = Queue(1)
    assert q.empty() == True
    assert q.qsize() == 0

    q = Queue(5)
    assert q.empty() == True
    assert q.qsize() == 0

    # case of maxsize = 0
    q = Queue(0)
    q._init()
    q._put(1)
    q._put(2)
    assert q.qsize() == 2

    # after putting, it still empty
    assert q.empty() == True
    assert q.qsize() == 2

    # case of maxsize > 0
    q = Queue(5)
    q._init()
    assert q.qsize()

# Generated at 2022-06-22 04:21:37.563234
# Unit test for method full of class Queue
def test_Queue_full():
    from queue import Queue
    queue = Queue()
    assert queue.full() == False
    assert queue.empty() == True

# Generated at 2022-06-22 04:21:39.924163
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    queue = Queue()
    qi = _QueueIterator(queue)
    f = qi.__anext__()
    assert isinstance(f, Awaitable)

# Generated at 2022-06-22 04:21:41.649874
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize = 0)
    assert q.empty() == True


# Generated at 2022-06-22 04:21:44.848760
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:21:47.232132
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.put(1)
    q.put(2)
    q.get()
    q.task_done()
    q.get()
    q.task_done()


# Generated at 2022-06-22 04:21:51.211824
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0
    q = Queue(5)
    assert q.maxsize == 5


# Generated at 2022-06-22 04:22:17.920382
# Unit test for method full of class Queue
def test_Queue_full():
    m = Queue(maxsize = 2)
    
    m.put_nowait(5)
    m.put_nowait(6)
    #case 1
    assert m.full() == True
    
    #case 2
    m.get_nowait()
    assert m.full() == False
    
    
    
m = Queue(maxsize = 2)
m.put_nowait(5)
m.put_nowait(6)
assert m.full() == True
m.get_nowait()
assert m.full() == False

# Generated at 2022-06-22 04:22:30.139993
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue(maxsize=2)

    # Add an item
    queue.put(5, timeout=5)
    assert queue.qsize() == 1

    # Get an item
    item = queue.get(timeout=5)
    assert item == 5
    assert queue.qsize() == 0
    
    # Get an item again
    item = queue.get(timeout=5)
    assert item == 5
    assert queue.qsize() == 0

    # Get an item but it's not there and we wait 5 second
    future = queue.get(timeout=5)
    assert len(queue._getters) == 1
    assert queue.qsize() == 0

    # Add an item
    queue.put(5, timeout=5)
    assert queue.qsize() == 1

# Generated at 2022-06-22 04:22:32.017976
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    q.put(5)
    q.put(10)
    assert q.qsize() == 2

# Generated at 2022-06-22 04:22:37.907748
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    result = queue.get_nowait()
    assert result == None
    queue.put(1)
    result = queue.get()
    assert result == 1
    done = queue.task_done()
    assert done == None
    done = queue.join()
    assert done == None

# Generated at 2022-06-22 04:22:40.786802
# Unit test for method full of class Queue
def test_Queue_full():
    # Create a Queue object.
    q = Queue(maxsize=0)
    # Check the queue is full.
    q.full()


# Generated at 2022-06-22 04:22:44.179198
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_LifoQueue()

# Generated at 2022-06-22 04:22:48.829273
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    def test_func():
        return None
    x = _QueueIterator(Queue())
    x.__init__(Queue())
    x.__anext__()
    x.q
    return test_func


# Generated at 2022-06-22 04:22:52.195906
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    if q.qsize() != 0:
        return False
    q.put_nowait(1)
    if q.qsize() != 1:
        return False
    return True


# Generated at 2022-06-22 04:22:53.078058
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    Queue(maxsize=2)



# Generated at 2022-06-22 04:22:55.571804
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    size_limit = 10
    q = Queue(maxsize=size_limit)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2


# Generated at 2022-06-22 04:23:43.498155
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    assert q.empty()
    assert not q.full()
    q.put_nowait(1)
    assert not q.empty()
    assert q.full()
    assert q.get_nowait() == 1
    assert not q.full()



# Generated at 2022-06-22 04:23:49.517054
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    print('q',q)
    print('q.qsize()',q.qsize())
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    print('q.qsize()',q.qsize())
    print('q._queue',q._queue)


# Generated at 2022-06-22 04:23:51.625096
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    print('test__QueueIterator')
    q = Queue()
    it = _QueueIterator(q)
    return it


# Generated at 2022-06-22 04:23:57.565910
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(0)
    assert not q.full()
    q.put_nowait(1)
    assert q.full()
    assert q.qsize() == 2
    assert q.empty() == False
    q.get_nowait()
    q.get_nowait()
    assert q.full() == False
    assert q.qsize() == 0
    assert q.empty()

# Generated at 2022-06-22 04:24:02.571584
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=1)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0

# Generated at 2022-06-22 04:24:04.986504
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    try: QueueFull()
    except Exception as e:
        assert(0)
    else:
        assert(1)
        


# Generated at 2022-06-22 04:24:12.285723
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    assert q.empty()
    f = q.put("A")
    assert not f.cancelled()
    assert not f.done()
    assert q.empty()
    f.set_result("A")
    assert not f.cancelled()
    assert f.done()
    assert not q.empty()
    assert q.qsize() == 1

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-22 04:24:12.795022
# Unit test for constructor of class QueueFull
def test_QueueFull():
    pass


# Generated at 2022-06-22 04:24:16.259418
# Unit test for method get of class Queue
def test_Queue_get():
    a = Queue()
    future = Future()
    result = QueueEmpty
    try:
        future.set_result(a.get_nowait())
    except QueueEmpty:
        result = QueueEmpty
    assert(result== QueueEmpty)

# Generated at 2022-06-22 04:24:18.797951
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        assert isinstance(e, QueueFull)



# Generated at 2022-06-22 04:25:54.018461
# Unit test for method put of class Queue
def test_Queue_put():
    io_loop = ioloop.IOLoop.current()
    q = Queue(maxsize=2)
    async def test():
        await q.put("1")
        await q.put("2")
        try:
            await q.put("3", timeout=1.0)
            assert False
        except gen.TimeoutError:
            pass
        try:
            await q.put("3")
            assert False
        except QueueFull:
            pass
        return True
    io_loop.run_sync(test)

    async def test2():
        await q.put("4")
        assert True
        return True
    io_loop.run_sync(test2)


# Generated at 2022-06-22 04:25:54.816820
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()



# Generated at 2022-06-22 04:26:04.457417
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def producer(item):
        print("Enqueuing %d" % item)
        q.put(item)
        print("Enqueued %d" % item)

    def producer_wrapper(item):
        producer(item)
        return True

    def consumer():
        try:
            while True:
                item = q.get()
                try:
                    print("Processing %d" % item)
                finally:
                    q.task_done()
        except gen.Return:
            pass

    def consumer_wrapper():
        try:
            consumer()
        except gen.Return:
            pass

    producer(1)
    producer(2)
    producer(3)
    print("Done enqueuing")
    
    ioloop.IOLoop.current().run_

# Generated at 2022-06-22 04:26:06.049188
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__(): pass


# Generated at 2022-06-22 04:26:08.870583
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()

    q.put_nowait(1)
    assert not q.full()

    q.put_nowait(2)
    assert q.full()

# Generated at 2022-06-22 04:26:09.666796
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-22 04:26:11.625473
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # Construct by passing the argument
    try:
        raise QueueFull("test")
    except QueueFull as e:
        assert(str(e) == "test")



# Generated at 2022-06-22 04:26:16.262738
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # self, item: _T, timeout: Optional[Union[float, datetime.timedelta]] = None
    # check None
    q = Queue(maxsize=0)
    q.put_nowait(item=None)

    # check numeric value
    q1 = Queue(maxsize=0)
    q1.put_nowait(item=0)

    # check string value
    q = Queue(maxsize=0)
    q.put_nowait(item='hello')


# Generated at 2022-06-22 04:26:25.177838
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Test with a Queue object
    q = Queue()

    assert repr(q) == '<Queue at 0x{0:x} maxsize=0 queue=deque([])>'.format(id(q))

    # put two items to the queue
    q.put_nowait('first')
    q.put_nowait('second')

    assert repr(q) == '<Queue at 0x{0:x} maxsize=0 queue=deque(['

# Generated at 2022-06-22 04:26:32.712453
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    print(q.qsize())
    q.put_nowait(1)
    print(q.qsize())
    q.put_nowait(2)
    print(q.qsize())
    print(q.get_nowait())
    print(q.qsize())
    print(q.get_nowait())
    print(q.qsize())

