

# Generated at 2022-06-22 04:17:20.524619
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    print("queue maxsize = ", q.maxsize)
    _list = []
    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                time.sleep(0.01)
                _list.append(item)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-22 04:17:21.553614
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()


# Generated at 2022-06-22 04:17:25.555708
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

if __name__ == '__main__':
    test_PriorityQueue()


# Generated at 2022-06-22 04:17:34.367955
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    ret = None
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    queue_iterator = _QueueIterator(q)
    async for n in queue_iterator:
        assert ret == None
        ret = n
        # assert ret == 1
        # ret = None
        # assert n == 1
        # ret = n
        # assert ret == 2
        # ret = None
        # assert n == 2
        # ret = n
        # assert ret == 3
        # ret = None
        # assert n == 3
        # ret = n
        # break


# Generated at 2022-06-22 04:17:37.580112
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()

    from tornado.util import b
    assert e == QueueEmpty()
    assert b(e) == b(QueueEmpty())
    assert str(e) == str(QueueEmpty())


# Generated at 2022-06-22 04:17:48.839868
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-22 04:17:58.907080
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:18:06.927007
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    element1 = 0
    element2 = 1
    assert q.empty() is True
    q.__put_internal(element1)
    assert q.get_nowait() == element1
    q.__put_internal(element2)
    assert q.get_nowait() == element2
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert True
    except:
        assert False


# Generated at 2022-06-22 04:18:10.890651
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    print("begin get")
    q.get()
    print("begin put")
    q.put(3)
    print("begin task_done")
    q.task_done()


# Generated at 2022-06-22 04:18:13.512418
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    if q.full():
        del q
        return True
    del q
    return False


# Generated at 2022-06-22 04:18:23.842658
# Unit test for method put of class Queue
def test_Queue_put():
    try:
        Queue().put(5)
    except:
        pass

# Generated at 2022-06-22 04:18:25.410298
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(0)
    with pytest.raises(QueueFull):
        q.put_nowait(1)
    

# Generated at 2022-06-22 04:18:26.756336
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.get_nowait() == None


# Generated at 2022-06-22 04:18:28.740356
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=0)
    q.put_nowait(0)
    assert q.qsize() == 1



# Generated at 2022-06-22 04:18:32.463272
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True, 'Test Failed'
    q.put('aaaa')
    assert q.empty() == False, 'Test Failed'
    r = q.get()
    r.result()
    assert q.empty() == True, 'Test Failed'


# Generated at 2022-06-22 04:18:44.000067
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-22 04:18:46.792991
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(0)
    it = _QueueIterator(q)
    assert q is it.q


_T_co = typing.TypeVar("_T_co", covariant=True)



# Generated at 2022-06-22 04:18:50.194095
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    print(q.qsize())
    q.put(1)
    print(q.qsize())
    q.put(2)
    print(q.qsize())


# Generated at 2022-06-22 04:18:52.273721
# Unit test for constructor of class QueueFull
def test_QueueFull():
    t = QueueFull()
    assert type(t) == QueueFull
    return None


# Generated at 2022-06-22 04:18:57.439362
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: () -> None
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    qiter = iter(q)
    assert isinstance(qiter, _QueueIterator)
    for v in qiter:
        print(v)
    assert True



# Generated at 2022-06-22 04:19:13.166905
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    # Put an item into the queue, then take it out and process it
    q.put('hi')
    item = q.get()
    # Indicate completion
    q.task_done()
    # Show queue is now empty
    if q.empty():
        print('queue is now empty')
    else:
        print('queue is not empty')
test_Queue_task_done()


# Generated at 2022-06-22 04:19:16.831861
# Unit test for method empty of class Queue
def test_Queue_empty():

    q = Queue(maxsize=1) # type: Queue[_T]
    assert q.empty() is True
    q.put_nowait(1)
    assert q.empty() is False


# Generated at 2022-06-22 04:19:18.384976
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    print(q)



# Generated at 2022-06-22 04:19:20.523663
# Unit test for constructor of class Queue
def test_Queue():
    queue=Queue(maxsize=1)
    queue.put_nowait(1)
    assert queue.get_nowait() == 1



# Generated at 2022-06-22 04:19:23.087112
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = Queue(5)
    for i in range(5):
        q.put_nowait(i)
    assert len(q) == 5
    try:
        q.put_nowait(5)
        assert False
    except QueueFull:
        print("QueueFull occured")


# Generated at 2022-06-22 04:19:30.131588
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q._queue = collections.deque([1, 2])
    q._unfinished_tasks = 2
    result = q.get_nowait()
    assert result == 1
    assert q._queue == collections.deque([2])
    assert q._unfinished_tasks == 1

# Generated at 2022-06-22 04:19:34.617968
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    a = PriorityQueue()
    b = PriorityQueue()
    a.put((0, 'high-priority item'))
    a.put((1, 'medium-priority item'))
    a.put((10, 'low-priority item'))
    a.get_nowait()
    a.get_nowait()
    a.get_nowait()


# Generated at 2022-06-22 04:19:38.534627
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass



# Generated at 2022-06-22 04:19:46.797332
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import sys
    import random
    import time
    import unittest
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    class QueueTestCase(AsyncTestCase):
        def setUp(self):
            super(QueueTestCase, self).setUp()
            self.queue = Queue()
        async def test_put_nowait(self):
            self.queue._putters.append((1,to_tornado_future(asyncio.Future(loop=self.loop))))
            self.assertTrue(self.queue.full())

# Generated at 2022-06-22 04:19:59.395286
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0>" % id(q)
    assert str(q) == "<Queue maxsize=0>"
    q.put_nowait(1)
    q.put_nowait(2)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([1, 2])>" % id(q)
    assert str(q) == "<Queue maxsize=0 queue=deque([1, 2])>"
    q.task_done()
    q.task_done()
    q.join()
    assert repr(q) == "<Queue at 0x%x maxsize=0>" % id(q)
    assert str(q) == "<Queue maxsize=0>"
    # unit test code ends



# Generated at 2022-06-22 04:20:15.254477
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    
    # Test first case.
    q._getters.append(None)
    q.get_nowait()
    
    q._putters.append((None, None))
    assert len(q._queue) > 0
    
    # Test case when q._queue is full.
    q._putters.append((None, None))
    q._putters.append((None, None))
    q._putters.append((None, None))
    
    try:
        q.put_nowait(None)
        assert False
    except QueueFull as e:
        pass


# Generated at 2022-06-22 04:20:19.011010
# Unit test for method empty of class Queue
def test_Queue_empty():
    a = Queue()

    if a.empty() != True:
        raise AssertionError("a.empty() should return True")



# Generated at 2022-06-22 04:20:21.003629
# Unit test for constructor of class Queue
def test_Queue():
    print(Queue(maxsize=None))
    print(Queue(maxsize=-1))
    print(Queue(maxsize=1))


# Generated at 2022-06-22 04:20:24.688991
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass



# Generated at 2022-06-22 04:20:33.052672
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    print(PriorityQueue.__doc__)
    q = PriorityQueue()
    q.put((1, "medium-priority item"))
    q.put((0, "high-priority item"))
    q.put((10, "low-priority item"))

    assert q.get_nowait() == (0, "high-priority item")
    assert q.get_nowait() == (1, "medium-priority item")
    assert q.get_nowait() == (10, "low-priority item")

import unittest


# Generated at 2022-06-22 04:20:41.755189
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import _tornado_five as tf
    from tornado.locks import Event
    from tornado.testing import AsyncTestCase, gen_test

    class MyTC(AsyncTestCase):
        @gen_test
        def test_it(self):
            def check(q: tf.Queue[tf.int]) -> tf.int:
                res = 0
                async for i in q:
                    res += i
                return res

            q = tf.Queue[tf.int](1)
            await q.put(1)
            await q.put(2)
            await q.put(3)
            self.assertEqual(await check(q), 6)

    MyTC().test_it()



# Generated at 2022-06-22 04:20:45.478244
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int]()
    q.put_nowait(1)
    q.put_nowait(2)
    it = _QueueIterator(q)
    assert it.q == q
    assert it.__anext__() == q.get()


# Generated at 2022-06-22 04:20:53.362527
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-22 04:20:59.195159
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-22 04:21:02.985809
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()

test_Queue()



# Generated at 2022-06-22 04:21:23.695764
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Put and Get tests
    q = Queue()
    put_item = 1
    q.put_nowait(put_item)
    get_item = q.get_nowait()
    assert put_item == get_item, "Get: Get item %s not equal Put item %s" % (get_item, put_item)
    assert q.empty(), "Get: Queue %s not empty" % q
    # Get from empty Queue
    try:
        q.get_nowait()
        assert False, "Get: Queue %s got item from empty Queue" % q
    except QueueEmpty:
        pass
    # Test Put and Get when Queue is full
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)


# Generated at 2022-06-22 04:21:26.708499
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert it.q == q


# Generated at 2022-06-22 04:21:28.121322
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    assert True


# Generated at 2022-06-22 04:21:30.304985
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    data = b"".join(bytes([v]) for v in range(255))
    q = Queue(maxsize=0)
    q.put_nowait(data)
    it = _QueueIterator(q)
    assert await it.__anext__() == data
    return 0


# Generated at 2022-06-22 04:21:36.929690
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')


# Generated at 2022-06-22 04:21:38.585520
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:21:40.680119
# Unit test for constructor of class QueueFull
def test_QueueFull():
   try:
       raise QueueFull
   except Exception as e:
       print('Caught an exception of {}'.format(str(e)))


# Generated at 2022-06-22 04:21:51.397766
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize = 0
    q = Queue(maxsize)
    q.put_nowait(1)
    assert q.empty() == False, "If the queue is not empty, why are getters waiting?"
    assert q.full() == False, "If the queue is not full, why are putters waiting?"
    assert q.qsize() == 1, "The queue size is 1, but the qsize is %s" % q.qsize()

    #maxsize = 2
    q = Queue(maxsize)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.empty() == False, "If the queue is not empty, why are getters waiting?"
    assert q.full() == True, "If the queue is full, why are putters waiting?"
    assert q.qsize

# Generated at 2022-06-22 04:21:52.708505
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass



# Generated at 2022-06-22 04:21:54.012082
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    assert(Queue()).get(1) == 1

# Generated at 2022-06-22 04:22:06.280315
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = Queue()
    q.put(1)
    q.get_nowait()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-22 04:22:07.923243
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        assert True



# Generated at 2022-06-22 04:22:12.709762
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q1 = Queue(maxsize=3)
    q2 = Queue(maxsize=0)
    try:
        q3 = Queue(maxsize=-1)
    except ValueError:
        pass
    except Exception:
        assert False

    q4 = Queue(maxsize=None)
    try:
        q4.put_nowait(1)
    except:
        assert False

# Generated at 2022-06-22 04:22:16.113192
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    with pytest.raises(QueueEmpty):
        raise QueueEmpty()


# Generated at 2022-06-22 04:22:28.975961
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    init_queue = collections.deque()
    max_size = 5
    test = Queue(max_size)
    test._queue = init_queue
    # Testing case 1: when queue is empty, a new item can be put into the queue.
    print("Testing case 1: when queue is empty, a new item can be put into the queue.")
    new_item = 1
    test.put_nowait(new_item)
    assert test.qsize() == 1, "when queue is empty, a new item cannot be put into the queue."
    print("Passed")
    # Testing case 2: when queue is empty, a new item cannot be put into the queue if the queue is full.
    print("Testing case 2: when queue is empty, a new item cannot be put into the queue if the queue is full.")
    # Test when max_size

# Generated at 2022-06-22 04:22:30.903467
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except:
        pass



# Generated at 2022-06-22 04:22:37.446327
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    print(q)
    q.get_nowait()
    print(q)



# Generated at 2022-06-22 04:22:39.017091
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0


# Generated at 2022-06-22 04:22:40.999410
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()

    q.get()

test_Queue_get()

# Generated at 2022-06-22 04:22:43.211987
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(0)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % (id(q),)



# Generated at 2022-06-22 04:23:10.492532
# Unit test for method get of class Queue
def test_Queue_get():
    """Unit test for method get of class Queue"""
    q = Queue(maxsize=2)
    timeout = 1
    q.get(timeout)



# Generated at 2022-06-22 04:23:11.571022
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    LifoQueue(10)



# Generated at 2022-06-22 04:23:19.496571
# Unit test for method get of class Queue
def test_Queue_get():
    async def producer():
        for i in range(10):
            print("Putting {}", i)
            await q.put(i)
            print("Put {}", i)
        
    async def consumer():
        while True:
            val = await q.get()
            print("Get {}", val)
            q.task_done()

    q = Queue()
    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().spawn_callback(producer)
    ioloop.IOLoop.current().start()


# Generated at 2022-06-22 04:23:26.199734
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    print("Queue Full : ", q.full())
    for i in range(2):
        q.put_nowait("test_Queue_full" + str(i))
        print("Queue Full : ", q.full())
    try:
        q.put_nowait("test_Queue_full2")
    except QueueFull:
        print("Queue Full : ",q.full())



# Generated at 2022-06-22 04:23:31.670316
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)
    q.maxsize = 2
    print(q)
    q.put_nowait(3)
    print(q)
    q.put_nowait(4)
    print(q)
    q.get_nowait()
    print(q)
    q.get_nowait()
    print(q)


# Generated at 2022-06-22 04:23:33.397814
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)


# Generated at 2022-06-22 04:23:33.916771
# Unit test for constructor of class QueueFull
def test_QueueFull():
    pass



# Generated at 2022-06-22 04:23:45.305423
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    @gen.coroutine
    def download_one(url):
        yield gen.sleep(2)
        return url
    @gen.coroutine
    def downloader(urls):
        """Download the URLs in parallel, but in the
        order given.
        """
        q = Queue()
        res = []
        for _ in range(4):
            for url in urls:
                yield q.put(url)
            for i in range(len(urls)):
                url = yield q.get()
                s = yield download_one(url)
                res.append(s)
                q.task_done()
                # print(res)
        return res

# Generated at 2022-06-22 04:23:45.814983
# Unit test for method put of class Queue
def test_Queue_put():
    pass

# Generated at 2022-06-22 04:23:54.520502
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()
    assert q._getters == collections.deque([])

    q.__put_internal(1)
    assert q._getters == collections.deque([])
    assert q._queue == collections.deque([1])
    assert not q.empty()

    value = q._get()
    assert value == 1
    assert q._getters == collections.deque([])
    assert q._queue == collections.deque([])
    assert q.empty()



# Generated at 2022-06-22 04:24:37.656987
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)
    q.qsize()
    q.empty()
    q.full()
    q.put(item=1, timeout=1)
    q.put_nowait(item=1)
    q.get(timeout=1)
    q.get_nowait()
    q.task_done()
    q.join(timeout=1)
    q._init()
    q._get()
    q._put(item=1)
    q.__put_internal(item=1)
    q._consume_expired()
    q.__repr__()
    q.__str__()
    q._format()
    #q._init_unlocked()
    #q._get_unlocked()
    #q._put_unlocked(item=1)
 


# Generated at 2022-06-22 04:24:48.063512
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)
    # 1


# Generated at 2022-06-22 04:24:50.870904
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        print("Exception caught")



# Generated at 2022-06-22 04:24:55.987218
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    for i in range(3):
        q.put_nowait(i)
    qi = _QueueIterator(q)
    for i in qi:
        pass
    # The loop must be successful
    print("test__QueueIterator___anext__() passed")
test__QueueIterator___anext__()



# Generated at 2022-06-22 04:24:57.363972
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue() #test1: when the queue is empty
    assert q.empty() == True


# Generated at 2022-06-22 04:25:00.636655
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(4)

    assert q.full() == False
    q._maxsize = 0
    assert q.full() == False
    q._maxsize = 1
    assert q.full() == False
    q._maxsize = 2
    assert q.full() == False
    q._maxsize = 3
    assert q.full() == False
    q._maxsize = 4
    assert q.full() == False


# Generated at 2022-06-22 04:25:03.509514
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    iterator = _QueueIterator(q)
    assert iterator.q == q


# Generated at 2022-06-22 04:25:09.066334
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-22 04:25:15.801422
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue()
    print("test_Queue: ")
    print("        maxsize: ", queue.maxsize)
    print("        qsize: ", queue.qsize())
    print("        empty: ", queue.empty())
    print("        full: ", queue.full())
    print("        _format: ", queue._format())


# Generated at 2022-06-22 04:25:19.926185
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    ioloop.IOLoop.current().run_sync(test_Queue_qsize_async)
async def test_Queue_qsize_async():
    q = Queue()
    assert q.qsize() == 0
    await q.put(3)
    assert q.qsize() == 1
    

# Generated at 2022-06-22 04:26:03.675591
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass


# Generated at 2022-06-22 04:26:05.216109
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(1)
    print("Unit test of constructor of Queue")


# Generated at 2022-06-22 04:26:06.736189
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        print("test QueueFull success!")


# Generated at 2022-06-22 04:26:09.485606
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=0)
    print (str(q))
    assert (str(q) == "<Queue maxsize=0 queue=deque([]) getters[0] putters[0] tasks=0>")



# Generated at 2022-06-22 04:26:12.987267
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado.queues import Queue
    q = Queue()
    print(q.full())
    print(q.qsize())
    for i in range(5):
        q.put(i)
    print(q.full())
    print(q.qsize())
    print(q)


# Generated at 2022-06-22 04:26:18.062934
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-22 04:26:23.547421
# Unit test for method full of class Queue
def test_Queue_full():
    """
    Testing Queue full
    """
    q = Queue(maxsize=2)
    print(">>> %s => %s" %(q.full(), "False"))
    q.put("1")
    q.put("2")
    print(">>> %s => %s" %(q.full(), "True"))
    q.get()
    print(">>> %s => %s" %(q.full(), "False"))


# Generated at 2022-06-22 04:26:29.361953
# Unit test for method join of class Queue
def test_Queue_join():

  q = Queue()

  # Test timeout
  result = q.join(timeout=5)
  if result != None:
    print('Failure')

  # Test non-timeout
  q._finished.set()
  result = q.join(timeout=5)
  if result != None:
    print('Failure')

  print('Success')


# Generated at 2022-06-22 04:26:35.190246
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    q.get_nowait()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

# Generated at 2022-06-22 04:26:38.230804
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty()

