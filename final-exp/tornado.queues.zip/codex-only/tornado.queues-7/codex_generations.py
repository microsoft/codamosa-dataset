

# Generated at 2022-06-24 09:09:31.628460
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=1000)
    assert(q.qsize() == 0)


# Generated at 2022-06-24 09:09:36.629687
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()
    q.get_nowait()
    q.task_done()
    assert not q.full()

# Generated at 2022-06-24 09:09:38.223720
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)

# Generated at 2022-06-24 09:09:48.370783
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Test a task_done in Queue
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop

    q = Queue()

    @coroutine
    def consumer():
        for i in range(3):
            val = yield q.get()
            print("consumed %s" % val)
            q.task_done()

    @coroutine
    def producer():
        for i in range(3):
            print("produced %s" % i)
            yield q.put(i)


    @coroutine
    def main():
        IOLoop.current().spawn_callback(consumer)
        yield producer()


    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:09:54.417495
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    def run_test():
        import random
        import tornado
        import tornado.testing
        from tornado.queues import Queue

        class Getter(object):
            def __init__(self, q: Queue[int]) -> None:
                self.q = q

            @tornado.gen.coroutine
            def get(self) -> int:
                return (yield self.q.get())

        class Tester(object):
            def __init__(self, test: tornado.testing.AsyncTestCase) -> None:
                self.test = test

            @tornado.gen.coroutine
            def test_get_nowait(self) -> None:
                q = Queue(maxsize=5)
                getter = Getter(q)

# Generated at 2022-06-24 09:09:58.113248
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert q.__repr__() == "<Queue at 0x7f629de0ec88 maxsize=2>"


# Generated at 2022-06-24 09:10:01.325168
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True
    q.put_nowait(5)
    assert q.empty() == False


# Generated at 2022-06-24 09:10:10.949480
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # test_Queue_get_nowait() is a test case that tests the get_nowait() method of class Queue
    # get_nowait() is a method that removes and returns an item from the queue without blocking.
    # Return an item if one is immediately available, else raise QueueEmpty.
    queue = Queue(3)
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    print('Queue: qsize = ', queue.qsize())
    print('Queue: get_nownait returns: ', queue.get_nowait())
    print('Queue: get_nownait returns: ', queue.get_nowait())

# Generated at 2022-06-24 09:10:18.587191
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    @gen.coroutine
    def main():
        q = Queue(maxsize=1)
        q.put_nowait('a')
        q.put_nowait('b')

        result = []
        async for item in q:
            result.append(item)

        # There was only room for one item, but we got two.
        assert result == ['a', 'b']

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:10:26.213447
# Unit test for method full of class Queue
def test_Queue_full():
    assert Queue().full() == False
    assert Queue(maxsize=0).full() == False
    assert Queue(maxsize=1).full() == False
    assert Queue(maxsize=1).put_nowait(1) == None
    assert Queue(maxsize=1).full() == True
    assert Queue(maxsize=1).get_nowait() == 1
    assert Queue(maxsize=1).full() == False
    return "Unit test for method full of class Queue passed!"

# Generated at 2022-06-24 09:10:31.931547
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue() # type: Queue
    q._unfinished_tasks = 10
    q.task_done()
    assert q._unfinished_tasks == 9
    try:
        q.task_done()
        q.task_done()
    except ValueError as e:
        assert e
    else:
        assert False, "Call task_done too many times, which should raise ValueError"


# Generated at 2022-06-24 09:10:39.960524
# Unit test for method full of class Queue
def test_Queue_full():
    # Make a queue of size 2.
    q = Queue(maxsize=2)

    # Put two items in the queue.
    q.put_nowait(1)
    q.put_nowait(2)

    # The queue is full.
    assert q.full() == True

    # The queue has 2 items.
    assert q.qsize() == 2

    # Now pop an item out.
    q.get_nowait()

    # The queue is not full anymore.
    assert q.full() == False

    # The queue still has one item.
    assert q.qsize() == 1

    # Put another item in the queue.
    q.put_nowait(3)

    # The queue is full again.
    asser

# Generated at 2022-06-24 09:10:51.694053
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado.gen

    # case 1
    @tornado.gen.coroutine
    def producer():
        yield queue.put(1)

    @tornado.gen.coroutine
    def consumer():
        item = yield queue.get()
        assert item == 1
        queue.task_done()

    queue = Queue()
    tornado.ioloop.IOLoop.current().spawn_callback(producer)
    tornado.ioloop.IOLoop.current().spawn_callback(consumer)
    queue.join()
    # case 2

    @tornado.gen.coroutine
    def producer1():
        yield queue1.put(1)

    queue1 = Queue()
    tornado.ioloop.IOLoop.current().spawn_callback(producer1)
    queue1.join()



# Generated at 2022-06-24 09:10:58.159101
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=3)
    # maxsize can't be None
    try:
        Queue(maxsize=None)
    except TypeError as e:
        assert str(e) == "maxsize can't be None"
    # maxsize can't be negative
    try:
        Queue(maxsize=-1)
    except ValueError as e:
        assert str(e) == "maxsize can't be negative"

    assert q.maxsize == 3
    # test qsize
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()
    # test get_nowait
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert str(e) == "QueueEmpty"


# Generated at 2022-06-24 09:11:10.318948
# Unit test for constructor of class Queue
def test_Queue():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from Queue import Queue, QueueEmpty, QueueFull

    q = Queue(maxsize=3)
    @gen.coroutine
    def consumer():
        print("start consumer")
        try:
            item = yield q.get(timeout=0.01)
            print("Doing work on %s" % item)
            item = yield q.get(timeout=0.01)
            print("Doing work on %s" % item)
            item = yield q.get(timeout=0.01)
            print("Doing work on %s" % item)
        except gen.TimeoutError:
            print("timeout")
            pass
        finally:
            q.task_done()

    @gen.coroutine
    def consumer2():
        print

# Generated at 2022-06-24 09:11:16.756808
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1
    q = Queue(maxsize=2)
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        assert True
    assert q.qsize() == 2

# Generated at 2022-06-24 09:11:21.985492
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:11:31.710809
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import threading
    import asyncio
    from typing import List
    # Test the join method to wait until all items have been processed.
    q = Queue()
    [q.put_nowait(i) for i in range(5)]
    thread_run_ids: List[threading.Thread] = []

    @asyncio.coroutine
    def _get(q):
        for _ in range(5):
            yield from q.get()
            q.task_done()

    def _set(q):
        asyncio.get_event_loop().run_until_complete(_get(q))

    thread_run_ids.append(threading.Thread(target=_set, args=(q,)))
    thread_run_ids[0].start()
    asyncio.get_event_loop().run_

# Generated at 2022-06-24 09:11:36.595267
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.maxsize == 2
    assert not q.empty()
    assert not q.full()

    q.put_nowait(0)
    assert q.qsize() == 1
    assert not q.empty()
    assert not q.full()

    q.put_nowait(1)
    assert q.qsize() == 2
    assert not q.empty()
    assert q.full()


# Generated at 2022-06-24 09:11:48.223946
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    import asyncio as _asyncio
    ioloop = _asyncio.get_event_loop()
    assert len(q._queue) == 0
    def consumer():
        return len(q._queue)
    def producer(a):
        q.put(a)
        return len(q._queue)
    def task_done(a):
        q.task_done()
        return len(q._queue)
    ans = lambda x, y: len(q._queue) == y and q._unfinished_tasks == x
    assert ioloop.run_until_complete(consumer()) == q.qsize()
    assert ioloop.run_until_complete(producer(1)) == q.qsize()
    assert ans(1,1)
    assert ioloop.run_until

# Generated at 2022-06-24 09:11:49.637819
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    return q.full()



# Generated at 2022-06-24 09:11:52.193133
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import types
    assert isinstance(Queue.__repr__, types.FunctionType)
# Test for method __repr__ of class Queue



# Generated at 2022-06-24 09:11:53.893081
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    print(q.qsize())
    
    

# Generated at 2022-06-24 09:12:05.727124
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    def _mock_anext_Coroutine():
        return None

    queue = Queue(2)
    queue._get = MagicMock(return_value=None)
    queue.get = MagicMock(return_value=_mock_anext_Coroutine())
    queue.get.return_value.__anext__ = MagicMock(side_effect=_mock_anext_Coroutine())
    queue.__aiter__ = MagicMock(return_value=_mock_QueueIterator())
    queue.__aiter__.return_value.__aiter__ = MagicMock(return_value=_mock_anext_Coroutine())

# Generated at 2022-06-24 09:12:16.766911
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
    except QueueFull:
        assert False, "The queue is not full"

    assert len(q._queue) > 0
    try:
        q.put_nowait(3)
    except QueueFull:
        assert False, "The queue is not full"

    try:
        q.put_nowait(4)
    except QueueFull:
        assert True
    else:
        assert False, "The queue is full"

    q = Queue(maxsize=0)

    try:
        q.put_nowait(1)
    except QueueFull:
        assert False, "The queue is not full"

    assert len(q._queue) > 0



# Generated at 2022-06-24 09:12:19.995445
# Unit test for method put of class Queue
def test_Queue_put():
    for i in range(100):
        q = Queue()
        p = q.put(1)
        assert(q.qsize() == 1)


# Generated at 2022-06-24 09:12:22.126334
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:12:25.752331
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    q.put(1)
    assert(q.full() == True)
    q.get()
    assert(q.full() == False)
# Test for method empty of class Queue

# Generated at 2022-06-24 09:12:28.057264
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int]()
    q.put_nowait(5)
    qiter = _QueueIterator(q)
    return qiter


# Generated at 2022-06-24 09:12:36.792377
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q._maxsize == 2
    assert q._init() == None
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()
    try:
        q = Queue(maxsize=None)
    except TypeError:
        assert True
    else:
        assert False
    try:
        q = Queue(maxsize=-1)
    except ValueError:
        assert True
    else:
        assert False
    try:
        q = Queue(maxsize='1')
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 09:12:42.471909
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q._unfinished_tasks = 2
    q.task_done()
    q.task_done()
    q.task_done()
    assert q._unfinished_tasks == 0



# Generated at 2022-06-24 09:12:43.075991
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    pass


# Generated at 2022-06-24 09:12:51.282454
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_queue = Queue()
    assert test_queue.empty()
    assert test_queue.qsize() == 0
    test_queue.put_nowait(0)
    test_queue.put_nowait(1)
    test_queue.put_nowait(2)
    test_queue.put_nowait(3)
    test_queue.put_nowait(4)
    test_queue.put_nowait(5)
    test_queue.put_nowait(6)
    test_queue.put_nowait(7)
    test_queue.put_nowait(8)
    test_queue.put_nowait(9)
    assert test_queue.get_nowait() == 0
    assert test_queue.get_nowait() == 1
    assert test_queue.get_nowait()

# Generated at 2022-06-24 09:12:55.499596
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2



# Generated at 2022-06-24 09:12:58.951273
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    print(q.put(1))


# Generated at 2022-06-24 09:13:09.340265
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at 0x{} maxsize=2 queue=deque([])>".format(id(q))
    q._queue = [1]
    assert repr(q) == "<Queue at 0x{} maxsize=2 queue=deque([1])>".format(id(q))
    q._getters = [2]
    assert repr(q) == "<Queue at 0x{} maxsize=2 queue=deque([1]) getters[1]>".format(id(q))
    q._putters = [3]
    assert repr(q) == "<Queue at 0x{} maxsize=2 queue=deque([1]) getters[1] putters[1]>".format(id(q))
    q._unfinished_tasks

# Generated at 2022-06-24 09:13:12.371334
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert 1 == q.get_nowait()
    assert 2 == q.get_nowait()
    assert 3 == q.get_nowait()

# Generated at 2022-06-24 09:13:18.642745
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue
    q = LifoQueue()
    assert q.qsize() == 0
    assert q.maxsize == 0
    assert not q.full()
    assert q.empty()
    assert q._queue == []
    assert q._getters == []
    assert q._putters == []
    assert type(q._unfinished_tasks) is int
    assert q._finished.is_set()
    assert q.__class__ == LifoQueue
    assert q.__class__.__class__ == type


# Generated at 2022-06-24 09:13:21.696023
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull(1,2)
    q.args = 1,2


# Generated at 2022-06-24 09:13:29.352401
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop, PeriodicCallback
    from tornado.queues import Queue, QueueEmpty
    import tornado.gen

    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)

    @tornado.gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print(item)
            finally:
                q.task_done()

    IOLoop.current().start()
    PeriodicCallback(consumer, 1000).start()

# Generated at 2022-06-24 09:13:31.790471
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    from tornado.queues import Queue
    q = Queue(maxsize=0)
    with pytest.raises(ValueError):
        q.task_done()

test_Queue_task_done()



# Generated at 2022-06-24 09:13:35.926211
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=3)
    q.put_nowait("1")
    q.put_nowait("2")
    q.put_nowait("3")
    assert q.full() == True


# Generated at 2022-06-24 09:13:39.215754
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue
    q = Queue()
    it = q.__aiter__()
    assert isinstance(it, _QueueIterator)
    assert it.q is q
test_Queue___aiter__()


# Generated at 2022-06-24 09:13:42.862868
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    async def foo():
        q = Queue()
        q.put(1)
        it = _QueueIterator(q)
        assert await it.__anext__() == 1
        await q.join()
    ioloop.IOLoop.current().run_sync(foo)
test__QueueIterator___anext__()



# Generated at 2022-06-24 09:13:44.842858
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()
    print(qf)


_QUEUE_TIMEOUT = object()



# Generated at 2022-06-24 09:13:55.256456
# Unit test for constructor of class QueueFull
def test_QueueFull():
    print('QueueFull')
    try:
        raise QueueFull()
    except Exception as e:
        e_class = type(e)
        print('e_class:', e_class)
        print('issubclass(e_class, QueueFull):', issubclass(e_class, QueueFull))
        print('issubclass(e_class, QueueEmpty):', issubclass(e_class, QueueEmpty))
        print('e.__class__ is QueueFull:', e.__class__ is QueueFull)
        print('e.__class__ is QueueEmpty:', e.__class__ is QueueEmpty)
        print('Exception name:', e.__class__.__name__)


# Generated at 2022-06-24 09:14:07.351202
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    start_time,time_unit=time.time(),'s'

    @gen.coroutine
    def main():
        q=Queue()
        async def p1():
            for i in range(10):
                print("Put %s"%i)
                yield q.put(i)
        async def p2():
            for i in range(11,15):
                print("Put %s"%i)
                yield q.put(i)
        async def c1():
            yield q.join()
            print('Done')
        yield [p1(),p2(),c1()]
    ioloop.IOLoop.current().run_sync(main)
    end_time=time.time()

# Generated at 2022-06-24 09:14:09.287018
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2


# Generated at 2022-06-24 09:14:12.326109
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert(q.qsize() == 3)
    assert(q.get_nowait() == 1)
    assert(q.qsize() == 2)
    assert(q.get_nowait() == 2)
    assert(q.qsize() == 1)
    assert(q.get_nowait() == 3)
    assert(q.qsize() == 0)

# Put more unit tests here

test_LifoQueue()

# Generated at 2022-06-24 09:14:17.350264
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    state = {"async_for": False}

    async def coroutine(state = None):
        async for i in Queue[int]():
            state["async_for"] = True

    ioloop.IOLoop.current().run_sync(lambda: coroutine(state))
    assert state["async_for"]



# Generated at 2022-06-24 09:14:21.394687
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:14:24.857361
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # Create an instance of LifoQueue class
    q = LifoQueue()

    # Add items to queue
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2

# Generated at 2022-06-24 09:14:32.085913
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an IOLoop
    loop = ioloop.IOLoop.current()
    # Create a queue
    q = Queue()
    # Add callback method to IOLoop
    # Inside callback method, we get an item from queue and do some job on it
    # Then we sleep for 0.01 seconds and print an item to the screen
    loop.add_callback(lambda: q.get().add_done_callback(lambda x: print(x.result())))
    loop.add_callback(lambda: time.sleep(0.01))
    loop.start()


# Generated at 2022-06-24 09:14:33.765482
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(1)
    assert q.empty()



# Generated at 2022-06-24 09:14:36.925335
# Unit test for constructor of class QueueFull
def test_QueueFull():
  # This function tests the constructor of QueueFull
  # It should return an object of class QueueFull
  err = QueueFull()
  assert isinstance(err, QueueFull)



# Generated at 2022-06-24 09:14:41.444987
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    total = 0
    while q.unfinished_tasks:
        q.put(total)
        total += 1
    assert q.task_done() == 0
    q.join()
    assert total == 0



# Generated at 2022-06-24 09:14:43.564840
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type:()->None
    q = Queue(0)
    qi = _QueueIterator(q)
    return qi


# Generated at 2022-06-24 09:14:45.512262
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    
    assert False

# Generated at 2022-06-24 09:14:53.123518
# Unit test for method full of class Queue
def test_Queue_full():
    import tornado.testing
    import tornado.platform.asyncio

    @tornado.testing.gen_test
    async def test_queue():
        queue = Queue(maxsize=1)
        assert queue.full() == False
        await queue.put(1)
        assert queue.full() == True
        queue.get_nowait()
        assert queue.full() == False

    # This is required for mypy to work with asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    test_queue()



# Generated at 2022-06-24 09:14:54.785035
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        assert True


# Generated at 2022-06-24 09:15:02.449227
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    class EmptyQueue(Queue[None]):
        def _init(self, maxsize: int = 0) -> None:
            pass
        def _put(self, item: None) -> None:
            raise NotImplementedError()
        def _get(self) -> None:
            raise NotImplementedError()
        def _qsize(self) -> int:
            return 0
    q = EmptyQueue()
    iterator = _QueueIterator(q)
    assert iterator.q is q
    

# Generated at 2022-06-24 09:15:03.452113
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    obj = _QueueIterator(Queue())


# Generated at 2022-06-24 09:15:04.862708
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception:
        pass



# Generated at 2022-06-24 09:15:06.798639
# Unit test for constructor of class Queue
def test_Queue():
  queue = Queue(30)
  assert queue.empty()
  assert queue.qsize() == 0
  assert queue.full() == False
  assert queue.maxsize == 30


# Generated at 2022-06-24 09:15:14.450756
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.qsize()
    q.put(1)
    q.put_nowait(2)
    q.qsize()
    try:
        q.put_nowait(3)
    except QueueFull:
        print('QueueFull')
    q.maxsize
    q.empty()
    q.full()
    q.task_done()
    q.join()
    q.get()
    q.get_nowait()
    q.task_done()
    q.join()
    q.join(timeout=5)
    q.task_done()
    print(q)


# Generated at 2022-06-24 09:15:15.929376
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception:
        pass



# Generated at 2022-06-24 09:15:18.386593
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue() # type: Queue[_T]
    try:
        q.get_nowait()
    except:
        print('Caught exception')


# Generated at 2022-06-24 09:15:21.035942
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(0)
    assert q.get_nowait() == 0


# Generated at 2022-06-24 09:15:26.246847
# Unit test for method full of class Queue
def test_Queue_full():
    """
    This unit test tests the function Queue.full
    """
    q = Queue(maxsize=2)
    assert q.qsize() == 0, "qsize is not 0"
    assert q.empty() is True, "empty is not True"
    assert q.full() is False, "full is not False"
test_Queue_full()

# Generated at 2022-06-24 09:15:29.810057
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    q.get()
    q.get()
    q.get_nowait()
    q.task_done()

# Generated at 2022-06-24 09:15:34.590610
# Unit test for constructor of class QueueFull
def test_QueueFull():
    with future_set_result_unless_cancelled() as future:
        try:
            raise QueueFull("Queue is full")
        except QueueFull:
            exc_info = sys.exc_info()
    future.result()


# Generated at 2022-06-24 09:15:37.935468
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    if qe.__class__ != QueueEmpty:
        raise AssertionError("__class__ not working")


# Generated at 2022-06-24 09:15:49.227687
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:15:56.773743
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    print("Start test_Queue_qsize")
    # Prepare test objects
    q = Queue(maxsize=2)
    q.empty()

    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:16:00.144890
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def queue_put(q, item):
        await q.put(item)
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(lambda: queue_put(q, 1))
    io_loop.run_sync(lambda: queue_put(q, 2))
    io_loop.run_sync(lambda: queue_put(q, 3))



# Generated at 2022-06-24 09:16:03.628630
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    with pytest.raises(QueueFull):
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)

# Generated at 2022-06-24 09:16:07.172639
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert q.full() == False
    q = Queue(maxsize=1)
    assert q.full() == False
    q.put_nowait(1)
    assert q.full() == True

test_Queue_full()

# Generated at 2022-06-24 09:16:19.239670
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:20.226827
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    this_queue = Queue() 
    this_queue.__put_internal


# Generated at 2022-06-24 09:16:22.035548
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("test")
    except QueueFull:
        pass
    return True



# Generated at 2022-06-24 09:16:25.197806
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:16:27.556325
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()
    q.put(1)
    assert not q.empty()
    q.get()
    assert q.empty()


# Generated at 2022-06-24 09:16:29.356090
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0

    q.put(1)
    assert q.qsize() == 1

# Generated at 2022-06-24 09:16:31.438497
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        print('QueueFull constructor test = pass')


# Generated at 2022-06-24 09:16:36.592835
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:16:37.578726
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass


# Generated at 2022-06-24 09:16:39.737620
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    iterator = _QueueIterator(Queue(1))
    result = iterator.__anext__()
    assert type(result) == Awaitable


# Generated at 2022-06-24 09:16:41.081615
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
	queue = Queue()
	print(repr(queue))
	

# Generated at 2022-06-24 09:16:48.925202
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # AssertionError: <tornado.queues.Queue object at 0x7f30f0a58c18 maxsize=0 queue=deque([]) tasks=2> != <tornado.queues.Queue object at 0x7f30f0a58c18 maxsize=0 queue=deque([1]) tasks=1>
    q: Queue[int] = Queue()

    # AssertionError: <tornado.queues.Queue object at 0x7f30f0a58c18 maxsize=0 queue=deque([1]) tasks=1> != <tornado.queues.Queue object at 0x7f30f0a58c18 maxsize=0 queue=deque([1, 2]) tasks=2>
    q.put_nowait(1)
    # AssertionError: <tornado.que

# Generated at 2022-06-24 09:16:53.557550
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert (not q.empty()) == 0
t1 = test_Queue_empty()
print(t1)

print("---------end of test method empty()--------")

print("---------start of test method put_nowait()--------")

# Generated at 2022-06-24 09:17:03.669586
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize = 2)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)
    q.put(2)

# Generated at 2022-06-24 09:17:14.529489
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:17.043814
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """
        Simple unit test for the core logic of the QueueFull class
    """
    try:
        raise QueueFull('test')
    except QueueFull as e:
        assert str(e) == 'test'


# Generated at 2022-06-24 09:17:20.193152
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    actual = q.__repr__()
    print("actual:%s"%actual)
    assert 1 == 1


# Generated at 2022-06-24 09:17:31.314707
# Unit test for method put of class Queue
def test_Queue_put():
    print("=====begin to test Queue put method======")
    import inspect
    import types
    from queue import Queue, Full
    q = Queue()
    a = q.put
    #print(isinstance(a, types.MethodType))
    if isinstance(a, types.MethodType):
        print('yes')
    x1 = 0
    def b(item, timeout=None):
        global x1
        if x1 == 0:
            q.put_nowait(item)
        elif x1 == 1:
            q.put_nowait(item)
        elif x1 == 2:
            raise Full()
        x1 = x1 + 1
    # print(inspect.getargspec(b))
    # print(inspect.getargspec(a))
    b = types.MethodType

# Generated at 2022-06-24 09:17:43.666220
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado.queues import Queue
    from tornado import gen
    from tornado.ioloop import IOLoop
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:56.335262
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:01.619154
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    q.put_nowait("a")
    assert it.__anext__().result() == "a"
    q.put_nowait("b")
    assert it.__anext__().result() == "b"



# Generated at 2022-06-24 09:18:04.429474
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull

    except Exception as e:
        assert e.__class__.__name__ == "QueueFull"


# Generated at 2022-06-24 09:18:07.887201
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # 1. Preconditions
    q = Queue(maxsize=2)
    # 2. Flow
    try:
        q.get_nowait()
    # 3. Assertions
    except Exception as exc:
        return
    raise Exception("get_nowait should raise exception")

# Generated at 2022-06-24 09:18:20.347865
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q: # type: ignore
            try:
                print("Doing work on {}".format(item))
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put {}".format(item))
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print

# Generated at 2022-06-24 09:18:22.864152
# Unit test for method get of class Queue
def test_Queue_get():
  q = Queue(maxsize=2)
  future = q.get(None)
  assert future!=None


# Generated at 2022-06-24 09:18:27.081545
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    print('unit test')
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    print('unit test passed')

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:18:37.678796
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.queues import QueueEmpty
    from tornado.ioloop import IOLoop
    io = IOLoop.current()
    que = Queue(maxsize=2)
    que.maxsize
    que.put_nowait(1)
    que.put_nowait(1)
    with self.assertRaises(QueueFull):
        que.put_nowait(1)
    self.assertEqual(que.qsize(), 2)
    self.assertEqual(que.empty(), False)
    self.assertEqual(que.full(), True)
    que.get_nowait()
    que.get_nowait()
    with self.assertRaises(QueueEmpty):
        que.get_nowait()

# Generated at 2022-06-24 09:18:40.163094
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("Queue is full")
    except QueueFull:
        pass


# Generated at 2022-06-24 09:18:52.120324
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import random
    import sys
    import unittest

    if sys.version_info >= (3, 7):
        from unittest.mock import patch
    else:
        from mock import patch

    class QueueTestCase(unittest.TestCase):
        def test___str__(self):
            q = Queue(maxsize=1)
            self.assertEqual(str(q), "<Queue maxsize=1 queue=deque([])>")
            q = Queue(maxsize=0)
            futures = [Future() for i in range(10)]
            q.put_nowait(1)
            q._getters.extend(futures)

# Generated at 2022-06-24 09:18:57.442197
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("Test QueueFull")
    except QueueFull as e:
        a = e

        assert isinstance(a, QueueFull)
        assert str(a) == "Test QueueFull"
        assert a.args == ("Test QueueFull",)



# Generated at 2022-06-24 09:19:07.135608
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    import random
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import queue
    import unittest

    class MyQueue(Queue):
        def __init__(self,  maxsize):
            Queue.__init__(self, maxsize)
            self._queue = [random.uniform(0, 1) for i in range(0, maxsize)]

        def _get(self):
            return self._queue.pop(0)


    class MyIterQueue(queue.Queue):
        def __init__(self,  maxsize):
            queue.Queue.__init__(self, maxsize)
            self._queue = [random.uniform(0, 1) for i in range(0, maxsize)]

        def get_nowait(self):
            return self._

# Generated at 2022-06-24 09:19:16.824960
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest
    import asyncio
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(20):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        asyncio.get_event_loop().create_task(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    loop

# Generated at 2022-06-24 09:19:28.930032
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    from tornado import gen
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import gen_test
    from tornado.test.testutils import AsyncTestCase
    from queue_test import Queue

    @gen.coroutine
    def get_next(queue: Queue) -> None:
        queue_iterator = _QueueIterator(queue)
        try:
            while(True):
                element = yield queue_iterator.__anext__()
                print(element)
        except gen.Return as e:
            raise e

    class Test_QueueIterator_async(AsyncTestCase):
        def setUp(self):
            super(Test_QueueIterator_async,self).setUp()
            self.queue = Queue(1)
    