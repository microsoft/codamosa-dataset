

# Generated at 2022-06-24 09:09:29.375277
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass

# Generated at 2022-06-24 09:09:38.680546
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    from tornado.queues import Queue
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    q = Queue()

    @asyncio.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield from asyncio.sleep(0.01)
            finally:
                q.task_done()

    @asyncio.coroutine
    def producer():
        for item in range(5):
            yield from q.put(item)
            print('Put %s' % item)

    @asyncio.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        asyncio.ensure_future(consumer())
       

# Generated at 2022-06-24 09:09:41.614896
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    #(priority number, unit test)
    q.put((1, 'test1'))
    assert q.qsize() == 1
    assert q.get_nowait() == (1, 'test1')

test_PriorityQueue()



# Generated at 2022-06-24 09:09:45.303020
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    qe = QueueEmpty()
    assert "QueueEmpty" in str(qe)



# Generated at 2022-06-24 09:09:47.251198
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 09:09:53.762202
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    a = []
    async def f():
        async for i in q:
            await gen.sleep(0)
            a.append(i)
    ioloop.IOLoop.current().run_sync(f)
    assert a == [1, 2, 3]
    a.clear()
    # test timeout
    q = Queue()
    ioloop.IOLoop.current().run_sync(q.get, timeout=10**-6)



# Generated at 2022-06-24 09:09:58.731531
# Unit test for method full of class Queue
def test_Queue_full():
	q = Queue(maxsize=10)
	assert q.full() == False
	for i in range(10):
		q.put_nowait(i)
	assert q.full() == True
	q.qsize() == q.maxsize


# Generated at 2022-06-24 09:10:01.539916
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        print(e.__class__.__name__)


# Generated at 2022-06-24 09:10:03.773438
# Unit test for method full of class Queue
def test_Queue_full():
    Queue(maxsize=5).full()

# Generated at 2022-06-24 09:10:08.848493
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:10:16.375318
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import unittest
    import asyncio
    from tornado.testing import gen_test
    from tornado.platform.asyncio import BaseAsyncIOLoop, AsyncIOMainLoop
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from queue import Queue
    class Test_QueueIterator___anext__(unittest.TestCase):
        @classmethod
        def tearDownClass(cls):
            AsyncIOMainLoop().close(all_fds=True)
        @gen_test
        async def test_basic_functionality(self):
            q = Queue()
            q.put_nowait(1)
            q.put_nowait(2)
            q.put_nowait(3)
            q_iter = _QueueIterator(q)
            self.assertE

# Generated at 2022-06-24 09:10:17.103265
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-24 09:10:19.301565
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=6)
    assert q.qsize() == 0


# Generated at 2022-06-24 09:10:25.554489
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    queue = Queue()

    @gen.coroutine
    def coro():
        async for i in queue:
            pass

    IOLoop.current().spawn_callback(coro)

    IOLoop.current().stop()
    IOLoop.current().start()



# Generated at 2022-06-24 09:10:30.877460
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.qsize()
    q.empty()
    q.full()
    q.put(1)
    q.put_nowait(1)
    q.get()
    q.get_nowait()
    q.task_done()
    q.join()
    q.__str__()
    q.__repr__()



# Generated at 2022-06-24 09:10:38.016782
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    sql="select * from student where age>18"
    db_conn1=Queue()
    db_conn2=Queue()
    db_conn3=Queue()
    db_conn1.put_nowait(sql)
    db_conn2.put_nowait(sql)
    db_conn3.put_nowait(sql)
    print(db_conn1.get_nowait())
    print(db_conn2.get_nowait())
    print(db_conn3.get_nowait())

test_Queue_put_nowait()




# Generated at 2022-06-24 09:10:41.919935
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    q = Queue()
    q.put(1)
    q.put(2)
    i = 0
    while not q.empty():
        i += q.get_nowait()
    assert i == 3
    i = 0
    while not q.empty():
        q.get_nowait()
    while not q.empty():
        q.task_done()
        i += 1
    return i == 3



# Generated at 2022-06-24 09:10:47.598917
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    for i in range(2):
        q.put_nowait(i)
    assert q.qsize() == 1

    q = Queue(maxsize=1)
    q.put_nowait(0)
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-24 09:10:49.584418
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    try:
        raise QueueFull
    except QueueFull:
        pass



# Generated at 2022-06-24 09:10:54.356538
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    future = Future()
    future.set_result(10)
    q._unfinished_tasks = 10
    q._finished = Event()
    q.task_done()
    assert q._unfinished_tasks == 9

    # what if the queue is already empty?
    q.task_done()



# Generated at 2022-06-24 09:10:55.467490
# Unit test for constructor of class QueueFull
def test_QueueFull():
    a = QueueFull()
    assert a


# Generated at 2022-06-24 09:11:05.706224
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()

    q.put_nowait(1)
    assert q.get_nowait() == 1

    q.put_nowait(2)
    assert q.get_nowait() == 2

    q.put_nowait(3)
    assert q.get_nowait() == 3

    q.put_nowait(4)
    assert q.get_nowait() == 4

    q.put_nowait(5)
    assert q.get_nowait() == 5

    q.put_nowait(6)
    assert q.get_nowait() == 6

    assert q.empty()



# Generated at 2022-06-24 09:11:08.131686
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    import typing
    q = Queue()
    i: _QueueIterator[typing.Any] = _QueueIterator(q)



# Generated at 2022-06-24 09:11:08.892136
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(None)
    q = Queue(-1)

# Generated at 2022-06-24 09:11:11.523414
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        assert e.__class__ == QueueFull


# Generated at 2022-06-24 09:11:13.082664
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    check_Queue_task_done(q)



# Generated at 2022-06-24 09:11:14.976860
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    queue = LifoQueue()
    print(queue)
    print(queue.maxsize)
    print(queue.empty())
    print(queue.full())
    print(queue.qsize())



if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:11:19.374075
# Unit test for method join of class Queue
def test_Queue_join():
    def mock_wait(self):
        return self.return_value
    mock_wait.return_value = 1
    with patch('__main__.Queue._finished.wait', mock_wait):
        queue = Queue()
        assert queue.join() == 1

# Generated at 2022-06-24 09:11:21.747071
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty('test')
    print(type(qe))



# Generated at 2022-06-24 09:11:29.916487
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.empty()
    assert not q.full()
    assert q.qsize() == 0

    q.put_nowait(1)
    assert not q.empty()
    assert not q.full()
    assert q.qsize() == 1

    q.put_nowait(2)
    assert not q.empty()
    assert q.full()
    assert q.qsize() == 2

    try:
        q.put_nowait(3)
        assert True
    except QueueFull:
        assert False



# Generated at 2022-06-24 09:11:32.412025
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:11:35.176796
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.get_nowait()
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)



# Generated at 2022-06-24 09:11:37.361314
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("Exception raised: Queue is full")
    except QueueFull as e:
        print("QueueFull Exception occured: ", e)



# Generated at 2022-06-24 09:11:41.845098
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:11:44.888207
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put("")

# Generated at 2022-06-24 09:11:50.895837
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-24 09:11:54.063740
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=3)
    print(q.maxsize)
    print(q.qsize())
    print(q.empty())
    print(q.full())



# Generated at 2022-06-24 09:11:55.694167
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:12:01.575247
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.platform.asyncio import to_tornado_future
    maxsize = 5
    q = Queue(maxsize)
    assert '<Queue maxsize=%r queue=deque([])>' % maxsize == q.__str__()
    q.__put_internal(4)
    q.__put_internal(1)
    q.__put_internal(2)
    q._unfinished_tasks = 1
    assert '<Queue maxsize=%r queue=deque([1, 2, 4]) tasks=%d>' % (maxsize, q._unfinished_tasks) == q.__str__()
    q._finished = 1
    assert '<Queue maxsize=%r queue=deque([1, 2, 4]) tasks=0>' % (maxsize, ) == q.__str__

# Generated at 2022-06-24 09:12:05.058101
# Unit test for method put of class Queue
def test_Queue_put():
    input = 2
    queue = Queue()
    future = queue.put(input)
    assert future.result() == None
    assert queue.qsize() == 1
    assert queue.get() == input
    assert queue.qsize() == 0


# Generated at 2022-06-24 09:12:11.909049
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:12:15.543372
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    '''
    >>> q = Queue(1)
    >>> q.put_nowait(1)
    >>> i = _QueueIterator(q)
    >>> i.__anext__().result()
    1
    '''
    pass



# Generated at 2022-06-24 09:12:18.781212
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True



# Generated at 2022-06-24 09:12:25.860125
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Test Queue.get
    """

    # set maxsize to 3
    q = Queue(maxsize=3)

    # set timeout to 1
    timeout = 1

    # put 1, 2, 3, 4 into queue with timeout
    q.put(1, timeout)
    q.put(2, timeout)
    q.put(3, timeout)
    q.put(4, timeout)

    # get the first element
    assert q.get(timeout) == 1

    # get the second element
    assert q.get(timeout) == 2

    # get the third element
    assert q.get(timeout) == 3

    # get the fourth element
    assert q.get(timeout) == 4

    # get the fifth element
    assert q.get(timeout) == 5



# Generated at 2022-06-24 09:12:26.888600
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    error = QueueEmpty()


# Generated at 2022-06-24 09:12:29.580407
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    raise QueueEmpty('runoob') 
try:
    test_QueueEmpty()
except QueueEmpty as e:
    print('QeueuEmpty 出错：', e)



# Generated at 2022-06-24 09:12:35.404339
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    queue.put_nowait(4)
    queue.put_nowait(5)
    queue.put_nowait(6)
    anext = _QueueIterator(queue).__anext__
    aiter = anext()
    IOLoop.current().run_sync(aiter)
    IOLoop.current().run_sync(aiter)
    IOLoop.current().run_sync(aiter)
    IOLoop.current().run_sync(aiter)
    IOLoop.current().run_sync(aiter)

# Generated at 2022-06-24 09:12:46.185441
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # first test
    q = Queue()
    i = 0
    q.task_done()
    i += 1
    assert i == 1
    q.task_done()
    i += 1
    assert i == 2
    assert q.qsize() == 0
    q.task_done()
    # second test
    q.__init__(5)
    q._unfinished_tasks = 0
    assert q.qsize() == 0
    q._finished.set()
    q.task_done()
    assert q._unfinished_tasks == 1
    # third test
    q.__init__(0)
    assert q._maxsize == 0
    assert q.task_done() == None



# Generated at 2022-06-24 09:12:50.548050
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:12:58.061523
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue()

    def run():
        print("run")
        async def consumer():
            async for item in q:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
                q.task_done()
        IOLoop.current().spawn_callback(consumer)
        IOLoop.current().start()

    def work():
        print("work")
        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)
        IOLoop.current().spawn_callback(producer)
        IOLoop.current().call_later(0, run)


# Generated at 2022-06-24 09:13:00.400290
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        str(e)
        repr(e)


# Generated at 2022-06-24 09:13:09.549860
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    async def main():
        q = Queue()

        async def worker(n):
            while True:
                item = await q.get()
                await asyncio.sleep(0.005)
                await q.task_done()

        for i in range(4):
            asyncio.get_event_loop().create_task(worker(i))

        for i in range(1000):
            await q.put(i)
        # start = time.time()
        await q.join()
        # elapsed = time.time() - start
        # assert elapsed < 0.5, elapsed

    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())


# Generated at 2022-06-24 09:13:11.976317
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-24 09:13:20.141819
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                #await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    IOL

# Generated at 2022-06-24 09:13:30.594354
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:13:40.951822
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import datetime
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish

# Generated at 2022-06-24 09:13:47.159778
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:13:48.980708
# Unit test for method get of class Queue
def test_Queue_get():
  # TODO: implement the test
  assert True 


# Generated at 2022-06-24 09:13:50.078057
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('Queue is full')
    except QueueFull as e:
        assert e == 'Queue is full'



# Generated at 2022-06-24 09:13:51.921628
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass



# Generated at 2022-06-24 09:13:57.343169
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import tornado.ioloop

    def func():
        pass

    x = Queue()
    x.put(func, timeout=0.5)
    # time.sleep(1)
    # x.task_done()
    tornado.ioloop.IOLoop.current().spawn_callback(x.join, timeout=2)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    test_Queue_join()

# Generated at 2022-06-24 09:13:58.834496
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert q.empty()
    q.put(1)
    assert not q.empty()
    assert q.full()

# Generated at 2022-06-24 09:14:05.270582
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:16.516417
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado.testing
    import tornado.gen

    class MyTestCase(tornado.testing.AsyncTestCase):
        def test_join(self):
            import time
            import datetime
            import tornado.queues
            ...
            q = tornado.queues.Queue(maxsize=2)
            self.assertFalse(q.full())
            q.put_nowait(1)
            q.put_nowait(2)
            self.assertTrue(q.full())
            self.assertFalse(q.empty())
            self.assertEqual(2, q.qsize())
            item = q.get()
            self.assertEqual(1, item)
            self.assertTrue(q.full())
            self.assertFalse(q.empty())
            self.assertEqual(2, q.qsize())



# Generated at 2022-06-24 09:14:19.000900
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    try:
        obj = Queue()
        result = str(obj)
    except Exception as err:
        print(err)
test_Queue___str__()



# Generated at 2022-06-24 09:14:20.730618
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    print(QueueEmpty())



# Generated at 2022-06-24 09:14:23.949377
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()




# Generated at 2022-06-24 09:14:32.788894
# Unit test for method join of class Queue
def test_Queue_join():
    # Builtin method
    # Called by:
    # tornado.test.test_queues.TestQueue.test_join
    # tornado.test.test_queues.TestQueue.test_join_exception
    print('test_Queue_join')
    # test_Queue_join > Called by:
    # tornado.test.test_queues.TestQueue.test_join
    q = Queue(maxsize=10)
    for i in range(9):
        q.put_nowait(object())
    f = Future()
    q._getters.append(f)
    timeout = gen_test.mock.Mock()
    q.join()
    timeout.return_value.cancel.assert_called_with()

# Generated at 2022-06-24 09:14:38.749460
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.empty() is True
    q.put_nowait(1)
    assert q.empty() is False
    q.put_nowait(2)
    assert q.empty() is False
    assert q.get_nowait() == 1
    assert q.full() is False
    assert q.empty() is False
    q.put_nowait(3)
    assert q.full() is True
    assert q.empty() is False
    assert q.get_nowait() == 2
    q.task_done()
    assert q.full() is False
    assert q.empty() is False
    assert q.get_nowait() == 3
    assert q.full() is False
    assert q.empty() is True


# Generated at 2022-06-24 09:14:44.936564
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert list(asyncio.as_completed(map(q.put, range(10)))) == [None]*10
    assert list(asyncio.as_completed(map(q.get, range(10)))) == [0,1,2,3,4,5,6,7,8,9]



# Generated at 2022-06-24 09:14:48.929781
# Unit test for method full of class Queue
def test_Queue_full():
    """Test the Queue.full method"""
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    q.put_nowait(1)
    assert q.full()


# Generated at 2022-06-24 09:14:50.540027
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        pass



# Generated at 2022-06-24 09:14:55.746756
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    def check_values(q, values):
        q.put_nowait(1)
        q.put_nowait(2)
        assert tuple(q) == values

    q = Queue()
    check_values(q, (1, 2))

    q = PriorityQueue()
    check_values(q, (1, 2))

    q = LifoQueue()
    check_values(q, (2, 1))



# Generated at 2022-06-24 09:15:07.001937
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:15:16.632306
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.ioloop import IOLoop
    q = Queue()

    async def consumer():
        try:
            async for item in q:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
        finally:
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:15:23.671115
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    print('test of Queue.__str__()')
    q = Queue()
    assert q._format() == 'maxsize=0 queue=deque([])'
    q = Queue(maxsize = 0)
    assert q.__str__() == '<Queue maxsize=0 queue=deque([])>'
    q._getters = ['getter 1','getter 2']
    assert q.__str__() == '<Queue maxsize=0 queue=deque([]) getters[2]>'



# Generated at 2022-06-24 09:15:26.793298
# Unit test for method get of class Queue
def test_Queue_get():

    def run_sync(f):
        return f()

    q = Queue()
    q.put(1)
    q.put(2)
    q.get()
    pass

# Generated at 2022-06-24 09:15:34.153709
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    print(q.qsize())
    q.put_nowait(0) # Put an item into the queue without blocking.
    print(q.qsize())
    q.put_nowait(1) # Put an item into the queue without blocking.
    print(q.qsize())
test_Queue_put_nowait()
# Output<maxsize=1, queue=[0], tasks=1>


# Generated at 2022-06-24 09:15:36.375001
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        assert True


# Generated at 2022-06-24 09:15:38.536253
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass



# Generated at 2022-06-24 09:15:41.916647
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: () -> None
    q = Queue()
    it = _QueueIterator(q)
    assert it.q == q



# Generated at 2022-06-24 09:15:45.368262
# Unit test for method empty of class Queue
def test_Queue_empty():
    """Tests the Queue's empty method"""
    q = Queue()
    assert q.empty() == True
    q.put(1)
    assert q.empty() == False

# Generated at 2022-06-24 09:15:47.710768
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
    except QueueFull as e:
        print(e)


# Generated at 2022-06-24 09:15:49.626562
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:15:51.647532
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 09:16:04.536475
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from . import ioloop
    from .queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:16.128968
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import gen
    def f():
        q = Queue()
        it = _QueueIterator(q)
        q.put_nowait(1)
        q.put_nowait(2)
        assert it.__anext__() == 1
        assert it.__anext__() == 2
        q.put_nowait(3)
        with pytest.raises(QueueEmpty):
            q.get_nowait()
        it = _QueueIterator(q)
        with pytest.raises(StopAsyncIteration):
            it.__anext__()
        q.put_nowait(4)
        assert gen.QueueIterator(q) == 4
        with pytest.raises(StopAsyncIteration):
            it.__anext__()
    gen.convert_yielded(f())



# Generated at 2022-06-24 09:16:21.954455
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q._put(1)
    it = _QueueIterator(q)
    assert gen.is_coroutine_function(it.__anext__)
    assert gen.is_coroutine_function(it.__aiter__)
    assert await it.__anext__() == 1


_T_co = TypeVar("_T_co", covariant=True)



# Generated at 2022-06-24 09:16:26.666979
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue with task_done() is called too many times
    tasks = Queue()
    # create a task by calling _QueueIterator
    task = _QueueIterator(tasks)
    # add task to queue
    tasks.put_nowait(task)
    # call task_done to update unfinished_tasks of queue
    tasks.task_done()
    # try to raise ValueError when calling task_done again
    tasks.task_done()

# Generated at 2022-06-24 09:16:31.714661
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    Queue.put_nowait = func_put_nowait(Queue.put_nowait)
    q = Queue(maxsize=2)
    q.put_nowait(0)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        assert False
    except QueueFull:
        return True
    return True

# Generated at 2022-06-24 09:16:33.990193
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 09:16:43.840585
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:51.199218
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    i = iter(q)
    assert isinstance(i, _QueueIterator)
    assert i.__anext__().result() == 1
    assert i.__anext__().result() == 2
    assert i.__anext__().result() == 3
    try:
        i.__anext__()
        assert False, "expected exception"
    except StopAsyncIteration:
        pass



# Generated at 2022-06-24 09:16:58.744106
# Unit test for method get of class Queue
def test_Queue_get():
    # test get is OK
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1 and q.get_nowait() == 2
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.get_nowait()
    q.put_nowait(3)
    assert q.get_nowait() == 3


# Generated at 2022-06-24 09:17:01.567571
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # TODO: Add unit test for all methods of class Queue
    def test(self):
        # TODO: Add test for method __repr__ of class Queue
        pass

# Generated at 2022-06-24 09:17:10.881658
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    _queue = collections.deque()  # type: collections.deque
    q = Queue()
    assert q.__repr__() == "<Queue at " + hex(id(q)) + " maxsize=0 queue=deque([])>"

    q = Queue(maxsize = 3)
    assert q.__repr__() == "<Queue at " + hex(id(q)) + " maxsize=3 queue=deque([])>"

    q._getters = collections.deque([Future()])
    assert q.__repr__() == "<Queue at " + hex(id(q)) + " maxsize=3 queue=deque([]) getters[1]>"

    q._putters = collections.deque([(1, Future())])

# Generated at 2022-06-24 09:17:16.792032
# Unit test for method full of class Queue
def test_Queue_full():
    queue = Queue(maxsize = 10)
    for i in range(10):
        queue.put_nowait(i)
    print(queue.full())
    print(queue.qsize())
    queue.put_nowait(11)
    print(queue.qsize())
    queue.get_nowait()
    print(queue.qsize())
    print(queue.full())
    return



# Generated at 2022-06-24 09:17:29.191938
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:29.689339
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    pass

# Generated at 2022-06-24 09:17:31.813698
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True

# Generated at 2022-06-24 09:17:39.515180
# Unit test for method get of class Queue
def test_Queue_get():
 
    q = Queue(maxsize=0)

    # force the queue to be empty
    while q.qsize() > 0:
        q.get_nowait()

    # the queue is empty, there is no item to get
    # so the next line should raise an exception
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False


# Generated at 2022-06-24 09:17:52.239670
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:54.603223
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        assert True, "QueueFull could be raised"



# Generated at 2022-06-24 09:17:56.641664
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.get_nowait() == 1

test_Queue_get_nowait()


# Generated at 2022-06-24 09:18:04.612226
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    maxsize=3
    q = Queue(maxsize=maxsize)
    item1 = 1
    item2 = 2
    item3 = 3
    item4 = 4
    q.put_nowait(item1)
    q.put_nowait(item2)
    q.put_nowait(item3)
    try:
        q.put_nowait(item4)
    except QueueFull:
        assert True
    else:
        assert False


# Generated at 2022-06-24 09:18:06.759149
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull('Queue Full Exception')
    assert(str(qf) == 'Queue Full Exception')


# Generated at 2022-06-24 09:18:10.901321
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    iterator = _QueueIterator(q)
    q.put(1)
    assert iterator.q.get_nowait() == 1
    q.put(2)
    assert (await iterator.__anext__()) == 2



# Generated at 2022-06-24 09:18:13.510978
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.qsize()
    q.empty()
    q.full()
    q.put_nowait(None)
    q.get_nowait()
    q.task_done()
    q.join()
    q.__put_internal(None)
    q.__aiter__()


# Generated at 2022-06-24 09:18:21.062949
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    
    import pytest

    q = Queue()
    q.put(1)
    assert not q.empty() == True
    q.get()
    assert q._unfinished_tasks == 1
    q.task_done()
    assert q._unfinished_tasks == 0
    
    
    

    
    
    
    
    with pytest.raises(ValueError):
        q.task_done()
        assert "task_done() called too many times"
    
    

# Generated at 2022-06-24 09:18:31.546863
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:36.797587
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    qit = _QueueIterator(q)
    assert(q.get() == 1)
    assert(qit.__anext__() == 2)
    assert(qit.q.get_nowait() == 3)



# Generated at 2022-06-24 09:18:43.651510
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:18:48.840376
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Test task_done before the last task is done
    q = Queue()
    for i in range(3):
        q.put(i)
    # Test case 1:
    q.task_done()
    for i in range(3):
        q.task_done()
    q._finished.wait()

# Generated at 2022-06-24 09:18:54.959190
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    assert q.empty()
    q.task_done()
    q.put_nowait(0)
    q.put_nowait(1)
    assert q.full()
    q.task_done()
    assert not q.empty()
    q.task_done()
    assert q.empty()
    q.task_done()


# Generated at 2022-06-24 09:18:58.209617
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize = 2)
    repr = q.__repr__()
    assert repr == "<Queue at 0x00000000 >", repr




# Generated at 2022-06-24 09:19:06.244354
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)     # maxsize is 2
    q.put_nowait(2)  # put 2 into the queue
    q.put_nowait(1)  # put 1 into the queue
    assert q.qsize() == 2  # current size of the queue should be 2
    q.get_nowait()   # get gets 1 from the queue
    assert q.qsize() == 1  # current size of the queue should be 1
    q.get_nowait()   # get gets 2 from the queue
    assert q.qsize() == 0  # current size of the queue should be 0


# Generated at 2022-06-24 09:19:11.597266
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at 0x{:x} maxsize=2 tasks=0>".format(id(q))
    assert str(q) == "<Queue maxsize=2 tasks=0>"

# Generated at 2022-06-24 09:19:18.185165
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    # expected:
    # ValueError: task_done() called too many times
    q = Queue(0)
    q.put_nowait(1)
    q.get_nowait()
    with pytest.raises(ValueError) as excinfo:
        q.task_done()
    assert excinfo.value.args[0]=="task_done() called too many times"
test_Queue_task_done()


# Generated at 2022-06-24 09:19:24.462812
# Unit test for constructor of class Queue
def test_Queue():
    # queue_name = Queue_name(maxsize=3)
    queue_number = Queue(maxsize=3)
    # print(queue_name)
    print(queue_number)
    print(queue_number.maxsize)
    print(type(queue_number.maxsize))
    print(type(queue_number))

#test_Queue()
#test_Queue()


# Generated at 2022-06-24 09:19:26.979239
# Unit test for constructor of class QueueFull
def test_QueueFull():
    a = FuncQueue()
    try:
        a.put_nowait(100)
    except QueueFull:
        pass



# Generated at 2022-06-24 09:19:37.789041
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    import unittest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    class TestQueue(unittest.TestCase):
        def setUp(self):
            self.q = Queue()

        @gen.coroutine
        def run_queue(self, finish_time, finish_callback, finish_timeout=None, timeout=None):
            try:
                item = yield self.q.get(timeout=timeout)
                if finish_time:
                    time.sleep(finish_time)
                    self.q.task_done()
                    finish_callback()
                    print("end")
            except Exception as e:
                print("Error",e)
        @gen.coroutine
        def run_test(self):
            Item = 1
            finish_