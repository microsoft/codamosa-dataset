

# Generated at 2022-06-24 09:09:29.975217
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    # Item in the queue
    q.put_nowait(1)
    q.put_nowait(2)
    actual = q.qsize()
    expected = 2
    assert expected == actual


# Generated at 2022-06-24 09:09:33.102963
# Unit test for constructor of class QueueFull
def test_QueueFull():
    class MyClass(Exception):
        def __init__(self,*args):
            Exception.__init__(self,*args)
    MyClass('T1','T2','T3','T4','T5','T6','T7','T8','T9')
    MyClass('T1')



# Generated at 2022-06-24 09:09:35.870354
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    msg = "foo"
    try:
        raise QueueEmpty(msg)
    except QueueEmpty as e:
        assert str(e) == msg



# Generated at 2022-06-24 09:09:46.845902
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')
    ioloop.IOLoop.current().run_sync(main)
test_Queue_put()


# Generated at 2022-06-24 09:09:49.201493
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:09:58.243714
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert "<Queue maxsize=2 queue=[]>" == str(q)
    q._put(1)
    assert "<Queue maxsize=2 queue=[1]>" == str(q)
    q._put(2)
    assert "<Queue maxsize=2 queue=[1, 2]>" == str(q)
    q._getters.append(None)
    assert "<Queue maxsize=2 queue=[1, 2] getters[1]>" == str(q)
    q._putters.append((3, None))
    assert "<Queue maxsize=2 queue=[1, 2] getters[1] putters[1]>" == str(q)
    q._unfinished_tasks = 3

# Generated at 2022-06-24 09:10:03.475618
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    async def consumer(asyncForQueue: asyncio.Queue) -> None:
        async for item in asyncForQueue:
            print('Doing work on %s' % item)

    q = Queue()

    consumer(q)


# Generated at 2022-06-24 09:10:07.968383
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
    except QueueFull:
        assert False
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True



# Generated at 2022-06-24 09:10:10.743809
# Unit test for method get of class Queue
def test_Queue_get():
    import sys
    import io
    import tempfile
    import pytest
    import inspect

    from tornado.queues import Queue
    queue_obj = Queue()
    with pytest.raises(QueueEmpty):
        queue_obj.get()


# Generated at 2022-06-24 09:10:11.303064
# Unit test for method join of class Queue
def test_Queue_join():
    pass


# Generated at 2022-06-24 09:10:14.058128
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
	q = LifoQueue()
	q.put(3)
	q.put(2)
	q.put(1)


# Generated at 2022-06-24 09:10:20.439513
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q.put_nowait('Hello')
    assert str(q) == "<Queue maxsize=0 queue=deque(['Hello'])>"
    q.get()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"



# Generated at 2022-06-24 09:10:21.074149
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass


# Generated at 2022-06-24 09:10:22.805444
# Unit test for constructor of class QueueFull
def test_QueueFull():
    test = QueueFull()
    assert isinstance(test, Exception)



# Generated at 2022-06-24 09:10:24.920663
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(10)
    assert 'maxsize=10' in q.__repr__()



# Generated at 2022-06-24 09:10:29.304336
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q_0 = Queue(maxsize=None)
    assert q_0.qsize() == 0
    q_1 = Queue(maxsize=0)
    assert q_1.qsize() == 0
    q_2 = Queue(maxsize=2)

# Generated at 2022-06-24 09:10:31.776659
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(0)
    q.put_nowait(1)
    assert q.get_nowait()==1
    print("ok")
test_Queue_get_nowait()

# Generated at 2022-06-24 09:10:34.046183
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except Exception as e:
        assert isinstance(e, QueueEmpty)



# Generated at 2022-06-24 09:10:41.547673
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    import unittest
    import sys
    import inspect
    import platform

    class TestQueueEmpty(unittest.TestCase):
        def test_QueueEmpty(self):
            with self.assertRaises(QueueEmpty):
                raise QueueEmpty()
            self.assertTrue(hasattr(QueueEmpty, '__module__'))
            self.assertTrue(hasattr(QueueEmpty, '__doc__'))
            self.assertTrue(hasattr(QueueEmpty, '__qualname__'))
            self.assertEqual(inspect.getmodule(QueueEmpty), sys.modules['tornado.queues'])
            self.assertEqual(QueueEmpty.__module__, 'tornado.queues')
            self.assertIsInstance(QueueEmpty.__qualname__, str)


# Generated at 2022-06-24 09:10:47.056846
# Unit test for constructor of class Queue
def test_Queue():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:10:49.365288
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # create a LifoQueue (Last-In-First-Out Queue)
    queue = LifoQueue()
    # add 10 items to the LifoQueue
    for i in range(10):
        queue.put(i)
    # get the LifoQueue elements
    for i in range(10):
        print(queue.get_nowait())


# Generated at 2022-06-24 09:10:52.357827
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    def coro() -> int:
        q: Queue[int] = Queue()
        iterator = _QueueIterator(q)
        assert isinstance(iterator, _QueueIterator)

    coro()



# Generated at 2022-06-24 09:10:57.448122
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))



# Generated at 2022-06-24 09:11:03.365400
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    asyncio.gather(
    Queue(maxsize=0).join(),
    Queue(maxsize=0).join(1),
    Queue(maxsize=0).join(datetime.timedelta(seconds=1)))


# Generated at 2022-06-24 09:11:05.499419
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q._format() == 'maxsize=0 queue=[1, 2] getters[0] putters[0] tasks=2'

# Generated at 2022-06-24 09:11:06.725946
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__() == "<Queue maxsize=0 queue=deque([])>"

# Generated at 2022-06-24 09:11:12.173202
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.1)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:11:15.654290
# Unit test for constructor of class Queue
def test_Queue():
    a = Queue(maxsize=0)
    b = Queue(maxsize=1)
    c = Queue(maxsize=2)
    d = Queue(maxsize=3)


# Generated at 2022-06-24 09:11:27.999074
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-24 09:11:34.951229
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                q.task_done()
                yield gen.sleep(0.01)
            finally:
                print("My work is done")

    @gen.coroutine
    def producer():
        for item in range(1, 5):
            yield q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.

# Generated at 2022-06-24 09:11:45.742836
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            print('Doing work on {}'.format(item))
            await gen.sleep(0.01)
            q.task_done()
            
    async def producer():
        for item in range(5):
            print('Put {}'.format(item))
            await q.put(item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        
        print('Done')
        
    IOLoop.current().run_sync(main)
    
# Unit test

# Generated at 2022-06-24 09:11:55.804397
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print("Doing work on %s" % item)
            await gen.sleep(0.01)
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer() # Wait for producer to put all tasks.
        await q.join() # Wait for consumer to finish all tasks.
        print("Done")

    IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:11:59.674210
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:12:07.344067
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    q._init()
    q._queue = collections.deque()
    q._queue.append(1)
    q._queue.append(2)
    q._getters = collections.deque([])
    q._putters = collections.deque([])
    q._unfinished_tasks = 2
    q._finished.clear()
    q._unfinished_tasks = 0
    q._finished.set()


# Generated at 2022-06-24 09:12:16.423393
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    def test_Queue_task_done_sub(undertest):
        undertest.put_nowait("a")
        undertest.put_nowait("a")
        undertest.put_nowait("a")
        assert undertest.qsize() == 3
        undertest.get_nowait()
        undertest.get_nowait()
        undertest.task_done()
        undertest.task_done()
        undertest.task_done()
        assert undertest.qsize() == 0
    test_Queue_task_done_sub(Queue())
    test_Queue_task_done_sub(LifoQueue())
    test_Queue_task_done_sub(PriorityQueue())


# Generated at 2022-06-24 09:12:23.613122
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert(q.qsize() == 0)
    q.put_nowait(1)
    assert (q.qsize() == 1)
    q.put_nowait(2)
    assert (q.qsize() == 2)
    assert(q.get_nowait() == 1)
    assert (q.qsize() == 1)
    assert(q.get_nowait() == 2)
    assert (q.qsize() == 0)
    print("test_Queue_qsize pass")


# Generated at 2022-06-24 09:12:33.552873
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    """
    Tests for the Queue.__repr__ method
    """
    
    # Test when maxsize is 0
    maxsize_0 = Queue(0)
    assert repr(maxsize_0) == "<Queue at 0x1d5678b0 maxsize=0 queue=deque([])>"
    # Test when maxsize is 3
    maxsize_3 = Queue(3)
    assert repr(maxsize_3) == "<Queue at 0x1d5678b0 maxsize=3 queue=deque([])>"
    # Test when maxsize is None
    def maxsize_None():
        Queue(None)
    #  ... and make sure the assertion holds up
    assert_raises(TypeError, maxsize_None)
    # Test when maxsize is negative
    def maxsize_negative():
        Que

# Generated at 2022-06-24 09:12:43.396513
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    def generator_factory(q: "Queue[int]") -> Generator:
        val: int
        try:
            while True:
                val = yield q.get()
        except QueueEmpty:
            return
        yield from generator_factory(q)    
    q = Queue()
    q.put(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    assert([1,2,3,4] == list(_QueueIterator(q)))
    return "passed __init__"



# Generated at 2022-06-24 09:12:47.186667
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=1)
    # print q
    # print repr(q)
    # print type(q)
    # print hex(id(q))
    # print hex(id(q))
    # print q.maxsize
    # print q._format()
    return



# Generated at 2022-06-24 09:12:50.241255
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Unit test for method get of class Queue

    # Unit test for method join of class Queue

    # Unit test for method put of class Queue

    # Unit test for method put_nowait of class Queue

    None



# Generated at 2022-06-24 09:12:51.509942
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    exc: QueueEmpty = QueueEmpty()
    assert str(exc) == "Queue is empty"


# Generated at 2022-06-24 09:12:54.137063
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(q)
    print(repr(q))

# Generated at 2022-06-24 09:12:59.860556
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.__put_internal(1)
    q.__put_internal(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Test passed")
    else:
        print("Test failed")

# Generated at 2022-06-24 09:13:02.610425
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    print(str(q))
# test_Queue___str__()



# Generated at 2022-06-24 09:13:07.113868
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Given an empty queue
    q = Queue(maxsize=0)
    # When calling method get_nowait
    try:
        res = q.get_nowait()
        assert -1, "Exception expected"
    except QueueEmpty:
        assert True
    # Then QueueEmpty Exception is raised
    assert True
        

# Generated at 2022-06-24 09:13:10.421087
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:13:12.154183
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("args")
    except QueueFull as e:
        assert e.args == ('args',)



# Generated at 2022-06-24 09:13:15.553078
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:13:25.508156
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0

    q.put(1)
    assert q.qsize() == 1

    q.put_nowait(2)
    assert q.qsize() == 2

    assert q.get_nowait() == 1
    assert q.qsize() == 1

    assert q.get_nowait() == 2
    assert q.qsize() == 0

    q.put(3)
    assert q.qsize() == 1

test_Queue_qsize()

# Generated at 2022-06-24 09:13:34.553464
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import unittest
    import sys
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    q = Queue()

    @gen.coroutine
    def put():
        for i in range(4):
            yield q.put(i)
            print(q.qsize())

    @gen.coroutine
    def get():
        try:
            while True:
                i = yield q.get()
                print('Doing work on %s' % i)
                yield gen.sleep(0.01)
                q.task_done()
        except QueueEmpty:
            print('Exception: Queue is empty.')

    @gen.coroutine
    def main():
        IOLoop.current().spawn_callback(put)
        IOLoop.current().spawn_callback(get)
       

# Generated at 2022-06-24 09:13:40.167169
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

'''
if __name__ == "__main__":
    #test_LifoQueue()
    test_PriorityQueue()
'''

# Generated at 2022-06-24 09:13:46.910248
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.gen import Return, coroutine, Task
    from tornado.testing import gen_test

    @coroutine
    def test1(x, y):
        yield gen.sleep(0.1)
        raise Return((yield x.get()))

    q = Queue()
    t = [Task(test1(q, i), ioloop=ioloop.IOLoop.current()) for i in range(10)]
    q.join()  # wait until all tasks are started

    @gen_test
    def test2():
        for i in t:
            q.put(i)
        q.join()  # wait until all tasks are finished
        t2 = []
        for i in t:
            t2.append(i.result())
        assert sorted(t2) == list(range(10))


# Unit

# Generated at 2022-06-24 09:13:51.421740
# Unit test for method get of class Queue
def test_Queue_get():
    async def f():
        q = Queue()
        await q.put(10)
        x = await q.get()
        assert x == 10

    ioloop.IOLoop.current().run_sync(f)

# Generated at 2022-06-24 09:13:54.297666
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado import ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    print(q.qsize())
    #assert q.qsize() == 2
    assert True
    ioloop.IOLoop.current().stop()

# Generated at 2022-06-24 09:14:01.225253
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    @gen.coroutine
    def putter():
        yield q.put("a")
        yield q.put("b")

    @gen.coroutine
    def getter():
        try:
            obj = yield q.get()
            print("Got: %s" % obj)
            yield q.join()
            print("Queue is empty")
        finally:
            q.task_done()

    @gen.coroutine
    def main():
        try:
            yield putter()
            yield getter()
            yield getter()
        finally:
            yield putter()
            yield q.join()
            print("Queue is empty")

    IOLoop.current().run_sync

# Generated at 2022-06-24 09:14:12.919881
# Unit test for method put of class Queue

# Generated at 2022-06-24 09:14:18.951820
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    
    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# test_PriorityQueue()



# Generated at 2022-06-24 09:14:27.970332
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    tasks = []
    async def consumer():
        async for item in q:
            try:
                tasks.append(item)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)

    IOLoop.current().run_sync(lambda: gen.multi([consumer(), producer()]))
    await q.join()  # Wait for consumer to finish all tasks.
    assert tasks == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:14:29.502684
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert (q.maxsize == 0)
    
assert LifoQueue().maxsize == 0

# Generated at 2022-06-24 09:14:32.440628
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0


# Generated at 2022-06-24 09:14:36.607846
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    """Not yet"""
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:14:38.875009
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        e


# Generated at 2022-06-24 09:14:42.435473
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()
    assert(isinstance(a,Exception))
    try:
        raise a
    except Exception as b:
        assert(isinstance(b,Exception))


# Generated at 2022-06-24 09:14:47.365609
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full() == True
    q.get_nowait()
    assert q.full() == False
    return q.full()


# Generated at 2022-06-24 09:14:57.822379
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=10)

    async def consumer():
        async for i in range(10):
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(10):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes)
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer

# Generated at 2022-06-24 09:14:59.122012
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    x = _QueueIterator(Queue())
    x
# End of unit test.



# Generated at 2022-06-24 09:15:09.925638
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:15:18.645385
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue()

    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)
        await q.join()
        q.put(None)

    async def consumer():
        while True:
            item = await q.get()
            print("Get:", item)
            if item is None:
                break
            await gen.sleep(0.01)
            q.task_done()

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer

# Generated at 2022-06-24 09:15:23.629622
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue
    from tornado.gen import coroutine, sleep
    from tornado.ioloop import IOLoop
    import time
    import random
    import sys
    import os

    @coroutine
    def main():
        q = Queue(maxsize=5)

        async def put_item(i: int) -> None:
            await q.put(i)

        @coroutine
        def get_items() -> None:
            async for item in q:
                print(item)
                await sleep(random.random())

        IOLoop.current().spawn_callback(get_items)

        for i in range(10):
            IOLoop.current().spawn_callback(put_item, i)

        await sleep(0.1)

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:15:33.026084
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    import queue, random

    for i in range(1, 20):
        a = queue.Queue(i)
        for item in range(1,20):
            a.put(item)
        a_len = a.qsize()
        assert isinstance(a,Queue)
        assert len(a.__repr__()) >= 10
        assert a.__repr__()[0] == '<'
        assert a.__repr__()[-1] == '>'
        assert a.__repr__()[1] == 'Q'
        assert a.__repr__()[-2] == ' '
        assert a.__repr__()[-3] == 's'
        assert a.__repr__()[-4] == 'e'
        assert a

# Generated at 2022-06-24 09:15:43.721980
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    q = Queue()

    async def producer():
        for x in range(5):
            await q.put(x)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print("Done")


    async def consumer():
        async for item in q:
            try:
                print("Doing work on", item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    #loop = ioloop.IOLoop.current()
    #loop.run_sync(main)

test_Queue___aiter__()

# Unit test

# Generated at 2022-06-24 09:15:48.528512
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    async def main():
        async for item in q:
            print(item)
    ioloop.IOLoop.current().run_sync(main)
test_Queue___aiter__()

# Generated at 2022-06-24 09:15:52.123720
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        print("type of e: {}".format(type(e)))
        print("e.args: {}".format(e.args))



# Generated at 2022-06-24 09:15:58.893322
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
	q = PriorityQueue()
	q.put((1,'medium-priority item'))
	q.put((0,'high-priority item'))
	q.put((10,'low-priority item'))
	print(q.get_nowait())
	print(q.get_nowait())
	print(q.get_nowait())


# Generated at 2022-06-24 09:16:04.096577
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False



# Generated at 2022-06-24 09:16:05.512576
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise(QueueEmpty)
    except Exception:
        pass


# Generated at 2022-06-24 09:16:17.594066
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-24 09:16:21.954406
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=1)
    before_item=q.get_nowait()
    q.put_nowait(10)
    after_item=q.get_nowait()
    if before_item==10 and after_item==10:
        return True

# Generated at 2022-06-24 09:16:24.112932
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e1:
        assert e1
    except BaseException as e2:
        assert False


# Generated at 2022-06-24 09:16:32.811510
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(1)
    assert q.maxsize == 1
    assert q.empty() == True
    assert q.full() == False
    q.put_nowait(1)
    assert q.maxsize == 1
    assert q.empty() == False
    assert q.full() == True
    assert q.qsize() == 1
    try:
        q.put_nowait(1)
        assert False
    except QueueFull:
        assert True
    assert q.maxsize == 1
    assert q.empty() == False
    assert q.full() == True
    assert q.qsize() == 1

# Generated at 2022-06-24 09:16:34.618950
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q: Queue[int] = Queue()
    iterable = _QueueIterator(q)
    assert isinstance(iterable, _QueueIterator)



# Generated at 2022-06-24 09:16:36.639903
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except Exception as e:
        assert e.__class__ == QueueEmpty



# Generated at 2022-06-24 09:16:38.750447
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    #type: ()->None
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass
    except Exception:
        raise



# Generated at 2022-06-24 09:16:40.404594
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    t = _QueueIterator(None)
    return t

_BaseQueue = collections.deque



# Generated at 2022-06-24 09:16:45.393466
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q._queue[0] == 1
    assert q._queue[1] == 2
    assert q._queue[2] == 3
# End of unit test for method put_nowait of class Queue

# Generated at 2022-06-24 09:16:51.584587
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    """Test task_done of class Queue"""
    maxsize = 0 # maxsize of queue
    q = Queue(maxsize)
    if q.empty():
        q._unfinished_tasks = 5
        q._finished.clear()
    q.task_done()
    assert q._unfinished_tasks == 4
    with pytest.raises(ValueError):
        q.task_done()

# Generated at 2022-06-24 09:16:56.335504
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)

    assert(q.full() is True)
    assert(q.size() == 2)

    q.put(3)
    assert q.size() == 3

# Generated at 2022-06-24 09:16:59.017968
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue() # type: Queue[_T]
    it = _QueueIterator(q) # type: _QueueIterator[_T]
    assert it.q is q


# Generated at 2022-06-24 09:17:07.091364
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import tornado.testing
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test
    import tornado.concurrent

    class TestTestCase(AsyncTestCase):
        @gen_test
        def test(self):
            import typing
            q: typing.Queue[int] = tornado.concurrent.queues.Queue()
            q.put(1)
            q.put(2)
            q.put(3)
            c = 0
            async for _ in q:
                c += 1
            self.assertEqual(c, 3)
    def mock_get_result():
        _q = typing.cast(typing.Queue[int], q)
        assert _q.qsize() == 0
        raise tornado.concurrent.Future.CancelledError()

# Generated at 2022-06-24 09:17:17.709645
# Unit test for method join of class Queue
def test_Queue_join():

    # This test was created automatically by test_generator.py
    # It checks that the method executes successfully.
    # You should delete the test after you have verified that it works correctly.

    # Define a function that returns True if the test passed or False if it did not.
    def ok_to_continue():
        return queue.empty()
    
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-24 09:17:20.103505
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except:
        pass


# Generated at 2022-06-24 09:17:28.201794
# Unit test for method put of class Queue
def test_Queue_put():
    Queue1 = Queue(maxsize=0)
    Queue2 = Queue(maxsize=1)
    Queue1.put("111")
    Queue2.put("111")
    Queue2.put("222")
    assert Queue1.putters == deque([])
    assert Queue1.getters == deque([])

# Generated at 2022-06-24 09:17:33.671606
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from typing import Union, Awaitable
    import asyncio
    async def test_do(self, q: "Queue[int]" = None) -> Union[float, Awaitable[None]]:
        i = 0.0
        try:
            while True:
                i += await self.q.get()
                self.q.task_done()
        except asyncio.QueueEmpty:
            pass
        else:
            j += i
        finally:
            return j

    queue = Queue()
    queue_iterator = _QueueIterator(queue)



# Generated at 2022-06-24 09:17:41.571126
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    print('Testing LifoQueue')
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print('LifoQueue constructor and put() method has been tested')

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:17:49.925514
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.qsize() == 0, 'qsize() == 0'
    assert q.empty() == True, 'q.empty() == True'
    assert q.maxsize >= 0, 'q.maxsize >= 0'
    q = Queue(10)
    assert q.qsize() == 0, 'qsize() == 0'
    assert q.empty() == True, 'q.empty() == True'
    assert q.maxsize == 10, 'q.maxsize == 10'


# Generated at 2022-06-24 09:17:59.112293
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import time
    import random
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    def f(q):
        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)
        print('1')
        return producer()

    IOLoop.current().run_sync(f, q)
    print(repr(q))
    print(q)


# Generated at 2022-06-24 09:18:09.213238
# Unit test for method join of class Queue
def test_Queue_join():
    Q = Queue(maxsize=2)
    assert Q.maxsize == 2, "maxsize is not 2"
    assert Q.qsize() == 0, "there are items in the queue"
    assert Q.empty() == True, "empty queue is not empty"
    assert Q.full() == False, "empty queue is full"
    Q.put_nowait(11)
    assert Q.qsize() == 1, "the queue does not contain 1 item"
    Q.put_nowait(22)
    assert Q.qsize() == 2, "the queue does not contain 2 items"
    assert Q.full() == True, "full queue is not full"
    assert Q.get_nowait() == 11, "get_nowait returned wrong item"

# Generated at 2022-06-24 09:18:14.661885
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert isinstance(q.put(1), Future) == True
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    assert isinstance(q.put(2), Future) == True
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    assert isinstance(q.put(3), Future) == True
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.put_nowait(4) == None
    assert q.qsize() == 2
    assert q

# Generated at 2022-06-24 09:18:25.633709
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:35.948912
# Unit test for method __aiter__ of class Queue

# Generated at 2022-06-24 09:18:39.847797
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    q = Queue()
    assert(repr(q) == '<Queue at %x maxsize=0 queue=deque([])>' % id(q))

# Generated at 2022-06-24 09:18:50.933664
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    """Unit test for method __aiter__ of class Queue."""
    q = Queue(maxsize=2)
        
    async def put_items():
        for i in range(5):
            await q.put(i)
            print("Put %s" % i)

    async def consume_items():
        async for item in q:
            print("Doing work on %s" % item)
            await gen.sleep(0.01)
            q.task_done()

    async def main():
        IOLoop.current().spawn_callback(consume_items)
        await put_items()
        await q.join()
        print("Done")

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:19:03.011119
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert '<Queue maxsize=0 queue=deque([])>' == q.__str__()
    q = Queue(3)
    assert '<Queue maxsize=3 queue=deque([])>' == q.__str__()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert '<Queue maxsize=3 queue=deque([1, 2, 3])>' == q.__str__()
    q.get_nowait()
    assert '<Queue maxsize=3 queue=deque([2, 3])>' == q.__str__()
    q = Queue()
    q.put(1)

# Generated at 2022-06-24 09:19:13.417000
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:19:17.532897
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    queue = Queue(maxsize=2)
    _time = time.time()
    queue.put(1, _time + 20)
    queue.put(3, _time + 20)
    queue.put(7, _time + 20)
    queue.put_nowait(1)
    queue.get_nowait()
    queue.task_done()
    queue.join()



# Generated at 2022-06-24 09:19:23.448496
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        print("isinstance(e, Exception) = %s" % isinstance(e, Exception))


# Generated at 2022-06-24 09:19:25.687604
# Unit test for method get of class Queue
def test_Queue_get():
    i = 0
    q = Queue(maxsize=2)
    try:
        i = i + 1
        assert i == 1
        q.get_nowait()
    except QueueEmpty:
        i = i + 1
        assert i == 2
        return
    assert False
test_Queue_get()

# Generated at 2022-06-24 09:19:33.934829
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado
    import tornado.concurrent
    import tornado.ioloop
    import tornado.gen
    import tornado.queues
    import tornado.locks
    import tornado.platform.asyncio
    import asyncio
    import time
    import concurrent.futures
    import itertools
    import multiprocessing
    import threading
    @tornado.gen.coroutine
    def worker(q):
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield tornado.gen.sleep(0.01)
            finally:
                q.task_done()
    q = tornado.queues.Queue()
    q.put(10)
    q.get_nowait()
