

# Generated at 2022-06-24 09:09:38.653073
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # setup
    q = Queue()
    
    qIter = _QueueIterator(q)
    for i in range(5):
        q.put_nowait(i)

    i = 0
    while True:
        try:
            # exercise
            result = yield qIter.__anext__()
        except StopAsyncIteration:
            break
        finally:
            # verify
            assert result == i
            i += 1


if typing.TYPE_CHECKING:
    _QueueLike = collections.deque
else:
    # Pure python equivalent of collections.deque, to serve as a
    # substitute if cPython optimize this class in the future.
    class _QueueLike(collections.MutableSequence):
        """Pure python implementation of collections.deque."""


# Generated at 2022-06-24 09:09:49.883117
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:09:56.674919
# Unit test for method get of class Queue
def test_Queue_get():
  from tornado import gen
  from tornado.ioloop import IOLoop
  from tornado.queues import Queue

  q = Queue(maxsize=2)

  async def consumer():
      async for item in q:
          try:
              print('Doing work on %s' % item)
              await gen.sleep(0.01)
          finally:
              q.task_done()

  async def producer():
      for item in range(5):
          await q.put(item)
          print('Put %s' % item)

  async def main():
      # Start consumer without waiting (since it never finishes).
      IOLoop.current().spawn_callback(consumer)
      await producer()     # Wait for producer to put all tasks.
      await q.join()       # Wait for consumer to finish all tasks.
      print('Done')

# Generated at 2022-06-24 09:10:06.365109
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    queue = Queue()
    async def test():
        await queue.put(1)
        await queue.put(2)
        await queue.put(3)
        async for item in queue:
            print(item)
    if __name__=="__main__":
        print("=========start test_Queue___aiter___yield_sub_coroutine==========")
        try:
            asyncio.run(test())
        except Exception as e:
            print(e)
        print("=========start test_Queue___aiter___yield_sub_coroutine==========")

# Generated at 2022-06-24 09:10:13.950922
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.testing import AsyncTestCase
    from tornado.queues import Queue
    from tornado import testing
    import time
    import unittest

    class QueueTestMixin(AsyncTestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            super(QueueTestMixin, self).setUp()

        def tearDown(self):
            self.io_loop.close()
            super(QueueTestMixin, self).tearDown()

        def test_qsize(self):
            q = self.Queue()
            self.assertEqual(q.qsize(), 0)
            q.put(object())

# Generated at 2022-06-24 09:10:19.744414
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue
    q = Queue(2)
    assert str(q) == "<Queue maxsize=2 queue=collections.deque([])>"
    q._put('a')
    assert str(q) == "<Queue maxsize=2 queue=collections.deque(['a'])>"



# Generated at 2022-06-24 09:10:26.353486
# Unit test for constructor of class Queue
def test_Queue():
    Queue()
    Queue(1)
    Queue(0)
    Queue(-1)
    Queue(maxsize=1)
    Queue(maxsize=0)
    Queue(maxsize=-1)
    try:
        Queue(maxsize=None)
    except TypeError:
        pass
    else:
        assert False, "Queue(maxsize=None) should raise TypeError"



# Generated at 2022-06-24 09:10:31.451538
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # Init
    q = LifoQueue()

    # Put three elements
    q.put(3)
    q.put(2)
    q.put(1)

    # Check whether items are put in the correct order
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:10:33.744063
# Unit test for method join of class Queue
def test_Queue_join():
    class Queue(object):
        def join(self) -> Future[None]:
            pass
    Queue.join(Queue())


# Generated at 2022-06-24 09:10:41.386566
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import asyncio
    from tornado.queues import Queue
    import unittest
    import unittest.mock as mock

    class ReturnValue(unittest.TestCase):
        def test_ReturnValue(self):
            q = Queue()
            result = q.__aiter__()
            self.assertIsInstance(result, _QueueIterator)
            self.assertEqual(q, result.q)

    class Behavior(unittest.TestCase):
        @mock.patch("asyncio.Future")
        def test_Behavior(self, Future):
            future1 = Future()
            future2 = Future()
            q = Queue()
            q._queue.append(1)
            q._queue.append(2)
            q._queue.append(3)
            result = q.__aiter__

# Generated at 2022-06-24 09:10:48.789648
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')
    print("Successful test for PriorityQueue")



# Generated at 2022-06-24 09:10:57.419480
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import time
    import tornado
    import tornado.ioloop
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish

# Generated at 2022-06-24 09:10:59.788018
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    
    assert (1 == q.get_nowait())
    assert (2 == q.get_nowait())
    assert (3 == q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:11:02.061395
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()
    print("Unit test finished!")

# Generated at 2022-06-24 09:11:03.139312
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()



# Generated at 2022-06-24 09:11:14.264149
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        io_loop = ioloop.IOLoop.current()
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    io_loop = ioloop.IOLoop

# Generated at 2022-06-24 09:11:15.395238
# Unit test for method put of class Queue
def test_Queue_put():
    print(Queue)


# Generated at 2022-06-24 09:11:16.848796
# Unit test for constructor of class QueueFull
def test_QueueFull():
    e = QueueFull()
    assert isinstance(e, QueueFull)


# Generated at 2022-06-24 09:11:28.984115
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:11:35.582299
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:11:46.515916
# Unit test for method join of class Queue
def test_Queue_join():
    from unittest import TestCase
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.test.util import unittest_run_loop

    @gen.coroutine
    def producer():
        for i in range(4):
            if q.full():
                yield q.join()
            yield q.put(i)
    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            print(item)
            q.task_done()
    class TestQueue(TestCase):
        def test_join(self):
            q = Queue(maxsize=2)
            IOLoop.current().run_sync(producer)
            IOLoop.current().run_sync(consumer)
    test = Test

# Generated at 2022-06-24 09:11:53.009065
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    q.maxsize = 10
    q._queue = [1, 2, 3]
    q._getters = [1, 2, 3]
    q._putters = [1, 2, 3]
    q._unfinished_tasks = 1
    assert q.__str__() == "<Queue maxsize=10 queue=[1, 2, 3] getters[3] putters[3] tasks=1>"



# Generated at 2022-06-24 09:11:57.344423
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    def f():

        q = Queue()
        x = 1
        y = 2
        q.put(x)
        q.put(y)
    f()


# Generated at 2022-06-24 09:11:59.995798
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    assert isinstance(it.q, Queue)



# Generated at 2022-06-24 09:12:09.490878
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = collections.deque()  # type: Queue[int]
    assert q.qsize() == 0
    assert q.empty() == True
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    q.put(2)
    q.get()
    assert q.qsize() == 1
    assert q.empty() == False
    q.get()
    assert q.qsize() == 0
    assert q.empty() == True
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    for x in q:
        print(x)
    q.task_done()
    assert q.qsize() == 1
    assert q.empty() == False
    q

# Generated at 2022-06-24 09:12:12.971730
# Unit test for constructor of class QueueFull
def test_QueueFull():
     with pytest.raises(QueueFull):
         q = Queue(maxsize=1)
         q.put_nowait(1)
         q.put_nowait(2)


# Generated at 2022-06-24 09:12:15.224659
# Unit test for method put of class Queue
def test_Queue_put():
    """Test for method put of class Queue"""

    q = Queue()
    q.put(0)


# Generated at 2022-06-24 09:12:20.616221
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    it = _QueueIterator(q)
    assert gen.isawaitable(it.__anext__())
    assert not gen.isawaitable(it.__anext__())
    assert it.q == q


# Generated at 2022-06-24 09:12:26.889935
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-24 09:12:33.881138
# Unit test for method put of class Queue
def test_Queue_put(): 
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    
    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:12:45.778782
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado.queues import Queue
    q = Queue()
    assert q.qsize() == 0
    q.__put_internal(1)
    assert q.qsize() == 1
    q.__put_internal(2)
    assert q.qsize() == 2
    q.__put_internal(3)
    assert q.qsize() == 3
    q.__put_internal(4)
    assert q.qsize() == 4
    q.__put_internal(5)
    assert q.qsize() == 5
    q.__put_internal(6)
    assert q.qsize() == 6
    q.__put_internal(7)
    assert q.qsize() == 7
    q.__put_internal(8)
    assert q.qsize() == 8
    q.__

# Generated at 2022-06-24 09:12:47.219757
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    """Test method Queue.__str__"""
    q = Queue()
    q.__str__()



# Generated at 2022-06-24 09:12:52.698417
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    assert q.empty(), "queue should be empty at the beginning"
    assert q.get_nowait() == 0, "first value should be 0"
    assert not q.empty(), "queue should be full at beginning"
    q.task_done()
    assert q.empty(), "queue should be empty after task_done"
    assert q.get_nowait() == 1, "second value should be 1"
    q.task_done()
    assert q.empty(), "queue should be empty after task_done"
    try:
        q.get_nowait()
        assert False, "queue should be empty, should throw QueueEmpty exception"
    except QueueEmpty:
        assert True
    assert q.put_nowait(5), "queue put with 5"
    assert q.put

# Generated at 2022-06-24 09:12:58.607252
# Unit test for constructor of class QueueFull
def test_QueueFull():
    class MyQueueFull(QueueFull):
        pass
    try:
        raise MyQueueFull("this is a test")
    except MyQueueFull as e:
        assert(True)
    except Exception as e:
        assert(False)



# Generated at 2022-06-24 09:13:07.014969
# Unit test for method join of class Queue
def test_Queue_join():
    '''Test the method join of class Queue
    '''
    import time
    import pytest
    from tornado.queues import Queue

    # initialize of Queue class
    q = Queue(maxsize=2)
    t = time.perf_counter()
    # check the result of join method
    q.join()

    t1 = time.perf_counter() - t
    assert q.empty(), 'q is not empty'
    assert t1 < 1, 't1 is not less than 1'

    # initialize of Queue class
    q = Queue()
    # put items into Queue
    q.put_nowait(1)
    q.put_nowait(2)
    # check the result of join method
    q.join()
    assert q.empty(), 'q is not empty'
   

# Generated at 2022-06-24 09:13:10.078955
# Unit test for method put of class Queue
def test_Queue_put():
    import typing as t
    Q = Queue()
    Q.put(1,timeout=1)
    Q.put_nowait(2)
    x = Q.get()
    y = Q.get_nowait()


# Generated at 2022-06-24 09:13:13.753523
# Unit test for method full of class Queue
def test_Queue_full():
    #get the docstring of method full()
    s = Queue(2)
    print(s.full.__doc__)
    #get the source code of method full()
    with open(Queue.full.__code__.co_filename) as f:
        code = f.read()
        print(code)
        # print(source(Queue.full))


# Generated at 2022-06-24 09:13:14.980597
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass


# Generated at 2022-06-24 09:13:15.946990
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    try:
        PriorityQueue()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 09:13:25.416990
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time
    q = Queue(maxsize=0)
    t1 = time.time()
    q.put_nowait(1)
    t2 = time.time()
    q.put_nowait(2)
    t3 = time.time()
    print("t2-t1 = ", t2-t1)
    print("t3-t2 = ", t3-t2)
    assert t3-t2 > 0.01

# Generated at 2022-06-24 09:13:31.880347
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:13:33.014449
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert True


# Generated at 2022-06-24 09:13:33.834924
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    pass



# Generated at 2022-06-24 09:13:43.160665
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    def get_q():
        return Queue(10)

    def get_item():
        return 'x'

    def call_put_nowait(q, item):
        q.put_nowait(item)

    def run_test():
        q = get_q()
        assert q.empty() == True
        assert q.full() == False
        assert q.qsize() == 0
        item = get_item()
        call_put_nowait(q, item)
        assert q.empty() == False
        assert q.full() == False
        assert q.qsize() == 1
        q.put_nowait(item)
        q.put_nowait(item)
        q.put_nowait(item)
        q.put_nowait(item)
        q.put_nowait(item)

# Generated at 2022-06-24 09:13:49.695578
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:13:55.923257
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()
    assert(a.args == ())
    b = QueueEmpty(1)
    assert(b.args == (1,))
    c = QueueEmpty(1, 2, 3)
    assert(c.args == (1, 2, 3))
    d = QueueEmpty(None)
    assert(d.args == (None,))
    e = QueueEmpty([1, 2])
    assert(e.args == ([1, 2],))


# Generated at 2022-06-24 09:13:57.003299
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    with pytest.raises(QueueEmpty):
        QueueEmpty()


# Generated at 2022-06-24 09:13:59.453095
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert str(e) == ' '
    assert repr(e) == ' '



# Generated at 2022-06-24 09:14:02.561237
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty("message")
    except Exception as ex:
        assert ex.args == ("message",)


# Generated at 2022-06-24 09:14:06.669272
# Unit test for method full of class Queue
def test_Queue_full():
    import asyncio
    async def test():
        q = Queue()
        assert q.full() == False
    loop = asyncio.new_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-24 09:14:17.729838
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue

    q = Queue()
    it = q.__aiter__()
    q.put_nowait(1)
    rtn = q.put_nowait(2)
    q.put_nowait('hi')
    rtn = q.put_nowait('bye')
    q.task_done()
    rtn = q.task_done()
    q.task_done()
    rtn = q.task_done()
    q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q.join()
    rtn = q

# Generated at 2022-06-24 09:14:21.393811
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull:
        return None
    raise AssertionError('Queue.put_nowait must raise QueueFull')



# Generated at 2022-06-24 09:14:24.781582
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # My code here
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    queue.get_nowait()


# Generated at 2022-06-24 09:14:33.814347
# Unit test for method join of class Queue
def test_Queue_join():
    queue = Queue(10)
    yield queue.put(1)
    yield queue.join()
    print("queue.join success")
    yield queue.put(1)
    yield queue.get()
    yield queue.join()
    print("queue.join success")
    yield queue.put(1)
    yield queue.put(2)
    yield queue.put(3)
    yield queue.join()
    print("queue.join success")
    yield queue.put(1)
    yield queue.put(2)
    yield queue.put(3)
    yield queue.put(4)
    yield queue.put(5)
    yield queue.put(6)
    yield queue.put(7)
    yield queue.put(8)
    yield queue.put(9)
    yield queue.put(10)


# Generated at 2022-06-24 09:14:35.200686
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:14:39.009567
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    async def test():
        await q.put("1")
        await q.get()
        assert q.qsize() == 0
    ioloop.IOLoop.current().run_sync(test)


# Generated at 2022-06-24 09:14:44.850600
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__() == '<Queue maxsize=0 queue=deque([])>'
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.__str__() == '<Queue maxsize=0 queue=deque([1, 2, 3])>'



# Generated at 2022-06-24 09:14:46.189868
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    print(Queue(None))

# Generated at 2022-06-24 09:14:50.914045
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    from tornado.testing import gen_test
    from tornado.gen import coroutine
    from tornado.platform.asyncio import AsyncIOMainLoop

    loop = AsyncIOMainLoop()
    loop.make_current()

    q = Queue()
    yield q.put(10)
    qi = _QueueIterator(q)
    assert (yield from qi.__anext__()) == 10



# Generated at 2022-06-24 09:14:52.092368
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass



# Generated at 2022-06-24 09:15:02.211823
# Unit test for constructor of class Queue
def test_Queue():
    import sys
    import os
    #import inspect
    #import linecache
    #import pprint

    ####################################################################
    # http://goo.gl/wgWZHJ
    ####################################################################

    # What line are we currently executing?
    #print >>sys.stderr, '\n'.join(os.getcwd() + ': ' + inspect.getsourcelines(inspect.currentframe())[0][0].rstrip() for i in range(10))
    #print >>sys.stderr, linecache.getline(__file__, 1)

    ####################################################################
    # http://goo.gl/c8pvOy
    ####################################################################

    # The whole file we're currently executing.
    #print >>sys.stderr, pprint.pformat(open(__file__

# Generated at 2022-06-24 09:15:03.587406
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0

# Generated at 2022-06-24 09:15:06.462157
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-24 09:15:08.470416
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty("QueueEmpty constructor test")
    except QueueEmpty as e:
        print("e = ", e)



# Generated at 2022-06-24 09:15:17.165412
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        Queue(0).put_nowait(1)
        raise Exception("Should have thrown QueueFull")
    except QueueFull:
        pass
    q = Queue(1)
    q.put_nowait(1)
    try:
        q.put_nowait(1)
        raise Exception("Should have thrown QueueFull")
    except QueueFull:
        pass
    q = Queue(maxsize=10)
    for i in range(0, 10):
        q.put_nowait(i)
    assert q.qsize() == 10
    try:
        q.put_nowait(10)
        raise Exception("Should have thrown QueueFull")
    except QueueFull:
        pass


# Generated at 2022-06-24 09:15:18.153751
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert Queue().empty() == True


# Generated at 2022-06-24 09:15:22.937363
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()

    q.put(1)
    q.put(2)
    q.put(3)

    a = _QueueIterator(q)

    b = a.__anext__()

    assert isinstance(b, Future)

QueueIterator = _QueueIterator(_T)



# Generated at 2022-06-24 09:15:31.598623
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import time
    async def producer(q):
        await q.put('First item')
        print("put 1")
        await q.put('Second item')
        print("put 2")
    async def consumer(q):
        await q.join()
        print("join finished")
        await q.put('Done item')
        print("put done")
    q = asyncio.Queue(1)
    asyncio.ensure_future(consumer(q))
    time.sleep(1)
    asyncio.ensure_future(producer(q))
    loop = asyncio.get_event_loop()
    loop.run_forever()
test_Queue_join()

# Generated at 2022-06-24 09:15:42.204287
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))
    q.put((0, 'high-priority item 2'))
    assert(q.get_nowait() == (0, 'high-priority item 2'))
    q.put((2, 'medium-priority item 2'))
    assert(q.get_nowait() == (2, 'medium-priority item 2'))


# Generated at 2022-06-24 09:15:44.640934
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    s = str(q)
    assert all(
        [s.startswith("<Queue maxsize=0"), s.endswith(">")]
    ), "test_Queue___str__() failed"
    pass


# Generated at 2022-06-24 09:15:46.656855
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        assert True
    else:
        assert False



# Generated at 2022-06-24 09:15:52.008906
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue(1)
    it = q.__anext__()

    try:
        await it.__anext__()
        # execution should not reach here
        assert False
    except StopAsyncIteration:
        # StopAsyncIteration indicates the end of the iteration
        pass
# end of test__QueueIterator___anext__



# Generated at 2022-06-24 09:16:04.577723
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:08.043750
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # test of method put_nowait
    # Given
    q = Queue()
    # When
    q.put_nowait(5)
    # Then
    return q._queue == collections.deque([5])

# Generated at 2022-06-24 09:16:11.566783
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Set maxsize to 0, which makes the queue of size 1
    q = Queue(maxsize=0)
    print(q.maxsize)


# Generated at 2022-06-24 09:16:14.963189
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q = Queue(None)
    q = Queue(0)
    q = Queue(1)
    q = Queue(2)
    q = Queue(-1)


# Generated at 2022-06-24 09:16:16.877934
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()
    print(a)
    return



# Generated at 2022-06-24 09:16:18.482869
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    '''Unit test for method __str__ of class Queue'''
    A = Queue()
    A._unfinished_tasks = 1
    assert A._format() == "maxsize=0 tasks=1"


# Generated at 2022-06-24 09:16:21.962777
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    q = Queue() # type: Queue[int]
    q.put_nowait(1)
    iterator = _QueueIterator(q)
    await iterator.__anext__()
    pass



# Generated at 2022-06-24 09:16:28.281487
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from .queue import Queue
    def runner():
        q = Queue()
        q.put(1)
        q.put(2)
        q.put(3)
        for n in q:
            print(n)
        print("Done.")
    import asyncio
    asyncio.ensure_future(runner())
    asyncio.set_event_loop_policy(ioloop.AsyncIOPolicy())
    asyncio.get_event_loop().run_forever()
# End of unit test test__QueueIterator___anext__
    def __next__(self) -> _T:
        raise StopIteration

# Generated at 2022-06-24 09:16:31.790067
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = Queue()
    try:
        a.get_nowait()
    except QueueEmpty as e:
        print("no items in queue")
        assert str(e) == 'queue empty'
    finally:
        print("passing test_QueueEmpty")


# Generated at 2022-06-24 09:16:37.579069
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.maxsize == 2
    assert q.full() == False
    assert q.empty() == True
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

# Generated at 2022-06-24 09:16:46.954530
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue


    q = Queue(maxsize=2)


    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
       

# Generated at 2022-06-24 09:16:51.583923
# Unit test for method full of class Queue
def test_Queue_full():
    __q = Queue()
    def test_helper__Queue_full(q):
        if not (q.full()):
            q.put_nowait('a')
        else:
            raise QueueFull
    try:
        test_helper__Queue_full(__q)
    except:
        pass


# Generated at 2022-06-24 09:16:53.105406
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)


# Generated at 2022-06-24 09:17:03.379251
# Unit test for method get of class Queue
def test_Queue_get():
    
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-24 09:17:07.268244
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=1)
    assert q.maxsize == 1


# Generated at 2022-06-24 09:17:16.080325
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    from tornado.queues import Queue

    async def main():
        queue = Queue()

        for i in range(5):
            await queue.put(i)

        await asyncio.gather(*[consumer(queue) for _ in range(2)])

    async def consumer(q: Queue):
        async for item in q:
            print(f"consumed {item}")
            await asyncio.sleep(item)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()

test_Queue_join()

# Generated at 2022-06-24 09:17:18.094848
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # make sure a finished job returns false
    q = Queue(4)
    assert q.task_done() == False

# Generated at 2022-06-24 09:17:30.373329
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import time
    import asyncio
    from tornado.queues import Queue
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop

    @coroutine
    def async_get():
        for i in q:
            print(i,end="|")

    @coroutine
    def async_put():
        for i in range(5):
            yield q.put(i)
            # print(i)

    q = Queue(maxsize=8)
    loop = IOLoop.current()
    loop.spawn_callback(async_put)
    loop.spawn_callback(async_get)
    # time.sleep(2)
    loop.run_sync(async_put)
    loop.run_sync(async_get)


# Generated at 2022-06-24 09:17:41.345073
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 tasks=0>" % id(q)
    assert str(q) == "<Queue maxsize=0 tasks=0>"

    q = Queue(maxsize=10)
    assert repr(q) == "<Queue at 0x%x maxsize=10 tasks=0>" % id(q)

    q._put("foo")
    q._getters.append("bar")
    assert repr(q) == "<Queue at 0x%x maxsize=10 queue=deque(['foo']) " "tasks=0 getters[1]>" % id(q)

# Generated at 2022-06-24 09:17:42.839263
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)


# Generated at 2022-06-24 09:17:44.124902
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    with pytest.raises(QueueEmpty):
        raise QueueEmpty


# Generated at 2022-06-24 09:17:54.709675
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() is True
    assert q.full() is False

    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() is False
    assert q.full() is False

    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is False

    q.put_nowait(3)
    assert q.qsize() == 3
    assert q.empty() is False
    assert q.full() is False

    


# Generated at 2022-06-24 09:18:01.633194
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_PriorityQueue()



# Generated at 2022-06-24 09:18:06.759180
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Verifies that task_done is called after a get
    q = Queue()
    q.put(123)
    assert q.unfinished_tasks == 1
    x = q.get()
    assert q.unfinished_tasks == 1
    assert x == 123
    assert q.unfinished_tasks == 0


# Generated at 2022-06-24 09:18:19.049918
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test 1: put into an empty queue without waiting
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    assert not q._getters
    assert not q._putters
    assert not q._finished.is_set()

    # Test 2: put into a full queue without waiting
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.full()
    assert q.qsize() == 1
    assert not q._getters
    assert not q._putters
    assert not q._finished.is_set()
    try:
        q.put_nowait(2)
        assert False
    except QueueFull:
        pass
    assert q.full()
    assert q.qsize() == 1
    assert q

# Generated at 2022-06-24 09:18:28.812950
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Create an instance of Queue
    assert Queue(maxsize=4).put_nowait(4) is None
    # Unit test for method get_nowait of class Queue
    def test_Queue_get_nowait():
        # Create an instance of Queue
        assert Queue(maxsize=4).get_nowait() is None
        # Unit test for method task_done of class Queue
        def test_Queue_task_done():
            # Create an instance of Queue
            assert Queue(maxsize=4).task_done() is None
            # Unit test for method join of class Queue
            def test_Queue_join():
                # Create an instance of Queue
                assert Queue(maxsize=4).join(None) is None
    # Defined in class Queue

# Generated at 2022-06-24 09:18:30.606699
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    queue = LifoQueue()
    queue.put(1)
    queue.put(2)
    queue.put(3)
    assert queue.get_nowait() == 3 
    assert queue.get_nowait() == 2
    assert queue.get_nowait() == 1
    assert queue.empty() == True

# Generated at 2022-06-24 09:18:37.643249
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen,ioloop, queues
    from types import GeneratorType

    # The Queue is initially empty, so qsize() must return 0
    q = queues.Queue(maxsize=1)
    assert q.qsize()==0

    # Check qsize() after put
    q.put_nowait(1)
    assert q.qsize()==1

    # Check qsize() after get
    q.get_nowait()
    print("The final qsize is:",q.qsize())
    assert q.qsize()==0



# Generated at 2022-06-24 09:18:44.846703
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-24 09:18:49.072402
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.queues import Queue
    from tornado.locks import Condition
    t = Condition()
    q = Queue(0)
    q.put_nowait(1)
    it = _QueueIterator(q)
    assert await it.__anext__() == 1


# Generated at 2022-06-24 09:18:49.820261
# Unit test for constructor of class QueueFull
def test_QueueFull():
    print(QueueFull)


# Generated at 2022-06-24 09:18:51.878985
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    get_event_loop().run_sync(test_Queue___aiter__)



# Generated at 2022-06-24 09:18:53.281866
# Unit test for method get of class Queue
def test_Queue_get():
    return 1



# Generated at 2022-06-24 09:18:57.146980
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    while not q.empty():
        e = q.get_nowait()
        print(e)

# Generated at 2022-06-24 09:19:00.230313
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    q._queue = [1,2,3,4]
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3, 4]>"
    return



# Generated at 2022-06-24 09:19:06.496396
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    import tornado.gen
    from tornado.queues import _QueueIterator, Queue
    async def async_fn():
        # __aiter__ returns an instance of _QueueIterator.
        q = _QueueIterator(Queue())
        assert isinstance(q, _QueueIterator)
        # Unpack __aiter__'s return.
        assert isinstance(q.q, Queue)

    tornado.ioloop.IOLoop.current().run_sync(async_fn)


# Generated at 2022-06-24 09:19:14.674218
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    '''Unit test for method ``__aiter__`` of class ``Queue``
    '''
    import pytest
    from tornado.queues import Queue
    q = Queue(maxsize=10)
    assert q.__aiter__()
    #pytest.raises(TypeError,
    #              "q.__aiter__({})")
    #pytest.raises(ValueError,
    #              "q.__aiter__([])")
    #pytest.raises(ValueError,
    #              "q.__aiter__()")



# Generated at 2022-06-24 09:19:17.860348
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int](0)
    # test instance type
    assert isinstance(_QueueIterator(q), _QueueIterator)



# Generated at 2022-06-24 09:19:29.289956
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(2)
    q.put("0")
    q.put("1")
    try:
        # q.put("2")
        # raise Exception("q.put should not success if queue is full")
        q.put_nowait("2")
        raise Exception("q.put should not success if queue is full")
    except QueueFull:
        pass
    # q.get()
    # raise Exception("q.get should return future")
    # q.get()
    # raise Exception("q.get should return future")
    q.get().result()
    q.get().result()