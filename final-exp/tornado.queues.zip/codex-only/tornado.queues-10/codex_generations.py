

# Generated at 2022-06-24 09:09:36.109017
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # assert 1==1 , "test for task_done method of class Queue"
    # assert 1==2 , "test for task_done method of class Queue"
    q = Queue(maxsize=0)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            print("Doing work on %s" % item)
            yield gen.sleep(0.01)
            q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print("Put %s" % item)

    @gen.coroutine
    def main():
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()
        yield q.join()
        print("Done")

# Generated at 2022-06-24 09:09:38.739424
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[]>" % id(q)


# Generated at 2022-06-24 09:09:49.623771
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    a=q.task_done()
    b=q.join()
    print(type(a))
    print(type(b))
    # print(type(q.get()))
    # print(type(q.get_nowait()))
    # print(type(q.put(45, timeout=None)))
    # print(type(q.put_nowait(4)))
    # print("qsize = ",q.qsize())
    # print("empty = ",q.empty())
    # print("full = ",q.full())
    # print("maxsize = ",q.maxsize)
    # print(q)
    # print(repr(q))

test_Queue_join()


# Generated at 2022-06-24 09:09:53.208233
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    assert(await it.__anext__()) == 1
    assert(await it.__anext__()) == 2
    assert(await it.__anext__()) == 3
    with pytest.raises(QueueEmpty):
        await it.__anext__()


# Generated at 2022-06-24 09:10:05.632075
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    resql=q.put_nowait(0)
    assert q.qsize() == 1
    resql=q.put_nowait(1)
    assert q.qsize() == 2
    resql=q.put_nowait(2)
    assert q.qsize() == 3
    resql=q.put_nowait(3)
    assert q.qsize() == 3
    assert resql==None
    assert resql==q.get_nowait()
    assert q.qsize() == 2
    assert resql==q.get_nowait()
    assert q.qsize() == 1
    assert resql==q.get_nowait()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:10:14.256257
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item'), "Test Fail: Constructor of class PriorityQueue"
    assert q.get_nowait() == (1, 'medium-priority item'), "Test Fail: Constructor of class PriorityQueue"
    assert q.get_nowait() == (10, 'low-priority item'), "Test Fail: Constructor of class PriorityQueue"


# Generated at 2022-06-24 09:10:20.196513
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import types
    import unittest
    import asyncio
    from tornado.queues import Queue

    class QueueTestCase(unittest.TestCase):
        def setUp(self):
            self.loop = ioloop.IOLoop.current()
            self.i = 0
            self.producer_lock = asyncio.Lock(loop=self.loop)

        async def produce(self, q: Queue):
            with await self.producer_lock:
                await q.put(self.i)
                await asyncio.sleep(0.05)
                self.i += 1

        async def run(self):
            q = Queue()
            tasks = []
            for _ in range(4):
                t = self.loop.create_task(self.producer(q))
                tasks

# Generated at 2022-06-24 09:10:28.509741
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    print(q.maxsize)
    print(q.qsize())
    print(q.empty())
    print(q.full())
    #print(q.get())
    q.put_nowait(1)
    q.put_nowait(2)
    #q.put_nowait(3)
    print(q.qsize())
    print(q.empty())
    print(q.full())
    print(q.get_nowait())
    print(q.get_nowait())
    #print(q.get_nowait())



# Generated at 2022-06-24 09:10:32.496157
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:10:35.620899
# Unit test for constructor of class QueueFull
def test_QueueFull():
    queue = Queue(1)
    queue.put_nowait(1)
    try:
        queue.put_nowait(1)
    except QueueFull:
        pass

test_QueueFull()


# Generated at 2022-06-24 09:10:42.640611
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=2 queue=[1]>"
    q.put_nowait(2)
    assert str(q) == "<Queue maxsize=2 queue=[1, 2]>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=2 queue=[2, 1]>"
    assert q.get_nowait() == 2
    assert str(q) == "<Queue maxsize=2 queue=[1]>"
    assert q.get_nowait() == 1
    assert str(q) == "<Queue maxsize=2>"
    q.put_nowait(1)

# Generated at 2022-06-24 09:10:45.313476
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an instance of Queue
    tempQueue = Queue()
    # get an item from the queue
    tempQueue.get()
    return tempQueue



# Generated at 2022-06-24 09:10:47.041986
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        pass



# Generated at 2022-06-24 09:10:48.789219
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    qsize = Queue().qsize()
    assert qsize == 0



# Generated at 2022-06-24 09:10:57.387175
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    global_test = None
    class TestClass(Exception):
        def __init__(self) -> None:
            self.value = 1

        def __str__(self) ->str:
            return self.value.__str__()

    def run(yielded_future):
        global global_test
        assert type(yielded_future) == Future
        try:
            global_test = 1
            raise TestClass()
        except TestClass as e:
            # This is the reason, why we need the above run function
            # because in this case the exception should be sent to yielded_future
            # by this line below
            yielded_future.set_exception(e)

    q = Queue(1)
    q.put_nowait(1)
    iterator = _QueueIterator(q)
    yielded_future = iterator

# Generated at 2022-06-24 09:10:59.655134
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Call the test function
test_PriorityQueue()


# Generated at 2022-06-24 09:11:02.580932
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=0)
    assert q.empty() == True


# Generated at 2022-06-24 09:11:07.735196
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)

    try:
        q.put_nowait(1)
        q.put_nowait(2)
        assert not q.full()
        q.put_nowait(3)
        assert q.full()
    except Exception as e:
        assert False, "Unexpected error %s" % e


# Generated at 2022-06-24 09:11:19.284017
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)
    q = Queue(maxsize = 1)
    q._queue = collections.deque([])
    q._getters = collections.deque([])
    q._putters = collections.deque([])
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    assert repr(q) == "<Queue at 0x%x maxsize=1 queue=deque([])>" % id(q)
    q = Queue(maxsize = 1)
    q._queue = collections.deque([1])
    q._getters = collections.deque([1])
    q._putters = collections.deque([1])


# Generated at 2022-06-24 09:11:24.235992
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=0)
    assert not q.full()

    q = Queue(maxsize=1)
    assert not q.full()
    _global_q = q
    _global_q.put_nowait(1)
    assert q.full()


# Generated at 2022-06-24 09:11:35.071842
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from typing import Union
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test
    class _TestBase(AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()
            self.loop = IOLoop.current()
        @gen.coroutine
        def _get_queue(self, queue_class=Queue) -> Queue[Any]:
            q = queue_class()
            self.loop.add_callback(to_asyncio_future, q.put(1))
            self.loop.add_callback(to_asyncio_future, q.put(2))
            self.loop.add_callback(to_asyncio_future, q.put(3))

# Generated at 2022-06-24 09:11:40.141745
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.qsize() == 0
    assert not q.empty()
    assert q.full()
    q = Queue(maxsize=10)
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()
    q = Queue(maxsize=0)
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()



# Generated at 2022-06-24 09:11:52.473619
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(2)

    q.__init__
    f1 = Future()
    f1.set_result((1, None, None))
    f2 = Future()
    f2.set_result((1, None, None))

    q._queue.appendleft(f1)
    q._queue.appendleft(f1)
    q._queue.appendleft(f2)
    q._queue.appendleft(f2)
    q._unfinished_tasks = 6

    q.task_done()
    print("Did done 2")
    print(q._queue)
    print(q._unfinished_tasks)

    q.task_done()
    print("Did done 1")
   

# Generated at 2022-06-24 09:11:57.135342
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q._unfinished_tasks = 2
    assert q._unfinished_tasks == 2
    assert q._finished.is_set() == False
    q.task_done()
    assert q._unfinished_tasks == 1
    assert q._finished.is_set() == False
    q.task_done()
    assert q._unfinished_tasks == 0
    assert q._finished.is_set() == True


# Generated at 2022-06-24 09:12:07.263745
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:12:12.903474
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait('test')
    itera = _QueueIterator(q)
    r = yield from itera.__anext__()
    assert r == 'test'



# Generated at 2022-06-24 09:12:14.944986
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull(-1)
    except Exception as e:
        print(e)
        print(e.args)


# Generated at 2022-06-24 09:12:24.802841
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    a = Queue()
    a.__put_internal(4)
    a._consume_expired()
    if a._putters:
        assert a.full(), "queue not full, why are putters waiting?"
        item, putter = a._putters.popleft()
        a.__put_internal(item)
        future_set_result_unless_cancelled(putter, None)
        a._get()
    elif a.qsize():
        a._get()
    else:
        raise QueueEmpty
    empty_queue = a.empty()
    assert not empty_queue, "queue should not be empty"
    q = Queue()
    assert isinstance(q, Queue)
    assert q.empty() == True
    assert q.qsize() == 0
    q.get()


# Generated at 2022-06-24 09:12:28.422967
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    q.put(1)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 1
    assert q.maxsize == 0


# Generated at 2022-06-24 09:12:36.942311
# Unit test for method join of class Queue
def test_Queue_join():
    #more than one getters
    queue = Queue(maxsize=0)
    queue_item=[]
    queue.__put_internal(1)
    queue.__put_internal(2)
    assert queue.__str__() == "<Queue maxsize=0 queue=[1, 2]>"
    future = queue.get()
    queue_item.append(future)
    future2 = queue.get()
    queue_item.append(future2)
    assert queue.__str__() == "<Queue maxsize=0 getters[2] tasks=2>"
    assert queue.full() == False
    assert queue.empty() == False
    assert queue.qsize() == 0
    queue.task_done()
    assert queue.__str__() == "<Queue maxsize=0 getters[2] tasks=1>"

# Generated at 2022-06-24 09:12:41.420223
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q=Queue(5)
    print(q.__repr__())
    q=Queue(0)
    print(q.__repr__())
# test_Queue___repr__()


# Generated at 2022-06-24 09:12:49.288136
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=3)

    q.put(1)
    q.put(2)
    q.put(3)
    assert q.full()
    assert q.__str__() == "<Queue maxsize=3 queue=[1, 2, 3]>"

    q.get_nowait()
    assert not q.full()
    assert q.__str__() == "<Queue maxsize=3 queue=[2, 3]>"

    q.put(4)
    q.get_nowait()
    q.get_nowait()
    assert not q.full()
    assert q.__str__() == "<Queue maxsize=3 queue=[4]>"



# Generated at 2022-06-24 09:12:53.054748
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-24 09:12:54.047783
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True


# Generated at 2022-06-24 09:12:55.922946
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull(5)
    QueueFull(5, "done")


# Generated at 2022-06-24 09:12:59.256370
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=None)
    q.qsize()
    pass

# Generated at 2022-06-24 09:13:09.671745
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import pytest
    from tornado import gen
    from tornado.queues import QueueEmpty
    # TODO: There is no way to disable a warning "RuntimeWarning: coroutine 'Queue._get' was never awaited",
    #       so we use this code to silence this warning.
    from warnings import simplefilter
    simplefilter("ignore", category=RuntimeWarning)
    q: Queue[int] = Queue()
    for i in range(10):
        q.put_nowait(i)
    result: int = 0
    async for i in q:
        result += i
    assert result == sum(range(10))
    with pytest.raises(QueueEmpty):
        try:
            async for i in q:
                result += i
        except:
            pytest.fail("should not generate exception")
    q.put_now

# Generated at 2022-06-24 09:13:13.636805
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(maxsize=1)
    q.put_nowait(10)
    q.close()
    iter = _QueueIterator(q)
    assert iter.q is q

AwaitableItem = Union[Awaitable[_T], Awaitable[None]]
AwaitableIterator = Union[Awaitable[None], Awaitable[_T], _QueueIterator[_T]]


# Generated at 2022-06-24 09:13:14.240032
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    pass



# Generated at 2022-06-24 09:13:15.552585
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:13:19.213819
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    if not q.empty():
        raise RuntimeError('test_Queue_qsize failed: 1')
    if q.full():
        raise RuntimeError('test_Queue_qsize failed: 2')
    if q.qsize() != 0:
        raise RuntimeError('test_Queue_qsize failed: 3')



# Generated at 2022-06-24 09:13:26.031757
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q1 = Queue()
    q1.put_nowait(1)
    q1.put_nowait(2)
    q1.put_nowait(3)

    # verify iterator correctness
    iter_queue_1 = q1.__aiter__()
    assert iter_queue_1.q is q1
    assert iter_queue_1.q.__class__ is Queue

    # verify called functions correctness
    q2 = Queue()
    q2.put_nowait(1)
    q2.put_nowait(2)
    q2.put_nowait(3)

    iter_queue_2 = q2.__aiter__()
    assert iter_queue_2.q is q2

    assert iter_queue_1 is not iter_queue_2


# Generated at 2022-06-24 09:13:31.422003
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    result = None
    try:
        result = q.get_nowait()
    except QueueEmpty:
        result = "QueueEmpty"
    if result == "QueueEmpty":
        return True
    else:
        return False


# Generated at 2022-06-24 09:13:32.924930
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Implicitly tested via the Queue example in __doc__
    pass



# Generated at 2022-06-24 09:13:37.020384
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.empty() == False
    return

# Generated at 2022-06-24 09:13:41.510768
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:13:46.685151
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

test_LifoQueue()

# Generated at 2022-06-24 09:13:51.610709
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize = 2)
    assert q.full() == False
    q.put_nowait(1)
    assert q.full() == False
    q.put_nowait(2)
    assert q.full() == True

# Generated at 2022-06-24 09:13:54.843186
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import tornado.testing
    import tornado.gen
    from .queue import _QueueIterator, Queue

    def f():
        q = Queue()
        q.put(1)
        it = _QueueIterator(q)
        return it.__anext__()

    ret = f()
    assert isinstance(ret, tornado.gen.Awaitable)
    ret = tornado.gen.convert_yielded(ret)
    assert ret == 1


# Generated at 2022-06-24 09:13:56.805391
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    s = q.__repr__()
    print(s)


# Generated at 2022-06-24 09:14:03.724988
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-24 09:14:07.354694
# Unit test for method join of class Queue
def test_Queue_join():
    test_object = Queue()
    future = test_object.join()
    test_object.task_done()
    future.result()



# Generated at 2022-06-24 09:14:14.229702
# Unit test for method join of class Queue
def test_Queue_join():
    def mytest():
        import time
        import queue
        q = queue.Queue()
        q.join()
        q.put(1)
        q.join()
        q.task_done()
        q.put(2)
        q.join()
        q.task_done()
        now = time.time()
        while True:
            if time.time() - now > 3:
                future.set_result(None)
                break
            time.sleep(0.01)
        q.join()
    # Run the unit test
    future = Future()
    ioloop.IOLoop.current().add_callback(mytest)
    ioloop.IOLoop.current().run_sync(lambda: future)


# Generated at 2022-06-24 09:14:16.412994
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=3)
    return q.empty()


# Generated at 2022-06-24 09:14:17.772724
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:14:24.533949
# Unit test for method get of class Queue
def test_Queue_get():
    # Initialize the Queue object
    q = Queue(maxsize=2)
    future = Future()
    timeout = None
    timeout_handle = None
    io_loop = ioloop.IOLoop.current()
    if timeout is not None:
        # There is a timeout parameter, call _set_timeout function
        _set_timeout(future, timeout)
    return future

# Generated at 2022-06-24 09:14:27.092096
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
        q.put_nowait(2)
    except QueueFull:
        return False
    return True


# Generated at 2022-06-24 09:14:31.496914
# Unit test for method join of class Queue
def test_Queue_join():
    queue = Queue()
    ioloop = IOLoop.current()
    ioloop.run_sync(lambda: queue.put(1))
    ioloop.run_sync(lambda: queue.put(2))
    ioloop.run_sync(queue.join)


# Generated at 2022-06-24 09:14:33.896841
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        if not isinstance(e, QueueFull):
            raise e


# Generated at 2022-06-24 09:14:36.652856
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(2)
    assert q.__str__() == "<Queue maxsize=2 queue=deque([]) getters[] putters[] tasks=0>"



# Generated at 2022-06-24 09:14:38.607478
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    assert(qsize() == 0)
    assert(qsize() == 0)



# Generated at 2022-06-24 09:14:42.959308
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait()==1
    assert q.get_nowait()==2
    assert q.get_nowait()==3

# Generated at 2022-06-24 09:14:43.929695
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    pass
    


# Generated at 2022-06-24 09:14:48.260858
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert Queue.empty(Queue()) == True
    assert Queue.empty(Queue(maxsize=0)) == True
    assert Queue.empty(Queue(maxsize=1)) == True


# Generated at 2022-06-24 09:14:53.290478
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=1)
    test_str = "<Queue maxsize=1 queue=deque([])>"
    assert(str(q) == test_str)
    q.put_nowait(item=20)
    test_str = "<Queue maxsize=1 queue=deque([20]) getters[0] putters[0]>"
    assert(str(q) == test_str)



# Generated at 2022-06-24 09:14:56.215599
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    i = q.__iter__()
    try:
        from tornado.concurrent import Future
        f = Future()
        f.set_result(None)
        assert q.get() == f
    except gen.BadYieldError:
        pass



# Generated at 2022-06-24 09:14:58.221067
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = QueueFull()
    assert "queue full" == q.__repr__()



# Generated at 2022-06-24 09:15:07.130901
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
  q = Queue(maxsize = 2)
  assert q.maxsize == 2
  assert q.get_nowait() == None
  assert q.empty() == True
  assert q.full() == False
  q.put_nowait(item = 3)
  assert q.empty() == False
  assert q.full() == False
  q.put_nowait(item = 4)
  assert q.empty() == False
  assert q.full() == True
  assert q.get_nowait() == 3
  assert q.get_nowait() == 4
  assert q.empty() == True
  assert q.full() == False

  # Test Queue Empty Exception

# Generated at 2022-06-24 09:15:12.192974
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue() 
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:15:18.018730
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado.queues import Queue
    q = Queue(maxsize=1)
    q.empty()
    q.put_nowait(1)
    q.full()
    q.get_nowait()
    q.empty()
    q.put_nowait(1)
    q.put_nowait(1)
    q.full()

# Generated at 2022-06-24 09:15:21.352521
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        return
    except:
        assert False, 'Failed to catch QueueEmpty'


# Generated at 2022-06-24 09:15:24.187229
# Unit test for constructor of class Queue
def test_Queue():
    """
    >>> q = Queue()
    >>> q.qsize()
    0
    >>> q.empty()
    True
    >>> q.full()
    False
    """



# Generated at 2022-06-24 09:15:27.713667
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False


# Generated at 2022-06-24 09:15:39.676486
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    try:
        q.put((1, 'medium-priority item'))
    except:
        assert False
    try:
        q.put((0, 'high-priority item'))
    except:
        assert False
    try:
        q.put((10, 'low-priority item'))
    except:
        assert False
        
    try:
        print(q.get_nowait())
    except:
        assert False
    try:
        print(q.get_nowait())
    except:
        assert False
    try:
        print(q.get_nowait())
    except:
        assert False
        
if __name__ == "__main__":
    test_PriorityQueue()



# Generated at 2022-06-24 09:15:50.445848
# Unit test for method full of class Queue
def test_Queue_full():
    import time
    import random
    import datetime
    import tornado.testing
    import tornado.ioloop
    import tornado.queues
    import unittest
    import logging

    class TestQueueFull(tornado.testing.AsyncTestCase):
        def test_full(self):
            q = tornado.queues.Queue(maxsize=1)
            self.assertEqual(q.maxsize, 1)
            self.assertFalse(q.full())
            q.put_nowait(1)
            self.assertTrue(q.full())
            q.get_nowait()
            self.assertFalse(q.full())
            q.put_nowait(2)
            q.put_nowait(3)
            self.assertTrue(q.full())
            q.get_nowait()
            q.get_

# Generated at 2022-06-24 09:15:57.165563
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:00.471054
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    for item in range(5):
        q.put_nowait(item)
        q.task_done()
    

# Generated at 2022-06-24 09:16:04.234489
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    try:
        q = _QueueIterator(Queue[int]())
        future = q.__anext__()
        print(future)
    except Exception as e:
        print(e)
asyncio.run(test__QueueIterator___anext__())


# Generated at 2022-06-24 09:16:07.777695
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Check the empty method of class Queue
    # Create a Queue object
    queue = Queue()
    # Make sure the queue is empty
    if queue.empty():
        assert True
    else:
        assert False


# Generated at 2022-06-24 09:16:10.102671
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
assert q.empty() == True

# Generated at 2022-06-24 09:16:18.875742
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    #__anext__: () -> Awaitable[_T]
    q = Queue[int]()
    qit = _QueueIterator[int](q)
    a = qit.__anext__()
    #py_ver = sys.version_info
    #all_py_ver = [[3, 0], [3, 1], [3, 2], [3, 3], [3, 4], [3, 5], [3, 6], [3, 7]]
    #if (py_ver in all_py_ver):
    assert(isinstance(a, Awaitable))



# Generated at 2022-06-24 09:16:27.623963
# Unit test for method join of class Queue

# Generated at 2022-06-24 09:16:31.235916
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    q.__put_internal('a')
    assert repr(q) == "<Queue at 0x7f0dae776370 maxsize=0 queue=deque(['a'])>"
    q.put_nowait('b')
    assert repr(q) == "<Queue at 0x7f0dae776370 maxsize=0 queue=deque(['a', 'b'])>"


# Generated at 2022-06-24 09:16:41.680300
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)


    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:16:49.184800
# Unit test for method empty of class Queue
def test_Queue_empty():
    import queue
    import random
    import unittest
    from tornado.queues import Queue

    def test_empty(self):
        test_queue = Queue()
        self.assertTrue(test_queue.empty())

    def test_full(self):
        test_queue = Queue(maxsize=1)
        self.assertFalse(test_queue.full())

    def test_full_after_put(self):
        test_queue = Queue(maxsize=1)
        item = 0
        test_queue.put_nowait(item)
        self.assertTrue(test_queue.full())

    def test_not_empty(self):
        test_queue = Queue()
        item = 0
        test_queue.put_nowait(item)
        self.assertFalse(test_queue.empty())

# Generated at 2022-06-24 09:17:00.329058
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == '<Queue maxsize=0 queue=deque([])>'
    q.put_nowait(0)
    q.put_nowait(1)
    assert str(q) == '<Queue maxsize=0 queue=deque([0, 1])>'
    q.task_done()
    q.task_done()
    assert str(q) == '<Queue maxsize=0 queue=deque([])>'
    f1 = q.get()
    f2 = q.get()
    assert str(q) == '<Queue maxsize=0 queue=deque([]) getters[2]>'
    future_set_result_unless_cancelled(f1, 2)

# Generated at 2022-06-24 09:17:03.884360
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    qit = _QueueIterator(q)
    qit.__anext__()
#test__QueueIterator___anext__()
    #test__QueueIterator___anext__
    #@"q,qit,qit.__anext__()->{q,qit}

# Generated at 2022-06-24 09:17:13.815296
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import datetime
    import tornado

    class TestQueue(unittest.TestCase):
        def setUp(self):
            self.q = Queue(maxsize=2)

        def test_put_nowait(self):
            self.q.put_nowait(1)
            self.q.put_nowait(2)
            with self.assertRaises(QueueFull):
                self.q.put_nowait(3)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestQueue)
    success = unittest.TextTestRunner(failfast=True).run(suite).wasSuccessful()
    return success


# Generated at 2022-06-24 09:17:20.034309
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    q._queue = [1,2,3]
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3]>"
    q._getters = [a for a in range(5)]
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3] getters[5]>"
    q._putters = [a for a in range(3)]
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3] getters[5] putters[3]>"
    q._unfinished_tasks = 2
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3] getters[5] putters[3] tasks=2>"


# Generated at 2022-06-24 09:17:26.948513
# Unit test for method __str__ of class Queue
def test_Queue___str__(): 
    q = Queue()
    assert str(q) == '<Queue maxsize=0 queue=deque([])>'
    q.put_nowait(1)
    q.put_nowait(2)
    assert str(q) == '<Queue maxsize=0 queue=deque([1, 2])>'
    q.get_nowait()
    assert str(q) == '<Queue maxsize=0 queue=deque([2])>'

# Generated at 2022-06-24 09:17:29.090552
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=1)
    print(q)


# Generated at 2022-06-24 09:17:31.942905
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    print('\n*** Unit test for method __repr__ of class Queue ***')
    q = Queue(maxsize=5)
    print(q)
    print('\n')


# Generated at 2022-06-24 09:17:44.370573
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert Queue().empty() == True
    assert Queue().put_nowait(1).empty() == False
    assert Queue().put_nowait(1).put_nowait(2).put_nowait(3).put_nowait(4).put_nowait(5).qsize() == 5
    assert Queue().put_nowait(1).put_nowait(2).put_nowait(3).empty() == False
    assert Queue().put_nowait(1).get().empty() == True
    assert Queue().put_nowait(1).get().put_nowait(2).empty() == False
    assert Queue().put_nowait(1).put_nowait(2).get().put_nowait(3).get().put_nowait(4).get().put_nowait(5).get().qsize

# Generated at 2022-06-24 09:17:53.241072
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True

# Generated at 2022-06-24 09:18:05.441282
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # declares a queue with max size 2
    q = Queue(2)
    # checks if queue is empty
    assert q.empty()
    # checks size of queue
    assert q.qsize() == 0
    q.put(1)
    # checks if queue is not empty
    assert not q.empty()
    # checks size of queue
    assert q.qsize() == 1
    q.put(2)
    # checks if queue is full
    assert q.full()
    # checks size of queue
    assert q.qsize() == 2
    # Remove and return an item from the queue.
    q.get_nowait()
    # checks size of queue
    assert q.qsize() == 1
    # Remove and return an item from the queue.
    q.get_nowait()
    # checks if queue is empty

# Generated at 2022-06-24 09:18:07.718651
# Unit test for method empty of class Queue
def test_Queue_empty():
    queue = Queue()
    # Case 1 - When no item is present
    assert queue.empty() == True
    # Case 2 - When some items are present
    queue._put(1)
    assert queue.empty() == False
# Test funtion for method full of class Queue

# Generated at 2022-06-24 09:18:08.895125
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    q.join()


# Generated at 2022-06-24 09:18:14.281890
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    assert q.qsize() == 2

# Generated at 2022-06-24 09:18:20.023785
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:18:24.095923
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False
    q.get_nowait()
    assert q.empty() == True


# Generated at 2022-06-24 09:18:26.520797
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    instances = [Queue([])]
    for i in instances:
        assert isinstance(i.__aiter__(), itertools.chain)


# Generated at 2022-06-24 09:18:37.181910
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize = 1)
    assert q.maxsize == 1
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    try:
        q.put_nowait(1)
    except QueueFull:
        assert False
    assert q.maxsize == 1
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == True
    try:
        q.put_nowait(0)
    except QueueFull:
        assert True
    assert q.get_nowait() == 1
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    assert q.qsize() == 1
    assert q.full() == True
    q.task_done

# Generated at 2022-06-24 09:18:44.035192
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    def wrapper(q):
        assert q.qsize() == 1
        # item = q.get_nowait()
        # return item
        return q.get_nowait()

    q = Queue(maxsize=2)
    q.put("foo")
    print("foo")
    assert wrapper(q) == "foo"
    print("end")


# Generated at 2022-06-24 09:18:51.296998
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)
    # try to insert a new element
    # this should raise QueueFull
    try:
        q.put_nowait(2)
    except QueueFull:
        return True
    return False

# This statment checks if the function test_Queue_put_nowait passes 
# or not
assert_(test_Queue_put_nowait, True)

 

# Generated at 2022-06-24 09:19:03.347449
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    items = []
    async def producer():
        for i in range(3):
            await q.put(i)
            items.append(i)
            await gen.sleep(0)
    async def consumer():
        while True:
            item = await q.get()
            try:
                await gen.sleep(0)
            finally:
                q.task_done()
    # Start consumer without waiting (since it never finishes).
    # 无限消费
    ioloop.IOLoop.current().spawn_callback(consumer)
    # Wait for producer to put all tasks.
    ioloop.IOLoop.current().run_sync(producer)
    assert set(range(3)) == set(items)
    # Wait for consumer to finish all tasks.
   

# Generated at 2022-06-24 09:19:04.732451
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull()

_ItemOrFuture = Union[_T, "Future[_T]"]
_QueueEntry = Tuple[int, _ItemOrFuture]


# Generated at 2022-06-24 09:19:11.728586
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

#test_PriorityQueue()



# Generated at 2022-06-24 09:19:14.830487
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    q.empty()

# Generated at 2022-06-24 09:19:27.232521
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1.test case for Queue_put_nowait
    q = Queue(maxsize=2)
    q.__put_internal(0)
    try:
        q.put_nowait(1)
    except QueueFull:
        print("Put 1 error.")
    else:
        print("Put 1 success.")
    try:
        q.put_nowait(2)
    except QueueFull:
        print("Put 2 error.")
    else:
        print("Put 2 success.")

    # 2.test case for Queue_put_nowait
    q = Queue(maxsize=0)
    try:
        q.put_nowait(0)
    except QueueFull:
        print("Put 0 error.(should not happen)")

# Generated at 2022-06-24 09:19:29.579940
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(3)
    q.qsize()
    q.maxsize
    q.empty()
    q.full()

