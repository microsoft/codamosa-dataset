

# Generated at 2022-06-24 09:09:34.731480
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import tornado
    import tornado.queues
    import tornado.testing
    import tornado.web
    import tornado.platform.asyncio
    import datetime
    import functools
    import logging
    import unittest
    from tornado import gen

    from tornado import concurrent
    from tornado import process
    from tornado.testing import AsyncHTTPTestCase, gen_test, bind_unused_port
    from tornado.test.util import unittest as _unittest  # type: ignore
    from tornado.httpclient import HTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.testing import AsyncTestCase, ExpectLog
    from tornado.web import RequestHandler
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import collections

# Generated at 2022-06-24 09:09:36.461042
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    """Test for __anext__ of class _QueueIterator"""
    pass
    # TODO
    return



# Generated at 2022-06-24 09:09:47.151586
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    q._queue=[1,2]
    q._unfinished_tasks = 1
    q._finished = Event()
    q_size = len(q._queue)

    # test two cases
    # 1. if putters waiting while the queue is full, a putter will be removed and the item is delivered to the getter.
    # 2. otherwise, a item will be removed and returned.
    result = q.get_nowait()
    assert result == 1 and len(q._queue) == q_size-1 and q._unfinished_tasks == 0

# Generated at 2022-06-24 09:09:50.745047
# Unit test for method empty of class Queue
def test_Queue_empty():
    value = Queue().empty()
    assert value == True
    return value


# Generated at 2022-06-24 09:09:55.149362
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    it = _QueueIterator(q)
    assert it.__anext__().result() == 1
    assert it.__anext__().result() == 2
    assert it.__anext__().result() == 3
    assert False


# Generated at 2022-06-24 09:10:06.133641
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q.empty()
    q.full()
    q.maxsize
    q.qsize()
    s = q.put(1)
    s = q.put_nowait(1)
    1 in q
    q.get()
    q.get_nowait()
    q.task_done()
    q.join()
    list(q)
    list(q)
    q.__aiter__()
    q.__aiter__()
    q.__str__()
    q.__repr__()
    q.__repr__()
    q.__repr__()


# Generated at 2022-06-24 09:10:08.695557
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q : Queue = Queue()
    # q.put(123)

    for i in _QueueIterator(q):
        pass
    # assert (await i) == 123, 'test__QueueIterator'



# Generated at 2022-06-24 09:10:15.726990
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Initialization
    q = Queue(maxsize=2)
    # Test the case when no free slot is immediately available,
    # Raise the exception QueueFull.
    with pytest.raises(QueueFull):
        q.put_nowait(0)
        q.put_nowait(1)
        q.put_nowait(2)
    # Test the case when there is an available slot
    q.put_nowait(3)
    assert q.qsize() == 1


# Generated at 2022-06-24 09:10:23.091862
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    for i in range(5):
        q.put_nowait(i)
    q_iter = q.__aiter__()
    assert q_iter.__anext__() == i
    q_iter.q.task_done()
    # from the implementation of gen.Return, the following statement will raise
    # StopIteration:
    q_iter.__anext__()


# Generated at 2022-06-24 09:10:25.139371
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:10:26.555626
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:10:28.265693
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass


# Generated at 2022-06-24 09:10:32.755495
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    a = Queue()
    a.put_nowait(1)
    assert a.qsize() == 1
    a.put_nowait(2)
    assert a.qsize() == 2

    b = Queue(3)
    for i in range(3):
        b.put_nowait(i)
    assert b.qsize() == 3


# Generated at 2022-06-24 09:10:34.437529
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    result = str(q)
    expected = "<tornado.queues.Queue maxsize=2 queue=deque([])>"
    assert result == expected



# Generated at 2022-06-24 09:10:37.907293
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    q.get_nowait()
    assert not q.full()
    q.get_nowait()
    assert not q.full()


# Generated at 2022-06-24 09:10:39.568074
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    """Unit test for constructor of class QueueEmpty."""
    qe = QueueEmpty()
    assert qe == None
    return qe



# Generated at 2022-06-24 09:10:45.308877
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=3)
    assert q.maxsize == 3
    assert q._maxsize == 3
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()



# Generated at 2022-06-24 09:10:48.646587
# Unit test for method put of class Queue
def test_Queue_put():
    try:
        Queue(1).put(1)
        return True
    except:
        return False
print ("(test_Queue_put) " + str(test_Queue_put()))


# Generated at 2022-06-24 09:10:55.869017
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.concurrent import Future
    my_getters = [Future()]
    my_putters = [(1, Future())]
    my_queue = Queue(maxsize=2)
    my_queue._getters = my_getters
    my_queue._putters = my_putters
    my_queue._unfinished_tasks = 3
    m = my_queue._format()
    print(m)

# Generated at 2022-06-24 09:10:58.443249
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    maxsize = 0
    a = Queue(maxsize)
    result = a.__str__()
    assert result == '<Queue maxsize=0>'



# Generated at 2022-06-24 09:11:02.528364
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()
    assert q.qsize() == 0
    
    

# Generated at 2022-06-24 09:11:07.245327
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
  t=self
  t.assertIs(t.x,t.y)
  t.assertIsNot(t.x,t.z)
  t.assertIs(t.x,t.x)
  t.assertIsNot(t.x,t.y)
  t.assertTrue(t.x)



# Generated at 2022-06-24 09:11:10.594287
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    q.full()
    q1 = Queue()
    q1.put_nowait(1)
    q1.full()
    q2 = Queue(1)
    q2.full()

# Generated at 2022-06-24 09:11:12.140593
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    pass


# Generated at 2022-06-24 09:11:14.264789
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    ioloop.IOLoop.current().run_sync(lambda:lambda:None)

# Generated at 2022-06-24 09:11:18.302976
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        q = Queue()
        q.get_nowait()
    except QueueEmpty as e:
        assert isinstance(e, Exception)
        assert str(e)
        assert repr(e)



# Generated at 2022-06-24 09:11:22.969532
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put("say")
    q.put("hello")
    assert q.qsize() == 2
    assert q.get_nowait() == "hello"
    q.task_done()
    assert q.get_nowait() == "say"

# Generated at 2022-06-24 09:11:30.268309
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    from tornado.ioloop import IOLoop
    async def async_function(arg):
        await asyncio.sleep(0.5)
        return arg
    async def async_function():
        await asyncio.sleep(0.5)
    async def main():
        q = Queue(maxsize=5)
        for i in range(5):
            await q.put
        await q.join()
        print('Done')
    IOLoop.current().run_sync(main)
test_Queue_join()


# Generated at 2022-06-24 09:11:34.411599
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():  # pragma: no cover
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:11:44.624258
# Unit test for method join of class Queue
def test_Queue_join():
    import unittest
    import logging
    import threading
    import time
    import tornado.gen
    import tornado.ioloop
    from tornado.queues import Queue
    from typing import Dict, Any

    class QueueTestCase(unittest.TestCase):
        def setUp(self):
            self.MAX_SIZE = 10
            self.COUNT = 100
            self.tearDown()

        def tearDown(self):
            self.queue = None

        def test_put_get(self):
            self.queue = Queue(maxsize=self.MAX_SIZE)
            for i in range(self.COUNT):
                self.queue.put_nowait(i)
            self.assertEqual(self.queue.qsize(), self.MAX_SIZE)

# Generated at 2022-06-24 09:11:48.222703
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    # TODO: raise error: TypeError("maxsize can't be None")
    # TypeError: maxsize can't be None
    q = Queue(maxsize=None)


# Generated at 2022-06-24 09:11:50.489107
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize = 10)
    a = q.maxsize
    assert(a == 10)
    assert(type(a) == int)


# Generated at 2022-06-24 09:11:56.298496
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import doctest
    import tornado.queues
    from tornado.queues import Queue

    # Skip annoying DOCSTRING_ELLIPSIS warnings
    _doctest_warnings = doctest.ELLIPSIS
    doctest.ELLIPSIS = False

    def load_tests(loader, tests, ignore):
        tests.addTests(doctest.DocTestSuite(tornado.queues))
        return tests

    doctest.ELLIPSIS = _doctest_warnings
    return load_tests



# Generated at 2022-06-24 09:11:57.878278
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:12:07.957301
# Unit test for method full of class Queue
def test_Queue_full():
    "@gen.coroutine"
    def _test_Queue_full(q: "Queue[_T]", expected: bool) -> None:
        actual = q.full()
        assert actual == expected, "%r != %r" % (actual, expected)

    q = Queue()
    yield _test_Queue_full(q, False)

    q.maxsize = 1
    yield _test_Queue_full(q, False)
    yield _test_Queue_full(q, False)

    q.maxsize = 0
    yield _test_Queue_full(q, False)
    yield _test_Queue_full(q, False)

    q = Queue(maxsize=0)
    yield _test_Queue_full(q, False)
    yield _test_Queue_full(q, False)

# Generated at 2022-06-24 09:12:19.309294
# Unit test for method put of class Queue
def test_Queue_put():
    import random
    from tornado.testing import AsyncTestCase
    from tornado.locks import Lock

    class TestPut(AsyncTestCase):
        def setUp(self):
            super(TestPut, self).setUp()
            self.lock = Lock()
            self.queue = Queue()
            self.num = 0
            self.is_put = False
            self.num = random.randint(0, 1000)

        def handle_get(self) -> None:
            self.num = self.queue.get_nowait()
            self.lock.release()

        def handle_put(self) -> None:
            self.queue.put(self.num)
            self.is_put = True

        def handle_put_all(self) -> None:
            self.queue.put(self.num)


# Generated at 2022-06-24 09:12:20.311208
# Unit test for method empty of class Queue
def test_Queue_empty():
    assert Queue().empty()


# Generated at 2022-06-24 09:12:26.752498
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()

    print("q.maxsize: ", q.maxsize) # 0
    print("q.qsize(): ", q.qsize()) # 0

    print("q.empty(): ", q.empty()) # True
    print("q.full(): ", q.full()) # False

    try:
        q.qsize = 10
    except ValueError as e:
        print("qsize can't be negative")



# Generated at 2022-06-24 09:12:30.724801
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    x = Queue()
    x.__put_internal(3)
    x.__put_internal(4)
    x.__put_internal(5)
    assert x.qsize() == 3
test_Queue_put_nowait()


# Generated at 2022-06-24 09:12:32.008308
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert str(e) == ""



# Generated at 2022-06-24 09:12:36.573882
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_PriorityQueue()

# Generated at 2022-06-24 09:12:41.099628
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    print(q.maxsize)
    print(q.qsize())
    print(q.empty())
    print(q.full())


# Generated at 2022-06-24 09:12:50.366745
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    q = Queue() # initializing queue
    # putting items inside queue
    # checking the size of queue
    # checking whether the queue is empty
    # checking whether the queue is full
    f1 = Future() # creating Future object
    # putting the future object inside queue
    # getting the popped element
    # checking whether the queue is full
    # checking whether the queue is empty
    # f is the future object
    # checking whether the future object's result is None
    f2 = Future()
    # putting the future object inside queue
    # getting the popped element
    # checking whether the queue is full
    # checking whether the queue is empty
    # f is the future object
    # checking whether the future object's result is None

# Generated at 2022-06-24 09:12:56.550879
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert str(q) == '<Queue maxsize=2 queue=deque([])>'
    q.put_nowait(4)
    q.put_nowait(7)
    assert str(q) == '<Queue maxsize=2 queue=deque([4, 7])>'

    assert repr(q) == '<Queue at 0x%x maxsize=2 queue=deque([4, 7])>' % id(q)
    q.put_nowait(9)
    assert repr(q) == '<Queue at 0x%x maxsize=2 queue=deque([4, 7, 9])>' % id(q)

    q = Queue(maxsize=2)
    q.put_nowait(4)

# Generated at 2022-06-24 09:13:00.893475
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    if Queue.__str__() == "<class 'tornado.queues.Queue'>":
        print('test_Queue___str__: success')
        return True
    else:
        print('test_Queue___str__: failed')
        return False

# Generated at 2022-06-24 09:13:03.283128
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    with pytest.raises(QueueEmpty, message='QueueEmpty constructor'):
        raise QueueEmpty()


# Generated at 2022-06-24 09:13:12.240402
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(10)
    q1 = Queue(10)
    q2 = Queue(10)
    q3 = Queue(10)
    q4 = Queue(10)
    q5 = Queue(10)
    q6 = Queue(10)
    q7 = Queue(10)
    q8 = Queue(10)
    q9 = Queue(10)
    q.put(0)
    q.put(1)
    q1.put_nowait(1)
    q2.put_nowait(2)
    q3.put_nowait(3)
    q4.put_nowait(4)
    q5.put_nowait(5)
    q6.put_nowait(6)
    q7.put_nowait(7)


# Generated at 2022-06-24 09:13:15.638748
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert not q.full()
    q = Queue(maxsize = 1)
    assert not q.full()
    q.put(1)
    assert q.full()
    q.get()
    assert not q.full()



# Generated at 2022-06-24 09:13:26.694712
# Unit test for method empty of class Queue
def test_Queue_empty():
    import random
    import unittest

    rand = random.Random()
    rand.seed()

    for empty in (True, False):
        for maxsize in (-1, 0, 1, 10):
            for n in (0, 1, maxsize if maxsize != 0 else 10):
                q = Queue(maxsize=maxsize)
                try:
                    for i in range(n):
                        q.put_nowait(rand.randint(0, n))
                except QueueFull:
                    self.assertTrue(maxsize >= 0 and n >= maxsize)
                    continue
                self.assertEqual(q.empty(), empty)



# Generated at 2022-06-24 09:13:29.270587
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    # q.put(1)
    print(q)



# Generated at 2022-06-24 09:13:39.687431
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    q.task_done()
    q.task_done()
    q.join()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 1
    q.put_nowait(1)

# Generated at 2022-06-24 09:13:46.643041
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=3)
    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:13:47.972295
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty(1)



# Generated at 2022-06-24 09:13:53.759503
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(AsyncTestCase):

        def test_foo(self):
            q = Queue()
            self.assertEqual(q.qsize(), 0)
            q.put('foo')
            self.assertEqual(q.qsize(), 1)


    Foo().test_foo()

# Generated at 2022-06-24 09:13:57.331049
# Unit test for method put of class Queue
def test_Queue_put():
    q=Queue()
    q.put_nowait(1)
    # assert q.qsize()==1
    t=q.put(1)
    print('queue: ', q)
    print('queue.qsize()', q.qsize())
    # assert t == 1


# Generated at 2022-06-24 09:14:10.207788
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:14:13.011033
# Unit test for method get of class Queue
def test_Queue_get():
    result = Queue().get()
    assert result == True, 'test_Queue_get() failed'
    print('test_Queue_get() passed')

# Generated at 2022-06-24 09:14:22.117073
# Unit test for method put of class Queue

# Generated at 2022-06-24 09:14:24.430446
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull(2,4,5)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 09:14:27.711968
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q=Queue()
    item=1
    q.empty() #return False
    q.put_nowait(item)
    assert q.qsize()==1
    assert q._queue.popleft()==item

# Generated at 2022-06-24 09:14:32.135354
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:43.611224
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # create an empty LifoQueue instance 
    q = LifoQueue()
    # add 4 elements to the LifoQueue 
    for i in range(4):
        q.put(i)
    # check that the LifoQueue instance has size 4
    assert q.qsize() == 4
    # show that the LifoQueue instance is not empty 
    assert not q.empty()
    # show that the LifoQueue instance is not full 
    assert not q.full()
    # check that the LifoQueue instance is not empty
    q.get_nowait()
    # check that the LifoQueue instance is not empty 
    q.get_nowait()
    # check that the LifoQueue instance is not empty
    q.get_nowait()
    # check that the LifoQueue instance is not empty
    q.get

# Generated at 2022-06-24 09:14:55.085062
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert(q.empty() == True)
    assert(q.qsize() == 0)
    assert(q.full() == False)
    q.put_nowait(1)
    assert(q.empty() == False)
    assert(q.qsize() == 1)
    assert(q.full() == False)
    q.put_nowait(2)
    assert(q.empty() == False)
    assert(q.qsize() == 2)
    assert(q.full() == False)
    q.get_nowait()
    assert(q.empty() == False)
    assert(q.qsize() == 1)
    assert(q.full() == False)
    q.get_nowait()
    assert(q.empty() == True)

# Generated at 2022-06-24 09:15:06.261649
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    maxsize = 0
    _queue = None
    _getters = [Future()]
    _putters = []
    _unfinished_tasks = 0
    _finished = Event()
    _finished.set()

    #Create a new queue
    queue = Queue(maxsize)
    queue._queue = _queue
    queue._getters = _getters
    queue._putters = _putters
    queue._unfinished_tasks = _unfinished_tasks
    queue._finished = _finished

    # The queue should be a string that looks like this
    result = "<Queue at 0x7f9a8b1a4250 maxsize=0 queue=[] getters[1]>"

    # The result of the method __repr__ should be the same as the expected value

# Generated at 2022-06-24 09:15:11.943069
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:15:23.398415
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(0)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)
    q.put_nowait(0)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([0])>" % id(q)
    q.put_nowait(1)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([0, 1])>" % id(q)
    q.get()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([1])>" % id(q)
    q.task_done()

# Generated at 2022-06-24 09:15:32.875110
# Unit test for method get of class Queue
def test_Queue_get():
    # Asynchronous context manager.
    # coroutine
    async def foo(q: Queue[int]):
        await q.put(7)
        await gen.sleep(0)
        await q.put(9)
        await gen.sleep(0)

    async def bar(q: Queue[int]):
        await q.put(10)
        await gen.sleep(0)
        await q.put(12)
        await gen.sleep(0)

    q = Queue()
    loop = ioloop.IOLoop.current()

    loop.add_callback(foo, q)
    loop.add_callback(bar, q)

    # Asynchronous iterator.

# Generated at 2022-06-24 09:15:37.325303
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=1)
    assert q.empty()
    q.put_nowait(2)
    assert not q.empty()
    q.get_nowait()
    assert q.empty()



# Generated at 2022-06-24 09:15:39.146261
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert(q.qsize() == 0)



# Generated at 2022-06-24 09:15:42.400484
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=10)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.get_nowait() == 1
    assert q.qsize() == 0


# Generated at 2022-06-24 09:15:51.383258
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)



    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q

# Generated at 2022-06-24 09:16:04.296527
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:06.098969
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__(): pass


# Generated at 2022-06-24 09:16:08.406619
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(0)
    i = _QueueIterator(q)
    assert isinstance(i, _QueueIterator)


# Generated at 2022-06-24 09:16:09.549008
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    pass

# Generated at 2022-06-24 09:16:11.872295
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue
    q = Queue(1)
    print(str(q))



# Generated at 2022-06-24 09:16:17.319545
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put("A")
    assert q.maxsize == 0
    assert q.empty() == False
    assert q.full() == False
    assert q.get_nowait() == "A"
    assert q.qsize() == 0
    assert q.task_done() == None


# Generated at 2022-06-24 09:16:23.986590
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
	from io import BytesIO
	f = BytesIO()
	self = Queue(maxsize=2)

	self._queue = [(1,), (2,)]
	self._getters = collections.deque()
	self._putters = collections.deque()
	self._unfinished_tasks = 0
	self._finished = ()


# Generated at 2022-06-24 09:16:25.876908
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    man = Queue(maxsize=0)
    print(man._format())
    print(man)
    print(repr(man))



# Generated at 2022-06-24 09:16:33.856958
# Unit test for method get of class Queue
def test_Queue_get():
  q = Queue()

  f1 = Future()
  f2 = Future()
  f3 = Future()
  f4 = Future()
  q._getters = collections.deque([f1, f2, f3, f4])
  print(q.qsize())
  print(q.empty())
  print(q.full())
  print(q._getters)
  q.get()
  print(q._getters)
  q.get_nowait()
  print(q._getters)
  q.task_done()
  print("task done")
  q.join()
  print("queue finished")
  print(q)



# Generated at 2022-06-24 09:16:35.504082
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    pass
__anext__ = __next__ = __anext__  # type: ignore



# Generated at 2022-06-24 09:16:45.312248
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    def _inner_test(q):
        assert repr(q) == '<Queue at 0x%x maxsize=%r queue=%r>' % (
            id(q), q.maxsize, q._queue,
        )
        assert str(q) == '<Queue %r>' % q._format()
        assert ' ' not in repr(q)
        assert ' ' not in str(q)

    q = Queue()  # type: ignore
    _inner_test(q)
    q = Queue(1)  # type: ignore
    _inner_test(q)
    q._queue.append('a')
    _inner_test(q)
    q._getters.append(Future())
    q._putters.append(('b', Future()))
    q._unfinished_tasks = 42


# Generated at 2022-06-24 09:16:57.169698
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:01.828669
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:17:13.015710
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    
    item1 = q.get_nowait()
    item2 = q.get_nowait()
    item3 = q.get_nowait()
    assert item1 == 1
    assert item2 == 2
    assert item3 == 3
    
    q = Queue()
    q.put_nowait(4)
    q.put_nowait(5)
    q.put_nowait(6)
    for item in q:
        print(item)

test_Queue___aiter__()


# Generated at 2022-06-24 09:17:15.305119
# Unit test for method full of class Queue
def test_Queue_full():
        q = Queue(maxsize=2)
        q.put_nowait(1)
        q.put_nowait(2)

        assert q.full() == True


# Generated at 2022-06-24 09:17:21.129286
# Unit test for method put of class Queue
def test_Queue_put():
    flag=0
    if flag==0:
        q = Queue(maxsize=2)
        #f1=Future()
        #f2=Future()
        f1=0
        f2=0
        try:
            q.put_nowait(f1)
        except QueueFull:
            print ("QueueFull should not be raised")
        try:
            q.put_nowait(f2)
        except QueueFull:
            print ("QueueFull should not be raised")
        print ("TEST PASS")
    elif flag==1:
        q = Queue(maxsize=2)
        f1=0
        f2=0
        f3=0
        try:
            q.put_nowait(f1)
        except QueueFull:
            print ("QueueFull should not be raised")

# Generated at 2022-06-24 09:17:31.712101
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    def run_test():
        q = Queue(maxsize=2)
        assert q.qsize() == 0
        q.put_nowait(1)
        assert q.qsize() == 1
        q.put_nowait(2)
        assert q.qsize() == 2
        q.get_nowait()
        assert q.qsize() == 1
        q.get_nowait()
        assert q.qsize() == 0
        q.put_nowait(3)
        assert q.qsize() == 1
    import time
    import threading
    time.sleep(1)
    thread_0 = threading.Thread(target=run_test)
    thread_0.start()
    time.sleep(1)


# Generated at 2022-06-24 09:17:36.301125
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0, "qsize returns wrong value"
    q.put_nowait(1)
    assert q.qsize() == 1, "qsize returns wrong value"

# Generated at 2022-06-24 09:17:41.182891
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:17:52.397472
# Unit test for method get of class Queue
def test_Queue_get():
    async def async_test() -> None:
        q = Queue()

        async def test_get_nowait() -> None:
            q.put_nowait(1)
            assert q.get_nowait() == 1

        async def test_get_timeout() -> None:

            def timeout() -> None:
                q.put_nowait(1)

            q.io_loop.add_timeout(q.io_loop.time() + 0.01, timeout)
            assert await q.get(timeout=0.1) == 1

        await test_get_nowait()
        await test_get_timeout()

    ioloop.IOLoop.current().run_sync(async_test)



# Generated at 2022-06-24 09:17:59.154526
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import tornado
    import asyncio
    @tornado.gen.coroutine
    def main():
        q = tornado.queues.Queue()
        print(q.qsize())
        q.put(1)
        q.put(2)
        yield q.join()
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(main())
    finally:
        loop.close()

# Generated at 2022-06-24 09:18:00.066928
# Unit test for constructor of class QueueFull
def test_QueueFull():
    pass


# Generated at 2022-06-24 09:18:03.460940
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = Queue()
    print(q)
    try:
        q.put_nowait()
    except QueueFull as e:
        print(e)



# Generated at 2022-06-24 09:18:07.697114
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    l = LifoQueue()
    l.put(3)
    l.put(2)
    l.put(1)
    print(l.get_nowait())
    print(l.get_nowait())
    print(l.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:18:13.678931
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    queue = PriorityQueue()
    assert(queue.empty() == True)
    assert(queue.full() == False)
    queue.put((0, 'test'))
    assert(queue.empty() == False)
    assert(queue.full() == False)
    queue.get()
    assert(queue.empty() == True)



# Generated at 2022-06-24 09:18:17.659136
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    f = it.__anext__()
    assert isinstance(f, Future)
    assert not f.done()
    ioloop.IOLoop.current().add_callback(q.put_nowait, 1)
    assert f.result() == 1
    f = it.__anext__()
    assert isinstance(f, Future)
    ioloop.IOLoop.current().add_callback(q.put_nowait, 2)
    assert f.result() == 2



# Generated at 2022-06-24 09:18:23.693620
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    async def main():
        await q.put(1)
        assert q.get_nowait() == 1
        try:
            q.get_nowait()
        except QueueEmpty:
            pass
        else:
            assert False
    ioloop.IOLoop.current().run_sync(main)

test_Queue_get_nowait()

# Generated at 2022-06-24 09:18:25.703071
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert issubclass(QueueEmpty, Exception)
    assert str(QueueEmpty()) == 'Queue is empty'
    assert str(QueueEmpty('error message')) == 'error message'



# Generated at 2022-06-24 09:18:27.075203
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0


# Generated at 2022-06-24 09:18:36.666094
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # start loop
    io_loop = ioloop.IOLoop.current()
    io_loop.start()

    # create a queue with maxsize
    q = Queue(maxsize=2)

    # test put_nowait to put a item
    q.put_nowait(1)
    assert q.qsize() == 1

    # test put_nowait to put a item
    q.put_nowait(2)
    assert q.qsize() == 2

    # test raise QueueFull
    try:
        q.put_nowait(3)
    except QueueFull:
        assert True
    else:
        assert False
        
    # stop loop
    io_loop.stop()

# Generated at 2022-06-24 09:18:39.795050
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == '<Queue maxsize=0 queue=deque([])>'

# Generated at 2022-06-24 09:18:45.174602
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull as e:
        print("Got exception:", e)
    q.qsize()



# Generated at 2022-06-24 09:18:47.750031
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q_iterator = _QueueIterator(q)
    assert q_iterator.q is q


# Generated at 2022-06-24 09:18:57.997274
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado.testing import AsyncTestCase, gen_test

    class TestQueue(AsyncTestCase):
        def setUp(self):
            super(TestQueue, self).setUp()
            self.q = Queue()

        @gen_test
        def test_qsize(self):
            self.assertTrue(self.q.qsize() == 0, "fail to initialize q.qsize")
            self.q.put(1)
            yield self.q.join()
            self.assertTrue(self.q.qsize() == 1, "fail to join q.qsize")
            self.q.get()
            self.assertTrue(self.q.qsize() == 0, "fail to get q.qsize")
            self.q.put_nowait(1)

# Generated at 2022-06-24 09:19:01.052376
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=5)
    assert q.qsize() == 0
    for i in range(5):
        q.put_nowait(i)
    assert q.qsize() == 5


# Generated at 2022-06-24 09:19:02.397152
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    q.put_nowait(2)

# Generated at 2022-06-24 09:19:05.257765
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    Q = LifoQueue()
    assert Q.qsize() == 0
    assert Q.empty() == True
    assert Q.full() == False
    assert Q.maxsize == 0

test_LifoQueue()

# Generated at 2022-06-24 09:19:13.976178
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    _T: Any
    from tornado.ioloop import IOLoop
    from tornado import gen

    @gen.coroutine
    def _(self: _QueueIterator[_T], get_func) -> _T:
        val = yield get_func()
        raise gen.Return(val)

    ioloop_ = IOLoop()
    q = Queue(1)
    q.put_nowait(1)
    it = _QueueIterator(q)
    ioloop_.run_sync(lambda: it.__anext__()) == 1


# Generated at 2022-06-24 09:19:20.044948
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.get_nowait() == 3
    assert q.get_nowait() == 2
    assert q.get_nowait() == 1

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:19:31.174103
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.gen import sleep
    from tornado.testing import AsyncTestCase, gen_test
    import unittest
    class TestQueue(_QueueIterator, Queue):
        def __init__(self, maxsize=0):
            super(TestQueue, self).__init__(maxsize=maxsize)
    class TestQueue___repr__(AsyncTestCase):
        def test_Queue___repr__(self):
            q = TestQueue(maxsize=2)
            @gen_test
            async def consumer():
                async for item in q:
                    try:
                        print('Doing work on %s' % item)
                        await sleep(0.01)
                    finally:
                        q.task_done()