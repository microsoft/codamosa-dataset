

# Generated at 2022-06-24 09:09:34.218738
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception:
        pass


# Generated at 2022-06-24 09:09:38.101455
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "should raise"

# Generated at 2022-06-24 09:09:47.440935
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
  q = Queue()
  assert q.qsize()==0
  it = _QueueIterator(q)
  assert q.qsize()==0
  q.put_nowait(1)
  assert q.qsize()==1
  q.put_nowait(2)
  assert q.qsize()==2
  yield from gen.sleep(0)
  assert q.qsize()==2
  assert (yield from it.__anext__())==1
  assert q.qsize()==1
  assert (yield from it.__anext__())==2
  assert q.qsize()==0



# Generated at 2022-06-24 09:09:55.355302
# Unit test for method get of class Queue
def test_Queue_get():
    # Create an IOLoop
    io_loop = ioloop.IOLoop.current()
    # Create a queue from the current IOLoop
    q = Queue(maxsize=2)
    # Create an async generator that fetches items from the queue
    async def consumer():
        # Use async for to iterate over the queue
        async for item in q:
            # Do some work
            try:
                print("Doing work on {}".format(item))
                await gen.sleep(0.01)
            finally:
                # Signal that the task is done
                q.task_done()
    # Create a coroutine that loops over a range, and puts items into the queue

# Generated at 2022-06-24 09:09:58.677224
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        assert e.__class__ is not QueueFull


# Generated at 2022-06-24 09:10:01.002644
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('This is a test')
    except QueueFull:
        pass



# Generated at 2022-06-24 09:10:10.774563
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Test for method __str__( ... ) of class Queue
    # Test for method __str__( ... ) of class Queue
    # Test for method __str__( ... ) of class Queue
    # Test for method __str__( ... ) of class Queue
    # Test for method __str__( ... ) of class Queue
    q = Queue(10)
    assert str(q) == "<Queue maxsize=10 queue=deque([]) getters[0] putters[0] tasks=0>"
    q = Queue(10)
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=10 queue=deque([1]) getters[0] putters[0] tasks=1>"
    return



# Generated at 2022-06-24 09:10:11.734733
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    assert Queue().qsize() == 0



# Generated at 2022-06-24 09:10:13.874873
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    assert isinstance(qe, Exception)



# Generated at 2022-06-24 09:10:26.051543
# Unit test for method __str__ of class Queue
def test_Queue___str__():
  from unittest import mock
  from unittest import mock
  from unittest import mock
  from unittest import mock

  q = Queue(maxsize=1)
  assert str(q) == '<Queue maxsize=1>'
  q.put_nowait(1)
  assert str(q) == '<Queue maxsize=1 queue=[1]>'
  mock_getters = mock.Mock()
  mock_getters.__len__ = mock.Mock(return_value=1)
  mock_putters = mock.Mock()
  mock_putters.__len__ = mock.Mock(return_value=1)
  q._getters = mock_getters
  q._putters = mock_putters
  q._unfinished_tasks = 3

# Generated at 2022-06-24 09:10:33.033893
# Unit test for method join of class Queue
def test_Queue_join():
    import datetime

    import tornado.gen
    import tornado.ioloop
    import tornado.queues

    queue = tornado.queues.Queue()
    for i in range(5):
        queue.put(i)

    @tornado.gen.coroutine
    def task():
        yield tornado.gen.sleep(0.01)

    @tornado.gen.coroutine
    def consumer():
        while True:
            try:
                i = yield queue.get()
                yield task()
                print("Consuming item %d" % i)
            finally:
                queue.task_done()

    torna

# Generated at 2022-06-24 09:10:33.692408
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    PQ = PriorityQueue()

# Generated at 2022-06-24 09:10:36.037862
# Unit test for constructor of class Queue
def test_Queue():
    assert Queue().qsize() == 0
    assert Queue().maxsize == 0
    q = Queue()
    assert not q.empty()


# Generated at 2022-06-24 09:10:40.151595
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize = 2)
    assert not q.full()
    q.put_nowait(1)
    assert not q.full()
    q.put_nowait(2)
    assert q.full()
    q.get_nowait()
    assert not q.full()
    q.get_nowait()
    assert not q.full()


# Generated at 2022-06-24 09:10:51.916771
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.test.util import unittest
    from tornado.test.util import AsyncTestCase
    from tornado.gen import coroutine
    import datetime
    import io
    import time
    import unittest
    from time import time as time_time, sleep as time_sleep
    from typing import Dict
    # TODO: remove wrapper
    from tornado.testing import gen_test
    from tornado.test.util import AsyncTestCase
    from tornado.gen import coroutine, Return
    from datetime import timedelta, datetime, time
    from time import time as time_time
    from typing import Any, Dict, Iterable, List, Optional, Tuple
    from tornado.locks import Event

    from tornado import gen
    from tornado.gen import TimeoutError
    from tornado.ioloop import IOLoop

# Generated at 2022-06-24 09:10:54.604862
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    for i in range(3):
        q.put_nowait(i)
    
    it = _QueueIterator(q)
    for i in range(3):
        assert i == ioloop.IOLoop.current().run_sync(it.__anext__)



# Generated at 2022-06-24 09:10:56.096403
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    _queue1 = Queue()
    _queue2 = Queue()
    print(Queue())
    print(Queue())
    print(Queue())


# Generated at 2022-06-24 09:10:58.289055
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass



# Generated at 2022-06-24 09:11:05.557716
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
test_PriorityQueue()



# Generated at 2022-06-24 09:11:08.801881
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    assert not q.empty()
    assert not q.full()
    assert q.qsize() == 0
    assert q.maxsize == 0
    q.task_done()


# Generated at 2022-06-24 09:11:11.901634
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    Queue._init = lambda self : None
    Queue._format = lambda self : ""

    q = Queue()
    repr(q)


# Generated at 2022-06-24 09:11:15.392495
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    future = q.get(timeout=0)
    assert future.done()
    assert isinstance(future.exception(), QueueEmpty)



# Generated at 2022-06-24 09:11:18.214032
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    m = Queue(3)
    assert m.qsize() == 0
    assert m.empty() == True

# Generated at 2022-06-24 09:11:29.667331
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=10)
    q = Queue(10)
    try:
        q = Queue(10, 12)
    except TypeError:
        pass
    try:
        q = Queue(10, 12, 22)
    except TypeError:
        pass
    try:
        q = Queue(maxsize=-1)
    except ValueError:
        pass

    q = Queue(maxsize=0)
    q.put_nowait(10)
    q = Queue(maxsize=10)
    for i in range(10):
        q.put_nowait(i)
    try:
        q.put_nowait(11)
    except QueueFull:
        pass

    q = Queue(maxsize=0)
    q.put(10)

# Generated at 2022-06-24 09:11:36.046700
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import unittest
    import tornado
    import tornado.concurrent
    import tornado.ioloop
    import tornado.queues

    class _IOLoopTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()

        def tearDown(self):
            self.io_loop.close(all_fds=True)

    class _GlobalQueueFixture():
        def __init__(self):
            self.q = tornado.queues.Queue()
            self.q._queue = [2, 3, 4]


# Generated at 2022-06-24 09:11:46.779007
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    try:
        q.put_nowait(4)
    except QueueFull:
        assert(True)
    assert(q.full() == True)

    # Test for put_nowait of a future
    print("finished")
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    f = Future()
    try:
        q.put_nowait(f)
    except :
        assert(True)
    print("finished")
    assert(q.full() == True)


# Generated at 2022-06-24 09:11:49.815191
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    queue = Queue()
    assert (queue.qsize() == 0 and queue._unfinished_tasks == 0)
    queue.task_done()



# Generated at 2022-06-24 09:11:53.805291
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """Test for constructor of class QueueFull"""
    try:
        raise QueueFull()
    except Exception as e:
        if isinstance(e, QueueFull):
            pass
        else:
            raise Exception("QueueFull() throws unexpected exception")



# Generated at 2022-06-24 09:12:05.727890
# Unit test for method full of class Queue
def test_Queue_full():
    import logging
    import sys
    import unittest
    from tornado import gen, ioloop

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG, format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s', datefmt='%a, %d %b %Y %H:%M:%S',)

    @gen.coroutine
    def consumer(q):
        while True:
            item = yield q.get()
            try:
                logging.info('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()


# Generated at 2022-06-24 09:12:08.518975
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    qe = QueueEmpty()
    assert type(qe) == QueueEmpty


# Generated at 2022-06-24 09:12:11.909175
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(1)
    q.put_nowait(1)
    # __get_nowait__
    assert(q.get_nowait() == 1)
    assert(q.empty())

# Generated at 2022-06-24 09:12:19.425275
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
      import inspect
      import tornado
      import tornado.gen
      import tornado.ioloop
      import tornado.queues
      import tornado.util
      import collections
      import typing
      if typing.TYPE_CHECKING:
          from typing import Deque, Tuple, Any  # noqa: F401
      QueueEmpty = tornado.queues.QueueEmpty
      class Queue(tornado.queues.Queue):
          def __init__(self, maxsize):
              super().__init__(maxsize)
              self.items = collections.deque()  # type: Deque
          def _get(self):
              return self.items.popleft()
          def _put(self, item):
              self.items.append(item)
      q = Queue(maxsize=2)
      q.put_nowait(10)

# Generated at 2022-06-24 09:12:22.443545
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(5)
    for i in range(5):
        q.put(i)
    assert q.qsize() == 5


# Generated at 2022-06-24 09:12:23.679673
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    #TODO
    return

# Generated at 2022-06-24 09:12:25.310065
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    assert q.get() == 1


# Generated at 2022-06-24 09:12:30.506879
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:12:38.075117
# Unit test for method empty of class Queue
def test_Queue_empty():
    # First, let's create a queue and put some items into it:
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    # Now, let's check if the queue is empty. It's not, so the function should return False:
    empty_val = q.empty()
    # To be sure, let's find out the length of the queue:
    queue_len_1 = q.qsize()
    # Now, we'll go ahead and process all the items in the queue using the task_done function:
    for i in range(4):
        q.task_done()
    # Finally, let's check if the queue is empty now. It is, so the function should return True:


# Generated at 2022-06-24 09:12:48.672690
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == '<Queue maxsize=0>'

    q = Queue(10)
    assert str(q) == '<Queue maxsize=10>'

    q._queue = [1, 2, 3]
    assert str(q) == '<Queue maxsize=10 queue=[1, 2, 3]>'

    q._putters = [(1, Future())]
    assert str(q) == '<Queue maxsize=10 queue=[1, 2, 3] putters[1]>'

    q._getters = [Future()]
    assert str(q) == '<Queue maxsize=10 queue=[1, 2, 3] putters[1] getters[1]>'

    q._unfinished_tasks = 10

# Generated at 2022-06-24 09:12:56.700293
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    loop = ioloop.IOLoop.current()
    q = Queue(maxsize=2)

    async def consumer():
        async for i in q:
            try:
                print('Doing work on %s' % i)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for i in range(5):
            await q.put(i)
            print('Put %s' % i)

    async def main():
        # Start consumer without waiting (since it never finishes).
        loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    loop.run_sync(main)


# Generated at 2022-06-24 09:12:57.365003
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull()


# Generated at 2022-06-24 09:12:59.860525
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        a = e
    assert str(a) == 'queue full'


# Generated at 2022-06-24 09:13:08.993707
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # q is a Queue of _T=repr, with maxsize=1, it will block until an item is available
    # __anext__ is an async context manager, it returns an Awaitable of _T
    q = Queue[repr]()
    # qi is an _QueueIterator of _T=repr
    qi = _QueueIterator(q)
    assert qi.__anext__()._state == 'PENDING'
    # qi.__anext__() is an Awaitable of _T=repr
    qi.q.put_nowait(repr(1))
    assert qi.__anext__()._state == 'FINISHED'


# Generated at 2022-06-24 09:13:16.389557
# Unit test for method get of class Queue
def test_Queue_get():
	# test_Queue_get_success
	q = Queue()
	result = q.get()
	assert result is not None, 'test_Queue_get_success'
	# test_Queue_get_success_2
	q = Queue()
	result = q.get()
	assert result is not None, 'test_Queue_get_success_2'
	# test_Queue_get_timeout
	q = Queue()
	result = q.get(timeout=None)
	assert result is not None, 'test_Queue_get_timeout'
	# test_Queue_get_timeout_3
	q = Queue()
	result = q.get(timeout=None)
	assert result is not None, 'test_Queue_get_timeout_3'

# Generated at 2022-06-24 09:13:24.011631
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 2)
    #print(q.put_nowait(1))
    #print(q.put_nowait(2))
    try:
        print(q.put_nowait(3))
    except Exception as e:
        print (type(e))
test_Queue_put_nowait()

# Generated at 2022-06-24 09:13:29.328448
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    queue = PriorityQueue()
    queue.put((1, 'medium-priority item'))
    queue.put((0, 'high-priority item'))
    queue.put((10, 'low-priority item'))

    print(queue.get_nowait())
    print(queue.get_nowait())
    print(queue.get_nowait())



# Generated at 2022-06-24 09:13:37.209531
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)
    q = Queue(maxsize=3)
    print(q)
    q.put("A")
    q.put("B")
    q.put("C")
    print(q)
    q.get_nowait()
    print(q)
    q.put("D")
    print(q)
    q.get_nowait()
    print(q)
    q.task_done()
    print(q)
    q.put("E")
    q.join()

test_Queue()


# Generated at 2022-06-24 09:13:41.074985
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_LifoQueue()

# Generated at 2022-06-24 09:13:53.273511
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    from tornado import gen
    from tornado.queues import Queue, QueueEmpty

    async def consumer(q: Queue) -> None:
        async for item in q:
            try:
                print('Doing work on %s' % (item,))
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer(q: Queue) -> None:
        for item in range(5):
            await q.put(item)
            print('Put %s' % (item,))

    q = Queue()

    consumer(q)
    producer(q)

    try:
        await q.join()
    except QueueEmpty:
        pass
    print('Done')

    # The following code is not executed as __aiter__() method returns a
    # coroutine object

# Generated at 2022-06-24 09:14:01.542281
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen, ioloop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2 queue=deque([]) getters[] putters[]>"
    async def consumer():
        async for item in q:
            try:
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            q.put_nowait(item)
    async def main():
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:14:06.670961
# Unit test for method task_done of class Queue
def test_Queue_task_done():
  q = Queue()
  for i in range(2):
    q.put(i)
  for i in range(2):
    q.get()
    q.task_done()
  assert q._unfinished_tasks == 0
  assert q._finished.is_set()


# Generated at 2022-06-24 09:14:07.439694
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:14:14.304951
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq = PriorityQueue()
    pq.put((1, 'medium-priority item'))
    pq.put((0, 'high-priority item'))
    pq.put((10, 'low-priority item'))

    assert pq.get_nowait() == (0, 'high-priority item')
    assert pq.get_nowait() == (1, 'medium-priority item')
    assert pq.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:14:24.964148
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    def consumer():
        try:
            async for item in q:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
        finally:
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    q = Queue(maxsize=2)
    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:14:25.825211
# Unit test for constructor of class QueueFull
def test_QueueFull():
    pass  # Just instantiate.



# Generated at 2022-06-24 09:14:26.751784
# Unit test for method get of class Queue
def test_Queue_get():
    pass



# Generated at 2022-06-24 09:14:29.153545
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    for i in range(10):
        q.put(i)
    assert q.qsize() == 10

# Generated at 2022-06-24 09:14:34.188456
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    s = str(q) # q.__str__()
    print(s)
    r = repr(q) # q.__repr__()
    print(r)

test_Queue___repr__()


# Generated at 2022-06-24 09:14:42.297168
# Unit test for method full of class Queue
def test_Queue_full():
    #testcase: Queue.full()
    q = Queue(maxsize=2)
    assert q.full() == False
    #testcase: Queue.full()
    q = Queue(maxsize=0)
    assert q.full() == False
    #testcase: Queue.put(item, timeout)
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.full() == True

# Generated at 2022-06-24 09:14:51.331503
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Test functions
    def func1():
        q = Queue()
        a = q.__aiter__()
        return (isinstance(a, _QueueIterator))

    def func2():
        q = Queue()
        a = q.__aiter__()
        return (a.q == q)

    def func3():
        q = Queue()
        a = q.__aiter__()
        return (hasattr(a, '__anext__') and callable(a.__anext__))

    # Test
    for test_function in [func1, func2, func3]:
        print("Unit test for: " + test_function.__name__)
        try:
            test_function()
            print("Pass")
        except Exception as e:
            print("Fail: " + str(e))

# Generated at 2022-06-24 09:14:53.290899
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
  q = Queue()
  assert isinstance(q.__aiter__(), _QueueIterator)



# Generated at 2022-06-24 09:14:57.543936
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    print(q)
    q.put(1)
    q.put(2)
    print(q)
    q.put(3)
    print(q)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q)
    print(q.get_nowait())
    print(q)

test_LifoQueue()

# Generated at 2022-06-24 09:15:08.384936
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert not q.full()
    assert not q.empty()
    assert q.qsize() == 0
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"
    q.__put_internal(1)
    assert not q.full()
    assert not q.empty()
    assert q.qsize() == 1
    assert str(q) == "<Queue maxsize=0 queue=deque([1])>"
    q.__put_internal(2)
    assert not q.full()
    assert not q.empty()
    assert q.qsize() == 2
    assert str(q) == "<Queue maxsize=0 queue=deque([1, 2])>"
    q.__put_internal(3)
    assert not q.full()
    assert not q.empty

# Generated at 2022-06-24 09:15:19.193735
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import typing
    import tornado.gen
    from tornado.ioloop import IOLoop
    from tornado.testing import bind_unused_port
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    io_loop = IOLoop.current()
    async def test___anext__():
        q = Queue(maxsize=5)
        iterator = _QueueIterator(q)
        await q.put(1)
        assert await iterator.__anext__() == 1
        await q.put(2)
        await q.put(3)
        await q.put(4)
        await q.put(5)
        await q.put(6)
        assert await iterator.__anext__() == 2
        assert await iterator.__anext

# Generated at 2022-06-24 09:15:24.052647
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())






# Generated at 2022-06-24 09:15:31.315539
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.__put_internal(4)
    q.__put_internal(2)
    assert q.qsize() == 2
    q.__put_internal(1)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0
    q.get_nowait()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:15:41.761827
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = tornado.queues.Queue(maxsize=2)
    class_name=q.__class__.__name__

    assert(q.__repr__()=='<Queue at 0x{0} maxsize=2>'.format(hex(id(q))))
    assert(repr(q)=='<Queue at 0x{0} maxsize=2>'.format(hex(id(q))))
    q.put_nowait(1)
    assert(q.__repr__()=='<Queue at 0x{0} maxsize=2 queue=[1]>'.format(hex(id(q))))
    assert(repr(q)=='<Queue at 0x{0} maxsize=2 queue=[1]>'.format(hex(id(q))))


# Generated at 2022-06-24 09:15:51.029120
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import time
    import unittest


    class TestQueueJoin(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)

        def tearDown(self):
            self.loop.close()

        def test_join(self):
            q = asyncio.Queue(loop=self.loop)

            async def putter():
                for i in range(3):
                    await q.put(i)
                await q.put(None)

            put_coro = putter()
            self.loop.run_until_complete(put_coro)

            self.assertEqual(q.qsize(), 4)

            get_coro = q.get()
            get_task = self

# Generated at 2022-06-24 09:15:54.338980
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:15:55.454868
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    assert False

# Generated at 2022-06-24 09:15:57.745325
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    q.full()


# Generated at 2022-06-24 09:16:02.782556
# Unit test for method empty of class Queue
def test_Queue_empty():
    q1 = Queue(maxsize = 0)
    assert q1.empty() == True

    q2 = Queue(maxsize = 1)
    assert q2.empty() == True
    assert q2.full() == False
    q2.put(1)
    assert q2.empty() == False



# Generated at 2022-06-24 09:16:06.222667
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull as e:
        print("Queue Full: ", e)


# Generated at 2022-06-24 09:16:18.302457
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    from tornado.gen import coroutine, Return
    from tornado.testing import gen_test
    from _pytest.compat import final

    from tornado.queues import Queue

    @gen_test(timeout=10)
    def _():
        @final
        class _aiter(Queue):
            maxsize = 1

            @final
            @coroutine
            def _put(self, item: _T) -> None:
                yield self.put_nowait(item)

            @final
            @coroutine
            def _get(self) -> _T:
                yield self.get()

            @final
            @coroutine
            def _init(self) -> None:
                _ = 0

        q = _aiter()  # type: Queue[_T]
        for i in range(8):
            q

# Generated at 2022-06-24 09:16:21.105969
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    assert isinstance(i, _QueueIterator)
    assert isinstance(i.q, Queue)



# Generated at 2022-06-24 09:16:33.824838
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("\n \n \n Unit test for method put_nowait of class Queue \n \n \n")
    q = Queue()
    q.put_nowait('hello')
    item = q.get_nowait()
    print(item)
    assert item == 'hello'

    maxsize = 5
    q = Queue(maxsize = maxsize)

    for i in range(maxsize):
        q.put_nowait(i)

    for i in range(maxsize):
        item = q.get_nowait()
        assert item == i

    try:
        q.put_nowait(maxsize)
    except QueueFull:
        print("Queue is full")
    else:
        print("This should not happen")


# Generated at 2022-06-24 09:16:35.779145
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        assert type(e) is QueueEmpty


# Generated at 2022-06-24 09:16:45.554852
# Unit test for method put of class Queue
def test_Queue_put():
    import random
    import time
    from tornado.ioloop import IOLoop
    from tornado.gen import sleep
    import tornado

    Q = Queue()
    Q1 = Queue()
    Q2 = Queue()

    async def test(q):
        for i in range(1, 6):
            await q.put(i)
            print(f'put \t{q.qsize()}')
            # sleep(random.random() * 0.01)
            await sleep(random.random() * 0.01)

    async def test1(q):
        while True:
            try:
                a = await q.get(timeout=0.001)
                print(f'get \t{a}')
            except tornado.util.TimeoutError:
                break


# Generated at 2022-06-24 09:16:52.135213
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    futures = [Future() for _ in range(2)]
    def callback(futures):
        for f in futures:
            f.set_result(None)
    ioloop.IOLoop.current().add_callback(callback, futures)
    q = Queue(maxsize=10)
    q._putters.extend(futures)
    assert "putters[2]" in repr(q)


# Generated at 2022-06-24 09:16:57.213117
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert not q.full()
    q = Queue(maxsize=0)
    assert not q.full()
    q = Queue(maxsize=1)
    assert not q.full()
    q.put_nowait("foo")
    assert q.full()


# Generated at 2022-06-24 09:16:59.336573
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    get_result = q.get()
    assert get_result == 1

# Generated at 2022-06-24 09:17:06.030611
# Unit test for method get of class Queue
def test_Queue_get():
    a=Queue(1)
    a.put(1)
    assert a.get() == 1
    a.put(2)
    a.put(2)
    assert a.get() == 2
    assert a.get() == 2
    a.put(2)
    a.put(2)
    assert a.get() == 2
    assert a.get() == 2
    a.put(2)
    assert a.get() == 2
    a.put(2)
    a.put(2)
    a.put(2)
    a.put(2)
    assert a.get() == 2



# Generated at 2022-06-24 09:17:13.960200
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.maxsize == 0

    q = Queue(1)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.maxsize == 1

    q = Queue(2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.maxsize == 2


# Generated at 2022-06-24 09:17:18.634087
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import gen_test, AsyncTestCase
    import asyncio

    class T(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.q = Queue()

        @gen_test
        async def test__QueueIterator___anext__(self):
            self.q.put_nowait("hello")
            async for i in _QueueIterator(self.q):
                self.assertEqual("hello", i)

    T().test__QueueIterator___anext__()



# Generated at 2022-06-24 09:17:30.412706
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:40.550906
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # test maxsize is None, expect TypeError
    try:
        Queue(None)
    except TypeError:
        pass
    except:
        return 1
    # test maxsize is negative, expect ValueError
    try:
        Queue(-1)
    except ValueError:
        pass
    except:
        return 2
    # test maxsize is 0, expect work successfully
    try:
        Queue(0)
    except:
        return 3
    # test maxsize is positive, expect work successfully
    try:
        Queue(1)
    except:
        return 4
    return 0



# Generated at 2022-06-24 09:17:45.802125
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    try:
        q.task_done()
    except ValueError:
        pass
    q.put_nowait(1)
    try:
        q.task_done()
    except ValueError:
        pass
    val = q.get_nowait() #type: int
    q.task_done()
    assert val == 1



# Generated at 2022-06-24 09:17:58.988102
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado.concurrent
    import tornado.ioloop
    import tornado.queues
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.twisted
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def main(ioloop):
        # Start consumer without waiting (since it never finishes).
        ioloop.spawn_callback(consumer)
        await q.put(1)     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-24 09:18:03.039522
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        assert isinstance(e, Exception)
        assert isinstance(e, QueueEmpty)



# Generated at 2022-06-24 09:18:04.769068
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue[int]()
    i = _QueueIterator(q)
    assert i.__anext__()



# Generated at 2022-06-24 09:18:08.673084
# Unit test for method full of class Queue
def test_Queue_full():
    if True:
        q = Queue(maxsize=2)
        q.__put_internal(1)
        q.__put_internal(2)
        assert q.full()
    else:
        q = Queue(maxsize=2)
        q.__put_internal(1)
        assert not q.full()

# Generated at 2022-06-24 09:18:21.006188
# Unit test for method get of class Queue
def test_Queue_get():
    # Test the method get of class Queue
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print ("Doing work on %s" % item)
            await gen.sleep(0.01)
        q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
        q.join()
        print ("Done")

    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        IOLoop.current().run_sync(producer)

    return main()

# Generated at 2022-06-24 09:18:23.465750
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-24 09:18:24.509462
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()



# Generated at 2022-06-24 09:18:32.094859
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import logging
    import threading
    import asyncio

    async def test():
        q = Queue(maxsize=2)
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        
        async for i in q:
            print(i)
            await asyncio.sleep(0.01)
        q.join()
        print('Done')

    try:
        thread = threading.Thread(target=asyncio.run, args=(test(),))
        thread.start()
        thread.join()
    except Exception as e:
        logging.exception(e)
        raise e

test_Queue___aiter__()


if typing.TYPE_CHECKING:
    _P = TypeVar("_P")



# Generated at 2022-06-24 09:18:36.929390
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    q = Queue()
    async def test():
        for symbol in ('a', 'b', 'c'):
            await q.put(symbol)
        it = _QueueIterator(q)
        async for symbol in it:
            print(symbol)
    asyncio.run(test())
test__QueueIterator___anext__()

# Generated at 2022-06-24 09:18:49.384283
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen, ioloop, queues
    import time
    q = queues.Queue(maxsize=2)
    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().spawn_callback(producer)
    time.sleep(3)
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on {}'.format(item))
                yield gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put {}'.format(item))
test_Queue_qsize()

# Generated at 2022-06-24 09:18:50.869144
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=2)
    print(queue)


# Generated at 2022-06-24 09:19:02.921010
# Unit test for method join of class Queue
def test_Queue_join():
    print("START")
    q = Queue()
    IOLoop.current().spawn_callback(consumer)

    def putter():
        # 使用@gen.coroutine装饰器装饰的函数，内部不能使用yield
        # yield是标识着生成器（Generator）
        for item in range(5):
            print('Put %s' % item)
            q.put(item)


# Generated at 2022-06-24 09:19:09.450765
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        pass

    @tornado.gen.coroutine
    def g():
        pass

    q = Queue()
    assert q.qsize() == 0

    q.put(f)
    q.put(g)
    assert q.qsize() == 2

    q.task_done()
    assert q.qsize() == 1
    q.task_done()
    assert q.qsize() == 0



# Generated at 2022-06-24 09:19:10.928405
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    pass


# Generated at 2022-06-24 09:19:18.152901
# Unit test for method full of class Queue
def test_Queue_full():
    # case 1
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    result = q.full()
    assert result == True
    # case 2
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.get_nowait()
    result = q.full()
    assert result == False
    # case 3
    q = Queue(maxsize=0)
    result = q.full()
    assert result == False
    # case 4
    q = Queue(maxsize=None)
    result = q.full()
    assert result == False


# Generated at 2022-06-24 09:19:24.869267
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(5)
    q.put(4)
    q.put(3)
    assert q.qsize() == 3
    assert q.maxsize == 0
    assert q.empty() == False
    assert q.full() == False
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5

# Generated at 2022-06-24 09:19:29.484668
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue = Queue()
    assert repr(queue) == "<Queue at 0x%X maxsize=0>" % id(queue)
    queue = Queue(maxsize=2)
    assert repr(queue) == "<Queue at 0x%X maxsize=2>" % id(queue)



# Generated at 2022-06-24 09:19:39.432257
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    instance = Queue(maxsize=0)
    instance._init()
    instance._getters = collections.deque([])  # type: Deque[Future[_T]]
    instance._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
    instance._unfinished_tasks = 0
    assert instance._format() == "maxsize=0"

    instance = Queue(maxsize=0)
    instance._init()
    instance._getters = collections.deque([Future()])
    instance._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
    instance._unfinished_tasks = 0
    assert instance._format() == "maxsize=0 getters[1]"
