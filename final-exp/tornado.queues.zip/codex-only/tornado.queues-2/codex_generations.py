

# Generated at 2022-06-24 09:09:38.732273
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    ans1 = q.put(2)
    assert ans1.done()
    assert q._queue == deque([2])
    assert q._putters == deque([])
    assert q.maxsize == 0
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False

    q2 = Queue(maxsize=1)
    ans2 = q2.put(2)
    ans2.done()
    assert q2._queue == deque([2])
    assert q2._putters == deque([])
    assert q2.maxsize == 1
    assert q2.qsize() == 1
    assert q2.empty() == False
    assert q2.full() == True

# Generated at 2022-06-24 09:09:39.419781
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=4)


# Generated at 2022-06-24 09:09:42.192070
# Unit test for method full of class Queue
def test_Queue_full():
    a = Queue(maxsize = 2)
    b = a.full()
    c = Queue(maxsize = 0)
    d = c.full()
    return b, d


# Generated at 2022-06-24 09:09:49.139832
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue

    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    item1 = q.get_nowait()
    item2 = q.get_nowait()
    item3 = q.get_nowait()
    assert item1 == 1
    assert item2 == 2
    assert item3 == 3

# Generated at 2022-06-24 09:09:51.192732
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    for item in range(4):
        q.put(item)
        assert q.full(), "not full"

# Generated at 2022-06-24 09:10:01.324876
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    q.put_nowait(6)
    q.put_nowait(7)
    q.put_nowait(8)
    q.put_nowait(9)
    q.put_nowait(10)
    q.put_nowait(11)

if __name__ == '__main__':
    print("Queue Test")
    test_Queue_qsize()

# Generated at 2022-06-24 09:10:04.625501
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    t = Queue(maxsize=3)
    t.qsize()
    assert  t.qsize() == 0



# Generated at 2022-06-24 09:10:05.996204
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)
    print(q)


# Generated at 2022-06-24 09:10:13.161079
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(10)
    assert str(q) == "<Queue maxsize=10 tasks=0>"
    for i in range(5):
        q.put_nowait(i)
    assert str(q) == "<Queue maxsize=10 tasks=5>"
    q.task_done()
    assert str(q) == "<Queue maxsize=10 tasks=4>"
    q.get_nowait()
    assert str(q) == "<Queue maxsize=10 tasks=3>"
    q.qsize()
    assert str(q) == "<Queue maxsize=10 tasks=3>"
    q.empty()
    assert str(q) == "<Queue maxsize=10 tasks=3>"
    q.full()
    assert str(q) == "<Queue maxsize=10 tasks=3>"



# Generated at 2022-06-24 09:10:25.335358
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print(
                    str(id(item))
                    + " Doing work on "
                    + str(item)
                    + str(id(item))
                )
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print(
                str(id(item))
                + " Put "
                + str(item)
                + str(id(item))
            )

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer

# Generated at 2022-06-24 09:10:29.690975
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    f = """\
{}(maxsize={!r})
"""
    q = Queue(maxsize=2)
    assert repr(q) == f.format(type(q).__name__, 2)

    # Unit test for method __str__ of class Queue

# Generated at 2022-06-24 09:10:32.473544
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    async def async_test():
        assert await q.__aiter__().__anext__() == 1
        assert await q.__aiter__().__anext__() == 2
    # IOLoop.current().run_sync(async_test)



# Generated at 2022-06-24 09:10:33.921421
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    pass



# Generated at 2022-06-24 09:10:41.501232
# Unit test for method get of class Queue
def test_Queue_get():
    class Queue:
        def __init__(self, maxsize: int = 0) -> None:
            if maxsize is None:
                raise TypeError("maxsize can't be None")

            if maxsize < 0:
                raise ValueError("maxsize can't be negative")

            self._maxsize = maxsize
            self._init()
            self._getters = collections.deque([])  # type: Deque[Future[_T]]
            self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
            self._unfinished_tasks = 0
            self._finished = Event()
            self._finished.set()

        @property
        def maxsize(self) -> int:
            """Number of items allowed in the queue."""
            return self._maxsize


# Generated at 2022-06-24 09:10:42.417428
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get() == 0


# Generated at 2022-06-24 09:10:44.066686
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    q.empty()


# Generated at 2022-06-24 09:10:48.506620
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()

    q.put_nowait(5)
    q.put_nowait(3)
    q.put_nowait(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 3
    assert q.get_nowait() == 5

# Generated at 2022-06-24 09:10:54.033289
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    q._queue.append('a')
    q._getters.append(None)
    q._putters.append(('b', None))
    result = str(q)
    expected = "<Queue maxsize=2 queue=deque(['a']) getters[1] putters[1] tasks=0>"
    assert result == expected
test_Queue___str__()



# Generated at 2022-06-24 09:10:57.503317
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.qsize() == 0

    q.put("a")
    q.put("b")
    q.put("c")
    assert q.qsize() == 3
    assert q.get() == "a"
    assert q.get() == "b"
    assert q.get() == "c"
    assert q.qsize() == 0


# Generated at 2022-06-24 09:11:01.268735
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(q)
test_Queue___repr__()


# Generated at 2022-06-24 09:11:03.906386
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        assert e
    else:
        assert False



# Generated at 2022-06-24 09:11:06.582349
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.qsize() == 0
    q = Queue(maxsize=3)
    assert q.qsize() == 0


# Generated at 2022-06-24 09:11:18.348207
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import unittest
    import typing
    import queue
    import random
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestCase(unittest.TestCase):
        def test(self):
            for _ in range(10):
                q: queue.Queue[_T] = queue.Queue()
                qi: _QueueIterator[_T] = _QueueIterator(q)
                a: typing.List[_T] = [random.randint(0, 100) for _ in range(100)]
                f: typing.List[typing.Tuple[Future, Awaitable]] = []
                for i in a:
                    q.put_nowait(i)

# Generated at 2022-06-24 09:11:26.564653
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq=PriorityQueue()
    pq.put((1, 'medium-priority item'))
    pq.put((0, 'high-priority item'))
    pq.put((10, 'low-priority item'))
    assert pq.get_nowait() == (0, 'high-priority item')
    assert pq.get_nowait() == (1, 'medium-priority item')
    assert pq.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:11:34.147580
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:11:44.093767
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import pytest
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert q.get_nowait() is None
    assert q.empty() is True
    assert q.qsize() == 0
    assert q.full() is False
    q.put_nowait(1)
    assert q.get_nowait() == 1
    assert q.empty() is True
    assert q.qsize() == 0
    assert q.full() is False
    q.put_nowait(2)
    q.put_nowait(3)
    with pytest.raises(QueueFull):
        q.put_nowait(4)
    assert q.get_nowait() == 2
    assert q.qsize() == 1
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:11:46.176264
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    queue = PriorityQueue()
    assert queue.qsize() == 0
    assert queue.maxsize == 0



# Generated at 2022-06-24 09:11:50.802989
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q._maxsize == 2
    assert q._getters == collections.deque()
    assert q._putters == collections.deque()
    assert q._unfinished_tasks == 0
    assert not q._finished.is_set()


# Generated at 2022-06-24 09:11:54.022256
# Unit test for constructor of class Queue
def test_Queue():
    assert isinstance(Queue.__init__.__signature__, typing.Signature)
    assert str(Queue.__init__.__signature__) == '(self, maxsize: int=0) -> None'



# Generated at 2022-06-24 09:11:58.844797
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=1)
    q.put(1)
    q.put(2)
    q.get_nowait()
    print(q.qsize())

test_Queue_qsize()


# Generated at 2022-06-24 09:12:01.151871
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    try:
        q.maxsize
    except:
        return False
    return True


# Generated at 2022-06-24 09:12:05.012134
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False
    q.get_nowait()
    assert q.empty() == True
test_Queue_empty()

# Generated at 2022-06-24 09:12:10.032058
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    import tornado.testing 
    if typing.TYPE_CHECKING:
        q = Queue[int]()
    q = Queue()
    it = _QueueIterator(q)
    def test(q:Queue):
        pass
    test(q)



# Generated at 2022-06-24 09:12:13.932946
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    q.put(0)
    q.put(0)
    q.put(0)
    if q.qsize() == 3:
        return True
    else:
        return False

# Generated at 2022-06-24 09:12:23.534206
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def put(item):
        q.put(item)
    q.put_nowait(0)
    q.put_nowait(1)
    future = q.put(2)
    @gen.coroutine
    def test():
        try:
            # Wait until putter is in the queue waiting for a free spot.
            yield gen.sleep(0.02)
            assert q.putters
            assert 2 == len(q.putters)
            for item, n in q.putters:
                assert n == future
                assert item == 2
            assert 2 == q.qsize()
        except Exception:
            pass
    IOLoop.current().add_callback(test)
    IOLoop.current().run_sync(lambda: future)
    assert 2 == q

# Generated at 2022-06-24 09:12:28.687346
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = Queue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:12:33.719194
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(1)
    # print(q.put_nowait(1))
    # print(q)
    # print(q.get())
    # print(q)
    # # print(q.task_done())
    # print(q.join())
    # print(q)


# Generated at 2022-06-24 09:12:40.800973
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

#test_PriorityQueue()



# Generated at 2022-06-24 09:12:45.782210
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    queue = Queue()
    queue.maxsize = 1
    queue._queue = [ 1, 2 ]
    queue._getters = [ 3, 4 ]
    queue._putters = [ 5, 6 ]
    queue._unfinished_tasks = 7
    assert "maxsize=1 queue=[1, 2]" == queue._format()




# Generated at 2022-06-24 09:12:47.680745
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado.queues

    q = tornado.queues.Queue(0)
    assert isinstance(q.__aiter__(), tornado.queues._QueueIterator)



# Generated at 2022-06-24 09:12:55.395561
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(2)
    q._queue = [1, 2]
    q._getters = [3, 4]
    q._putters = [5, 6]
    q._unfinished_tasks = 7
    assert "maxsize=2 queue=[1, 2] getters[2] putters[2] tasks=7" == q._format()
    assert "<Queue at 0x{id} maxsize=2 queue=[1, 2] getters[2] putters[2] tasks=7>".format(
        id=hex(id(q))
    ) == q.__repr__()
    assert "<Queue maxsize=2 queue=[1, 2] getters[2] putters[2] tasks=7>" == q.__str__()



# Generated at 2022-06-24 09:13:00.192511
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int]()
    q.put_nowait(1)
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator) is True
    assert it.q == q


# Generated at 2022-06-24 09:13:08.994309
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.queues
    import typing

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    q = tornado.queues.Queue()

    async def producer(q: tornado.queues.Queue):
        await q.put(1)

    async def consumer(q: tornado.queues.Queue):
        item = await q.get()

    ioloop = tornado.ioloop.IOLoop.current()
    ioloop.add_callback(tornado.ioloop.IOLoop.current().stop)


# Generated at 2022-06-24 09:13:16.604168
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
  import pytest
  from random import randint
  from tornado import gen


  from tornado.ioloop import IOLoop
  from tornado.queues import Queue


  q = Queue(maxsize=2)


  async def consumer():
    async for item in q:
      try:
        print("Doing work on %s" % item)
        await gen.sleep(0.01)
      finally:
        q.task_done()


  async def producer():
    for item in range(5):
      await q.put(item)
      print("Put %s" % item)


  async def main():
    # Start consumer without waiting (since it never finishes).
    IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join

# Generated at 2022-06-24 09:13:18.985412
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert q.empty() is True


# Generated at 2022-06-24 09:13:30.225676
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    async def test_case_1():
        q = Queue()
        l = []
        async for i in q:
            l.append(i)

    async def test_case_2():
        q = Queue()
        await q.put(1)
        await q.put(2)
        l = []
        async for i in q:
            l.append(i)
        assert l == [1, 2]

    async def test_case_3():
        q = Queue()
        await q.put(1)
        await q.put(2)
        async for i in q:
            pass
        assert q.qsize() == 0

    for test_case in [test_case_1, test_case_2, test_case_3]:
        ioloop.IOLoop.current().run_

# Generated at 2022-06-24 09:13:31.918803
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=0)
    assert q.empty() == True



# Generated at 2022-06-24 09:13:41.199055
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    from tornado.queues import Queue, QueueFull, QueueEmpty
    q = Queue(maxsize=2)
    q.put_nowait(999)
    q.put_nowait(888)
    try:
        q.put_nowait(777)
    except QueueFull as e:
        print(e)
    print(q.get_nowait())
    print(q.get_nowait())
    try:
        print(q.get_nowait())
    except QueueEmpty as e:
        print(e)

    # task_done() method
    q.task_done()
    # join() method
    q.join()



# Generated at 2022-06-24 09:13:51.376109
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)  # type: Queue[int]
    q.put_nowait(1)  # Here put() is called, thus _unfinished_tasks is incremented
    q.put_nowait(2)
    assert q.qsize() == 2
    q.put_nowait(3)
    assert q.qsize() == 3
    q.put_nowait(4)
    assert q.qsize() == 4
    # q.task_done()
    # q.put_nowait(3)
    # assert q.qsize() == 2

test_Queue_put_nowait()



# Generated at 2022-06-24 09:13:53.670601
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    Q = LifoQueue()
    assert Q.empty() == True
    assert Q.qsize() == 0


# Generated at 2022-06-24 09:13:56.374749
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    queue = Queue()
    assert repr(queue) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(queue)


# Generated at 2022-06-24 09:13:58.115538
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:14:01.381686
# Unit test for method full of class Queue
def test_Queue_full():
    new_Queue = Queue(maxsize=2)
    print("Queue(maxsize=2).full() is", new_Queue.full())



# Generated at 2022-06-24 09:14:12.277202
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import random
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(1)
    for i in range(1,6):
        q.put(i)
    print("queue size is:", q.qsize())
    # print("the queue is full?", q.full())
    IOLoop.current().spawn_callback(q.join)
    print("the queue is joined.")
    # print("the queue is full?", q.full())
    for i in range (1,6):
        print("get element:", q.get_nowait())
    print("queue size is:", q.qsize())
    # print("the queue is full?", q.full())

# Generated at 2022-06-24 09:14:14.971660
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    future = q.get(timeout=5)
    print(future)


# Generated at 2022-06-24 09:14:25.575081
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    num = 3
    q = Queue(maxsize=num)
    async def consumer():
        async for i in q:
            try:
                print("Doing work on %s" % i)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for i in range(num):
            await q.put(i)
            print("Put %s" % i)
    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print("Done")
    IOLoop.current().run_sync(main)

# Output:
# Put 0
# Put 1


# Generated at 2022-06-24 09:14:34.401640
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == False
    assert q.get_nowait() == 1
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 1
    q.put_nowait(3)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == False
    q.task_done()
    q.task_done()
    assert q.qsize() == 0
    assert q.empty() == True


# Generated at 2022-06-24 09:14:35.954944
# Unit test for method empty of class Queue
def test_Queue_empty():
    qsize = 0
    q = Queue(maxsize=qsize)
    empty = q.empty()
    return empty



# Generated at 2022-06-24 09:14:40.529061
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    for i in range(3):
        q.put_nowait(i)
    # Check that put_nowait throws an exception when queue is full
    q.put_nowait(i)


# Generated at 2022-06-24 09:14:44.534614
# Unit test for method __str__ of class Queue
def test_Queue___str__():

  # Test with default args
  Queue_instance = Queue()
  str_returned = Queue_instance.__str__()

  # Test with explicit args
  Queue_instance = Queue(maxsize=0)
  str_returned = Queue_instance.__str__()

# Generated at 2022-06-24 09:14:52.835669
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test

    class MyTest(AsyncTestCase):
        @gen_test
        async def test_empty(self):
            q = Queue()
            self.assertEqual(q.empty(), True)
            await q.put(1)
            self.assertEqual(q.empty(), False)
            await q.get()
            self.assertEqual(q.empty(), True)

    MyTest().test_empty()



# Generated at 2022-06-24 09:14:54.333946
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert q.full() == False


# Generated at 2022-06-24 09:14:56.281123
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=1)
    assert q.qsize() == 0
    q.put(item=0)
    assert q.qsize() == 1


# Generated at 2022-06-24 09:15:03.082969
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue_obj = Queue()
    #queue_obj.qsize()
    print(queue_obj.qsize())
    queue_obj.put_nowait(2)
    queue_obj.put_nowait(1)
    print(queue_obj.qsize())
    print(queue_obj.get_nowait())
    print(queue_obj.get_nowait())
    print(queue_obj.qsize())

test_Queue_get_nowait()


# Generated at 2022-06-24 09:15:05.987973
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(maxsize=10)
    i = _QueueIterator(q)
    assert isinstance(i, _QueueIterator)
    assert isinstance(i.q, Queue)



# Generated at 2022-06-24 09:15:15.794277
# Unit test for method get of class Queue
def test_Queue_get():
    """Unit test for method get of class Queue"""
    # Test the cases in Queue.get where the queue is empty:
    # The queue is empty, there are no pending getters and the queue
    # is not full
    q = Queue()
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    q.put_nowait(1) # Don't let the queue be empty, since the QueueEmpty case
                    # has already been tested
    # The queue is empty, there are no pending getters and the queue
    # is full
    q = Queue(maxsize=1)
    q.put_nowait(1)
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    # The queue is empty, there are pending getters, the queue is
    #

# Generated at 2022-06-24 09:15:26.740734
# Unit test for method put of class Queue
def test_Queue_put():
    import unittest
    import gen

    from tornado import testing
    from tornado.ioloop import IOLoop
    from tornado import gen

    from tornado.queues import Queue

    class MyTestCase(testing.AsyncTestCase):
        def test_put(self):
            self.q = Queue(maxsize=2)
            self.future = self.q.put("test")
            self.assertEqual(1, len(self.q._putters))

            def put_test():
                if not self.future.done():
                    self.future.set_result(None)
                self.stop()

            self.io_loop.add_callback(put_test)
            self.wait()

            self.assertEqual(0, len(self.q._putters))

    def test_main():
        testing.run

# Generated at 2022-06-24 09:15:34.880733
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    # End def test_Queue___str__

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer

# Generated at 2022-06-24 09:15:46.358788
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    try:
        from tornado.queues import Queue
    except ImportError:
        return

    q = Queue[int](maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    for i in q:
        if i in [1, 2]:
            pass
        else:
            assert False

__all__ = ['Queue', 'QueueIterator', 'QueueFull', 'QueueEmpty', 'LifoQueue', 'PriorityQueue']

# class QueueIterator:
#     """Returns an iterator object which iterates the given Queue object.
#     """
#     def __init__(self, queue: 'Queue[_T]') -> None:
#         self.queue = queue
# 
#     def __iter__(self) -> 'QueueIterator':
#         return self

# Generated at 2022-06-24 09:15:51.815373
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    it = _QueueIterator(q)
    assert (1, 2, 3, 4) == tuple(it)



# Generated at 2022-06-24 09:16:00.224004
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)             # Queue has one element
    q.put_nowait(2)             # Queue has two elements
    try:
        q.put_nowait(3)         # Error: Queue is full
    except QueueFull:
        print('Queue is full')  #  OK

test_Queue_put_nowait()


# Generated at 2022-06-24 09:16:06.128937
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    if q.qsize() != 0:
        raise Exception("Queue qsize error")
    q.put(1)
    q.put(2)
    q.put(3)
    if q.qsize() != 3:
        raise Exception("Queue qsize error")
    if not q.full():
        raise Exception("Queue full error")
    try:
        q.put(4)
        raise Exception("Queue qsize error")
    except QueueFull:
        pass


# Generated at 2022-06-24 09:16:13.224393
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    from tornado.queues import Queue
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()
    q = Queue(maxsize=2)
    coro = consumer()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(coro)

# Generated at 2022-06-24 09:16:22.078429
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    if (q.get_nowait() != (0, 'high-priority item') or
        q.get_nowait() != (1, 'medium-priority item') or
        q.get_nowait() != (10, 'low-priority item')):
        raise RuntimeError('Queue get_nowait failed')
    else:
        print('Queue get_nowait passes unit test')

test_PriorityQueue()



# Generated at 2022-06-24 09:16:27.061822
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Test for method empty ( )
    q = Queue(5)
    for i in range(5):
        q.put_nowait(i)
    # Check that queue is now full.
    assert q.full() == True, "Queue should be full but is not"
    # Remove item from queue
    q.get_nowait()
    # Check that queue is now not empty
    assert q.empty() == False, "Queue should not be empty, but is"


# Generated at 2022-06-24 09:16:33.457231
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    for i in range(5):
        q.put_nowait(i)
    it = _QueueIterator(q)

    async def run():
        for i in range(5):
            assert await it.__anext__() == i

        with pytest.raises(gen.TimeoutError):
            await gen.with_timeout(datetime.timedelta(seconds=0.1), it.__anext__())

    ioloop.IOLoop.current().run_sync(run)



# Generated at 2022-06-24 09:16:37.942680
# Unit test for method get of class Queue
def test_Queue_get():
    a = Queue()
    b = Future()
    i = 1
    a._getters.append(b)
    try:
        a.get_nowait()
        i += 1
    except QueueEmpty:
        i += 10
    except:
        i += 100
    print("Result of test_Queue_get is " + str(i))


# Generated at 2022-06-24 09:16:47.196208
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:50.840059
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize = 2)
    q_repr = repr(q)
    assert(q_repr == '<Queue at 0x10b26a2e8 maxsize=2>')
test_Queue___repr__()


# Generated at 2022-06-24 09:16:55.187097
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(10)
    for i in range(10):
        q.put_nowait(i)
    assert q.qsize() == 10
    assert q.full() == True
    assert q.empty() == False

# Generated at 2022-06-24 09:17:00.191007
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    import time
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-24 09:17:01.910904
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    r = yield from it.__anext__()
    print(r)


# Generated at 2022-06-24 09:17:04.208453
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull()


# Generated at 2022-06-24 09:17:07.210137
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_LifoQueue()

# Generated at 2022-06-24 09:17:14.727883
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0

    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2

    assert q.get_nowait() == 1
    assert q.qsize() == 1

    q.put_nowait(3)
    assert q.qsize() == 2
    assert q.get_nowait() == 2
    assert q.qsize() == 1


# Generated at 2022-06-24 09:17:16.641546
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert QueueEmpty().__class__.__name__ == "QueueEmpty"
    assert QueueEmpty().__doc__.startswith("Raised by")
test_QueueEmpty()


# Generated at 2022-06-24 09:17:28.322296
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.empty() == True
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    q.put(2)
    assert q.full() == True
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.qsize() == 1
    q.task_done()
    assert q.qsize() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty() == True
    q.task_done()
    assert q.qsize() == 0
    assert q.empty() == True
    return

# Generated at 2022-06-24 09:17:29.771036
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass



# Generated at 2022-06-24 09:17:33.215118
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False
test_Queue_empty()

# Generated at 2022-06-24 09:17:35.995839
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(5)
    assert q.empty() == False


# Generated at 2022-06-24 09:17:38.482299
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        print(e)



# Generated at 2022-06-24 09:17:41.072255
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except Exception as e:
        assert type(e) == QueueEmpty



# Generated at 2022-06-24 09:17:53.545550
# Unit test for method join of class Queue
def test_Queue_join():

    from random import randint
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(randint(0, 3))
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put

# Generated at 2022-06-24 09:18:05.663292
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import time
    import numpy as np
    x = time.time();
    t = Queue()
    t.put(np.array([1,2]));
    assert '<Queue at' in t.__repr__();
    assert '__main__.Queue' in t.__repr__();
    assert 'maxsize=' in t.__repr__();
    assert 'queue=' in t.__repr__();
    y = time.time();
    # assert that the function runs in less than 100ms
    assert (y - x) < 0.1;
    x = time.time();
    t.put(np.array([1,2,3]));
    t.put(np.array([1,2,3,4]));
    assert 'getters[2]' in t.__repr__();


# Generated at 2022-06-24 09:18:09.207995
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    #! [mypy-test]
    #! [mypy-test-1]
    from tornado.queues import Queue
    x = Queue()
    x.qsize()
    #! [mypy-test-1]
    #! [mypy-test-2]
    from tornado.queues import Queue
    x = Queue(maxsize = 10)
    x.qsize()
    #! [mypy-test-2]
    #! [mypy-test]



# Generated at 2022-06-24 09:18:14.157216
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    L=[]
    q.put_nowait(1)
    L.append(q.qsize())
    q.put_nowait(2)
    L.append(q.qsize())
    q.put_nowait(3)
    L.append(q.qsize())
    q.put_nowait(4)
    L.append(q.qsize())
    assert(L==[1,2,2,2])


# Generated at 2022-06-24 09:18:21.227100
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import time
    import random
    import unittest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import asyncio
    import concurrent.futures
    queue = Queue()
    assert queue.qsize() == 0
    queue._queue = [1,2,3]
    assert queue.qsize() == 3
    # IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:18:24.747040
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(2)
    assert q.full() == False
    q.put_nowait(1)
    assert q.full() == False
    q.put_nowait(2)
    assert q.full() == True


# Generated at 2022-06-24 09:18:32.278670
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    import unittest
    import sys
    import os
    import io

    class PriorityQueueTestCase(unittest.TestCase):
        def setUp(self):
            self.saved_stdout = sys.stdout
            self.out = io.StringIO()
            sys.stdout = self.out
            
        def tearDown(self):
            sys.stdout = self.saved_stdout
            if os.path.isfile("PriorityQueueTestCase.txt"):
                os.remove("PriorityQueueTestCase.txt")

        # Test the output of PriorityQueue
        def test_result(self):
            q = PriorityQueue()
            expected_output = "(0, 'high-priority item')\n(1, 'medium-priority item')\n(10, 'low-priority item')\n"

           

# Generated at 2022-06-24 09:18:36.263798
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()

    try:
        item = q.get_nowait()
    except QueueEmpty as e:
        item = e

    q.put_nowait(item)

    iter = _QueueIterator(q)
    assert iter.q == q
    q.get_nowait()



# Generated at 2022-06-24 09:18:44.306671
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:18:48.215967
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False
    task = q.get()
    assert q.empty() == True


# Generated at 2022-06-24 09:18:58.378837
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()

    # Put an item without blocking
    q.put_nowait(1)
    assert q.qsize() == 1, "qsize should return 1"
    
    # Put 2 items without blocking
    q.put_nowait(2)
    assert q.qsize() == 2, "qsize should return 2"

    # Put 3 items when queue is full
    try:
        q.put_nowait(3)
    except QueueFull:
        assert q.qsize() == 2, "qsize should return 2"
    else:
        assert False, "Queue should be full!"

    # Put 4 items with a timeout of 0.01 seconds
    put_future = q.put(4, timeout=0.01)

# Generated at 2022-06-24 09:19:02.866926
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    
test_Queue_get_nowait()

# Generated at 2022-06-24 09:19:11.035816
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio

    @asyncio.coroutine
    def run():
        q = Queue()
        q.put_nowait(42)
        q.put_nowait(43)
        q.put_nowait(44)
        it = _QueueIterator(q)
        assert (yield from it.__anext__()) == 42
        assert (yield from it.__anext__()) == 43
        assert (yield from it.__anext__()) == 44

    asyncio.get_event_loop().run_until_complete(run())



# Generated at 2022-06-24 09:19:15.724676
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([]) getters[] putters[] tasks=0>"


# Generated at 2022-06-24 09:19:21.333495
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:19:32.228085
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import ast, astunparse
    from tornado.queues import Queue
    from asttyped import TypeChecker, ast_convert, ast_infer
    from asttyped import make_func_ty

    # This example shows how to use __aiter__ typed checker on class Queue
    # In order to use __aiter__, need to write a stub class for `Queue` and
    # define __aiter__ in the stub class

    # Use this stub when __aiter__ is used
    class QueueStub:
        @make_func_ty(args=[], returns=None)
        def __init__(self, maxsize=0):
            pass

        def __aiter__(self):
            pass
