

# Generated at 2022-06-24 09:09:33.395302
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(4)
        q.put_nowait(5)
        q.put_nowait(6)
    except QueueFull:
        print("QueueFull exception")
        assert False == True
    else:
        assert True == True


# Generated at 2022-06-24 09:09:44.441099
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    @gen.coroutine
    def consumer():
        while True:
            try:
                item = yield q.get()
                try:
                    print('Doing work on %s' % item)
                    yield gen.sleep(0.01)
                finally:
                    q.task_done()
            except Exception as e:
                print(e)
    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)
    @gen.coroutine
    def main():
        IOLoop.current().spawn_callback(consumer)
        yield producer()

# Generated at 2022-06-24 09:09:50.774724
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    msg = "A new instance of QueueEmpty has to be created"
    assert type(QueueEmpty()) is QueueEmpty, msg



# Generated at 2022-06-24 09:09:58.464816
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert q.empty()
    assert str(q) == "<Queue maxsize=0 tasks=0>"
    assert q.maxsize == 0
    q = Queue(0)
    assert q.empty()
    assert str(q) == "<Queue maxsize=0 tasks=0>"
    assert q.maxsize == 0
    q = Queue(10)
    assert q.empty()
    assert str(q) == "<Queue maxsize=10 tasks=0>"
    assert q.maxsize == 10



# Generated at 2022-06-24 09:10:09.524410
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    a = Queue(1)
    assert "maxsize=1 queue=deque([])" == str(a)
    a._queue = deque(["a"])
    assert "maxsize=1 queue=deque(['a'])" == str(a)
    a._getters = [1,2,3]
    assert "maxsize=1 queue=deque(['a']) getters[3]" == str(a)
    a._putters = [4,5,6]
    assert "maxsize=1 queue=deque(['a']) getters[3] putters[3]" == str(a)
    a._unfinished_tasks = 1
    assert "maxsize=1 queue=deque(['a']) getters[3] putters[3] tasks=1" == str(a)


# Generated at 2022-06-24 09:10:13.316454
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:10:15.782292
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.put(1)
    q.get()
    q.task_done()
    try:
        q.task_done()
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 09:10:24.196005
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    import time
    class Test_Queue_full(unittest.TestCase):
        def setUp(self):
            self.q = Queue(maxsize=2)
        def test_full(self):
            self.q.put(1)
            self.q.put(2)
            self.assertTrue(self.q.full())
            self.q.get_nowait()
            self.assertFalse(self.q.full())

    unittest.main()

# Generated at 2022-06-24 09:10:32.581699
# Unit test for method full of class Queue
def test_Queue_full():
    method_name = inspect.stack()[0][3] # Get name of method from stack frame
    q = Queue()
    if (q.full()):
        logger.error("Error: %s passed for empty queue"%(method_name))
    q.put_nowait(1)
    if (q.full()):
        logger.error("Error: %s passed for non full queue of size 1"%(method_name))
    q.put_nowait(2)

# Generated at 2022-06-24 09:10:38.277092
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    from tornado.gen import sleep

    async def main():
        q=Queue()
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        q.put(5)
        async for i in q:
            print(i)
            await sleep(0.5)
        print('done')

    # main()
    IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:10:39.185088
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()



# Generated at 2022-06-24 09:10:43.252533
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
	import tornado
	import tornado.testing
	q = tornado.queues.Queue()
	q.put_nowait(12)
	test_val = q.get_nowait()
	assert(test_val == 12)

# Generated at 2022-06-24 09:10:47.502325
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = Future()
    try:
        q.put_nowait(1)
    except QueueFull:
        future.set_result(None)
    else:
        future.set_result(None)
    return future

# Generated at 2022-06-24 09:10:49.157857
# Unit test for constructor of class Queue
def test_Queue(): 
    q = Queue()
    print(q)


# Generated at 2022-06-24 09:10:55.367345
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    q = Queue(maxsize=2)
    q.put(1)
    a = q.get()
    q.task_done()
    #q.get(timeout=0.1)
    #q.task_done()
    q.join()
    print("Done")
# Testcase for method task_done of class Queue

# Generated at 2022-06-24 09:10:59.351077
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    @gen.coroutine
    def consumer():
        while True:
            item = yield q
            try:
                print('Doing work on %s' % item)
                # yield gen.sleep(0.01)
            finally:
                q.task_done()
    io_loop = ioloop.IOLoop.current()
    io_loop.spawn_callback(consumer)

    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    q.join()
    print('Done')



# Generated at 2022-06-24 09:11:01.874597
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True


# Generated at 2022-06-24 09:11:05.276585
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = Queue(1)
    try:
        q.put_nowait(1)
        q.put_nowait(1)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-24 09:11:16.620099
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:11:24.697487
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))

test_PriorityQueue()



# Generated at 2022-06-24 09:11:33.686398
# Unit test for method put of class Queue
def test_Queue_put():
    """
    This is a system test for the method Queue.put

    During this method, io_loop.add_timeout and io_loop.remove_timeout are called

    The return of io_loop.add_timeout is used as a parameter of io_loop.remove_timeout

    """
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    import datetime
    import asyncio
    import unittest

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


# Generated at 2022-06-24 09:11:36.695874
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.empty() is True
    assert q.full() is False
    assert q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.empty() is False
    assert q.full() is True
    assert q.qsize() == 2

test_Queue_full()

# Generated at 2022-06-24 09:11:48.325684
# Unit test for method join of class Queue
def test_Queue_join():
    import random
    from tornado import gen, ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(random.random())
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(1, 10):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        # yield ioloop.IOLoop

# Generated at 2022-06-24 09:11:57.135167
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)

    # Test task_done
    f = Future()

    async def consumer():
        await f  # wait until producer puts some items
        async for item in q:
            try:
                # print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            # print('Put %s' % item)
        f.set_result(None)  # should be set after all items are put

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks

# Generated at 2022-06-24 09:12:01.938351
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    a = [i async for i in q]
    assert a == [1,2,3,4]

# Generated at 2022-06-24 09:12:03.393725
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()
    print(qf)



# Generated at 2022-06-24 09:12:04.769775
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)



# Generated at 2022-06-24 09:12:12.201890
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    # q.put_nowait(1)
    i = 1

    async def consumer():
        await q.put(1)
        await q.put(2)
        await q.put(3)

    async def producer():
        while True:
            try:
                item = await q.get()
                print('Doing work on %s' % item)
            finally:
                q.task_done()
    # IOLoop.current().spawn_callback(consumer)
    # # IOLoop.current().spawn_callback(producer)     # Wait for producer to put all tasks.
    # await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-24 09:12:18.619086
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # check return value
    # expected = ""
    # actual = Queue().put_nowait()
    # assert actual==expected
    # check exception
    Queue.put_nowait(object())
    # check exception
    Queue.put_nowait(datetime.datetime.now())
    # check exception - overflow arg
    Queue.put_nowait(b'spam')
    # check exception - overflow arg
    Queue.put_nowait(bytearray(b'spam'))
    # check exception - overflow arg
    Queue.put_nowait(memoryview(b'spam'))
test_Queue_put_nowait()

# Generated at 2022-06-24 09:12:22.708396
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:12:30.767722
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.qsize() == 0
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    q.put_nowait('a')
    assert q.get_nowait() == 'a'
    q.put_nowait('b')
    q.put_nowait('c')
    assert q.get_nowait() == 'b'
    assert q.get_nowait() == 'c'
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True

# Generated at 2022-06-24 09:12:32.392402
# Unit test for constructor of class QueueFull
def test_QueueFull():
	try:
		raise QueueFull
	except QueueFull:
		print("QueueFull")



# Generated at 2022-06-24 09:12:36.851410
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()

    q = Queue(maxsize=0)
    assert not q.full()

    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    assert not q.full()



# Generated at 2022-06-24 09:12:42.887157
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3


# Generated at 2022-06-24 09:12:51.257303
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:12:54.454188
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait(): 
    q = Queue(maxsize=2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4

test_Queue_get_nowait()



# Generated at 2022-06-24 09:12:58.715986
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put('foo')
    assert gen.convert_yielded(q.get()) == 'foo'


# Generated at 2022-06-24 09:12:59.359017
# Unit test for method get of class Queue
def test_Queue_get():
    pass



# Generated at 2022-06-24 09:13:09.425401
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(1)
    q.put('a')
    q.put('b')
    assert q.qsize()==1
    q.put_nowait('c')
    assert q.qsize()==2
    assert q.get_nowait()=='b'
    assert q.get_nowait()=='c'
    q.put_nowait('a')
    q.put_nowait('b')
    q.put_nowait('c')
    with pytest.raises(QueueFull): q.put_nowait('d')

    assert q.qsize()==3
    assert q.get_nowait()=='a'
    with pytest.raises(QueueEmpty): q.get_nowait()


# Generated at 2022-06-24 09:13:15.934654
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2 queue=[]>"

    q = Queue()
    q._queue = collections.deque([1])
    assert str(q) == "<Queue maxsize=0 queue=[1]>"
    q._unfinished_tasks = 2
    assert str(q) == "<Queue maxsize=0 queue=[1] tasks=2>"
    class MyQueue(Queue):
        def _format(self):
            return "my_queue"
    q = MyQueue()
    assert str(q) == "<MyQueue my_queue>"



# Generated at 2022-06-24 09:13:27.102891
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    io_loop = ioloop.IOLoop.current()
    io_loop.spawn_callback(consumer)
    io_loop.run_sync(producer)
    io_loop.run_sync(q.join)
    print('Done')


# Generated at 2022-06-24 09:13:33.347621
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    
test_PriorityQueue()



# Generated at 2022-06-24 09:13:36.439340
# Unit test for method empty of class Queue
def test_Queue_empty():
    # argument types
    arg0 = 1
    q = Queue(arg0)
    # function call
    # assert not empty(q)



# Generated at 2022-06-24 09:13:40.043283
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q_maxsize = 10
    #q_maxsize = 0
    q = Queue(maxsize=q_maxsize)
    assert 0 == q.qsize(), "q.qsize() should be 0"
    print(q.qsize())
    for x in range(10):
        q.put_nowait(x)
    assert 10 == q.qsize(), "q.qsize() should be 10"
    print(q.qsize())


# Generated at 2022-06-24 09:13:46.840463
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from collections import deque
    import tornado.gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import tornado.util
    import unittest
    import warnings

    def mock_current():
        return (3, 5, 2, 0)

    class TestQueue(unittest.TestCase):

        def setUp(self):
            self._async_value = 1
            self.q = Queue(maxsize=2)

        def test___str__(self):
            result = str(self.q)
            self.assertEqual(result, "<Queue maxsize=2 queue=deque([])>")
            self.q._queue = deque([1, 2])
            result = str(self.q)

# Generated at 2022-06-24 09:13:52.313279
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3


# Generated at 2022-06-24 09:13:59.972108
# Unit test for method get of class Queue
def test_Queue_get():
    class AsyncMock(object):

        def __init__(self, *args, **kwargs):
            self.mock = MagicMock(*args, **kwargs)

        async def __call__(self, *args, **kwargs):
            return self.mock(*args, **kwargs)

    def _run(coro):
        return tornado.ioloop.IOLoop.current().run_sync(coro)

    @gen.coroutine
    def get_item(self):
        item = yield self._get_item_from_queue()
        return item

    @gen.coroutine
    def _get_item_from_queue(self):
        item = yield self.queue.get()
        return item

    # Normal scenario.
    # self.queue.qsize() == 0.

# Generated at 2022-06-24 09:14:02.401724
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    que = QueueEmpty()
    assert que.args[0] == "queue is empty"



# Generated at 2022-06-24 09:14:08.519410
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:12.169818
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    class Queue(_QueueIterator):
        get = lambda self: future_set_result_unless_cancelled(self.q.get(), 1)
        __anext__ = lambda self: 2

    q = Queue(None)
    assert q.__anext__() == 2
    assert isinstance(q.__iter__(), collections.abc.AsyncIterator)
    assert q.__aiter__() is q



# Generated at 2022-06-24 09:14:17.213801
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, "medium-priority item"))
    q.put((0, "high-priority item"))
    q.put((10, "low-priority item"))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:14:21.949868
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    assert not q.empty()
    try:
        assert q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    q.put(1)
    res = q.get_nowait()
    assert res == 1
    res = q.get_nowait()
    assert False

# Test for asynchrous reading from LifoQueue
# and unit test for put, get and get_nowait functions in LifoQueue
async def test_LifoQueue_Async():
    q = LifoQueue()
    assert not q.empty()
    try:
        await q.get()
        assert False
    except QueueEmpty:
        pass
    q.put(1)
    res = await q.get()
    assert res == 1

# Generated at 2022-06-24 09:14:30.863050
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        consumer() # no await
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    main()



# Generated at 2022-06-24 09:14:33.721772
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert isinstance(e, Exception)
    assert isinstance(e, QueueEmpty)
    assert e.args == ()


# Generated at 2022-06-24 09:14:44.895304
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    async def put_in_queue():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def consume_from_queue():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consume_from_queue)
        await put_in_queue()    

# Generated at 2022-06-24 09:14:55.686579
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import pytest
    @pytest.fixture
    def q():
        q = Queue(maxsize=2)
        return q
    @pytest.fixture
    def q_exception_0(q):
        with pytest.raises(QueueFull):
            q.put_nowait('a')
            q.put_nowait('b')
            q.put_nowait('c')
    @pytest.fixture
    def q_exception_1(q):
        with pytest.raises(ValueError):
            q.put_nowait('a')
            q.put_nowait('b')
            q.put_nowait('c')

# Generated at 2022-06-24 09:15:06.915754
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import time
    import random
    import datetime
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    IOLoop.current().spawn_callback(consumer)
    for i in range(5):
        q.put_nowait(i)
        #print(q.qsize())
        print('Put %s' % i)
    IOLoop.current().start()
    time.sleep(2)


test_Queue_qsize()

# Generated at 2022-06-24 09:15:08.283904
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass



# Generated at 2022-06-24 09:15:17.524815
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at %x maxsize=0 queue=deque([])>" % id(q)
    q = Queue(4)
    assert repr(q) == "<Queue at %x maxsize=4 queue=deque([])>" % id(q)
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at %x maxsize=2 queue=deque([])>" % id(q)
    q = Queue(maxsize=2)
    q.put_nowait('A')
    assert repr(q) == "<Queue at %x maxsize=2 queue=deque(['A'])>" % id(q)
    q = Queue(maxsize=2)
    q.put_nowait('A')
    q.put_now

# Generated at 2022-06-24 09:15:28.598135
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import tornado
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    async def consumer(q):
        while True:
            # wait for an item from the producer
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                # Notify the queue that the "work item" has been processed.
                q.task_done()

    async def producer(q, num_workers):
        # Add some numbers to the queue to simulate jobs
        for item in range(num_workers * 3):
            print('Put %s' % item)
            await q.put(item)

        # Add some poison pillls for the consumers

# Generated at 2022-06-24 09:15:40.688399
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Initialize 
    q = Queue()
    for i in range(5):
        q.put(i)
    
    # Check if value added or not
    for i in range(5):
        assert q.get_nowait() == i

    # Test when queue is empty
    try:
        q.get_nowait()
        assert False
    except Exception as e:
        assert type(e) == QueueEmpty

    # Test when queue is full
    maxsize = q.maxsize
    q.maxsize = 3
    for i in range(5):
        if i < 3:
            q.put(i)
        else:
            try:
                q.put(i)
                assert False
            except Exception as e:
                assert type(e) == QueueFull
    
    # Restore value


# Generated at 2022-06-24 09:15:44.879858
# Unit test for constructor of class Queue
def test_Queue():
    queue=Queue(maxsize=2)
    queue.put_nowait(1)
    queue.put_nowait(2)
    print(queue.empty())
    print(queue.full())
    print(queue.qsize())


# Generated at 2022-06-24 09:15:52.452795
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    q = Queue()
    q._init()
    q._queue = collections.deque([1,2,3])
    assert repr(q) == "<Queue at 0x7f66811d8d98 maxsize=0 queue=deque([1, 2, 3])>"
    q.put_nowait(4)
    assert repr(q) == "<Queue at 0x7f66811d8d98 maxsize=0 queue=deque([1, 2, 3, 4])>"
    q.get_nowait()
    assert repr(q) == "<Queue at 0x7f66811d8d98 maxsize=0 queue=deque([2, 3, 4])>"
    q.task_done()
    q.join()
    q._unfinished_tasks = 3
   

# Generated at 2022-06-24 09:15:57.284762
# Unit test for method full of class Queue
def test_Queue_full():
    assert Queue(0).full() is False
    assert Queue(1).full() is False
    q = Queue(1)
    q.put_nowait(1)
    assert q.full() is True



# Generated at 2022-06-24 09:16:04.738899
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue(1)
    q.put_nowait(1)
    q.put_nowait(2)
    it = iter(q)
    assert await it.__anext__() == 1
    assert await it.__anext__() == 2
    try:
        await it.__anext__()
        assert False
    except StopAsyncIteration:
        pass
    q.put_nowait(3)
    it = iter(q)
    assert await it.__anext__() == 3


# Generated at 2022-06-24 09:16:11.993296
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    async def async_test(arg):
        print(f"{arg}")

    # test_Queue___aiter__()
    q = Queue(maxsize=0)
    print("q=", q)
    async for item in q:
        print(item)
        async_test(item)
    print("done")
    assert repr(q) == "<Queue at 0x7fdfc060a0e0 maxsize=0 tasks=0>"


# Generated at 2022-06-24 09:16:14.526884
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import doctest
    doctest.run_docstring_examples(Queue._format, globals(), verbose=True)


# Generated at 2022-06-24 09:16:15.734644
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # queue
    pass



# Generated at 2022-06-24 09:16:21.325541
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    try:
        q.task_done()
    except ValueError:
        pass
    
    for i in range(5):
        q.put_nowait(i)
    for _ in range(5):
        q.task_done()
    
    try:
        q.task_done()
    except ValueError:
        pass

# Generated at 2022-06-24 09:16:25.521659
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    @gen.coroutine
    def task_done_test():
        q.task_done()
        print(q.empty())
    IOLoop.current().spawn_callback(task_done_test)



# Generated at 2022-06-24 09:16:30.068665
# Unit test for method full of class Queue
def test_Queue_full():
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    q = Queue(maxsize=2)
    q.put(3)
    q.put(4)
    assert q.full()
    try:
        q.put_nowait(5)
        assert False
    except QueueFull:
        assert True



# Generated at 2022-06-24 09:16:34.197907
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put(1, 'one', [])

    itr = _QueueIterator(q)
    assert (1, 'one', []) == itr.__next__()
    q.put(2, 'two', [])
    assert (2, 'two', []) == itr.__next__()



# Generated at 2022-06-24 09:16:36.184740
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        assert isinstance(e, QueueFull)



# Generated at 2022-06-24 09:16:41.815066
# Unit test for method empty of class Queue
def test_Queue_empty():

    q = Queue(maxsize=2)

    q._getters = collections.deque([])  # type: Deque[Future[_T]]
    q._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
    q._queue = collections.deque()
    q._unfinished_tasks = 0

    return q.empty()


# Generated at 2022-06-24 09:16:43.079458
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(0)
    q.__init__(0)


# Generated at 2022-06-24 09:16:53.166245
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(5)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(1)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:03.415837
# Unit test for method put of class Queue
def test_Queue_put():
    my_queue = Queue(maxsize=2)
    async def consumer():
        print("consumer start to run")
        async for item in my_queue:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(1)
            finally:
                my_queue.put_nowait(item)
                my_queue.task_done()

    async def producer():
        for item in range(5):
            await my_queue.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await my_queue.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-24 09:17:07.270742
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    # type: () -> None
    e = QueueEmpty()
    assert type(e) is QueueEmpty



# Generated at 2022-06-24 09:17:16.073500
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=3)
    assert str(q) == "<Queue maxsize=3 queue=deque([])>"
    q.put_nowait(1)
    q.put_nowait(2)
    assert str(q) == "<Queue maxsize=3 queue=deque([1, 2])>"
    q.get_nowait()
    q.get_nowait()
    assert str(q) == "<Queue maxsize=3 queue=deque([])>"
    q.get()
    q.get()
    q.get()
    assert str(q) == "<Queue maxsize=3 queue=deque([]) getters[3]>"
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)

# Generated at 2022-06-24 09:17:28.090932
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Warning: this function may mutate global state if any global variables are used
    # in the function.
    # set up
    q = Queue(5)
    q._queue.append(5)
    
    

    q._queue.append(10)
    
    

    q._getters.append(Future())
    q._getters.append(Future())
    
    

    q._putters.append(((5, Future())))
    q._putters.append(((10, Future())))
    
    

    q._unfinished_tasks = 30
    
    

    # test
    result = repr(q)
    
    

    # assert

# Generated at 2022-06-24 09:17:35.071214
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import collections, types
    import functools

    class Queue(collections.deque):
        pass

    class _QueueIterator(collections.Iterator):
        def __init__(self, q):
            self.q = q

        def __anext__(self):
            return self.q.get()

    @functools.singledispatch
    def test_object(object, method_name):
        print('test {} for {}'.format(method_name, object.__class__))
        print('  instance?', isinstance(object, object.__class__))
        print('  subclass?', issubclass(object.__class__, object.__class__))
        print('  generator?', isinstance(object, types.GeneratorType))


# Generated at 2022-06-24 09:17:46.913549
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.full() == False
    q.put("one")
    assert q.qsize() == 1
    assert q.full() == False
    q.put("two")
    assert q.qsize() == 2
    assert q.full() == True
    q.get_nowait()
    assert q.qsize() == 1
    assert q.full() == False

    class TestQueue(unittest.TestCase):
        def test_Queue_full(self):
            q = Queue(maxsize=2)
            self.assertEqual(q.qsize(), 0)
            self.assertFalse(q.full())
            q.put("one")

# Generated at 2022-06-24 09:17:52.504302
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.get_nowait() == 3
    assert q.get_nowait() == 2
    assert q.get_nowait() == 1

# Generated at 2022-06-24 09:17:54.497498
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)
    print(dir(Queue.__init__))
    pass



# Generated at 2022-06-24 09:18:05.290636
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    q = Queue()

    # empty queue
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "should raise QueueEmpty"

    # non-empty queue
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    # get item from queue
    assert q.get_nowait() == 1
    # get items until empty queue
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "should raise QueueEmpty"


# Generated at 2022-06-24 09:18:08.161915
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:18:16.634388
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert (q.get_nowait() == (0, 'high-priority item'))
    assert (q.get_nowait() == (1, 'medium-priority item'))
    assert (q.get_nowait() == (10, 'low-priority item'))


# Generated at 2022-06-24 09:18:27.207579
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2) 
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit

# Generated at 2022-06-24 09:18:35.352497
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue[int]()
    it = q.__aiter__()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert it.__anext__().result() == 1
    assert it.__anext__().result() == 2
    assert it.__anext__().result() == 3
    try:
        it.__anext__()
        raise AssertionError()
    except StopAsyncIteration:
        pass
test_Queue___aiter__()

# Generated at 2022-06-24 09:18:37.389333
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    try:
        # set up
        q = Queue(0)
    except Exception:
        # tear down
        raise


# Generated at 2022-06-24 09:18:41.835825
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=1)
    async def main():
        # Wait for consumer to finish all tasks.
        await q.join()

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-24 09:18:53.416578
# Unit test for method full of class Queue
def test_Queue_full():
    if not isinstance(Queue.full(), bool):
        return False
    q1 = Queue(maxsize=0)
    if not q1.full() == False:
        return False
    q2 = Queue(maxsize=5)
    if not q2.full() == False:
        return False
    q3 = Queue(maxsize=5)
    q3.put(1)
    if not q3.full() == False:
        return False
    q4 = Queue(maxsize=5)
    q4.put(1)
    q4.put(1)
    q4.put(1)
    q4.put(1)
    q4.put(1)
    if not q4.full() == True:
        return False
    return True


# Generated at 2022-06-24 09:18:59.776623
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=2)
    # maxsize=None 触发 ValueError
    try:
        queue = Queue(maxsize=None)
    except TypeError:
        print("maxsize can't be None")
    # maxsize=-1 触发 ValueError
    try:
        queue = Queue(maxsize=-1)
    except ValueError:
        print("maxsize can't be negative")


# Generated at 2022-06-24 09:19:03.767200
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:19:06.922559
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    q.put(3)
    async def func():
        v = await it.__anext__()
        assert v == 3
    ioloop.IOLoop.current().run_sync(func)



# Generated at 2022-06-24 09:19:12.352759
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty("a")
    assert a is not None
    if False:
        a.args
    if False:
        a.message
    assert a.__reduce_ex__(1) is not None
    assert a.__reduce__() is not None
    assert a.__getstate__() is None


# Generated at 2022-06-24 09:19:23.220511
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # maxsize given
    q = Queue(3)
    q.put_nowait(1)
    assert q.get_nowait() == 1
    # maxsize default
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1

    # raise an exception if the queue is empty
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    # raise an exception if the queue is empty and we try to get one object
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.get_nowait()
    q.get_nowait()

# Generated at 2022-06-24 09:19:25.646554
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        print(e.__class__.__name__)



# Generated at 2022-06-24 09:19:35.628571
# Unit test for method empty of class Queue
def test_Queue_empty():
    import asyncio
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import unittest


    class TaskQueue(tornado.queues.Queue):
        def __init__(self, maxsize=0):
            super().__init__(maxsize=maxsize)
            self.tasks = []

        def _put(self, i):
            self.tasks.append(i)

        def _get(self):
            return self.tasks.pop()


    class QueueTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.queue = TaskQueue(maxsize=1)

        def tearDown(self):
            self.io_loop.close()