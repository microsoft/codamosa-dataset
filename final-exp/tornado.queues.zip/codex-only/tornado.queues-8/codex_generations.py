

# Generated at 2022-06-24 09:09:31.134676
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    pass



# Generated at 2022-06-24 09:09:36.936965
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(repr(q))
    q.put_nowait(1)
    print(repr(q))
    q.put_nowait(2)
    print(repr(q))
    q.get_nowait()
    print(repr(q))



# Generated at 2022-06-24 09:09:45.955233
# Unit test for method get of class Queue
def test_Queue_get():
    def __put_internal(item):
        pass
    def __init__(self, maxsize = 0):
        pass
    q = Queue()
    q.__init__ = __init__
    q.__put_internal = __put_internal
    q._putters = collections.deque()
    q._get = lambda: 1
    assert q.get() == 1
    q._putters = collections.deque([(1, Future())])
    q._putters[0][1].set_result(None)
    q.maxsize = 0
    assert q.get() == 1



# Generated at 2022-06-24 09:09:50.724566
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    q.put_nowait(3)
    q_i = _QueueIterator(q)
    try:
        assert(q_i.q)
        # print("q_i.q: %s", q_i.q)
    except AssertionError:
        print("Error: QueueIterator does not contain a queue.")


# Generated at 2022-06-24 09:09:51.359508
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    return QueueEmpty("message")


# Generated at 2022-06-24 09:09:53.242419
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    print("test_QueueEmpty")
    queue_empty=QueueEmpty()
    print(queue_empty)


# Generated at 2022-06-24 09:10:03.430529
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue

    queue = Queue(maxsize=1)
    queue.getters = [1, 2]
    queue.putters = [1, 2]
    queue.tasks = 2
    queue.queue = [1, 2]
    # call the method
    str_get = queue.__repr__()
    str_right = '<Queue at 0x7f4b3390ef98 maxsize=1 queue=[1, 2] getters[2] putters[2] tasks=2>'
    assert str_get == str_right

# end class Queue



# Generated at 2022-06-24 09:10:11.737303
# Unit test for method put of class Queue
def test_Queue_put():
    # From http://asyncio.readthedocs.io/en/latest/queues.html
    # Queue represents a queue where you can put items in one end and take them
    # from the other end. It can be a FIFO (First In First Out) queue or a LIFO
    # (Last In First Out) queue.
    import asyncio
    queue = asyncio.Queue()

    async def consumer():
        while True:
            item = await queue.get()
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                queue.task_done()

    async def producer():
        for item in range(5):
            await queue.put(item)
            print('Put %s' % item)


# Generated at 2022-06-24 09:10:13.423505
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        pass

# Unit test
QueueFull()


# Generated at 2022-06-24 09:10:15.357631
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    assert(str(e) == 'Queue is empty')


# Generated at 2022-06-24 09:10:18.725893
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("test")
    except QueueFull as e:
        if e.__str__() != "test":
            raise



# Generated at 2022-06-24 09:10:22.154180
# Unit test for method put of class Queue
def test_Queue_put():
    item = 5
    q = Queue(maxsize=2)
    q.put(item)
    assert q._queue[0] == item



# Generated at 2022-06-24 09:10:29.646705
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    #Queue.put_nowait(item)
    #Put an item into the queue without blocking.
    #
    #    If no free slot is immediately available, raise ``QueueFull``.
    q = Queue(maxsize=2, loop=None)
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full()
    try:
        q.put_nowait(3)
    except QueueFull:
        assert q.qsize() == 2
    else:
        assert False



# Generated at 2022-06-24 09:10:35.262905
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get() == 1
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get() == 2
    assert q.get() == 3
# Test Queue.qsize()

# Generated at 2022-06-24 09:10:38.690281
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        # Test constructor
        full_queue = QueueFull()

        # Test the error message
        try:
            full_queue.__str__()
        except Exception as e:
            assert False, "Error: " + str(e)
    except Exception as e:
        assert Fals

# Generated at 2022-06-24 09:10:44.269513
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    try:
        assert q.full() is False
        q.put_nowait(0)
        assert q.full() is False
        q.put_nowait(0)
        assert q.full() is True
    except QueueFull:
        assert False


# Generated at 2022-06-24 09:10:49.065148
# Unit test for method put of class Queue
def test_Queue_put():
    foo = ioloop.IOLoop.current()
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        # first try
        q.put_nowait(3)
    except:
        pass



# Generated at 2022-06-24 09:10:54.200179
# Unit test for constructor of class Queue
def test_Queue():
    assert Queue().maxsize == 0
    assert Queue(0).maxsize == 0
    assert Queue(1).maxsize == 1
    assert Queue(None).maxsize == 0
    assert Queue(-1).maxsize == 0
    try:
        Queue(maxsize=1)
    except TypeError:
        pass
    else:
        raise Exception("Did not detect type error")



# Generated at 2022-06-24 09:10:58.888215
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq = PriorityQueue()
    pq.put((1, 'medium-priority item'))
    pq.put((0, 'high-priority item'))
    pq.put((10, 'low-priority item'))
    assert pq.get_nowait() == (0, 'high-priority item')
    assert pq.get_nowait() == (1, 'medium-priority item')
    assert pq.get_nowait() == (10, 'low-priority item')

# Test PriorityQueue with typed tuples

# Generated at 2022-06-24 09:11:06.084732
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
        print("put_nowait success")
    except QueueFull:
        print("queue full")
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()


# Generated at 2022-06-24 09:11:08.130500
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 09:11:19.651036
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
                assert item == 1, item
            finally:
                q.task_done()
        assert False, 'Queue __aiter__ did not yield anything'

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine  # test case
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.

# Generated at 2022-06-24 09:11:22.423382
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass


# Generated at 2022-06-24 09:11:24.032317
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass


# Generated at 2022-06-24 09:11:26.466921
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()

    print(e)



# Generated at 2022-06-24 09:11:29.900722
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:11:31.172303
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    print(q.qsize())
    print(q.empty())
    print(q.full())


# Generated at 2022-06-24 09:11:34.457186
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import queue
    q = queue.Queue()
    q.put(1)
    q.put('foo')  #__queue.put(item, block=False)
    q.put(5)
    print(q.qsize()) #Return the approximate size of the queue.   __queue.qsize()
    q.get()
    q.task_done() # Indicate that a formerly enqueued task is complete.
    q.get()
    q.task_done()
    print(q.qsize())
#test_Queue_qsize()




# Generated at 2022-06-24 09:11:36.753189
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q._maxsize == 2
    assert not q.empty()
    assert q.qsize() == 0
    assert not q.full()


# Generated at 2022-06-24 09:11:38.481345
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    assert q.maxsize == 2


# Generated at 2022-06-24 09:11:40.785868
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        # TODO: test for the correct error message and other attributes
        print('got here')


# Generated at 2022-06-24 09:11:48.113167
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def test():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
        print('Done')
        await q.join()

    IOLoop.current().run_sync(test)


# Generated at 2022-06-24 09:11:52.695241
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    f = q.put('t')
    assert(f.result() == None)
    q.put_nowait('t2')
    assert(q.qsize() == 2)
    assert(q.full() == True)

# Generated at 2022-06-24 09:11:59.629681
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:12:00.246718
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    assert True


# Generated at 2022-06-24 09:12:04.912434
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()

    ret_1 = q.full()
    print(ret_1)
    # False

    q._maxsize = 1
    q._queue = collections.deque()
    q._queue.append(1)

    ret_2 = q.full()
    print(ret_2)
    # True


# Generated at 2022-06-24 09:12:08.375738
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:12:12.606426
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    ret = it.__anext__()
    assert asyncio.iscoroutine(ret)



# Generated at 2022-06-24 09:12:15.970555
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.qsize() == 3
    assert q.empty() == False

# test for method get_nowait() of class LifoQueue

# Generated at 2022-06-24 09:12:23.795596
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    ## queue_repr_test
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at %x maxsize=2>" % id(q)
    q.put_nowait(10)
    q.put_nowait(20)
    assert repr(q) == "<Queue at %x maxsize=2 queue=deque([10, 20])>" % id(q)
    q.get_nowait()
    assert repr(q) == "<Queue at %x maxsize=2 queue=deque([20])>" % id(q)
    ## queue_repr_test



# Generated at 2022-06-24 09:12:26.467075
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put("abc")
    assert ("abc", True) == (q.get_nowait(), True)
    return

# Generated at 2022-06-24 09:12:30.767210
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q._maxsize == 0
    assert q._queue is not None
    assert len(q._getters) == 0
    assert len(q._putters) == 0
    assert q._unfinished_tasks == 0
    assert not q._finished.is_set()



# Generated at 2022-06-24 09:12:31.410620
# Unit test for method empty of class Queue
def test_Queue_empty():
    pass

# Generated at 2022-06-24 09:12:37.762870
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue
    q = Queue(maxsize=0, _queue=[1, 2, 3])
    # See http://bugs.python.org/issue3710
    assert str(q) == str(q).replace("L", "")
    assert str(q).replace(",)>", ")>").replace(",)", ")") == "<Queue maxsize=0 queue=[1, 2, 3]>"
    q._queue.clear()
    assert str(q) == "<Queue maxsize=0>"
    assert str(q).replace(",)>", ")>").replace(",)", ")") == "<Queue maxsize=0>"


# Generated at 2022-06-24 09:12:39.732716
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-24 09:12:49.376076
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    def test_Queue_put_nowait_add_one_elem_if_not_full(test_Queue_put_nowait_obj: Queue[_T]) -> None:
        test_Queue_put_nowait_obj._queue = ["item1"]
        test_Queue_put_nowait_obj._getters = [Future]
        test_Queue_put_nowait_obj.put_nowait("item2")
        assert test_Queue_put_nowait_obj._queue == ["item1", "item2"]
        assert test_Queue_put_nowait_obj._getters == []

    def test_Queue_put_nowait_putters_should_be_empty_if_not_full(test_Queue_put_nowait_obj: Queue[_T]) -> None:
        test_Queue_put_now

# Generated at 2022-06-24 09:12:55.601075
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:13:00.824534
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    class A:
        def __init__(self) -> None:
            self.x = 0
        def get(self):
            return self.x + 1

    a = A()
    q = _QueueIterator(a)
    print(q.__anext__())



# Generated at 2022-06-24 09:13:10.818742
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(1)
    # Test execution of call when there are waiters (getters)
    assert q.qsize() == 0
    assert len(q._getters) == 0
    assert not q.empty()
    assert q.full()
    f = Future()
    q._getters.append(f)
    q.__put_internal(1)
    assert q.qsize() == 1
    assert len(q._getters) == 0
    assert not q.empty()
    assert q.full()
    # Test execution of call when there are waiters (putters)
    assert q.qsize() == 1
    assert len(q._putters) == 0
    assert not q.empty()
    assert q.full()
    f = Future()
    item = 1

# Generated at 2022-06-24 09:13:14.059773
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full() == 0
    q.put_nowait(3)
    assert q.full() == 1

# Generated at 2022-06-24 09:13:21.266017
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Positive test case
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
    except Exception:
        assert True
    try:
        q.get_nowait()
        q.get_nowait()
        assert True
    except Exception:
        assert False

    # Negative test case
    q = Queue(maxsize=1)
    try:
        q.put_nowait(1)
        assert True
    except Exception:
        assert False
    try:
        q.get_nowait()
    except Exception:
        assert False
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-24 09:13:30.891418
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    # Create a queue
    q = Queue(maxsize=3)


    # Generate a callback to pass to Queue.put which should return True
    future = Future()
    future.set_result(None)
    cb = lambda _: future


    # Call Queue.put with a timeout value that should raise a
    # TimeoutError exception
    timeout = 0.0
    timeout_error = False
    try:
        r = q.put(1, timeout, cb)
    except gen.TimeoutError:
        timeout_error = True
    assert timeout_error


    # Call Queue.put with a timeout value that should not raise an
    # exception
    timeout_error = False
    timeout = 1.0

# Generated at 2022-06-24 09:13:37.641464
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__(): 
    def example__QueueIterator___anext__(self):
        q = Queue()
        q.put(1)
        # Make sure the coroutine runs with an empty queue.
        yield gen.moment
        # The queue was empty above, so this will raise QueueEmpty.
        try:
            i = _QueueIterator(q)
            # The second call will be a no-op.
            yield i.__anext__()
        except gen.Return:
            pass



# Generated at 2022-06-24 09:13:43.063370
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import logging
    import sys

    def test(q: Queue[_T]) -> None:
        async def test_coro() -> None:
            async for v in q:
                assert v == 1
                return
        asyncio.run(test_coro())
    q = Queue()
    q.put(1)
    test(q)



# Generated at 2022-06-24 09:13:54.597822
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import random
    import string
    import time

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            q.task_done()
        print('Done consuming')
        return 0

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
        print('Done producing')
        return 0

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:13:57.947542
# Unit test for constructor of class Queue
def test_Queue():
    try:
        Queue(maxsize = 2)
        Queue(maxsize = None)
        Queue(maxsize = -1)
        assert False
    except TypeError:
        pass
    except ValueError:
        pass
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-24 09:14:10.292915
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.empty()
    q._init()
    # Case1: qsize() > 0
    q._queue = collections.deque(["a", "b", "c"])
    q._putters = collections.deque([("d", None)])
    item = q.get_nowait()
    assert item == "a"
    assert q._queue == collections.deque(["b", "c"])
    assert q._putters == collections.deque([("d", None)])
    # Case2: qsize() == 0
    q._queue = collections.deque([])
    q._putters = collections.deque([("d", None)])
    item = q.get_nowait()
    assert item == "d"
    assert q._queue == collections

# Generated at 2022-06-24 09:14:20.448156
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import pytest
    from tornado.concurrent import Future

    q = Queue(3)

    def put_item(item: int, timeout: Optional[Union[None, float, datetime.timedelta]] = None) -> Future:
        f = Future()
        q.put(item, timeout=timeout)
        future_set_result_unless_cancelled(f, None)
        return f

    # Result: [1, 2, 3]
    @gen.coroutine
    def test_case_1():
        for item in _QueueIterator(q):
            yield item
            assert False

    # Result: [1, 2]
    @gen.coroutine
    def test_case_2():
        for item in _QueueIterator(q):
            yield item
            break

    # Result: [2, 3]
   

# Generated at 2022-06-24 09:14:23.350701
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:26.110505
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qfull = QueueFull(10,20)
    assert qfull.args==(10,20)

_F = TypeVar("_F", Awaitable[None], Future[None])



# Generated at 2022-06-24 09:14:28.221367
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty('Queue is empty.')
    except QueueEmpty as ex:
        print(ex.args[0])



# Generated at 2022-06-24 09:14:30.620054
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-24 09:14:32.798428
# Unit test for method join of class Queue
def test_Queue_join():
    arg = Queue()
    assert arg.join() == None, "Function join is not working"



# Generated at 2022-06-24 09:14:35.635118
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    
    assert q._unfinished_tasks == 0
    q.task_done()
    assert q._unfinished_tasks == 0

# Generated at 2022-06-24 09:14:37.967438
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass


# Generated at 2022-06-24 09:14:48.031907
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:14:51.658697
# Unit test for method full of class Queue
def test_Queue_full():
    q=Queue(maxsize=2)
    print(q.maxsize)
    q.put_nowait(1)
    q.put_nowait(2)
    if q.full():
        print("mở rộng maxsize")
test_Queue_full()


# Generated at 2022-06-24 09:14:57.607046
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    p00 = q.get_nowait()
    p01 = q.get_nowait()
    p02 = q.get_nowait()

    return True if p00==(0, 'high-priority item') and p01==(1, 'medium-priority item') and p02==(10, 'low-priority item') else False


# Generated at 2022-06-24 09:14:59.140750
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qf = QueueFull()
    assert isinstance(qf, Exception)


# Generated at 2022-06-24 09:15:04.152416
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=1)
    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() != True


# Generated at 2022-06-24 09:15:13.406900
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from typing import SupportsInt
    from unittest import mock
    from unittest.mock import Mock
    from datetime import timedelta
    from tornado.ioloop import IOLoop
    from tornado.log import gen_log
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.gen import gen_test, TimeoutError
    from pytest import raises
    from tornado_pytest import gen_test, sync_test
    import sys

    # Reset the list of supported ports.
    AsyncIOMainLoop.configure(reset=True)
    # Create a mocked IOLoop.
    asyncio_loop = Mock()
    io_loop = IOLoop(asyncio_loop=asyncio_loop)

    # Patch the get_event_loop function to use the mocked IOLoop.
   

# Generated at 2022-06-24 09:15:16.475030
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    a = Queue()
    a.put_nowait("TEST")
    assert len(a._queue) == 1
    assert a._queue[0] == "TEST"
    return



# Generated at 2022-06-24 09:15:18.198836
# Unit test for method full of class Queue
def test_Queue_full():
    if (Queue(2).full()):
        assert False
    else:
        assert True



# Generated at 2022-06-24 09:15:19.836900
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q)

# Generated at 2022-06-24 09:15:21.989423
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        QueueEmpty()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 09:15:26.512317
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q._unfinished_tasks = 0
    q.task_done()
    assert(q._unfinished_tasks == 0)
    q._unfinished_tasks = 1
    q.task_done()

# Generated at 2022-06-24 09:15:35.525560
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    assert Queue().__str__() == "<Queue maxsize=0>"
    assert Queue(maxsize = 1).__str__() == "<Queue maxsize=1>"
    assert Queue(maxsize = 2).__str__() == "<Queue maxsize=2>"
    assert Queue(maxsize = None).__str__() == "<Queue maxsize=0>"
    assert Queue(maxsize = -1).__str__() == "<Queue maxsize=0>"
    assert Queue(maxsize = -2).__str__() == "<Queue maxsize=0>"




# Generated at 2022-06-24 09:15:38.031373
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    assert Queue(maxsize=10).__str__() == "<Queue maxsize=10>"


# Generated at 2022-06-24 09:15:46.087751
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: ()-> None
    q = Queue()
    q.put_nowait(5)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(0)

    qi = _QueueIterator(q)
    assert(type(qi) == _QueueIterator)
    assert(qi.q == q)


# Generated at 2022-06-24 09:15:48.573166
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    assert q.join() == None
    assert q.join(timeout=None) == None

# Generated at 2022-06-24 09:15:53.733445
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import asyncio
    loop = asyncio.get_event_loop()
    q = Queue()
    assert q.empty()
    assert q.qsize() == 0 # Process the Queue element
    q.put('X')
    assert q.empty() == False # If the Queue element is not empty
    assert q.qsize() == 1 # If the Queue element has number of element == 1
    assert q.get_nowait() == 'X' # Return an item if one is immediately available, else raise QueueEmpty
    #assert q.get_nowait() == None # If the Queue is empty, return None
    assert q.empty()
    assert q.qsize() == 0
test_Queue_get_nowait()


# Generated at 2022-06-24 09:16:05.270179
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado.queues import Queue
    import threading
    import random
    import time
    import queue
    max_size = 5
    q = Queue(maxsize=max_size)
    count = 0
    lock = threading.Lock()
    # monitor thread
    def monitor_thread():
        while True:
            print(str(threading.current_thread()) +" queue size is "+ str(q.qsize()))
            if q.qsize() > max_size:
                print("queue size is larger than the maxsize: "+str(max_size))
                break
            time.sleep(1)
    # producer thread
    def producer_thread():
        while True:
            with lock:
                global count
                count += 1
                item = "test_item"+str(count)

# Generated at 2022-06-24 09:16:15.734862
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=0)

    def consumer():
        while True:
            item = q.get_nowait()
            print('Doing work on %s' % item)
            q.task_done()

    def producer():
        for item in range(5):
            q.put_nowait(item)
            print('Put %s' % item)

    producer()
    # Start consumer without waiting (since it never finishes).
    # IOLoop.current().spawn_callback(consumer)
    # await q.join()       # Wait for consumer to finish all tasks.
    # print('Done')

if __name__ == '__main__':
    test_Queue()



# Generated at 2022-06-24 09:16:25.641483
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test

    q = Queue(maxsize=2)

    async def consumer():
        try:
            async for item in q:
                try:
                    print("Doing work on %s" % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
        except Exception as e:
            print("e: "+str(e))

    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)


# Generated at 2022-06-24 09:16:31.637821
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    if not hasattr(q.__str__(), '__call__'):
        raise AssertionError
    q = Queue(10)
    if not hasattr(q.__str__(), '__call__'):
        raise AssertionError
    q.put_nowait('a')
    q.get_nowait()
    if not hasattr(q.__str__(), '__call__'):
        raise AssertionError


# Generated at 2022-06-24 09:16:34.288509
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('put_nowait')
    except QueueFull as e:
        print(e)


# Generated at 2022-06-24 09:16:42.035683
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Test a simple object
    a = Queue()
    assert repr(a) == "<Queue at {} maxsize=0>"

    # Test that only attributes are shown
    class Test1(Queue):
        __repr__ = None
    b = Test1()
    assert repr(b) == "<Test1 at {} maxsize=0>"

    # Test an object with __repr__ after __str__
    class Test2(Queue):
        def __str__(self):
            return "test2"
    c = Test2()
    assert repr(c) == "<Test2 at {} maxsize=0>"


# Generated at 2022-06-24 09:16:43.111167
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    repr(q)


# Generated at 2022-06-24 09:16:49.232794
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    _T = TypeVar("_T")
    q = Queue['_T']()
    q.put_nowait("test__QueueIterator___anext__")
    iterator = _QueueIterator['_T'](q)
    future = iterator.__anext__()
    if isinstance(future, Future):
        item = future.result()
        assert(item == "test__QueueIterator___anext__")
    else:
        item = future
        assert(item == "test__QueueIterator___anext__")



# Generated at 2022-06-24 09:16:55.243716
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=0)
    assert not q.full()
    q = Queue(maxsize=10)
    assert not q.full()
    for i in range(10):
        q.put_nowait(i)
    assert q.full()
    q.get_nowait()
    assert not q.full()


# Generated at 2022-06-24 09:16:58.058265
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    assert q.empty() == True

# Generated at 2022-06-24 09:17:06.422461
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    try:
        __anext__
    except NameError:
        pass
    else:
        raise RuntimeError('Could not overrite __anext__ of class _QueueIterator')
    from asyncio import coroutine
    from typing import get_type_hints
    from typing import List, Tuple
    from tornado import gen
    T = TypeVar('T')
    @coroutine
    def get(self: T) -> T:
        pass
    class Queue(Generic[T]):
        def __init__(self) -> None:
            pass
        def __aiter__(self: T) -> T:
            return self
    qi = _QueueIterator(Queue())

# Generated at 2022-06-24 09:17:11.102373
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue(0)
    print(queue)
    queue_with_items = Queue(0)
    queue_with_items._queue.append(2)
    queue_with_items._queue.append(3)
    print(queue_with_items)
    assert queue
    assert queue_with_items



# Generated at 2022-06-24 09:17:18.242652
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    q._init()
    q._queue = collections.deque([1,2])
    q._getters = collections.deque([])
    q._putters = collections.deque([])
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()

    if q._format() == "maxsize=2 queue=deque([1, 2])":
        print("So good!")
    else:
        print("Not so good!")

    res = q.__repr__()
    print(res)
    res = q.__str__()
    print(res)

if __name__ == '__main__':
    test_Queue___repr__()


# Generated at 2022-06-24 09:17:30.371847
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q
    assert q.qsize() == 0
    assert q.empty() == True
    assert q._queue == collections.deque()
    assert q._maxsize == 0
    q = Queue(1)
    assert q
    assert q.qsize() == 0
    assert q.empty() == True
    assert q._queue == collections.deque()
    assert q._maxsize == 1
    q = Queue(maxsize = 2)
    assert q
    assert q.qsize() == 0
    assert q.empty() == True
    assert q._queue == collections.deque()
    assert q._maxsize == 2
    try:
        q = Queue(maxsize = -2)
    except ValueError:
        assert True

# Generated at 2022-06-24 09:17:34.179601
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    msg = "message"
    qe = QueueEmpty(msg)
    assert qe.__cause__ is None
    assert qe.__context__ is None
    assert qe.args == (msg,)



# Generated at 2022-06-24 09:17:40.764622
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:17:46.058400
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:17:54.864067
# Unit test for constructor of class _QueueIterator
def test__QueueIterator(): # pragma: no cover
    import asyncio
    q = Queue()
    async def test():
        q.put_nowait(10)
        it = _QueueIterator(q)
        await q.put(20)
        await q.put(30)
        assert await it.__anext__() == 10
        assert await it.__anext__() == 20
        assert await it.__anext__() == 30
    asyncio.get_event_loop().run_until_complete(test())




# Generated at 2022-06-24 09:18:05.524211
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:08.571524
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    q.put_nowait(3)
    assert q.get_nowait() == 2

# Generated at 2022-06-24 09:18:21.333254
# Unit test for method put of class Queue
def test_Queue_put():
    import concurrent
    from tornado import gen
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_put(self):
            q = Queue()

            # Basic put/get.
            with self.assertRaises(QueueEmpty):
                q.get_nowait()
            q.put_nowait(1)
            self.assertEqual(1, q.get_nowait())

            # Non-blocking put.
            q = Queue(maxsize=1)
            q.put_nowait(1)
            with self.assertRaises(QueueFull):
                q.put_nowait(2)

            # Blocking put.
           

# Generated at 2022-06-24 09:18:31.877693
# Unit test for method put of class Queue
def test_Queue_put():
    # Set up initial state
    maxsize = 0
    _queue = None
    _maxsize = maxsize
    _init = Queue.__init__
    _getters = collections.deque([])
    _putters = collections.deque([])
    _unfinished_tasks = 0
    _finished = Event()
    _finished.set()
    _init = Queue._init
    _get = Queue._get
    _put = Queue._put
    item = 0
    timeout = None
    Queue.__init__(Queue, maxsize)
    Queue._init(Queue)
    future = Future()
    Queue.put_nowait(Queue, item)
    _putters.append((item, future))
    Queue.__put_internal(Queue, item)
    Queue.task_done

# Generated at 2022-06-24 09:18:36.856955
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
test_PriorityQueue()


# Generated at 2022-06-24 09:18:40.669789
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    q.put_nowait(1)
    q.get_nowait()
    q.task_done()
    q.join()
    print("Done")
    return True

# Generated at 2022-06-24 09:18:44.035310
# Unit test for method put of class Queue
def test_Queue_put():
    future = Future()  # type: Future[None]
    try:
        future.set_result(None)
    except:
        pass

# Generated at 2022-06-24 09:18:47.131320
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # This is for test of method __str__ of class Queue
    # The following assertion was not present:
    # assert False
    raise NotImplementedError()

# Generated at 2022-06-24 09:18:52.349604
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    print(q.qsize())
    q.put_nowait(1)
    q.put_nowait(2)
    print(q.get_nowait())
    print(q.get_nowait())

    try:
        q.get_nowait()
    except QueueEmpty as e:
        print(e)
      

# Generated at 2022-06-24 09:18:54.570687
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    """Unit test for constructor of class QueueEmpty."""
    empty = QueueEmpty()
    assert()


# Generated at 2022-06-24 09:18:56.043786
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue()
    q.put(1)
    q.join()
    q.task_done()


# Generated at 2022-06-24 09:19:04.769043
# Unit test for method full of class Queue
def test_Queue_full():
    # Initialize a Queue object with capacity = 5.
    test_Queue = Queue(maxsize = 5)
    # Assume no item in queue.
    assert test_Queue.full() == False
    # Push four items into queue.
    test_Queue.put_nowait(0)
    test_Queue.put_nowait(1)
    test_Queue.put_nowait(2)
    test_Queue.put_nowait(3)
    assert test_Queue.full() == False
    # Push the fifth item into queue.
    test_Queue.put_nowait(4)
    assert test_Queue.full() == True



# Generated at 2022-06-24 09:19:07.937500
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(5)
    q.get_nowait()
    print(q.qsize())



# Generated at 2022-06-24 09:19:14.393589
# Unit test for constructor of class Queue
def test_Queue():
    # type: () -> None
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.empty()
    assert not q.full()
    assert q.qsize() == 0
    assert q.__repr__() == "<Queue at 0x7f0cd3c0a140 maxsize=2 queue=deque([])>"
    assert q.__str__() == "<Queue maxsize=2 queue=deque([])>"


# Generated at 2022-06-24 09:19:26.607369
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)

    # Check empty when used default construction with Size 0
    assert not q.empty();

    try:
        q.put(1)
        # Check empty when used default construction
        assert not q.empty();
    except QueueFull:
        pass
    try:
        q.put(3)
        # Check empty when used default construction
        assert not q.empty();
    except QueueFull:
        pass
    try:
        q.put(2)
    except QueueFull:
        # Check empty when q is full
        assert not q.empty();
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    # Check empty when q is empty
    assert q.empty()


# Generated at 2022-06-24 09:19:27.744762
# Unit test for method empty of class Queue
def test_Queue_empty():
    q=Queue()
    assert q.empty() == True

# Generated at 2022-06-24 09:19:38.383700
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    from tornado.queues import LifoQueue
    # Initial check
    q = LifoQueue()
    assert (not q.full()), "Cannot be full"
    assert q.empty(), "Cannot be full"
    assert (q.maxsize == 0), "Max size should be 0"
    assert ((q.qsize() == 0) and (len(q._queue) == 0)), "Size should be 0"
    assert (not q._getters), "Queue is empty"
    
    # Try to put something on the queue
    q.put(3)
    assert (not q.full()), "Cannot be full"
    assert (not q.empty()), "Cannot be empty"
    assert (q.maxsize == 0), "Max size should be 0"