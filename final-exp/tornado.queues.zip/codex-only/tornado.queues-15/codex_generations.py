

# Generated at 2022-06-24 09:09:35.489886
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize = 10)
    q.put(1)
    q.put(2)
    assert q.qsize() == 2


# Generated at 2022-06-24 09:09:39.503949
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, "two"))
    q.put((0, "one"))
    q.put((3, "four"))
    q.put((2, "three"))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:09:50.683719
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:09:57.247553
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-24 09:09:57.808849
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    a = LifoQueue()

# Generated at 2022-06-24 09:09:59.326238
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()


# Generated at 2022-06-24 09:10:01.539566
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q = Queue()


# Generated at 2022-06-24 09:10:04.383217
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        print(str(e))


# Generated at 2022-06-24 09:10:08.439105
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1, "test_Queue_get_nowait error"
    assert len(q._queue) == 1, "test_Queue_get_nowait error"
    q.put_nowait(3)
    assert q.get_nowait() == 2, "test_Queue_get_nowait error"
    assert q.get_nowait() == 3, "test_Queue_get_nowait error"
    assert len(q._queue) == 0, "test_Queue_get_nowait error"
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True, "test_Queue_get_nowait error"


# Generated at 2022-06-24 09:10:20.006022
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:10:26.795673
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    q.get()
    q.get()

    assert not q.join(timeout=0.1)
    assert q.join(timeout=0.1)
    assert q.join()
    assert not q.join(timeout=0.01)

# Generated at 2022-06-24 09:10:32.519231
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    # size of empty queue is zero
    assert q.qsize()==0
    q.put_nowait(10)
    assert q.qsize()==1
    q.put_nowait(20)
    assert q.qsize()==2
    q.get_nowait()
    assert q.qsize()==1
    q.get_nowait()
    assert q.qsize()==0


# Generated at 2022-06-24 09:10:35.359558
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:10:40.425437
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    assert q.empty() == True, "queue is not empty"
    q.put_nowait(1)
    assert q.empty() == False, "queue is empty"
    q.task_done()
    assert q.empty() == True, "queue is not empty"
    try:
        q.task_done()
    except ValueError:
        pass
    else:
        assert False, "ValueError is not raised"


test_Queue_task_done()

# Generated at 2022-06-24 09:10:44.564337
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q=Queue()
    q.put(5)
    try:
        i=q.get_nowait()
        print(i)
    except QueueEmpty:
        print('error')

# Generated at 2022-06-24 09:10:45.911919
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass



# Generated at 2022-06-24 09:10:55.645976
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == '<Queue at 0x%x maxsize=2>' % id(q)
    q.put(1)
    assert repr(q) == '<Queue at 0x%x maxsize=2 queue=[1]>' % id(q)
    q.put(2)
    assert repr(q) == '<Queue at 0x%x maxsize=2 queue=[1, 2]>' % id(q)
    q.get()
    assert repr(q) == '<Queue at 0x%x maxsize=2 queue=[2]>' % id(q)
    q.get()
    assert repr(q) == '<Queue at 0x%x maxsize=2>' % id(q)



# Generated at 2022-06-24 09:10:57.375428
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:10:59.016954
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q = Queue(1)
    q = Queue(maxsize=-1)
    q = Queue(maxsize="1")


# Generated at 2022-06-24 09:11:04.125673
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    """test method Queue.__aiter__

    """
    q = Queue()
    for i in range(5):
        q.put_nowait(i)
    assert [i for i in q] == [0, 1, 2, 3, 4]



# Generated at 2022-06-24 09:11:12.605521
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    from tornado import locks
    import asyncio
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    @asyncio.coroutine
    def _test():
        iterator = _QueueIterator(q)
        assert (yield from iterator.__anext__()) == 1
        assert (yield from iterator.__anext__()) == 2
        assert (yield from iterator.__anext__()) == 3

    loop = locks.EventLoop()
    loop.run_sync(_test)



# Generated at 2022-06-24 09:11:15.657332
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue(maxsize=10)
    assert queue.qsize() == 0
    assert queue.empty() is True
    assert queue.full() is False


# Generated at 2022-06-24 09:11:17.041677
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    assert isinstance(_QueueIterator(Queue()), _QueueIterator)
    assert isinstance(_QueueIterator(DequeQueue()), _QueueIterator)
    assert isinstance(_QueueIterator(PriorityQueue()), _QueueIterator)



# Generated at 2022-06-24 09:11:21.752356
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()

    # Fill queue with values 0..9
    future_values = []
    for i in range(10):
        future_values.append(q.put(i))
    for value in future_values:
        ioloop.IOLoop.current().run_sync(lambda: value)

    assert len(q._queue) == 10

    q_iter = q.__aiter__()
    assert q_iter.__await__() is not None

    # Read all items from the queue
    for _ in range(10):
        item = ioloop.IOLoop.current().run_sync(lambda: q_iter.__anext__())
        assert type(item) == int
    assert item == 9  # last value

    # Trying to read from queue should raise QueueEmpty

# Generated at 2022-06-24 09:11:23.163268
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    a = Queue()
    a.put_nowait(1)
    a.put_nowait(2)
    a.put_nowait(3)
    a.put_nowait(4)

# Generated at 2022-06-24 09:11:29.103133
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3




# Generated at 2022-06-24 09:11:34.192006
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    scheduler = ioloop.IOLoop.current()
    def _test_coro():
        q = Queue()
        q.put_nowait(4)
        it = _QueueIterator(q)
        x = yield from it.__anext__()
        assert x == 4
    scheduler.add_callback(lambda : asyncio.run(_test_coro()))
    scheduler.add_callback(scheduler.stop)
    scheduler.start()



# Generated at 2022-06-24 09:11:44.196365
# Unit test for method task_done of class Queue
def test_Queue_task_done():

	import pytest
	from contextlib import suppress
	from tornado import gen
	from tornado.ioloop import IOLoop
	from tornado.queues import Queue

	q = Queue()

	@gen.coroutine
	def add_items():
		for i in range(10):
			yield q.put(i)

	@gen.coroutine
	def test():
		yield add_items()

		# task_done() is called when handling each of the items
		@gen.coroutine
		def fail_task_done():
			try:
				while True:
					yield q.get()
					yield gen.sleep(0)
			except Exception:
				q.task_done()

		# task

# Generated at 2022-06-24 09:11:49.053307
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize = 2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty:
        print("QueueEmpty exception")


# Generated at 2022-06-24 09:11:57.662059
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado import ioloop
    from tornado.locks import Event
    # Test the actual method __repr__ of class Queue.
    # Test for case where attribute _queue does not exist.
    _Queue = Queue()
    _Queue._queue = None
    _Queue._getters = collections.deque()
    _Queue._putters = collections.deque()
    _Queue._unfinished_tasks = 0
    _Queue._finished = Event()
    _Queue._finished.set()
    _Queue.maxsize = 0
    assert _Queue.__repr__() == "<Queue at 0x%x maxsize=0>"%id(_Queue)
    # Test for case where attribute _queue exists.
    _Queue._queue = collections.deque([1, 2, 3])
    _Queue._getters = collections.deque()


# Generated at 2022-06-24 09:12:00.762973
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    for i in range(10):
        queue.put_nowait(i)
    for i in range(10):
        assert queue.get_nowait() == i


# Generated at 2022-06-24 09:12:02.240428
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty

QueueFull = gen.QueueFull


# Generated at 2022-06-24 09:12:10.869521
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import tornado
    import tornado.testing

    q = Queue(maxsize=2)

    @tornado.gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put {}'.format(item))
        yield q.join()
        print('Producer Done!')

    @tornado.gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on {}'.format(item))
                yield q.join()
                yield tornado.gen.sleep(0.01)
            finally:
                q.task_done()


# Generated at 2022-06-24 09:12:15.577934
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q._init()
    q._queue.append(1)
    q._queue.append(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2



# Generated at 2022-06-24 09:12:16.582711
# Unit test for constructor of class QueueFull
def test_QueueFull():
    e = QueueFull()
    assert isinstance(e, Exception)



# Generated at 2022-06-24 09:12:26.752772
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    import time
    import threading
    import logging
    logging.basicConfig(filename='test_Queue_join.log',level=logging.DEBUG)
    logging.debug("Queue: start")
    q = Queue(maxsize=2)
    def work(item, q_len):
        print("Doing work: thread: %s - item: %s - q_len: %s" % ( threading.current_thread(), item, q_len))
        logging.debug("Doing work: thread: %s - item: %s - q_len: %s" % ( threading.current_thread(), item, q_len))
    async def worker():
        async for item in q:
            work(item, q.qsize())
           

# Generated at 2022-06-24 09:12:33.827765
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import random
    import threading

    class WordGenerator(threading.Thread):
        def __init__(self, queue):
            super(WordGenerator, self).__init__()
            self.queue = queue

        def run(self):
            word_list = [
                'hello',
                'world',
                'iterable',
                'queue',
                'computer',
                'science',
                'haha',
            ]

            while True:
                time.sleep(1)
                self.queue.put(random.choice(word_list))
                print("put word")

    q = Queue(maxsize=10)
    wg = WordGenerator(q)
    wg.start()


# Generated at 2022-06-24 09:12:40.494725
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(4)
    q.put_nowait(8)
    q.put_nowait(16)
    a = 0
    for i in q:
        a = a + i
    assert a == 31

# Generated at 2022-06-24 09:12:42.787659
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0

# Generated at 2022-06-24 09:12:50.892318
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x7f8f8e63c668 maxsize=0 queue=deque([])>"

    q.put_nowait(1)
    assert repr(q) == "<Queue at 0x7f8f8e63c668 maxsize=0 queue=deque([1])>"

    q.put_nowait(2)
    assert repr(q) == "<Queue at 0x7f8f8e63c668 maxsize=0 queue=deque([1, 2])>"

    q.get_nowait()
    assert repr(q) == "<Queue at 0x7f8f8e63c668 maxsize=0 queue=deque([2])>"

    q.get_nowait()

# Generated at 2022-06-24 09:12:56.952316
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ = Queue()
    assert QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ

# Generated at 2022-06-24 09:12:59.820443
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except Exception as e:
        assert e.__class__ == QueueFull



# Generated at 2022-06-24 09:13:04.165633
# Unit test for method full of class Queue
def test_Queue_full():
    # Create an instance of Queue
    q = Queue()

    # Call the method
    result = q.full()

    # Check if the result is false
    if result:
        print("FAILED")
    else:
        print("SUCCESS")


# Generated at 2022-06-24 09:13:08.420377
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, "medium-priority item"))
    q.put((0, "high-priority item"))
    q.put((10, "low-priority item"))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:13:11.711378
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    try:
        q.put_nowait(5)
    except e as QueueFull:
        print(e)
    else:
        print("qqq")


# Generated at 2022-06-24 09:13:13.304959
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"


# Generated at 2022-06-24 09:13:19.118115
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    f =  q.put(1)
    assert isinstance(f, Future)
    assert f.done()
    q.put_nowait(1)
    assert len(q.putters) == 0
    assert q.qsize() > 0
    try:
        q.put_nowait(1)
    except Exception as e:
        assert isinstance(e, QueueFull)
    assert len(q.putters) == 1
    assert q.qsize() == 2


# Generated at 2022-06-24 09:13:22.207577
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import AsyncTestCase, gen_test

    class _TestCase(_AsyncTestCase):
        @gen_test
        def test_test__QueueIterator___anext__(self: '_TestCase') -> None:
            async def testCode():
                async with _QueueIterator(None) as it:
                    pass

            await testCode()

    _TestCase().run()



# Generated at 2022-06-24 09:13:25.903327
# Unit test for constructor of class QueueFull
def test_QueueFull():
    with pytest.raises(QueueFull) as excinfo:
        raise QueueFull('test message')
    assert 'test message' in str(excinfo.value)


# Generated at 2022-06-24 09:13:33.461718
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    assert q._queue == [1, 2]
    print(q)
    assert q.qsize() == 2
    assert q.full() is False
    q.task_done()
    q.task_done()
    assert q.join() is None
    q.get_nowait()
    q.put_nowait(3)
    assert q.empty() is False
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:13:38.800309
# Unit test for method get of class Queue
def test_Queue_get():
    def run_test(test):
        @gen.coroutine
        def f():
            q = Queue()
            yield q.put(1)
            yield gen.moment
            val = yield q.get()
            test.assertEqual(1, val)
        ioloop.IOLoop.current().run_sync(f)

    run_test(self)

# Generated at 2022-06-24 09:13:46.114127
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from asyncio import Queue as StdQueue
    from tornado import gen
    from tornado.ioloop import IOLoop

    q = Queue()

    async def consumer(st):
        cnt = 0
        async for item in q:
            assert item == st + cnt
            cnt += 1
            await gen.sleep(0.01)
        assert cnt == 5

    async def producer():
        for item in range(5):
            await q.put(item)
        await q.join()

    async def main():
        tasks = []
        for i in range(5):
            tasks.append(IOLoop.current().spawn_callback(consumer, i))
        tasks.append(IOLoop.current().spawn_callback(producer))
        await gen.wait(tasks)

    IOLoop.current().run

# Generated at 2022-06-24 09:13:56.843445
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    for i in range(2):
        assert not q.full(), "queue not full, why are putters waiting?"
        q.put_nowait(i)
        assert q.full(), "queue full, why are putters waiting?"
    assert 2 == q.qsize(), "the qsize of queue should be 2"
    q.get_nowait()
    assert not q.full(), "queue not full, why are putters waiting?"
    q.put_nowait(2)
    assert q.full(), "queue full, why are putters waiting?"
    q.get_nowait()
    assert not q.full(), "queue not full, why are putters waiting?"
    q.get_nowait()
    assert q.empty(), "the queue should be empty"
    assert not q

# Generated at 2022-06-24 09:14:00.552430
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert(q.empty() == True)
    q.put(1)
    assert(q.empty() == False)


# Generated at 2022-06-24 09:14:07.778092
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # Runs a test of the implementation of _QueueIterator.__anext__
    # Preconditions:
    #   q is an existing object of class Queue
    # Postconditions:
    #   Checking the implementation of the method __anext__ for class _QueueIterator
    # Constraints:
    #   q must be an object of class Queue
    pass
# Test for method __anext__ of class _QueueIterator



# Generated at 2022-06-24 09:14:11.568484
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.qsize() == 3, "qsize incorrect"
    assert q._queue[0] == 1, "first element incorrect"
    assert q._queue[1] == 2, "second element incorrect"
    assert q._queue[2] == 3, "third element incorrect"
    assert q.get_nowait() == 1, "first element incorrect"
    assert q.get_nowait() == 2, "second element incorrect"
    assert q.get_nowait() == 3, "third element incorrect"


# Generated at 2022-06-24 09:14:13.891970
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    result = q.get()
    print(result)



# Generated at 2022-06-24 09:14:18.699937
# Unit test for method full of class Queue
def test_Queue_full():
    try:
        import Queue
    except:
        from queue import Queue

    q = Queue(2)
    q.put(1)
    q.put(2)
    assert q.full()
    try:
        q.put("hello")
    except QueueFull:
        assert True


# Generated at 2022-06-24 09:14:24.852302
# Unit test for method full of class Queue
def test_Queue_full():
    # Queue.full():return a boolean which is False if queue is
    # at its maximum size.
    q = Queue(maxsize=2)
    # Test when q is not full.
    assert q.full() is False, "it should be False"
    q.put_nowait(1)
    assert q.full() is False, "it should be False"
    q.put_nowait(2)
    # Test when q is full.
    assert q.full() is True
    # Test what will happen if put_nowait is called when q is full.
    try:
        q.put_nowait(3)
    except QueueFull:
        print("put_nowait(3) raises QueueFull when queue is full.")
        assert q.full() is True
    assert q.empty() is False
   

# Generated at 2022-06-24 09:14:28.046034
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:32.639122
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:14:43.975481
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    from .utils import TestCase, run_tests
    from .utils import has_coroutines
    from .utils import chained_future
    from .utils import sleep, async_sleep
    from .core import Future
    from .core import is_future

    from .queues import Queue

    async def async_f():
        # type: () -> None
        raise ValueError()

    def f():
        # type: () -> None
        raise ValueError()

    class TestQueueJoin(TestCase):
        def test_timeout(self):
            q = Queue()
            q.put(None)
            self.io_loop.call_later(0.1, q.task_done)
            self.assertRaises(gen.TimeoutError, q.join, timeout=0.01)


# Generated at 2022-06-24 09:14:48.309197
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        if not isinstance(e, QueueFull):
            raise ValueError('constructor of class QueueFull is broken')


# Generated at 2022-06-24 09:14:58.632260
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    loop = IOLoop.current()
    @gen.coroutine
    def get_first_item():
        yield q.put(1)
        yield q.get()
        assert 1 == q.qsize()
        #q.task_done()

    @gen.coroutine
    def put_new_item():
        yield q.put(2)
        assert 2 == q.qsize()
        #q.task_done()

    @gen.coroutine
    def main():
        # Get a first item from the queue
        IOLoop.current().spawn_callback(get_first_item)
        # Put new item into the queue
        IOLoop.current

# Generated at 2022-06-24 09:15:06.216583
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    import tornado.ioloop
    # Test with default args
    queue = Queue()
    # Test results
    assert isinstance(queue.__repr__(), str)
    # Test with explicit args
    queue = Queue(maxsize = 2)
    # Test results
    assert isinstance(queue.__repr__(), str)
    # Test with explicit args
    queue = Queue(3)
    # Test results
    assert isinstance(queue.__repr__(), str)

# Generated at 2022-06-24 09:15:10.454948
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    assert q._finished.is_set()
    assert q._unfinished_tasks == 0

    q._unfinished_tasks = 4
    q.task_done()
    assert not q._finished.is_set()
    assert q._unfinished_tasks == 3

    q.task_done()
    q.task_done()
    q.task_done()
    assert q._finished.is_set()
    assert q._unfinished_tasks == 0
    with pytest.raises(ValueError):
        q.task_done()



# Generated at 2022-06-24 09:15:12.897379
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    future = q.get(timeout=0)
    assert (future.result() is None) == True


# Generated at 2022-06-24 09:15:18.832674
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=3)
    q._queue = collections.deque([1, 2])
    q._getters = collections.deque([])
    q._putters = collections.deque([])
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    assert str(q) == "<Queue maxsize=3 queue=[1, 2]>"



# Generated at 2022-06-24 09:15:24.035206
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(1)
    it = q.__aiter__()
    assert 1 == it.__anext__().result()
    q.put_nowait(2)
    assert 2 == it.__anext__().result()
    print("Success: test_Queue___aiter__")



# Generated at 2022-06-24 09:15:26.303255
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        assert str(e) == ""



# Generated at 2022-06-24 09:15:27.804899
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    pq = PriorityQueue()
    assert pq.qsize() == 0

# Generated at 2022-06-24 09:15:35.696060
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import unittest2
    from tornado.queues import Queue
    class TestQueue(unittest2.TestCase):
        @unittest2.skip("Not implemented")
        def test_Queue___str__(self):
            # queue = Queue()
            # self.assertEqual(expected, queue.__str__())
            assert False  # TODO: implement your test here
    
    unittest2.main()


# Generated at 2022-06-24 09:15:41.567719
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(2)
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()

    try:
        q.put_nowait("a")
    except QueueFull:
        print("Queue is not empty")

    try:
        q.get_nowait()
    except QueueEmpty:
        print("Queue is not full")

test_Queue()



# Generated at 2022-06-24 09:15:50.668414
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert 'maxsize=0 queue=deque([])' == q._format()
    assert '<Queue maxsize=0 queue=deque([])>' == q.__str__()
    assert '<Queue at 0x7f6c0b989898 maxsize=0 queue=deque([])>' == q.__repr__()
    q = Queue(1)
    assert 'maxsize=1 queue=deque([])' == q._format()
    assert '<Queue maxsize=1 queue=deque([])>' == q.__str__()
    assert '<Queue at 0x7f6c0b989898 maxsize=1 queue=deque([])>' == q.__repr__()


# Generated at 2022-06-24 09:15:56.244231
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    q.task_done()
    assert q.get_nowait() == 2
    q.task_done()



# Generated at 2022-06-24 09:16:00.366512
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    print("Entering test_Queue___aiter__...")
    q = Queue()
    print(q)
    item = q.get()
    print(item)
    next(item)

# Generated at 2022-06-24 09:16:05.159413
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:16:07.482898
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try: 
        raise QueueEmpty("just for test") 
    except QueueEmpty as e: 
        print(e)


# Generated at 2022-06-24 09:16:13.738432
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        first = q.get_nowait()
    except QueueEmpty:
        # print('Queue empty')
        q.put_nowait(1)
        q.get_nowait()
    else:
        print("Queue initalized with something")
        print("First: ", first)
# Unit tests for Queue class

# Generated at 2022-06-24 09:16:16.878121
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=5)
    q.put_nowait(0)
    assert q.get_nowait() == 0


# Generated at 2022-06-24 09:16:19.710197
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    b = q.full()
    print('The result is: ',b)
    assert(b == False)




# Generated at 2022-06-24 09:16:20.321222
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    pass



# Generated at 2022-06-24 09:16:28.502918
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert q.__str__() == "<Queue maxsize=0>"
    q = Queue(3)
    assert q.__str__() == "<Queue maxsize=3>"
    q.__put_internal(1)
    assert q.__str__() == "<Queue maxsize=3 queue=[1]>"
    q.__put_internal(2)
    assert q.__str__() == "<Queue maxsize=3 queue=[1, 2]>"
    q.__put_internal(3)
    assert q.__str__() == "<Queue maxsize=3 queue=[1, 2, 3]>"
    q.get()
    assert q.__str__() == "<Queue maxsize=3 queue=[2, 3]>"
    q.task_done()

# Generated at 2022-06-24 09:16:29.905544
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue()
    print(queue)


# Generated at 2022-06-24 09:16:32.776059
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert str(q) == '<Queue maxsize=2>', 'actual: %r' % str(q)
test_Queue___str__()

# Generated at 2022-06-24 09:16:42.530626
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        print('consumer: task_done() too much')
        try:
            for item in q:
                print('consumer:', item)
                await gen.sleep(0.01)
                q.task_done()
        except ValueError as e:
            print(e)
        print('consumer: task_done() too much')
        try:
            q.task_done()
        except ValueError as e:
            print(e)

    async def producer():
        print('producer: put 1')
        await q.put(1)
        print('producer: put 2')
        await q.put(2)

# Generated at 2022-06-24 09:16:49.677811
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    import random

    item_list = list()

    # Create a queue object with a given maximum size
    q = Queue(3)

    getters = []

    def get(q):
        item = q.get()
        print("start get:", item)
        time.sleep(random.random() * 2)
        return item

    for i in range(10):
        future = gen.spawn(get, q)
        getters.append(future)

    # Put few items in the queue
    for i in range(10):
        t = i * random.random()
        time.sleep(t)
        item = q.put(i)
        print("put:", i, "after", t, "seconds")

    q.join()

    for future in getters:
        res = future.result()

# Generated at 2022-06-24 09:17:00.771675
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:01.784434
# Unit test for method join of class Queue
def test_Queue_join():raise NotImplementedError

# Generated at 2022-06-24 09:17:09.793584
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.full() == False
    q = Queue(maxsize=0)
    assert q.full() == False
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.full() == True
    q = Queue(maxsize=1)
    q.put(1, timeout=0.1)
    assert q.full() == True

# Generated at 2022-06-24 09:17:21.135440
# Unit test for method put of class Queue
def test_Queue_put():
    # try:
        myT_T = 1
        myT_T1 = 1
        myT_T2 = 1
        myT_T3 = 1
        myT_T4 = 1
        myT_T5 = 1
        myQueue = Queue()
        myQueue.put(1)
        myQueue.put(2)
        myQueue.put(3)
        myQueue.put(4)
        myQueue.put(5)
        myQueue.put(6)
        for myT_T in range(6):
            if myT_T == 0:
                myT_T1 = myQueue.get_nowait()
            elif myT_T == 1:
                myT_T2 = myQueue.get_nowait()
            elif myT_T == 2:
                myT

# Generated at 2022-06-24 09:17:26.505823
# Unit test for method join of class Queue
def test_Queue_join():
    f = future()
    f.done()
    t = time.time()
    # print(t)
    timeout = 0.2
    if not f.done():
        time.sleep(timeout)
    # print(time.time())
    if not f.done():
        raise tornado.util.TimeoutError()



# Generated at 2022-06-24 09:17:34.594234
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    @gen.coroutine
    def coroutine():
        q = Queue()
        IOLoop.current().spawn_callback(q.put, 1)
        IOLoop.current().spawn_callback(q.put, 2)
        IOLoop.current().spawn_callback(q.put, 3)
        result_list = []
        async for item in q:
            result_list.append(item)
        assert result_list == [1,2,3]
        print("test_Queue___aiter__ coroutine() finished")
    IOLoop.current().run_sync(coroutine)
    print("test_Queue___aiter__ finished")
    return
if __name__ == "__main__":
    test

# Generated at 2022-06-24 09:17:40.216566
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(object())
    assert not q.full()
    q.put_nowait(object())
    assert q.full()
    q.get_nowait()
    assert not q.full()


# Generated at 2022-06-24 09:17:48.395582
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.queues import Queue

    def test():
        async def func():
            async for item in q:
                print(item)
                if item==4:
                    break
        q=Queue(5)
        for i in range(5):
            q.put(i)
        IOLoop.current().spawn_callback(func)
        return gen.sleep(0.1)
    IOLoop.current().run_sync(test)

# Generated at 2022-06-24 09:18:00.953013
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("开始测试Queue类")
    #类方法测试
    class cla:
        p=int
        q=str
    un1=cla()
    un2=cla()
    un1.p=1
    un2.p=2
    un1.q="a"
    un2.q="b"
    q=Queue()
    #测试特殊情况：1.队列为空；2.队列满 应为可能报错

# Generated at 2022-06-24 09:18:05.925930
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.full() == False
    q.put(i)
    q.put(i)
    assert q.full() == True
    q.task_done()
    q.task_done()
    assert q.full() == False


# Generated at 2022-06-24 09:18:10.337508
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Main function to test LifoQueue

# Generated at 2022-06-24 09:18:15.072347
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(1, timeout=None)
    future = q.put_nowait(2)
    future = q.put(3, timeout=None)
    return future


# Generated at 2022-06-24 09:18:20.293232
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(2)
    q.put(1)
    f = q.get()
    #Return an awaitable which resolves once an item is available, or raises
    # `tornado.util.TimeoutError` after a timeout.
    assert f.result() == 2



# Generated at 2022-06-24 09:18:29.535312
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:31.197691
# Unit test for method __str__ of class Queue
def test_Queue___str__():
  q = Queue()
  print(q.__str__())
test_Queue___str__()



# Generated at 2022-06-24 09:18:34.118926
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Initialize a Queue object named q with maxsize = 3
    q = Queue(maxsize = 3)
    # Add some elements to the queue
    q.put(1)
    # Indicate that the processing on the first element is complete
    q.task_done()
    # Check whether the queue is empty or not
    assert not q.empty()



# Generated at 2022-06-24 09:18:43.652294
# Unit test for method get of class Queue
def test_Queue_get():
    for i in range(10):
        q = Queue(maxsize=2)
        print(q.empty())
        print(q.full())
        print(q)
        print(q.qsize())
        print(q.put(1))
        print(q.put_nowait(2))
        print(q)
        print(q.get())
        print(q)
        print(q.task_done())
        print(q.join())
        print(q.get_nowait())
        print(q)
        print(q.task_done())
        print(q.join())

# Generated at 2022-06-24 09:18:48.063283
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    res = q.get()
    
    assert res == 1
    res = q.get()
    assert res == 2
    

# Generated at 2022-06-24 09:18:59.699625
# Unit test for method full of class Queue
def test_Queue_full():

    # Test internal methods.
    q = Queue()
    q._init()  # type: ignore
    q._put(1)
    assert q._get() == 1

    q = Queue()

    async def consumer():
        print('Consumer waiting')
        item = await q.get()
        print('Consumer done')
        return item

    async def producer():
        q.put_nowait(object())
        q.put_nowait(object())
        print('Producer done')

    ioloop.IOLoop.current().run_sync(lambda: producer())  # type: ignore
    ioloop.IOLoop.current().run_sync(lambda: consumer())  # type: ignore
    assert q.empty()

    assert not q.full()
    q._put(object())
    assert q.full()




# Generated at 2022-06-24 09:19:04.090672
# Unit test for method put of class Queue
def test_Queue_put():
    try:
        Q = Queue()
        assert Q.qsize() == 0
        Q.put_nowait(1)
        assert Q.qsize() == 1
        assert Q.get_nowait() == 1
    except:
        print("TEST ERROR: Please input the correct type of arguments.")


# Generated at 2022-06-24 09:19:09.280170
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    class ExampleQueue(Queue):
        def __init__(self):
            super(ExampleQueue, self).__init__()
    q = ExampleQueue()
    assert repr(q) == "<ExampleQueue at %s maxsize=0>" % hex(id(q))



# Generated at 2022-06-24 09:19:12.404654
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    question = Queue(maxsize=1)
    print(question)
    return



# Generated at 2022-06-24 09:19:15.832559
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    assert isinstance(q.__aiter__(), _QueueIterator)
    assert isinstance(q.__aiter__(), _QueueIterator)


# Generated at 2022-06-24 09:19:24.348085
# Unit test for method get of class Queue
def test_Queue_get():
    import uuid
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.gen import coroutine

    q = Queue(maxsize=10)

    @coroutine
    def consumer():
        async for i in q:
            print(i)

    def producer():
        for i in range(10):
            q.put(i)

    producer()
    IOLoop.current().spawn_callback(consumer)
    IOLoop.current().start()

# Generated at 2022-06-24 09:19:32.313184
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
    assert (next(iter(q))) == (1)
    assert (next(iter(q))) == (2)
    assert (next(iter(q))) == (3)
    assert (next(iter(q))) == (4)
    assert (next(iter(q))) == (5)

# Class for using check in test_queue_iterator