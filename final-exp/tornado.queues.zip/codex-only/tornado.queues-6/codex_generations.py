

# Generated at 2022-06-24 09:09:29.914349
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    p = Queue()
    assert repr(p) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(p)



# Generated at 2022-06-24 09:09:31.414237
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(1)
    for i in range(1,4):
        q.put(i)
    assert q.task_done() == None

# Generated at 2022-06-24 09:09:37.712181
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:09:49.005199
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:09:52.261018
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except:
        print('catched exception')

# Generated at 2022-06-24 09:09:54.652932
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(q)
    q.put_nowait(1)
    print(q)
# test_Queue___repr__()



# Generated at 2022-06-24 09:09:59.889154
# Unit test for method put of class Queue
def test_Queue_put():

    future = Future()  # type: Future[None]
    try:
        future.set_result(self.get_nowait())
    except QueueEmpty:
        self._getters.append(future)
        _set_timeout(future, timeout)
    return future


# Generated at 2022-06-24 09:10:01.539289
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:10:09.318889
# Unit test for method full of class Queue
def test_Queue_full():
    print('test_Queue_full')
    try:
        maxsize = int(sys.argv[1])
    except:
        print('please input a integer as maxsize for this test')
    q = Queue(maxsize=maxsize)
    count = 0
    for i in range(maxsize):
        q.put_nowait(i)
        count += 1
    assert count == q.qsize()
    assert not q.empty()
    assert q.full()
    print('test_Queue_full pass')
test_Queue_full()


# Generated at 2022-06-24 09:10:16.590048
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    def get_nowait_test():
        from tornado.httpclient import HTTPRequest
        from tornado.testing import AsyncHTTPTestCase, gen_test
        import tornado
        import random
        import time
        import threading

        # Code taken from github.com/tornadoweb/tornado/blob/master/tornado/test/httpclient_test.py
        class SleepHandler(tornado.web.RequestHandler):
            def get(self):
                time.sleep(random.uniform(0, 1))
                self.write(b"async")

        class AsyncHTTPTest(AsyncHTTPTestCase):
            def get_app(self):
                return tornado.web.Application([("/", SleepHandler)])

            @gen_test(timeout=1000)
            def test_async_sleep(self):
                res = yield self

# Generated at 2022-06-24 09:10:18.726041
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    assert i


# Generated at 2022-06-24 09:10:20.082773
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    queue = Queue(maxsize = 0)
    assert repr(queue) == "<Queue at 0x7fef768c9b38 maxsize=0>"

# Generated at 2022-06-24 09:10:27.055894
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

    #1
    #2
    #3



# Generated at 2022-06-24 09:10:29.775749
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    if q.full():
        print("Queue is full")


# Generated at 2022-06-24 09:10:35.261150
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    ioloop = ioloop.IOLoop.current()
    # Start consumer without waiting (since it never finishes).
    ioloop.spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

    ioloop.run_sync(main)


# Generated at 2022-06-24 09:10:36.923267
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0



# Generated at 2022-06-24 09:10:39.498703
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    try:
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        q.put(5)
    except:
        pass



# Generated at 2022-06-24 09:10:42.880302
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True 
    q.put(1)
    assert q.empty() == False



# Generated at 2022-06-24 09:10:44.747353
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    q.empty()
    q.full()


# Generated at 2022-06-24 09:10:54.365602
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    result = [0]
    def consumer() -> None:
        try:
            for i in range(10):
                item = yield q.get()
                result[0] = result[0] + item
                yield gen.sleep(0.01)
        finally:
            q.task_done()
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    yield q.put(1)
    yield q.put(2)
    assert q.qsize() == 2
    yield q.put(3)
    assert q.qsize() == 3
    IOLoop.current().spawn_callback(consumer)
    yield q.join()
    assert q.qsize() == 0
    assert result[0] == 1 + 2 + 3



# Generated at 2022-06-24 09:11:00.499884
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:11:11.522234
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert str(q) == "<Queue tasks=0>"
    q.put_nowait(1)
    assert str(q) == "<Queue tasks=1>"
    q.put_nowait(2)
    assert str(q) == "<Queue tasks=2>"
    assert q.get_nowait() == 1
    assert str(q) == "<Queue tasks=1>"
    q.task_done()
    assert str(q) == "<Queue tasks=0>"
    assert q.get_nowait() == 2
    assert str(q) == "<Queue tasks=0>"
    q.task_done()
    assert str(q) == "<Queue tasks=0>"
    q.put_nowait(1)
    assert str(q) == "<Queue tasks=1>"
    assert q.get_now

# Generated at 2022-06-24 09:11:14.108818
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        assert e.args[0] == "queue full"


# Generated at 2022-06-24 09:11:16.517106
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    a = Queue[int](4)
    assert a.qsize() == 0, 'queue is not empty!'


# Generated at 2022-06-24 09:11:18.265562
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
	q = LifoQueue()
	q.put(3)
	q.put(2)
	q.put(1)
	print(q.get_nowait())
	print(q.get_nowait())
	print(q.get_nowait())
	print("Success")


# Generated at 2022-06-24 09:11:20.018473
# Unit test for method empty of class Queue
def test_Queue_empty():
   q = Queue() # type: Queue[int]
   assert not q.empty()


# Generated at 2022-06-24 09:11:31.021161
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    print(q.empty())

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync

# Generated at 2022-06-24 09:11:35.761524
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert not q.full()
    assert q.empty()
    q.put_nowait(1)
    assert q.qsize() == 1
    assert not q.empty()
    assert not q.full()
    q.put_nowait(2)
    assert q.qsize() == 2
    assert not q.empty()
    assert q.full()
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass


# Generated at 2022-06-24 09:11:39.113068
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado
    q = tornado.queues.Queue()
    q.put(1)

    @gen.coroutine
    def f():
        assert(q.maxsize == 0)
        for i in q:
            assert i == 1
            break
    f()



# Generated at 2022-06-24 09:11:50.999261
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import AsyncTestCase
    from tornado.gen import coroutine
    import unittest
    import typing
    if typing.TYPE_CHECKING:
        from typing import Any
    class _QueueIteratorTestCase(AsyncTestCase):
        @gen.coroutine
        def test__QueueIterator___anext__(self):

            def _future_callback(future):
                future.set_result(True)
            q = Queue()
            q_iterator = _QueueIterator(q)
            future = Future()
            with self.assertRaises(QueueEmpty):
                yield q_iterator.__anext__()

            q.put_nowait(True)
            future = q.get_nowait()
            self.assertTrue((yield future), "Expected: True")
            q_iterator = _QueueIterator(q)

# Generated at 2022-06-24 09:11:54.431505
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    res = q.empty()
    #assert res == True
    assert res == True


# Generated at 2022-06-24 09:11:59.762778
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q1 = Queue()
    q1.put(3)
    q1.put(4)
    q1.put(5)
    it = _QueueIterator(q1)
    assert isinstance(it, _QueueIterator)
    assert isinstance(it.q, Queue)



# Generated at 2022-06-24 09:12:03.345223
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(2)
    assert not q.full()
    q.put_nowait(3)
    assert q.full()



# Generated at 2022-06-24 09:12:11.540085
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import sys
    import types
    import random
    import time
    import multiprocessing
    import threading
    import io


    class QueueTestCase(unittest.TestCase):
        def test_put_nowait(self):
            import warnings
            q = Queue()
            self.assertRaises(TypeError, q.put_nowait)
            q.get()
            q.put_nowait(10)
            q.task_done()
            q.put(10)
            q.join()
            q.get()
            self.assertRaises(QueueFull, q.put_nowait, 10)
            q.task_done()
            q.join()
            q.put_nowait(10)
            q.put(10)
            # In the original test

# Generated at 2022-06-24 09:12:16.487891
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at %x maxsize=2 queue=deque([])>" % id(q)
    with pytest.raises(TypeError):
        Queue(maxsize=None)
    with pytest.raises(ValueError):
        Queue(maxsize=-1)



# Generated at 2022-06-24 09:12:20.999758
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    class T(object):
        value = None

    t = T()
    t.value = 1

    q = Queue[int]()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)

    it = _QueueIterator(q)
    assert it.q is q

    assert 1 == (await it.__anext__())
    assert 2 == (await it.__anext__())
    assert 3 == (await it.__anext__())
    try:
        await it.__anext__()
    except gen.TimeoutError:
        pass
    else:
        assert False



# Generated at 2022-06-24 09:12:31.572712
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    print(q)
    assert q.qsize() == 0
    assert q.unfinished_tasks == 0
    q.put_nowait(1)
    q.put_nowait(2)
    print(q)
    assert q.qsize() == 2
    assert q.unfinished_tasks == 2
    q.put_nowait(3)
    print(q)
    assert q.qsize() == 3
    assert q.unfinished_tasks == 3
    q.task_done()
    print(q)
    assert q.qsize() == 2
    assert q.unfinished_tasks == 2
    q.get_nowait()
    assert q.qsize() == 1
    assert q.unfinished_tasks == 1

# Generated at 2022-06-24 09:12:36.255972
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	q = Queue()
	try:
		q.get_nowait()
	except QueueEmpty:
		print('Queue is empty!')
		
	q.put(1)
	assert(q.get_nowait()==1)
	q.put(2)
	assert(q.get_nowait()==2)
	q.put(3)
	assert(q.get_nowait()==3)

# Generated at 2022-06-24 09:12:38.103432
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    exception = QueueEmpty()
    assert isinstance(exception, Exception)



# Generated at 2022-06-24 09:12:39.851440
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    assert isinstance(q.__aiter__(), _QueueIterator)
    q = Queue()
    q._queue = [1]
    assert isinstance(q.__aiter__(), _QueueIterator)

# Generated at 2022-06-24 09:12:48.409701
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def producer():
        print('producing')
        await q.put(1)
        await q.put(2)
        await q.put(3)
        await q.put(None)
        print('producer done')

    async def consumer():
        print('consuming')
        async for i in q:
            print('consumed', i)
        print('consumer done')

    async def main():
        IOLoop.current().spawn_callback(producer)
        await consumer()
        print('done')

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:12:50.027947
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass


# Generated at 2022-06-24 09:12:53.387629
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    q.__put_internal(1)
    q.__put_internal(2)
    assert q._queue == collections.deque([1, 2])
    assert q._unfinished_tasks == 2
    assert not q._finished.is_set()


# Generated at 2022-06-24 09:13:00.930916
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest
    import random
    import time
    import sys
    def test_full():
        q = Queue(maxsize=2)
        print(q.full())
        q.put_nowait(1)
        print(q.full())
        q.put_nowait(2)
        print(q.full())
    test_full()
    # Result
    '''
    False
    False
    True
    '''


# Generated at 2022-06-24 09:13:10.310442
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    io_loop = ioloop.IOLoop.current()
    io_loop.spawn_callback(consumer)
    io_loop.run_sync(producer)
    q.get_nowait()

if __name__ == "__main__":
    test_Queue_get_nowait()



# Generated at 2022-06-24 09:13:12.410457
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Just print a queue instance and make sure it doesn't rase any exception
    q = Queue()
    print (q.__repr__())


# Generated at 2022-06-24 09:13:16.135711
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    result = q.get()
    print(result)
# In the loop, it will keep waiting for item from the queue.
async def consumer(q):
    while True:
        item = await q.get()
        try:
            print(item)
        finally:
            q.task_done()


# Generated at 2022-06-24 09:13:23.954889
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    x = Queue(maxsize=2)
    # x = Queue(maxsize=None)
    x.put_nowait(1)
    x.put_nowait(2)
    x.put_nowait(3)
    x.get_nowait()
    x.get_nowait()
    x.get_nowait()



# Generated at 2022-06-24 09:13:27.335817
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:13:38.708655
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    n = 0
    q = Queue(maxsize=0)
    assert repr(q) == "<Queue at " + hex(id(q)) + " maxsize=0>"
    n += 1
    q.put_nowait(1)
    assert repr(q) == r"<Queue at " + hex(id(q)) + " maxsize=0 queue=deque([1])>"
    n += 1
    q = Queue(maxsize=1)
    q.put_nowait(1)
    q.put_nowait("s")
    assert repr(q) == (
        r"<Queue at " + hex(id(q)) + " maxsize=1 queue=deque(['s']) putters[1]>"
    )
    n += 1
    q = Queue(maxsize=3)
   

# Generated at 2022-06-24 09:13:47.304851
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        try:
            while True:
                item = yield q.get()
                try:
                    print('Doing work on %s' % item)
                    yield gen.sleep(0.01)
                finally:
                    q.task_done()
        except:
            q.task_done()

    async def main():
        IOLoop.current().spawn_callback(consumer)
        await q.join()
        print("Done")

    IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:13:57.658021
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:13:59.595457
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print(q.__str__())

# Generated at 2022-06-24 09:14:03.578612
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    if typing.TYPE_CHECKING:
        # @todo Add tests
        e = _QueueIterator
        assert False, 'Unimplemented[{}]'.format(e)


# Generated at 2022-06-24 09:14:09.570954
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q: typing.Deque[typing.Any] = collections.deque()
    q.append(1)
    queue = Queue()
    queue._queue = q
    queue_iterator = _QueueIterator(queue)
    assert 1 == ioloop.IOLoop.current().run_sync(lambda: queue_iterator.__anext__(), timeout=0.1)


# Generated at 2022-06-24 09:14:10.711173
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0

# Generated at 2022-06-24 09:14:15.018366
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=6)
    q._unfinished_tasks = 1
    q._finished.clear()

    q.task_done()
    assert 1 == q._unfinished_tasks
    assert q._finished.is_set()



# Generated at 2022-06-24 09:14:16.143468
# Unit test for constructor of class Queue
def test_Queue():
    queue = Queue()



# Generated at 2022-06-24 09:14:17.585636
# Unit test for constructor of class Queue
def test_Queue():
    a = Queue(10)
    return a



# Generated at 2022-06-24 09:14:20.397619
# Unit test for constructor of class QueueFull
def test_QueueFull():
    new_QueueFull1 = QueueFull()


# Generated at 2022-06-24 09:14:23.273457
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:14:24.534030
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:14:33.646807
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(3):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:14:35.635307
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__(): assert isinstance(
    _QueueIterator(None).__anext__(),
    Awaitable[Any]
)

# Generated at 2022-06-24 09:14:39.334849
# Unit test for method qsize of class Queue
def test_Queue_qsize(): 
    q = Queue()
    # The size of the queue should be 0
    assert q.qsize() == 0
    q.put(1.0)
    q.put(1.0)
    # The size of the queue should be 2
    assert q.qsize() == 2
    q.get()
    # The size of the queue should be 1
    assert q.qsize() == 1
    q.get()
    # The size of the queue should be 0
    assert q.qsize() == 0
test_Queue_qsize()


# Generated at 2022-06-24 09:14:46.055075
# Unit test for constructor of class Queue
def test_Queue():
    q0 = Queue(maxsize=2)
    assert isinstance(q0, Queue)
    q1 = Queue()
    assert isinstance(q1, Queue)
    try:
        q2 = Queue(maxsize=None)
        assert False, "should not reach here"
    except TypeError:
        pass
    try:
        q3 = Queue(maxsize=-1)
        assert False, "should not reach here"
    except ValueError:
        pass



# Generated at 2022-06-24 09:14:49.134625
# Unit test for constructor of class Queue
def test_Queue():
    # Instantiation test
    q = Queue(maxsize=1)
    assert q.maxsize == 1
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False



# Generated at 2022-06-24 09:14:54.452157
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
	queue = Queue(maxsize=2)
	try:
		queue.put_nowait(1)
		queue.put_nowait(2)
	except QueueFull:
		raise AssertionError("QueueFull Exception raised")
	try:
		queue.put_nowait(3)
	except QueueFull:
		pass
	else:
		raise AssertionError("QueueFull Exception not raised")

# Generated at 2022-06-24 09:15:04.814326
# Unit test for method get of class Queue
def test_Queue_get():
    from typing import Dict
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    result = dict()  # type: Dict[str, str]

    async def consumer():
        async for item in q:
            try:
                 result["Doing work on "] = str(item)
            finally:
                 q.task_done()
    IOLoop.current().spawn_callback(consumer)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    assert result['Doing work on '] == "5"



# Generated at 2022-06-24 09:15:11.246841
# Unit test for method full of class Queue
def test_Queue_full():
    import unittest

    class test_Queue_full(unittest.TestCase):

        def test_Queue(self):
            import tornado.queues
            q = tornado.queues.Queue(maxsize=1)
            self.assertFalse(q.full())
            q.put_nowait(1)
            self.assertTrue(q.full())
            q.get_nowait()
            self.assertFalse(q.full())
        if __name__ == '__main__':
            unittest.main()

# Generated at 2022-06-24 09:15:15.991864
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()

# Generated at 2022-06-24 09:15:26.954612
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    assert repr(Queue(0)) == "<Queue at 0x%x maxsize=0>" % id(Queue(0))
    assert repr(Queue(10)) == "<Queue at 0x%x maxsize=10>" % id(Queue(10))
    q = Queue(0)
    assert repr(q) == "<Queue at 0x%x maxsize=0>" % id(q)
    q._queue = [1, 2, 3]
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[1, 2, 3]>" % id(q)
    q._getters.append(0)
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=[1, 2, 3] getters[1]>" % id(q)
    q._putters.append(0)
   

# Generated at 2022-06-24 09:15:29.928428
# Unit test for constructor of class QueueFull
def test_QueueFull():
    with pytest.raises(QueueFull) as excinfo:
        raise QueueFull("not enough")
    assert "not enough" in excinfo.value.args[0]

# Generated at 2022-06-24 09:15:32.788084
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    queue = Queue(1)
    queue.task_done()
    queue.task_done()



# Generated at 2022-06-24 09:15:36.428384
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2


# Generated at 2022-06-24 09:15:40.970415
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = Queue()    
    try:
        q.put_nowait(1)
    except:
        q.get_nowait()
        try:
            q.put_nowait(1)
            assert False, "Can't throw exception QueueFull"
        except QueueFull:
            assert True


# Generated at 2022-06-24 09:15:43.864119
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:15:49.413128
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=0)
    assert q.full() == False
    data = Queue()
    assert data.full() == False
    q = Queue(maxsize=2000000)
    assert q.full() == False
    data = Queue()
    assert data.full() == False
    q = Queue(maxsize=500)
    assert q.full() == False
    data = Queue()
    assert data.full() == False


# Generated at 2022-06-24 09:15:54.000566
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Unit tests for method __repr__ of class Queue
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)
    # Unit tests for method __str__ of class Queue
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"


# Generated at 2022-06-24 09:15:54.852313
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        assert False
    except:
        QueueEmpty()



# Generated at 2022-06-24 09:15:59.952290
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)

    q.put(1)
    q.put(2)
    assert q.full()
    q.get_nowait()
    assert not q.full()
    q.put(3)
    assert q.full()

# Generated at 2022-06-24 09:16:10.052305
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado import testing
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import requests
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            try:
                response = requests.get(request.url)
            except Exception as e:
                response = requests.Response()
                response.request = request
                response.error = e
            callback(response)

    class TestQueueIterator(AsyncHTTPTestCase):
        def get_app(self):
            return None

        @gen_test
        def test__QueueIterator___anext__(self):
            q = Queue()
            q.put((lambda: 42)())

# Generated at 2022-06-24 09:16:11.992518
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    ioloop.IOLoop().run_sync(lambda : None)


# Generated at 2022-06-24 09:16:16.990689
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=5)
    q.put_nowait(1)

    assert q.qsize() == 1


# Test for method get_nowait of class Queue

# Generated at 2022-06-24 09:16:21.828768
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    """A test class for Queue"""
    q = Queue(maxsize=2)
    q._queue = [1,2]
    actual = q._format()
    expected = "maxsize=2 queue=[1, 2] tasks=0"
    assert actual == expected, actual
test_Queue___str__()


# Generated at 2022-06-24 09:16:27.050618
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1

# Generated at 2022-06-24 09:16:30.749916
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:16:31.800254
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait()
    q.get_nowait()


# Generated at 2022-06-24 09:16:36.139428
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado.queues import Queue
    q = Queue(maxsize=10)
    assert q.full() is False
    
    for i in range(10):
        q.put_nowait(i)
        
    assert q.full() is True 
test_Queue_full()

# Generated at 2022-06-24 09:16:45.866914
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:51.647658
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    import types
    with gen.IOLoop() as loop:
        q = Queue()
        it = _QueueIterator(q)
        assert isinstance(it, types.GeneratorType)
        assert isinstance(it, collections.abc.AsyncIterator)
        assert it.__anext__.__qualname__ == "Queue._QueueIterator.__anext__"



# Generated at 2022-06-24 09:16:54.736579
# Unit test for method empty of class Queue
def test_Queue_empty():
    print(Queue.empty(Queue()))
    print(Queue.empty(Queue(maxsize=0)))
    print(Queue.empty(Queue(maxsize=10)))


# Generated at 2022-06-24 09:16:57.398403
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.get() == None, "get not yet implemented"


# Generated at 2022-06-24 09:17:05.339364
# Unit test for method get of class Queue
def test_Queue_get():
    def test_Queue_get_0(self):
        # Test for empty queue
        if self.qsize() == 0:
            return QueueEmpty
        
        # Test for queue is not empty
        def test_Queue_get_1(self):
            self._consume_expired()
            if self._putters:
                assert self.full(), "queue not full, why are putters waiting?"
                item, putter = self._putters.popleft()
                self.__put_internal(item)
                future_set_result_unless_cancelled(putter, None)
                return self._get()
            elif self.qsize():
                return self._get()
            else:
                return QueueEmpty


# Generated at 2022-06-24 09:17:06.175458
# Unit test for method put of class Queue
def test_Queue_put():
    assert put([1,2,3]) == None

# Generated at 2022-06-24 09:17:12.045003
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    i = _QueueIterator(q)
    assert i.q.get_nowait() == 1
    assert i.q.get_nowait() == 2
    assert i.q.get_nowait() == 3
    assert i.q.qsize() == 0



# Generated at 2022-06-24 09:17:12.828609
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty().__class__


# Generated at 2022-06-24 09:17:13.887806
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # __repr__ is tested in test_Queue_str
    pass

# Generated at 2022-06-24 09:17:14.589078
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass


# Generated at 2022-06-24 09:17:15.730070
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()


# Generated at 2022-06-24 09:17:17.845773
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # arrange
    q = LifoQueue()

    # act
    for i in range(4):
        q.put(i)
        print(q.get_nowait())

    # assert
    return 0


if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:17:21.456970
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)



# Generated at 2022-06-24 09:17:26.480521
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    q = Queue()

    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:17:29.951068
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:17:34.602246
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    n = 0
    q.task_done()
    if q._unfinished_tasks != n:
        return False
    return True


if __name__ == "__main__":
    print(test_Queue_task_done())

# Generated at 2022-06-24 09:17:36.916297
# Unit test for constructor of class QueueFull
def test_QueueFull():
    cf = QueueFull()
    assert cf.args is None or len(cf.args) == 0



# Generated at 2022-06-24 09:17:39.678215
# Unit test for constructor of class QueueFull
def test_QueueFull():
    # type: () -> None
    with pytest.raises(QueueFull):
        raise QueueFull()


# Generated at 2022-06-24 09:17:46.446884
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """When maxsize is non-zero, a Queue put_nowait should raise exception
    if queue is full.
    """
    q = Queue(maxsize=1)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except:
        print("QueueFull Exception thrown")
    else:
        raise Exception("QueueFull Exception not thrown")

test_Queue_put_nowait()


# Generated at 2022-06-24 09:17:49.815041
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    iterator = _QueueIterator(q)
    assert isinstance(iterator, _QueueIterator)



# Generated at 2022-06-24 09:18:01.269831
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    class DummyQueue(Queue[_T]):
        def _init(self) -> None:
            pass

        def _get(self) -> _T:
            pass

        def _put(self, item: _T) -> None:
            pass
    maxsize = 0
    regular_queue = DummyQueue(maxsize)
    print(regular_queue)
    maxsize_negative = -1
    wrong_maxsize_queue = DummyQueue(maxsize_negative)
    print(wrong_maxsize_queue)
    maxsize_positive = 5
    regular_queue = DummyQueue(maxsize_positive)
    print(regular_queue)

if __name__ == "__main__":
    test_Queue___str__()


# Generated at 2022-06-24 09:18:07.813749
# Unit test for method get of class Queue
def test_Queue_get():
    # Since the contract of get() and put() is that they block, this test
    # needs to run in a separate thread so it doesn't block the whole test
    # runner.
    import threading

    q = Queue()

    def putter():
        for x in range(1000):
            q.put(x)

    threading.Thread(target=putter).start()

    for x in range(1000):
        assert q.get() == x



# Generated at 2022-06-24 09:18:16.130353
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.maxsize ==2
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        testError = False
    except QueueFull:
        testError = True
    assert testError is False
    # full
    try:
        q.put_nowait(3)
        testError = False
    except QueueFull:
        testError = True
    assert testError is True


# Generated at 2022-06-24 09:18:19.206116
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    assert q.empty() == False
    
if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:18:28.600983
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import random
    import time

    async def producer(q, n):
        for _ in range(n):
            await q.put(random.random())
        await q.join()
        await q.put(None)

    async def consumer(q):
        while True:
            item = await q.get()
            if item is None:
                break
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def main():
        q = Queue()
        await gen.multi([consumer(q), producer(q, 10)])
        print('Done')

    import tornado
    tornado.ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:18:30.503692
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    t = QueueEmpty()
    t = QueueEmpty("abc")
    t = QueueEmpty(["a","b","c"])



# Generated at 2022-06-24 09:18:39.330662
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import concurrent.futures
    import typing
    q = tornado.queues.Queue[str](maxsize=1)
    @tornado.gen.coroutine
    def consumer():
        nonlocal q
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    @tornado.gen.coroutine
    def producer():
        nonlocal q
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @tornado.gen.coroutine
    def main():
        nonlocal q
        # Start consumer without

# Generated at 2022-06-24 09:18:51.194594
# Unit test for method join of class Queue
def test_Queue_join():
    import pytest
    from tornado.testing import gen_test
    from tornado.web import RequestHandler, Application, url
    from tornado.queues import Queue
    from typing import Dict
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop,PeriodicCallback
    import logging
    import threading
    
    
    
    
    class Handler(RequestHandler):
        def initialize(self,q: Queue) -> None:
            self.q = q
        
        @gen.coroutine
        def get(self):
            self.q.put_nowait("")
            try:
                yield self.q.join()
            except gen.TimeoutError:
                logging.info("join timeout...")
            else:
                logging.info("join stop...")
            self.write("ok")


# Generated at 2022-06-24 09:19:03.299212
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    # Determine if __init__ initializes the object
    q = LifoQueue()
    assert q._queue == [], '__init__ method must initialize _queue'
    assert q._maxsize == 0, '__init__ method must initialize _maxsize'
    assert q._putters == [], '__init__ method must initialize _putters'
    assert q._getters == [], '__init__ method must initialize _getters'
    assert q._unfinished_tasks == 0, '__init__ method must initialize _unfinished_tasks'
    # Determine if the constructor with maxsize argument initializes the object
    q = LifoQueue(5)
    assert q._queue == [], '__init__ method must initialize _queue when initialized with a nonzero maxsize'

# Generated at 2022-06-24 09:19:03.962936
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    pass

# Generated at 2022-06-24 09:19:13.762830
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import time
    import unittest
    import asyncpg
    from asyncpg.pool import Pool
    from tornado.testing import gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    class _QueueIteratorTest(unittest.TestCase):
        def setUp(self):
            self.pool = None
            AsyncIOMainLoop().install()
            asyncio.set_event_loop(asyncio.new_event_loop())
            self.loop = asyncio.get_event_loop()

        def tearDown(self):
            self.loop.close()
            AsyncIOMainLoop().uninstall()

        @gen_test(timeout=30)
        async def test___anext__(self):
            async with self.pool.acquire() as conn:
                pass
# Unit test

# Generated at 2022-06-24 09:19:25.595119
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    q._consume_expired()
    q._init()
    q.put_nowait(2)
    assert q.qsize() == 2
    q._consume_expired()
    q._queue = []
    assert q.qsize() == 0
    q._consume_expired()
    q.get_nowait()
    assert q.qsize() == 0
    q._consume_expired()
    q.get()
    assert q.qsize() == 0
    q._consume_expired()
    q.put(3)
    assert q.qsize() == 1
    q._consume_expired()
    q.get()
   

# Generated at 2022-06-24 09:19:28.707885
# Unit test for constructor of class QueueFull
def test_QueueFull():
    """Unit test for constructor of class QueueFull"""
    q = QueueFull(1)
    assert q.args == (1,)
    if q.args is None:
        raise AssertionError

