

# Generated at 2022-06-24 09:09:41.032428
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    import ipdb
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue()
    async def run():
        await q.put(10)
        await q.put(20)
        await q.put(30)
        
        print(await q.get())
        print(await q.get())
        print(await q.get())
        
        await q.put(random.randint(0,5))
        print(await q.get())

    io_loop = IOLoop.current()
    io_loop.run_sync(run)


# Generated at 2022-06-24 09:09:45.092747
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q._init()
    q._queue.append(1)
    assert(q.get_nowait() == 1)
    

# Generated at 2022-06-24 09:09:51.095794
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    print(q.qsize())
    print(q.maxsize)
    print()


# Generated at 2022-06-24 09:09:53.944302
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Case 1 of 1:
    q = Queue(maxsize=2)
    assert q.__repr__() == "<Queue at 0x" in q.__repr__()



# Generated at 2022-06-24 09:09:55.328161
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=10)
    assert q.empty()



# Generated at 2022-06-24 09:10:07.927274
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # Call method (with appropriate args)
    # We do this in a separate function so we can easily catch
    # exceptions.
    result1 = Queue.__aiter__(Queue(), )
    # We have just one return type.
    assert isinstance(result1, _QueueIterator)
    # And one argument type.
    assert isinstance(Queue(), Queue)


try:
    import queue
except ImportError:
    # In Python <3.7 the Queue is not a subclass of the queue.Queue
    pass

# Generated at 2022-06-24 09:10:16.162517
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from random import randint
    from tornado.ioloop import IOLoop
    import time
    import logging
    logging.basicConfig(filename="test.log", level=logging.INFO)
    class Test_Queue_task_done(Queue):
        #task_num = 1
        def __init__(self, maxsize=0):
            Queue.__init__(self, maxsize)  # Call constructor of Queue
            #self.task_num = task_num
        async def On_item_put(self, item):
            await gen.sleep(0.001)
            self.task_done()
        async def put_and_task_done(self, item):
            await self.put(item)
            await self.On_item_put(item)
            return True
    test = Test_Queue_task_done

# Generated at 2022-06-24 09:10:20.818201
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    try:
        q.task_done()
    except ValueError:
        # print("Queue_task_done is working properly")
        q._unfinished_tasks = 1
        q.task_done()
    else:
        assert False

# Generated at 2022-06-24 09:10:27.229682
# Unit test for method get of class Queue
def test_Queue_get():
    timeout = 1
    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()
    try:
        q = Queue(maxsize=2)
        consumer()
    except:
        pass


# Generated at 2022-06-24 09:10:34.799563
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:10:39.117706
# Unit test for constructor of class QueueFull
def test_QueueFull():
    from tornado.testing import AsyncTestCase, main, bind_unused_port, gen_test
    import asyncio

    class TestQueue(AsyncTestCase):
        @gen_test
        async def test_QueueFull(self):
            try:
                raise QueueFull(666)
            except Exception as e:
                print(e)

    if __name__ == "__main__":
        main()


# Generated at 2022-06-24 09:10:44.422224
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    assert(q.get_nowait() == 1)
    assert(q.get_nowait() == 2)

# Generated at 2022-06-24 09:10:51.294903
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())       # (0, 'high-priority item')
    print(q.get_nowait())       # (1, 'medium-priority item')
    print(q.get_nowait())       # (10, 'low-priority item')


# Generated at 2022-06-24 09:10:53.474374
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # Test with a small queue size
    q = Queue(5)
    print( q )
    # Test with a large queue size
    q = Queue(75)
    print( q )
    # Test with a queue size of 0
    q = Queue(0)
    print( q )
    # Test with a queue size of None
    q = Queue(None)
    print( q )


# Generated at 2022-06-24 09:10:57.953370
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert q.full() is False
    q = Queue(maxsize=0)
    assert q.full() is False
    q = Queue(maxsize=1)
    assert q.full() is False
    q.put_nowait(1)
    assert q.full() is True
    q = Queue(maxsize=2)
    q.put_nowait(1)
    assert q.full() is False
    q.put_nowait(2)
    assert q.full() is True



# Generated at 2022-06-24 09:11:03.083540
# Unit test for method get_nowait of class Queue

# Generated at 2022-06-24 09:11:09.367600
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    priorityQueue = PriorityQueue()
    priorityQueue.put((0, 'high-priority item'))
    priorityQueue.put((1, 'medium-priority item'))
    priorityQueue.put((-1, 'low-priority item'))

    assert(priorityQueue.get_nowait()[0] == -1)
    assert(priorityQueue.get_nowait()[0] == 0)
    assert(priorityQueue.get_nowait()[0] == 1)



# Generated at 2022-06-24 09:11:13.528429
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=2)
    assert q.empty()
    assert not q.full()
    q.put_nowait(123)
    assert not q.empty()
    assert not q.full()
    q.put_nowait(456)
    assert not q.empty()
    assert q.full()
    assert q.get_nowait() == 123
    assert not q.empty()
    assert not q.full()
    assert q.get_nowait() == 456
    assert q.empty()
    assert not q.full()
    assert q.qsize() == 0
    assert q.maxsize == 2

# Generated at 2022-06-24 09:11:22.516737
# Unit test for method get of class Queue
def test_Queue_get():
    # Set up
    q = Queue(maxsize=2)
    q.put_nowait(0)
    q.put_nowait(1)
    q.get_nowait()
    q.get_nowait()
    # Exercise
    # Verify
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    assert q.put(0,0) != None
    assert q.put_nowait(0)
    # Tear down



# Generated at 2022-06-24 09:11:24.113754
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        assert True


# Generated at 2022-06-24 09:11:27.442505
# Unit test for method empty of class Queue
def test_Queue_empty():
    if not hasattr(Queue,'empty'):
        return
    q = Queue() 
    return q.empty()

# Generated at 2022-06-24 09:11:31.119567
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import unittest
    from tornado.queues import Queue

    class TestQueue(unittest.TestCase):
        def test_Queue_qsize(self):
            q = Queue(maxsize=2)
            self.assertEqual(q.qsize(),0)


    unittest.main()

# Generated at 2022-06-24 09:11:33.402374
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    assert not q.full()
    q.put_nowait(object())
    assert q.full()
    q.get_nowait()
    assert not q.full()



# Generated at 2022-06-24 09:11:40.391822
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import unittest
    import pytest
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    from functools import partial
    from tornado.testing import AsyncTestCase, gen_test
    
    
    
    
    
    
    
    
    
    
    
    
    @pytest.mark.gen_test
    def test_queue_iterator(self):
        
        items = [1, 2, 3]
        q = Queue()
        for i in items:
            yield q.put(i)
        it = _QueueIterator(q)
        assert isinstance(it, collections.Iterator)
        assert isinstance(it, collections.Iterable)

# Generated at 2022-06-24 09:11:48.895358
# Unit test for method empty of class Queue
def test_Queue_empty():
    # Initialize the Queue class
    q = Queue(maxsize = 10)
    # check if the queue is empty
    assert q.empty() == True
    # add item to queue
    q.put(1)
    # check if the queue is empty
    assert q.empty() == False
    # clear the queue
    q.qsize()
    # check if the queue is empty
    assert q.empty() == True
    print("Test Successful")

# unit test for method full of class Queue

# Generated at 2022-06-24 09:11:52.599737
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(123)
    itr = _QueueIterator(q)
    assert (await itr.__anext__()) == 123
test__QueueIterator___anext__()


# Generated at 2022-06-24 09:11:53.542690
# Unit test for constructor of class QueueFull
def test_QueueFull():
    qfull = QueueFull()



# Generated at 2022-06-24 09:12:03.545527
# Unit test for method join of class Queue
def test_Queue_join():
    def f_proc(q):
        print("f_proc started")
        # run forever
        while True:
            # get values
            item = q.get()
            print("Consumed an item:", item)
            # give notification that item is processed
            q.task_done()

    q = Queue(maxsize=10)
    t = Thread(target=f_proc, args=(q,))
    t.daemon = True
    t.start()

    # insert items
    for item in range(5):
        q.put(item)

    # wait till the end
    q.join()
    print("ended")


# Generated at 2022-06-24 09:12:06.082075
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    from typing import List

    queue = Queue()
    it = _QueueIterator(queue)
    assert it.q is queue
    assert it.__anext__ is not None


# Generated at 2022-06-24 09:12:08.111471
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(1)
    # type: ignore
    q.put_nowait(0)
    _QueueIterator(q)



# Generated at 2022-06-24 09:12:17.362943
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from . import dummy
    q = Queue(maxsize=1)
    q.put(1)
    it = dummy.DummyAsyncIterator(q)
    assert dummy.anexpect(it.a__anext__(), 1) is None
    assert dummy.anexpect(it.a__anext__(), 2) == 1
    assert dummy.anexpect(it.a__anext__(), 3) == 2
    assert dummy.anexpect(it.a__anext__(), 4) == 3
    assert dummy.anexpect(it.a__anext__(), 5) == 4


# Generated at 2022-06-24 09:12:21.287507
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue

    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

if __name__ == "__main__":
    test_PriorityQueue()
    print("All test cases are passed!")


# Generated at 2022-06-24 09:12:23.890392
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    if(q.task_done()==ValueError):
        assert True
test_Queue_task_done()

# Generated at 2022-06-24 09:12:29.710754
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    assert isinstance(q, collections.abc.AsyncIterable)
    assert isinstance(q.__aiter__(), collections.abc.AsyncIterator)

    @gen.coroutine
    def foo(q):
        for i in q:
            print(i)
            return i

    q.put(5)
    assert gen.with_timeout(timedelta(seconds=0.1), foo(q)) == 5



# Generated at 2022-06-24 09:12:35.567123
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-24 09:12:40.837011
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:12:48.620064
# Unit test for method empty of class Queue
def test_Queue_empty():
    a = Queue(maxsize=2)
    assert(a.empty() == True)
    assert(a.full() == False)
    a.put_nowait(1)
    assert(a.empty() == False)
    assert(a.full() == False)
    a.put_nowait(2)
    assert(a.empty() == False)
    assert(a.full() == True)
    a.get_nowait()
    assert(a.empty() == False)
    assert(a.full() == False)
    a.get_nowait()
    assert(a.empty() == True)
    assert(a.full() == False)
    print("Pass test_Queue_empty")


# Generated at 2022-06-24 09:12:50.616630
# Unit test for method empty of class Queue
def test_Queue_empty():
    print("\nUnit test for Queue.empty method")
    queue = Queue()
    print(queue.empty())


# Generated at 2022-06-24 09:12:53.885416
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import time
    import random
    import operator
    import unittest
    import logging

    q = Queue()
    logging.info(q.empty())
    time.sleep(2)
    q._queue.append(1)
    logging.info(q.qsize())

# Generated at 2022-06-24 09:13:02.610762
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from .test_utils import BaseTestCase
    from tornado import gen

    class TestQueue__repr__(BaseTestCase):
        @gen.coroutine
        def setUp(self):
            yield super().setUp()

            self.q = Queue()
            self.q._queue = "queue1"
            self.q._getters = "getters"
            self.q._putters = "putters"
            self.q._unfinished_tasks = 3

        def test_empty_queue(self):
            self.assertEqual(repr(Queue()), "<Queue at 0x{:x} maxsize=0 queue=deque([])>".format(
                id(Queue())))


# Generated at 2022-06-24 09:13:06.865651
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    testQueue = Queue()
    assert testQueue.qsize() == 0
    testQueue.put(5)
    assert testQueue.qsize() == 1
    testQueue.put(7)
    assert testQueue.qsize() == 2
    testQueue.get()
    assert testQueue.qsize() == 1
    testQueue.get()
    assert testQueue.qsize() == 0


# Generated at 2022-06-24 09:13:15.511397
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

#     async def consumer():
#         async for item in q:
#             try:
#                 print('Doing work on %s' % item)
#                 await gen.sleep(0.01)
#             finally:
#                 q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
#         IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish

# Generated at 2022-06-24 09:13:19.684469
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

test_PriorityQueue()



# Generated at 2022-06-24 09:13:30.256735
# Unit test for method full of class Queue
def test_Queue_full():
    def test_full1(q: Queue):
        assert q.full() == False
        q.put_nowait(1)
        assert q.full() == True
        q.get_nowait()

    def test_full2(q: Queue):
        assert q.full() == False
        q.put_nowait(2)
        assert q.full() == False
        q.put_nowait(2)
        assert q.full() == True
        q.get_nowait()

    q1 = Queue(1)
    q2 = Queue(2)
    test_full1(q1)
    test_full1(q2)
    test_full2(q1)
    test_full2(q2)



# Generated at 2022-06-24 09:13:38.524356
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    print('test_PriorityQueue()')
    q = PriorityQueue()
    # put()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    # get_nowait(), we can assert the priority order
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:13:43.910261
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:13:45.391298
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert not q.full()


# Generated at 2022-06-24 09:13:48.900851
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    _q = Queue()
    _q.put_nowait(1)
    _i = _QueueIterator(_q)
    _r = asyncio.run(_i.__anext__())

# Generated at 2022-06-24 09:13:50.903460
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    assert isinstance(q, PriorityQueue)
    assert not q.empty()
    assert q._queue != None
    assert q._getters == None
    assert q._putters == None
    assert q._unfinished_tasks == None
    assert q._finished == None



# Generated at 2022-06-24 09:13:51.464770
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-24 09:13:55.515831
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert isinstance(q, Queue)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-24 09:14:02.292858
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.__put_internal(1)
    q.__put_internal(2)
    q.__put_internal(3)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
        assert False
    except QueueEmpty as e:
        assert True


# Generated at 2022-06-24 09:14:04.299765
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty:
        pass


# Generated at 2022-06-24 09:14:15.835058
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue
    q = Queue(maxsize=4)
    # queue=deque([], maxlen=4)
    assert str(q) == "<Queue maxsize=4 queue=deque([]>)"
    # getters[1] because we create a _QueueIterator
    assert str(_QueueIterator(q)) == "<_QueueIterator at 0x7f909bd6c490 queue=deque([]>)"
    assert str(q) == "<Queue maxsize=4 queue=deque([]) getters[1]>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=4 queue=deque([1]) getters[1]>"
    assert str(q) == "<Queue maxsize=4 queue=deque([1]) getters[1]>"

# Generated at 2022-06-24 09:14:22.402610
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    """
    Test if Queue's task_done behaves as expected
    """
    q = Queue()

    # Test if task_done works when there is no unfinished_tasks
    q.task_done()

    # Test if task_done works when there is unfinished_tasks
    q._unfinished_tasks = 1
    q.task_done()

    # Test if task_done raises error when unfinished_tasks is less than 0
    q._unfinished_tasks = -1
    exception = False
    try:
        q.task_done()
    except ValueError:
        exception = True
    assert exception
    return True

# Generated at 2022-06-24 09:14:30.301058
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    from tornado.testing import AsyncTestCase, gen_test


    class TestQueueIter(AsyncTestCase):
        @gen_test
        async def test__QueueIterator(self):
            q = Queue()
            q.put_nowait(1)
            q.put_nowait(2)
            q.put_nowait(3)
            async for i in _QueueIterator(q):
                self.assertEqual(i, 1)
                self.assertEqual(i, 2)
                self.assertEqual(i, 3)

    asyncio.run(TestQueueIter().test__QueueIterator())



# Generated at 2022-06-24 09:14:32.300771
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    test_queue = PriorityQueue()
    assert test_queue.maxsize == 0
    assert test_queue.qsize() == 0
    assert test_queue.empty() == True
    assert test_queue.full() == False
    assert test_queue.maxsize == 0
    assert test_queue.maxsize == 0


# Generated at 2022-06-24 09:14:40.752836
# Unit test for method empty of class Queue
def test_Queue_empty():
    for maxsize in (-1, 0, 10):
        q = Queue(maxsize=maxsize)
        assert q.empty()
        assert q.qsize() == 0
        # Enqueue a single item
        q.put_nowait(object())
        assert not q.empty()
        assert q.qsize() == 1
        assert q.get_nowait() is not None
        assert not q.empty()
        q.task_done()
        assert q.empty()
        assert q.qsize() == 0


# Generated at 2022-06-24 09:14:44.759731
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    print("Testing LifoQueue...")
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:14:54.258825
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=5)
    q._queue = collections.deque([0, 1, 2, 3, 4])
    q._unfinished_tasks = 5
    x = q.get()
    print(type(x))
    print(x)
    # <class 'tornado.concurrent.Future'>
    # <Future finished exception=<class 'tornado.gen.TimeoutError'>>
    x1 = q._get()
    print(type(x1))
    print(x1)
    # <class 'int'>
    # 0


# Generated at 2022-06-24 09:14:56.245863
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    # Check if the repr shows instances of Queue
    assert "Queue" in repr(q)


# Generated at 2022-06-24 09:14:58.228921
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()

    q.put_nowait(1)
    assert not q.empty()

    q.get_nowait()
    assert q.empty()



# Generated at 2022-06-24 09:15:05.553186
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.get_nowait()
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:15:11.948476
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    class TestQueue(Queue):
        def __init__(self):
            Queue._init(self)
            self._unfinished_tasks = 0

        def task_done(self):
            Queue.task_done(self)

    q = TestQueue()
    assert q._unfinished_tasks == 0
    with pytest.raises(ValueError):
        q.task_done()

    q._unfinished_tasks = 1
    q.task_done()
    assert q._unfinished_tasks == 0



# Generated at 2022-06-24 09:15:23.400419
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    def ttt(*args,**kwargs):
        print('Come in ttt')
        async def consumer():
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
        return consumer(*args,**kwargs)
    async def producer(q):
        for item in range(20):
            await gen.sleep(0.01)
            print('Put %s' % item)
            await q.put(item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current

# Generated at 2022-06-24 09:15:32.871963
# Unit test for method get of class Queue
def test_Queue_get():
    print("Test Queue.get()")
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)

    # test 1: successful get
    print("  Test 1")
    coro = q.get()
    assert(isinstance(coro, Awaitable))
    future = Future()
    coro.add_done_callback(lambda f: future.set_result(f.result()))
    item = future.result()
    assert(item == 1)

    # test 2: unsuccessful get
    print("  Test 2")
    q.__init__()
    coro = q.get()
    assert(isinstance(coro, Awaitable))
    future = Future()

# Generated at 2022-06-24 09:15:38.490759
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue(maxsize=0)
    queue.maxsize
    queue.qsize()
    queue.empty()
    queue.full()
    queue.put_nowait(1)
    queue.get_nowait()
    queue.task_done()
    queue.join()
    queue.join()



# Generated at 2022-06-24 09:15:43.477420
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue = Queue()
    assert queue.__repr__() == "<Queue at " + hex(id(queue)) + " maxsize=0>"
    assert queue.__str__() == "<Queue maxsize=0>"



# Generated at 2022-06-24 09:15:44.519368
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    LifoQueue()


# Generated at 2022-06-24 09:15:49.004833
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:15:56.739764
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:16:01.257314
# Unit test for constructor of class Queue
def test_Queue():
    # __init__
    print("------------- test_queue __init__ -----------------")
    q = Queue()
    print(q)
    # maxsize
    print("------------- test_queue maxsize -----------------")
    print(q.maxsize)



# Generated at 2022-06-24 09:16:03.109611
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from tornado.queues import Queue
    queue1 = Queue()
    print(queue1)



# Generated at 2022-06-24 09:16:04.638907
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue(3)
    return q.put(2)
    

# Generated at 2022-06-24 09:16:16.448525
# Unit test for constructor of class _QueueIterator
def test__QueueIterator(): # pragma: no cover
    from . import testing

    def test_iter(q: "Queue[int]"):
        # type: ignore
        x = yield from _QueueIterator(q)
        assert x == 1
        x = yield from _QueueIterator(q)
        assert x == 2
        x = yield from _QueueIterator(q)
        assert x == 3
        yield q.put(4)
        yield q.put(5)
        x = yield from _QueueIterator(q)
        assert x == 4
        x = yield from _QueueIterator(q)
        assert x == 5

    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    testing.run_sync(test_iter, q)



# Generated at 2022-06-24 09:16:20.167783
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(10)
    assert q.qsize() == 1
    q.get_nowait()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:16:27.625869
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()

    def consumer():
        try:
            while True:
                item = q.get_nowait()
                try:
                    print('Doing work on %s' % item)
                finally:
                    q.task_done()
        except QueueEmpty:
            print('Queue is empty.')

    def producer():
        for item in range(5):
            q.put_nowait(item)
            print('Put %s' % item)

    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().spawn_callback(producer)
    ioloop.IOLoop.current().start()



# Generated at 2022-06-24 09:16:35.129007
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.empty()
    assert not q.full()
    q.put_nowait(1)
    assert not q.empty()
    assert not q.full()
    q.put_nowait(2)
    assert not q.empty()
    assert q.full()
    assert q.get_nowait() == 1
    assert not q.empty()
    assert not q.full()
    assert q.get_nowait() == 2
    assert q.empty()
    assert not q.full()
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False



# Generated at 2022-06-24 09:16:41.664803
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import asyncio
    import tornado

    @gen.coroutine
    def test():
        q = Queue()
        q.put(1)
        q.put(2)
        q.put(3)
        iterator = _QueueIterator(q)
        items = []
        async for i in iterator:
            items.append(i)
        tornado.ioloop.IOLoop.current().stop()
        assert items == [1, 2, 3]

    ioloop = tornado.ioloop.IOLoop.current()
    ioloop.add_callback(test)
    ioloop.start()



# Generated at 2022-06-24 09:16:45.351725
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    # type: () -> None
    q = Queue() # type: Queue[int]
    q._putters = []
    q._waiters = []
    it = _QueueIterator(q)
    q.unfinished_tasks = 1
    q.maxsize = 0
    Event().wait()



# Generated at 2022-06-24 09:16:47.542744
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    t = PriorityQueue()
    print(t)


# Generated at 2022-06-24 09:16:53.612286
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_PriorityQueue()



# Generated at 2022-06-24 09:16:56.785092
# Unit test for method put of class Queue
def test_Queue_put():
      
  q = Queue(maxsize=2)
  q.put(1)
  q.put(2)
  assert q.get() == 1




# Generated at 2022-06-24 09:16:59.290845
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    print(q.qsize())

# Generated at 2022-06-24 09:17:03.108968
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1 and q.get_nowait() == 2
    assert q.qsize() == 0
    assert q.empty()


# Generated at 2022-06-24 09:17:05.062390
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q.maxsize
    q.qsize()



# Generated at 2022-06-24 09:17:09.845021
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:17:10.590805
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    q = QueueEmpty()
    return



# Generated at 2022-06-24 09:17:14.380635
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue[int]()
    q.put(1)
    i = _QueueIterator[int](q)
    assert i.__anext__() == gen.sleep(0) + q.get()

# Generated at 2022-06-24 09:17:20.647135
# Unit test for constructor of class Queue
def test_Queue():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-24 09:17:24.713445
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put('a')
    q.put('b')
    q.put('c')
    q.join()
    assert list(q) == ['a', 'b', 'c']



# Generated at 2022-06-24 09:17:32.079690
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    
    #assert q.full() == False, "q is not full"

    q.put_nowait(1)
    q.put_nowait(2)

    try:
        q.put_nowait(3)
    except QueueFull:
        print('Queue is full')

    #assert q.full() == True, "q is full"
    
    
#############
# test if the queue is full
#############
if __name__ == "__main__":
    test_Queue_put_nowait()

# Generated at 2022-06-24 09:17:37.507934
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    res = it.__anext__()
    isinstance(res, coroutine) == True
    isinstance(res, Awaitable) == True
    q.task_done()



# Generated at 2022-06-24 09:17:39.137212
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Test the method __str__ of class Queue
    pass



# Generated at 2022-06-24 09:17:51.356376
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    # checking to see if Queue is empty
    assert q.empty()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.

# Generated at 2022-06-24 09:18:03.970102
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue
    import sys

    # Test PriorityQueue._init()
    q = PriorityQueue()
    assert q._queue == []

    # Test PriorityQueue.put_nowait()
    q.put_nowait((1, 'medium-priority item'))
    q.put_nowait((0, 'high-priority item'))
    q.put_nowait((10, 'low-priority item'))
    assert q._queue == [(0, 'high-priority item'), (1, 'medium-priority item'), (10, 'low-priority item')]

    # Test PriorityQueue._get() method
    assert q._get() == (0, 'high-priority item')
    assert q._queue == [(1, 'medium-priority item'), (10, 'low-priority item')]


# Generated at 2022-06-24 09:18:06.838951
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put("a")
    it = _QueueIterator(q)
    a = it.__anext__()
    assert a.result() == "a"


# Generated at 2022-06-24 09:18:19.049734
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:21.062838
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass


# Generated at 2022-06-24 09:18:24.225006
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize = 0)
    assert q.maxsize == 0
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()


# Generated at 2022-06-24 09:18:25.544726
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    print(q)
test_Queue()

# Generated at 2022-06-24 09:18:32.825821
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado.gen
    import tornado.ioloop
    import unittest
    import tornado.queues
    import time

    class JoinTest(unittest.TestCase):
        def test_join(self):
            async def test_with_timeout():
                timeout = 5
                q = tornado.queues.Queue(maxsize=10, io_loop=io_loop)
                for i in range(10):
                    await q.put(1)
                start_time = time.time()
                with self.assertRaises(tornado.util.TimeoutError):
                    await q.join(0.4)
                elapsed_time = time.time() - start_time
                self.assertGreater(elapsed_time, timeout - 1)
                self.assertLess(elapsed_time, timeout)


# Generated at 2022-06-24 09:18:36.443572
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    #q.put_nowait(3)  # The queue is full, it will raise a `QueueFull` exception


# Generated at 2022-06-24 09:18:48.933326
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import datetime

    # The top-level IOLoop should not be accessed directly, but this is a
    # test...
    io_loop = tornado.ioloop.IOLoop.current()

    # This test is written in a special way so that it can be run with
    # ``python -m unittest`` from the top-level directory.
    import sys
    import os.path
    import unittest
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from tornado.test.ioloop_util import async_test
    from tornado.util import timedelta_to_seconds


# Generated at 2022-06-24 09:18:51.278842
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # create a queue
    q = Queue()
    # put the item into the queue
    q.put()
    # test task_done
    q.task_done()



# Generated at 2022-06-24 09:19:03.346434
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    def put(value):
        q.put_nowait(value)

    def get():
        return q.get_nowait()

    def main(loop):
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        producer()

# Generated at 2022-06-24 09:19:05.078333
# Unit test for method put of class Queue
def test_Queue_put():
	q=Queue()
	q.put("test")
	assert q.qsize()==1


# Generated at 2022-06-24 09:19:12.105530
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = q.put(1) # returns a Future
    assert isinstance(f, Future)
    i = q.get() # get is a coroutine
    assert isinstance(i, Awaitable)
    a = i.result() # handles coroutine and returns value
    assert isinstance(a, _T)
    b = a()
    assert b == 1


# Generated at 2022-06-24 09:19:15.353596
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0>" % id(q)

# Generated at 2022-06-24 09:19:21.282542
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import tornado.ioloop
    import tornado.gen
    import tornado.queues
    import typing
    event_queue = tornado.queues.Queue()
    loop = tornado.ioloop.IOLoop.instance()
    tornado.ioloop.PeriodicCallback(lambda: event_queue.put([1, 2, 3]), 100, loop).start()
    tornado.ioloop.PeriodicCallback(lambda: event_queue.put([4, 5, 6]), 200, loop).start()
    tornado.ioloop.PeriodicCallback(lambda: event_queue.put([7, 8, 9]), 400, loop).start()
    tornado.ioloop.PeriodicCallback(lambda: event_queue.put([10, 11, 12]), 800, loop).start()

# Generated at 2022-06-24 09:19:24.454488
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    assert isinstance(it, typing.AsyncIterator)


# Generated at 2022-06-24 09:19:32.440478
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import tornado.gen

    def queue_put(q):
        q.put(1)
        q.put(2)
        q.put(3)

    q = Queue()
    ioloop = tornado.ioloop.IOLoop.current()
    yield tornado.gen.Task(ioloop.add_callback, queue_put, q)
    for i in range(3):
        result = yield q.put(i)
        assert result == i

