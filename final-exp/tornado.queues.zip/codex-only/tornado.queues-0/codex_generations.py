

# Generated at 2022-06-24 09:09:30.653623
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(1)  # type: ignore
    assert not q.full()
    f = Future()
    assert f.done() == False
    q._putters.append((1, f))
    q._putters[0][1].set_result(None)
    assert f.done() == True
    assert q.full() 
    

# Generated at 2022-06-24 09:09:36.588736
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # Test for empty queue
    q = Queue()
    assert q.qsize() == 0
    # Test for non-empty queue
    q = Queue()
    q._queue.append(1)
    assert q.qsize() == 1


# Generated at 2022-06-24 09:09:38.825561
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty()
    except QueueEmpty as e:
        assert str(e) == ''


# Generated at 2022-06-24 09:09:45.398254
# Unit test for method full of class Queue
def test_Queue_full():
  q = Queue(maxsize=5)
  res = q.full()
  assert res == False
  q.put('a')
  q.put('b')
  q.put('c')
  q.put('d')
  q.put('e')
  res = q.full()
  assert res == True
  q.get()
  res = q.full()
  assert res == False

# Generated at 2022-06-24 09:09:54.215581
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    assert isinstance(Queue(0), Queue)
    q = Queue(0)
    assert len(q._getters) is 0
    assert q.empty()
    try:
        q.get_nowait()
        assert 0
    except QueueEmpty:
        pass
    q._putters.append([0, Future()])
    assert q.full()
    try:
        q.get_nowait()
        assert 0
    except QueueEmpty:
        pass
    q._queue.append(0)
    assert q.qsize() is 1
    assert q.get_nowait() is 0
    q._getters.append(Future())
    assert q.empty()
    q._put(0)
    assert q.qsize() is 1

# Generated at 2022-06-24 09:09:55.672343
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0



# Generated at 2022-06-24 09:10:08.170620
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    from datetime import timedelta
    from pytest import mark

    @mark.asyncio
    async def test_Queue___repr__():
        q = Queue()
        for i in range(5):
            q.put_nowait(i)
        assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([0, 1, 2, 3, 4])>" % (
            id(q),
        )
        getter = q.get()
        assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([0, 1, 2, 3, 4]) " % (
            id(q),
        ) + "getters[1]>"
        future = q.put(5, timeout=timedelta(seconds=1))

# Generated at 2022-06-24 09:10:14.279127
# Unit test for method task_done of class Queue
def test_Queue_task_done():
  q = Queue(maxsize=10)
  # use two yield in function, need to be coverted to coroutine
  def exit_when_task_is_done():
    yield q.get()
    q.task_done()
    yield gen.sleep(0)
  @gen.coroutine
  def producer():
    q.put(1)
    q.put(2)
  @gen.coroutine
  def main():
    for x in range(2):
      ioloop.IOLoop.current().spawn_callback(exit_when_task_is_done)
    yield producer()
    yield q.join()
  ioloop.IOLoop.current().run_sync(main)
print("ok")


# Generated at 2022-06-24 09:10:16.818928
# Unit test for method get of class Queue
def test_Queue_get():
    count = Queue()
    count.put(5)
    return count.get()


# Generated at 2022-06-24 09:10:18.814766
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)

    q.put(1)
    q.qsize()
    q.empty()
    q.full()
    q.get()
    q.task_done()
    q.join()



# Generated at 2022-06-24 09:10:20.603163
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    a = QueueEmpty()
    assert a is not None



# Generated at 2022-06-24 09:10:26.142603
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty as qe:
        print(qe)



# Generated at 2022-06-24 09:10:34.328059
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:10:36.637215
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import queue
    assert '<Queue maxsize=0 queue=deque([])>' == str(queue.Queue())
test_Queue___str__()



# Generated at 2022-06-24 09:10:40.894745
# Unit test for method full of class Queue
def test_Queue_full():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    q.put_nowait(6)
    q.put_nowait(7)
    assert q.full() == True
    q.get_nowait()
    assert q.full() == False

# Generated at 2022-06-24 09:10:45.308459
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.get_nowait()
    q.task_done()
    q.task_done()
test_Queue_get_nowait()

# Generated at 2022-06-24 09:10:45.914287
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass



# Generated at 2022-06-24 09:10:55.359566
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()

    q = Queue()
    q.put_nowait(None)
    assert q._unfinished_tasks == 1
    q.task_done()
    assert q._unfinished_tasks == 0

    q = Queue()
    q.put_nowait(None)
    q.put_nowait(None)
    assert q._unfinished_tasks == 2
    assert not q._finished.is_set()
    q.task_done()
    assert q._unfinished_tasks == 1
    assert not q._finished.is_set()
    q.task_done()
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()


# Generated at 2022-06-24 09:11:01.451910
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
    import io, io
   

# Generated at 2022-06-24 09:11:12.299501
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, get_unused_port
    from tornado.httpclient import AsyncHTTPClient, HTTPClientError
    from tornado.httpserver import HTTPServer
    import socket
    import threading
    import urllib.parse
    import requests
    import json
    import time

    class Client(AsyncHTTPClient):
        def initialize(self, server, **kwargs):
            super(Client, self).initialize(**kwargs)
            self.server = server

        def get(self, url, **kwargs):
            return super(Client, self).get(
                urllib.parse.urljoin(self.server, url), **kwargs)
    

# Generated at 2022-06-24 09:11:14.060505
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    itr = _QueueIterator(q)



# Generated at 2022-06-24 09:11:26.479522
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-24 09:11:31.239538
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int](1)
    q.put(1)
    i = _QueueIterator(q)
    x: Awaitable[int] = i.__anext__()
    assert isinstance(x, Awaitable)
    assert isinstance(x.result(), int)



# Generated at 2022-06-24 09:11:38.947812
# Unit test for method full of class Queue
def test_Queue_full():
    # Initialization
    q = Queue(2)
    print(q)
    # Output: <Queue maxsize=2 queue=deque([], maxlen=2)>
    assert q.qsize() == 0

    result = q.full()
    print(result)
    # Output: False

    q.put_nowait(0)
    print(q)
    # Output: <Queue maxsize=2 queue=deque([0], maxlen=2)>
    assert q.qsize() == 1

    result = q.full()
    print(result)
    # Output: False

    q.put_nowait(1)
    print(q)
    # Output: <Queue maxsize=2 queue=deque([0, 1], maxlen=2)>
    assert q.qsize() == 2

    result

# Generated at 2022-06-24 09:11:49.257004
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, "medium-priority item"))
    q.put((0, "high-priority item"))
    q.put((10, "low-priority item"))

    print("(0, 'high-priority item')")
    print("(1, 'medium-priority item')")
    print("(10, 'low-priority item')")

    print("====================================")
    print("\n" + str(q.get_nowait()))
    print("\n" + str(q.get_nowait()))
    print("\n" + str(q.get_nowait()))
test_PriorityQueue()


# Generated at 2022-06-24 09:11:50.178033
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    assert 1 == 1

# Generated at 2022-06-24 09:11:52.333776
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue()
    str(queue)
test_Queue___str__()



# Generated at 2022-06-24 09:11:58.529449
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:12:08.487298
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
        q.task_done()

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-24 09:12:15.387449
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()
    q.put_nowait(42)
    assert not q.full()
    q.put_nowait(42)
    assert q.full()
    q.get_nowait()
    assert not q.full()


_PRIORITY_QUEUE_EMPTY = "Priority queue is empty"



# Generated at 2022-06-24 09:12:20.830057
# Unit test for method __str__ of class Queue
def test_Queue___str__():  # noqa: N802
    q = Queue()
    assert str(q) == "<Queue maxsize=0 queue=deque([])>"

    q = Queue()
    q._queue = [1, 2, 3]
    q._putters = [(4, 5), (6, 7)]
    q._getters = [8, 9]
    q._unfinished_tasks = 10
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3] putters[2] getters[2] tasks=10>"

    q = Queue()
    q._queue = [1, 2, 3]
    q._unfinished_tasks = 10
    assert str(q) == "<Queue maxsize=0 queue=[1, 2, 3] tasks=10>"



# Generated at 2022-06-24 09:12:27.434867
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)

    # Put 0
    q.put_nowait(0)
    assert q.qsize() == 1

    # Put 1
    q.put_nowait(1)
    assert q.qsize() == 2

    # Take 0
    q.get_nowait()
    assert q.qsize() == 1

    # Take 1
    q.get_nowait()
    assert q.qsize() == 0



# Generated at 2022-06-24 09:12:30.595814
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert isinstance(it, _QueueIterator)
    await q.put(1)
    assert await it.__anext__() == 1



# Generated at 2022-06-24 09:12:38.123913
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    '''
    def get_nowait(self) -> _T:
        """Remove and return an item from the queue without blocking.

        Return an item if one is immediately available, else raise
        `QueueEmpty`.
        """
        self._consume_expired()
        if self._putters:
            assert self.full(), "queue not full, why are putters waiting?"
            item, putter = self._putters.popleft()
            self.__put_internal(item)
            future_set_result_unless_cancelled(putter, None)
            return self._get()
        elif self.qsize():
            return self._get()
        else:
            raise QueueEmpty
    '''
    q = Queue(maxsize=2)
    assert type(q) == Queue

# Generated at 2022-06-24 09:12:39.935093
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
test_Queue_put_nowait()

# Generated at 2022-06-24 09:12:45.373123
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    value_list = [1, 2]
    for i in value_list:
        q.put_nowait(i)
    q_len = len(q._queue)
    assert q_len == len(value_list), "Queue not empty"
    #print("Queue not empty")
    # Check if elements are in queue
    for i in range(q_len):
        assert q._queue[i] == value_list[i], "Element not in position {}, should be {}".format(i, value_list[i])


# Generated at 2022-06-24 09:12:52.478926
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import tornado
    import tornado.concurrent
    import tornado.ioloop
    import tornado.log

    # FIXME: This line is not supported by mypy yet
    import asyncio
    async def async_main():
        q = Queue()
        await q.put(1)
        await q.put(2)
        await q.put(3)
        async for i in q:
            tornado.log.gen_log.info("i = %s", i)
            if i == 2:
                tornado.log.gen_log.info("break")
                break

    if __name__ == "__main__":
        tornado.log.enable_pretty_logging()
        io_loop = tornado.ioloop.IOLoop.current()
        io_loop.run_sync(async_main)

# Generated at 2022-06-24 09:12:58.607323
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put(3)
    assert q.qsize() == 1
    q.task_done()
    assert q.qsize() == 0



# Generated at 2022-06-24 09:12:59.899286
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)


# Generated at 2022-06-24 09:13:05.493178
# Unit test for constructor of class Queue
def test_Queue():
    def test_none():
        q = Queue(None)
    
    def test_negative():
        q = Queue(-1)

    assert_raises(TypeError, test_none)
    assert_raises(ValueError, test_negative)


# Subclass of Queue that uses getters/putters to block when the Queue is empty
# or full.

# Generated at 2022-06-24 09:13:08.287941
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert(q.qsize()==0)
    q.put_nowait(3)
    assert(q.qsize()==1)


# Generated at 2022-06-24 09:13:14.812683
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait("imooc")
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.qsize() == 1
    assert q.get_nowait() == "imooc"
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert isinstance(e, QueueEmpty)
        print(e)

# Generated at 2022-06-24 09:13:15.438909
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    pass



# Generated at 2022-06-24 09:13:17.949136
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    x = yield from it.__anext__()
    assert x == 1

# Generated at 2022-06-24 09:13:21.698906
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    f = _QueueIterator(Queue())
    assert isinstance(f, _QueueIterator)
    assert f.q.qsize() == 0


# Generated at 2022-06-24 09:13:25.496424
# Unit test for method join of class Queue
def test_Queue_join():
    import io, io_loop
    @gen.coroutine
    def main():
        q = Queue(maxsize=2)
        q.put_nowait(1)
        q.put_nowait(2)
        yield q.join()
        assert q.qsize() == 0
    io_loop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:13:32.131569
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    # Initialize a queue with maxsize 0
    q = Queue(maxsize = 0)
    # Get the size of the queue
    size = q.qsize()
    assert size == 0
    # Put an item into the queue
    q.put_nowait(10)
    # Get the size of the queue
    size = q.qsize()
    assert size == 1


# Generated at 2022-06-24 09:13:40.360148
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    time.sleep(0.01)
    q.put_nowait(3)
    q.put_nowait(4)
    print(q.get_nowait())
    time.sleep(0.01)
    print(q.get_nowait())
    print(q.get_nowait())
    time.sleep(0.01)
    print(q.get_nowait())
    print("")

test_Queue_get_nowait()


# Generated at 2022-06-24 09:13:52.314657
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                # print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            # print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        # print('Done')


# Generated at 2022-06-24 09:13:54.682714
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    assert 1 == (await _QueueIterator(q).__anext__())


# Generated at 2022-06-24 09:13:59.547498
# Unit test for constructor of class QueueFull
def test_QueueFull():
    a = QueueFull
    a_name = 'QueueFull'
    a_module = 'tornado.queues'
    a_doc = """Raised by `.Queue.put_nowait` when a queue is at its maximum size."""
    assert a.__name__ == a_name
    assert a.__module__ == a_module
    assert a.__doc__ == a_doc



# Generated at 2022-06-24 09:14:03.963997
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Arrange
    q = Queue(maxsize=2)
    q._unfinished_tasks = 1

    # Act
    q.task_done()

    # Assert
    assert q._unfinished_tasks == 0


# Generated at 2022-06-24 09:14:07.877983
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    item = 1
    q.put(item)
    assert q.get_nowait() == item, "Queue get_nowait wrong value"

# Generated at 2022-06-24 09:14:10.064444
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize = 0)
    assert q.qsize() == 0


# Generated at 2022-06-24 09:14:12.825374
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put_nowait(1)
    it = _QueueIterator(q)
    assert(it.__anext__().result() == 1)



# Generated at 2022-06-24 09:14:15.880792
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(4)
    q.put(1)
    q.put(2)
    for i in q:
        print(i)



# Generated at 2022-06-24 09:14:18.442649
# Unit test for method __str__ of class Queue
def test_Queue___str__():
	from tornado.queues import Queue
	test_Queue___str__ = Queue()
	test_Queue___str__ = Queue(maxsize=2)


# Generated at 2022-06-24 09:14:22.148179
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:14:23.914676
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado.queues
    q = tornado.queues.Queue()
    q.task_done()


# Generated at 2022-06-24 09:14:26.359140
# Unit test for method full of class Queue
def test_Queue_full():
    # Arrange
    q = Queue(maxsize=2)
    # Act
    retValue = q.full()
    # Assert
    assert retValue == False



# Generated at 2022-06-24 09:14:28.179588
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.maxsize == 0
    assert q.qsize() == 0



# Generated at 2022-06-24 09:14:36.184344
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import json
    import time

    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    # 生产者
    def producer():
        for num in range(10):
            print('Put %s' % num)
            q.put(num)
            time.sleep(0.5)

        yield q.put(None)
        print('Producer exit')

    # 消费者
    def consumer():
        while True:
            num = yield q.get()
            if num is None:
                break

            print('Get %s' % num)
            yield q.task_done()

        print('Consumer exit')

    q = Queue()    # maxsize=2
    IOLoop.current().run_sync(producer)
    IOLoop.current().run

# Generated at 2022-06-24 09:14:38.515911
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get(timeout=1.0) is not None


# Generated at 2022-06-24 09:14:42.860329
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:14:44.979082
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    print(q)

test_Queue___repr__()


# Generated at 2022-06-24 09:14:51.752909
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    class A:
        def __init__(self, a):
            self.a = a
        def __lt__(self, other):
            return self.a < other.a
    q = PriorityQueue()
    q.put(A(1))
    q.put(A(2))
    q.put(A(3))
    return q


test_PriorityQueue()


# Generated at 2022-06-24 09:14:55.644030
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    q.put(2)
    i = 0
    _len = q.qsize()
    while i < _len:
        a = q.get()
        print(a)
        i += 1
    a=q.get()
        
test_Queue_get()


# Generated at 2022-06-24 09:14:59.173126
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    try:
        for i in range(5):
            q.get()
            q.task_done()
            print("Task Done")
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-24 09:15:06.218159
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert repr(q) == "<Queue at 0x%x maxsize=2>" % id(q)
    q.put_nowait(1)
    q.put_nowait(2)
    assert repr(q) == "<Queue at 0x%x maxsize=2 queue=[1, 2]>" % id(q)



# Generated at 2022-06-24 09:15:15.669758
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    result = q.get_nowait()
    assert result == None
    #print("qsize()={}".format(q.qsize()))
    #print("empty()={}".format(q.empty()))
    #print("full()={}".format(q.full()))
    #print("task_done()={}".format(q.task_done()))
    #print("put(item, timeout)={}".format(q.put(item,timeout)))
    #print("put_nowait(item)={}".format(q.put_nowait(item)))
    #print("get(timeout)={}".format(q.get(timeout)))

test_Queue_get_nowait()


# Generated at 2022-06-24 09:15:17.264623
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("")
    except QueueFull:
        pass
    finally:
        print("test_QueueFull")



# Generated at 2022-06-24 09:15:26.880967
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue at 0x%x maxsize=2>" % id(q)
    q.put_nowait(1)
    assert str(q) == "<Queue at 0x%x maxsize=2 queue=[1]>" % id(q)
    q.put_nowait(2)
    assert str(q) == "<Queue at 0x%x maxsize=2 queue=[1, 2]>" % id(q)

    q.get_nowait()
    assert str(q) == "<Queue at 0x%x maxsize=2 queue=[2]>" % id(q)

    q.task_done()
    assert str(q) == "<Queue at 0x%x maxsize=2 queue=[2] tasks=1>" % id(q)

    f

# Generated at 2022-06-24 09:15:29.021168
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    print(q.__repr__())
# test_Queue___repr__()



# Generated at 2022-06-24 09:15:33.639407
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()
    q._unfinished_tasks = 1

    try:
        q.task_done()
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-24 09:15:44.189393
# Unit test for method join of class Queue
def test_Queue_join():
    # These tests are more complicated than they need to be because the
    # Queue is a coroutine; we need to start it and then wait for it
    # to finish. The test framework doesn't give us a good way to do
    # that, so we use a Future to wait for the Queue to finish in the
    # main thread and then do a get_nowait on the Future to see if it
    # worked out (could also use an explicit callback, but that
    # requires lots of extra state to keep track of).
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class QueueJoinTest(AsyncTestCase):
        def test_get_nowait(self):
            q = Queue()
            q.put_nowait(42)

# Generated at 2022-06-24 09:15:47.628239
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

# Generated at 2022-06-24 09:15:56.079979
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOL

# Generated at 2022-06-24 09:15:59.256714
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert isinstance(q.__repr__(), str)

# Test for method __str__ of class Queue

# Generated at 2022-06-24 09:16:03.674774
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert q.full() is False
    q.put_nowait('item0')
    assert q.full() is False
    q.put_nowait('item1')
    assert q.full() is True

test_Queue_full()


# Generated at 2022-06-24 09:16:11.190069
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)


    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

#    async def consumer():
#        async for item in q:
#            try:
#                print('Doing work on %s' % item)
#                await gen.sleep(0.01)
#            finally:
#                q.task_done()


    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)

# Generated at 2022-06-24 09:16:13.841868
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(2)
    assert q.get_nowait() == 2


# Generated at 2022-06-24 09:16:16.933168
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    z = Queue(maxsize=2)
    try:
        z.task_done()
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 09:16:26.292013
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    from unittest import TestCase

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to

# Generated at 2022-06-24 09:16:35.101750
# Unit test for method get of class Queue
def test_Queue_get():
    try:
        import queue
    except ImportError:
        import Queue as queue

    def _test_get(self, q: "queue.Queue[_T]", f: Future) -> None:
        try:
            item = q.get_nowait()
        except queue.Empty:
            self.fail("Unexpected queue.Empty exception")
        self.assertEqual(item, "spam")


# Generated at 2022-06-24 09:16:39.092321
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado.queues import Queue
    queue1 = Queue()
    queue1.task_done()
    queue1._unfinished_tasks = 0
    queue1.task_done()
    queue1._unfinished_tasks = 1
    queue1.task_done()



# Generated at 2022-06-24 09:16:42.440019
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(1)
    assert q.full() == False
    q.put_nowait(0)
    assert q.full() == True
test_Queue_full()


# Generated at 2022-06-24 09:16:49.631542
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    from tornado.queues import Queue
    async def do_test():
        q = Queue()
        await q.put(1)
        await q.put(2)
        await q.put(3)
        await q.put(4)
        print("q.qsize()=" + str(q.qsize()))
        assert q.qsize() == 4
        print("q.get()=" + str(await q.get()))
        print("q.get()=" + str(await q.get()))
        print("q.get()=" + str(await q.get()))
        print("q.get()=" + str(await q.get()))
        q.task_done()
        q.task_done()
        q.task_done()
        q.task

# Generated at 2022-06-24 09:16:58.150751
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert '<Queue maxsize=2 queue=deque([])>' == str(q)
    assert '<Queue maxsize=2 queue=deque([])>' == str(q)
    q.put_nowait(1)
    q.put_nowait(2)
    assert '<Queue maxsize=2 queue=deque([1, 2])>' == str(q)
    assert '<Queue maxsize=2 queue=deque([1, 2])>' == str(q)


# Generated at 2022-06-24 09:16:59.519000
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    pq = PriorityQueue()
    print(pq)



# Generated at 2022-06-24 09:17:00.984696
# Unit test for method task_done of class Queue
def test_Queue_task_done():

    with pytest.raises(ValueError):
        # call method task_done wrongly
        q.task_done(item)



# Generated at 2022-06-24 09:17:05.158171
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=1)
    q._queue = collections.deque()
    q._queue.append(1)
    assert str(q) == "<Queue maxsize=1 queue=[1]>"


# Generated at 2022-06-24 09:17:13.130181
# Unit test for method put of class Queue
def test_Queue_put():
    import tornado
    import tornado.http1connection
    import tornado.httputil
    import tornado.httpserver
    import tornado.iostream
    import tornado.ioloop
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    q = Queue(maxsize=2)
    q
    assert len(q) == 2
    assert q.empty()
    assert not q.full()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full()
    q.put(1)

# Generated at 2022-06-24 09:17:17.752521
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    q.put(3)
    assert q.get() == 3



# Generated at 2022-06-24 09:17:30.168128
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    items = []
    for i in range(5):
        items.append(i)
    
    # before test
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    
    # test after put_nowait(item)
    for item in items:
        q.put_nowait(item)
    assert q.maxsize == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.qsize() == 2
    assert q.get_nowait() == 0
    assert q.maxsize == 2
    assert q.empty() == False
    assert q.full() == True
    assert q.qsize() == 1
    assert q

# Generated at 2022-06-24 09:17:35.524053
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Given
    q = Queue(maxsize=2)
    q._queue = collections.deque([1, 2])

    # When
    item = q.get_nowait()

    # Then
    assert item == 1
    assert q._queue == collections.deque([2])



# Generated at 2022-06-24 09:17:42.199991
# Unit test for method full of class Queue
def test_Queue_full():
    a = Queue()
    b = a.full()
    print(b)
    a.put_nowait(1)
    b = a.full()
    print(b)
    a.put_nowait(2)
    b = a.full()
    print(b)
    a.put_nowait(3)
    b = a.full()
    print(b)


# Generated at 2022-06-24 09:17:43.549504
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    pass

# Generated at 2022-06-24 09:17:47.020506
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q1 = Queue(maxsize=2)
    try:
        q1.put_nowait(1)
    except QueueFull:
        return(False)
    return(True)



# Generated at 2022-06-24 09:17:50.151402
# Unit test for method qsize of class Queue
def test_Queue_qsize():
        print("Method qsize of class Queue")
        q = Queue(maxsize=2)
        print(q.qsize())
        q.put_nowait(1)
        q.put_nowait(2)
        print(q.qsize())
        q.task_done()
        print(q.qsize())
        q.task_done()
        print(q.qsize())        


# Generated at 2022-06-24 09:18:03.135147
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    #check if no tasks are done
    assert q._unfinished_tasks == 0
    try:
        q.task_done()
    except ValueError as e:
        assert type(e) == ValueError, 'ValueError expected'
    q.put(1)
    q.get()
    q.task_done()
    assert q._unfinished_tasks == 0, "done task"
    #check if 1 task is done
    q.put(1)
    q.task_done()
    assert q._unfinished_tasks == 1, '1 task is done'
    q.get()
    q.task_done()
    assert q._unfinished_tasks == 0, "done task"
    #check if max tasks are done
    q.put(1)
    q.put

# Generated at 2022-06-24 09:18:11.058154
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    async def work(ee):
        for i in range(5):
            await ee.put(i)
            print('Put %s' % i)
    async def main():
        q = Queue(maxsize=2)
        ee = thread_safe_queue()
        # Start consumer without waiting (since it never finishes).
        # IOLoop.current().spawn_callback(consumer)
        # await producer()     # Wait for producer to put all tasks.
        # await q.join()       # Wait for consumer to finish all tasks.
        await work(ee)
        print(ee._queue)
        print(ee.get_nowait())
        print(ee.get_nowait())
        print('Done')
    
    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:18:17.560237
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:27.821749
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    import queue
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.get_event_loop()
            self.q = queue.Queue(maxsize=3)

        def tearDown(self):
            self.loop.close()

        def test_empty_queue(self):
            future = asyncio.Future(loop=self.loop)
            f = self.q.join(future)
            self.assertTrue(f.done())
            f.cancel()

        def test_one_item_waiter(self):
            future = asyncio.Future(loop=self.loop)
            f = self.q.join(future)
            self.assertTrue(f.done())
            f.cancel()


# Generated at 2022-06-24 09:18:29.645993
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    """
    >>> assert not QueueEmpty()
    """


# Generated at 2022-06-24 09:18:31.690455
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():  # pragma: no cover
    q = Queue()
    itr = _QueueIterator(q)
    assert itr.q is q



# Generated at 2022-06-24 09:18:34.786844
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado.queues import Queue
    q = Queue()
    assert q.__str__() == "<Queue maxsize=0>", "__str__ should return  <Queue maxsize=0>"



# Generated at 2022-06-24 09:18:38.047704
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    from tornado.testing import gen_test
    @gen.coroutine
    def f():
        raise QueueEmpty
    with pytest.raises(QueueEmpty):
        yield f()
    with pytest.raises(QueueEmpty):
        yield f()



# Generated at 2022-06-24 09:18:47.285169
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from sys import getrefcount
    from tornado.queues import PriorityQueue
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))



# Generated at 2022-06-24 09:18:54.533760
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # test scenario
    # 1. Queue is full
    Queue.put_nowait(1)
    Queue.put_nowait(1)

    try:
        Queue.put_nowait(1)
        assert False
    except QueueFull:
        pass

    # 2. Queue is not full
    Queue.get_nowait()
    Queue.put_nowait(1)

    try:
        Queue.put_nowait(1)
        assert False
    except QueueFull:
        pass

# Generated at 2022-06-24 09:18:56.176887
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    #comment
    return None

# Generated at 2022-06-24 09:19:00.452500
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
	q = Queue(maxsize=2)
	q.put_nowait(1)
	q.put_nowait(2)
	if q.qsize() == 2:
		return True
	else:
		return False
print(test_Queue_put_nowait())


# Generated at 2022-06-24 09:19:05.543877
# Unit test for method join of class Queue
def test_Queue_join():
    # Test Queue.join() with a successful result.
    q = Queue(1)

    def putter(value):
        q.put_nowait(value)

    def closer():
        q.put_nowait(None)
        q.join()

    p = ioloop.IOLoop.current().run_sync(lambda: gen.Task(q.put, 1))
    num_tasks = 0

    def task():
        nonlocal num_tasks
        num_tasks += 1
        try:
            item = q.get_nowait()
            if item is None:
                q.task_done()
                return None
            return item
        finally:
            q.task_done()

    q.join()
    num_tasks = 0

    def task2():
        nonlocal num_t

# Generated at 2022-06-24 09:19:15.517441
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%x maxsize=0 queue=deque([])>" % id(q)
    q = Queue(2)
    assert str(q) == "<Queue maxsize=2 queue=deque([])>"
    q.put_nowait(0)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull:
        pass
    assert str(q) == "<Queue maxsize=2 queue=deque([0, 1])>"
    q.join()
    assert str(q) == "<Queue maxsize=2 queue=deque([])>"

# Generated at 2022-06-24 09:19:16.798188
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(1)
    q.put_nowait(1)
    print(q)



# Generated at 2022-06-24 09:19:20.821211
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-24 09:19:21.505382
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-24 09:19:24.661164
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    # The function __repr__ of class Queue can return a string as follows.
    assert str(Queue()).startswith("<Queue")



# Generated at 2022-06-24 09:19:34.832084
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_