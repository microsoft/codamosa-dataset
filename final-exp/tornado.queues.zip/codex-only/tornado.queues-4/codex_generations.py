

# Generated at 2022-06-24 09:09:30.411258
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=10)
    assert q._unfinished_tasks == 0
    q._queue = collections.deque([1, 2, 3, 4, 5])
    q.task_done()
    assert q._unfinished_tasks == 0



# Generated at 2022-06-24 09:09:32.098721
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q.maxsize == 0
    assert q.qsize() == 0
    assert q.empty() is True
    assert q.full() is False


# Generated at 2022-06-24 09:09:34.827328
# Unit test for method qsize of class Queue
def test_Queue_qsize():
  import random
  import asyncio
  q = Queue()
  q.put_nowait(1)


# Generated at 2022-06-24 09:09:46.048717
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.

# Generated at 2022-06-24 09:09:54.587824
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from Queue import Queue
    from random import randint
    for i in range(2000):
        qlength = randint(0, 100)
        q = Queue.Queue(maxsize=qlength)
        putQueue = ""
        getQueue = ""
        for j in range(qlength):
            q.put(randint(0, 100))
            putQueue = putQueue + str(q.qsize()) + " "
        while not q.empty():
            getQueue = getQueue + str(q.qsize()) + " "
            q.get()
        assert str(q) == "<Queue maxsize=%d queue=deque([]), getters[0], putters[0]>" % (qlength,)
    print("Queue class test1:", end="")
    print("Passed")

# Generated at 2022-06-24 09:09:58.356721
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(10)
    q.put_nowait(1)
    for x in _QueueIterator(q):
        assert x == 1



# Generated at 2022-06-24 09:10:00.729815
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    res = q.task_done()
    assert res == None


# Generated at 2022-06-24 09:10:04.865859
# Unit test for constructor of class Queue
def test_Queue():
    """
    >>> queue = Queue(maxsize=2)
    >>> queue
    <Queue at 0x10f8adc88 maxsize=2>
    >>> queue.maxsize
    2
    """

# Generated at 2022-06-24 09:10:12.478124
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(2)
    assert q.full() == False
    assert q.empty() == True
    
    q.put(1)
    assert q.full() == False
    assert q.empty() == False
    q.put(2)
    assert q.full() == True
    assert q.empty() == False
    
    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            q.task_done()
    
    async def producer():
        for item in range(5):
            print('Put %s' % item)
            await q.put(item)
    # consumer never finishes
    IOLoop.current().spawn_callback(consumer)
    IOLoop.current().run_sync(producer)
    
    assert q.full()

# Generated at 2022-06-24 09:10:22.297366
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    
    ret = q.put('item1')
    assert ret
    
    ret = q.put('item2')
    assert ret
    
    assert q.qsize() == 2
    
    try:
        q.put('item3')
    except QueueFull:
        ret = True
    assert ret
    assert q.qsize() == 2
    
    assert q.put_nowait('item3')
    assert q.qsize() == 2

# Generated at 2022-06-24 09:10:31.561918
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    # IOLoop.current().spawn_callback(consumer)
    # q.empty()
    if q.empty():
        print("Empty Queue")
    else:
        print("Queue not empty")

    # await producer()     # Wait for producer to put all tasks.
    for item in range(5):
        q.put_nowait(item)
    print('Producer put %s' % item)
    # await q.join()       # Wait for consumer to finish all tasks.
    q.join()
    print('Acquaintance')


# Generated at 2022-06-24 09:10:35.888850
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=10)
    assert q.maxsize == 10
    assert len(q._queue) == 0
    assert len(q._getters) == 0
    assert len(q._putters) == 0
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()
    return



# Generated at 2022-06-24 09:10:38.907702
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue[int]()
    q.put(1)
    q.put(2)
    it = _QueueIterator(q)
    assert it.q.get_nowait() == 1
    assert it.q.get_nowait() == 2


# Generated at 2022-06-24 09:10:41.356852
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert QueueEmpty().__class__ == QueueEmpty
    assert QueueEmpty("message").__class__ == QueueEmpty



# Generated at 2022-06-24 09:10:52.315411
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:10:52.815129
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert 0 == 1

# Generated at 2022-06-24 09:10:54.295073
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    queue = Queue(maxsize=2)
    assert queue.__str__() == "<Queue maxsize=2>"

# Generated at 2022-06-24 09:11:00.468905
# Unit test for method full of class Queue
def test_Queue_full():
    import random
    q = Queue(maxsize=2)

    # Put 1 item
    assert q.qsize() == 0
    q.put_nowait(1)
    assert not q.empty()
    assert not q.full()

    # Put 1 more item
    q.put_nowait(2)
    assert not q.empty()
    assert q.full()

    # Put 1 more item
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        raise AssertionError()
    assert not q.empty()
    assert q.full()

    # Get 1 item
    assert q.get_nowait() == 1
    assert not q.empty()
    assert not q.full()

    # Get 1 more item
    assert q.get_now

# Generated at 2022-06-24 09:11:03.519508
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        queue = Queue(maxsize = 2)
        queue.put_nowait(1)
        print("item can be put in")
        queue.put_nowait(2)
        print("item can be put in")
        queue.put_nowait(3)
        print("item can be put in")
    except QueueFull:
        print("Queue is full")


# Generated at 2022-06-24 09:11:14.689236
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import datetime
    import tornado
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNoThreads
    import tornado.concurrent
    from tornado.locks import Event
    from tornado.queues import Queue

    class QueueTestMixin(object):
        def setUp(self):
            super(QueueTestMixin, self).setUp()
            self.q = self.Queue()

        def test_put_get(self):
            it = self.q.put(1)
            self.assertIsInstance(it, tornado.concurrent.Future)
            self.assertEqual(it.result(), None)
            self.assertEqual(self.q.get_nowait(), 1)

        def test_async_for(self):
            self.q.put_

# Generated at 2022-06-24 09:11:16.712436
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    q._queue = [0, 1, 2]
    str(q)



# Generated at 2022-06-24 09:11:28.866657
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.platform.asyncio import to_asyncio_future
    from asyncio import Future as _Future
    from asyncio import gather, get_event_loop
    from typing import Any, Union, Awaitable
    from asyncio import Queue as _Queue

    _T = TypeVar("_T")
    maxsize: int = 0
    q: Queue[_T] = Queue(maxsize=maxsize)

    async def test1(q: Union[Queue[_T], Awaitable[_T]]) -> Any:
        assert isinstance(q, Queue)
        assert q.empty()
        assert not q.full()


# Generated at 2022-06-24 09:11:32.115190
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    it = _QueueIterator(q)
    x = it.__anext__()
    assert x
    def set_next():
        pass
    set_next(x.set_result(2))
print(test__QueueIterator___anext__())


# Generated at 2022-06-24 09:11:40.483178
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print(q)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:11:42.224174
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    i = _QueueIterator(q)
    del i
# /Unit test for constructor of class _QueueIterator



# Generated at 2022-06-24 09:11:48.690807
# Unit test for method empty of class Queue
def test_Queue_empty():

    import pytest
    from tornado.queues import Queue
    a = Queue(maxsize=2)
    for i in [0,1]:
        a.put_nowait(i)
    b = Queue(maxsize=2)
    assert b.empty() == True
    assert a.empty() == False


# Generated at 2022-06-24 09:11:57.199467
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    q = Queue(maxsize=2)
    IOLoop.current().run_sync(main)


# Generated at 2022-06-24 09:12:07.303296
# Unit test for method join of class Queue
def test_Queue_join():

    q = Queue()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.0)
            finally:
                q.task_done()


    async def producer():
        for item in range(2):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


    ioloop.IOLoop.current().run_sync(main)




# Generated at 2022-06-24 09:12:19.310104
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    i = 0
    async def consumer():
        nonlocal i
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to

# Generated at 2022-06-24 09:12:19.915790
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass



# Generated at 2022-06-24 09:12:24.319505
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:12:34.127906
# Unit test for method empty of class Queue
def test_Queue_empty():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks

# Generated at 2022-06-24 09:12:42.467026
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q._unfinished_tasks = 0
    try:
        q.task_done()
        assert False
    except ValueError as e:
        assert type(e) == ValueError
        assert str(e) == "task_done() called too many times"
    q._unfinished_tasks = 1
    q.task_done()
    assert q._unfinished_tasks == 0
test_Queue_task_done()



# Generated at 2022-06-24 09:12:51.187751
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import queue
    class Test(AsyncTestCase):
        @gen_test
        async def test___anext__(self):
            q=queue.Queue()
            q.put(1)
            q.put(2)
            self.assertEqual(q.qsize(), 2)
            t = _QueueIterator(q)
            async for v in t:
                self.assertEqual(v, 1)
                self.assertEqual(q.qsize(), 1)
                break
            self.assertEqual(q.qsize(), 1)
            async for v in t:
                self.assertEqual(v, 2)

# Generated at 2022-06-24 09:12:57.165155
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    assert repr(q) == "<Queue at 0x%s maxsize=0 queue=deque([])>" % hex(id(q))

    q = Queue(maxsize=1)
    q._queue.append(1)
    assert repr(q) == "<Queue at 0x%s maxsize=1 queue=deque([1])>" % hex(id(q))

    f = Future()
    q._putters.append((1, f))  # type: ignore
    assert repr(q) == "<Queue at 0x%s maxsize=1 queue=deque([1]) putters[1]>" % hex(id(q))

    g = Future()
    q._getters.append(g)

# Generated at 2022-06-24 09:13:02.822093
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(10)
    q._unfinished_tasks += 1
    q.task_done()
    assert q._unfinished_tasks == 0, "task_done() called too many times"
    q._unfinished_tasks = -1
    try:
        q.task_done()
    except Exception as e:
        assert type(e) in [ValueError], "task_done() called too many times"

# Generated at 2022-06-24 09:13:05.138302
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    with pytest.raises(QueueEmpty):
        q.get_nowait()


# Generated at 2022-06-24 09:13:07.531877
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("Queue is full.")
    except QueueFull as e:
        print("Queue is full, should not add any item.")


# Generated at 2022-06-24 09:13:12.969662
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    from tornado.util import PY3
    assert isinstance(QueueEmpty(), Exception)
    obj = QueueEmpty()
    assert str(obj)
    assert repr(obj)
    assert obj.args == tuple()
    obj = QueueEmpty('test')
    assert str(obj) == 'test'
    if PY3:
        assert repr(obj) == 'test'
    else:
        assert repr(obj) == 'test[test]'
    assert obj.args == ('test',)



# Generated at 2022-06-24 09:13:17.987544
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(5)
    except Exception as e:
        print("Warning: {}".format(e))
    try:
        q.put_nowait(6)
        q.put_nowait(7)
    except Exception as e:
        print("Warning: {}".format(e))


# Test for method put of class Queue

# Generated at 2022-06-24 09:13:25.860615
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    result = q.qsize()
    expected = 0
    assert result == expected
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(1)
    result = q.qsize()
    expected = 2
    assert result == expected


# Generated at 2022-06-24 09:13:29.792968
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(0)
    it = _QueueIterator(q)
    assert q.qsize() == 1
    assert q._getters == []



# Generated at 2022-06-24 09:13:34.816122
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:13:43.750139
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-24 09:13:52.912254
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import tornado

    @gen.coroutine
    def test_gen():
        q = Queue()
        assert issubclass(type(q.__aiter__()), _QueueIterator)

        yield q.put(1)
        yield q.put(2)
        yield q.put(3)
        yield q.put(4)

        r = []
        async for i in q:
            r.append(i)

        assert r == [1, 2, 3, 4]

    tornado.ioloop.IOLoop.current().run_sync(test_gen)




# Generated at 2022-06-24 09:13:56.019851
# Unit test for method empty of class Queue

# Generated at 2022-06-24 09:13:58.075723
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:14:10.293767
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    import unittest
    from . import util
    from . import queue_test
    from .queue_test import QueueTests

    class QueueStrTests(QueueTests, unittest.TestCase):

        def test_str(self):
            q = self._get_target_class()(maxsize = 1)
            self.assertEqual(str(q), "<Queue maxsize=1>")
            q.put_nowait(0)
            if (hasattr(q, "_queue")):
                self.assertEqual(str(q), "<Queue maxsize=1 queue=[0]>")
            q.task_done()
            q.join()
            self.assertEqual(str(q), "<Queue maxsize=1>")
            q = self._get_target_class()(maxsize = 1)


# Generated at 2022-06-24 09:14:14.413304
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(3)
    assert q.qsize() == 0
    assert not q.empty()
    assert not q.full()
    q = Queue(0)
    assert not q.full()
    q = Queue(None)


# Generated at 2022-06-24 09:14:23.651680
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    from asyncio import Future
    from types import coroutine
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    l = AsyncIOMainLoop()
    l.make_current()

    q = Queue()

    @coroutine
    def test():
        f = Future()
        f.set_result('Hello')
        q.put_nowait(f)
        c = _QueueIterator(q)
        a: str = yield from c.__anext__()
        return a

    g = test()
    assert g.send(None) == 'Hello'
    g.close()



# Generated at 2022-06-24 09:14:33.038582
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    '''Test defining a function that exposes the __anext__ method of _QueueIterator'''
    # _QueueIterator[T](q: Queue[T]) -> _QueueIterator[T]
    # __anext__(self: _QueueIterator[_T]) -> Awaitable[_T]
    #
    # - q: Queue[T]
    #
    #     The only argument we will supply is the __init__ value for the q attribute of _QueueIterator
    #
    # - q.get(): Awaitable[_T]
    #
    #     The only method we will call is the q.get() method
    #
    # - self.q: Queue[T]
    #     self is an instance of the class _QueueIterator[T]
    #
    #     We will provide self.q via the __init__ value of the

# Generated at 2022-06-24 09:14:37.017758
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3

# Generated at 2022-06-24 09:14:43.805751
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((10, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((20, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


if __name__ == "__main__":
    test_PriorityQueue()



# Generated at 2022-06-24 09:14:45.145516
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    assert q


# Generated at 2022-06-24 09:14:54.293942
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    assert q.maxsize == 1
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()

    q.put('a')
    assert q.qsize() == 1
    assert not q.empty()
    assert q.full()

    q.put('b')
    assert q.qsize() == 1
    assert not q.empty()
    assert q.full()

    q.put_nowait('c')
    assert q.qsize() == 1
    assert not q.empty()
    assert q.full()

    assert q.get_nowait() == 'b'
    assert q.qsize() == 0
    assert q.empty()
    assert not q.full()


# Generated at 2022-06-24 09:15:05.444141
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:15:06.779137
# Unit test for constructor of class QueueFull
def test_QueueFull():
    def fun():
        raise QueueFull
    fun()


# Generated at 2022-06-24 09:15:16.396707
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(7)
    q.put(8)
    it = _QueueIterator(q)
    yield gen.moment

    # Method next of class _QueueIterator
    # ------------------------------------------------------------------------
    #
    #                              start
    #                                  \
    #                                   v
    #
    #                     return self.q.get()                                 =>
    #
    #                                                                           v
    #
    #                                                                     q = Queue()
    #                                                                     return self.q
    #
    #    def __init__(self, q: "Queue[_T]") -> None:
    #        self.q = q
    #
    #
    #    def __anext__(self) -> Awaitable[_T]:
    #        return self.q.get

# Generated at 2022-06-24 09:15:27.424420
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    @gen.coroutine
    def test_get_all_data_from_queue(queue: "Queue[int]"):
        result = []
        async for item in queue:
            result.append(item)
            queue.task_done()
        return result
    # Test implementation
    q = Queue(10)
    for item in range(20):
        q.put_nowait(item)
    assert test_get_all_data_from_queue(q) == list(range(20))
    # Test calling method with an empty queue
    q = Queue(10)
    assert test_get_all_data_from_queue(q) == []
    # Test calling method with a queue containing only one item
    q = Queue(10)
    q.put_nowait(1)
    assert test_get_all

# Generated at 2022-06-24 09:15:31.677342
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:15:34.206703
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    print("Queue:", q)
    assert True


test_Queue___str__()



# Generated at 2022-06-24 09:15:38.401327
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    x = Queue()
    assert isinstance(x.__aiter__(), _QueueIterator)
    assert isinstance(x.__aiter__(), _QueueIterator)
    assert isinstance(x.__aiter__(), _QueueIterator)



# Generated at 2022-06-24 09:15:46.439473
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    item1 = q.get_nowait()
    print(item1)
    item2 = q.get_nowait()
    print(item2)
    item3 = q.get_nowait()
    print(item3)

test_PriorityQueue()



# Generated at 2022-06-24 09:15:51.261285
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:15:54.529346
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()
    q.task_done()



# Generated at 2022-06-24 09:16:05.625544
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from copy import copy
    from numbers import Number
    from unittest import mock
    from types import MethodType
    from queue import Queue, Empty, Full

    def _get_unfinished_tasks_mock(self):
        return getattr(self, "_unfinished_tasks", None)

    def _get_queue_mock(self):
        return getattr(self, "_queue", None)

    def _get_getters_mock(self):
        return getattr(self, "_getters", None)

    def _get_putters_mock(self):
        return getattr(self, "_putters", None)

    queues = [
        Queue(0),
        Queue(1),
        Queue(10),
    ]

# Generated at 2022-06-24 09:16:09.999719
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:16:13.010657
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()
    q.put(1)
    assert not q.empty()

# Generated at 2022-06-24 09:16:18.720583
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:16:20.602238
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull:
        pass


# Generated at 2022-06-24 09:16:25.954285
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:16:31.313549
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    print("Testing LifoQueue")
    test_LifoQueue()
    print("Test finished")

# Generated at 2022-06-24 09:16:41.814934
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
       

# Generated at 2022-06-24 09:16:46.124151
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:16:49.861448
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q = _QueueIterator(q)  # type: ignore



# Generated at 2022-06-24 09:16:50.946567
# Unit test for method empty of class Queue
def test_Queue_empty():
    pass


# Generated at 2022-06-24 09:16:57.062060
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:16:58.470589
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.task_done()

# Generated at 2022-06-24 09:17:00.232778
# Unit test for method empty of class Queue
def test_Queue_empty():
    queue = Queue()
    assert queue.empty() == True
# test for method full of class Queue

# Generated at 2022-06-24 09:17:01.715622
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True, "A new Queue should be empty"


# Generated at 2022-06-24 09:17:06.966383
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert(q.get_nowait() == (0, 'high-priority item'))
    assert(q.get_nowait() == (1, 'medium-priority item'))
    assert(q.get_nowait() == (10, 'low-priority item'))

test_PriorityQueue()



# Generated at 2022-06-24 09:17:10.195937
# Unit test for method full of class Queue
def test_Queue_full():
    
    q = Queue(maxsize=2)
    try:
        assert q.full() == False
    except:
        assert False == True # print("test_Queue_full failed")
    

# Generated at 2022-06-24 09:17:11.879289
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:17:12.905145
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull:
        pass



# Generated at 2022-06-24 09:17:14.728219
# Unit test for method put of class Queue
def test_Queue_put():
    with ioloop.IOLoop.current().run_sync(Queue()) as q:
        for i in range(10):
            q.put(i)


# Generated at 2022-06-24 09:17:16.391936
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert it.q == q

_SENTINEL = object()



# Generated at 2022-06-24 09:17:19.872947
# Unit test for method get of class Queue
def test_Queue_get():
    def f2() -> None:
        pass
    def f1() -> None:
        pass
    q = Queue()
    result = q.get()
    assert result

# Generated at 2022-06-24 09:17:31.066599
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:35.409131
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    for i, val in enumerate(_QueueIterator(q)):
        assert i == val - 1


# Generated at 2022-06-24 09:17:37.943908
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert "maxsize" in q.__str__()



# Generated at 2022-06-24 09:17:41.948361
# Unit test for method put of class Queue
def test_Queue_put():
    # Create an object of class Queue
    q = Queue(maxsize=2)
    # Get the reference of method put of class Queue
    put_method = q.put
    assert(put_method == q.put)


# Generated at 2022-06-24 09:17:43.901847
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty() == True

# Generated at 2022-06-24 09:17:56.519847
# Unit test for method join of class Queue
def test_Queue_join():
    import time
    import random
    import threading

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    start_time = time.time()

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(random.uniform(0, 0.1))
            # 当任务完成时，调用 task_done() 以通知队列
            # task_done() 要和 put() 一一对应的
            q.task_done()
            print(q.qsize())

# Generated at 2022-06-24 09:18:02.991198
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  q = Queue(0)
  q = Queue(3)
  q.put_nowait(1)
  q.put_nowait(2)
  q.put_nowait(3)
  try:
    q.put_nowait(1)
  except QueueFull:
    pass



# Generated at 2022-06-24 09:18:10.980391
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:18:11.931563
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    Queue()._format()

# Generated at 2022-06-24 09:18:13.264148
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    x = _QueueIterator(Queue(3))


# Generated at 2022-06-24 09:18:18.542380
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue[int]()
    qit = _QueueIterator(q)
    q.put(1)
    q.put(2)
    assert 1 == qit.__anext__()
    assert 2 == qit.__anext__()
    assert StopAsyncIteration == qit.__anext__()


# Generated at 2022-06-24 09:18:19.750743
# Unit test for method full of class Queue
def test_Queue_full():
    return True

# Generated at 2022-06-24 09:18:24.617564
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(1)
    q.put(2)
    q.put(3)
    for i in range(1,4):
        assert q.get_nowait() == i, f"LifoQueue: expected {i}, got {q.get_nowait()}"


# Generated at 2022-06-24 09:18:30.186419
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    assert q.__class__.__name__ == 'PriorityQueue'

    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')



# Generated at 2022-06-24 09:18:34.404865
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.empty() == True
    q.put(1)
    q.put(2)
    assert q.empty() == False
    assert q.qsize() == 2
    assert q.full() == True
    assert q.maxsize == 2



# Generated at 2022-06-24 09:18:37.497445
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except QueueFull as e:
        e.__class__ == QueueFull
        return True
    return False

# Capacity of default queue
_DEFAULT_MAXSIZE = 2 ** 31 - 1



# Generated at 2022-06-24 09:18:46.582778
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()

    # We don't actually want to run a coroutine for this test,
    # we're only testing the instantiation and methods of QueueIterator
    class MockFuture:
        def done(self):
            return True
    q._getters.append(MockFuture())

    async def async_get() -> None:
        pass

    q._getters[0].set_result(async_get)
    i = q.__aiter__()
    assert i.__anext__() == async_get()

# Generated at 2022-06-24 09:18:51.879152
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:19:01.014759
# Unit test for method put of class Queue
def test_Queue_put():
    from .ioloop_test_util import skip_if_nonasyncio_event_loop
    skip_if_nonasyncio_event_loop()
    from tornado.testing import AsyncTestCase
    from tornado.ioloop import IOLoop
    from tornado.queues import QueueFull

    class TestQueue(AsyncTestCase):
        def test_queue(self):

            q = Queue(maxsize=2)

            async def consumer():
                async for item in q:
                    try:
                        print("Doing work on {}".format(item))
                        await gen.sleep(0.01)
                    finally:
                        q.task_done()

            async def producer():
                for item in range(5):
                    await q.put(item)
                    print("Put {}".format(item))


# Generated at 2022-06-24 09:19:02.711599
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())


# Generated at 2022-06-24 09:19:05.234606
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    from tornado.queues import PriorityQueue
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:19:10.079488
# Unit test for method empty of class Queue
def test_Queue_empty():
	q = Queue()
	assert q.empty()
	q.put(1)
	assert not q.empty()
	assert q.get_nowait() == 1
	assert q.empty()


# Generated at 2022-06-24 09:19:11.148627
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty('test')



# Generated at 2022-06-24 09:19:14.475455
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue()
    assert(q.full() == False)
    q = Queue(maxsize=2)
    assert(q.full() == False)
    q = Queue(maxsize=0)
    assert(q.full() == False)


# Generated at 2022-06-24 09:19:19.335913
# Unit test for method put of class Queue
def test_Queue_put():
    _T = TypeVar("_T")
    item = 1
    future = Future()
    timeout = None
    Queue._putters = Deque[Tuple[_T, Future[None]]]
    q = Queue
    q.put(item,timeout)

# Generated at 2022-06-24 09:19:21.754581
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-24 09:19:24.805323
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    # Test result of qsize before entering any items
    assert q.qsize() == 0
    # Test result of qsize before entering 2 items
    q.put(1)
    assert q.qsize() == 1
    q.put(2)
    assert q.qsize() == 2
    # Test result of qsize when queue is full
    try:
        q.put(3)
    except QueueFull:
        assert q.qsize() == 2

# Generated at 2022-06-24 09:19:35.031180
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    from tornado import gen, ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    print(q)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print