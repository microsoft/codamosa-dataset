

# Generated at 2022-06-24 09:09:33.723070
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q=Queue()
    a=Future()
    a.set_result(1)
    q._unfinished_tasks+=1
    q._finished.clear()
    q._getters.append(a)
    q.task_done()
    assert q._unfinished_tasks==0
    assert q._finished.is_set()
    assert len(q._getters)==0

# Generated at 2022-06-24 09:09:39.340771
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    import tornado
    import asyncio
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine
    def assert_true(a):
        assert a is True
    def assert_equals(a,b):
        assert a == b
    @coroutine
    def get_async(x):
        return x.get()
    @gen_test(timeout=10.0)
    def test___anext__(self):
        def assert_true(a):
          assert a is True
        def assert_equals(a,b):
          assert a == b
        @coroutine
        def get_async(x):
            return x.get()
        q = Queue()
        assert_equals(q.qsize(), 0)

# Generated at 2022-06-24 09:09:45.198761
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import pytest
    from tornado.queues import Queue
    q = Queue()
    with pytest.raises(ValueError):
        q.task_done()
    q.put_nowait(1)
    q.task_done()
    with pytest.raises(ValueError):
        q.task_done()


# Generated at 2022-06-24 09:09:53.590303
# Unit test for method qsize of class Queue
def test_Queue_qsize():
  q = Queue(maxsize=5)
  assert q.qsize() == 0
  q.put("test")
  assert q.qsize() == 1
  q.put("test2")
  assert q.qsize() == 2
  q.task_done()
  assert q.qsize() == 1
  q.task_done()
  assert q.qsize() == 0
  q.put("test3")
  assert q.qsize() == 1
  q.put("test4")
  assert q.qsize() == 2
  print("test_Queue_qsize passed")


# Generated at 2022-06-24 09:10:01.053571
# Unit test for method empty of class Queue
def test_Queue_empty():
    import unittest
    import tornado
    import tornado.ioloop
    import tornado.queues

    class QueueTestCase(unittest.TestCase):

        def test_empty(self):
            q = tornado.queues.Queue()
            self.assertTrue(q.empty())
            q.put(object())
            self.assertFalse(q.empty())

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 09:10:06.957780
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q= Queue(100)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize()==3
    assert q.get_nowait()==1
    assert q.get_nowait()==2
    assert q.get_nowait()==3


# Generated at 2022-06-24 09:10:12.441350
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    getter = Future()
    putter = Future()
    q._getters.append(getter)
    q._putters.append((1, putter))
    _set_timeout(getter, 10)
    _set_timeout(putter, 10)
    
    q.get_nowait()

# Generated at 2022-06-24 09:10:17.164397
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue()
    q.put_nowait(0)
    it = q.__aiter__()
    assert isinstance(it, _QueueIterator)
    assert q.__aiter__() is not it
    assert it.q is q
    assert it.__anext__().result() == 0
    assert q._getters == collections.deque([])
    try:
        it.__anext__().result()
    except QueueEmpty:
        pass
    assert q._getters == collections.deque([])



# Generated at 2022-06-24 09:10:19.482609
# Unit test for method empty of class Queue
def test_Queue_empty():
    q=Queue(3)
    res = q.empty()
    return res

# Generated at 2022-06-24 09:10:22.668921
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e:
        assert isinstance(e, Exception)
        assert str(e) == "queue full"



# Generated at 2022-06-24 09:10:26.795289
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull("test_QueueFull")
    except QueueFull as e:
        assert str(e) == "test_QueueFull"



# Generated at 2022-06-24 09:10:32.558837
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == '__main__':
    test_LifoQueue()
    print()

# Generated at 2022-06-24 09:10:33.958877
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    x = QueueEmpty()


# Generated at 2022-06-24 09:10:38.795722
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    # QueueFull, the queue is full now.
    try:
        q.put_nowait(3)
    except QueueFull:
        print("The queue is full now.")
    else:
        print("The queue is not full now.")

# test_Queue_put_nowait()



# Generated at 2022-06-24 09:10:40.250340
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull('test')
    except Exception:
        pass


# Generated at 2022-06-24 09:10:48.355753
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    print("test__QueueIterator___anext__ started")
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    # q.put_nowait(3)
    it = _QueueIterator(q)
    print(it.__anext__())
    print(it.__anext__())
    print(it.__anext__())
    print("test__QueueIterator___anext__ ended")


# Generated at 2022-06-24 09:10:52.140377
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue(maxsize=1)
    q.put(1)
    q0 = _QueueIterator(q)
    assert (await q0.__anext__()) == 1

T = typing.TypeVar("T")
V = typing.TypeVar("V")


# Generated at 2022-06-24 09:10:55.651799
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    import sys, datetime
    class MockIOLoop():
        def add_callback(self, f, fn_args=None, fn_kwargs=None):
            f()
    ioloop.IOLoop.configure(MockIOLoop)
    q = Queue()
    q.put_nowait(42)
    async for item in q:
        assert item == 42


# Generated at 2022-06-24 09:10:58.100853
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    a = Queue(maxsize=0)
    assert a.__repr__() == '<Queue at 0x7f2afb7f73c8 maxsize=0 queue=deque([])>'
    assert a.__repr__() == a.__str__()



# Generated at 2022-06-24 09:11:10.230124
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # if self._getters:
    #     assert self.empty(), "queue non-empty, why are getters waiting?"
    #     getter = self._getters.popleft()
    #     self.__put_internal(item)
    #     future_set_result_unless_cancelled(getter, self._get())
    # elif self.full():
    #     raise QueueFull
    # else:
    #     self.__put_internal(item)
    a = Queue(10)
    b = Queue(10)
    for i in range(10):
        try:
            a.put_nowait(i)
            b.put_nowait(i)
        except QueueFull:
            pass
    c = Queue(10)
    d = Queue(10)
   

# Generated at 2022-06-24 09:11:22.742715
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.queue import Queue
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-24 09:11:24.069486
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0



# Generated at 2022-06-24 09:11:26.471004
# Unit test for method empty of class Queue
def test_Queue_empty():
    x = Queue()
    x.empty()

# Generated at 2022-06-24 09:11:30.138188
# Unit test for method empty of class Queue
def test_Queue_empty():
    orig_empty = Queue.empty

    def empty_test(self):
        print("test hook called on Queue to test empty()")
        return orig_empty(self)

    Queue.empty = empty_test
    q = Queue(2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.get_nowait()
    q.get_nowait()
    empty = q.empty()
    print(empty)
    assert empty == True
    print(q._queue)
    print()

if __name__ == "__main__":
    test_Queue_empty()


# Generated at 2022-06-24 09:11:31.280353
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    assert q.empty()
    q.put(1)
    assert not q.empty()


# Generated at 2022-06-24 09:11:34.781159
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:11:38.359471
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(123)
    q.put_nowait(456)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
test_Queue_put_nowait()


# Generated at 2022-06-24 09:11:49.371432
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    async def main():
        q = Queue(maxsize=3)
        assert q.qsize() == 0
        await q.put(1)
        assert q.qsize() == 1
        await q.put(2)
        assert q.qsize() == 2
        await q.put(3)
        assert q.qsize() == 3
        await q.get()
        assert q.qsize() == 2
        await q.get()
        assert q.qsize() == 1
        await q.get()
        assert q.qsize() == 0
        await q.put(4)
        assert q.qsize() == 1
    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:11:50.641795
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert it.q is q



# Generated at 2022-06-24 09:11:52.285527
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    

if __name__ == '__main__':
    test_PriorityQueue()

# Generated at 2022-06-24 09:11:57.038294
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(0)
    q.qsize()
    assert q.qsize == 0
    q = Queue(2)
    q.put_nowait(1)
    assert q.qsize == 1
    q.put_nowait(2)
    assert q.qsize == 2
    q.get_nowait()
    assert q.qsize == 1
    q.get_nowait()
    assert q.qsize == 0


# Generated at 2022-06-24 09:12:07.323897
# Unit test for method put of class Queue
def test_Queue_put():
    # parameters
    maxsize = 0
    # queue under test
    q = Queue(maxsize)

    # test 1 : test the put method without timeout and without block
    # put the value "item 1" in the queue
    item = "item 1"
    future = Future()  # type: Future[None]
    try:
        q.put_nowait(item)
    except QueueFull:
        q._putters.append((item, future))
        _set_timeout(future, None)
    else:
        future.set_result(None)
    # assert test 1
    # assert that the queue is not empty
    assert q.empty() == False
    # assert that the number of items in the queue is 1
    assert q.qsize() == 1

    # test 2 : test the put method with timeout and block


# Generated at 2022-06-24 09:12:16.324550
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    import typing
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')


# Generated at 2022-06-24 09:12:20.352977
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    import pytest
    queue = LifoQueue()
    assert queue.empty() == True
    queue.put(1)
    assert queue.full() == False
    assert queue.get_nowait() == 1
    assert queue.empty() == True
    with pytest.raises(Exception):
        queue.get_nowait()

# Generated at 2022-06-24 09:12:21.817791
# Unit test for method put of class Queue
def test_Queue_put():
    pass


# Generated at 2022-06-24 09:12:32.181102
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import concurrent
    from tornado import ioloop
    from tornado import queues
    import typing

    # Test simple case (all items enqueued before join)
    item_count = 100
    queue = queues.Queue()
    loop = ioloop.IOLoop()

    @gen.coroutine
    def producer(queue):
        for i in range(item_count):
            yield queue.put(i)

    @gen.coroutine
    def consumer(queue):
        while True:
            item = yield queue.get()
            queue.task_done()
            if item is None:
                break

    @gen.coroutine
    def main():
        consumers = [consumer(queue) for i in range(10)]
        yield producer(queue)
        yield queue.join()
        for item in range(10):
            yield

# Generated at 2022-06-24 09:12:44.385785
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import asyncio
    async def test():
        q=Queue()
        await q.put(1)
        await q.put(2)
        await q.put(3)
        assert q.get_nowait() == 1, "check for get_nowait of Queue"
        await q.put(4)
        await q.put(5)
        await q.put(6)
        assert q.get_nowait() == 2, "check for get_nowait of Queue"
        assert q.get_nowait() == 3, "check for get_nowait of Queue"
        q.task_done()
        assert q.get_nowait() == 4, "check for get_nowait of Queue"
        q.task_done()
        q.task_done()
        

# Generated at 2022-06-24 09:12:47.346608
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()

    for i in range(10):
        q.put(i)

    for i in range(10):
        q.task_done()

    assert q.qsize() == 0 and q._unfinished_tasks == 0


# Generated at 2022-06-24 09:12:50.027737
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    q = Queue(maxsize=0)
    q_iterator = q.__aiter__()
    assert isinstance(q_iterator, _QueueIterator)
    assert q_iterator.q is q


# Generated at 2022-06-24 09:12:52.751947
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q: 'Queue[int]' = Queue()

    s3: Awaitable[int] = _QueueIterator(q).__anext__()
    s4: int = yield s3

    assert(s4 == 0)



# Generated at 2022-06-24 09:12:54.733697
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.qsize() == 3

# Generated at 2022-06-24 09:13:05.885927
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    print('>>> test_Queue___aiter__')
    q = Queue(maxsize=2)
    q.put_nowait(2)
    q.put_nowait(1)
    #print(q.__aiter__)
    #print(q.__aiter__())
    q_iter = q.__aiter__()
    print('type(q_iter)=', type(q_iter))
    print('dir(q_iter)=', dir(q_iter))
    print('dir(q_iter.__anext__)=', dir(q_iter.__anext__))
    print('q_iter.__anext__()=', q_iter.__anext__())
    #print('next(q_iter)=', next(q_iter))
    #print('next(q_iter)=', next

# Generated at 2022-06-24 09:13:13.636616
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:13:16.020326
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(4)
    except QueueFull:
        return True
    return False


# Generated at 2022-06-24 09:13:23.580897
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())



# Generated at 2022-06-24 09:13:24.940571
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    pass # just for typing


# Generated at 2022-06-24 09:13:29.411918
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2);


# Generated at 2022-06-24 09:13:34.092022
# Unit test for method get of class Queue
def test_Queue_get():
    Q = Queue()
    Q.put_nowait('First')
    print(Q.get_nowait()) # 'First'
    # print(Q.get_nowait()) # raises QueueEmpty
    print(Q.get()) # 'First'
    # print(Q.get()) # raises QueueEmpty


# Generated at 2022-06-24 09:13:35.561781
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    print(Queue(maxsize=2))

# Generated at 2022-06-24 09:13:39.252452
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert(q.empty() == True)
    q.put_nowait(1)
    assert(q.empty() == False)
    q.get_nowait()
    assert(q.empty() == True)


# Generated at 2022-06-24 09:13:46.408012
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():

    # Create an empty queue.
    q = Queue(maxsize=2)
    assert list(q) == []
    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)
    # Wait for producer to put all tasks.
    # Wait for consumer to finish all tasks.
    print('Done')
    return


async def consumer():
    async for item in q:
        try:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
        finally:
            q.task_done()
    return


async def producer():
    for item in range(5):
        await q.put(item)
        print('Put %s' % item)
    return


# Generated at 2022-06-24 09:13:57.088761
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    # type: () -> None
    q = Queue(maxsize=2)

    def put(q: Queue[int], data: int, done_fut: Future[None]) -> None:
        ioloop.IOLoop.current().add_callback(q.put, data)
        if data == 4:
            ioloop.IOLoop.current().add_callback(done_fut.set_result, None)

    done_fut = Future()
    for i in range(5):
        ioloop.IOLoop.current().add_callback(put, q, i, done_fut)

    async def consumer():
        async for item in q:
            try:
                print("Doing work on {}".format(item))
                await gen.sleep(1)
            finally:
                q.task_

# Generated at 2022-06-24 09:14:00.917655
# Unit test for method join of class Queue
def test_Queue_join():
    import types
    q = Queue()
    assert type(q.join) == types.MethodType
    assert type(q.join()) == types.CoroutineType


# Generated at 2022-06-24 09:14:12.679106
# Unit test for method join of class Queue
def test_Queue_join():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer(size):
        for item in range(size):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer(20)     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
       

# Generated at 2022-06-24 09:14:21.932318
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import doctest
    import tornado.queues
    import copy

    class TestQueue(unittest.TestCase):
        def setUp(self):
            self.q = tornado.queues.Queue()
            self.q2 = tornado.queues.Queue()
        def tearDown(self):
            pass
        def test_put(self):
            self.q.put_nowait(1)
            self.q.put_nowait(2)
            self.q.put_nowait(3)
            self.assertEqual(self.q._queue[0], 1)
            self.assertEqual(self.q._queue[1], 2)
            self.assertEqual(self.q._queue[2], 3)

        def test_put_exception(self):
            self.q

# Generated at 2022-06-24 09:14:23.544446
# Unit test for method empty of class Queue
def test_Queue_empty():
    pass



# Generated at 2022-06-24 09:14:24.830314
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue()
    print(q.empty())


# Generated at 2022-06-24 09:14:28.362721
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    item1 = q.get_nowait()
    item2 = q.get_nowait()
    item3 = q.get_nowait()
    return item1, item2, item3

# Generated at 2022-06-24 09:14:32.485299
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert '<Queue at' in str(q)
    q.put_nowait("a")
    q.put_nowait("b")
    q.put_nowait("c")
    assert 'a, b, c' in str(q)


# Generated at 2022-06-24 09:14:34.585393
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    print("start test_LifoQueue")
    queue = LifoQueue(1)
    queue.put(1)
    a = queue.get_nowait()
    print("test result:"+str(a))
    print("test_LifoQueue done")

test_LifoQueue()

# Generated at 2022-06-24 09:14:38.830155
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    q.put_nowait(3)
    iterator = _QueueIterator(q)
    q.get_nowait()
    assert(await iterator.__anext__() == 3)

T = TypeVar("T")



# Generated at 2022-06-24 09:14:41.631299
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    e = QueueEmpty()
    try:
        raise e
    except Exception as x:
        assert x is e



# Generated at 2022-06-24 09:14:50.749485
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    io_loop = ioloop.IOLoop.current()

    async def consumer():
        await q.join()
        print("Done")

    async def producer():
        for i in range(5):
            await q.put(i)
            print(q)

    p = producer()
    c = consumer()
    try:
        io_loop.run_sync(p)
        try:
            io_loop.run_sync(c)
        except Exception as e:
            print("Failed to run c")
            print(e)
    except Exception as e:
        print("Failed to run p")
        print(e)


if __name__ == '__main__':
    test_Queue_join()
    # TODO
    # test_Queue_apply

# Generated at 2022-06-24 09:14:52.280845
# Unit test for method empty of class Queue
def test_Queue_empty():
    q = Queue(maxsize=2)
    assert q.empty()
test_Queue_empty()

# Generated at 2022-06-24 09:14:55.212684
# Unit test for method qsize of class Queue
def test_Queue_qsize():
	q = Queue()
	assert q.qsize()==0, "incorrect qsize"
	print("test_Queue_qsize is passed.")
test_Queue_qsize()


# Generated at 2022-06-24 09:14:56.119038
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    # type: () -> None
    pass


# Generated at 2022-06-24 09:15:03.928257
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=1)
    assert not q.full() and not q.empty(), "queue should not be full or empty"
    q.put_nowait(1)
    assert q.full() and not q.empty(), "queue should be full and not empty"
    q.get_nowait()
    assert not q.full() and q.empty(), "queue should not be full and should be empty"

if __name__ == "__main__":
    test_Queue_full()


# Generated at 2022-06-24 09:15:09.465922
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    import random
    import unittest

    def randint(r):
        return random.randint(1, r)

    q = Queue()
    assert q.qsize() == 0
    q.put(1)
    assert q.qsize() == 1
    q.put(2)
    assert q.qsize() == 2
    assert q.qsize() == 2
    q.put(3)
    assert q.qsize() == 3
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.qsize() == 1

    q.put(5)
    assert q.get_nowait() == 3
    assert q.qsize() == 1
    assert q.get_nowait() == 5
    assert q.qsize() == 0

# Generated at 2022-06-24 09:15:10.835193
# Unit test for constructor of class QueueFull
def test_QueueFull():
    with pytest.raises(QueueFull):
        raise QueueFull



# Generated at 2022-06-24 09:15:12.206119
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    print(q.get())


# Generated at 2022-06-24 09:15:23.671154
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    import unittest
    import unittest.mock
    def run_sync(coroutine):
        return tornado.ioloop.IOLoop.current().run_sync(coroutine)
    class QueueTaskDoneTestCase(unittest.TestCase):
        def setUp(self):
            self.queue = tornado.queues.Queue(maxsize=2)
        def test_task_done(self):
            self.assertFalse(run_sync(self.queue.join()))
            self.assertEqual(0, self.queue._unfinished_tasks)
            self.assertEqual(0, run_sync(self.queue.qsize()))

# Generated at 2022-06-24 09:15:28.729813
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)

    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:15:31.043522
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = ioloop.Queue()
    iterator = _QueueIterator(q)



# Generated at 2022-06-24 09:15:41.874824
# Unit test for method join of class Queue
def test_Queue_join():
    import tornado.gen
    import tornado.ioloop
    import tornado.queues
    q = tornado.queues.Queue(maxsize=2)
    async def consumer():
        while True:
            item = await q.get()
            try:
                print("Doing work on %s" % item)
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    @tornado.gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)


    @tornado.gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for

# Generated at 2022-06-24 09:15:44.252586
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    with pytest.raises(TypeError):
        Queue.__aiter__({})

# Generated at 2022-06-24 09:15:52.117574
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    """ Test __aiter__(self) of class Queue """

    # Test with a empty queue
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() is True
    iterator = q.__aiter__()
    with pytest.raises(QueueEmpty):
        it = iterator.__anext__()

    # Test with a queue with several element and no putter nor getter
    q = Queue(4)
    assert q.qsize() == 0
    assert q.empty() is True
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    assert q.qsize() == 4
    assert q.full() is True
    iterator = q.__a

# Generated at 2022-06-24 09:16:04.618863
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
	from random import seed, randint
	from tornado import gen
	from tornado.ioloop import IOLoop
	from tornado.queues import Queue
	seed(1)
	q = Queue(maxsize=2)
	async def consumer():
		async for item in q:
			try:
				print('Doing work on %s' % item)
				await gen.sleep(0.01)
				print(q)
			finally:
				q.task_done()
	async def producer():
		for item in range(5):
			await q.put(item)
			print('Put %s' % item)
			print(q)

# Generated at 2022-06-24 09:16:07.120229
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    #print("Queue")
    q = Queue()
    q.put(1)
    #print(q.qsize())
    assert q.qsize() == 1


# Generated at 2022-06-24 09:16:19.187787
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import unittest

    import gen
    import ioloop
    import testing

    test_timeout = 2

    def test_get_done_callback(future):
        future.set_result(1)

    def test_put(q):
        # Queue.put is an asynchronous method, which will return a future object,
        # so it needs to wait until the future object is ready
        return q.put(1).add_done_callback(test_get_done_callback)

    def test_put_timeout(q):
        q.maxsize = 1
        f = q.put(1, timeout=0.01)
        ioloop.IOLoop.current().add_future(f, lambda result: q.put(2, timeout=0.01))
        return f


# Generated at 2022-06-24 09:16:20.694431
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue()
    assert "Queue" in str(q)



# Generated at 2022-06-24 09:16:26.267321
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-24 09:16:27.906096
# Unit test for constructor of class Queue
def test_Queue():
    tq = Queue()
    print(tq)


# Generated at 2022-06-24 09:16:31.142926
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    try:
        q = Queue()
        q.task_done()
    except ValueError as e:
        assert 'called too many times' in str(e)

q = Queue()
q.task_done()


# Generated at 2022-06-24 09:16:35.459242
# Unit test for method __anext__ of class _QueueIterator
def test__QueueIterator___anext__():
    q = Queue()
    q.put(1)
    q.put(None)
    it = _QueueIterator(q)
    assert await it.__anext__() == 1
    assert await it.__anext__() is None
    assert await it.__anext__()



# Generated at 2022-06-24 09:16:39.828281
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    #Default Queue init
    qsize = 0
    q1 = Queue()
    assert q1.qsize() == qsize, 'Queue qsize wrote wrong'

    #Queue init with unbound
    q1 = Queue(maxsize=0)
    assert qsize <= q1.qsize(), 'Queue qsize wrote wrong'





# Generated at 2022-06-24 09:16:45.110864
# Unit test for constructor of class _QueueIterator
def test__QueueIterator(): 
    from tornado.ioloop import IOLoop 
    from tornado.queues import Queue 
    from tornado import gen 

    @gen.coroutine
    def main():
        q = Queue()
        q.put(7)
        q.put(8)
        it = iter(q)
        print(next(it))  # 7
        print(next(it))  # 8
        print(next(it))  # Blockeder

    io_loop = IOLoop.current()

    io_loop.run_sync(main)



# Generated at 2022-06-24 09:16:47.944370
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    s = Queue().__str__()
    print(s)
Queue.__str__ = test_Queue___str__


# Generated at 2022-06-24 09:16:56.582392
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """
    _queue = deque()
    _getters = deque([])
    _putters = deque([])
    _unfinished_tasks = 0
    _finished = Event()
    """
    def Queue__get():
        return self._queue.popleft()
    def Queue__put_internal(item):
        self._unfinished_tasks += 1
        self._finished.clear()
        self._put(item)

    Queue__put_internal(1)
    
    
    
    


# See also PriorityQueue, which is defined below.



# Generated at 2022-06-24 09:16:57.782142
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    assert issubclass(QueueEmpty, Exception)


# Generated at 2022-06-24 09:16:59.471053
# Unit test for constructor of class _QueueIterator
def test__QueueIterator():
    q = Queue()
    it = _QueueIterator(q)
    assert it.q == q


# Generated at 2022-06-24 09:17:02.007189
# Unit test for method get of class Queue
def test_Queue_get():
    maxsize = 0
    timeout: Optional[Union[float, datetime.timedelta]] = None
    q = Queue(maxsize=0)
    f: Future[_T] = q.get(timeout = timeout)


# Generated at 2022-06-24 09:17:04.385348
# Unit test for method put of class Queue
def test_Queue_put():
    Queue()


# Generated at 2022-06-24 09:17:11.910391
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test empty queue
    q = Queue(maxsize=1)
    with pytest.raises(QueueEmpty):
        q.get_nowait()

    # Test queue with item
    q = Queue(maxsize=1)
    q._put(1)
    assert q._queue[0] == 1
    assert q.get_nowait() == 1


if __name__ == "__main__":
    test_Queue_get_nowait()

# Generated at 2022-06-24 09:17:13.214486
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    try:
        raise QueueEmpty
    except QueueEmpty as e:
        pass


# Generated at 2022-06-24 09:17:20.763385
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    q = Queue()
    try:
         assert str(q) == "<Queue at 0x%x maxsize=0 tasks=0>" % id(q)
         q.put("item1")
         assert str(q) == "<Queue at 0x%x maxsize=0 queue=[\'item1\'] tasks=1>" % id(q)
    except:
        print("Error: method __repr__(self) of class Queue not working correctly")
test_Queue___repr__()



# Generated at 2022-06-24 09:17:31.714015
# Unit test for method __aiter__ of class Queue
def test_Queue___aiter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-24 09:17:34.127624
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull()
    except QueueFull as e: pass



# Generated at 2022-06-24 09:17:43.532201
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    print(PriorityQueue.__doc__)
    # Step 1: Initialize the queue
    q = PriorityQueue()
    # Step 2: Put the items with their priorities
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))
    # Step 3: Print the items
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_PriorityQueue()



# Generated at 2022-06-24 09:17:49.488666
# Unit test for constructor of class LifoQueue
def test_LifoQueue():
    q = LifoQueue()
    q.put(3)
    q.put(2)
    q.put(1)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())

if __name__ == "__main__":
    test_LifoQueue()

# Generated at 2022-06-24 09:17:53.489767
# Unit test for method full of class Queue
def test_Queue_full():
    q = Queue(maxsize=2)
    assert not q.full()

    q.put_nowait(1)
    q.put_nowait(2)
    assert q.full()


# Generated at 2022-06-24 09:17:55.905951
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    try: 
        q.task_done()
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 09:17:59.180894
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue(maxsize=2)
    print(q)


# Generated at 2022-06-24 09:18:04.060364
# Unit test for method join of class Queue
def test_Queue_join():
    import asyncio
    async def main():
        q = Queue()
        await q.put(1)
    try:
        asyncio.run(main())
        assert False
    except:
        assert True

test_Queue_join()

# Generated at 2022-06-24 09:18:05.968980
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    # Just run the method
    q = Queue()
    q.__str__()


# Generated at 2022-06-24 09:18:12.214522
# Unit test for method qsize of class Queue
def test_Queue_qsize():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.get_nowait()
    q.get_nowait()
    assert q.qsize() == 0

# Generated at 2022-06-24 09:18:15.172656
# Unit test for constructor of class QueueFull
def test_QueueFull():
    try:
        raise QueueFull
    except Exception as e:
        print(e)
    finally:
        pass



# Generated at 2022-06-24 09:18:23.466242
# Unit test for method full of class Queue
def test_Queue_full():
    import asyncio
    async def f():
        q = Queue()
        assert q.full() == False
        q.put(1)
        assert q.full() == False
        q.put(2)
        assert q.full() == False
        q.put(3)
        assert q.full() == False
        q.put(4)
        assert q.full() == False
        q.put(5)
        assert q.full() == False
    loop = asyncio.get_event_loop()
    loop.run_until_complete(f())


# Generated at 2022-06-24 09:18:33.354030
# Unit test for method join of class Queue
def test_Queue_join():
    q = Queue(maxsize=2)
    # producer task
    async def producer():
        for i in range(10):
            await q.put(i)
            print("put : ", i)
    # consumer task
    async def consumer():
        while True:
            item = await q.get()
            try:
                print("get : ", item)
                await gen.sleep(1)
            finally:
                q.task_done()

    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)
    # Wait for producer to put all tasks.
    ioloop.IOLoop.current().spawn_callback(producer)
    # Wait for consumer to finish all tasks.
    q.join()
    print("Done!")



# Generated at 2022-06-24 09:18:38.646048
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.get_nowait()
    q.task_done()
    q.get_nowait()
    q.task_done()
    q.get_nowait()
    q.task_done()
    assert q.empty()
    assert not q.full()
    assert q.qsize() == 0


# Generated at 2022-06-24 09:18:39.742498
# Unit test for constructor of class QueueEmpty
def test_QueueEmpty():
    QueueEmpty()



# Generated at 2022-06-24 09:18:42.428244
# Unit test for constructor of class QueueFull
def test_QueueFull():
    q = Queue()
    try:
        q.put_nowait("some data")
    except QueueFull as e:
        pass



# Generated at 2022-06-24 09:18:50.517611
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    q = Queue(maxsize=2)
    assert str(q) == "<Queue maxsize=2 queue=deque([])>"
    q.put_nowait(1)
    assert str(q) == "<Queue maxsize=2 queue=deque([1])>"
    q.put_nowait(2)
    assert str(q) == "<Queue maxsize=2 queue=deque([1, 2])>"
    q.get_nowait()
    assert str(q) == "<Queue maxsize=2 queue=deque([2])>"



# Generated at 2022-06-24 09:18:59.510804
# Unit test for method __repr__ of class Queue
def test_Queue___repr__():
    queue_with_task = Queue(maxsize=10)
    queue_with_task.put_nowait(1)
    x = repr(queue_with_task)
    assert x == "<Queue at 0x7f1b7a812b00 maxsize=10 queue=[1] tasks=1>"

    queue_without_task = Queue(maxsize=10)
    x = repr(queue_without_task)
    assert x == "<Queue at 0x7f1b7a812b00 maxsize=10>"
test_Queue___repr__()


# Generated at 2022-06-24 09:19:00.961890
# Unit test for method __str__ of class Queue
def test_Queue___str__():
    print(Queue(maxsize=2))
test_Queue___str__()


# Generated at 2022-06-24 09:19:12.483487
# Unit test for method put of class Queue
def test_Queue_put():
    # Queue object created
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()  # Wait for producer to put all tasks.
        yield q.join()  # Wait for consumer to finish all tasks.

# Generated at 2022-06-24 09:19:14.790184
# Unit test for constructor of class Queue
def test_Queue():
    #q = Queue()
    q = Queue(maxsize=10)
    print("The maxsize of q is: %s " % q.maxsize)



# Generated at 2022-06-24 09:19:18.112726
# Unit test for constructor of class Queue
def test_Queue():
    q = Queue()
    q.put(10)
    assert(q.qsize() == 1)


# Generated at 2022-06-24 09:19:25.277317
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado.gen import coroutine
    from tornado.queues import Queue
    import asyncio
    q = Queue()
    q.put(0)
    q.put(1)
    @coroutine
    def func():
        while True:
            item = yield q.get()
            if q.empty():
                break
            q.task_done()
            print(item)
    asyncio.get_event_loop().run_until_complete(func())



# Generated at 2022-06-24 09:19:26.498287
# Unit test for constructor of class QueueFull
def test_QueueFull():
    QueueFull()



# Generated at 2022-06-24 09:19:32.565575
# Unit test for constructor of class PriorityQueue
def test_PriorityQueue():
    q = PriorityQueue()
    q.put((1, 'medium-priority item'))
    q.put((0, 'high-priority item'))
    q.put((10, 'low-priority item'))

    assert q.get_nowait() == (0, 'high-priority item')
    assert q.get_nowait() == (1, 'medium-priority item')
    assert q.get_nowait() == (10, 'low-priority item')

