

# Generated at 2022-06-12 14:01:27.463149
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.full()
    try:
        q.put_nowait(4)
    except QueueFull:
        pass
    else:
        raise AssertionError("QueueFull not raised")
    assert not q.empty()
    assert q.qsize() == 3
    assert not q.full()



# Generated at 2022-06-12 14:01:32.092728
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  from tornado import gen
  from tornado.ioloop import IOLoop
  from tornado.queues import Queue

  q = Queue(maxsize=2)

  async def consumer():
    async for item in q:
      try:
        print('Doing work on %s' % item)
        await gen.sleep(0.01)
      finally:
        q.task_done()

  async def producer():
    for item in range(5):
      await q.put(item)
      print('Put %s' % item)

  async def main():
    # Start consumer without waiting (since it never finishes).
    IOLoop.current().spawn_callback(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

# Generated at 2022-06-12 14:01:35.777270
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get() # Noncompliant {{Make sure that reading from this message queue is safe here.}}
    # ^^^^^^

# Generated at 2022-06-12 14:01:45.502381
# Unit test for method put of class Queue
def test_Queue_put():
  from tornado.ioloop import IOLoop
  from tornado.queues import Queue
  from tornado.gen import sleep
  from tornado.testing import AsyncTestCase

  import unittest

  class TestCase(AsyncTestCase):
    def setUp(self):
      super().setUp()
      self.q = Queue()

    def tearDown(self):
      super().tearDown()
      self.q.close()

    @tornado.testing.gen_test
    async def test_put(self):
      await self.q.put('bob')
      await self.q.put('jane')
      x = await self.q.get()
      y = await self.q.get()
      self.assertEqual(x, 'bob')
      self.assertEqual(y, 'jane')



# Generated at 2022-06-12 14:01:51.069733
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(0)
    assert q.get_nowait() == 0
    q.put_nowait(1)
    assert q.get_nowait() == 1
    try:
        q.get_nowait()
    except QueueEmpty:
        pass



# Generated at 2022-06-12 14:01:58.960423
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """Unit test for method get_nowait of class Queue"""

    q = Queue(maxsize=2)
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    q._queue.append(0)
    q._queue.append(1)
    assert q.empty() == False
    assert q.full() == True
    assert q.qsize() == 2
    assert q.get_nowait() == 0
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 1
    assert q.get_nowait() == 1
    assert q.empty() == True

# Generated at 2022-06-12 14:02:04.441060
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)

    try:
        q.put_nowait(3)
    except:
        print("success")
    else:
        print("fail")


# Generated at 2022-06-12 14:02:09.085942
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.empty()
    assert not q.full()

    getter1 = Future()
    getter2 = Future()
    putter1 = Future()
    putter2 = Future()
    q._getters.append(getter1)
    q._getters.append(getter2)
    q._putters.append((1, putter1))
    q._putters.append((2, putter2))

    f = q.put(3)
    assert f.done()
    assert f.result() is None
    assert q.full()
    assert not q.empty()
    assert q.qsize() == 2
    assert q._queue == [1, 2]
    assert getter1.done()
    assert get

# Generated at 2022-06-12 14:02:19.748218
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    def consumer():
        while True:
            item = q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        ioloop.IOLoop.current().run_sync(producer)     # Wait for producer to put all tasks.
        ioloop.IOLoop.current().run_sync(q.join)       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:02:22.389119
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()  # type: Queue[_T]
    q.put_nowait(1)
    assert q.get_nowait() == 1
try:
    test_Queue_get_nowait()
    print('test_Queue_get_nowait successed!')
except:
    print('test_Queue_get_nowait failed!')



# Generated at 2022-06-12 14:02:42.303657
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    @gen.coroutine
    def consumer():
        while True:
            text = yield q.get()
            try:
                print('Doing work on %s' % text)
                yield gen.sleep(0.01)
            finally:
                q.task_done()
    @gen.coroutine
    def producer():
        for item in range(5):
            print("put %s" % item)
            yield q.put(item)
    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks

# Generated at 2022-06-12 14:02:44.647157
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    assert q._queue == deque([1,])



# Generated at 2022-06-12 14:02:50.500497
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    # Test if queue is empty, QueueEmpty is raised
    try:
        q.get_nowait()
    except:
        assert isinstance(q, Queue)
    # Test if queue is not empty, return value
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:02:52.255200
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait("hello")
    assert q.qsize() == 1
    assert q._queue[0] == "hello"


# Generated at 2022-06-12 14:02:55.247726
# Unit test for method get of class Queue
def test_Queue_get():
    def _get():
        print(q.get())

    a = 0
    q = Queue()
    threading.Thread(target=_get).start()
    q.put(a)
    time.sleep(1)



# Generated at 2022-06-12 14:02:57.240471
# Unit test for method put of class Queue
def test_Queue_put(): 
    q = Queue()
    q.put(10)
    assert q.get_nowait() == 10

# Generated at 2022-06-12 14:03:08.780299
# Unit test for method get_nowait of class Queue

# Generated at 2022-06-12 14:03:16.603589
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:03:26.302192
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    aq = Queue()
    async def consumer():
        async for item in aq:
            print('Doing work on %s' % item)
            await asyncio.sleep(0.01)
        print('Done')

    async def producer():
        for item in range(5):
            await aq.put(item)
            print('Put %s' % item)
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await aq.join()       # Wait for consumer to finish all tasks.
        print('Done')



# Generated at 2022-06-12 14:03:34.177281
# Unit test for method put of class Queue
def test_Queue_put():
    q1 = Queue(maxsize=2)
    item = 1
    try:
        q1.put_nowait(item)
    except QueueFull:
        raise
    else:
        pass

    getter = q1.get_nowait()
    assert getter == item
    q1.task_done()

    item = 2
    q1.put_nowait(item)
    q1.put_nowait(3)
    try:
        q1.put_nowait(4)
    except QueueFull:
        pass
    else:
        raise
    #TODO: check if an item is added to the queue



# Generated at 2022-06-12 14:03:58.988583
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # inv: q.get_nowait() for q of class Queue and q.qsize() > 0
    q = Queue()
    assert q.qsize() == 0
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    else:
        assert False

    q.put_nowait(10)
    q.put_nowait(20)
    assert q.get_nowait() == 10
    assert q.get_nowait() == 20

    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass
    else:
        assert False


# Generated at 2022-06-12 14:04:10.706588
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:04:17.891268
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:04:20.142882
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-12 14:04:27.612851
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    max_size = 10
    # Create an empty queue with max_size = 10
    q = Queue(max_size)
    assert q.empty() # Check if queue is empty
    assert q.qsize() == 0 # Check if queue is empty
    assert q.full() == 0 # Check if queue is empty
    # Add two items
    q.put_nowait(1)
    assert q.qsize() == 1 # Check if queue is empty
    q.put_nowait(1)
    assert q.qsize() == 2 # Check if queue is empty
    # Test if queue is full
    for i in range(1, max_size):
        q.put_nowait(i)
    assert q.qsize() == max_size
    assert q.full() == 1
    # Test if exception is raised

# Generated at 2022-06-12 14:04:37.525209
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:04:39.938498
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    res = q.get(timeout = 3)
    #print(res)
    return res

# Generated at 2022-06-12 14:04:43.731005
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    for i in range(5):
        q.put_nowait(i)
    return q

_G1 = test_Queue_put_nowait()
print(_G1)


# Generated at 2022-06-12 14:04:52.257413
# Unit test for method put of class Queue
def test_Queue_put():
    def test_Queue_put0():
        q = Queue(maxsize=2)
        assert q._putters == deque()
        assert q.empty() == True
        assert q.full() == False
    test_Queue_put0()

    def test_Queue_put1():
        q = Queue(maxsize=2)
        q._queue = deque([0]) 
        q._getters = deque([Future()])
        q._putters = deque([(1, Future())])
        assert q._putters == deque([(1, Future())])
        assert q.empty() == False
        assert q.full() == False
    test_Queue_put1()


# Generated at 2022-06-12 14:05:03.863611
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # create the Queue instance
    maxsize = 2
    queue = Queue(maxsize)
    # add the tasks
    queue.put_nowait(1)
    queue.put_nowait(2)
    # set the flag for getting the tasks
    get_queue = True
    # check the Qsize
    assert queue.qsize() == 2
    assert queue.empty() == False
    assert queue.full() == True
    # iterate the queue to check the correctness

# Generated at 2022-06-12 14:05:48.184226
# Unit test for method put of class Queue
def test_Queue_put():
    # maxsize=2 q=deque() getters=[] putters=[] num_tasks=0
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q._getters == []
    assert q._putters == []
    assert q._unfinished_tasks == 0
    assert q.full() == False
    assert q.empty() == True
    # maxsize=2 q=deque([1]) getters=[] putters=[] num_tasks=0
    q.__put_internal(1)
    assert q.qsize() == 1
    assert q._getters == []
    assert q._putters == []
    assert q._unfinished_tasks == 0
    assert q.full() == False
    assert q.empty()

# Generated at 2022-06-12 14:05:50.547504
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    for i in range(500):
        q = Queue()
        q.put_nowait(1)
        assert q.get_nowait() == 1



# Generated at 2022-06-12 14:05:58.717058
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # Put two items to the queue
    q.__put_internal(1)
    q.__put_internal(1)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 1
    # Test case 2
    q = Queue()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    # Test case 3
    q = Queue()
    q.__put_internal(1)
    assert q.get_nowait() == 1
    # Test case 4
    q = Queue()
    q.__put_internal(1)
    assert q.get_nowait() == 1

# Generated at 2022-06-12 14:06:10.080921
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            print('Put %s' % item)
            yield q.put(item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for

# Generated at 2022-06-12 14:06:12.442411
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize = 2)
    q.put_nowait(1)
    expected = 1
    assert(q.get_nowait() == expected)

# Generated at 2022-06-12 14:06:17.978375
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put("hello")
    assert q.get_nowait() == "hello"
    assert q.empty()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True
    else:
        assert False



# Generated at 2022-06-12 14:06:24.624653
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    print(q.qsize())
    q.put(1)
    q.put(2)
    q.put(3)
    print(q.qsize())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.qsize())

test_Queue_get_nowait()

# Generated at 2022-06-12 14:06:31.493349
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:06:42.512747
# Unit test for method put of class Queue
def test_Queue_put():
    #Tests the method put of class Queue.
    #This method adds an object to the queue and blocks if the queue is full.
    #creating an object of class Queue
    #test_Queue = Queue()
    #creating an object of class QueueFull
    test_QueueFull = QueueFull()
    #setting the maxsize to 0
    test_Queue.maxsize = 0
    #setting the value of the full attribute to True
    test_Queue.full() == True
    #if statements to check test_Queue.put
    if test_Queue.full() == True:
        test_Queue.put(test_QueueFull) == test_QueueFull
    else:
        test_Queue.put(test_QueueFull) != test_QueueFull
    print(test_Queue)
         

# Generated at 2022-06-12 14:06:53.385939
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:08:16.760345
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Queue object construction
    q1 = Queue(maxsize=0)
    q2 = Queue(maxsize=1)
    q3 = Queue(maxsize=2)

    # Queue object is empty
    # Should raise QueueEmpty
    try:
        q1.get_nowait()
    except QueueEmpty:
        pass
    except Exception as e:
        print("Wrong exception")
        print(e)

    # Queue object is empty
    # Add 1 item to queue
    # Get 1 item from queue
    try:
        q1.put_nowait("a")
        v1 = q1.get_nowait()
        assert v1 == "a"
    except Exception as e:
        print("Wrong exception")
        print(e)

    # Queue object is empty
   

# Generated at 2022-06-12 14:08:19.011343
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get() == 1

if __name__ == '__main__':
    test_Queue_get()

# Generated at 2022-06-12 14:08:28.623878
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:08:38.899766
# Unit test for method get of class Queue
def test_Queue_get():
    print(test_Queue_get.__name__)
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        consumer()
        producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    main()

# Generated at 2022-06-12 14:08:44.268140
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    _queue = collections.deque()
    assert(Queue.get_nowait(_queue) is None)
    _queue.append(1)
    assert(Queue.get_nowait(_queue) == 1)
    assert(Queue.get_nowait(_queue) is None)



# Generated at 2022-06-12 14:08:47.489203
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2


# Generated at 2022-06-12 14:08:52.830455
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine

    @coroutine
    def main():
        q = Queue()
        q.put(1)
        q.put(2)
        x = yield q.get()

    IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:09:01.677628
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def consumer():
        await q.get()
        print("consume")
        q.task_done()

    async def producer():
        await q.put(2)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:09:05.380759
# Unit test for method get of class Queue
def test_Queue_get():
    # Create a queue to hold the csv file lines
    q = Queue(maxsize=0)
    # Get a task from the queue
    get_task = q.get()
    # Check if the task is a queue
    assert isinstance(get_task, Queue)


# Generated at 2022-06-12 14:09:15.525400
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import random 
    import time
    
    
    
    async def put_num(q):
        print("put_num")
        print(q[0].qsize())

        while q[0].qsize() <= 5:
            await q[0].put(random.randint(0, 1000))
            print("put: %d" % q[0].qsize())
            await asyncio.sleep(1)
        print("put_num_finished")

    async def get_num(q):
        print("get_num")
        print(q[1].qsize())
        while q[1].qsize() <= 5:
            await q[1].get()
            print("get: %d" % q[1].qsize())
            await asyncio.sleep(1)