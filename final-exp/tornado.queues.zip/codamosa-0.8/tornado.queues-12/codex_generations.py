

# Generated at 2022-06-12 14:01:12.399381
# Unit test for method put of class Queue
def test_Queue_put():
    global q
    q = Queue()
    def test1():
        q.put(1)
        a = q.empty()
        if a == False :
            return 1
        else:
            return 0
    def test2():
        q.put(1)
        q.put(1)
        q.put(1)
        q.put(1)
        q.get()
        a = q.full()
        if a == False :
            return 1
        else:
            return 0
    test1()
    test2()



# Generated at 2022-06-12 14:01:19.993400
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=3)
    #initialization
    result = [q.qsize(), q.empty(), q.full()]
    assert(result == [0, True, False])
    #test get_nowait, empty queue
    try:
        q.get_nowait()
    except QueueEmpty:
        assert 1
    #test put_nowait, queue not full
    try:
        q.put_nowait(1)
        q.put_nowait(2)
    except QueueFull:
        assert 0
    result = [q.qsize(), q.empty(), q.full()]
    assert(result == [2, False, False])
    #test get_nowait, queue not empty
    assert(q.get_nowait() == 1)

# Generated at 2022-06-12 14:01:27.335136
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from collections import deque

    # test: queue is already empty
    q = Queue(0)
    assert q.empty()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "no QueueEmpty exception raised"

    # test: queue is not empty, but no items are available
    q = Queue(1)
    q.put_nowait(0)
    assert q.full()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "no QueueEmpty exception raised"

    # test: queue is empty, an item is available
    q = Queue(1)
    q._queue.append(0)
    assert not q.empty()
    assert q.get

# Generated at 2022-06-12 14:01:32.598151
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Unit test for method get_nowait of class Queue
    q = Queue()  # type: Queue
    assert q.qsize() == 0
    assert q.empty() is True
    assert q.full() is False
    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() is False
    assert q.full() is False
    assert q.get_nowait() == 1
    assert q.qsize() == 0
    assert q.empty() is True
    assert q.full() is False
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 2
    assert q.empty() is False
    assert q.full() is False
    q.put_nowait(4)
    assert q

# Generated at 2022-06-12 14:01:38.229763
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full() == 1
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty() == True


# Generated at 2022-06-12 14:01:47.606675
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    print('Unit test for method task_done of class Queue')
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.I

# Generated at 2022-06-12 14:01:53.610763
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    future = Future() # type: Future[None]
    try:
        q.put_nowait(1)
    except QueueFull:
        q._putters.append((1, future))
        _set_timeout(future, None)
    else:
        future.set_result(None)
    assert q.get_nowait() == 1 # q is not empty.


# Generated at 2022-06-12 14:02:05.452347
# Unit test for method put of class Queue
def test_Queue_put():
    def _put(x: int, q: Queue[int], f: Future[None], t: Union[None, float, datetime.timedelta]) -> Future[None]:
        return q.put(x, t)
    
    _get = Queue.get
    _get_nowait = Queue.get_nowait
    _put_nowait = Queue.put_nowait
    
    # qsize = 0, maxsize = 5
    q = Queue(5)
    f = Future()
    # Put x = 0 into q
    x = 0
    t = None
    assert _put(x, q, f, t) == f
    assert f.done()
    assert f.result() is None
    assert q.qsize() == 1
    assert q._getters == collections.deque()
   

# Generated at 2022-06-12 14:02:12.111605
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    async def coro():
        # tests put_nowait method
        q = Queue()
        q.put_nowait(11)
        q.put_nowait(12)
        res = q.get_nowait()
        assert res == 11
        res = q.get_nowait()
        assert res == 12
        assert q.empty()

    coro().add_done_callback(lambda f: ioloop.IOLoop.current().stop())
    ioloop.IOLoop.current().start()



# Generated at 2022-06-12 14:02:22.717744
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # init queue: (maxsize = 2)
    # fill queue: put_nowait(0), put_nowait(1)
    # test: get_nowait(). == 0
    # assert queue: queue = [1]
    queue = Queue(2)
    queue.put_nowait(0)
    queue.put_nowait(1)
    assert queue.get_nowait() == 0
    assert queue._queue == deque([1])
    
    # init queue: (maxsize = 2)
    # test: get_nowait(). raise QueueEmpty
    # assert queue: queue = []
    queue = Queue(2)
    try:
        res = queue.get_nowait()
        assert False
    except QueueEmpty:
        assert queue._queue == deque([])
        
    # init queue

# Generated at 2022-06-12 14:02:40.597943
# Unit test for method get of class Queue
def test_Queue_get():
    # Setup input and expected result
    q = Queue(maxsize=2)
    result = q._get()

    print("Output:")
    print(result)

    # Test
    assert result == None
    print("Success")


# Generated at 2022-06-12 14:02:42.687943
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    _Queue = Queue()
    _Queue.put_nowait(4)
    assert _Queue._queue == collections.deque([4])


# Generated at 2022-06-12 14:02:43.694239
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    s = Queue()
    s.put_nowait(1)


# Generated at 2022-06-12 14:02:47.913734
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty()
    q.put(1)
    assert q.qsize() == 1
    assert not q.empty()
    assert q.get_nowait() == 1
    assert q.qsize() == 0
    assert q.empty()

# Generated at 2022-06-12 14:02:48.551548
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass

# Generated at 2022-06-12 14:02:57.585845
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:03:09.076891
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import sys
    import functools
    import typing
    import datetime
    import time
    import unittest
    import tornado.concurrent
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    from tornado.gen import sleep
    from tornado import ioloop
    from tornado.web import RequestHandler, Application, url
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Queue(object):
        def __init__(self):
            self._queue = collections.deque()
            # self._queue = []
            self.maxsize = 0
            self._getters = collections.deque()
            self._putters = collections.deque()


# Generated at 2022-06-12 14:03:12.055862
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(3)
    q.put_nowait(4)
    try:
        q.put_nowait(5)
        print("It cannot reach here")
    except QueueFull:
        print("Yes, it is full")
    finally:
        print("No matter what happens, this line will be output!")
    # test
    test_Queue_put_nowait()

# Generated at 2022-06-12 14:03:17.005405
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    import numpy as mypy_numpy
    mldb = MLDB()  # noqa
    
    _queue_item = {"abc": 123}
    _queue_size = 10
    _queue_timeout = .05
    _queue_delay = .02
    _queue_delta = .05
    _timeout_error_msg = "Timeout while waiting for Queue.get_nowait()"
    _empty_error_msg = "No item in Queue"

    # Create a queue q with a maxsize of _queue_size
    q = Queue(maxsize=_queue_size)

    # Fill the queue q with _queue_size items
    for x in range(0, _queue_size):
        q.put_nowait(x)

    # Assert q.empty() returns False and q.

# Generated at 2022-06-12 14:03:19.308721
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-12 14:03:36.979354
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:03:42.111975
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import tornado.queues
    q = tornado.queues.Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.put_nowait(3)
    assert q.qsize() == 3
    q.put_nowait(4)
    assert q.qsize() == 4

# Generated at 2022-06-12 14:03:46.210753
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    passed = True
    maxsize=0
    _unfinished_tasks=0
    _getters=[]
    _queue=[]
    _putters=[]
    value = Queue.__dict__['get_nowait'](maxsize,_unfinished_tasks,_getters,_queue,_putters)
    value = QueueEmpty
    assert value == QueueEmpty
    print ("Passed! get_nowait method of class Queue passed.")
    return true



# Generated at 2022-06-12 14:03:55.659521
# Unit test for method get of class Queue
def test_Queue_get():
   from tornado.ioloop import IOLoop
   from tornado.queues import Queue
   q = Queue(maxsize=2)
   # @gen.coroutine
   # def consumer():
   #     while True:
   #         item = yield q.get()
   #         try:
   #             print('Doing work on %s' % item)
   #             yield gen.sleep(0.01)
   #         finally:
   #             q.task_done()

   # @gen.coroutine
   # def producer():
   #     for item in range(5):
   #         yield q.put(item)
   #         print('Put %s' % item)

   # @gen.coroutine
   # def main():
   #     # Start consumer without waiting (since it never finishes).
   #     IOL

# Generated at 2022-06-12 14:03:57.717653
# Unit test for method put of class Queue
def test_Queue_put():
    # Test scenario - put
    queue = Queue(1)
    queue.put(item=1)
    print('test_queue_put passed!')


# Generated at 2022-06-12 14:04:01.319913
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 24
    q = Queue(maxsize = maxsize)
    for i in range(maxsize):
        q.put(i)
    
    q.put(maxsize + 1)

# Generated at 2022-06-12 14:04:06.686682
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    r1 = q.get_nowait()
    r2 = q.get_nowait()
    assert isinstance(r1, int)
    assert isinstance(r2, int)
    assert r1 == 1
    assert r2 == 2

# Generated at 2022-06-12 14:04:15.760587
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import pytest
    from tornado.gen import sleep

    q = Queue(maxsize=0)

    async def producer():
        for i in range(4):
            await q.put(i)
            await sleep(0)

    async def consumer():
        while True:
            item = await q.get()
            print("Got item %s" % item)
            q.task_done()

    async def main():
        # Start consumer without waiting (since it never finishes).
        q.put_nowait(1)
        pytest.fail("cannot put")
        await q.join()  # Wait for consumer to finish all tasks.
        print("Done")

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:04:17.458016
# Unit test for method get of class Queue
def test_Queue_get():
    future = Future()
    # Replace the following line with your code
    pass
    return future    
    
    
    

# Generated at 2022-06-12 14:04:23.857022
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:04:51.657488
# Unit test for method put of class Queue
def test_Queue_put():
    maxsize = 10
    q = Queue(maxsize)
    assert type(q) == Queue
    assert q.maxsize == maxsize
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    item = 10
    future = q.put(item)
    # assert type(future) == Future
    assert future.done()
    assert q.qsize() == 1
    
    
    
    item = 10
    timeout = 0.1
    future = q.put(item, timeout)
    assert type(future) == Future
    assert future.done()
    assert q.qsize() == 2
    
    
    
       
    
    
    
    
    
    

# Generated at 2022-06-12 14:04:55.251834
# Unit test for method put of class Queue
def test_Queue_put():
    i=Queue(maxsize=3)
    i.put(1)
    i.put(2)
    i.put(3)
    i.put(4)

# Generated at 2022-06-12 14:04:58.014010
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.put(1) is False
    assert q.put(2) is False
    assert q.put(3) is True

# Generated at 2022-06-12 14:05:08.010409
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # get_nowait(self, timeout: Optional[Union[float, datetime.timedelta]] = None) -> _T:
    # This is an auto-generated Django model module.
    # You'll have to do the following manually to clean this up:
    #   * Rearrange models' order
    #   * Make sure each model has one field with primary_key=True
    #   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
    #   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
    # Feel free to rename the models, but don't rename db_table values or field names.
    from django.db import models
    from django.contrib.auth.models import User
    if timeout is None:
        if self.empty():
            raise

# Generated at 2022-06-12 14:05:14.487147
# Unit test for method get of class Queue
def test_Queue_get():
    """Test whether method get of class Queue could return the right value"""
    import tornado
    import tornado.concurrent
    import tornado.ioloop
    import tornado.queues
    import datetime
    import time

    # Create a TornadoFuturesQueue object tornado.queues.Queue
    # maxsize = 0
    my_TornadoFuturesQueue = tornado.queues.Queue(maxsize=0)
    x__get_getter = my_TornadoFuturesQueue.__aiter__()
    # var_x = test_x__get_getter.__anext__()
    # __anext__(self) -> Awaitable[Any]
    # Returns an awaitable that resolves to the next item when
    # one is available. When the queue is empty, raises the
    # exception returned by ``exc_callback

# Generated at 2022-06-12 14:05:15.646128
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    assert queue.get() == QueueEmpty()


# Generated at 2022-06-12 14:05:23.225714
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import queue

    def _thread_init(q):
        time.sleep(1.0)
        q.put(1)
        time.sleep(1.0)
        q.put(2)
        time.sleep(1.0)
        q.put(3)
        time.sleep(1.0)
        q.put(4)

    q = queue.Queue(maxsize=0)
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)

    threads = []
    threads.append(threading.Thread(target=_thread_init, args=(q,)))

    for t in threads:
        t.start()

    # block until all items in the queue are processed
    q.join()

    q.empty()

# Generated at 2022-06-12 14:05:31.909292
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	from tornado import queues
	from tornado import gen
	from tornado.ioloop import IOLoop
	from tornado.queues import Queue

	q = Queue(maxsize=2)

	async def consumer():
		async for item in q:
			try:
				print('Doing work on %s' % item)
				await gen.sleep(0.01)
			finally:
				q.task_done()

	async def producer():
		for item in range(5):
			await q.put(item)
			print('Put %s' % item)

	async def main():
		# Start consumer without waiting (since it never finishes).
		IOLoop.current().spawn_callback(consumer)
		aw

# Generated at 2022-06-12 14:05:33.088555
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()

# Generated at 2022-06-12 14:05:38.957396
# Unit test for method get of class Queue
def test_Queue_get():
    # EmptyQueueError
    queue = Queue()
    assert queue.get() == None
    queue.task_done()
    assert queue.get() == None
    queue.task_done()
    assert queue.get() == None
    queue.task_done()
    queue.put(1)
    assert queue.get() == 1
    queue.task_done()
    assert queue.get() == None
    queue.task_done()


# Generated at 2022-06-12 14:06:21.437450
# Unit test for method put of class Queue
def test_Queue_put():
	#method_args: item: _T, timeout: Optional[Union[float, datetime.timedelta]] = None
	#method_return: Future[None]
	assert True



# Generated at 2022-06-12 14:06:23.005478
# Unit test for method get of class Queue
def test_Queue_get():
    pass



# Generated at 2022-06-12 14:06:28.586508
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    inp = [4, 6, 5]
    exp = [4, 6, 5]
    fail_flag = True
    try:
        q = Queue()
        for i in inp:
            q.put_nowait(i)
        for i in exp:
            if i != q.get_nowait():
                fail_flag = False
                break
    except:
        fail_flag = False
    assert fail_flag

# Generated at 2022-06-12 14:06:39.374327
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import tornado.gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:06:42.346891
# Unit test for method put of class Queue
def test_Queue_put():
    q=Queue()
    f=Future()
    putters=(("test",f),)
    q.put("test",None)
    assert(q._putters==putters)


# Generated at 2022-06-12 14:06:53.176863
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    def run_test(self):
        # Put item in empty queue.
        item = object()
        q.put_nowait(item)
        assert q.qsize() == 1 and q._queue[0] is item
        # Put item in nonempty queue.
        item = object()
        q.put_nowait(item)
        assert q.qsize() == 2 and q._queue[1] is item
        # Put item in full queue.
        q = Queue(1)
        q.put_nowait(object())
        try:
            q.put_nowait(object())
            assert False
        except QueueFull:
            pass
        assert q.qsize() == 1
        # Put item with timeout into empty queue.
        q = Queue(1)
        item = object()

# Generated at 2022-06-12 14:07:04.040435
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=10)
    q.put_nowait(1)
    assert q.qsize() == 1
    assert len(q._getters) == 0
    assert len(q._putters) == 0
    q.put_nowait(2)
    assert q.qsize() == 2
    assert len(q._getters) == 0
    assert len(q._putters) == 0
    for i in range(10):
        q.put_nowait(i)
    assert q.qsize() == 10
    assert len(q._getters) == 0
    assert len(q._putters) == 0
    try:
        q.put_nowait(11)
        assert False
    except QueueFull as e:
        assert True
    assert q.qsize() == 10
   

# Generated at 2022-06-12 14:07:14.936736
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        asyncio.get_event_loop().create_task(consumer())
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    q = Queue(maxsize=2)
    main()

# Generated at 2022-06-12 14:07:19.582697
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(5)
    try:
        q.put_nowait(6)
        q.put_nowait(7)
    except QueueFull:
        isFull = True
    print(isFull)


# Generated at 2022-06-12 14:07:27.012738
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:08:50.111367
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest 
    import tornado
    import tornado.testing

    def test_put_nowait(self):
        queue = Queue()
        queue.put_nowait(1)
        self.assertEqual(queue.qsize(), 1)
        queue.put_nowait(2)
        self.assertEqual(queue.qsize(), 2)
        self.assertRaises(QueueFull, queue.put_nowait, 1)
        self.assertEqual(queue.qsize(), 2)





# Generated at 2022-06-12 14:09:00.727924
# Unit test for method put of class Queue
def test_Queue_put():
    # maxsize is not None
    try:
        Queue(maxsize=None)
        raise AssertionError("Expected a TypeError here")
    except TypeError:
        pass
    # maxsize is negative
    try:
        Queue(maxsize=-1)
        raise AssertionError("Expected a ValueError here")
    except ValueError:
        pass

    # maxsize is 0
    q = Queue(maxsize=0)
    f = q.put(1)
    assert f.result() is None
    assert q.get_nowait() == 1

    # maxsize is positive
    q = Queue(maxsize=1)
    f = q.put(1)
    assert f.result() is None
    f = q.put(2)
    assert not f.done()

# Generated at 2022-06-12 14:09:03.301203
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Some tests of the method get in the class Queue.
    """
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get()==1
    assert q.get()==2

# Generated at 2022-06-12 14:09:13.485066
# Unit test for method put of class Queue
def test_Queue_put():
    with pytest.raises(TypeError):
        q = Queue()
        q.put(1, 2)
    with pytest.raises(ValueError):
        q = Queue()
        q.put(1, -1)
    with pytest.raises(TypeError):
        q = Queue()
        q.put(1, 1.2)
    with pytest.raises(TypeError):
        q = Queue()
        q.put(1, None)
    with pytest.raises(TypeError):
        q = Queue()
        q.put(1, "")
    with pytest.raises(QueueFull):
        q = Queue(maxsize=1)
        q.put(1)
        q.put(1)

# Generated at 2022-06-12 14:09:24.072785
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:09:34.041863
# Unit test for method get of class Queue
def test_Queue_get():

    import asyncio
    import random
    import time
    q = Queue()
    print("q:",q)
    async def produce(q):
        while True:
            await q.put("hello")
            await asyncio.sleep(random.randint(1,3))
    async def consume(q):
        while True:
            data = await q.get()
            print("consumer:",data)
            await asyncio.sleep(random.randint(1,3))
    async def main():
        task1 = [asyncio.create_task(produce(q)) for _ in range(5)]
        task2 = [asyncio.create_task(consume(q)) for _ in range(5)]
        await asyncio.wait(task1)
        await asyncio.wait(task2)

# Generated at 2022-06-12 14:09:38.213914
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import asyncio
    async def main():
        q = Queue()
        await q.put(42)
        print(await q.get())
        print(await q.get())
    try:
        ioloop.IOLoop.current().run_sync(main)
    except QueueEmpty as e:
        print(e)

# Generated at 2022-06-12 14:09:44.110506
# Unit test for method put of class Queue
def test_Queue_put():

    # Create Queue instance q
    q = Queue()

    # Put item 1 into queue
    item = 1
    q.put_nowait(item)
    assert q.qsize() == 1, 'queue not full, why are putters waiting?'

    # Put item 2 into queue
    item = 2
    q.put_nowait(item)
    assert q.qsize() == 2, 'queue not full, why are putters waiting?'

    # Put item 3 into queue and verify QueueFull exception
    item = 3
    try:
        q.put_nowait(item)
    except QueueFull:
        assert True
    else:
        raise Exception(
            'QueueFull exception not raised with full queue on put_nowait')

test_Queue_put()


# Generated at 2022-06-12 14:09:52.092045
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:09:59.546935
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=5)
    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    assert q.maxsize == 5
    # Queue with elements
    q.put(2)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 1
    assert q.maxsize == 5
    q.put(4)
    q.put(1)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 3
    assert q.maxsize == 5
    for i in range(3, 5):
        q.put(i)
    assert q.empty() == False
    assert q.full() == True