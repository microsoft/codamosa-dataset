

# Generated at 2022-06-12 14:01:21.176404
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:01:31.901153
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    # Parameterized test case.
    q1 = Queue(maxsize=2)
    q1.put(1)
    q1.put(2)
    assert q1.full() == True
    
    assert q1.empty() == False
    assert q1.qsize() == 2

    assert q1._finished.is_set() == False
    
    q1.task_done()
    assert q1._unfinished_tasks == 1
    assert q1._finished.is_set() == False

    assert q1.get_nowait() == 2
    q1.task_done()
    assert q1._unfinished_tasks == 0
    assert q1._finished.is_set() == True

    q1.put(3)
    q1.put(4)
    assert q1.full()

# Generated at 2022-06-12 14:01:40.744345
# Unit test for method get of class Queue
def test_Queue_get():

    size = 4
    q = Queue(maxsize = size)

    for i in range(size):
        q.put_nowait(i)

    for i in range(size):
        if (q.qsize() == size - i):
            assert q.full()
        else:
            assert not q.full()
        if (q.qsize() == i):
            assert q.empty()
        else:
            assert not q.empty()
        assert q.qsize() == size - i
        assert q.get_nowait() == i

    assert q.qsize() == 0
    assert q.empty()

# Generated at 2022-06-12 14:01:52.816771
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:01:57.346718
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    qsize = 3
    q = Queue(maxsize=qsize)
    if q.qsize() != 0:
        return False
    for i in range(qsize):
        q.put(i)
        if q.qsize() != i+1:
            print(q.qsize())
            return False
    return True


# Generated at 2022-06-12 14:02:09.306824
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.empty() is True
    assert q.qsize() == 0
    try:    
        q.put_nowait(0)
        q.put_nowait(1)
    except QueueFull:
        pass
    assert q.empty() is False
    assert q.qsize() == 2
    assert q.full() is True
    try:
        q.put_nowait(2)
    except QueueFull:
        pass
    assert q.qsize() == 2
    assert q.full() is True
    q.get_nowait()
    q.get_nowait()
    assert q.qsize() == 0
    assert q.full() is False
    try:
        q.get_nowait()
    except QueueEmpty:
        pass

# Generated at 2022-06-12 14:02:12.025840
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.task_done()
    q.task_done()


# Generated at 2022-06-12 14:02:18.959033
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.qsize() == 1
    q.task_done()
    assert q.qsize() == 0
    q = Queue(maxsize=1)
    with pytest.raises(ValueError) as exc_info:
        q.task_done()
    assert "task_done() called too many times" in str(exc_info.value)


# Generated at 2022-06-12 14:02:27.568887
# Unit test for method put of class Queue
def test_Queue_put():
    # Test for function Queue.put
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    def main():
        # Start consumer without waiting (since it never finishes).
        #IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:02:29.883166
# Unit test for method task_done of class Queue
def test_Queue_task_done():
    q = Queue(10)
    assert q.qsize() == 0
    assert not q.full()
    assert q.empty()
test_Queue_task_done()


# Generated at 2022-06-12 14:02:41.985118
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.put(1)
    assert q.get() == 1

# Generated at 2022-06-12 14:02:49.095864
# Unit test for method get of class Queue
def test_Queue_get():
    import time, random
    import tornado
    import tornado.ioloop
    import tornado.queues
    q = tornado.queues.Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await tornado.gen.sleep(random.random())
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-12 14:02:52.772991
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(2)
    q.put_nowait(3)
    with pytest.raises(QueueFull):
        q.put_nowait(4)


# Generated at 2022-06-12 14:02:57.366506
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 2)
    try:
        q.put_nowait(1)
    except:
        pass
    try:
        q.put_nowait(2)
    except:
        pass
    try:
        q.put_nowait(3)
        pass
    except:
        return True
    return False

# Generated at 2022-06-12 14:03:02.002850
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue() # create a queue
    q.put_nowait("hello") # add element to the queue
    assert q._queue[0] == "hello" # the element added is hello
    assert q.qsize() == 1 # queue should have only one element


# Generated at 2022-06-12 14:03:05.414686
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)


# Generated at 2022-06-12 14:03:08.920736
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q._unfinished_tasks = 2
    q._queue = collections.deque(["a", "b"])
    r = q.get_nowait()
    assert r == "a"

# Generated at 2022-06-12 14:03:10.973690
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0

    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.qsize() == 0

# Generated at 2022-06-12 14:03:13.511762
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        Queue.put_nowait(Queue(), 1)
        return True
    except:
        import sys, traceback
        exc_info = sys.exc_info()
        traceback.print_exception(*exc_info)
        return False
test_Queue_put_nowait()


# Generated at 2022-06-12 14:03:15.582218
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty as e:
        pass

# Generated at 2022-06-12 14:03:25.468654
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-12 14:03:28.975014
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(3)
    q.put(4)

    assert not q.full()
    q.put(5)
    assert q.full()

# Generated at 2022-06-12 14:03:31.452545
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
	q = Queue()
	q.put_nowait('First')
	q.put_nowait('Second')
	assert q.qsize() == 2


# Generated at 2022-06-12 14:03:35.277106
# Unit test for method get of class Queue
def test_Queue_get():
    # Arrange
    q = Queue(maxsize=2)
    expected = 'queue is empty'
    actual = ''
    try:
        # Act
        actual = q.get_nowait()
    except QueueEmpty:
        actual = 'queue is empty'

    # Assert
    assert expected == actual

# Generated at 2022-06-12 14:03:43.934633
# Unit test for method get of class Queue
def test_Queue_get():
    # test function for method get of class Queue

    # Create Queue object
    newQueue = Queue()

    # put items into the queue
    newQueue.put_nowait(1)
    newQueue.put_nowait(2)
    newQueue.put_nowait(3)

    # get items from the queue
    newQueue.get_nowait()
    newQueue.task_done()
    newQueue.get_nowait()
    newQueue.task_done()
    newQueue.get_nowait()
    newQueue.task_done()

    # get error message
    try:
        newQueue.get_nowait()
    #check if it is empty
    except QueueEmpty:
        print("Exception QueueEmpty raised.")


# Generated at 2022-06-12 14:03:52.812546
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    @gen_test
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @gen_test
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    @gen_test
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:04:00.624580
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()

    assert q.empty()

    with pytest.raises(QueueEmpty):
        q.get_nowait()

    q.put('a')
    assert q.get_nowait() == 'a'

    q.put('a')
    q.put('b')
    q.put('c')
    assert q.get_nowait() == 'a'
    assert q.get_nowait() == 'b'
    assert q.get_nowait() == 'c'

    with pytest.raises(QueueEmpty):
        q.get_nowait()


# Generated at 2022-06-12 14:04:03.132753
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("Starting test_Queue_put_nowait")
    q = Queue()
    q.put_nowait(1)
    print(q._queue)



# Generated at 2022-06-12 14:04:13.823670
# Unit test for method get of class Queue
def test_Queue_get():
    print('test_Queue_get')
    q = Queue()
    def main():
        async def consumer():
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)
        async def main():
            # Start consumer without waiting (since it never finishes).
            ioloop.IOLoop.current().spawn_callback(consumer)
            await producer()     # Wait for producer to put all tasks.
            await q.join()       # Wait for consumer to finish all tasks.
            print('Done')
        ioloop.IOLoop.current().run

# Generated at 2022-06-12 14:04:21.261924
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen, ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    i

# Generated at 2022-06-12 14:04:34.866245
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def async_test():
        q = Queue(maxsize=2)
        await q.put(1)
        await q.put(2)
        try:
            await q.put(3, timeout=0.3)
        except gen.TimeoutError:
            return
        assert False

    IOLoop.current().run_sync(async_test)


# Generated at 2022-06-12 14:04:40.472969
# Unit test for method put of class Queue
def test_Queue_put():
    # Create a Queue instance with maxsize 2
    q = Queue(maxsize=2)
    # Create two tasks, each of which takes a long time of waiting to run
    a_waiting_task = Future()
    b_waiting_task = Future()
    # Create two putters, each of which has its waiting task
    a_putter = (0, a_waiting_task)
    b_putter = (1, b_waiting_task)
    # Add the two putters to putters queue
    q._putters.append(a_putter)
    q._putters.append(b_putter)
    # Add one getter to getter queue
    getter = Future()
    q._getters.append(getter)
    # Call function _consume_expired which should remove the first put

# Generated at 2022-06-12 14:04:41.183459
# Unit test for method put of class Queue
def test_Queue_put():
    pass

# Generated at 2022-06-12 14:04:50.973104
# Unit test for method put of class Queue
def test_Queue_put():
    print("Test : Queue put")
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run

# Generated at 2022-06-12 14:04:51.979888
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-12 14:05:02.204462
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
        
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
    
    ioloop.IOLoop.current().run_sync(main)

test_Queue_put()




# Generated at 2022-06-12 14:05:08.619911
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
    except QueueFull:
        # TODO
        pass
    else:
        # TODO
        pass
    try:
        q.put_nowait(2)
    except QueueFull:
        # TODO
        pass
    else:
        # TODO
        pass
    try:
        q.put_nowait(3)
    except QueueFull:
        # TODO
        pass
    else:
        # TODO
        pass


# Generated at 2022-06-12 14:05:14.406565
# Unit test for method put of class Queue
def test_Queue_put():
    ioloop.IOLoop.clear_current()
    io_loop = ioloop.IOLoop()
    io_loop.make_current()
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join

# Generated at 2022-06-12 14:05:21.832700
# Unit test for method get of class Queue
def test_Queue_get():
  q = Queue(maxsize=2)

  async def consumer():
    async for item in q:
      try:
        print('Doing work on %s' % item)
        await gen.sleep(0.01)
      finally:
        q.task_done()
    
  async def producer():
    for item in range(5):
      await q.put(item)
      print('Put %s' % item)
    
  async def main():
    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().run_sync(consumer)
    await producer()     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

  ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:05:31.001281
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:05:54.648540
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    def consumer():
        for item in q:
            print('Doing work on %s' % item)
            gen.sleep(0.01)

    def producer():
        for item in range(5):
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        producer()     # Wait for producer to put all tasks.
        q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:05:57.909456
# Unit test for method put of class Queue
def test_Queue_put():
    # Queue_put1
    # A test for _put(item)
    print("Test 1: put")
    q = Queue()
    q._put(1)
    assert q._queue == deque([1]), '_put method of Queue class failed'
    print('Test passed!')
    

# Generated at 2022-06-12 14:06:08.477104
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.testing import AsyncTestCase

    class MyTestCase(AsyncTestCase):
        def test_put(self):
            q = Queue()
            putter = q.put(object())

            def check_put():
                self.assertIsInstance(putter, Future)
                self.assertTrue(putter.done())
                self.assertEqual(q.qsize(), 1)

            self.io_loop.add_callback(check_put)
            self.wait()

    test_case = MyTestCase()
    test_case.run_test('test_put')



# Generated at 2022-06-12 14:06:14.084679
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado.queues
    import sys
    import threading
    q1 = tornado.queues.Queue(5)
    #print(q1.qsize())
    q1.put_nowait(1)
    #print(q1.qsize())
    q1.put_nowait(2)
    q2 = tornado.queues.Queue(5)
    q2.put_nowait(1)
    q2.put_nowait(2)
    #q1.put_nowait(1)#error, too many argument
    #q1.put_nowait()#error, too number of arguments
    a = q1.get_nowait()
    b = q1.get_nowait()
    #c = q1.get_nowait()#error, queue empty
    #d = q1

# Generated at 2022-06-12 14:06:18.044379
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put('aa')
    assert q.get_nowait() == 'aa'



# Generated at 2022-06-12 14:06:23.032968
# Unit test for method put of class Queue
def test_Queue_put():
	q = Queue(maxsize=2)

	async def consumer():
		async for item in q:
			try:
				print('Doing work on %s' % item)
				await gen.sleep(0.01)
			finally:
				q.task_done()

	async def producer():
		for item in range(5):
			await q.put(item)
			print('Put %s' % item)

	async def main():
		# Start consumer without waiting (since it never finishes).
		ioloop.IOLoop.current().spawn_callback(consumer)
		await producer()     # Wait for producer to put all tasks.
		await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-12 14:06:29.274342
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Queue should be empty
    print(q.empty())
    # put an item into the queue
    q.put_nowait(42)
    # Queue should not be empty now
    print(q.empty())
    # remove an item from the queue
    q.get_nowait()
    # Queue should be empty again
    print(q.empty())
    # Item should have been removed
    q.get_nowait()
test_Queue_get_nowait()


# Generated at 2022-06-12 14:06:37.082172
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait([5])
    if len(q._queue) != 1:
        raise Exception("put_nowait failed to add the element")
    if q._queue[0] != [5]:
        raise Exception("put_nowait failed to add the correct element")
    if q._finished.is_set():
        raise Exception("put_nowait should not have set finished")
    if q._unfinished_tasks != 1:
        raise Exception("put_nowait should have incremented task count")


# Generated at 2022-06-12 14:06:45.248055
# Unit test for method put of class Queue
def test_Queue_put():
    # Test the put method of class Queue.
    # Describe the the preconditions
    # The maxsize of q is 2
    # The queue is not full
    # The queue is empty
    q = Queue(maxsize=2)
    assert not q.full()
    assert q.empty()
    # Describe the q.put(item) process 
    # The item for the queue is putted 
    # The number of items in the queue is 1
    # The queue is not empty
    q.put(1)
    assert q.qsize() == 1
    assert not q.empty()
    # Test the if statement 
    # If the if statement is true
    # The queue is not full
    assert q.qsize() == 1
    assert not q.full()
    # Test the else statement
    # If

# Generated at 2022-06-12 14:06:49.223926
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    d = Queue(10)
    d.__put_internal(3)
    x = d.get_nowait()
    if x == 3:
        print("test passed")
    else:
        print("test failed")


# Generated at 2022-06-12 14:07:09.078885
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(1)
    q.put_nowait(10)
    assert q.get_nowait() == 10
    

# Generated at 2022-06-12 14:07:09.723990
# Unit test for method put of class Queue
def test_Queue_put():
    pass

# Generated at 2022-06-12 14:07:15.540889
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        print("Yes, Queue is Empty.")
        assert True
    else:
        assert False

# Generated at 2022-06-12 14:07:24.702952
# Unit test for method put of class Queue
def test_Queue_put():
	q = Queue(maxsize=0)
	f = Future()	
	assert f.done() == False, "test_Queue_put 1"
	try:
		q.put_nowait(1)
	except QueueFull:
		assert True, "test_Queue_put 2"
	else:
		assert False, "test_Queue_put 3"

	q = Queue(maxsize=1)
	q.put_nowait(1)
	assert q._maxsize == 1 and q._queue[0] == 1 and q._unfinished_tasks == 1 and q._finished.is_set() == False, "test_Queue_put 4"

	q = Queue(maxsize=1)
	q.put_nowait(1)

# Generated at 2022-06-12 14:07:28.036251
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
    except:
        pass
    assert q.qsize() == 1

# Generated at 2022-06-12 14:07:39.021057
# Unit test for method put of class Queue
def test_Queue_put():
        from tornado import gen
        from tornado.ioloop import IOLoop
        from tornado.queues import Queue

        q = Queue(maxsize=2)

        async def consumer():
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()

        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)

        async def main():
            # Start consumer without waiting (since it never finishes).
            IOLoop.current().spawn_callback(consumer)
            await producer()     # Wait for producer to put all tasks.
            await q.join()       # Wait for consumer to finish all tasks.
            print('Done')

# Generated at 2022-06-12 14:07:42.459833
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2


# Generated at 2022-06-12 14:07:47.857345
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False

    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True

    try:
        assert q.put_nowait(3)
    except QueueFull as e:
        assert e.args[0] == 'queue full'
    else:
        assert False

    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True


# Generated at 2022-06-12 14:07:58.284544
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

    items = [item for item in range(5)]

# Generated at 2022-06-12 14:08:04.865577
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    items = []
    for i in range(2):
        items.append(i)
    # test put_nowait
    for i in items:
        q.put_nowait(i)
    # test QueueFull exception
    try:
        for i in items:
            q.put_nowait(i)
    except QueueFull:
        print("QueueFull")



# Generated at 2022-06-12 14:08:28.890604
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    import threading
    q = Queue(maxsize=2)
    async def producer():
        for item in range(5):
            await q.put(item)
            time.sleep(0.01)
            print('Put %s' % item)
    t = threading.Thread(target = IOLoop.current().run_sync, args = (producer,))
    t.start()
    t.join()
    print("Passed!")


# Generated at 2022-06-12 14:08:39.861064
# Unit test for method put of class Queue
def test_Queue_put():
    def __init__(self, maxsize: int = 0) -> None:
        if maxsize is None:
            raise TypeError("maxsize can't be None")

        if maxsize < 0:
            raise ValueError("maxsize can't be negative")

        self._maxsize = maxsize
        self._init()
        self._getters = collections.deque([])  # type: Deque[Future[_T]]
        self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
        self._unfinished_tasks = 0
        self._finished = Event()
        self._finished.set()


# Generated at 2022-06-12 14:08:41.529460
# Unit test for method put of class Queue
def test_Queue_put():
    a = Queue(0)
    assert a._putters == collections.deque([])


# Generated at 2022-06-12 14:08:52.562583
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    f = q.put(1, timeout = None)
    assert f.result() == None
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    f = q.put(2, timeout = None)
    assert f.result() == None
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    f = q.put(3, timeout = None)
    assert f.exception() == QueueFull
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True


# Generated at 2022-06-12 14:08:57.266080
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    def consumer():
        try:
            print('Doing work on %s' % q.get_nowait())
            print('Doing work on %s' % q.get_nowait())
        except QueueEmpty:
            print("QueueEmpty")

    async def producer():
        for x in range(5):
            await q.put(x)
            print('Put %s' % x)

    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:09:05.723417
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
       

# Generated at 2022-06-12 14:09:11.959408
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    print("Testing method get_nowait of class Queue")
    queue = Queue()
    queue.put_nowait(1)
    queue.put_nowait(2)
    item1 = queue.get_nowait()
    item2 = queue.get_nowait()
    if item1 == 1 and item2 == 2:
        print("Test Pass: Successfully got items from queue")
    else:
        print("Test Fail: Didn't get items from queue")


# Generated at 2022-06-12 14:09:22.802504
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:09:27.292672
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    def method(q, item):
        q.put_nowait(item)
    q = Queue(3)
    for i in range(3):
        assert(q.full()==False)
        method(q, i)
    assert(q.full()==True)
    try:
        method(q, 3)
    except QueueFull:
        pass


# Generated at 2022-06-12 14:09:31.214533
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = Future()
    def on_timeout():
        if not future.done():
            future.set_exception(gen.TimeoutError())

    io_loop = ioloop.IOLoop.current()
    timeout_handle = io_loop.add_timeout(timeout, on_timeout)
    future.add_done_callback(lambda _: io_loop.remove_timeout(timeout_handle))
    future = Future()
    try:
        q.put_nowait(item)
    except QueueFull:
        q._putters.append((item, future))
        _set_timeout(future, timeout)
    else:
        future.set_result(None)

