

# Generated at 2022-06-12 14:01:24.504216
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    task_done_1 = Event()
    task_done_2 = Event()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
                if item == 1:
                    task_done_1.set()
                else:
                    task_done_2.set()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer

# Generated at 2022-06-12 14:01:36.167147
# Unit test for method get of class Queue
def test_Queue_get():
    # Test of method get of class Queue
    from tornado.testing import gen_test
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    if (__name__ == "__main__"):
        q = Queue(maxsize=2)
        async def consumer():
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)
        async def main():
            # Start consumer without waiting (since it never finishes).
            IOLoop.current().spawn_callback(consumer)

# Generated at 2022-06-12 14:01:39.252996
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Create a queue
    q = Queue()
    # put an item into the queue
    q.put_nowait(5)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False


# Generated at 2022-06-12 14:01:50.662942
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    myQueue = Queue(maxsize=2)
    async def consumer():
        async for item in myQueue:
            try:
                print('\nDoing work on ' + str(item))
                await gen.sleep(0.01)
            finally:
                myQueue.task_done()

    async def producer():
        for item in range(5):
            await myQueue.put(item)
            print('\nPut ' + str(item))

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await myQueue.join()       # Wait for consumer to finish

# Generated at 2022-06-12 14:01:57.247408
# Unit test for method put of class Queue
def test_Queue_put():
    #Initialization
    q = Queue()
    q.put(2)
    q.put(3)
    q.put(5)

    assert q.qsize() == 3
    assert q.full() == True
    assert q._get() == 2
    assert q._get() == 3
    assert q._get() == 5
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    q.put(7)
    q.put(11)
    assert q.qsize() == 2
    assert q.empty() == False


# Generated at 2022-06-12 14:01:59.126464
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    print('q.get() :',q.get())


# Generated at 2022-06-12 14:02:00.857785
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue
    q = Queue()
    q.put("first")
    a = q.get_nowait()
    assert a == "first"

# Generated at 2022-06-12 14:02:07.470154
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    try:
        q.put_nowait(2)
    except QueueFull:
        q.get_nowait()
        q.put_nowait(3)
        assert q.get_nowait() == 3
    else:
        assert False


# Generated at 2022-06-12 14:02:14.865430
# Unit test for method put of class Queue
def test_Queue_put():
    import tornado.testing
    import tornado.gen
    import tornado.testing
    import time

    q = Queue(maxsize=10)

    async def put_test(item: int) -> None:
        await q.put(item)

    async def put_test1(item: int) -> None:
        await q.put(item, timeout = 0.001)

    async def put_test2(item: int, delay: float) -> None:
        await q.put(item, delay)


    async def get_test() -> int:
        return await q.get()

    async def get_test1() -> int:
        return await q.get(timeout = 0.001)

    async def get_test2() -> int:
        return await q.get(delay = 0.001)


# Generated at 2022-06-12 14:02:19.371821
# Unit test for method put of class Queue
def test_Queue_put():
    print("********************begin**************")
    q = Queue(maxsize=5)
    print("task queue is empty? %s" % q.empty())
    for i in range(5):
        q.put(i)
    print("task queue is full? %s" % q.full())
    print("********************end****************")


# Generated at 2022-06-12 14:02:32.652853
# Unit test for method get of class Queue
def test_Queue_get():
    # Arrange
    q = Queue()
    # Act
    result = q.get()
    # Assert

# Generated at 2022-06-12 14:02:36.185318
# Unit test for method put of class Queue
def test_Queue_put():
  q = Queue()
  f = Future()
  result = q.put(item=1,timeout=1)
  assert f.set_result(None)
  return result


# Generated at 2022-06-12 14:02:44.374199
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen, ioloop
    from tornado.queues import Queue
    import time
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(1)
            finally:
                q.task_done()
    
    async def producer():
        for i in range(5):
            await q.put(i)
            print('Put %s' % i)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-12 14:02:54.721118
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    result = q.put("Test")
    future_set_result_unless_cancelled(result, None)
    assert q.empty() is False, "test_Queue_get: q n'est pas vide"
    result = q.put("Test2")
    future_set_result_unless_cancelled(result, None)
    assert q.empty() is False, "test_Queue_get: q n'est pas vide"
    assert q.qsize() == 2, "test_Queue_get: La taille de q est fausse"
    result = q.get()
    future_set_result_unless_cancelled(result, "Test")
    assert q.empty() is False, "test_Queue_get: q n'est pas vide"
    result = q.get()


# Generated at 2022-06-12 14:03:05.575846
# Unit test for method put of class Queue
def test_Queue_put():
    print('Executing unit test for method put of Class Queue')
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.I

# Generated at 2022-06-12 14:03:14.825524
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # @TODO: Why the two definitions of Queue?
    class Queue(collections.deque):
        maxsize = 0

        def get(self):
            if self:
                return self.popleft()
            raise QueueEmpty

    # Empty Queue
    def test_Queue_get_nowait_empty():
        q = Queue()
        try:
            q.get_nowait()
        except QueueEmpty:
            pass
        else:
            assert False, "Should raise QueueEmpty"

    # Non-Empty Queue
    def test_Queue_get_nowait_non_empty():
        q = Queue()
        q.append("item")


# Generated at 2022-06-12 14:03:24.210856
# Unit test for method put of class Queue
def test_Queue_put():
    import random

    # set up the queue
    q = asyncio.Queue(maxsize=10)
    assert q.full() is False
    assert q.empty() is True

    # add some items to the queue
    items = []
    for i in range(0, 10):
        items.append(random.randint(1, 99))
        q.put_nowait(items[i])

    assert q.full() is True
    assert q.empty() is False

    # remove the first element
    items.reverse()
    for i in range(0, len(items)):
        ritem = q.get_nowait()

        assert items[i] == ritem


# Generated at 2022-06-12 14:03:34.260028
# Unit test for method put of class Queue
def test_Queue_put():
    """
    This is a unit test for Queue.put
    """
    import datetime

    q=Queue()
    len_1=q.qsize()
    assert len_1==0
    q.put("hi")
    len_2=q.qsize()
    assert len_2==1
    q.put("hello")
    q.put("world")
    q.put("This",datetime.timedelta(seconds=2))
    q.put("is",datetime.timedelta(seconds=3))
    q.put("a",datetime.timedelta(seconds=4))
    q.put("test",datetime.timedelta(seconds=5))
    q.put("!")
    len_3=q.qsize()
    assert len_3==8


# Generated at 2022-06-12 14:03:43.389508
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:46.196515
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(2)
    q.put(5)
    assert(5 == q.get_nowait())
    assert(q.empty())


# Generated at 2022-06-12 14:04:02.460407
# Unit test for method get of class Queue

# Generated at 2022-06-12 14:04:13.226322
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def consumer():
        gen.sleep(0.1)
        try:
            print('Doing work on %s' % item)
            gen.sleep(0.01)
        finally:
            q.task_done()
    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)
    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current

# Generated at 2022-06-12 14:04:17.640780
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    assert q.qsize() == 0
    assert q.put(1, timeout=0) == None
    assert q.qsize() == 1
    assert q.put(2, timeout=0) == None
    assert q.qsize() == 1
    assert q.put(2, timeout=0) == None
    assert q.qsize() == 1


# Generated at 2022-06-12 14:04:20.543307
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    item = "test"
    q.put(item)
    assert(item == q.get_nowait())



# Generated at 2022-06-12 14:04:27.928721
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:04:37.394388
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    
    future = None
    
    future = q.put(1)
    
    print(future)
    print(q.qsize())
    print(q.full())
    print(q.empty())
    print(q)
    
    future = q.put(2)
    
    print(future)
    print(q.qsize())
    print(q.full())
    print(q.empty())
    print(q)
    
    future = q.put(3)
    
    print(future)
    print(q.qsize())
    print(q.full())
    print(q.empty())
    print(q)
    
test_Queue_put()


# Generated at 2022-06-12 14:04:45.004957
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait("abc")
        q.put_nowait("def")
        q.put_nowait("ghi")
        print("function call: put_nowait")
        print("failure")
    except QueueFull:
        print("function call: put_nowait")
        print("success")
    else:
        print("function call: put_nowait")
        print("failure")


# Generated at 2022-06-12 14:04:50.161965
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    import math
    import random
    import time 
    
    def is_sorted(l):
        return all(l[i] <= l[i+1] for i in range(len(l)-1))

    def Queue_put():
        q = Queue()
        a = []
        start = time.clock()
        while time.clock() - start < 0.5:
            num = math.ceil(random.random()*100)
            q.put(num)
            a.append(num)
        print(q)
        q.join()
        a.reverse()
        print(a)
        print(is_sorted(a))

    test = Queue_put
    test()



# Generated at 2022-06-12 14:04:55.312147
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    
    async def produce(q):
        n = 0
        while n < 5:
            n += 1
            print('put {}'.format(n))
            await q.put(n)
            await asyncio.sleep(0.5)

    async def consume(q):
        while True:
            n = await q.get()
            print('get {}'.format(n))
            q.task_done()
            await asyncio.sleep(0.2)

    q = Queue()
    loop = asyncio.get_event_loop()
    task = [
        loop.create_task(consume(q)),
        loop.create_task(produce(q))
    ]
    loop.run_until_complete(asyncio.wait(task))
    q.join()
    loop.close

# Generated at 2022-06-12 14:05:05.822225
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop

    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        # Consume items from the front of the queue.
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        # Produce items from the back of the queue.
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()    

# Generated at 2022-06-12 14:05:29.154037
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Initialize a Queue
    q = Queue()
    # Put several item into the queue
    for i in range(10):
        q.put_nowait(i)
    # Get the first item in the queue
    assert 0 == q.get_nowait()
    return

# Generated at 2022-06-12 14:05:30.560662
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.put(5) == None


# Generated at 2022-06-12 14:05:34.124591
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        q = Queue(maxsize=1)
        q.put_nowait(1)
        q.put_nowait(2)
    except QueueFull:
        pass
    try:
        q = Queue(maxsize=0)
        q.put_nowait(2)
    except QueueFull:
        pass


# Generated at 2022-06-12 14:05:44.966730
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:50.203567
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Create a Queue object
    queue = Queue()
    # Put some values into queue
    result = queue.put(1)
    # Get value from queue and return it
    value = queue.get_nowait()
    print("The value is", value)
    # Set the future result of result object as None
    result.set_result(None)


# Generated at 2022-06-12 14:05:58.474393
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    assert q.get_nowait() == 1
    q.put(2)
    assert q.get_nowait() == 2
    q.put(3)
    assert q.get_nowait() == 3
    assert q.full() == False
    q = Queue(2)
    q.put(1)
    assert q.get_nowait() == 1
    q.put(2)
    assert q.get_nowait() == 2
    q.put(3)
    assert q.full() == True
    assert q.empty() == False
    f1 = q.put(4)
    assert f1.result() == None
    assert q.empty() == False
    assert q.full() == True
    assert q.get_nowait()

# Generated at 2022-06-12 14:06:00.865404
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	q = Queue(maxsize=2)
	q.get_nowait()


# Generated at 2022-06-12 14:06:08.703336
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import pytest
    q = Queue(maxsize=2)
    # pytest.raises(QueueEmpty, q.get_nowait)
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.put_nowait(2)
    q.put_nowait(3)
    # pytest.raises(QueueFull, q.put_nowait, 4)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3


# Generated at 2022-06-12 14:06:16.245586
# Unit test for method put of class Queue
def test_Queue_put():
    import sys
    import datetime
    from random import randint
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from .random_gen import Generate_random_float, Generate_random_datetime

    @gen.coroutine
    def consumer():
        try:
            while True:
                item = yield q.get()
                try:
                    print('Doing work on %s' % item)
                    yield gen.sleep(item)
                finally:
                    q.task_done()
        except Exception as e:
            print( e )

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-12 14:06:24.538973
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        assert False
    except QueueFull:
        assert True
    q.get_nowait()
    q.get_nowait()
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        assert True

# Generated at 2022-06-12 14:06:55.209777
# Unit test for method get of class Queue
def test_Queue_get():
    cnt = 0
    # TODO: not support return an Future object
    # return_val = Queue().get()
    # if return_val == None:
    #     cnt = cnt + 1
    # return_val = Queue().get()
    # if return_val == None:
    #     cnt = cnt + 1
    # return_val = Queue().get()
    # if return_val == None:
    #     cnt = cnt + 1
    
    return_val = Queue().get()
    if isinstance(return_val,Awaitable):
        cnt = cnt + 1
    if return_val == None:
        cnt = cnt + 1
    return_val = Queue().get()
    if isinstance(return_val,Awaitable):
        cnt

# Generated at 2022-06-12 14:07:00.698198
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    print(q.get_nowait())
    print(q.get_nowait())
    try:
        q.get_nowait()
    except QueueEmpty:
        print('QueueEmpty')
    time.sleep(2)


# Generated at 2022-06-12 14:07:03.637635
# Unit test for method get of class Queue
def test_Queue_get():
    a = Queue(maxsize=2)
    a.put(1)

test_Queue_get()


# Generated at 2022-06-12 14:07:14.902226
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())

    class Foo():
        pass

    @asyncio.coroutine
    def main():
        q = Queue(maxsize=2)
        q.put(Foo())

        #nowait
        async def test_put_nowait():
            q = Queue(maxsize=2)
            q.put_nowait(Foo())

        asyncio.ensure_future(test_put_nowait())

        #timeout
        async def test_put_timeout():
            q = Queue(maxsize=2)
            await q.put(Foo(), timeout=0.5)

        asyncio.ensure_future(test_put_timeout())

   

# Generated at 2022-06-12 14:07:21.718520
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.__put_internal(item=1)
    assert q.qsize() == 1
    q.__put_internal(item=2)
    assert q.qsize() == 2
    q.put(3, timeout=1)
    assert q.qsize() == 3
    assert q.full() == True
    # q.put(4, timeout=1)
    # assert q.qsize() == 3
    # assert q.full() == True

# Generated at 2022-06-12 14:07:24.125179
# Unit test for method get of class Queue
def test_Queue_get():
    # import tornado.queues
    # q = Queue()
    # q.put('')
    # q.get()
    # q.task_done()
    # q.join()
    pass

# Generated at 2022-06-12 14:07:29.218507
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Create a new Queue object with maxsize=0
    q = Queue(maxsize=0)
    assert q.qsize() == 0
    assert not q.empty()
    assert q.full()
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:07:40.432756
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert len(q._queue) == 0
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

    q.put(1)
    assert len(q._queue) == 1
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False

    q.put(2)
    assert len(q._queue) == 2
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == False
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        pass

test_Queue_put()

#

# Generated at 2022-06-12 14:07:44.710041
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    i = 0
    q.put(i)
    i +=1
    q.put(i)
    i +=1
    assert q.get() != 1
    assert q.get() != 2
if __name__ == '__main__':
    test_Queue_get()


# Generated at 2022-06-12 14:07:54.892175
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

test

# Generated at 2022-06-12 14:08:50.535426
# Unit test for method get of class Queue
def test_Queue_get():
    #   In versions of Python without native coroutines (before 3.5),
    #   ``consumer()`` could be written as::
    #
    #       @gen.coroutine
    #       def consumer():
    #           while True:
    #               item = yield q.get()
    #               try:
    #                   print('Doing work on %s' % item)
    #                   yield gen.sleep(0.01)
    #               finally:
    #                   q.task_done()
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()



# Generated at 2022-06-12 14:09:01.135664
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    def test_Queue_put_0():
        # Put an item into the queue, perhaps waiting until there is room.
        # Returns a Future, which raises `tornado.util.TimeoutError` after a
        # timeout.
        # `timeout` may be a number denoting a time (on the same
        # scale as `tornado.ioloop.IOLoop.time`, normally `time.time`), or a
        # `datetime.timedelta` object for a deadline relative to the
        # current time.
        q.put(item=0, timeout=123)

# Generated at 2022-06-12 14:09:08.518847
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.full()
    assert q.qsize() == 0
    assert not q.empty()

    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert 0

    try:
        q.put_nowait(1)
    except QueueFull:
        pass
    else:
        assert 0


# Generated at 2022-06-12 14:09:11.711296
# Unit test for method get of class Queue
def test_Queue_get():
    q1 = Queue(maxsize=2)
    q1.put_nowait(1)
    q1.put_nowait(2)
    q1.get_nowait()
    print(q1)


# Generated at 2022-06-12 14:09:15.870875
# Unit test for method put of class Queue
def test_Queue_put():
    # Test the method put of class Queue
    m = collections.deque()
    b = Queue()
    b._queue = m
    b.put(1)
    assert b._queue == m
    assert m.popleft() == 1
    assert b.qsize() == 0


# Generated at 2022-06-12 14:09:26.368562
# Unit test for method get of class Queue
def test_Queue_get():
	import tornado
	import asyncio
	
	@tornado.gen.coroutine
	def consumer():
		queue = Queue(maxsize=2)
		async for item in queue:
			print ("Doing work on %s" % item)
			await asyncio.sleep(0.01)
			queue.task_done()
			if item == 4: break
	
	@tornado.gen.coroutine
	def producer():
		queue = Queue(maxsize=2)
		print ("Put %s" % 0)
		await queue.put(0)
		print ("Put %s" % 1)
		await queue.put(1)
		print ("Put %s" % 2)
		await queue.put(2)


# Generated at 2022-06-12 14:09:36.298882
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:09:42.631895
# Unit test for method put of class Queue
def test_Queue_put():
    import pytest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:09:50.713734
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Test for a normal case: put an item into the queue without blocking.
    # If no free slot is immediately available, raise QueueFull.
    print('Unit test for method put_nowait of class Queue')
    q = Queue(maxsize=3)
    assert q.empty() == True
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.empty() == False

    # The queue is full, so raise QueueFull.
    with pytest.raises(QueueFull):
        q.put_nowait(4)

    # The queue is empty, so we get an item and put an item.
    assert q.get_nowait() == 1
    q.put_nowait(4)

# Generated at 2022-06-12 14:09:53.982033
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(0)
        q.put_nowait(1)
        q.put_nowait(2)
    except QueueFull:
        raise Exception("method put_nowait should raise QueueFull exception")

