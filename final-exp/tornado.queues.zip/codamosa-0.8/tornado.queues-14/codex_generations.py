

# Generated at 2022-06-12 14:01:22.804403
# Unit test for method put of class Queue
def test_Queue_put():
    from mamba import describe, context, before, after, it
    from expects import expect, be_a, equal, be_true, be_false
    from expects.matchers import raise_error
    from doublex import Spy
    from doublex_expects import have_been_called, have_been_called_with
    from tornado import gen
    from tornado.ioloop import IOLoop
    import asyncio
    from tornado.queues import Queue

    with describe('Queue') as _:
        @before.each
        def _():
            def callback(future):
                gen.sleep(0.02)
                future.set_result(None)

            def get(_):
                gen.sleep(0.01)
                return 3

            _.future = Future() # type: Future[None]
            _.future.add_done_

# Generated at 2022-06-12 14:01:27.099930
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    assert q.empty() == True
    q.put_nowait(3)
    assert q.empty() == False
    assert q.full() == True
    with pytest.raises(QueueFull):
        q.put_nowait(1)



# Generated at 2022-06-12 14:01:30.461272
# Unit test for method put of class Queue
def test_Queue_put():
    import time

    q = Queue()
    try:
        q.put(0)
    except Exception:
        print("Method put of class Queue does not function properly")
        return False
    return True


# Generated at 2022-06-12 14:01:34.071332
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    try:
        q.put_nowait(1)
        assert q._queue == deque([1])
    except:
        assert False

# Generated at 2022-06-12 14:01:38.917842
# Unit test for method put of class Queue
def test_Queue_put():
    # Pass
    q = Queue()
    q.put('')
    q.put('')
    q.put('')
    # Fail
    #q.put()
    #q.put('')
    #q.put('')
    #q.put('')


# Generated at 2022-06-12 14:01:50.117113
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    assert not q.empty()
    assert q.full()
    assert q.qsize() == 2
    q.put_nowait(4)
    assert q.qsize() == 2

    try:
        q.put_nowait(4)
    except QueueFull:
        pass
    else:
        raise Exception("put_nowait should raise QueueFull when a queue is at its maximum size")

    q.get_nowait()
    assert q.qsize() == 1
    q.put_nowait(5)
    assert q.qsize() == 2

    q.task_done()
    q.task_done()
    assert q.empty()
    assert not q.full()
    assert q.qsize() == 0

test_Queue_put_now

# Generated at 2022-06-12 14:01:54.069052
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=5)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)


# Generated at 2022-06-12 14:01:58.301729
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    # End of Unit test for method get of class Queue

# Generated at 2022-06-12 14:02:10.185757
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import unittest
    from tornado.testing import gen_test, AsyncTestCase
    import tornado
    from tornado.queues import Queue, QueueFull
    from tornado.log import gen_log

    class MyTest(AsyncTestCase):
        @gen_test
        async def test_1(self):
            q = Queue(maxsize=2)
            self.assertFalse(q.full())
            q.put_nowait(4)
            q.put_nowait(2)
            self.assertTrue(q.full())
            self.assertFalse(q.empty())
            q.get()
            q.put_nowait(2)
            self.assertTrue(q.full())
            self.assertTrue(q.full())
            q.get()

# Generated at 2022-06-12 14:02:12.457193
# Unit test for method get of class Queue
def test_Queue_get():
    future = Future() # type: Future[_T]
    ioloop.IOLoop.current().run_sync(get(future, None))
    



# Generated at 2022-06-12 14:02:21.894150
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get()
    q.get()


# Generated at 2022-06-12 14:02:30.036436
# Unit test for method get of class Queue
def test_Queue_get():
    # Test that Queue.get returns a Future that can be used with await.
    q = Queue()
    q.put_nowait(42)
    assert q.get() == 42 # test if get return an item of the queue
    assert q.qsize() == 0 # test if the size of the queue is 0
    # test if get_nowait raise an exception if the queue is empty
    try:
        q.get_nowait()
        assert False # this should only be executed if get_nowait didn't raise an Exception
    except QueueEmpty:
        assert True
    # test if the getter's queue is filled after putting an item
    q.put(42)
    assert q.get() == 42 # test if get return an item of the queue
    assert q.qsize() == 0 # test if the size of the queue is 0

# Generated at 2022-06-12 14:02:41.426486
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import tornado
    #test Queue.put_nowait(self, item: _T) -> None
    class TestQueue(unittest.TestCase):
        def test_Queue_put_nowait(self):
            tornado.ioloop.IOLoop.current().run_sync(self.test_Queue_put_nowait)
        @tornado.gen.coroutine
        def test_Queue_put_nowait(self):
            q = Queue()
            self.assertEqual(q.put_nowait(1), None)
            q.put(2)
            self.assertEqual(len(q._getters), 0)
            self.assertEqual(len(q._putters), 0)
            self.assertEqual(q.get_nowait(), 1)

# Generated at 2022-06-12 14:02:42.019365
# Unit test for method put of class Queue
def test_Queue_put():
	pass
	

# Generated at 2022-06-12 14:02:46.407892
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado.ioloop
    import time
    import tornado.gen
    import random
    import tornado.concurrent


    q = Queue(0)
    
    
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    
    async def consumer():
        while True:
            item = await q.get()
            print('Doing work on %s' % item)
    
    
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        # Wait for producer to put all tasks.
        await producer()     
        # Wait for consumer to finish all tasks.
        await q.join()       
        print

# Generated at 2022-06-12 14:02:52.642052
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=2)
    queue.put_nowait(1)
    queue.put_nowait(2)
    if not queue.full():
        #The size of the queue is no more than 2
        assert False
    try:
        queue.put_nowait(3)
    except:
        assert True
        #The size of the queue can not be bigger than its maxsize
        return
    assert False


# Generated at 2022-06-12 14:02:53.272940
# Unit test for method put of class Queue
def test_Queue_put():
    pass



# Generated at 2022-06-12 14:02:55.507523
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    try:
        q.get()
    except:
        pass
    else:
        assert False

# Generated at 2022-06-12 14:02:59.128892
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
   # queue.Queue(maxsize) 
   # Put an item into the queue without blocking.
   # If no free slot is immediately available, raise QueueFull.
   
    size = 3
    q = Queue(size)
    
    for i in range(size):
        q.put_nowait(i)
    
    # check full
    try:
        q.put_nowait(0)
    except QueueFull:
        print("full")


# Generated at 2022-06-12 14:03:02.438788
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(item=1)
    q.put(item=2)
    q.put(item=3)
    q.put(item=4)
    
    

# Generated at 2022-06-12 14:03:14.699865
# Unit test for method get of class Queue
def test_Queue_get():
    for t in range(4):
        q = Queue(t)
        for i in range(t):
            q.put_nowait(0)
        try:
            q.put_nowait(0)
        except QueueFull:
            assert(True)

    for t in range(4):
        q = Queue(t)
        for i in range(t):
            assert q.get_nowait() == 0
        try:
            q.get_nowait()
        except QueueEmpty:
            assert(True)
    assert(True)



# Generated at 2022-06-12 14:03:25.144106
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine

    @coroutine
    def test_coroutine(self):
        from tornado import gen
        from tornado.ioloop import IOLoop
        from tornado.queues import Queue

        @gen.coroutine
        def consumer():
            while True:
                item = yield q.get()
                try:
                    yield gen.sleep(0.1)
                finally:
                    q.task_done()

        @gen.coroutine
        def producer():
            for item in range(5):
                yield q.put(item)
                yield gen.sleep(0.1)

        q = Queue(maxsize=2)
        IOLoop.current().spawn_callback(consumer)

# Generated at 2022-06-12 14:03:32.624269
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.empty() is True
    assert q.full() is False
    q.put_nowait(1)
    assert q.empty() is False
    assert q.full() is False
    q.put_nowait(2)
    assert q.empty() is False
    assert q.full() is True
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    assert q.empty() is False
    assert q.full() is True



# Generated at 2022-06-12 14:03:41.614959
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:03:50.733343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:53.311786
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait('hello')
    assert q.get_nowait() == 'hello'


# Generated at 2022-06-12 14:04:03.476250
# Unit test for method put of class Queue
def test_Queue_put():
    async def foo(q):
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        q.put(5)
        q.put(6, timeout=10)
        q.put_nowait(7)
        q.get()
        q.get_nowait()
        q.task_done()
        q.join(timeout=10)
        async for i in q:
            print(i)
        print("q", q)
        print("q.maxsize", q.maxsize)
        print("q.qsize", q.qsize())
        print("q.empty", q.empty())
        print("q.full", q.full())
    q = Queue(maxsize=10)

# Generated at 2022-06-12 14:04:13.782196
# Unit test for method put of class Queue
def test_Queue_put():

    q = Queue(maxsize=2)
    # __main__
    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    # __main__
    async def producer():
        for item in range(10):
            await q.put(item)
            print('Put %s' % item)
            await gen.sleep(0.01)
    q
    ioloop.IOLoop.current().start()
    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().run_sync(producer)



# Generated at 2022-06-12 14:04:20.821575
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import asyncio
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full() == True
    try:
        q.put_nowait(3)
    except QueueFull:
        assert q.full() == True
        q.get_nowait()
    assert q.put_nowait(3) == None
    assert q.put_nowait(4) == None
    assert q.put_nowait(5) == None
    assert q.full() == True

# Generated at 2022-06-12 14:04:28.174938
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import unittest

    from tornado.queues import Queue, QueueEmpty

    class MyTestCase(unittest.TestCase):
        def test_Queue_put(self):
            q = Queue(maxsize=3)
            q.put(1)
            q.put(2)
            q.put(3)
            print(q.qsize())
            q.put(4)
            q.put(5)
            q.put(6)
            print(q.qsize())
            assert q.empty() == False
            assert q.full() == True
            try:
                q.put_nowait(7)
                assert 1 is not None
            except QueueFull:
                pass
            try:
                q.get_nowait()
            except QueueEmpty:
                pass

# Generated at 2022-06-12 14:04:47.507979
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:04:58.246642
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:08.252199
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=10)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(50):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:09.327896
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.get()


# Generated at 2022-06-12 14:05:11.699308
# Unit test for method get of class Queue
def test_Queue_get():
    # Init a Queue instance
    q = Queue()
    # Test if q is an instance of Queue
    assert isinstance(q, Queue)
    # Test get method
    assert isinstance(q.get(), Awaitable)



# Generated at 2022-06-12 14:05:13.333987
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get() == 1

# Generated at 2022-06-12 14:05:18.982244
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try :
        q.get_nowait()
    except QueueEmpty:
        print("ok1")

    q.put_nowait(100)
    q.put_nowait(200)
    try:
        q.put_nowait(300)
    except QueueFull:
        print("ok2")

    assert q.get_nowait() == 100, "Not correct result"
    assert q.get_nowait() == 200, "Not correct result"

    try:
        q.get_nowait()
    except QueueEmpty:
        print("ok3")


# Generated at 2022-06-12 14:05:25.535353
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    #     """Remove and return an item from the queue without blocking.
    #
    #     Return an item if one is immediately available, else raise
    #     `QueueEmpty`.
    #     """
    #     self._consume_expired()
    #     if self._putters:
    #         assert self.full(), "queue not full, why are putters waiting?"
    #         item, putter = self._putters.popleft()
    #         self.__put_internal(item)
    #         future_set_result_unless_cancelled(putter, None)
    #         return self._get()
    #     elif self.qsize():
    #         return self._get()
    #     else:
    #         raise QueueEmpty
    pass


# Generated at 2022-06-12 14:05:30.739077
# Unit test for method get of class Queue
def test_Queue_get():
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop = ioloop.IOLoop.current()
        io_loop.spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    q = Queue(maxsize=2)
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync

# Generated at 2022-06-12 14:05:32.499116
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    assert q.get_nowait() == 1



# Generated at 2022-06-12 14:05:56.714439
# Unit test for method put of class Queue
def test_Queue_put():
    print("--- start test_Queue_put ---")

    from tornado import gen, ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    io_loop = ioloop.IOLoop.current()

    # define a consumer function
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    # define a producer function
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    # define a main function
    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback

# Generated at 2022-06-12 14:06:08.016561
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:06:12.196757
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)

# Generated at 2022-06-12 14:06:18.561108
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Unit test

# Generated at 2022-06-12 14:06:19.918192
# Unit test for method get of class Queue
def test_Queue_get():
    print()



# Generated at 2022-06-12 14:06:26.636421
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # type: () -> None
    """Unit test for `get_nowait`."""
    q = Queue()
    assert q.empty()
    q._queue.append("test")
    assert q.get_nowait() == "test"
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    q.put_nowait("test2")
    assert q.get_nowait() == "test2"



# Generated at 2022-06-12 14:06:35.532950
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.maxsize == 2
    assert q.empty() == True

    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            q.put(item)

    def main():
        ioloop.IOLoop.current().spawn_callback(consumer)
        producer()
        q.join()
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:06:36.781481
# Unit test for method get of class Queue
def test_Queue_get():
    assert True == True


# Generated at 2022-06-12 14:06:45.068099
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    queue_maxsize = q.maxsize
    queue_size = q.qsize()
    queue_empty = q.empty()
    queue_full = q.full()
    q.put_nowait("123")
    q.put_nowait("456")
    if q.qsize() != 2:
        print("q.qsize() != 2")
    if not q.full():
        print("q.full() == false")
    if q.empty():
        print("q.empty() == true")
    q.get_nowait()
    if not q.empty():
        print("q.empty() == false")
    if q.full():
        print("q.full() == true")
    q.get_nowait()

# Generated at 2022-06-12 14:06:45.935381
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()
    assert True


# Generated at 2022-06-12 14:07:13.700142
# Unit test for method get of class Queue
def test_Queue_get():
    class myQueue(Queue):
        def __init__(self):
            self.queue = []
        def qsize(self):
            return len(self.queue)
        def _put(self, item):
            self.queue.append(item)
        def _get(self):
            if self.empty():
                raise QueueEmpty
            return self.queue.pop()
    import random
    import time
    import traceback
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.locks import Event
    from tornado.concurrent import Future
    from tornado.testing import AsyncTestCase, gen_test

# Generated at 2022-06-12 14:07:21.927317
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time
    import random
    def get_instance():
        q = Queue()
        q.put_nowait(2)
        return q
    q = get_instance()
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(2)
    q.put_nowait(2)
    q.put_nowait(4)
    for i in range(10000):
        q.put_nowait(random.randint(0,i))
    print(q)
test_Queue_put_nowait()

# Generated at 2022-06-12 14:07:29.131519
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Case 1: normal case
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except Exception:
        pass
    # Case 2: maxsize is 0
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    return True

# Generated at 2022-06-12 14:07:34.686137
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    print(str(q))
    # Start consumer without waiting (since it never finishes).
    #IOLoop.current().spawn_callback(consumer)
    #await producer()     # Wait for producer to put all tasks.
    #await q.join()       # Wait for consumer to finish all tasks.
    #print('Done')

test_Queue_get()


# Generated at 2022-06-12 14:07:45.919289
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    print(q)
    print(q.maxsize)
    print(type(q))

    async def consumer():
        print("consumer")
        async for item in q:
            try:
                print("Doing work on {}".format(item))
                # await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        print("producer")
        for item in range(5):
            await q.put(item)
            print("Put {}".format(item))
        print(q)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.

# Generated at 2022-06-12 14:07:52.581285
# Unit test for method put of class Queue
def test_Queue_put():
    @gen.coroutine
    def test():
        q = Queue()
        q.put(2)
        assert q.get_nowait() == 2
        q.put(4)
        assert q.get_nowait() == 4
        q.put(6)
        assert q.get_nowait() == 6
        q.put(8)
        assert q.get_nowait() == 8
    ioloop.IOLoop.current().run_sync(test)



# Generated at 2022-06-12 14:07:58.502187
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(4)
        assert False
    except:
        pass
    assert q.qsize() == 2
    assert not q.empty()
    assert q.full()

# Generated at 2022-06-12 14:08:01.048561
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    q.get()
    return

# Generated at 2022-06-12 14:08:11.108833
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:08:11.674533
# Unit test for method get of class Queue
def test_Queue_get():
    pass



# Generated at 2022-06-12 14:08:52.290727
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    queue._put(1)
    assert queue._queue is not None
    assert len(queue._queue) == 1
    assert queue._unfinished_tasks == 1
    queue._put(2)
    assert len(queue._queue) == 2
    assert queue._unfinished_tasks == 2
    assert queue._finished.is_set()



# Generated at 2022-06-12 14:09:02.467142
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    
    # 0
    if not q.empty():
        print("Error: The queue is not empty")
    try:
        q.get_nowait()
        print("Error: You can get an item from an empty queue")
    except QueueEmpty:
        pass
    except Exception as e:
        print("Error:", e)
    # 1
    q.put_nowait(1)
    if q.empty():
        print("Error: The queue is empty")
    try:
        if q.get_nowait() != 1:
            print("Error: You did get the right item")
    except Exception as e:
        print("Error:", e)
    # 2
    q.put_nowait(2)
    if q.empty():
        print("Error: The queue is empty")

# Generated at 2022-06-12 14:09:07.646356
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    # print(q.put(0))
    # print(q.put(1))
    # print(q.put(2))
    # print(q.put(3))
    # print(q.get())
    # print(q.get())
    # print(q.get())
    # print(q.get())


# Generated at 2022-06-12 14:09:15.914860
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q._init()
    q._putters = collections.deque([])
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    future = Future()
    try:
        q.put_nowait(3)
    except QueueFull:
        q._putters.append((3, future))
        if isinstance(0, datetime.timedelta):
            timeout = 0
        else:
            timeout = 0
        _set_timeout(future, timeout)
    else:
        future.set_result(None)
    return future


# Generated at 2022-06-12 14:09:26.414364
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print("Done")

# Generated at 2022-06-12 14:09:33.892815
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = q.put('Mary')
    f.add_done_callback(on_done)
    q.put_nowait('had')
    q.put_nowait('a')
    q.put_nowait('little')
    q.put_nowait('lamb.')

    try:
        f.result()
    except QueueFull:
        print('Unable to put Mary into the queue')

    try:
        q.put_nowait('Its')
    except QueueFull:
        print('Queue is full')


# Generated at 2022-06-12 14:09:41.449345
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=6)
    # Case 1: Put item when the queue is empty
    q.put_nowait(3)
    assert q.qsize() == 1
    assert q.empty() == False
    # Case 2: Put item when the queue is full
    for i in range(5):
        q.put_nowait(i)
    try:
        q.put_nowait(1)
    except:
        assert q.full() == True
        assert q.qsize() == 6
    # Case 3: Put item when the queue has getters.
    q.task_done()
    q.task_done()
    assert q.qsize() == 4
    future = Future()
    q._getters.append(future)
    q.put_nowait(3)

# Generated at 2022-06-12 14:09:42.917595
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:09:48.154487
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """
        Test function for unit testing of Queue class.
        Params:
            item: item in queue
    """
    q = Queue(maxsize = 1)
    try:
        q.put_nowait(1)
        assert q.qsize() == 1
        assert q._queue.popleft() == 1
        assert q.qsize() == 0
        assert q._unfinished_tasks == 1
    except QueueFull:
        assert False


# Generated at 2022-06-12 14:09:56.478874
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')