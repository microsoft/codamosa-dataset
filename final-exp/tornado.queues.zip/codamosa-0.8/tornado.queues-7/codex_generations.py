

# Generated at 2022-06-12 14:01:34.070266
# Unit test for method put of class Queue
def test_Queue_put():
    import tornado.ioloop
    from tornado.queues import Queue
    from tornado import gen
    import time
    import asyncio
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                print('Doing task done on %s' % item)
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    tornado.ioloop.I

# Generated at 2022-06-12 14:01:44.500994
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import random
    async def add():
        async with q.get() as item:
            print(f"add: {item}")
            await asyncio.sleep(random.random())
            q.task_done()
    async def run():
        await q.join()
        print("Done.")
    # Other methods such as join, put, get_nowait, etc.
    q = asyncio.Queue()
    for i in range(0,3):
        q.put_nowait(i)
    for i in range(0,3):
        q.put_nowait("test")
    asyncio.run(asyncio.gather(run(), add()))
    print(q.qsize())
if __name__ == '__main__':
    test_Queue_get()


# Generated at 2022-06-12 14:01:45.277006
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-12 14:01:53.777444
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    future = Future()
    queue.put(1)
    assert queue._queue == deque([1])
    assert queue._unfinished_tasks == 1

    queue.put(2,timeout=0.1)
    assert queue._queue == deque([1,2])
    assert queue._unfinished_tasks == 2

    queue._putters.append((3,future))
    queue.put(3)
    assert queue._queue == deque([1,2,3])
    assert queue._unfinished_tasks == 3
    assert queue._putters == deque([])


# Generated at 2022-06-12 14:01:58.813433
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.empty()
    assert not q.full()
    q.put_nowait(0)
    assert not q.empty()
    assert not q.full()
    q.put_nowait(1)
    assert not q.empty()
    assert not q.full()
    q.put_nowait(2)
    assert not q.empty()
    assert not q.full()
    q.put_nowait(3)
    assert not q.empty()
    assert not q.full()


# Generated at 2022-06-12 14:02:01.946691
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # The queue is empty, queue.Empty should be raised
    test_try_catch(q.get_nowait,'.QueueEmpty')


# Generated at 2022-06-12 14:02:05.118893
# Unit test for method get of class Queue
def test_Queue_get():
    q=Queue()
    q.put_nowait(1)
    q.get()


# Generated at 2022-06-12 14:02:09.620451
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
  q = Queue()
  print("Unit test for method get_nowait of class Queue")
  result = q.get_nowait()
  # The exception is not being caught when we call get_nowait meaning that it works properly

test_Queue_get_nowait()


# Generated at 2022-06-12 14:02:19.831733
# Unit test for method put of class Queue
def test_Queue_put():
    import sys
    import os
    
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    
    from queue import Queue
    
    
    
    def test_Queue_put_0():
        q = Queue(1)
        
        try:
            q.put(1)
            q.put(2)
        except QueueFull as e:
            assert(True)
        else:
            assert(False)
    
    def test_Queue_put_1():
        q = Queue(maxsize=1)
        
        try:
            q.put_nowait(1)
            q.put_nowait(2)
        except QueueFull as e:
            assert(True)

# Generated at 2022-06-12 14:02:20.533844
# Unit test for method get of class Queue
def test_Queue_get():
    return None


# Generated at 2022-06-12 14:02:37.668893
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    """
    test put_nowait function of class Queue
    """
    q = Queue(2)
    q.put_nowait(5)
    q.put_nowait(6)
    try:
        q.put_nowait(7)
    except Exception:
        pass

# Generated at 2022-06-12 14:02:44.267230
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    # mock the function
    def mock_future_set_result_unless_cancelled(getter, return_value):
        print("Task " + str(return_value) + "started")

    from unittest import mock

# Generated at 2022-06-12 14:02:51.441261
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado.queues import Queue
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)
    q.put(5)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5


# Generated at 2022-06-12 14:02:56.295419
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Tests the Queue class method put_nowait.

    q = Queue()
    assert q.qsize() == 0

    q.put_nowait(1)
    assert q.qsize() == 1

    q.put_nowait(2)
    assert q.qsize() == 2

    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert False



# Generated at 2022-06-12 14:03:01.024441
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    print(q.empty())
    print(q.full())
    q.put(1)
    q.put(2)
    print(q.qsize())
    q.get_nowait()
    print(q.qsize())


# Generated at 2022-06-12 14:03:04.501624
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize = 1)
    q.put(10,timeout = 1)
    q.put(10,timeout = 1)
    q.put(10,timeout = 1)


# Generated at 2022-06-12 14:03:14.151068
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    IOLoop.current().spawn_callback(consumer)
    q.put(1, timeout=10)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    q.put(2, timeout=10)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    q.get(timeout=10)
   

# Generated at 2022-06-12 14:03:17.365082
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    '''
    Test function for method get_nowait of class Queue
    '''
    # Create a queue for testing
    q = Queue(maxsize=10)
    
    q.get_nowait() # Test normal run
    

# Generated at 2022-06-12 14:03:20.148587
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado.queues
    queue = tornado.queues.Queue()
    # first test, queue is empty
    print(queue.get_nowait())

# Generated at 2022-06-12 14:03:24.723497
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert None, "Queue should be full"
    except QueueFull:
        pass


# Generated at 2022-06-12 14:03:42.315738
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    q.put_nowait('aaa')
    q.put_nowait('bbb')
    assert q.qsize() == 2
    assert q.empty() == False
    get_item = q.get_nowait()
    assert get_item == 'aaa'
    assert q.qsize() == 1
    assert q.empty() == False

# Generated at 2022-06-12 14:03:47.166191
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # cls: Queue, item: int
    q = Queue()
    q.put_nowait(0)
    q.put_nowait(1)
    item1 = q.get_nowait()
    q.put_nowait(2)
    item2 = q.get_nowait()
    item3 = q.get_nowait()
    print('the item1 is:', item1)
    print('the item2 is:', item2)
    print('the item3 is:', item3)
    item4 = q.get_nowait()


# Generated at 2022-06-12 14:03:56.810467
# Unit test for method get of class Queue
def test_Queue_get():
    """Test method `get` of class Queue.
    """
    import time
    import tornado
    import tornado.ioloop
    import tornado.queues

    q = tornado.queues.Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await tornado.gen.sleep(0.01)
            q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       #

# Generated at 2022-06-12 14:04:07.878468
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    q.put_nowait(3)
    assert q.qsize() == 3
    # A Queue can have a maximum size if it is initialized with maxsize
    q2 = Queue(maxsize=2)
    assert q2.qsize() == 0
    q2.put_nowait(1)
    assert q2.qsize() == 1
    q2.put_nowait(2)
    assert q2.qsize() == 2
    q2.put_nowait(3)
    assert q2.qsize() == 2

# Generated at 2022-06-12 14:04:08.743173
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-12 14:04:17.718870
# Unit test for method put of class Queue
def test_Queue_put():
    # Define a function to test the method put of class Queue
    q = Queue()
    q.put(1)
    # The method put() should return True
    q.put(2)
    # The method put() should return True
    q.put(3)
    # The method put() should return True
    assert q.qsize() == 3 # The method get() should return True
    q.get()
    assert q.qsize() == 2 # The method get() should return True
    q.get()
    assert q.qsize() == 1 # The method get() should return True
    q.get()
    assert q.qsize() == 0 # The method get() should return True

"""
Unit test code for Queue
"""
test_Queue_put()
print("Test finished")


# Generated at 2022-06-12 14:04:19.960850
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=5)
    for i in range(5):
        queue.put_nowait(i)

    for i in range(5):
        print(queue.get_nowait())


# Generated at 2022-06-12 14:04:24.993101
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import typing
    Q = Queue()
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    isinstance(Q, typing.Sized)
    isinstance(Q, typing.Iterable)
    isinstance(Q, typing.Awaitable)
    assert Q.qsize() == 0
    assert Q.empty() == True
    Q.put_nowait(1)
    assert Q.get_nowait() == 1
    Q.task_done()

# Generated at 2022-06-12 14:04:26.641372
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.empty()
    assert q.get_nowait() == None


# Generated at 2022-06-12 14:04:32.332679
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:04.963068
# Unit test for method get of class Queue
def test_Queue_get():    
    a = Queue()
    b = Queue()
    c = Queue()
    d = Queue()

    a.get(4)
    b.get(None)
    c.get(3.3)

    a.get_nowait()
    b.get_nowait()
    c.get_nowait()
    d.get_nowait()

    a.task_done()
    b.task_done()
    c.task_done()

    a.join(5)
    b.join(4)
    c.join()
    d.join(1)

# Generated at 2022-06-12 14:05:06.862088
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put('hello world')
    print(future.done())

# Generated at 2022-06-12 14:05:10.241807
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass
    print("Success Queue put_nowait")


# Generated at 2022-06-12 14:05:19.545052
# Unit test for method put of class Queue
def test_Queue_put():

    import asyncio
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    a = Queue(maxsize=3)

    def test2():
        print('doing work: ', item)
        a.task_done()
        print('done')

    def test1():

        for item in range(5):
            a.put(item)
            print('put ', item)
            
            if item == 3:
                IOLoop.current().spawn_callback(test2)

    async def main():
        # Start consumer without waiting (since it never finishes).
        a.join()  # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:05:27.128850
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    queue = Queue()

    @gen.coroutine
    def f():
        print("Put in")
        yield queue.put("hello")
        print("Put out")

    @gen.coroutine
    def g():
        print("Get in")
        x = yield queue.get()
        print("Get out")
        print(x)

    IOLoop.current().spawn_callback(g)
    IOLoop.current().spawn_callback(f)

    IOLoop.current().start()

# Unit test of class Queue

# Generated at 2022-06-12 14:05:34.695332
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import ioloop
    from tornado.queues import Queue
    import time
    import threading
    import random
    import os

    # Single-threaded timing test of Queue.put()

    q = Queue(maxsize=1000)
    q_time = 0
    for i in range(1000):
        t1 = time.time()
        q.put_nowait(i)
        q.get_nowait()
        t2 = time.time()
        q_time += (t2-t1)
    q_time /= 1000

    # Single-threaded timing test of Queue.join()

    q_join_time = 0
    for i in range(1000):
        q = Queue(maxsize=1000)
        t1 = time.time()
        q.join()
        t

# Generated at 2022-06-12 14:05:41.673523
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    
    def consumer():
        item = q.get()
        try:
            print('Doing work on %s' % item)
            time.sleep(0.01)
        finally:
            q.task_done()
    
    producer()
    IOLoop.current().spawn_callback(consumer)
    await q.join()  
    print('Done')
Queue.get.__code__.co_varnames


# Generated at 2022-06-12 14:05:49.369132
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import tornado
    q = Queue()
    # put_nowait(item)
    #
    # Put an item into the queue without blocking.
    #
    # If no free slot is immediately available, raise QueueFull.
    #
    #
    # Please note the difference between Queue.put(item) and Queue.put_nowait(item),
    #
    # (1) Queue.get(item) 会返回一个asyncio.tasks.Future 对象， 并在该队列有空位时可能会一直阻塞。
    # (2) Queue.get_nowait() 会立刻返回队列中的

# Generated at 2022-06-12 14:05:57.879586
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    res1 = q.get_nowait()
    q.put_nowait(4)
    res2 = q.get_nowait()
    res3 = q.get_nowait()
    q.put_nowait(5)
    res4 = q.get_nowait()
    try:
        res5 = q.get_nowait()
    except:
        pass
    assert res1 == 1
    assert res2 == 2
    assert res3 == 3
    assert res4 == 4
    assert res1 == 1
    assert res2 == 2
    assert res3 == 3
    assert res4 == 4

# Generated at 2022-06-12 14:06:09.157535
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    maxsize=2

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:06:59.513790
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    f = Future()
    q._putters.append((1, f))
    print(q._putters)
    q.put_nowait(1)
    print(q._putters)


# Generated at 2022-06-12 14:07:11.111955
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.empty() == True
    for i in range(10):
        q.put_nowait(i)
        print(q.qsize())
        print(q)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 10
    assert q.maxsize == 0
    q.task_done()
    q.put_nowait(11)
    assert q.qsize() == 11
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    q.task_done()
    
    while not q.empty():
        q.get_nowait()
        print(q.qsize())
        print(q)


# Generated at 2022-06-12 14:07:15.115360
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("Queue is full!")

# Generated at 2022-06-12 14:07:20.394047
# Unit test for method get of class Queue
def test_Queue_get():
    question = Queue(maxsize=2)
    future = Future()
    timeout  = None
    assert question.get(timeout) == future.result()
    assert question.get(timeout, None) == future.result(None)
    assert question.get(timeout, timeout) == future.result(timeout)
    assert question.get(timeout, ) == future.result( )


# Generated at 2022-06-12 14:07:21.047106
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass

# Generated at 2022-06-12 14:07:23.264220
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    test = "blah"
    future = q.put(test)
    assert(test == future._result)



# Generated at 2022-06-12 14:07:28.463179
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert False


# Generated at 2022-06-12 14:07:36.858427
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    test_queue = Queue()
    assert len(test_queue._getters) == 0
    assert len(test_queue._putters) == 0
    test_queue._queue.append(30)
    assert len(test_queue._queue) == 1
    test_queue._unfinished_tasks = 1
    test_queue._finished.clear()
    assert test_queue.get_nowait() == 30
    assert len(test_queue._queue) == 0
    assert test_queue._unfinished_tasks == 0
    assert test_queue._finished.is_set() is True


# Generated at 2022-06-12 14:07:47.855814
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    async def consumer(q):
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()


    async def producer(q):
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        loop = asyncio.get_running_loop()
        loop.create_task(consumer(q))

        await producer(q)     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


    q = Queue()

# Generated at 2022-06-12 14:07:58.155074
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test with empty queue
    # Test before any put
    q = Queue()
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    # Test after put_nowait
    q.put_nowait(1)
    q.get_nowait()
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    # Test after put
    q.put(1)
    q.get()
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    # Test with non-empty queue
    q.put_nowait(1)
    q.get_nowait()
    q.put_nowait(2)
    q.get_nowait()
    q.put_nowait(3)
    q.get_now

# Generated at 2022-06-12 14:09:00.799263
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado.ioloop
    import tornado.queues
    import logging

    q = tornado.queues.Queue()

    async def consumer():
        while True:
            item = await q.get()
            try:
                logging.info(f"Doing work on {item}")
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            logging.info(f"Put {item}")

    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-12 14:09:07.515239
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import asyncio
    q = Queue(maxsize=2)
    # Start consumer without waiting (since it never finishes).
    def consumer():
        async for item in q:
            print('Doing work on %s' % item)
    asyncio.run(consumer)
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    asyncio.run(producer())     # Wait for producer to put all tasks.
    await q.join()       # Wait for consumer to finish all tasks.
    print('Done')

# Generated at 2022-06-12 14:09:12.706734
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=0)
    try:
        q.get_nowait()
        assert(False)
    except QueueEmpty:
        pass
    q.put_nowait(1)
    assert(q.get_nowait() == 1)
    try:
        q.get_nowait()
        assert(False)
    except QueueEmpty:
        pass


# Generated at 2022-06-12 14:09:15.018699
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put("hi")
    assert (q.qsize() == 1)


# Generated at 2022-06-12 14:09:18.064894
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    assert q.empty() == True
    q.put_nowait(1)
    assert q.empty() == False


# Generated at 2022-06-12 14:09:21.472410
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    if q.qsize() == 0:
        q.put_nowait(1)
    if q.qsize() == 1:
        q.put_nowait(2)


# Generated at 2022-06-12 14:09:27.417771
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    f1 = Future()
    f2 = Future()
    q._getters.append(f1)
    q._getters.append(f2)
    assert q._getters == collections.deque([f1, f2])

    q._queue.append(1)
    q._queue.append(2)
    assert  q._queue == collections.deque([1, 2])
    assert q.get() == 1

# Generated at 2022-06-12 14:09:32.041693
# Unit test for method put of class Queue
def test_Queue_put():
    q=Queue()
    res=q.put(1)
    print(res)
    res=q.put(2)
    print(res)
    res=q.put(3)
    print(res)
#test_Queue_put()
#test_Queue_put()


# Generated at 2022-06-12 14:09:33.359874
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    Queue()
    # Nothing to test



# Generated at 2022-06-12 14:09:41.091605
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    def consumer():
        for item in range(1, 6):
            print('Doing work on %s' % item)
            item = q.get_nowait()
            q.task_done()

    def producer():
        for i in range(5):
            q.put_nowait(i)
            print('Put %s' % i)

    IOLoop.current().spawn_callback(consumer)
    IOLoop.current().spawn_callback(producer)
    IOLoop.current().run_sync(lambda : print("DONE!"))

if __name__ == "__main__":
    test_Queue_put()