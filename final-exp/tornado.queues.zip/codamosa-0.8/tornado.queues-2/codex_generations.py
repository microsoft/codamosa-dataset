

# Generated at 2022-06-12 14:01:30.955386
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
   
    async def consumer():
        try:
            while True:
                item = await q.get()
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()
        except:
            pass

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        ioloop = IOLoop.current()
        ioloop.spawn_callback(consumer)
        await producer()    
        await q.join()      
        print('Done')

    ioloop = IOLoop.current()
    ioloop.run_sync(main)

# Generated at 2022-06-12 14:01:38.455254
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    status_list = []
    def callback(_):
        status_list.append(1)
    def callback1(_):
        status_list.append(2)
    f = q.put(1)
    f.add_done_callback(callback)
    f = q.put(2)
    f.add_done_callback(callback1)
    assert status_list == [1,2]

# Generated at 2022-06-12 14:01:42.529773
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    flag = False
    def on_timeout():
        flag = True
    io_loop = ioloop.IOLoop.current()
    timeout_handle = io_loop.add_timeout(0.1, on_timeout)
    q.put(5, 0.1)
    assert flag == True


# Generated at 2022-06-12 14:01:45.102770
# Unit test for method get of class Queue
def test_Queue_get():
    # moke testing
    try:
        Queue().get(timeout=3)
    except gen.TimeoutError:
        pass

# Generated at 2022-06-12 14:01:47.048878
# Unit test for method get of class Queue
def test_Queue_get():
    assert True
    # TODO:
    # not yet implemented.

# Generated at 2022-06-12 14:01:50.161207
# Unit test for method get of class Queue
def test_Queue_get():
  q = Queue(maxsize=1)
  r = q.get(timeout=9999)
  r.result()
test_Queue_get()



# Generated at 2022-06-12 14:01:58.399492
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize = 2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:02:04.324949
# Unit test for method put of class Queue
def test_Queue_put():
    item = 1
    q = Queue(max_size=2)
    q.__put_internal(item)

    assert q.qsize() == 1
    assert item == q._get()

    q.task_done()
    q._finished.wait(timeout=1)
    assert q._unfinished_tasks == 0

# Generated at 2022-06-12 14:02:13.338799
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:02:16.710257
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    t = time.time()
    q = Queue()
    def put_item():
        q.put_nowait(1)
        q.put_nowait(1)
        q.put_nowait(1)
        q.put_nowait(1)
    put_item()
    q.qsize()
    print(time.time()-t)

test_Queue_put_nowait()



# Generated at 2022-06-12 14:02:37.623170
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Queue 队列中放入一个元素，不阻塞
    q = Queue(maxsize=2)
    # 先把队列填满
    q.put_nowait(1)
    q.put_nowait(2)
    # 再加就报错
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass
    # 出队列一个
    q.get_nowait()
    # 再加就不报错
    q.put_nowait(3)

# Generated at 2022-06-12 14:02:41.050322
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False
    except QueueFull:
        pass


# Generated at 2022-06-12 14:02:41.632378
# Unit test for method put of class Queue
def test_Queue_put():
    assert True



# Generated at 2022-06-12 14:02:44.201681
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
    except QueueEmpty:
        pass
    assert q.empty() == False
    assert q.get_nowait() == 1
    assert q.empty() == True
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    assert q.empty() == True

# Generated at 2022-06-12 14:02:54.513504
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import unittest

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue


    class TestQueuePut(unittest.TestCase):
        @gen.coroutine
        def producer(self, q, n):
            for i in range(1, n + 1):
                yield q.put(i)
                print("Produced %d from %s" % (i, id(q)))
                self.assertEquals(i, q.qsize())
                yield gen.sleep(0.01)
            #print("Producer done for %s" % id(q))

        @gen.coroutine
        def consumer(self, q):
            while True:
                item = yield q.get()

# Generated at 2022-06-12 14:02:56.242377
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    with pytest.raises(QueueEmpty):
        result = Queue()
        result.get_nowait()

# Generated at 2022-06-12 14:03:00.975674
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    for i in range(0, 5):
        q.put_nowait(i)
    assert q.qsize() == 5
    for i in range(0, 5):
        assert q.get_nowait() == i
    assert q.qsize() == 0

# Generated at 2022-06-12 14:03:06.473244
# Unit test for method get of class Queue
def test_Queue_get():
    for i in range(0,1):
        queue = Queue(maxsize=None)
        qsize = queue.qsize()
        if qsize == 0:
            result = queue.get(timeout = 1)
            assert(result == QueueEmpty)
        else:
            result = queue.get(timeout = 1)
            assert(result != QueueEmpty)

# Generated at 2022-06-12 14:03:08.766884
# Unit test for method get of class Queue
def test_Queue_get():
    obj = Queue()
    obj.get(timeout = 0)
    obj.get_nowait()
    obj.task_done()

# Generated at 2022-06-12 14:03:16.628241
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():                                                         
    import time                                                                      
    from io import StringIO                                                          
    import sys                                                                       
    from tornado import gen                                                          
    from tornado.ioloop import IOLoop                                                 
    from tornado.queues import Queue                                                 
                                                                                     
    q = Queue(maxsize=2)                                                             
                                                                                     
    async def consumer():                                                            
        async for item in q:                                                         
            try:                                                                     
                print('Doing work on %s' % item)                                     
                await gen.sleep(0.01)                                                
            finally:                                                                 
                q.task_done()                                                        
                                                                                     

# Generated at 2022-06-12 14:03:35.849898
# Unit test for method put of class Queue
def test_Queue_put():
    from datetime import datetime, timedelta
    import time
    import unittest
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado import gen

    def _run_task(q: Queue, item: int, timeout: float) -> None:
        f = q.put(item, timeout)
        IOLoop.current().add_future(f, lambda f: f.result())

    def _run_task_timeout(q: Queue, item: int) -> None:
        _run_task(q, item, 0.001)

    def _run_task_nowait(q: Queue, item: int) -> None:
        _run_task(q, item, 0)

    # @unittest2.skipUnless(hasattr(Queue, 'put_nowait

# Generated at 2022-06-12 14:03:41.681243
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(5)

    assert q.qsize() == 0
    assert not q.full()
    assert q.empty()

    q.put_nowait(1)
    assert q.qsize() == 1

    q.put_nowait(2)
    assert q.qsize() == 2

    q.put_nowait(3)
    assert q.qsize() == 3

    q.put_nowait(4)
    assert q.qsize() == 4

    q.put_nowait(5)
    assert q.qsize() == 5
    assert q.full()

    try:
        q.put_nowait(6)
    except QueueFull:
        assert q.qsize() == 5
    else:
        raise AssertionError("Did raise")

# Generated at 2022-06-12 14:03:50.806071
# Unit test for method get of class Queue
def test_Queue_get():
    import unittest
    import asyncio
    from tornado.ioloop import IOLoop    

    def run_test(func: typing.Callable):
        loop = asyncio.get_event_loop()
        loop.run_until_complete(func())
        loop.close()

    class Test(unittest.TestCase):
        def test_Queue_get(self):
            import time
            MOD = 100
            q: Queue[int] = Queue(maxsize=MOD)
            fut1 = q.get()
            fut2 = q.get()
            self.assertTrue(asyncio.futures.Future.done(fut1))
            self.assertTrue(asyncio.futures.Future.done(fut2))

# Generated at 2022-06-12 14:04:01.410111
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=10)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put_nowait(1)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put_nowait(1)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put_nowait(1)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put_nowait(1)
    q.put(1)
    q.put(2)
    q.put(2)
    q.put_nowait(1)
    q.put(1)
    q.put

# Generated at 2022-06-12 14:04:12.278285
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    from datetime import datetime, timedelta
    from tornado import gen, ioloop
    q = Queue(maxsize=4)
    for i in range(4):
        q.put_nowait(i)

# Generated at 2022-06-12 14:04:15.873821
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
    except QueueFull:
        print('The queue is full')
        
test_Queue_put_nowait()


# Generated at 2022-06-12 14:04:18.017288
# Unit test for method get of class Queue
def test_Queue_get():
    x = Queue()
    print(x.get_nowait())


# Generated at 2022-06-12 14:04:25.683105
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test that Queue.get_nowait() returns immediately with the next item in the queue, if there is one, or raises QueueEmpty if there isn't
	# Get an empty queue
    q = Queue()
    #if there isn't raise QueueEmpty
    try:
        q.get_nowait()
        return True
    except QueueEmpty:
        pass
    #if there is one return immediately
    q.put_nowait(1)
    assert q.get_nowait() == 1
    return True


# Generated at 2022-06-12 14:04:30.826792
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import unittest
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time

    IOLoop.current().run_sync(lambda: Queue(maxsize=1).put(1) )



if __name__ == '__main__':
    test_Queue_get_nowait()

# Generated at 2022-06-12 14:04:34.119714
# Unit test for method get of class Queue
def test_Queue_get():
    print("Testing Queue.get")
    q = Queue(maxsize=5)
    for i in range(5):
        q.put(i)
    for i in range(5):
        if q.get_nowait()==i:
            print(True)
        else:
            print(False)


# Generated at 2022-06-12 14:05:05.093120
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:05:10.348377
# Unit test for method put of class Queue
def test_Queue_put():
    import tornado.gen
    import tornado.ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await tornado.gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print

# Generated at 2022-06-12 14:05:19.572058
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    # Simple case.
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.full()
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.empty()

    # Multiple futures.
    q = Queue()
    getters = [q.get() for _ in range(3)]
    putter1 = q.put(1)
    putter2 = q.put(2)
    putter3 = q.put(3)
    assert isinstance(putter1, Future)
    assert isinstance(putter2, Future)

# Generated at 2022-06-12 14:05:26.202305
# Unit test for method put of class Queue
def test_Queue_put():
    # Put an item into the queue, perhaps waiting until there is room.
    #
    # Returns a Future, which raises `tornado.util.TimeoutError` after a
    # timeout.

    # ``timeout`` may be a number denoting a time (on the same
    # scale as `tornado.ioloop.IOLoop.time`, normally `time.time`), or a
    # `datetime.timedelta` object for a deadline relative to the
    # current time.
    assert True # TODO: implement your test here



# Generated at 2022-06-12 14:05:31.286033
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import queue
    import random
    import time
    import threading
    import asyncio
    from asyncio import get_event_loop
    import os
    import sys
    import types
    import collections
    from collections import defaultdict
    from collections import deque
    from typing import Generic, Optional, List
    from .Queue import Queue
    from .PriorityQueue import PriorityQueue
    from .LifoQueue import LifoQueue

    #import logging
    #logging.basicConfig(level=logging.DEBUG,
    #                    format='(%(threadName)-10s) %(message)s',
    #                    )

    #def worker():
    #    """thread worker function"""
    #    logging.debug('Starting')
    #    time.sleep(0.2)
    #    logging.debug('Exiting')

   

# Generated at 2022-06-12 14:05:41.079095
# Unit test for method get of class Queue
def test_Queue_get():
    # test if get() makes a getter for the queue
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    from tornado import gen

    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)

    # start a consumer
    async def consumer(a):
        async for item in q:
            assert item == a
            q.task_done()

    IOLoop.current().spawn_callback(consumer, 1)

    # put in a producer
    async def producer():
        for item in range(5):
            await q.put(item)

    IOLoop.current().run_sync(producer)
    IOLoop.current().run_sync(lambda: q.join())



# Generated at 2022-06-12 14:05:44.441393
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import asyncio
    q = Queue()
    print(q.put_nowait(1))
    print(q.put_nowait(2))
    print(q.put_nowait(3))

# Generated at 2022-06-12 14:05:54.148377
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.testing import gen_test, AsyncTestCase
    import datetime
    import time
    import asyncio
    # 声明一个Queue，队列最大容量为3
    q = Queue(maxsize=3)
    # 创建一个消费者函数，其中await q.get()挂起自身,等待数据进入队列，
    # 有数据进入后，await q.get()立即返回
    async def consumer():
        while True:
            item = await q.get()

# Generated at 2022-06-12 14:05:56.072487
# Unit test for method put of class Queue
def test_Queue_put():
    Q = Queue()
    if (Q.put(2) == Future()):
        return True
    else:
        return False

# Generated at 2022-06-12 14:05:58.462622
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        value = q.get_nowait()
    except QueueEmpty:
        print("no task yet")


# Generated at 2022-06-12 14:06:43.557594
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(10)
    assert q._putters == collections.deque()
    assert q._getters == collections.deque()
    assert q._unfinished_tasks == 1
    assert q._queue == collections.deque([10])
    assert q.empty() == False
    assert q.full() == False


# Generated at 2022-06-12 14:06:47.599093
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1
    f = q.put(2, None)
    assert f.done() == True
    assert q.qsize() == 2


# Generated at 2022-06-12 14:06:50.768812
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(5)
    q.put(6)
    assert q.get_nowait() == 5

# Generated at 2022-06-12 14:06:58.008761
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=10)
    q.put("a")
    q.put("b")
    assert q.get_nowait() == "a"
    assert q.get_nowait() == "b"
    assert q.empty()
    q.put("c")
    q.put("d")
    assert q.get_nowait() == "c"
    q.task_done()
    q.put("e")
    assert q.get_nowait() == "d"
    assert q.get_nowait() == "e"
    assert q.empty()
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert type(e) == QueueEmpty


# Generated at 2022-06-12 14:07:09.788864
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import random
    import time
    import threading
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue, QueueEmpty

    # Will test 100 times
    for i in range(100):
        # Randomly generate the number of items in the queue
        n = random.randint(0, 100)
        q = Queue(n)
        assert q.qsize() == 0

        # Randomly generate the number of items to be put into the queue
        m = random.randint(0, 100)
        if m > n:
            m = n
        item_list = []
        for j in range(m):
            item = random.randint(0, 100)
            item_list.append(item)
            q.put_nowait(item)

# Generated at 2022-06-12 14:07:20.617934
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:07:23.691017
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)

    try:
        q.put_nowait("good")
        assert True
    except QueueFull:
        assert False

    try:
        q.put_nowait("bad")
        assert False
    except QueueFull:
        assert True

# Generated at 2022-06-12 14:07:34.733374
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:07:39.963907
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print("QueueFull")

    return True


# Generated at 2022-06-12 14:07:50.278467
# Unit test for method get of class Queue
def test_Queue_get():
    # unit test for Queue in case of Tornado
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    IOLoop.current().run_sync(main)
    return


# This

# Generated at 2022-06-12 14:09:24.298125
# Unit test for method put of class Queue
def test_Queue_put():
    import unittest
    import asyncio
    
    q = Queue()
    q.put_nowait(item=5)
    assert q.qsize() == 1
    assert q.empty() == False
    
    
    class Test_Queue(unittest.TestCase):
        
        @staticmethod
        def test_put_and_get(arg1, arg2):
            q = Queue()
            q.put_nowait(arg1)
            q.put_nowait(arg2)
            assert q.qsize() == 2
            assert q.empty() == False
            assert q.get_nowait() == arg1
            assert q.get_nowait() == arg2
            

# Generated at 2022-06-12 14:09:34.259311
# Unit test for method get of class Queue
def test_Queue_get():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:09:41.698328
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def  consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer() # Wait for producer to put all tasks.
        await q.join() # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:09:45.351770
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    try:
        q.put_nowait(4)
    except Exception as e:
        print(e.args)


# Generated at 2022-06-12 14:09:51.062763
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:09:58.868168
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:10:03.660956
# Unit test for method get of class Queue
def test_Queue_get():
    """ Test get method of class Queue - this method is based on the _get method of class Queue"""
    class Queue_test(Queue):
        def __init__(self, maxsize: int = 0):
            Queue.__init__(self, maxsize=maxsize)
            self._queue = []
            self._maxsize = 0

        def _get(self):
            # Return an item if one is immediately available, else raise QueueEmpty
            if self._queue:
                return self._queue.pop()
            else:
                raise QueueEmpty

# Generated at 2022-06-12 14:10:11.347636
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize = 2)
    # Put 0
    future = q.put(0)
    assert future.done()
    assert not future.cancelled()
    assert future.result() is None
    assert q.maxsize == 2
    assert q.qsize() == 1
    assert not q.empty()
    assert not q.full()
    # Put 1
    future = q.put(1)
    assert future.done()
    assert not future.cancelled()
    assert future.result() is None
    assert q.maxsize == 2
    assert q.qsize() == 2
    assert not q.empty()
    assert q.full()
    # Put 2
    future = q.put(2, timeout = None)
    assert not future.done()
    assert not future.cancelled()

# Generated at 2022-06-12 14:10:13.057463
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:10:16.189146
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    
    q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False
    
    q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True
    