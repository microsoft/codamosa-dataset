

# Generated at 2022-06-12 14:01:13.963941
# Unit test for method get of class Queue
def test_Queue_get():
  my_queue = Queue(maxsize=6)
  my_queue.put(1)
  try:
    my_queue.get_nowait()
  except QueueEmpty:
    print('Queue is empty')

test_Queue_get()


# Generated at 2022-06-12 14:01:20.488146
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # 1. Put 3 items into queue, because the maxsize is 3, queue should be full
    # 2. Put 1 more item into queue, because the queue is full, QueueFull exception should be raised
    q = Queue(maxsize=3)
    # Test case 1
    q.put_nowait('dog')
    q.put_nowait('cat')
    q.put_nowait('lion')
    assert q.full()
    # Test case 2
    try:
        q.put_nowait('elephant')
    except QueueFull:
        print('queue is full.')
    finally:
        assert q.full()


# Generated at 2022-06-12 14:01:22.378517
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.get_nowait()

# Generated at 2022-06-12 14:01:32.886544
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import time
    import pytest
    
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish

# Generated at 2022-06-12 14:01:43.469045
# Unit test for method put of class Queue
def test_Queue_put():
    # Put an item into the queue, perhaps waiting until there is room.
    #
    # Returns a Future, which raises tornado.util.TimeoutError after a
    # timeout.
    #
    # ``timeout`` may be a number denoting a time (on the same
    # scale as tornado.ioloop.IOLoop.time, normally time.time), or a
    # datetime.timedelta object for a deadline relative to the
    # current time.


    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    @gen.coroutine
    def producer():
        for item in range(10):
            print('Put %s' % item)
            yield q.put(item)

    @gen.coroutine
    def consumer():
        while True:
            item = yield q

# Generated at 2022-06-12 14:01:45.428484
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Just check that it runs.
    Queue().get_nowait()



# Generated at 2022-06-12 14:01:55.858086
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:02:08.447193
# Unit test for method get of class Queue
def test_Queue_get():
    # the get() method of the Queue class
    import pytest
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')
    IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:02:15.305900
# Unit test for method put of class Queue
def test_Queue_put():
    # make a queue
    q = Queue(maxsize=2)

    # make a list for results
    results = []

    # make a list for results of method get
    results_get = []

    # make a list for results of method put_nowait
    results_put_nowait = []

    @gen.coroutine
    def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            results_get.append(item)
            yield gen.sleep(0.01)
            q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
            results.append(item)

    # Start consumer without waiting (since it never finishes).
   

# Generated at 2022-06-12 14:02:16.360122
# Unit test for method get of class Queue
def test_Queue_get():
    pass



# Generated at 2022-06-12 14:02:25.949174
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()

    # Test that Queue.get() is awaitable
    assert not isinstance(q.get(), Future)

    # Test that q.get() is an awaitable, not just some random value.
    assert q.get() is not None

# Generated at 2022-06-12 14:02:26.810876
# Unit test for method put of class Queue
def test_Queue_put():
    pass



# Generated at 2022-06-12 14:02:27.867344
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    res = q.get()


# Generated at 2022-06-12 14:02:38.983499
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer

# Generated at 2022-06-12 14:02:42.287775
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue(maxsize=1)
    queue.put_nowait(1)
    queue.put_nowait(2)
    assert queue._queue[-1] == 2, "Queue.put_nowait method works incorrect"
    print("Queue.put_nowait method works correct")
    print("-----------")

# Generated at 2022-06-12 14:02:49.361923
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    # __aiter__()
    it = iter(q)
    with pytest.raises(StopIteration):
        next(it)
    # get_nowait()
    with pytest.raises(QueueEmpty):
        q.get_nowait()
    # put()
    async def t1():
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        await q.put(5)
    ioloop.IOLoop.current().run_sync(t1)
    # get()
    future = Future()
    future.set_result(q.get())
    # _consume_expired()
    q._consume_expired()
    # task_done()
    q.task_done

# Generated at 2022-06-12 14:02:50.678467
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:02:55.243262
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:03:06.319939
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)
    item_value = []

    async def consumer():
        async for item in q:
            item_value.append(item)
        

    async def producer():
        for item in range(5):
            item_value.append(item)
            await q.put(item)
        

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:03:08.675507
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    result = Queue()
    result.__put_internal(2)
    assert result.get_nowait()==2
    

# Generated at 2022-06-12 14:03:26.395438
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
  q = Queue(maxsize=2)
  q.put_nowait(10)
  q.put_nowait(20)
  assert(q.get_nowait()==10)
  assert(q.get_nowait()==20)
  # All the elements were successfully returned
  assert(True)


# Generated at 2022-06-12 14:03:35.435904
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    print(q.qsize())
    print(q.empty())
    print(q.full())

    print('--------')
    q.put_nowait(1)
    q.put_nowait(2)
    
    print(q.qsize())
    print(q.empty())
    print(q.full())

    print('--------')
    try:
        q.put_nowait(3)
    except QueueFull:
        print('QueueFull')

    print(q.qsize())
    print(q.empty())
    print(q.full())

    print('--------')
    try:
        q.get_nowait()
    except QueueEmpty:
        print('QueueEmpty')

    print(q.qsize())

# Generated at 2022-06-12 14:03:42.151674
# Unit test for method get of class Queue
def test_Queue_get():
    # Implicitly tests __aiter__ as well
    q = Queue()
    q.put_nowait(42)
    q.put_nowait(43)
    q.task_done()
    q.task_done()
    # Put another item on the queue so that the iterator doesn't finish.
    q.put_nowait(44)
    assert list(q) == [42, 43]
    assert list(q.__aiter__()) == [42, 43]
    q.task_done()

# Generated at 2022-06-12 14:03:48.574622
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:50.054408
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()
    q.get_nowait()

# Generated at 2022-06-12 14:03:58.155049
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop

# Generated at 2022-06-12 14:04:09.421516
# Unit test for method get of class Queue
def test_Queue_get():
    text = [
        ["a","b"]
        #,"a"
    ]
    
    inp = Queue()
    outp = Queue()
    # Queue(maxsize=maxsize)
    # Queue.maxsize=0
    # Queue.maxsize=None
    # Queue.maxsize=-1
    inp = Queue(0)
    for x in text:
        inp.put_nowait(x)
    # Queue.put(item, timeout=None)
    # Queue.put_nowait(item)
    # Queue.get(timeout=None)
    # Queue.get_nowait()
    for x in text:
        assert (inp.get()) == (x)
    assert (inp.qsize()) == (0)
    # Queue.empty

# Generated at 2022-06-12 14:04:12.478983
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert False, "The queue is full but still can put"
    except QueueFull:
        pass


# Generated at 2022-06-12 14:04:17.485969
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(3)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.get() == 1
    assert q.get() == 2

    q.put_nowait("a")
    q.put_nowait("b")
    q.put_nowait("c")
    assert q.get_nowait() == "a"
    assert q.get_nowait() == "b"
    assert q.get_nowait() == "c"

    q.join()



# Generated at 2022-06-12 14:04:28.321298
# Unit test for method get of class Queue
def test_Queue_get():
    # Queue without maxsize has no bound
    q = Queue()
    assert q.empty()
    assert q.qsize() == 0
    assert not q.full()
    q.put("a")
    assert not q.empty()
    assert q.qsize() == 1
    assert not q.full()
    q.put("b")
    assert not q.empty()
    assert q.qsize() == 2
    assert not q.full()

    # Queue with negative maxsize can't be created
    assert raises(ValueError, lambda: Queue(maxsize=-1))

    # Queue with maxsize 1 has a bound
    q = Queue(maxsize=1)
    assert q.empty()
    assert q.qsize() == 0
    assert not q.full()
    q.put("a")


# Generated at 2022-06-12 14:05:03.507241
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    q = Queue(maxsize=2)
    
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-12 14:05:10.310983
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test for issue #2289: Queue.empty() does not call _consume_expired
    # Test for issue #2290: Queue.get_nowait() locks when Queue.put_nowait() called
    import asyncio
    import time
    queue = Queue()
    async def put():
        while True:
            await asyncio.sleep(0.1)
            queue.put_nowait(0)
    async def get():
        while True:
            await asyncio.sleep(0.1)
            queue.get_nowait()
    async def test():
        await asyncio.gather(put(), get())
    asyncio.run(test())



# Generated at 2022-06-12 14:05:19.599511
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:23.795123
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.qsize() == 0
    q.put_nowait(1)
    q.put_nowait(2)
    q.get_nowait() == 1
    q.get_nowait() == 2
    q.qsize() == 0



# Generated at 2022-06-12 14:05:28.548481
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(3)
    q.put(4)
    q.put_nowait(5)
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4
    assert q.get_nowait() == 5
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass



# Generated at 2022-06-12 14:05:32.804524
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Test function of get() on Queue
    :return:
    """
    q = Queue()
    assert(q.empty() == True)
    item = "A"
    q.put_nowait(item)
    assert(q.full() == True)
    assert(q.qsize() == 1)
    assert(q.get_nowait() == item)


# Generated at 2022-06-12 14:05:38.158888
# Unit test for method get of class Queue
def test_Queue_get():
    """Unit test for Queue.get"""
    import asyncio
    # ------ begin of the test ------

    # software under test
    async def consumer():
        # await q.join()  # Implicitly via the __anext__ of the queue
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.1)

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        consumer_task = ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await consumer_task

    # ------ end of the test ------

    q = Queue(maxsize=2)

# Generated at 2022-06-12 14:05:47.567155
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def put(item):
        try:
            q.put_nowait(item)
        except QueueFull:
            q._putters.append((item, Future()))
    def get():
        try:
            return q.get_nowait()
        except QueueEmpty:
            q._getters.append(Future())
    put(1)
    put(2)
    assert(q.get_nowait()==1)
    assert(q.get_nowait()==2)
    put(3)
    put(4)
    assert(q.get_nowait()==3)
    assert(q.get_nowait()==4)
    put(5)
    put(6)
    assert(q.get_nowait()==5)
   

# Generated at 2022-06-12 14:05:56.513400
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:06:07.733173
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)


    async def consumer():
        while True:
            async  with q:
                item = await q.get()
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-12 14:07:00.421456
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        assert q.qsize() == 2

test_Queue_put_nowait()

# Generated at 2022-06-12 14:07:12.534530
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:07:22.575199
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:07:26.362800
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q1 = Queue(maxsize=2)
    q1._queue.append(1)
    q1._queue.append(2)
    assert q1.get_nowait() == 1
    assert q1.get_nowait() == 2
    assert q1.empty()



# Generated at 2022-06-12 14:07:33.602841
# Unit test for method put of class Queue
def test_Queue_put():
    # Initialize
    q = Queue(maxsize=0)
    item = 0
    timeout = 0.1
    timeoutObject = datetime.timedelta(seconds=timeout)
    # Run method
    t0 = time.time()
    future = q.put(item, timeout)
    # Check if it has finished in time
    if future.done():
        t1 = time.time()
        delta = t1 - t0
        assert delta < timeout
    else:
        assert False


# Generated at 2022-06-12 14:07:38.560128
# Unit test for method put of class Queue
def test_Queue_put():
    print("\nTest for Queue_put")
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    print(q._queue)
    assert q._queue == deque([1, 2, 3])


# Generated at 2022-06-12 14:07:49.112194
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    print("-------------------test_Queue_put_nowait-----------------")
    # Verify that a timeout actually waits as it should
    async def main(loop):

        q = Queue(maxsize=1)
        item1 = await q.put(1)
        print("Put item1 : ", item1)
        item2 = await q.put(2)
        print("Put item2 : ", item2)
        item3 = None
        # This should raise a timeout error after 2 seconds
        try:
            item3 = await gen.with_timeout(timedelta(seconds=2), q.put(3))
        except Exception as e:
            print("Exception: ", e)
            pass

        print("Put item3 : ", item3)

    loop = ioloop.IOLoop.current()
    loop.run_sync(main)

# Generated at 2022-06-12 14:07:49.705210
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-12 14:07:54.013414
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=3)
    get_future = q.get()
    q.put("hello")
    try:
        print(q.get_nowait())
    except QueueEmpty:
        print("Queue is empty")
    finally:
        q.task_done()

# Generated at 2022-06-12 14:08:00.627771
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Arrange
    q = Queue()
    
    # Act
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    q.put_nowait(5)
   
    # Assert
    assert q.qsize() == 5
    assert q.empty() == False
    assert q.full() == False


# Generated at 2022-06-12 14:09:42.498447
# Unit test for method get of class Queue
def test_Queue_get():
	maxsize=5
	timeout=None
	q= Queue(maxsize)
	future = Future()
	try:
		future.set_result(q.get_nowait())
	except QueueEmpty:
		q._getters.append(future)
		_set_timeout(future, timeout)
	return future

#Unit test for method put of class Queue

# Generated at 2022-06-12 14:09:45.961344
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
        raise AssertionError("Expected QueueEmpty")
    except QueueEmpty:
        pass

    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        raise AssertionError("Expected QueueFull")
    except QueueFull:
        pass

    #self.assertEqual(q.get_nowait(), 1)



# Generated at 2022-06-12 14:09:53.945849
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop


    @asyncio.coroutine
    def test_get():
        q = Queue()
        assert q.qsize() == 0
        q.put_nowait(1)
        assert q.qsize() == 1
        yield from q.put(2)
        assert q.qsize() == 2
        with assert_raises(QueueFull):
            q.put_nowait(3)
        assert q.qsize() == 2
        it = q.__aiter__()
        assert type(it) == _QueueIterator
        assert (yield from it.__anext__()) == 1
        assert q.qsize() == 1
        assert (yield from it.__anext__()) == 2
        assert q.qsize

# Generated at 2022-06-12 14:09:57.883343
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        q.put_nowait(4)
    except e:
        raise Exception('ERROR: Queue has reached its maxsize')



# Generated at 2022-06-12 14:10:04.435791
# Unit test for method get of class Queue
def test_Queue_get():
  # Creating a Queue
  q = Queue()
  # Inserting three elements in the queue
  q.put(10)
  q.put(15)
  q.put(20)
  # Removing element from the queue and printing it
  print(q.get_nowait())
  print(q.get_nowait())
  print(q.get_nowait())

  # Creating a Queue
  q1 = Queue()
  # Inserting three elements in the queue
  q1.put(10)
  q1.put(15)
  q1.put(20)
  # Removing element from the queue and printing it
  print(q1.get_nowait())
  print(q1.get_nowait())
  print(q1.get_nowait())

# Testing the Queue

# Generated at 2022-06-12 14:10:11.850346
# Unit test for method put of class Queue
def test_Queue_put():
    _queue = Queue()
    _queue.put_nowait(43)

    callback_called = False

    def callback():
        nonlocal callback_called
        callback_called = True

    _queue._putters.append((42, Future()))
    _queue._putters[0][1].set_result(True)
    _queue._putters[0][1].add_done_callback(callback)

    _queue._unfinished_tasks = 2
    _queue._finished.clear()

    _queue._putters[0] = ()

    _queue.put_nowait(45)
    _queue.get_nowait()

    assert _queue.qsize() == 1
    assert _queue._unfinished_tasks == 1
    assert _queue._finished.wait()
    assert callback_called


# Generated at 2022-06-12 14:10:20.536332
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen, ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    print

# Generated at 2022-06-12 14:10:27.306942
# Unit test for method get of class Queue
def test_Queue_get():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:10:31.797705
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    assert(q.get_nowait() == 2)
    q.task_done()
    assert(q.get_nowait() == 1)
    q.task_done()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False

if __name__ == "__main__":
    test_Queue_get_nowait()

# Generated at 2022-06-12 14:10:32.290658
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass