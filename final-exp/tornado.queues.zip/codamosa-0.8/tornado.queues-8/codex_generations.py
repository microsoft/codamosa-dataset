

# Generated at 2022-06-12 14:01:27.832794
# Unit test for method put of class Queue
def test_Queue_put():
    # Test for:
        # 1. future is empty at first before future is done
        # 2. future has been set as true when it is done

    q = Queue()
    future = q.put(1)
    assert future.done() == False

    future = q.put(1, timeout=0.01)
    assert future.done() == True


# Generated at 2022-06-12 14:01:33.366829
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    testQ = Queue(5)
    A = [1,2,3]
    B = [1,2,3]
    testQ.put(1)
    testQ.put(2)
    testQ.put(3)
    assert testQ.get_nowait() in A
    assert testQ.get_nowait() in B
    assert testQ.get_nowait() in A


# Generated at 2022-06-12 14:01:42.370261
# Unit test for method get of class Queue
def test_Queue_get():
    done = Event()
    a=Queue()
    a.put_nowait(1)
    a.put_nowait(2)
    a.put_nowait(3)
    @gen.coroutine
    def consumer():
        nonlocal done
        async for item in a:
            try:
                print('Doing work on %s' % item)
            finally:
                print(type(item))
                print('finall')
                a.task_done()
        done.set()


    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)
    ioloop.IOLoop.current().start()

# Generated at 2022-06-12 14:01:45.318540
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=5)
    item = q.get()
    assert item == QueueEmpty, "expected result QueueEmpty, got {}".format(item)

# Generated at 2022-06-12 14:01:51.738907
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait(): 
    q = Queue()
    try:
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        q.put_nowait(4)
    except:
        print('Queue is full')
    finally:
        print(q.qsize())
        print('q size is %d' % q.qsize())


# Generated at 2022-06-12 14:01:55.151017
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 5)
    len_before = len(q._queue)
    assert (len_before == 0)
    q.put_nowait(1)
    len_after = len(q._queue)
    assert (len_after == 1)




# Generated at 2022-06-12 14:02:06.803455
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Queue should not contain any element
    q = Queue(maxsize=2)
    assert not q.qsize(), 'queue is empty'
    
    # Put new elements to queue
    q.put_nowait(0)
    q.put_nowait(1)
    
    # Queue should not grow more than maxsize
    try:
        q.put_nowait(2)
        assert 0, 'queue grew more than maxsize'
    except QueueFull:
        pass
    
    # Number of elements should be equal to maxsize
    assert q.qsize() == q.maxsize, 'queue is not full'
    
    # Queue should be full
    assert q.full(), 'queue is full'

# Generated at 2022-06-12 14:02:08.299671
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # given:
    item = 1
    q = Queue()
    # when:
    q.put_nowait(item)
    # then:
    assert(q._queue[0] == 1)


# Generated at 2022-06-12 14:02:12.766932
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=5)
    for i in range(5):
        q.put_nowait(i)
    for i in range(5):
        assert q.get_nowait() == i
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False

test_Queue_get_nowait()

# Generated at 2022-06-12 14:02:16.963377
# Unit test for method get of class Queue
def test_Queue_get():
    from typing import Dict, Any
    from tornado.queues import Queue
    queue = Queue()
    queue._getters = collections.deque([])  # type: Deque[Future[_T]]
    queue.get()




# Generated at 2022-06-12 14:02:39.254142
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import random
    import threading
    q = Queue()
    # set a time-out
    timeout = (time.time() + 0.5)
    # set a thread for producer
    def producer():
        for i in range(5):
            item = random.randint(0, 256)
            q.put(item)
            print('Put %s' % item)
            # set a time-out
            timeout = (time.time() + 0.5)
    # set a thread for consumer
    def consumer():
        # if there is no task_done(), when the queue is empty, consumer will be blocked forever
        while True:
            item = q.get()
            print('Consumer %s' % item)
            q.task_done()
    t1 = threading.Thread(target=producer)

# Generated at 2022-06-12 14:02:46.472143
# Unit test for method get of class Queue
def test_Queue_get():
    async def main():
        print("in main")
        q = Queue()
        # get item from empty queue
        with pytest.raises(QueueEmpty):
            q.get_nowait()
        await q.get()
        # put item in queue
        await q.put(1)
        # get item from queue
        res = await q.get()
        assert res == 1
        # put items in queue
        await q.put(1)
        await q.put(2)
        # get items from queue
        res = await q.get()
        assert res == 1
        res = await q.get()
        assert res == 2
        # get item from empty queue
        with pytest.raises(QueueEmpty):
            q.get_nowait()
        await q.get()


# Generated at 2022-06-12 14:02:56.265161
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.queues
    import time
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    async def producer():
        for item in range(5):
            time.sleep(0.01)
            await q.put(item)
            #print('Put %s' % item)
    
    #@tornado.gen.coroutine
    async def consumer():
        while True:
            item = await q.get()
            #print('Doing work on %s' % item)
            await tornado.gen.sleep(0.01)
            q.task_done()
    
    async def main():
        # Start consumer without waiting (since it never finishes).
        tornado.iol

# Generated at 2022-06-12 14:03:07.448777
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:15.918670
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:21.156477
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    length = 3
    q = Queue(length)
    for i in range(length):
        q.put_nowait(i)
    for i in range(length):
        assert i == q.get_nowait()
    
    try:
        q.get_nowait()
        assert False
    except QueueEmpty:
        pass



# Generated at 2022-06-12 14:03:31.760444
# Unit test for method get of class Queue
def test_Queue_get():
    # test fonctionnel
    print("test_Queue_get")
    q = Queue()
    q.put(1)
    q.put("string")
    q.put(c or "")
    assert q.get() == 1
    assert q.get() == "string"
    assert q.get() == c or ""
    assert q.qsize() == 0
    q.put(None)
    assert q.get() == None
    assert q.qsize() == 0
    q.put(False)
    assert q.get() == False
    q.put(True)
    assert q.get() == True
    # test d'exception
    q = Queue()
    try:
        q.get()
        assert False
    except QueueEmpty:
        assert True


# Generated at 2022-06-12 14:03:33.272522
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize = 2)
    assert type(q.get()) == Future


# Generated at 2022-06-12 14:03:42.510754
# Unit test for method get of class Queue
def test_Queue_get():
    # Method get: Call the method_get of the class Queue
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        print("consumer is running")
        async for item in q:
            print("Doing work on %s" % item)
            await gen.sleep(0.01)
            q.task_done()
    async def producer():
        print("producer is running")
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

# Generated at 2022-06-12 14:03:51.560129
# Unit test for method get of class Queue
def test_Queue_get():
    # Test code
    import sys
    import os
    import types
    import pytest
    import asyncio
    this_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(this_dir, ".."))
    from tornado.concurrent import Future  # noqa: E402
    from tornado.platform.asyncio import (  # noqa: E402
        AsyncIOMainLoop,
    )
    from tornado.ioloop import IOLoop  # noqa: E402
    import tornado.queues
    io_loop = IOLoop.current()

    # Test code
    q = tornado.queues.Queue(maxsize=0)


# Generated at 2022-06-12 14:04:12.907159
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)
test_Queue_

# Generated at 2022-06-12 14:04:15.119264
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put(1)
    assert q.get_nowait() == 1
    assert q.empty()
    assert q.qsize() == 0

# Generated at 2022-06-12 14:04:16.793962
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    try:
        q = Queue()
        q.get_nowait()
    except QueueEmpty:
        pass


# Generated at 2022-06-12 14:04:17.796959
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.get() == 123



# Generated at 2022-06-12 14:04:24.545766
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    q.put(1)
    q.put(2)
    assert q.qsize() == 2
    q.put(3)
    assert q.qsize() == 2
    assert q._queue[0] == 1
    assert q._queue[1] == 2
    with pytest.raises(QueueFull) as e:
        q.put(4)
    assert str(e.value) == "full"


# Generated at 2022-06-12 14:04:34.541450
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    t = Queue()
    e = Future()
    e.set_result(None)
    t.put_nowait(1)
    print("test_Queue_put_nowait: ", t.qsize())
    assert t.qsize() == 1
    t._maxsize = 0
    e.set_result(None)
    t._putters.append((1, e))
    t._consume_expired()
    print("test_Queue_put_nowait: ", t._putters)
    assert t._putters == deque([])
    # Test whether put succeeds when getters are waiting
    print("test_Queue_put_nowait: ", t._getters)
    assert t._getters == deque([])
    t._getters.append(e)

# Generated at 2022-06-12 14:04:45.642597
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:04:49.136213
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.qsize  # => 0
    q.empty  # => True
    assert q.get_nowait() is None
    q.put_nowait(0)
    assert q.get_nowait() == 0



# Generated at 2022-06-12 14:04:50.960139
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest

    @gen.coroutine
    def test_main():
        q = Queue()
        q.put_nowait(1)
        assert (yield q.get()) == 1

    ioloop.IOLoop().run_sync(test_main)



# Generated at 2022-06-12 14:04:52.211592
# Unit test for method get of class Queue
def test_Queue_get():
    import Queue
    q = Queue.Queue(max_size = 0)
    assert q.get(timeout = 0) == None


# Generated at 2022-06-12 14:05:10.112068
# Unit test for method put of class Queue
def test_Queue_put():
  q = Queue()
  f = Future()
  q._putters.append(('a',f))
  q.__put_internal('a')

  assert q._queue[-1] == 'a'
  assert q._unfinished_tasks == 1
  q.task_done()
  assert q._unfinished_tasks == 0
  q._finished.set()
  f = Future()
  f.set_result(None)
  assert not q._finished.is_set()
  q.__put_internal('b')
  assert q._queue[-1] == 'b'

  q.task_done()
  q._finished.set()
  assert q._finished.is_set()
  

if __name__ == "__main__":
  test_Queue_put()

# Generated at 2022-06-12 14:05:14.109624
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = Future()
    try:
        q.put_nowait(1)
    except QueueFull:
        future.set_result(None)
    else:
        future.set_result(None)
    return future



# Generated at 2022-06-12 14:05:16.238273
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    for i in range(3):
        q.put_nowait(i)
    for i in range(3):
        q.get_nowait()



# Generated at 2022-06-12 14:05:18.534491
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    future = Future()
    item = 0
    timeout = None
    q._getters.append(future)
    assert q.put(item, timeout) == future


# Generated at 2022-06-12 14:05:25.434698
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    try:
        q.put_nowait('A')
        q.put_nowait('B')
        q.put_nowait(None)
    except QueueFull:
        print("QueueFull")
    # Cannot add new element because the queue is full
    try:
        q.put_nowait('C')
    except QueueFull:
        print("QueueFull")
    # Get an element and add new element
    print(q.get_nowait())
    try:
        q.put_nowait('C')
    except QueueFull:
        print("QueueFull")
    print(q.get_nowait())
    print(q.get_nowait())
    # Cannot get new element because the queue is empty

# Generated at 2022-06-12 14:05:29.587822
# Unit test for method get of class Queue
def test_Queue_get():
	async def test_1(queue):
		pass
	
	async def test_2(queue):
		pass
			
if __name__ == "__main__":
	print("testing get")
	q = Queue()
	q.get()
	print("get", "OK")

# Generated at 2022-06-12 14:05:38.795945
# Unit test for method put of class Queue
def test_Queue_put():
    def put():
        q = Queue(maxsize=2)
        q.task_done()
        q.task_done()
        q.task_done()

        try:
            q.put(1, timeout=0.1)
        except QueueFull:
            pass
        else:
            raise Exception("expected queue full")

        q.put_nowait(1)
        q.put_nowait(2)
        try:
            q.put_nowait(3)
        except QueueFull:
            pass
        else:
            raise Exception("expected queue full")

        try:
            q.put(3, timeout=0.1)
        except gen.TimeoutError:
            pass
        else:
            raise Exception("expected timeout")

    test_Queue_put()



# Generated at 2022-06-12 14:05:47.862601
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    import time
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from lib.helper import BaseTestCase


    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)



# Generated at 2022-06-12 14:05:56.764254
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    # Queue.put uses add_callback, which is implemented by _run_callback
    # take in the eventloop and callback
    #print(ioloop.IOLoop.current())
    # asyncio.get_event_loop().run_until_complete(test_Queue_put())
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-12 14:06:05.661085
# Unit test for method get of class Queue
def test_Queue_get():
    flag = True
    for i in range(5):
        if flag:
            flag = False
            print(flag)
        else:
            flag = False
            print(flag)
    q = Queue(maxsize=2)
    try:
        print(q.qsize())
    except AttributeError:
        print("Error")
    try:
        q.put_nowait(1)
        q.put_nowait(1)
    except QueueFull:
        print("Full")
    q.task_done()
    q.task_done()
    print(q.join())
    print(q.get())



# Generated at 2022-06-12 14:06:20.401447
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    assert q.get() == None


# Generated at 2022-06-12 14:06:30.510736
# Unit test for method put of class Queue
def test_Queue_put():
    # Test case: return a Future, which raises `tornado.util.TimeoutError` after a
    # timeout, when the queue is full
    def testcase1() -> Future:
        q = Queue(maxsize=2)
        q.put_nowait(1)
        q.put_nowait(2)
        future = Future()
        q.put(3, timeout = 5)
        return future
    # Run the test case
    future = testcase1()
    io_loop = ioloop.IOLoop.current()
    io_loop.add_timeout(datetime.timedelta(seconds = 5), lambda:future.set_exception(gen.TimeoutError()))

# Generated at 2022-06-12 14:06:32.187040
# Unit test for method get of class Queue
def test_Queue_get():
    q = 1
    timeout = 2
    return q.get(timeout)


# Generated at 2022-06-12 14:06:42.930264
# Unit test for method put of class Queue
def test_Queue_put():

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Unit test

# Generated at 2022-06-12 14:06:50.101773
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    assert queue.qsize() == 0
    assert queue.empty() == True
    assert queue.full() == False
    queue.put_nowait(0)
    assert queue.qsize() == 1
    assert queue.empty() == False
    assert queue.full() == False
    assert queue.get() == 0
    assert queue.qsize() == 0
    assert queue.empty() == True
    assert queue.full() == False


# Generated at 2022-06-12 14:06:53.006213
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    async def test_put(item):
        await q.put(item)
    ioloop.IOLoop.current().run_sync(test_put(1))



# Generated at 2022-06-12 14:07:02.241954
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import unittest
    import tornado
    import gen

    def target(q):
        print("starting getter")
        print("getter: got %r" % (q.get_nowait(),))

    q = Queue(maxsize=2)
    t = gen.Task(target, q)
    print("putting 1")
    q.put(1)
    print("putting 2")
    q.put(2)
    print("putting 3")
    q.put(3)
    print("putting 4")
    q.put(4)
    print("running getter")
    t.start()
    tornado.ioloop.IOLoop.instance().start()


# Generated at 2022-06-12 14:07:05.777660
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest
    queue = Queue()
    queue.put_nowait(1)
    
    item = queue.get()
    print(item)
    pytest.fail()


# Generated at 2022-06-12 14:07:10.963598
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # given
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    # when
    result = q.get_nowait()
    # then
    expected_result = 1
    assert result == expected_result


# Generated at 2022-06-12 14:07:16.771950
# Unit test for method put of class Queue
def test_Queue_put():
    import queue
    import datetime
    q = queue.Queue()
    q.put(1)
    q.put(2)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put(2,timeout=None)
    q.put(2,timeout=1)
    q.put(2,timeout=datetime.datetime())



# Generated at 2022-06-12 14:08:19.490824
# Unit test for method put of class Queue
def test_Queue_put():
    getter = Future()
    putter = Future()
    item = 1
    self = Queue(maxsize=2)
    self.maxsize = 2
    self._init()
    self._getters = collections.deque([getter])
    self._putters = collections.deque([])
    self._unfinished_tasks = 0
    self.put(item)
    assert(((item, putter) in self._putters))
    assert(item in self._queue)



# Generated at 2022-06-12 14:08:26.243263
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=1)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            print('Put %r' % item, q.put(item))
            print('Put %r done' % item)
    ioloop.IOLoop.current().run_sync(producer)



# Generated at 2022-06-12 14:08:29.292404
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    async def set_and_get():
        await q.put(42)
        item = await q.get()
        return item
    item = ioloop.IOLoop.current().run_sync(set_and_get)
    assert item == 42

# Generated at 2022-06-12 14:08:37.829633
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert None is None
    q = Queue(maxsize = 2)
    assert q.maxsize == 2
    assert q._getters == collections.deque([])
    assert q._putters == collections.deque([])
    assert q._unfinished_tasks == 0
    assert q._finished.is_set()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    try:
        q.put_nowait(4)
        assert False
    except QueueFull:
        assert True

# Generated at 2022-06-12 14:08:41.174620
# Unit test for method put of class Queue
def test_Queue_put():
    # test of put()
    q = Queue(maxsize=3)
    print("q.put(1)")
    q.put(1)
    print("q.put(2)")
    q.put(2)
    print("q.put(3)")
    q.put(3)
    q.put_nowait(4)
    q.put_nowait(5)
    return q
q = test_Queue_put()


# Generated at 2022-06-12 14:08:52.960697
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish

# Generated at 2022-06-12 14:08:53.891704
# Unit test for method put of class Queue
def test_Queue_put():
    """Test for Queue"""
    pass

# Generated at 2022-06-12 14:08:56.871777
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.maxsize == 0
    assert q.full() == False


# Generated at 2022-06-12 14:09:04.194745
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    # put
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    #get
    if q.get_nowait() == 1:
        print('Get 1')
    if q.get_nowait() == 2:
        print('Get 2')
    if q.get_nowait() == 3:
        print('Get 3')
    if q.get_nowait() == 4:
        print('Get 4')


# Generated at 2022-06-12 14:09:09.555211
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:10:29.245336
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    IOLoop.current().spawn_callback(test_put_consumer,q)
    IOLoop.current().spawn_callback(test_put_producer,q)
    IOLoop.current().start()


# Generated at 2022-06-12 14:10:36.787534
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    print(q)
    assert q.qsize() == 0

    future = q.put(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False

    future = q.put(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True

    future = q.put(3, timeout=datetime.timedelta(milliseconds=10))
    assert future.result() == None
    assert q.qsize() == 3
    assert q.empty() == False
    assert q.full() == True

    future = q.put(4, timeout=datetime.timedelta(milliseconds=10))
    assert future.done() == False

# Generated at 2022-06-12 14:10:43.194248
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def consumer():
        gen.sleep(0.01)
        return q
    def producer():
        for item in range(5):
            q.put(item)
        q.join()
    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        producer()     # Wait for producer to put all tasks.
        print('Done')

    IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:10:46.873904
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    result=Queue().get_nowait()
    print(type(result))
    print(isinstance(result, QueueEmpty))
    print(isinstance(result,BaseException))
    print(isinstance(result,Exception))
    print(result.__class__.__name__)


test_Queue_get_nowait()


# Generated at 2022-06-12 14:10:50.994675
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    num_items = 5
    all_items = set()
    for item in range(num_items):
        all_items.add(item)

    queue = Queue(maxsize=num_items)
    for item in all_items:
        queue.put_nowait(item)

    received_items = set()
    while True:
        try:
            received_items.add(queue.get_nowait())
        except QueueEmpty:
            break

    assert received_items == all_items

