

# Generated at 2022-06-12 14:01:08.448254
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
test_Queue_get_nowait()


# Generated at 2022-06-12 14:01:17.081178
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:01:24.801955
# Unit test for method get of class Queue
def test_Queue_get():
    def __init__(self, maxsize: int = 0) -> None:
        self._maxsize = maxsize
        self._getters = collections.deque([])  # type: Deque[Future[_T]]
        self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
        self._unfinished_tasks = 0
        self._finished = Event()
        self._finished.set()

    def get(self, timeout: Optional[Union[float, datetime.timedelta]] = None) -> Awaitable[_T]:
        future = Future()  # type: Future[_T]
        try:
            future.set_result(self.get_nowait())
        except QueueEmpty:
            self._getters.append(future)

# Generated at 2022-06-12 14:01:35.971787
# Unit test for method put of class Queue
def test_Queue_put():
    with pytest.raises(TypeError):
        q = Queue()
        q.put(None)
    with pytest.raises(ValueError):
        q = Queue(-1)
        q.put(1)
    with pytest.raises(QueueFull):
        q = Queue(0)
        q.put(1)
    q = Queue(1)
    q.put(1)
    with pytest.raises(QueueFull):
        q.put(2)
    q = Queue(2)
    for i in range(1, 3):
        assert q.put(i) == None
    with pytest.raises(QueueFull):
        q.put(2)
    # Unit test for method get of class Queue


# Generated at 2022-06-12 14:01:45.283862
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado.ioloop import IOLoop

    q = Queue()

    f = []
    for i in range(10):
        f.append(q.put_nowait(i))
    
    for i in range(10, 20):
        q.put(i)

    for i in range(20, 30):
        q.put_nowait(i)

    allfutures = f + [q.put(i) for i in range(30, 40)]

    def check_future(wait_futures):
        for future in wait_futures:
            if future.done():
                raise QueueFull

    IOLoop.current().add_callback(check_future, allfutures)
    IOLoop.current().start()



# Generated at 2022-06-12 14:01:53.160077
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:02:04.626158
# Unit test for method put of class Queue

# Generated at 2022-06-12 14:02:08.106857
# Unit test for method put of class Queue
def test_Queue_put():
    input_params = [2, 3, 4]
    for val in input_params:
        q = Queue(val)
        res = q.put(val)
        print(res)

# Generated at 2022-06-12 14:02:13.163009
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    q = Queue()

    async def coro(value):
        await q.put(value)
        #print(q.qsize())
    coro_list = []
    for i in range(10):
        coro_list.append(coro(i))
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.wait(coro_list))
    print(q._queue)


# Generated at 2022-06-12 14:02:16.128339
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    i = 1
    try:
        assert q.qsize() == 0
        assert q.empty() == True
        q.put_nowait(i)
        i = i + 1
        assert q.qsize() == 1
        assert q.empty() == False
    except QueueFull:
        print('oops')



# Generated at 2022-06-12 14:02:24.423104
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  q = Queue()
  print(q.put_nowait(1)) # Pass


# Generated at 2022-06-12 14:02:31.592547
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import enum
    import logging
    import random
    import threading
    import time
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.queues import Queue
    from enum import Enum
    IterationState = Enum('IterationState', 'one two three four five')
    state = IterationState.one
    
    
    
    @gen.coroutine
    def consumer():
        global state 
        while True:
            print('Before get', state)
            # This method will block until someone does a get_nowait
            item = yield q.get()
            print('After get', state)
            print('Doing work on %s' % item)

# Generated at 2022-06-12 14:02:36.231771
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    callback_called = [False]
    
    q = Queue()
    q.get_nowait()
    # NEEDS COMMENT
    q.get_nowait()
    callback_called[0] = True


# Generated at 2022-06-12 14:02:44.428057
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import collections
    import datetime
    import heapq
    import typing
    import Queue
    import asyncio
    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    class QueueEmpty(Exception):
        """Raised by `.Queue.get_nowait` when the queue has no items."""
        
        pass
    
    
    class QueueFull(Exception):
        """Raised by `.Queue.put_nowait` when a queue is at its maximum size."""
        
        pass
    
    

# Generated at 2022-06-12 14:02:54.763286
# Unit test for method put of class Queue
def test_Queue_put():
    with open("unit_test/unit_test_result/test_Queue_put.txt","w") as file:
    #q = Queue(maxsize=2)
        q=Queue()
        file.write(str(q))
        file.write("\n")
        future = Future()
        timeout = 0.1
        file.write(str(timeout))
        file.write("\n")
        _set_timeout(future, timeout)
        file.write(str(future))
        file.write("\n")        
        assert not future.done()
        item=5
        file.write(str(item))
        file.write("\n")
        future=q.put(item,timeout)
        file.write(str(future))
        file.write("\n")
        gen.sleep(1)

# Generated at 2022-06-12 14:03:05.674788
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():


    async def put_items(q: Queue):
        await q.put(1)
        await q.put(2)
        await q.put(3)
        await q.put(4)
        await q.put_nowait(5)


    async def get_items(q: Queue):
        item = await q.get()
        assert item == 5
        item = await q.get()
        assert item == 1
        item = await q.get()
        assert item == 2
        item = await q.get()
        assert item == 3
        item = await q.get()
        assert item == 4


    def test():
        q = Queue()
        io_loop = ioloop.IOLoop.current()
        io_loop.run_sync(lambda: put_items(q))
       

# Generated at 2022-06-12 14:03:14.885574
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """Test Queue._get_nowait"""
    import random
    import time
    import collections
    import unittest
    import io
    def _make_queue(maxsize: int = None) -> Queue[int]:
        return Queue(maxsize=maxsize)
    def _test_empty_queue(q: Queue[int]) -> None:
        with test_support.assertRaises(QueueEmpty):
            q.get_nowait()
    def _test_queue_empty_get_wait(q: Queue[int]) -> None:
        finished = False
        def get_done(future: Future[int]) -> None:
            nonlocal finished
            finished = True

# Generated at 2022-06-12 14:03:20.309740
# Unit test for method get of class Queue
def test_Queue_get():
    # Expected test result
    expected_result: Optional[str] = "get_nowait"

    # Expected test result
    print("Expected result:", expected_result)

    # Run unit test
    result = Queue.get(1)

    # Actual test result
    print("Actual result:", result)

    # Check test result
    assert expected_result == result


# Generated at 2022-06-12 14:03:21.981606
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get()


# Generated at 2022-06-12 14:03:27.208867
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue(maxsize=3)
    queue.put_nowait(1)
    queue.put_nowait(2)
    queue.put_nowait(3)
    assert queue.get_nowait() == 1
    assert queue.get_nowait() == 2
    assert queue.get_nowait() == 3


# Generated at 2022-06-12 14:03:41.573864
# Unit test for method get of class Queue
def test_Queue_get():
    # Creating an instance of Queue
    q = Queue(maxsize=2)
    # Creating an instance of Future
    future = Future()
    # Invoking method get of q and catching the exception thrown
    try:
        q.get(timeout=datetime.timedelta(seconds=0.02))
    except:
        # Expected the exception class
        print("Expected the exception QueueEmpty")
    # Invoking method put of q and catching the exception thrown
    try:
        q.put_nowait(item=0)
    except QueueFull:
        # Expected the exception class
        print("Expected the exception QueueFull")



# Generated at 2022-06-12 14:03:50.734159
# Unit test for method put of class Queue
def test_Queue_put():
    # Asynchronous Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:04:01.366192
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import time
    import random
    import itertools
    import asyncio
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    flag = 0
    q = Queue(maxsize=0)
    async def consumer():
        while True:
            item = await q.get()
            print("Doing work on", item)
            await gen.sleep(random.random())
            print("Finished", item)
            q.task_done()

    async def producer():
        for item in itertools.count():
            await q.put(item)
            print("Put", item)
            await gen.sleep(random.random())

    async def main():
        loop = IOLoop.current()
        loop.spawn_callback(consumer)


# Generated at 2022-06-12 14:04:05.862431
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=0)
    q.get_nowait()

    q.put(1)
    q.get_nowait()

    try:
        q.get_nowait()
        assert False, "Queue is empty, QueueEmpty exception should be raised"
    except QueueEmpty:
        pass

    q = Queue(maxsize=1)
    q.put(1)
    try:
        q.put(2)
        assert False, "Queue is full, QueueFull exception should be raised"
    except QueueFull:
        pass



# Generated at 2022-06-12 14:04:15.761100
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        print('wait for queue')
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all

# Generated at 2022-06-12 14:04:18.726611
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(0)
    future = Future()
    assert(q.put(1)) == future



# Generated at 2022-06-12 14:04:29.765533
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Unit test

# Generated at 2022-06-12 14:04:39.213971
# Unit test for method get of class Queue
def test_Queue_get():
    import pytest
    import time
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())

    q = Queue()
    loop = IOLoop.current()

    # put something in the queue
    await q.put(1)

    # consumer
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(2)
            finally:
                q.task_done()

    # producer
    async def producer():
        await q.put(1)

    loop.run_sync(producer)
    assert q.qsize() == 1

    loop.run_sync(consumer)
    assert q

# Generated at 2022-06-12 14:04:41.799434
# Unit test for method get of class Queue
def test_Queue_get():
    result = Queue.get(Queue, timeout=None)
    assert isinstance(result, Awaitable)

# Generated at 2022-06-12 14:04:46.214992
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        print('q.put_nowait(3) raise QueueFull')

# Generated at 2022-06-12 14:04:59.642825
# Unit test for method get of class Queue
def test_Queue_get():
    print("Executing test_Queue_get...")
    q = Queue(maxsize=2)
    for item in range(5):
        q.put(item)
    for i in range(5):
        print("item = ", q.get_nowait())
    finish=0
    if finish==0:
        print("test_Queue_get finished")
    else:
        print("test_Queue_get failed")

# Generated at 2022-06-12 14:05:09.106198
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    class MyQueue(Queue):
        _queue = None
        def _init(self):
            self._queue = collections.deque()
        def _get(self) -> _T:
            return self._queue.popleft()
        def _put(self, item: _T) -> None:
            self._queue.append(item)
    q = MyQueue(maxsize=1)
    # call put_nowait function with item is not None and queue is not full
    q.put_nowait(2)
    assert q._queue.popleft() == 2
    q._queue.append(1)
    q.put_nowait(3)
    assert q._queue[1] == 3
    # call put_nowait function with item is None and queue is not full
    q.put_nowait(None)
   

# Generated at 2022-06-12 14:05:18.264115
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.full() == False
    assert q.empty() == True
    assert q.qsize() == 0
    try:
        q.put_nowait(5)
    except QueueFull:
        assert False
    assert q.full() == False
    assert q.empty() == False
    assert q.qsize() == 1
    try:
        q.put_nowait(10)
    except QueueFull:
        assert False
    assert q.full() == True
    assert q.empty() == False
    assert q.qsize() == 2
    try:
        q.put_nowait(15)
    except QueueFull:
        assert True
    assert q.full() == True
    assert q.empty() == False
    assert q.qsize()

# Generated at 2022-06-12 14:05:25.270476
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    """Unit test for method get_nowait of class Queue"""

    import random
    import time
    import unittest

    from concurrent.futures import ThreadPoolExecutor
    from tornado import gen, httpclient, ioloop, queues

    @gen.coroutine
    def get_url(url):
        http = httpclient.AsyncHTTPClient()
        response = yield http.fetch(url)
        raise gen.Return(response.body)

    @gen.coroutine
    def main():
        q = queues.Queue()
        start = time.time()
        yield q.put(get_url("http://www.tornadoweb.org/en/stable/"))
        yield q.put(get_url("http://www.tornadoweb.org/en/stable/"))

# Generated at 2022-06-12 14:05:28.278094
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=10)
    try:
        q.get_nowait()
    except QueueEmpty:
        print("QueueEmpty")
    else:
        print("QueueNonEmpty")


# Generated at 2022-06-12 14:05:35.421483
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import sys
    import unittest
    import subprocess
    from tornado.queues import Queue, QueueEmpty


    class QueueTest(unittest.TestCase):
        def test_get_nowait(self):
            q = Queue(maxsize=3)
            q.put_nowait(0)
            q.put_nowait(1)
            q.put_nowait(2)
            self.assertEqual(0, q.get_nowait())
            self.assertEqual(1, q.get_nowait())
            self.assertEqual(2, q.get_nowait())
            with self.assertRaises(QueueEmpty):
                q.get_nowait()


    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-12 14:05:42.036016
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    f = q.put(1, timeout=None)
    f.set_result(None)

    g = q.put(2, timeout=None)
    g.set_result(None)

    h = q.put(3, timeout=None)
    h.set_exception(QueueFull())

    i = q.put(4, timeout=None)
    i.set_exception(QueueFull())

# Generated at 2022-06-12 14:05:42.512133
# Unit test for method get of class Queue
def test_Queue_get():
    pass

# Generated at 2022-06-12 14:05:47.025396
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = Future()  
    item = 1
    timeout = 0#not used in tornado.queues.Queue.put
    try:
        q.put_nowait(item)
    except QueueFull:
        q._putters.append((item, future))
        _set_timeout(future, timeout)
    else:
        future.set_result(None)
    return future


# Generated at 2022-06-12 14:05:55.998759
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import unittest
    import random
    import queue
    import time
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler, WebSocketClosedError
    from tornado.queues import QueueEmpty

    connections = [ ]
    messages = queue.Queue()

    class TestHandler(WebSocketHandler):
        def get_compression_options(self):
            # Non-None enables compression with default options.
            return {}

        def open(self):
            print ('new connection')
            connections.append(self)

        def on_close(self):
            print ('connection closed')
            connections.remove(self)

        def on_message(self, message):
            print ('got message %r', message)
            messages.put_nowait(message)

# Generated at 2022-06-12 14:06:12.028690
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.put_nowait(1)
    assert queue.get_nowait() == 1
    assert queue.empty() == True
    assert queue.get_nowait() == None


# Generated at 2022-06-12 14:06:14.044848
# Unit test for method put of class Queue
def test_Queue_put():
    assert Queue().put(1)
    assert Queue().put(None)
    assert Queue().put(QueueFull())
    assert Queue().put(QueueEmpty())


# Generated at 2022-06-12 14:06:27.398311
# Unit test for method get of class Queue
def test_Queue_get():

    q = Queue(maxsize=2)

    #@gen.coroutine
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    #@gen.coroutine
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    #@gen.coroutine
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:06:30.549015
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q=Queue()
    try:
        q.put_nowait("new_item_in_queue")
    except QueueFull:
        assert False, "This queue is not full"
    else:
        assert True, "This function put_nowait was executed"

# Generated at 2022-06-12 14:06:33.033374
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        raise Exception("Failed")


# Generated at 2022-06-12 14:06:37.717523
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(item=1, timeout=1)
    assert type(future) == Future
    assert future.result() == None
    assert q.queue == [1]


# Generated at 2022-06-12 14:06:44.514208
# Unit test for method put of class Queue
def test_Queue_put():
    a= Queue()
    future = Future()
    try:
        a.put_nowait(1)
        a.put_nowait(2)
        a.put_nowait(3)
    except:
        print('QueueFull')
    try:
        a.put_nowait(4)
        a.put_nowait(5)
        a.put_nowait(6)
    except:
        print('QueueFull')
    try:
        a.put_nowait(7)
        a.put_nowait(8)
        a.put_nowait(9)
    except:
        print('QueueFull')


# Generated at 2022-06-12 14:06:52.742642
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Init a Queue
    q = Queue()
    # Put a item into the queue
    q.put_nowait(1)
    # Call get_nowait of queue
    assert q.get_nowait() == 1
    assert q.empty() == True
    try:
        q.get_nowait()
        print("ERROR: get_nowait doesn't raise QueueFull when queue is empty")
    except QueueEmpty:
        pass
    except Exception:
        print("ERROR: unexcepted exception raised by get_nowait")


# Generated at 2022-06-12 14:07:03.081755
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import asyncio
    counter = 0
    def print_num(name):
        print(name,':',counter)
    async def consumer():
        nonlocal counter
        while counter < 5:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                counter += 1
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
            print_num('put')
    async def main():
        # Start consumer without waiting (since it never finishes).
        await consumer()     # Wait for producer to put all tasks.
        await producer()     # Wait for consumer to finish all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:07:06.529409
# Unit test for method put of class Queue
def test_Queue_put():
  from random import random
  q = Queue()
  q.put(random())
  q.put(random())
  q.put(random())
  assert q.maxsize == 0


# Generated at 2022-06-12 14:07:21.973251
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q.get() # __clinit__ in Queue.class
    q.put_nowait(1)
    q.get()


# Generated at 2022-06-12 14:07:27.680558
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
        print("Test of method put_nowait")
        the_queue = Queue(maxsize=2)
        the_queue.put_nowait(1)
        the_queue.put_nowait(2)
        try:
            the_queue.put_nowait(3)
            assert False
        except Exception:
            assert True
            print("Put_nowait works well")


# Generated at 2022-06-12 14:07:38.612270
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in "abcd":
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer

# Generated at 2022-06-12 14:07:41.676089
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    if q.qsize() == 0:
        print("get: Queue is not empty")
        return False
    print("get: Queue is empty")
    return True

# Generated at 2022-06-12 14:07:52.120549
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    q._init()
    q._getters.append(Future())
    q._putters.append((0, Future()))
    q._consume_expired()
    assert len(q._queue) == 2
    assert len(q._getters) == 0
    assert len(q._putters) == 0

    q._getters.append(Future())
    q._consume_expired()
    assert len(q._queue) == 2
    assert len(q._getters) == 0

    q._putters.append((0, Future()))
    q._putters.append((1, Future()))
    q._consume_expired()
    assert len(q._queue) == 2
    assert len(q._putters) == 1


# Generated at 2022-06-12 14:08:02.808028
# Unit test for method put of class Queue
def test_Queue_put():

    # Test the method put of class Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:08:05.331629
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.empty() == True
    assert q.empty() == True

# Generated at 2022-06-12 14:08:09.342913
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q._queue.insert(0, 0)
    print(q._queue)
    return None


test_Queue_put_nowait()



# Generated at 2022-06-12 14:08:10.262354
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	pass



# Generated at 2022-06-12 14:08:15.079458
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(1)
    try:
        q.put_nowait("item1")
        q.put_nowait("item2")
        assert False
    except Exception as e:
        assert isinstance(e, QueueFull)
    try:
        assert "item1" == q.get_nowait()
        assert "item2" == q.get_nowait()
        assert False
    except Exception as e:
        assert isinstance(e, QueueEmpty)


# Generated at 2022-06-12 14:08:51.876887
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    queue = Queue()
    print(queue.empty())
    print(queue.full())
    print(queue.maxsize)
    print(queue.put_nowait(1))
    print(queue.empty())
    print(queue.full())
    print(queue.put_nowait(2))
    print(queue.qsize())
    print(queue._queue)
    print(queue.put_nowait(3))
    print(queue.put_nowait(4))
    print(queue.put_nowait(5))
    print(queue.qsize())
    print(queue._queue)
    print(queue.put_nowait(6))

# Generated at 2022-06-12 14:09:01.594578
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
        q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()
        await q.join()
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:09:07.834228
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import tornado.ioloop

    q = Queue()

    async def f1():
        await q.put(1)
        await q.put(2)
        await q.put(3)
        await q.put(4)

    async def f2():
        await q.get()
        await q.get()
        await q.get()

    async def f3():
        await q.put(5)
        await q.put(6)
        await q.put(7)
        await q.put(8)

    async def f4():
        await q.get()
        await q.get()

    async def f5():
        await q.put(9)
        await q.put(10)
        await q.put(11)
        await q.put(12)

#

# Generated at 2022-06-12 14:09:18.152584
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    def my_put_nowait(q, item):
        if (q.maxsize == 0):
            return
        if (q.maxsize == None):
            return
        if (q.maxsize < 0):
            return
        from collections import deque
        q._getters = deque([])  # type: Deque[Future[_T]]
        q._putters = deque([])  # type: Deque[Tuple[_T, Future[None]]]
        q._unfinished_tasks = 0
        q._finished = Event()
        q._finished.set()
        if not q._getters:
            q.__put_internal(item)
        else:
            if not q.full():
                q.__put_internal(item)
            else:
                raise QueueFull



# Generated at 2022-06-12 14:09:22.663085
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    assert q.empty() == True
    assert q.qsize() == 0
    assert q.full() == False
    q.put_nowait(33)
    assert q.empty() == False
    assert q.qsize() == 1
    assert q.full() == True

# Generated at 2022-06-12 14:09:26.131355
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    assert q._queue[0] == 1
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.full() == True


# Generated at 2022-06-12 14:09:36.084830
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Prepare
    q = Queue(maxsize=10)
    q.__put_internal(2)  # fill the queue
    
    # Execute
    q.put_nowait(10)
    
    # Assert
    assert q.qsize() == 2 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 14:09:39.283225
# Unit test for method put of class Queue
def test_Queue_put():

    it = Queue()

    #This should pass
    it.put(1)
    #This should pass
    it.put(None)
    #This should pass
    it.put_nowait(1)
    #This should pass
    it.put_nowait(None)



# Generated at 2022-06-12 14:09:44.760900
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    # Verify it is empty
    if q.empty():
        print("PASS")
    else:
        print("FAIL")

    # Put some elements
    q.put_nowait("abcd")
    q.put_nowait("efgh")

    # Verify it is not empty
    if q.empty():
        print("FAIL")
    else:
        print("PASS")

    # Verify the size
    if q.qsize() == 2:
        print("PASS")
    else:
        print("FAIL")

    # Get the first element
    print(q.get_nowait())

    # Verify the size
    if q.qsize() == 1:
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-12 14:09:50.530666
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    Q = Queue()
    for i in range(59, -1, -1):
        Q.put_nowait(i)
    assert Q.qsize() == 60
    assert Q.maxsize == 0
    assert Q.full() is False
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    Q.get_nowait()
    assert Q.qsize() == 56
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    with pytest.raises(QueueEmpty):
        Q.get_nowait()
    with pytest.raises(QueueEmpty):
        Q