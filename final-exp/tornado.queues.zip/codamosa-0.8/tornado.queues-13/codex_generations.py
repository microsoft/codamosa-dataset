

# Generated at 2022-06-12 14:01:25.156542
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)
            await gen.sleep(0.01)
            q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:01:36.722212
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:01:46.070868
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    q = Queue()

    async def async_producer():
        for item in ranqe(10):
            print('Put %s' % item)
            await q.put(item)

    async def async_consumer():
        while True:
            print('Consumed')
            item = await q.get()
            try:
                print('Doing work on %s' %item)
            finally:
                q.task_done()

    async def main():
        IOLoop.current().spawn_callback(async_consumer)
        await async_producer()
        await q.join()

    IOLoop().run_sync(main)

# Generated at 2022-06-12 14:01:47.201457
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass


# Generated at 2022-06-12 14:01:50.298140
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    q.put(2)
    q.put(3)
    q.put(4)

# Generated at 2022-06-12 14:01:54.929987
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize = 2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2, "put_nowait method of class Queue doesn't work well"
    print("put_nowait method of class Queue works well")
    
test_Queue_put_nowait()


# Generated at 2022-06-12 14:01:56.664594
# Unit test for method put of class Queue
def test_Queue_put():
    from queue import Queue
    q = Queue()
    q.put(1)
    assert q.qsize() == 1


# Generated at 2022-06-12 14:02:02.450134
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    import queue
    import threading
    from tornado.platform.asyncio import to_asyncio_future
    from tornado import gen
    from tornado import ioloop
    from tornado.queues import Queue

    q = Queue(maxsize=1)
    counter = 0
    b_done = threading.Event()

    def th_func():
        global counter
        try:
            counter = 100
            f = q.put(42) # Returns Future
            assert isinstance(f, Future)
            assert f.result() is None # Block until the Future is done
            assert q.full()
            assert q.qsize() == 1
            counter = 200
            assert q.get_nowait() == 42
            assert q.empty()
            assert q.qsize() == 0
        finally:
            b

# Generated at 2022-06-12 14:02:05.170323
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    item = queue.get_nowait()
    assert item == None


# Generated at 2022-06-12 14:02:05.903497
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    pass

# Generated at 2022-06-12 14:02:35.237492
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.put_nowait('a')
    assert q.get_nowait() == 'a'

test_Queue_get_nowait()



# Generated at 2022-06-12 14:02:43.244712
# Unit test for method put of class Queue
def test_Queue_put():
    Q = Queue()
    test_item1 = 1
    test_item2 = 2
    test_item3 = 3
    test_item4 = 4
    test_item5 = 5
    Q.put(test_item1)
    Q.put(test_item2)
    Q.put(test_item3)
    Q.put(test_item4)
    Q.put(test_item5)
    assert Q._queue[0] == test_item1
    assert Q._queue[1] == test_item2
    assert Q._queue[2] == test_item3
    assert Q._queue[3] == test_item4
    assert Q._queue[4] == test_item5


# Generated at 2022-06-12 14:02:46.142910
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    q.put("a")
    q.put("b")
    q.put("c")
    assert q.qsize() == 2


# Generated at 2022-06-12 14:02:55.988938
# Unit test for method put of class Queue
def test_Queue_put():
    import sys
    import types
    import itertools
    import math
    from datetime import timedelta
    from unittest import mock
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.queues import Queue, QueueEmpty
    from tornado.test.util import unittest, AsyncTestCase, skipIfNonUnix, timeout, skipOnTravis, skipIfNoPycurl
    from tornado.test.util import skipOnTravis # import added

    #@tornado.testing.gen_test
    def test_put(self):
        q = Queue()
        yield q.put(object())
        self.assertEqual(q.qsize(), 1)
    # Unit test for method get of class Queue
   

# Generated at 2022-06-12 14:03:07.253384
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Testing if Queue.get() is implemented correctly
    """
    print("\nTesting Queue.get()")
    q = Queue()
    using_get = True
    try:
        q.get_nowait()
    except Exception as e:
        assert type(e) is QueueEmpty
        using_get = False
    if using_get:
        print("Queue.get_nowait() was used instead of Queue.get()!\n"
            + "Skipping tests for Queue.get()")
        return

    q = Queue()
    for i in range(10):
        q.put_nowait(i)
    for i in range(10):
        assert q.get_nowait() == i

# Generated at 2022-06-12 14:03:15.838781
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    current = ioloop.IOLoop.current()
    q = Queue(maxsize=0)
    assert q.empty() is True
    assert q.full() is False

    current.spawn_callback(q.put, 1)
    current.spawn_callback(q.put, 2)
    current.spawn_callback(q.put, 3)

    current.spawn_callback(q.get_nowait)
    current.spawn_callback(q.get_nowait)
    current.spawn_callback(q.get_nowait)
    current.spawn_callback(q.get_nowait)

    assert q.qsize() is 3
    assert q.empty() is False
    assert q.full() is False


    # Set a max size
    q = Queue(maxsize=2)
    assert q.empty

# Generated at 2022-06-12 14:03:27.028051
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:35.906016
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:03:41.822248
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
                                                                                                                                                                                                                                                                                        

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
                                                                                                                                                                                                                                                                                        

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait

# Generated at 2022-06-12 14:03:47.893926
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import testing
    import tornado.ioloop
    import tornado.platform.asyncio
    from tornado.queues import Queue
    import asyncio
    @testing.gen_test
    def test_get():
        q = Queue()
        q.put(1)
        q.put(2)
        q.put(3)
        res = []

# Generated at 2022-06-12 14:04:41.851289
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize = 0)
    # put item in the queue
    queue.put(item = 2, timeout = None)
    # test if the queue is empty
    assert queue.empty() == False


# Generated at 2022-06-12 14:04:44.047888
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    res = q.get_nowait()
    assert res == 1


# Generated at 2022-06-12 14:04:54.300240
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Simple test
    q = Queue()
    q._queue = [1,2,3]
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    try:
        q.get_nowait()
        assert False, "Expected exception was not raised!"
    except QueueEmpty:
        pass
    # Test with a simple getter
    q = Queue()
    q._queue = [1,2,3,4]
    q._getters = deque([Future()])
    q.get_nowait()
    assert q._getters == [], "More than one getter was removed!"
    assert q._queue == [2,3,4], "Invalid queue after execution of get_nowait"
    # Test with a

# Generated at 2022-06-12 14:04:57.685257
# Unit test for method put of class Queue
def test_Queue_put():
    _queue = Queue(maxsize=2)
    future = _queue.put(item="item", timeout=None)
    assert future.result()==None and _queue.full()


# Generated at 2022-06-12 14:05:01.623156
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    print (q)
test_Queue_put_nowait()


# Generated at 2022-06-12 14:05:08.252007
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        print('It is wrong.')
    except QueueFull:
        print('It is right.')

    q.get_nowait()
    q.get_nowait()
    try:
        q.get_nowait()
        print('It is wrong.')
    except QueueEmpty:
        print('It is right.')




# Generated at 2022-06-12 14:05:10.506688
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(0)
    with pytest.raises(QueueFull):
        q.put_nowait(1)


# Generated at 2022-06-12 14:05:16.222353
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:18.463539
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    with pytest.raises(QueueFull):
        q.put_nowait(2)


# Generated at 2022-06-12 14:05:23.386679
# Unit test for method get of class Queue
def test_Queue_get():

    """Unit test for method get of class Queue

    The method test_Queue_get() tests the get() method of class Queue
    """
    # Create a queue with maxsize as 2
    q = Queue(maxsize=2)
    assert(q.maxsize == 2), "maxsize of queue should be equal to 2"
    assert(q.qsize() == 0), "qsize of queue should be equal to 0"
    assert(q.empty() == True), "queue should be empty"
    assert(q.full() == False), "queue should not be full"

# Generated at 2022-06-12 14:06:01.882331
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	myQueue = Queue(maxsize=2);
	myQueue.put_nowait(1)
	## get_nowait function should return the first element in the queue
	assert myQueue.get_nowait() == 1
	


## Unit test for method get of class Queue

# Generated at 2022-06-12 14:06:06.768760
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue(maxsize=1)
    queue.put(1)
    # _set_timeout(queue.put(1), None)
    assert True
if __name__ == '__main__':
    test_Queue_put()
    test_Queue_qsize()

 

# Generated at 2022-06-12 14:06:15.218076
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import asyncio
    async def func():
        #create Queue obj
        q = Queue(2)
        #put 1,2 into q directly
        q.put_nowait(1)
        q.put_nowait(2)
        
        #get 1 from q and print it
        x = q.get_nowait()
        print('get',x,'from q:')
        #vars to record the result of compare
        res1 = False
        res2 = False
        #compare x with 1 and 2
        if x == 1:
            res1 = True
        if x == 2:
            res2 = True
        #get nowait()
        #put a new one, x = 3 and get it again
        q.put_nowait(3)
        x = q.get_nowait()
        print

# Generated at 2022-06-12 14:06:22.818267
# Unit test for method put of class Queue
def test_Queue_put():
    """
    Test Queue.put with no timeout
    """
    q = Queue(maxsize=1)
    future = q.put(1)
    assert future.result() == None
    future = q.put(2)
    assert future.result() == None
    assert q.qsize() == 2
    

# Generated at 2022-06-12 14:06:31.931036
# Unit test for method put of class Queue
def test_Queue_put():
    async def async_func():
        q=Queue(maxsize=1)
        future1=Future()
        future2=Future()
        future3=Future()
        #queue is empty, item will be put in
        q.put_nowait(5)
        #queue is full, call q.put_nowait will raise QueueFull exception
        try:
            q.put_nowait(6)
        except QueueFull:
            future1.set_result(True)
        #create a putter(input item, output is future), putter will be put in putter queue
        q.put(item=7,timeout=None)
        if len(q._putters)>0:
            future2.set_result(True)

# Generated at 2022-06-12 14:06:42.759246
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import timeit
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    import concurrent.futures as cf
    import threading
    import random
    import pytest
    import string
    import time
    import sys
    import logging
    import time

    logging.basicConfig(filename="test_log.log", level=logging.DEBUG)
    sys.setrecursionlimit(10000)
    loop = IOLoop.current()


    def test_putting_into_q():
        global q
        for i in range(5000):
            q.put(random.choice(string.ascii_letters))


    # This is the function to be benchmarked.
    def start_test():
        global q
        q = Queue()
        start = time.clock

# Generated at 2022-06-12 14:06:50.358259
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    q.put(1)   
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except QueueFull:
        pass
    else:
        assert(0)
    q.put(3)
    assert q.qsize() == 2


# Generated at 2022-06-12 14:06:54.776996
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
   q = Queue(maxsize=2)
   
   q.put(1)
   q.put(2)
   q.put(3)
   
   a = q.get_nowait()
   b = q.get_nowait()
   
   assert a == 1
   assert b == 2
   assert q.qsize() == 1


# Generated at 2022-06-12 14:06:58.522801
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    assert q.qsize() == 0
    q.put_nowait(1)
    assert q.qsize() == 1
    q.put_nowait(2)
    assert q.qsize() == 2
    try:
        q.put_nowait(3)
    except tornado.queues.QueueFull:
        pass
    assert q.qsize() == 2


# Generated at 2022-06-12 14:07:02.797544
# Unit test for method put of class Queue
def test_Queue_put():
	q = Queue(maxsize=2)
	future = q.put(1)
	future.done()

	future = q.put(2)
	future.done()

	future = q.put(3)
	future.done()


# Generated at 2022-06-12 14:07:33.823073
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    ret = q.put(1)
    assert ret.done()
    assert ret.result() == None
    assert q._queue == collections.deque([1])
    assert q._unfinished_tasks == 1
    assert q._finished.is_set() == False
    q._finished.set()
    ret = q.put(2)
    assert ret.done()
    assert ret.result() == None
    assert q._queue == collections.deque([1, 2])
    assert q._unfinished_tasks == 2
    assert q._finished.is_set() == False
    q._finished.set()
    ret = q.put(3)
    assert ret.done() == False
    assert ret.result() == None

# Generated at 2022-06-12 14:07:43.177454
# Unit test for method put of class Queue
def test_Queue_put():
    # construct a queue object with argument max_size as 2
    q = Queue(maxsize = 2)
    # put item "1" into the queue with argument timeout as 1 minute
    q.put(1, timeout = 1)
    # put item "2" into the queue with argument timeout as 1 minute
    q.put(2, timeout = 1)
    # put item "3" into the queue with argument timeout as 1 minute
    if q.put(3, timeout = 1):
        print("Put item 3 into the queue")
    else:
        print("Error from put method of Queue")

# unit test for method get of class Queue

# Generated at 2022-06-12 14:07:46.522573
# Unit test for method put of class Queue
def test_Queue_put():
    # Test the put method
    q = Queue()
    q.put_nowait(10)
    q.put_nowait(20)
    q.put_nowait(30)
    assert(q.full() == False)
    try:
        q.put_nowait(40)
    except QueueFull:
        pass
    assert(q.full() == True)
test_Queue_put()


# Generated at 2022-06-12 14:07:51.282362
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put " + str(item))
    def main():
        ioloop.IOLoop.current().run_sync(producer)
    main()
test_Queue_put()

# Generated at 2022-06-12 14:07:53.537609
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    with pytest.raises(QueueEmpty):
        q.get_nowait()

# Generated at 2022-06-12 14:08:04.962675
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    async def consumer(q: "Queue[_T]") -> None:
        item = q.get_nowait()
        try:
            print('Doing work on %s' % item)
        finally:
            q.task_done()

    q = Queue(maxsize=5)
    q._getters.append(Future())
    q._getters.append(Future())
    q._queue.append(1)
    q._queue.append(2)
    q._queue.append(3)
    q._queue.append(4)
    q._queue.append(5)
    q._unfinished_tasks = 5
    consumer(q)
    assert q.empty() is False
    assert q.full() is True
    assert q._queue == deque([2, 3, 4, 5, 5])

# Generated at 2022-06-12 14:08:06.324396
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    assert q.get_nowait() == None

# Generated at 2022-06-12 14:08:09.221213
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q._queue = [1, 2]
    assert q.get_nowait() == 1, '''Method get_nowait of class Queue works incorrectly'''


# Generated at 2022-06-12 14:08:16.475379
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    assert queue.qsize() == 0
    assert queue.full() == False
    assert queue.empty() == True
    try:
        queue.put_nowait(0)
    except Exception:
        assert True
    assert queue.qsize() == 0
    assert queue.full() == False
    assert queue.empty() == True
    queue._maxsize = 2
    queue.put_nowait(0)
    assert queue.qsize() == 1
    assert queue.full() == False
    assert queue.empty() == False
    queue.put_nowait(1)
    assert queue.qsize() == 2
    assert queue.full() == True
    assert queue.empty() == False
    try:
        queue.put_nowait(1)
    except Exception:
        assert True

# Generated at 2022-06-12 14:08:17.236146
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
     pass