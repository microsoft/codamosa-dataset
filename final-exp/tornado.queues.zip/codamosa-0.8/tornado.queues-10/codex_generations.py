

# Generated at 2022-06-12 14:01:05.691176
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    future = q.put(5, timeout=5)
    return future


# Generated at 2022-06-12 14:01:12.614737
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    loop = ioloop.IOLoop.current()
    q = Queue(maxsize=1)
    assert q.maxsize == 1
    # Put to queue a first element
    # without blocking
    q.put_nowait(1)
    # Check q.qsize()
    assert q.qsize() == 1
    # Put to queue a second element
    # It raises QueueFull exception
    try:
        q.put_nowait(2)
    except QueueFull:
        assert True
    else:
        assert False

# Generated at 2022-06-12 14:01:13.783611
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    assert False # TODO: implement your test here


# Generated at 2022-06-12 14:01:21.528767
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)

    # case 1.1: q not full, getters empty
    if q.full():
        raise RuntimeError
    if not q._getters:
        pass
    else:
        raise RuntimeError
    q.put_nowait(1)
    if q._queue[0] == 1:
        pass
    else:
        raise RuntimeError

    # case 1.2: q not full, getters not empty
    q = Queue(maxsize=2)
    q._getters.append(1)
    if q.full():
        raise RuntimeError
    if q._getters:
        pass
    else:
        raise RuntimeError
    q.put_nowait(1)
    if q._queue[0] == 1:
        pass
    else:
        raise Runtime

# Generated at 2022-06-12 14:01:30.142741
# Unit test for method put of class Queue
def test_Queue_put():
    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        yield q.put(item)
        print('Put %s' % item)
        
    q = Queue(maxsize=2)
    item = 1
    IOLoop.current().run_sync(producer)
    IOLoop.current().run_sync(consumer)
    print("End")


# Generated at 2022-06-12 14:01:41.173964
# Unit test for method get of class Queue
def test_Queue_get():
    import random
    import asyncio
    async def put_data(qu):
        # await asyncio.sleep(random.random())
        await qu.put(random.randint(1, 10))
        print("put_data")

    async def get_data(qu):
        await asyncio.sleep(random.random())
        print("get data",  await qu.get())

    q = Queue()
    tasks = [put_data(q) for i in range(10)]
    tasks1 = [get_data(q) for i in range(10)]
    # loop = asyncio.get_event_loop()
    loop = ioloop.IOLoop.current()
    loop.add_callback(asyncio.wait, tasks)
    loop.add_callback(asyncio.wait, tasks1)

# Generated at 2022-06-12 14:01:52.818010
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:01:57.110207
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q=Queue()
    try:
        print("Passed test 1")
        q.put_nowait("hello1")
        print("Passed test 2")
        q.put_nowait("hello2")
        print("Passed test 3")
        q.put_nowait("hello3")
        print("Should not print this")
    except Exception as e:
        print(e)


# Generated at 2022-06-12 14:01:58.912682
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # the only method to be tested
    #TODO:
    return True



# Generated at 2022-06-12 14:02:10.645759
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    try:
        print('Try to get item from empty queue')
        x = q.get()
        print(x)
    except QueueEmpty:
        print('Queue is empty')
    print('Put item 1')
    q.put_nowait(1)
    print('Try to get item from queue')
    x = q.get_nowait()
    print(x)
    print('Put item 2')
    q.put_nowait(2)
    try:
        print('Try to put item 3 to full queue')
        q.put_nowait(3)
        print('No exception')
    except QueueFull:
        print('Queue is full')

# Generated at 2022-06-12 14:02:22.877322
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()

    def put(i):
        q.put(i)

    def get():
        return q.get()

    seq_result = []
    for _ in range(5):
        seq_result.append(get())

    q.put(1)
    q.put(2)
    assert q.get_nowait() == 1
    put(3)
    q.put(4)
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    assert q.get_nowait() == 4

    # q.put(1)
    # assert q.get_nowait() == 1



# Generated at 2022-06-12 14:02:29.723539
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.qsize() == 0
    try:
        q.get_nowait()
    except QueueEmpty:
        pass
    else:
        assert False, "should raise QueueEmpty"
    q.put_nowait(1)
    x = q.get_nowait()
    assert x == 1
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.qsize() == 2
    try:
        q.put_nowait(4)
    except QueueFull:
        pass
    else:
        assert False, "should raise QueueFull"



# Generated at 2022-06-12 14:02:37.208628
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    L = []
    q = Queue(maxsize = 2)
    q.put_nowait('a')
    L.append(q.qsize() == 1)
    q.put_nowait('b')
    L.append(q.qsize() == 2)
    try:
        q.put_nowait('c')
    except QueueFull:
        L.append(True)

    assert all(L)


# Generated at 2022-06-12 14:02:44.930877
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer(num):
        for item in range(num):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer(5)     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:02:52.014239
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Setup
    q = Queue(maxsize=2)
    q._queue = (1, 2, 3)
    q._getters = collections.deque([])

    # Precondition
    assert isinstance(q._queue, collections.deque)
    assert isinstance(q._getters, collections.deque)
    assert isinstance(q, Queue)

    # Test
    q.get_nowait()

    # Postcondition
    assert not q.empty()



# Generated at 2022-06-12 14:02:59.055839
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    IOLoop.current().run_sync(main)
from tornado import gen
from tornado.ioloop import IOLoop

# Generated at 2022-06-12 14:03:09.998789
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:03:15.539963
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    # Check basic empty/full behavior
    q = Queue(2)
    q.put_nowait(1)
    assert q._queue == deque([1])
    assert q.get_nowait() == 1
    assert q._queue == deque()
    q.put_nowait(1)
    assert q._queue == deque([1])
    q.put_nowait(2)
    assert q._queue == deque([1, 2])
    with raises(QueueFull):
        q.put_nowait(3)
    assert q._queue == deque([1, 2])

    # Make sure that the maxsize is still enforced
    # if there are getters waiting
    q = Queue(1)
    fut = Future()
    q._getters.append(fut)
    q.put_nowait

# Generated at 2022-06-12 14:03:26.712381
# Unit test for method get of class Queue
def test_Queue_get():
    # Test get with expected value and timeout -1
    q = Queue()
    # ret_value should be 0 and @gen.coroutine should return object of type Future
    ret_value = q.get(-1)  # type: Future
    assert ret_value.__class__ == Future

    # Test get with expected value and timeout 0
    q = Queue()
    # ret_value should be 0 and @gen.coroutine should return object of type Future
    ret_value = q.get(0)  # type: Future
    assert ret_value.__class__ == Future

    # Test get with expected value and timeout 100
    q = Queue()
    # ret_value should be 0 and @gen.coroutine should return object of type Future
    ret_value = q.get(100)  # type: Future

# Generated at 2022-06-12 14:03:35.680999
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    class Mock():
        def __init__(self):
            self._queue = []
            self._getters = []
        def qsize(self):
            return len(self._queue)
        def empty(self):
            return self.qsize() == 0
        def get_nowait(self):
            if self.empty():
                raise QueueEmpty
            return self._queue.pop()
        def put_nowait(self, item):
            self._queue.append(item)
    mock_queue = []
    mock = Mock()
    mock.put_nowait(1)
    mock.put_nowait(2)
    mock_queue.append(mock.get_nowait())
    mock_queue.append(mock.get_nowait())
    mock.put_nowait(3)
    mock.put

# Generated at 2022-06-12 14:03:57.829680
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=1)
    @gen.coroutine
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await q.put(1)
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
        q.get()
    # print('Done')
    ioloop.IOLoop.current().run_sync(main)
test_Queue_get()

# Generated at 2022-06-12 14:03:59.893571
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize = 2)

    q.put_nowait(1)
    q.get()
    q.qsize()
    q.task_done()
    q.join()



# Generated at 2022-06-12 14:04:11.199806
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:04:12.256169
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.put(1) == None


# Generated at 2022-06-12 14:04:13.920980
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    Item = "item"
    q.put_nowait(Item)
    assert q.qsize() == 1

# Generated at 2022-06-12 14:04:21.322481
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:04:28.545840
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    # ensure the queue is empty.
    assert(len(q._queue) == 0)

    item = 0
    # put 2 items into the queue.
    q.put_nowait(item)
    item += 1
    q.put_nowait(item)
    assert(len(q._queue) == 2)
    
    # get an item from the queue.
    ans = q.get_nowait()
    
    assert(ans == 0)
    assert(len(q._queue) == 1)
    item = 2
    q.put_nowait(item)

    ans = q.get_nowait()
    assert(ans == 1)
    assert(len(q._queue) == 1)
    ans = q.get_nowait()

# Generated at 2022-06-12 14:04:38.212655
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:04:49.522564
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)
test_Queue_

# Generated at 2022-06-12 14:05:00.967860
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    future = q.get()
    q.put(item = 1)
    future = q.get(timeout = 2)
    q.get_nowait()
    q.task_done()
    q.join()

    q.join(timeout=2)
    q._format()
    res = q.__aiter__()
    q.empty()
    q.full()
    q.get_nowait()
    q.join()
    q.put(item=1)
    q.put_nowait(1)
    q.qsize()
    q.task_done()
    q._init()
    q._get()
    q._put()
    x = 3
    if x == 3:
       print(True)

# Generated at 2022-06-12 14:05:20.895976
# Unit test for method put of class Queue
def test_Queue_put():
    # Test with None input
    a = Queue(maxsize=2)
    try:
        a.put(None)
    except TypeError:
        b = False
        print("b is", b)
        pass
    else:
        b = True
        print("b is", b)

    # Test with negative integer input
    c = Queue(maxsize=-1)
    try:
        c.put(1)
    except ValueError:
        d = False
        print("d is", d)
        pass
    else:
        d = True
        print("d is", d)

    # Test with None timeout
    e = Queue(maxsize=2)

# Generated at 2022-06-12 14:05:23.052957
# Unit test for method get of class Queue
def test_Queue_get():
    # q = Queue()
    # q.get()
    print("test_Queue_get success")



# Generated at 2022-06-12 14:05:26.749658
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    # put item into the queue
    q.put_nowait(1)
    q.put_nowait(2)
    # get item from the queue
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2

# Generated at 2022-06-12 14:05:28.062300
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()

# Generated at 2022-06-12 14:05:35.285183
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Unit test

# Generated at 2022-06-12 14:05:36.610328
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()
    q.get_nowait()



# Generated at 2022-06-12 14:05:39.509330
# Unit test for method put of class Queue
def test_Queue_put():
    q=Queue(maxsize=5)
    for i in range(0,10):
        q.put_nowait(i)
    assert q.qsize() == 5

# Generated at 2022-06-12 14:05:42.782975
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    async def main():
        q = Queue(maxsize=0)
        await q.put("foo")
    asyncio.run(main())



# Generated at 2022-06-12 14:05:50.840525
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue()
    count = 0
    async def test():
        global count
        count += 1
        if count == 5:
            await q.put(0)
        if count == 5:
            item = await q.get()
            print(item)
            assert item == 0
        IOLoop.current().call_at(IOLoop.current().time() + 0.1, test)
    IOLoop.current().call_at(IOLoop.current().time() + 0.1, test)
    IOLoop.current().start()


# Generated at 2022-06-12 14:05:58.085867
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print(f'Doing work on {item}')
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print(f'Put {item}')
    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:06:23.479436
# Unit test for method get of class Queue
def test_Queue_get():
    import time
    import collections
    import typing
    import pytest

    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.test.util import unittest, skipIfNonUnix
    from tornado.gen import TimeoutError, sleep, coroutine, TimeoutError
    from tornado.locks import Event
    from tornado.platform.asyncio import AsyncIOMainLoop

    from tornado import  gen
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop


    ioloop = IOLoop()
    asyncio.set_event_loop(ioloop)
    queue = Queue(maxsize=10)
    queue.put('hello', 10)
    fut = queue.get()
    ioloop.add_future

# Generated at 2022-06-12 14:06:24.872478
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:06:32.033047
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    ioloop.IOLoop.current().run_sync(producer)   
    ioloop.IOLoop.current().run_sync(consumer) 

# Generated at 2022-06-12 14:06:36.927044
# Unit test for method get of class Queue
def test_Queue_get():
    queue = Queue()
    queue.put("first")
    assert queue.get()=="first","get function of Queue does not work"
    print("get function of Queue works fine if you're seeing this")

# Generated at 2022-06-12 14:06:38.721543
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue()
    q.get()

test_Queue_get()

# Generated at 2022-06-12 14:06:41.903726
# Unit test for method put of class Queue
def test_Queue_put():
    async def test():
        q1 = Queue()
        await q1.put(0)
        assert q1.qsize() == 1
    ioloop.IOLoop.current().run_sync(test)


# Generated at 2022-06-12 14:06:52.835231
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.ioloop import IOLoop
    import asyncio
    from time import time, sleep
    from datetime import datetime, timedelta
    loop = IOLoop.current()
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await asyncio.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        loop.call_later(2, loop.stop)
        loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.

# Generated at 2022-06-12 14:06:53.661873
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()


# Generated at 2022-06-12 14:06:56.784291
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    assert q.qsize() == 1

test_Queue_put_nowait()


# Generated at 2022-06-12 14:06:59.163929
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    with pytest.raises(QueueFull):
        q.put_nowait(3)

# Generated at 2022-06-12 14:08:21.560739
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    assert False, "can't be tested until the methods __init__ _queue _get _put are abstracted"



# Generated at 2022-06-12 14:08:25.041343
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    queue = Queue()
    queue.put_nowait(5)
    queue.put_nowait('a')
    assert queue.get_nowait() == 5
    assert queue.get_nowait() == 'a'

# Generated at 2022-06-12 14:08:26.059362
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import types
    assert isinstance(Queue.get_nowait,types.MethodType)
    pass

# Generated at 2022-06-12 14:08:27.269577
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(1)
    q.put_nowait('111')
    item = q.get_nowait()
    print(item)


# Generated at 2022-06-12 14:08:30.810219
# Unit test for method put of class Queue
def test_Queue_put():
    async def main():
        q = Queue()
        q.put(1)
        print(q.qsize())

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:08:41.268066
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    print('\n-------Unit Test test_Queue_get_nowait ----------\n')

    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        while True:
            item = await q.get()
            try:
                print('Doing work on %s' % item)
                yield gen.sleep(0.01)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


# Generated at 2022-06-12 14:08:44.999358
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(2)
    assert q.qsize() == 1
    print('pass')


# Generated at 2022-06-12 14:08:52.564497
# Unit test for method put of class Queue
def test_Queue_put():

    Q = Queue()


    #assert Q.put(1)  == 0
    Q.put(1)
    Q.put(2)
    Q.put(3)
    Q.put(4)
    assert Q.put(5)  == 1
    assert Q.put(6)  == 1
    assert Q.put(7)  == 1
    assert Q.put(8)  == 1
    assert Q.put(9)  == 1
    assert Q.put(10) == 1


test_Queue_put()


# Generated at 2022-06-12 14:08:55.421231
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    _queue = Queue()
    _queue.get_nowait()
    _queue.put_nowait(1)
    _queue.get_nowait()
    _queue.task_done()

# Generated at 2022-06-12 14:09:04.726975
# Unit test for method put of class Queue
def test_Queue_put():
    # Invalid type of parameter timeout
    with pytest.raises(TypeError):
        q = Queue(maxsize=2)
        res = q.put(1, timeout=1.0)

    # Use parameter timeout in type of float
    q = Queue(maxsize=2)
    timeout = 1.0
    res = q.put(1, timeout=timeout)

    # Use parameter timeout in type of datetime.timedelta
    q = Queue(maxsize=2)
    timeout = datetime.timedelta(microseconds=10)
    res = q.put(1, timeout=timeout)

    # Use parameter timeout in type of None
    q = Queue(maxsize=2)
    timeout = None
    res = q.put(1, timeout=timeout)
