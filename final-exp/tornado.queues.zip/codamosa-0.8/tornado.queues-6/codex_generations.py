

# Generated at 2022-06-12 14:01:28.440951
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=10)
    # maxsize < 0
    res = q.put_nowait(1)
    assert res == ValueError, 'Failed1'
    q = Queue(maxsize=0)
    # maxsize = 0
    res = q.put_nowait(1)
    assert res == 1, 'Failed2'
    # maxsize > 0
    q = Queue(maxsize=10)
    res = q.put_nowait(1)
    assert res == 1, 'Failed3'



# Generated at 2022-06-12 14:01:39.594984
# Unit test for method put of class Queue
def test_Queue_put():
    print("==== test_Queue_put ====")
    import collections
    import asyncio
    async def consumer(q, timeout=None) :
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(1)
            finally:
                q.task_done()

    async def producer(q, timeout=None) :
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer,q)
        await producer(q)
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')


# Generated at 2022-06-12 14:01:51.252478
# Unit test for method put of class Queue
def test_Queue_put():
    import asyncio
    import json
    import logging
    import os
    import random
    import time
    import asyncio
    import json
    import logging
    import os
    import random
    import time
    import unittest

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    from tornado.tcpclient import TCPClient

    from tornado.testing import AsyncTestCase, bind_unused_port
    from tornado.test.util import unittest
    from utils import *

    # _test_put_timeout_yield
    class TestPutTimeoutYield(AsyncTestCase):
        @gen.coroutine
        def test_put_timeout_yield(self):
            q = Queue(maxsize=1)
            # Put something on the queue, so we

# Generated at 2022-06-12 14:01:52.941534
# Unit test for method put of class Queue
def test_Queue_put():
    # Create module object
    # Call method put of class Queue
    # Return value assertion
    pass



# Generated at 2022-06-12 14:02:04.265143
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    # tornado.ioloop.IOLoop.current().run_sync(main)
    # a = None

    def test1():
        # time.sleep(10)
        while 1:
            a.put_nowait('a')

    def test2():
        # time.sleep(10)
        while 1:
            a.put_nowait('b')

    a = Queue()

    import _thread
    _thread.start_new_thread(test1, ())
    _thread.start_new_thread(test2, ())

    # a.put_nowait('a')
    # a.put_nowait('a')
    # a.put_nowait('a')

    # print(a.qsize())
    # print(a.qsize())
    # print(a.qsize())

# Generated at 2022-06-12 14:02:12.574614
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def test_put(q):
        future = q.put(1, timeout=1)
        return future
    __tracebackhide__ = True
    future = test_put(q)
    assert future
    def test_put(q):
        future = q.put(1, timeout=1)
        return future
    __tracebackhide__ = True
    future = test_put(q)
    assert future
    def test_put(q):
        future = q.put(1, timeout=1)
        return future
    __tracebackhide__ = True
    future = test_put(q)
    assert future

# Generated at 2022-06-12 14:02:15.250956
# Unit test for method put of class Queue
def test_Queue_put():
    ioloop.IOLoop.current().run_sync(test_Queue_put_coro)

# Generated at 2022-06-12 14:02:18.267264
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    getElement0 = q.get()
    getElement0.set_result(10)
    assert getElement0.result() == 10


# Generated at 2022-06-12 14:02:27.004619
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:02:33.192277
# Unit test for method get of class Queue
def test_Queue_get():
    # create a new ioloop
    io_loop = ioloop.IOLoop()

    # create a new queue
    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        io_loop.spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.

# Generated at 2022-06-12 14:02:42.703934
# Unit test for method put of class Queue
def test_Queue_put():
    queue = Queue()
    item = queue.put('item', timeout=0.1)
    assert(queue.get_nowait() == 'item')



# Generated at 2022-06-12 14:02:44.693205
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import asyncio
    asyncio.run(Queue().put_nowait('hello'))



# Generated at 2022-06-12 14:02:55.095005
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass

    assert q.empty() == False
    assert q.full() == True
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2

    try:
        q.get_nowait()
    except QueueEmpty:
        pass

    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except QueueFull:
        pass


    assert q.empty() == False
    assert q.full() == True
    assert q.get_nowait() == 1


# Generated at 2022-06-12 14:02:56.918241
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=1)
    q.put_nowait(1)
    get_1 = q.get()
    assert get_1 == 1



# Generated at 2022-06-12 14:02:59.604784
# Unit test for method get of class Queue
def test_Queue_get():
    x = Queue()
    x.put_nowait(1)
    # x.put_nowait(2)
    print('tasks:', x.qsize())
    print('task:', x.get_nowait())
    print('tasks:', x.qsize())


if __name__ == '__main__':
    test_Queue_get()

# Generated at 2022-06-12 14:03:05.574319
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    if(q.get_nowait() == 1 and q.get_nowait() == 2 and q.empty()):
        print("test_Queue_get_nowait passed")
    else:
        print("test_Queue_get_nowait failed")



# Generated at 2022-06-12 14:03:10.058155
# Unit test for method get of class Queue
def test_Queue_get():  #TODO
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.


# Generated at 2022-06-12 14:03:13.917169
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=0)
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    assert q.get_nowait() == 3
    q.task_done()
    q.task_done()
    q.task_done()

test_Queue_get_nowait()

# Generated at 2022-06-12 14:03:16.680129
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)
    def show_get():        
        future = q.get()
        print(future)
    show_get()
    # q.get()


# Generated at 2022-06-12 14:03:22.142970
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    #q.put_nowait(1)
    assert q.get_nowait()==1
    print("hi")


if __name__ == "__main__":
    test_Queue_get_nowait()

# Generated at 2022-06-12 14:03:38.106027
# Unit test for method put of class Queue

# Generated at 2022-06-12 14:03:40.213989
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    q.put(1)
    q.put(1)


# Generated at 2022-06-12 14:03:48.314202
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:03:58.294761
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=2)
    def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-12 14:04:08.824394
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import tornado
    import tornado.ioloop
    from tornado.queues import Queue

    def test_put_nowait():
        q = Queue(2)
        q.put_nowait(1)
        assert q.qsize() == 1
        q.put_nowait(2)
        assert q.qsize() == 2
        try:
            q.put_nowait(3)
        except tornado.queues.QueueFull:
            assert True
        else:
            assert False
        
        return True

    print("test_put_nowait: " + str(test_put_nowait())) 
if __name__ == "__main__":
    test_Queue_put_nowait()


# Generated at 2022-06-12 14:04:17.788464
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    item = 1
    q.put_nowait(item)
    assert q.get_nowait() == 1
    q.put_nowait(item)
    q.put_nowait(item)
    assert q.qsize() == 2
    assert q.full() == True
    with pytest.raises(QueueFull, match='Queue Full'):
        q.put_nowait(item)
    assert q.full() == True

    item = 2
    q.put_nowait(item)
    q.put_nowait(item)
    assert q.qsize() == 2
    assert q.full() == True
    with pytest.raises(QueueFull, match='Queue Full'):
        q.put_nowait(item)
    assert q.full

# Generated at 2022-06-12 14:04:18.852747
# Unit test for method get of class Queue
def test_Queue_get():
    pass


# Generated at 2022-06-12 14:04:24.651964
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2
    try:
        q.get_nowait()
    except QueueEmpty:
        assert True
    else:
        assert False

# Generated at 2022-06-12 14:04:26.459522
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    assert q.put(1) is not None


# Generated at 2022-06-12 14:04:36.349133
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:05:03.729990
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-12 14:05:06.038032
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
    except QueueEmpty:
        print("QueueEmpty")


# Generated at 2022-06-12 14:05:08.874576
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put(1)
    assert len(q._queue) == 1
    assert q.qsize() == 1
    assert q._unfinished_tasks == 1
    assert not q._finished.is_set()



# Generated at 2022-06-12 14:05:15.133496
# Unit test for method put_nowait of class Queue

# Generated at 2022-06-12 14:05:22.695211
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    def test_get():
        async def consumer():
            async for item in q:
                try:
                    print('Doing work on %s' % item)
                    await gen.sleep(0.01)
                finally:
                    q.task_done()

        async def producer():
            for item in range(5):
                await q.put(item)
                print('Put %s' % item)

        async def main():
            # Start consumer without waiting (since it never finishes).
            IOLoop.current().spawn_callback(consumer)
            await producer()     # Wait for producer to put all tasks.
            await q.join()       # Wait for consumer to finish all tasks

# Generated at 2022-06-12 14:05:26.749533
# Unit test for method put of class Queue
def test_Queue_put():
    import time
    q = Queue(maxsize=2)
    q.put(1)
    q.put(2)
    
    # this would raise an exception of QueueFull
    q.put(3)
    # this would wait for a get call, then add the element into the queue
    q.put(4)


# Generated at 2022-06-12 14:05:28.581955
# Unit test for method get of class Queue
def test_Queue_get():
    # Not implemented:
    # * Return value can be null or raised.
    # * Timeout can be "amount of time" or "at a precise time".
    # * Queue can be empty or non-empty.
    pass


# Generated at 2022-06-12 14:05:33.776012
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time
    import random
    from tornado.gen import sleep
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue, QueueEmpty, QueueFull
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer

    q = Queue()

    @gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            # Do some 'work'
            yield sleep(item)
            print('Doing work on %s' % item)
            q.task_done()
            print('Done with %s' % item)

    @gen.coroutine
    def producer():
        for item in range(5):
            yield sleep(3)
            if q.full():
                print('Queue is full, sleep a while')
                sleep_time

# Generated at 2022-06-12 14:05:35.252487
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()
    q.put()
    


# Generated at 2022-06-12 14:05:45.647121
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:06:22.512379
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(item="Hello, World")
    assert q.get_nowait() == "Hello, World"



# Generated at 2022-06-12 14:06:24.624535
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()

    # Put a value in to the queue
    q.put_nowait(1)


# Generated at 2022-06-12 14:06:32.440335
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    async def _Queue_put_nowait(q, item) -> None:
        try:
            q.put_nowait(item)
            return True
        except:
            return False
    q = Queue()
    assert _Queue_put_nowait(q, 1) == True
    assert _Queue_put_nowait(q, 2) == True
    q = Queue(1)
    assert _Queue_put_nowait(q, 1) == True
    assert _Queue_put_nowait(q, 2) == True
    assert _Queue_put_nowait(q, 3) == False
    assert _Queue_put_nowait(q, 4) == False


# Generated at 2022-06-12 14:06:40.275589
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import random
    import pytest
    queues = []
    for i in range(100):
        queues.append(Queue())
    for i in range(10000):
        queue = random.randint(0, 99)
        if queues[queue].empty():
            queues[queue].put_nowait(i)
            assert queues[queue].get_nowait() == i
        else:
            with pytest.raises(QueueEmpty):
                queues[queue].get_nowait()


# Generated at 2022-06-12 14:06:41.756025
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=0)
    future = q.put('hello')

# Generated at 2022-06-12 14:06:50.463313
# Unit test for method put of class Queue
def test_Queue_put():


    def test(q: "Queue[str]") -> None:
        q = Queue(2)
        io_loop = ioloop.IOLoop()

        @gen.coroutine
        def test_puts() -> None:
            yield q.put("hello")
            assert q.qsize() == 1
            yield q.put("world")
            assert q.qsize() == 2
            with pytest.raises(QueueFull):
                yield q.put("!")
            assert q.qsize() == 2

        io_loop.run_sync(test_puts)


# Generated at 2022-06-12 14:06:54.852165
# Unit test for method put of class Queue
def test_Queue_put():
    print("test_Queue_put")
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
        assert(False)
    except QueueFull:
        pass
    else:
        print("error")
    return


# Generated at 2022-06-12 14:07:01.116798
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(5)
    try:
        q.put_nowait(0)
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        q.put_nowait(4)
        q.put_nowait(5)
    except QueueFull:
        print("Queue is full!\n")
    print(q.qsize())
    q.task_done()

# Generated at 2022-06-12 14:07:13.199598
# Unit test for method put of class Queue
def test_Queue_put():
    t1 = time.time()
    q = Queue()
    q._init()
    q._unfinished_tasks = 0
    q._finished = Event()
    q._finished.set()
    q._getters = []
    q._putters = []
    item = 1
    timeout = 10
    if q._putters :
        if q.full() and q._getters :
            future = Future()
            getter = q._getters.popleft()
            q._put(item)
            future_set_result_unless_cancelled(getter, q._get())
            return future
        elif q.full() and not q._getters :
            raise QueueFull
            
    q._unfinished_tasks += 1
    q._finished.clear()
    q._put(item)


# Generated at 2022-06-12 14:07:18.106104
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=3)
    q.put_nowait("one")
    q.put_nowait("two")
    q.put_nowait("three")
    assert q.qsize() == 3
    with pytest.raises(QueueFull):
        q.put_nowait("four")