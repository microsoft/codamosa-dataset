

# Generated at 2022-06-12 14:01:32.345536
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:01:37.591140
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    try:
        Queue().put_nowait(1)
    except QueueFull:
        print("Encountered QueueFull when calling put_nowait of class Queue")
    except:
        print("Encountered unknown exception when calling put_nowait of class Queue")


# Generated at 2022-06-12 14:01:47.077453
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    assert q.empty() == True and q.full() == False and q.qsize() == 0
    q.put(1)
    assert q.empty() == False and q.full() == False and q.qsize() == 1
    q.put(2)
    assert q.empty() == False and q.full() == True and q.qsize() == 2
    q.put(3)
    assert q.empty() == False and q.full() == True and q.qsize() == 2
    assert q.get() == 1
    assert q.empty() == False and q.full() == False and q.qsize() == 1
    assert q.get() == 2
    assert q.empty() == True and q.full() == False and q.qsize() == 0




# Generated at 2022-06-12 14:01:55.858138
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # Test statements
    print ("Coming to test_Queue_get_nowait")
    q = Queue(maxsize=2)
    # Test type
    assert(isinstance(q, Queue))
    # Test attributes
    assert(q.maxsize == 2 and not q.empty() and not q.full() \
    and q.qsize() == 0 and not q.empty() and not q.full())
    assert(q._getters == deque([]) and q._putters == deque([]))
    assert(type(q._queue) == deque)
    assert(isinstance(q._finished, Event) == True and q._finished.is_set() == True)



# Generated at 2022-06-12 14:02:08.055824
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    class MyQueue(Queue):
        def __init__(self, maxsize: int = 0) -> None:
            super(MyQueue, self).__init__(maxsize)
            self._queue = collections.deque([1, 2, 3])
        def _init(self) -> None:
            self._queue = collections.deque([1, 2, 3])
    queue = MyQueue()
    queue._getters = collections.deque([])
    queue._putters = collections.deque([])
    queue._unfinished_tasks = 0
    queue._finished = Event()
    queue._finished.set()
    it = queue.get_nowait()
    assert it == 1
    assert queue._queue == collections.deque([2, 3,])


# Generated at 2022-06-12 14:02:09.795201
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.get_nowait()==0


# Generated at 2022-06-12 14:02:19.003913
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    assert q.maxsize == 2
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False

    q.put_nowait(1)
    assert q.qsize() == 1
    assert q.empty() == False
    assert q.full() == False

    q.put_nowait(2)
    assert q.qsize() == 2
    assert q.empty() == False
    assert q.full() == True

    try:
        q.put_nowait(3)
    except QueueFull:
        assert True
    except:
        assert False
    else:
        assert False



# Generated at 2022-06-12 14:02:27.897682
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:02:39.029495
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    # This test is for #6995.  put_nowait() and get_nowait() are allowed
    # to fail without a timeout.  If put_nowait() fails, you may call
    # it again until it succeeds, or use the Future returned by put().
    # If get_nowait() fails, you may call it again until it succeeds, or
    # use the Future returned by get().
    q = Queue()
    assert q.empty()
    q.put_nowait(1)
    assert not q.empty()
    assert q.get_nowait() == 1
    assert q.empty()
    assert q.get_nowait() == 1
    assert q.empty()
    assert q.get_nowait() == 1
    assert q.empty()
    f1 = q.put(1)

# Generated at 2022-06-12 14:02:42.242843
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except:
        assert(q.qsize() == 2)
        assert(q.full())
        assert(not q.empty())


# Generated at 2022-06-12 14:03:03.212051
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
  import time
  import tornado
  from tornado.platform.asyncio import AsyncIOMainLoop
  import asyncio
  q = Queue()
  def test_asyncio():
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.put_nowait(4)
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    print(q.get_nowait())
    AsyncIOMainLoop().close()
  tornado.ioloop.IOLoop.current().add_callback(test_asyncio)
  # tornado.ioloop.IOLoop.current().start()
  asyncio_loop = asyncio.new_event_loop()

# Generated at 2022-06-12 14:03:04.444194
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    Queue()
    pass

# Generated at 2022-06-12 14:03:06.781592
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    q.put_nowait(1)
    assert q.qsize() == 1


# Generated at 2022-06-12 14:03:13.365870
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    # q.put_nowait(item)
    # The following call to put_nowait should succeed
    q.put_nowait(1)
    # The following call to put_nowait should succeed
    q.put_nowait(2)
    # The following call to put_nowait should throw a QueueFull exception
    try:
        q.put_nowait(3)
        assert(False)
    except QueueFull:
        pass


test_Queue_put_nowait()



# Generated at 2022-06-12 14:03:20.896774
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()

    def put(q):
        q.put_nowait(1)
        q.put_nowait(2)
        q.put_nowait(3)
        q.put_nowait(4)
        q.put_nowait(5)

    thread = threading.Thread(target=put, args=(q,))
    thread.start()
    for i in range(5):
        assert q.get_nowait() == i + 1
    thread.join()
    print("Test method get_nowait of class Queue passed")



# Generated at 2022-06-12 14:03:31.587461
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize = 2)
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.put_nowait(1)
    q.put_nowait(2)
    q.put_nowait(3)
    q.get_nowait()
    q.put_nowait(3)
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.get_nowait()
    q.put_nowait(1)
    q.put_nowait(2)
    q.get_nowait()
    q.get_nowait()
    q.put_nowait(3)
    q

# Generated at 2022-06-12 14:03:38.970776
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=3)
    put_2 = q.put(2)
    put_1 = q.put(1)
    put_2.set_result(None)
    put_1.set_result(None)
    get_1 = q.get()
    get_2 = q.get()
    get_1.set_result(1)
    get_2.set_result(2)
    assert q.qsize() == 0
    q.task_done()
    q.task_done()
    assert q.join() == None

    q = Queue(maxsize=0)
    put_2 = q.put(2)
    put_1 = q.put(1)
    put_2.set_result(None)
    put_1.set_result(None)


# Generated at 2022-06-12 14:03:46.008485
# Unit test for method get of class Queue
def test_Queue_get():

    a = Queue()

    # single get
    f = a.get() # type: Future[_T]
    assert isinstance(f,Future)
    f.cancel()

    # get with timeout
    f = a.get(timeout=1) # type: Future[_T]
    assert isinstance(f,Future)
    f.cancel()

    # get_nowait not defined
    try:
        a.get_nowait()
    except QueueEmpty:
        pass

    # iterate over Queue
    for x in a:
        pass

    # iterate over Queue with timeout
    for x in a:
        pass

    # join not defined
    try:
        a.join()
    except ValueError:
        pass

    # task_done
    a.task_done()

    # put


# Generated at 2022-06-12 14:03:54.031473
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado.queues import Queue, QueueFull
    a = Queue(maxsize= 2)
    a.put_nowait(1)
    a.put_nowait(2)
    try:
        a.put_nowait(3)
    except Exception as error:
        assert isinstance(error, QueueFull)
        print('QueueFull')
    b = Queue()
    b.put_nowait(1)
    b.put_nowait(2)
    b.put_nowait(3)
    assert b._queue == deque([1, 2, 3])
test_Queue_put_nowait()



# Generated at 2022-06-12 14:04:01.955564
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=0)
    try:
        q.put_nowait(item=None)
    except QueueFull:
        assert False
    def g():
        try:
            q.put_nowait(item=None)
        except QueueFull:
            assert True
    g()
    try:
        q.put_nowait(item=None)
    except QueueFull:
        assert False
    def g():
        try:
            q.put_nowait(item=None)
        except QueueFull:
            assert True
    g()


# Generated at 2022-06-12 14:04:15.329401
# Unit test for method get of class Queue
def test_Queue_get():
    """
    Unit test for method get of class Queue

    Checks if the get method works
    """

    q = Queue()
    q.put(1)
    assert q.qsize() == 1 and q.get() == 1 and q.qsize() == 0


# Generated at 2022-06-12 14:04:20.290912
# Unit test for method put of class Queue
def test_Queue_put():
    # Create queue
    q = Queue()
    # Create underlying data structure
    q._init()
    # Put an item
    q.put_nowait(1)
    # Check if item was put
    assert(q.qsize() == 1)



# Generated at 2022-06-12 14:04:27.708692
# Unit test for method get of class Queue
def test_Queue_get():
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    from tornado.httputil import HTTPHeaders
    from tornado.util import bytes_type
    from tornado.testing import gen_test
    from tornado.queues import Queue
    from tornado.concurrent import Future
    import logging
    import time
    import asyncio
    import sys

    if sys.version_info[0] < 3 or sys.version_info[1] < 5:
        return

    def _test(q, value):
        q.put_nowait(value)
        return q.get()

    @asyncio.coroutine
    def test():
        q = Queue()
        future = asyncio.ensure_future(_test(q, 42))

        yield from asyncio.sleep(0.001)
        assert future

# Generated at 2022-06-12 14:04:34.170576
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=1)
    assert q.qsize() == 0
    f = q.put(1)
    assert f.result() == None
    f = q.get()
    assert f.result() == 1
    assert q.qsize() == 0
    assert q.empty() == True
    assert q.full() == False
    f = q.get()
    assert f.result() == 1
    assert q.empty() == True
    assert q.full() == False

# Generated at 2022-06-12 14:04:45.187487
# Unit test for method get of class Queue

# Generated at 2022-06-12 14:04:46.125247
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue()



# Generated at 2022-06-12 14:04:56.597622
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)

    @gen.coroutine
    def consumer():
        for _ in range(5):
            yield q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    @gen.coroutine
    def producer():
        for item in range(5):
            yield q.put(item)
            print('Put %s' % item)

    @gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        yield producer()     # Wait for producer to put all tasks.
        yield q.join()       # Wait for consumer to finish all tasks.
        print('Done')

    ioloop.IOL

# Generated at 2022-06-12 14:05:05.137224
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():

    q = Queue()

    assert q.empty() == True
    assert q.full() == False
    assert q.qsize() == 0
    q.put(1)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 1
    q.put(2)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 2

    for k in range(10):
        q.put(k)
    assert q.empty() == False
    assert q.full() == False
    assert q.qsize() == 12


# Generated at 2022-06-12 14:05:12.391139
# Unit test for method put of class Queue
def test_Queue_put():
    class MockedQueue(Queue):
        def __init__(self, maxsize: int = 0) -> None:
            self._queue = collections.deque()
            self._maxsize = maxsize
            self._getters = collections.deque([])  # type: Deque[Future[_T]]
            self._putters = collections.deque([])  # type: Deque[Tuple[_T, Future[None]]]
            self._unfinished_tasks = 0
            self._finished = Event()
            self._finished.set()
        def _get(self) -> _T:
            return self._queue.popleft()
        def _put(self, item: _T) -> None:
            self._queue.append(item)
    q = MockedQueue(maxsize=1)

# Generated at 2022-06-12 14:05:20.656068
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import time
    import random
    import unittest
    from tornado.queues import Queue
    q = Queue()
    count = 0
    def get_nowait_worker(count):
        while count < 100:
            time.sleep(random.randint(1, 5) / 100.0)
            if q.qsize() > 0:
                print(q.get_nowait())
                count += 1
    get_nowait_worker = Thread(target = get_nowait_worker, args = (count, ))
    put_nowait_worker = Thread(target = put_nowait_worker, args = (count, ))
    get_nowait_worker.start()
    put_nowait_worker.start()
    get_nowait_worker.join()
    put_nowait_worker.join()
   

# Generated at 2022-06-12 14:05:39.273976
# Unit test for method put of class Queue
def test_Queue_put():
    if __name__ == "__main__":
        q = Queue()

        async def put(value):
            await q.put(value)

        async def get():
            item_got = await q.get()
            q.task_done()
            return item_got

        async def main():
            for i in range(20):
                await put(i)
            for _ in range(20):
                item = await get()
                print(item)
            await q.join()
            print("all tasks done!")

        import asyncio
        loop = asyncio.get_event_loop()
        loop.run_until_complete(main())


# Generated at 2022-06-12 14:05:40.833328
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
	# Test the method Queue.get_nowait without passing in parameters
	q = Queue(maxsize=2)
	assert q.get_nowait() == None
	return None


# Generated at 2022-06-12 14:05:44.563004
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.get_nowait() == 1
    assert q.get_nowait() == 2



# Generated at 2022-06-12 14:05:54.271454
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado
    import tornado.ioloop
    import tornado.queues
    import time
    @tornado.gen.coroutine
    def consumer():
        while True:
            item = yield q.get()
            try:
                print('Doing work on %s' % item)
                yield tornado.gen.sleep(0.01)
            finally:
                q.task_done()
    @tornado.gen.coroutine
    def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    @tornado.gen.coroutine
    def main():
        # Start consumer without waiting (since it never finishes).
        tornado.ioloop.IOLoop.current().spawn_callback(consumer)
        # Wait for producer to put all tasks.
        yield producer

# Generated at 2022-06-12 14:06:00.907036
# Unit test for method get of class Queue
def test_Queue_get():
    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)
    async def main():
        # Start consumer without waiting (since it never finishes).
        ioloop.IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')
    q = Queue(maxsize=2)
    ioloop.IOLoop.current().run_sync(main)
    
test_

# Generated at 2022-06-12 14:06:11.596178
# Unit test for method put of class Queue
def test_Queue_put():
    async def main(loop):
        queue = Queue()
        # test Queue.put(item, timeout=None)
        await queue.put(1)
        assert len(queue._queue) == 1

        # test Queue.put(item, timeout=3)
        r = await queue.put(2, timeout=3)
        assert r == None and len(queue._queue) == 2

        # test Queue.put(item, timeout=0.01) and Queue.put(item, timeout=0.001)
        r = await queue.put(3, timeout=0.01)
        assert r == None and len(queue._queue) == 3
        r = await queue.put(4, timeout=0.001)
        assert r == None and len(queue._queue) == 4


# Generated at 2022-06-12 14:06:13.948297
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    for i in range(5):
        q.put_nowait(i)
    for i in range(5):
        assert q.get_nowait() == i


# Generated at 2022-06-12 14:06:19.837031
# Unit test for method put of class Queue
def test_Queue_put():
    def run_test(self):
        self.getters.append(None)
        self.assertEqual(self.queue.put(None), None)
        self.assertEqual(self.queue.put(None), None)
        self.assertTrue(self.queue.full())
        self.queue.putters.appendleft((None, self.getters.popleft()))
        self.assertEqual(self.queue.qsize(), 2)

    def test_put(self):
        # enqueue one, not full
        self.queue = Queue()
        run_test(self)

        # enqueue one, full
        self.queue = Queue()
        self.queue.putters.append(None)
        run_test(self)

        # enqueue many, full
        self.queue = Queue()

# Generated at 2022-06-12 14:06:30.113529
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado.queues import Queue
    def test_Queue_put__1():
        q = Queue(maxsize=2)
        # Test for expected exception
        q.put(1)
        q.put(2)
        with pytest.raises(QueueFull):
            q.put(3)
        with pytest.raises(QueueFull):
            q.put(4)
    def test_Queue_put__2():
        q = Queue(maxsize=2)
        # Test for expected exception
        q.put(1)
        q.put(2)
        with pytest.raises(QueueFull):
            q.put(3)
        with pytest.raises(QueueFull):
            q.put(4)

# Generated at 2022-06-12 14:06:32.007009
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    ss = Queue()
    ss.__put_internal(1)
    assert ss.get_nowait() == 1


# Generated at 2022-06-12 14:06:52.392323
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
  from tornado.queues import Queue
  from tornado.testing import AsyncTestCase, gen_test

  class TestCase(AsyncTestCase):
    @gen_test
    async def test_put_nowait(self):
      q = Queue()
      # Testing the capacity of the Queue
      self.assertEqual(q.qsize(), 0)
      q.put_nowait(1)
      q.put_nowait(2)
      self.assertEqual(q.qsize(), 2)
      self.assertEqual(await q.get(), 1)
      self.assertEqual(q.qsize(), 1)

  # Running the tests
  TestCase().run()


# Generated at 2022-06-12 14:06:57.951126
# Unit test for method put of class Queue
def test_Queue_put():
    q = Queue(maxsize=3)

    def consumer():
        while True:
            item = q.get()
            try:
                print('Doing work on %s' % item)
            finally:
                q.task_done()

    # Start consumer without waiting (since it never finishes).
    ioloop.IOLoop.current().spawn_callback(consumer)

    for item in range(5):
        q.put(item)
        print('Put %s' % item)
    q.join()
    print('Done')
    return q

# Generated at 2022-06-12 14:06:58.955421
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    print("test_Queue_get_nowait is not implemented")


# Generated at 2022-06-12 14:07:04.626017
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue()
    print("testing method put_nowait of class Queue")
    print(q.empty())
    print(q.full())
    print(q.num)
    print(q.num_get)
    print(q.num_put)
    q.put_nowait(1)
    print(q.empty())
    print(q.full())
    print(q.num)
    print(q.num_get)
    print(q.num_put)
    q.put_nowait(2)
    print(q.empty())
    print(q.full())
    print(q.num)
    print(q.num_get)
    print(q.num_put)
    q.put_nowait(3)
    print(q.empty())

# Generated at 2022-06-12 14:07:11.769739
# Unit test for method get of class Queue
def test_Queue_get():
    '''
    Test get method of class Queue
    '''
    # initialize the queue
    queue = Queue()
    # put some elements into queue
    queue.put(1)
    queue.put(2)
    queue.put(3)

    # get the 1st element
    assert queue.get() == 1
    # get the 2nd element
    assert queue.get() == 2
    # get the 3rd element
    assert queue.get() == 3


# Generated at 2022-06-12 14:07:16.677695
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    assert q.put_nowait(3) == None


# Generated at 2022-06-12 14:07:25.439338
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    class TestQueue(Queue):
        def _init(self):
            self._queue = collections.deque([])
        def _get(self):
            return self._queue.popleft()
        def _put(self, item: _T):
            self._queue.append(item)
    class QueueEmpty(Exception):
        pass
    class QueueFull(Exception):
        pass
    queue = TestQueue(maxsize=100)
    assert queue.get_nowait() == None
    assert queue.empty() == True
    assert queue.full() == False
    assert queue.qsize() == 0
    queue._getters.append(Future())
    assert queue.get_nowait() == None
    assert queue.empty() == True
    assert queue.full() == False
    assert queue.qsize() == 0
    queue

# Generated at 2022-06-12 14:07:28.920517
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue()  # type: Queue[_T]
    q._put(1)
    print(q.get_nowait())

# test_Queue_get_nowait()


# Generated at 2022-06-12 14:07:40.107125
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')

# Generated at 2022-06-12 14:07:45.108875
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    assert q.empty() == True
    assert q.get_nowait() ==  QueueEmpty()
    q.put_nowait(1)
    assert q.get_nowait() == 1
    q.task_done()
    assert q.get_nowait() == QueueEmpty()



# Generated at 2022-06-12 14:08:09.422310
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
    except QueueEmpty as e:
        print(e)



# Generated at 2022-06-12 14:08:10.997065
# Unit test for method put of class Queue
def test_Queue_put():
    result = Queue(maxsize = 2).put(1, timeout = 10)
    assert result != None


# Generated at 2022-06-12 14:08:14.098410
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=2)
    def get_q():
        return q.get()
    def put_q():
        return q.put(1)
    get_q()
    put_q()
    get_q().result()
    #get_q()



# Generated at 2022-06-12 14:08:18.347779
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():

    q = Queue(maxsize=0)

    for i in range(10):
        q.put_nowait(i)

    for i in range(10):
        assert len(q) == 10 - i
        assert q.get_nowait() == i

test_Queue_put_nowait()



# Generated at 2022-06-12 14:08:28.070911
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    import tornado.testing
    import tornado.ioloop
    import asyncio
    import unittest


    class TestQueue(tornado.testing.AsyncTestCase):
        def test_get_nowait(self):
            from tornado.queues import Queue

            q = Queue()
            q.put_nowait(1)
            q.put_nowait(2)
            self.assertEqual(1, q.get_nowait())
            self.assertEqual(2, q.get_nowait())
            q.put_nowait(1)
            q.put_nowait(2)
            q.put_nowait(3)
            self.assertRaises(tornado.queues.QueueFull, q.put_nowait, 4)

# Generated at 2022-06-12 14:08:31.939234
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    q = Queue(maxsize=2)
    q.put_nowait(1)
    q.put_nowait(2)
    try:
        q.put_nowait(3)
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 14:08:35.790268
# Unit test for method get of class Queue
def test_Queue_get():
    q = Queue(maxsize=0)

    async def consumer():
        async for item in q:
            print('Doing work on %s' % item)


    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)


    async def main():
        IOLoop.current().spawn_callback(consumer)
        await producer()


    IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:08:41.848636
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    async def main():
      q = Queue(maxsize=2)
      result = await q.get()
      print(result)
      result1 = await q.get()
      print(result1)
    asyncio.run(main())

test_Queue_get()


# Generated at 2022-06-12 14:08:43.342168
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    pass

# Generated at 2022-06-12 14:08:53.589349
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    
    # @gen.coroutine
    async def consumer():
        async for i in q:
            try:
                print('Doing work on %s' % i)
                await gen.sleep(0.01)
            finally:
                q.task_done()
    
    q = Queue(maxsize=2)
    q.put(item=1)
    q.put(item=2)
    print(q.get(timeout=2))
    q.put(item=3)
    IOLoop.current().spawn_callback(consumer)
    IOLoop.current().start()
    # IOLoop.current().run_sync(main)


# Generated at 2022-06-12 14:09:38.104719
# Unit test for method get_nowait of class Queue
def test_Queue_get_nowait():
    q = Queue(maxsize=2)
    try:
        q.get_nowait()
    except QueueEmpty as e:
        assert isinstance(e, QueueEmpty)

# Generated at 2022-06-12 14:09:42.110183
# Unit test for method get of class Queue
def test_Queue_get():
    import asyncio
    from tornado.ioloop import IOLoop
    async def main():
        q = Queue()
        q.put_nowait(1)
        q.put_nowait(2)
        print(await q.get())
        print(await q.get())

        IOLoop.current().stop()
    IOLoop.current().run_sync(main)

if __name__ == '__main__':
    test_Queue_get()

# Generated at 2022-06-12 14:09:43.375558
# Unit test for method put of class Queue
def test_Queue_put():
    o = Queue()
    o.put(12,timeout=0)


# Generated at 2022-06-12 14:09:45.677010
# Unit test for method put of class Queue
def test_Queue_put():
    v1 = 1
    v2 = 'hi'

    q1 = Queue()
    q1.put(v1)
    q1.put(v2)


# Generated at 2022-06-12 14:09:53.573723
# Unit test for method put_nowait of class Queue
def test_Queue_put_nowait():
    import time

    exQueue = Queue(maxsize = 5)

    for i in range(5):
        exQueue.put_nowait(i)
        print("Put: %s" % i)
        print("Queue size: %s" % exQueue.qsize())
    try:
        exQueue.put_nowait(5)
    except QueueFull:
        print("Can't put another item")

    for i in range(5):
        print("Get: %s" % exQueue.get_nowait())
        print("Queue size: %s" % exQueue.qsize())
    try:
        exQueue.get_nowait()
    except QueueEmpty:
        print("Can't get another item")

    for i in range(5):
        exQueue.put_nowait(i)

# Generated at 2022-06-12 14:09:58.981082
# Unit test for method get of class Queue
def test_Queue_get():
    # implementation of test_Queue_get
    q = Queue(maxsize=0)
    future = Future()  # type: Future[_T]
    # try:
    #     future.set_result(self.get_nowait())
    # except QueueEmpty:
    #     self._getters.append(future)
    #     _set_timeout(future, timeout)
    assert(future == None)
    # Return an awaitable, which raises `tornado.util.TimeoutError` after a
    # timeout.
    return future


# Generated at 2022-06-12 14:10:06.067080
# Unit test for method get of class Queue
def test_Queue_get():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue
    q = Queue(maxsize=2)
    async def get_message():
        def test_get():
            return "get_message"
    def fake_add_future():
        return None
    def fake_add_timeout():
        return None

    q.__init__ = test_Queue_put()
    q.put_nowait = test_Queue_put_nowait()
    q.Empty = QueueEmpty()
    q.get_nowait = test_Queue_get_nowait()
    q.task_done = test_Queue_task_done()
    q.join = test_Queue_join()
    q.__str__ = test_Queue___str__()

# Generated at 2022-06-12 14:10:06.886464
# Unit test for method put of class Queue
def test_Queue_put():
    def test_put():
        pass

# Generated at 2022-06-12 14:10:14.117205
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen

    from tornado.ioloop import IOLoop

    from tornado.queues import Queue

    q = Queue(maxsize=2)


    async def consumer():
        async for item in q:
            try:
                print("Doing work on %s" % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()


    async def producer():
        for item in range(5):
            await q.put(item)
            print("Put %s" % item)


    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()  # Wait for producer to put all tasks.
        await q.join()  # Wait for consumer to finish all tasks.
        print

# Generated at 2022-06-12 14:10:22.599004
# Unit test for method put of class Queue
def test_Queue_put():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    q = Queue(maxsize=2)

    async def consumer():
        async for item in q:
            try:
                print('Doing work on %s' % item)
                await gen.sleep(0.01)
            finally:
                q.task_done()

    async def producer():
        for item in range(5):
            await q.put(item)
            print('Put %s' % item)

    async def main():
        # Start consumer without waiting (since it never finishes).
        IOLoop.current().spawn_callback(consumer)
        await producer()     # Wait for producer to put all tasks.
        await q.join()       # Wait for consumer to finish all tasks.
        print('Done')