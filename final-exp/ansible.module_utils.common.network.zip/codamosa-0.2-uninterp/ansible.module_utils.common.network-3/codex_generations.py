

# Generated at 2022-06-16 22:38:14.314404
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
   

# Generated at 2022-06-16 22:38:26.257955
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.128') == '192.168.1.0/25'

# Generated at 2022-06-16 22:38:34.534901
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.25')
    assert not is_netmask('255.255.255.2555')

# Generated at 2022-06-16 22:38:44.792083
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:38:55.011729
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:39:03.523188
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('128.0.0.0')

# Generated at 2022-06-16 22:39:13.676606
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:39:22.480663
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:39:33.151868
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:39:45.154421
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:39:52.508915
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:40:04.040519
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:abcd:1234::') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:1234') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:1234/64') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:1234/128') == '2001:db8:abcd:1234:5678:9abc:def0:1234'

# Generated at 2022-06-16 22:40:13.075416
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1/64') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1/128') == '2001:db8:0:1:1:1:1:1'
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1/127') == '2001:db8:0:1:1:1:1:0'

# Generated at 2022-06-16 22:40:24.231372
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:40:34.449759
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:0:0:7334') == '2001:db8:85a3::'

# Generated at 2022-06-16 22:40:41.191073
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:abcd:1234:0000:0000:0000:0000') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:0000:0000:0000') == '2001:db8:abcd:1234:5678::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:0000:0000') == '2001:db8:abcd:1234:5678:9abc::'

# Generated at 2022-06-16 22:40:52.904420
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0/64') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0/128') == '2001:db8::'

# Generated at 2022-06-16 22:41:02.317281
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'

# Generated at 2022-06-16 22:41:14.535429
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:0:0:0') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:0:0:0') == '2001:db8:85a3::'

# Generated at 2022-06-16 22:41:23.438331
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:41:36.864741
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:41:48.884614
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.25')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:41:53.446186
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:42:03.673916
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:42:15.953815
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.0.256')
    assert not is_netmask('255.255.255.0.255.0')
    assert not is_netmask('255.255.255.0.255.255')
    assert not is_netmask('255.255.255.0.255.256')
    assert not is_netmask('255.255.255.0.255.255.0')

# Generated at 2022-06-16 22:42:28.574772
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:42:39.509116
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0')

# Generated at 2022-06-16 22:42:49.358271
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('0.0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask

# Generated at 2022-06-16 22:43:02.627942
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:12.625386
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:43:27.993785
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:37.357979
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('0.0.0.0.0')
    assert not is_net

# Generated at 2022-06-16 22:43:51.264012
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255.255.255')

# Generated at 2022-06-16 22:44:00.567595
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:12.604072
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:20.494529
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:44:31.939063
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:44:41.957185
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:44:50.708938
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.1.0')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.255.0')

# Generated at 2022-06-16 22:45:00.272659
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255.255.255')

# Generated at 2022-06-16 22:45:12.159481
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:24.155423
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:33.899952
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:45:46.898127
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:45:55.944423
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:46:05.831803
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:46:16.975151
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:46:24.582128
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:46:36.644285
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:46:43.981095
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:47:03.331525
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:47:10.781532
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask

# Generated at 2022-06-16 22:47:21.380817
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:47:31.872007
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:47:44.133911
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.255')

# Generated at 2022-06-16 22:47:53.619287
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:48:03.922863
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')