

# Generated at 2022-06-16 22:38:12.245863
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:0:0:7334') == '2001:db8:85a3::'

# Generated at 2022-06-16 22:38:23.450422
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:38:33.492790
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:38:45.525800
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:38:57.340041
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:0:0:0:2:1') == '2001:db8:0:0:0:0:0:0:'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:2:1/64') == '2001:db8:0:0:0:0:0:0:'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:2:1/128') == '2001:db8:0:0:0:0:2:1:'
    assert to_ipv6_subnet('2001:db8::2:1') == '2001:db8:0:0:0:0:0:0:'

# Generated at 2022-06-16 22:39:08.672491
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.0', False) == '192.168.1.0/24'

# Generated at 2022-06-16 22:39:19.624099
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_

# Generated at 2022-06-16 22:39:29.410334
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:39:36.676981
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
   

# Generated at 2022-06-16 22:39:46.365240
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:40:00.305777
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:40:10.249480
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:a0b:12f0::1') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1/64') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1/128') == '2001:db8:a0b:12f0:1:1:1:1'

# Generated at 2022-06-16 22:40:22.340955
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:40:30.785484
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:40:39.289944
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334/128') == '2001:0db8:85a3:0000:0000:8a2e:0370:7334'

# Generated at 2022-06-16 22:40:51.392102
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334/128') == '2001:0db8:85a3:0000:0000:8a2e:0370:7334'

# Generated at 2022-06-16 22:41:01.068761
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:0') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:0/64') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:0/128') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:0/0') == '2001:db8::'

# Generated at 2022-06-16 22:41:13.502238
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:41:23.007931
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:1::1') == '2001:db8:0:1::'
    assert to_ipv6_network('2001:db8:0:1:0:1::1') == '2001:db8:0:1::'
    assert to_ipv6_network('2001:db8:0:1:0:1:0:1') == '2001:db8:0:1::'
    assert to_ipv6_network('2001:db8:0:1:0:1:0:1') == '2001:db8:0:1::'

# Generated at 2022-06-16 22:41:34.944804
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1/64') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1/128') == '2001:db8:0:0:1:0:0:1'
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1/127') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1/126') == '2001:db8::'


# Generated at 2022-06-16 22:41:48.479327
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:42:00.822120
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:42:13.769961
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:22.939971
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255/24')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask

# Generated at 2022-06-16 22:42:35.239155
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:42:46.702495
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:59.959881
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')


# Generated at 2022-06-16 22:43:08.812026
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:17.359689
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:43:30.181474
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.254')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')
    assert not is_netmask('255.255.255.1/24')
    assert not is_netmask('255.255.255.1/255.255.255.0')
    assert not is_netmask('255.255.255.1 255.255.255.0')

# Generated at 2022-06-16 22:43:42.031884
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:43:53.150987
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')


# Generated at 2022-06-16 22:44:01.085222
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:44:13.188131
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:44:20.865070
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:44:32.297573
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:41.066427
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:50.159394
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:45:00.151473
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')


# Generated at 2022-06-16 22:45:10.247535
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:27.496959
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:45:36.109830
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_

# Generated at 2022-06-16 22:45:49.209672
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1')

# Generated at 2022-06-16 22:45:57.459353
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:46:04.105405
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:46:16.137540
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:46:27.067441
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:46:38.218058
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.1.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.255.255')

# Generated at 2022-06-16 22:46:48.948431
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:46:57.758214
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:47:21.981859
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.0.0.255')
    assert not is_netmask('255.255.255.0.0.0.255')
   

# Generated at 2022-06-16 22:47:32.226209
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:47:44.466851
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/32')

# Generated at 2022-06-16 22:47:53.872621
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')