

# Generated at 2022-06-16 22:38:09.159283
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:38:21.176741
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:38:30.820713
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-16 22:38:40.667631
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:38:50.314085
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:39:00.629522
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:39:12.120324
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:a0b:12f0::1') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1/64') == '2001:db8:a0b:12f0::'
    assert to_ipv6_network('2001:db8:a0b:12f0:1:1:1:1/128') == '2001:db8:a0b:12f0:1:1:1:1'

# Generated at 2022-06-16 22:39:21.839452
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:0:1::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:0:1:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:0:1:0:1') == '2001:db8::'

# Generated at 2022-06-16 22:39:32.962153
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.0.256')
    assert not is_netmask('255.255.255.0.255.0')
    assert not is_netmask('255.255.255.0.255.1')


# Generated at 2022-06-16 22:39:44.967301
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.1', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '24') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '255.255.255.0', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.1', '24', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.1', '255.255.255.0', False) == '192.168.0.0/24'

# Generated at 2022-06-16 22:39:52.154535
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:40:03.756853
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:40:12.887774
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:40:24.098404
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_

# Generated at 2022-06-16 22:40:34.326252
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:40:47.240388
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:40:53.467679
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:41:02.751775
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:41:14.779252
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:41:23.600647
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/255.255.255.0')

# Generated at 2022-06-16 22:41:33.980525
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.129')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0.0')

# Generated at 2022-06-16 22:41:41.122714
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:41:52.518279
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:42:03.284851
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:15.907323
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask

# Generated at 2022-06-16 22:42:24.366556
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:36.268176
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:47.377486
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255.255.255')

# Generated at 2022-06-16 22:43:00.748201
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:43:10.691812
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:43:30.093452
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:37.493802
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:51.315070
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:44:00.613053
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:12.653358
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:44:20.557523
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_net

# Generated at 2022-06-16 22:44:31.986461
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:44:40.805486
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:44:49.941233
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:45:00.020496
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:45:26.343097
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:35.388644
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:48.690390
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:45:57.077220
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0.0')

# Generated at 2022-06-16 22:46:03.988071
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:46:16.053107
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:46:26.939410
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.2')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:46:38.136381
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/32')

# Generated at 2022-06-16 22:46:48.858370
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:46:57.678264
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:47:34.774672
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0 255.255.255.0')
    assert not is_netmask('255.255.255.0/255.255.255.0')
    assert not is_netmask('255.255.255.0/24')

# Generated at 2022-06-16 22:47:46.916284
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:47:54.762219
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')