

# Generated at 2022-06-16 22:38:12.852148
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:38:22.351358
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-16 22:38:32.847476
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.128') == '192.168.1.0/25'

# Generated at 2022-06-16 22:38:44.740392
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.128') == '192.168.1.0/25'

# Generated at 2022-06-16 22:38:56.655347
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:39:08.008741
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334/64') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334/128') == '2001:db8:85a3:0:0:8a2e:370:7334'

# Generated at 2022-06-16 22:39:19.149516
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:39:30.556837
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0.24')
    assert not is_netmask('255.255.255.0 24')
    assert not is_netmask('255.255.255.0,24')
    assert not is_netmask('255.255.255.0;24')
    assert not is_netmask('255.255.255.0 24')

# Generated at 2022-06-16 22:39:42.487339
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.252.0') == 22
   

# Generated at 2022-06-16 22:39:51.571139
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '1111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '1111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '1111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '1111111111111111111111111111110'

# Generated at 2022-06-16 22:40:04.858399
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0') == '2001:db8::'

# Generated at 2022-06-16 22:40:13.575006
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:abcd:1234:0000:0000:0000:0000') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:0000') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:1234') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:5678:9abc:def0:1234') == '2001:db8:abcd:1234::'
    assert to_ipv6_

# Generated at 2022-06-16 22:40:24.549279
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:1:2::') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6:7:8') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6:7:8:9:a:b:c:d:e:f') == '2001:db8:1:2::'

# Generated at 2022-06-16 22:40:34.702113
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1/64') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1/128') == '2001:db8:0:1:0:0:0:1'
   

# Generated at 2022-06-16 22:40:47.910428
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.-1')
    assert not is_netmask('255.255.255.1.0')

# Generated at 2022-06-16 22:40:54.150769
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'

# Generated at 2022-06-16 22:41:03.215207
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:0') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1/64') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1/128') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1/127') == '2001:db8::'
    assert to_ipv6_

# Generated at 2022-06-16 22:41:15.130877
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6/64') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6/128') == '2001:db8:1:2:3:4:5:6'
    assert to_ipv6_subnet('2001:db8:1:2:3:4:5:6/127') == '2001:db8:1:2:3:4:5:6'

# Generated at 2022-06-16 22:41:23.867286
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == '2001:db8:85a3:8d3::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348/128') == '2001:db8:85a3:8d3:1319:8a2e:370:7348'

# Generated at 2022-06-16 22:41:35.795713
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:1::1') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1/64') == '2001:db8:0:1::'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1/128') == '2001:db8:0:1:0:0:0:1'
    assert to_ipv6_subnet('2001:db8:0:1:0:0:0:1/127')

# Generated at 2022-06-16 22:41:49.299239
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:01.456501
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:42:14.484747
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:42:24.663495
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:42:36.396650
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:42:47.492738
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:43:00.851943
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:43:10.778281
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:43:19.360242
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:43:31.174626
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.3')

# Generated at 2022-06-16 22:43:42.469188
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:43:53.444380
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0.24')
    assert not is_netmask('255.255.255.0 24')
    assert not is_netmask('255.255.255.0.24')
    assert not is_netmask('255.255.255.0 24')
    assert not is_netmask('255.255.255.0/24')

# Generated at 2022-06-16 22:44:01.682365
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:44:13.823078
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:21.214410
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:32.528047
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.1')
    assert not is_netmask('255.255.255.0.1')

# Generated at 2022-06-16 22:44:41.304385
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:44:46.295787
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.255/24')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.255/32')
    assert not is_netmask

# Generated at 2022-06-16 22:44:56.986067
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:45:07.720640
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:45:25.405246
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:45:34.730237
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:45:47.913512
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.01')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')

# Generated at 2022-06-16 22:45:58.768046
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('0.0.0.0.0')
    assert not is_netmask

# Generated at 2022-06-16 22:46:11.258625
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.1')


# Generated at 2022-06-16 22:46:20.569171
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/24')
    assert not is_netmask('255.255.255.0/255.255.255.0')
    assert not is_netmask('255.255.255.0/24')

# Generated at 2022-06-16 22:46:33.135155
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:46:39.381218
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:46:45.656987
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('255.128.0.0')
    assert is_netmask('255.192.0.0')
    assert is_netmask('255.224.0.0')
    assert is_netmask('255.240.0.0')
    assert is_netmask('255.248.0.0')
    assert is_netmask('255.252.0.0')
    assert is_netmask('255.254.0.0')
    assert is_netmask('255.255.0.0')

# Generated at 2022-06-16 22:46:55.082911
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.2')

# Generated at 2022-06-16 22:47:14.241616
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.1.1')

# Generated at 2022-06-16 22:47:25.131577
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:47:33.976476
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-16 22:47:45.987064
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')

# Generated at 2022-06-16 22:47:55.055825
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.255')
    assert not is_netmask('255.255.255.0.0.255')
    assert not is_netmask('255.255.255.0.255.0')

# Generated at 2022-06-16 22:48:04.779757
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/24')
