

# Generated at 2022-06-11 01:08:50.219418
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0')), 'assertion failed'
    assert(is_netmask('128.0.0.0')), 'assertion failed'
    assert(is_netmask('192.168.1.0')), 'assertion failed'
    assert(is_netmask('255.255.0.0')), 'assertion failed'
    assert(not is_netmask('255.0.0.25')), 'assertion failed'
    assert(not is_netmask('300.0.0.0')), 'assertion failed'
    assert(not is_netmask('')), 'assertion failed'
    assert(not is_netmask(None)), 'assertion failed'
    assert(not is_netmask('foobar')), 'assertion failed'


# Generated at 2022-06-11 01:08:52.598995
# Unit test for function to_bits
def test_to_bits():

    assert '11111111000000000000000000000000' == to_bits('255.0.0.0')
    assert '11111111111111111111111100000000' == to_bits('255.255.255.0')

# Generated at 2022-06-11 01:08:57.330031
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen("255.255.255.0") == 24
    assert to_masklen("255.255.0.0") == 16
    assert to_masklen("255.0.0.0") == 8
    assert to_masklen("0.0.0.0") == 0


# Generated at 2022-06-11 01:09:05.209605
# Unit test for function is_netmask
def test_is_netmask():
    ipv4_true = [
        '255.255.255.255',
        '255.255.0.0',
        '128.0.0.0',
        '255.0.0.0',
        '0.0.0.0',
        '255.255.255.254',
    ]

    ipv4_false = [
        '255.255.255.256',
        '1.2.3.4.5',
        '1.2.3.999',
        '1.2.3',
        '1.2.3.4.5',
        '1.2.3.4.5',
        '300.2.3.4',
    ]

    for test_addr in ipv4_true:
        if not is_netmask(test_addr):
            raise

# Generated at 2022-06-11 01:09:09.792460
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.252.0') == 22
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8

# Generated at 2022-06-11 01:09:11.276511
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24

# Generated at 2022-06-11 01:09:19.304557
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Test addresses as shown in RFC 4843
    assert to_ipv6_subnet('2001:db8::567:89ab') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::567:89ab/64') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::567:89ab/48') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::567:89ab/32') == '2001:db8::'

# Generated at 2022-06-11 01:09:27.615452
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.0.0.0') != 16

    try:
        to_masklen('255.0.0')
    except ValueError:
        assert True
    except BaseException:
        assert False

    try:
        to_masklen('')
    except ValueError:
        assert True
    except BaseException:
        assert False

    try:
        to_masklen('255.0.255.0')
    except ValueError:
        assert True
    except BaseException:
        assert False



# Generated at 2022-06-11 01:09:32.866574
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', 24) == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'

# Generated at 2022-06-11 01:09:36.259213
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.0')



# Generated at 2022-06-11 01:09:40.745537
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'



# Generated at 2022-06-11 01:09:47.872271
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    print("Testing to_ipv6_subnet")
    assert(to_ipv6_subnet('fe80::10e6:1eff:fe98:2b6c/64') == 'fe80::')
    assert(to_ipv6_subnet('2001:0db8:85a3:08d3:1319:8a2e:0370:7334/64') == '2001:db8:85a3::')
    assert(to_ipv6_subnet('2001:0db8:85a3:08d3:1319:8a2e:0370:7334') == '2001:db8:85a3::')

# Generated at 2022-06-11 01:09:58.323085
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::3e3c:7183:c842:d9a7') == 'fe80::'
    assert to_ipv6_subnet('fe80::3e3c:7183:c842:d9a7') == 'fe80::'
    assert to_ipv6_subnet('fe80::3e3c:7183:c842:d9a7/64') == 'fe80::'
    assert to_ipv6_subnet('fe80::3e3c:7183:c842:d9a7%eth0') == 'fe80::'
    assert to_ipv6_subnet('2001:db8:1::1') == '2001:db8:1::'

# Generated at 2022-06-11 01:10:04.655714
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    def assert_equal(a, b):
        if a != b:
            raise ValueError('%s != %s' % (a, b))
        return True

    assert_equal(to_ipv6_subnet('2001:db8::123:4567:89ab:cdef'), '2001:db8::')
    assert_equal(to_ipv6_subnet('2001:db8::/64'), '2001:db8::')
    assert_equal(to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:123:4567'), '2001::123:4567:')
    assert_equal(to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:123:4567/64'), '2001::123:4567:')

# Generated at 2022-06-11 01:10:11.308235
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('::1:1') == '::1:'
    assert to_ipv6_network('1:1::') == '1:1:0:0:0:'
    assert to_ipv6_network('1:1:1:1:1:1:1:1') == '1:1:1:'
    assert to_ipv6_network('1:1:1:1:1:1:1:1:1') == '1:1:1:'

# Generated at 2022-06-11 01:10:22.240502
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    test_addrs = {
        '::1': '::',
        '::': '::',
        '0::': '0:0:0:',
        '0:0::': '0:0:0:',
        '0:0:0::': '0:0:0:',
        '0:0:0:0::': '0:0:0:',
        'fe80::100:7f:fffe%eth0': 'fe80::',
        '2610:1c1:0:4a4:192:168:10:10':'2610:1c1:0:4a4:',
        'fedc:ba98:7654:3210:fedc:ba98:7654:3210': 'fedc:ba98:7654:3210:'
    }


# Generated at 2022-06-11 01:10:27.821084
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # ipv6_network_addr should equal 'a:b:c:d::'
    ipv6_addr = 'a:b:c:d:1:2:3:4'
    ipv6_network_addr = to_ipv6_network(ipv6_addr)
    assert ipv6_network_addr == 'a:b:c:d::'
    # ipv6_network_addr should equal '1234:567::'
    ipv6_addr = '1234:567:b2d9:eaaf:f2d1:4d4e:4f3c:fb3e'
    ipv6_network_addr = to_ipv6_network(ipv6_addr)
    assert ipv6_network_addr == '1234:567::'
    #

# Generated at 2022-06-11 01:10:32.108989
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    addr = "2001:0db8:85a3:0000:0000:8a2e:0370:7334"
    assert to_ipv6_subnet(addr) == "2001:db8:85a3::"


# Generated at 2022-06-11 01:10:40.831537
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-11 01:10:44.546783
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.10.10.10', '255.255.255.0') == '10.10.10.0/24'
    assert to_subnet('10.10.10.10', '24') == '10.10.10.0/24'

# Generated at 2022-06-11 01:10:54.140722
# Unit test for function is_netmask
def test_is_netmask():
    assert abs(is_netmask("255.255.255.0"))
    assert abs(is_netmask("255.255.255.128"))
    assert abs(is_netmask("255.128.0.0"))
    assert abs(is_netmask("255.0.0.0"))
    assert abs(is_netmask("128.0.0.0"))
    assert abs(is_netmask("0.0.0.0"))
    assert abs(is_netmask("0.0.0.255"))
    assert abs(is_netmask("0.0.255.0"))
    assert abs(is_netmask("0.255.0.0"))
    assert abs(is_netmask("255.0.0.0"))
    assert not is_netmask("0.0.0.256")

# Generated at 2022-06-11 01:11:05.067123
# Unit test for function is_netmask
def test_is_netmask():
    """
    Tests is_netmask()
    :return: None
    """
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.255.128') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('128.0.0.0') is True
    assert is_netmask('0.0.0.0') is True

    assert is_netmask('255.0.0.0') is False
    assert is_netmask('0.255.0.0') is False
    assert is_netmask('256.0.0.0') is False
    assert is_netmask('1.256.0.0') is False
    assert is_netmask('1.1.256.0') is False

# Generated at 2022-06-11 01:11:13.554743
# Unit test for function to_subnet

# Generated at 2022-06-11 01:11:17.722759
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.1', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '24') == '192.168.0.0/24'



# Generated at 2022-06-11 01:11:25.175463
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.10.10.10', '24') == '10.10.10.0/24'
    assert to_subnet('10.10.10.10', '255.255.255.0') == '10.10.10.0/24'
    assert to_subnet('10.10.10.10', '255.255.255.0', True) == '10.10.10.0 255.255.255.0'
    assert to_subnet('::ffff:192.168.1.10', '112') == '::ffff:192.168.1.0/112'

# Generated at 2022-06-11 01:11:33.973773
# Unit test for function to_subnet
def test_to_subnet():
    from netaddr import IPNetwork

    assert to_subnet('192.168.2.0', 24) == '192.168.2.0/24'
    assert to_subnet('192.168.2.0', '255.255.255.0') == '192.168.2.0/24'
    assert to_subnet('192.168.2.0', '255.255.255.0', True) == '192.168.2.0 255.255.255.0'
    assert to_subnet('192.168.2.0', '255.255.255.128') == '192.168.2.0/25'
    assert to_subnet('192.168.2.0', '255.255.255.128', True) == '192.168.2.0 255.255.255.128'

# Generated at 2022-06-11 01:11:38.212799
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.0.1')  # too many parts
    assert not is_netmask('255.255.255')  # too few parts
    assert not is_netmask('foo.string')  # non-numeric part


# Generated at 2022-06-11 01:11:47.209417
# Unit test for function to_subnet

# Generated at 2022-06-11 01:11:58.636594
# Unit test for function to_subnet

# Generated at 2022-06-11 01:12:07.407223
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.255")
    assert is_netmask("255.255.255.0")
    assert is_netmask("255.255.0.0")
    assert is_netmask("255.0.0.0")
    assert not is_netmask("255.255.255.256")
    assert not is_netmask("255.256.255.255")
    assert not is_netmask("256.255.255.255")
    assert not is_netmask("255.255.255.x")


# Generated at 2022-06-11 01:12:15.733862
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')

    assert not is_netmask('255.0')
    assert not is_netmask('255.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('0.0.0.0.0')
    assert not is_netmask('255.255.255.-1')
    assert not is_netmask('-1.0.0.0')


# Generated at 2022-06-11 01:12:25.802696
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.254.253.0') is False
    assert is_netmask('256.255.255.255') is False
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('0.0.0.0') is True
    assert is_netmask('128.0.0.0') is True
    assert is_netmask('255.255.254.0') is False
    assert is_netmask('255.255.252.0') is True
    assert is_netmask('255.255.248.0') is True
    assert is_netmask('255.255.240.0') is True
    assert is_netmask('255.255.224.0') is True
   

# Generated at 2022-06-11 01:12:36.703931
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.a')
    assert not is_netmask('255.255.255.0a')
    assert not is_netmask('')
    assert not is_netmask('a.b.c.d')
    assert not is_netmask('a.b.c.0')
    assert not is_netmask('255.255.255.-1')


# Generated at 2022-06-11 01:12:45.758414
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.255") is True
    assert is_netmask("255.255.255.0") is True
    assert is_netmask("255.255.252.0") is True
    assert is_netmask("128.0.0.0") is True
    assert is_netmask("0.0.0.0") is True
    assert is_netmask("255.255.255.25") is False
    assert is_netmask("255.255.255.252") is False
    assert is_netmask("255.255.0") is False
    assert is_netmask("255.255.0.0.0") is False


# Generated at 2022-06-11 01:12:51.804064
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0")
    assert is_netmask("255.255.255.254")
    assert not is_netmask("255.256.255.0")
    assert not is_netmask("255.255.255")
    assert not is_netmask("255.255.255.0.0")


# Generated at 2022-06-11 01:12:57.246093
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.0.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('256.255.255.255')


# Generated at 2022-06-11 01:13:01.483334
# Unit test for function is_netmask
def test_is_netmask():
    """ Unit test for function is_netmask """
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.252.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.x')
    assert not is_netmask('255.255.255.0/8')



# Generated at 2022-06-11 01:13:13.425790
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0'))
    assert(is_netmask('255.255.255.255'))
    assert(is_netmask('255.255.255.254'))
    assert(is_netmask('255.255.255.252'))
    assert(is_netmask('255.255.255.248'))
    assert(is_netmask('255.255.255.240'))
    assert(is_netmask('255.255.255.224'))
    assert(is_netmask('255.255.255.192'))
    assert(is_netmask('255.255.255.128'))
    assert(is_netmask('255.255.255.0'))
    assert(is_netmask('255.255.254.0'))
   

# Generated at 2022-06-11 01:13:17.993165
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('0.0.0.0.0')



# Generated at 2022-06-11 01:13:25.951699
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0') == True)
    assert(is_netmask('255.0.0.0') == True)
    assert(is_netmask('255.255.255.0') == True)
    assert(is_netmask('0.0.0.0') == True)
    assert(is_netmask('10.0.0.0') == True)
    assert(is_netmask('0.0.0.1') == False)
    assert(is_netmask('255.0.0.1') == False)
    assert(is_netmask('255.255.255.255') == True)
    assert(is_netmask('256.255.255.255') == False)
    assert(is_netmask('255.256.255.255') == False)

# Generated at 2022-06-11 01:13:40.711182
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("1.1.1.1") == True
    assert is_netmask("255.1.1.1") == True
    assert is_netmask("255.255.1.1") == True
    assert is_netmask("255.255.255.1") == True
    assert is_netmask("255.255.255.255") == True
    assert is_netmask("128.1.1.1") == False
    assert is_netmask("256.1.1.1") == False
    assert is_netmask("1.256.1.1") == False
    assert is_netmask("1.1.256.1") == False
    assert is_netmask("1.1.1.256") == False
    assert is_netmask("0.0.0") == False

# Generated at 2022-06-11 01:13:49.692965
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('1.2.3.4')
    assert not is_netmask('')
    assert not is_netmask(1)
    assert not is_netmask('256.0.0.0')
    assert not is_netmask('1.0.0.256')
    assert not is_netmask('1.0')
    assert not is_netmask('1.0.0')
    assert not is_netmask('1.0.0.0.0')
    assert not is_netmask('1.0.0.0.0.0')
    assert not is_netmask(None)

# Generated at 2022-06-11 01:13:58.637938
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask('a.b.c.d')
    assert not is_netmask('127.0.0.1')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('192.168.1.1/24')
    assert not is_netmask('192.168.1.1/24')

    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')


# Generated at 2022-06-11 01:14:06.165379
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0")
    assert is_netmask("255.255.254.0")
    assert not is_netmask("255.255.255.0.0.0")
    assert not is_netmask("255.255.256.0")
    assert not is_netmask("255.256.255.0")
    assert not is_netmask("256.255.255.0")
    assert not is_netmask("255.255.255.a")


# Generated at 2022-06-11 01:14:11.955359
# Unit test for function is_netmask
def test_is_netmask():
    print("Testing function is_netmask")
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('192.168.10.1')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('1.2.3.4')



# Generated at 2022-06-11 01:14:18.092113
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.128.0')
    assert is_netmask('255.255.128.255')
    assert not is_netmask('255.255.128')
    assert not is_netmask('255.255.128.0.0')
    assert not is_netmask('255.255.128.0.255')



# Generated at 2022-06-11 01:14:28.733658
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('0.0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.-1')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('foo')
    assert not is_netmask('.255.255.0')
    assert not is_netmask('255,255,255,0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.255')



# Generated at 2022-06-11 01:14:33.697779
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.0.255')
    assert not is_netmask('255.255.0.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255.0.0.0')



# Generated at 2022-06-11 01:14:40.744718
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('1080:0:0:0:8:800:200C:417A')
    assert not is_netmask('331.12.255.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('invalid')


# Generated at 2022-06-11 01:14:47.799142
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask(None)
    assert not is_netmask('255.255.0.0')
    assert not is_netmask('255.255.255.255.0.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.224')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0')


# Generated at 2022-06-11 01:15:00.174135
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.1000') == False
    assert is_netmask('255.255.255.0.0') == False
    assert is_netmask('255..255.0') == False
    assert is_netmask('255.255.255.0/24') == False
    assert is_netmask('24') == False



# Generated at 2022-06-11 01:15:06.751855
# Unit test for function is_netmask
def test_is_netmask():
    netmasks = [
        '255.255.254.0',
        '255.255.255.0',
        '255.255.255.128',
        '255.255.255.192',
        '255.255.255.224',
        '255.255.255.240',
        '255.255.255.248',
        '255.255.255.252',
        '255.255.255.254',
        '255.255.255.255',
        ]

    for netmask in netmasks:
        assert is_netmask(netmask), 'Invalid: %s' % netmask


# Generated at 2022-06-11 01:15:11.725713
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('0.0.0.0') == True
    assert is_netmask('255.255.0.0') == True
    assert is_netmask('255.255.0.1') == False



# Generated at 2022-06-11 01:15:20.016366
# Unit test for function is_netmask
def test_is_netmask():
    # Test invalid netmasks
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.01')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0/1')
    assert not is_netmask('')
    assert not is_netmask('0')
    assert not is_netmask('foo')
    assert not is_netmask(1.1)

    # Test valid netmasks
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.255')



# Generated at 2022-06-11 01:15:26.712823
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.350.0') == False
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255.2555') == False


# Generated at 2022-06-11 01:15:30.777556
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.0.1')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255.0.0.0')



# Generated at 2022-06-11 01:15:34.829426
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.240')
    assert not is_netmask('255.255.128.240')
    assert is_netmask('255.255.0.0')
    assert not is_netmask('111.255.0.0')



# Generated at 2022-06-11 01:15:36.214248
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')


# Generated at 2022-06-11 01:15:42.084919
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0'))
    assert(not is_netmask('255.255.255.255.0'))
    assert(not is_netmask('255.255.255'))
    assert(not is_netmask('255.255.255.300'))
    assert(not is_netmask('255.255.255.0.1'))
    assert(not is_netmask('a.b.c.d'))



# Generated at 2022-06-11 01:15:45.801822
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert not is_netmask('256.255.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('')



# Generated at 2022-06-11 01:15:57.658938
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.266.0')


# Generated at 2022-06-11 01:16:03.713570
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask('255.10.10.0')
    assert not is_netmask('255.10.10.255.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert not is_netmask('255.255.0.255')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')


# Generated at 2022-06-11 01:16:06.990283
# Unit test for function is_netmask
def test_is_netmask():
    """
        Test for function is_netmask
    """
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.0')

# Generated at 2022-06-11 01:16:17.331666
# Unit test for function is_netmask
def test_is_netmask():

    def test(arg1, result):
        if is_netmask(arg1) != result:
            raise AssertionError
        return True

    test('255.255.255.0', True)
    test('0.0.0.0', True)
    test('0.0.0.1', True)
    test('0.0.0.0', True)
    test('255.0.0.0', True)
    test('255.0.0.1', True)
    test('255.0.0.0', True)
    test('255.255.0.0', True)
    test('255.255.0.1', True)
    test('255.255.0.0', True)
    test('255.255.255.0', True)

# Generated at 2022-06-11 01:16:22.092969
# Unit test for function is_netmask
def test_is_netmask():

    assert not is_netmask("192.168.0.0.0")
    assert not is_netmask("192.168.0.0")
    assert not is_netmask("192.168.0.1")
    assert is_netmask("255.255.255.0")
    assert not is_netmask("255.255.255.256")


# Generated at 2022-06-11 01:16:27.231972
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.0.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255')
    assert not is_netmask('255')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('1234.255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.0')



# Generated at 2022-06-11 01:16:36.416392
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.128.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.128.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('128.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('foo')



# Generated at 2022-06-11 01:16:45.991071
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('128.0.0.0')
    assert not is_netmask('255.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.0')

# Generated at 2022-06-11 01:16:49.815984
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0")
    assert not is_netmask("255.5.5.5")
    assert not is_netmask("255.255.255.256")
    assert not is_netmask("255.255.255.0.0")
    assert not is_netmask("255.255.255.0/24")


# Generated at 2022-06-11 01:16:53.171830
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.1')



# Generated at 2022-06-11 01:17:14.142072
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('1.1.1.0')



# Generated at 2022-06-11 01:17:22.994989
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0'))
    assert(not is_netmask('255.255.255.255.0'))
    assert(not is_netmask('255.255.255.0.0'))
    assert(not is_netmask('255.255.255'))
    assert(not is_netmask('255.255.255.0.0'))
    assert(not is_netmask('255.255.255.256'))
    assert(not is_netmask('foobar'))
    assert(not is_netmask('255.255.255.0/24'))


# Generated at 2022-06-11 01:17:31.986536
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('128.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('-1.0.0.0')

# Generated at 2022-06-11 01:17:42.115748
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.0.0.0') == True
    assert is_netmask('255.255.0.0') == True
    assert is_netmask('255.255.255.254') == True
    assert is_netmask('255.255.255.1') == True
    assert is_netmask('255.255.254.255') == True
    assert is_netmask('255.255.1.255') == True
    assert is_netmask('255.0.255.255') == True
    assert is_netmask('254.255.255.255') == True
    assert is_netmask('1.255.255.255') == True

   

# Generated at 2022-06-11 01:17:50.109218
# Unit test for function is_netmask
def test_is_netmask():
    # invalid mask
    assert is_netmask('255.255.0') is False
    assert is_netmask('255.255.0.0.0') is False
    assert is_netmask('255.255.0.0x0') is False
    assert is_netmask('') is False

    # valid masks
    assert is_netmask('255.255.0.0') is True
    assert is_netmask('0.0.0.0') is True
    assert is_netmask('255.255.255.255') is True



# Generated at 2022-06-11 01:17:54.708432
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.252.0') is True
    assert is_netmask('255.255.252.10') is False
    assert is_netmask('255.255.252.0.') is False
    assert is_netmask('.255.252.10') is False
    assert is_netmask('a.b.c.d') is False



# Generated at 2022-06-11 01:18:00.619116
# Unit test for function is_netmask
def test_is_netmask():
    nets = [
        '255.0.0.0',
        '255.255.254.0',
        '255.255.255.254',
        '255.255.255.255',
        '128.0.0.0',
        '255.128.0.0',
        '255.255.128.0',
        '255.255.255.128',
    ]
    for net in nets:
        assert is_netmask(net)



# Generated at 2022-06-11 01:18:05.491026
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('255.255.255.256') is False
    assert is_netmask('255.255.255') is False


# Generated at 2022-06-11 01:18:16.270741
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.252')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.0.0')
    # 255.255.0.0 is not a valid netmask because it is not continuous
    assert not is_netmask('255.254.255.0')
    # 255.254.255.0 is not a valid netmask because it is not continuous
    assert not is_netmask('255.255.255.1')
    # 255.255.255.1 is not a valid netmask because it is not continuous
    assert not is_netmask(1)
    # 1 is not a valid netmask because

# Generated at 2022-06-11 01:18:20.218699
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('128.0.0.1')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255')
