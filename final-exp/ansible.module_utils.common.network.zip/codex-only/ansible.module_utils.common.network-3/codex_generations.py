

# Generated at 2022-06-22 21:41:01.661333
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # IPv6 address for subnet function
    addr = "fe80:0:0:0:f816:3eff:fe0d:f5f6"

    # Results of function
    result = to_ipv6_subnet(addr)

    # Check result contains correct data
    assert result == "fe80:0:0:0::"



# Generated at 2022-06-22 21:41:10.528279
# Unit test for function to_masklen
def test_to_masklen():
    """ Test the to_masklen function """
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-22 21:41:21.563427
# Unit test for function to_masklen

# Generated at 2022-06-22 21:41:30.532330
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.128.0') == 17
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('0.0.0.0') == 0

# Generated at 2022-06-22 21:41:42.270003
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # IPv6 Network Tests
    assert to_ipv6_network('2001:4860:4860::8888') == '2001:4860:4860::'
    assert to_ipv6_network('2001:4860:4860:0:0:0:0:8888') == '2001:4860:4860::'
    assert to_ipv6_network('2001::0:0:0:0:8888') == '2001::'
    assert to_ipv6_network(':0:0:0:0:0:0:0:0') == '::'
    assert to_ipv6_network('2001:4860:4860:0000:0000:0000:0000:8888') == '2001:4860:4860::'

# Generated at 2022-06-22 21:41:43.504593
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24



# Generated at 2022-06-22 21:41:49.322204
# Unit test for function is_netmask
def test_is_netmask():
    assert True == is_netmask('255.255.255.0')
    assert False == is_netmask('255.255.255.255')
    assert False == is_netmask('255.255.255')
    assert False == is_netmask('255.255.256.0')
    assert False == is_netmask('255.255.255.0.0')


# Generated at 2022-06-22 21:41:58.663279
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fc00::79f4:4c4d:c1ce:2cc2') == 'fc00::'
    assert to_ipv6_subnet('fc00:1:2:3:4:5:6:7') == 'fc00:1:2:3:4:5:6:7:'
    assert to_ipv6_subnet('fc00:1:2:3::') == 'fc00:1:2:3::'
    assert to_ipv6_subnet('fc00:1:2::') == 'fc00:1:2::'
    assert to_ipv6_subnet('fc00:1::') == 'fc00:1::'


# Generated at 2022-06-22 21:42:08.877555
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('AA:BB:CC:DD:EE:FF')
    assert is_mac('aa:bb:cc:dd:ee:FF')
    assert is_mac('aa:bb:cc:dd:eE:ff')
    assert is_mac('aA:bb:cc:dd:ee:ff')
    assert is_mac('aa:bb:cc:dd:ee:fF')
    assert not is_mac('aa:bb:cc:dd:ee')
    assert not is_mac('aa:bb:cc:dd:ee:fg')
    assert not is_mac('aa:bb:cc:dd:ee:f')
    assert not is_mac('aa:bb:cc:dd:ee:fg:ff')

# Generated at 2022-06-22 21:42:12.872097
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(31)
    assert is_masklen("31")
    assert is_masklen("0")
    assert not is_masklen("a")
    assert not is_masklen("10a")


# Generated at 2022-06-22 21:42:19.626551
# Unit test for function is_masklen
def test_is_masklen():
    valid_masklens = [0, 1, 31, 32]
    invalid_masklens = [33, 99, -1]

    for val in valid_masklens:
        assert (is_masklen(val) is True), "Expected True for value %s" % val

    for val in invalid_masklens:
        assert (is_masklen(val) is False), "Expected False for value %s" % val



# Generated at 2022-06-22 21:42:25.182511
# Unit test for function is_netmask
def test_is_netmask():
    """Test function is_netmask"""
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.224')
    assert not is_netmask('255.255.255.240')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.0.255')
    assert not is_netmask('245.255.255.255')



# Generated at 2022-06-22 21:42:26.306196
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')


# Generated at 2022-06-22 21:42:30.554733
# Unit test for function is_masklen
def test_is_masklen():
    assert not is_masklen(33)
    assert not is_masklen('foobar')
    assert is_masklen('0')
    assert is_masklen('32')
    # This is a valid masklen according to is_masklen()
    assert is_masklen('33')


# Generated at 2022-06-22 21:42:38.402198
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    """Test to_ipv6_subnet() method."""
    assert to_ipv6_subnet("FF01::101") == 'FF01::'
    assert to_ipv6_subnet("FF01:0:0:0:0:0:0:101") == 'FF01::'
    assert to_ipv6_subnet("2001:FF01::101") == '2001:FF01::'
    assert to_ipv6_subnet("2001:FF01:0:0:0:0:0:101") == '2001:FF01::'


# Generated at 2022-06-22 21:42:41.830040
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('128.0.0.0') == '10000000000000000000000000000000'

# Generated at 2022-06-22 21:42:48.780684
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("FA:16:3E:FC:FB:BF") is True
    assert is_mac("FA:16:3E:FC:FB:BK") is False
    assert is_mac("FA:16:3E:FC:FB:") is False
    assert is_mac("FA:16:3E:FC:FB:B") is False
    assert is_mac("FA:16:3E:FC:FB:BF-FA:16:3E:FC:FB:BF") is False

# Generated at 2022-06-22 21:42:58.734581
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('0.0.0.255') == 8
    assert to_masklen('0.0.255.0') == 16
    assert to_masklen('0.0.255.255') == 24
    assert to_masklen('0.255.0.0') == 16
    assert to_masklen('0.255.0.255') == 24
    assert to_masklen('0.255.255.0') == 24
    assert to_masklen('0.255.255.255') == 24
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.0.0.255') == 16
    assert to_masklen('255.0.255.0') == 16
   

# Generated at 2022-06-22 21:43:10.631034
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.224') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.240') == '11111111111111111111111111100000'
    assert to_bits('255.255.255.248') == '11111111111111111111111111110000'
    assert to_bits('255.255.255.252') == '11111111111111111111111111111100'

# Generated at 2022-06-22 21:43:14.616884
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '111111111111111111111111100000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('240.0.0.0') == '11110000000000000000000000000000'

# Generated at 2022-06-22 21:43:25.090833
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():

    assert(to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::')
    assert(to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334/64') == '2001:db8:85a3::')
    assert(to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::')
    assert(to_ipv6_subnet('2001:0db8:85a3::8a2e:0370:7334') == '2001:db8:85a3::')

# Generated at 2022-06-22 21:43:36.157612
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:abcd:1234:1::1') == '2001:db8:abcd:1234::'
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('0000:0000:0000:0000:0000:0000:0000:0001') == '::'
    assert to_ipv6_subnet('fe80::') == 'fe80::'
    assert to_ipv6_subnet('fe80:1::') == 'fe80::'

# Generated at 2022-06-22 21:43:47.756928
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fd3d:e4a1:8a7:9fd3::f3:29') == 'fd3d:e4a1:8a7:9fd3::'
    assert to_ipv6_network('fd3d:e4a1:8a7::') == 'fd3d:e4a1:8a7::'
    assert to_ipv6_network('fd3d::') == 'fd3d::'
    assert to_ipv6_network('fd3d:200:8a7:9fd3::f3:29') == 'fd3d:200:8a7:9fd3::'

# Generated at 2022-06-22 21:43:57.912151
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert is_mac('0011.2233.4455')
    assert is_mac('00-11-22-33-44-55')
    assert is_mac('00 11 22 33 44 55')
    assert not is_mac('00:11:22:33:44:55:66')
    assert not is_mac('00 11 22 33 44 55 66')
    assert not is_mac('00-11-22-33-44-55-66')
    assert not is_mac('00:11:22:33:44:55:66:77')

# Generated at 2022-06-22 21:44:06.303465
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '24'
    assert to_masklen('24') == '255.255.255.0'
    assert to_subnet('10.1.1.1', '24') == '10.1.1.0/24'
    assert to_subnet('10.1.1.1', '255.255.255.0') == '10.1.1.0/24'

# Generated at 2022-06-22 21:44:13.285680
# Unit test for function to_netmask
def test_to_netmask():
    assert(to_netmask(24) == '255.255.255.0')
    assert(to_netmask(20) == '255.255.240.0')
    assert(to_netmask(16) == '255.255.0.0')
    assert(to_netmask(8) == '255.0.0.0')
    assert(to_netmask(0) == '0.0.0.0')



# Generated at 2022-06-22 21:44:21.103702
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::200:f8ff:fe21:67cf') == 'fe80::'
    assert to_ipv6_subnet('fe80::200:f8ff:fe21:67cf/64') == 'fe80::'
    assert to_ipv6_subnet('fe80::200:f8ff:fe21:67cf/128') == 'fe80::200:f8ff:fe21:67cf'
    assert to_ipv6_subnet('2001:db8:ac10:fe01::') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:ac10:fe01::/64') == '2001:db8::'

# Generated at 2022-06-22 21:44:31.241204
# Unit test for function is_netmask
def test_is_netmask():
    assert(is_netmask('255.255.255.0'))
    assert(is_netmask('255.255.254.0'))
    assert(is_netmask('255.255.252.0'))
    assert(is_netmask('255.255.248.0'))
    assert(is_netmask('255.255.240.0'))
    assert(is_netmask('255.255.224.0'))
    assert(is_netmask('255.255.192.0'))
    assert(is_netmask('255.255.128.0'))
    assert(is_netmask('255.255.0.0'))
    assert(is_netmask('255.254.0.0'))
    assert(is_netmask('255.252.0.0'))
   

# Generated at 2022-06-22 21:44:32.526367
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('24')
    assert not is_masklen('39')


# Generated at 2022-06-22 21:44:40.379715
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:0:1:0:0:1') == '2001:db8:0:0:'
    assert to_ipv6_subnet('2001:db8::1:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8::1:0:0:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:00:0000:0000:0000:1:1') == '2001:db8:0:0:0:0:0:1:'

# Generated at 2022-06-22 21:44:42.347917
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')



# Generated at 2022-06-22 21:44:49.427706
# Unit test for function to_subnet
def test_to_subnet():

    assert to_subnet('10.0.0.0', '8') == '10.0.0.0/8'
    assert to_subnet('172.16.1.2', '16') == '172.16.0.0/16'
    assert to_subnet('172.16.1.2', '17') == '172.16.0.0/17'
    assert to_subnet('172.16.1.2', '18') == '172.16.0.0/18'
    assert to_subnet('172.16.1.2', '19') == '172.16.0.0/19'
    assert to_subnet('172.16.1.2', '20') == '172.16.0.0/20'

# Generated at 2022-06-22 21:45:00.086448
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.252.0') == 22
    assert to_masklen('255.255.248.0') == 21
   

# Generated at 2022-06-22 21:45:08.268697
# Unit test for function is_mac
def test_is_mac():
    mac_addresses = ['02:01:02:03:04:05', '02:01:02:03:04:5', '02-01-02-03-04-05']
    not_mac_addresses = ['02:01:02:03:04:', '02:01:02:03:04:1', '02-01-02-03-04-5']

    # test valid mac addresses
    assert ([True] * len(mac_addresses) == list(map(is_mac, mac_addresses)))

    # test invalid mac addresses
    assert ([False] * len(not_mac_addresses) == list(map(is_mac, not_mac_addresses)))

# Generated at 2022-06-22 21:45:12.055991
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::86d6:a6ff:fe85:a0d3') == 'fe80::'



# Generated at 2022-06-22 21:45:22.841153
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert("::" == to_ipv6_network('::'))
    assert('1::' == to_ipv6_network('1::'))
    assert('1:2::' == to_ipv6_network('1:2::1:2:3'))
    assert('1:2:3::' == to_ipv6_network('1:2:3::1:2:3'))
    assert('1:2:3:4::' == to_ipv6_network('1:2:3:4::1:2:3:4'))

# Generated at 2022-06-22 21:45:35.213836
# Unit test for function to_masklen

# Generated at 2022-06-22 21:45:42.210709
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('e8:de:27:af:67:bc')
    assert is_mac('e8-de-27-af-67-bc')
    assert is_mac('E8-DE-27-AF-67-BC')
    assert not is_mac('E8:DE:27:AF:67:BC:00')
    assert not is_mac('E8:DE:27:AF:67')
    assert not is_mac('E8:DE:27::AF:67:BC:00')
    assert not is_mac('abcd.ef01.2345')

# Generated at 2022-06-22 21:45:51.212819
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.128.0.0') == '11111111100000000000000000000000'
    assert to_bits('255.255.192.0') == '11111111111111111100000000000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'



# Generated at 2022-06-22 21:45:55.308409
# Unit test for function is_masklen
def test_is_masklen():

    assert is_masklen(32) is True
    assert is_masklen(1) is True
    assert is_masklen(0) is True
    assert is_masklen('1') is True
    assert is_masklen('1.10') is False
    assert is_masklen(33) is False


# Generated at 2022-06-22 21:45:59.307258
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """
    Given IPv6 address, assert the network is generated
    """
    input_addr = '2000::/3'
    expected_network = '2000::/3'
    actual_network = to_ipv6_network(input_addr)

    assert actual_network == expected_network


# Generated at 2022-06-22 21:46:05.208187
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32') is True
    assert is_masklen('31') is True
    assert is_masklen('0') is True
    assert is_masklen('-0') is True
    assert is_masklen('33') is False
    assert is_masklen('') is False
    assert is_masklen('abc') is False
    assert is_masklen('1.1.1.1') is False
    assert is_masklen('/32') is False



# Generated at 2022-06-22 21:46:10.520633
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """
    Unit test to validate function to_ipv6_network

    Examples of expected behaviour:
        2001:DB8::10/128 -> 2001:DB8::/48
        2001:DB8:1111:2222::10/128 -> 2001:DB8:1111:2222::/48
        2001:DB8:1111:2222:3333:4444::10/128 -> 2001:DB8:1111:2222::/48
    """
    # Address with 4 groups present
    ipv6_addr_1 = u'2001:DB8:1111:2222::10/128'
    ipv6_network_1 = to_ipv6_network(ipv6_addr_1)
    if ipv6_network_1 != u'2001:DB8:1111:2222::/48':
        raise AssertionError


# Generated at 2022-06-22 21:46:19.486597
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(0) == '0.0.0.0'

    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('16') == '255.255.0.0'
    assert to_netmask('8') == '255.0.0.0'
    assert to_netmask('0') == '0.0.0.0'

# Generated at 2022-06-22 21:46:23.813910
# Unit test for function to_masklen
def test_to_masklen():
    """Unit test for to_masklen"""
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26



# Generated at 2022-06-22 21:46:27.431810
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-22 21:46:33.553271
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.3', 24) == '192.168.1.0/24'
    assert to_subnet('192.168.1.3', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.3', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'

# Generated at 2022-06-22 21:46:36.495030
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    try:
        to_masklen('255.255.255.8')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-22 21:46:40.545257
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.192.0') == '255.255.192.0'
    assert to_netmask(26) == '255.255.255.192'



# Generated at 2022-06-22 21:46:49.732390
# Unit test for function is_masklen
def test_is_masklen():
    """ Tests for is_masklen function """

# Generated at 2022-06-22 21:46:53.851521
# Unit test for function to_bits
def test_to_bits():
    """
    Run unit tests for function to_bits
    """
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'

# Generated at 2022-06-22 21:47:03.509458
# Unit test for function is_masklen
def test_is_masklen():
    """
    Test for invalid inputs for is_masklen
    """
    assert is_masklen(0) is True
    assert is_masklen(32) is True
    assert is_masklen(31) is True
    assert is_masklen('0') is True
    assert is_masklen('32') is True
    assert is_masklen('31') is True
    assert is_masklen('0.0.0.0') is False
    assert is_masklen('33') is False
    assert is_masklen('31.31.31.31') is False
    assert is_masklen('31\n') is False


# Generated at 2022-06-22 21:47:11.941296
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:cdba:0000:0000:0000:0000:3257:9652') == '2001:cdba:0000:0000:0000:0000:'
    assert to_ipv6_network('2001:cdba:0000:0000:0000:0000:3257:9652/64') == '2001:cdba:0000:0000:0000:0000:'
    assert to_ipv6_network('2001:cdba::3257:9652') == '2001:cdba::'
    assert to_ipv6_network('2001:cdba:0:0:0:0:3257:9652') == '2001:cdba:0:0:0:0:'



# Generated at 2022-06-22 21:47:13.396767
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-22 21:47:24.632164
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet(u'2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3:::'
    assert to_ipv6_subnet(u'2001:0db8:85a3:0:0:8a2e:0370:7334') == '2001:db8:85a3:::'
    assert to_ipv6_subnet(u'2001:0db8:85a3::8a2e:0370:7334') == '2001:db8:85a3:::'
    assert to_ipv6_subnet(u'2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3:::'
   

# Generated at 2022-06-22 21:47:35.659014
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    from ansible.module_utils.network.common.utils import to_ipv6_subnet

    assert '::' == to_ipv6_subnet('::')
    assert '2001::' == to_ipv6_subnet('2001::')
    assert '2001::' == to_ipv6_subnet('2001::1')
    assert '2001:0db8::' == to_ipv6_subnet('2001:0db8::1')
    assert '2001:0db8:0c18:0042::' == to_ipv6_subnet('2001:0db8:0c18:0042::1')

# Generated at 2022-06-22 21:47:42.222903
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.224.0') == '255.255.224.0'
    assert to_netmask(27) == '255.255.255.224'
    assert is_netmask(to_netmask(24))
    assert is_netmask(to_netmask('24'))
    assert not is_netmask(to_netmask('24.0.0.0'))
    assert not is_netmask(to_netmask('255.255.255.0.0'))



# Generated at 2022-06-22 21:47:49.805219
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0)
    assert is_masklen(32)
    assert is_masklen('0')
    assert is_masklen('32')
    assert not is_masklen(-1)
    assert not is_masklen(33)
    assert not is_masklen('-1')
    assert not is_masklen('33')
    assert not is_masklen('string')


# Generated at 2022-06-22 21:47:59.522034
# Unit test for function is_netmask
def test_is_netmask():
    for test in [
        '255.255.255.255',
        '255.255.252.128',
        '255.255.0.0',
        '255.255.255.254',
        '255.254.0.0',
    ]:
        assert is_netmask(test)
    for test in [
        '255.255.255.256',
        '255.256.255.255',
        '255.255.255.0.0',
        '255.0.0',
        '256.255.255.255',
        '0.0.0.0',
        '1.1.1',
        '1.1.1.1.2',
    ]:
        assert not is_netmask(test)



# Generated at 2022-06-22 21:48:05.319729
# Unit test for function to_bits
def test_to_bits():
    """ Test to_bits function """
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'



# Generated at 2022-06-22 21:48:07.667288
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    test_addr = 'fe80::1%c0a8010a'
    test_subnet = 'fe80::'
    assert(to_ipv6_subnet(test_addr) == test_subnet), "Subnet of given address should be fe80::"


# Generated at 2022-06-22 21:48:17.450264
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet("2001:0db8:0000:0000:0000:ff00:0042:8329") == "2001:0db8:0000:0000::"
    assert to_ipv6_subnet("2001:0db8:0000:0000:0000:ff00:0042:8329") == "2001:0db8:0000:0000::"
    assert to_ipv6_subnet("2001:db8::ff00:42:8329") == "2001:db8::"
    assert to_ipv6_subnet("2001:db8:a:b:c:d:e:1") == "2001:db8:a:b:c:d:e::"


# Generated at 2022-06-22 21:48:23.459363
# Unit test for function to_subnet
def test_to_subnet():
    assert '192.168.1.0 255.255.255.0' == to_subnet('192.168.1.65', '24')
    assert '192.168.1.0/24' == to_subnet('192.168.1.65', '255.255.255.0', False)
    assert '10.0.0.0/8' == to_subnet('10.1.1.1', '255.0.0.0', False)

# Generated at 2022-06-22 21:48:29.825337
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:1234::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1234:5678:abcd::1') == '2001:db8:0:1234::'
    assert to_ipv6_subnet('2001:db8:0:1234:5678:abcd:1:1') == '2001:db8:0:1234::'


# Generated at 2022-06-22 21:48:41.514188
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert '2001::' == to_ipv6_network('2001::')
    assert '2001:db8::' == to_ipv6_network('2001:db8::1')
    assert '2001:db8::' == to_ipv6_network('2001:db8::1:2')
    assert '2001:db8::' == to_ipv6_network('2001:db8:0:0:1:2:3:4')
    assert '2001:db8::' == to_ipv6_network('2001:db8:0:0:1:2:3:4')
    assert '2001:db8:0:1::' == to_ipv6_network('2001:db8:0:1:1:1:1:1')

# Generated at 2022-06-22 21:48:50.188575
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('255.255.255.256') is False
    assert is_netmask('255.255.255.2') is False
    assert is_netmask('255.255.255.24') is False
    assert is_netmask('255.255.24.24') is False
    assert is_netmask('255.24.24.24') is False
    assert is_netmask('24.24.24.24') is False
    assert is_netmask('24.24.255.255') is False
    assert is_netmask('24.255.255.255') is False
    assert is_netmask('255.255.255.24') is False
   

# Generated at 2022-06-22 21:48:58.525232
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('128.0.0.0') == '10000000000000000000000000000000'
    assert to_bits('127.255.255.255') == '01111111111111111111111111111111'
    assert to_bits('10.0.0.0') == '00001010000000000000000000000000'


# Generated at 2022-06-22 21:49:01.413654
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'


# Generated at 2022-06-22 21:49:03.506763
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'



# Generated at 2022-06-22 21:49:11.063495
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:DB8::1') == '2001:DB8::'
    assert to_ipv6_network('2001:DB8:1:2:3:4::1') == '2001:DB8:1:2:3:4::'
    assert to_ipv6_network('2001:DB8:1:2:3:4:5:6') == '2001:DB8:1:2:3:4::'
    assert to_ipv6_network('2001:DB8:0:0:0:0:0:0') == '2001:DB8::'
    assert to_ipv6_network('2001:DB8:0:0:1:2:3:4') == '2001:DB8:0:0:0:0:0:0'
    assert to_

# Generated at 2022-06-22 21:49:19.133229
# Unit test for function to_bits
def test_to_bits():
    """
    Test cases for function to_bits
    """
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'



# Generated at 2022-06-22 21:49:21.548207
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('10') == True
    assert is_masklen('-1') == False
    assert is_masklen('33') == False
    assert is_masklen('asdf') == False


# Generated at 2022-06-22 21:49:24.265923
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24

# Generated at 2022-06-22 21:49:34.052782
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:00:00:00:00')
    assert is_mac('01:23:45:67:89:ab')
    assert is_mac('ff:ff:ff:ff:ff:ff')
    assert is_mac('00-00-00-00-00-00')
    assert is_mac('01-23-45-67-89-ab')
    assert is_mac('ff-ff-ff-ff-ff-ff')
    assert is_mac('00:00:00:00:00:00')
    assert is_mac('01:23:45:67:89:ab')
    assert is_mac('ff:ff:ff:ff:ff:ff')
    assert not is_mac('00:00:00:00:00:00:00')
    assert not is_mac

# Generated at 2022-06-22 21:49:40.905426
# Unit test for function is_mac
def test_is_mac():
    # Validate mac address
    assert is_mac('00-0a-95-9d-68-16') is True
    assert is_mac('00:0a:95:9d:68:16') is True

    # Invalid mac address
    assert is_mac('00-0a-95-9d-68-160') is False
    assert is_mac('00-0a-95-9d-68-16-0') is False


# Generated at 2022-06-22 21:49:48.052206
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24', dotted_notation=True) == '192.168.1.0 255.255.255.0'



# Generated at 2022-06-22 21:49:53.914235
# Unit test for function is_masklen
def test_is_masklen():
    # Valid masklen
    assert is_masklen(24)
    assert is_masklen(31)
    assert is_masklen(0)
    assert is_masklen(32)

    # Empty value, invalid masklen
    assert not is_masklen('')
    assert not is_masklen(' ')

    # Invalid masklen
    assert not is_masklen(-1)
    assert not is_masklen(33)



# Generated at 2022-06-22 21:50:02.224661
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('0.0.0.1') == 0
    assert to_masklen('0.0.0.2') == 1
    assert to_masklen('0.0.0.3') == 2
    assert to_masklen('0.0.0.4') == 3
    assert to_masklen('0.0.0.5') == 3
    assert to_masklen('0.0.0.6') == 3
    assert to_masklen('0.0.0.7') == 3
    assert to_masklen('0.0.0.8') == 4
    assert to_masklen('0.0.0.9') == 4
    assert to_masklen('0.0.0.10') == 4
   

# Generated at 2022-06-22 21:50:13.601093
# Unit test for function to_ipv6_network
def test_to_ipv6_network():

    test_address = 'fe80::9b9a:6e0f:b59a:6cd8'
    expected_network = 'fe80::'
    assert to_ipv6_network(test_address) == expected_network

    test_address = 'fe80::3e38:6e0f:b59a:6cd8'
    expected_network = 'fe80::3e38:'
    assert to_ipv6_network(test_address) == expected_network

    test_address = 'fe80:0:0:0:3e38:6e0f:b59a:6cd8'
    expected_network = 'fe80::3e38:'
    assert to_ipv6_network(test_address) == expected_network


# Generated at 2022-06-22 21:50:18.448528
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'

# Generated at 2022-06-22 21:50:27.263435
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.0.0') is True
    assert is_netmask('255.0.0.0') is True
    assert is_netmask('0.0.0.0') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('255.255.255.254') is False
    assert is_netmask('255.255.255.256') is False
    assert is_netmask('255.255.255.255.255') is False
    assert is_netmask('255.255.255.1') is False


# Generated at 2022-06-22 21:50:35.820227
# Unit test for function to_subnet
def test_to_subnet():
    """ Test to_subnet function """
    assert {'addr': '192.168.1.2', 'mask': '32', 'dotted_notation': False, 'result': '192.168.1.2/32'} == to_subnet('192.168.1.2', '32')
    assert {'addr': '192.168.1.0', 'mask': '24', 'dotted_notation': False, 'result': '192.168.1.0/24'} == to_subnet('192.168.1.0', '255.255.255.0')

# Generated at 2022-06-22 21:50:39.440818
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    addr = "2001:db8:1a2b:3a4b:5a6b:7a8b:9aab:bcad"
    subnet = to_ipv6_subnet(addr)
    assert subnet == "2001:db8:1a2b:3a4b::"

    addr = "2001:db8::1a2b:3a4b:5a6b:7a8b:9aab:bcad"
    subnet = to_ipv6_subnet(addr)
    assert subnet == "2001:db8::"



# Generated at 2022-06-22 21:50:45.248392
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32) is True
    assert is_masklen(0) is True
    assert is_masklen(24) is True
    assert is_masklen(22) is True
    assert is_masklen(5) is True
    assert is_masklen(23) is True
    assert is_masklen(33) is False
    assert is_masklen(-1) is False



# Generated at 2022-06-22 21:50:47.114560
# Unit test for function to_bits
def test_to_bits():
    bits = to_bits('255.255.255.0')
    assert bits == '11111111111111111111111100000000'

# Generated at 2022-06-22 21:50:52.221834
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(26) == '255.255.255.192'
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(28) == '255.255.255.240'


# Generated at 2022-06-22 21:50:57.806940
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.255.254') == 23