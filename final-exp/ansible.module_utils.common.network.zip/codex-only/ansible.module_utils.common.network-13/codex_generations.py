

# Generated at 2022-06-22 21:41:05.513816
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:1428:57ab') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:0:0:0:0:1428:57ab') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::1428:57ab') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:0:8765::1428:57ab') == '2001:db8:0:8765::'
    assert to_ipv6_subnet('2001:db8:0:0:0:8765::1428:57ab') == '2001:db8:0:0:0::'


# Generated at 2022-06-22 21:41:09.562874
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    test_addr = 'fe80::10:254:a00:2%eth1'
    subnet_addr = to_ipv6_subnet(test_addr)
    expected_addr = 'fe80::10:254:a00:'
    assert subnet_addr == expected_addr

# Generated at 2022-06-22 21:41:18.234328
# Unit test for function is_masklen
def test_is_masklen():
    assert(is_masklen('32'))
    assert(is_masklen('31'))
    assert(is_masklen('24'))
    assert(is_masklen('16'))
    assert(is_masklen('0'))
    assert(not is_masklen('33'))
    assert(not is_masklen('-1'))
    assert(not is_masklen(''))
    assert(not is_masklen('a'))


# Generated at 2022-06-22 21:41:25.658973
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.0', 24, True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.0', '255.255.255.0', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0/24'

# Generated at 2022-06-22 21:41:32.513184
# Unit test for function to_subnet
def test_to_subnet():
    subnet_tests = [('10.20.30.0', 24, '10.20.30.0/24'),
                    ('10.20.30.0', '255.255.255.0', '10.20.30.0/24'),
                    ('10.20.30.0', '255.255.0.0', '10.20.0.0/16'),
                    ('10.20.30.0', '255.0.0.0', '10.0.0.0/8')
                   ]

    for (addr, mask, cidr) in subnet_tests:
        assert to_subnet(addr, mask) == cidr

# Generated at 2022-06-22 21:41:43.460506
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8:::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:0:1') == '2001:db8:::'
    assert to_ipv6_subnet('2001:db8:0:cd30:0:0:0:1') == '2001:db8:::'
    assert to_ipv6_subnet('2001:0db8:0:cd30:123:4567:89ab:cdef') == '2001:db8:::'
    assert to_ipv6_subnet('2001:0db8:0:cd30:123:4567:89ab:cdef') == '2001:db8:::'


# Generated at 2022-06-22 21:41:55.319796
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    print('# Unit test for function to_ipv6_subnet')
    assert to_ipv6_subnet('2001:0db8:85a3::8a2e:0370:7334') == '2001:db8:85a3::', 'Incorrect IPv6 subnet returned'
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::', 'Incorrect IPv6 subnet returned'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::', 'Incorrect IPv6 subnet returned'

# Generated at 2022-06-22 21:42:06.877517
# Unit test for function to_netmask
def test_to_netmask():
    assert(to_netmask(32) == '255.255.255.255')
    assert(to_netmask(31) == '255.255.255.254')
    assert(to_netmask(30) == '255.255.255.252')
    assert(to_netmask(29) == '255.255.255.248')
    assert(to_netmask(28) == '255.255.255.240')
    assert(to_netmask(27) == '255.255.255.224')
    assert(to_netmask(26) == '255.255.255.192')
    assert(to_netmask(25) == '255.255.255.128')
    assert(to_netmask(24) == '255.255.255.0')

# Generated at 2022-06-22 21:42:15.303584
# Unit test for function to_masklen

# Generated at 2022-06-22 21:42:24.175152
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('08:00:27:de:be:af') is True
    assert is_mac('08-00-27-de-be-af') is True

    assert is_mac('08:00:27:de:be:af:') is False
    assert is_mac('08-00-27-de-be-af ') is False
    assert is_mac('08:00:27:de:be') is False
    assert is_mac('08-00-27-de-be') is False
    assert is_mac('08:00:27:de:be:af:0') is False
    assert is_mac('08-00-27-de-be-af-0') is False

# Generated at 2022-06-22 21:42:27.688081
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0)
    assert is_masklen(32)
    assert is_masklen(16)
    assert not is_masklen(33)
    assert not is_masklen(-1)
    assert not is_masklen(3.6)
    assert not is_masklen('33')
    assert not is_masklen(None)


# Generated at 2022-06-22 21:42:38.391366
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    def run_test(addr, expected_result):
        result = to_ipv6_subnet(addr)
        assert(result == expected_result)

    # Test cases taken from RFC2374, Appendix A
    run_test('1080:0:0:0:8:800:200C:417A', '1080::8:800:200C:417A')
    run_test('FF01:0:0:0:0:0:0:101', 'FF01::101')
    run_test('0:0:0:0:0:0:0:1', '::1')
    run_test('0:0:0:0:0:0:0:0', '::')

# Generated at 2022-06-22 21:42:45.067717
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert not is_mac('00-11-22-33-44-55')
    assert not is_mac('00:11:22:33:44:5f')

if __name__ == '__main__':
    # Run tests
    test_is_mac()

# Generated at 2022-06-22 21:42:56.406134
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
     assert to_ipv6_network('fe80::a00:27ff:fe7b:1561') == 'fe80::'
     assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
     assert to_ipv6_network('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3::'
     assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'

# Generated at 2022-06-22 21:43:09.407090
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.1.1.1', '24') == '10.1.1.0/24'
    assert to_subnet('10.1.1.1', '255.255.255.0') == '10.1.1.0/24'
    assert to_subnet('10.1.1.1', '255.255.255.0', True) == '10.1.1.0 255.255.255.0'
    assert to_subnet('10.1.1.0', '255.255.255.0') == '10.1.1.0/24'
    assert to_subnet('10.1.1.0', '255.255.255.0', True) == '10.1.1.0 255.255.255.0'



# Generated at 2022-06-22 21:43:17.529720
# Unit test for function is_mac

# Generated at 2022-06-22 21:43:21.453633
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.0.0.0')
    assert not is_netmask('255.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('255.0.0.a')
    assert not is_netmask('127.0.0.1')


# Generated at 2022-06-22 21:43:31.657509
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask('254') == '255.255.255.254'
    assert to_netmask('255.255.240.0') == '255.255.240.0'
    assert to_netmask('/32') == '255.255.255.255'
    assert to_netmask('255.255.255.255') == '255.255.255.255'
    assert to_netmask('255.255.255.254') == '255.255.255.254'


# Generated at 2022-06-22 21:43:33.474720
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen("255.255.0.0") == 16


# Generated at 2022-06-22 21:43:40.354668
# Unit test for function to_subnet
def test_to_subnet():
    # Test masklen
    assert to_subnet('192.168.1.1', 24) == '192.168.1.0/24'
    # Test mask
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    # Test dotted mask
    assert to_subnet('192.168.1.1', 24, True) == '192.168.1.0 255.255.255.0'
    # Test invalid masklen
    try:
        to_subnet('192.168.1.1', -1)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-22 21:43:41.390752
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'



# Generated at 2022-06-22 21:43:44.837290
# Unit test for function to_bits
def test_to_bits():

    assert(to_bits('255.255.255.255') == '11111111111111111111111111111111')
    assert(to_bits('255.0.0.0') == '11111111000000000000000000000000')
    assert(to_bits('128.0.0.0') == '10000000000000000000000000000000')
    assert(to_bits('0.0.0.0') == '00000000000000000000000000000000')
    assert(to_bits('255.255.248.0') == '11111111111111111111111110000000')



# Generated at 2022-06-22 21:43:48.537201
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask('255.255.255.192') == '255.255.255.192'

# Generated at 2022-06-22 21:43:57.600124
# Unit test for function to_masklen
def test_to_masklen():
    masklen_values = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                      16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]

# Generated at 2022-06-22 21:44:06.883819
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('127.0.0.0') == 0
    assert to_masklen('0.0.0.0') == 0



# Generated at 2022-06-22 21:44:11.909172
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.0.255.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('abc')
    assert not is_netmask('1')


# Generated at 2022-06-22 21:44:14.730029
# Unit test for function to_netmask
def test_to_netmask():
    assert is_masklen(to_masklen('255.255.255.0')) == True


# Generated at 2022-06-22 21:44:20.671179
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.255') == to_netmask(32)
    assert to_netmask('255.255.255.0') == to_netmask(24)
    assert to_netmask('255.255.0.0') == to_netmask(16)
    assert to_netmask('255.0.0.0') == to_netmask(8)
    assert to_netmask('0.0.0.0') == to_netmask(0)
    assert to_netmask('255.128.0.0') == to_netmask(9)



# Generated at 2022-06-22 21:44:31.072808
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # https://tools.ietf.org/rfc/rfc2374.txt
    assert to_ipv6_subnet('2001:db8:0:1234:0:567:8:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::123:4567:89ab') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:0:2:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:1234::') == '2001::'

# Generated at 2022-06-22 21:44:38.608132
# Unit test for function to_subnet
def test_to_subnet():
    results = list()
    results.append(to_subnet('1.2.3.4', 24))
    results.append(to_subnet('1.2.3.4', '255.255.255.0'))
    results.append(to_subnet('1.2.3.4', '255.255.255.0', True))
    if results[0] != '1.2.3.0/24':
        raise AssertionError("Incorrect ipv4 conversion to subnet")
    elif results[1] != '1.2.3.0/24':
        raise AssertionError("Incorrect ipv4 conversion to subnet")

# Generated at 2022-06-22 21:44:45.009387
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert str(to_masklen('0.0.0.0')) == '0'
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.128.0') == 17
    assert to_masklen('255.255.255.255') == 32

# Generated at 2022-06-22 21:44:47.464988
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.252') == 30



# Generated at 2022-06-22 21:44:58.971612
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("FE80:0000:0000:0000:0202:B3FF:FE1E:8329") == "FE80::"
    assert to_ipv6_network("fe80:0000:0000:0000:0202:B3FF:FE1E:8329") == "fe80::"
    assert to_ipv6_network("FE80::0202:B3FF:FE1E:8329") == "FE80::"
    assert to_ipv6_network("FE80::0202:B3FF:FE1E") == "FE80::"
    assert to_ipv6_network("FE80::0202:B3FF") == "FE80::"
    assert to_ipv6_network("FE80::0202") == "FE80::"
    assert to_

# Generated at 2022-06-22 21:45:09.349291
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    ip_address = '2001:db8:1234:5678:9abc:def0:1234:5678'
    assert to_ipv6_network(ip_address) == '2001:db8:1234::'
    ip_address = 'fe80:1234:5678:9abc:def0:1234:5678:abcd'
    assert to_ipv6_network(ip_address) == 'fe80:1234:5678::'
    ip_address = '2001:db8:1234:5678::'
    assert to_ipv6_network(ip_address) == '2001:db8:1234::'
    ip_address = '2001:db8:1234::'
    assert to_ipv6_network(ip_address) == '2001:db8::'
   

# Generated at 2022-06-22 21:45:19.394823
# Unit test for function is_mac
def test_is_mac():
    assert True == is_mac('0123.4567.89ab')
    assert True == is_mac('01:23:45:67:89:ab')
    assert True == is_mac('01-23-45-67-89-ab')
    assert False == is_mac('0123.4567.89ab.cdef')
    assert False == is_mac('01234.567.89ab')
    assert False == is_mac('01:23:45:67:89:ab:cd')
    assert False == is_mac('abcd:01:23:45:67:89')
    assert False == is_mac('abcdef')
    assert False == is_mac('abcdefg')
    assert False == is_mac('abcdefghijkl')

# Generated at 2022-06-22 21:45:26.413205
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.254')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('foo')
    assert not is_netmask(None)


# Generated at 2022-06-22 21:45:38.494294
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    """ Unit test for function to_ipv6_subnet. """
    assert to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:0000:0001:0000:0000:cafe:0000:0000:1414:1414:1414') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:0000:0001') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'

# Generated at 2022-06-22 21:45:40.680532
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.0', '255.255.255.0') == '192.168.1.0/24'


# Generated at 2022-06-22 21:45:45.979284
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'



# Generated at 2022-06-22 21:45:47.681704
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-22 21:45:54.538090
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('172.16.0.0', '255.255.240.0') == u'172.16.0.0/20'
    assert to_subnet('172.16.0.0', '255.255.255.0') == u'172.16.0.0/24'
    assert to_subnet('172.16.0.0', '255.255.0.0') == u'172.16.0.0/16'


# Generated at 2022-06-22 21:46:04.066917
# Unit test for function to_bits
def test_to_bits():
    """
    Test to_bits method
    :return:
    """
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('128.0.0.0') == '10000000000000000000000000000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.128.0.0') == '11111111000000000000000010000000'

# Generated at 2022-06-22 21:46:06.884073
# Unit test for function is_masklen
def test_is_masklen():
    assert not is_masklen('33')
    assert is_masklen('32')
    assert is_masklen('24')
    assert is_masklen(24)
    assert not is_masklen('-1')



# Generated at 2022-06-22 21:46:13.242060
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '1111111111111111111111100000000', "Test to_bits with CIDR netmask"
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111', "Test to_bits with CIDR netmask"


# Generated at 2022-06-22 21:46:21.764858
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Test 1
    addr = '2001:db8:0:1234::abcd'
    assert to_ipv6_subnet(addr) == '2001:db8::'

    # Test 2
    addr = '2001:db8:0:1234::'
    assert to_ipv6_subnet(addr) == '2001:db8:0:1234::'

    # Test 3
    addr = '2001:db8::'
    assert to_ipv6_subnet(addr) == '2001:db8::'

    # Test 4
    addr = '0:0:0:0:0:0:0:0'
    assert to_ipv6_subnet(addr) == '::'


# Generated at 2022-06-22 21:46:27.104102
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert not is_masklen(33)
    assert is_masklen(0)
    assert not is_masklen(-1)
    assert not is_masklen(33.4)
    assert not is_masklen('re')
    assert not is_masklen(None)


# Generated at 2022-06-22 21:46:33.643283
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55') is True
    assert is_mac('00-11-22-33-44-55') is True
    assert is_mac('00-11-22-33-44:-55') is False
    assert is_mac('00-11-22-33-44-55-66') is False
    assert is_mac('00:11:22:33:44:55:66') is False


# Generated at 2022-06-22 21:46:36.262575
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen("0") is True
    assert is_masklen("32") is True
    assert is_masklen("-1") is False
    assert is_masklen("33") is False


# Generated at 2022-06-22 21:46:42.157314
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('not a real mask')

# Generated at 2022-06-22 21:46:51.665054
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen("255.255.255.0") == 24
    assert to_masklen("255.255.255.128") == 25
    assert to_masklen("255.255.255.192") == 26
    assert to_masklen("255.255.255.224") == 27
    assert to_masklen("255.255.255.240") == 28
    assert to_masklen("255.255.255.248") == 29
    assert to_masklen("255.255.255.252") == 30
    assert to_masklen("255.255.255.254") == 31
    assert to_masklen("255.255.255.255") == 32



# Generated at 2022-06-22 21:47:01.116134
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.5', '22') == '192.168.0.0/22'
    assert to_subnet('192.168.1.5', '255.255.252.0') == '192.168.0.0/22'
    assert to_subnet('192.168.1.5', '255.255.252.0', dotted_notation=True) == '192.168.0.0 255.255.252.0'


# Generated at 2022-06-22 21:47:05.579311
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.2550')
    assert not is_netmask('255.255.255.0.0')


# Generated at 2022-06-22 21:47:10.257909
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("01:23:45:67:89:AB")
    assert is_mac("01-23-45-67-89-AB")
    assert is_mac("0123.4567.89AB")
    assert not is_mac("0123.4567.89AB.CDEF")
    assert not is_mac("G123.4567.89AB")


# Generated at 2022-06-22 21:47:16.589782
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.128') is True
    assert is_netmask('255.256.255.128') is False
    assert is_netmask('256.255.255.128') is False
    assert is_netmask('255.255.255.x') is False
    assert is_netmask('255.255.255') is False


# Generated at 2022-06-22 21:47:20.738627
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == '2001:db8:85a3::'


# Generated at 2022-06-22 21:47:30.986381
# Unit test for function to_masklen
def test_to_masklen():
    # Test positive values
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23

# Generated at 2022-06-22 21:47:35.649569
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(31)
    assert is_masklen(0)
    assert not is_masklen(33)
    assert not is_masklen(-1)
    assert not is_masklen(None)
    assert not is_masklen('foobar')


# Generated at 2022-06-22 21:47:38.740498
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2604:4100:1263:3ef:4554:f003:ef:23') == '2604:4100:1263:3ef::'


# Generated at 2022-06-22 21:47:41.978186
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'

# Generated at 2022-06-22 21:47:47.153428
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    addr = "2001:db8:1234:5678:9101:1121:3257:9652"

    assert to_ipv6_network(addr) == "2001:db8:1234::"

# Generated at 2022-06-22 21:47:55.889534
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask("0.0.0")
    assert not is_netmask("0.0.0.0.0")
    assert not is_netmask("256.0.0.0")
    assert not is_netmask("0.256.0.0")
    assert not is_netmask("0.0.256.0")
    assert not is_netmask("0.0.0.256")
    assert is_netmask("0.0.0.0")
    assert is_netmask("0.0.0.1")
    assert is_netmask("0.0.0.255")
    assert is_netmask("0.0.1.0")
    assert is_netmask("0.0.1.255")
    assert is_netmask("0.0.255.0")
   

# Generated at 2022-06-22 21:47:57.413825
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.128.0') == 17


# Generated at 2022-06-22 21:48:04.253031
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.240.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')



# Generated at 2022-06-22 21:48:13.558008
# Unit test for function to_subnet

# Generated at 2022-06-22 21:48:19.792533
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet("::ffff:192.0.2.128") == "::192.0.2.128"
    assert to_ipv6_subnet("2001:db8:a0b:12f0::1") == "2001:db8:a0b:12f0::"
    assert to_ipv6_subnet("2001:0db8:0000:85a3:0000:0000:ac1f:8001") == "2001:0db8::ac1f:8001"

# Generated at 2022-06-22 21:48:30.333489
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert '2001:0db8::0' == to_ipv6_network('2001:0db8::0')
    assert '2001:0db8::0' == to_ipv6_network('2001:0db8::0:0')
    assert '2001:0db8::0' == to_ipv6_network('2001:0db8::0:0:0')
    assert '2001:0db8::0' == to_ipv6_network('2001:0db8::0:0:0:0')
    assert '2001:0db8::0' == to_ipv6_network('2001:0db8::0:0:0:0:0')

# Generated at 2022-06-22 21:48:40.119443
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.254') == '11111111111111111111111111111110'
    assert to_bits('255.255.252.0') == '11111111111111111111110000000000'
    assert to_bits('255.255.254.0') == '11111111111111111111111000000000'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'

# Generated at 2022-06-22 21:48:46.643765
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3:0:0:8a2e:370::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:0:0:8a2e:370::'


# Generated at 2022-06-22 21:48:57.641842
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:10:0:12:34:56:78') == '2001:db8:10::'
    assert to_ipv6_subnet('2001:db8:1000:2000:3000:4000:5000:6000') == '2001:db8:1000:2000::'
    assert to_ipv6_subnet('100:100:100:100:100:100:100:100') == '100:100:100:100::'
    assert to_ipv6_subnet('1234:abcd:1234:abcd:1234:abcd:1234:abcd') == '1234:abcd:1234:abcd::'

# Generated at 2022-06-22 21:49:04.080696
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.128.0.0') == '11111111100000000000000000000000'
    assert to_bits('128.0.0.0') == '10000000000000000000000000000000'



# Generated at 2022-06-22 21:49:11.361124
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask('16') == '255.255.0.0'

    assert to_netmask(9) == '255.128.0.0'
    assert to_netmask('9') == '255.128.0.0'

    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask('8') == '255.0.0.0'

    # too small
    try:
        to_netmask(7)
        assert False
    except ValueError:
        assert True

    # too big

# Generated at 2022-06-22 21:49:21.771454
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    expected = '2:31::'
    actual = to_ipv6_subnet('2:31:cafe:babe::0/64')
    assert expected == actual

    expected = 'dead::'
    actual = to_ipv6_subnet('dead::1/64')
    assert expected == actual

    expected = 'fd::'
    actual = to_ipv6_subnet('fd::1/64')
    assert expected == actual

    expected = 'f1::'
    actual = to_ipv6_subnet('f12:31:cafe:babe::1/64')
    assert expected == actual

    expected = 'f12:31:cafe:babe::'

# Generated at 2022-06-22 21:49:31.675717
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', 24) == '192.168.1.0/24'
    assert to_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334', 64) == '2001:db8:85a3::/64'
    assert to_subnet('2001:0db8:85a3:0000:0:8a2e:0370:7334', 64) == '2001:db8:85a3::/64'

# Generated at 2022-06-22 21:49:38.334936
# Unit test for function to_subnet
def test_to_subnet():
    assert '0.0.0.0 255.255.255.0' == to_subnet('0.0.0.0', '24', True)
    assert '10.0.0.0 255.0.0.0' == to_subnet('10.1.1.1', '8', True)
    assert '10.128.0.0 255.255.0.0' == to_subnet('10.128.1.1', '16', True)
    assert '10.179.128.0 255.255.224.0' == to_subnet('10.179.128.1', '27', True)
    assert '10.79.128.0 255.255.240.0' == to_subnet('10.170.128.1', '28', True)

# Generated at 2022-06-22 21:49:45.682832
# Unit test for function to_subnet
def test_to_subnet():
    tests = [
        ('10.0.0.1', '255.255.255.0', '10.0.0.0/24'),
        ('192.168.1.4', '32', '192.168.1.4/32'),
        ('192.168.1.4', '255.255.255.0', '192.168.1.0/24'),
        ('2a00:1bc0:2:101::1', '64', '2a00:1bc0:2:101::/64'),
        ('2001:0DB8:0000:CD30:0000:0000:0000:0000', '48', '2001:db8::/48'),
    ]

    for addr, mask, expected in tests:
        actual = to_subnet(addr, mask)
        assert actual == expected



# Generated at 2022-06-22 21:49:49.468352
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(24)
    assert is_masklen(32)
    assert is_masklen(0)
    assert not is_masklen(-1)
    assert not is_masklen(33)
    assert not is_masklen(5.5)



# Generated at 2022-06-22 21:49:59.606943
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    expected_output = '2001:db8::'
    actual_output = to_ipv6_subnet('2001:db8:1234:5678:9abc:def0:1234:5678')
    assert expected_output == actual_output

    expected_output = '2001:db8:1234::'
    actual_output = to_ipv6_subnet('2001:db8:1234:5678::')
    assert expected_output == actual_output

    expected_output = '2001:db8:1234:cafe::'
    actual_output = to_ipv6_subnet('2001:db8:1234:5678:9abc:def0:1234:cafe')
    assert expected_output == actual_output


# Generated at 2022-06-22 21:50:04.954627
# Unit test for function to_subnet
def test_to_subnet():
    # Test segments to addresses
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', dotted_notation=True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24', dotted_notation=True) == '192.168.1.0 255.255.255.0'
    # Test addresses to segments

# Generated at 2022-06-22 21:50:08.654555
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(24)
    assert not is_masklen(0)
    assert not is_masklen('test')
    assert not is_masklen(33)


# Generated at 2022-06-22 21:50:14.595066
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # https://tools.ietf.org/rfc/rfc2374.txt
    assert to_ipv6_subnet('2001:2:2:2::2') == '2001:2:2:2::'
    assert to_ipv6_subnet('2001:2::2') == '2001:2::'
    assert to_ipv6_subnet('2001::') == '2001::'

# Generated at 2022-06-22 21:50:19.074076
# Unit test for function is_masklen
def test_is_masklen():
    # Test masks that should work
    masks = ['0', '1', '2', '8', '16', '32']
    for mask in masks:
        assert is_masklen(mask)

    # Test masks that should not work
    masks = ['33', '-1', '4.4.4.4']
    for mask in masks:
        assert not is_masklen(mask)



# Generated at 2022-06-22 21:50:23.913999
# Unit test for function to_bits
def test_to_bits():
    assert(to_bits('255.255.255.0') == '11111111111111111111111100000000')
    assert(to_bits('255.255.255.128') == '11111111111111111111111110000000')
    assert(to_bits('255.128.0.0') == '11111111100000000000000000000000')


# Generated at 2022-06-22 21:50:27.640565
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30



# Generated at 2022-06-22 21:50:38.959541
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert(to_ipv6_network('fe80::2:eaff:fe76:c419') == 'fe80::')
    assert(to_ipv6_network('fe80::') == 'fe80::')
    assert(to_ipv6_network('fe80:1::2:eaff:fe76:c419') == 'fe80:1::')
    assert(to_ipv6_network('fe80:1:2::2:eaff:fe76:c419') == 'fe80:1:2::')
    assert(to_ipv6_network('fe80:1:2:3::2:eaff:fe76:c419') == 'fe80:1:2:3::')


# Generated at 2022-06-22 21:50:46.770787
# Unit test for function to_netmask
def test_to_netmask():
    assert('255.255.255.0' == to_netmask(24))
    assert('255.255.255.128' == to_netmask(25))
    assert('255.255.255.0' == to_netmask('255.255.255.0'))
    assert('255.255.255.0' == to_netmask('/24'))
    assert('255.255.0.0' == to_netmask('255.255.0.0'))
    assert('255.255.0.0' == to_netmask('/16'))



# Generated at 2022-06-22 21:50:55.295611
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.0', '24') == '192.168.0.0 255.255.255.0'

    assert to_subnet('192.168.0.0', '255.255.255.0', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.0', '24', True) == '192.168.0.0 255.255.255.0'
