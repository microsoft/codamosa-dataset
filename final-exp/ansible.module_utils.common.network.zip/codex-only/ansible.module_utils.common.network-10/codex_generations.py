

# Generated at 2022-06-22 21:41:02.820041
# Unit test for function to_masklen
def test_to_masklen():
    assert 32 == to_masklen('255.255.255.255')
    assert 28 == to_masklen('255.255.255.240')
    assert 22 == to_masklen('255.255.252.0')
    assert 11 == to_masklen('255.224.0.0')
    assert 31 == to_masklen('255.255.255.254')
    assert 20 == to_masklen('255.255.240.0')
    assert 12 == to_masklen('255.240.0.0')
    assert 16 == to_masklen('255.255.0.0')
    assert 8 == to_masklen('255.0.0.0')
    assert 0 == to_masklen('0.0.0.0')



# Generated at 2022-06-22 21:41:12.358313
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-22 21:41:16.622705
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('256.255.255.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.0.0')



# Generated at 2022-06-22 21:41:20.011492
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.0.255.255') == '11111111000000000000000011111111'

# Generated at 2022-06-22 21:41:29.889134
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask('192.168.1.1')
    assert not is_netmask('192.168.1.0/24')
    assert not is_netmask('255.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.0')
    assert is_netmask('255.254.0.0')
    assert not is_netmask('255.254.0.1')
    assert not is_netmask('255.255.0.256')



# Generated at 2022-06-22 21:41:32.340880
# Unit test for function to_bits
def test_to_bits():
    assert '0110011001100110000001100000011' == to_bits('198.51.100.3')



# Generated at 2022-06-22 21:41:37.693835
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa-aa-aa-aa-aa-aa')
    assert is_mac('aa:aa:aa:aa:aa:aa')
    assert not is_mac('aa:aa:aa:aa:aa')
    assert not is_mac('aa:aa:aa:aa:aa:aa:aa')


# Generated at 2022-06-22 21:41:48.211495
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('52:54:00:83:e4:ca') is True
    assert is_mac('52:54:00:83:e4:cA') is True
    assert is_mac('52:54:00:83:e4:c-') is False
    assert is_mac('123') is False
    assert is_mac('52:54:00:83:e4:c') is False
    assert is_mac('52.54.00.83.e4.ca') is False
    assert is_mac('654:54:00:83:e4:ca') is False
    assert is_mac('52:54:00:83:e4:c$') is False
    assert is_mac('52:54:00:83:e4:c&') is False

# Generated at 2022-06-22 21:41:58.663430
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2620:0:2d0:200::7') == '2620:0:2d0::'
    assert to_ipv6_subnet('2001:db8::9abc:d0ff:fefe:6789') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:abc:d0ff:fefe:6789:abcd:ef01') == '2001:db8:abc:d0ff:fefe::'
    assert to_ipv6_subnet('2620:0:2d0:200:f816:3eff:fe20:7335') == '2620:0:2d0::'

# Generated at 2022-06-22 21:42:01.514353
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32') == True
    assert is_masklen('33') == False
    assert is_masklen('-1') == False



# Generated at 2022-06-22 21:42:08.715511
# Unit test for function is_masklen
def test_is_masklen():
    if is_masklen('') or is_masklen('0'):
        raise AssertionError("is_masklen('0') or is_masklen('') should be false but they are True")
    if is_masklen(33) or is_masklen(-1):
        raise AssertionError("is_masklen(33) or is_masklen(-1) should be false but they are True")
    if not is_masklen(16):
        raise AssertionError("is_masklen(16) should be true but it is false")



# Generated at 2022-06-22 21:42:19.997251
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:DB8:1:2:3:4:5:6') == '2001:db8:1::'
    assert to_ipv6_subnet('2001:DB8:1:2:3::6') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:DB8:1:2::6') == '2001:db8:1:2::'
    assert to_ipv6_subnet('2001:DB8:1::6') == '2001:db8:1::'
    assert to_ipv6_subnet('2001:DB8::6') == '2001:db8::'
    assert to_ipv6_subnet('2001:DB8::6:7:8') == '2001:db8::'

# Generated at 2022-06-22 21:42:27.198073
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0 ')
    assert not is_netmask(' 255.255.255.0')
    assert not is_netmask('255.255.255.0\n')



# Generated at 2022-06-22 21:42:37.922490
# Unit test for function to_subnet
def test_to_subnet():
    import random
    import netaddr

    # test random masklens and netmasks
    for i in range(0, 100):
        addr = '.'.join([str(random.randint(0, 255)) for i in range(0, 4)])
        cidr_masklen = random.randint(0, 32)
        assert to_subnet(addr, cidr_masklen) == netaddr.IPNetwork('%s/%s' % (addr, cidr_masklen)).cidr

    for i in range(0, 100):
        addr = '.'.join([str(random.randint(0, 255)) for i in range(0, 4)])
        netmask = to_netmask(random.randint(0, 32))
        assert to_subnet(addr, netmask) == netaddr

# Generated at 2022-06-22 21:42:41.200865
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('8') is True
    assert is_masklen(24) is True

    assert is_masklen('33') is False
    assert is_masklen(-1) is False
    assert is_masklen(16.2) is False



# Generated at 2022-06-22 21:42:51.213820
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:01:02:03:04:05') is True
    assert is_mac('00-01-02-03-04-05') is True
    assert is_mac('00:01:02:03:04:5') is False
    assert is_mac('00:01:02:03:04:') is False
    assert is_mac('00:01:02:03:04') is False
    assert is_mac('00:01:02:03:04:05:06') is False
    assert is_mac('00:01:02:03:04:05:06:07') is False
    assert is_mac('Z0:01:02:03:04:05') is False
    assert is_mac('00:Z1:02:03:04:05') is False
    assert is_mac

# Generated at 2022-06-22 21:43:00.461269
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.192.0') == 18
    assert to_masklen('255.252.0.0') == 14
    assert to_masklen('255.248.0.0') == 13
    assert to_masklen('255.240.0.0') == 12
    assert to_masklen('255.224.0.0') == 11
    assert to_masklen('255.192.0.0') == 10
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('254.0.0.0') == 7
    assert to_masklen('252.0.0.0') == 6
   

# Generated at 2022-06-22 21:43:01.286362
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-22 21:43:05.016250
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('-1')


# Generated at 2022-06-22 21:43:07.380902
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('test')


# Generated at 2022-06-22 21:43:15.461758
# Unit test for function to_subnet
def test_to_subnet():
    # Test cases where input mask is netmask
    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.0', '255.255.255.128') == '192.168.0.0/25'
    assert to_subnet('192.168.0.0', '255.255.255.192') == '192.168.0.0/26'
    assert to_subnet('192.168.0.0', '255.255.255.224') == '192.168.0.0/27'
    assert to

# Generated at 2022-06-22 21:43:18.025865
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.248') == '11111111111111111111111111111000'



# Generated at 2022-06-22 21:43:27.082989
# Unit test for function is_netmask
def test_is_netmask():
    # Valid netmask values
    assert is_netmask('255.0.0.0')
    assert is_netmask('255.128.0.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.128.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')



# Generated at 2022-06-22 21:43:37.656150
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    """ Test to_ipv6_subnet function. """
    assert to_ipv6_subnet('2001:cdba:0000:0000:0000:0000:3257:9652') == '2001:cdba::'
    assert to_ipv6_subnet('2001:cdba:0000:0000:0000:0000:0000:0000') == '2001:cdba::'
    assert to_ipv6_subnet('2001:cdba:0:0:0:0:3257:9652') == '2001:cdba::'
    assert to_ipv6_subnet('2001:cdba:0:0:0:0:0:0') == '2001:cdba::'
    assert to_ipv6_subnet('2001:cdba::3257:9652') == '2001:cdba::'
   

# Generated at 2022-06-22 21:43:46.281719
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:1:2:3:4:5') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:2:3:4::') == '2001:db8:0:1:2:3:4::'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::5') == '2001:db8::'


# Generated at 2022-06-22 21:43:52.687873
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(18) == '255.255.192.0'
    assert to_netmask(32) == '255.255.255.255'



# Generated at 2022-06-22 21:43:58.092303
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:db8:0:0:1::1') == '2001:db8:0:0:1::'
    assert to_ipv6_network('2001::1') == '2001::'



# Generated at 2022-06-22 21:44:07.055474
# Unit test for function to_netmask
def test_to_netmask():
    tests = {
        '2': '128.0.0.0',
        '8': '255.0.0.0',
        '24': '255.255.255.0',
        '25': '255.255.255.128',
        '32': '255.255.255.255',
    }

    for test, expected in tests.items():
        actual = to_netmask(test)
        assert actual == expected, '%s != %s (%s)' % (actual, expected, test)



# Generated at 2022-06-22 21:44:17.327080
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("2001:db8:1234:ffff:ffff:ffff:ffff:ffff") == "2001:db8:1234::"
    assert to_ipv6_network("2001:0db8:0000:1234:0000:ffff:ffff:ffff") == "2001:db8:0:1234::"
    assert to_ipv6_network("2001:db8::1234:ffff:ffff:ffff:ffff") == "2001:db8::1234::"
    assert to_ipv6_network("2001::1234:ffff:ffff:ffff:ffff:ffff") == "2001::1234::"
    assert to_ipv6_network("2001:db8:a:b:c:d:e:f") == "2001:db8:a:b::"
    assert to_

# Generated at 2022-06-22 21:44:23.759823
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('24') is True
    assert is_masklen('32') is True
    assert is_masklen('0') is True
    assert is_masklen('-1') is False
    assert is_masklen('33') is False
    assert is_masklen('-24') is False



# Generated at 2022-06-22 21:44:28.176520
# Unit test for function is_mac
def test_is_mac():
    assert(is_mac('00:50:56:00:00:00'))
    assert(not is_mac('00:50:56:00:00:000'))
    return True


# Generated at 2022-06-22 21:44:37.871665
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.252.0') == 22
   

# Generated at 2022-06-22 21:44:46.933168
# Unit test for function to_masklen
def test_to_masklen():
    test_cases = (
        (24, '255.255.255.0'),
        (23, '255.255.254.0'),
        (17, '255.255.128.0'),
        (9, '255.128.0.0'),
        (16, '255.255.0.0'),
        (1, '128.0.0.0'),
        (0, '0.0.0.0'),
        (32, '255.255.255.255'),
    )
    for masklen, netmask in test_cases:
        assert masklen == to_masklen(netmask)



# Generated at 2022-06-22 21:44:53.725319
# Unit test for function to_masklen
def test_to_masklen():
    # Correct results
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.255') == 32
    # Incorrect results
    try:
        to_masklen('255.0.0.0.0')
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"
    try:
        to_masklen('255.0.0')
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"

# Generated at 2022-06-22 21:44:55.287326
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24



# Generated at 2022-06-22 21:45:07.863418
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # IPv6 addresses are eight groupings. The first four groupings (64 bits) comprise the subnet address.
    # https://tools.ietf.org/rfc/rfc2374.txt
    addr1 = '1:2:3:4:5:6:7:8'
    addr2 = '::1:2:3:4:5:6:7:8'
    addr3 = '1:2:3:4:5:6:7:8::'
    addr4 = '1:2:3:4:5:6:7'
    addr5 = '1:2:3:4:5:6'
    addr6 = '1:2:3:4:5'
    addr7 = '1:2:3:4'
    addr8 = '1:2:3'

# Generated at 2022-06-22 21:45:13.872814
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.1', '255.0.0.0') == '10.0.0.0/8'
    assert to_subnet('10.0.0.1', '255.255.255.0') == '10.0.0.0/24'



# Generated at 2022-06-22 21:45:18.450050
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(25)
    assert not is_masklen('25')
    assert not is_masklen(0)
    assert not is_masklen(33)
    assert not is_masklen('-1')
    assert not is_masklen(32.5)


# Generated at 2022-06-22 21:45:29.615891
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert (to_ipv6_network('fd00:202:e3ff:fe2c:b4ff:fe2a:4b4e:1c3d') == 'fd00:202:e3ff:fe2c::')
    assert (to_ipv6_network('fd00:202:e3:fe2c:b4ff:fe2a:4b4e:1c3d') == 'fd00:202:e3::')
    assert (to_ipv6_network('fd00:202:e3ff:fe2c::') == 'fd00:202:e3ff:fe2c::')
    assert (to_ipv6_network('fd00:202:e3:fe2c::') == 'fd00:202::')

# Generated at 2022-06-22 21:45:35.296921
# Unit test for function to_netmask
def test_to_netmask():
    assert is_netmask(to_netmask(24))
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(28) == '255.255.255.240'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(0) == '0.0.0.0'


# Generated at 2022-06-22 21:45:41.468685
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('21') == '255.255.248.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask('255.255.255.255') == '255.255.255.255'
    assert to_netmask('255.255.25.0') != '255.255.255.0'
    assert to_netmask('25') != '255.255.255.0'



# Generated at 2022-06-22 21:45:51.330325
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.254')
    assert not is_netmask('1')
    assert not is_netmask('-1')
    assert not is_netmask('255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('a.255.255.255')
    assert not is_netmask(None)



# Generated at 2022-06-22 21:45:57.626643
# Unit test for function to_netmask
def test_to_netmask():
    assert '0.0.0.0' == to_netmask(0)
    assert '255.255.255.255' == to_netmask(32)
    assert '128.0.0.0' == to_netmask(1)
    assert '255.128.0.0' == to_netmask(9)
    assert '192.0.0.0' == to_netmask(2)
    assert '255.192.0.0' == to_netmask(10)


# Generated at 2022-06-22 21:46:02.141839
# Unit test for function is_netmask
def test_is_netmask():
    for val in VALID_MASKS:
        if not is_netmask(inet_ntoa(pack('>I', 2**32 - 2**val))):
            raise ValueError('function "is_netmask" failed for mask "%s"' % inet_ntoa(pack('>I', 2**32 - 2**val)))



# Generated at 2022-06-22 21:46:08.468610
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.255.0')
    assert not is_netmask('192.168.33')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('192.168.33.256')
    assert not is_netmask('192.168.33.0.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('::1')
    assert is_netmask('::ffff:255.255.255.255')

# Generated at 2022-06-22 21:46:18.328946
# Unit test for function to_netmask

# Generated at 2022-06-22 21:46:23.851308
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    test_addr = '2001:0db8:85a3:0000:0000:8a2e:0370:7334'
    result = to_ipv6_subnet(test_addr)
    assert result == '2001:db8:85a3::', \
        "test_to_ipv6_subnet failed, result should be '2001:db8:85a3::', got: %s" % result


# Generated at 2022-06-22 21:46:34.798886
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(1) == '128.0.0.0'
    assert to_netmask(25) == '255.255.255.128'
    assert to_netmask(26) == '255.255.255.192'
    assert to_netmask(27) == '255.255.255.224'
    assert to_netmask(28) == '255.255.255.240'

# Generated at 2022-06-22 21:46:40.945908
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """ Unit test is_mac """
    assert to_ipv6_network('fe80::4b41:5cff:feb5:5d5d') == 'fe80::'
    assert to_ipv6_network('0::1') == '::'
    assert to_ipv6_network('::1') == '::'
    assert to_ipv6_network('2001:0db8:11a3:09d7:1f34:8a2e:07a0:765d') == '2001:db8:11a3:d:1f34:8a2e:a:765d'

# Generated at 2022-06-22 21:46:51.218831
# Unit test for function to_netmask
def test_to_netmask():
    # Test various invalid masklens
    assert is_netmask(to_netmask(-1)) == False
    assert is_netmask(to_netmask(33)) == False
    assert is_netmask(to_netmask('33')) == False
    assert is_netmask(to_netmask('not a number')) == False
    # Test various valid masklens
    assert is_netmask(to_netmask(0)) == True
    assert is_netmask(to_netmask(4)) == True
    assert is_netmask(to_netmask(8)) == True
    assert is_netmask(to_netmask(24)) == True
    assert is_netmask(to_netmask(32)) == True
    # Test various valid netmasks

# Generated at 2022-06-22 21:46:56.647722
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('-1')
    assert not is_masklen(None)


# Generated at 2022-06-22 21:47:05.748304
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.128.0') == 17
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.254.0.0') == 15
    assert to_masklen('255.252.0.0') == 14
    assert to_masklen('255.248.0.0') == 13
    assert to_masklen('255.240.0.0') == 12
    assert to_masklen('255.224.0.0') == 11
    assert to_masklen('255.192.0.0') == 10
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.0.0.0') == 8
   

# Generated at 2022-06-22 21:47:11.293107
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::4f3c:2aff:fe70:de7f') == 'fe80::'
    assert to_ipv6_network('fe80::4f3c:2afb:fe70:de7f') == 'fe80::4f3c:2afb:fe70:'
    assert to_ipv6_subnet('fe80::4f3c:2afb:fe70:de7f') == 'fe80::4f3c:2afb:fe70:'
    assert to_ipv6_subnet('fe80::4f3c:2afb:fe70:de7f') != 'fe80::4f3c:1afb:fe70:'

# Generated at 2022-06-22 21:47:22.518707
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.255")
    assert is_netmask("255.255.255.254")
    assert is_netmask("255.255.255.252")
    assert is_netmask("255.255.255.248")
    assert is_netmask("255.255.255.240")
    assert is_netmask("255.255.255.224")
    assert is_netmask("255.255.255.192")
    assert is_netmask("255.255.255.128")
    assert is_netmask("255.255.255.0")
    assert not is_netmask("255.255.255")
    assert not is_netmask("255.255.255.0.0")
    assert not is_netmask("255.255.255.0.1")

# Generated at 2022-06-22 21:47:25.490927
# Unit test for function to_netmask
def test_to_netmask():
    assert is_netmask(to_netmask(24))
    assert is_netmask(to_netmask(31))
    assert '255.255.255.254' == to_netmask(31)


# Unit tests for function to_subnet

# Generated at 2022-06-22 21:47:28.653066
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'


# Generated at 2022-06-22 21:47:30.452928
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::1') == 'fe80::'



# Generated at 2022-06-22 21:47:32.623246
# Unit test for function is_masklen
def test_is_masklen():
    # Test mask length
    assert is_masklen(32)
    assert is_masklen(24)
    assert is_masklen(0)
    assert is_masklen(1)
    assert not is_masklen('32')
    assert not is_masklen(-1)
    assert not is_masklen(33)



# Generated at 2022-06-22 21:47:42.484142
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert(to_ipv6_network('fe80::a00:27ff:fe70:73e8/64') == 'fe80::')
    assert(to_ipv6_network('fe80::a00:27ff:fe70:73e8') == 'fe80::')
    assert(to_ipv6_network('fe80::a00:27ff:fe70:73e8/126') == 'fe80::')
    assert(to_ipv6_network('fe80:0:0:0:a00:27ff:fe70:73e8/64') == 'fe80:0:0:0:')

# Generated at 2022-06-22 21:47:49.665035
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-22 21:47:56.248470
# Unit test for function to_masklen
def test_to_masklen():

    assert(to_masklen('255.255.255.255') == 32)
    assert(to_masklen('255.255.255.0') == 24)
    assert(to_masklen('255.255.0.0') == 16)
    assert(to_masklen('255.0.0.0') == 8)
    assert(to_masklen('0.0.0.0') == 0)


# Generated at 2022-06-22 21:48:03.985833
# Unit test for function to_masklen
def test_to_masklen():
    assert isinstance(to_masklen('0.0.0.0'), int)
    assert isinstance(to_masklen('0.0.0.1'), int)
    assert isinstance(to_masklen('0.0.0.2'), int)
    assert isinstance(to_masklen('0.0.0.3'), int)
    assert isinstance(to_masklen('0.0.0.4'), int)
    assert isinstance(to_masklen('0.0.0.5'), int)
    assert isinstance(to_masklen('0.0.0.6'), int)
    assert isinstance(to_masklen('0.0.0.7'), int)
    assert isinstance(to_masklen('0.0.0.8'), int)

# Generated at 2022-06-22 21:48:06.820852
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'



# Generated at 2022-06-22 21:48:18.082197
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('12:34:56:78:90:AB')
    assert is_mac('12-34-56-78-90-AB')
    assert is_mac('1234.5678.90ab')

    assert not is_mac('12345.67890.ab')
    assert not is_mac('1234-5678-90ab')
    assert not is_mac('12:34:56:78:90:ABC')
    assert not is_mac('ab:cd:ef:gh:ij:kl')
    assert not is_mac('12:34:56:78:90')
    assert not is_mac('12:34:56:78:90:')
    assert not is_mac('12:34:56:78:90:=')
    assert not is_mac('')

# Generated at 2022-06-22 21:48:21.350281
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'


# Generated at 2022-06-22 21:48:31.224358
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """ IPv6 network address is the first three groups. """
    assert to_ipv6_network("2001:db8::1") == "2001:db8::"
    assert to_ipv6_network("2001:db8:0:0:1:1:1:1") == "2001:db8::"
    assert to_ipv6_network("2001:db8:0:0:1:1:1:1/32") == "2001:db8::"
    assert to_ipv6_network("2001:db8:0:0:1:1") == "2001:db8:0:0:"
    assert to_ipv6_network("2001:db8:0:0:1:1/32") == "2001:db8:0:0:"

# Generated at 2022-06-22 21:48:39.334222
# Unit test for function to_bits
def test_to_bits():
    assert "00000000" == to_bits("0.0.0.0")
    assert "11111111" == to_bits("255.0.0.0")
    assert "1111111100000000" == to_bits("255.0.0.0")
    assert "11111111" == to_bits("255.255.255.0")
    assert "1111111111111111" == to_bits("255.255.255.0")
    assert "11111111111111110000000000000000" == to_bits("255.255.255.0")



# Generated at 2022-06-22 21:48:47.920223
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:00:00:00:00') is True
    assert is_mac('00-00-00-00-00-00') is True
    assert is_mac('AA-BB-CC-DD-EE-FF') is True
    assert is_mac('AA:BB:CC:DD:EE:FF') is True
    assert is_mac('aa:bb:cc:dd:ee:ff') is True
    assert is_mac('aa:bb:cc:dd:xx:zz') is True
    assert is_mac('aa:bb:cc:dd:ee:ff:gg') is False
    assert is_mac('aa:bb:cc:dd:ee') is False

# Generated at 2022-06-22 21:48:57.755995
# Unit test for function is_netmask
def test_is_netmask():
    # Test valid netmasks
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.255')

    assert is_netmask('255.0.0.0')
    assert is_netmask('255.128.0.0')
    assert is_netmask('255.252.0.0')
    assert is_netmask('255.255.0.0')

    assert is_netmask('0.255.0.0')
    assert is_netmask('128.255.0.0')
    assert is_netmask('252.255.0.0')
    assert is_netmask('255.255.0.0')

# Generated at 2022-06-22 21:49:04.080645
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('256.255.255.0')
    assert not is_netmask('255.255.255.256')



# Generated at 2022-06-22 21:49:08.911304
# Unit test for function to_bits
def test_to_bits():
    test_masklen = [16, 24, 32, 0]
    expected_bits = [
        '11111111.11111111.00000000.00000000',
        '11111111.11111111.11111111.00000000',
        '11111111.11111111.11111111.11111111',
        '00000000.00000000.00000000.00000000'
    ]
    for i in range(len(test_masklen)):
        bits = to_bits(to_netmask(test_masklen[i]))
        assert bits == expected_bits[i]

# Generated at 2022-06-22 21:49:19.978535
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::3e97:eff:fe4f:a2c%eth0') == 'fe80::'
    assert to_ipv6_network('fe80::3e97:eff:fe4f:a2c') == 'fe80::'
    assert to_ipv6_network('fe80::') == 'fe80::'
    assert to_ipv6_network('fe80::3e97:eff:fe4f:a2c%eth0/64') == 'fe80::'
    assert to_ipv6_network('fe80::3e97:eff:fe4f:a2c/64') == 'fe80::'
    assert to_ipv6_network('fe80::3e97:eff:fe4f:a2c::fe80/64')

# Generated at 2022-06-22 21:49:25.829300
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('33') is False
    assert is_masklen('0') is True
    assert is_masklen('') is False
    assert is_masklen('-1') is False
    assert is_masklen('9') is True
    assert is_masklen('32') is True


# Generated at 2022-06-22 21:49:29.934780
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('0.0.0.0') == 0


# Generated at 2022-06-22 21:49:33.448555
# Unit test for function is_masklen
def test_is_masklen():
    assert(is_masklen('25'))
    assert(not is_masklen('32'))
    assert(not is_masklen('33'))
    assert(not is_masklen('-1'))
    assert(not is_masklen('a'))


# Generated at 2022-06-22 21:49:43.518098
# Unit test for function to_subnet
def test_to_subnet():
    tests = [
        ('1.2.3.4', '255.255.255.255', '1.2.3.4/32'),
        ('1.2.3.4', '255.255.255.0', '1.2.3.0/24'),
        ('1.2.3.4', '255.255.0.0', '1.2.0.0/16'),
        ('1.2.3.4', '255.0.0.0', '1.0.0.0/8'),
        ('1.2.3.4', '0.0.0.0', '0.0.0.0/0'),
    ]
    for addr, mask, expected in tests:
        output = to_subnet(addr, mask)

# Generated at 2022-06-22 21:49:54.122332
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():

    assert to_ipv6_subnet('2001:cdba:0000:0000:0000:0000:3257:9652') == '2001:cdba::', \
        "Subnet calculation failed for FQDN 2001:cdba:0000:0000:0000:0000:3257:9652 - Expected 2001:cdba::"

    assert to_ipv6_subnet('2001:cdba:0000:0000:0000:0000:3257:9652/48') == '2001:cdba::', \
        "Subnet calculation failed for FQDN 2001:cdba:0000:0000:0000:0000:3257:9652/48 - Expected 2001:cdba::"


# Generated at 2022-06-22 21:49:57.779333
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.240')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.240.0')



# Generated at 2022-06-22 21:50:03.907169
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    addr = 'fe80:0000:0000:0000:aa00:0000:0000:0040'
    expected = 'fe80::'
    subnet = to_ipv6_subnet(addr)
    assert subnet == expected, '%s != %s' % (subnet, expected)

    addr = 'fe80:0000:0000:0000:aa00:0000:0000:0040/64'
    expected = 'fe80::'
    subnet = to_ipv6_subnet(addr)
    assert subnet == expected, '%s != %s' % (subnet, expected)

    addr = 'fe80:0000:0000:0000:aa00:0000:0000:0040/128'
    expected = 'fe80:0000:0000:0000:aa00:0000:0000:0040'
    subnet = to

# Generated at 2022-06-22 21:50:07.050954
# Unit test for function to_netmask
def test_to_netmask():

    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(17) == '255.255.128.0'


# Generated at 2022-06-22 21:50:17.530226
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('254.0.0.0') == 7
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.0.0.128') == 9
    assert to_masklen('255.0.128.255') == 9
   

# Generated at 2022-06-22 21:50:19.402042
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa:bb:cc:dd:ee:ff') is True


# Generated at 2022-06-22 21:50:22.267810
# Unit test for function is_netmask
def test_is_netmask():
    if not is_netmask('255.255.255.0'):
        raise AssertionError('255.255.255.0 is a valid netmask')



# Generated at 2022-06-22 21:50:32.350506
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:a:b:0:0:0:0') == '2001:db8:a:b::'
    assert to_ipv6_network('2001:db8:a:0:0:0:0:0') == '2001:db8:a::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:0') == '2001:db8:0:0::'
    assert to_ipv6_network('2001:0:0:0:0:0:0:0') == '2001::'
    assert to_ipv6_network('2001:db8::00') == '2001:db8:0:0::'

# Generated at 2022-06-22 21:50:34.658344
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'



# Generated at 2022-06-22 21:50:45.694428
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(9) == '255.128.0.0'
    assert to_netmask(10) == '255.192.0.0'
    assert to_netmask(11) == '255.224.0.0'

# Generated at 2022-06-22 21:50:54.612611
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('16') == '255.255.0.0'
    assert to_netmask('8') == '255.0.0.0'
    assert to_netmask('255.255.255.255') == '32'
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.255.0.0') == '16'
    assert to_netmask('255.0.0.0') == '8'
    assert to_netmask('0.0.0.0') == '0'
    assert to_netmask(0) == '0.0.0.0'