

# Generated at 2022-06-22 21:41:04.668563
# Unit test for function is_mac
def test_is_mac():
    tests = [
        {'input': 'aa-11-bb-22-cc-33', 'expected': True},
        {'input': 'aa-11:bb:22:cc:33:44', 'expected': True},
        {'input': 'aa-11:bb:22:cc:33:aa-11', 'expected': False},
        {'input': 'aa-11:bb:22:cc:33:gg', 'expected': False},
        {'input': 'aa-1g:bb:22:cc:33:dd', 'expected': False},
        {'input': 'aa-11:bb:2g:cc:33:dd', 'expected': False},
    ]
    for test in tests:
        result = is_mac(test['input'])
        if result != test['expected']:
            raise Ass

# Generated at 2022-06-22 21:41:12.433994
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    tests = list()
    tests.append(('2001:4860:4860::8888', '2001:4860:4860::'))
    tests.append(('2001:1:99:a::100', '2001:1:99::'))
    tests.append(('2001:db8:1234:ffff::', '2001:db8:1234::'))

    for (test, expected) in tests:
        actual = to_ipv6_subnet(test)
        if actual != expected:
            raise Exception("Test '%s' expected '%s', got '%s'" % (test, expected, actual))


# Generated at 2022-06-22 21:41:21.178745
# Unit test for function is_netmask
def test_is_netmask():
    from nose.tools import assert_equal

    assert_equal(is_netmask('255.255.255.0'), True)
    assert_equal(is_netmask('255.255.254.0'), False)
    assert_equal(is_netmask('255.255.0'), False)
    assert_equal(is_netmask('255.255.0.0.0'), False)
    assert_equal(is_netmask('255.255.10.0.1'), False)

# Generated at 2022-06-22 21:41:23.102441
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-22 21:41:34.958530
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.248.0') == 21
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.255.255') == 32
    assert not is_masklen('256.0.0.0')
    assert not is_masklen('255.0.0.256')
    assert not is_masklen('255.0.256.0')
    assert not is_masklen('255.256.0.0')
    assert not is_masklen('255.0.0.0.')
    assert not is_

# Generated at 2022-06-22 21:41:41.722868
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.0.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')



# Generated at 2022-06-22 21:41:53.344327
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('aaaa:bbbb:cccc:dddd:eeee:ffff:gggg:hhhh') == 'aaaa:bbbb:cccc::'
    assert to_ipv6_network('aaaa:bbbb:cccc:dddd::gggg:hhhh') == 'aaaa:bbbb:cccc::'
    assert to_ipv6_network('aaaa:bbbb:cccc::hhhh') == 'aaaa:bbbb:cccc::'
    assert to_ipv6_network('aaaa:bbbb::gggg:hhhh') == 'aaaa:bbbb::'
    assert to_ipv6_network('aaaa::dddd:eeee:ffff:gggg:hhhh') == 'aaaa::'

# Generated at 2022-06-22 21:42:01.402737
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    print("Unit test score:\n")
    print("to_ipv6_subnet('fe80::a00:27ff:fe98:12a0')")
    assert to_ipv6_subnet('fe80::a00:27ff:fe98:12a0') == 'fe80::'
    print("OK\n")
    print("to_ipv6_subnet('fc00:0002:0000:0000:0000:0000:0000:0004')")
    assert to_ipv6_subnet('fc00:0002:0000:0000:0000:0000:0000:0004') == 'fc00:2::'
    print("OK\n")
    print("to_ipv6_subnet('fe80:0:0:0:200:f8ff:fe21:67cf')")
    assert to_

# Generated at 2022-06-22 21:42:11.216532
# Unit test for function to_ipv6_network

# Generated at 2022-06-22 21:42:14.028677
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.0.0') == '24'
    assert to_netmask('255.255.255.0') == '16'


# Generated at 2022-06-22 21:42:22.419364
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(1) == '128.0.0.0'
    assert to_netmask(2) == '192.0.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(9) == '255.128.0.0'
    assert to_netmask(31) == '255.255.255.254'
    assert to_netmask(32) == '255.255.255.255'


# Generated at 2022-06-22 21:42:27.814432
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    try:
        to_masklen('255.255.255.1')
        assert False
    except ValueError:
        assert True
    try:
        to_masklen('255.255.255.256')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-22 21:42:38.537964
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert "2015::" == to_ipv6_subnet("2015:4866:1f23:beef:a:b:c:d")
    assert "2015::" == to_ipv6_subnet("2015:4866:1f23:beef::1a2b:3c4d")
    assert "2015::" == to_ipv6_subnet("2015:4866:1f23:beef:a:b:c:d/64")
    assert "2015::" == to_ipv6_subnet("2015:4866:1f23:beef::1a2b:3c4d/64")

    assert "FE80::" == to_ipv6_subnet("FE80::1a2b:3c4d")
    assert "FE80::" == to_ipv

# Generated at 2022-06-22 21:42:45.217856
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('54:52:00:79:10:9b')
    assert is_mac('54:52:00:79:10:9B')
    assert is_mac('54-52-00-79-10-9B')
    assert not is_mac('Invalid-MAC')
    assert not is_mac('Invalid-MAC-Address')

# Generated at 2022-06-22 21:42:53.671960
# Unit test for function is_mac
def test_is_mac():
    mac_address_1 = u'00-11-22-33-44-55'
    assert is_mac(mac_address_1) is True
    mac_address_2 = u'aa-bb-cc-dd-ee-ff'
    assert is_mac(mac_address_2) is True
    mac_address_3 = u'00-11-22-33-44-5g'
    assert is_mac(mac_address_3) is False


# Generated at 2022-06-22 21:42:54.574982
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '111111111111111111111111100000000'


# Generated at 2022-06-22 21:42:58.587614
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '255.255.255.255') == '192.168.1.1/32'

# Generated at 2022-06-22 21:43:03.723331
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32) is True
    assert is_masklen(16) is True
    assert is_masklen(0) is True
    assert is_masklen(33) is False
    assert is_masklen(-1) is False



# Generated at 2022-06-22 21:43:13.352412
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.1', '255.255.255.0', True) == '10.0.0.0 255.255.255.0'
    assert to_subnet('10.0.0.1', '255.255.0.0', True) == '10.0.0.0 255.255.0.0'
    assert to_subnet('10.0.0.1', '255.0.0.0', True) == '10.0.0.0 255.0.0.0'
    assert to_subnet('10.0.0.1', '0.0.0.0', True) == '0.0.0.0 0.0.0.0'

# Generated at 2022-06-22 21:43:21.477439
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert is_mac('00-11-22-33-44-55')
    assert is_mac('00:11:22:33:44:55:66') == False
    assert is_mac('00:11:22:33:44:5g') == False
    assert is_mac('00:11:22:33:44') == False
    assert is_mac('00:11:22:33:44:55:66:77:88') == False

# Generated at 2022-06-22 21:43:23.463915
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'



# Generated at 2022-06-22 21:43:31.513969
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)

    assert not is_masklen('32')
    assert not is_masklen(33)
    assert not is_masklen(-32)
    assert not is_masklen(0.5)
    assert not is_masklen('0x8')
    assert not is_masklen('0b100')
    assert not is_masklen('')
    assert not is_masklen([])
    assert not is_masklen({})
    assert not is_masklen(None)



# Generated at 2022-06-22 21:43:39.241017
# Unit test for function to_netmask
def test_to_netmask():
    assert '0.0.0.0' == to_netmask(0)
    assert '0.0.0.255' == to_netmask(8)
    assert '0.0.255.255' == to_netmask(16)
    assert '0.255.255.255' == to_netmask(24)
    assert '255.255.255.255' == to_netmask(32)
    try:
        to_netmask(-1)
    except ValueError:
        pass
    else:
        assert False
    try:
        to_netmask(33)
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-22 21:43:43.779137
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    addr = "2001:db8:a0b:12f0::1"
    assert to_ipv6_network(addr) == "2001:db8:a0b:12f0::"

# Generated at 2022-06-22 21:43:53.777631
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00-00-5E-00-53-00')
    assert is_mac('00:00:5E:00:53:00')
    assert not is_mac('00 00 5E 00 53 00')
    assert not is_mac('00 00:5E 00:53 00')
    assert not is_mac('00-00-5E-00-53')
    assert not is_mac('00-00-5E-00-53-00-00')
    assert not is_mac('00-00-5E-00-53-GG')
    assert not is_mac('00-00-5E-00-53-GG-GG')
    assert not is_mac('00-00-5E-00-53-GG-GG-GG')

# Generated at 2022-06-22 21:43:59.127460
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask(255) == True
    assert is_netmask(255.0) == True
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255') == False
    assert is_netmask('255.255.255.0.1') == False
    assert is_netmask('255.255.255.1/24') == False


# Generated at 2022-06-22 21:44:00.303961
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111110000000'

# Generated at 2022-06-22 21:44:10.273767
# Unit test for function is_netmask
def test_is_netmask():
    # Positive tests
    assert is_netmask('255.255.255.0'), '255.255.255.0 was not recognized as a netmask'
    assert is_netmask('255.255.0.0'), '255.255.0.0 was not recognized as a netmask'
    assert is_netmask('255.255.128.0'), '255.255.128.0 was not recognized as a netmask'
    assert is_netmask('255.128.0.0'), '255.128.0.0 was not recognized as a netmask'
    assert is_netmask('255.0.0.0'), '255.0.0.0 was not recognized as a netmask'
    assert is_netmask('255.255.255.128'), '255.255.255.128 was not recognized as a netmask'

# Generated at 2022-06-22 21:44:14.895179
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(1) == True
    assert is_masklen(32) == True
    assert is_masklen(64) == False
    assert is_masklen(0) == True
    assert is_masklen(33) == False
    assert is_masklen("717") == False


# Generated at 2022-06-22 21:44:21.868067
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ip1 = '2001:DB8:AB:CD:AB:CD:AB:CD'
    ip2 = '2001:0DB8:0AB:0CD:AB:CD:AB:CD'
    ip3 = '2001:AB8:AB:CD:AB:CD:AB:CD'
    ip4 = '2001:AB8:AB:CD:AB:CD:AB:CD:AB:CD'
    ip5 = '2001::AB8:AB:CD:AB:CD:AB:CD:AB:CD'
    ip6 = '::2001:AB8:AB:CD:AB:CD:AB:CD'
    ip7 = '2001:AB8:AB:CD:AB:CD:AB:CD::'

# Generated at 2022-06-22 21:44:34.497047
# Unit test for function to_netmask
def test_to_netmask():
    assert is_netmask('255.255.255.0')
    assert is_masklen('24')
    assert to_netmask('24') == '255.255.255.0'
    assert to_masklen('255.255.255.0') == 24
    assert to_subnet('192.0.2.1', '24') == '192.0.2.0/24'
    assert to_subnet('192.0.2.1', '255.255.255.0') == '192.0.2.0/24'
    assert to_subnet('192.0.2.1', '24', dotted_notation=True) == '192.0.2.0 255.255.255.0'

# Generated at 2022-06-22 21:44:47.197306
# Unit test for function is_mac
def test_is_mac():
    test_cases = [
        ['aa:bb:cc:dd:ee:ff', True],
        ['aa-bb-cc-dd-ee-ff', True],
        ['aa:bb:cc:dd:ee-ff', True],
        ['aa:bb:cc:dd:ee:ff:', False],
        ['aa:bb:cc:dd:ee', False],
        ['aa:bb:cc:dd:ee:fg', False]
    ]

    print ('*' * 80)
    print ('Start testing function is_mac')
    for test_case in test_cases:
        if is_mac(test_case[0]) != test_case[1]:
            print ('Failed testing on input: %s' % test_case[0])
            return
    print ('Test pass')

# Generated at 2022-06-22 21:44:50.233419
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    ipv6_prefix = '2001:db8:342:9400:7928:f12d:c960:3e3b'
    network_addr = '2001:db8:342:9400::'

    assert to_ipv6_network(ipv6_prefix) == network_addr

# Generated at 2022-06-22 21:45:00.412454
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Test cases from RFC 2374, Appendix A
    assert(to_ipv6_subnet('2001:db8:0:0:1:0:0:1') == '2001:db8::')
    assert(to_ipv6_subnet('2001:db8:0:1:1:0:0:1') == '2001:db8:0:1::')
    assert(to_ipv6_subnet('2001:db8:0:1:1:0:0:1') == '2001:db8:0:1::')
    assert(to_ipv6_subnet('2001:db8::1:0:0:1') == '2001:db8:0:0::')
    assert(to_ipv6_subnet('2001:0:0:1::1') == '2001::')

# Generated at 2022-06-22 21:45:06.881774
# Unit test for function to_masklen
def test_to_masklen():
    assert(to_masklen('255.255.255.0') == 24)
    assert(to_masklen('255.255.0.0') == 16)
    assert(to_masklen('255.0.0.0') == 8)
    assert(to_masklen('128.0.0.0') == 1)
    assert(to_masklen('0.0.0.0') == 0)



# Generated at 2022-06-22 21:45:12.055805
# Unit test for function to_bits
def test_to_bits():
    parts = [192, 168, '1', '100']
    bits = to_bits('.'.join(map(lambda x: str(x), parts)))
    eq_(bits, '1100000000000000000000101011110100', bits)

# Generated at 2022-06-22 21:45:20.154894
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.255.1')
    assert not is_netmask('255.255.255.255.1')
    assert not is_netmask('255.255.255.0.0.0')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.0.0.0.0')
    assert not is_netmask('255.255.255.0.0.0.0.0')

# Generated at 2022-06-22 21:45:24.496409
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('9') == True
    assert is_masklen('33') == False
    assert is_masklen('-8') == False
    assert is_masklen('a') == False


# Generated at 2022-06-22 21:45:36.076392
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.255.255.128') == '25'
    assert to_netmask('255.255.128.0') == '17'
    assert to_netmask('255.240.0.0') == '12'
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.128.0.0') == '9'
    assert to_netmask('255.0.0.0') == '8'
    assert to_netmask('254.0.0.0') == '7'
    assert to_netmask('252.0.0.0') == '6'
    assert to_netmask('248.0.0.0') == '5'

# Generated at 2022-06-22 21:45:43.026250
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.0.0.0')
    assert is_netmask('128.0.0.0')
    assert not is_netmask('0.0.0.0')
    assert not is_netmask('255.255.0.0')
    assert not is_netmask('127.0.0.1')
    assert not is_netmask('255.128.128.128')



# Generated at 2022-06-22 21:45:54.139516
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('11:22:33:44:55:66') is True
    assert is_mac('11-22-33-44-55-66') is True
    assert is_mac('a1:b2:c3:d4:e5:f6') is True
    assert is_mac('a1-b2-c3-d4-e5-f6') is True
    assert is_mac('AA:BB:CC:DD:EE:FF') is True
    assert is_mac('AA-BB-CC-DD-EE-FF') is True
    assert is_mac('a1-b2-c3-d4-e5-f6') is True

    assert is_mac('11:22:33:44:55:66:77') is False

# Generated at 2022-06-22 21:46:02.007837
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:00:00:00:00') == True
    assert is_mac('00-00-00-00-00-00') == True
    assert is_mac('00:00:00:00:00:0z') == False
    assert is_mac('00:00:00:00:00:00:00') == False
    assert is_mac('00:00:00:00:00:00:00:00:00') == False
    assert is_mac('zzz') == False
    assert is_mac('zz:zz:zz:zz:zz:zz:zz:zz:zz') == False

# Generated at 2022-06-22 21:46:05.498721
# Unit test for function is_masklen
def test_is_masklen():
    assert(is_masklen(0))
    assert(is_masklen(32))
    assert(is_masklen(24))
    assert(not is_masklen(1))
    assert(not is_masklen(33))
    assert(not is_masklen(-1))


# Generated at 2022-06-22 21:46:14.852480
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('172.16.10.1', 24) == '172.16.10.0/24'
    assert to_subnet('172.16.10.1', to_netmask(24)) == '172.16.10.0/24'
    assert to_subnet('1:2:3:4:5:6:7:8', 120) == '1:2:3:4::/120'
    assert to_subnet('1:2:3:4:5:6:7:8', to_netmask(120)) == '1:2:3:4::/120'

# Generated at 2022-06-22 21:46:23.268804
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ipv6_input = '::1'
    ipv6_exp_output = '::'
    ipv6_act_output = to_ipv6_subnet(ipv6_input)
    assert ipv6_exp_output == ipv6_act_output, "Expected %s, but got %s" % (ipv6_exp_output, ipv6_act_output)

    ipv6_input = '2001:0db8:85a3::8a2e:0370:7334'
    ipv6_exp_output = '2001:db8:85a3::'
    ipv6_act_output = to_ipv6_subnet(ipv6_input)

# Generated at 2022-06-22 21:46:31.782453
# Unit test for function to_subnet
def test_to_subnet():

    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('2001:db8::1', '48') == '2001:db8::/48'

# Generated at 2022-06-22 21:46:39.651423
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.0', '255.0.0.0') == '10.0.0.0/8'
    assert to_subnet('10.0.0.0', '255.255.255.0') == '10.0.0.0/24'
    assert to_subnet('10.0.0.0', '8') == '10.0.0.0/8'
    assert to_subnet('10.0.0.0', '24') == '10.0.0.0/24'
    assert to_subnet('10.0.0.0', '255.0.0.0', dotted_notation=True) == '10.0.0.0 255.0.0.0'

# Generated at 2022-06-22 21:46:50.977068
# Unit test for function is_mac
def test_is_mac():
    """ Unit test for function is_mac """
    fake_mac1 = '01-23-45'
    fake_mac2 = 'ab-cd-ef-gh-ij-kl'
    fake_mac3 = '01-23-45-67-89-az'
    fake_mac4 = '01:23:45:67:89:az'
    mac1 = '01-23-45-67-89-ab'
    mac2 = '01:23:45:67:89:ab'
    assert is_mac(mac1)
    assert is_mac(mac2)
    assert not is_mac(fake_mac1)
    assert not is_mac(fake_mac2)
    assert not is_mac(fake_mac3)
    assert not is_mac(fake_mac4)

# Generated at 2022-06-22 21:46:56.272464
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fdee:b8e1:f7:a00::66') == 'fdee:b8e1:f7::'
    assert to_ipv6_network('fdee:b8e1::') == 'fdee:b8e1::'
    assert to_ipv6_network('fdee:b8e1:f7::') == 'fdee:b8e1:f7::'
    assert to_ipv6_network('fe80::76a9:8a1a:7f46:b049') == 'fe80::'

# Generated at 2022-06-22 21:46:58.825687
# Unit test for function to_masklen
def test_to_masklen():
    masklen = to_masklen('255.255.255.0')
    assert masklen == 24


# Generated at 2022-06-22 21:47:07.163721
# Unit test for function is_mac
def test_is_mac():
    assert True == is_mac('00:0c:29:8d:8b:e9')
    assert True == is_mac('00-0C-29-8D-8B-E9')
    assert True == is_mac('000c298d8be9')

    assert False == is_mac('00:0c:29:8d:8b:e9:ab')
    assert False == is_mac('0:0c:29:8d:8b:e9')
    assert False == is_mac('00:0c:29:8d:8b')
    assert False == is_mac('00_0c_29_8d_8b_e9')
    assert False == is_mac('00=0c=29=8d=8b=e9')

# Generated at 2022-06-22 21:47:16.210673
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("00-11-22-33-44-55")
    assert is_mac("00:11:22:33:44:55")
    assert is_mac("00:11:22:33:44:55")
    assert is_mac("00:11:22:33:44:5f")
    assert is_mac("a0:b1:c2:d3:e4:f5")
    assert not is_mac("00-11-22-33-44-55-66")
    assert not is_mac("00-11-22-33-44-gg")
    assert not is_mac("00-11-22-33-44-55--55")
    assert not is_mac("0-111-22-33-44-55")

# Generated at 2022-06-22 21:47:19.113750
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111110000000'


# Unit tests for function to_netmask

# Generated at 2022-06-22 21:47:27.449908
# Unit test for function to_subnet
def test_to_subnet():
    # Test Masked IP address
    assert to_subnet('10.0.0.55', '255.255.255.0') == '10.0.0.0/24'
    # Test Mask Length IP address
    assert to_subnet('10.0.0.55', 24) == '10.0.0.0/24'
    # Test Masked IP address with dot notation
    assert to_subnet('10.0.0.55', '255.255.255.0', True) == '10.0.0.0 255.255.255.0'
    # Test Mask Length IP address with dot notation
    assert to_subnet('10.0.0.55', 24, True) == '10.0.0.0 255.255.255.0'



# Generated at 2022-06-22 21:47:32.646381
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('98:fe:94:6f:1a:ad')
    assert not is_mac('361:fe:94:6f:1a:ad')
    assert not is_mac('98:fe:94:6f:1a:ad1')
    assert not is_mac('98:fe:94:6f:1a:ad:1')


# Generated at 2022-06-22 21:47:42.748357
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::45e:c22a:a3ff:fe74:15b3') == 'fe80::'
    assert to_ipv6_subnet('fe80::') == 'fe80::'
    assert to_ipv6_subnet('fe80::45e:c22a:a3ff:fe74:15b3') == 'fe80::'
    assert to_ipv6_subnet('fe80:0000:0000:0000:0000:0000:0000:0000') == 'fe80::'
    assert to_ipv6_subnet('fe80::45e:c22a:a3ff::fe74:15b3') == 'fe80::45e:c22a:a3ff::'

# Generated at 2022-06-22 21:47:47.632489
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '0.0.0.255'
    assert to_netmask(24) == '255.255.255.0'



# Generated at 2022-06-22 21:47:50.351139
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:23:45:67:89.ab')
    assert is_mac('01:23:45:67:89:ab:cd:ef')


# Generated at 2022-06-22 21:47:59.990588
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0:0:1::1') == '2001:0:0:1::'
    assert to_ipv6_network('2001:0:0:1:0:0:0:1') == '2001:0:0:1::'
    assert to_ipv6_network('2001:0:0:1:0:1:0:1') == '2001:0:0:1::'
    assert to_ipv6_network('2001:0:0:1:0:1:ab:1') == '2001:0:0:1::'
    assert to_ipv6_network('2001:0:1::1') == '2001:0:1::'
    assert to_ipv6_network('2001:ab::1') == '2001:ab::'
   

# Generated at 2022-06-22 21:48:05.620863
# Unit test for function to_bits
def test_to_bits():
    bits = to_bits('255.255.255.0')
    assert bits == '11111111111111111111111100000000'

    bits = to_bits('255.255.255.128')
    assert bits == '11111111111111111111111110000000'


# Generated at 2022-06-22 21:48:08.550641
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(24) == True
    assert is_masklen(32) == True
    assert is_masklen(0) == True
    assert is_masklen(33) == False
    assert is_masklen(-1) == False
    assert is_masklen(1.5) == False
    assert is_masklen('24') == False


# Generated at 2022-06-22 21:48:12.787583
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0") is True
    assert is_netmask("0.0.0.0") is True
    assert is_netmask("255.0.0.0") is True
    assert is_netmask("255.255.0.0") is True
    assert is_netmask("255.255.255.255") is True

    assert is_netmask("255.0.0") is False
    assert is_netmask("255.0.0.0.0") is False
    assert is_netmask("") is False
    assert is_netmask("0x010.0.0.0") is False



# Generated at 2022-06-22 21:48:19.234592
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('128.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.0.0.1')
    assert not is_netmask('255.0.0.255')
    assert not is_netmask('255.0.0.256')
    assert not is_netmask('256.0.0.0')
    assert not is_netmask('255.0.0')
    assert not is_netmask('127')
    assert not is_netmask('127.0.0')

# Generated at 2022-06-22 21:48:29.906888
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # Verify the first three groupings comprise the network address
    assert to_ipv6_network('fe80::1') == 'fe80::'
    assert to_ipv6_network('fe80::1:2') == 'fe80::'
    assert to_ipv6_network('fe80::1:2:3') == 'fe80::'
    assert to_ipv6_network('2001:db8::1:2:3:4') == '2001:db8:0:0:0:'
    assert to_ipv6_network('fe80::1:2:3:4:5:6:7') == 'fe80::'

# Generated at 2022-06-22 21:48:41.637823
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert is_mac('00-11-22-33-44-55')
    assert is_mac('0011.2233.4455')
    assert is_mac('00:11:22:33:44:55:66') is False
    assert is_mac('00-11-22-33-44-55-66') is False
    assert is_mac('0011.2233.4455.66') is False
    assert is_mac('') is False
    assert is_mac('00') is False
    assert is_mac('00:aa') is False
    assert is_mac('00:aa:aa') is False
    assert is_mac('00:aa:aa:aa') is False

# Generated at 2022-06-22 21:48:50.024542
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert not is_mac('aa:bb:cc:dd:ee')
    assert not is_mac('aa:bb:cc:dd:ee:fg')
    assert not is_mac('aa-bb-cc-dd-ee-ff')
    assert not is_mac('aa:bb:cc:dd:ee-fg')
    assert not is_mac(' aa:bb:cc:dd:ee:ff')
    assert not is_mac('aa:bb:cc:dd:ee:ff ')
    assert not is_mac('aa:bb:cc:dd:ee:ff ')
    assert not is_mac(' aa:bb:cc:dd:ee:ff ')


# Generated at 2022-06-22 21:48:58.458023
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    ipv6_addr = '2a02:2788:0:209::f9e9:be0c:4b4d'
    assert to_ipv6_network(ipv6_addr) == '2a02:2788:0:209::'
    ipv6_addr = '2a02:2788::209::f9e9:be0c:4b4d'
    assert to_ipv6_network(ipv6_addr) == '2a02:2788::'
    ipv6_addr = '2a02:2788:::f9e9:be0c:4b4d'
    assert to_ipv6_network(ipv6_addr) == '2a02:2788::'

# Generated at 2022-06-22 21:49:01.695119
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0)
    assert is_masklen(32)
    assert not is_masklen(-1)
    assert not is_masklen('junk')



# Generated at 2022-06-22 21:49:10.227635
# Unit test for function to_masklen
def test_to_masklen():

    assert(to_masklen('0.0.0.0') == 0)
    assert(to_masklen('128.0.0.0') == 1)
    assert(to_masklen('192.0.0.0') == 2)
    assert(to_masklen('224.0.0.0') == 3)
    assert(to_masklen('240.0.0.0') == 4)
    assert(to_masklen('248.0.0.0') == 5)
    assert(to_masklen('252.0.0.0') == 6)
    assert(to_masklen('254.0.0.0') == 7)
    assert(to_masklen('255.0.0.0') == 8)
    assert(to_masklen('255.128.0.0') == 9)

# Generated at 2022-06-22 21:49:21.155014
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('1024.255.255.255')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert not is_netmask('255.255.255.256')



# Generated at 2022-06-22 21:49:25.934186
# Unit test for function to_bits
def test_to_bits():
    # given
    val = '255.255.255.0'
    expected = '11111111111111111111111100000000'

    # when
    bits = to_bits(val)

    # then
    assert bits == expected



# Generated at 2022-06-22 21:49:36.581061
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(27) == '255.255.255.224'
    assert to_netmask(30) == '255.255.255.252'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask('24') == '255.255.255.0'

# Generated at 2022-06-22 21:49:40.298463
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert is_masklen('24')
    assert is_masklen('0')
    assert not is_masklen('33')
    assert not is_masklen('-1')



# Generated at 2022-06-22 21:49:42.409949
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')



# Generated at 2022-06-22 21:49:47.586713
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00-00-00-00-00-00')
    assert not is_mac('00-00-00-00-00-0G')
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert not is_mac('aa:bb:cc:dd:ee:0g')

# Generated at 2022-06-22 21:49:57.754250
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('192.0.0.0') == 2
    assert to_masklen('224.0.0.0') == 3
    assert to_masklen('240.0.0.0') == 4
    assert to_masklen('248.0.0.0') == 5
    assert to_masklen('252.0.0.0') == 6
    assert to_masklen('254.0.0.0') == 7
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.192.0.0') == 10
   

# Generated at 2022-06-22 21:50:04.200148
# Unit test for function is_netmask
def test_is_netmask():
    assert (is_netmask('fdff:ffff:ffff:ffff::'))
    assert (is_netmask('fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'))
    assert (not is_netmask('fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:1'))
    assert (not is_netmask('fdff'))
    assert (not is_netmask('fdff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'))
    assert (not is_netmask('fdaa:ffff:ffff:ffff:ffff:ffff:ffff:ffff'))
    assert (not is_netmask(':ffff:ffff:ffff:ffff:ffff:ffff:ffff'))


# Generated at 2022-06-22 21:50:10.653730
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("2001:db8:0:1:1:1:1:1") == "2001:db8:0:1::"
    assert to_ipv6_network("2001:db8:0:0:1:1:1:1") == "2001:db8::"
    assert to_ipv6_network("2001:db8::1:1:1:1") == "2001:db8::"

# Generated at 2022-06-22 21:50:14.594922
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    test_subnet = 'fe80::1/64'
    assert to_ipv6_subnet(test_subnet) == 'fe80::/64', "Unit test failed for to_ipv6_subnet"


# Generated at 2022-06-22 21:50:25.767408
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:1234::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:1234:1::1') == '2001:db8:1234::'
    assert to_ipv6_subnet('2001:db8:1234:1234::1') == '2001:db8:1234:1234::'
    assert to_ipv6_subnet('2001:db8:1234:1234:1234::1') == '2001:db8:1234:1234::'

# Generated at 2022-06-22 21:50:35.182807
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:0:0:1:0:0:1') == '2001:db8:0:0:1::'
    assert to_ipv6_network('2001:db8:1:0:1:0:0:1') == '2001:db8:1::'
    assert to_ipv6_network('2001:db8:2:0:1:0:0:1') == '2001:db8:2::'
    assert to_ipv6_network('2001:db8:3:0:1:0:0:1') == '2001:db8:3::'
    assert to_ipv6_network('2001:db8:0:0:0:0:0:1') == '2001:db8::'
    assert to_ipv6

# Generated at 2022-06-22 21:50:46.055267
# Unit test for function to_masklen
def test_to_masklen():
    # cidr notation
    assert 24 == to_masklen('255.255.255.0')
    assert 24 == to_masklen('0.0.0.255')
    assert 0 == to_masklen('0.0.0.0')
    assert 32 == to_masklen('255.255.255.255')

    # netmask notation
    assert 24 == to_masklen('24')
    assert 24 == to_masklen('24')
    assert 0 == to_masklen('0')
    assert 32 == to_masklen('32')

    # tests of invalid values
    try:
        to_masklen('255.255.255.255.255')
    except ValueError:
        pass
    else:
        assert False, 'to_masklen() did not detect invalid netmask'


# Generated at 2022-06-22 21:50:49.652615
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:1:2:3:4:5:6') == '2001:db8:1:2:3:4::'

# Generated at 2022-06-22 21:50:54.152386
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:1::1') == '2001:db8:0:1::'
    assert to_ipv6_network('2001:db8:0:1:1::1') == '2001:db8:0:1:1::'
