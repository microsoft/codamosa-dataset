

# Generated at 2022-06-20 15:54:30.640332
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(27) == '255.255.255.224'
    assert to_netmask(28) == '255.255.255.240'
    assert to_netmask(26) == '255.255.255.192'

# Generated at 2022-06-20 15:54:34.699613
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('8') == '255.0.0.0'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('16') == '255.255.0.0'


# Generated at 2022-06-20 15:54:45.464391
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.26.4.4', 24) == '10.26.4.0/24'
    assert to_subnet('10.26.4.4', '255.255.255.0') == '10.26.4.0/24'
    assert to_subnet('1.1.1.1', 32) == '1.1.1.1/32'
    assert to_subnet('1.1.1.1', '255.255.255.255') == '1.1.1.1/32'
    assert to_subnet('1.1.1.1', '0.0.0.0', dotted_notation=True) == '0.0.0.0 0.0.0.0'

# Generated at 2022-06-20 15:54:53.599429
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0) is True
    assert is_masklen(1) is True
    assert is_masklen(2) is True
    assert is_masklen(3) is True
    assert is_masklen(4) is True
    assert is_masklen(5) is True
    assert is_masklen(32) is True
    assert is_masklen(33) is False
    assert is_masklen(256) is False
    assert is_masklen(False) is False
    assert is_masklen(None) is False
    assert is_masklen(0.5) is False
    assert is_masklen([]) is False


# Generated at 2022-06-20 15:55:01.297404
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    subnet = to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334')
    assert(subnet == '2001:db8:85a3::')
    subnet = to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334')
    assert(subnet == '2001::')
    subnet = to_ipv6_subnet('2001:0:0:0:0:0:0:1')
    assert(subnet == '2001::')
    subnet = to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334')

# Generated at 2022-06-20 15:55:05.526624
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('192.168.0.1') == False
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.0.0') == True
    assert is_netmask('255.0.0.0') == True
    assert is_netmask('255.255.255.255.255') == False
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255.254') == True
    assert is_netmask('') == False


# Generated at 2022-06-20 15:55:09.134787
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('8')
    assert is_masklen('24')
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('-1')


# Generated at 2022-06-20 15:55:20.274894
# Unit test for function to_subnet
def test_to_subnet():
    test_pairs = (
        (('10.0.0.0', '255.255.255.0'), '0.0.0.0/24'),
        (('192.168.0.1', '255.255.255.0'), '192.168.0.0/24'),
        (('172.16.1.1', '255.240.0.0'), '172.16.0.0/12'),
        (('10.0.0.0', '24'), '0.0.0.0/24'),
        (('192.168.0.1', '24'), '192.168.0.0/24'),
        (('172.16.1.1', '12'), '172.16.0.0/12'),
    )
    for pair in test_pairs:
        assert to_

# Generated at 2022-06-20 15:55:28.138798
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.1', '255.255.0.0') == '10.0.0.0/16'
    assert to_subnet('10.0.0.1', '16') == '10.0.0.0/16'
    assert to_subnet('10.0.0.1', '255.255.0.0', True) == '10.0.0.0 255.255.0.0'

# Generated at 2022-06-20 15:55:33.714138
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.0', '255.255.255.0') == '10.0.0.0/24'
    assert to_subnet('10.0.0.0', '24') == '10.0.0.0/24'
    assert to_subnet('10.0.0.0', 24) == '10.0.0.0/24'
    assert to_subnet('10.0.0.0', 24, True) == '10.0.0.0 255.255.255.0'


# Generated at 2022-06-20 15:55:46.138141
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('::1') == '::1:'
    assert to_ipv6_subnet('2001::db8') == '2001::db8:'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:a:b:c:d:e:f') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:a:b:c:d:e:f%eth0') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:2:3:4:5') == '2001:db8:0:1::'

# Generated at 2022-06-20 15:55:52.988678
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('11:22:33:44:55:66')
    assert is_mac('11-22-33-44-55-66')
    assert not is_mac('aa:bb:cc:dd:ee:ff:11')
    assert not is_mac('11:22:33:44:55')
    assert not is_mac('11-22-33-44-55')
    assert not is_mac('11:22:33:44:55:66:77')

# Generated at 2022-06-20 15:56:03.598650
# Unit test for function is_mac
def test_is_mac():
    assert not is_mac('H1:E1:0A:C0:FF:EE')
    assert not is_mac('c0:ee:ff:c0:ee:ff')
    assert not is_mac('pal:ex:pal:ex:pal:ex')

    assert is_mac('c0:ee:ff:c0:ee:ff:c0:ee')
    assert is_mac('c0-ee-ff-c0-ee-ff-c0-ee')
    assert is_mac('c0:ee:ff:c0:ee:ff:c0:ee')
    assert is_mac('c0-ee-ff-c0-ee-ff-c0-ee')
    assert is_mac('CC:EE:FF:CC:EE:FF:CC:EE')

# Generated at 2022-06-20 15:56:11.000826
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.255.128') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('192.168.1.1') is False
    assert is_netmask('255.255.255.256') is False
    assert is_netmask('300.255.255.255') is False
    assert is_netmask('255.255.255.0.0') is False
    assert is_netmask('255.255.255') is False



# Generated at 2022-06-20 15:56:17.462842
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(10)
    assert is_masklen(20)
    assert is_masklen(24)
    assert is_masklen(30)
    assert is_masklen(32)
    assert not is_masklen(31)
    assert not is_masklen(33)
    assert not is_masklen(9)
    assert not is_masklen(0)
    assert not is_masklen(255)



# Generated at 2022-06-20 15:56:19.266441
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'



# Generated at 2022-06-20 15:56:25.416711
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:abcd:0001:0000:0000:0000:0001') == '2001:db8:abcd:0001::'
    assert to_ipv6_subnet('2001:db8:abcd:0001:0000:0000:0000:0000') == '2001:db8:abcd:0001::'
    assert to_ipv6_subnet('2001:db8:abcd:0001:0000:0000:0000::') == '2001:db8:abcd:0001::'
    assert to_ipv6_subnet('2001:db8:abcd:0001:0000:0000::') == '2001:db8:abcd:0001::'

# Generated at 2022-06-20 15:56:33.586639
# Unit test for function to_subnet
def test_to_subnet():
    from ansible.module_utils.net_tools import to_subnet
    assert to_subnet('10.66.100.1', 24) == '10.66.100.0/24'
    assert to_subnet('10.66.100.1', '255.255.255.0') == '10.66.100.0/24'
    assert to_subnet('10.66.100.1', '24') == '10.66.100.0/24'
    assert to_subnet('10.66.100.1', '255.255.254.0') == '10.66.100.0/23'
    assert to_subnet('10.66.100.1', '255.255.255.128') == '10.66.100.0/25'

# Generated at 2022-06-20 15:56:35.564738
# Unit test for function to_masklen
def test_to_masklen():
    for i in range(0, 33):
        assert to_masklen(to_netmask(i)) == i


# Generated at 2022-06-20 15:56:37.258504
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'

# Generated at 2022-06-20 15:56:43.257136
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:de:ad:be:ef')
    assert is_mac('00-00-DE-AD-BE-EF')
    assert is_mac('00:00:de:AD:BE:ef')
    assert not is_mac('00-00-DE-AD-BE-E')
    assert not is_mac('00:00:de:AD:BE:EF:00')

# Generated at 2022-06-20 15:56:53.940143
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True, 'failed to identify 255.255.255.0 as a valid netmask'
    assert is_netmask('255.255.255.255') is True, 'failed to identify 255.255.255.255 as a valid netmask'
    assert is_netmask('255.255.0.0') is True, 'failed to identify 255.255.0.0 as a valid netmask'
    assert is_netmask('255.255.0.255') is False, 'incorrectly identified 255.255.0.255 as a valid netmask'
    assert is_netmask('255.255.0.aaa') is False, 'incorrectly identified 255.255.0.aaa as a valid netmask'



# Generated at 2022-06-20 15:57:05.288551
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa:bb-cc-dd-ee-ff')
    assert not is_mac('aa:bb:cc:dd:ee')
    assert not is_mac('aa:bb:cc:dd:xx:yy')
    assert not is_mac('aa:bb:cc:gg:ee:ff')


# Fetches the value of a given variable key, a list of search paths, and a
# variable separator. The variable separator is used as a delimiter between
# the search path and the variable key.  For example, ansible_facts['ansible_default_ipv4']['interface']
# can be fetched with:
#
# key = 'default_ipv4.interface'
# paths = ['ansible_facts', '

# Generated at 2022-06-20 15:57:11.570532
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    print("TEST: function to_ipv6_network")
    addr = "2001::1"
    result = to_ipv6_network(addr)
    assert result == "2001::", "ERROR: " + result + " != 2001::"
    print("Result: " + result)
    print("SUCCESS: function to_ipv6_network\n")

test_to_ipv6_network()

# Generated at 2022-06-20 15:57:17.816063
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask('255.255.255.255') == '255.255.255.255'
    assert to_netmask('-1') == '0.0.0.0'
    assert to_netmask('33') == '0.0.0.0'


# Generated at 2022-06-20 15:57:25.514587
# Unit test for function is_mac
def test_is_mac():
    valid_mac_addrs = [
        "A0:B1:C2:D3:E4:F5",
        "0a-b1-c2-d3-e4-f5",
        "A0:B1:C2:D3:E4:F5",
        "0a-b1-c2-d3-e4-f5",
        "a0:b1:c2:d3:e4:f5"
    ]
    assert all([is_mac(val) for val in valid_mac_addrs])

# Generated at 2022-06-20 15:57:33.398782
# Unit test for function to_masklen
def test_to_masklen():
    """
    Unit testing for module function to_masklen
    """
    assert to_masklen("255.255.255.255") == 32
    assert to_masklen("255.255.255.254") == 31
    assert to_masklen("255.255.255.252") == 30
    assert to_masklen("255.255.255.248") == 29
    assert to_masklen("255.255.255.240") == 28
    assert to_masklen("255.255.255.224") == 27
    assert to_masklen("255.255.255.192") == 26
    assert to_masklen("255.255.255.128") == 25
    assert to_masklen("255.255.255.0") == 24
    assert to_masklen("255.255.254.0") == 23

# Generated at 2022-06-20 15:57:37.870232
# Unit test for function to_netmask
def test_to_netmask():
    assert '255.255.255.0' == to_netmask(24)
    assert '255.255.254.0' == to_netmask(23)
    assert '255.255.255.255' == to_netmask(32)



# Generated at 2022-06-20 15:57:47.898215
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('1620:1::1') == '1620:1::'
    assert to_ipv6_network('1620:1:2:3::1') == '1620:1:2:3::'
    assert to_ipv6_network('1620:1:2:3:4:5:6::1') == '1620:1:2:3:4:5:6:0::'
    assert to_ipv6_network('1620:1:2:3:4:5:6:7:8') == '1620:1:2:3:4:5:6:7:8::'

# Generated at 2022-06-20 15:57:58.513689
# Unit test for function is_mac
def test_is_mac():
    # Valid MACs
    assert is_mac('AA:BB:CC')
    assert is_mac('AA-BB-CC')
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa-bb-cc-dd-ee-ff')
    assert is_mac('aa-bb-cc-dd-ee-f1')
    assert is_mac('12-34-56-78-90-ab')

    # Invalid MACs
    assert not is_mac('00-11-aa-bb')
    assert not is_mac('aa-bb-cc-dd-ef')
    assert not is_mac('aa.bb.cc.dd.ee.ff')
    assert not is_mac('aa:bb:cc:dd:ee:fg')

# Generated at 2022-06-20 15:58:09.382835
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():

    subnet = to_ipv6_subnet('fd00:1:2:3::4:5')
    assert subnet == 'fd00:1:2:3::'

    subnet = to_ipv6_subnet('fd00:1:2:3:4:5:6:7')
    assert subnet == 'fd00:1:2:3::'

    subnet = to_ipv6_subnet('fd00::1')
    assert subnet == 'fd00::'

    subnet = to_ipv6_subnet('0000:ffff::1')
    assert subnet == '0000:ffff::'


# Generated at 2022-06-20 15:58:15.989968
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.224') == '11111111111111111111111111100000'
    assert to_bits('255.255.255.240') == '11111111111111111111111111110000'
    assert to_bits('255.255.255.248') == '11111111111111111111111111111000'
    assert to_bits('255.255.255.252') == '11111111111111111111111111111100'

# Generated at 2022-06-20 15:58:26.677963
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:50:56:A8:99:AA') is True
    assert is_mac('00:50:56:AB:99:AA') is True
    assert is_mac('00:50:57:AB:9A:AA') is True
    assert is_mac('00:50:57:AB:9A:AB') is True

    # Invalid MAC addresses
    assert is_mac('00:50:56:AB:99:Z') is False
    assert is_mac('00:50:56:AB:99') is False
    assert is_mac('00:50:56:AB:99:AAFA') is False
    assert is_mac('00:50:56:AB:99:AA:F') is False
    assert is_mac('00:50:56:AB:99:F-') is False

# Generated at 2022-06-20 15:58:27.748114
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == "255.255.255.0"

# Generated at 2022-06-20 15:58:34.774492
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'

    # Specifying the mask as a CIDR value should work as well
    assert to_subnet('2001:db8:1f70::999:dd:aaaa', '64') == '2001:db8:1f70::/64'

    # Raises for invalid values
    try:
        to_subnet('192.168.1.1', '255.255.0')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-20 15:58:38.767480
# Unit test for function to_masklen
def test_to_masklen():
    inputs = {
        'invalid': ['255.255.0.0', '255.255.0.0.0', '-1.0.0.0', '256.0.0.0', '0.0', '0.0.0', '1.1.1.1.1'],
        'valid': ['255.255.255.0', '255.255.255.252', '0.0.0.0', '255.255.255.255', '8.8.8.8']
    }
    outputs = {
        'invalid': [None, None, None, None, None, None, None],
        'valid': [24, 30, 0, 32, 32]
    }
    for idx, val in enumerate(inputs['valid']):
        assert outputs['valid'][idx]

# Generated at 2022-06-20 15:58:46.841277
# Unit test for function is_mac
def test_is_mac():
    valid_macs = [
        '00:00:5E:00:53:01',
        '00-00-5E-00-53-01',
        '0000.5e00.5301',
        '0000.5E00.5301',
    ]

# Generated at 2022-06-20 15:58:54.301273
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.1.1', '255.255.0.0') == '10.0.0.0/16'
    assert to_subnet('10.0.1.1', '255.255.0.0', True) == '10.0.0.0 255.255.0.0'
    assert to_subnet('10.0.1.1', '24') == '10.0.1.0/24'
    assert to_subnet('10.0.1.1', 24, True) == '10.0.1.0 255.255.255.0'



# Generated at 2022-06-20 15:59:02.411800
# Unit test for function to_subnet
def test_to_subnet():
    """ Unit test for function to_subnet """

    assert to_subnet('192.168.0.0', '24') == '192.168.0.0/24'
    assert to_subnet('192.168.0.0', '255.255.255.0', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('192.168.0.0', '0.0.0.255') == '192.168.0.0/24'


# Generated at 2022-06-20 15:59:09.427495
# Unit test for function to_subnet
def test_to_subnet():
    assert(to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24')
    assert(to_subnet('192.168.1.1', '24') == '192.168.1.0/24')
    assert(to_subnet('192.168.1.0', '24') == '192.168.1.0/24')
    assert(to_subnet('192.168.1.1', '255.255.255.254') == '192.168.1.0/31')
    assert(to_subnet('192.168.1.1', 31) == '192.168.1.0/31')

# Generated at 2022-06-20 15:59:23.048671
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("01:23:45:67:89:ab")
    assert is_mac("01:23:45:67:89:AB")
    assert is_mac("01:23:45:67:89:aB")
    assert is_mac("01:23:45:67:89:Ab")
    assert is_mac("01:23:45:67:89:AB")
    assert is_mac("01:23:45:67:89:aB")
    assert is_mac("01:23:45:67:89:Ab")
    assert is_mac("01:23:45:67:89:ab")
    assert is_mac("01-23-45-67-89-ab")
    assert is_mac("01-23-45-67-89-ab")

# Generated at 2022-06-20 15:59:33.630808
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32') is True
    assert is_masklen('31') is True
    assert is_masklen('30') is True
    assert is_masklen('29') is True
    assert is_masklen('28') is True
    assert is_masklen('27') is True
    assert is_masklen('26') is True
    assert is_masklen('25') is True
    assert is_masklen('24') is True
    assert is_masklen('23') is True
    assert is_masklen('22') is True
    assert is_masklen('21') is True
    assert is_masklen('20') is True
    assert is_masklen('19') is True
    assert is_masklen('18') is True
    assert is_masklen('17') is True

# Generated at 2022-06-20 15:59:41.552309
# Unit test for function is_netmask
def test_is_netmask():
    # test positive cases
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.128')
    assert is_netmask('128.0.0.0')
    assert is_netmask('127.0.0.1')

    # test negative cases
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.256.0.1')
    assert not is_netmask('256.0.0.1')
    assert not is_netmask('0.0.0.0.0')
    assert not is_netmask('')
    assert not is_netmask('127.0')
    assert not is_netmask('127.0.0')

# Generated at 2022-06-20 15:59:52.723427
# Unit test for function is_masklen
def test_is_masklen():
    test_cases = [
        {'masklen': '1', 'result': True},
        {'masklen': '32', 'result': True},
        {'masklen': '0', 'result': True},
        {'masklen': '33', 'result': False},
        {'masklen': '-1', 'result': False},
        {'masklen': 'a', 'result': False},
        {'masklen': '0.0.0.0', 'result': False},
        {'masklen': '1.2.3.4', 'result': False},
    ]

    for test_case in test_cases:
        if test_case['result'] is True:
            assert is_masklen(test_case['masklen'])

# Generated at 2022-06-20 16:00:03.214212
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:4:4:4:4:4:4:4') == '2001:4:4:4::'
    assert to_ipv6_subnet('2001:4:4:4:4:4:4:4/64') == '2001:4:4:4::'
    assert to_ipv6_subnet('2001:4:4:4:4:4:4:4/64') == '2001:4:4:4::'
    assert to_ipv6_subnet('2001:4:4:4::') == '2001:4:4:4::'
    assert to_ipv6_subnet('2001:4::6') == '2001:4::'

# Generated at 2022-06-20 16:00:09.030461
# Unit test for function to_netmask
def test_to_netmask():

    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(17) == '255.255.128.0'
    assert to_netmask(9) == '255.128.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(7) == '254.0.0.0'
    assert to_netmask(6) == '252.0.0.0'
    assert to_netmask(5) == '248.0.0.0'
    assert to_netmask(4) == '240.0.0.0'
    assert to_netmask(3) == '224.0.0.0'
    assert to_netmask(2) == '192.0.0.0'

# Generated at 2022-06-20 16:00:13.601487
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(0) == '0.0.0.0'



# Generated at 2022-06-20 16:00:23.424128
# Unit test for function to_netmask

# Generated at 2022-06-20 16:00:26.054069
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.128.0') == '1111111111111111' \
                                      '1000000000000000' \
                                      '0000000000000000' \
                                      '00000000'

# Generated at 2022-06-20 16:00:29.196824
# Unit test for function to_bits
def test_to_bits():
    print(to_bits('255.255.255.254'))
    assert to_bits('255.255.255.254') == '11111111111111111111111111111110'



# Generated at 2022-06-20 16:00:42.548373
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('16') == '255.255.0.0'
    assert to_netmask('29') == '255.255.255.248'
    assert to_netmask('31') == '255.255.255.254'
    assert to_netmask('32') == '255.255.255.255'


# Generated at 2022-06-20 16:00:50.503538
# Unit test for function is_masklen
def test_is_masklen():
    # Assert none
    assert(is_masklen(None) is False)
    # Test all possible valid values
    for n in range(1, 33):
        assert(is_masklen(n) is True)
    # Test all possible invalid values
    for n in range(-1, -33, -1):
        assert(is_masklen(n) is False)
    for n in range(33, 65):
        assert(is_masklen(n) is False)



# Generated at 2022-06-20 16:00:53.123413
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(30)
    assert not is_masklen(33)
    assert not is_masklen(-1)



# Generated at 2022-06-20 16:00:57.372333
# Unit test for function to_masklen
def test_to_masklen():
    '''
    Test the to_masklen function
    '''
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.252') == 30

# Generated at 2022-06-20 16:01:08.141861
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00-00-00-00-00-00')
    assert is_mac('00:00:00:00:00:00')
    assert is_mac('11-aa-00-bb-22-ee')
    assert is_mac('11:aa:00:bb:22:ee')
    assert is_mac('11:aa:33:bb:22:ee')
    assert is_mac('11-aa-33-55-22-ee')
    assert not is_mac('11:aa:bb:cc:dd:11:22:33')
    assert not is_mac('11:aa:bb:cc:dd:11-22-33')
    assert not is_mac('11:aa:bb:cc:dd:ee:22:33')

# Generated at 2022-06-20 16:01:16.512431
# Unit test for function to_netmask
def test_to_netmask():
    tests = [
        ('0.0.0.0', '0.0.0.0'),
        ('0.0.0.0', '0.0.0.0'),
        ('255.255.255.0', '24'),
        ('255.255.255.128', '25'),
        ('255.255.255.128', '255.255.255.128'),
        ('255.255.255.255', '32'),
    ]

    for exp, mask in tests:
        res = to_netmask(mask)
        if exp != res:
            raise AssertionError("Failed to convert mask to netmask, expected %s got %s" % (exp, res))



# Generated at 2022-06-20 16:01:19.344654
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('24')
    assert is_masklen('32')

    assert not is_masklen('-1')
    assert not is_masklen('33')
    assert not is_masklen('a')
    assert not is_masklen('1.0')



# Generated at 2022-06-20 16:01:28.037796
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(0) == '0.0.0.0'
    try:
        to_netmask(33)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-20 16:01:32.072932
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8



# Generated at 2022-06-20 16:01:41.154976
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:0000:0000:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:0000:0000:0000') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:0000:0000:0000:0000:0000:0000') == '2001:0db8::'

# Generated at 2022-06-20 16:02:07.728493
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:5E:00:53:00')
    assert is_mac('00-00-5E-00-53-00')
    assert is_mac('00:00:5E:00:53') is False
    assert is_mac('00:00:5E:00:53:00:00:00:00:00:00') is False

# Generated at 2022-06-20 16:02:12.732744
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('52:54:00:cc:f5:66')
    assert not is_mac('52:54:00:cc:f5:66:78')
    assert not is_mac('ab:cd:ef:01:23:45')
    assert not is_mac('001122334455')
    assert not is_mac('00-11-22-33-44-55')
    assert is_mac('00-11-22-33-44-55')

# Generated at 2022-06-20 16:02:19.648952
# Unit test for function is_netmask
def test_is_netmask():
    print("Testing is_netmask")
    assert is_netmask("255.255.255.0")
    assert not is_netmask("255.255.255.255.0")
    assert not is_netmask("255.255.255.0.0")
    assert not is_netmask("255.255.0")
    assert not is_netmask("255.255.0.255")
    assert not is_netmask("0.0.0.0")
    assert not is_netmask("128.0.0.0")
    assert not is_netmask("255.255.255.254")
    assert not is_netmask("255.255.255.256")
    assert not is_netmask("255.255.255.2a")



# Generated at 2022-06-20 16:02:23.208249
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(24) is True
    assert is_masklen(255) is False


# Generated at 2022-06-20 16:02:33.993520
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(31)
    assert is_masklen(30)
    assert is_masklen(29)
    assert is_masklen(28)
    assert is_masklen(27)
    assert is_masklen(26)
    assert is_masklen(25)
    assert is_masklen(24)
    assert is_masklen(23)
    assert is_masklen(22)
    assert is_masklen(21)
    assert is_masklen(20)
    assert is_masklen(19)
    assert is_masklen(18)
    assert is_masklen(17)
    assert is_masklen(16)
    assert is_masklen(15)
    assert is_masklen(14)
    assert is_masklen(13)

# Generated at 2022-06-20 16:02:39.758827
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('1.2.3.4')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255')

# Generated at 2022-06-20 16:02:43.742146
# Unit test for function to_netmask
def test_to_netmask():
    assert '255.0.0.0' == to_netmask(8)
    assert '255.255.255.0' == to_netmask(24)
    assert '255.255.255.0' == to_netmask('24')
    assert '255.255.255.224' == to_netmask('27')



# Generated at 2022-06-20 16:02:50.830154
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('192.168.0.0/24')
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.255.255')

# Unit tests for function to_netmask

# Generated at 2022-06-20 16:02:55.350255
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', 24, True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'



# Generated at 2022-06-20 16:02:57.707571
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24


# Generated at 2022-06-20 16:03:45.605865
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'

# Generated at 2022-06-20 16:03:54.021555
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:23:45:67:AB:CD')
    assert is_mac('01:23:45:67:ab:cd')
    assert is_mac('01-23-45-67-ab-cd')
    assert not is_mac('01:23:45:67:AB:CD:EF')
    assert not is_mac('01:23:45:67:AB:C')
    assert not is_mac('0123.4567.abcd')
    assert not is_mac('01234567abcd')
    assert not is_mac('not a real mac')
    assert not is_mac('')
    assert not is_mac(None)

# Generated at 2022-06-20 16:03:55.137120
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24



# Generated at 2022-06-20 16:03:59.692219
# Unit test for function is_masklen
def test_is_masklen():
    ansible_unittest.assertTrue(is_masklen(0))
    ansible_unittest.assertTrue(is_masklen(32))
    ansible_unittest.assertFalse(is_masklen(-1))
    ansible_unittest.assertFalse(is_masklen(33))
    ansible_unittest.assertFalse(is_masklen('foo'))


# Generated at 2022-06-20 16:04:06.702050
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    ipv6_addr_w_o_zero_groups_expected = 'fd40::1:1'
    ipv6_addr_w_o_zero_groups_actual = 'fd40:0:0:0:0:1:1:1'
    ipv6_addr_w_o_zero_groups_actual = to_ipv6_network(ipv6_addr_w_o_zero_groups_actual)
    assert ipv6_addr_w_o_zero_groups_actual == ipv6_addr_w_o_zero_groups_expected

    ipv6_addr_w_single_zero_group_expected = 'fd40::1'
    ipv6_addr_w_single_zero_group_actual = 'fd40:0:0:0:1:1:1:1'
   

# Generated at 2022-06-20 16:04:07.913023
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True


# Generated at 2022-06-20 16:04:20.470365
# Unit test for function to_subnet
def test_to_subnet():
    try:
        to_subnet('1.1.1.1', '255.255.255.0')
    except ValueError as e:
        assert 'netmask' in str(e)

    try:
        to_subnet('1.1.1.1', '255.255.255.255.255')
    except ValueError as e:
        assert 'netmask' in str(e)

    assert to_subnet('1.1.1.1', 24) == '1.1.1.0/24'
    assert to_subnet('1.1.1.1', 24, True) == '1.1.1.0 255.255.255.0'

# Generated at 2022-06-20 16:04:24.776381
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(42)
    assert is_masklen(0)
    assert not is_masklen(-1)
    assert is_masklen(32)
    assert not is_masklen(33)
    assert not is_masklen('foo')
    assert not is_masklen('/32')
    assert not is_masklen('1.1.1.1')
    assert not is_masklen(False)
    assert not is_masklen(True)
