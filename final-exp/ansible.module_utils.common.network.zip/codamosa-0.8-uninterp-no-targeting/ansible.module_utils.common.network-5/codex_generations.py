

# Generated at 2022-06-20 15:54:34.314421
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3:1319:8a2e:370:0::'
    assert to_ipv6_network('2001::db8::85a3::8d3:1319::8a2e:370:7348') == '2001::db8::8d3:1319::0:0:0:'

# Generated at 2022-06-20 15:54:38.701888
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.20.30.40', '255.0.0.0') == '10.0.0.0/8'
    assert to_subnet('10.20.30.40', '255.0.0.0', dotted_notation=True) == '10.0.0.0 255.0.0.0'

# Generated at 2022-06-20 15:54:45.273133
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.248.0") is True
    assert is_netmask("255.255.255.0") is True
    assert is_netmask("255.255.255.255") is True
    assert is_netmask("0.0.0.0") is True
    assert is_netmask("255.255.254.0") is False
    assert is_netmask("255.255.255") is False


# Generated at 2022-06-20 15:54:54.602596
# Unit test for function is_mac
def test_is_mac():
    assert is_mac(mac_address='00:50:56:AB:CD:EF')
    assert is_mac(mac_address='0:0:0:0:0:0')
    assert is_mac(mac_address='00-50-56-AB-CD-EF')
    assert is_mac(mac_address='00-50-56-ab-cd-ef')
    assert not is_mac(mac_address='0050.56AB.CDEF')
    assert not is_mac(mac_address='00-AB-BC-AB-CD-EF-GG')
    assert not is_mac(mac_address='00:AB:BC:AB:CD:EF:GH')
    assert not is_mac(mac_address='00:AB:BC:AB:CD:EF:')

# Generated at 2022-06-20 15:55:01.728422
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Subnets with addresses in the first four groups
    assert to_ipv6_subnet('2001:db81:3f2d:f0c9:1b95:73b1:79d7:a6ee') == '2001:db81:3f2d:f0c9::'
    assert to_ipv6_subnet('2001:db8:3f2d:f0c9:1b95:73b1:79d7:a6ee') == '2001:db8:3f2d::'
    assert to_ipv6_subnet('2001:db8:3f2d:f0c9:1b95:73b1:79d7:a6ee') == '2001:db8:3f2d::'

# Generated at 2022-06-20 15:55:12.696526
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:db8:85a3::8a2e:370:7334/64') == '2001:db8:85a3::'



# Generated at 2022-06-20 15:55:17.000567
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('33') == False
    assert is_masklen('-1') == False
    assert is_masklen('0') == True
    assert is_masklen('8') == True
    assert is_masklen('32') == True


# Generated at 2022-06-20 15:55:24.302830
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ipv6_address = "fe80::3ab8:69ff:fe4e:a3e4"
    expected_ipv6_subnet = "fe80::"
    ipv6_subnet = to_ipv6_subnet(ipv6_address)
    assert expected_ipv6_subnet == ipv6_subnet

    ipv6_address = "2001:db8::2ec2:60ff:fe4f:f85a"
    expected_ipv6_subnet = "2001:db8::"
    ipv6_subnet = to_ipv6_subnet(ipv6_address)
    assert expected_ipv6_subnet == ipv6_subnet



# Generated at 2022-06-20 15:55:33.136257
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32) is True
    assert is_masklen(24) is True
    assert is_masklen(8) is True
    assert is_masklen(0) is True
    assert is_masklen(-1) is False
    assert is_masklen(99) is False
    assert is_masklen("32") is True
    assert is_masklen("24") is True
    assert is_masklen("8") is True
    assert is_masklen("0") is True
    assert is_masklen("-1") is False
    assert is_masklen("99") is False
    assert is_masklen("aaa") is False
    assert is_masklen(".") is False
    assert is_masklen("10.0.0.1") is False


# Generated at 2022-06-20 15:55:43.858215
# Unit test for function to_bits
def test_to_bits():
    print('-- Testing to_bits --')

    from nose.tools import assert_equal

    test_data = {
        '': '',
        '1': '100000000',
        '1.1': '10000000100000001',
        '1.1.1': '10000000100000001100000001',
        '1.1.1.1': '10000000100000001100000001100000001',
    }

    for val, expected in test_data.items():
        print('Testing to_bits - input: {0}'.format(val))
        print('Expected: {0}'.format(expected))

        output = to_bits(val)

        print('Output: {0}'.format(output))

        assert_equal(output, expected)



# Generated at 2022-06-20 15:55:55.442270
# Unit test for function to_subnet
def test_to_subnet():
    print('Test to_subnet function')
    assert '10.1.10.0/24' == to_subnet('10.1.10.99', '255.255.255.0')
    assert '10.1.10.0 255.255.255.0' == to_subnet('10.1.10.99', '255.255.255.0', True)
    assert '192.168.0.0 255.255.255.0' == to_subnet('192.168.0.255', '24', True)
    assert '192.168.0.0/24' == to_subnet('192.168.0.255', '24', False)
    assert '10.0.0.0/8' == to_subnet('10.1.10.0', '255.0.0.0')

# Generated at 2022-06-20 15:55:59.083552
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet("2001:0DB8:AC10:FE01::") == "2001:0db8:ac10:fe01::"
    assert to_ipv6_subnet("2001:0DB8:AC10:FE01:0011:0022:0033:0044") == "2001:0db8:ac10:fe01::"
    assert to_ipv6_subnet("2001:0DB8:AC10:FE01::0055:0066:0077:0088") == "2001:0db8:ac10:fe01::"


# Generated at 2022-06-20 15:56:10.290370
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', 24) == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', 24, True) == '192.168.1.0 255.255.255.0'
    assert to_subnet('192.168.1.0/24', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.0/24', 24) == '192.168.1.0/24'

# Generated at 2022-06-20 15:56:18.908177
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('AA:BB:CC:DD:EE:FF')
    assert not is_mac('AA:BB:CC:DD:EE-FF')  # Separator must be ':'
    assert not is_mac('AA:BB:CC:DD:E-FF')   # Group size must be 2
    assert not is_mac('AA:BB:CC:DD:EE:XX')  # Characters must be in hex range
    assert not is_mac('AA_BB_CC_DD_EE_FF')   # Separator must be ':' or '-'


# Generated at 2022-06-20 15:56:30.252787
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:0:0:0:0:7897:9eef') == '2001:db8:0:0:0:0:7897:0:'
    assert to_ipv6_subnet('2001:db8::7897:9eef') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:7897:9eef') == '2001:db8:0:0:0:0:7897:0:'
    assert to_ipv6_subnet('2001:db8:0:0:7897:9eef') == '2001:db8:0:0:0:0:7897:0:'

# Generated at 2022-06-20 15:56:38.406874
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::cafe:beef') == 'fe80::'
    assert to_ipv6_subnet('fe80::a:b:c:d:e:f') == 'fe80::'
    assert to_ipv6_subnet('fe80::a:b:c:cafe:beef') == 'fe80::a:b:c::'
    assert to_ipv6_subnet('fe80::a:b:c:cafe:beef') == 'fe80::a:b:c::'
    assert to_ipv6_subnet('fe80::a:b:c:cafe:beef') == 'fe80::a:b:c::'



# Generated at 2022-06-20 15:56:46.132101
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet("fe80::1:2:3:4") == "fe80::"
    assert to_ipv6_subnet("fe80:1:2:3:4:5:6:7") == "fe80:1:2:3::"
    assert to_ipv6_subnet("fe80:1:2:3:4::7") == "fe80:1:2:3:4::"
    assert to_ipv6_subnet("fe80::1:2:3") == "fe80::"
    assert to_ipv6_subnet("fe80::1:2") == "fe80::"
    assert to_ipv6_subnet("fe80::1") == "fe80::"

# Generated at 2022-06-20 15:56:53.518854
# Unit test for function to_netmask
def test_to_netmask():
    assert is_netmask(to_netmask('24'))
    assert is_netmask(to_netmask(24))
    assert not is_netmask(to_netmask('24a'))
    assert not is_netmask(to_netmask(33))
    assert not is_netmask(to_netmask(-1))
    assert to_netmask(24) == '255.255.255.0'



# Generated at 2022-06-20 15:56:56.756445
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ExpAddr = 'fe80::1'
    ExpSubnet = 'fe80::'
    Subnet = to_ipv6_subnet(ExpAddr)
    assert Subnet == ExpSubnet

# Generated at 2022-06-20 15:57:03.516152
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255') == False
    assert is_netmask('foo') == False
    assert is_netmask('192.168.1.1') == False


# Generated at 2022-06-20 15:57:11.139235
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('128.0.0.0') == '10000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'

# Generated at 2022-06-20 15:57:20.981726
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.1', '24') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.1', '255.255.255.128') == '192.168.0.0/25'
    assert to_subnet('192.168.0.1', '255.255.255.192') == '192.168.0.0/26'
    assert to_subnet('192.168.0.1', '255.255.255.224') == '192.168.0.0/27'

# Generated at 2022-06-20 15:57:23.762013
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('24')
    assert is_masklen(24)

    assert not is_masklen('foo')
    assert not is_masklen(None)
    assert not is_masklen('33')
    assert not is_masklen(-1)


# Generated at 2022-06-20 15:57:29.806204
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('22')
    assert is_masklen(22)
    assert is_masklen(0)
    assert is_masklen(32)
    assert not is_masklen('32')
    assert not is_masklen('a')
    assert not is_masklen(-1)
    assert not is_masklen(33)
    assert is_masklen(33.0)
    assert not is_masklen('33.0')



# Generated at 2022-06-20 15:57:34.435415
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert is_masklen('31')
    assert not is_masklen('33')
    assert not is_masklen(True)
    assert not is_masklen(False)
    assert not is_masklen('x')


# Generated at 2022-06-20 15:57:37.673505
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('20') is True
    assert is_masklen('33') is False
    assert is_masklen('0') is True


# Generated at 2022-06-20 15:57:47.736462
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('1234:5678:90ab:cdef:1234:5678:90ab:cdef') == '1234:5678:90ab:cdef::'
    assert to_ipv6_network('1234:5678:90ab:cdef:1234:5678:90ab:cdef/64') == '1234:5678:90ab:cdef::'
    assert to_ipv6_network('1234:5678:90ab:cdef:1234:5678:90ab:cdef/105') == '1234:5678:90ab::'
    assert to_ipv6_network('1234:5678:90ab:cdef:1234:5678:90ab') == '1234:5678:90ab::'
    assert to_

# Generated at 2022-06-20 15:57:58.391516
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('1:2:3:4:5:6:7::8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4:5:6::8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4:5::8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4::8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3::8') == '1:2:3::'
    assert to_ipv6_subnet('1:2::8') == '1:2::'
   

# Generated at 2022-06-20 15:58:09.199507
# Unit test for function to_netmask
def test_to_netmask():
    """ Test converting mask length to netmask """
    # Test empty values
    if not to_netmask('') == '0.0.0.0':
        raise AssertionError('Failed to convert empty mask length to netmask')

    # Test invalid values
    try:
        to_netmask('33')
        raise AssertionError('Expected value error when converting invalid mask length')
    except:
        pass

    # Test valid values
    if not to_netmask('32') == '255.255.255.255':
        raise AssertionError('Failed to convert 32 mask length to netmask')
    if not to_netmask('31') == '255.255.255.254':
        raise AssertionError('Failed to convert 31 mask length to netmask')

# Generated at 2022-06-20 15:58:15.864218
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("::1") == ":::"
    assert to_ipv6_network("::") == ":::::::"
    assert to_ipv6_network("1::2:3:4:5:6:7:8") == "1::3:4:5:6::"
    assert to_ipv6_network("1::2:3:4") == "1::3:4::"
    assert to_ipv6_network("1::2:3:4:5:6:7:8:") == "1::3:4:5:6::"
    assert to_ipv6_network("1:2:3:4:5:6:7:8::") == "1:2:3::"

# Generated at 2022-06-20 15:58:28.986079
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert str(to_ipv6_subnet("1:2:3:4:5:6:7:8")) == "1:2:3:4::"
    assert str(to_ipv6_subnet("1:2:3:4:5:6:7:8%1")) == "1:2:3:4::"
    assert str(to_ipv6_subnet("1:2:3:4:5:6:7:8/64")) == "1:2:3:4::"
    assert str(to_ipv6_subnet("::")) == "::"
    assert str(to_ipv6_subnet("1::3:4:5:6:7:8")) == "1::"

# Generated at 2022-06-20 15:58:33.027377
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    if to_ipv6_network('2001:0db8:0000:0000:0000:ff00:0042:8329') != '2001:db8::':
        raise SystemExit('Failed to_ipv6_network test.')


# Generated at 2022-06-20 15:58:42.966901
# Unit test for function to_subnet
def test_to_subnet():

    # Test dotted notation being disabled
    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0/24'

    # Test dotted notation being enabled
    assert to_subnet('192.168.0.0', '255.255.255.0', True) == '192.168.0.0 255.255.255.0'

    # Test masklen
    assert to_subnet('192.168.0.0', '24') == '192.168.0.0/24'

    # Test bad masklen
    try:
        to_subnet('192.168.0.0', '33')
        raise AssertionError()
    except ValueError:
        pass

    # Test bad netmask

# Generated at 2022-06-20 15:58:54.301587
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8/64') == '1:2:3:4::'
    assert to_ipv6_subnet('fe80::3:2ff:fe21:67cf') == 'fe80::'
    assert to_ipv6_subnet('fe80::3:2ff:fe21:67cf/64') == 'fe80::'
    assert to_ipv6_subnet(':') == '::'
    assert to_ipv6_subnet(':/64') == '::'

# Generated at 2022-06-20 15:59:02.412789
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('192.168.1.0') == '110000001010100000000001000000000'
    assert to_bits('192.168.1.1') == '110000001010100000000001000000001'
    assert to_bits('192.168.1.2') == '110000001010100000000001000000010'



# Generated at 2022-06-20 15:59:03.368391
# Unit test for function to_bits
def test_to_bits():
    test_mask = '255.255.255.0'
    assert to_bits(test_mask) == '11111111111111111111111100000000'



# Generated at 2022-06-20 15:59:09.520282
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:0000:0000:0000:ff00:0042:8329') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:0:ff00:42:8329') == '2001:db8::'
    assert to_ipv6_network('2001:db8::ff00:42:8329') == '2001:db8::'


# Generated at 2022-06-20 15:59:15.550216
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert is_masklen(32)
    assert is_masklen('1')
    assert is_masklen(1)
    assert not is_masklen('33')
    assert not is_masklen(33)
    assert not is_masklen('0')
    assert not is_masklen(0)
    assert not is_masklen('-1')
    assert not is_masklen(-1)



# Generated at 2022-06-20 15:59:22.923050
# Unit test for function to_subnet
def test_to_subnet():
    subnet = to_subnet('10.0.0.2', '255.255.255.0')
    assert subnet == '10.0.0.0/24'

    subnet = to_subnet('10.0.0.2', '24')
    assert subnet == '10.0.0.0/24'

    subnet = to_subnet('10.0.0.2', '255.255.255.0', True)
    assert subnet == '10.0.0.0 255.255.255.0'

    subnet = to_subnet('10.0.0.2', '24', True)
    assert subnet == '10.0.0.0 255.255.255.0'

# Generated at 2022-06-20 15:59:33.549279
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8:::'
    assert to_ipv6_subnet('2001:db8:0:0:1:0:2:1') == '2001:db8:0:0::'
    assert to_ipv6_subnet('2001:db8::1:0:2:1') == '2001:db8:::'
    assert to_ipv6_subnet('2001:db8:0:0:1::2:1') == '2001:db8:0:0::'
    assert to_ipv6_subnet('2001:db8:0:1::2:1') == '2001:db8:0:0::'

# Generated at 2022-06-20 15:59:47.034867
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Given
    addr = '0:0:0:ffff::1'
    expected_subnet = '0:0:0:ffff::'

    # When
    subnet = to_ipv6_subnet(addr)

    # Then
    assert subnet == expected_subnet



# Generated at 2022-06-20 15:59:54.733573
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """ Unit test for function to_ipv6_network """
    assert 'FE80::' == to_ipv6_network('FE80::21B:77FF:FE5F:9D86')
    assert '2001::' == to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334')
    assert '2001:0db8:85a3:0000:0000:0000:0000:0000' == to_ipv6_network('2001:0db8:85a3:0000:0000:0000:0000:0000')



# Generated at 2022-06-20 16:00:04.310975
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-20 16:00:10.354177
# Unit test for function to_subnet

# Generated at 2022-06-20 16:00:16.271639
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', 24) == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == '192.168.1.0 255.255.255.0'

# Generated at 2022-06-20 16:00:20.910414
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::719:9dff:fe7d:c8aa') == 'fe80::'
    assert to_ipv6_subnet('::1') == '::'
    assert to_ipv6_subnet('fe80::') == 'fe80::'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'


# Generated at 2022-06-20 16:00:30.587274
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:08d3:1319:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:08d3:1319:8a2e:0370:7334/64') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:0000:0000:0000') == '2001:0db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3::0001') == '2001:0db8:85a3::'

# Generated at 2022-06-20 16:00:39.162696
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('52:54:00:67:9c:9a') == True
    assert is_mac('52:54:00:67:9c:9a:ff') == False
    assert is_mac('52:54:00:67:9c') == False
    assert is_mac('52-54-00-67-9c-9a') == True
    assert is_mac('52-54-00-67-9c-9a-ff') == False
    assert is_mac('52-54-00-67-9c') == False
    assert is_mac('52 54 00 67 9c 9a') == False
    assert is_mac('52 54 00 67 9c 9a ff') == False
    assert is_mac('52 54 00 67 9c') == False

# Generated at 2022-06-20 16:00:40.082437
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(masklen) == netmask


# Generated at 2022-06-20 16:00:46.590567
# Unit test for function to_subnet
def test_to_subnet():
    test_data = [
        ('192.168.1.1', '255.255.255.0', '192.168.1.0/24'),
        ('192.168.1.1', '24', '192.168.1.0/24'),
        ('192.168.1.1', '/24', '192.168.1.0/24'),
        ('192.168.1.1', '255.255.255.0', True, '192.168.1.0 255.255.255.0'),
        ('192.168.1.1', '24', True, '192.168.1.0 255.255.255.0'),
        ('192.168.1.1', '/24', True, '192.168.1.0 255.255.255.0'),
    ]
    failed = list()


# Generated at 2022-06-20 16:01:11.602673
# Unit test for function is_netmask
def test_is_netmask():
    if not is_netmask('255.255.192.0'):
        raise Exception('is_netmask test 1 failed')

    if not is_netmask('255.248.0.0'):
        raise Exception('is_netmask test 2 failed')

    if not is_netmask('255.255.255.0'):
        raise Exception('is_netmask test 3 failed')

    if is_netmask('255.255.240.1'):
        raise Exception('is_netmask test 4 failed')

    if is_netmask('255.255.1.0'):
        raise Exception('is_netmask test 5 failed')

    if is_netmask('255.256.0.0'):
        raise Exception('is_netmask test 6 failed')


# Generated at 2022-06-20 16:01:16.584827
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('8000:42ca:2f7d::1') == '8000:42ca:2f7d::'
    assert to_ipv6_network('8000:42ca:2f7d:1::1') == '8000:42ca:2f7d:1:0:0::'
    assert to_ipv6_network('8000::1') == '8000::'

# Generated at 2022-06-20 16:01:19.905176
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('255.128.0.0') == '11111111100000000000000000000000'


# Generated at 2022-06-20 16:01:31.618169
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.252.0') == 22
   

# Generated at 2022-06-20 16:01:33.034992
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.192') == 26

# Generated at 2022-06-20 16:01:38.409970
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:4860:4860::8844') == '2001:4860:4860:0:0:0:0:0:'
    assert to_ipv6_network('2001:4860:4860:8844::') == '2001:4860:4860:8844::'
    assert to_ipv6_network('2001:4860:4860:8844:aaaa:bbbb:cccc:dddd') == '2001:4860:4860:8844:0:0:0:0:'

# Generated at 2022-06-20 16:01:50.028095
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    network_addr = to_ipv6_network('abc1:abc2:abc3:abc4:abc5:abc6:abc7:abc8')
    assert network_addr == 'abc1:abc2:abc3::'

    # Test idempotency
    assert to_ipv6_network(network_addr) == network_addr, 'Returned network address does not match expected value'

    # Test zeros for omitted zeros
    network_addr = to_ipv6_network('abc1:abc2:abc3::abc7:abc8')
    assert network_addr == 'abc1:abc2:abc3::', 'Returned network address does not match expected value'

    network_addr = to_ipv6_network('abc1:abc2::abc7:abc8')

# Generated at 2022-06-20 16:01:53.120519
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('23')
    assert not is_masklen('24')
    assert not is_masklen('z')
    assert is_masklen(23)
    assert not is_masklen(24)
    assert not is_masklen('1.1')


# Generated at 2022-06-20 16:02:03.374949
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.254.0') is True
    assert is_netmask('255.255.255.128') is True
    assert is_netmask('255.255.255.192') is True
    assert is_netmask('255.255.255.224') is True
    assert is_netmask('255.255.255.240') is True
    assert is_netmask('255.255.255.248') is True
    assert is_netmask('255.255.255.252') is True
    assert is_netmask('255.255.255.254') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('255.255.255.0.0') is False

# Generated at 2022-06-20 16:02:07.374748
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('0c:c4:7a:90:05:de') == True
    assert is_mac('0c:c4:7a:90:05:de') != False
    assert is_mac('0c:c4:7a:90:05') == False


# Generated at 2022-06-20 16:02:52.551836
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask(to_masklen('255.255.255.0')) == '255.255.255.0'
    assert to_netmask(23) == '255.255.254.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask('0.0.0.0') == '0.0.0.0'



# Generated at 2022-06-20 16:02:54.981691
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(123) is False
    assert is_masklen(33) is False
    assert is_masklen(0) is True
    assert is_masklen(32) is True
    assert is_masklen(-1) is False


# Generated at 2022-06-20 16:02:57.461633
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.224') == '11111111.11111111.11111111.11100000'
    assert to_bits('255.255.255.0') == '11111111.11111111.11111111.00000000'
    assert to_bits('255.255.255.128') == '11111111.11111111.11111111.10000000'

# Generated at 2022-06-20 16:03:08.504708
# Unit test for function is_mac
def test_is_mac():
    """
    test function
    """
    assert(is_mac('f8-16-54-a2-e1-cc'))
    assert(is_mac('f816.54a2.e1cc'))
    assert(is_mac('F81654A2E1CC'))
    assert(is_mac('f8:16:54:a2:e1:cc'))
    assert(is_mac('99:E2:D3:1A:53:A4'))
    assert(is_mac('99-e2-d3-1A-53-a4'))
    assert(is_mac('99-e2-d3-1a-53-a4'))
    assert(not is_mac('99:e2:d3:1a:53:aG'))


# Generated at 2022-06-20 16:03:15.162861
# Unit test for function to_ipv6_network
def test_to_ipv6_network():

    print(to_ipv6_network('fdf8:f53b:82e4::1'))
    print(to_ipv6_network('fdf8:f53b:82e4:f53b:82e4:f53b:82e4:1'))
    print(to_ipv6_network('fdf8:f53b:82e4:1'))
    print(to_ipv6_network('fdf8:f53b:82e4:1:1:1:1:1'))


if __name__ == '__main__':
    test_to_ipv6_network()

# Generated at 2022-06-20 16:03:26.388210
# Unit test for function to_masklen

# Generated at 2022-06-20 16:03:35.486234
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ipv6addr = '2001:db8::1'
    assert to_ipv6_subnet(ipv6addr) == '2001:db8::'

    ipv6addr = '1::1'
    assert to_ipv6_subnet(ipv6addr) == '1::'

    ipv6addr = '1:2:3:4:5:6::1'
    assert to_ipv6_subnet(ipv6addr) == '1:2:3:4:'

    ipv6addr = '::1'
    assert to_ipv6_subnet(ipv6addr) == '::'


# Generated at 2022-06-20 16:03:37.650332
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.10.10.1', '255.255.255.0') == '10.10.10.0/24'
    assert to_subnet('2001:db8::1', 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:0') == '2001:db8::/64'

# Generated at 2022-06-20 16:03:41.305014
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32), '32 is valid masklen'
    assert not is_masklen(33), '33 is invalid masklen'


# Generated at 2022-06-20 16:03:42.870976
# Unit test for function is_masklen
def test_is_masklen():
    from nose.plugins.skip import SkipTest
    raise SkipTest('No unit tests for this module yet')
