

# Generated at 2022-06-20 15:54:38.347567
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    print('Testing to_ipv6_subnet with valid IPv6 address:')
    addr = '2001:db8:f00::8'
    # subnet should be the first 48 bits, or the first three groups
    assert to_ipv6_subnet(addr) == '2001:db8:f00::'
    print('  PASSED')

    print('Testing to_ipv6_subnet with IPv6 address missing groups:')
    addr = '2001:db8:f00::'
    # subnet should be the first 48 bits, or the first three groups
    assert to_ipv6_subnet(addr) == '2001::'
    print('  PASSED')

    print('Testing to_ipv6_subnet with IPv6 address missing a lot of groups:')
    addr = '2001:db8::'


# Generated at 2022-06-20 15:54:45.287367
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.256.255.255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.25.5')
    assert not is_netmask(None)



# Generated at 2022-06-20 15:54:54.599594
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.248.0') == 21
    assert to_masklen('255.192.0.0') == 10
    assert to_masklen('255.240.0.0') == 12
    assert to_masklen('255.255.192.0') == 18
    assert to_masklen('255.255.252.0') == 22
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.255.0') == 24
   

# Generated at 2022-06-20 15:55:03.394166
# Unit test for function to_masklen
def test_to_masklen():
    # Test values
    test_val = ((('255.255.255.255', 32),),
                (('255.255.255.0', 24),),
                (('255.255.0.0', 16),),
                (('255.0.0.0', 8),),
                (('0.0.0.0', 0),),
                (('255.248.0.0', 13),))
    for val in test_val:
        assert to_masklen(val[0][0]) == int(val[0][1])


# Generated at 2022-06-20 15:55:07.159788
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.128.0.0') == '9'
    assert to_netmask('255.255.255.254') == '23'



# Generated at 2022-06-20 15:55:11.712988
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'

# Generated at 2022-06-20 15:55:17.183864
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('32')
    assert is_masklen(0)
    assert is_masklen(32)
    assert not is_masklen('33')
    assert not is_masklen('-1')
    assert not is_masklen(33)
    assert not is_masklen(-1)



# Generated at 2022-06-20 15:55:18.831477
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-20 15:55:21.952142
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(128) is False, "128 is not a valid mask length"
    assert is_masklen(32) is True, "32 is a valid mask length"
    assert is_masklen(33) is False, "33 is not a valid mask length"


# Generated at 2022-06-20 15:55:32.336208
# Unit test for function is_mac
def test_is_mac():
    """
    This function tests is_mac function with valid and invalid strings
    Returns (Boolean) True if all tests pass, otherwise False
    """
    # Valid MAC strings
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa:bb:cc:dd:ee:FF')
    assert is_mac('aA:BB:cc:dd:EE:ff')
    assert is_mac('aA-BB-cc-dd-EE-ff')
    # Valid MAC strings with a broadcast bit set
    assert is_mac('aa:bb:ff:dd:ee:ff')
    assert is_mac('aa:bb:cc:dd:ee:fF')
    assert is_mac('aA:BB:ff:dd:EE:ff')

# Generated at 2022-06-20 15:55:39.448817
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'



# Generated at 2022-06-20 15:55:42.989664
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:34:56:78:9a:bc')
    assert is_mac('01:34:56:78:9A:BC')
    assert is_mac('01-34-56-78-9A-BC')
    assert not is_mac('0134:567')

# Generated at 2022-06-20 15:55:53.549403
# Unit test for function to_subnet
def test_to_subnet():
    """ Ensure that to_subnet() behaves properly """
    assert to_subnet('10.0.0.1', '255.255.255.0') == '10.0.0.0/24'
    assert to_subnet('10.0.0.1', '24') == '10.0.0.0/24'
    assert to_subnet('10.0.0.1', '255.255.0.0') == '10.0.0.0/16'
    assert to_subnet('10.0.0.1', '16') == '10.0.0.0/16'
    assert to_subnet('10.0.0.1', '255.0.0.0') == '10.0.0.0/8'

# Generated at 2022-06-20 15:55:57.719197
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('30'), True
    assert is_masklen('32'), True
    assert is_masklen('0'), True
    assert is_masklen('-1'), False
    assert is_masklen('a'), False


# Generated at 2022-06-20 15:56:05.650305
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('28') == '255.255.255.240'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('16') == '255.255.0.0'
    assert to_netmask('8') == '255.0.0.0'
    assert to_netmask('4') == '240.0.0.0'
    assert to_netmask('2') == '192.0.0.0'
    assert to_netmask('1') == '128.0.0.0'
    assert to_netmask('0') == '0.0.0.0'



# Generated at 2022-06-20 15:56:17.033234
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('ffff::') == 'ffff::'
    assert to_ipv6_subnet('ffff::/64') == 'ffff::'
    assert to_ipv6_subnet('ffff::/64/32') == 'ffff::'
    assert to_ipv6_subnet('ffff::/64/32/') == 'ffff::'

    assert to_ipv6_subnet('ffff:ffff:ffff:ffff::') == 'ffff:ffff:ffff:ffff::'
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff::/64') == 'ffff:ffff:ffff:ffff::'
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff::/66/5') == 'ffff:ffff:ffff:ffff::'
    assert to_ipv

# Generated at 2022-06-20 15:56:24.505453
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('ff01:0000:0000:0000:0000:0000:0000:0001') == 'ff01::'
    assert to_ipv6_network('2001:0db8:0000:0000:0002:0000:0000:0001') == '2001:db8::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0000:0001') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:0001')

# Generated at 2022-06-20 15:56:33.206793
# Unit test for function to_netmask
def test_to_netmask():
    # Generate list of CIDR masks
    cidr_masks = range(0,33)
    # Generate list of expected netmasks

# Generated at 2022-06-20 15:56:43.641952
# Unit test for function to_masklen
def test_to_masklen():
    """
    Unit test for function to_masklen
    """
    masklen = to_masklen('255.255.255.255')
    assert masklen == 32, 'Unexpected mask length for 255.255.255.255'

    masklen = to_masklen('255.255.255.0')
    assert masklen == 24, 'Unexpected mask length for 255.255.255.0'

    masklen = to_masklen('255.255.0.0')
    assert masklen == 16, 'Unexpected mask length for 255.255.0.0'

    masklen = to_masklen('255.0.0.0')
    assert masklen == 8, 'Unexpected mask length for 255.0.0.0'

    masklen = to_masklen('0.0.0.0')

# Generated at 2022-06-20 15:56:50.078198
# Unit test for function to_netmask

# Generated at 2022-06-20 15:56:55.614090
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('02:42:ac:11:00:02')
    assert is_mac('02:42:ac:11:00:02')
    assert not is_mac('02:42:ac:11:00:O2')


# Generated at 2022-06-20 15:57:00.797222
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8


# Generated at 2022-06-20 15:57:05.246400
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(1) == '128.0.0.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask('32') == '255.255.255.255'



# Generated at 2022-06-20 15:57:10.711190
# Unit test for function to_netmask
def test_to_netmask():
    assert('255.255.255.0' == to_netmask(24))
    assert('255.255.255.240' == to_netmask(28))
    assert(to_netmask(32) == '255.255.255.255')
    assert(to_netmask(0) == '0.0.0.0')


# Generated at 2022-06-20 15:57:13.287252
# Unit test for function to_netmask
def test_to_netmask():
  assert to_netmask(24) == '255.255.255.0'
  assert to_netmask(30) == '255.255.255.252'


# Generated at 2022-06-20 15:57:16.809510
# Unit test for function to_netmask
def test_to_netmask():
    for masklen in range(0, 33):
        mask = str(to_netmask(masklen))
        assert is_netmask(mask)
        assert int(to_masklen(mask)) == masklen


# Generated at 2022-06-20 15:57:25.334181
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31

# Generated at 2022-06-20 15:57:33.302452
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("1:2:3:4:5:6:7:8") == "1:2:3:4::"
    assert to_ipv6_network("1:2:3:4:5:6:7::") == "1:2:3:4::"
    assert to_ipv6_network("1:2:3:4:5:6::") == "1:2:3:4::"
    assert to_ipv6_network("1:2:3:4:5::") == "1:2:3:4::"
    assert to_ipv6_network("1:2:3:4::") == "1:2:3:4::"

# Generated at 2022-06-20 15:57:36.301549
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("aa:bb:CC:DD:ee:ff")
    assert is_mac("aa:bb:cc:dd:ee:ff")
    assert not is_mac("ab:cd:ef")



# Generated at 2022-06-20 15:57:39.230211
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.a')



# Generated at 2022-06-20 15:57:49.010622
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('0.0.0.255')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('foo')
    assert not is_netmask('255.0.0')
    assert not is_netmask('255.0')
    assert not is_netmask('255')
    assert not is_netmask('255.0.0.0')



# Generated at 2022-06-20 15:57:59.330261
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("aa:bb:cc:dd:ee:ff") is True
    assert is_mac("AA:BB:CC:DD:EE:FF") is True
    assert is_mac("aa-bb-cc-dd-ee-ff") is True
    assert is_mac("AA-BB-CC-DD-EE-FF") is True
    assert is_mac("aa:bb:cc:dd:ee:") is False
    assert is_mac("AA:BB:CC:DD:EE:") is False
    assert is_mac(":aa:bb:cc:dd:ee:ff") is False
    assert is_mac(":AA:BB:CC:DD:EE:FF") is False
    assert is_mac("aa:bb:cc:dd:ee:ff:") is False

# Generated at 2022-06-20 15:58:06.669589
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') != 23
    assert to_masklen('255.255.255.128') != 24
    assert to_masklen('255.255.255.255') != 31


# Generated at 2022-06-20 15:58:09.742860
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.0.0') == '16'
    assert to_netmask('255.255.255.248') == '29'
    assert to_netmask('255.255.255.254') == '31'
    assert to_netmask('255.255.255.255') == '32'



# Generated at 2022-06-20 15:58:16.221332
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:23:45:67:89:ab')
    assert is_mac('01-23-45-67-89-ab')
    assert is_mac('0123.4567.89ab')
    assert is_mac('0123456789ab')
    assert is_mac('0123456789AB')
    assert is_mac('0:1:2:3:4:5:6:7:8:9:a:b:c:d:e:f')
    assert is_mac('0-1-2-3-4-5-6-7-8-9-a-b-c-d-e-f')
    assert not is_mac('gg:gg:gg:gg:gg:gg')
    assert not is_mac('gggggggggggg')

# Generated at 2022-06-20 15:58:26.861297
# Unit test for function is_mac
def test_is_mac():
    # Standard MAC
    assert is_mac('00:11:22:33:44:55') is True
    assert is_mac('00-11-22-33-44-55') is True
    assert is_mac('00:11:22:33:44:66') is True
    assert is_mac('00-11-22-33-44-66') is True
    assert is_mac('AA-BB-CC-DD-EE-FF') is True
    # Failed MACs
    assert is_mac('00') is False
    assert is_mac('00:11:22:33:44:5') is False
    assert is_mac('00-11-22-33-44:55') is False
    assert is_mac('00-11-22-33-44-5') is False

# Generated at 2022-06-20 15:58:33.433597
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('A1:B2:C3:D4:E5:F6')
    assert is_mac('a1:b2:c3:d4:e5:f6')
    assert is_mac('a1-b2-c3-d4-e5-f6')
    assert not is_mac('AA:BB:CC:DD:EE')
    assert not is_mac('AA-BB-CC-DD-EE')
    assert not is_mac('AA:BB:CC:DD:EE:FF:11')
    assert not is_mac('AA-BB-CC-DD-EE-FF-11')
    assert not is_mac('g1-b2-c3-d4-e5-f6')

# Generated at 2022-06-20 15:58:43.319294
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('172.16.27.173', '24') == '172.16.27.0/24'
    assert to_subnet('172.16.27.173', '255.255.255.0') == '172.16.27.0/24'
    assert to_subnet('fe80::226:2dff:fe6e:a6d0', '64') == 'fe80::/64'
    assert to_subnet('fe80::226:2dff:fe6e:a6d0', 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:0') == 'fe80::/64'
    assert to_subnet('fe80::226:2dff:fe6e:a6d0', 'ffff:ffff:ffff:ffff::') == 'fe80::/64'

# Generated at 2022-06-20 15:58:54.174917
# Unit test for function is_mac
def test_is_mac():
    # Valid MAC addresses
    assert is_mac('00:00:00:00:00:00')
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('01-23-45-67-89-ab')
    assert is_mac('cd:ef:ab:cd:ef:ab')

    # Invalid MAC address
    assert not is_mac('AA-BB-CC')
    assert not is_mac('AA:BB:CC:DD:EE')
    assert not is_mac('AA:BB:CC:DD:EE')
    assert not is_mac('AA:BB:CC:DD:EE')
    assert not is_mac('AA:BB:CC:DD:EE:GG:HH')
    assert not is_mac('AA:BB:CC:DD:EE:FF:HH')

# Generated at 2022-06-20 15:59:04.936285
# Unit test for function to_subnet

# Generated at 2022-06-20 15:59:18.010283
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(25) == '255.255.255.128'
    assert to_netmask(30) == '255.255.255.252'



# Generated at 2022-06-20 15:59:20.078386
# Unit test for function to_bits
def test_to_bits():
    nets = ['255.255.255.0', '255.0.0.0']
    for net in nets:
        assert len(to_bits(net)) == 32



# Generated at 2022-06-20 15:59:29.879291
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(23) == '255.255.254.0'
    assert to_netmask(22) == '255.255.252.0'
    assert to_netmask(21) == '255.255.248.0'
    assert to_netmask(20) == '255.255.240.0'
    assert to_netmask(19) == '255.255.224.0'
    assert to_netmask(18) == '255.255.192.0'
    assert to_netmask(17) == '255.255.128.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(15) == '255.254.0.0'

# Generated at 2022-06-20 15:59:33.423963
# Unit test for function is_mac
def test_is_mac():
    valid_mac = '00:0C:29:8D:1B:8F'
    assert is_mac(valid_mac) is True, "Valid MAC Address not found"

    invalid_mac = 'test-test-test'
    assert is_mac(invalid_mac) is False, "Invalid MAC Address found as valid"

# Generated at 2022-06-20 15:59:39.058605
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31


# Generated at 2022-06-20 15:59:43.908320
# Unit test for function to_bits
def test_to_bits():
    tests = (
        ('255.255.255.0', '11111111111111111111111100000000'),
        ('255.255.255.128', '11111111111111111111111110000000'),
        ('255.0.0.0', '11111111000000000000000000000000'),
        ('255.128.0.0', '111111100000000000000111000000000'),
    )

    for input, output in tests:
        assert to_bits(input) == output



# Generated at 2022-06-20 15:59:45.647272
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.240') == '11111111111111111111111111110000'



# Generated at 2022-06-20 15:59:48.214756
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'


# Unit tests for function to_netmask

# Generated at 2022-06-20 15:59:55.149301
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:1200::1234') == '2001:db8:1200::'
    assert to_ipv6_subnet('2001:db8:1200:abcd::1234') == '2001:db8:1200:abcd::'
    assert to_ipv6_subnet('2001:db8:1200:abcd::1234:56ab') == '2001:db8:1200:abcd::'
    assert to_ipv6_subnet('2001:db8:1200') == '2001:db8:1200::'
    assert to_ipv6_subnet('2001:db8:1200:abcd') == '2001:db8:1200:abcd::'

# Generated at 2022-06-20 16:00:04.636007
# Unit test for function is_masklen
def test_is_masklen():

    assert is_masklen('0')
    assert is_masklen('1')
    assert is_masklen('2')
    assert is_masklen('3')
    assert is_masklen('4')
    assert is_masklen('5')
    assert is_masklen('6')
    assert is_masklen('7')
    assert is_masklen('8')
    assert is_masklen('9')
    assert is_masklen('10')
    assert is_masklen('11')
    assert is_masklen('12')
    assert is_masklen('13')
    assert is_masklen('14')
    assert is_masklen('15')
    assert is_masklen('16')
    assert is_masklen('17')
    assert is_masklen('18')
    assert is_masklen('19')

# Generated at 2022-06-20 16:00:18.711350
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fd2a:3eba:3e82:c8a0::82e7:c75:d96a') == 'fd2a:3eba:3e82:c8a0::'


# Generated at 2022-06-20 16:00:22.472939
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:23:45:67:89:ab')
    assert is_mac('01-23-45-67-89-ab')
    assert is_mac('0123.4567.89ab')
    assert is_mac('0123456789ab')
    assert not is_mac('abcdef:ghijkl:mnopqr')

# Generated at 2022-06-20 16:00:26.136953
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.50', '255.255.255.0') == '10.0.0.0/24'
    assert to_subnet('10.0.0.50', 24) == '10.0.0.0/24'

# Generated at 2022-06-20 16:00:35.300792
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.255.254.0') is True
    assert is_netmask('255.255.252.0') is True
    assert is_netmask('255.255.248.0') is True
    assert is_netmask('255.255.240.0') is True
    assert is_netmask('255.255.224.0') is True
    assert is_netmask('255.255.192.0') is True
    assert is_netmask('255.255.128.0') is True
    assert is_netmask('255.255.0.0') is True
    assert is_netmask('255.254.0.0') is True
    assert is_netmask('255.252.0.0') is True
   

# Generated at 2022-06-20 16:00:44.292380
# Unit test for function is_mac
def test_is_mac():
    assert(is_mac('aa:bb:cc:dd:ee:ff') == True)
    assert(is_mac('aa-bb-cc-dd-ee-ff') == True)
    assert(is_mac('aabbccddeeff') == False)
    assert(is_mac('AA-BB-CC-DD-EE-FF') == True)
    assert(is_mac('AA:BB:CC:DD:EE:ff') == True)
    assert(is_mac('aa:bb:cc:dd:ee:gg') == False)
    assert(is_mac('aa:bb:cc:dd:ee:fg') == False)
    assert(is_mac('aa:bb:cd:dd:ee:fg') == False)
    assert(is_mac('aabbccddeeff') == False)

# Generated at 2022-06-20 16:00:51.993734
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask(23) == '255.255.254.0'
    assert to_netmask(26) == '255.255.255.192'
    assert to_netmask(30) == '255.255.255.252'
    assert to_netmask(32) == '255.255.255.255'



# Generated at 2022-06-20 16:00:59.399361
# Unit test for function to_subnet
def test_to_subnet():
    # check valid subnet - dotted notation
    assert (to_subnet('1.2.3.4', '255.255.255.0') == '1.2.3.0/24')
    # check valid subnet - cidr notation
    assert (to_subnet('1.2.3.4', '24') == '1.2.3.0/24')
    # check valid subnet - dotted and cidr notation
    assert (to_subnet('1.2.3.4', '24', True) == '1.2.3.0 255.255.255.0')
    # check invalid subnet - dotted notation
    assert (to_subnet('1.2.3.4', 'a.b.c.d') is None)
    # check invalid subnet - cidr notation

# Generated at 2022-06-20 16:01:09.624885
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:::8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:ffff:ffff:ffff') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:85a3::8a2e:0370:7334') == '2001:db8:85a3::'

# Generated at 2022-06-20 16:01:12.144245
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('-1')


# Generated at 2022-06-20 16:01:16.135384
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == "255.255.255.0"
    assert to_netmask(16) == "255.255.0.0"
    assert to_netmask(8) == "255.0.0.0"
    assert to_netmask(0) == "0.0.0.0"



# Generated at 2022-06-20 16:01:45.369743
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('-1.0.0.255') is False
    assert is_netmask('255.255.255.x') is False
    assert is_netmask('255.255.255') is False
    assert is_netmask('255.555.255.255') is False
    assert is_netmask('256.255.255.255') is False



# Generated at 2022-06-20 16:01:49.088512
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.254.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.0')
    assert not is_netmask('256.255.255.0')


# Generated at 2022-06-20 16:01:55.715351
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('22:33:44:11:22:33')
    assert is_mac('22:33:44:11:22:33/24')
    assert is_mac('22:33:44:11:22:33/24')
    assert is_mac('22:33:44:11:22:33/255:255:255:0')
    assert is_mac('22:33:44:11:22:33/24')
    assert is_mac('22-33-44-11-22-33')
    assert is_mac('22-33-44-11-22-33')
    assert is_mac('22-33-44-11-22-33/24')
    assert is_mac('22-33-44-11-22-33/24')

# Generated at 2022-06-20 16:02:06.738505
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:00:00:00:00')
    assert is_mac('ff:ff:ff:ff:ff:ff')
    assert is_mac('01-23-45-67-89-ab')
    assert is_mac('01:23:45:67:89:ab')
    assert is_mac('ab:cd:ef:ab:cd:ef')
    assert not is_mac('')
    assert not is_mac('notamac')
    assert not is_mac('00-00-a0-00-00-00')
    assert not is_mac('a0:00:00:00:00:00')
    assert not is_mac('not:a:mac')
    assert not is_mac('00-00-00-00-00-00-00')
    assert not is_

# Generated at 2022-06-20 16:02:11.546933
# Unit test for function is_masklen
def test_is_masklen():
    # Test masklen is valid
    assert is_masklen('8') == True
    assert is_masklen('24') == True
    assert is_masklen('0') == True
    assert is_masklen('32') == True

    # Test masklen is invalid
    assert is_masklen('-1') == False
    assert is_masklen('33') == False
    assert is_masklen('8.8.8') == False


# Generated at 2022-06-20 16:02:16.785257
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('1.1.1.1') == 0



# Generated at 2022-06-20 16:02:25.239013
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(18) == '255.255.192.0'
    assert to_netmask(20) == '255.255.240.0'
    assert to_netmask(21) == '255.255.248.0'
    assert to_netmask(22) == '255.255.252.0'
    assert to_netmask(23) == '255.255.254.0'
    assert to_netmask(17) == '255.255.128.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(15) == '255.254.0.0'

# Generated at 2022-06-20 16:02:29.261373
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("00:11:22:33:44:55")
    assert is_mac("00-11-22-33-44-55")
    assert not is_mac("00:11:22:33:44:5")
    assert not is_mac("00:11:22:33:44:5G")

# Generated at 2022-06-20 16:02:34.679201
# Unit test for function to_netmask
def test_to_netmask():
    assert(to_netmask(24) == '255.255.255.0')
    assert(to_netmask(27) == '255.255.255.224')

# Generated at 2022-06-20 16:02:41.687218
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('23') == '255.255.254.0'
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('17') == '255.255.128.0'
    assert to_netmask('255.255.224.0') == '19'
    assert to_netmask('255.255.255.192') == '26'


# Generated at 2022-06-20 16:03:36.711411
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('fe80::f816:3eff:feb1:67cf') == 'fe80::'
    assert to_ipv6_subnet('fe80::') == 'fe80::'
    assert to_ipv6_subnet('2001:db8::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8::') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:0:f101::1') == '2001:db8::'
    assert to_ipv6_subnet('2001:0db8:0:f101::') == '2001:db8::'

# Generated at 2022-06-20 16:03:43.159858
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', '255.255.255.0') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24') == '192.168.1.0/24'
    assert to_subnet('192.168.1.1', '24', True) == '192.168.1.0 255.255.255.0'

# Generated at 2022-06-20 16:03:51.920099
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('1:2:3:4::') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8/64') == '1:2:3:4::'

# Generated at 2022-06-20 16:04:00.448767
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    test_addr = 'fc01::1'
    assert to_ipv6_network(test_addr) == 'fc01::'

    test_addr = 'fc00:0:0:0:0:0:0:0'
    assert to_ipv6_network(test_addr) == 'fc00:0:0:0::'

    test_addr = '2001:0db8:85a3:0000:1319:8a2e:0370:7344'
    assert to_ipv6_network(test_addr) == '2001:db8:85a3:0:0:0:0:'

    test_addr = '2a03:2880:2130:cf05:face:b00c::1'

# Generated at 2022-06-20 16:04:02.736689
# Unit test for function to_bits
def test_to_bits():
    assert('11111111' == to_bits('255.0.0.0'))
    assert('11111111000000000000000000000000' == to_bits('255.0.0.0'))


# Generated at 2022-06-20 16:04:08.788623
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('11:22:33:aa:bb:cc')
    assert is_mac('11-22-33-aa-bb-cc')
    assert is_mac('11:22:33:aa:bb:cc')
    assert is_mac('11-22:33:aa:bb:cc')
    assert is_mac('11:22:33:aa:bb:cc')
    assert is_mac('11-22-33:aa:bb:cc')
    assert is_mac('11-22-33-aa:bb:cc')
    assert is_mac('11-22-33-aa-bb:cc')
    assert is_mac('11-22-33-aa-bb-cc')
    assert is_mac('11:22:33:AA:bb:CC')

# Generated at 2022-06-20 16:04:21.237792
# Unit test for function is_mac
def test_is_mac():
    try:
        assert is_mac('01-23-45-67-AB-CD')
    except AssertionError:
        print("MAC validation failure for MAC with dashes")
    try:
        assert is_mac('01:23:45:67:AB:CD')
    except AssertionError:
        print("MAC validation failure for MAC with colons")
    try:
        assert not is_mac('1234.5678.9ABC')
    except AssertionError:
        print("MAC validation failure for MAC with invalid characters")
    try:
        assert not is_mac('01-23-45-67-AB-CD-EF')
    except AssertionError:
        print("MAC validation failure for MAC with too many characters")