

# Generated at 2022-06-20 15:54:30.708836
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("52:54:00:96:86:29")
    assert not is_mac("52:54:00:96:86")
    assert not is_mac("52:54:00:96:86:ZZ")

# Generated at 2022-06-20 15:54:37.942647
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.-1')
    assert not is_netmask('255.255.255.3')
    assert not is_netmask('255.255.255.01')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.128.0.0')



# Generated at 2022-06-20 15:54:40.009629
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-20 15:54:44.415935
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert '2001:db8:0:0:0:' == to_ipv6_subnet(addr='2001:db8::1')
    assert '2001:db8:0:0:0:0:0:0:' == to_ipv6_subnet(addr='2001:db8:0:0:0:0:0:1')


# Unit tests for function to_ipv6_network

# Generated at 2022-06-20 15:54:49.677579
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(27) == True
    assert is_masklen("27") == True
    assert is_masklen(33) == False
    assert is_masklen("33") == False
    assert is_masklen("33F") == False
    assert is_masklen("") == False
    assert is_masklen("33.00.0") == False
    assert is_masklen("33.0.0.0") == False


# Generated at 2022-06-20 15:54:54.630383
# Unit test for function to_netmask
def test_to_netmask():
    """ to_netmask() unit tests """
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(0) == '0.0.0.0'



# Generated at 2022-06-20 15:54:58.847080
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.128.0') == 17
    assert to_masklen('255.255.255.0') == 24



# Generated at 2022-06-20 15:55:01.021797
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-20 15:55:07.833809
# Unit test for function to_subnet
def test_to_subnet():
    try:
        assert to_subnet('1.1.1.0', '8') == '1.0.0.0/8'
        assert to_subnet('1.1.1.0', '255.0.0.0', True) == '1.0.0.0 255.0.0.0'
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-20 15:55:17.716449
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.0.0.0') == '111111110000000000000000'
    assert to_bits('255.255.0.0') == '111111111111111100000000'
    assert to_bits('255.255.255.0') == '111111111111111111111111'
    assert to_bits('255.255.255.240') == '111111111111111111110000'
    assert to_bits('255.255.255.252') == '111111111111111111111100'
    assert to_bits('255.255.255.254') == '111111111111111111111110'
    assert to_bits('255.255.255.255') == '111111111111111111111111'

# Generated at 2022-06-20 15:55:30.552130
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.128.0')
    assert not is_netmask('255.255.255.254')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('')



# Generated at 2022-06-20 15:55:42.165221
# Unit test for function to_masklen
def test_to_masklen():
    # Test for valid masklen numbers
    for i in range(0, 33):
        assert i == to_masklen(to_netmask(i))

    # Test for invalid masklen numbers
    for i in range(-1, -32, -1):
        try:
            to_masklen(to_netmask(i))
        except:
            pass
        else:
            assert False
    for i in range(33, 64):
        try:
            to_masklen(to_netmask(i))
        except:
            pass
        else:
            assert False
    for i in range(64, 128):
        try:
            to_masklen(to_netmask(i))
        except:
            pass
        else:
            assert False


# Generated at 2022-06-20 15:55:50.496870
# Unit test for function to_masklen
def test_to_masklen():
    """ Return True on success or False on failure """
    netmasks = dict(
        netmask1='255.255.255.0',
        netmask2='255.255.0.0',
        netmask3='255.0.0.0',
        netmask4='0.0.0.0',
        netmask5='255.255.255.255',
    )
    for name, netmask in netmasks.items():
        if to_masklen(netmask) != netmasks[name]:
            raise AssertionError('%s netmask mismatch' % name)
    return True

# Generated at 2022-06-20 15:55:57.583279
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334/64') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334/ffff:ffff:ffff::') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001::85a3:0:0:8a2e:370:7334') == '2001::85a3::'

# Generated at 2022-06-20 15:56:07.224132
# Unit test for function to_subnet
def test_to_subnet():
    print('Checking conversion of netmask-style subnet(s) to CIDR-style subnet(s)...')

# Generated at 2022-06-20 15:56:11.849098
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen("32") is True
    assert is_masklen("1") is True
    assert is_masklen("a") is False
    assert is_masklen("-1") is False
    assert is_masklen("33") is False
    assert is_masklen(32) is True


# Generated at 2022-06-20 15:56:22.033065
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('a0:d3:7a:2a:1e:7f') == True
    assert is_mac('a0-d3-7a-2a-1e-7f') == True
    assert is_mac('a0d37a2a1e7f') == False
    assert is_mac('a0:a:a:a:a:a') == True
    assert is_mac('a0:d3:7a:2a:1e') == False
    assert is_mac('a0:d3:7a:2a:1e:7f:aa') == False
    assert is_mac('a0:d3:7a:2a:1e:7') == False

# Generated at 2022-06-20 15:56:30.659009
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert is_mac('00-11-22-33-44-55')
    assert is_mac('0011.2233.4455')
    assert is_mac('00:11:22:33:44:5A')
    assert not is_mac('00-11-22-33-44-55-66')
    assert not is_mac('00:11:22:33:44:55:66')
    assert not is_mac('00:11:22:33:44:55:66:77')
    assert not is_mac('0011.2233.4455.6677')


# Generated at 2022-06-20 15:56:35.873800
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::1') == '2001:db8:::'
    assert to_ipv6_network('2001:db8:0:1:1:1:1:1') == '2001:db8:::'
    assert to_ipv6_network('1:1:1:1:1:1:1:1') == '1:::'
    assert to_ipv6_network('::1') == ':::'


# Generated at 2022-06-20 15:56:37.591905
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-20 15:56:44.382198
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2601:9:4f81:9700:face:b00c::1') == '2601:9:4f81:9700::'
    assert to_ipv6_network('2001:4860:4860::8888') == '2001:4860:4860::'

# Generated at 2022-06-20 15:56:48.321094
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    test_addr = 'fe80::2acf:e9ff:fee9:f9dd'

    assert to_ipv6_network(test_addr) == 'fe80::'

# Generated at 2022-06-20 15:56:50.937323
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:8:4:2:2:2:1') == '2001:db8:8:4::'

# Generated at 2022-06-20 15:56:54.368630
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.128.0.0') == 9



# Generated at 2022-06-20 15:57:00.997435
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen("20")
    assert is_masklen("32")
    assert is_masklen("0")
    assert is_masklen("01")
    assert is_masklen("001")
    assert not is_masklen("0x")
    assert not is_masklen("hello")
    assert not is_masklen("-1")
    assert not is_masklen("33")


# Generated at 2022-06-20 15:57:05.123409
# Unit test for function to_bits
def test_to_bits():
    netmask = '255.255.255.0'
    expected_result = '11111111111111111111111100000000'
    result = to_bits(netmask)
    assert result == expected_result, "Expected %s, got %s" % (expected_result, result)


# Generated at 2022-06-20 15:57:12.638855
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'



# Generated at 2022-06-20 15:57:14.379278
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24

# Generated at 2022-06-20 15:57:22.915406
# Unit test for function to_bits
def test_to_bits():
    assert '00000001' == to_bits('1.0.0.0')
    assert '00000010' == to_bits('128.0.0.0')
    assert '00000011' == to_bits('192.0.0.0')
    assert '00000100' == to_bits('224.0.0.0')
    assert '00000101' == to_bits('240.0.0.0')
    assert '00000110' == to_bits('248.0.0.0')
    assert '00000111' == to_bits('252.0.0.0')
    assert '00001000' == to_bits('254.0.0.0')
    assert '00001001' == to_bits('255.0.0.0')



# Generated at 2022-06-20 15:57:32.222881
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::6076:dd22:1a0c:9d48') == 'fe80::'
    assert to_ipv6_network('fe80::f092:5310:1a0c:9d48') == 'fe80::'
    assert to_ipv6_network('fe80::f092:5310:1a0c:9d48/64') == 'fe80::'
    assert to_ipv6_network('2001:4898:28:10:201:1ff:fe24:d52a') == '2001:4898:28:10::'
    assert to_ipv6_network('2001:4898:28:10:201:1ff:fe24:d52a/48') == '2001:4898:28::'

# Generated at 2022-06-20 15:57:45.766138
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'



# Generated at 2022-06-20 15:57:51.010972
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(22) == '255.255.252.0'
    assert to_netmask(29) == '255.255.255.248'
    assert to_netmask(32) == '255.255.255.255'



# Generated at 2022-06-20 15:57:59.476556
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.255.255.255') == '32'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'

# Generated at 2022-06-20 15:58:10.444399
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-20 15:58:22.973678
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    subnets = [
        ('2001:db8::/32', '2001:db8::/48'),
        ('2001:db8:0:8d3:0:8a2e:70:7344/128', '2001:db8:0:8d3::/64'),
    ]
    for subnet in subnets:
        if to_ipv6_network(subnet[0]) != subnet[1]:
            print("to_ipv6_network(%s) should be %s, but is %s" % (subnet[0], subnet[1], to_ipv6_network(subnet[0])))

    # Test IPv4 in IPv6

# Generated at 2022-06-20 15:58:30.460333
# Unit test for function to_masklen
def test_to_masklen():
    ''' Test to_masklen function '''
    # Masklen to netmask test
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.0.0') == 16

# Generated at 2022-06-20 15:58:35.854524
# Unit test for function to_masklen
def test_to_masklen():
    try:
        to_masklen('255.255.255.256')
        assert False
    except ValueError:
        assert True

    try:
        to_masklen('255.255.255.255')
    except ValueError:
        assert False

    try:
        to_masklen('255.255.255.254')
    except ValueError:
        assert False

# Generated at 2022-06-20 15:58:41.112678
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('255.255.255.0') == '255.255.255.0'
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('255.255.255.255') == '255.255.255.255'



# Generated at 2022-06-20 15:58:48.566503
# Unit test for function to_bits
def test_to_bits():
    x = []
    if to_bits('255.255.255.0') != '11111111111111111111111100000000':
        x.append("to_bits('255.255.255.0') != '11111111111111111111111100000000'")

    if to_bits('255.255.254.0') != '11111111111111111111111110000000':
        x.append("to_bits('255.255.254.0') != '11111111111111111111111110000000'")

    if to_bits('255.255.252.0') != '11111111111111111111111111000000':
        x.append("to_bits('255.255.252.0') != '11111111111111111111111111000000'")


# Generated at 2022-06-20 15:58:55.661417
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('52:54:00:9a:e8:f8')
    assert is_mac('52:54:00:9a:e8:f8')
    assert not is_mac('52:54:00:9a:e8:f8:8')
    assert not is_mac('52-54-00-9a-e8-f8')  # not supported by network module
    assert not is_mac('52:54:00:9a:e8:f')
    assert not is_mac('52:54:00:9a:e8')
    assert not is_mac('52:54:00:9a:e')
    assert not is_mac('52:54:00:9a:')
    assert not is_mac('52:54:00:9a')

# Generated at 2022-06-20 15:59:17.890265
# Unit test for function is_mac
def test_is_mac():
    valid_macs = [
        '01:23:45:67:89:ab',
        '01-23-45-67-89-ab',
        '0123.4567.89ab',
        '0123456789ab',
        '01:23:45:67:89:AB'
    ]


# Generated at 2022-06-20 15:59:22.556880
# Unit test for function to_netmask
def test_to_netmask():
    from math import log

    for i in range(1, 33):
        mask = to_netmask(i)
        assert is_netmask(mask)
        assert to_masklen(mask) == i
        assert int(log(2**32 - 2**(32-i), 2)) + 1 == i

    try:
        to_netmask('invalid')
    except ValueError as e:
        assert 'invalid value for masklen' in str(e)



# Generated at 2022-06-20 15:59:32.548560
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111110000000'
    assert to_bits('255.255.254.0') == '11111111111111111111111111000000'
    assert to_bits('255.255.252.0') == '11111111111111111111111111100000'
    assert to_bits('255.255.240.0') == '11111111111111111111111111110000'
    assert to_bits('255.255.224.0') == '11111111111111111111111111111000'
    assert to_bits('255.255.192.0') == '11111111111111111111111111111100'
    assert to_bits('255.255.128.0') == '11111111111111111111111111111110'

# Generated at 2022-06-20 15:59:40.578719
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.128') \
        == '11111111111111111111111110000000'
    assert to_bits('255.255.255.0') \
        == '11111111111111111111111100000000'
    assert to_bits('128.0.0.0') \
        == '10000000000000000000000000000000'
    assert to_bits('255.128.0.0') \
        == '11111111100000000000000000000000'
    assert to_bits('255.255.255.255') \
        == '11111111111111111111111111111111'
    assert to_bits('255.255.255.254') \
        == '11111111111111111111111111111110'
    assert to_bits('255.255.255.252') \
        == '11111111111111111111111111111100'


# Unit

# Generated at 2022-06-20 15:59:52.651501
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-20 16:00:03.208214
# Unit test for function to_ipv6_subnet

# Generated at 2022-06-20 16:00:07.945402
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.a')
    assert not is_netmask('255.255.255.')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.455')
    assert not is_netmask('255.255')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255.a.0')

# Generated at 2022-06-20 16:00:13.511022
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.2555')
    assert not is_netmask('255.255.255.255.')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.255.255')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255')
    assert not is_netmask('255')
    assert not is_netmask('')
    assert not is_netmask(None)


# Generated at 2022-06-20 16:00:20.754797
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    ipv6_addr = '2001:db8:1234:5678:9abc:def0:0000:0123'
    ipv6_prefix = ipv6_addr.split('::')[0]
    ipv6_suffix = ipv6_addr.split('::')[1]
    ipv6_network = to_ipv6_subnet(ipv6_addr)

    assert ipv6_network == '%s::' % (ipv6_prefix)



# Generated at 2022-06-20 16:00:27.256312
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # https://tools.ietf.org/html/rfc4291#section-2.5.5.2
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1') == '2001:db8:0:1::'

    # https://tools.ietf.org/html/rfc2373#section-2.5.2
    # https://tools.ietf.org/html/rfc5952#section-4.2
    assert to_ipv6_subnet('2001:db8:0:0:0:0:2:1') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:1:1:1:1:1') == '2001:db8::'
    assert to_ipv

# Generated at 2022-06-20 16:00:51.372376
# Unit test for function to_bits
def test_to_bits():
    """ to_bits unit test """
    assert to_bits('255.255.255.0') == '11111111.11111111.11111111.00000000'

# Generated at 2022-06-20 16:00:57.350675
# Unit test for function to_bits
def test_to_bits():
    masked_ips = [('10.1.1.1', '255.255.255.0', '1010000000000000010000000001'),
                  ('10.1.1.1', '0.0.0.0', '00000000000000000000000000000000'),
                  ('10.1.1.1', '255.255.255.255', '1010000000000000010000000001')]
    for (ip, netmask, bits) in masked_ips:
        assert to_bits(to_subnet(ip, netmask, True).split()[0]) == bits


# Generated at 2022-06-20 16:01:04.648777
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8:cafe::17') == '2001:db8:cafe::'
    assert to_ipv6_network('2001:db8:cafe:fefe::17') == '2001:db8:cafe:fefe::'
    assert to_ipv6_network('2001:db8:cafe:fefe:beef:dead:c0de:17') == '2001:db8:cafe:fefe::'

# Generated at 2022-06-20 16:01:14.300850
# Unit test for function to_subnet
def test_to_subnet():
    ok = dict()
    ok['ipv4'] = [
        '1.2.3.4/32',
        '1.2.3.4/255.255.255.255',
    ]
    ok['ipv6'] = [
        '1:2:3:4:5:6:7:8/128',
        '1:2:3:4:5:6:7:8/ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff',
    ]
    not_ok = dict()
    not_ok['ipv4'] = [
        '1.2/32',
        '1.2/255.255',
        '1.2/foo',
        '1.2/0',
        '1.2/256',
    ]
    not_ok['ipv6']

# Generated at 2022-06-20 16:01:21.367057
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.0', '8') == '10.0.0.0/8'
    assert to_subnet('10.2.3.4', '8') == '10.0.0.0/8'
    assert to_subnet('10.2.3.4', 16) == '10.2.0.0/16'
    assert to_subnet('10.2.3.4', '255.255.0.0') == '10.2.0.0/16'
    assert to_subnet('10.2.3.4', '255.255.3.0') == '10.2.3.0/24'



# Generated at 2022-06-20 16:01:32.022790
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('0.255.255.255') == '00000000111111111111111111111111'
    assert to_bits('0.0.255.255') == '00000000000000001111111111111111'
    assert to_bits('0.0.0.255') == '00000000000000000000000011111111'


# Unit test to_subnet()

# Generated at 2022-06-20 16:01:39.822626
# Unit test for function to_netmask
def test_to_netmask():
    assert '255.255.255.0' == to_netmask('24')
    assert '255.255.255.0' == to_netmask('255.255.255.0')
    assert '255.255.255.0' == to_netmask('28')
    assert '255.128.0.0' == to_netmask('9')
    assert '255.0.0.0' == to_netmask('8')
    assert '128.0.0.0' == to_netmask('1')
    assert '0.0.0.0' == to_netmask('0')
    try:
        to_netmask('foo')
    except ValueError:
        pass
    else:
        assert False
    try:
        to_netmask(33)
    except ValueError:
        pass
   

# Generated at 2022-06-20 16:01:44.432665
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '111111111111111111111111100000000'
    assert to_bits('255.255.255.128') == '111111111111111111111111110000000'



# Generated at 2022-06-20 16:01:49.026889
# Unit test for function is_masklen
def test_is_masklen():
    assert not is_masklen("this is a string")
    assert not is_masklen(33)
    assert not is_masklen(-1)
    assert not is_masklen("1.1.1.1")

    assert is_masklen("32")
    assert is_masklen(32)
    assert is_masklen("0")
    assert is_masklen(0)



# Generated at 2022-06-20 16:01:52.763178
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    test_addr = 'fe80.0000.0000.0000.0204.eaff.fe9f.d800'
    expected_addr = 'fe80::204:eaff:fe9f:d800/64'
    actual_addr = to_ipv6_subnet(test_addr)

    assert (actual_addr == expected_addr)



# Generated at 2022-06-20 16:02:39.542059
# Unit test for function to_subnet

# Generated at 2022-06-20 16:02:45.322922
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'
    assert to_bits('255.0.0.0') == '11111111000000000000000000000000'
    assert to_bits('127.0.0.1') == '01111111000000000000000000000001'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'



# Generated at 2022-06-20 16:02:54.374313
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0DB8:AC10:FE01:0000:0000:0000:0000') == '2001:db8:ac10:fe01::'
    assert to_ipv6_subnet('2001::AC10:FE01:0000:0000:0000:0000') == '2001::'
    assert to_ipv6_subnet('2001:0DB8:AC10:FE01:0000:0000:0000:0000/64') == '2001:db8:ac10:fe01::'
    assert to_ipv6_subnet('2001::AC10:FE01:0000:0000:0000:0000/64') == '2001::'

# Generated at 2022-06-20 16:03:03.872424
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-20 16:03:10.347402
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32) == True
    assert is_masklen(8) == True
    assert is_masklen(0) == True
    assert is_masklen(33) == False
    assert is_masklen(64) == False
    assert is_masklen('8') == True
    assert is_masklen('0') == True
    assert is_masklen('33') == False
    assert is_masklen('64') == False
    assert is_masklen('a') == False
    assert is_masklen('8a') == False


# Generated at 2022-06-20 16:03:20.084497
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::3') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0001::3') == '2001:db8:0001::'
    assert to_ipv6_network('2001:db8:0001:1a00::3') == '2001:db8:0001:1a00::'
    assert to_ipv6_network('2001:db8:0001:1a00:0001:0001::3') == '2001:db8:0001:1a00:0001:0001::'
    assert to_ipv6_network('2001:db8::3:3') == '2001:db8::3:'

# Generated at 2022-06-20 16:03:29.872874
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.254.0.0') == 15
    assert to_masklen('255.252.0.0') == 14
    assert to_masklen('255.248.0.0') == 13
    assert to_masklen('255.240.0.0') == 12
    assert to_masklen('255.224.0.0') == 11
    assert to_masklen('255.192.0.0') == 10
    assert to_masklen('255.128.0.0') == 9
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('254.0.0.0') == 7
   

# Generated at 2022-06-20 16:03:40.752592
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:02:03:04:05:06')
    assert is_mac('01-02-03-04-05-06')
    assert is_mac('01:02:03:04:05:0A')
    assert is_mac('01-02-03-04-05-0A')
    assert not is_mac('01-02-03-04-05-0A:A')
    assert not is_mac('01:02:03:04:05-06')
    assert not is_mac('01-02-03-04-05-06-07')
    assert not is_mac('01:02:03:04:05:06:07')
    assert not is_mac('01:02:03:04:05:A0')

# Generated at 2022-06-20 16:03:48.063364
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Parse with no ::
    assert to_ipv6_subnet('0012:0034:4ba4:0001:0000:4321:0000:0000') == '0012:0034:4ba4:0001::'
    assert to_ipv6_subnet('0012:0034:4ba4:0001:0000:4321:0000:0000/64') == '0012:0034:4ba4:0001::'

    # Parse with a ::
    assert to_ipv6_subnet('0012:0034:4ba4:0001:0000:4321::') == '0012:0034:4ba4:0001::'

# Generated at 2022-06-20 16:03:51.831703
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert(to_ipv6_network("fe80::1") == "fe80:"), "Network address should not include host address"
    assert(to_ipv6_network("fe80:ffff:ffff:ffff:ffff:ffff:ffff:ffff") == "fe80:ffff:ffff:ffff::"), "Network address should not include host address"
