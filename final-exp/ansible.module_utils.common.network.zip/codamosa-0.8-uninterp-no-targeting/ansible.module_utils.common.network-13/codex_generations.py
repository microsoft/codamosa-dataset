

# Generated at 2022-06-20 15:54:39.459070
# Unit test for function to_netmask

# Generated at 2022-06-20 15:54:43.730457
# Unit test for function to_masklen

# Generated at 2022-06-20 15:54:49.974760
# Unit test for function to_subnet
def test_to_subnet():
    assert "1.1.1.1 255.255.255.0" == to_subnet("1.1.1.1", "255.255.255.0", True)
    assert "1.1.1.0/24" == to_subnet("1.1.1.1", "255.255.255.0")
    assert "1:2:3:4:5:6:7:8/64" == to_subnet("1:2:3:4:5:6:7:8", "ff:ff:ff::", False)

# Generated at 2022-06-20 15:54:58.436674
# Unit test for function is_masklen
def test_is_masklen():
    # Does case of 32 fail
    assert not is_masklen(32)
    # Does case of 0 fail
    assert is_masklen(0)
    # Does case of -1 fail
    assert not is_masklen(-1)
    # Does case of 1 fail
    assert is_masklen(1)
    # Does case of b'24' fail
    assert is_masklen(b'24')
    # Does case of '24' fail
    assert is_masklen('24')
    # Does case of '1a' fail
    assert not is_masklen('1a')
    # Does case of b'1a' fail
    assert not is_masklen(b'1a')


# Generated at 2022-06-20 15:55:04.124044
# Unit test for function is_masklen
def test_is_masklen():
    assert(is_masklen('32'))
    assert(is_masklen(32))
    assert(not is_masklen('33'))
    assert(not is_masklen(33))
    assert(not is_masklen('3a'))
    assert(not is_masklen('-1'))
    assert(not is_masklen(-1))



# Generated at 2022-06-20 15:55:07.845320
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.252') == '11111111111111111111111111111100'

# Generated at 2022-06-20 15:55:19.189073
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert '::1' == to_ipv6_subnet('::1')
    assert '::1:0:0:0' == to_ipv6_subnet('::1:0:0:0')
    assert '2001:0:0:0:0:0:0:0' == to_ipv6_subnet('2001:0:0:0:0:0:0:0')
    assert '2001:0:0:0:0:0:0:0' == to_ipv6_subnet('2001:0:0:0:0:0:0:0')
    assert '2001:0:0:0:0:0:0:0' == to_ipv6_subnet('2001::')
    assert '2001:0:0:0:0:0:0:0' == to_

# Generated at 2022-06-20 15:55:27.253123
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('1.1.1.1', '255.255.255.0') == '1.1.1.0/24'
    assert to_subnet('1.1.1.1', 8, dotted_notation=True) == '1.0.0.0 255.0.0.0'
    assert to_subnet('1.1.1.1', 24) == '1.1.1.0/24'



# Generated at 2022-06-20 15:55:34.657091
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    addr = '::1/128'
    assert to_ipv6_subnet(addr) == '::'

    addr = '99fe:3ba3:ddef::1/128'
    assert to_ipv6_subnet(addr) == '99fe:3ba3:ddef::'

    addr = '99fe:3ba3:ddef::1'
    assert to_ipv6_subnet(addr) == '99fe:3ba3:ddef::'

    addr = '99fe::1/64'
    assert to_ipv6_subnet(addr) == '99fe::'

    addr = '99fe:3ba3:ddef::1/64'
    assert to_ipv6_subnet(addr) == '99fe:3ba3::'

    # Unit test for function

# Generated at 2022-06-20 15:55:42.164806
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:db8::75de:dbff:fe94:7f1e') == '2001:db8::'
    assert to_ipv6_network('2001:db8::75de:dbff:fe94:7f1e/64') == '2001:db8::'
    assert to_ipv6_network('2001:db8:a:3::75de:dbff:fe94:7f1e/64') == '2001:db8:a:3::'

# Generated at 2022-06-20 15:55:45.328499
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('24') == True
    assert is_masklen('33') == False
    assert is_masklen('one') == False


# Generated at 2022-06-20 15:55:55.443266
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::a00:27ff:fe17:fb5b/64') == 'fe80::/64'
    assert to_ipv6_network('fe80::a00:27ff:fe17:fb5b/32') == 'fe80::/32'
    assert to_ipv6_network('fe80::a00:27ff:fe17:fb5b/128') == 'fe80::a00:27ff:fe17:fb5b/128'
    assert to_ipv6_network('fe80::a00:27ff:fe17:fb5b/120') == 'fe80::/120'
    assert to_ipv6_network('fe80::a00:27ff:fe17:fb5b/112') == 'fe80::/112'

# Generated at 2022-06-20 15:56:00.020767
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('0.0.0.0') == '00000000000000000000000000000000'



# Generated at 2022-06-20 15:56:08.898967
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe01::1/64') == 'fe01::'
    assert to_ipv6_network('fe01:db8::1/64') == 'fe01:db8::'
    assert to_ipv6_network('fe01:db8:1::1/64') == 'fe01:db8:1::'
    assert to_ipv6_network('fe01:db8:1:1::1/64') == 'fe01:db8:1:1::'
    assert to_ipv6_network('fe01:db8:1:1:1::1/64') == 'fe01:db8:1:1:1::'

# Generated at 2022-06-20 15:56:20.552008
# Unit test for function to_masklen
def test_to_masklen():
    """ Unit test for function to_masklen """

    assert(to_masklen('255.255.255.0') == 24)
    assert(to_masklen('255.255.255.128') == 25)
    assert(to_masklen('192.168.0.0') == 16)
    assert(to_masklen('128.0.0.0') == 1)
    assert(to_masklen('0.0.0.0') == 0)
    assert(to_masklen('255.255.255.255') == 32)

    try:
        to_masklen('255.255')
        assert(False)
    except ValueError:
        assert(True)


# Generated at 2022-06-20 15:56:31.740480
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80::5054:ff:feb7:4c4c%4') == 'fe80::5054:ff:feb7:4c4c:'
    assert to_ipv6_network('fe80::5054:ff:feb7:4c4c') == 'fe80::5054:ff:feb7:4c4c:'
    assert to_ipv6_network('fe80::5054:ff:feb7:4c4c:') == 'fe80::5054:ff:feb7:4c4c:'
    assert to_ipv6_network('fe80::5054:ff:feb7:4c4c::') == 'fe80::5054:ff:feb7:4c4c:'
    assert to_ipv6

# Generated at 2022-06-20 15:56:35.828485
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.1.1.1', '255.255.255.0') == '10.1.1.0/24'
    assert to_subnet('10.1.1.1', '24') == '10.1.1.0/24'

# Generated at 2022-06-20 15:56:41.753116
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-20 15:56:44.796347
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(0)
    assert not is_masklen(-1)
    assert not is_masklen(33)
    assert not is_masklen("33")



# Generated at 2022-06-20 15:56:56.715021
# Unit test for function to_subnet
def test_to_subnet():
    # Test with a masklen
    assert(to_subnet('1.1.1.1', 24) == '1.1.1.0/24')
    assert(to_subnet('192.168.1.1', 30) == '192.168.1.0/30')
    assert(to_subnet('192.168.1.1', 16) == '192.168.0.0/16')

    # Test with a netmask
    assert(to_subnet('1.1.1.1', '255.255.255.0') == '1.1.1.0/24')
    assert(to_subnet('192.168.1.1', '255.255.255.252') == '192.168.1.0/30')

# Generated at 2022-06-20 15:57:08.310986
# Unit test for function to_ipv6_network

# Generated at 2022-06-20 15:57:14.379469
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('1.1.1.1.1')
    assert not is_netmask('1.1.1.1')
    assert not is_netmask('string')
    assert not is_netmask('1.1')
    assert not is_netmask('1')
    assert not is_netmask(None)



# Generated at 2022-06-20 15:57:15.824996
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('10.0.0.1', '24') == '10.0.0.0/24'

# Generated at 2022-06-20 15:57:26.488618
# Unit test for function to_netmask
def test_to_netmask():
    from ansible.module_utils.basic import AnsibleModule

    def test(masklen, netmask):
        module = AnsibleModule(argument_spec=dict())
        res = to_netmask(masklen)
        module.exit_json(**{
            'changed': True,
            'converted_value': res,
            'expected_value': netmask
        })
        return True

    masklen = {
        24: '255.255.255.0',
        26: '255.255.255.192'
    }

    passed = 0
    failed = 0
    for m, n in masklen.items():
        if test(m, n):
            passed += 1
        else:
            failed += 1


# Generated at 2022-06-20 15:57:32.513295
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('0.0.0.0')
    assert is_netmask('128.0.0.0')
    assert is_netmask('255.0.0.0')
    assert not is_netmask('0.0.0.1')
    assert not is_netmask('255.0.0.13')
    assert not is_netmask('255.255.0.0.0')


# Generated at 2022-06-20 15:57:37.574212
# Unit test for function to_netmask
def test_to_netmask():
    """ Tests our ability to convert masklens into netmasks """
    assert to_netmask('24') == '255.255.255.0'
    assert to_netmask('32') == '255.255.255.255'
    assert to_netmask('23') == '255.255.254.0'



# Generated at 2022-06-20 15:57:45.173470
# Unit test for function to_bits
def test_to_bits():
    cases = (
        [
            '255.255.255.0',
            '11111111111111111111111100000000'
        ],
        [
            '255.255.0.0',
            '11111111111111110000000000000000'
        ],
        [
            '255.0.0.0',
            '11111111000000000000000000000000'
        ],
        [
            '0.0.0.0',
            '00000000000000000000000000000000'
        ],
    )

    for netmask, bits in cases:
        assert to_bits(netmask) == bits

# Generated at 2022-06-20 15:57:51.414805
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Test with valid IPv6 addresses
    assert to_ipv6_subnet('2002:d3fe:afdc:3::1') == '2002:d3fe:afdc:3::'
    assert to_ipv6_subnet('2002:d3fe:afdc:3:230:aa5d:c955:e425') == '2002:d3fe:afdc:3::'
    # Test with invalid IPv6 addresses
    assert to_ipv6_subnet('2002:d3fe::') == '2002:d3fe::'
    assert to_ipv6_subnet('2002:d3fe:afdc::c955:e425') == '2002:d3fe:afdc::'


# Generated at 2022-06-20 15:57:59.684784
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.0.0.0')
    assert not is_netmask('255.128.0.0')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255 0 0 0')
    assert not is_netmask('netmask')
    assert not is_netmask(None)



# Generated at 2022-06-20 15:58:08.629667
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # full address
    addr = 'fe80::c903:13ff:fe04:b64e%ens192'
    expected = 'fe80::c903:13ff:fe04:'
    assert to_ipv6_network(addr) == expected, "Expected %s, got %s" % (expected, to_ipv6_network(addr))

    # partial address
    addr = 'fe80::'
    expected = 'fe80::'
    assert to_ipv6_network(addr) == expected, "Expected %s, got %s" % (expected, to_ipv6_network(addr))

# Generated at 2022-06-20 15:58:25.072998
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.10.0', '24') == '192.168.10.0/24'

    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0/24'

    assert to_subnet('100.100.100.100', '28') == '100.100.100.96/28'

    assert to_subnet('100.100.100.100', '255.255.255.240') == '100.100.100.96/28'

    assert to_subnet('2001:4860:4860::8888', '64') == '2001:4860:4860::/64'


# Generated at 2022-06-20 15:58:31.782139
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('0.0.0.0') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255') == False
    assert is_netmask('255.256.255.255') == False
    assert is_netmask('0.0.0.1') == False
    assert is_netmask('255.0.0.255') == False
    assert is_netmask('255.0.255.0') == False
    assert is_netmask('0.0.0.1') == False


# Generated at 2022-06-20 15:58:39.911836
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('0') == '0.0.0.0'
    assert to_netmask('1') == '128.0.0.0'
    assert to_netmask('2') == '192.0.0.0'
    assert to_netmask('8') == '255.0.0.0'
    assert to_netmask('16') == '255.255.0.0'
    assert to_netmask('25') == '255.255.255.128'
    assert to_netmask('32') == '255.255.255.255'



# Generated at 2022-06-20 15:58:45.232133
# Unit test for function is_mac
def test_is_mac():
    assert(is_mac("01:23:45:67:89:ab"))
    assert(is_mac("01-23-45-67-89-ab"))
    assert not (is_mac("01-23-45-67-89-z"))
    assert not (is_mac("01-23-45-67-89-z"))
    assert not (is_mac("01:23:45:67:89:ab:cd"))
    assert not (is_mac("01:23:45:67:89"))


# Generated at 2022-06-20 15:58:49.727373
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('fe:ff:ff:ff:ff:ff') == True
    assert is_mac('fe-ff-ff-ff-ff-ff') == True
    assert is_mac('feff.ffff.ffff')   == False
    assert is_mac('fe:ff:ff:gg:ff:ff') == False
    assert is_mac('fe:ff:ff:ff:ff:1g') == False
    assert is_mac('fe:ff:ff:ff:ff:')   == False
    assert is_mac('')                  == False
    return True

# Generated at 2022-06-20 15:58:55.403059
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.0.0')
    assert not is_netmask('255.0.0.0.0')
    assert not is_netmask('255.256.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('127.0.0.1')
    assert not is_netmask('foo')



# Generated at 2022-06-20 15:58:58.980867
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask(246)
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.0.0.0')



# Generated at 2022-06-20 15:59:03.254308
# Unit test for function is_masklen
def test_is_masklen():
    assert (is_masklen(32) and is_masklen(24) and is_masklen(1)), "Invalid masklen"
    assert not (is_masklen(33) and is_masklen(0) and is_masklen(-1)), "Invalid masklen"



# Generated at 2022-06-20 15:59:04.786632
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('-1') == False
    assert is_masklen('33') == False
    assert is_masklen('32') == True
    assert is_masklen('0') == True


# Generated at 2022-06-20 15:59:09.660537
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0")
    assert not is_netmask("255.255.255.0.0")
    assert not is_netmask("256.255.255.0")


# Generated at 2022-06-20 15:59:18.721192
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.0.0') == '11111111111111110000000000000000'

# Generated at 2022-06-20 15:59:29.213297
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.254.0')
    assert is_net

# Generated at 2022-06-20 15:59:30.621886
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'



# Generated at 2022-06-20 15:59:35.823169
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(25) == '255.255.255.128'
    assert to_netmask(17) == '255.255.128.0'
    assert to_netmask(12) == '255.240.0.0'


# Generated at 2022-06-20 15:59:42.577103
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('01:23:45:67:89:ab') is True
    assert is_mac('01:23:45:67:89:ab:cd:ef') is False
    assert is_mac('abcdef') is False
    assert is_mac('a1:23:45:67:89:ab') is False
    assert is_mac('01:23:45:67:89:ZZ') is False
    assert is_mac('01-23-45-67-89-ab') is True
    assert is_mac('01-23-45-67-89-ab-cd-ef') is False
    assert is_mac('a1-23-45-67-89-ab') is False

# Generated at 2022-06-20 15:59:53.087693
# Unit test for function is_mac
def test_is_mac():
    """
    Simple unit test for function is_mac.
    The following MAC addresses should be validated as True:
    00:00:00:00:00:00
    01:23:45:67:89:ab
    ab:cd:ef:00:00:11
    The following MAC addresses should be validated as False:
    00-00-00-00-00-00
    00:00:00:00:00
    00:00:00:00:00:00:00
    00:000:00:00:00:00
    00:00:00:00:00:0
    00:00:00:g0:00:00
    """
    assert(is_mac('00:00:00:00:00:00'))

# Generated at 2022-06-20 16:00:03.253148
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111110000000'
    assert to_bits('255.255.255.128') == '11111111111111111111111111000000'
    assert to_bits('255.255.255.192') == '11111111111111111111111111100000'
    assert to_bits('255.255.255.224') == '11111111111111111111111111110000'
    assert to_bits('255.255.255.240') == '11111111111111111111111111111000'
    assert to_bits('255.255.255.248') == '11111111111111111111111111111100'
    assert to_bits('255.255.255.252') == '11111111111111111111111111111110'

# Generated at 2022-06-20 16:00:08.101893
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('fe80:aaaa::1') == 'fe80:aaaa::'
    assert to_ipv6_network('fe80:aaaa:bbbb:cccc:dddd:eeee:ffff:ffff') == 'fe80:aaaa:bbbb:cccc::'
    assert to_ipv6_network('::1') == '::'
    assert to_ipv6_network('::ffff') == '::'
    assert to_ipv6_network('fe80:aaaa:bbbb:cccc:dddd:eeee:ffff:gggg') == 'fe80:aaaa:bbbb:cccc:dddd:eeee:ffff::'



# Generated at 2022-06-20 16:00:13.777677
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0:0:0:0:0:0:1') == '2001::'
    assert to_ipv6_subnet('2001:0:a:b:0:0:0:1') == '2001:0:a:b::'
    assert to_ipv6_subnet('2001:0:a:1:1:1:0:0') == '2001:0:a:1::'
    assert to_ipv6_subnet('2001:0:a:1:1:1:a:a') == '2001:0:a:1::'
    assert to_ipv6_subnet('2001:0:a:1:1:1:1:1') == '2001:0:a:1:1:1:1:0'
    assert to

# Generated at 2022-06-20 16:00:23.120995
# Unit test for function to_ipv6_network

# Generated at 2022-06-20 16:00:46.476686
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff:ffff:ffff:ffff:0000') == 'ffff:ffff:ffff:ffff::'
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff:ffff:0000:0000:0000') == 'ffff:ffff:ffff:ffff::'
    assert to_ipv6_subnet('ffff:ffff:ffff:0000:0000:0000:0000:0000') == 'ffff:ffff:ffff::'
    assert to_ipv6_subnet('ffff:ffff:0000:0000:0000:0000:0000:0000') == 'ffff:ffff::'
    assert to_ipv6_subnet('ffff:0000:0000:0000:0000:0000:0000:0000') == 'ffff::'

# Generated at 2022-06-20 16:00:56.844354
# Unit test for function to_ipv6_network
def test_to_ipv6_network():

    print("----- Testing to_ipv6_network() function ------\n")

    print("Testing to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348')...")
    if to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348') == '2001:db8:85a3:8d3::':
        print("Success! Got expected result.\n")
    else:
        print("Fail! Did not get expected result.\n")

    print("Testing to_ipv6_network('2001:db8:85a3:8d3:1319:8a2e:370:7348/64')...")

# Generated at 2022-06-20 16:01:07.875338
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network("fe80::5efe:10.0.0.4") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a00:5") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a01:5") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a02:5") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a03:5") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a04:5") == "fe80::"
    assert to_ipv6_network("fe80::5efe:a05:5") == "fe80::"


# Generated at 2022-06-20 16:01:17.169898
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('256.255.255.0')
    assert not is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.255')
    assert not is_netmask('255.255.255.255.0')

# Generated at 2022-06-20 16:01:20.487494
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('FF01::101') == 'FF01::'
    assert to_ipv6_subnet('FF01:101::') == 'FF01:101::'
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8') == '1:2:3:4::'



# Generated at 2022-06-20 16:01:31.889193
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    """
    Test IPv6 subnet addresses
    """
    # Note: Currently there is no way to run the unit tests in Ansible, so this
    # test is not being used. However, it should be possible to run unit tests
    # with py.test
    # Details: https://github.com/ansible/ansible/wiki/Ansible-and-Unit-Test
    # https://github.com/ansible/ansible/issues/20892

    # Test default host address
    assert to_ipv6_subnet('0:0:0:0:0:0:0:0') == '0:0:0:0:0:0:0:'

    # Test default host address with omitted zeros

# Generated at 2022-06-20 16:01:39.524081
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.0.0', '255.255.255.0') == '192.168.0.0/24'
    assert to_subnet('192.168.0.0', '24') == '192.168.0.0/24'
    assert to_subnet('192.168.0.0', '24', True) == '192.168.0.0 255.255.255.0'
    assert to_subnet('10.0.0.0', '255.255.192.0') == '10.0.0.0/18'
    assert to_subnet('10.0.0.0', '18') == '10.0.0.0/18'

# Generated at 2022-06-20 16:01:45.034882
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('ffff::1') == 'ffff:::'
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff') == 'ffff:ffff:ffff:::'
    assert to_ipv6_subnet('ffff:ffff:ffff:ffff:ffff:ffff:ffff:0') == 'ffff:ffff:ffff:ffff:::'
    assert to_ipv6_subnet('abcd:abcd:abcd:abcd:abcd:abcd:abcd:abcd') == 'abcd:abcd:abcd:::'
    assert to_ipv6_subnet('abcd:abcd:abcd:abcd:abcd:abcd:abcd:0') == 'abcd:abcd:abcd:abcd:::'
    assert to_

# Generated at 2022-06-20 16:01:54.489283
# Unit test for function is_netmask
def test_is_netmask():
    # Test valid netmasks
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.255.128') == True
    assert is_netmask('255.255.255.224') == True
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('255.248.0.0') == True
    assert is_netmask('255.255.255.252') == True

    # Test invalid netmasks
    assert is_netmask('2a.0.0.0') == False
    assert is_netmask('-1.0.0.0') == False
    assert is_netmask('1.2.3.4.5') == False
    assert is_netmask('255.0.0.0.0')

# Generated at 2022-06-20 16:01:57.859988
# Unit test for function to_bits
def test_to_bits():
    """ Unit test for function to_bits """
    if not to_bits('255.255.255.0') == '11111111111111111111111110000000':
        raise AssertionError('Failed to convert 255.255.255.0 mask to bits')

# Generated at 2022-06-20 16:02:42.328522
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("0a:00:00:00:00:00") == True
    assert is_mac("0a:00:00:00:00:00:00") == False
    assert is_mac("zz:00:00:00:00:00") == False


# Generated at 2022-06-20 16:02:49.485411
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(0)
    assert is_masklen(24)
    assert is_masklen(20)
    assert is_masklen(16)
    assert is_masklen(12)
    assert is_masklen(8)
    assert is_masklen(4)
    assert is_masklen(2)
    assert not is_masklen(33)
    assert not is_masklen(-1)
    assert not is_masklen(35)


# Generated at 2022-06-20 16:02:56.939445
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(32) == '255.255.255.255'
    assert to_netmask(0) != '0.0.0.1'
    assert to_netmask(1) != '255.0.0.0'
    assert to_netmask(2) != '255.255.0.0'
    assert to_netmask(3) != '255.255.255.0'
    assert to_netmask(4) != '255.255.255.255'

# Generated at 2022-06-20 16:03:07.845962
# Unit test for function to_subnet
def test_to_subnet():
    assert '192.168.1.0/24' == to_subnet('192.168.1.1', '255.255.255.0')
    assert '192.168.1.0/24' == to_subnet('192.168.1.1', '24')
    assert '192.168.3.2 255.255.255.128' == to_subnet('192.168.3.2', '255.255.255.128', dotted_notation=True)
    assert '192.168.3.2 255.255.255.128' == to_subnet('192.168.3.2', '25', dotted_notation=True)
    assert 'fd00:a::1/64' == to_subnet('fd00:a::b:c:d:e', 'ffff:ffff:ffff:ffff::')

# Generated at 2022-06-20 16:03:09.785725
# Unit test for function to_masklen
def test_to_masklen():
    masklen = to_masklen('255.255.255.0')
    assert masklen == 24



# Generated at 2022-06-20 16:03:14.757282
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-20 16:03:25.895568
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3::5:6:7:8') == '1:2::'
    assert to_ipv6_subnet('1:2::5:6:7:8') == '1:2::'
    assert to_ipv6_subnet('1:2::5:6:7:8') == '1:2::'
    assert to_ipv6_subnet('1::5:6:7:8') == '1::'
    assert to_ipv6_subnet('1::5:6:7:8') == '1::'

# Generated at 2022-06-20 16:03:32.390569
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.0.0.0') is True
    assert is_netmask('255.0.0.255') is True
    assert is_netmask('255.255.255.255') is True
    assert is_netmask('255.255.255.0') is True
    assert is_netmask('255.128.255.0') is True
    assert is_netmask('255.128.150.0') is False
    assert is_netmask('asdf') is False
    assert is_netmask('') is False
    assert is_netmask('255.128.150.a') is False


# Generated at 2022-06-20 16:03:37.172916
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32') == True
    assert is_masklen('33') == False
    assert is_masklen('0') == True
    assert is_masklen('-1') == False
    assert is_masklen('a') == False
    assert is_masklen('1.1') == False
    assert is_masklen('1/2') == False



# Generated at 2022-06-20 16:03:46.777784
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    if to_ipv6_subnet('fe80::8f70:d5ff:fe5f:2eba') != 'fe80::':
        raise AssertionError('to_ipv6_subnet() function not working correctly.')
    if to_ipv6_subnet('fe80::8f70:d5ff:fe5f:2eba/64') != 'fe80::':
        raise AssertionError('to_ipv6_subnet() function not working correctly.')
    if to_ipv6_subnet('fe80::8f70:d5ff::2eba') != 'fe80::':
        raise AssertionError('to_ipv6_subnet() function not working correctly.')