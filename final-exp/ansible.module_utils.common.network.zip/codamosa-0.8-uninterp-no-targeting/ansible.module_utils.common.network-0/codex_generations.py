

# Generated at 2022-06-20 15:54:39.458787
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.255.255') == 32

    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8

    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('192.0.0.0') == 2
    assert to_masklen('224.0.0.0') == 3
    assert to_masklen('240.0.0.0') == 4
    assert to_masklen('248.0.0.0') == 5
    assert to_masklen('252.0.0.0') == 6
   

# Generated at 2022-06-20 15:54:46.980304
# Unit test for function is_mac
def test_is_mac():
    assert(is_mac('aa-bb-cc-dd-ee-ff'))
    assert(is_mac('aa:bb:cc:dd:ee:ff'))
    assert(is_mac('aa:bb:cc:dd:ee:fF'))
    assert(is_mac('Aa:BB:cc:dd:eE:fF'))
    assert(not is_mac('Aa:BB:cc:dd:eE:fFg'))
    assert(not is_mac('Aa:BB:cc:dd:eE:ff:gg'))
    assert(not is_mac('Aa-BB-cc-dd-eE-ff'))
    assert(not is_mac('Aa:BB:cc:dd:eE:ff:gg'))

# Generated at 2022-06-20 15:54:57.952840
# Unit test for function is_masklen
def test_is_masklen():
    # Negatives
    assert not is_masklen(-1)
    assert not is_masklen(-100)
    assert not is_masklen("-5.5")
    assert not is_masklen("-5")
    assert not is_masklen("4.-3")

    # Zero
    assert is_masklen(0)

    # Positive numbers within mask length
    for integer in range(1, 33):
        assert is_masklen(integer)
        assert is_masklen(float(integer))
        assert is_masklen(float(integer) + 0.5)
        assert is_masklen(str(integer))
        assert is_masklen(str(float(integer)))
        assert is_masklen(str(float(integer) + 0.5))

    # Positive numbers out of mask length
    assert not is_masklen

# Generated at 2022-06-20 15:55:09.264968
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('1:2:3:4:5:6:7:8') == '1:2:3:4::'
    assert to_ipv6_subnet('1:2:3::') == '1:2:3::'
    assert to_ipv6_subnet('1:2:3::4:5') == '1:2:3::'
    assert to_ipv6_subnet('1:2:3::4:5:6:7:8') == '1:2:3::'
    assert to_ipv6_subnet('1:2:3::4:5:6:7:8:9') == '1:2:3::'

# Generated at 2022-06-20 15:55:14.017114
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    examples = {
        'FE80::0202:B3FF:FE1E:8329': 'FE80::'}
    for addr, expected_subnet in examples.items():
        result = to_ipv6_subnet(addr)
        assert result == expected_subnet

# Generated at 2022-06-20 15:55:23.183569
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.252.0') == 22
    assert to_masklen('255.255.248.0') == 21
    assert to_masklen('255.255.240.0') == 20
    assert to_masklen('255.255.224.0') == 19
    assert to_masklen('255.255.192.0') == 18
    assert to_masklen('255.255.128.0') == 17
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.254.0.0') == 15
    assert to_masklen('255.252.0.0') == 14
   

# Generated at 2022-06-20 15:55:32.475573
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask('A.A.A.A')
    assert is_netmask('255.0.0.0')
    assert not is_netmask('255.0.0.1')
    assert is_netmask('255.255.255.0')
    assert not is_netmask('1.2.3.4.5')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('255.255.0.255.255')
    assert not is_netmask('255.255.0.255.255')
    assert not is_netmask('255.0.0')
    assert not is_netmask('255.0.0.0.0')



# Generated at 2022-06-20 15:55:36.939384
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'
    assert to_bits('255.255.254.0') == '11111111111111111111111111000000'



# Generated at 2022-06-20 15:55:47.379175
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """ Test to_ipv6_network function for different test cases """
    assert to_ipv6_network('2001:db8::1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:1::1') == '2001:db8::'
    assert to_ipv6_network('2001:db8:0:0:1::1') != '2001:db8:0:0:1::'
    assert to_ipv6_network('2001:db8:1::1') == '2001:db8:1::'
    assert to_ipv6_network('2001:db8:1::1') != '2001:db8:0:0:1::'

# Generated at 2022-06-20 15:55:52.242573
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen("33") is False
    assert is_masklen("-1") is False
    assert is_masklen("0") is True
    assert is_masklen("1") is True
    assert is_masklen("32") is True
    assert is_masklen("33") is False


# Generated at 2022-06-20 15:56:03.870817
# Unit test for function is_mac
def test_is_mac():
    assert is_mac("00:50:56:b4:37:1b")
    assert not is_mac("0050.56b4.371b")
    assert not is_mac("005056b4.371b")
    assert not is_mac("005056b4371b")
    assert is_mac("00:50:56:b4:37:1b")
    assert is_mac("00:50:56:B4:37:1B")
    assert not is_mac("00-50-56-b4-37-1b")
    assert is_mac("00-50-56-b4-37-1b")


# Generated at 2022-06-20 15:56:12.812011
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32


# Generated at 2022-06-20 15:56:23.350707
# Unit test for function to_netmask
def test_to_netmask():
    print("Testing to_netmask()")
    cases = {}
    cases['good'] = {
        'masklen': ['24', '16', '0', '32'],
        'netmask': ['255.255.255.0', '255.255.0.0', '0.0.0.0', '255.255.255.255'],
    }
    cases['bad'] = {
        'masklen': ['33', '-1'],
        'netmask': ['300.0.0.0', '1.2.3.4'],
    }

    for test in cases['good']:
        for val in cases['good'][test]:
            print("Testing %s(%s) == %r" % (test, repr(val), cases['good'][test][val]))
            assert to_net

# Generated at 2022-06-20 15:56:32.627565
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('::') == '::'
    assert to_ipv6_network('::1') == '::'
    assert to_ipv6_network('1::') == '1::'
    assert to_ipv6_network('1:2::1') == '1:2::'
    assert to_ipv6_network('1:2:3::1') == '1:2:3::'
    assert to_ipv6_network('1:2:3:4::1') == '1:2:3:4::'
    assert to_ipv6_network('1:2:3:4:5:6:7:8') == '1:2:3::'
    assert to_ipv6_network('1:2:3:4:5:6:7::')

# Generated at 2022-06-20 15:56:36.237269
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:11:22:33:44:55')
    assert not is_mac('00:11:22:33:44:56')
    assert is_mac('00-11-22-33-44-55')
    assert not is_mac('00-11-22-33-44-56')

# Generated at 2022-06-20 15:56:39.259123
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.0.0')



# Generated at 2022-06-20 15:56:45.291213
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert to_ipv6_network('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:db8:85a3::'
    assert to_ipv6_network('2001:0db8:0a0b:12f0:2:600:300c:326b') == '2001:db8:a0b::'
    assert to_ipv6_network('2001:0db8:85a3:12f0:2:600:300c:326b') == '2001:db8:85a3:12f0::'

# Generated at 2022-06-20 15:56:57.591450
# Unit test for function to_ipv6_network

# Generated at 2022-06-20 15:57:02.197056
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(16) == '255.255.0.0'
    assert to_netmask(32) == '255.255.255.255'



# Generated at 2022-06-20 15:57:10.063603
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:0a:95:9d:68:16')
    assert is_mac('00-0a-95-9d-68-16')
    assert is_mac('000a959d6816')
    assert not is_mac('000a959d68161')
    assert not is_mac('000a959d6816:')
    assert not is_mac('000a959d6816-')
    assert not is_mac('000a959d6816_')
    assert not is_mac('000a959d681r')
    assert not is_mac('000a959d681X')
    assert not is_mac('000a959d681x')


# Generated at 2022-06-20 15:57:15.517444
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(28) == '255.255.255.240'
    assert to_netmask(32) == '255.255.255.255'



# Generated at 2022-06-20 15:57:25.004500
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    network_tests = (
        ('fe80::1', 'fe80::1'),
        ('fe80::1%eth0', 'fe80::'),
        ('fe80::1%2', 'fe80::'),
        ('fe80:1::1', 'fe80:1::'),
        ('fe80:1::1%eth0', 'fe80:1::'),
        ('fe80:1::1%2', 'fe80:1::'),
        ('fe80:1::1::2', 'fe80:1::'),
    )
    for addr, net in network_tests:
        assert to_ipv6_network(addr) == net
        print(to_ipv6_network(addr))


# Generated at 2022-06-20 15:57:33.124844
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    assert(to_ipv6_network('2001:0DB8:0000:0000:0000:8A2E:0370:7334') == '2001:0DB8::')
    assert(to_ipv6_network('2001:0DB8:0000:0000:0000:8A2E:0370:7334/64') == '2001:0DB8::')
    assert(to_ipv6_network('2001:0DB8:0:0:0:8A2E:0370:7334/64') == '2001:0DB8::')
    assert(to_ipv6_network('2001:0DB8:0:0:0:8A2E:0370:7334') == '2001:0DB8::')

# Generated at 2022-06-20 15:57:40.454664
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.254.0.0') == 15



# Generated at 2022-06-20 15:57:49.350104
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('8.8.8.8', '255.255.255.0') == '8.8.8.0/24'
    assert to_subnet('8.8.8.8', '255.255.255.128') == '8.8.8.0/25'
    assert to_subnet('8.8.8.8', '255.255.255.192') == '8.8.8.0/26'
    assert to_subnet('8.8.8.8', '255.255.255.224') == '8.8.8.0/27'
    assert to_subnet('8.8.8.8', '255.255.255.240') == '8.8.8.0/28'

# Generated at 2022-06-20 15:57:59.512934
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    """Unit test for function to_ipv6_network"""
    import pytest
    from ansible.module_utils.net_tools import to_ipv6_network

    # Basic test, IPv6 address with all groups.
    test_addr = 'ff02:0:0:0:0:0:0:1'
    assert to_ipv6_network(test_addr) == 'ff02:0:0:0::'

    # Basic test, IPv6 address with only a few groups.
    test_addr = 'ff00::1'
    assert to_ipv6_network(test_addr) == 'ff00::'

    # Basic test, IPv6 address with one group.
    test_addr = 'ff02::1'
    assert to_ipv6_network(test_addr) == 'ff02::'



# Generated at 2022-06-20 15:58:05.695154
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert not is_netmask('255.255.255.1')
    assert not is_netmask('255.255.255.255.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255.255.0.')



# Generated at 2022-06-20 15:58:12.777984
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0) is True
    assert is_masklen(32) is True
    assert is_masklen(8) is True
    assert is_masklen(24) is True

    assert is_masklen(33) is False
    assert is_masklen(44) is False
    assert is_masklen(66) is False
    assert is_masklen(128) is False
    assert is_masklen(-1) is False
    assert is_masklen('33') is False
    assert is_masklen(None) is False
    assert is_masklen([24]) is False
    assert is_masklen({24: 33}) is False



# Generated at 2022-06-20 15:58:23.031306
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # Test case 1
    assert to_ipv6_network('2001:db8:85a3::8a2e:37023:7334') == '2001:db8:85a3::'
    # Test case 2
    assert to_ipv6_network('fe80::') == 'fe80::'
    # Test case 3
    assert to_ipv6_network('fe80::95f6:26fc:e25d:2df9') == 'fe80::'


# Generated at 2022-06-20 15:58:24.449786
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.255') == '11111111111111111111111111111111'

# Generated at 2022-06-20 15:58:34.267107
# Unit test for function to_netmask

# Generated at 2022-06-20 15:58:40.369705
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.0.0')
    assert is_netmask('255.255.240.0')
    assert not is_netmask('255.255.240')
    assert not is_netmask('255.255.240.0.0')
    assert not is_netmask('255.256.240.0')
    assert not is_netmask('255.255.240.0.1')


# Generated at 2022-06-20 15:58:43.857252
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(32)
    assert is_masklen(0)
    assert is_masklen('0')
    assert is_masklen('32')

    assert not is_masklen(-1)
    assert not is_masklen(33)
    assert not is_masklen('33')



# Generated at 2022-06-20 15:58:54.232334
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('00:00:00:00:00:00') is True
    assert is_mac('00:00:00:00:00:00:00') is False
    assert is_mac('10-10-10-10-10-10') is True
    assert is_mac('10,10,10,10,10,10') is False
    assert is_mac('aa:bb:cc:dd:ee:ff') is True
    assert is_mac('AA:BB:CC:DD:EE:FF') is True
    assert is_mac('AA:BB:CC:DD:EE:ZZ') is False
    assert is_mac('AA:BB:CC:DD:EE') is False
    assert is_mac('AA:BB:CC::EE:FF') is False
    assert is_mac('0') is False
   

# Generated at 2022-06-20 15:59:00.860160
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask('255.255.255.0') == '24'
    assert to_netmask('255.255.0.0') == '16'
    assert to_netmask('255.0.0.0') == '8'
    assert to_netmask('128.0.0.0') == '1'
    assert to_netmask('0.0.0.0') == '0'

# Generated at 2022-06-20 15:59:04.849776
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32

# Unit tests for function to_netmask

# Generated at 2022-06-20 15:59:16.195399
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('11:22:33:44:55:66') is True
    assert is_mac('11-aa-11-aa-11-aa') is True
    assert is_mac('AA-11-AA-11-AA-11') is True
    assert is_mac('AA:11:22:33:44:55') is True
    assert is_mac('11:22:33:44:55') is False
    assert is_mac('AA:11:22:33:44') is False
    assert is_mac('AA:11:22:33:44:55:66:77:88') is False
    assert is_mac('AA:11:22:33:44:55:66:77:88:99:00') is False

# Generated at 2022-06-20 15:59:23.048308
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.0.255.0') == 9
    assert to_masklen('128.0.0.0') == 1
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0



# Generated at 2022-06-20 15:59:28.148923
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen(-1)
    assert not is_masklen(None)
    assert not is_masklen('123')
    assert not is_masklen('a')
    assert not is_masklen('')


# Generated at 2022-06-20 15:59:36.875237
# Unit test for function to_subnet
def test_to_subnet():
    tests = [
        # addr, mask, dotted_notation, expected
        ['192.168.0.0', '255.255.0.0', False, '192.168.0.0/16'],
        ['192.168.0.0', '255.255.0.0', True, '192.168.0.0 255.255.0.0'],
        ['192.168.0.0', 16, False, '192.168.0.0/16'],
        ['192.168.0.0', 16, True, '192.168.0.0 255.255.0.0'],
    ]

    for addr, mask, dotted_notation, expected in tests:
        subnet = to_subnet(addr, mask, dotted_notation)
        assert subnet == expected

# Generated at 2022-06-20 15:59:44.900027
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255') == True
    assert is_netmask('0.0.0.0') == True
    assert is_netmask('255.192.0.0') == True
    assert is_netmask('') == False
    assert is_netmask('255.255.0.0') == True
    assert is_netmask('255.255.128.0') == True
    assert is_netmask('255.192.255.0') == False
    assert is_netmask('255.255.255.0') == True
    assert is_netmask('255.255.255.255.1') == False
    assert is_netmask('255.255.255.256') == False
    assert is_netmask('255.255.255.1') == False



# Generated at 2022-06-20 15:59:51.152675
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('0.0.0.0')
    assert is_netmask('255.255.255.255')
    assert not is_netmask('')
    assert not is_netmask('255.255.0')
    assert not is_netmask('255.255.0.0.0')
    assert not is_netmask('255.255.0.256')



# Generated at 2022-06-20 15:59:54.733544
# Unit test for function to_bits
def test_to_bits():
    assert '11111111' == to_bits('255.0.0.0')
    assert '10101010' == to_bits('170.0.0.0')
    assert '10101010' == to_bits('170.0.0.255')


# Generated at 2022-06-20 15:59:56.951974
# Unit test for function to_bits
def test_to_bits():
    assert to_bits('255.255.255.0') == '11111111111111111111111100000000'

# Generated at 2022-06-20 16:00:05.579474
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv6_subnet('2001:0db8:0000:0000:0000:0000:0000:0001') == '2001:0db8::'
    assert to_ipv6_subnet('2001:0db8:0000:0000:0db8:85a3:0000:0000') == '2001:0db8:0db8:85a3::'
    assert to_ipv6_subnet('2001:0db8:85a3:08d3:1319:8a2e:0370:7334') == '2001:0db8:85a3::'
    assert to_ipv

# Generated at 2022-06-20 16:00:07.578437
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.255')
    assert not is_netmask('0.0.0.256')



# Generated at 2022-06-20 16:00:13.378463
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(0) == '0.0.0.0'
    assert to_netmask(1) == '128.0.0.0'
    assert to_netmask(2) == '192.0.0.0'
    assert to_netmask(3) == '224.0.0.0'
    assert to_netmask(4) == '240.0.0.0'
    assert to_netmask(5) == '248.0.0.0'
    assert to_netmask(6) == '252.0.0.0'
    assert to_netmask(7) == '254.0.0.0'
    assert to_netmask(8) == '255.0.0.0'
    assert to_netmask(9) == '255.128.0.0'

# Generated at 2022-06-20 16:00:18.304290
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0') is True
    assert is_masklen('32') is True
    assert is_masklen(-1) is False
    assert is_masklen('33') is False
    assert is_masklen(33) is False


# Generated at 2022-06-20 16:00:25.768925
# Unit test for function to_netmask
def test_to_netmask():
    mask_tests = {
        '0.0.0.0': '0.0.0.0',
        '255.255.255.255': '255.255.255.255',
        '0.0.0.255': '255.255.255.0',
        '0.0.255.255': '255.255.0.0',
        '0.255.255.255': '255.0.0.0',
        '255.255.255.0': '0.0.0.255',
        '255.255.0.0': '0.0.255.255',
        '255.0.0.0': '0.255.255.255',
    }
    for masklen, mask in list(mask_tests.items()):
        assert to_netmask(masklen) == mask

# Generated at 2022-06-20 16:00:35.096156
# Unit test for function to_subnet
def test_to_subnet():
    assert to_subnet('192.168.1.1', 24) == "192.168.1.0/24"
    assert to_subnet('192.168.1.1', '255.255.255.0') == "192.168.1.0/24"
    assert to_subnet('192.168.1.1', '0.0.0.0') == "0.0.0.0/0"
    assert to_subnet('192.168.1.1', 24, True) == "192.168.1.0 255.255.255.0"
    assert to_subnet('192.168.1.1', '255.255.255.0', True) == "192.168.1.0 255.255.255.0"

# Generated at 2022-06-20 16:00:45.000982
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    # Test standard address: fe80::5054:ff:fede:110 (128 bits)
    test_addr = 'fe80::5054:ff:fede:110'
    assert(to_ipv6_subnet(test_addr) == 'fe80::')

    # Test similar address: fe80::5054:ff:fede:11 (96 bits)
    test_addr = 'fe80::5054:ff:fede:11'
    assert(to_ipv6_subnet(test_addr) == 'fe80::')

    # Test similar address: fe80::5054:ff:fede (64 bits)
    test_addr = 'fe80::5054:ff:fede'
    assert(to_ipv6_subnet(test_addr) == 'fe80::')

    # Test similar address

# Generated at 2022-06-20 16:00:55.896597
# Unit test for function is_netmask
def test_is_netmask():
    assert not is_netmask(None)
    assert not is_netmask([])
    assert not is_netmask('')
    assert not is_netmask('x')
    assert not is_netmask('1.2.3.4.5')
    assert not is_netmask('1.2.3.4.5.6')
    assert is_netmask('1.2.3.4')
    assert is_netmask('2.3.4.255')
    assert not is_netmask('2.3.4.256')
    assert not is_netmask('2.3.4.254.5')
    assert not is_netmask('2.3.4.0.255')
    assert not is_netmask('255.255.255.255.255')



# Generated at 2022-06-20 16:01:07.796493
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('3fff:ffff:ffff:ffff:ffff:ffff:ffff:ffff') == '3fff:ffff:ffff::'
    assert to_ipv6_subnet('3fff:ffff:ffff:ffff::ffff:ffff:ffff') == '3fff:ffff:ffff::'
    assert to_ipv6_subnet('3fff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff') == '3fff:ffff:ffff::'
    assert to_ipv6_subnet('::') == '::'
    assert to_ipv6_subnet('3fff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff') == '3fff:ffff:ffff::'
    assert to_ipv6

# Generated at 2022-06-20 16:01:17.100545
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.255')
    assert is_netmask('255.255.254.0')
    assert is_netmask('128.0.0.0')
    assert is_netmask('0.0.0.0')
    assert not is_netmask('255.255.255.0.0')
    assert not is_netmask('255.255.255')
    assert not is_netmask('256.255.255.0')
    assert not is_netmask('255.256.255.0')
    assert not is_netmask('255.255.256.0')
    assert not is_netmask('255.255.255.256')
    assert not is_netmask('127.255.255.0')


# Generated at 2022-06-20 16:01:23.441941
# Unit test for function to_subnet
def test_to_subnet():
    """ unit tests for function to_subnet """

# Generated at 2022-06-20 16:01:28.036717
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('0')
    assert is_masklen('32')
    assert not is_masklen('33')
    assert not is_masklen('-1')
    assert not is_masklen('a')
    assert not is_masklen('')

# Generated at 2022-06-20 16:01:37.076276
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('AA:BB:CC:DD:EE:FF')
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa-bb-cc-dd-ee-ff')
    assert is_mac('aa.bb.cc.dd.ee.ff')
    assert not is_mac('aa.bb.cc.dd.ee')
    assert not is_mac('aa:bb:cc:dd:ee')
    assert not is_mac('aa:bb:cc:dd:ee:ff:gg')
    assert not is_mac('aa-bb-cc-dd-ee-ff-gg')
    assert not is_mac('AA:BB:CC:DD:EE')
    assert not is_mac('AA-BB-CC-DD-EE')

# Generated at 2022-06-20 16:01:49.956999
# Unit test for function is_mac
def test_is_mac():
    assert is_mac('aa:bb:cc:dd:ee:ff')
    assert is_mac('aa:bb:cc:dd:ee:fF')
    assert is_mac('aa-bb-cc-dd-ee-ff')
    assert is_mac('aa-bb-cc-dd-ee-fF')
    assert not is_mac('aa-bb-cc-dd-ee:fF')
    assert not is_mac('aa::bb:cc:dd:ee:ff')

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='netutils test')
    parser.add_argument('--check', dest='check', action='store_true', help='check function')

# Generated at 2022-06-20 16:01:54.017956
# Unit test for function to_netmask
def test_to_netmask():
    assert to_netmask(24) == '255.255.255.0'
    assert to_netmask(27) == '255.255.255.224'
    assert to_netmask(28) == '255.255.255.240'
    assert to_netmask(29) == '255.255.255.248'
    assert to_netmask(30) == '255.255.255.252'



# Generated at 2022-06-20 16:02:04.559690
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2001:db8:85a3::8a2e:370:7334') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:8a2e:370:7334') == '2001:db8:85a3:0:0:0:0:0'
    assert to_ipv6_subnet('2001:db8:85a3:0:0:0:0:0') == '2001:db8:85a3::'
    assert to_ipv6_subnet('2001:db8:85a3:8d3:1319:8a2e:370:7334') == '2001:db8:85a3::0:0:0:0:'


# Generated at 2022-06-20 16:02:14.457025
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32
    assert to_masklen('255.255.255.256') == 0



# Generated at 2022-06-20 16:02:16.840393
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen('32')
    assert not is_masklen('33')


# Generated at 2022-06-20 16:02:25.271085
# Unit test for function is_mac
def test_is_mac():
    assert True is is_mac('00:00:00:00:00:00')
    assert True is is_mac('00-00-00-00-00-00')
    assert False is is_mac('asdf:asdf:asdf:asdf')
    assert False is is_mac('asdf-asdf-asdf-asdf')
    assert True is is_mac('22:22:22:22:22:22')
    assert False is is_mac('22:22:22:22:22:22:22')
    assert False is is_mac('22:22:22:22:22:22:')
    assert False is is_mac('22-22-22-22-22-22-22')
    assert False is is_mac('22-22-22-22-22-22-')

# Generated at 2022-06-20 16:02:35.655668
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.255.192')
    assert is_netmask('255.255.255.224')
    assert is_netmask('255.255.255.240')
    assert is_netmask('255.255.255.248')
    assert is_netmask('255.255.255.252')
    assert is_netmask('255.255.255.254')
    assert is_netmask('255.255.255.255')

    assert not is_netmask('255.255.255.256')
    assert not is_netmask('255.255.255')
    assert not is_netmask('255.255')
    assert not is_netmask('255')

# Generated at 2022-06-20 16:02:43.109394
# Unit test for function to_masklen
def test_to_masklen():
    """ test for function to_masklen """
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('0.0.0.0') == 0
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-20 16:02:52.742805
# Unit test for function is_mac
def test_is_mac():
    # Check successful validation
    assert is_mac('12:34:56:78:9A:BC')
    assert is_mac('12-34-56-78-9a-bc')
    assert is_mac('123456789abc')

    # Check failed validations
    assert not is_mac('')
    assert not is_mac(' ')
    assert not is_mac('1')
    assert not is_mac('12')
    assert not is_mac('12:34:56:77:9A:BC')
    assert not is_mac('12-34-56-77-9a-bc')
    assert not is_mac('123456789ab')
    assert not is_mac('123456789abcd')
    assert not is_mac('1234:5678:90AB:CDEF')

# Generated at 2022-06-20 16:02:53.808286
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask("255.255.255.0")



# Generated at 2022-06-20 16:03:02.397799
# Unit test for function is_netmask
def test_is_netmask():
    # List of valid netmasks
    assert is_netmask('255.255.255.0')
    assert is_netmask('255.255.255.128')
    assert is_netmask('255.255.0.0')

    # List of invalid netmasks
    assert not is_netmask('255.255.0.255')
    assert not is_netmask('255.255.0.256')
    assert not is_netmask('255.255.0')


# Generated at 2022-06-20 16:03:11.983364
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    res = to_ipv6_subnet('fe80::2:8e11:f6ff:fea1:ce1c')
    assert(res == 'fe80:::')
    res = to_ipv6_subnet('fe80::2:8e11:f6ff:fea1:ce1c/64')
    assert(res == 'fe80:::')
    res = to_ipv6_subnet('fe80::2:8e11:f6ff:fea1:ce1c/48')
    assert(res == 'fe80:0:0:0:')
    res = to_ipv6_subnet('fe80::2:8e11:f6ff:fea1:ce1c/123')
    assert(res == 'fe80::')
    res = to_

# Generated at 2022-06-20 16:03:14.322436
# Unit test for function is_masklen
def test_is_masklen():
    assert is_masklen(0)
    assert is_masklen(24)
    assert is_masklen(32)
    assert not is_masklen(33)
    assert not is_masklen(-1)


# Generated at 2022-06-20 16:03:23.284983
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27



# Generated at 2022-06-20 16:03:31.037007
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.0.0.0') == 8
    assert to_masklen('255.255.0.0') == 16
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.255.255') == 32



# Generated at 2022-06-20 16:03:36.197130
# Unit test for function is_masklen
def test_is_masklen():
    assert not is_masklen(None)
    assert not is_masklen('')
    assert not is_masklen('x')
    assert not is_masklen('35')
    assert not is_masklen('-1')

    assert is_masklen('0')
    assert is_masklen('1')
    assert is_masklen('33')
    assert is_masklen('32')


# Generated at 2022-06-20 16:03:42.995486
# Unit test for function to_ipv6_network
def test_to_ipv6_network():
    # Test a well formed IPv6 address
    assert to_ipv6_network('2607:f0d0:1002:51::4') == '2607:f0d0:1002:51::'

    # Test an IPv6 address with some ommitted zeros
    assert to_ipv6_network('2001:db8:0:1:1:1:1:1') == '2001:db8::1:1:1:1:1:'



# Generated at 2022-06-20 16:03:54.782376
# Unit test for function to_ipv6_subnet
def test_to_ipv6_subnet():
    assert to_ipv6_subnet('2600:1012:b000:7e1b:21ae:c4ff:fe4b:aeb0') == '2600:1012:b000:7e1b::'
    assert to_ipv6_subnet('::b000:7e1b:21ae:c4ff:fe4b:aeb0') == '::'
    assert to_ipv6_subnet('2001:0db8:0000:0000:0000:ff00:0042:8329') == '2001:db8::'
    assert to_ipv6_subnet('2001:db8:0:0:0:ff00:42:8329') == '2001:db8::'

# Generated at 2022-06-20 16:04:04.150971
# Unit test for function to_masklen
def test_to_masklen():
    assert to_masklen('255.255.255.0') == 24
    assert to_masklen('255.255.254.0') == 23
    assert to_masklen('255.255.255.128') == 25
    assert to_masklen('255.240.0.0') == 12
    assert to_masklen('255.255.255.192') == 26
    assert to_masklen('255.255.255.224') == 27
    assert to_masklen('255.255.255.240') == 28
    assert to_masklen('255.255.255.248') == 29
    assert to_masklen('255.255.255.252') == 30
    assert to_masklen('255.255.255.254') == 31
    assert to_masklen('255.255.255.255') == 32

# Generated at 2022-06-20 16:04:09.745785
# Unit test for function is_netmask
def test_is_netmask():
    assert is_netmask('1.1.1.1') == True  # True
    assert is_netmask('1.1.1') == False  # False
    assert is_netmask('1.1.1.1.1') == False  # False
    assert is_netmask('1.1.1.1.') == False  # False
    assert is_netmask('256.1.1.1') == False  # False
    assert is_netmask('1.256.1.1') == False  # False
    assert is_netmask('-1.1.1.1') == False  # False
    assert is_netmask('1.1.1.1.0') == False  # False
    assert is_netmask('1.1.1.1.254') == False  # False
    assert is_

# Generated at 2022-06-20 16:04:22.114246
# Unit test for function to_ipv6_network