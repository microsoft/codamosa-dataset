

# Generated at 2022-06-23 10:16:00.492887
# Unit test for function unique

# Generated at 2022-06-23 10:16:01.827525
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:16:13.656781
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Action: Create a dict of dicts from a list of dicts
    # Expect: The original list of dicts is converted to a dict of dicts keyed on the key
    data = [
        {'id': '1', 'name': 'a'},
        {'id': '2', 'name': 'b'},
        {'id': '3', 'name': 'c'}
    ]
    key = 'id'
    duplicates = 'error'

    new_obj = rekey_on_member(data, key, duplicates)
    assert new_obj == {
        '1': {'id': '1', 'name': 'a'},
        '2': {'id': '2', 'name': 'b'},
        '3': {'id': '3', 'name': 'c'}
    }

# Generated at 2022-06-23 10:16:15.505022
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:16:17.288583
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2
    assert inversepower(27, 3) == 3

# Generated at 2022-06-23 10:16:24.922046
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(9) == 3
    assert inversepower(8) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(16, 4) == 2
    assert inversepower(256, 4) == 4
    assert inversepower(256, 8) == 4
    try:
        inversepower(27, 1)
    except AnsibleFilterTypeError as e:
        assert str(e) == 'root() can only be used on numbers: float() argument must be a string or a number, not \'dict\''
    else:
        raise Exception



# Generated at 2022-06-23 10:16:32.616574
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2.0, 3]) == 3
    assert max([1, 2.5, 2.5, 3]) == 3
    assert max([1, 2.5, 2.5, 3], default=0) == 3
    assert max(None, default=0) == 0
    assert max([], default=0) == 0
    assert max([1, 2, 3], key=int) == 3
    assert max({'a': 1, 'b': 2, 'c': 3}) == 3
    assert max({'a': 1, 'b': 3, 'c': 2}) == 3

# Generated at 2022-06-23 10:16:34.487612
# Unit test for function min
def test_min():
    assert min([1, 2, 3], [1, 5, 6]) == 1



# Generated at 2022-06-23 10:16:38.445404
# Unit test for function logarithm
def test_logarithm():
    logarithm(0)
    logarithm(1, base=10)
    logarithm(math.e)
    logarithm(math.e, base=math.e)



# Generated at 2022-06-23 10:16:49.295113
# Unit test for function human_readable
def test_human_readable():
    # Test the basic functions
    assert human_readable(100) == '100 B'
    assert human_readable(100, isbits=True) == '800 b'
    assert human_readable(1000, unit='KB') == '1 KB'
    assert human_readable(1000, unit='KB', isbits=True) == '8 Kb'

    # Ensure we can pass bools to isbits
    assert human_readable(100, isbits=False) == '100 B'
    assert human_readable(100, isbits=True) == '800 b'

    # Invalid input types
    import os
    try:
        human_readable("hello world")
        assert False
    except AnsibleFilterError:
        pass
    except Exception as e:
        assert False, 'Expected AnsibleFilterError, got %s' % e.__class__

# Generated at 2022-06-23 10:16:51.130911
# Unit test for function difference
def test_difference():
    assert difference([1, 2, 2, 3], [2, 3, 4]) == [1]

# Generated at 2022-06-23 10:17:00.780786
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 2]) == [1, 2]
    assert unique([1, 2, 1, 2], True) == [1, 2]
    assert unique([1, 2, 1, 2], False) == [1, 2]
    assert unique(['a', 'A', 'b'], False, attribute='upper') == ['a', 'b']
    assert unique(['a', 'A', 'b'], False, attribute='upper') != ['a', 'b', 'A']
    assert unique(['a', 'A', 'b'], False, attribute='lower') == ['a', 'b', 'A']

    # Test that error from 'unique' function is being wrapped into AnsibleFilterError

# Generated at 2022-06-23 10:17:01.604187
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters

# Generated at 2022-06-23 10:17:02.933960
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-23 10:17:06.878309
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, -3) == 1./8
    f = power(2, 3)
    assert isinstance(f, float)
    try:
        power('2', 3)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 10:17:10.038697
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 3, 4, 5]) == [2, 3]
    assert intersect([1, 2, 3], [2, 3, 4, 5]) != [1, 2, 3, 4, 5]



# Generated at 2022-06-23 10:17:23.034161
# Unit test for function human_readable
def test_human_readable():
    f = FilterModule()

# Generated at 2022-06-23 10:17:35.908406
# Unit test for function human_readable
def test_human_readable():
    assert(human_readable(0) == '0 B')
    assert(human_readable(1) == '1 B')
    assert(human_readable(12) == '12 B')
    assert(human_readable(123) == '123 B')
    assert(human_readable(1234) == '1.21 kB')
    assert(human_readable(12345) == '12.1 kB')
    assert(human_readable(123456) == '123 kB')
    assert(human_readable(1234567) == '1.18 MB')
    assert(human_readable(12345678) == '12 MB')
    assert(human_readable(123456789) == '118 MB')
    assert(human_readable(1234567890) == '1.15 GB')

# Generated at 2022-06-23 10:17:39.911729
# Unit test for function union
def test_union():
    '''
    Return the union of two lists, removing duplicates
    '''
    a = [1, 2, 3, 4, 5]
    b = [1, 1, 2, 6, 7, 8]

    result = union(a, b)
    assert result == [1, 2, 3, 4, 5, 6, 7, 8], "unexpected result"

# Generated at 2022-06-23 10:17:46.539258
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 10) == 1.0
    assert logarithm(1) == 0.0
    assert logarithm(32, 2) == 5.0
    assert logarithm(100, 100) == 1.0
    assert logarithm('x')
    assert logarithm(10, 'x')


# Generated at 2022-06-23 10:17:49.101912
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(16) == 4
    assert inversepower(27) == 3
    assert inversepower(256) == 4



# Generated at 2022-06-23 10:17:56.289035
# Unit test for function difference
def test_difference():
    def check(a, b, expected):
        diff = difference(a, b)
        diff.sort()
        expected.sort()
        assert diff == expected

    check([1, 2, 3], [1, 2], [3])
    check([1, 2], [1, 2, 3], [])
    check([1, 2, 3], [], [1, 2, 3])
    check([], [], [])
    check([1, 2, 3], [1, 2, 3], [])



# Generated at 2022-06-23 10:17:59.183998
# Unit test for function max
def test_max():
    s = {}
    # Test for 'max' filter which does not take keyword arguments
    if max(s, something='something'):
        # This should fail as 'max' does not take keyword arguments
        raise AssertionError

# Generated at 2022-06-23 10:18:03.314832
# Unit test for function difference
def test_difference():
    data = [1, 2, 3, 4, 1, 2, 5, 2, 3, 2, 1, 2, 3, 2, 4, 2]
    query = [1, 2, 3]
    result = difference(None, data, query)
    assert result == [4, 5, 4]


# Generated at 2022-06-23 10:18:10.706165
# Unit test for function intersect
def test_intersect():
    s1 = set(['green', 'blue'])
    s2 = set(['green', 'red'])
    s3 = set(['white'])
    s = intersect(s1, s2)
    assert s == set(['green'])
    s = intersect(s1, s3)
    assert s == set()
    s = intersect(s1, s2, s3)
    assert s == set()
    s = intersect(s1, [1, 2, 3])
    assert s == set()
    s = intersect([1, 2, 3], [2, 3, 4])
    assert s == set([2, 3])
    s = intersect([1, 2, 3], [1, 2])
    assert s == set([1, 2])


# Generated at 2022-06-23 10:18:21.892638
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    # Prepare test object
    f = FilterModule()
    filters = f.filters()

    # Tests for filters
    # zip
    zip_data = ['abc', 'def', 'ghi']
    zip_data2 = ['A', 'D', 'G']
    zip_data3 = ['a', 'b', 'c']
    zip_data4 = [1, 2, 3]
    zip_data5 = ['a', 'b', 'c', 'd']
    zip_data6 = ['A', 'B', 'C', 'D']
    zip_data7 = ['a', 'b', 'c', 'd', 'e']
    zip_result = [('abc', 'A', 'a', 1), ('def', 'D', 'b', 2), ('ghi', 'G', 'c', 3)]

# Generated at 2022-06-23 10:18:33.528192
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native

    from jinja2.exceptions import UndefinedError

    d = [
        {'name': 'a', 'value': 1},
        {'name': 'b', 'value': 2},
        {'name': 'c', 'value': 3},
        {'name2': 'd', 'value': 4},
    ]


# Generated at 2022-06-23 10:18:44.870584
# Unit test for function human_readable
def test_human_readable():
    from ansible.utils.display import Display
    display = Display()

    assert 64769 == human_to_bytes('64K')
    assert 114688 == human_to_bytes('112k')
    assert 73400320 == human_to_bytes('70M')
    assert 84934656 == human_to_bytes('81M')
    assert 4398046511104 == human_to_bytes('40G')
    assert 28991029248 == human_to_bytes('27G')
    assert 8796093022208 == human_to_bytes('8192T')
    assert 15 == human_to_bytes('15')
    assert 15 == human_to_bytes('15B')
    assert 16 == human_to_bytes('16.0B')


# Generated at 2022-06-23 10:18:46.965377
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 10) == 1



# Generated at 2022-06-23 10:18:51.763233
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference("abc", "def") == ['a', 'b', 'c', 'd', 'e', 'f']
    assert symmetric_difference("abc", "abc") == []
    assert symmetric_difference("ab", "a") == ['b']
    assert symmetric_difference("a", "ab") == ['b']

# Generated at 2022-06-23 10:19:02.369715
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('1') == '1kB'
    assert human_readable('1', unit='B') == '1B'
    assert human_readable('1') == '1kB'
    assert human_readable('1') == '1kB'
    assert human_readable('1kb') == '1kB'
    assert human_readable('1Kb') == '1kB'
    assert human_readable('1k') == '1kB'
    assert human_readable('1K') == '1kB'
    assert human_readable('1KiB') == '1kB'
    assert human_readable('1Ki') == '1kB'
    assert human_readable('1kb', unit='B') == '1024B'
    assert human_readable('1Kb', unit='B') == '1024B'

# Generated at 2022-06-23 10:19:12.698541
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([-1, -2, 3]) == 3
    assert max([1, 2, -3]) == 2
    assert max([-1, -2, -3]) == -1
    assert max(['a', 'aa', 'aaa']) == 'aaa'
    assert max(['a', 'aa', 'aaa'], default='') == 'aaa'
    assert max(['a', 'aa', 'aaa'], default='', attribute='length') == 3
    assert max(['a', 'aa', 'aaa'], default='', attribute='length', limit=2) == 'aa'
    assert max(['a', 'aa', 'aaa'], default='', attribute='length', reverse=True) == 1

# Generated at 2022-06-23 10:19:20.298630
# Unit test for function intersect
def test_intersect():
    def _match(value, expected):
        if not value == expected:
            raise AssertionError("Value %s does not match expected value %s" % (value, expected))
        return True

    # 2args
    _match(intersect([1, 2], [2, 3]), [2])
    _match(intersect(['cat', 'dog'], ['dog', 'cow']), ['dog'])
    _match(intersect(['cat', 'dog'], [1, 2]), [])
    _match(intersect([1, 2], [1, 2]), [1, 2])
    _match(intersect('cat', 'cat'), 'cat')


# Generated at 2022-06-23 10:19:30.166205
# Unit test for function power
def test_power():
    # abs(actual - expected) <= decimal_precision
    decimal_precision = 0.0000000001

    assert power(2, 3) == 8
    assert abs(power(4, 0.5) - 2) <= decimal_precision
    assert power(10, 0) == 1

    try:
        power('a', 2)
        assert False, 'power() did not raise exception on a power of a string'
    except AnsibleFilterTypeError:
        pass

    try:
        power(2, 'b')
        assert False, 'power() did not raise exception on a string exponent'
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-23 10:19:38.871693
# Unit test for function min
def test_min():
    case = [1, 2, 3, 4]
    if min(case) != 1:
        return False
    case = [4, 3, 2, 1]
    if min(case) != 1:
        return False
    case = ['b', 'a', 'd', 'c']
    if min(case) != 'a':
        return False
    case = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    if min(case, key=case.get) != 'a':
        return False
    case = {'a': 4, 'b': 3, 'c': 2, 'd': 1}
    if min(case, key=case.get) != 'd':
        return False
    return True


# Generated at 2022-06-23 10:19:48.758837
# Unit test for function human_readable
def test_human_readable():
    """
    Test the human_readable function with
    known values.
    """

    x = (
        (0, '0.0B'),
        (1024, '1.0K'),
        (2048, '2.0K'),
        (1024*1024, '1.0M'),
        (2*1024*1024, '2.0M'),
        (1024**3, '1.0G'),
        (2*1024**3, '2.0G'),
        (1024**4, '1.0T'),
        (2*1024**4, '2.0T'),
        (1024**5, '1.0P'),
        (2*1024**5, '2.0P'),
    )

    for value, expected in x:
        actual = human_readable(value)

# Generated at 2022-06-23 10:19:58.199212
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1029) == '1.01K'
    assert human_readable(1029, unit='B') == '1.01KB'
    assert human_readable(1029, unit='B', isbits=True) == '8.33KB'
    assert human_readable(1049) == '1.02K'
    assert human_readable(1049, unit='B') == '1.02KB'
    assert human_readable(1049, unit='B', isbits=True) == '8.39KB'
    assert human_readable(1024, isbits=True) == '8.00K'
    assert human_readable(1024, isbits=True, unit='B') == '8.00KB'
    assert human_readable(1024) == '1.00K'

# Generated at 2022-06-23 10:20:09.113972
# Unit test for function human_readable
def test_human_readable():

    # Successful conversions
    assert human_readable(0) == '0.00 B'
    assert human_readable(1) == '1.00 B'
    assert human_readable(1.0) == '1.00 B'
    assert human_readable('1') == '1.00 B'
    assert human_readable(1, isbits=True) == '8.00 b'
    assert human_readable(10.5, isbits=True) == '84.00 b'
    assert human_readable(10.5, isbits=False) == '10.50 B'
    assert human_readable(2**10) == '1.02 KB'
    assert human_readable(2**10 + 2**9) == '1.53 KB'
    assert human_readable(2**20) == '1.05 MB'

# Generated at 2022-06-23 10:20:19.038213
# Unit test for function max
def test_max():
    import ansible.errors
    from ansible.utils.hashing import md5s

    assert max([1, 2, 3]) == 3
    assert max([-1, 0, 1]) == 1
    assert max(["aa", "ab", "ba"]) == "ba"
    assert max([-1, -0.0, 1]) == 1
    assert max([-1.0, -0.0, 1]) == 1

    assert max([1, 2, 3], default=4) == 3
    assert max([], default=4) == 4

    # Invalid usage
    try:
        max([], key=lambda x: x)
    except Exception as e:
        assert isinstance(e, TypeError)

# Generated at 2022-06-23 10:20:23.449049
# Unit test for function difference
def test_difference():
    given_list1 = [1,2,3]
    given_list2 = [1,2,4]
    expected_output = [3]
    assert difference(given_list1, given_list2) == expected_output

# Generated at 2022-06-23 10:20:32.542207
# Unit test for function difference
def test_difference():
    d = {'a': 1, 'b': 2}

    def check(a, b, expected):
        filter = FilterModule()
        assert filter.filters()['difference'](d, a, b) == expected

    # mapping
    check({'a': 1}, {'a': 1}, {})
    check({'a': 1}, {'a': 1, 'b': 2}, {})
    check({'a': 1, 'b': 2}, {'a': 1}, {'b': 2})
    check({'a': 1, 'b': 2}, {'b': 2}, {'a': 2})
    check({'a': 1, 'b': 2}, {'a': 2}, {'a': 1, 'b': 2})

# Generated at 2022-06-23 10:20:41.933435
# Unit test for function inversepower
def test_inversepower():
    from ansible.compat.tests import unittest

    class TestInversePower(unittest.TestCase):
        def test_inversepower(self):
            # Positive integers
            # Positive non-integer
            # Positive infinity
            # Negative numbers
            # Non-real numbers
            # None

            self.assertEqual(inversepower(4), 2)
            self.assertEqual(inversepower(9), 3)
            self.assertEqual(inversepower(1024), 32)
            self.assertEqual(inversepower(9, 3), 2)
            self.assertEqual(inversepower(125, 5), 2.5)
            self.assertAlmostEqual(inversepower(float('inf')), float('inf'))


# Generated at 2022-06-23 10:20:46.861189
# Unit test for function logarithm
def test_logarithm():
    """Math: logarithm"""
    f = FilterModule()
    list = f.filters()
    assert list['log'](100) == math.log(100)
    assert list['log'](100, 10) == math.log(100, 10)
    try:
        list['log']('test')
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError('log() did not raise AnsibleFilterTypeError')


# Generated at 2022-06-23 10:20:53.274136
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3, 4], [2, 3]) == [1, 4]
    assert symmetric_difference([1, 2, 3, 4], [2, 3], [3, 4]) == [1]
    assert symmetric_difference([1, 2, 3, 4], [2, 3], [3, 4], [4, 5]) == [1, 5]

# Generated at 2022-06-23 10:21:02.735386
# Unit test for function logarithm
def test_logarithm():
    l = math.log(2.0)
    l10 = math.log(2.0, 10)
    assert l == logarithm(2.0)
    assert l == logarithm(2.0, math.e)
    assert l10 == logarithm(2.0, 10)
    assert l10 == logarithm(2.0, '10')
    assert l10 == logarithm(2.0, '0xA')
    assert l10 == logarithm(2.0, 10.0)
    try:
        logarithm('a')
        assert False, 'should not get here'
    except AnsibleFilterTypeError as e:
        assert 'only be used on numbers' in str(e)

# Generated at 2022-06-23 10:21:13.552857
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100k') == 100000)
    assert(human_to_bytes('100K') == 100000)
    assert(human_to_bytes('100KiB') == 102400)
    assert(human_to_bytes('1M') == 1000000)
    assert(human_to_bytes('1MiB') == 1048576)
    assert(human_to_bytes('1G') == 1000000000)
    assert(human_to_bytes('1GiB') == 1073741824)
    assert(human_to_bytes('1T') == 1000000000000)
    assert(human_to_bytes('1TiB') == 1099511627776)
    assert(human_to_bytes('1TB') == 1000000000000)

# Generated at 2022-06-23 10:21:19.082439
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(zip_longest(['a', 'b', 'c', 'd'], ['a', 'b', 'c']) == [('a', 'a'), ('b', 'b'), ('c', 'c'), ('d', None)])

# Generated at 2022-06-23 10:21:27.705489
# Unit test for function difference
def test_difference():
    import pytest
    f = FilterModule()
    assert f.filters()['difference']('AB', 'ABC') == 'B'
    with pytest.raises(AnsibleFilterError):
        f.filters()['difference']('A', ())

# Generated at 2022-06-23 10:21:29.627014
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]

# Generated at 2022-06-23 10:21:41.734482
# Unit test for function intersect
def test_intersect():
    list1 = [1,2,3,4,5]
    list2 = [5,6,7,8,9]
    list3 = [1,2,3,4,5,6,7,8,9]
    assert [5] == intersect(1,list1,list2)
    assert list3 == intersect(1,list1,list3)
    assert list3 == intersect(1,list3,list3)
    assert [] == intersect(1,list1, [])
    assert [9] == intersect(1,list1, [9])
    assert [] == intersect(1, [], list1)

    for element in list3:
        assert list3 == intersect(1, element, list3)
        assert [element] == intersect(1, list3, element)

# Generated at 2022-06-23 10:21:49.994315
# Unit test for function intersect
def test_intersect():
    from ansible.compat.tests import unittest

    from jinja2.utils import contextfunction

    class TestIntersectFilters(unittest.TestCase):
        data_ascii = list(u"abcdef")
        data_utf8 = list(u"aébecfï")
        utf8_char = u'ï'

        def test_intersect_types(self):
            for test_dict in (dict(),
                              {'_ansible_no_log': True},
                              {'_ansible_no_log': False}):
                intersection = intersect(test_dict, "ab", "ac")
                self.assertIsInstance(intersection, list)
                self.assertEqual(intersection, ['a'])


# Generated at 2022-06-23 10:21:52.439266
# Unit test for constructor of class FilterModule
def test_FilterModule():
    res = FilterModule().filters()
    assert 'min' in res



# Generated at 2022-06-23 10:22:00.095484
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from jinja2 import Environment, StrictUndefined

    env = Environment()
    env.filters['rekey_on_member'] = rekey_on_member
    env.undefined = StrictUndefined

    template = env.from_string('''
{{ dict_list | rekey_on_member(key='id') | to_json }}

{{ dict_list | rekey_on_member(key='id', duplicates='overwrite') | to_json }}

{{ dict_list | rekey_on_member(key='non_existing_key') | to_json }}

{{ dict_list | rekey_on_member(key='blah', duplicates='error') | to_json }}
''')


# Generated at 2022-06-23 10:22:06.875708
# Unit test for function intersect
def test_intersect():

    # Use hard-coded list for more easy testing
    data = [('A', 'a', 'a', 'a'), ('A', 'b', 'c', 'd'), ('A', 'a', 'b', 'd')]
    print(data)
    print(set(data[0]) & set(data[1]))

    # Use hard-coded list for more easy testing
    data = ['a', 'a', 'A', 'b', 'A']
    print(data)
    print(set(data))

    # Use hard-coded list for more easy testing
    data = ['a', 'b', 'c', 'c', 'd', 'e']
    print(data)
    print(set(data))

    # Use hard-coded list for more easy testing

# Generated at 2022-06-23 10:22:08.527988
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(object()) is not None


# Generated at 2022-06-23 10:22:19.779097
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100m') == 100 * 1024 * 1024
    assert human_to_bytes('100g') == 100 * 1024 * 1024 * 1024
    assert human_to_bytes('100t') == 100 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('100p') == 100 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('100e') == 100 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('100z') == 100 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('100y') == 100 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('100k') == 100 * 1024

# Generated at 2022-06-23 10:22:21.149642
# Unit test for function power
def test_power():
    assert power(2, 10) == 1024


# Generated at 2022-06-23 10:22:30.724963
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4
    assert max([1, 2, 3, 4], attribute='age') == 4
    assert max([{'age': 7}, {'age': 3}, {'age': 100}], attribute='age') == {'age': 100}
    assert max([{'age': 7}, {'age': 3}, {'age': 100}], attribute='age', default=1) == {'age': 100}
    assert max([{'age': 7}, {'age': 3}, {'age': 100}], attribute='age', default=100) == {'age': 100}
    assert max([{'age': 7}, {'age': 3}, {'age': 100}], attribute='age', default=0) == {'age': 100}

# Generated at 2022-06-23 10:22:42.989068
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1024, unit='K') == "1.0"
    assert human_readable(1024, unit='Ki') == "1.0"
    assert human_readable(1024, unit='M') == "1.0M"
    assert human_readable(1024, unit='Mi') == "1.0M"
    assert human_readable(1024.0, unit='M') == "1.0M"
    assert human_readable(1024.1, unit='M') == "1.0M"
    assert human_readable(1024.9, unit='M') == "1.0M"
    assert human_readable(1025, unit='K') == "1.1K"
    assert human_readable(1025, unit='Ki') == "1.0Ki"

# Generated at 2022-06-23 10:22:52.457507
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.plugins.filter import core

    data = [{'foo': 'baz', 'foobar': 1}, {'foo': 'baz', 'foobar': 2}]
    assert core._rekey_on_member(data, 'foo') == {'baz': {'foo': 'baz', 'foobar': 2}}

    data = [{'foo': 'baz', 'foobar': 1}, {'foo': 'baz', 'foobar': 2}]
    assert core._rekey_on_member(data, 'foo', 'overwrite') == {'baz': {'foo': 'baz', 'foobar': 1}}

    data = {'foo': 'bar', 'foobar': 1}

# Generated at 2022-06-23 10:22:55.527708
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, 2) == 2
    assert inversepower(4, 4) == 1.5
    assert inversepower(16) == 4
    assert inversepower(8, 3) == 2

# Generated at 2022-06-23 10:23:03.277284
# Unit test for function human_readable
def test_human_readable():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    def load(data):
        return AnsibleLoader(None, data).get_single_data()

    def dump(data):
        return AnsibleDumper().dump(data, Dumper=AnsibleDumper)

    def check(data):
        loaded = load(dump(data))
        if loaded != data:
            raise AssertionError('%r != %r' % (loaded, data))

    # Test some sample data

# Generated at 2022-06-23 10:23:07.489975
# Unit test for function symmetric_difference
def test_symmetric_difference():
    environment = {}
    a = [1, 2, 3, 4]
    b = [3, 4, 5, 6]
    c = symmetric_difference(environment, a, b)
    assert sorted(c) == [1, 2, 5, 6]

# Generated at 2022-06-23 10:23:15.558992
# Unit test for function rekey_on_member
def test_rekey_on_member():
    member = {
        'a': {'key': 'a', 'val': 1},
        'b': {'key': 'b', 'val': 2},
        'c': {'key': 'c', 'val': 3}
    }
    assert rekey_on_member(member, 'key') == member

    member.update({'d': {'val': 4, 'key': 'd'}})
    assert rekey_on_member(member, 'key') == member

    # Test exception handling
    try:
        rekey_on_member(member, 'bad_key')
        assert 0
    except AnsibleFilterError:
        pass
    try:
        rekey_on_member(member, 'key', 'bad_option')
        assert 0
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:23:17.340233
# Unit test for function power
def test_power():
    assert power(2, 3) == 8.0



# Generated at 2022-06-23 10:23:27.057460
# Unit test for function unique
def test_unique():
    env = {}
    a = [1, 2, 3, 2, 1]
    b = unique(env, a, True)
    assert b == [1, 2, 3]
    a = "(1, 2, 3, 2, 1)"
    b = unique(env, a, True)
    assert b == ['1', '2', '3']
    a = [{'foo': 'bar', 'zoo': 'moo'}, {'foo': 'baz', 'zoo': 'moo'}, {'foo': 'bar', 'zoo': 'zoo'}]
    b = unique(env, a, True, 'foo')
    assert b == [{'foo': 'bar', 'zoo': 'moo'}, {'foo': 'baz', 'zoo': 'moo'}]

# Generated at 2022-06-23 10:23:34.384868
# Unit test for function union
def test_union():
    f = union({}, [1, 2, 3], [4, 5, 6])
    f2 = union({}, [1, 2, 3], [3, 4, 5], [6, 5, 4])
    assert f == [1, 2, 3, 4, 5, 6]
    assert f2 == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-23 10:23:42.890586
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(25, base=5) == 2.0
    assert inversepower(5, base=5) == 1.0
    assert inversepower(1) == 1.0
    assert inversepower(276.12) == 16.6
    assert inversepower(16.6) == 4.03
    assert inversepower(2, base=2) == 1.414213562373095
    assert inversepower(4, base=2) == 2.0
    assert inversepower(225, base=3) == 5.0
    assert inversepower(125, base=5) == 2.0
    assert inversepower(0.01, base=2) == 0.1
    assert inversepower(0.03, base=2) == 0.1732050807568877
    assert inversepower(0, base=2) == 0.0

# Generated at 2022-06-23 10:23:46.282355
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['zip_longest'] == zip_longest

# Generated at 2022-06-23 10:23:51.701534
# Unit test for function difference
def test_difference():
    list1 = ['key_10', 'key_20', 'key_30']
    list2 = ['key_20', 'key_25', 'key_30']

    assert difference(None, list1, list2) == ['key_10']


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-vvs', '-x'])

# Generated at 2022-06-23 10:23:58.897405
# Unit test for function max
def test_max():
    module = FilterModule()
    filter_func = module.filters()['max']
    assert filter_func(10, 2) == 10
    with display.override_verbosity(0):
        assert filter_func(10, 2) == 10
    assert filter_func([10, 15, 2, 20], 2) == 20
    assert filter_func([10, 15, 2, 20], "a") == 20
    assert filter_func(['a', 'b', 'c'], 'c') == 'c'
    assert filter_func([10, 15, 2, 20], attribute='a') == 20
    assert filter_func(['a', 'b', 'c'], attribute='a') == 'c'

# Generated at 2022-06-23 10:24:08.852690
# Unit test for function difference
def test_difference():
    from datetime import date
    from jinja2 import Environment
    e = Environment()


# Generated at 2022-06-23 10:24:16.696984
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100, 10) == 2
    assert logarithm(100, 2) == 6.6438561897747248
    assert logarithm(100) == 4.6051701859880918
    assert logarithm(0.01, 10) == -2
    assert logarithm(0.01, 2) == -6.6438561897747248
    assert logarithm(0.01) == -4.6051701859880918
    try:
        logarithm('a')
    except AnsibleFilterTypeError as e:
        assert 'log() can only be used on numbers' in to_text(e)



# Generated at 2022-06-23 10:24:19.583069
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert fm.filters() is not None


# Generated at 2022-06-23 10:24:22.857494
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10) == 2.302585092994046
    assert logarithm(5,5.) == 1.0
    assert logarithm(10,10) == 1.0

# Generated at 2022-06-23 10:24:34.399175
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY2, text_type
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, \
        AnsibleSequence, AnsibleUnicode

# Generated at 2022-06-23 10:24:37.103089
# Unit test for function inversepower
def test_inversepower():
    value = inversepower(9)
    assert(value == 3)

    value = inversepower(4, 2)
    assert(value == 2)


# Generated at 2022-06-23 10:24:45.390265
# Unit test for function intersect
def test_intersect():
    '''
    Test function intersect

    The function intersect tests whether the intersection of two lists/sets have a
    common element or not.
    '''
    testobj1 = dict(a=dict(b=dict(c=[1, 2, 3])))
    testobj2 = dict(a=dict(b=dict(c=[3, 4, 5])))
    # Case 1 - The two objects have a common element
    assert sorted(intersect(None, testobj1, testobj2)) == [3], "Failed to find common element in two sets"

    # Case 2 - The two objects have no common element
    testobj3 = dict(a=dict(b=dict(c=[1, 2, 3])))
    testobj4 = dict(a=dict(b=dict(c=[4, 5, 6])))

# Generated at 2022-06-23 10:24:48.604398
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('1024') == '1.0K'
    assert human_readable('1024', True) == '1.0Ki'
    assert human_readable('1024', False, 'Ki') == '1.0Ki'
    assert human_readable(1024, False) == '1.0K'
    assert human_readable('1024', 'Ki') == '1.0Ki'



# Generated at 2022-06-23 10:25:00.369943
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(2, 2) == 1.4142135623730951, "The square root of 2 isn't 1.4142135623730951"
    assert inversepower(4, 2) == 2, "The square root of 4 isn't 2"
    assert inversepower(5, 2) == 2.23606797749979, "The square root of 5 isn't 2.23606797749979"
    assert inversepower(2, 3) == 1.2599210498948732, "The cube root of 2 isn't 1.2599210498948732"
    assert inversepower(8, 3) == 2, "The cube root of 8 isn't 2"
    assert inversepower(9, 3) == 2.080083823051904, "The cube root of 9 isn't 2.080083823051904"




# Generated at 2022-06-23 10:25:05.428444
# Unit test for function union
def test_union():
    f = FilterModule()
    filters = f.filters()
    assert filters['union']([1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]



# Generated at 2022-06-23 10:25:15.005325
# Unit test for function human_readable
def test_human_readable():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({})


# Generated at 2022-06-23 10:25:16.441549
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """ This is in test/utils/moduletools/test_template.py """
    pass

# Generated at 2022-06-23 10:25:17.866067
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3



# Generated at 2022-06-23 10:25:29.553255
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping, MutableSequence, Sequence
    def check_type(result):
        # Check type
        assert isinstance(result, Mapping)
        assert not isinstance(result, MutableMapping)
        assert not isinstance(result, MutableSequence)
        assert isinstance(result, Sequence)

    # Simple example
    test1 = {
        'a': {
            'id': 'a',
            'name': 'Jon Doe',
            'age': '50',
        },
        'b': {
            'id': 'b',
            'name': 'Jane Doe',
            'age': '43',
        }
    }

    result = rekey_on_member(test1, 'id')

# Generated at 2022-06-23 10:25:36.677024
# Unit test for function symmetric_difference
def test_symmetric_difference():
    env = {}
    a = [1, 2, 3, 4, 5]
    b = [3, 4, 5, 6, 7]

    symdiff = list(symmetric_difference(env, a, b))

    assert len(symdiff) == 4
    assert [1, 2] == list(symdiff[0:2])
    assert [6, 7] == list(symdiff[2:4])


# Generated at 2022-06-23 10:25:45.218989
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 4, 6]) == [2]
    assert intersect([1, 2, 3], [2, 4, 6, 1]) == [2, 1]
    assert intersect([1, 2, 3], []) == []
    assert intersect([], []) == []
    assert intersect([1, 2, 3], None) == []
    assert intersect(None, [1, 2, 3]) == []
    assert intersect(None, None) == []
    assert intersect({'a': 'A', 'b': 'B'}, ['a', 'c']) == ['a']
    assert intersect({'a': 'A', 'b': 'B'}, ['a', 'c'], True) == ['a']

# Generated at 2022-06-23 10:25:50.649699
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2
    assert max([1, 2], [3, 4]) == [3, 4]
    assert max([1, 2], [3, 4], key=lambda x: max(x)) == [3, 4]

