

# Generated at 2022-06-23 10:15:59.794040
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("100") == 100
    assert human_to_bytes("100.0") == 100
    assert human_to_bytes("100.1") == 100
    assert human_to_bytes("100.9") == 100
    assert human_to_bytes("100.5") == 101

    assert human_to_bytes("1k") == 1024
    assert human_to_bytes("1K") == 1024
    assert human_to_bytes("1ko") == 1024
    assert human_to_bytes("1Ki") == 1024
    assert human_to_bytes("1Kib") == 1024
    assert human_to_bytes("1KiB") == 1024
    assert human_to_bytes("1kb") == 1000
    assert human_to_bytes("1kB") == 1000

# Generated at 2022-06-23 10:16:03.218193
# Unit test for function power
def test_power():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['pow'](2, 3) == 8
    assert filters['pow'](1, 1) == 1



# Generated at 2022-06-23 10:16:14.585690
# Unit test for function union
def test_union():
    # Union of two strings
    assert union("hello", "world") == list("helowrd")

    # Union of a string and a list
    assert union("hello", ["w", "o", "r", "l", "d"]) == list("helowrd")

    # Union of a string and a dict
    assert union("hello", dict(zip(["w", "o", "r", "l", "d"], [6, 7, 8, 9, 10]))) == list("helowrd")

    # Union of two lists of strings
    assert union(["hello"], ["world"]) == list("helowrd")

    # Union of two lists
    assert union([1, 2, 3, 4], [5, 6, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 8]

    # Union of two

# Generated at 2022-06-23 10:16:21.910455
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(x=8, base=2) == 3
    assert logarithm(x=8, base=10) == 0.903
    assert logarithm(x=10, base=10) == 1
    try:
        logarithm(x='hello', base=2)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "logarithm('hello', 2) should fail."


# Generated at 2022-06-23 10:16:31.146306
# Unit test for function human_readable
def test_human_readable():
    '''
    Unit test for function human_readable
    '''
    hr_filter = FilterModule().filters()['human_readable']

    # Default unit: byte
    assert hr_filter(2) == '2B'
    assert hr_filter(20) == '20B'
    assert hr_filter(2000) == '2000B'
    assert hr_filter(2048) == '2.00KB'
    assert hr_filter(2097152) == '2.00MB'
    assert hr_filter(2147483648) == '2.00GB'

    # Unit: kilobyte
    assert hr_filter(100, unit='KB') == '100KB'
    assert hr_filter(1024, unit='KB') == '1.00MB'

# Generated at 2022-06-23 10:16:38.033259
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100) == 2.0
    assert logarithm(100, 10) == 2.0
    assert logarithm(1024, 2) == 10.0
    assert logarithm(10.0, 2.0) == 3.3219280948873626
    try:
        logarithm("bogus", 2)
    except AnsibleFilterTypeError as e:
        assert "can only be used on numbers" in to_native(e)



# Generated at 2022-06-23 10:16:48.350149
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference(None, [1, 2, 3, 4, 5], [1, 4, 5, 6, 7]) == [2, 3, 6, 7]
    # test strings
    assert symmetric_difference(None, [1, 2, 3, 4, 5], ['1', '4', '5', '6', '7']) == [2, 3, '6', '7', '1']
    # test unicode
    assert symmetric_difference(None, [1, 2, 3, 4, 5], [u'\u0031', u'\u0034', u'\u0035', u'\u0036', u'\u0037']) == [2, 3, u'\u0036', u'\u0037', u'\u0031']

    # test mixed datat

# Generated at 2022-06-23 10:16:57.977570
# Unit test for function rekey_on_member
def test_rekey_on_member():
    '''
    Test cases for function rekey_on_member

    '''
    from ansible import errors

    # Test cases for rekey_on_member
    # Arguments: args, result
    # rekey_on_member(data, key, duplicates='error')

# Generated at 2022-06-23 10:17:07.077388
# Unit test for function inversepower
def test_inversepower():
    from ansible.module_utils.common.text.converters import to_bytes
    assert inversepower(8) == 2
    assert inversepower(64) == 2
    assert inversepower(73) == 2
    assert inversepower(8, 2) == 2
    assert inversepower(64, 2) == 2
    assert inversepower(73, 2) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(27, 3.0) == 3
    assert inversepower(8, 10) == 0.5
    assert inversepower(64, 2.0) == 2.0
    assert inversepower(73, 2.0) == 2.0
    assert inversepower(27, 3.0) == 3.0
    assert inversepower(8, 10.0) == 0.5

# Generated at 2022-06-23 10:17:14.285004
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('123.45M') == 128742400
    assert human_to_bytes('0kB') == 0
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('2.3K') == 2355
    assert human_to_bytes('3.4G') == 3664439296
    assert human_to_bytes('4.5T') == 4915281894400
    assert human_to_bytes('5.6P') == 60368540620800
    assert human_to_bytes('6.1e') == 642649600
    assert human_to_bytes('7.0Z') == 751619276800
    assert human_to_bytes('888Y') == 984999344742400
    assert human_to_bytes('1234.5')

# Generated at 2022-06-23 10:17:20.504517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    #############################################################
    # set up method variables
    #############################################################
    the_list = [1, 2, 3, 2, 3]
    the_list_s = [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 2}, {'a': 3}]
    the_dict = dict([(x, y) for x, y in zip(the_list, the_list_s)])

    #############################################################
    # set up the test methods
    #############################################################
    test_obj = FilterModule()

    #############################################################
    # run tests
    #############################################################
    # set theory
    assert test_obj.filters()['unique'](the_list) == [1, 2, 3]
    assert test_obj.filters()

# Generated at 2022-06-23 10:17:31.094882
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    d = {'a_dict': {'param1': 1, 'param2': 'string', 'param3': True}}

    # Test unique filter
    assert fm.filters()['unique']([1,2,1,2]) == [1, 2]

    # Test intersect filter
    assert fm.filters()['intersect'](['a','b','c','x','y','z'], ['a','d','q','w','c']) == ['c', 'a']

    # Test difference filter
    assert fm.filters()['difference'](['a','b','c','x','y','z'], ['a','d','q','w','c']) == ['b', 'y', 'z', 'x']

    # Test symmetric_difference filter

# Generated at 2022-06-23 10:17:37.673461
# Unit test for function logarithm
def test_logarithm():
    assert math.log(2) == logarithm(2)
    assert math.log10(2) == logarithm(2, 10)
    try:
        logarithm('a')
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-23 10:17:50.353260
# Unit test for function human_readable
def test_human_readable():
    """human_readable test cases"""

# Generated at 2022-06-23 10:18:00.758827
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import iteritems
    from ansible_collections.ansible.netcommon.tests import test_filter_plugins

    data = [
        {'num': 1, 'foo': 'a'},
        {'num': 2, 'foo': 'b'},
        {'num': 0, 'foo': 'c'}
    ]

    expected_result = {
        0: {'num': 0, 'foo': 'c'},
        1: {'num': 1, 'foo': 'a'},
        2: {'num': 2, 'foo': 'b'},
    }

    new_obj = test_filter_plugins.rekey_on_member(data, 'num', duplicates='overwrite')
    if (not isinstance(new_obj, dict)):
        raise Ansible

# Generated at 2022-06-23 10:18:05.095333
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [4, 3, 2]) == [1, 2, 3, 4]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], [1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-23 10:18:11.964279
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([-1, -2, -3]) == -3
    assert min([2, 3, -1]) == -1
    assert min([1, 2, 3], attribute='test') == 1
    assert min([-1, -2, -3], attribute='test') == -3
    assert min([2, 3, -1], attribute='test') == -1



# Generated at 2022-06-23 10:18:23.080078
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test it with string only (no unit)
    assert human_to_bytes(0) == 0
    assert human_to_bytes(1) == 1
    assert human_to_bytes(123) == 123
    assert human_to_bytes(123.0) == 123.0

    # Test it with units
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('123B') == 123
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1.1K') == 1.1 * 1024
    assert human_to_bytes('.5K') == .5 * 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1.1M') == 1.1 * 1024 * 1024
    assert human_to_

# Generated at 2022-06-23 10:18:28.861699
# Unit test for function max
def test_max():
    assert max([3, 1, 2]) == 3
    assert max(['abc', 'bca', 'cab'], key=len) == 'abc'
    assert max((5, 7, 8)) == 8
    assert max({1: 3, 2: 5, 3: 6}) == 3



# Generated at 2022-06-23 10:18:35.180528
# Unit test for function max
def test_max():
    assert max([3, 5, 2]) == 5
    assert max([3, 5, 2], 4) == 5
    assert max([3, 5, 2], 5) == 5
    assert max([3, 5, 2], 6) == 6
    assert max((i for i in (3, 5, 2))) == 5
    assert max(x for x in (3, 5, 2)) == 5
    assert max(3 for x in (3, 5, 2)) == 3
    assert max(x for x in (3, 5, 2) if x != 3) == 5

# Generated at 2022-06-23 10:18:45.434466
# Unit test for function intersect
def test_intersect():
    try:
        import jinja2
    except ImportError:
        return

    env = jinja2.Environment()
    test_list_1 = ['1', '2', '3', '4', '5']
    test_list_2 = ['5', '4', '3', '2', '1']
    test_list_3 = ['1', '4', '3']
    test_string_1 = '12222'
    test_string_2 = '22122'
    test_string_3 = '123'


# Generated at 2022-06-23 10:18:50.846661
# Unit test for function inversepower
def test_inversepower():
    # Test with valid numbers
    assert inversepower(x=9, base=3) == 2
    assert inversepower(x=27, base=3) == 3
    assert inversepower(x=4, base=2) == 2
    # Test with float numbers
    assert inversepower(x=9.0, base=3) == 2.0
    assert inversepower(x=27.0, base=3) == 3.0
    assert inversepower(x=4.0, base=2) == 2.0
    # Test with invalid number, raise exception
    try:
        inversepower(x='abc', base=2)
        assert False, 'Expected exception'
    except AnsibleFilterTypeError:
        pass
    # Test with invalid base, raise exception

# Generated at 2022-06-23 10:19:01.989456
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    dict_result = FilterModule().filters()
    assert dict_result['min'] == min
    assert dict_result['max'] == max
    assert dict_result['log'] == logarithm
    assert dict_result['pow'] == power
    assert dict_result['root'] == inversepower
    assert dict_result['unique'] == unique
    assert dict_result['intersect'] == intersect
    assert dict_result['difference'] == difference
    assert dict_result['symmetric_difference'] == symmetric_difference
    assert dict_result['union'] == union
    assert dict_result['product'] == itertools.product
    assert dict_result['permutations'] == itertools.permutations
    assert dict_result['combinations'] == itertools.combinations
    assert dict_result['human_readable'] == human

# Generated at 2022-06-23 10:19:10.025466
# Unit test for function union
def test_union():
    env = {}
    assert union(env, [0], [0]) == [0]
    assert union(env, ['a'], ['a']) == ['a']
    assert union(env, [0], []) == [0]
    assert union(env, [], [0]) == [0]
    assert union(env, [0], [0, 1]) == [0, 1]
    assert union(env, [0, 1], [0]) == [0, 1]
    assert union(env, [], []) == []

# Generated at 2022-06-23 10:19:11.749342
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-23 10:19:16.946236
# Unit test for function unique
def test_unique():
    environment = {}
    a = ['a', 'b', 'c', 'b', 'a', 'a', 'd']
    assert ['a', 'b', 'c', 'd'] == unique(environment, a)
    assert ['a', 'b', 'c', 'b'] == unique(environment, a, case_sensitive=False)
    assert ['d'] == unique(environment, a, attribute='endswith', value='d')

# Generated at 2022-06-23 10:19:26.685022
# Unit test for function intersect
def test_intersect():
    module = FilterModule()

    my_intersect = module.filters()['intersect']

    # test that dicts are not allowed
    dict1 = dict(k1='v1', k2='v2', k3='v3')
    dict2 = dict(k4='v4', k5='v5', k6='v6')
    result = my_intersect(dict1, dict2)
    assert result == []

    # test set theory returns
    data1 = ["a", "b", "c", "d", "e", "f", "g", "h"]
    data2 = ["a", "b", "c", "d", "e", "f", "g", "h"]
    result = my_intersect(data1, data2)

# Generated at 2022-06-23 10:19:36.643211
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test product()
    f = FilterModule().filters()
    assert list(f['product']([1, 2], [3, 4], [5, 6])) == [(1, 3, 5), (1, 3, 6), (1, 4, 5), (1, 4, 6), (2, 3, 5), (2, 3, 6), (2, 4, 5), (2, 4, 6)]

    # Test permutations()
    assert list(f['permutations']([1, 2, 3])) == [(1, 2, 3), (1, 3, 2), (2, 1, 3), (2, 3, 1), (3, 1, 2), (3, 2, 1)]

# Generated at 2022-06-23 10:19:43.433224
# Unit test for function logarithm
def test_logarithm():
    # return True
    # Normal operation
    assert logarithm(1) == 0
    assert logarithm(32) == 3
    assert logarithm(12, 10) == math.log10(12)
    assert logarithm(5,5) == 1

    # Exception handling
    caught = False
    try:
        logarithm("a")
    except AnsibleFilterTypeError as e:
        caught = True
        assert "log() can only be used on numbers: float" in to_native(e)

    assert caught


# Generated at 2022-06-23 10:19:49.935359
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1) == '1.0 B', "Error in bytes size"
    assert human_readable(2000) == '1.9 KB', "Error in KBytes size"
    assert human_readable(100000) == '97.7 KB', "Error in KBytes size"
    assert human_readable(1000000) == '976.6 KB', "Error in MBytes size"
    assert human_readable(1000000000) == '953.7 MB', "Error in MBytes size"
    assert human_readable(1000000000000) == '931.3 GB', "Error in MBytes size"
    assert human_readable(1000000000000000) == '909.5 TB', "Error in MBytes size"
    assert human_readable(1000000000000000000) == '888.0 PB', "Error in MBytes size"
    assert human_

# Generated at 2022-06-23 10:19:59.026630
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_FilterModule = FilterModule()
    assert test_FilterModule.filters()['min'] == min
    assert test_FilterModule.filters()['max'] == max
    assert test_FilterModule.filters()['log'] == logarithm
    assert test_FilterModule.filters()['pow'] == power
    assert test_FilterModule.filters()['root'] == inversepower
    assert test_FilterModule.filters()['unique'] == unique
    assert test_FilterModule.filters()['intersect'] == intersect
    assert test_FilterModule.filters()['difference'] == difference
    assert test_FilterModule.filters()['symmetric_difference'] == symmetric_difference
    assert test_FilterModule.filters()['union'] == union
    assert test_FilterModule.filters()['product']

# Generated at 2022-06-23 10:20:00.065879
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:20:03.101755
# Unit test for function union
def test_union():
    a = [1, 2, 3]
    b = [1, 2, 4]
    c = union(None, a, b)
    assert c == [1, 2, 3, 4]



# Generated at 2022-06-23 10:20:09.550374
# Unit test for function unique
def test_unique():
    # Initialize test parameters
    a = [1, 1, 2, 3, 3, 3, 4, 4, 5, 5, 6, 7, 8, 8, 9, 9, 9, 10]
    result = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    # Call function to test
    b = unique(None, a)

    # Assert results
    assert b == result, "Expected Result: %s, Result: %s" % (result, b)



# Generated at 2022-06-23 10:20:11.332003
# Unit test for function unique
def test_unique():
    data = [1, 2, 2, 3, 4, 4, 5, 6, 6, 7, 8, 8, 9]
    assert unique(data) == [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-23 10:20:12.282251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:20:22.170837
# Unit test for function human_to_bytes
def test_human_to_bytes():
    human_to_bytes('5') == 5
    human_to_bytes('5') == 5
    human_to_bytes('5b') == 5
    human_to_bytes('5B') == 5
    human_to_bytes('5m') == 5 * 1024 * 1024
    human_to_bytes('5M') == 5 * 1024 * 1024
    human_to_bytes('5k') == 5 * 1024
    human_to_bytes('5K') == 5 * 1024
    human_to_bytes('5kib') == 5 * 1024
    human_to_bytes('5KiB') == 5 * 1024
    human_to_bytes('5kb') == 5 * 1000
    human_to_bytes('5kB') == 5 * 1000
    human_to_bytes('5gib') == 5 * 1024 * 1024 * 1024
    human

# Generated at 2022-06-23 10:20:31.777718
# Unit test for function union
def test_union():
    for v1 in range(4):
        for v2 in range(4):
            for v3 in range(4):
                for v4 in range(4):
                    for v5 in range(4):
                        for v6 in range(4):
                            s1 = set()
                            r1 = []
                            if v1:
                                s1.add(1)
                                r1.append(1)
                            if v2:
                                s1.add(2)
                                r1.append(2)
                            if v3:
                                s1.add(3)
                                r1.append(3)
                            if v4:
                                s1.add('i1')
                                r1.append('i1')

# Generated at 2022-06-23 10:20:40.422228
# Unit test for function difference
def test_difference():
    result = difference([1,2,3], [1,2])
    assert len(result) == 1
    assert result[0] == 3

    result = difference([1,2,3], [4,5])
    assert len(result) == 3

    result = difference([1,2,3], [4,5,3,4])
    assert len(result) == 2
    assert result == [1,2]

    result = difference([1,2,3], [4,5,3,4,1,2])
    assert len(result) == 0

    result = difference([1,2,3,1], [1,2,3,1])
    assert len(result) == 0

# Generated at 2022-06-23 10:20:46.385402
# Unit test for function max
def test_max():
    assert max(range(4)) == 3
    assert max([[1, 2], [3, 9], [4, -2]]) == [3, 9]
    assert max([[1, 2], [3, 9], [4, -2]], key=lambda a: a[1]) == [4, -2]
    assert max([[1, 2], [3, 9], [4, -2]], default=42) == [3, 9]
    assert max([]) == []


# Generated at 2022-06-23 10:20:50.623105
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100) == math.log(100)
    assert logarithm(100, 10) == math.log10(100)
    assert logarithm(17, 3) == math.log(17, 3)



# Generated at 2022-06-23 10:21:00.872443
# Unit test for function intersect
def test_intersect():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.ajson import AnsibleJSONEncoder
    a = ['a', 'b', 'c', 'd', 'e']
    b = ['a', 'b', 'c', 'f', 'g']
    c = [{'a': 1}, {'b': 2}, {'c': 3}, {'d': 4}, {'e': 5}]
    d = [{'a': 5}, {'b': 2}, {'c': 3}, {'f': 4}, {'g': 5}]
    e = [{'a': 1}, {'b': 2}, {'c': 3}, {'d': 4}, 'e']

# Generated at 2022-06-23 10:21:07.765602
# Unit test for function union
def test_union():
    module_utils = __import__('ansible.module_utils.common.math', globals(), locals(), ['math'])
    math = module_utils.math

    a = [1, 2, 3, 4]
    b = [1, 2, 4, 5]
    assert math.union(a, b) == [1, 2, 3, 4, 5]


# Generated at 2022-06-23 10:21:18.188064
# Unit test for function difference
def test_difference():
    f = FilterModule().filters()
    assert f['difference']('abc', 'abcd') == 'c'
    assert f['difference']([1, 2, 3], [1, 2, 4]) == [3]
    assert f['difference']((1, 2, 3), (1, 2, 4)) == (3,)
    assert f['difference']({'a': 'b', 'c': 'd', 'e': 'f'}, {'a': 'B', 'c': 'D', 'e': 'f'}) == {'a': 'b', 'c': 'd'}
    assert f['difference']([1, 2, 3], (1, 2, 4)) == [3]


# Generated at 2022-06-23 10:21:25.280811
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1,2,3]
    b = [1,3,5]
    difference = [2,5]

    c = [1,2,3,4]
    d = [2,4,6,8]
    sym_difference = [1,3,5,7]

    assert symmetric_difference(a,b) == difference
    assert symmetric_difference(c,d) == sym_difference

# Generated at 2022-06-23 10:21:32.050642
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, 4.0) == 16.0
    assert power(2, -1) == 0.5

    assert power(-2, 3) == -8

    try:
        power(2, "a")
        assert False
    except AnsibleFilterTypeError:
        pass

    try:
        power("a", "b")
        assert False
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-23 10:21:43.085828
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1, False) == '1 B'
    assert human_readable(100, False) == '100 B'
    assert human_readable(1024, False) == '1 KB'
    assert human_readable(1024*1024, False) == '1 MB'
    assert human_readable(1024*1024*1024, False) == '1 GB'
    assert human_readable(1024*1024*1024*1024, False) == '1 TB'
    assert human_readable(1024*1024*1024*1024*1024, False) == '1 PB'
    assert human_readable(1024*1024*1024*1024*1024*1024, False) == '1024 PB'
    assert human_readable(1234, False) == '1234 B'
    assert human_readable(1234567, False) == '1234.6 KB'


# Generated at 2022-06-23 10:21:49.046306
# Unit test for function inversepower
def test_inversepower():
    assert 2 == inversepower(4, base=2)
    assert 3 == inversepower(27, base=3)
    assert 2 == inversepower(8, base=4)
    assert 5 == inversepower(3125, base=5)
    assert 6 == inversepower(46656, base=6)
    assert 7 == inversepower(823543, base=7)
    assert 8 == inversepower(16777216, base=8)
    assert 9 == inversepower(387420489, base=9)
    assert 10 == inversepower(10000000000, base=10)

# Generated at 2022-06-23 10:21:50.332678
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-23 10:21:52.005454
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1



# Generated at 2022-06-23 10:22:00.990934
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Test method 'filters' for class FilterModule"""
    obj = FilterModule()
    attrs_filter_module = ('product', 'permutations', 'combinations', 'min',
                           'max', 'log', 'pow', 'root', 'unique', 'intersect',
                           'difference', 'symmetric_difference', 'union',
                           'human_readable', 'human_to_bytes', 'rekey_on_member',
                           'zip', 'zip_longest')

    attrs_test = obj.filters()

    err_msg = "Method 'filters' of class 'FilterModule' doesn't return the attributes list: {0}"
    assert attrs_test == attrs_filter_module, err_msg.format(attrs_test)

# Generated at 2022-06-23 10:22:07.415759
# Unit test for function intersect
def test_intersect():
    f = FilterModule()
    assert f.filters()['intersect'] == intersect
    assert intersect({}, [1, 2, 3], [2, 3, 4]) == [2, 3]
    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]
    assert intersect(set([1, 2, 3]), [2, 3, 4]) == {2, 3}
    assert intersect(set([1, 2, 3]), set([2, 3, 4])) == {2, 3}
    assert intersect('string', [2, 3, 4]) == []
    assert intersect([2, 3, 4], 'string') == []
    assert intersect(set([1, 2, 3]), 'string') == set()
    assert intersect('string', set([1, 2, 3])) == set()

# Generated at 2022-06-23 10:22:09.988188
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-23 10:22:15.761665
# Unit test for function union
def test_union():
    """
    Test Ansible union filter
    """
    f = FilterModule()
    assert f.filters()['union'] == union
    assert union([1, 2, 3], [3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union([1, 2, 1, 3], [3, 4, 2, 5]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 10:22:25.829167
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max(1, 2, 3) == 3
    assert max([1, 'a', 2, 'b']) == 2
    assert max([1, 'a', 2, 'b'], key=len) == 'a'
    assert max([1, (1, 1), 2, 'b'], key=lambda x: len(str(x))) == (1, 1)
    assert max(['a', 'b'], default='c') == 'b'
    assert max(['a', 'b'], default='c', key=len) == 'b'
    assert max([], default='c') == 'c'
    assert max([], default=1) == 1
    assert max([], default=1, key=len) == 1

# Generated at 2022-06-23 10:22:30.062994
# Unit test for function power
def test_power():
    assert power(2, 10) == 1024
    assert power(3, 4) == 81
    try:
        power("a", "b")
        assert False
    except:
        assert True
    try:
        power(2.2, 3.1)
        assert False
    except:
        assert True


# Generated at 2022-06-23 10:22:33.864553
# Unit test for function union
def test_union():
    assert union([1, 2], [2, 3]) == [1, 2, 3]
    assert union([1, 2], [1, 2]) == [1, 2]
    assert union([1, 2, 3], [3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union(["a", "b"], ["b", "c"]) == ["a", "b", "c"]



# Generated at 2022-06-23 10:22:34.936068
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'rekey_on_member' in fm.filters().keys()

# Generated at 2022-06-23 10:22:39.339029
# Unit test for function min
def test_min():
    fltr = FilterModule()
    fn = fltr.filters()['min']
    assert fn(None, [3, 1, 5]) == 1
    assert fn(None, [3, -1, 5]) == -1
    assert fn(None, []) is None


# Generated at 2022-06-23 10:22:42.148301
# Unit test for function max
def test_max():
    max = FilterModule().filters().get('max')
    assert max([1, 2, 3, 4, 5]) == 5



# Generated at 2022-06-23 10:22:45.710641
# Unit test for function power
def test_power():
    class MyFakeEnvironment:
        def __init__(self, *args):
            pass
    assert power(MyFakeEnvironment(), 2, 4) == 16

# Generated at 2022-06-23 10:22:55.141674
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.module_utils.common.text import formatters
    class MockEnvironment(object):
        def __init__(self, *args, **kwargs):
            pass
        def from_string(self, *args, **kwargs):
            return self
        def get_template(self, *args, **kwargs):
            class MockTemplate(object):
                def __init__(self, *args, **kwargs):
                    pass
                def render(self, *args, **kwargs):
                    return ''
            return MockTemplate()
        def compile_templates(self, *args, **kwargs):
            pass
        def compile(self, *args, **kwargs):
            def render(*args, **kwargs):
                return 'render'
            return render
    env = MockEnvironment()


# Generated at 2022-06-23 10:23:02.551110
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == "0 B"
    assert human_readable(0, unit='B') == "0 B"
    assert human_readable(1000, unit='B') == "1000 B"
    assert human_readable(1024, unit='B') == "1.0 KiB"
    assert human_readable(1024, unit='B', isbits=True) == "8.0 Kib"
    assert human_readable(1048576, unit='B') == "1.0 MiB"
    assert human_readable(1073741824, unit='B') == "1.0 GiB"
    assert human_readable(1152921504606846976, unit='B') == "1.0 TiB"

# Generated at 2022-06-23 10:23:12.667665
# Unit test for function max
def test_max():
    from ansible.compat.tests import unittest

    # verify max function with existing jinja2.filters.do_max function
    class TestMaxFuncJinja(unittest.TestCase):
        def setUp(self):
            self.func_jinja = HAS_MIN_MAX
            self.func_ansible = not HAS_MIN_MAX

        def test_int_value(self):
            if self.func_jinja:
                self.assertEqual(max([1, 2, 3, 4, 5]), 5)
            if self.func_ansible:
                self.assertEqual(max([1, 2, 3, 4, 5]), 5)


# Generated at 2022-06-23 10:23:21.610155
# Unit test for function difference
def test_difference():

    f = FilterModule()
    env = {}
    a = [1, 2, 3, 4, 4, 5, 6, 7, 7, 8, 9, 9]
    b = [1, 2, 2, 3, 3, 4, 5, 6, 6, 7, 8, 9, 9, 9]

    r = f.filters()['difference'](env, a, b)
    if r != [4, 7]:
        raise AssertionError("difference(%s, %s) returned %s" % (a, b, r))


# Generated at 2022-06-23 10:23:28.272742
# Unit test for function inversepower
def test_inversepower():
    f = FilterModule()
    math = f.filters()
    assert math['root'](9) == 3
    assert math['root'](9, 3) == 2
    assert math['root'](64, 4) == 2
    assert math['root'](x=64, base=4) == 2
    assert math['root'](y=4, x=64) == 2
    # Error tests
    try:
        math['root'](5, 0)
    except AnsibleFilterTypeError as e:
        assert 'root() can only be used on numbers' in to_text(e)



# Generated at 2022-06-23 10:23:39.664053
# Unit test for function unique
def test_unique():
    u = unique([1, 2, 3, 1, 3])
    assert u == [1, 2, 3]

    u = unique([1, 2, 3, 1, 3], case_sensitive=False)
    assert u == [1, 2, 3]

    u = unique([1, 2, 3, 1, 3], attribute='attr')
    assert u == [1, 2, 3]

    u = unique([{'ip': '10.0.0.1', 'attr': 'a'}, {'ip': '20.0.0.1', 'attr': 'b'}, {'ip': '10.0.0.1', 'attr': 'c'}], attribute='ip')

# Generated at 2022-06-23 10:23:51.433548
# Unit test for function intersect
def test_intersect():
    actual = intersect([1, 2, 3], [2, 3])
    assert actual == [2, 3]
    actual = intersect([1, 2, 3], [2, 3, 4])
    assert actual == [2, 3]
    actual = intersect([1, 2, 3], [3, 4])
    assert actual == [3]
    actual = intersect(['a', 'b'], ['b', 'c'])
    assert actual == ['b']
    actual = intersect('abcdefg', 'bcdef')
    assert actual == ['b', 'c', 'd', 'e']
    actual = intersect('abcdefg', 'bcdef')
    assert actual == ['b', 'c', 'd', 'e']
    actual = intersect('abcde', 'cdefg')
    assert actual == ['c', 'd', 'e']


# Generated at 2022-06-23 10:23:53.024429
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'zip' in filters
    assert 'root' in filters


# Unit tests for functions defined outside of a class

# Generated at 2022-06-23 10:23:58.643700
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)

    filters = FilterModule.filters(FilterModule)
    assert isinstance(filters, dict)

    expected_filters = {
        'combinations', 'difference', 'human_readable', 'human_to_bytes', 'intersect', 'log', 'max', 'min', 'permutations', 'pow', 'product', 'rekey_on_member', 'root', 'symmetric_difference', 'union', 'unique', 'zip', 'zip_longest'
    }
    assert expected_filters == set(filters.keys())

# Generated at 2022-06-23 10:24:08.758721
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(0, True) == '0 B'
    assert human_readable(0, isbits=True) == '0 B'

    assert human_readable(1) == '1 B'
    assert human_readable(1, True) == '1 B'
    assert human_readable(1, isbits=True) == '1 B'

    assert human_readable(1000) == '1.0 kB'
    assert human_readable(1000, True) == '1.0 kB'
    assert human_readable(1000, isbits=True) == '1000 B'

    assert human_readable(1023) == '1.0 kB'
    assert human_readable(1023, True) == '1.0 kB'

# Generated at 2022-06-23 10:24:12.200190
# Unit test for function intersect
def test_intersect():
   assert ([1, 2, 3] == intersect([1, 2, 3], [2, 3, 4]))
   assert ([2, 3] == intersect([1, 2, 2, 3], [2, 3, 4]))
   assert ([] == intersect([1, 2, 2, 3], [4, 5, 6]))


# Generated at 2022-06-23 10:24:22.659808
# Unit test for function max
def test_max():
    # No arguments
    assert max([]) == None

    # Numeric
    assert max([1, 2, 3]) == 3
    assert max([3, 2, 1]) == 3

    assert max([3, '2', 1]) == 3

    # String
    assert max(['1', '2', '3']) == '3'
    assert max(['3', '2', '1']) == '3'

    # Mixed
    assert max(['1', 2, '3']) == '3'
    assert max([1, '2', 3]) == 3

# Generated at 2022-06-23 10:24:24.154558
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-23 10:24:34.092391
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3
    assert max('abc') == 'c'
    assert max('abc', 'ab', 'abc', 'xyz') == 'xyz'
    assert max(['a', 'b', 'c'], ['x', 'y', 'z'], key=lambda x: x[-1]) == ['x', 'y', 'z']
    try:
        max([1, 2, 'a'])
        assert False, 'Expected exception'
    except TypeError:
        pass
    try:
        max([1, 2, 3], 4, 5, 6)
        assert False, 'Expected exception'
    except TypeError:
        pass


# Generated at 2022-06-23 10:24:37.354094
# Unit test for function logarithm
def test_logarithm():
    module = FilterModule()
    filters = module.filters()
    result = filters['log'](10, 10)
    assert math.isclose(result, 1.0)



# Generated at 2022-06-23 10:24:39.310315
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(2, 5) == 2**(1.0/float(5))

# Generated at 2022-06-23 10:24:51.179094
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()

# Generated at 2022-06-23 10:25:01.735860
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'min' in filters
    assert 'max' in filters
    assert 'log' in filters
    assert 'pow' in filters
    assert 'root' in filters
    assert 'unique' in filters
    assert 'intersect' in filters
    assert 'difference' in filters
    assert 'symmetric_difference' in filters
    assert 'union' in filters
    assert 'product' in filters
    assert 'permutations' in filters
    assert 'combinations' in filters
    assert 'human_readable' in filters
    assert 'human_to_bytes' in filters
    assert 'rekey_on_member' in filters
    assert 'zip' in filters
    assert 'zip_longest' in filters

# Generated at 2022-06-23 10:25:02.956757
# Unit test for function inversepower
def test_inversepower():
    ret = inversepower(4)
    assert ret == 2

# Generated at 2022-06-23 10:25:10.695511
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, base=2) == 2
    assert inversepower(8, base=3) == 2
    assert inversepower(27, base=3) == 3
    assert inversepower(64, base=4) == 4
    assert inversepower(125, base=5) == 5
    assert inversepower(256, base=4) == 4
    assert inversepower(512, base=4) == 8
    assert inversepower(1, base=2) == 1


# Generated at 2022-06-23 10:25:18.900780
# Unit test for function max
def test_max():
    filter = FilterModule()
    func = filter.filters()['max']
    assert func([1, 2, 3, 4]) == 4
    assert func([4, 3, 2, 1]) == 4
    assert func((1, 2, 3, 4)) == 4
    assert func((4, 3, 2, 1)) == 4
    assert func({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == 4
    assert func({'d': 4, 'c': 3, 'b': 2, 'a': 1}) == 4


# Generated at 2022-06-23 10:25:21.793970
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min(1, 2, 3) == 1


# Generated at 2022-06-23 10:25:31.538305
# Unit test for function union
def test_union():
    f = FilterModule()
    assert f.filters()['union']([1, 2], [2, 3]) == [1, 2, 3]
    assert f.filters()['union']([1, 2], [2, 3, 4]) == [1, 2, 3, 4]
    assert f.filters()['union']([1, 2, 5], [2, 3]) == [1, 2, 3, 5]
    assert f.filters()['union']([1, 2, 5], [2, 3, 7, 8]) == [1, 2, 3, 5, 7, 8]
    assert f.filters()['union'](["a", "b"], ["c", "b", "e"]) == ["a", "b", "c", "e"]

# Generated at 2022-06-23 10:25:36.670153
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3, 4, 5]
    b = [2, 4, 6, 8, 10]
    c = [1, 3, 5, 6, 7, 8, 9, 10]
    assert sorted(symmetric_difference(None, a, b)) == sorted(c)


# Generated at 2022-06-23 10:25:45.250424
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [{'foo': 1, 'bar': 'baz'},
            {'foo': 2, 'baz': 'qux'},
            {'foo': 1, 'bar': 'corge'},
            {'foo': 2, 'baz': 'qux'}]

    new_obj = rekey_on_member(data, 'foo', duplicates='overwrite')
    assert new_obj == {1: {'foo': 1, 'bar': 'corge'}, 2: {'foo': 2, 'baz': 'qux'}}

    new_obj = rekey_on_member(data, 'foo', duplicates='error')
    assert new_obj == {1: {'foo': 1, 'bar': 'baz'}, 2: {'foo': 2, 'baz': 'qux'}}



# Generated at 2022-06-23 10:25:47.098516
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None

# Generated at 2022-06-23 10:25:54.398537
# Unit test for function union
def test_union():
    assert set(union([1, 2, 3, 4], [3, 4, 5, 6])) == set([1, 2, 3, 4, 5, 6])
    assert union([1, 2, 3, 4], [3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert union([1, 2, 3, 4], [3, 4, 5, 6], [7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]