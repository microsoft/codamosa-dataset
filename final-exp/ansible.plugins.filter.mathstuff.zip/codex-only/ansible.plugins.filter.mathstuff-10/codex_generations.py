

# Generated at 2022-06-23 10:15:57.018500
# Unit test for function max
def test_max():
    assert 10 == max(10)
    assert 10 == max([1, 2, 10])
    assert {'b': 2, 'c': 3} == max([{'a': 1}, {'b': 2}, {'c': 3}], key='a')
    assert {'c': 3} == max([{'a': 1}, {'b': 2}, {'c': 3}], key='c')
    assert 'foo' == max('foo', 'bar', 'baz')

# Generated at 2022-06-23 10:16:08.873061
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.filter.core import FilterModule
    import json
    import pytest
    rekey_on_member = FilterModule().filters()['rekey_on_member']

    # Verify that the filter fails when the key is not present in the dict
    with pytest.raises(AnsibleFilterError) as excinfo:
        rekey_on_member([{'foo': 'value'}], 'bar')
    assert 'was not found' in str(excinfo.value)
    with pytest.raises(AnsibleFilterError) as excinfo:
        rekey_on_member({'foo': {'foo': 'value'}}, 'bar')
    assert 'was not found' in str(excinfo.value)

# Generated at 2022-06-23 10:16:13.074516
# Unit test for function power
def test_power():
    assert power(3,3) == 27
    assert power(2,8) == 256
    assert power(2, 16) == 65536

    try:
        power('number', 'number')
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "Should be unreachable"


# Generated at 2022-06-23 10:16:19.004837
# Unit test for function human_readable
def test_human_readable():
    result = human_readable(1024)
    assert result == '1.0K'
    result = human_readable(1024 * 1024)
    assert result == '1.0M'
    result = human_readable(1024 * 1024 * 1024)
    assert result == '1.0G'
    result = human_readable(1024 * 1024 * 1024 * 1024)
    assert result == '1.0T'
    result = human_readable(1024 * 1024 * 1024 * 1024 * 1024)
    assert result == '1.0P'
    result = human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert result == '1.0E'
    result = human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert result == '1024.0E'

# Generated at 2022-06-23 10:16:23.092032
# Unit test for function unique
def test_unique():
    data = [
        'localhost',
        'localhost',
        'localhost',
        'hostname',
        'hostname',
        'hostname',
        'hostname',
        'other',
        'other',
        'other',
    ]

    assert ['localhost', 'hostname', 'other'] == unique(data)

    data = [dict(a=1), dict(a=1), dict(a=2), dict(a=2), dict(a=3), dict(a=3)]
    assert [dict(a=1), dict(a=2), dict(a=3)] == unique(data)
    assert [dict(a=1), dict(a=2), dict(a=3)] == unique(data, case_sensitive=None)

# Generated at 2022-06-23 10:16:23.686521
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:16:26.092330
# Unit test for function logarithm
def test_logarithm():
    logarithm_result = logarithm(math.e)
    assert logarithm(math.e) == logarithm_result



# Generated at 2022-06-23 10:16:28.045912
# Unit test for function difference
def test_difference():
    assert difference(['a', 'b', 'c'], ['b', 'c', 'd']) == ['a']


# Generated at 2022-06-23 10:16:39.629423
# Unit test for function difference
def test_difference():
    for left in [[], ['a', 'b'], ['a', 'b', 'c']]:
        for right in [[], ['a', 'b'], ['a', 'b', 'c']]:
            diff = difference(left, right)
            inter = intersect(left, right)
            union_ = union(left, right)
            sym_diff = symmetric_difference(left, right)

            # property 1: u1 = (u1-u2)+(u2-u1)
            assert_diff = difference(union_, inter)
            assert_sym_diff = difference(right, left)
            assert union_(diff, assert_sym_diff) == union_
            assert union_(assert_diff, sym_diff) == union_

            # property 2: (u1-u2) n (u2-u1) = 0

# Generated at 2022-06-23 10:16:50.404710
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import pytest
    from ansible.errors import AnsibleFilterError

    # Test all possible combinations of options
    duplicates_values = ['error', 'overwrite']
    argument_types = [dict, list]
    argument_values = [{'a': {'key': 'a', 'value': 1}}, [{'key': 'a', 'value': 1}]]

    for duplicates_value, argument_type, argument_value in itertools.product(duplicates_values, argument_types, argument_values):
        test_value = rekey_on_member(argument_value, 'key', duplicates=duplicates_value)

        assert argument_type == type(test_value)
        assert test_value == {'a': {'key': 'a', 'value': 1}}

    # Test various exceptions

# Generated at 2022-06-23 10:16:51.805806
# Unit test for function logarithm
def test_logarithm():
    logarithm(10, 10) == 1



# Generated at 2022-06-23 10:16:59.913688
# Unit test for function unique
def test_unique():
    d = {'foo': [1, 1, 2, 2, 3, 4],
         'bar': [2, 3, 4, 5, 5, 6],
         'baz': (4, 5, 6, 7, 7, 8),
         'bat': 'bat',
         }

    # Test calls to unique
    assert unique(d['foo'], True) == [1, 2, 3, 4]
    assert unique(d['foo'], False) == [1, 2, 3, 4]
    assert unique(d['bar'], True) == [2, 3, 4, 5, 6]
    assert unique(d['bar'], False) == [2, 3, 4, 5, 6]
    assert unique(d['baz'], True) == [4, 5, 6, 7, 8]

# Generated at 2022-06-23 10:17:06.305533
# Unit test for function logarithm
def test_logarithm():
    # Test natural logarithm
    assert math.log(math.e) == logarithm(1)

    # Test decimal logarithm
    assert math.log(10) == logarithm(10, 10)

    # Test taking 2nd order root
    assert math.sqrt(100) == inversepower(100, 2)

    # Test raising 2^4
    assert math.pow(2, 4) == power(2, 4)



# Generated at 2022-06-23 10:17:10.156052
# Unit test for function difference
def test_difference():
    list1 = [1, 2, 3]
    list2 = [0, 1, 2]
    list3 = [3, 4]
    assert difference(None, list1, list2) == [3]
    assert difference(None, list1, list3) == [1, 2]


# Generated at 2022-06-23 10:17:12.502759
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-23 10:17:16.466133
# Unit test for function symmetric_difference
def test_symmetric_difference():

    a = ['a', 'b', 'c']
    b = ['c', 'd']
    expected = ['a', 'b', 'd']
    diff = list(symmetric_difference(None, a, b))
    assert (diff == expected)

# Generated at 2022-06-23 10:17:28.286029
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import types
    # Verify all the filters
    fm = FilterModule()
    all_filters = fm.filters()
    assert isinstance(all_filters, dict)

    assert 'min' in all_filters.keys()
    assert 'max' in all_filters.keys()
    assert 'log' in all_filters.keys()
    assert 'pow' in all_filters.keys()
    assert 'root' in all_filters.keys()
    assert 'unique' in all_filters.keys()
    assert 'intersect' in all_filters.keys()
    assert 'difference' in all_filters.keys()
    assert 'symmetric_difference' in all_filters.keys()
    assert 'union' in all_filters.keys()

# Generated at 2022-06-23 10:17:36.994979
# Unit test for function unique
def test_unique():
    '''
    Test whether unique() can take case_sensitive=False, attribute='null'
    and other parameter combinations that require a featureful version of
    Jinja2
    '''
    from jinja2 import Environment
    for case_sensitive in (None, False, True):
        for attribute in (None, 'null'):
            for fail in (False, True):
                try:
                    unique(Environment(), [], case_sensitive=case_sensitive, attribute=attribute)
                except AnsibleFilterError:
                    if fail:
                        pass
                    else:
                        raise


# Unit Test for function rekey_on_member

# Generated at 2022-06-23 10:17:43.568978
# Unit test for function difference
def test_difference():
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_difference = filters['difference']

    # Test basic difference
    result = filter_difference([1, 2, 3, 4], [3, 4, 5, 6])
    assert result == [1, 2]

    # Test set difference
    result = filter_difference(set([1, 2, 3, 4]), set([3, 4, 5, 6]))
    assert result == [1, 2]

    # Test that duplicate entries are removed
    result = filter_difference([1, 1, 2, 3, 3, 4], [3, 4, 5, 6])
    assert result == [1, 2]

    # Test that ordering is retained

# Generated at 2022-06-23 10:17:47.405301
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    test_filters = {
        'intersect' : intersect,
        'difference': difference,
        'symmetric_difference' : symmetric_difference,
        'union': union,
        'product': itertools.product,
        'permutations': itertools.permutations,
        'combinations': itertools.combinations,
        'human_readable': human_readable,
        'human_to_bytes': human_to_bytes,
        'zip': zip,
        'zip_longest': zip_longest,
    }
    assert fm.filters() == test_filters

# Generated at 2022-06-23 10:17:53.538650
# Unit test for function symmetric_difference
def test_symmetric_difference():
    environment = {}
    a = ['apple', 'carrot', 'pear']
    b = ['cherry', 'carrot', 'peach']

    compare = ['apple', 'pear', 'cherry', 'peach']
    c = symmetric_difference(environment, a, b)
    c.sort()
    assert c == compare


# Generated at 2022-06-23 10:17:54.538045
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:18:03.586953
# Unit test for function max
def test_max():
    context = {}
    assert max(context, [1, 2], 1) == max([1, 2], 1)
    assert max(context, [1, 2], 5) == max([1, 2], 5)
    assert max(context, [1, 2], raw=True) == max([1, 2])
    assert max(context, [1, 2, 3, 4], as_string=True) == max([1, 2, 3, 4], as_string=True)
    assert max(context, {'a': 1, 'b': 2}, 1) == max({'a': 1, 'b': 2}, 1)
    assert max(context, {'a': 1, 'b': 2}, raw=True) == max({'a': 1, 'b': 2})

# Generated at 2022-06-23 10:18:08.658035
# Unit test for function difference
def test_difference():
    module = FilterModule()
    filters = module.filters()
    assert filters.get('difference', None) is not None
    inputlist = [1, 2, 3, 4, 5]
    inputlist2 = [1, 2, 6, 7, 8]
    result = filters['difference'](inputlist, inputlist2)
    assert result == [3, 4, 5]
    assert result != [1, 2, 3, 4, 5]



# Generated at 2022-06-23 10:18:19.630084
# Unit test for function symmetric_difference
def test_symmetric_difference():

    testA = ['a', 'b', 'c', 'd']
    testB = ['b', 'c', 'e', 'f']
    testC = ['e', 'f', 'a', 'g', 'h']

    testA_B = symmetric_difference(None, testA, testB)
    testB_A = symmetric_difference(None, testB, testA)
    testA_C = symmetric_difference(None, testA, testC)
    testC_A = symmetric_difference(None, testC, testA)

    assert testA_B == ['a', 'd', 'e', 'f']
    assert testB_A == ['a', 'd', 'e', 'f']
    assert testA_C == ['c', 'd', 'g', 'h']
   

# Generated at 2022-06-23 10:18:25.561792
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [3, 4, 5]) == [1, 2, 4, 5]
    assert symmetric_difference(['a', 'b', 'c'], ['c', 'd', 'e']) == ['a', 'b', 'd', 'e']
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []



# Generated at 2022-06-23 10:18:31.937519
# Unit test for function unique
def test_unique():
    m = FilterModule()
    u = m.filters()['unique']


# Generated at 2022-06-23 10:18:34.323542
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 10) == 1
    assert logarithm(100) == 4.6051701859880918



# Generated at 2022-06-23 10:18:41.011669
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 2) == 3.3219280948873623
    assert logarithm(10) == 2.302585092994046
    assert logarithm(1) == 0
    assert logarithm(0) == float('-inf')
    try:
        logarithm("string")
        assert False
    except AnsibleFilterTypeError:
        assert True

#Unit test for function power

# Generated at 2022-06-23 10:18:52.361469
# Unit test for function union
def test_union():
    '''
    test union filter
    '''

# Generated at 2022-06-23 10:19:02.621633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    from ansible.compat.tests import mock
    from ansible import context
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils import context_objects as co
    from ansible.utils.display import Display

    class TestFilterModule(unittest.TestCase):

        def setUp(self):
            context._init_global_context(load_plugins=False)
            self.fm = FilterModule()

        def tearDown(self):
            pass

        def test_log(self):
            base = 10
            x = 10000
            expected_value = 4
            log = self.fm.filters()['log']

# Generated at 2022-06-23 10:19:12.378868
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(42) == '42'
    assert human_readable(42, True) == '42.00b'
    assert human_readable(4200) == '4.1k'
    assert human_readable(4200, True) == '4.13k'
    assert human_readable('4199B') == '4.1k'
    assert human_readable('4209.12') == '4.2k'
    assert human_readable('4289.12', True) == '4.19k'
    assert human_readable('4289.12', True, 'Ki') == '4.19K'
    assert human_readable('4289.12', True, 'Ei') == '0.00E'



# Generated at 2022-06-23 10:19:19.712906
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.plugins.filter.core import FilterModule
    from ansible.errors import AnsibleError
    # initial test data
    data = [{'name': 'something', 'key': 'value01'}, {'name': 'anything', 'key': 'value02'},
            {'name': 'something', 'key': 'value03'}, {'name': 'nothing', 'key': 'value04'}]
    rekey = {'value01': {'name': 'something', 'key': 'value01'},
             'value02': {'name': 'anything', 'key': 'value02'},
             'value03': {'name': 'something', 'key': 'value03'},
             'value04': {'name': 'nothing', 'key': 'value04'}}
    # test rekey_on_member function
   

# Generated at 2022-06-23 10:19:24.001505
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3, 4, 5]
    b = [2, 4, 5]
    assert [1, 3] == symmetric_difference(a, b)

# Generated at 2022-06-23 10:19:28.758555
# Unit test for function difference
def test_difference():
    assert difference([1, 2, 3], [2, 3, 4]) == [1]
    assert difference([1, 2, 3], [1, 2, 3]) == []
    assert difference([1, 2, 3], [4, 5, 6, 7]) == [1, 2, 3]



# Generated at 2022-06-23 10:19:38.110198
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    f = fm.filters()
    # General math
    assert f['min']([1, 2, 3]) == 1
    assert f['max']([1, 2, 3]) == 3
    # Exponents and logarithms
    assert f['log'](10) == math.log(10)
    assert f['pow'](10, 2) == 100
    assert f['root'](10, 2) == math.sqrt(10)
    # Set theory
    assert f['unique']([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert f['intersect']([1, 2, 3], [2, 3, 4]) == [2, 3]

# Generated at 2022-06-23 10:19:44.946490
# Unit test for function logarithm
def test_logarithm():
    #pylint: disable=protected-access
    assert logarithm(1) == 0.0
    assert logarithm(2.71828183) == 1.0
    assert logarithm(1, 10) == 0.0
    assert logarithm(10, 10) == 1.0
    assert logarithm(100, 100) == 1.0
    assert logarithm(10, 2) == 3.321928095



# Generated at 2022-06-23 10:19:46.610651
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert type(filter_module.filters()) == dict


# Generated at 2022-06-23 10:19:53.966580
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(9, 2) == 3.0
    assert inversepower(11, 3) == 2.0
    assert inversepower(100, 2.5) == 4.47213595499958
    assert inversepower(100, 1.5) == 3.162
    assert inversepower(9, 3) == 2
    assert inversepower(10, 3) == 2.154434690031884
    assert inversepower(9, 9.0 / 16.0) == 2.378414230005442
    assert inversepower(9, -2) == 0.1111111111111111

# Generated at 2022-06-23 10:20:01.960281
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([-1, -2, -3]) == -3
    assert min([1.1, 2.2, 3.3]) == 1.1
    assert min([-1.1, -2.2, -3.3]) == -3.3
    assert min((1, 2, 3)) == 1
    assert min([]) == 0
    assert min(['a', 'b', 'c']) == 'a'
    assert min(['a', 'bc', 'def']) == 'a'
    assert min(['bc', 'a', 'def']) == 'a'
    # types of args vary (int and float), but returned value is int, not float
    assert type(min([1, 2.2, 3])) == int
    # test kwargs passed

# Generated at 2022-06-23 10:20:04.661616
# Unit test for function max
def test_max():
    data = [1, 5, 8, 10, 2, 5, 6, 8, 99, 5, 3]
    assert max(data) == 99

# Generated at 2022-06-23 10:20:08.202818
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2]
    b = [2, 3]
    expected = [1, 3]
    result = symmetric_difference(None, a, b)
    assert result == expected
    result = symmetric_difference(None, b, a)
    assert result == expected

# Generated at 2022-06-23 10:20:18.348849
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Basic usage
    assert human_to_bytes(42) == 42
    assert human_to_bytes('42') == 42
    assert human_to_bytes('42b') == 42
    assert human_to_bytes('42B') == 42
    assert human_to_bytes('42kB') == 42 * 1000
    assert human_to_bytes('42kB', 'B') == 42 * 1024
    assert human_to_bytes('42KiB') == 42 * 1024
    assert human_to_bytes('42mB') == 42 * 1000**2
    assert human_to_bytes('42MB') == 42 * (1024**2)
    assert human_to_bytes('42MiB') == 42 * 1024**2
    assert human_to_bytes('42gB') == 42 * 1000**3

# Generated at 2022-06-23 10:20:29.295593
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test here all the unit
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1M') == 1048576)
    assert(human_to_bytes('1G') == 1073741824)
    assert(human_to_bytes('1T') == 1099511627776)
    assert(human_to_bytes('1P') == 1125899906842624)
    assert(human_to_bytes('1E') == 1152921504606846976)
    assert(human_to_bytes('1Ki') == 1024)
    assert(human_to_bytes('1Mi') == 1048576)
    assert(human_to_bytes('1Gi') == 1073741824)
    assert(human_to_bytes('1Ti') == 1099511627776)

# Generated at 2022-06-23 10:20:35.386953
# Unit test for function logarithm
def test_logarithm():
    # Test for logarithm(x, base=math.e)
    assert logarithm(1) == 0.0
    assert logarithm(math.e) == 1.0
    assert logarithm(math.e**2) == 2.0
    assert logarithm(math.e**3) == 3.0
    assert logarithm(math.e**4) == 4.0
    assert logarithm(math.e**5) == 5.0

    # Test for logarithm(x, base=10)
    assert logarithm(1, base=10) == 0.0
    assert logarithm(10, base=10) == 1.0
    assert logarithm(100, base=10) == 2.0

# Generated at 2022-06-23 10:20:42.212608
# Unit test for function difference
def test_difference():
    data1 = [1, 2, 3, 4]
    data2 = [3, 4, 5, 6]

    expected = [1, 2]

    assert difference(None, data1, data2) == expected


# Generated at 2022-06-23 10:20:46.845318
# Unit test for function symmetric_difference
def test_symmetric_difference():
    test1 = [1, 2, 3, 4, 5]
    test2 = [4, 5, 6, 7, 8]
    assert [1, 2, 3, 6, 7, 8] == symmetric_difference(None, test1, test2)

# Generated at 2022-06-23 10:20:48.881696
# Unit test for function power
def test_power():
    assert power(2, 2) == 4



# Generated at 2022-06-23 10:20:59.489154
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test basic functionality
    data = [{'a': 1, 'b': 2, 'c': 3}, {'a': 4, 'b': 5, 'c': 6}]
    key_val = 'a'
    new_dict = rekey_on_member(data, key_val)
    assert new_dict == {1: {'a': 1, 'b': 2, 'c': 3}, 4: {'a': 4, 'b': 5, 'c': 6}}

    # Test duplicates behavior
    data = [{'a': 1, 'b': 2, 'c': 3}, {'a': 4, 'b': 5, 'c': 6}, {'a': 1, 'b': 8, 'c': 9}]
    key_val = 'a'

# Generated at 2022-06-23 10:21:10.528809
# Unit test for function symmetric_difference
def test_symmetric_difference():
    import os
    import sys
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    from ansible.module_utils import six
    from ansible.module_utils.six.moves import zip

    from ansible.module_utils.common._collections_compat import Mapping

    def dict_to_tuples(d):
        if not isinstance(d, Mapping):
            raise Exception("input is not a dict")
        return sorted(six.iteritems(d))

    in1 = dict(a=1, b=2, c=3)
    in2 = dict(a=2, b=2, c=2, d=2)

    # symmetric_difference of two dicts
    expected = dict

# Generated at 2022-06-23 10:21:12.995018
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters is not None

# Generated at 2022-06-23 10:21:26.260084
# Unit test for function power
def test_power():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = basic.AnsibleOptions(
        connection='local',
        module_path='',
        forks=100,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False)

    variable_manager = VariableManager()

    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')

    # Hosts that will be used in the test

# Generated at 2022-06-23 10:21:34.700302
# Unit test for function union
def test_union():
    assert union([1, 2, 2, 3], [2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], [3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union(['a', 'b', 'b'], ['b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert union(['a', 'abc', 'abc'], ['abc', 'd', 'a']) == ['a', 'abc', 'd']

# Generated at 2022-06-23 10:21:40.071832
# Unit test for function logarithm
def test_logarithm():
    assert round(logarithm(math.e)) == 1
    assert round(logarithm(math.e, base=math.e)) == 1
    assert round(logarithm(2, base=math.e)) == 1
    assert round(logarithm(8, base=2)) == 3



# Generated at 2022-06-23 10:21:49.660959
# Unit test for function unique
def test_unique():
    from ansible import constants as C
    from ansible.plugins.filter.core import FilterModule
    from jinja2 import Environment, StrictUndefined
    import jinja2.filters
    import sys

    env = Environment(undefined=StrictUndefined)
    env.filters = jinja2.filters.DEFAULT_FILTERS.copy()
    env.filters.update(FilterModule().filters())

    if sys.version_info >= (3, 5):
        assert env.filters['unique']([1, 2, 3, 1, 2, 3], False, None) == [1, 2, 3]

# Generated at 2022-06-23 10:22:00.488240
# Unit test for function human_to_bytes

# Generated at 2022-06-23 10:22:04.623281
# Unit test for function unique
def test_unique():
    env = {}
    a = ['hello', 'world', 'hello', 'ansible', 'hello', 'ansible']
    assert unique(env, a, case_sensitive=True) == ['hello', 'world', 'ansible']
    assert unique(env, a, case_sensitive=False) == ['hello', 'world', 'ansible']
    assert unique(env, a) == ['hello', 'world', 'ansible']


# Generated at 2022-06-23 10:22:09.496017
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.module_utils.common._collections_compat import Sequence, Set, Mapping

    with patch.object(formatters, 'get_formatter', return_value=formatters.HumanReadableFormatter()):
        with patch.object(formatters, '_formatter_plugins', return_value={}):
            simple_list = [3, 2, 4, 1]
            simple_set = set(simple_list)
            simple_dict = {'e': 5, 'a': 1, 'f': 6, 'b': 2}
            simple_tuple = tuple(simple_dict.keys())

            # Test all possible combinations of built-in collections.

# Generated at 2022-06-23 10:22:12.264472
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    for method in filter_obj.filters():
        print("Filter: {}".format(method))


# Generated at 2022-06-23 10:22:22.896864
# Unit test for function union
def test_union():
    # union(a,b) should return a + b where `a` and `b` are lists, with members of `b` only appearing once.
    # len(a) = len(b)
    a = [1,2,3,4,5]
    b = [1,2,1,1,1]

    c = union(None, a, b)
    assert len(c) == 5
    assert c == [1,2,3,4,5]

    # len(a) > len(b)
    a = [1,2,3,4,5]
    b = [1]

    c = union(None, a, b)
    assert len(c) == 5
    assert c == [1,2,3,4,5]

    # len(a) < len(b)
    a

# Generated at 2022-06-23 10:22:31.785390
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )


# Generated at 2022-06-23 10:22:43.735254
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1, human_to_bytes('1')
    assert human_to_bytes('1B') == 1, human_to_bytes('1B')
    assert human_to_bytes('1K') == 1024, human_to_bytes('1K')
    assert human_to_bytes('1M') == 1024 ** 2, human_to_bytes('1M')
    assert human_to_bytes('1G') == 1024 ** 3, human_to_bytes('1G')
    assert human_to_bytes('1T') == 1024 ** 4, human_to_bytes('1T')
    assert human_to_bytes('1b') == 1, human_to_bytes('1b')
    assert human_to_bytes('1k') == 1024, human_to_bytes('1k')
    assert human

# Generated at 2022-06-23 10:22:47.489629
# Unit test for function inversepower
def test_inversepower():
    f = inversepower(9, 2)
    assert f == 3
    f = inversepower(27, 3)
    assert f == 3


# Generated at 2022-06-23 10:22:55.579673
# Unit test for function rekey_on_member
def test_rekey_on_member():

    import json
    import pytest


# Generated at 2022-06-23 10:23:03.302899
# Unit test for function max
def test_max():
    assert max(['1', '9']) == '9'

    assert max([1, 2, 3, 4]) == 4
    assert max([[1, 2], [3, 4]]) == [3, 4]
    assert max([[1, 2], [3, 4]], key=lambda x: x[1]) == [1, 2]
    assert max([1, 2, None]) == 2
    assert max([1, 2, None], key=lambda x: x if x is not None else 0) == 2
    assert max(['1', '2']) == '2'
    assert max(['1', '2'], key=lambda x: x) == '2'
    assert max([1, 1, 2, 3, 5, 8, 13, 21], key=lambda x: float(x)) == 21

# Generated at 2022-06-23 10:23:05.909158
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # method "filters" of class "FilterModule"
    assert len(FilterModule().filters()) >= 17



# Generated at 2022-06-23 10:23:07.340109
# Unit test for function power
def test_power():
    assert power(2, 5) == 32.0



# Generated at 2022-06-23 10:23:15.477131
# Unit test for function union
def test_union():
    assert union([], []) == []
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2], [3, 4]) == [1, 2, 3, 4]
    assert union(['a', 'b', 'c', 'd'], 'abcd') == ['a', 'b', 'c', 'd']
    assert union(['a', 'b', 'c'], 'abc') == ['a', 'b', 'c']
    assert union([1, 2, 3], [1, 2, 4]) == [1, 2, 3, 4]
    assert union([1, 'a', 'b'], [2, 3, 'b']) == [1, 'a', 'b', 2, 3]

# Generated at 2022-06-23 10:23:18.530170
# Unit test for function union
def test_union():
    assert union([1, 2, 3, 4], [3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-23 10:23:25.226452
# Unit test for function max
def test_max():
    assert max((1,2,3,4,5)) == 5
    assert max([1,2,3,4,5]) == 5
    assert max('hello') == 'o'
    assert max(-1.5, 0, 1.5) == 1.5
    assert max({1: 'a', 2: 'b'}) == 2
    assert max({'a': 1, 'b': 2}) == 'b'
    assert max({'a': 'b', 'b': 'a'}) == 'b'

# Generated at 2022-06-23 10:23:26.600756
# Unit test for function power
def test_power():
    assert power(9, 2) == 81
    assert power(4, 0.5) == 2

# Generated at 2022-06-23 10:23:32.714481
# Unit test for function difference
def test_difference():
    data = {
        'foo': [1, 2, 3, 4],
        'bar': [2, 3, 4, 5]
    }
    assert difference(data=data, a='{{ foo }}', b='{{ bar }}') == [1]



# Generated at 2022-06-23 10:23:36.044426
# Unit test for function symmetric_difference
def test_symmetric_difference():
    s = [1,2,3,4]
    t = [3,4,5,6]
    res = symmetric_difference(None, s, t)
    assert res == [1,2,5,6]

# Generated at 2022-06-23 10:23:43.314301
# Unit test for function union
def test_union():
    args = [1, 2, 3]
    kwargs = {}
    result = union(args, kwargs)
    assert result == set([1, 2, 3])

    args = [set([1, 2]), set([2, 3])]
    kwargs = {}
    result = union(args, kwargs)
    assert result == set([1, 2, 3])

    args = [
        {
            'a': 1,
            'b': 2,
        },
        {
            'a': 1,
            'c': 3,
        },
    ]
    kwargs = {}
    result = union(args, kwargs)
    assert result == [{'a': 1, 'b': 2}, {'a': 1, 'c': 3}]


# Generated at 2022-06-23 10:23:46.183793
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max(2, 3, 4) == 4

# Generated at 2022-06-23 10:23:55.553673
# Unit test for function union
def test_union():
    # Testing with ints
    lst = [0, 1, 2, 3, 4]
    lst2 = [3, 4, 5, 6, 7]
    result = union(lst, lst2)
    assert result == [0, 1, 2, 3, 4, 5, 6, 7]

    # Testing with lists
    lst = ['a', 'b', 'c']
    lst2 = ['d', 'e', 'f']
    result = union(lst, lst2)
    assert result == ['a', 'b', 'c', 'd', 'e', 'f']

    # Testing with lists and duplicates
    lst = ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-23 10:24:00.393348
# Unit test for function min
def test_min():
    assert min([-1, 5, 2, -10, 15, 20, 0]) == -10
    assert min([-1, 5, 2, -10, 15, 20, 0], attribute='length') == 0


# Generated at 2022-06-23 10:24:10.680452
# Unit test for function max
def test_max():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'data': {'type': 'list'},
        'case_sensitive': {'type': 'bool', 'default': True},
    })

# Generated at 2022-06-23 10:24:15.781239
# Unit test for function min
def test_min():
    assert FilterModule().filters()['min']([1, 2, '3']) == 1



# Generated at 2022-06-23 10:24:25.990289
# Unit test for function union
def test_union():
    # has fewer items than the other
    assert union([1, 2, 3], [1, 3, 4, 5]) == [1, 2, 3, 4, 5]

    # has more items than the other
    assert union([1, 2, 3, 4], [3, 4, 5]) == [1, 2, 3, 4, 5]

    # same length as the other
    assert union([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]

    # duplicate elements
    assert union([1, 2, 3], [4, 5, 2]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-23 10:24:28.479543
# Unit test for function difference
def test_difference():
    assert difference(['a', 'b', 'c'], ['c','d']) == ['a','b']

# Generated at 2022-06-23 10:24:37.197762
# Unit test for function rekey_on_member

# Generated at 2022-06-23 10:24:43.036814
# Unit test for function difference
def test_difference():
    filter_ = FilterModule().filters()

    assert filter_['difference']([1, 2, 3], [2, 3, 4]) == [1]
    assert filter_['difference'](set(), set()) == set()
    assert filter_['difference'](set([1]), set([1])) == set()



# Generated at 2022-06-23 10:24:47.764223
# Unit test for function symmetric_difference
def test_symmetric_difference():
    func = symmetric_difference
    list1 = [1,2,3,4,5]
    list2 = [5,6,7,8,9]
    output = func(list1, list2)
    assert output == [1,2,3,4,6,7,8,9]

# Generated at 2022-06-23 10:24:59.676466
# Unit test for function max
def test_max():
    """
    Test max filter with integer and string values, including a unicode string.
    """
    from jinja2 import Environment
    from jinja2 import Template
    env = Environment()
    env.filters['max'] = max
    test_strings = (
        '{% set simple_int_list = [1, 2, 3] %}'
        '{{ simple_int_list | max }}',
        '{% set simple_str_list = ["a", "b", "c"] %}'
        '{{ simple_str_list | max }}',
        '{% set simple_unicode_list = ["ein", "zwei", "drei"] %}'
        '{{ simple_unicode_list | max }}',
    )

# Generated at 2022-06-23 10:25:02.496763
# Unit test for function intersect
def test_intersect():
    print(intersect([1, 2, 3], [2, 3, 4]))


# Generated at 2022-06-23 10:25:12.773057
# Unit test for function logarithm
def test_logarithm():
    data = [
        (10, 2.302585092994046, 10),
        (5, 1.6094379124341003, 10),
        (55, 1.736806299721071, 10),
        (55, 2.435137618944643, 6),
        (55, 3.1292830169449665, 4),
        (55, 4.153156300300923, 3),
        (55, 5.034064539477808, 2),
    ]

    fm = FilterModule()
    for d in data:
        assert fm.filters()['log'](d[0], base=d[2]) == d[1]


# Generated at 2022-06-23 10:25:22.820625
# Unit test for function power
def test_power():

    assert(power(2, 3) == 8)
    assert(power(2, -1) == 0.5)
    assert(power(2, 0) == 1)
    assert(power(3, 2) == 9)
    assert(power(2, -2) == 0.25)
    assert(power(3, -3) == 0.037037037037037035)
    assert(power(10, -2) == 0.01)
    assert(power(10, 2) == 100)
    assert(power(10, 0) == 1)
    assert(power(0, 4) == 0)


# Generated at 2022-06-23 10:25:32.485645
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    fm = FilterModule()

    # Create list of list for testing
    input_list_1 = [[1, 2], [2, 3]]
    input_list_2 = [[2, 3, 4], [3, 4, 5]]

    test_value = fm.filters()['symmetric_difference'](templar, input_list_1, input_list_2)
    assert test_value == [1, 2, 4, 5]

    # Create list of set for testing

# Generated at 2022-06-23 10:25:34.179093
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    assert t.filters() is not None



# Generated at 2022-06-23 10:25:44.368096
# Unit test for function inversepower
def test_inversepower():
    # Diminished root
    assert int(inversepower(16, 4)) == 2
    assert inversepower(16, 4, 1) == 2.0
    assert inversepower(16, 4, 2) == 1.8284271247461903

    # Quartic root
    assert int(inversepower(16, 5)) == 2
    assert inversepower(16, 5, 1) == 2.0
    assert inversepower(16, 5, 2) == 1.9486832980505138

    # Square root
    assert inversepower(16, 2) == 4
    assert inversepower(16, 2, 1) == 4.0
    assert inversepower(16, 2, 2) == 4.0

    # General root
    assert inversepower(256, 4, 2) == 3.132491021518467



# Generated at 2022-06-23 10:25:55.376850
# Unit test for function human_to_bytes
def test_human_to_bytes():
    #test values from https://docs.python.org/3/library/functions.html#int
    assert human_to_bytes("12345") == 12345
    assert human_to_bytes("1234567") == 1234567
    assert human_to_bytes("10000000") == 10000000
    assert human_to_bytes("10M") == 10485760
    assert human_to_bytes("10MB") == 10485760
    assert human_to_bytes("1010MiB") == 10555311680
    assert human_to_bytes("1G") == 1073741824
    assert human_to_bytes("1GB") == 1073741824
    assert human_to_bytes("1GiB") == 1073741824