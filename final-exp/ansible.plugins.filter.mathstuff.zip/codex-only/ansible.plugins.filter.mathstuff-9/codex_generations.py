

# Generated at 2022-06-23 10:16:00.616009
# Unit test for function human_readable
def test_human_readable():
    '''
    >>> test_human_readable()
    True
    '''

    # === test 1 ===
    # string with suffix => excepted result

# Generated at 2022-06-23 10:16:09.032468
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([1, 1, 3, 4, 5]) == 1
    assert min([1, 1, 1, 4, 5]) == 1

    assert min([1, 2, 3, 4, 5], 1, 2, 3, 4, 5) == 1
    assert min([1, 1, 3, 4, 5], 1, 2, 3, 4, 5) == 1
    assert min([1, 1, 1, 4, 5], 1, 2, 3, 4, 5) == 1

    assert min(['a', 'b', 'c', 'd', 'e']) == 'a'
    assert min(['a', 'b', 'c', 'd', 'e'], 'a', 'b', 'c', 'd', 'e') == 'a'

# Generated at 2022-06-23 10:16:16.722347
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Test for invalid input
    try:
        human_to_bytes(None)
        assert False, 'Expected AnsibleFilterError'
    except AnsibleFilterError as e:
        assert str(e) == "human_to_bytes() can't interpret following string: None"

    # Test for valid inputs.
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.0') == 1.0
    assert human_to_bytes('1.0b') == 1.0
    assert human_to_bytes('1.0B') == 1.0
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1000b') == 1000
    assert human

# Generated at 2022-06-23 10:16:27.083129
# Unit test for function unique
def test_unique():
    from jinja2 import Environment
    env = Environment()

    # Test unique using dict
    data = [{'name': 'first'}, {'name': 'second'}, {'name': 'first'}]
    result = unique(env, data, attribute='name')
    assert result == [{'name': 'first'}, {'name': 'second'}]

    result = unique(env, data, attribute='name', case_sensitive=False)
    assert result == [{'name': 'first'}, {'name': 'second'}]

    # Test unique using list
    data = ['test', 'Test', 'test']
    result = unique(env, data)
    assert result == ['test', 'Test']

    result = unique(env, data, case_sensitive=False)
    assert result == ['test']

# Generated at 2022-06-23 10:16:38.785202
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'min' in filters
    assert 'max' in filters
    assert 'log' in filters
    assert 'pow' in filters
    assert 'root' in filters
    assert 'unique' in filters
    assert 'intersect' in filters
    assert 'difference' in filters
    assert 'symmetric_difference' in filters
    assert 'union' in filters
    assert 'product' in filters
    assert 'permutations' in filters
    assert 'combinations' in filters
    assert 'human_readable' in filters
    assert 'human_to_bytes' in filters
    assert 'rekey_on_member' in filters
    assert 'zip' in filters
    assert 'zip_longest' in filters

# Generated at 2022-06-23 10:16:46.227889
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_bytes
    filter_loader = filter_loader_factory()
    env = jinja2.Environment()
    env.loader = filter_loader
    fm_filters = FilterModule().filters()
    for filter_name in fm_filters:
        env.filters[filter_name] = fm_filters[filter_name]
    assert env.from_string("{{ [1,2,3] | unique | list }}").render(to_bytes=to_bytes) == '[1, 2, 3]'

# Generated at 2022-06-23 10:16:48.222697
# Unit test for function min
def test_min():
    f = FilterModule().filters()
    assert f['min']([1,2,3]) == 1
    assert f['min']({'A': 1, 'B': 2, 'C': 3}) == 1

# Generated at 2022-06-23 10:16:57.871757
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    # Importing the filter plugin here to workaround the
    # patching of `ansible.module_utils.common.text.formatters.to_text`
    # in the ansible-test framework.
    import ansible.plugins.filter.core

    class TestRekeyOnMember(unittest.TestCase):
        ''' Unit tests for rekey_on_member '''

        @patch('ansible.module_utils.common.text.formatters.to_text')
        def test_basic(self, mock_to_text):
            ''' Test basic operation of rekey_on_member '''

# Generated at 2022-06-23 10:17:05.705870
# Unit test for function logarithm
def test_logarithm():

    logarithm_data = [
        (1, 1.0, math.e),
        (3.0, 1.0986122886681098, math.e),
        (64, 6.0, 2),
        (5, 1.6094379124341003, math.e),
        ]

    for x, y, base in logarithm_data:
        logarithm_returned = logarithm(x, base)
        assert logarithm_returned == y


# Generated at 2022-06-23 10:17:07.444506
# Unit test for function min
def test_min():
    assert min(range(100)) == 0
    assert min([1, 2, 3, 4, 5]) == 1



# Generated at 2022-06-23 10:17:14.409140
# Unit test for function rekey_on_member
def test_rekey_on_member():
    rekey_list = [
        dict(key1=1, key2=2, key3=3),
        dict(key1=3, key2=4, key3=5),
    ]

    rekey_dict = {
        1: dict(key1=1, key2=2, key3=3),
        2: dict(key1=3, key2=4, key3=5),
    }

    rekey_dict_with_duplicates = {
        1: dict(key1=1, key2=2, key3=3),
        2: dict(key1=3, key2=4, key3=5),
        3: dict(key1=3, key2=4, key3=5),
    }


# Generated at 2022-06-23 10:17:27.030136
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1 B'
    assert human_readable(10 ** 3) == '1.0 kB'
    assert human_readable(10 ** 6) == '1.0 MB'
    assert human_readable(10 ** 9) == '1.0 GB'

    assert human_readable(0, True) == '0'
    assert human_readable(8, True) == '8 B'
    assert human_readable(10 * 2 ** 10, True) == '10.0 KiB'
    assert human_readable(10 ** 3, True) == '1000 B'
    assert human_readable(10 ** 6, True) == '976.6 KiB'
    assert human_readable(10 ** 9, True) == '953.7 MiB'


# Generated at 2022-06-23 10:17:29.048611
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 1, 2, 3, 3], [2, 3, 4]) == [1, 1, 4]

# Generated at 2022-06-23 10:17:38.926974
# Unit test for function union
def test_union():
    assert union(['a', 'b', 'c'], ['b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert union(['a', 'b', 'c'], ['b', 'c', 'd', 'a']) == ['a', 'b', 'c', 'd']
    assert union(['a', 'b', 'c'], 'bcd') == ['a', 'b', 'c', 'b', 'c', 'd']
    assert union(['a', 'b', 'c'], ['b', 'c', 'd'], ['b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    # test python 2.6 iteritems compatibility

# Generated at 2022-06-23 10:17:44.759128
# Unit test for function unique
def test_unique():
    assert unique(["foo", "foo", "bar", "foo", "bar", "foo"]) == ["foo", "bar"]
    assert unique(["foo", "foo", "bar", "foo", "bar", "foo"], case_sensitive=False) == ["foo", "bar"]
    assert unique(["foo", "foo", "bar", "foo", "bar", "foo"], case_sensitive=False, attribute='lower') == ["foo", "bar"]
    try:
        unique(["foo", "foo", "bar", "foo", "bar", "foo"], case_sensitive=False, attribute='lower', other_attribute=False)
    except AnsibleFilterError as e:
        assert "Jinja2's unique filter failed" in to_text(e)
        assert "Jinja2's unique filter failed" in str(e)

    #

# Generated at 2022-06-23 10:17:48.999432
# Unit test for function symmetric_difference
def test_symmetric_difference():
    '''  assert symmetric_difference([1,2,3,4,5], [1,2,4,5]) == [3] '''

    assert symmetric_difference([1, 2, 3, 4, 5], [1, 2, 4, 5]) == [3]

# Generated at 2022-06-23 10:17:59.555117
# Unit test for function logarithm
def test_logarithm():
    f = FilterModule()
    env = {}

    # test an integer passed in
    integer = 10
    base = 2
    result = f.filters()['log'](env, integer, base)
    assert result == math.log(integer, base)

    # test a float passed in
    float = 10.33
    base = 3
    result = f.filters()['log'](env, float, base)
    assert result == math.log(float, base)

    # test a float passed in with base of 10
    float = 10.33
    base = 10
    result = f.filters()['log'](env, float, base)
    assert result == math.log(float, base)

    # test with base set to e
    result = f.filters()['log'](env, integer)
    assert result

# Generated at 2022-06-23 10:18:04.371998
# Unit test for function min
def test_min():
    assert min(1, 2) == 1
    assert min([1, 2]) == 1
    assert min([2, 1]) == 1
    assert min(2, 1) == 1
    assert min(1, 2, -1) == -1

    # Make sure 'min' from python builtins is still
    # available
    assert 'min' in vars(__builtins__)

# Generated at 2022-06-23 10:18:06.655117
# Unit test for function power
def test_power():
    assert power(2, 3) == 8

# Generated at 2022-06-23 10:18:17.725102
# Unit test for function unique
def test_unique():
    class A(object):
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

        def __hash__(self):
            return hash(self.name)

        def __repr__(self):
            return self.name

    class B(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    class C(object):
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

        def __hash__(self):
            return hash(self.name)


# Generated at 2022-06-23 10:18:18.798576
# Unit test for function min
def test_min():
    assert min([0, 5, 2, 3, 7, 5, 10, 1, 3]) == 0


# Generated at 2022-06-23 10:18:19.665350
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-23 10:18:21.488169
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 10) == 1
    assert logarithm(50, 50) == 1
    assert logarithm(10) == 2.302585092994046


# Generated at 2022-06-23 10:18:29.106504
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    test_data = [
        {'host': 'host1', 'name': 'name1', 'value': 'value1'},
        {'host': 'host2', 'name': 'name2', 'value': 'value2'},
        {'host': 'host3', 'name': 'name3', 'value': 'value3'}
    ]
    template_data = {'test_data': test_data, 'host': 'host1'}
    name_group_key = 'name'
    host_group_key = 'host'
    unknown_group_key = 'unknown'
    # Test list input
    play_context = PlayContext()

# Generated at 2022-06-23 10:18:37.808335
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Tests that the conversion is working as expected
    assert human_to_bytes('512M') == 512 * 1024 * 1024
    assert human_to_bytes('The value is 512M') == 512 * 1024 * 1024
    assert human_to_bytes('512M is the value') == 512 * 1024 * 1024
    assert human_to_bytes('  512    M ') == 512 * 1024 * 1024
    assert human_to_bytes('512M is the value') == 512 * 1024 * 1024
    assert human_to_bytes('512MB') == 512 * 1024 * 1024
    assert human_to_bytes('512MB is the value') == 512 * 1024 * 1024
    assert human_to_bytes('512   MB ') == 512 * 1024 * 1024
    assert human_to_bytes('2K') == 2 * 1024

# Generated at 2022-06-23 10:18:40.167352
# Unit test for function difference
def test_difference():
    from jinja2 import Environment

    jinja_env = Environment()
    filtered = jinja_env.from_string('''{{ [1, 2, 3] | difference([1, 2]) | list }}''').render()
    assert filtered == '[3]'

# Generated at 2022-06-23 10:18:41.760780
# Unit test for function power
def test_power():
    assert power(2, 3) == 8

# Generated at 2022-06-23 10:18:53.302670
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1.001M") == 1024 * 1024
    assert human_to_bytes("200K") == 200 * 1024
    assert human_to_bytes("1.347 K") == 1347
    assert human_to_bytes("6.998M") == 6 * 1024 * 1024
    assert human_to_bytes("") == 0
    assert human_to_bytes("-1") == -1
    assert human_to_bytes("-10") == -10
    assert human_to_bytes("-1.9") == -1
    assert human_to_bytes("-0.9") == 0
    assert human_to_bytes("-0.0") == 0
    assert human_to_bytes("0.0") == 0
    assert human_to_bytes("0.9") == 0
    assert human_to_bytes

# Generated at 2022-06-23 10:19:03.316936
# Unit test for function unique
def test_unique():
    assert [1, 2, 3] == unique([1, 2, 3])
    assert [1, 2, 3] == unique([1, 2, 2, 3])
    assert [1, 2, 3, 4] == unique([1, 2, 3, 3, 3, 4, 4, 4, 4, 4])
    assert [1, 2, 3] == unique([[1], [2], [3]])
    assert [1, 2, 3] == unique([(1,), (2,), (3,)])
    assert ['a', 'b', 'c'] == unique(['c', 'b', 'a'])
    assert ['a', 'b', 'c'] == unique(['a', 'b', 'c', 'c'])

# Generated at 2022-06-23 10:19:09.066582
# Unit test for function power
def test_power():
    '''
    power function:
    '''
    assert power(2, 3) == 8
    assert power(3, 2) == 9
    assert power(2, 0.5) == 1.4142135623730951
    assert power(8, 1.0/3.0) == 2.0



# Generated at 2022-06-23 10:19:11.260304
# Unit test for function min
def test_min():
    assert min([4, 2, 1, 3]) == 1



# Generated at 2022-06-23 10:19:16.526266
# Unit test for function power
def test_power():
    assert power(2,3) == 8
    assert power(2,0) == 1
    assert power(0,10) == 0
    assert power(10,0) == 1
    assert power(2,-1) == 0.5
    assert power(1,1) == 1
    try:
        power(2,"A")
        assert False
    except:
        assert True


# Generated at 2022-06-23 10:19:21.403872
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Make sure FilterModule is a class
    assert FilterModule.__class__.__name__ == 'FilterModule'

    # Make sure FilterModule has a __init__ method
    assert hasattr(FilterModule, '__init__') and callable(getattr(FilterModule, '__init__'))

    # Make sure FilterModule has a filters method
    assert hasattr(FilterModule, 'filters') and callable(getattr(FilterModule, 'filters'))

    # Make sure filters method returns a dict
    assert isinstance(FilterModule().filters(), dict)



# Generated at 2022-06-23 10:19:24.442273
# Unit test for function union
def test_union():
    res = union([1, 2, 3], [1, 2, 4])
    assert res == [1, 2, 3, 4]



# Generated at 2022-06-23 10:19:26.433800
# Unit test for function inversepower
def test_inversepower():
    result = inversepower(4, 2)
    assert result == 2



# Generated at 2022-06-23 10:19:36.463773
# Unit test for function human_readable
def test_human_readable():
    ''' test human_readable function '''
    assert human_readable(1049) == '1.0 KiB'
    assert human_readable(2558) == '2.5 KiB'
    assert human_readable(2558, unit='MB') == '1.0 MB'
    assert human_readable(2558, isbits=True) == '2.0 Kibit'
    assert human_readable(1024, isbits=True) == '1.0 Kibit'
    assert human_readable(1048576, unit='GB') == '1.0 GB'
    assert human_readable(1, unit='bit') == '1 bit'
    assert human_readable(0, unit='byte') == '0 Bytes'
    assert human_readable(0, unit='kilobyte') == '0 KiB'
    assert human_

# Generated at 2022-06-23 10:19:45.334228
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1024) == '1K'
    assert human_readable(1536) == '1.5K'
    assert human_readable(1536, 2) == '1.50K'
    assert human_readable(2097152) == '2M'
    assert human_readable(2097152, 2) == '2.00M'
    assert human_readable(1073741824) == '1G'
    assert human_readable(1073741824, 2) == '1.00G'
    assert human_readable(1073741824, 0) == '1G'
    assert human_readable(1099511627776) == '1T'
    assert human_readable(1099511627776, 2) == '1.00T'

# Generated at 2022-06-23 10:19:55.225310
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1) == 2**0
    assert human_to_bytes(1, 'k') == 2**10
    assert human_to_bytes(1, 'Ki') == 2**10
    assert human_to_bytes(1, 'M') == 2**20
    assert human_to_bytes(1, 'Mi') == 2**20
    assert human_to_bytes(1, 'G') == 2**30
    assert human_to_bytes(1, 'Gi') == 2**30
    assert human_to_bytes(1, 'T') == 2**40
    assert human_to_bytes(1, 'Ti') == 2**40
    assert human_to_bytes(1, 'P') == 2**50
    assert human_to_bytes(1, 'Pi') == 2**50
    assert human

# Generated at 2022-06-23 10:20:04.535190
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

    assert isinstance(fm, FilterModule)

# Generated at 2022-06-23 10:20:06.319679
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    assert isinstance(test_filter_module, object)


# Generated at 2022-06-23 10:20:12.751331
# Unit test for function power
def test_power():
    assert power(2, 3) == 8.0
    assert power(4, -1) == 0.25
    assert power(3.0, 0) == 1.0
    assert power(2, 3.0) == 8.0
    assert power("a", "b") == 1.0
    assert power("a", 3) == 1.0
    assert power("a", -1) == 1.0

# Generated at 2022-06-23 10:20:18.946863
# Unit test for function intersect
def test_intersect():
    assert (intersect('x','x','x')) =='x'
    assert (intersect(['x','y','z'],['x','yy','x'])) == ['x']
    assert (intersect([],[1,2])) == []
    assert (intersect(['x','y','z'],['x','y','z'])) == ['x','y','z']


# Generated at 2022-06-23 10:20:27.246470
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    # Test that the FilterModule class returns the expected dict
    assert isinstance(fm.filters(), dict)
    assert sorted(fm.filters()) == sorted(['min', 'max', 'log', 'pow', 'root', 'unique', 'intersect',
                                           'difference', 'symmetric_difference', 'union', 'product',
                                           'permutations', 'combinations', 'human_readable', 'human_to_bytes',
                                           'rekey_on_member'])

# Unit tests for function min

# Generated at 2022-06-23 10:20:41.243670
# Unit test for function unique
def test_unique():
    assert unique(['aa', 'bb', 'aa', 'cc'], False) == ['aa', 'bb', 'cc']
    assert unique(['aa', 'bb', 'aa', 'cc'], True) == ['aa', 'bb', 'aa', 'cc']
    assert unique(['aa', 'BB', 'aa', 'cc'], False) == ['aa', 'BB', 'aa', 'cc']
    assert unique(['aa', 'BB', 'aa', 'cc'], True) == ['aa', 'bb', 'cc']
    assert unique(['a', 'B', 'a', 'c'], Attribute='lower') == ['a', 'B', 'c']
    assert unique(['a', 'B', 'a', 'c'], Attribute='upper') == ['a', 'B', 'a', 'c']

# Generated at 2022-06-23 10:20:43.173157
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm.filters()
    assert fm is not None

# Generated at 2022-06-23 10:20:51.693550
# Unit test for function difference
def test_difference():
    assert difference(['a', 'b'], ['b', 'c']) == ['a']
    assert difference(['a', 'b'], ['a', 'c', 'd']) == ['b']
    assert difference(['a', 'b', 'c'], ['a', 'b', 'c', 'd']) == ['d']
    assert difference(['a', 'b', 'c'], ['x', 'y', 'z']) == ['a', 'b', 'c']


# Generated at 2022-06-23 10:20:56.830146
# Unit test for function human_readable
def test_human_readable():
    '''
    Test the human_readable filter
    '''

    assert human_readable(512) == '512B'
    assert human_readable(5120) == '5.0K'
    assert human_readable(51200) == '50.0K'
    assert human_readable(512000) == '500.0K'
    assert human_readable(5120000) == '5.0M'

    assert human_readable(512, True) == '4.0K'
    assert human_readable(5120, True) == '40.0K'
    assert human_readable(51200, True) == '400.0K'
    assert human_readable(512000, True) == '4.0M'

    assert human_readable(512, False, 'KiB') == '0.5KiB'
   

# Generated at 2022-06-23 10:21:05.158324
# Unit test for function human_readable
def test_human_readable():

    # Test bytes
    assert human_readable(1) == '1.0 B'
    assert human_readable(1024) == '1.0 K'
    assert human_readable(1024*1024) == '1.0 M'
    assert human_readable(1024**3) == '1.0 G'
    assert human_readable(1024**4) == '1.0 T'
    assert human_readable(1024**5) == '1.0 P'
    assert human_readable(1024**6) == '1.0 E'
    assert human_readable(1024**7) == '1.0 Z'
    assert human_readable(1024**8) == '1.0 Y'
    assert human_readable(1024**9) == '1024.0 Y'

    # Test fractionals

# Generated at 2022-06-23 10:21:13.628798
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: x * -1) == 3
    assert min(["a", "b", "c"]) == "a"
    assert min(["a", "b", "c"], key=lambda x: str(x) + "c") == "a"
    assert min({"a": "b", "c": "d"}) == "a"
    assert min({"a": "b", "c": "d"}, key=lambda x: x * 2) == "a"
    assert min({"a": "b", "c": "d"}, key=lambda x: "abc") == "c"



# Generated at 2022-06-23 10:21:24.153229
# Unit test for function human_to_bytes
def test_human_to_bytes():
    f = FilterModule()
    filters = f.filters()
    human_readable_str = ['10GB', '10G', '1000MB', '1000M', '1kb', '1k', '1b']
    human_readable_bytes = [10737418240, 1073741824, 1048576000, 1048576000, 1000, 1024, 1]
    for i in range(0, len(human_readable_str)):
        assert filters['human_to_bytes'](human_readable_str[i]) == human_readable_bytes[i]



# Generated at 2022-06-23 10:21:35.213289
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.plugins.filter import rekey_on_member

    assert rekey_on_member.__name__ == 'rekey_on_member'

    paths = [
        "/etc/ansible/hosts",
        "/usr/bin/python",
        "/usr/bin/python2.6",
        "/usr/bin/python2.7",
        "/usr/bin/python3.6",
        "/usr/bin/python3.7",
        "/var/tmp/file.txt"
    ]

    test = [
        {"path": path, "size": len(path)} for path in paths
    ]

    assert rekey_on_member(test, 'path', duplicates='overwrite') == dict([(i, {'size': len(i), 'path': i}) for i in set(paths)])

# Generated at 2022-06-23 10:21:43.888917
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            self.module = MagicMock()
            self.module.fail_json.__name__ = 'fail_json'

        @patch('ansible.plugins.filter.core.AnsibleFilterError', wraps=AnsibleFilterError)
        def test_duplicate_entries_error(self, exception_mock):
            data = [{'a': 'alpha', 'b': 'beta'}, {'a': 'gamma', 'b': 'delta'}, {'a': 'alpha', 'b': 'epsilon'}]

# Generated at 2022-06-23 10:21:54.621374
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """
    Test the rekey_on_member function.
    """
    from ansible.template.safe_eval import ansible_safe_eval
    import yaml
    yaml.SafeLoader.add_constructor(u'tag:yaml.org,2002:python/unicode',
                                    lambda loader, node: node.value)

    def test_data_member(test_data, test_name):
        """
        Run one test
        """
        # The 'excepts' variable is a list of any exceptions the test is allowed to throw
        excepts = test_data.get('excepts', ['AnsibleFilterError'])
        # The 'result' variable is the expected result
        result = test_data.get('result', None)
        # The 'duplicates' variable is a parameter to rekey_on_member


# Generated at 2022-06-23 10:21:58.867254
# Unit test for function union
def test_union():
    filter = FilterModule()
    union = filter.filters()['union']
    intersection = filter.filters()['intersect']

    assert union([1,2,3], [2,3,4]) == [1,2,3,4]
    assert intersection([1,2,3], [2,3,4]) == [2,3]

# Generated at 2022-06-23 10:22:01.030409
# Unit test for function difference
def test_difference():
    a = [1, 2, 3]
    b = [1, 2, 4]
    assert difference(None, a, b) == [3]



# Generated at 2022-06-23 10:22:05.841449
# Unit test for function union
def test_union():
    print("Testing union")
    errmsg = "{0}({1}, {2}) -> {3}, expected {4}"
    test_array_A = [1, 2, 3]
    test_array_B = [1, 3, 4]
    test_dict_A = {'A': 1, 'B': 2}
    test_dict_B = {'A': 1, 'C': 3}
    result = union(test_array_A, test_array_B)
    expected = [1, 2, 3, 4]
    assert(result == expected), errmsg.format('union', test_array_A, test_array_B, result, expected)
    result = union(test_dict_A, test_dict_B)
    expected = [1, 2, 3]
    assert(result == expected), errmsg.format

# Generated at 2022-06-23 10:22:07.382238
# Unit test for function intersect
def test_intersect():
    assert intersect([1,2,3], [2,3,4]) == [2,3]

# Generated at 2022-06-23 10:22:08.666027
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]



# Generated at 2022-06-23 10:22:13.092458
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1, math.e) == 0
    assert logarithm(1, 10) == 0
    assert logarithm(2, 2) == 1
    assert logarithm(math.e, 2) == 1



# Generated at 2022-06-23 10:22:24.084285
# Unit test for function rekey_on_member
def test_rekey_on_member():
    rekey_on_member_filter = FilterModule().filters()['rekey_on_member']

    # Test successful rekeying of a dict.
    input_dict = {'a': {'one': 1, 'two': 2, 'three': 3},
                  'b': {'one': 4, 'two': 5, 'three': 6},
                  'c': {'one': 7, 'two': 8, 'three': 9}}

    expected_dict = {1: {'one': 1, 'two': 2, 'three': 3},
                     4: {'one': 4, 'two': 5, 'three': 6},
                     7: {'one': 7, 'two': 8, 'three': 9}}

    assert rekey_on_member_filter(input_dict, 'one') == expected_dict

    # Test successful reke

# Generated at 2022-06-23 10:22:32.446808
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Function to test method filters of class FilterModule
    """
    # Create object of class FilterModule
    obj_FilterModule = FilterModule()

    # Get filters
    filters = obj_FilterModule.filters()

    # Get keys of filters
    filters_keys = list(filters.keys())

    # Check filters_keys length
    assert len(filters_keys) == 22

    # Check type and value of filters_keys

# Generated at 2022-06-23 10:22:43.866160
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(-1) == '-1.0B'
    assert human_readable(0) == '0B'
    assert human_readable(2) == '2B'
    assert human_readable(1023) == '1023B'
    assert human_readable(1024) == '1.0KiB'
    assert human_readable(1535) == '1.5KiB'
    assert human_readable(2047) == '2.0KiB'
    assert human_readable(2048) == '2.0KiB'
    assert human_readable(2 * 1024) == '2.0KiB'

# Generated at 2022-06-23 10:22:51.914623
# Unit test for function logarithm
def test_logarithm():

    assert logarithm(10, base=10) == 1
    assert logarithm(100, base=10) == 2
    assert logarithm(100, base=100) == 1
    assert logarithm(10, base=2) == 3.3219280948873626

    try:
        logarithm('a')
    except AnsibleFilterTypeError as e:
        assert to_text(e) == 'log() can only be used on numbers: must be real number, not str'



# Generated at 2022-06-23 10:23:01.212588
# Unit test for function unique
def test_unique():
    from ansible.utils.display import Display
    display = Display()

    t = {
        'in': ['a', 'b', 'c', 'b', 'c', 'a'],
        'out': ['a', 'b', 'c'],
        'case_sensitive': True,
        'attribute': None,
    }
    assert unique(None, t['in']) == t['out'], display.error('Failed to get unique values: %s' % (unique(None, t['in']),))

    t = {
        'in': [{ 'name': 'a' }, { 'name': 'a' }],
        'out': [{ 'name': 'a' }],
        'case_sensitive': True,
        'attribute': 'name',
    }

# Generated at 2022-06-23 10:23:05.960035
# Unit test for function symmetric_difference
def test_symmetric_difference():
    environment = {}

    a = [1,2,3,4,5]
    b = [1,2,6,7,8]

    assert symmetric_difference(environment, a,b) == [3,4,5,6,7,8]



# Generated at 2022-06-23 10:23:13.667892
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([[1, 2, 3], [5, 6, 7]]) == [5, 6, 7]
    assert max([[1, 2, 3], [5, 6, 7]], attr='index') == [5, 6, 7]
    assert max([[1, 2, 3], [5, 6, 7]], attr='index', default=None) == [5, 6, 7]
    assert max([], default=8) == 8
    assert max('a', 'ab', 'bc') == 'bc'
    assert max([1, 'a'], default=8) == 8



# Generated at 2022-06-23 10:23:24.860322
# Unit test for function intersect

# Generated at 2022-06-23 10:23:36.889763
# Unit test for function human_to_bytes
def test_human_to_bytes():
    output = human_to_bytes('1')
    assert output == 1
    output = human_to_bytes('1K')
    assert output == 1024
    output = human_to_bytes('1.5K')
    assert output == 1536
    output = human_to_bytes('1Ki')
    assert output == 1024
    output = human_to_bytes('1Mi')
    assert output == 1048576
    output = human_to_bytes('1Gi')
    assert output == 1073741824
    output = human_to_bytes('1Ti')
    assert output == 1099511627776
    output = human_to_bytes('1Pi')
    assert output == 1125899906842624
    output = human_to_bytes('1Ei')
    assert output == 1152921504606850000

# Generated at 2022-06-23 10:23:44.133735
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
        'i',
        'j',
        'k',
        'l',
        'm',
        'n',
        'o',
        'p',
        'q',
        'r',
        's',
        't',
        'u',
        'v',
        'w',
        'x',
        'y',
        'z'
    ]

# Generated at 2022-06-23 10:23:54.355447
# Unit test for function human_readable
def test_human_readable():

    assert human_readable(100) == "100 b"
    assert human_readable(100, True) == "100 b"
    assert human_readable(1000) == "1000 b"
    assert human_readable(1000, True) == "0.001Ki"
    assert human_readable(1024, False) == "1.0K"
    assert human_readable(1024, False, "s") == "1.0Ks"
    assert human_readable(1024, True, "s") == "1.024Kis"
    assert human_readable("1024") == "1.0K"
    assert human_readable("1024", False) == "1.0K"
    assert human_readable("1024", "K") == "1.024K"
    assert human_readable("1024", "K", True) == "1.024Ki"

# Generated at 2022-06-23 10:24:05.416684
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import re

    PATTERN = re.compile(r'^\d+')

    def assert_result(value, value2):
        assert human_to_bytes(value) == int(PATTERN.match(value2).group(0))

    assert_result('1B', '1B')
    assert_result('1K', '1024B')
    assert_result('1M', '1024K')
    assert_result('1G', '1024M')
    assert_result('1T', '1024G')
    assert_result('1P', '1024T')
    assert_result('1E', '1024P')
    assert_result('1Z', '1024E')
    assert_result('1Y', '1024Z')

    assert_result('1KiB', '1024B')

# Generated at 2022-06-23 10:24:13.273976
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3, 4], [3, 4, 5]) == [3, 4]
    assert intersect([1, 2, 3, 4], [5, 6, 7]) == []

    assert intersect([1, 2, 3], [1, 2]) == [1, 2]
    assert intersect([1, 2, 3], [3, 4, 5]) == [3]
    assert intersect([1, 2, 3], [5, 6, 7]) == []

    assert intersect([1, 2], [1, 2, 3]) == [1, 2]
    assert intersect([3, 4, 5], [1, 2, 3]) == [3]
    assert intersect([5, 6, 7], [1, 2, 3]) == []

    assert intersect([], []) == []

# Generated at 2022-06-23 10:24:25.680575
# Unit test for function max
def test_max():

    # Test basic usage
    data = [1, 2, 3, 4, 5]
    assert max(data) == 5

    # Test kwargs
    assert max(data, default=0) == 5
    assert max(data, default=100) == 5
    assert max(data, default='100') == 5

    # Test error on usage of keyword args
    try:
        max(data, key='foo')
        assert False
    except AnsibleFilterError as e:
        assert "keyword arguments" in to_text(e)

    # Test error on non-iterable
    try:
        max(1)
        assert False
    except AnsibleFilterTypeError as e:
        assert "sequence of numbers" in to_text(e)


# Generated at 2022-06-23 10:24:33.641780
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0B'
    assert human_readable(0, isbits=True) == '0b'
    assert human_readable(1000) == '1KB'
    assert human_readable(1000, isbits=True) == '8kb'
    assert human_readable(1000000) == '1MB'
    assert human_readable(1000000, unit='GB') == '0GB'
    assert human_readable(1000000, isbits=True, unit='GB') == '0Gb'


# Generated at 2022-06-23 10:24:41.279272
# Unit test for function inversepower
def test_inversepower():
    filter_module = FilterModule()
    my_filters = filter_module.filters()
    assert my_filters['root'](4, 2) == 2
    assert my_filters['root'](4, base=2) == 2
    assert my_filters['root'](2) == math.sqrt(2)
    assert my_filters['root'](2, base=2) == math.sqrt(2)
    assert my_filters['root'](8, base=3) == 2
    assert my_filters['root'](64, base=4) == 2
    assert my_filters['root'](27, base=3) == 3
    assert my_filters['root'](1, base=2) == 1

# Generated at 2022-06-23 10:24:47.313898
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('1024') == '1.0K'
    assert human_readable('1000') == '1.0K'
    assert human_readable('-1000') == '-1.0K'
    assert human_readable('1024', unit='B') == '1.0K'
    assert human_readable('1024', unit='KiB') == '1.0KiB'


# Generated at 2022-06-23 10:24:59.375562
# Unit test for function power

# Generated at 2022-06-23 10:25:05.432618
# Unit test for function max
def test_max():
    assert max(1, 2) == 2
    assert max([1, 3, 2]) == 3
    assert max(['c', 'b', 'a'], key=lambda x: x.lower()) == 'c'



# Generated at 2022-06-23 10:25:09.669656
# Unit test for function min
def test_min():
    from ansible.vars.unsafe_proxy import wrap_var
    f = wrap_var(FilterModule().filters())
    assert f.min([3, 2, 1]) == 1
    assert f.min([[2, 3], [1, 4]]) == [1, 4]
    assert f.min([[2, 3], [1, 4]], "foo") == [1, 4]
    assert f.min([[2, 3], [1, 4]], "foo", "bar") == [1, 4]
    assert f.min({'foo': 1, 'bar': 2}) == 1
    assert f.min('abcd') == 'a'



# Generated at 2022-06-23 10:25:19.796409
# Unit test for function difference
def test_difference():
    # pylint: disable=import-error
    import jinja2
    # pylint: enable=import-error
    env = jinja2.Environment()
    assert env.from_string('{{ foo | difference(bar) }}').render(foo=[1, 2, 3], bar=[3, 2, 4]) == '[1]'
    assert env.from_string('{{ foo | difference(bar) }}').render(foo=[1, 2, 3, 2], bar=[3, 2, 4]) == '[1]'
    assert env.from_string('{{ foo | difference(bar) }}').render(foo=[1, 2, 3, 2], bar=[4]) == '[1, 2, 3, 2]'

# Generated at 2022-06-23 10:25:22.418126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert type(filter_module.filters()) == dict

# Generated at 2022-06-23 10:25:32.085663
# Unit test for function min
def test_min():
    # simple tests
    assert min([-1]) == -1
    assert min([]) is None
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3, -4]) == -4
    # Jinja2 2.10+ supports keyword arguments
    assert min([1, 2, 3], default=0) == 1
    assert min(data=[1, 2, 3], default=0) == 1
    assert min([], default=0) == 0
    assert min([], default=None) is None
    # keyword arguments without Jinja2 2.10+ should fail
    try:
        min([1, 2, 3], default=0)
        assert False, "Expected AnsibleFilterError"
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:25:33.089214
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-23 10:25:35.666273
# Unit test for function difference
def test_difference():
    assert difference([1,2,3,4,5], [1,3,5]) == [2,4]


# Generated at 2022-06-23 10:25:38.121095
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) == FilterModule

# Unit tests for the logarithm filters

# Generated at 2022-06-23 10:25:46.530418
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.utils.display import Display
    from ansible.utils import context_objects as co
    import ansible.constants as C

    # We need to override the context objects, so we can set the set the order
    # to run the tests in.
    display = Display()
    context = co.Context()

    if C.DEFAULT_LOAD_CALLBACK_PLUGINS:
        context._final_callbacks = context._load_callbacks(C.DEFAULT_CALLBACK_WHITELIST)

    context._final_shell = co.Shell()
    context._final_stdout_callback = display.get_callback(C.DEFAULT_STDOUT_CALLBACK)


# Generated at 2022-06-23 10:25:57.330384
# Unit test for function human_readable
def test_human_readable():

    test_filters = FilterModule()
    filters = test_filters.filters()

    assert filters['human_readable'](1) == '1.0 B'
    assert filters['human_readable'](1, isbits=True) == '8.0 b'
    assert filters['human_readable'](1, unit='bit') == '1.0 bits'
    assert filters['human_readable'](10) == '10.0 B'
    assert filters['human_readable'](10, isbits=True) == '80.0 b'
    assert filters['human_readable'](10, unit='bit') == '10.0 bits'
    assert filters['human_readable'](1024) == '1.0 KiB'
    assert filters['human_readable'](1024, isbits=True) == '8.0 Kib'
