

# Generated at 2022-06-23 10:16:01.200105
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1 B') == 1
    assert human_to_bytes('1 KB') == 1000
    assert human_to_bytes('1 MB') == 1000000
    assert human_to_bytes('1 GB') == 1000000000
    assert human_to_bytes('1 TB') == 1000000000000
    assert human_to_bytes('1 PB') == 1000000000000000
    assert human_to_bytes('1 EB') == 1000000000000000000
    assert human_to_bytes('1 ZB') == 1000000000000000000000
    assert human_to_bytes('1 YB') == 1000000000000000000000000
    assert human_to_bytes('1 KiB') == 1024
    assert human_to_bytes('1 MiB') == 1048576
    assert human_to_bytes('1 GiB') == 1073741824

# Generated at 2022-06-23 10:16:13.166899
# Unit test for function max
def test_max():
    assert max(range(5)) == 4
    assert max(1,2,3,4,5) == 5

    assert max([1, 2, 3, 4, 5]) == 5
    assert max([1, 2, 3, 4, 5], [5, 4, 3, 2, 1]) == 5
    assert max([[1, 2], [3, 4]], [[5, 6], [7, 8]]) == [7, 8]
    assert max([{'a': 1}, {'a': 2}], ['b', 'c']) == 'c'

    assert max([1, 2, 3, 4, 5], [5, 4, 3, 2, 1], (5, 0), key=lambda x: len(str(x))) == '55555'


# Generated at 2022-06-23 10:16:19.029680
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]
    assert union(set([1, 2, 3]), set([2, 3, 4])) == set([1, 2, 3, 4])



# Generated at 2022-06-23 10:16:20.096559
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2.0

# Unit tests for function power

# Generated at 2022-06-23 10:16:21.138661
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')

# Generated at 2022-06-23 10:16:29.269315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Call the filters method from the module
    from ansible.plugins.filter.core import FilterModule
    this_filter = FilterModule()
    filters = this_filter.filters()
    # Test for expected filters
    for filter in (
            'min',
            'max',
            'log',
            'pow',
            'root',
            'unique',
            'intersect',
            'difference',
            'symmetric_difference',
            'union',
            'product',
            'permutations',
            'combinations',
            'human_readable',
            'human_to_bytes',
            'rekey_on_member',
            'zip',
            'zip_longest',
    ):
        assert filter in filters

# Generated at 2022-06-23 10:16:34.802935
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(20) == math.log(20)
    assert logarithm(20, 5) == math.log(20, 5)
    assert logarithm(20, 10) == math.log10(20)
    assert logarithm(20, 20) == math.log(20, 20)
    assert logarithm(base=10, x=20) == math.log10(20)



# Generated at 2022-06-23 10:16:45.828276
# Unit test for function max
def test_max():
    fm = FilterModule()
    env = {}
    filters = fm.filters()
    max_f = filters.get('max')

    # Test float input
    assert max_f(env, [1.2, 2.2, 3.3, 2.2]) == 3.3
    assert max_f(env, [1.2, 3.2, 3.3, 2.2], 1.5) == 1.5

    # Test string input
    assert max_f(env, ['a', 'b', 'ab', 'abc']) == 'abc'
    assert max_f(env, ['a', 'b', 'ab', 'abc'], 'abcd') == 'abcd'

    # AssertionError expected

# Generated at 2022-06-23 10:16:51.825390
# Unit test for function symmetric_difference
def test_symmetric_difference():
    cases = [
        (
            [1, 2, 3, 4, 5, 6],
            [0, 1, 3, 7, 8],
            [0, 2, 4, 5, 6, 7, 8]
        ),
        (
            [1, 2, 3, 4, 5, 6],
            [],
            [1, 2, 3, 4, 5, 6]
        ),
        (
            [],
            [0, 1, 3, 7, 8],
            [0, 1, 3, 7, 8]
        ),
        (
            [],
            [],
            []
        ),
    ]

    for a, b, result in cases:
        assert symmetric_difference(None, a, b) == result

# Generated at 2022-06-23 10:17:02.199507
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1], True) == [1, 2, 3]
    assert unique([1, 2, 3, 1], False) == [1, 2, 3]
    assert unique(['a', 'b', 42], True) == ['a', 'b', 42]
    assert unique(['a', 'b', 42], False) == ['a', 'b', 42]
    assert unique([1, 2.0, 3, 1], True) == [1, 2.0, 3]
    assert unique([1, 2.0, 3, 1], False) == [1, 3, 2.0]
    assert unique([1, 2.0, 3, 1], case_sensitive=True) == [1, 2.0, 3]
    assert unique([1, 2.0, 3, 1], case_sensitive=False)

# Generated at 2022-06-23 10:17:12.026151
# Unit test for function human_readable
def test_human_readable():
    # Taken from http://www.ibm.com/developerworks/linux/library/l-si/
    assert human_readable(10, isbits=False) == '10 B'
    assert human_readable(10, isbits=True) == '10 bits'
    assert human_readable(10, isbits=False, unit='KB') == '10 KB'
    assert human_readable(10, isbits=True, unit='KB') == '10 Kbit'
    assert human_readable(10**12, isbits=False) == '12000.0 MB'
    assert human_readable(10**12, isbits=True) == '12000.0 Mbit'

    # 2**64
    assert human_readable(18446744073709551616, isbits=False) == '2.0 E'
    assert human_

# Generated at 2022-06-23 10:17:24.179315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-23 10:17:25.797284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:17:31.238603
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils import basic
    import json

    def assert_result(data, key, new_dict):
        result = basic.AnsibleModule(argument_spec={}).run_command('echo', json.dumps(data))[1]
        result = json.loads(result)
        result = result['rekey_on_member']
        assert result == new_dict

    # test duplicates error
    err_data = {
        "nodes": [
            {"name": "node1", "ip": "10.0.0.1", "size": "small"},
            {"name": "node1", "ip": "10.0.0.11", "size": "small"}
        ]
    }
    err_key = 'name'

# Generated at 2022-06-23 10:17:41.643102
# Unit test for function human_readable
def test_human_readable():
    '''
    Check valid inputs on function human_readable
    '''
    assert(human_readable(0)) == '0 B'
    assert(human_readable(0, isbits=True)) == '0 b'
    assert(human_readable(100)) == '100 B'
    assert(human_readable(100, isbits=True)) == '800 b'
    assert(human_readable(200, unit='kb')) == '200 kb'
    assert(human_readable(2000, unit='kb', isbits=True)) == '16 Mb'
    assert(human_readable(10000, unit='mb')) == '10.0 mb'
    assert(human_readable(12000, unit='gb', isbits=True)) == '96 Gb'

# Generated at 2022-06-23 10:17:52.219275
# Unit test for function human_readable
def test_human_readable():
    if not human_readable(1, False) == '1.0 B':
        raise AssertionError('human_readable() failed on 1.0 B')
    if not human_readable(1) == '1.0 B':
        raise AssertionError('human_readable() failed on 1.0 B')
    if not human_readable(10, False) == '10 B':
        raise AssertionError('human_readable() failed on 10 B')
    if not human_readable(100, False) == '100 B':
        raise AssertionError('human_readable() failed on 100 B')
    if not human_readable(1024, False) == '1.0 KiB':
        raise AssertionError('human_readable() failed on 1mib 1024')

# Generated at 2022-06-23 10:18:02.527926
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1) == '1 B'
    assert human_readable(10) == '10 B'
    assert human_readable(100) == '100 B'
    assert human_readable(1000) == '1000 B'
    assert human_readable(1000**2) == '1000 kB'
    assert human_readable(1000**3) == '1000 MB'
    assert human_readable(1000**4) == '1000 GB'
    assert human_readable(1000**5) == '1000 TB'
    assert human_readable(1000**6) == '1000 PB'
    assert human_readable(1000**7) == '1000 EB'
    assert human_readable(1000**8) == '1000 ZB'
    assert human_readable(1000**9) == '1000 YB'

    # test precision

# Generated at 2022-06-23 10:18:05.542310
# Unit test for function union
def test_union():
    assert union([1,2,3], [2,3,4,5]) == [1,2,3,4,5]
    assert union([1,2,3], [2,3]) == [1,2,3]

# Generated at 2022-06-23 10:18:16.656583
# Unit test for function min
def test_min():
    f = FilterModule()

# Generated at 2022-06-23 10:18:26.606580
# Unit test for function human_readable
def test_human_readable():
    x = human_readable(bytes_data=536870912, isbits=False, unit=None)
    assert x == '512M', x

    x = human_readable(bytes_data=536870912, isbits=True, unit=None)
    assert x == '4G', x

    x = human_readable(bytes_data=536870912, isbits=False, unit='B')
    assert x == '512M', x

    x = human_readable(bytes_data=536870912, isbits=True, unit='B')
    assert x == '4G', x

    x = human_readable(bytes_data=536870912, isbits=False, unit='KB')
    assert x == '524288K', x


# Generated at 2022-06-23 10:18:31.797553
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1, "Failed on '1'"
    assert human_to_bytes('1K') == 1024, "Failed on '1K'"
    assert human_to_bytes('1M') == 1048576, "Failed on '1M'"
    assert human_to_bytes('1G') == 1073741824, "Failed on '1G'"


# Generated at 2022-06-23 10:18:39.572995
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == "0.00 B"
    assert human_readable(1) == "1.00 B"
    assert human_readable(1, True) == "8.00 b"
    assert human_readable(2**10) == "1.00 KB"
    assert human_readable(2**20) == "1.00 MB"
    assert human_readable(2**30) == "1.00 GB"
    assert human_readable(2**40) == "1.00 TB"
    assert human_readable(2**50) == "1.00 PB"
    assert human_readable(2**60) == "1.00 EB"
    assert human_readable(2**70) == "1.00 ZB"
    assert human_readable(2**80) == "1.00 YB"
    assert human

# Generated at 2022-06-23 10:18:47.424367
# Unit test for function human_readable
def test_human_readable():
    """
    Human readable test

    :return: True
    """
    print(human_readable(1024, unit='B'))
    print(human_readable(1048576))
    print(human_readable(1073741824, unit='iB'))
    print(human_readable(1099511627776, unit='B'))
    print(human_readable(1125899906842624, unit='B', isbits=True))
    return True

# Generated at 2022-06-23 10:18:59.739290
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.compat.tests import unittest

    class TestHumanToBytes(unittest.TestCase):
        def test_decimal_units(self):
            # Test bytes
            self.assertEqual(human_to_bytes("1"), 1)
            self.assertEqual(human_to_bytes("25"), 25)
            self.assertEqual(human_to_bytes("1B"), 1)
            self.assertEqual(human_to_bytes("25B"), 25)
            self.assertEqual(human_to_bytes("1KB"), 1000)
            self.assertEqual(human_to_bytes("25KB"), 25000)
            self.assertRaises(AnsibleFilterError, human_to_bytes, "25b")

            # Test bits

# Generated at 2022-06-23 10:19:06.591584
# Unit test for function intersect
def test_intersect():
    jinja2 = DummyEnvironment()

    # Dictionary intersect
    assert 'a' == list(intersect(jinja2, {'a': 'match1', 'b': 'mismatch'}, {'a': 'match2'}))[0]

    # List intersect
    assert 'a' == list(intersect(jinja2, ['a', 'b'], ['a', 'c']))[0]

    # Large list intersect, needs unique fallback
    assert len(list(intersect(jinja2, ['a', 'b'] * 10000, ['a', 'c'] * 10000))) == 1

    # OrderedDict intersect, needs unique fallback
    try:
        from collections import OrderedDict
    except ImportError:
        from ansible.module_utils.common._collections_compat import OrderedDict


# Generated at 2022-06-23 10:19:12.906378
# Unit test for function unique
def test_unique():

    data = [
        {'name': 'foo', 'key': 'value1'},
        {'name': 'foo', 'key': 'value2'},
    ]

    filtered_data = unique(None, data, True)
    assert len(filtered_data) == 1
    assert filtered_data[0] == data[0]

    filtered_data = unique(None, data, True, 'name')
    assert len(filtered_data) == 1
    assert filtered_data[0] == data[0]



# Generated at 2022-06-23 10:19:21.042030
# Unit test for function max
def test_max():
    assert max([1,2]) == 2
    assert max([2,3,4,5,4,3,4,5,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3,4,3]) == 5
    assert max([1, 2, 0, 1, 0, 2, 1, 2]) == 2
    assert max([1, 2, 0, 3, 4, 0, 5, 6]) == 6
    assert max([-1, 0, 1]) == 1
    assert max([-1, -2, -3]) == -1
    assert max([]) == None



# Generated at 2022-06-23 10:19:23.476666
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3, 4], [3, 4]) == [3, 4]

# Generated at 2022-06-23 10:19:27.217687
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1]) == 1
    assert max([]) is None

    # Handle None
    assert max([None, 1, 2]) is None



# Generated at 2022-06-23 10:19:31.141639
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(64, 2) == 6
    assert logarithm(8, 2) == 3
    assert logarithm(3, 2) == 1.584962500721156
    assert logarithm(2, 3) == 0.6309297535714574


# Generated at 2022-06-23 10:19:39.759773
# Unit test for function human_to_bytes

# Generated at 2022-06-23 10:19:48.111270
# Unit test for function intersect
def test_intersect():
    efilter = FilterModule().filters()
    assert efilter['intersect']('ABC', 'ABC') == 'ABC'
    assert efilter['intersect']('ABC', 'ABD') == 'AB'
    assert efilter['intersect']('A', 'ABC') == 'A'
    assert efilter['intersect']('ABC', 'D') == ''
    assert efilter['intersect']('ABC', '') == ''
    assert efilter['intersect']('ABC', 1) == ''
    assert efilter['intersect'](['A', 'B', 'C'], ['A', 'B', 'C']) == ['A', 'B', 'C']
    assert efilter['intersect'](['A', 'B', 'C'], ['A', 'B', 'D']) == ['A', 'B']
    assert efilter

# Generated at 2022-06-23 10:19:53.031025
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, base=3) == 9
    assert power(4, 0.5) == 2
    assert power(4, 2) == 16
    assert power(5, 0.5) == 2.23606797749979
    assert type(power(5, 0.5)) is float



# Generated at 2022-06-23 10:20:01.291065
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("30000") == 30000
    assert human_to_bytes("30000", default_unit="bit") == 30000
    assert human_to_bytes("30000 kb") == 30000 * 1024
    assert human_to_bytes("30000 MB") == 30000 * 1024 * 1024
    assert human_to_bytes("30000 GB") == 30000 * 1024 * 1024 * 1024
    assert human_to_bytes("30000 TB") == 30000 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes("30000 TB", isbits=True) == 30000 * 1024 * 1024 * 1024 * 1024 * 8
    assert human_to_bytes("30000", default_unit="GB") == 30000 * 1024 * 1024 * 1024
    assert human_to_bytes("30000", default_unit="bit") == 30000


# Generated at 2022-06-23 10:20:10.804114
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # When two lists are given as input
    # we should get a single list as output
    input = [1, 2, 3]
    output = [3, 4, 5]
    diff = [3, 4, 5]

    assert symmetric_difference(input, output) == diff

    # When two strings are given as input
    # we should get a single string as output
    input = 'foo'
    output = 'oof'
    diff = 'of'

    assert symmetric_difference(input, output) == diff

    # When an integer and a string are given
    # as input, an exception should be raised
    input = 1
    output = 'foo'

    try:
        symmetric_difference(input, output)
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-23 10:20:11.932170
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()


# Generated at 2022-06-23 10:20:17.058210
# Unit test for function min
def test_min():
    assert min([1]) == 1
    assert min([1, 2]) == 1
    assert min([2, 1]) == 1
    assert min([-1, -2]) == -2
    assert min([-1, -2, 2, 1]) == -2
    assert min([-1, -2, 2, 1, 0]) == -2
    assert min([1, 2, -2, -1, 0]) == -2
    assert min([]) == None

# Generated at 2022-06-23 10:20:20.104103
# Unit test for function intersect
def test_intersect():
    a = [u'foo', u'bar']
    b = [u'foo', u'foo']

    c = intersect(a, b)

    assert c == [u'foo'], 'unexpected intersection {0}'.format(c)


# Generated at 2022-06-23 10:20:30.784719
# Unit test for function difference
def test_difference():

    filters = FilterModule()

    assert [1, 3] == filters.filters()['difference']([1, 2, 3, 4], [2, 4])
    assert 'd' == filters.filters()['difference']('abcd', 'abc')
    assert [] == filters.filters()['difference']([], [])
    assert [] == filters.filters()['difference']('', '')
    assert [2, 3, 4] == filters.filters()['difference']([1, 2, 3, 4, 5], [1, 5])
    assert {1: 2, 3: 4, 5: 6} == filters.filters()['difference']({1: 2, 2: 3, 3: 4, 4: 5, 5: 6}, [2, 4])

# Generated at 2022-06-23 10:20:41.385413
# Unit test for function difference

# Generated at 2022-06-23 10:20:47.238965
# Unit test for function human_readable
def test_human_readable():
    assert '1.00 B' == formatters.bytes_to_human(1)
    assert '1.00 KB' == formatters.bytes_to_human(1024)
    assert '1.00 MB' == formatters.bytes_to_human(1024 * 1024)
    assert '1.00 GB' == formatters.bytes_to_human(1024 * 1024 * 1024)
    assert '1.00 TB' == formatters.bytes_to_human(1024 * 1024 * 1024 * 1024)
    assert '1.00 PB' == formatters.bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024)
    assert '1.00 EB' == formatters.bytes_to_human(1024 * 1024 * 1024 * 1024 * 1024 * 1024)

# Generated at 2022-06-23 10:20:52.508375
# Unit test for function intersect
def test_intersect():
    from ansible.module_utils import basic
    from ansible.plugins.filter import math as math_filter
    from ansible.compat.tests import unittest

    class TestIntersect(unittest.TestCase):
        def test_single(self):
            data = [1, 2, 3, 4]
            self.assertEqual([1], math_filter.intersect(basic.AnsibleModule(), data, [1]))

        def test_multiple(self):
            data = [1, 2, 3, 4]
            self.assertCountEqual([1, 2], math_filter.intersect(basic.AnsibleModule(), data, [1, 2]))

        def test_empty(self):
            data = [1, 2, 3, 4]

# Generated at 2022-06-23 10:21:02.126441
# Unit test for function unique
def test_unique():
    print("Testing unique")
    # Test strings
    assert unique(['a', 'b', 'c', 'a', 'a'], False) == ['a', 'b', 'c']
    assert unique(['a', 'foo', 'c', 'bar', 'a'], False) == ['a', 'foo', 'c', 'bar']
    assert unique(['a', 'foo', 'c', 'bar', 'a'], False, 'length') == ['a', 'c', 'bar']
    # Test ints
    assert unique([1, 2, 3, 1, 1], False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 1], False, 'length') == [1, 2]
    # Test dictionaries

# Generated at 2022-06-23 10:21:04.727518
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert instance is not None



# Generated at 2022-06-23 10:21:10.995935
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule().filters()
    assert filters['log'] == logarithm
    assert filters['pow'] == power
    assert filters['min'] == min
    assert filters['max'] == max
    assert filters['inversepower'] == inversepower
    assert filters['human_readable'] == human_readable



# Generated at 2022-06-23 10:21:19.547865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.utils.unskip as unskip

    unskip.mark_all_targets()
    
    # test general math functions
    def test_min(F):
        assert F.min([]) is None
        assert F.min([1, 2, 3]) == 1
        assert F.min(['a', 'b', 'c']) == 'a'
        assert F.min([(1, 2), (3, 0), (-1, 9), (1, 1)], attribute='1') == 0

        try:
            F.min(1, 2)
        except Exception as e:
            assert isinstance(e, AnsibleFilterTypeError)

    # test exponents and logarithms
    def test_log(F):
        assert F.log(4, 2) == 2
        assert F.log

# Generated at 2022-06-23 10:21:29.687722
# Unit test for function human_to_bytes

# Generated at 2022-06-23 10:21:38.441000
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0, True) == '0 bits'
    assert human_readable(8) == '8.0 B'
    assert human_readable(8, True) == '8 bits'
    assert human_readable(8, False, 'B') == '8 B'
    assert human_readable(8, True, 'B') == '8.0 Bb'
    assert human_readable(8, False, 'KiB') == '8.0 KiB'
    assert human_readable(8, True, 'KiB') == '8.0 KiBb'
    assert human_readable(1000) == '1000 B'
    assert human_readable(1000, True) == '1000 bits'
    assert human_readable(1000, False, 'B') == '1000 B'

# Generated at 2022-06-23 10:21:46.113952
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # Set up test
    test_list1 = [1, 2, 3, 4]
    test_list2 = [3, 4, 5, 6]

    # Perform test
    retval = symmetric_difference(test_list1, test_list2)

    # Perform assertions
    assert len(retval) == 4
    assert 1 in retval
    assert 2 in retval
    assert 5 in retval
    assert 6 in retval

# Generated at 2022-06-23 10:21:48.410228
# Unit test for function min
def test_min():
    assert FilterModule().filters()['min']([1, 2]) == 1



# Generated at 2022-06-23 10:22:00.322337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    import random
    import string

    test = FilterModule()
    filters = test.filters()

    # Test list of ints and floats
    int_list = [random.randint(0, 100) for _ in range(10)]
    float_list = [random.uniform(0, 100) for _ in range(10)]

    # Test list of strings
    char_set = string.ascii_lowercase
    string_list = [''.join(random.sample(char_set*5, 5)) for _ in range(10)]

    # Test general math filters
    def test_general_math_filters(input_list):
        assert filters['min'](input_list) == min(input_list)
        assert filters['max'](input_list) == max(input_list)

    # Test

# Generated at 2022-06-23 10:22:06.979395
# Unit test for function human_readable
def test_human_readable():

    assert human_readable(100).strip() == '100 B'
    assert human_readable(1024).strip() == '1 KB'
    assert human_readable(1024000).strip() == '1000 KB'
    assert human_readable(1.0).strip() == '1 B'
    assert human_readable(1024, isbits=True).strip() == '8 Kb'
    assert human_readable(1024000, isbits=True).strip() == '8000 Kb'
    assert human_readable(1048576, isbits=True).strip() == '8192 Kb'
    assert human_readable(1048576, isbits=True, unit='Byte').strip() == '8 Mb'
    assert human_readable(1048576, isbits=True, unit='Bit').strip() == '8 Kb'



# Generated at 2022-06-23 10:22:07.915612
# Unit test for function power
def test_power():
    p = power(2, 3)
    assert p == 8

# Generated at 2022-06-23 10:22:11.637039
# Unit test for function max
def test_max():
    test_value = [0, 1, 2, 3, 4, 5]

    def err_case():
        raise AssertionError()

    assert max(test_value) == 5, err_case()



# Generated at 2022-06-23 10:22:22.952892
# Unit test for function intersect
def test_intersect():
    result = intersect([1, 2, 3, 4], [2, 3, 4, 5])
    assert result == [2, 3, 4]

    result = intersect([1, 1, 2, 3, 4], [2, 3, 4, 5])
    assert result == [2, 3, 4]

    result = intersect([1, 2, 3, 4], [2, 3, 4, 5])
    assert result == [2, 3, 4]

    result = intersect([1, 2, 3, 4], {2, 3, 4, 5})
    assert result == [2, 3, 4]

    result = intersect([1, 1, 2, 3, 4], {2, 3, 4, 5})
    assert result == [2, 3, 4]


# Generated at 2022-06-23 10:22:31.989804
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("2M") == 2097152
    assert human_to_bytes("3.3M", "M") == 3418880
    assert human_to_bytes("100%") == -1
    assert human_to_bytes("100 GB") == 107374182400
    assert human_to_bytes("5TB") == 5497558138880
    assert human_to_bytes("5tb") == 5497558138880
    assert human_to_bytes("5P") == 5629499534213120
    assert human_to_bytes("3.3", "M") == 3418880
    assert human_to_bytes("3.3", "G") == 35651584
    assert human_to_bytes("5%") == -1
    assert human_to_bytes("5") == 5


# Generated at 2022-06-23 10:22:37.546170
# Unit test for function logarithm
def test_logarithm():
    fm = FilterModule()
    assert 3.2 == fm.filters()['log'](100, 10)
    assert 2.718281828459 == fm.filters()['log'](10)
    assert 2.0 == fm.filters()['log'](100, 100)


# Generated at 2022-06-23 10:22:46.523553
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2], [2, 3]) == [1, 3]
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]

    assert symmetric_difference([1, '2'], [2, 3]) == ['1', '2', '3']
    assert symmetric_difference([1, '2'], [1, 3]) == ['2', '3']
    assert symmetric_difference([1, '2'], [1, '2']) == []

    assert symmetric_difference([[1, 'a'], [2, 'b'], [3, 'c']], [[2, 'b'], [3, 'c'], [4, 'd']]) == [[1, 'a'], [4, 'd']]

# Generated at 2022-06-23 10:22:55.387435
# Unit test for function logarithm
def test_logarithm():
    data = (
        (1, 2, 0.3010299956639812),
        (10, 10, 1.0),
        (10, 2, 3.3219280948873626),
        (10, 'foo', None),
        ('foo', 10, None),
        (2, 3, 0.6309297535714574),
    )
    for x, base, expected in data:
        result = logarithm(x, base)
        if result != expected:
            raise AssertionError("log({0}, {1}) returned {2}, expected {3}".format(x, base, result, expected))



# Generated at 2022-06-23 10:22:58.286382
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm_instance = FilterModule()
    assert isinstance(fm_instance, FilterModule)
    assert fm_instance.filters()


# Generated at 2022-06-23 10:23:10.234390
# Unit test for function max
def test_max():
    assert max([]) == None
    assert max([1]) == 1
    assert max([1, 2]) == 2
    assert max([2, 1]) == 2
    assert max(['a', 'b']) == 'b'
    assert max([2.2, 2.1, 1.9]) == 2.2
    assert max([2.2, 2.5, 2.1, 1.9]) == 2.5
    assert max([2.2, '2.5', 2.1, 1.9]) == 2.2
    assert max(['b', 'c', 'a']) == 'c'
    assert max([1, 2, 'a']) == 2
    assert max(['a', 'b', 'c'], key=lambda x: ord(x)) == 'c'


# Generated at 2022-06-23 10:23:18.087587
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''test human_to_bytes() function'''

    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1k') == 1000
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1m') == 1000**2
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1g') == 1000**3
    assert human_to_bytes('1G') == 1024**3
    assert human_to_bytes('1t') == 1000**4
    assert human_to_bytes('1T') == 1024**4
    assert human_to_bytes('1p') == 1000**5
    assert human_to_bytes('1P') == 1024**5

# Generated at 2022-06-23 10:23:21.567135
# Unit test for function union
def test_union():
    _union = union(None, [1, 2, 3, 4], [2, 3, 4, 5])
    assert _union == [1, 2, 3, 4, 5]



# Generated at 2022-06-23 10:23:22.733264
# Unit test for function max
def test_max():
    assert max([1, 5, 2]) == 5


# Generated at 2022-06-23 10:23:25.411225
# Unit test for function power
def test_power():
    assert power(2,2) == 4
    assert power(2,-1) == 0.5
    assert power(2,0) == 1
    assert power(2,3) == 8

# Generated at 2022-06-23 10:23:32.190778
# Unit test for function intersect
def test_intersect():
    # Test intersect with nested dictionaries
    a = {'a': {'x': 1, 'y': 2}, 'b': {'x': 2, 'z': 1}}
    b = {'a': {'x': 1, 'y': 2}, 'b': {'x': 1, 'z': 1}}
    assert intersect(a, b) == {'a': {'x': 1, 'y': 2}}

    # Test intersect with set
    a = {'a', 'b', 'c'}
    b = {'c', 'd', 'e'}
    assert intersect(a, b) == {'c'}

    # Test intersect with list
    a = ['a', 'b', 'c', 'b']
    b = ['c', 'd', 'e', 'a']
    assert intersect(a, b)

# Generated at 2022-06-23 10:23:41.373611
# Unit test for function inversepower
def test_inversepower():
    module = type('Module', (object,), {})()
    module.fail_json = fail_json
    module.log = log
    module._ansible_test_test_inversepower = inversepower

    setattr(module, '_ansible_test_test_inversepower', inversepower)
    setattr(module, '_ansible_test_test_inversepower', inversepower)
    setattr(module, '_ansible_test_test_inversepower', inversepower)

    # first test square root
    assert inversepower(4.0) == 2.0
    assert inversepower(9.0) == 3.0
    assert inversepower(2.0) == 1.4142135623730951
    assert inversepower(8.0) == 2.8284271247461903

    # now test

# Generated at 2022-06-23 10:23:53.229411
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.module_utils.common.text import format_json
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils import basic

    check_result = basic.AnsibleModule(
        argument_spec=dict(
            a=dict(type='list'),
            b=dict(type='list'),
        )
    ).run_command(to_bytes('/usr/bin/python'), [to_bytes(__file__), '--symmetric_difference'], check_rc=True)[1]

    check_result = to_text(check_result)

# Generated at 2022-06-23 10:23:56.601407
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100, 10) == 2.0
    assert logarithm(8, 2) == 3.0


# Generated at 2022-06-23 10:23:57.846007
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm is not None)

# Generated at 2022-06-23 10:24:08.276602
# Unit test for function min
def test_min():
    f = FilterModule()
    assert f.filters()['min']([1, 2, 3, 4, 5]) == 1
    assert f.filters()['min']([-1, -2, -3, -4, -5]) == -5
    assert f.filters()['min']([-1.1, -2.2, -3.3, -4.4, -5.5]) == -5.5
    assert f.filters()['min']([1, 2, 3, 4, 5], by='<') == 5
    assert f.filters()['min']([-1, -2, -3, -4, -5], by='<') == -1

# Generated at 2022-06-23 10:24:11.639335
# Unit test for function power
def test_power():
    for x in range(1, 10):
        for y in range(1, 10):
            assert pow(x, y) == power(x, y), 'Function power failed: pow(%s, %s) != %s' % (x, y, power(x, y))


# Generated at 2022-06-23 10:24:25.819924
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3, 4, 5]
    b = [3, 4, 5, 6, 7]
    assert symmetric_difference(None, a, b) == [1, 2, 6, 7]
    a = 'abcde'
    b = 'cdefg'
    assert symmetric_difference(None, a, b) == list('abeg')
    a = ['a', 'b', 'c']
    b = ['c', 'd', 'e']
    assert symmetric_difference(None, a, b) == ['a', 'b', 'd', 'e']
    a = {'a', 'b', 'c'}
    b = {'c', 'd', 'e'}

# Generated at 2022-06-23 10:24:28.280064
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_class = FilterModule()
    assert 'zip' in test_class.filters()


# Generated at 2022-06-23 10:24:35.721557
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1, 2) == 0
    assert logarithm(8, 2) == 3
    assert logarithm(3, 10) == 0.47712125471966244
    assert logarithm(666, 10) == 2.8271582625136924
    assert logarithm(1) == 0
    assert logarithm(666) == 6.3926916262991335
    assert logarithm(42, 42) == 1
    assert logarithm(42, 1) == 42


# Generated at 2022-06-23 10:24:44.624795
# Unit test for function power
def test_power():
    class TestFilterPower(object):
        def test_power_non_numeric_input(self):
            with pytest.raises(AnsibleFilterTypeError):
                power("two", "three")

        def test_power_non_numeric_input_float(self):
            with pytest.raises(AnsibleFilterTypeError):
                power(2.0, "three")

        def test_power_non_numeric_input_float_second(self):
            with pytest.raises(AnsibleFilterTypeError):
                power("two", 3.0)

        def test_power_numeric_input_int(self):
            assert power(2, 3) == 8

        def test_power_numeric_input_float(self):
            assert power(2.0, 3.0) == 8.

# Generated at 2022-06-23 10:24:49.190232
# Unit test for function symmetric_difference
def test_symmetric_difference():
    x = [0,1,2,3,4,5]
    y = [2,3,4,5,6,7]
    result = symmetric_difference(None, x, y)
    assert len(result) == 6 and result == [0,1,6,7]

# Generated at 2022-06-23 10:24:53.062001
# Unit test for function union
def test_union():
    test_filter = FilterModule()
    filters = test_filter.filters()
    assert filters['union']([1, 2], [2, 3]) == [1, 2, 3]



# Generated at 2022-06-23 10:25:02.890244
# Unit test for function difference
def test_difference():
    result = difference(
        [
            'A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9', 'A10',
            'A11', 'A12', 'A13', 'A14', 'A15', 'A16', 'A17', 'A18', 'A19', 'A20',
            'A21', 'A22', 'A23', 'A24', 'A25', 'A26', 'A27', 'A28', 'A29', 'A30'
        ],
        [
            'A5', 'A9', 'A11', 'A12', 'A15', 'A19', 'A23', 'A26'
        ]
    )


# Generated at 2022-06-23 10:25:13.695282
# Unit test for function difference
def test_difference():

    filter_module = FilterModule()
    filters = filter_module.filters()

    # The following are the test values
    A = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    B = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
    C = (2, 4, 6, 8, 10, 12, 14, 16, 18, 20)
    D = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
    E = (1, 3, 5, 7, 9, 11, 13, 15, 17, 19)

    # The following are the results of the test values
    R1 = [1, 3, 5, 7, 9] # A - B
    R2 = [3, 5, 7, 9]

# Generated at 2022-06-23 10:25:15.522991
# Unit test for function power
def test_power():
    assert power(3, 2) == 9
    assert power(10, 0) == 1



# Generated at 2022-06-23 10:25:18.455315
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    filters = filter_module.filters()
    result = filters['min']([1, 2, 3], [0, 1, 2])
    assert 0 == result


# Generated at 2022-06-23 10:25:24.605769
# Unit test for function symmetric_difference
def test_symmetric_difference():
    """ Unit test for function symmetric_difference()
        Returns:
            None
    """
    s_diff=symmetric_difference([1,2,3,4,5], [3,4,5,6,7])
    assert [1, 2, 6, 7] == s_diff, "Test failed!"


# Generated at 2022-06-23 10:25:29.389660
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]
    assert union([], []) == []
    assert union([], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], []) == [1, 2, 3]



# Generated at 2022-06-23 10:25:40.975825
# Unit test for function union
def test_union():
    from ansible.module_utils._text import to_bytes, to_text
    from io import BytesIO, StringIO

    x = [1, 2, 3]
    y = [2, 3, 4]

    assert union(None, [x, y]) == [1, 2, 3, 4]
    assert union(None, [to_bytes(s) for s in x], [to_bytes(s) for s in y]) == [to_bytes(s) for s in [1, 2, 3, 4]]
    assert union(None, [to_bytes(s) for s in x], [to_text(s) for s in y]) == [to_bytes(s) for s in [1, 2, 3, 4]]


# Generated at 2022-06-23 10:25:47.676184
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(0, isbits=True) == '0'
    assert human_readable(0, unit='B') == '0'

    assert human_readable(1) == '1'
    assert human_readable(1, isbits=True) == '1'
    assert human_readable(1, unit='B') == '1'

    assert human_readable(1000) == '1.0K'
    assert human_readable(1000, isbits=True) == '1.0Ki'
    assert human_readable(1000, unit='B') == '1.0K'

    assert human_readable(1024) == '1.0K'
    assert human_readable(1024, isbits=True) == '1.0Ki'

# Generated at 2022-06-23 10:25:53.232544
# Unit test for function logarithm
def test_logarithm():
    assert 2.0 == logarithm(100.0, 10.0)
    assert 2.0 == logarithm(100.0)
    assert 2.0 == logarithm(math.e ** 2)
    assert math.log(7.0) == logarithm(7.0)

