

# Generated at 2022-06-25 09:20:26.232044
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('45M') == 47185920
    assert human_to_bytes('87GB') == 94489280512
    assert human_to_bytes('67M') == 69905024
    assert human_to_bytes('18M') == 18874368
    assert human_to_bytes('10G') == 10737418240


# Generated at 2022-06-25 09:20:28.283337
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3, "3 is the maximum value among 1, 2 and 3 "


# Generated at 2022-06-25 09:20:36.024428
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()

    # Test with no key arguments
    assert filter_module_0.filters()['min']([3, 4, 1, 4]) == 1

    # Test with key argument
    assert filter_module_0.filters()['min']([{'val': -5}, {'val': 2}, {'val': 4}], key='val') == {'val': -5}

    # Test with no key argument and case_sensitive=True
    assert filter_module_0.filters()['min'](['b', 'c', 'a', 'c']) == 'a'

    # Test with key argument and case_sensitive=True

# Generated at 2022-06-25 09:20:38.921364
# Unit test for function inversepower
def test_inversepower():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['root'](8, 2) == 2.8284271247461903
    assert filter_module_0.filters()['root'](8, 3) == 2.0


# Generated at 2022-06-25 09:20:45.805632
# Unit test for function min
def test_min():
    assert min([4, 2, 3, 1]) == 1
    assert min([4]) == 4

    assert min([4, 2, 3, 1], **{'attribute': 'keys'}) == 1
    assert min([4], **{'attribute': 'keys'}) == 4

    assert min([{'foo': 4, 'bar': 2}, {'foo': 3, 'bar': 1}], **{'attribute': 'foo'}) == {'foo': 3, 'bar': 1}
    assert min([{'foo': 4, 'bar': 2}], **{'attribute': 'foo'}) == {'foo': 4, 'bar': 2}


# Generated at 2022-06-25 09:20:51.592579
# Unit test for function logarithm
def test_logarithm():
    filter_module_logarithm = FilterModule()
    assert filter_module_logarithm.filters()['log'](10) == 2.302585092994046



# Generated at 2022-06-25 09:20:54.483128
# Unit test for function min
def test_min():
    assert min([0, 1, 2]) == 0
    assert min([0, 1, 2], attribute='key') == 0
    assert min([0, 1, 2], case_sensitive=True) == 0
    assert min([0, 1, 2], attribute='key', case_sensitive=True) == 0


# Generated at 2022-06-25 09:21:00.270710
# Unit test for function human_to_bytes
def test_human_to_bytes():

    assert human_to_bytes('0') == 0
    assert human_to_bytes('0B') == 0
    assert human_to_bytes('0Gb') == 0

    # integer
    assert human_to_bytes('1') == 1
    assert human_to_bytes(1) == 1

    # Bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1000') == 1000
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1000000') == 1000000
    assert human_to_bytes('2147483648') == 2147483648

    # KBytes
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K')

# Generated at 2022-06-25 09:21:05.999732
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    json_input = '[1,2,3]'
    json_output = 1
    assert_output = filter_module_0.filters['min'](json_input)
    assert assert_output == json_output, 'Test Failed'



# Generated at 2022-06-25 09:21:09.376061
# Unit test for function max
def test_max():
    assert FilterModule().filters()['max']([1, 2, 3, 4]) == 4


# Generated at 2022-06-25 09:21:24.358095
# Unit test for function max
def test_max():
    pass



# Generated at 2022-06-25 09:21:31.984132
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    results = filter_module_max.filters()['max'](range(1,10))
    assert results == 9
    results = filter_module_max.filters()['max'](range(0, -10, -1))
    assert results == 0
    results = filter_module_max.filters()['max'](range(-1, -10, -1))
    assert results == -1


# Generated at 2022-06-25 09:21:36.708426
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    filter_dict_0 = filter_module_0.filters()
    arg_0 = 3
    arg_1 = 5
    arg_2 = 6
    arg_3 = 1
    arg_4 = [arg_0, arg_1, arg_2, arg_3]
    result = filter_dict_0['min'](arg_4)
    assert 1 == result



# Generated at 2022-06-25 09:21:39.575125
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([1, 2, 3]) == 3

# unit test for function min

# Generated at 2022-06-25 09:21:48.378291
# Unit test for function min
def test_min():
    print('')
    print('Testing min')
    result = min([0, 3, 2])
    assert(result == 0)
    print('min([0, 3, 2]) = ' + str(result))

    try:
        result = min([0, 3, 2], key=lambda x: x['item'])
        print('')
        print('This should raise an exception')
        print('min([0, 3, 2], key=lambda x: x[\'item\']) = ' + str(result))
    except Exception as e:
        assert(True)
        print("Success")



# Generated at 2022-06-25 09:21:52.178948
# Unit test for function unique
def test_unique():
    filter_module_0 = FilterModule()
    c = filter_module_0.filters()['unique']
    assert c(['a', 'a', 'b', 'b', 'b']) == ['a', 'b']
    assert c(['a', 'b', 'c', 'a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-25 09:21:55.450292
# Unit test for function max
def test_max():
    assert max([10, 2, 3, 8, 3]) == 10


# Generated at 2022-06-25 09:21:56.624955
# Unit test for function logarithm
def test_logarithm():
    result = logarithm(100,10)
    assert result == 2

# Generated at 2022-06-25 09:22:00.289329
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = {
        'a': {
            'b': 1,
            'c': 2
        },
        'e': {
            'f': 3,
            'g': 4
        },
    }
    key = 'c'
    duplicates = 'error'
    res = rekey_on_member(data, key, duplicates)
    assert '{b: 1, c: 2}' in res.values()
    assert '{f: 3, g: 4}' in res.values()
    assert '2' in res


# Generated at 2022-06-25 09:22:03.396747
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()

    assert filter_module_1.filters()['max']([1,2,3,4,5]) == 5, "Didn't return max value from list"

# Test invalid max input

# Generated at 2022-06-25 09:22:17.412432
# Unit test for function max
def test_max():
    assert max(1, 2, 3) == 3
    assert max(float(1), float(2)) == 2.0
    assert max([1, 2, 3, 0]) == 3


# Generated at 2022-06-25 09:22:25.371761
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(u'0') == 0
    assert human_to_bytes(u'10') == 10
    assert human_to_bytes(u'10B') == 10
    assert human_to_bytes(u'10K') == 10240
    assert human_to_bytes(u'10M') == 10485760
    assert human_to_bytes(u'10G') == 10737418240
    assert human_to_bytes(u'10T') == 10995116277760
    assert human_to_bytes(u'10P') == 11258999068426240
    assert human_to_bytes(u'10E') == 1152921504606847000
    assert human_to_bytes(u'10Z') == 118059162071741130

# Generated at 2022-06-25 09:22:26.808087
# Unit test for function unique
def test_unique():
    assert unique(['a', 'a', 'b', 'c', 'b', 'a']) == ['a', 'b', 'c']


# Generated at 2022-06-25 09:22:39.070686
# Unit test for function min
def test_min():
    assert min([0, 1, 2, 3, 4]) == 0, "min([0, 1, 2, 3, 4]) should be 0"
    assert min([0.0, 1.0, 2.0, 3.0, 4.0]) == 0.0, "min([0, 1, 2, 3, 4]) should be 0.0"
    assert min([4, 3, 2, 1, 0]) == 0, "min([4, 3, 2, 1, 0]) should be 0"
    assert min([4.0, 3.0, 2.0, 1.0, 0.0]) == 0.0, "min([4.0, 3.0, 2.0, 1.0, 0.0]) should be 0.0"

# Generated at 2022-06-25 09:22:40.420853
# Unit test for function max
def test_max():
    assert 4 == max([2, 3, 4])


# Generated at 2022-06-25 09:22:42.980404
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([[1], [2], [3]]) == [1]


# Generated at 2022-06-25 09:22:54.129267
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # test a dict of dicts is rekeyed
    data = {
        'item1': {
            'item': 'test',
            'second': 'test1',
            },
        'item2': {
            'item': 'test2',
            'second': 'test3',
            },
        }
    result = rekey_on_member(data, 'item')
    assert result == {
        'test': {
            'item': 'test',
            'second': 'test1',
            },
        'test2': {
            'item': 'test2',
            'second': 'test3',
            },
        }

    # test an array of dicts is rekeyed

# Generated at 2022-06-25 09:22:58.636424
# Unit test for function min
def test_min():
    assert min([5, 9, 2, 3]) == 2
    assert min(5, 9, 2, 3) == 2
    assert min([[5, 9], [2, 3]]) == [2, 3]
    assert min(5, 9, None) is None
    assert min([5, 9, None]) is None


# Generated at 2022-06-25 09:23:03.494054
# Unit test for function min
def test_min():
    assert min([5, 2, 1]) == 1
    assert min([{'a': 5}, {'a': 3}, {'a': 2}], attribute='a') == {'a': 2}
    assert min([1, 2, 3], 8) == 1


# Generated at 2022-06-25 09:23:07.537091
# Unit test for function max
def test_max():
    assert max([1,2,3,4,5]) == 5
    assert max([1,2,3,4,5], default=0) == 5
    assert max([1,2,3,4,5], default=6) == 5
    assert max([1,2,3,4,5], default=5) == 5


# Generated at 2022-06-25 09:23:25.031221
# Unit test for function min
def test_min():
    assert min([2, 3, 4, 5]) == 2
    assert min([3, 4, 5]) == 3
    assert min([2, 3, 5]) == 2
    assert min([3, 5]) == 3
    assert min([5]) == 5

## Unit test for function max

# Generated at 2022-06-25 09:23:29.044145
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 1, 2, 3], case_sensitive=None) == [1, 2, 3]
    # Can't use lazy objects (Jinja2 will complain)
    assert unique([1, 2, 1, 2, 3], attribute='test') == [1, 2, 3]



# Generated at 2022-06-25 09:23:38.216423
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_input_size = human_to_bytes('100MB')
    assert (test_input_size == 100000000), "Test failed, Expected: 100000000, Actual: %s" % to_native(test_input_size)
    test_input_size = human_to_bytes('1GB')
    assert (test_input_size == 1000000000), "Test failed, Expected: 1000000000, Actual: %s" % to_native(test_input_size)
    test_input_size = human_to_bytes('500TB')
    assert (test_input_size == 5000000000000), "Test failed, Expected: 5000000000000, Actual: %s" % to_native(test_input_size)
    test_input_size = human_to_bytes('1e1')

# Generated at 2022-06-25 09:23:44.776598
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min(['a', 'b', 'c']) == 'a'
    assert min(1, 2, 3) == 1
    assert min('a', 'b', 'c') == 'a'
    assert min(['a', 'b', 1, 'c']) == 1
    assert min([1, [2, 'b'], 'a']) == [2, 'b']
    assert min([]) is None
    try:
        min([1, 'a'])
        assert False, "Should throw exception"
    except AnsibleFilterError:
        pass


# Generated at 2022-06-25 09:23:47.700723
# Unit test for function min
def test_min():
    assert min([0, 1, 2]) == 0
    assert min([0, 1, 2], [1, 2, 3]) == [0, 1, 2]


# Generated at 2022-06-25 09:23:50.803029
# Unit test for function human_readable
def test_human_readable():
    size = 2048
    isbits = False
    unit = 'B'
    assert human_readable(size, isbits, unit) == '2.0KB'


# Generated at 2022-06-25 09:24:00.475083
# Unit test for function unique
def test_unique():
    '''
    Test:
    - unique is able to handle hashable objects
    - unique is able to handle unhashable objects
    - unique is able to handle unhashable objects with case_sensitive set
    '''

    assert unique([1, 2, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 2, 3, 4, 5], case_sensitive=False) == [1, 2, 3, 4, 5]

    assert unique([(1, 2), (3, 4), (1, 2), (5, 6)]) == [(1, 2), (3, 4), (5, 6)]

# Generated at 2022-06-25 09:24:07.446437
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1
    assert min([[1, 2, 3], [1, 2, 4], [1, 2, 5]]) == [1, 2, 3]
    assert min(['abc', 'xyz']) == 'abc'
    assert min([1, 2, 3], key=lambda x: -x) == 3
    assert min('abc', default='x') == 'a'
    assert min([], default='x') == 'x'
    assert min([], default='x', key=lambda x: -ord(x)) == 'x'
    assert min('', default='x') == 'x'
    assert min('', default='x', key=lambda x: -ord(x)) == 'x'
    assert min([1], default=None) == 1

# Generated at 2022-06-25 09:24:11.523616
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], 2) == 3
    assert max({1: 2, 2: 3, 3: 4}) == 4
    assert max({1: 2, 2: 3, 3: 4}, 3) == 4
    assert max([1, 2, 3], 2, 3) == 3
    assert max({1: 2, 2: 3, 3: 4}, 3, 4) == 4


# Generated at 2022-06-25 09:24:18.986790
# Unit test for function min
def test_min():
    # Input parameters
    a = { 2, 3, 5, 7, 11, 13 }
    b = { 2, 3, 5, 7, 11, 13 }
    # Expected result
    expected_result = 2

    assert min(a) == expected_result, "Expected result is " + expected_result
    assert min(a,b) == expected_result, "Expected result is " + expected_result


# Generated at 2022-06-25 09:24:50.203457
# Unit test for function min
def test_min():
    if min([2, 3, 1]) != 1:
        raise Exception('min([2, 3, 1]) != 1')
    if min([2, 1, 3]) != 1:
        raise Exception('min([2, 1, 3]) != 1')


# Generated at 2022-06-25 09:24:54.141320
# Unit test for function max
def test_max():
    assert max(None, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == 9
    assert max(None, [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]) == 9
    try:
        max(None, [5, 'a', True])
        assert False, 'Expected AnsibleFilterTypeError'
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-25 09:24:59.481675
# Unit test for function max
def test_max():
    # Make sure we get 100 from max
    assert(max([10, 20, 50, 100, 2]) == 100)

    # Make sure we get 64 from max
    assert(max([10, "20", 50, "64", 2]) == 64)

    # Make sure we get 67 from max
    assert(max([10, "20", 50, "64", 2], key=len) == 67)


# Generated at 2022-06-25 09:25:01.558889
# Unit test for function human_readable
def test_human_readable():
    result = human_readable(10240)
    assert result == "10 KB"


# Generated at 2022-06-25 09:25:06.209115
# Unit test for function max
def test_max():
    v = [4, 11, 5, 0, -1, 5, 2]
    assert max(v) == 11

# Generated at 2022-06-25 09:25:10.143975
# Unit test for function min
def test_min():

    assert min( [10, 30, 20] ) == 10
    assert min( [10, 20, 30] ) == 10
    assert min( [30, 20, 10] ) == 10
    assert min( [10, 30] ) == 10
    assert min( [30, 10] ) == 10


# Generated at 2022-06-25 09:25:15.315921
# Unit test for function min
def test_min():
    assert min([1, 2, 3], [2, 3, 4]) == [1, 2, 3]
    assert min([1, 2, 3], [2, 3, 4], key=lambda x: x * 2) == [2, 3, 4]
    assert min([1, 2, 3], [2, 3, 4], default=90) == [1, 2, 3]
    assert min([1, 2, 3], [2, 3, 4], key=lambda x: x * 2, default=90) == [2, 3, 4]


# Generated at 2022-06-25 09:25:26.042628
# Unit test for function min
def test_min():

    float_0 = -150.077239
    float_1 = -639.726
    float_2 = -149.22
    float_3 = -9.002745
    float_4 = -108.5334
    float_5 = -130.8114
    float_6 = -161.2783
    float_7 = -711.43
    float_8 = -885.29
    float_9 = -186.4589
    float_10 = -687.2966
    float_11 = -208.0893
    float_12 = -521.135
    float_13 = -749.57
    float_14 = -842.09
    float_15 = -251.7441
    float_16 = -56.797
    float_17 = -818.1156


# Generated at 2022-06-25 09:25:30.575271
# Unit test for function min
def test_min():
    assert min([3,3,3,3,3]) == 3
    assert min([1,2,3,4,5]) == 1
    assert min([5,4,3,2,1]) == 1
    assert min([1,1,2,2,3]) == 1

# Generated at 2022-06-25 09:25:42.130166
# Unit test for function max
def test_max():
    assert max([1, 2, 1, 3, 2, 1, 2, 3, 2, 1]) == 3
    assert max([1, 2, 1, 3, 2, 1, 2, 3, -2, 1]) == 3
    assert max(["hello", "world", "hello", "ansible", "ansible"]) == "world"
    assert max(["hello", "world", "hello", "ansible"]) == "world"
    assert max(["hello", "world", "hello", "ansible", 2]) == 2
    assert max(["hello", "world", "hello", "ansible", (1, 2, 3)]) == (1, 2, 3)
    assert max(["hello", "world", "hello", "ansible", (1, 2, 3), 2]) == (1, 2, 3)

# Unit

# Generated at 2022-06-25 09:26:42.840164
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([15, 3, 5]) == 3
    assert min([-5, -1, -10]) == -10
    assert min([0, -1, -10, 5]) == -10
    assert min([-5, -1, -10], -100) == -100
    assert min([-5, -1, -10], key=abs) == -1
    assert min(5, 4, 3, 2, 1) == 1
    assert min([[1, 2], [3, 4]], key=sum) == [1, 2]
    assert min([{'a': 1, 'b': 2}, {'a': 3}], key=lambda item: item['a']) == {'a': 1, 'b': 2}

# Generated at 2022-06-25 09:26:45.063301
# Unit test for function max
def test_max():
    n = max([1, 2, 3])
    assert n == 3

    n = max([1, 2, 3], key=lambda x: -x)
    assert n == 1



# Generated at 2022-06-25 09:26:47.502925
# Unit test for function human_to_bytes
def test_human_to_bytes():
    bytes_0 = human_to_bytes('1 KiB')
    bytes_1 = human_to_bytes('1/1024KiB')
    bytes_2 = human_to_bytes('1 MiB')


# Generated at 2022-06-25 09:26:56.166168
# Unit test for function human_readable
def test_human_readable():
    # Test for function human_readable
    # Test for function human_readable
    # Test for function human_readable
    assert human_readable(123.0, False, 'B') == '123.00 B'
    assert human_readable(123.0, False, 'KiB') == '0.12 KiB'
    assert human_readable(123.0, False, 'MiB') == '0.00 MiB'
    assert human_readable(123.0, False, 'GiB') == '0.00 GiB'
    assert human_readable(123.0, False, 'TiB') == '0.00 TiB'
    assert human_readable(123.0, False, 'PiB') == '0.00 PiB'

# Generated at 2022-06-25 09:26:58.954714
# Unit test for function min
def test_min():
    x = [10, 20, 30, 40]
    y = [20, 10, 30, 40]
    z = [40, 10, 20, 30]
    assert(min(x, y, z) == 10)



# Generated at 2022-06-25 09:27:04.200221
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1G') == 1024**3
    assert human_to_bytes('1T') == 1024**4
    assert human_to_bytes('1P') == 1024**5
    assert human_to_bytes('1E') == 1024**6
    assert human_to_bytes('1Z') == 1024**7
    assert human_to_bytes('1Y') == 1024**8


# Generated at 2022-06-25 09:27:15.070133
# Unit test for function unique

# Generated at 2022-06-25 09:27:16.659721
# Unit test for function min
def test_min():
    assert min([6,2,6,2]) == 2


# Generated at 2022-06-25 09:27:23.949474
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([-1, -3, -2]) == -1
    assert max([-3, -2, -1]) == -1
    assert max([-1.0, -2.0, -3.0]) == -1.0
    assert max([-1.0, -3.0, -2.0]) == -1.0
    assert max([-3.0, -2.0, -1.0]) == -1.0
    assert max([1.0, 2.0, 3.0]) == 3.0

# Generated at 2022-06-25 09:27:35.352072
# Unit test for function max
def test_max():
    float_0 = -150.077239
    float_1 = 2.3
    float_2 = 1.0
    float_3 = -1.0
    float_4 = 0.5
    string_0 = 'ansible'
    string_1 = 'bcoca'
    string_2 = 'brian conrad'
    string_3 = 'bcoca'
    string_4 = 'devel'
    string_5 = 'devel'
    string_6 = 'devel'
    string_7 = 'devel'
    var_0 = max([float_0, float_1, float_2, float_3, float_4])
    var_1 = max([string_0, string_1, string_2, string_3, string_4, string_5, string_6, string_7])


# Generated at 2022-06-25 09:29:39.015961
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('10', unit='B') == '10.0 bytes'
    assert human_readable('10', unit='B', isbits=True) == '80.0 bits'
    assert human_readable('10.5', unit='B') == '10.5 bytes'
    assert human_readable('10.5', unit='B', isbits=True) == '84.0 bits'
    assert human_readable('10.5', unit='B', isbits=True) == '84.0 bits'
    assert human_readable('1000.5', unit='B') == '1000.5 bytes'
    assert human_readable('1000.5', unit='B', isbits=True) == '8000.1 bits'
    assert human_readable('1000.5KiB') == '1.0 KiB'

# Generated at 2022-06-25 09:29:46.095034
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(1024) == 1048576
    assert human_to_bytes('1048576') == 1048576
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('2MB') == 1048576 * 2
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1.4TB') == 1490116119.2
    assert human_to_bytes('1.4TiB') == 1572864000
    assert human_to_bytes('1.4TB', default_unit='KB') == 14680064
    assert human_to_bytes('2.0GB') == 2147483648
    assert human_to_bytes('2.0GiB') == 2147483648

# Generated at 2022-06-25 09:29:46.982876
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1


# Generated at 2022-06-25 09:29:55.213337
# Unit test for function min
def test_min():
    assert min([3,2,1]) == 1
    assert min([3,2,1],1) == 1
    assert min([3,2,1],2) == 2
    assert min([3,2,1],3) == 3
    assert min([3,2,1],4) == 3
    assert min([3,2,1],-1) == 1
    assert min([3,2,-1],-1) == -1
    assert min(3,4) == 3
    assert min(1.0,1.1) == 1.0
    assert min(1.2,1.1) == 1.1
    assert min(1,1.1) == 1
    assert min(1.1,1) == 1
    assert min([-1,-1.1]) == -1.1