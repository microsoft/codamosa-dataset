

# Generated at 2022-06-25 09:20:03.289114
# Unit test for function min
def test_min():
    test_list = [1, 4, 3, 2, 0, 5]
    assert min(test_list) == 0


# Generated at 2022-06-25 09:20:06.061648
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10,2) == 3.321928094887362
    assert logarithm(23,10) == 1.3617278360175928
    assert logarithm(100,100) == 1.0


# Generated at 2022-06-25 09:20:08.334200
# Unit test for function min
def test_min():
    ''' Unit test for function min '''
    filter_module_2 = FilterModule()
    var_2 = filter_filters()
    min_0 = var_2['min']
    min_0(None, None)


# Generated at 2022-06-25 09:20:11.574559
# Unit test for function min
def test_min():
    assert min([1,2,3,4],key=abs) == 1
    assert min([-1,-2,3,4]) == -2


# Generated at 2022-06-25 09:20:22.813876
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('2.2k') == 2200
    assert human_to_bytes('2.2k', 'b') == 2200
    assert human_to_bytes('2.2k', 'bits') == 2200
    assert human_to_bytes('2.2k', 'B') == 2200
    assert human_to_bytes('2.2k', 'bits', True) == 2200
    assert human_to_bytes('2.2k', 'B', True) == 2200
    assert human_to_bytes('2.2k', 'b', True) == 17600

    assert human_to_bytes('2.2kb') == 2200
    assert human_to_bytes('2.2kB') == 2200
    assert human_to_bytes('2.2kb', 'b') == 2200

# Generated at 2022-06-25 09:20:25.974035
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(27,3) > 3
    assert logarithm(64,2) == 6
    assert logarithm(math.exp(2)) == 2


# Generated at 2022-06-25 09:20:27.341489
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-25 09:20:32.979596
# Unit test for function symmetric_difference
def test_symmetric_difference():
    var_0 = [1, 2, 3, 4]
    var_1 = [4, 5, 6, 7]
    var_2 = symmetric_difference(var_0, var_1)
    assert isinstance(var_2, list)
    assert var_2 == [1, 2, 3, 5, 6, 7]
    assert isinstance(var_2[0], int)


# Generated at 2022-06-25 09:20:38.073366
# Unit test for function max
def test_max():
    assert max([1]) == 1
    assert max([1, 5, 3, 8, 2]) == 8
    assert max(['foo', 'bar']) == 'foo'
    assert max(['foo', 'bar'], key=len) == 'bar'
    assert max((), default=5) == 5



# Generated at 2022-06-25 09:20:44.615458
# Unit test for function min
def test_min():
    assert min((1, 2)) == 1
    assert min((2, 1)) == 1
    assert min((2, 1, 3)) == 1
    assert min(([1], [2], [3])) == [1]
    assert min(([3], [2], [1])) == [1]
    assert min((["b"], ["a"])) == ["a"]
    assert min(({"a": "b"}, {"c": "d"})) == {"a": "b"}


# Generated at 2022-06-25 09:20:56.838774
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    dict1 = {
        'item1': {
            'key1': 1,
            'key2': 2,
            'key3': 3,
        },
        'item2': {
            'key1': 11,
            'key2': 22,
            'key3': 33,
        }
     }
    dict2 = [
        {
            'key1': 1,
            'key2': 2,
            'key3': 3,
        },
        {
            'key1': 11,
            'key2': 22,
            'key3': 33,
        }
     ]


# Generated at 2022-06-25 09:21:01.195868
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    arg1 = filter_module.filters()['max']([1,2,3])
    arg2 = filter_module.filters()['max']([1,2,3,6,2])
    arg3 = filter_module.filters()['max'](["aaa","bbb","ccc"])
    assert arg1 == 3
    assert arg2 == 6
    assert arg3 == 'ccc'


# Generated at 2022-06-25 09:21:06.349627
# Unit test for function human_readable
def test_human_readable():
    test_value = 1048576
    filter_module_0 = FilterModule()
    human_readable_0 = filter_module_0.filters()['human_readable']
    human_readable_res = human_readable_0(test_value)
    assert human_readable_res == "1.00 MB"


# Generated at 2022-06-25 09:21:17.045032
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()

    # Case 0: List of dicts
    data_0 = [
        {
            "key0": "value00",
            "key1": "value01",
            "key2": "value02"
        },
        {
            "key0": "value10",
            "key1": "value11",
            "key2": "value12"
        }
    ]
    key_0 = "key1"
    new_obj_0 = filter_module_0.filters()['rekey_on_member'](data_0, key_0, duplicates='overwrite')
    assert len(new_obj_0) == 2
    assert "value01" in new_obj_0
    assert "value11" in new_obj_0


    # Case 1: D

# Generated at 2022-06-25 09:21:19.858940
# Unit test for function max
def test_max():
    print("Testing max function")
    module = FilterModule()
    value = module.filters()['max'](1, 2, 3)
    try:
        assert value == 3
    except AssertionError:
        print("max returned %s, expected %s" % (value, 3))
        return 1
    return 0


# Generated at 2022-06-25 09:21:24.252760
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    result_0 = filter_module_0.filters().get('max')([1, 2, 3, 4])
    # Test that the result is correct
    assert result_0 == 4, 'Test that the result is correct'


# Generated at 2022-06-25 09:21:31.267538
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_1 = FilterModule()
    human_to_bytes = filter_module_1.filters()['human_to_bytes']

    assert human_to_bytes('10.1M') == 10485760
    assert human_to_bytes('10.2M', 'M') == 10485760
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('0M') == 0
    assert human_to_bytes('10.2K') == 10240
    assert human_to_bytes('10.2K', 'K') == 10240
    assert human_to_bytes('10K') == 10240
    assert human_to_bytes('0K') == 0
    assert human_to_bytes('10.1G') == 10737418240
    assert human_to_bytes

# Generated at 2022-06-25 09:21:35.127689
# Unit test for function max
def test_max():
    data = [1, 2, 1000, 43, 0]

    max_obj = FilterModule()
    max_val = max_obj.filters()['max'](data)
    if max_val == 1000:
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-25 09:21:38.035609
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([4, 5, 6, 7, 8]) == 8, 'Should return the maximum value in a list.'



# Generated at 2022-06-25 09:21:49.537133
# Unit test for function rekey_on_member
def test_rekey_on_member():
    l0 = [{'x': 7, 'y': 3, 'z': 4}, {'x': 7, 'y': 5, 'z': 6}]
    l1 = [{'x': 7, 'y': 3, 'z': 4}, {'x': 2, 'y': 5, 'z': 6}]
    l2 = [{'x': 7, 'y': 3, 'z': 4}, {'x': 2, 'y': 5, 'z': 6}, {'x': 2, 'y': 5, 'z': 6}]
    l3 = [{'x': 7, 'y': 3}, {'x': 7, 'y': 5}]
    
    d0 = {'x': 7, 'y': 3, 'z': 4}

# Generated at 2022-06-25 09:22:03.521271
# Unit test for function rekey_on_member

# Generated at 2022-06-25 09:22:15.499436
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    in_data = [{'a': '1', 'b': '2'}, {'a': '2', 'b': '2'}]
    out_data = {'1': {'a': '1', 'b': '2'}, '2': {'a': '2', 'b': '2'}}
    assert filter_module_0.filters()['rekey_on_member'](in_data, 'a') == out_data
    assert filter_module_0.filters()['rekey_on_member'](in_data, 'b') == out_data
    assert filter_module_0.filters()['rekey_on_member'](in_data, 'c') == None

# Generated at 2022-06-25 09:22:18.902015
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(16, 4) == 2
    assert inversepower(4, 16) == 0.25
    assert inversepower(65536, 2) == 256
    assert inversepower(math.pi, math.e) == 0.7328054958509717


# Generated at 2022-06-25 09:22:25.537740
# Unit test for function min
def test_min():
    # init
    filter_module = FilterModule()
    # test
    assert filter_module.filters()['min']([1, 2, 3]) == 1
    assert filter_module.filters()['min']([1, 2, 3], attribute="data") == 1
    assert filter_module.filters()['min']([1, 2, 3], attribute="data", default=0) == 1
    assert filter_module.filters()['min']([1, 2, 3], attribute="data", default=2) == 1
    assert filter_module.filters()['min']([], attribute="data", default=2) == 2


# Generated at 2022-06-25 09:22:30.582302
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    result = max("abcd")
    assert result == "d"
    result = max("a1c3")
    assert result == "c"
    result = max("a1b3", "b5d3")
    assert result == "d"
    result = max([1,2,4,5])
    assert result == 5
    result = max({'a':1, 'b':2, 'c':4, 'd':5})
    assert result == ('d', 5)
    result = max({'a':1, 'b':2, 'c':4, 'd':5}, key=lambda x: x[1])
    assert result == ('d', 5)

# Generated at 2022-06-25 09:22:33.987470
# Unit test for function max
def test_max():
    assert FilterModule().filters()['max']([1, 2, 3]) == 3
    assert FilterModule().filters()['max'](1, 2, 3) == 3
    assert FilterModule().filters()['max'](['a', 'b', 'c']) == 'c'
    assert FilterModule().filters()['max']([1, 'b', 3]) == 3


# Generated at 2022-06-25 09:22:42.114025
# Unit test for function human_readable
def test_human_readable():

    display = Display()
    # Tests for megabytes
    assert formatters.bytes_to_human(1, isbits=False, unit=None) == '1 B'
    display.display('1MB is %s' % formatters.bytes_to_human(1000000, isbits=False, unit=None))
    display.display('1MB is %s' % formatters.bytes_to_human(1000000, isbits=False, unit='Mb'))
    display.display('1MB is %s' % formatters.bytes_to_human(1000000, isbits=False, unit='B'))

    # Tests for gigabytes
    display.display('1GB is %s' % formatters.bytes_to_human(1000000000, isbits=False, unit=None))

# Generated at 2022-06-25 09:22:44.806624
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([1, 2, 3]) == 3


# Generated at 2022-06-25 09:22:50.138342
# Unit test for function inversepower
def test_inversepower():
    filter_module = FilterModule()
    assert inversepower(9) == 3
    assert inversepower(81, 4) == 3
    assert inversepower(3, 2) == 3


# Generated at 2022-06-25 09:22:56.869378
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    min = filter_module_0.filters()['min']
    data = [10,43,2,13,45]
    data_0 = [99,2,3,4,5]
    data_1 = [3,4,5,6,7,1,2]
    data_2 = [1,2,2,2,2]
    data_3 = [1,2,2,2,2,2,2]

    assert min(data) == 2
    assert min(data_0) == data_0[1]
    assert min(data_1) == data_1[0]
    assert min(data_2) == 1
    assert min(data_3) == 1



# Generated at 2022-06-25 09:23:10.145046
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    input = [1, 5, 2, 3, 4,]
    assert filter_module_0.filters()['min'](input) == 1



# Generated at 2022-06-25 09:23:17.451885
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    answer = [3, 5]
    test_input = [3, 7, 5, 1]
    assert filter_module_0.filters()['min'](test_input) == answer


# Generated at 2022-06-25 09:23:27.870558
# Unit test for function rekey_on_member
def test_rekey_on_member():
    test_rekey_on_member_0 = FilterModule()
    test_rekey_on_member_0.filters()['rekey_on_member']({'foo': {'bar': 1, 'baz': 2, 'qux': 3}, 'bar': {'bar': 4, 'baz': 5, 'qux': 6}}, 'bar')
    test_rekey_on_member_0.filters()['rekey_on_member']({'foo': {'bar': 1, 'baz': 2, 'qux': 3}, 'bar': {'bar': 4, 'baz': 5, 'qux': 6}}, 'baz')

# Generated at 2022-06-25 09:23:29.773581
# Unit test for function min
def test_min():
    min_filter = min([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert min_filter == 0



# Generated at 2022-06-25 09:23:38.828875
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    assert filter_module.filters()['rekey_on_member']([{'key': 'bob'}, {'key': 'rob'}], 'key') == {'bob': {'key': 'bob'}, 'rob': {'key': 'rob'}}
    assert filter_module.filters()['rekey_on_member']([{'key': 'bob'}, {'key': 'rob'}], 'key', 'overwrite') == {'bob': {'key': 'bob'}, 'rob': {'key': 'rob'}}
    assert filter_module.filters()['rekey_on_member']([{'key': 'bob'}, {'key': 'bob'}], 'key', 'error') == 0
    assert filter_module

# Generated at 2022-06-25 09:23:45.954732
# Unit test for function min
def test_min():

    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()

    assert filters_0['min']([1, 2, 3]) == 1
    assert filters_0['min']([1, 2, -3]) == -3
    assert filters_0['min']([1, 2, "3"]) == 1
    # Test args
    assert filters_0['min']([1, 2, 3], key=lambda x: -x) == 3


# Generated at 2022-06-25 09:23:50.197666
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    max_result = filter_module_max.filters()['max']([1, 2, 3])
    if max_result != 3:
        raise AssertionError()


# Generated at 2022-06-25 09:24:00.164259
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    assert filter_module_max.filters()['max']([1,2,3]) == 3
    assert filter_module_max.filters()['max']([1,2,'a']) == 2
    assert filter_module_max.filters()['max']({'a':1, 'b':2, 'c':3}) == 3
    assert filter_module_max.filters()['max']({'a':3, 'b':2, 'c':1}) == 3
    assert filter_module_max.filters()['max']({'a':3, 'b':2, 'c':'a'}) == 3

# Generated at 2022-06-25 09:24:04.582843
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 3, 2]) == 3
    assert max([1.0, 2.0, 3.0]) == 3.0
    assert max([3.0, 2.0, 1.0]) == 3.0
    assert max([1.0, 3.0, 2.0]) == 3.0


# Generated at 2022-06-25 09:24:10.902571
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()

    # Test 1 - min value is first in sequence
    a = [1,2,3,4,5]
    b = filter_module_1.filters()['min'](a)
    assert b == 1

    # Test 2 - min value is last in sequence
    a = [5,4,3,2,1]
    b = filter_module_1.filters()['min'](a)
    assert b == 1

    # Test 3 - min value is in the middle of sequence
    a = [5,4,1,2,3]
    b = filter_module_1.filters()['min'](a)
    assert b == 1


# Generated at 2022-06-25 09:24:40.711637
# Unit test for function human_readable

# Generated at 2022-06-25 09:24:43.459529
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max'](range(1, 5)) == 4


# Generated at 2022-06-25 09:24:53.307389
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()

    test_list = [{'name': 'foo', 'age': 30}, {'name': 'bar', 'age': 30}]
    new_dict = filter_module.filters()['rekey_on_member'](test_list, 'name')

    assert isinstance(new_dict, dict)
    assert new_dict['foo'] == {'name': 'foo', 'age': 30}
    assert new_dict['bar'] == {'name': 'bar', 'age': 30}

    # Test duplicate keys detected and raise correct error

# Generated at 2022-06-25 09:25:01.940079
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # object of type dict
    filter_module = FilterModule()
    _rekey_on_member = filter_module.filters()['rekey_on_member']

    # case 0, simple rekey
    data = [{'key':'foo', 'value':'bar'}, {'key':'baz', 'value':'qux'}]
    key = 'key'
    rekeyed_data = _rekey_on_member(data, key)
    assert rekeyed_data == {'foo': {'key': 'foo', 'value': 'bar'}, 'baz': {'key': 'baz', 'value': 'qux'}}

    # case 1, simple rekey - duplicates

# Generated at 2022-06-25 09:25:06.331426
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    filter_function = filter_module.filters()['min']
    assert filter_function([1,2,3]) == 1
    assert filter_function([-43, 7, 8, 900, -5]) == -43
    try:
        filter_function([None, 7, 8, 900])
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 09:25:10.254474
# Unit test for function min
def test_min():
    min = FilterModule().filters()['min']
    assert min(range(10)) == 0
    assert min(set(range(10))) == 0
    assert min([[10], [-10]]) == [-10]
    assert min(['foo', 'bar']) == 'bar'
# Testing on list

# Generated at 2022-06-25 09:25:20.859611
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1, 2, 3], 4) == 1
    assert filter_module_0.filters()['min']([4, 1, 2, 3]) == 1
    assert filter_module_0.filters()['min']([]) == 0
    assert filter_module_0.filters()['min']([1]) == 1
    assert filter_module_0.filters()['min']([[1, 2], [3, 4]]) == [1, 2]
    assert filter_module_0.filters()['min']([1, 2], key=lambda x: x**2) == 1


# Generated at 2022-06-25 09:25:22.360111
# Unit test for function max
def test_max():
    assert 15 == max([1, 15, 5])


# Generated at 2022-06-25 09:25:28.938506
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters().get('min')([1, 2, 3]) == 1



# Generated at 2022-06-25 09:25:32.338765
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    filters_max = filter_module_1.filters()
    max_val = filters_max['max']([1, -2, 3, -4])
    assert max_val == 3


# Generated at 2022-06-25 09:26:21.095713
# Unit test for function unique
def test_unique():
    filter_module_unique = FilterModule()
    unique_filter = filter_module_unique.filters()['unique']

    # TypeError raises when input is not a list
    try:
        unique_filter(None)
    except AnsibleFilterTypeError as e:
        assert "| unique filter expects a list" in to_text(e)
    else:
        assert False, "AnsibleFilterTypeError not raised"

    # successful run
    x = [1, 2, 3, 4]
    y = [2, 2, 3, 2]
    z = [1, 2]
    assert unique_filter(x) == x
    assert unique_filter(y) == [2, 3]
    assert list(unique_filter([x, y, z])) == [x, [2, 3], z]


# Generated at 2022-06-25 09:26:25.269701
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([1, 2, 3, 4]) == 4

    # Test for empty input
    assert filter_module_1.filters()['max']([]) is None

# Integration test

# Generated at 2022-06-25 09:26:35.295446
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # Create a dict of dicts
    dict_data = {
        'key1': {
            'key_a': 'value1_a',
            'key_b': 'value1_b',
            'key_c': 'value1_c'
        },
        'key2': {
            'key_a': 'value2_a',
            'key_b': 'value2_b',
            'key_c': 'value2_c'
        }
    }

    # Create a list of dicts

# Generated at 2022-06-25 09:26:36.619191
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3


# Generated at 2022-06-25 09:26:45.005838
# Unit test for function min
def test_min():
    # test for a = [1, 2, 3, 4, 5]
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([1, 2, 3, 4, 5], 2, 3) == 1
    assert min([1, 2, 3, 4, 5], 3) == 1
    assert min([1, 2, 3, 4, 5], 4) == 1
    assert min([1, 2, 3, 4, 5], 5) == 1

    # test for a = [4, 5, 6, 7, 8, 10]
    assert min([4, 5, 6, 7, 8, 10]) == 4
    assert min([4, 5, 6, 7, 8, 10], 2, 3) == 4
    assert min([4, 5, 6, 7, 8, 10], 3) == 4
    assert min

# Generated at 2022-06-25 09:26:51.272410
# Unit test for function unique
def test_unique():
    filter_module_unique = FilterModule()
    unique = filter_module_unique.filters()['unique']

    # test that unique returns a filtered list with no duplicates
    assert [1, 2, 3, 4, 5] == unique([1, 2, 1, 3, 4, 5])

    # test that unique returns a filtered list with no duplicates and preserves order
    assert [1, 2, 3, 4, 5] == unique([1, 2, 1, 3, 4, 5, 3, 2, 4, 1])

    # test that unique does not impact a list with no duplicates
    assert [1, 2, 3, 4] == unique([1, 2, 3, 4])

    # test that unique returns a filtered list when all values are duplicates
    assert [1] == unique([1, 1, 1, 1, 1])

#

# Generated at 2022-06-25 09:26:57.667345
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    max_results = []
    max_results.append(filter_module_0.filters()['max'](range(0, 10)))
    max_results.append(filter_module_0.filters()['max']({
        'a': 9,
        'b': 0,
        'c': 10
    }))
    assert max_results == [9, 10]

# Generated at 2022-06-25 09:27:03.688929
# Unit test for function min
def test_min():

    assert min([5, 8, 1, 6, 3]) == 1
    assert min(5, 8, 1, 6, 3) == 1
    assert min([5, 6, 3], [8, 2, 1]) == [5, 2, 1]
    assert min([5, 8, 1], key=lambda x: -x) == 8
    assert min(5, 8, 1, key=lambda x: -x) == 8
    assert min([5, 8, 1, 6, 3], [8, 2, 1], key=lambda x: -x) == [5, 8, 1]


# Generated at 2022-06-25 09:27:15.100586
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Create generic data
    data = [{"a": 1, "b": 2},
            {"a": 3, "b": 4},
            {"a": 5, "b": 6}]

    # Check that a normal rekey works on a list of dicts
    rekeyed_data = rekey_on_member(data, "a")
    assert rekeyed_data == {1: {"a": 1, "b": 2},
                            3: {"a": 3, "b": 4},
                            5: {"a": 5, "b": 6}}, "Failed to rekey a list of dicts"

    # Check that a rekey on a dict works

# Generated at 2022-06-25 09:27:23.162402
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    my_list = [
        {'id': 'a', 'value': 1},
        {'id': 'b', 'value': 2},
        {'id': 'c', 'value': 3},
        {'id': 'd', 'value': 4}
    ]

    assert filter_module_0.filters()['rekey_on_member'](my_list, 'id') == {'a': {'id': 'a', 'value': 1},
                                                                           'b': {'id': 'b', 'value': 2},
                                                                           'c': {'id': 'c', 'value': 3},
                                                                           'd': {'id': 'd', 'value': 4}}


# Generated at 2022-06-25 09:27:52.371987
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1, 2, 3, 4]) == 1
    assert filter_module_0.filters()['min']([3, 2, 1, 4]) == 1
    assert filter_module_0.filters()['min']([]) is None


# Generated at 2022-06-25 09:28:03.609662
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_1 = FilterModule()
    test_data = [
      {'id': 1, 'name': 'test1'},
      {'id': 2, 'name': 'test2'},
      {'id': 3, 'name': 'test3'}
    ]

    assert filter_module_1.filters()['rekey_on_member'](test_data, 'id') == \
        {'1': {'name': 'test1', 'id': 1},
         '2': {'name': 'test2', 'id': 2},
         '3': {'name': 'test3', 'id': 3}}


# Generated at 2022-06-25 09:28:07.159502
# Unit test for function max
def test_max():
    import pytest
    from jinja2 import Environment

    env_0 = Environment()
    env_0.filters['max'] = max
    assert env_0.from_string('{{ [2,8,6,4] | max }}').render() == '8'


# Generated at 2022-06-25 09:28:18.217467
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    filters = filter_module.filters()

    # one arg
    assert filters['min']([1, 2, 3]) == 1

    # two args
    assert filters['min']([1, 2, 3], [1, 2, 3]) == [1, 1, 1]

    # three args
    assert filters['min']([1, 2, 3], [1, 2, 3], [1, 2, 3]) == [1, 1, 1]

    # filter and keyword args
    assert filters['min']([1, 2, 3], 1, 2, 3) == [1, 1, 1]

    # filter and keyword args
    assert filters['min'](1, 2, 3, [1, 2, 3]) == [1, 1, 1]



# Generated at 2022-06-25 09:28:21.472737
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    assert filter_module.filters()['min']([1, 2, 3]) == 1



# Generated at 2022-06-25 09:28:23.427980
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert(max(filter_module_1.filters()['max']([1, 2, 3])) == 3)


# Generated at 2022-06-25 09:28:27.847679
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([1,2,3,4,5,6,7,8,9,10]) == 10
    assert filter_module_0.filters()['max']([5,5,5]) == 5


# Generated at 2022-06-25 09:28:35.529569
# Unit test for function unique
def test_unique():
    all = ['a', 'b', 'c', 'd', 'a', 'b']
    unique = ['a', 'b', 'c', 'd']
    assert filter_module_0.filters()['unique'](all) == unique


    strings_only = ['a', 'b', 'c', 'd', 'a', 'b']
    strings_only_unique = ['a', 'b', 'c', 'd']
    assert filter_module_0.filters()['unique'](strings_only) == strings_only_unique


    no_order = ['a', 'b', 'c', 'd', 'a', 'b']
    no_order_unique = ['a', 'b', 'c', 'd']
    assert filter_module_0.filters()['unique'](no_order) == no_order_unique

# Generated at 2022-06-25 09:28:42.698339
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()["min"]([21, 12, 33]) == min([21, 12, 33])
    assert filter_module_1.filters()["min"]([21, "ab", 33]) == min([21, "ab", 33])


# Generated at 2022-06-25 09:28:54.005313
# Unit test for function rekey_on_member
def test_rekey_on_member():

    filter_module_1 = FilterModule()

    # Test 1 - a dict of dicts

# Generated at 2022-06-25 09:29:25.218778
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    assert filter_module.filters()['max']([1, 2, 3, 4]) == 4
    assert filter_module.filters()['max']([-1, -2, -3, -4]) == -1
    assert filter_module.filters()['max']([1, 2, -4, -4, 5]) == 5
    assert filter_module.filters()['max']([1, 2, 2, 3, 2, 3, 2]) == 3
    assert filter_module.filters()['max']([], default=0) == 0
    assert filter_module.filters()['max']([], default=20) == 20


# Generated at 2022-06-25 09:29:33.845800
# Unit test for function human_to_bytes

# Generated at 2022-06-25 09:29:44.837350
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    min_1 = filter_module_0.filters()["min"]
    assert min_1([3, 1, 2]) == 1
    assert min_1({1: 'a', 2: 'a'}) == 1
    assert min_1(['a', 'b', 'c']) == 'a'
    assert min_1({'a': 1, 'b': 2}) == 'a'
    assert min_1([1, 2, 3]) == 1
    assert min_1(['a', 'b']) == 'a'
    assert min_1([]) == None
    assert min_1((1, 2, 3)) == 1
    assert min_1(('a', 'b', 'c')) == 'a'


# Generated at 2022-06-25 09:29:46.274053
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    min = filter_module_0.filters().get('min')
    assert min([0,10,2]) == 0


# Generated at 2022-06-25 09:29:47.647793
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    result = filter_module.filters()['max'](0,0,0)
    assert result == 0
