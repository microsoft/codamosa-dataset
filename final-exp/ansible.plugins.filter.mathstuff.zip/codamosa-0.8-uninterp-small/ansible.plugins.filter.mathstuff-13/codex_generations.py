

# Generated at 2022-06-25 09:20:04.558332
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # mock class for environment
    class Environment:
        def __init__(self):
            self.filters = {}
    # init environment
    env = Environment()
    
    # test case
    list_0 = [u'7g?', u'r\\[{', u'zT\\eAZ}', u'q\x18\x11\x0b\x00', u'\uf8c7?+\x16']

# Generated at 2022-06-25 09:20:15.050965
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:20:23.029202
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.1K') == 1123
    assert human_to_bytes('1.1') == 1123
    assert human_to_bytes('1.1M') == 11796481
    assert human_to_bytes('1.1T') == 1200596529201
    assert human_to_bytes('1.1G') == 1181116006
    assert human_to_bytes('-1.1G') == -1181116006
    assert human_to_bytes('-1.1G', default_unit='K') == -1181116006/1024
    assert human_to_bytes('1.1k') == 112

# Generated at 2022-06-25 09:20:24.674298
# Unit test for function min
def test_min():
    assert min([5, 6, 9, 1]) == 1


# Generated at 2022-06-25 09:20:33.587556
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    this_min = filter_module.filters()['min']

    # test that it throws an error if used with keyword params
    try:
        this_min([1, 2], dummy=True)
        assert False, "Should have thrown an error"
    except AnsibleFilterError as e:
        assert "supports keyword arguments" in str(e)

    assert this_min([1, 2]) == 1
    assert this_min([1, 2, 3]) == 1
    assert this_min([-1, -2, -3]) == -3
    assert this_min([1.1, 1.0, 0.0]) == 0.0
    assert this_min([-1.1, 1.0, 0.0]) == -1.1

# Generated at 2022-06-25 09:20:43.263357
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    iterable0 = ['CMZsI', '', '8TfWGk6']
    iterable1 = ['', '8TfWGk6', 'CMZsI']

    ans = [None, None, None]
    try:
        ans[0] = filter_module_0.filters()['min'](iterable0)
    except AnsibleFilterError:
        pass
    try:
        ans[1] = filter_module_0.filters()['min'](iterable1, key=None)
    except AnsibleFilterError:
        pass
    try:
        ans[2] = filter_module_0.filters()['min'](iterable1, key=None)
    except AnsibleFilterError:
        pass
    return ans


#

# Generated at 2022-06-25 09:20:54.484389
# Unit test for function unique
def test_unique():
    filter_module_1 = FilterModule()
    list_0 = [ to_text(x) for x in range(0, 10) ]
    assert filter_module_1.filters()['unique'](list_0) == [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ]
    list_1 = [ to_text(x) for x in range(0, 10) ] + [ '1', '2', '3', '4', '5' ]
    assert filter_module_1.filters()['unique'](list_1) == [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ]

# Generated at 2022-06-25 09:20:59.369802
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([-1, -2, -3, -4, -5]) == -5
    assert min({'a': 1, 'b': 2, 'c': 3}) == 1
    assert min(1, 2, 3, 4, 5) == 1
    assert min(-1, -2, -3, -4, -5) == -5
    assert min('abcde') == 'a'
    assert min({'a': 1, 'b': 2, 'c': 3}, key=lambda x: x[1]) == 'a'
    assert min({'a': 1, 'b': 2, 'c': 3}, key=lambda x: x[1], default=10) == 'a'

# Generated at 2022-06-25 09:21:06.585326
# Unit test for function unique
def test_unique():
    assert unique(['asdf', 'asdf', 'sdfa'], True) == ["asdf", "sdfa"]
    assert unique(['asdf', 'asdf', 'sdfa'], False) == ["asdf", "sdfa"]
    assert unique(['asdf', 'asdf', 'sdfa'], True, attribute='id') == ["asdf", "sdfa"]


# Generated at 2022-06-25 09:21:09.941296
# Unit test for function unique
def test_unique():
    str = 'The quick brown fox jumps over the lazy dog'
    filter_module_0 = FilterModule()


# Generated at 2022-06-25 09:21:18.708661
# Unit test for function max
def test_max():
    assert max((1, 2, 3)) == 3



# Generated at 2022-06-25 09:21:23.781570
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1, 2, 3]) == 1


# Generated at 2022-06-25 09:21:30.944960
# Unit test for function human_readable
def test_human_readable():
    filter_module_0 = FilterModule()
    filters_0 = filter_module_0.filters()
    human_readable_0 = filters_0['human_readable']

    # Sample test cases
    assert (human_readable_0(0) == '0.0')
    assert human_readable_0(0.123) == '123.0m'
    assert human_readable_0(0.1234) == '123.4m'
    assert human_readable_0(1024) == '1.0K'
    assert human_readable_0(2048) == '2.0K'
    assert human_readable_0(2048, True) == '2.1KiB'
    assert human_readable_0(2 ** 20) == '1.0M'

# Generated at 2022-06-25 09:21:33.797571
# Unit test for function human_readable
def test_human_readable():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['human_readable']('57000000') == '57 M'


# Generated at 2022-06-25 09:21:40.469205
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    filter_module_0._setup_template_class()

    # dict of dicts
    data = {
        'one': {'a': 1, 'b': 2},
        'two': {'a': 3, 'b': 4},
        'three': {'a': 5, 'b': 6},
    }
    key = 'a'
    rekeyed_dict = filter_module_0.filters()['rekey_on_member'](data, key)
    expected_dict = {
        1: {'a': 1, 'b': 2},
        3: {'a': 3, 'b': 4},
        5: {'a': 5, 'b': 6},
    }
    assert rekeyed_dict == expected_dict

    # list of dicts


# Generated at 2022-06-25 09:21:45.587694
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([3, 5, 2, 1, 6, 4]) == 1
    assert min([3, 5, 2, 1, 6, 4]) == 1


# Generated at 2022-06-25 09:21:53.176773
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    filters = filter_module.filters() 
    assert filters['max']([1,2,3,4,5]) == 5
    assert filters['max'](['cisco', 'network', 'to', 'code', 'is', 'amazing']) == 'to'
    assert filters['max']([2.54, 3.66, 7.89, 8.23]) == 8.23
    assert filters['max']([True, False]) is True



# Generated at 2022-06-25 09:21:58.774957
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()

    # Error for non-dict or non-list
    error_msg = "Type is not a valid list, set, or dict"
    non_dict = "{}"
    try:
        filter_module.filters()['rekey_on_member'](non_dict, 'key', 'error')
        assert False, "Expected AnsibleFilterTypeError exception."
    except AnsibleFilterTypeError as e:
        assert error_msg in to_native(e), "Expected {0}, got: {1}".format(error_msg, to_native(e))

    # Error for non-dict in list
    error_msg = "List item is not a valid dict"
    non_dict_list = [{'key': 'value'}, "not-a-dict"]

# Generated at 2022-06-25 09:22:05.159236
# Unit test for function unique
def test_unique():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['unique']([4, 3, 2, 1, 2, 3, 4]) == [4, 3, 2, 1]
    assert filter_module_1.filters()['unique']([{'key': '2'}, {'key': '1'}, {'key': '1'}, {'key': '2'}], attribute='key') == [{'key': '2'}, {'key': '1'}]


# Generated at 2022-06-25 09:22:19.193367
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.text import formatters

    old_display = display
    out = StringIO()
    display = Display(verbosity=2, stdout=out)
    filter_module = FilterModule()
    display = old_display

    filter_module.filters()['human_readable']("0")
    filter_module.filters()['human_readable']("0B")
    filter_module.filters()['human_readable']("0", True)
    filter_module.filters()['human_readable']("0B", True)
    filter_module.filters()['human_readable']("0", unit="B")

# Generated at 2022-06-25 09:22:40.628133
# Unit test for function min
def test_min():
    my_list = [3, 1, 4, 2, 5]
    my_tuple = (3, 1, 4, 2, 5)
    my_str = "3421"
    assert(min(my_list, attribute="rstrip") == 1)
    assert(min(my_str) == "1")
    assert(min(my_tuple, attribute="rstrip") == 1)
    assert(min(my_str) == "1")



# Generated at 2022-06-25 09:22:52.552135
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    assert filter_module.filters()['rekey_on_member']([
        { 'key': 'a', 'value': 1 },
        { 'key': 'b', 'value': 2 },
        { 'key': 'c', 'value': 3 },
    ], 'value') == { 'a': { 'key': 'a', 'value': 1 }, 'b': { 'key': 'b', 'value': 2 }, 'c': { 'key': 'c', 'value': 3 } }

# Generated at 2022-06-25 09:22:56.812733
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([43, 1, 3]) == 1
    assert min([]) is None
    assert min(['a']) == 'a'


# Generated at 2022-06-25 09:22:59.381206
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], key=lambda x: x * -1) == 1


# Generated at 2022-06-25 09:23:09.970571
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    template_min = filter_module.filters()['min']

    # Test 1D array
    data = [1, 5, 2, -1, 2, 5]
    assert template_min(None, data) == -1
    assert template_min(None, data, attribute='x') == -1
    assert template_min(None, data, attribute='x', case_sensitive=False) == -1

    # Test 1D array with mixed types
    data = [1, 'a', 'aa', 5]
    assert template_min(None, data) == 1
    assert template_min(None, data, attribute='x') == 1
    assert template_min(None, data, attribute='x', case_sensitive=False) == 1

    # Test 2D array

# Generated at 2022-06-25 09:23:19.248774
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['rekey_on_member']([{'name': 'test', 'key': 'test'}, {'name': 'test2', 'key': 'test2'}], 'key')
    assert(result == {'test': {'name': 'test', 'key': 'test'}, 'test2': {'name': 'test2', 'key': 'test2'}})

# Generated at 2022-06-25 09:23:28.968365
# Unit test for function human_readable
def test_human_readable():
    filter_module_1 = FilterModule()
    filter_module_1.filters()

    # Assert that the filter throws an AnsibleFilterError on an invalid
    # human readble value
    try:
        human_readable('blah', default_unit='blah')
    except AnsibleFilterError:
        pass
    else:
        raise AssertionError("Invalid human_readable value did not raise an AnsibleFilterError")

    # Assert that the filter returns the correct value for a human readable
    # string
    assert human_readable('100M') == 104857600
    assert human_readable('1024') == 1024
    assert human_readable('1TB') == 1099511627776
    assert human_readable('1K', isbits=True) == 128
    assert human_readable('1K', isbits=False) == 1024



# Generated at 2022-06-25 09:23:38.183110
# Unit test for function rekey_on_member
def test_rekey_on_member():
    test_object_0 = {
        "a": {
            "a": "a",
        },
        "b": {
            "b": "b",
        },
    }

    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['rekey_on_member'](test_object_0, 'a') == {
        "a": {
            "a": "a",
        },
    }
    assert filter_module_0.filters()['rekey_on_member'](test_object_0, 'b') == {
        "b": {
            "b": "b",
        },
    }


# Generated at 2022-06-25 09:23:40.956720
# Unit test for function unique
def test_unique():

    filter_module_0 = FilterModule()
    result_0 = filter_module_0.filters()['unique']([1, 2, 3, 2, 1])
    assert result_0 == [1, 2, 3]


# Generated at 2022-06-25 09:23:44.949459
# Unit test for function unique
def test_unique():
    filter_module = FilterModule();
    print(filter_module.filters()['unique']('test'))


# Generated at 2022-06-25 09:24:19.975218
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module_1 = FilterModule()
    set_a = [1, 2, 3, 4, 5]
    set_b = [6, 7, 3, 9, 7]
    result = filter_module_1.filters()["symmetric_difference"](set_a, set_b)
    expected_result = [1,2,4,5,6,7,9]
    assert result == expected_result


# Generated at 2022-06-25 09:24:23.511777
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    a = 1
    b = 2
    c = 3
    assert 3 == filter_module_0.filters()['max'](a, b, c)
    assert 2 == filter_module_0.filters()['min'](a, b, c)

#Unit test for function max

# Generated at 2022-06-25 09:24:27.844815
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    c = filter_module_0.filters()
    assert c['max']([4,6,2,6,7]) == 7
    assert c['max']([[4,6,2,6,7],
                     [4,6,2,6,7],
                     [4,6,2,6,7],
                     [4,6,2,6,7],
                     [4,6,2,6,7]]) == [4,6,2,6,7]



# Generated at 2022-06-25 09:24:29.675949
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module = FilterModule()
    assert symmetric_difference([1,2,3,4], [3,4,5,6]) == [1, 2, 5, 6]


# Generated at 2022-06-25 09:24:37.008335
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filters = FilterModule().filters()
    data = [{'name': 'fred', 'age': 42}, {'name': 'alice', 'age': 3}]

    # Rekey on a pre-existing key
    assert filters['rekey_on_member'](data, 'name') == {'fred': {'name': 'fred', 'age': 42}, 'alice': {'name': 'alice', 'age': 3}}

    # Rekey on a key that is the same as the new key
    assert filters['rekey_on_member'](data, 'name', 'name') == {'fred': {'name': 'fred', 'age': 42}, 'alice': {'name': 'alice', 'age': 3}}

    # Rekey on a key that doesn't exist

# Generated at 2022-06-25 09:24:43.053841
# Unit test for function min
def test_min():
    test_list = ['1','2', '3', '4']
    assert min(test_list) == '1'
    assert max(test_list) == '4'


# Generated at 2022-06-25 09:24:47.049483
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([1,2,3]) == 3



# Generated at 2022-06-25 09:24:50.788479
# Unit test for function logarithm
def test_logarithm():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters().get('log')(100,10) == 2
    assert filter_module_0.filters().get('log')(100) == 4.60517018599

# Generated at 2022-06-25 09:24:54.526946
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference(None, [1,2,3], [2,3,4]) == [1, 4]


# Generated at 2022-06-25 09:25:01.411242
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3]) == 1, 'Should be 1'
    assert filter_module_1.filters()['min']([3, 2, 1]) == 1, 'Should be 1'
    assert filter_module_1.filters()['min']([5]) == 5, 'Should be 5'
    assert filter_module_1.filters()['min']([100, 33, 42, 18, 2, -5, 1]) == -5, 'Should be -5'


# Generated at 2022-06-25 09:25:20.251620
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()

    for x in (4, 3, 2, 1):
        assert filter_module_max.filters()['max']([1, 2, 3, 4]) == x


# Generated at 2022-06-25 09:25:27.685646
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_cases = [
        ("10TB", (10737418240, 1024)),
        ("10tb", (109951162777600, 1000)),
        ("1G", (1073741824, 1024)),
        ("1g", (1073741824, 1024)),
        ("1M", (1048576, 1024)),
        ("1m", (1048576, 1024)),
        ("1K", (1024, 1024)),
        ("1k", (1000, 1000)),
        ("1B", (1, 1024)),
        ("1b", (1, 1000)),
    ]
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:25:30.443504
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    min_filter = filter_module.filters()['min']
    assert min_filter([1, 2, 3]) == 1


# Generated at 2022-06-25 09:25:33.159130
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([-10, 4, 6, 1]) == -10


# Generated at 2022-06-25 09:25:44.860945
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    filters = filter_module.filters()
    rekey_on_member = filters['rekey_on_member']

    # Create a dict of dicts, where the value of 'a' is the key
    l = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    assert rekey_on_member(l, 'a') == {1: {'a': 1, 'b': 2}, 2: {'a': 2, 'b': 3}}

    # Create a dict of dicts from a dict of dicts
    d = {0: {'a': 1, 'b': 2}, 1: {'a': 2, 'b': 3}}

# Generated at 2022-06-25 09:25:48.568888
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    test_values_0 = [random.uniform(0, 100) for r in xrange(10)]
    test_expected_0 = max(test_values_0)
    assert filter_module_0.filters()['max'](test_values_0) == test_expected_0


# Generated at 2022-06-25 09:25:56.875251
# Unit test for function rekey_on_member
def test_rekey_on_member():
    flt = FilterModule()
    myfilter = flt.filters()['rekey_on_member']

    # Test rekeying a dict on a key
    test_dict = {
        'a': {'item1': 'value1', 'item2': 'value2'},
        'b': {'item1': 'value3', 'item2': 'value4'},
        'c': {'item1': 'value5', 'item2': 'value6'},
    }


# Generated at 2022-06-25 09:25:59.815393
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    result_1 = filter_module_1.filters()['max']([1,2,3])
    assert result_1 == 3


# Generated at 2022-06-25 09:26:02.135683
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    max = filter_module_1.filters()['max']
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-25 09:26:09.814420
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    result_1 = filter_module_1.filters()['max'](range(10))
    result_2 = filter_module_1.filters()['max'](range(1, 11))
    assert result_1 == 9
    assert result_2 == 10


# Generated at 2022-06-25 09:26:34.807170
# Unit test for function min
def test_min():
    assert min([0, 1, 2]) == 0


# Generated at 2022-06-25 09:26:43.469229
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    a_list = [
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2},
        {'key': 'c', 'value': 3}
    ]
    b_list = [
        {'name': 'a', 'value': 1},
        {'name': 'b', 'value': 2},
        {'name': 'c', 'value': 3}
    ]
    a_dict = {
        '1': {'key': 'a', 'value': 1},
        '2': {'key': 'b', 'value': 2},
        '3': {'key': 'c', 'value': 3}
    }


# Generated at 2022-06-25 09:26:44.813121
# Unit test for function min
def test_min():
    assert min( [ 5, 3, 4, 1, 2 ] ) == 1


# Generated at 2022-06-25 09:26:51.356980
# Unit test for function unique
def test_unique():
    # test the following with no duplicate elements
    unique_list1 = [0, 1, 2, 3, 4, 5]
    unique_list2 = ['abc', 'def', 'ghi', 'jkl', 'mno']

    # test with both lists being the same
    assert unique_list1 == unique(unique_list1)
    assert unique_list2 == unique(unique_list2)

    # test with an empty list
    assert [] == unique([])

    # test the following with duplicate elements
    unique_list1_dup = [0, 1, 2, 3, 4, 5, 5, 4]
    unique_list2_dup = ['abc', 'def', 'ghi', 'jkl', 'mno', 'abc', 'mno']

    # this test will fail when called as: unique(unique_list1)

# Generated at 2022-06-25 09:26:55.210985
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3, 4]) == 1


# Generated at 2022-06-25 09:27:01.204513
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min([3,2,1]) == 1
    assert min(['a','b','c']) == 'a'
    assert min(['c','b','a']) == 'a'
    assert min([[1],[2],[3]]) == [1]
    assert min([[3],[2],[1]]) == [1]
    assert min([[[1]],[[2]],[[3]]]) == [[1]]
    assert min([[[3]],[[2]],[[1]]]) == [[1]]


# Generated at 2022-06-25 09:27:03.445629
# Unit test for function max
def test_max():
    import random
    test_vals = [random.randint(-100, 100) for _ in range(10)]
    assert max(test_vals) == max(test_vals, test_vals)



# Generated at 2022-06-25 09:27:06.886540
# Unit test for function min
def test_min():
    filter_module_min = FilterModule()
    test_output = filter_module_min.filters()['min'](2, 3)
    assert test_output == 2


# Generated at 2022-06-25 09:27:14.659323
# Unit test for function min
def test_min():
    if not HAS_MIN_MAX:
        raise AssertionError("Error in test_min(): the test was expected to run under jinja2>=2.10. "
                             "Please upgrade jinja2 and re-run the test")
    filter_module_1 = FilterModule()
    arr = [1,2,3,4,5]
    min_f_1 = filter_module_1.filters()['min']
    assert min_f_1(arr) == 1
    assert min_f_1(arr, attribute="upper") == "1"


# Generated at 2022-06-25 09:27:18.209992
# Unit test for function max
def test_max():

    # Test data for max
    data1 = [190,280,170,210,310]
    data2 = ['A','B','C','D','E']

    assert max(data1) == 310
    assert max(data2) == 'E'


# Generated at 2022-06-25 09:27:44.913089
# Unit test for function max
def test_max():

    filter_module = FilterModule()
    assert filter_module.filters()['max']([1, 2, 3, 4, 5]) == 5


# Generated at 2022-06-25 09:27:52.980402
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    assert 2 == filter_module_max.filters()['max']([1,2,3])
    assert 3 == filter_module_max.filters()['max']([1,3,2])
    assert 2 == filter_module_max.filters()['max']([2,1,3])
    assert 3 == filter_module_max.filters()['max']([3,1,2])


# Generated at 2022-06-25 09:27:57.326006
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3]) == 1
    assert filter_module_1.filters()['min']([1, 2, 3]) == 1




# Generated at 2022-06-25 09:28:09.117424
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([4, 5, 6, 7, 1, 3, 5]) == 7
    assert filter_module_1.filters()['max']([1]) == 1
    assert filter_module_1.filters()['max']([1, 1, 1, 1, 1, 1, 1]) == 1
    assert filter_module_1.filters()['max']([1, 2, 3, 4, 1, 2, 3, 4]) == 4
    assert filter_module_1.filters()['max']([1, 2, 3, 4, 2, 3, 4, 1]) == 4

# Generated at 2022-06-25 09:28:20.679189
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()

    list = ['1', '2', '3', '4', '5']
    assert filter_module_max.filters()['max'](list) == max(list)

    list = ["a", "b", "c", "d", "e"]
    assert filter_module_max.filters()['max'](list) == max(list)

    list = [1,2,3,4,5]
    assert filter_module_max.filters()['max'](list) == max(list)

    list = ["a", "b", "c", "d", "e"]
    assert filter_module_max.filters()['max'](list) == max(list)

    list = [1,2,3,4,5]
    assert filter_module_max.fil

# Generated at 2022-06-25 09:28:26.624621
# Unit test for function human_readable
def test_human_readable():
    filter_module_0 = FilterModule()

    # Test case: input a is integer
    try:
        filter_module_0.filters()['human_readable'](12345678)
    except AnsibleFilterTypeError as e:
        raise AssertionError("The function human_readable raised AnsibleFilterTypeError with code: %s" % (to_native(e)))

    # Test case: input a is not integer
    try:
        filter_module_0.filters()['human_readable']("12345678")
    except AnsibleFilterTypeError as e:
        raise AssertionError("The function human_readable raised AnsibleFilterTypeError with code: %s" % (to_native(e)))

    # Test case: input isbits is set to be True

# Generated at 2022-06-25 09:28:29.062197
# Unit test for function logarithm
def test_logarithm():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['log'](10)
    assert result == math.log10(10)


# Generated at 2022-06-25 09:28:31.609233
# Unit test for function min
def test_min():
    filter_module_0_min = FilterModule()
    assert filter_module_0_min.filters()['min'](1,2) == 1


# Generated at 2022-06-25 09:28:32.742827
# Unit test for function max
def test_max():
    assert max(list(range(0, 10))) == 9


# Generated at 2022-06-25 09:28:40.607512
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 'a', 'b', 1, 2, 3, 'a', 'b']) == [1, 2, 3, 'a', 'b']
    assert unique('ansible') == ['a', 'n', 's', 'i', 'b', 'l', 'e']


# Generated at 2022-06-25 09:29:38.655924
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_0 = FilterModule()

    assert filter_module_0.filters()['human_to_bytes']("10") == 10
    assert filter_module_0.filters()['human_to_bytes']("10", "kb") == 10240
    assert filter_module_0.filters()['human_to_bytes']("10", "kib") == 10240
    assert filter_module_0.filters()['human_to_bytes']("10", "mb") == 10485760
    assert filter_module_0.filters()['human_to_bytes']("10", "mib") == 10485760
    assert filter_module_0.filters()['human_to_bytes']("10", "gb") == 10737418240

# Generated at 2022-06-25 09:29:44.821985
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_0 = FilterModule()
    human_to_bytes_function = filter_module_0.filters()['human_to_bytes']
    assert human_to_bytes_function("100") == 100
    assert human_to_bytes_function("100k") == 102400
    assert human_to_bytes_function("100K") == 102400
    assert human_to_bytes_function("100m") == 104857600
    assert human_to_bytes_function("100M") == 104857600
    assert human_to_bytes_function("100g") == 107374182400
    assert human_to_bytes_function("100G") == 107374182400
    assert human_to_bytes_function("100t") == 109951162777600