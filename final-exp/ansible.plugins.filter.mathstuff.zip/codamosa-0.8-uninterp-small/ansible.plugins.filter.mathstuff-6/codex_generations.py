

# Generated at 2022-06-25 09:20:06.791447
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_1 = FilterModule()
    data_1 = [
            {'data_1': 'a', 'data_2': 1},
            {'data_1': 'b', 'data_2': 2}
    ]
    result_1 = filter_module_1.filters()['rekey_on_member'](data_1, 'data_1')
    assert result_1['a']['data_2'] == 1 


# Generated at 2022-06-25 09:20:11.900487
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()["symmetric_difference"]([1,2,3], [2,3,4]) == [1,4]


# Generated at 2022-06-25 09:20:22.998888
# Unit test for function human_to_bytes
def test_human_to_bytes():
    g = FilterModule()
    assert g.filters()['human_to_bytes']('1 TB') ==  1000000000000
    assert g.filters()['human_to_bytes']('1.5 TB') ==  1500000000000
    assert g.filters()['human_to_bytes']('1tb') ==  1000000000000
    assert g.filters()['human_to_bytes']('1.5tb') ==  1500000000000
    assert g.filters()['human_to_bytes']('1024 GB') == 1000000000000
    assert g.filters()['human_to_bytes']('1 GB') ==  1000000000
    assert g.filters()['human_to_bytes']('1.5 GB') ==  1500000000
    assert g.filters()['human_to_bytes']('1024 mb')

# Generated at 2022-06-25 09:20:26.100333
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    max_filter = filter_module_max.filters()['max']
    assert max_filter([1, 2, 3, 4, 5]) == 5


# Generated at 2022-06-25 09:20:28.619791
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1,2,3,4,5]) == 1


# Generated at 2022-06-25 09:20:29.526440
# Unit test for function min
def test_min():
    pass


# Generated at 2022-06-25 09:20:32.914624
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([1, 2, 3, 4, 5]) == 5
    assert filter_module_1.filters()['max']([5, 4, 3, 2, 1]) == 5


# Generated at 2022-06-25 09:20:34.616895
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1) == 0
    assert logarithm(math.e) == 1
    assert logarithm(1000,10) == 3


# Generated at 2022-06-25 09:20:44.916176
# Unit test for function min
def test_min():
    data = {'x': {'a': 1, 'b': 2, 'c': 3}, 'y': {'a': 2, 'b': 1, 'c': 4}}
    assert FilterModule().filters()['min'](data, 'x.a', 'x.b', 'y.c') == 1
    assert FilterModule().filters()['min'](data, 'x.b', 'y.a') == 1
    assert FilterModule().filters()['min'](data, 'x.a', 'y.c', default='abc') == 'abc'
    assert FilterModule().filters()['min'](data, 'x.a', 'y.c', default=None) is None


# Generated at 2022-06-25 09:20:51.944500
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_1 = FilterModule()
    data = [ {'data': 'aa', 'key': 'b'},
             {'data': 'bb', 'key': 'a'},
             {'data': 'cc', 'key': 'b'} ]
    key = 'key'
    try:
        filter_module_1.filters()['rekey_on_member'](data, key)
        assert False, 'rekey_on_member should have failed due to duplicates'
    except AnsibleFilterError:
        pass

    data = [ {'data': 'aa', 'key': 'b'},
             {'data': 'bb', 'key': 'a'},
             {'data': 'cc', 'key': 'c'} ]

    duplicates = 'error'
    result = filter_module_1.fil

# Generated at 2022-06-25 09:21:06.944976
# Unit test for function rekey_on_member
def test_rekey_on_member():
    assert rekey_on_member([{'a': 1}, {'a': 2}], 'a', 'error') == {1: {'a': 1}, 2: {'a': 2}}



# Generated at 2022-06-25 09:21:17.188342
# Unit test for function min
def test_min():
    assert min([]) == None, "min([])"
    assert min([1, 2, 3]) == 1, "min([1, 2, 3])"
    assert min([1.1, 1.2, 1.3]) == 1.1, "min([1.1, 1.2, 1.3])"
    assert min([], default=0) == 0, "min([], default=0)"
    assert min([1, 2, 3], default=0) == 1, "min([1, 2, 3], default=0)"
    assert min([1.1, 1.2, 1.3], default=0) == 1.1, "min([1.1, 1.2, 1.3], default=0)"

# Generated at 2022-06-25 09:21:18.183694
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 2]) == [1, 2]


# Generated at 2022-06-25 09:21:24.079113
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [{'key': 'a', 'val': 1}, {'key': 'b', 'val': 2}]
    key = 'key'
    result = rekey_on_member(data, key)

    expected = {'a': {'key': 'a', 'val': 1}, 'b': {'key': 'b', 'val': 2}}
    assert result == expected, "result: %s and expected: %s" % (result, expected)



# Generated at 2022-06-25 09:21:28.116215
# Unit test for function min
def test_min():
    # This is a test for the filter min
    import jinja2
    env = jinja2.Environment()
    assert env.from_string('{{ [1, 2, 3, 4, 5] | min }}').render() == '1'
    assert env.from_string('{{ [1000, 100, 10, -1000, -100, -10] | min }}').render() == '-1000'


# Generated at 2022-06-25 09:21:32.688058
# Unit test for function unique
def test_unique():
    assert unique([1, 1, 2]) == [1, 2]
    assert unique([1, 2, 1]) == [1, 2]


# Generated at 2022-06-25 09:21:34.624795
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([1, 2, '3', 4, 5]) == 1
    assert min([False, 'a', 'b', True, None]) is False


# Generated at 2022-06-25 09:21:42.000796
# Unit test for function unique
def test_unique():
    str_0 = 'ehabled-runtime'
    var_0 = unique(str_0, -100, -100)
    var_1 = unique(str_0, -100, -100)
    var_2 = unique(str_0, -100, -100)
    var_3 = unique(str_0, 0, 0)
    assert var_0 == -100
    assert var_1 == -100
    assert var_2 == -100
    assert var_3 == 0



# Generated at 2022-06-25 09:21:47.333858
# Unit test for function min
def test_min():
    assert(min([4,3,2,1]) == 1)
    assert(min([4,3,2]) == 2)
    assert(min([4,5,5,5]) == 4)
    assert(min([4,2,2,5,5]) == 2)
    assert(min([10,10,10,-10,-10,-10]) == -10)


# Generated at 2022-06-25 09:21:53.946761
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], 5) == 1
    assert min([1, 2, 3], -1) == -1
    assert min([1, 2, 3], default=10) == 1
    assert min([], default=10) == 10
    assert min('abc') == 'a'
    assert min('abc', 'xyz') == 'a'
    assert min('abc', 'xyz', '1', '9') == '1'
    assert min([], default=10) == 10
    assert min({'one': 1, 'two': 2}) == 1
    assert min({'one': 1, 'two': 2}, foo=10) == 1


# Generated at 2022-06-25 09:22:01.112900
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    res = min(filter_module, [1,2,3,4,5])
    assert 1 == res


# Generated at 2022-06-25 09:22:03.480368
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1 == max(filter_module_1, filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:22:05.404959
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    var_1 = max(filter_module_1, 1)


# Generated at 2022-06-25 09:22:15.676862
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data_0 = [{u'foo': u'haha', u'bar': u'wang', u'baz': u'wang'}, {u'foo': u'hehe', u'bar': u'tian', u'baz': u'wang'}, {u'foo': u'haha', u'bar': u'wang', u'baz': u'wang'}]
    key_0 = u'foo'
    duplicates_0 = u'overwrite'

# Generated at 2022-06-25 09:22:21.182336
# Unit test for function max
def test_max():
    assert max(filter_module_1, [1,2,3]) == 3
    assert max(filter_module_1, '1,2,3') == '3'
    assert max(filter_module_1, [10.2,2.0,3]) == 10.2
    assert max(filter_module_1, [10,2,30]) == 30
    assert max(filter_module_1, ['10','2','3']) == '3'


# Generated at 2022-06-25 09:22:27.261889
# Unit test for function min
def test_min():
    var_1 = min(1,2,3)
    assert(var_1 == 1)
    var_3 = max(1,2,3)
    assert(var_3 == 3)


# Generated at 2022-06-25 09:22:32.658292
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters()
    var_0 = max(var_0, var_0)


# Generated at 2022-06-25 09:22:39.904767
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module = FilterModule()
    assert symmetric_difference(filter_module, filter_module, filter_module) == []
    assert symmetric_difference(filter_module, [1, 2, 3, 4], [3, 4, 5]) == [1, 2, 5]
    assert symmetric_difference(filter_module, {1, 2, 3, 4}, {3, 4, 5}) == {1, 2, 5}
    assert symmetric_difference(filter_module, [1, 2, 3, 4], (1, 2, 3, 4, 5)) == [5]
    # Exception raised when dict compared to list & set
    try:
        symmetric_difference(filter_module, {1, 2, 3, 4}, {3, 4, 5, 6, 7})
    except Exception:
        assert True

# Generated at 2022-06-25 09:22:42.519210
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.max()
    assert var_0 is None


# Generated at 2022-06-25 09:22:44.805898
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert max(filter_module_0, filter_module_0) is None


# Generated at 2022-06-25 09:23:00.368956
# Unit test for function unique
def test_unique():

    # Unit test for function unique with arguments: []
    assert unique(None, []) == []
    # Unit test for function unique with arguments: [[1]]
    assert unique(None, [1]) == [1]
    # Unit test for function unique with arguments: [[1, 1]]
    assert unique(None, [1, 1]) == [1]
    # Unit test for function unique with arguments: [[1, 1, 2]]
    assert unique(None, [1, 1, 2]) == [1, 2]
    # Unit test for function unique with arguments: [[1, 1, 2, 2]]
    assert unique(None, [1, 1, 2, 2]) == [1, 2]

    # Unit test for function unique with arguments: ['test']
    assert unique(None, "test") == "test"
    # Unit test for function unique with

# Generated at 2022-06-25 09:23:04.809644
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module_1 = FilterModule()
    var_1 = symmetric_difference(filter_module_1, filter_module_1)
    expected_1 = []
    assert var_1 == expected_1


# Generated at 2022-06-25 09:23:06.848440
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    var_1 = max(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:23:08.339867
# Unit test for function max
def test_max():
    # Test for no input param
    assert max(FilterModule(), [1]) == 1


# Generated at 2022-06-25 09:23:11.365880
# Unit test for function min
def test_min():
    test_input = [5]
    test_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    assert min(test_list, test_input) == 4



# Generated at 2022-06-25 09:23:18.312447
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    var_1 = [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    var_2 = None
    var_3 = min(filter_module_1, var_1, var_2)


# Generated at 2022-06-25 09:23:24.187164
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    var_actual = min(filter_module, filter_module)
    var_expected = min(filter_module)
    assert var_actual == var_expected


# Generated at 2022-06-25 09:23:36.073757
# Unit test for function human_readable
def test_human_readable():
    assert (human_readable(100) == '100.0 B')
    assert (human_readable('100') == '100.0 B')
    assert (human_readable(1024) == '1.0 kB')
    assert (human_readable('1kB') == '1.0 kB')
    assert (human_readable('1.2MB') == '1.2 MB')
    assert (human_readable('1.2MiB') == '1.3 MB')
    assert (human_readable('1.2MiB', isbits=True) == '1.1 MB')
    assert (human_readable('1.2TB', isbits=True) == '1.3 TB')
    assert (human_readable('1.2TiB') == '1.3 TB')

# Generated at 2022-06-25 09:23:41.216257
# Unit test for function min
def test_min():
    if HAS_MIN_MAX:
        filter_module = FilterModule()
        assert min(filter_module, [2, 3, 4]) == 2
        assert min(filter_module, [2, 3, 4], attribute='a') == 2


# Generated at 2022-06-25 09:23:43.811484
# Unit test for function max
def test_max():
    assert min([32, 5, 12, 8, 3, 75, 2, 15]) == 2
    assert min([-32, -5, -12, -8, -3, -75, -2, -15]) == -75


# Generated at 2022-06-25 09:23:58.755771
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('3K') == 3072
    assert human_to_bytes('3M') == 3145728
    assert human_to_bytes('3G') == 3221225472
    assert human_to_bytes('3T') == 3298534883328
    assert human_to_bytes('3P') == 338380848179712
    assert human_to_bytes('3E') == 34678440563091968
    assert human_to_bytes('3Z') == 3551928651146151936
    assert human_to_bytes('3Y') == 36360844006323023872
    assert human_to_bytes('3k') == 3072
    assert human_to_bytes('3m') == 3145728
    assert human_to_bytes('3g') == 3221225472


# Generated at 2022-06-25 09:24:06.778099
# Unit test for function min

# Generated at 2022-06-25 09:24:08.376418
# Unit test for function min
def test_min():
    test_list = [1, 2, 3, 4, 5, 6]
    assert min(test_list) == 1



# Generated at 2022-06-25 09:24:09.376562
# Unit test for function min
def test_min():
    test_filter_data_0 = min(0, 0, 0)



# Generated at 2022-06-25 09:24:12.549076
# Unit test for function symmetric_difference
def test_symmetric_difference():
    input_list_a = [1, 2, 3]
    input_list_b = [2, 3, 4]
    expected_list = [1, 4]

    filter_module = FilterModule()
    output_list = symmetric_difference(filter_module, input_list_a, input_list_b)

    assert output_list == expected_list


# Generated at 2022-06-25 09:24:13.828648
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    var_1 = min(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:24:23.257985
# Unit test for function unique
def test_unique():
    module = FilterModule()
    assert [1, 2, 3] == module.unique([1, 2, 3])
    assert [1, 2, 3] == module.unique([1, 2, 3, 3, 2, 1])
    assert [1, 2, 3] == module.unique([1, 2, 3, 2, 1])
    assert [1, 2, 3] == module.unique([1, 2, 3, 2, 1])
    assert [1, 2, 3] == module.unique([1, 2, 3, 3, 2, 1])
    assert ['a', 1, 'b', 2] == module.unique(['a', 'b', 'a', 1, 2, 'b'])

# Generated at 2022-06-25 09:24:25.500806
# Unit test for function min
def test_min():
    arg1 = 1
    arg2 = 2
    arg3 = 3
    arg4 = 4
    expected_result = 1

    result = min(arg1, arg2, arg3, arg4)

    assert result == expected_result


# Generated at 2022-06-25 09:24:31.381588
# Unit test for function min
def test_min():
    from ansible.module_utils.common._collections_compat import (
        UserDict,
        UserList,
        UserString,
    )
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([0, -1, -2, -3, -4, -5]) == -5
    assert min([1, 1, 1, 1, 1]) == 1
    assert min([-1, -1, -1, -1, -1]) == -1
    assert min([]) is None
    assert min("abcdefg") == "a"
    assert min("") is None
    assert min(set("abcdefg")) == "a"
    assert min(set("")) is None
    assert min("", default="z") == "z"
    assert min("", default=object()) == object

# Generated at 2022-06-25 09:24:34.790567
# Unit test for function max
def test_max():
    filter_module = FilterModule()

    # Test with non-empty input
    assert filter_module.filters()['max'](1, 2, 3, 4, 5) == 5

    # Test with empty input
    assert filter_module.filters()['max']() is __builtins__.get('None')


# Generated at 2022-06-25 09:24:42.453239
# Unit test for function min
def test_min():
    tuple_0 = ( 1, 2, 3)
    var_0 = min(tuple_0)
    assert var_0 == 1


# Generated at 2022-06-25 09:24:43.931151
# Unit test for function max
def test_max():
    assert max(None, 7, 6, 5, 4, 3, 2, 1) == 7


# Generated at 2022-06-25 09:24:46.890783
# Unit test for function min
def test_min():
    assert min(3,4) == 3


# Generated at 2022-06-25 09:24:49.717599
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    integer_list = [1, 2, 3, 4, 5, 6, 7]
    expected = 1
    actual = min(filter_module, integer_list)
    assert actual == expected



# Generated at 2022-06-25 09:24:55.427729
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_1 = FilterModule()
    assert human_to_bytes(filter_module_1, filter_module_1, default_unit=None, isbits=False) == 0


# Generated at 2022-06-25 09:25:01.170305
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    var_0 = filter_module_0.filters.get('max')
    assert isinstance(var_0, object) == True
    a = [1, 2, 3, 4]
    b = [1, 2, 3, 4]
    c = var_0(a, b)
    assert b == [1, 2, 3, 4]
    assert c == [1, 2, 3, 4]
    assert a == [1, 2, 3, 4]


# Generated at 2022-06-25 09:25:06.509438
# Unit test for function min
def test_min():

    filter_module_1 = FilterModule()
    var_1 = min(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:25:11.994753
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    testlist = [2, 4, 3, 5, 7, 6]
    res = max(filter_module_1, testlist)
    assert res == 7


# Generated at 2022-06-25 09:25:16.194490
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    var_1 = min(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:25:19.752422
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_0 = FilterModule()
    var_0 = [filter_module_0]
    var_1 = rekey_on_member(var_0, filter_module_0)
    assert var_1 == var_0

# Generated at 2022-06-25 09:25:28.937915
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    assert min(filter_module, [1, 2, 3, 4], case_sensitive=False) == 1


# Generated at 2022-06-25 09:25:34.183225
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    assert filter_module.filters()['min']([0, 1, 2]) == 0
    assert filter_module.filters()['min']([2, 1]) == 1
    assert filter_module.filters()['min']("a", "b") == "a"
    assert filter_module.filters()['min']([]) == None


# Generated at 2022-06-25 09:25:36.617914
# Unit test for function min
def test_min():
    assert min(filter_module_0, filter_module_0) == filter_module_0


# Generated at 2022-06-25 09:25:48.663022
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module_1 = FilterModule()

    list_0 = [{'a': 1, 'b': {'c': 2, 'd': 3}}, {'a': 2, 'b': {'c': 4, 'd': 5}}, {'a': 3, 'b': {'c': 6, 'd': 7}}]
    var_0 = rekey_on_member(list_0, 'a')
    assert var_0 == {1: {'a': 1, 'b': {'c': 2, 'd': 3}}, 2: {'a': 2, 'b': {'c': 4, 'd': 5}}, 3: {'a': 3, 'b': {'c': 6, 'd': 7}}}


# Generated at 2022-06-25 09:25:52.447599
# Unit test for function max
def test_max():
    assert max(3, 1) == 3
    assert max(1, 3) == 3
    assert max((3, 1)) == 3
    assert max((1, 3)) == 3
    assert max([3, 1]) == 3
    assert max([1, 3]) == 3
    assert max('ab', 'a') == 'ab'
    assert max({'a': 2, 'b': 1}) == 2
    assert max({'a': 2, 'b': 1}, key=lambda x: x[0]) == 'b'

# Generated at 2022-06-25 09:26:01.944809
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    var = filter_module
    var = [1, 1]
    var = [3, 2, 1]
    var = [3, 1, 2]
    var = ['a', 1, 2, 'a']
    var = ['a', 'b', 'c']
    var = ['a', 'b', 'a']
    var = ['b', 'a', 'a']
    var = [1, 'a', 'b', 'a']
    var = [1, 'a', 'b', 1]
    var = [1, 'a', 'b', 'b']
    var = ['c', 'b', 'a', 'a']
    var = ['a']
    var = [1]
    var = [1, 2]
    var = [1, 'a']

# Generated at 2022-06-25 09:26:12.880066
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module = FilterModule()

    assert filter_module.filters()['human_to_bytes'](['1k']) == 1024
    assert filter_module.filters()['human_to_bytes'](['1k'], default_unit='k') == 1000
    assert filter_module.filters()['human_to_bytes'](['1k'], default_unit='k', isbits=True) == 8000
    assert filter_module.filters()['human_to_bytes'](['1m']) == 1048576
    assert filter_module.filters()['human_to_bytes'](['1 m']) == 1048576
    assert filter_module.filters()['human_to_bytes'](['1 MiB']) == 1048576

# Generated at 2022-06-25 09:26:23.237630
# Unit test for function rekey_on_member
def test_rekey_on_member():
    fixture = [{'name': 'a', 'value': 1}, {'name': 'b', 'value': 2}, {'name': 'c', 'value': 3}]

    expected = {'a': {'name': 'a', 'value': 1},
                'b': {'name': 'b', 'value': 2},
                'c': {'name': 'c', 'value': 3}}

    assert expected == rekey_on_member(fixture, 'name')

    expected = {'1': {'name': 'a', 'value': 1},
                '2': {'name': 'b', 'value': 2},
                '3': {'name': 'c', 'value': 3}}

    assert expected == rekey_on_member(fixture, 'value')


# Generated at 2022-06-25 09:26:25.783181
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    res_0 = min(filter_module_0, filter_module_0)
    assert res_0 == filter_module_0


# Generated at 2022-06-25 09:26:27.694549
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([1,2,3,4,5])


# Generated at 2022-06-25 09:26:37.549403
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    test_input = ['B', 'C', 'A']
    expected_output = 'C'

    actual_output = max(filter_module, test_input)

    assert expected_output == actual_output


# Generated at 2022-06-25 09:26:39.754730
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    list_object = [1, 2, 3]
    max_object = max(filter_module_0, list_object)


# Generated at 2022-06-25 09:26:41.771423
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    filter_module_1.min([1,2,3,4,5])


# Generated at 2022-06-25 09:26:43.610358
# Unit test for function human_readable
def test_human_readable():
    filter_module_1 = FilterModule()
    var_1 = human_readable(unit='B', isbits=True, size=1)


# Generated at 2022-06-25 09:26:50.462201
# Unit test for function unique
def test_unique():
    _unique = FilterModule().filters()['unique']
    # No Unicode, no change
    assert _unique(["a","b","b","c"], case_sensitive=True) == ["a","b","c"]
    assert _unique(["a","b","b","c"], case_sensitive=False) == ["a","b","c"]
    # No Unicode, change case
    assert _unique(["a","B","b","c"], case_sensitive=True) == ["a","B","b","c"]
    assert _unique(["a","B","b","c"], case_sensitive=False) == ["a","b","c"]
    # No Unicode, no change, dicts with same value for different keys

# Generated at 2022-06-25 09:26:55.484076
# Unit test for function max
def test_max():
    assert max(0, []) == 0
    assert max(10, [10, 3, 5]) == 10
    assert max(-1, [-1, -3, -0.5]) == 0
    assert max('b', ['b', 'a', 'c']) == 'c'
    assert max(0, [0, 10, -10]) == 10
    assert max(0.0, [0.0, 1.0, -1.0]) == 1.0
    assert max('', ['', 'a', 'b']) == 'b'
    assert max(1, [1, 1, 0, 0]) == 1
    assert max(1, [1, 1, 1, 1]) == 1
    assert max(-1, [-1, -1, -2, -2]) == -1

# Generated at 2022-06-25 09:26:57.668375
# Unit test for function min
def test_min():
    assert min([]) == None
    assert min([1,2,3]) == 1
    assert min([1,2,3], attribute='something') == None


# Generated at 2022-06-25 09:26:59.886585
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    var_0 =  filter_module_0.filters()['max']('a')
    var_1 =  filter_module_0.filters()['max']('test_value')
    assert var_0 == 'test_value'
    assert var_1 == 'test_value'


# Generated at 2022-06-25 09:27:02.252490
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_0 = FilterModule()
    var_0 = human_to_bytes(filter_module_0, filter_module_0)


# Generated at 2022-06-25 09:27:04.284078
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    var_1 = min(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:27:21.211860
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test a simple list of dicts:
    vd = [{'description': 'first', 'key': 'one'}, {'description': 'second', 'key': 'two'}]
    rekeyed_vd = rekey_on_member(vd, 'key')
    assert rekeyed_vd['one']['description'] == 'first'
    assert rekeyed_vd['two']['description'] == 'second'

    # Test that a ValueError is thrown if the key is not unique.
    try:
        rekeyed_vd = rekey_on_member(vd, 'description')
    except AnsibleFilterError as e:
        assert 'Key first is not unique' in to_text(e)

    # Test that overwriting works.

# Generated at 2022-06-25 09:27:31.752805
# Unit test for function rekey_on_member
def test_rekey_on_member():
    fm = FilterModule()

    data = [
        dict(id='A', key='a', val='x'),
        dict(id='B', key='b', val='y'),
    ]

    data_rekey = rekey_on_member(data, 'id')

    assert 'a' in data_rekey
    assert 'b' in data_rekey
    assert data_rekey['a'] == dict(id='a', key='a', val='x')
    assert data_rekey['b'] == dict(id='b', key='b', val='y')

    data_rekey2 = rekey_on_member(data, 'key')

    assert 'a' in data_rekey
    assert 'b' in data_rekey

# Generated at 2022-06-25 09:27:37.398126
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()

    var_1 = [1, 2, 3, 4, 5, 6]
    var_2 = min(var_1, filter_module_1)
    assert(var_2 == 1)

# Generated at 2022-06-25 09:27:38.747353
# Unit test for function min
def test_min():
    assert min(range(5)) == 0


# Generated at 2022-06-25 09:27:46.465238
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Assert for base case, where size is measured in bytes
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('100') == 100
    # Assert for size is measured in KB
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1K') == 1024
    # Assert for size is measured in MB
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1M') == 1048576
    # Assert for size is measured in GB
    assert human_to_bytes('1GB') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    # Ass

# Generated at 2022-06-25 09:27:56.430243
# Unit test for function min
def test_min():
    # from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError
    from ansible.utils.display import Display
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import zip, zip_longest
    from ansible.module_utils.common._collections_compat import Hashable, Mapping, Iterable
    from ansible.module_utils._text import to_native, to_text
    from ansible.utils.display import Display
    # from ansible.module_utils.six import string_types
    # from ansible.module_utils._text import to_text, to_native
    # from ansible.utils.display import Display
    # from ansible.plugins.loader import add_all_plugin_dirs
    # from ansible.

# Generated at 2022-06-25 09:27:58.620889
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filter_module_1 = FilterModule()
    var_1 = human_to_bytes(filter_module_1, '4G', 'm', False)


# Generated at 2022-06-25 09:28:00.273099
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    var_1 = max(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:28:02.500052
# Unit test for function min
def test_min():
    assert min(9, 42, 42, 19, 1, 2) == 1


# Generated at 2022-06-25 09:28:04.147785
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    var_1 = max(filter_module_1, filter_module_1)



# Generated at 2022-06-25 09:28:13.876843
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    list_1 = [1,2,3]
    min_1 = min(filter_module_1, list_1)


# Generated at 2022-06-25 09:28:16.722375
# Unit test for function human_readable
def test_human_readable():
    filter_module_0 = FilterModule()
    var_0 = human_readable(filter_module_0, filter_module_0)


# Generated at 2022-06-25 09:28:20.204052
# Unit test for function min
def test_min():
    pass



# Generated at 2022-06-25 09:28:25.299360
# Unit test for function min
def test_min():
    assert min(1, 1, 0, 2) == 0
    assert min([1, 1, 0, 2]) == 0
    assert min(["a", "b", "c", "d"]) == "a"
    assert min(["a", "b", "c", "d"], attribute="upper") == "a"
    assert min(["A", "b", "c", "d"], attribute="upper") == "A"



# Generated at 2022-06-25 09:28:29.556121
# Unit test for function max
def test_max():
    f = FilterModule()
    assert 16 == max(f, [[5,3,1],[5,7,9,1],[5,7,9,16]])
    assert 'a' == max(f, [['a','b','c'],['d','e','f','a'],['g','h','i','a']])


# Generated at 2022-06-25 09:28:33.518094
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3

# Generated at 2022-06-25 09:28:39.298233
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    test_dict = {'a':1, 'b':1, 'c':2, 'd':2}
    assert unique(filter_module, test_dict, case_sensitive=False, attribute='values') == [1, 2]
    test_dict = {'a':1, 'b':2, 'c':3}
    assert unique(filter_module, test_dict, case_sensitive=False, attribute='values') == [1, 2, 3]


# Generated at 2022-06-25 09:28:44.701396
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    var_0 = list()
    var_0.append(1)
    var_0.append(2)
    var_0.append(3)
    var_0.append(4)
    var_0.append(5)
    var_0 = filter_module_0.filters()['min'](filter_module_0, var_0)


# Generated at 2022-06-25 09:28:50.720023
# Unit test for function min
def test_min():

    assert min([0, 1, 2]) == 0
    assert min((0, 1, 2)) == 0

    assert min([0, 2, 1]) == 0
    assert min((0, 2, 1)) == 0

    assert min([-1, 0, 1]) == -1
    assert min((-1, 0, 1)) == -1



# Generated at 2022-06-25 09:29:02.438827
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_class = FilterModule()

    # input:  data = [{"a": 1, "b": 1}, {"a": 2, "b": 2}, {"a": 3, "b": 3}], key = "a"
    # expected_result: {"1": {"a": 1, "b": 1}, "2": {"a": 2, "b": 2}, "3": {"a": 3, "b": 3}}
    data = [{"a": 1, "b": 1}, {"a": 2, "b": 2}, {"a": 3, "b": 3}]
    key = "a"
    expected_result = {"1": {"a": 1, "b": 1}, "2": {"a": 2, "b": 2}, "3": {"a": 3, "b": 3}}
    actual_result = rekey_on_member

# Generated at 2022-06-25 09:29:21.041098
# Unit test for function min
def test_min():
    arg1 = 10
    arg2 = 20
    arg3 = -10
    arg4 = 'sample'
    arg5 = None

    assert min(arg1, arg2, arg3, arg4, arg5) == -10


# Generated at 2022-06-25 09:29:25.830663
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    # Test no arguments
    with pytest.raises(AnsibleFilterError):
        var_1 = min(filter_module_1, filter_module_1)


# Generated at 2022-06-25 09:29:28.425936
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert min(filter_module_1, 0, 1, 2, 3, 4, 5) == 0


# Generated at 2022-06-25 09:29:35.990296
# Unit test for function rekey_on_member

# Generated at 2022-06-25 09:29:39.448485
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    assert max(filter_module, [1, 2, 3, 4, 5]) == 5


# Generated at 2022-06-25 09:29:43.138547
# Unit test for function max
def test_max():
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader
    from jinja2 import Template
    env = Environment(loader=DictLoader({'test.tpl': '{{ a | max }}'}))
    template = env.get_template('test.tpl')
    result = template.render(a=[1, 2, 3, 4, 5])
    assert result == '5'


# Generated at 2022-06-25 09:29:47.651971
# Unit test for function min
def test_min():
    assert min([2, 5, 8, 3, 4, 5, 10, 15]) == 2
    assert min([[1, 5], [3], [4, 8], [2, 6]]) == [1, 5]
    assert min(['ab', 'cd', 'ef']) == 'ab'
    assert min("abcdefg") == 'a'

