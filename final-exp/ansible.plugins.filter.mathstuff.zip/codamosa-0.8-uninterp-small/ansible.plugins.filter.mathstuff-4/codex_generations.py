

# Generated at 2022-06-25 09:20:07.468765
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    print("max filter: ", filter_module.filters()['max'])
    a = [1,2,3]
    b = 5
    c = -4
    print("max of a: ", filter_module.filters()['max'](a))
    print("max of a and b: ", filter_module.filters()['max'](a,b))
    print("max of a and c: ", filter_module.filters()['max'](a,c))
    print("max of b and c: ", filter_module.filters()['max'](b,c))


# Generated at 2022-06-25 09:20:09.453218
# Unit test for function min
def test_min():
    f = filter_module_0.filters()
    assert f['min']([45, 4, 3, 1]) == 1


# Generated at 2022-06-25 09:20:21.789387
# Unit test for function human_to_bytes
def test_human_to_bytes():

    filter_module = FilterModule()

    assert filter_module.filters()['human_to_bytes']('1') == 1
    assert filter_module.filters()['human_to_bytes']('1.0') == 1
    assert filter_module.filters()['human_to_bytes']('1 EiB') == 1125899906842624
    assert filter_module.filters()['human_to_bytes']('1.0 EiB') == 1125899906842624
    assert filter_module.filters()['human_to_bytes']('1.0EiB') == 1125899906842624
    assert filter_module.filters()['human_to_bytes']('1024') == 1024
    assert filter_module.filters()['human_to_bytes']('1024M') == 1073741824

# Generated at 2022-06-25 09:20:31.426003
# Unit test for function unique
def test_unique():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['unique']([1,2,3,3,3,2,2,3,3,3,3,3,1]) == [1,2,3]
    assert filter_module_1.filters()['unique']({"a": 1, "b": 1, "c": 2, "d": 3, "e": 2, "f": 3}) == [1, 2, 3]
    assert filter_module_1.filters()['unique']({"a": 1, "b": 1, "c": 2, "d": 3, "e": 2, "f": 3}, True) == [1, 2, 3]

# Generated at 2022-06-25 09:20:37.827985
# Unit test for function min
def test_min():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert min([2, 3, 1], None) == 1        # min
    assert min((2, 4, 1, 3), None) == 1     # min in a tuple
    assert min({'a': 2, 'b': 1}, None) == 1 # min in a dict

    # key parameter
    assert min([{'a': 2, 'b': 1}, {'a': 3, 'b': 3}], None, key=lambda d: d['a']) == {'a': 2, 'b': 1}

    # convert to string
    assert min('ba', None) == 'a'

    # str is not allowed
    try:
        assert min('foo', None) == 'a'
    except AnsibleFilterTypeError:
        pass

    # error:

# Generated at 2022-06-25 09:20:40.159996
# Unit test for function min
def test_min():
    from ansible.module_utils.jinja2.filters.tests.test_min import TestMin
    TestMin.test_min()
    TestMin.test_min_with_attribute()
    TestMin.test_min_with_attribute_and_key()


# Generated at 2022-06-25 09:20:45.515220
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    assert filter_module.filters().get('max')([1, 2, 3, 4]) == 4
    assert filter_module.filters().get('max')([1, 2, 3, 4], 5, 6) == 6
    assert filter_module.filters().get('max')([1, 2, 3, 4], 1, 6) == 6


# Generated at 2022-06-25 09:20:51.249498
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    min_a = min([1,2,3],2)
    assert min_a == 1


# Generated at 2022-06-25 09:20:56.264258
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module_0 = FilterModule()

    # Test for correct input
    a = ['a', 'b', 'c', 'd', 'e']
    b = ['c', 'd', 'e', 'f']
    c = filter_module_0.filters()["symmetric_difference"](None, a, b)
    assert set(c) == set(['a', 'b', 'f'])

    # Error case:
    # Mismatched inputs:
    a_error = 123
    b_error = 456
    try:
        c_error = filter_module_0.filters()["symmetric_difference"](None, a_error, b_error)
    except Exception as exception:
        assert type(exception) == AnsibleFilterTypeError

# Generated at 2022-06-25 09:21:01.497375
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    dict_of_dicts = {'dict1': {'a': 'v1', 'b': 'v1'}, 'dict2': {'a': 'v2', 'b': 'v2'}}
    dict_of_dicts_duplicate_error = {'dict1': {'a': 'v1', 'b': 'v1'}, 'dict2': {'a': 'v1', 'b': 'v2'}}
    dict_of_dicts_key_not_found = {'dict1': {'a': 'v1', 'b': 'v1'}, 'dict2': {'c': 'v2', 'b': 'v2'}}

# Generated at 2022-06-25 09:21:18.810650
# Unit test for function logarithm
def test_logarithm():
    # Good value
    assert logarithm(5, 2) == 2.321928094887362
    # Good value
    assert logarithm(5, 10) == 0.6989700043360189
    # Good value
    assert logarithm(5) == 1.6094379124341003



# Generated at 2022-06-25 09:21:23.781195
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3, 4]) == 1


# Generated at 2022-06-25 09:21:28.581178
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    list_0 = ['1', '2', '3', '4', '5']
    assert(filter_module_0.filters()['min'](environment=None, a=list_0) == '1')


# Generated at 2022-06-25 09:21:32.918723
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3]) == 1


# Generated at 2022-06-25 09:21:40.003724
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Unit tests for function human_to_bytes
    # Test if the result is int instead of float
    assert isinstance(human_to_bytes('1024'), int)

    # Test if the function can convert bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1b') == 1

    # Test if the function can convert kilobytes
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1kB') == 1024

    # Test if the function can convert megabytes
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1mb') == 1048576

# Generated at 2022-06-25 09:21:44.831833
# Unit test for function human_to_bytes
def test_human_to_bytes():
    for test_input, expected_result in (('1K', 1024), ('1.5k', 1536), ('1M', 1048576), ('1.2M', 1258291)):
        assert human_to_bytes(test_input) == expected_result


# Generated at 2022-06-25 09:21:48.497845
# Unit test for function max
def test_max():
    test_input = [4,9,3,4,8,1,2,2,5,1]
    test_max_0 = filter_module_0.filters()['max'](test_input)
    assert test_max_0 == 9


# Generated at 2022-06-25 09:21:55.088986
# Unit test for function min
def test_min():
    filter_module = FilterModule()

    print("\nTesting min...")
    assert filter_module.filters()['min']([2, 3, 6, 3, 1, 0, 2, 5]) == 0
    assert filter_module.filters()['min']([-1, 2, 4, -3]) == -3
    assert filter_module.filters()['min']([-1, 2, 4]) == -1
    assert filter_module.filters()['min']([-1, 2]) == -1
    assert filter_module.filters()['min']([2, -1]) == -1
    assert filter_module.filters()['min']([-1, -1]) == -1
    assert filter_module.filters()['min'](13) == 13

# Generated at 2022-06-25 09:22:04.479850
# Unit test for function min
def test_min():
    filter_module_min = FilterModule()

    # simple max
    assert filter_module_min.filters()['min']([0, 1, 2, 3]) == 0

    # max with attribute
    assert filter_module_min.filters()['min']({'one': 1, 'two': {'three': 3}, 'four': 4}, attribute='three') == 3

    # max with attribute and non matching dictionary
    assert filter_module_min.filters()['min']({'one': 1, 'two': {'three': 3}, 'four': 4}, attribute='five') is None

    # max with attribute and non matching list
    assert filter_module_min.filters()['min']([1, 2, 3, 4], attribute='five') is None

    # max with attribute and non matching string
    assert filter_module_min

# Generated at 2022-06-25 09:22:08.074619
# Unit test for function max
def test_max():
    filter_module_instance = FilterModule()
    assert filter_module_instance.filters()['max'] == max


# Generated at 2022-06-25 09:22:41.169236
# Unit test for function human_readable
def test_human_readable():
    filter_module_1 = FilterModule()
    
    assert filter_module_1.filters()['human_readable'](1000) == '1.0K'
    assert filter_module_1.filters()['human_readable'](102400) == '100.0K'
    assert filter_module_1.filters()['human_readable'](102400, 1) == '100K'
    assert filter_module_1.filters()['human_readable'](104857600) == '100.0M'
    assert filter_module_1.filters()['human_readable'](104857600, 1) == '100M'
    assert filter_module_1.filters()['human_readable'](107374182400) == '100.0G'

# Generated at 2022-06-25 09:22:45.749422
# Unit test for function max
def test_max():
    assert max(['b', 'a'], ['c'], 'd') == ['d']
    assert max([10, 1, 2, 3]) == 10
    assert max([]) is None
    assert max(['a', 'b'], ['a'], 'a') == 'a'


# Generated at 2022-06-25 09:22:50.027665
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1,2,3],[2,3,4]) == [1,4]


# Generated at 2022-06-25 09:22:56.994047
# Unit test for function min
def test_min():

    filter_module = FilterModule()
    filters = filter_module.filters()

    class TestClass1():
        def __init__(self, x):
            self.x = x

        def __str__(self):
            return self.x

        def __lt__(self, other):
            return self.x < other

    class TestClass2():
        def __init__(self, x):
            self.x = x

        def __str__(self):
            return self.x

        def __lt__(self, other):
            return self.x < other


# Generated at 2022-06-25 09:23:07.725418
# Unit test for function unique
def test_unique():
    unique_filter = unique
    assert unique_filter(['a', 'b', 'c', 'a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert unique_filter(['a', 'b', 'c', 'a', 'b', 'c', 'a'], case_sensitive=False) == ['a']
    assert unique_filter({'a': 'b', 'b': 'c', 'c': 'a'}) == [{'a': 'b'}, {'b': 'c'}, {'c': 'a'}]
    assert unique_filter([{'a': 'b'}, {'b': 'c'}, {'c': 'a'}]) == [{'a': 'b'}, {'b': 'c'}, {'c': 'a'}]

# Generated at 2022-06-25 09:23:19.000914
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()

    #--------------------------------------------------
    # This test group checks that the correct exceptions
    # are raised when bad arguments are passed in to
    # the rekey_on_member function.
    #--------------------------------------------------

    # Test #1
    # Test throwing of exception if no arguments are passed in
    error_thrown = False
    try:
        filter_module.filters()["rekey_on_member"]()
    except AnsibleFilterError:
        error_thrown = True
    assert error_thrown

    # Test #2
    # Test throwing of exception if only one argument is passed in
    error_thrown = False
    try:
        filter_module.filters()["rekey_on_member"]({"foo": "bar"})
    except AnsibleFilterError:
        error_thrown = True


# Generated at 2022-06-25 09:23:28.959632
# Unit test for function unique
def test_unique():
    filter_module_1 = FilterModule()
    # Test case 1
    a = [ '80', '1111', '22', '22', '443' ]
    result_1 = filter_module_1.filters()['unique']( a )
    expected_1 = [ '80', '1111', '22', '443' ]
    assert result_1 == expected_1

    # Test case 2
    a = [ '80', '1111', '22', '22', '443' ]
    result_2 = filter_module_1.filters()['unique']( a, case_sensitive=False )
    expected_2 = [ '80', '1111', '22', '443' ]
    assert result_2 == expected_2

    # Test case 3
    a = [ '80', '1111', '22', '22', '443' ]

# Generated at 2022-06-25 09:23:32.174672
# Unit test for function human_readable
def test_human_readable():
    human_readable_0 = human_readable()
    human_readable_1 = human_readable()
    assert human_readable_0 == human_readable_1, "{} != {}".format(human_readable_0, human_readable_1)
    del human_readable_0
    try:
        human_readable(1, 1)
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised"
    del human_readable_1


# Generated at 2022-06-25 09:23:37.420975
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    filters = filter_module.filters()

    input_list = [{'key': '1', 'value': 'one'}, {'key': '2', 'value': 'two'}]
    expected_output = {'1': {'key': '1', 'value': 'one'}, '2': {'key': '2', 'value': 'two'}}
    assert filters['rekey_on_member'](input_list, 'key') == expected_output
    assert filters['rekey_on_member'](input_list, 'key', duplicates='overwrite') == expected_output

    input_dict = {'one': {'key': '1', 'value': 'one'}, 'two': {'key': '2', 'value': 'two'}}

# Generated at 2022-06-25 09:23:42.787528
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    assert filter_module.filters()['min']([1, 2, 3, 4, 5, 6, 7]) == 1
    assert filter_module.filters()['min']('fish') == 'f'
    try:
        filter_module.filters()['min'](['cat', 1, 2])
        assert False
    except AnsibleFilterTypeError:
        assert True



# Generated at 2022-06-25 09:24:20.873408
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    test_list = ['a','c','b','c','a','a','d','b','c','d']
    assert filter_module.filters()['unique'](test_list) == ['a','c','b','d']


# Generated at 2022-06-25 09:24:22.917647
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([1, 2, 3, 4]) == 4


# Generated at 2022-06-25 09:24:29.167701
# Unit test for function min
def test_min():
    filter_module_min = FilterModule()
    all_filters_min = filter_module_min.filters()
    min_ = all_filters_min.get('min')

    for test_list in ([1, 2, 6, 2, -1, 1, 3], (1, 2, 6, 2, -1, 1, 3)):
        data = test_list
        expected = -1
        actual = min_(data)
        assert actual == expected, "Expected {0} but got {1}".format(expected, actual)


    # test with keyword args
    min_kwargs = {'attr': 'y'}
    test_list = [{'x': 1, 'y': 3}, {'x': 1, 'y': 2}]
    data = test_list

# Generated at 2022-06-25 09:24:31.494096
# Unit test for function min
def test_min():
    filter_min = FilterModule()
    assert filter_min.filters()['min']([-5, -3, -10, -3]) == -10



# Generated at 2022-06-25 09:24:38.070494
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()
    filter_method = filter_module.filters()['rekey_on_member']
    test_data = [
        {'first_key': 1, 'second_key': 2, 'third_key': 3},
        {'first_key': 4, 'second_key': 5, 'third_key': 6},
        {'first_key': 7, 'second_key': 8, 'third_key': 9},
    ]

    # Test valid key
    assert {1: {'first_key': 1, 'second_key': 2, 'third_key': 3},
            4: {'first_key': 4, 'second_key': 5, 'third_key': 6},
            7: {'first_key': 7, 'second_key': 8, 'third_key': 9}} == filter

# Generated at 2022-06-25 09:24:41.862788
# Unit test for function max
def test_max():
    assert max(range(1, 5)) == 4


# Generated at 2022-06-25 09:24:49.832823
# Unit test for function human_readable
def test_human_readable():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['human_readable']('524288') == '512K'
    assert filter_module_1.filters()['human_readable']('1048576') == '1M'
    assert filter_module_1.filters()['human_readable']('10485760') == '10M'
    assert filter_module_1.filters()['human_readable']('1073741824') == '1G'
    assert filter_module_1.filters()['human_readable']('10737418240') == '10G'
    assert filter_module_1.filters()['human_readable']('1099511627776') == '1T'

# Generated at 2022-06-25 09:24:54.720347
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([4,6,2,6,1,6]) == 6


# Generated at 2022-06-25 09:24:59.375524
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()

    data_0 = [1, 2, 3]
    expected_0 = 1
    actual_0 = filter_module_0.filters()['min'](filter_module_0, data_0, key=lambda x: x)
    assert(actual_0 == expected_0)


# Generated at 2022-06-25 09:25:02.081884
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['min']([1, 2, 3])
    assert result == 1


# Generated at 2022-06-25 09:25:47.531520
# Unit test for function max
def test_max():

    filter_module = FilterModule()
    try:
        assert filter_module.filters()['max']([1, 2, 3, 4]) == 4
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-25 09:25:53.844441
# Unit test for function max
def test_max():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['max']([1, 2, 3, 4]) == 4
    assert filter_module_1.filters()['max']((1, 2, 3, 4)) == 4
    assert filter_module_1.filters()['max']({1, 2, 3, 4}) == 4


# Generated at 2022-06-25 09:25:57.595619
# Unit test for function min
def test_min():
    test_filter_module = FilterModule()
    assert test_filter_module.filters()['min']([2, 3, 1]) == 1
    assert test_filter_module.filters()['min']([2, 3, 1], attribute="value") is None


# Generated at 2022-06-25 09:26:06.061090
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # Test on a dict of dicts
    filter_module = FilterModule()
    data = {'Dict1': {'name':'kyle', 'age':29, 'phone':'206-555-9876'},
            'Dict2': {'name':'brian', 'age':44, 'phone':'206-555-1111'},
            'Dict3': {'name':'mark', 'age':27, 'phone':'206-555-9876'},
            'Dict4': {'name':'steve', 'age':22, 'phone':'206-555-9877'},
            'Dict5': {'name':'steve', 'age':22, 'phone':'206-555-9877'}}


# Generated at 2022-06-25 09:26:12.028668
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    a = [1,2,2,2,2,2,3,4,5,6,7,7,7,8,8,8,8]
    b = [{"a": 1, "b": 2}, {"a": 2, "b": 2}, {"a": 3, "b": 3}]
    c = [{"a": 1, "b": 2}, {"a": 2, "b": 2}, {"a": 3, "b": 3}, {"a": 1, "b": 2}]
    d = [1, 2, 3, 2, 4, 2, 5, 2, 6, 2, 7, 2, 8, 2, 9, 2, 10]
    e = [{'b': 'hi'}, {'a': 'hello'}, {'a': 'hello'}]


# Generated at 2022-06-25 09:26:22.743295
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter_module = FilterModule()

    # Rekey a dict of dicts
    d = [
        {'one': 1, 'two': 2, 'three': 3},
        {'two': 2, 'three': 3, 'four': 4},
    ]
    assert filter_module.filters()['rekey_on_member'](data=d, key='one') == {
        1: {'one': 1, 'two': 2, 'three': 3},
    }
    assert filter_module.filters()['rekey_on_member'](data=d, key='two') == {
        2: {'two': 2, 'three': 3, 'four': 4},
    }

# Generated at 2022-06-25 09:26:29.642623
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['min']([1, 2, 3, 4, 5])
    assert result == 1
    result = filter_module_0.filters()['min'](['1', '2', '3', '4', '5'])
    assert result == '1'


# Generated at 2022-06-25 09:26:34.614051
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()

    assert filter_module_0.filters()['min']([1, 2, 3]) == 1
    assert filter_module_0.filters()['min']([2, 3, 1]) == 1
    assert filter_module_0.filters()['min'](['a', 'c', 'b']) == 'a'
    # assert filter_module_0.filters()['min'](['c', 'a', 'b']) == 'a'
    assert filter_module_0.filters()['min']([]) is None


# Generated at 2022-06-25 09:26:39.021455
# Unit test for function min
def test_min():
    filter_module_min = FilterModule()
    filter_module_min.filters()["min"]([10, 2, 1, 99])
    filter_module_min.filters()["min"]([10, 2, 1, 99, -1])
    filter_module_min.filters()["min"]([-1, -2, -3])


# Generated at 2022-06-25 09:26:47.181944
# Unit test for function unique

# Generated at 2022-06-25 09:28:02.902227
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1, 2, 3]) == 1
    assert filter_module_0.filters()['min']((1, 2, 3)) == 1
    assert filter_module_0.filters()['min']([[1], [2], [3]]) == [1]
    assert filter_module_0.filters()['min']([{'foo': 1}, {'foo': 2}], attribute='foo') == {'foo': 1}
    assert filter_module_0.filters()['min']([{'foo': 1}, {'foo': 2}], 'foo') == {'foo': 1}


# Generated at 2022-06-25 09:28:10.036011
# Unit test for function max
def test_max():

    # Tests for max with lists
    list_0 = [4, 3, 9, 5, 1]
    list_1 = ['a', 'b', 'c', 'd', 'e']
    list_2 = [1.1, 3.2, 4.2, 9.8]

    assert max(list_0) == 9
    assert max(list_1) == 'e'
    assert max(list_2) == 9.8

    # Tests for max with dictionaries
    dict_0 = {'a': 10, 'b': 20, 'c': 30}
    dict_1 = {'a': 2.2, 'b': 4.5, 'c': 9.8}
    dict_2 = {'a': 'abc', 'b': 'bcd', 'c': 'efghi'}

# Generated at 2022-06-25 09:28:20.875771
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test with a map of maps
    map_of_maps = {
        "key_1": {"name": "value1", "key": "key_1"},
        "key_2": {"name": "value2", "key": "key_2"},
        "key_3": {"name": "value3", "key": "key_3"},
    }
    assert(rekey_on_member(map_of_maps, "name") == {
        "value1": {"name": "value1", "key": "key_1"},
        "value2": {"name": "value2", "key": "key_2"},
        "value3": {"name": "value3", "key": "key_3"},
    })

# Generated at 2022-06-25 09:28:29.935595
# Unit test for function min
def test_min():
    filter_module = FilterModule()

    # Test min with a list
    results = filter_module.filters()['min']([5, 6, 7])
    assert results == 5
    results = filter_module.filters()['min']([5, 6, 7, 4, 3, 2, 1])
    assert results == 1
    results = filter_module.filters()['min'](['five', 'six', 'seven'])
    assert results == 'five'

    # Test min with a list of dicts
    results = filter_module.filters()['min']([{'a': 1}, {'a': 2}, {'a': 3}], attribute='a')
    assert results == {'a': 1}

# Generated at 2022-06-25 09:28:30.959000
# Unit test for function min
def test_min():
    assert min(10, 20, 30) == 10
    assert min([10, 20, 30]) == 10
    assert min(10) == 10



# Generated at 2022-06-25 09:28:33.581579
# Unit test for function max
def test_max():
    if HAS_MIN_MAX:
        filter_module_0 = FilterModule()
        assert filter_module_0.filters()['max']([1, 2, 3, 4, 5, 6, 8, 9, 10]) == 10


# Generated at 2022-06-25 09:28:38.397386
# Unit test for function min
def test_min():
    test_filter_module = FilterModule()
    test_filter_obj = test_filter_module.filters()['min']

    assert test_filter_obj([4, 8, 2, 1]) == 1
    assert test_filter_obj([4, 8, 2, 1], 'value') == 4
    assert test_filter_obj([4, 8, 2, 1], attribute='value') == 4



# Generated at 2022-06-25 09:28:45.401350
# Unit test for function max
def test_max():
    # Our test input
    input_list = [4, 0, 2, 78, -1]
    # Our correct output
    correct_output = 78
    # Initialise our jinja2 filters
    filter_module_0 = FilterModule()
    # Our test output
    test_output = filter_module_0.filters()['max'](input_list)
    # Assert that our output is correct
    assert(test_output == correct_output), 'Here is the test_output: %s, and this is the correct_output: %s.' % (test_output, correct_output)


# Generated at 2022-06-25 09:28:52.381101
# Unit test for function unique
def test_unique():
    filter_module_1 = FilterModule()
    obj = [1, 4, 2, 3, 2, 1, 1, 4]
    obj_actual = filter_module_1.filters['unique'](obj)
    obj_expected = [1, 4, 2, 3]
    assert obj_actual == obj_expected, 'test_unique: obj_actual "%s" != obj_expected "%s"' % (obj_actual, obj_expected)


# Generated at 2022-06-25 09:28:55.568032
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
