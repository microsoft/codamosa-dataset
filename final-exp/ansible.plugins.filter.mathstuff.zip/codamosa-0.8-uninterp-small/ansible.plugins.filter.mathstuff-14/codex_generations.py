

# Generated at 2022-06-25 09:20:07.090570
# Unit test for function unique
def test_unique():

    # Should preserve empty list if supplied
    assert unique([]) == []

    # Should preserve single-element list if just the element
    assert unique([10]) == [10]

    # Should preserve single-element list if just the element (in list)
    assert unique([[10]]) == [[10]]

    # Should preserve single-element list if just the element (in list)
    assert unique([[10, 15]]) == [[10, 15]]

    # Should preserve multiple-element list if elements are not duplicated
    assert unique([10, 15]) == [10, 15]

    # Should preserve multiple-element list if elements are not duplicated
    assert unique([[10, 15], [20, 25]]) == [[10, 15], [20, 25]]

    # Should preserve multiple-element list if elements are not duplicated

# Generated at 2022-06-25 09:20:15.011290
# Unit test for function min
def test_min():
    # Test that min works with different types
    assert min('test', 'aest') == 'aest'
    assert min(5, 8) == 5
    assert min(5, 8, 4, 3) == 3

    # Test that min works with different key types
    assert min(8, [5, 4, 1]) == [5, 4, 1]
    assert min('test', {'a': 'e'}, key=lambda k: k['a']) == {'a': 'e'}

    # Test that min works with different attribute types
    assert min(100, 23, key=lambda x: str(x)) == 23
    assert min('test', {'a': 'e'}, attribute=lambda k: k['a']) == {'a': 'e'}

    # Test that min raises an error if key and attribute are used together

# Generated at 2022-06-25 09:20:23.819397
# Unit test for function rekey_on_member

# Generated at 2022-06-25 09:20:33.107425
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [
        {'original-key': 'foo', 'other-key': 1, 'single-key': 'foo'},
        {'original-key': 'bar', 'other-key': 2, 'single-key': 'bar'},
        {'original-key': 'baz', 'other-key': 3, 'single-key': 'baz'},
    ]

    ansible_filters = FilterModule()

    # Ensure that a dict can be rekeyed on an existing key
    result = ansible_filters.filters()['rekey_on_member'](data, 'original-key')

# Generated at 2022-06-25 09:20:39.323688
# Unit test for function max
def test_max():
    assert max([0, 1, 2, 3, 4, 5, 6, 7]) == 7
    assert max([0, 1, 2, 3, 4, 5, 6, 7], default=None) == 7
    assert max([1, 2, 3, 4, 5, 6, 7, 8, 9], 5) == 9
    assert max([1, 2, 3, 4, 5, 6, 7, 8, 9], default=5) == 9
    assert max(['g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p'], 'g') == 'p'
    assert max(['g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p'], default='g') == 'p'


# Generated at 2022-06-25 09:20:40.441438
# Unit test for function max
def test_max():
    assert max(1,2) == 2, "Max not determined correctly in filter"


# Generated at 2022-06-25 09:20:47.065862
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Tests using dict
    existing_data = {
        'host1.example.com': {
            'hostname': 'host1.example.com',
            'foo': 'bar',
            },
        'host2.example.com': {
            'hostname': 'host2.example.com',
            'foo': 'baz',
            },
        'host3.example.com': {
            'hostname': 'host3.example.com',
        }
    }

    key = 'hostname'

    assert rekey_on_member(existing_data, key) == existing_data

    with pytest.raises(AnsibleFilterError, match="Key foo was not found"):
        rekey_on_member(existing_data, 'foo')

    # Tests using list

# Generated at 2022-06-25 09:20:56.473527
# Unit test for function max
def test_max():

    # Filter starting with hashable types
    my_dict = {"a": 1, "b": 2, "c": 4}
    my_list = [1, 5, 2, 8]
    my_tuple = (1, 5, 2, 8)

    assert max(my_dict) == 'c'
    assert max(my_list) == 8
    assert max(my_tuple) == 8

    # Filter starting with unhashable types
    my_set = {1, 5, 2, 8}
    my_list = [{"a":1}, {"a":5}, {"a":2}, {"a":8}]
    my_dict = {"a": {"a":1}, "b": {"a":5}, "c": {"a":2}, "d": {"a":8}}

# Generated at 2022-06-25 09:20:59.070902
# Unit test for function logarithm
def test_logarithm():
    bytes_0 = b'\x01\x84\xaf\x92\x96\xa2'
    var_0 = logarithm(bytes_0)
    assert var_0 == -1


# Generated at 2022-06-25 09:21:03.611545
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 2, 1]) == [1, 2, 3]



# Generated at 2022-06-25 09:21:17.223031
# Unit test for function human_readable

# Generated at 2022-06-25 09:21:18.808013
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4, "Function max is not working as expected"
    assert max(1, 2, 3, 4) == 4, "Function max is not working as expected"


# Generated at 2022-06-25 09:21:25.048559
# Unit test for function max
def test_max():
    assert max([1]) == 1
    assert max([1,2,3]) == 3
    try:
        assert max([])
    except ValueError:
        # We do not test for a Exception type because ValueError is derived from
        # Python2.X and Python3.X
        pass


# Generated at 2022-06-25 09:21:36.186998
# Unit test for function logarithm
def test_logarithm():
    try:
        assert(logarithm(4.0, base=2.0) == 2.0)
        assert(logarithm(1000.0, base=10.0) == 3.0)
        assert(logarithm(64.0, base=8.0) == 3.0)
        assert(logarithm(64.0, base=2.0) == 6.0)
        assert(logarithm(64.0, base=1.0) == 64.0)
        assert(logarithm(16, base=2) == 4)
        assert(logarithm(16, base=16) == 1)
    except (TypeError, ValueError) as e:
        raise Exception("Exception in test_logarithm: %s" % e)


# Generated at 2022-06-25 09:21:47.973461
# Unit test for function symmetric_difference
def test_symmetric_difference():
    elem_0 = [b'\x00', b'\x00', b'\x00', b'\x00', b'\x00']
    elem_0 = set(elem_0)

# Generated at 2022-06-25 09:21:57.124395
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(1) == '1 B'
    assert human_readable(1.5) == '1.5 B'
    assert human_readable(1024) == '1.0 KiB'
    assert human_readable(1024, unit='MB') == '0.0 MB'
    assert human_readable(1024, unit='KiB') == '1.0 KiB'
    assert human_readable(1024 * 1024 * 1024 * 1.2) == '1.2 GiB'
    assert human_readable(1024 * 1024 * 1024 * 1.2, unit='MiB') == '1279.0 MiB'
    assert human_readable(1024 * 1024 * 1024 * 1.2, unit='MiB', isbits=False) == '1279.0 MiB'
   

# Generated at 2022-06-25 09:22:06.130361
# Unit test for function symmetric_difference
def test_symmetric_difference():
    l_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    l_1 = [0, 2, 4, 6, 8]
    l_2 = [1, 3, 5, 7, 9]

    assert(symmetric_difference(l_0, l_1) == [1, 3, 5, 7, 9])
    assert(symmetric_difference(l_0, l_2) == [0, 2, 4, 6, 8])
    assert(symmetric_difference(l_1, l_2) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

    s_0 = set(l_0)
    s_1 = set(l_1)
    s_2 = set(l_2)

# Generated at 2022-06-25 09:22:11.267765
# Unit test for function max
def test_max():
    assert max(1,2) == 2
    assert max([1,2]) == 2
    assert max([-3,3]) == 3


# Generated at 2022-06-25 09:22:12.797361
# Unit test for function power
def test_power():
    x = 3
    y = 4
    assert power(x, y) == 81


# Generated at 2022-06-25 09:22:19.636453
# Unit test for function max
def test_max():
    # Dictionaries
    var_1 = max({ 0: 99, 1: 1, 2: 0, 3: 99 })
    assert var_1 == 99, "max() should return 99"

    # Strings
    var_2 = max('12345')
    assert var_2 == '5', "max() should return 5"

    # Strings and numbers mixed in a list
    var_3 = max([1, '5', 2, 'abc', 0])
    assert var_3 == 'abc', "max() should return abc"

    # Mixed types in a list
    var_4 = max([1, '5', [2, 3], 'abc', 0])
    assert var_4 == 'abc', "max() should return abc"


# Generated at 2022-06-25 09:22:26.601090
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 3, 2]) == 1
    assert min(['bar', 'foo']) == 'bar'
    assert min(['bar', 'foo', 'baz']) == 'bar'


# Generated at 2022-06-25 09:22:31.646633
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == set(symmetric_difference([1, 2, 3, 4, 5], [5, 6, 7, 8, 9, 10]))
    assert set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == set(symmetric_difference([5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5]))

    assert set([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == set(symmetric_difference(set([1, 2, 3, 4, 5]), [5, 6, 7, 8, 9, 10]))

# Generated at 2022-06-25 09:22:34.251004
# Unit test for function max
def test_max():
    value = max([1, 2, 3, 4])
    assert value == 4


# Generated at 2022-06-25 09:22:42.290773
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 2, 3, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 2, 3, 3], [2, 3, 4, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 2, 3, 3, 4], [2, 3, 4, 4, 5, 5]) == [1, 4, 5]

# Generated at 2022-06-25 09:22:49.369956
# Unit test for function min
def test_min():
    assert min([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == 0
    assert min([0, 1, 2, 3, 4, 5, 6, 7, 8, -9]) == -9
    assert min([0, 1, 2, 3, 4, 5, 6, -7, 8, 9]) == -7


# Generated at 2022-06-25 09:22:51.916106
# Unit test for function max
def test_max():
    list_0 = ['dog', 'cat', 'fish', 'dragon', 'hedgehog', 'deer']
    assert max(list_0) == 'fish'  # verify that max is working


# Generated at 2022-06-25 09:22:56.193271
# Unit test for function unique
def test_unique():
    a = [1, 2, 2, 3]
    b = [2, 1, 3]
    assert unique(a) == b


# Generated at 2022-06-25 09:23:05.041925
# Unit test for function min
def test_min():
    assert min([1, 1, 2]) == 1
    assert min([1, 2, 1]) == 1
    assert min(['a', 'b', 'c']) == 'a'
    assert min(['a', 'b', 'c', 'd']) == 'a'
    assert min([1, 1, 2, 'a']) == 1
    assert min([1, 1, 'b', 'a']) == 1
    assert min([1, 'a', 'b', 2]) == 1
    assert min(['a', 'b', 1, 2]) == 1
    assert min(['b', 'a', 1, 2]) == 1


# Generated at 2022-06-25 09:23:11.836526
# Unit test for function unique
def test_unique():
    assert unique([]) == [], 'Empty list should return empty list'
    assert unique([1, 1, 2, 3, 2, 3, 2, 1, 2]) == [1, 2, 3], 'Non-empty list should return correct list'
    assert unique([1, 1, 2, 3, 2, 3, 2, 1, 2], True) == [1, 2, 3], 'Non-empty list should return correct list'


# Generated at 2022-06-25 09:23:15.615322
# Unit test for function max
def test_max():
    arg = [1, 5, 3, 2]
    assert max(arg) == max(arg)


# Generated at 2022-06-25 09:23:24.381578
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(12345) == '12.1K'
    assert human_readable(16, False) == '0.0'


# Generated at 2022-06-25 09:23:26.609418
# Unit test for function symmetric_difference
def test_symmetric_difference():
    sym_diff = symmetric_difference(['a','b','c','d','e'], ['a','b','c','d','f'])
    assert sym_diff == ['e','f']



# Generated at 2022-06-25 09:23:32.151693
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert max([1, 2, 3], [1, 2, 3], key=len) == [1, 2, 3]
    assert max('foo', 'bar', 'baz') == 'foo'
    assert max(1, 2, 3) == 3
    assert max(b'foo', b'bar', b'baz') == b'foo'
    assert max(1.1, 2.2, 3.3) == 3.3
    assert max([[1, 2], [3, 4], [5, 6]], key=sum) == [5, 6]
    assert max(1, 2, 3, default='N/A') == 3
   

# Generated at 2022-06-25 09:23:42.785375
# Unit test for function max
def test_max():
    # Test for iterable as first argument
    assert max(range(5)) == 4, 'max of range(5) should be 4'
    assert max([1, 2, 3]) == 3, 'max of [1, 2, 3] should be 3'
    assert max(set([1, 2, 3])) == 3, 'max of set([1, 2, 3]) should be 3'
    assert max('python') == 'y', 'max of python should be y'

    # Test for iterable as second argument
    test_set = {'a', 'b', 'c', 'd', 'e'}
    assert max(test_set, key=lambda x: x) == 'e', 'max with key should be e'

# Generated at 2022-06-25 09:23:52.545805
# Unit test for function min
def test_min():
    assert min([
                ['a', 'c', 'd'],
                ['b', 'c'],
                ['a', 'd']
               ]) == ['a', 'c', 'd']
    assert min([
                ['b', 'c'],
                ['a', 'd'],
                ['a', 'c', 'd']
               ]) == ['a', 'c', 'd']
    assert min([
                ['b', 'c'],
                ['a', 'd'],
                ['a', 'd', 'e']
               ]) == ['a', 'd', 'e']



# Generated at 2022-06-25 09:23:58.255056
# Unit test for function max
def test_max():
    assert max([10, 25, 27, 40, 55], 6) == [6, 25, 27, 40, 55]
    assert max([10, 25, 27, 40, 55], 60) == [10, 25, 27, 40, 60]
    assert max([10, 25, 27, 40, 55], 15) == [15, 25, 27, 40, 55]


# Generated at 2022-06-25 09:24:03.163868
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert set([1, 2, 3]) == symmetric_difference([1,2,3,4], [3,5,7])
    assert set([1, 2, 3]) == symmetric_difference([3,5,7], [1,2,3,4])
    assert set([1, 2, 3, 4, 5, 7]) == symmetric_difference([1,2,3,4], [5,6,7])


# Generated at 2022-06-25 09:24:14.876295
# Unit test for function min
def test_min():
    ret0 = min([2, 3])
    assert ret0 == 2
    ret1 = min((2, 3))
    assert ret1 == 2
    ret2 = min({'a': 3, 'b': 2})
    assert ret2 == 2
    ret3 = min({'a': 3, 'b': 2}, attr='value')
    assert ret3 == 2
    ret4 = min({'a': 3, 'b': 2}, attr='value', key=lambda x: x.upper())
    assert ret4 == 3
    ret5 = min([3, 2])
    assert ret5 == 2
    ret6 = min([3, 2])
    assert ret6 == 2
    ret7 = min([3, 2], attr='value')
    assert ret7 == 2

# Generated at 2022-06-25 09:24:23.861599
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 2, 1, 4, 5], True) == [1, 2, 4, 5]
    assert unique([1, 2, 1, 2, 1, 4, 5], False) == [1, 2, 4, 5]
    assert unique([1, 2, 1.0, 2, 1, 4, 5], True) == [1, 2, 4, 5]
    assert unique([1, 2, 1.0, 2, 1, 4, 5], False) == [1, 2, 4, 5]
    assert unique([1, 2, '1', 2, 1, 4, 5], True) == [1, 2, '1', 4, 5]
    assert unique([1, 2, '1', 2, 1, 4, 5], False) == [1, 2, '1', 4, 5]
   

# Generated at 2022-06-25 09:24:29.979726
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]);
    assert min([10, 20, 30.5, 40, 50]) == 10;
    assert min(['a', 'c', 'b']) == 'a'
    assert min(['a', 'c', 'b']) == 'a'
    assert min(['a', 'A', 'B'], case_sensitive=False) == 'A'
    assert min(['a', 'A', 'B'], case_sensitive=True) == 'A'
    assert min( [[9, 'a'], [8, 'b']]) == [8, 'b']
    assert min( [[9, 'a'], [8, 'b']], attribute='0') == [8, 'b']

# Generated at 2022-06-25 09:24:55.043503
# Unit test for function human_to_bytes
def test_human_to_bytes():

    filter_module = FilterModule()
    assert filter_module.filters()['human_to_bytes']('1 kB') == 1000
    assert filter_module.filters()['human_to_bytes']('1 KB') == 1000
    assert filter_module.filters()['human_to_bytes']('1 kb') == 1000
    assert filter_module.filters()['human_to_bytes']('1 Kb') == 1000
    assert filter_module.filters()['human_to_bytes']('1 kb') == 1000
    assert filter_module.filters()['human_to_bytes']('2 ka') == 2000
    assert filter_module.filters()['human_to_bytes']('1 MB') == 1000000
    assert filter_module.filters()['human_to_bytes']('1 mb') == 1000000
   

# Generated at 2022-06-25 09:24:57.662408
# Unit test for function min
def test_min():
    assert 1 == min([1, 2, 3, 4, 5])


# Generated at 2022-06-25 09:24:59.600322
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']([1, 2, 5, 1, -5, 0, -2]) == -5


# Generated at 2022-06-25 09:25:04.687394
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 1
    assert filter_module_1.filters()['min']([-1]) == -1
    assert filter_module_1.filters()['min']([], default=0) == 0


# Generated at 2022-06-25 09:25:10.188606
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, 5]) == 5
    assert max([1, 2, 3, 5, 4]) == 5
    assert max([-1, -2, -3, -4, -5]) == -1


# Generated at 2022-06-25 09:25:20.624482
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module = FilterModule()

    # case 1: set1 is None, set2 is None
    # expect to return []
    set1 = None
    set2 = None
    result = filter_module.symmetric_difference(set1, set2)
    assert result == []

    # case 2: set1 is not None, set2 is None
    # expect to return set1
    set1 = [1, 2, 3, 4]
    set2 = None
    result = filter_module.symmetric_difference(set1, set2)
    assert result == set1

    # case 3: set1 is None, set2 is not None
    # expect to return set2
    set1 = None
    set2 = [1, 2, 3, 4]
    result = filter_module.symmetric_difference

# Generated at 2022-06-25 09:25:23.371155
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    # Call function
    result = filter_module_0.filters()['max']([1,2,7,4,0])
    assert result == 7



# Generated at 2022-06-25 09:25:30.813796
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters['max']([1, 2, 5, 3, 4]) == 5
    assert filter_module_0.filters['max']([2.4, 3.0, 5.0]) == 5
    assert filter_module_0.filters['max']([2.4, 3.0, 5]) == 5.0
    assert filter_module_0.filters['max'](['c', 'b', 'a', 'x', 'y']) == 'y'
    assert filter_module_0.filters['max'](['b', 'a', 'x', 'y'], attribute='lower') == 'y'



# Generated at 2022-06-25 09:25:42.481990
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    unique_filter = filter_module.filters()['unique']


# Generated at 2022-06-25 09:25:46.039666
# Unit test for function max
def test_max():
    assert max([1,2,3,4,5]) == 5


# Generated at 2022-06-25 09:26:34.456447
# Unit test for function unique
def test_unique():
    filter_module = FilterModule()
    assert filter_module.filters()['unique'] == unique



# Generated at 2022-06-25 09:26:43.061100
# Unit test for function rekey_on_member

# Generated at 2022-06-25 09:26:43.824822
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()


# Generated at 2022-06-25 09:26:50.626263
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data1 = {'asdf': {'foo': 123, 'name': 'bob'}, 'qwer': {'foo': 456, 'name': 'bill'}}
    data2 = [{'foo': 123, 'name': 'bob'}, {'foo': 456, 'name': 'bill'}]
    assert {'bob': {'foo': 123, 'name': 'bob'}, 'bill': {'foo': 456, 'name': 'bill'}} == rekey_on_member(data1, 'name')
    assert {'bob': {'foo': 123, 'name': 'bob'}, 'bill': {'foo': 456, 'name': 'bill'}} == rekey_on_member(data2, 'name')


# Generated at 2022-06-25 09:26:56.586112
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    input_0 = [1,3,5,2,4,6]
    result_0 = filter_module_0.filters()['max'](input_0)
    assert None != result_0
    assert result_0 == 6


# Generated at 2022-06-25 09:27:01.282113
# Unit test for function unique
def test_unique():
    data = ['red', 'white', 'black', 'white', 'blue', 'blue', 'black', 'red', 'red']
    case_sensitive = False
    attribute = None

    expected_results = ['red', 'white', 'black', 'blue']

    filter_module_0 = FilterModule()
    filters = filter_module_0.filters()
    assert filters.get('unique')(data, case_sensitive, attribute) == expected_results


# Generated at 2022-06-25 09:27:03.272757
# Unit test for function max
def test_max():
    filter_module_max = FilterModule()
    assert filter_module_max.filters()['max']([2, 3, 4, 5]) == 5, "Failure: max() returned incorrect value"


# Generated at 2022-06-25 09:27:12.864643
# Unit test for function min
def test_min():
    # Empty list
    assert [] == min([])
    # Numerical list
    assert 0 == min([1, 0, 3, -2])
    # String list
    assert 'a' == min(['b', 'a', 'c'])
    # List of complex items
    assert 'cat' == min(['cat', 'dog', 'ant'], key=len)
    # Provide an attribute key
    assert 'dog' == min([{'animal': 'cat'}, {'animal': 'dog'}], attribute='animal')


# Generated at 2022-06-25 09:27:20.575067
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['min']('test', 1) is False
    assert filter_module_0.filters()['min'](1,2) == 1
    assert filter_module_0.filters()['min']([1,2]) == 1
    assert filter_module_0.filters()['min']([1,2,3], 2) == 2
    assert filter_module_0.filters()['min']([1,2,3], reverse=True, attribute='age') == 3

# Generated at 2022-06-25 09:27:23.075342
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    assert filter_module.filters()['min']([1, 2, 3]) == 1
    assert filter_module.filters()['min']() == 2


# Generated at 2022-06-25 09:28:24.902077
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert max([1,2,3]) == 3


# Generated at 2022-06-25 09:28:27.160233
# Unit test for function min
def test_min():
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['min'](2, 3)
    assert result == 2


# Generated at 2022-06-25 09:28:28.725792
# Unit test for function max
def test_max():
    assert FilterModule().filters()['max']([1, 2, 3]) == 3


# Generated at 2022-06-25 09:28:30.251882
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1


# Generated at 2022-06-25 09:28:34.946838
# Unit test for function min
def test_min():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['min']([1, 4, 6, 7, 8, 10, 3, 2, 3]) == 1


# Generated at 2022-06-25 09:28:46.055534
# Unit test for function min

# Generated at 2022-06-25 09:28:56.552621
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    test_cases = [
        {'input': [10, 15, 20], 'want': 20},
        {'input': ['red', 'green', 'blue'], 'want': 'red'},
        {'input': [{'a': 10, 'b': 20}, {'a': 7, 'b': 3}, {'a': 4, 'b': 10}], 'want': {'a': 10, 'b': 20}},
    ]

    for test_case in test_cases:
        got = filter_module.filters()['max'](None, test_case['input'])
        assert got == test_case['want'], 'input was {0}, want {1}, got {2}'.format(test_case['input'], test_case['want'], got)

# Unit

# Generated at 2022-06-25 09:28:59.115264
# Unit test for function max
def test_max():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['max']([-2, 10, 3]) == 10


# Generated at 2022-06-25 09:29:01.741380
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    from ansible.module_utils._text import to_text
    assert filter_module.filters()['min']('foobar') == 'b'


# Generated at 2022-06-25 09:29:08.916791
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    # Test if inputs are valid.
    assert(filter_module.filters()["max"]("string"))

    # Test if inputs are valid.
    assert(filter_module.filters()["max"](25))

    # Test if inputs are valid.
    assert(filter_module.filters()["max"]([1, 2, 3, 4, 5]))
