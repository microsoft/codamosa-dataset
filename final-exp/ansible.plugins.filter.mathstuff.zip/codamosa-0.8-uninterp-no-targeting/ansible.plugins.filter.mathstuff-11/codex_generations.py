

# Generated at 2022-06-21 04:40:45.276393
# Unit test for function difference
def test_difference():
    '''
    Difference test cases
    '''
    from ansible.template import Templar

    template = Templar(None, loader=None)

    # simple list
    assert [2] == template.template("{{ [1,2,3,4,5]|difference([1,3,5]) }}")
    assert [] == template.template("{{ [1,2,3,4,5]|difference([1,2,3,4,5]) }}")
    assert [1,2,3,4,5] == template.template("{{ [1,2,3,4,5]|difference([]) }}")
    assert [1,2,3,4,5] == template.template("{{ [1,2,3,4,5]|difference(['a','b']) }}")

    # list of dict
   

# Generated at 2022-06-21 04:40:55.759883
# Unit test for function inversepower
def test_inversepower():
    # tests for correct values
    assert inversepower(4) == 2
    assert inversepower(4, 2) == 2
    assert inversepower(9, 3) == 2

    # tests for incorrect values
    try:
        inversepower(4, 0)
    except AnsibleFilterTypeError:
        pass
    except Exception:
        raise AssertionError("Exception raised is not AnsibleFilterTypeError")

    try:
        inversepower(-4, 2)
    except AnsibleFilterTypeError:
        pass
    except Exception:
        raise AssertionError("Exception raised is not AnsibleFilterTypeError")

    try:
        inversepower("aca")
    except AnsibleFilterTypeError:
        pass
    except Exception:
        raise AssertionError("Exception raised is not AnsibleFilterTypeError")

# Generated at 2022-06-21 04:41:06.779889
# Unit test for function intersect
def test_intersect():
    x = ['a', 'b', 'c']

    # expect a list
    assert set(intersect(None, x, x)) == set(['a', 'b', 'c'])

    assert set(intersect(None, x, x[1:])) == set(['b', 'c'])

    assert set(intersect(None, x, ['c', 'b', 'a'])) == set(['a', 'b', 'c'])

    assert set(intersect(None, x, ['b', 'a'])) == set(['a', 'b'])

    assert set(intersect(None, x, ['b', 'j'])) == set(['b'])

    assert set(intersect(None, x, ['j'])) == set([])



# Generated at 2022-06-21 04:41:09.633484
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fn = FilterModule()
    assert len(fn.filters()) > 0

# Generated at 2022-06-21 04:41:20.754005
# Unit test for function unique
def test_unique():
    assert unique(['a', 'b', 'b', 'c']) == ['a', 'b', 'c']
    assert unique(['a', 'A', 'b', 'B'], case_sensitive=False) == ['a', 'b']
    assert unique(['a', 'b', 'c'], case_sensitive=False) == ['a', 'b', 'c']
    with pytest.raises(AnsibleFilterError):
        unique(['a', 'b', 'c'], case_sensitive=None, attribute='foo')
    assert unique([{'a': 1, 'b': 2}, {'a': 1}], attribute=None) == [{'a': 1, 'b': 2}, {'a': 1}]

# Generated at 2022-06-21 04:41:28.325450
# Unit test for function unique
def test_unique():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    import jinja2

    assert unique((3, 2, 1, 2, 3)) == [3, 2, 1]
    assert unique(wrap_var(HostVars(dict(a=1, b=2, c=3, d=1, e=2, f=3)), 'vars')) == [1, 2, 3]

    class testObj():
        def __eq__(self, other):
            return id(self) == id(other)

    assert unique([testObj(), testObj(), testObj()]) == [testObj()]

    # Verify that it does not raise an error if an error occurs when using the
    # filter, yet fall back to the Ansible version

# Generated at 2022-06-21 04:41:30.539225
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-21 04:41:35.722662
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1099511627776) == u'1 T'
    assert human_readable(2**50) == u'1 PiB'
    assert human_readable(2**60) == u'1 EiB'


# Generated at 2022-06-21 04:41:47.445786
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1") == 1
    assert human_to_bytes("1T") == 1e12
    assert human_to_bytes("1000T") == 1e15
    assert human_to_bytes("1M") == 1e6
    assert human_to_bytes("1G") == 1e9
    assert human_to_bytes("1K") == 1e3
    assert human_to_bytes("1E") == 1e18
    assert human_to_bytes("1Z") == 1e21
    assert human_to_bytes("1Y") == 1e24
    assert human_to_bytes("1Ei") == 1.125e24
    assert human_to_bytes("1Pi") == 1.5e25
    assert human_to_bytes("1Ti") == 1.25e24
    assert human

# Generated at 2022-06-21 04:41:51.602040
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(9, 2) == 3
    assert inversepower(16, 2) == 4
    assert inversepower(9, -2) == 0.1111111111111111
    assert inversepower(16, -2) == 0.0625
    try:
        inversepower('a', 2)
        assert False
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:42:10.002154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()

    # general math
    assert isinstance(filters['min'], type(lambda: None))
    assert isinstance(filters['max'], type(lambda: None))

    # exponents and logarithms
    assert isinstance(filters['log'], type(lambda: None))
    assert isinstance(filters['pow'], type(lambda: None))
    assert isinstance(filters['root'], type(lambda: None))

    # set theory
    assert isinstance(filters['unique'], type(lambda: None))
    assert isinstance(filters['intersect'], type(lambda: None))
    assert isinstance(filters['difference'], type(lambda: None))

# Generated at 2022-06-21 04:42:20.513636
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('260B') == 260
    assert human_to_bytes('260b') == 260
    assert human_to_bytes('100KB') == 1024 * 100
    assert human_to_bytes('100MB') == 1024 * 1024 * 100
    assert human_to_bytes('100GB') == 1024 * 1024 * 1024 * 100
    assert human_to_bytes('1.6TB') == 1024 * 1024 * 1024 * 1024 * 1.6
    assert human_to_bytes('1.6TIB') == 1024 * 1024 * 1024 * 1024 * 1.6
    assert human_to_bytes('1.6TiB') == 1024 * 1024 * 1024 * 1024 * 1.6
    assert human_to_bytes('1.6tb') == 1024 * 1024 * 1024 * 1024 * 1.6

# Generated at 2022-06-21 04:42:24.809675
# Unit test for function difference
def test_difference():
    result = difference([1, 2, 3, 4, 5], [1, 3, 5])
    assert result == [2, 4]


# Generated at 2022-06-21 04:42:29.438966
# Unit test for function inversepower
def test_inversepower():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert(filters['root'](81) == 9)
    assert(filters['root'](9, 3) == 2)
    assert(filters['root'](2, 4) == 1.189207115)
    assert(filters['root'](-8, 3) == -2)

# Generated at 2022-06-21 04:42:33.360036
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(1, 1) == 1
    assert power(-3, -3) == -27

# Generated at 2022-06-21 04:42:35.400735
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-21 04:42:43.547392
# Unit test for function union
def test_union():
    # Load the union filter
    f = FilterModule().filters['union']

    # Validate input/output patterns
    assert f(range(3), range(3,7)) == list(range(7))
    assert f([[0,1],[2,3]], [[4,5]]) == [[0,1],[2,3],[4,5]]
    assert f([[0,1],[2,3]], [5]) == [[0,1],[2,3],5]
    assert f(range(3), range(3,7,3)) == [0,1,2,3,6]
    assert f([], []) == []
    assert f('a', 'b') == ['a', 'b']
    assert f([1], [2]) == [1,2]

# Generated at 2022-06-21 04:42:46.681858
# Unit test for function symmetric_difference
def test_symmetric_difference():
    input = [1,2,3,4]
    b = [3,4,5,6]
    result = [1,2,5,6]
    filtered = symmetric_difference(input, b)
    assert result == filtered
    return



# Generated at 2022-06-21 04:42:51.022228
# Unit test for function union
def test_union():
    # Test data
    data = [ [2, 3, 4, 3], [1, 2, 3, 4, 5, 6] ]
    expected_result = [ 1, 2, 3, 4, 5, 6 ]

    # Test execution
    filter_module = FilterModule()
    filters = filter_module.filters()
    result = filters['union'](filters, data)

    # Test assertion
    assert result == expected_result

# Generated at 2022-06-21 04:42:52.788967
# Unit test for function intersect
def test_intersect():
    env = {}
    a = [1, 2, 3, 4, 5]
    b = [3, 4, 5, 6, 7]
    c = [3, 4, 5]
    result = intersect(env, a, b)
    assert result == c



# Generated at 2022-06-21 04:43:20.695619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    # general math
    assert filters["min"]([1, 2, 3, 4, 5]) == 1
    assert filters["max"]([1, 2, 3, 4, 5]) == 5

    # exponents and logarithms
    assert filters["log"](10, base=10) == 1.
    assert filters["log"](10) == math.log(10)
    assert filters["pow"](10, 2) == 100.
    assert filters["root"](100, base=2) == 10.

    # set theory
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    b = [1, 4, 3, 7, 5, 6, 7, 8, 9, 10, 10]

# Generated at 2022-06-21 04:43:27.566149
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min(['a','b','c']) == 'a'
    assert min([1,'a','b']) == 'a'
    assert min([[1,4,3], [4,8,7], [3,4,5]]) == [1,4,3]


# Generated at 2022-06-21 04:43:42.766475
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import ansible
    import sys
    assert sys.version_info[0] == 2, "This unit test is not compatible with Python 3"

    def _assert(expected, data, key):
        result = ansible.utils.jinja.eval_filters({'rekey_on_member': rekey_on_member},
                                                  'rekey_on_member(data, key)', data, key=key)
        assert expected == result

    def _assert_no_error(data, key, duplicates='error'):
        result = ansible.utils.jinja.eval_filters({'rekey_on_member': rekey_on_member},
                                                  'rekey_on_member(data, key, duplicates=duplicates)',
                                                  data, key=key, duplicates=duplicates)

# Generated at 2022-06-21 04:43:54.957558
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from pprint import pprint

    f = FilterModule()


# Generated at 2022-06-21 04:44:00.503932
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10) == math.log(10)
    assert logarithm(10, 10) == math.log(10, 10)
    assert logarithm(1000, 10) == math.log(1000, 10)
    assert logarithm(1000000, 10) == math.log(1000000, 10)
    assert logarithm(10, 10) == math.log(10) / math.log(10)
    assert logarithm(1000, 10) == math.log(1000) / math.log(10)
    assert logarithm(1000000, 10) == math.log(1000000) / math.log(10)

    try:
        logarithm('test', 10)
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:44:03.215744
# Unit test for function human_to_bytes
def test_human_to_bytes():
    x = y = None
    try:
        x = human_to_bytes('1 KB', 'MiB')
        y = human_to_bytes('1 MiB', 'KB')
    except:
        pass

    assert x == 1048576
    assert y == 1024


# Generated at 2022-06-21 04:44:14.785083
# Unit test for function min
def test_min():
    test_list = [1.5, 1.7, 2.5]
    assert min(test_list) == 1.5
    assert min(test_list, attribute='value') == 1.5
    assert min(test_list, attribute='value', reverse=True) == 2.5
    test_dict = [{'value': 1.5}, {'value': 1.7}, {'value': 2.5}]
    assert min(test_dict) == 1.5
    assert min(test_dict, attribute='value') == 1.5
    assert min(test_dict, attribute='value', reverse=True) == 2.5


# Generated at 2022-06-21 04:44:27.630006
# Unit test for function union
def test_union():
    assert union((1, 2), (2, 3, 4)) == [1, 2, 3, 4]
    assert union([1, 2], (2, 3, 4)) == [1, 2, 3, 4]
    assert union((1, 2), [2, 3, 4]) == [1, 2, 3, 4]
    assert union([1, 2], [2, 3, 4]) == [1, 2, 3, 4]
    assert union((1, 2), (2, 3, 4, 1)) == [1, 2, 3, 4]
    assert union([1, 2], (2, 3, 4, 1)) == [1, 2, 3, 4]
    assert union((1, 2), [2, 3, 4, 1]) == [1, 2, 3, 4]

# Generated at 2022-06-21 04:44:42.113534
# Unit test for function unique
def test_unique():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __hash__(self):
            return hash(self.value)

        def __eq__(self, other):
            return self.value == other.value

    def test_unique_expected_result(filter_name, value, expected_result, case_sensitive=None, attribute=None):
        import jinja2
        env = jinja2.Environment()
        env.filters['unique'] = unique
        template = env.from_string('{{ %s|unique(%s) }}'
                                   % (value, ', '.join(filter(lambda x: x is not None,
                                                              ['case_sensitive=%s' % case_sensitive,
                                                               'attribute="%s"' % attribute]))))


# Generated at 2022-06-21 04:44:49.182135
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(0.0) == '0.00 B'
    assert human_readable(0.0, isbits=True) == '0.00 b'
    assert human_readable('0k') == '0.00 KB'
    assert human_readable('0K') == '0.00 KB'
    assert human_readable('0m') == '0.00 MB'
    assert human_readable('0M') == '0.00 MB'
    assert human_readable('0g') == '0.00 GB'
    assert human_readable('0G') == '0.00 GB'
    assert human_readable('0t') == '0.00 TB'
    assert human_readable('0T') == '0.00 TB'

# Generated at 2022-06-21 04:45:08.101132
# Unit test for function symmetric_difference
def test_symmetric_difference():

    from jinja2 import Environment

    env = Environment()

    expected_result = ['a', 'b', 'c']
    result = env.from_string("{{ ['a', 'b', 'c'] | symmetric_difference(['a', 'd', 'c']) }}").render()
    assert result == expected_result

    expected_result = ['a', 'b', 'c']
    result = env.from_string("{{ ['a', 'd', 'c'] | symmetric_difference(['a', 'b', 'c']) }}").render()
    assert result == expected_result

    expected_result = ['a', 'c']
    result = env.from_string("{{ ['a', 'c'] | symmetric_difference(['b', 'd']) }}").render()
    assert result == expected_result

   

# Generated at 2022-06-21 04:45:11.686462
# Unit test for function inversepower
def test_inversepower():
    from ansible.module_utils.common.text import formatters
    assert inversepower(4) == 2


# Unit tests for function product

# Generated at 2022-06-21 04:45:16.567974
# Unit test for function power
def test_power():
    assert power(1, 2) == 1
    assert power(2, 2) == 4
    assert power(2, 3) == 8
    assert power(2, -2) == 0.25
    assert power(2., 2) == 4.
    assert power(2., -2) == 0.25
    assert power(2, 0) == 1
    try:
        power(1, None)
    except AssertionError:
        pass
    else:
        assert False



# Generated at 2022-06-21 04:45:24.899294
# Unit test for function rekey_on_member
def test_rekey_on_member():
    testdata = {
        'good_data_dict': {
            'first': {'key': 'first', 'other': 'value'},
            'second': {'key': 'second', 'other': 'value'},
            'third': {'key': 'third', 'other': 'value'}
        },
        'good_data_list': [
            {'key': 'first', 'other': 'value'},
            {'key': 'second', 'other': 'value'},
            {'key': 'third', 'other': 'value'}
        ],
        'empty_collection': [],
        'empty_dict': {},
        'bad_key_dict': {'first': {}, 'second': {}},
        'bad_key_list': [{}, {}]
    }


# Generated at 2022-06-21 04:45:30.782738
# Unit test for function inversepower
def test_inversepower():
    # test inversepower
    assert inversepower(9) == 3.0
    assert inversepower(4,4) == 2.0
    assert inversepower(16,4) == 4.0
    assert inversepower(36,6) == 4.0


# Generated at 2022-06-21 04:45:40.316780
# Unit test for function inversepower
def test_inversepower():
    filter_obj = FilterModule()
    filters = filter_obj.filters()

    # Test result is correct
    result = filters['root'](27, 3)
    assert result == 3

    # Test a positive and a negative value
    result = filters['root'](-27, 3)
    assert result == -3

    # Test if the result is correct for a given base
    result = filters['root'](8, 2)
    assert result == 2

    # Test if error is raised for non numeric value
    try:
        filters['root']('a', 2)
    except AnsibleFilterTypeError as e:
        assert "root() can only be used on numbers" in to_text(e)
    else:
        assert False

    # Test if error is raised for invalid base

# Generated at 2022-06-21 04:45:46.712726
# Unit test for function power
def test_power():
    fm = FilterModule()
    func = fm.filters()['pow']
    assert func(2, 2) == 4
    assert func(5, 2) == 25
    assert func(-5, 2) == 25
    assert func(-5, 3) == -125
    assert func(2.0, 3) == 8.0

    try:
        func("2", "2")
        assert False
    except AnsibleFilterTypeError:
        assert True



# Generated at 2022-06-21 04:45:54.349742
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3
    assert max([1,2,3,4,5]) == 5
    assert max([-1,-2,-3]) == -1
    assert max([-1,-2,-3,0]) == 0
    assert max(['a','b','c']) == 'c'
    assert max(['a','b','c','d','e']) == 'e'


# Generated at 2022-06-21 04:45:55.006345
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-21 04:45:56.401819
# Unit test for function power
def test_power():
    assert power(2, 10) == 1024



# Generated at 2022-06-21 04:46:21.490000
# Unit test for function union
def test_union():
    a = [1, 2, 3]
    b = [4, 5, 6]
    assert union(a, b) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 04:46:25.289974
# Unit test for function difference
def test_difference():
    a = {1, 2, 3, 4}
    b = {1, 2, 5}
    assert difference(None, a, b) == {3, 4}

# Generated at 2022-06-21 04:46:40.380352
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils import basic
    import sys
    import inspect
    import json

    inst = FilterModule()

    # inject ansible's basic import
    basic._ANSIBLE_ARGS = None
    sys.modules['ansible.module_utils.basic'] = basic
    import ansible.module_utils.basic

    # instantiate ansible context
    context = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # construct the object
    class_filters = inst.filters

    # test the methods
    for fname, f in class_filters().items():
        display.display("testing: {}".format(fname))

# Generated at 2022-06-21 04:46:55.377258
# Unit test for function unique
def test_unique():
    '''
    test_unique:
    function: tests of function unique

    Notes:
    - This is a useful example of using Jinja inside an Ansible test
    - This is a simple test file, and does not completely exercise the function.
    - This also demonstrates the use of a Jinja environment and the
      Ansible "assert" module.
    - For more advanced tests, use the AnsibleTest framework.
    '''

    # Note: original_env is the Jinja2 environment that Jinja2 creates.
    #       The Ansible module always uses the same environment for all
    #       tests, and it does not reset it after each test.
    #       We can create a dummy env to test just this filter, though.
    original_env = globals().get('env', None)
    env = original_env.overlay()

    # Use a

# Generated at 2022-06-21 04:47:05.722955
# Unit test for function human_readable
def test_human_readable():
    # Test with default units
    assert human_readable(2**10) == '1024'
    # Test with specified units
    assert human_readable(2**32, unit='B') == '4.0 GiB'
    # Test with specified base 10 units as bytes
    assert human_readable(2**31, unit='B', isbits=False) == '2.0 GiB'
    # Test with specified base 2 units as bits
    assert human_readable(2**30, unit='b', isbits=True) == '1.0 GiB'
    # Test with unspecified units
    assert human_readable(2**15, unit=None) == '32.0 Ki'
    # Test with bad units, should fail without error
    assert human_readable(2**10, unit='bad') == '1024'
    # Test with bad base 10 units as

# Generated at 2022-06-21 04:47:10.518696
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1,2,3]
    b = [2,3,4]
    expected = [1, 4]
    assert symmetric_difference(None, a, b) == expected

# Generated at 2022-06-21 04:47:13.880161
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filtered = symmetric_difference([1, 2, 3], [2, 3, 4])
    assert filtered == [1, 4]

# Generated at 2022-06-21 04:47:22.874236
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.plugins import filter_loader
    import sys

    # Fake imports for unit test
    sys.modules['ansible'] = type('MockModule', (object,), {'errors': type('MockErrors', (object,), {
        'AnsibleFilterError': AnsibleFilterError,
        'AnsibleFilterTypeError': AnsibleFilterTypeError,
    })})
    sys.modules['ansible.module_utils.common'] = type('MockModule', (object,), {'text': type('MockText', (object,), {
        'formatters': formatters,
    })})

# Generated at 2022-06-21 04:47:37.675151
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 2, 1]) == [1, 2, 3]
    assert unique(['non', 'empty', 'string', 'non']) == ['non', 'empty', 'string']
    assert unique([u'unicode', u'string']) == [u'unicode', u'string']
    assert unique(['unicode', u'string']) == ['unicode', u'string']
    assert unique(['unicode', u'string'], True) == ['unicode', u'string']
    assert unique(['string', 'string'], True) == ['string']
    assert unique([(1, 2), (3, 4), (1, 2)]) == [(1, 2), (3, 4)]

# Generated at 2022-06-21 04:47:42.661955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['min'] == min

# Generated at 2022-06-21 04:48:48.251269
# Unit test for function min
def test_min():
    d = {'A':1, 'B':2, 'C':3}

    f = {'min': min, 'max': max}
    assert f['min'](d, 'A') == 1
    assert f['min'](d, 'B') == 2
    assert f['min'](d, 'C') == 3
    assert f['min'](d, 'D') == 0
    assert f['min'](d, 'D', default=23) == 23
    assert f['min'](d, 'D', default='Z') == 'Z'
    assert f['min'](d, 'D', default=[1]) == [1]

    # Test against function 'max'
    assert f['min'](d, 'A') <= f['max'](d, 'A')

# Generated at 2022-06-21 04:48:55.628615
# Unit test for function power
def test_power():

    assert power(2, 3) == 8
    assert power(2, -1) == 0.5
    assert power(2, 0) == 1



# Generated at 2022-06-21 04:49:09.432007
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == "0 B"
    assert human_readable(1) == "1 B"
    assert human_readable(2) == "2 B"
    assert human_readable(1, True) == "1 bit"
    assert human_readable(2, True) == "2 bits"
    assert human_readable(1024) == "1.0 KiB"
    assert human_readable(1024, True) == "1.0 Kibit"
    assert human_readable(1536) == "1.5 KiB"
    assert human_readable(1536, True) == "1.5 Kibit"
    assert human_readable(1536, False, 'm') == "1.5 mB"
    assert human_readable(1536, False, 'M') == "1.5 MB"
    assert human_

# Generated at 2022-06-21 04:49:16.871987
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.0Ki') == 1024
    assert human_to_bytes('1.0K') == 1000
    assert human_to_bytes('100B') == 100
    assert human_to_bytes('1.0Mi') == 1048576
    assert human_to_bytes('1.0M') == 1000000
    assert human_to_bytes('1.0Gi') == 1073741824
    assert human_to_bytes('1.0G') == 1000000000
    assert human_to_bytes('1.0Ti') == 1099511627776
    assert human_to_bytes('1.0T') == 1000000000000


# Generated at 2022-06-21 04:49:28.345832
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(100000000) == "95.4M"
    assert human_readable(185318531853) == "1.7T"
    assert human_readable(1024, isbits=True) == "1.0K"
    assert human_readable(3072, isbits=True) == "3.0K"
    assert human_readable(1024, unit="M") == "0.0M"
    assert human_readable(185318531853, unit="M") == "1783.3M"
    assert human_readable(10000, unit="KMGTPEZY") == "9.8K"
    assert human_readable(3072, unit="BKMGTPEZY", isbits=True) == "3.0K"



# Generated at 2022-06-21 04:49:38.905689
# Unit test for function min
def test_min():
    environment = {}

    # Testing a list of integers
    assert min(environment, [1, 2, 3]) == 1
    assert min(environment, [1, 2, 3], 2) == 2

    # Testing a list of strings
    assert min(environment, ["a", "b", "c"]) == "a"
    assert min(environment, ["a", "b", "c"], "b") == "b"

    # Testing a Hashable (set)
    assert min(environment, {1, 2, 3}) == 1
    assert min(environment, {1, 2, 3}, 2) == 2

    # Testing a dictionary
    assert min(environment, {1: "a", 2: "b", 3: "c"}) == 1
    assert min(environment, {1: "a", 2: "b", 3: "c"}, 2)

# Generated at 2022-06-21 04:49:50.600506
# Unit test for function unique
def test_unique():
    environment = type('', (), dict(name='ansible'))()
    environment.__dict__['filters'] = {}


# Generated at 2022-06-21 04:49:55.104371
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert union([{'a': 1}], [{'b': 2}]) == [{'a': 1}, {'b': 2}]
    assert union([1, 2, 3], [1, 5, 6]) == [1, 2, 3, 5, 6]
    assert union([{'a': 1}, {'a': 3}], [{'a': 2}, {'b': 2}]) == [{'a': 1}, {'a': 3}, {'a': 2}, {'b': 2}]


# Generated at 2022-06-21 04:49:57.641753
# Unit test for function difference
def test_difference():
    assert [1, 2] == difference([1, 2, 3], [2, 3, 4])

# Generated at 2022-06-21 04:50:01.911688
# Unit test for function max
def test_max():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variable_manager=variable_manager)

    assert templar.template('{{ [1,2,3] | max }}') == 3
    assert templar.template('{{ [1,2,3] | max(attribute="name") }}') == 3

