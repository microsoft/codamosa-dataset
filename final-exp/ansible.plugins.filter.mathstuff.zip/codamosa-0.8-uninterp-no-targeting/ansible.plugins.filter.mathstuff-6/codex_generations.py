

# Generated at 2022-06-21 04:40:42.449842
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(15) == '15'
    assert human_readable(1023) == '1023'
    assert human_readable(1024) == '1.0K'
    assert human_readable(1536) == '1.5K'
    assert human_readable(1024 * 1024) == '1.0M'
    assert human_readable(1024 * 1024 * 1024) == '1.0G'
    assert human_readable(1024 * 1024 * 1024 * 1024) == '1.0T'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024) == '1.0P'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.0E'


# Generated at 2022-06-21 04:40:50.320059
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('1073741824') == '1.0GiB'
    assert human_readable('1024') == '1.0KiB'
    assert human_readable('1') == '1.0B'
    assert human_readable('-1') == '-1.0B'
    assert human_readable('1.1') == '1.1B'
    assert human_readable('1024', True) == '8.0Kib'
    assert human_readable('1024', False, 'K') == '1.0K'
    assert human_readable(1024) == '1.0KiB'
    assert human_readable(1024.0) == '1.0KiB'
    assert human_readable(8.0) == '8.0B'

# Generated at 2022-06-21 04:40:57.620915
# Unit test for function power
def test_power():
    assert power(2, 2) == 4
    assert power(2, -2) == 0.25
    assert power(2, 0) == 1
    assert power(2.5, 3) == 15.625
    assert power(2.5, -3) == 0.0256
    assert power(0, 4) == 0
    assert power(3, 0.5) == 1.7320508075688772
    assert power(3, -0.5) == 0.5773502691896257
    assert power(0, -0.5) == 0

# Generated at 2022-06-21 04:41:06.052641
# Unit test for function logarithm
def test_logarithm():

    f = FilterModule()

    # a no-op
    assert f.filters()['log']("1.0") == 0.0
    assert f.filters()['log'](1.0) == 0.0

    assert f.filters()['log']("10.0") == 1.0
    assert f.filters()['log'](10.0) == 1.0

    # results in an error
    try:
        f.filters()['log']("foo")
    except AnsibleFilterTypeError:
        pass
    except Exception:
        raise


# Generated at 2022-06-21 04:41:14.930652
# Unit test for function symmetric_difference
def test_symmetric_difference():
    module = AnsibleModule(argument_spec=dict(
        lista = dict(type='list', required=True),
        listb = dict(type='list', required=True),
    ))
    a = [1, 2, 3, 4, 5]
    b = [4, 5, 6, 7, 8]
    assert module.filters['symmetric_difference'](a, b) == [1, 2, 3, 6, 7, 8]



# Generated at 2022-06-21 04:41:21.193947
# Unit test for function logarithm
def test_logarithm():
    assert math.log(10) == logarithm(10)
    assert math.log(10, 2) == logarithm(10, 2)
    try:
        logarithm("test")
    except AnsibleFilterTypeError as e:
        assert 'can only be used on numbers' in str(e)



# Generated at 2022-06-21 04:41:28.204166
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test for rekey_on_member using a list and dict
    member_key = 'name'

    d1 = {'name': 'foo', 'age': 1}
    d2 = {'name': 'bar', 'age': 2}
    d3 = {'name': 'baz', 'age': 3}
    d4 = {'name': 'quux', 'age': 4}

    l1 = [d1, d2, d3, d4]
    new_dict1 = rekey_on_member(l1, member_key, 'overwrite')
    assert isinstance(new_dict1, dict)
    assert new_dict1 == {
        'foo': d1,
        'bar': d2,
        'baz': d3,
        'quux': d4,
    }

    #

# Generated at 2022-06-21 04:41:31.047839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-21 04:41:38.739268
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule().filters()

    from jinja2.environment import Environment
    e = Environment()
    e.filters.update(f)

    # test the log filter, which takes a base argument
    template = e.from_string('''{{ 100|log(10) }}''')
    output = template.render()
    assert output == "2.0"

    # test the floor() filter
    template = e.from_string('''{{ 100.5|floor }}''')
    output = template.render()
    assert output == "100"

    # test the ceil() filter
    template = e.from_string('''{{ 100.5|ceil }}''')
    output = template.render()
    assert output == "101"

    # test absolute value

# Generated at 2022-06-21 04:41:46.334050
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(64) == math.log(64)
    assert logarithm(64, 4) == math.log(64, 4)
    assert logarithm(64, 10) == math.log10(64)
    assert logarithm(math.exp(1)) == 1
    assert logarithm(math.exp(1), math.exp(1)) == 1
    assert logarithm(math.exp(2), math.exp(1)) == 2



# Generated at 2022-06-21 04:41:58.386123
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert (symmetric_difference('abcd', 'cdae') == ['a', 'b', 'e'])
    # Also test more than two items since it's implemented differently than difference()
    assert (symmetric_difference('abcde', 'cdae', 'aef') == ['b', 'e'])



# Generated at 2022-06-21 04:42:07.699909
# Unit test for function inversepower
def test_inversepower():
    f = FilterModule()
    filters = f.filters()
    assert filters['root'](16, 2) == 4
    assert filters['root'](16, 4) == 2
    assert filters['root'](16, 2) == 4
    assert filters['root'](16, 4) == 2
    assert filters['root'](9, 2) == 3
    try:
        filters['root'](-1, 2)
        assert False
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:42:10.618796
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3
    assert max([3,2,1], key=lambda x: -x) == 1


# Generated at 2022-06-21 04:42:20.716302
# Unit test for function unique
def test_unique():
    assert unique('foo') == ['foo']
    assert unique('foo') == ['foo']
    assert unique(['foo', 'bar']) == ['foo', 'bar']
    assert unique(['foo', 'bar', 'foo']) == ['foo', 'bar']
    assert unique(['a', 'b', 'a'], attribute='lower') == ['a', 'b']
    assert unique(['A', 'B', 'a'], case_sensitive=False) == ['A', 'B', 'a']
    assert unique(['A', 'B', 'a'], case_sensitive=True) == ['A', 'B', 'a']
    assert unique(['A', 'B', 'a', 'B'], case_sensitive=False, attribute='lower') == ['A', 'B', 'a']

# Generated at 2022-06-21 04:42:32.388151
# Unit test for function human_readable

# Generated at 2022-06-21 04:42:33.400592
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2

# Generated at 2022-06-21 04:42:42.265732
# Unit test for function symmetric_difference
def test_symmetric_difference():

    # Test various types of input
    a = ['a', 'b', 'c', 'd']
    b = ['c', 'd', 'e', 'f']
    diff = ['a', 'b', 'e', 'f']
    assert symmetric_difference(None, a, b) == diff

    d1 = dict(a=1, b=2, c=3)
    d2 = dict(c=3, d=4, e=5)
    diff = dict(a=1, b=2, d=4, e=5)
    assert symmetric_difference(None, d1, d2) == diff

    # Test string inputs
    a = 'abcd'
    b = 'cdef'
    diff = ['a', 'b', 'e', 'f']

# Generated at 2022-06-21 04:42:51.780148
# Unit test for function human_readable

# Generated at 2022-06-21 04:42:53.819679
# Unit test for constructor of class FilterModule
def test_FilterModule():
    foo_instance = FilterModule()
    assert isinstance(foo_instance, FilterModule)

# Unit tests for filters on the FilterModule

# Generated at 2022-06-21 04:43:02.897619
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(2) == '2.00B'
    assert human_readable(1024, False) == '1.02K'
    assert human_readable(1024, True) == '1.00K'
    assert human_readable(18446744073709551616, False) == '1.75Y'
    assert human_readable(18446744073709551616, True) == '1.61Y'
    assert human_readable(18446744073709551616, False, 'd') == '2.19d'
    assert human_readable(18446744073709551616, True, 'd') == '2.08d'
    assert human_readable(18446744073709551616, False, 'w') == '31.17w'

# Generated at 2022-06-21 04:43:10.483092
# Unit test for function symmetric_difference
def test_symmetric_difference():
    difference_list = symmetric_difference(None, [1,2,3,4], [3,4,5,6])
    assert difference_list == [1,2,5,6]

# Generated at 2022-06-21 04:43:23.201410
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # List of dicts
    # Test various key values
    data = [{'a': 5, 'b': 'foo'}, {'a': 1, 'b': 'bar'}, {'a': 9, 'b': 'baz'}]
    rst = rekey_on_member(data, 'a')
    assert rst == {1: {'a': 1, 'b': 'bar'}, 5: {'a': 5, 'b': 'foo'}, 9: {'a': 9, 'b': 'baz'}}
    rst = rekey_on_member(data, 'b')

# Generated at 2022-06-21 04:43:32.173194
# Unit test for function max
def test_max():
    import math

    assert max([1, 2, 3]) == 3
    assert max([1.1, 2.1, 1.2]) == 2.1
    assert max([1.1, 2.1, 1.2], key=int) == 1.1
    assert max([1.1, 2.1, 1.2], key=math.floor) == 1.1
    assert max([[0, 1], [1, 2], [3, 4]]) == [3, 4]
    assert max([[0, 1], [1, 2], [3, 4]], key=lambda x: x[1]) == [0, 1]
    assert max('a', 'b', 'c') == 'c'



# Generated at 2022-06-21 04:43:44.183742
# Unit test for function power
def test_power():
    assert math.pow(3, 4) == FilterModule().filters()['pow'](3, 4)
    assert math.pow(3, 4) == FilterModule().filters()['pow'](3., 4)
    assert math.pow(3., 4.) == FilterModule().filters()['pow'](3., 4.)
    assert math.pow(3, 4) == FilterModule().filters()['pow'](3., 4.)
    assert math.pow(3., 4) == FilterModule().filters()['pow'](3., 4)
    assert math.pow(3, 4) == FilterModule().filters()['pow'](3, 4.)
    assert math.pow(3., 4) == FilterModule().filters()['pow'](3, 4.)

# Unit

# Generated at 2022-06-21 04:43:52.118297
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert union([1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-21 04:44:01.665403
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2], [2, 3]) == [1, 3]
    assert symmetric_difference([1, 2, 2], [2, 3]) == [1, 3]
    assert symmetric_difference([1, 2], [3, 3]) == [1, 2, 3]
    assert symmetric_difference([1, 2], [1, 1]) == [2, 1]
    assert symmetric_difference([1, 2], [2, 1]) == []



# Generated at 2022-06-21 04:44:07.416342
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100, 10) == 2
    assert logarithm(2, 2) == 1
    assert logarithm(144, 12) == 2
    assert logarithm(1) == 0



# Generated at 2022-06-21 04:44:19.041176
# Unit test for function logarithm
def test_logarithm():
    # This will work with any base
    assert logarithm(1) == 0
    assert logarithm(2) == 1
    assert logarithm(3) == 1.098612288668110
    assert logarithm(9) == 2.1972245773362
    assert logarithm(27) == 3.295836866004330

    # Check against a specific base
    assert logarithm(1, 5) == 0
    assert logarithm(125, 5) == 3.000000000000
    assert logarithm(3, 3) == 1.0000000000000



# Generated at 2022-06-21 04:44:23.527668
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, 2) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(8, 3) == 2

# Unit tests for function human_to_bytes

# Generated at 2022-06-21 04:44:24.831234
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-21 04:44:43.271599
# Unit test for function unique
def test_unique():
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['__ansible_module_builtin__'] = True
    builtins.__dict__['__ansible_module__'] = True

    assert unique(None, [1, 3, 3]) == [1, 3]
    assert unique(None, [1, 1, 1]) == [1]
    assert unique(None, [1, 1, 1], case_sensitive=False) == [1]
    assert unique(None, ['a', 'a', 'A'], case_sensitive=False) == ['a']
    assert unique(None, ['a', 'a', 'A'], case_sensitive=True) == ['a', 'A']

    d = {'x': 'a', 'y': 'b', 'z': 'c'}


# Generated at 2022-06-21 04:44:45.407294
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2.0
    assert inversepower(4, 2) == 2.0
    assert inversepower(4, 3) == 1.5874010519681994

# Generated at 2022-06-21 04:44:58.556837
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # bytes
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1.1B') == 1
    assert human_to_bytes('1.01B') == 1
    assert human_to_bytes('.1kB') == 100
    assert human_to_bytes('1.1kB') == 1100
    assert human_to_bytes('1.01kB') == 1010
    assert human_to_bytes('.1MB') == 100000
    assert human_to_bytes('1.1MB') == 1100000
    assert human_to_bytes('1.01MB') == 1010000
    assert human_to_bytes('.1GB') == 100000000
    assert human_to_bytes('1.1GB') == 1100000000
    assert human_to_bytes('1.01GB') == 1010000000
   

# Generated at 2022-06-21 04:45:01.099878
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, -1, 0]) == 1
    assert max(['', 'a', 'ab']) == 'ab'


# Generated at 2022-06-21 04:45:01.958261
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm.filters

# Generated at 2022-06-21 04:45:13.379617
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    data = {"a": 1, "b": 2, "c": 3}

    # Mapping
    assert rekey_on_member(data, "a") == {"1": {"a": 1}}

    # Mapping with duplicates
    assert rekey_on_member(data, "a", "error") == {"1": {"a": 1}}
    assert rekey_on_member(data, "a", "overwrite") == {"1": {"a": 1}}

    # List
    assert rekey_on_member(list(data.items()), 1) == {"1": (1, 1)}

    # Error on non-existing key
    with pytest.raises(AnsibleFilterError):
        rekey_on_

# Generated at 2022-06-21 04:45:17.945468
# Unit test for function max
def test_max():
    assert max([1,2,3,4]) == 4
    assert max([4,3,2,1]) == 4
    assert max([0.1, 0.2, 0.3, 0.4]) == 0.4
    assert max([1+2j, 3+4j, 5+6j, 7+8j]) == 7+8j
    assert max(['10', '20', '30', '40']) == '40'
    assert max(['1', '2', '3', '4']) == '4'


# Generated at 2022-06-21 04:45:21.022882
# Unit test for function union
def test_union():
    assert union([1,2,3], [2,3,4]) == [1,2,3,4]
    assert union([1,2,3], [2,3,4]) != [1,2,3,4,5]


# Generated at 2022-06-21 04:45:35.180768
# Unit test for function symmetric_difference
def test_symmetric_difference():
    import jinja2

    # Test symmetric_difference as an environment filter
    env = jinja2.Environment()
    env.filters['symmetric_difference'] = symmetric_difference
    template = env.from_string("A={{a|symmetric_difference(b)|list}}")
    assert template.render(a=[1, 2, 3, 4], b=[3, 4, 5, 6]) == "A=[1, 2, 5, 6]"

    # Test symmetric_difference as a module filter
    jinja2.filters.FILTERS['symmetric_difference'] = symmetric_difference
    template = env.from_string("A={{a|symmetric_difference(b)|list}}")

# Generated at 2022-06-21 04:45:46.462210
# Unit test for function difference
def test_difference():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils._text import to_bytes

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-21 04:46:09.828630
# Unit test for function logarithm
def test_logarithm():
    f = FilterModule()
    assert f.filters()['log'](10) == math.log(10)
    assert f.filters()['log'](10, 10) == math.log10(10)
    assert f.filters()['log'](1, 10) == 0.0
    try:
        display.vvv(f.filters()['log']('10'))
        raise Exception('No exception raised')
    except AnsibleFilterTypeError as e:
        assert 'bad input:' in to_native(e)


# Generated at 2022-06-21 04:46:18.433663
# Unit test for function min
def test_min():
    assert FilterModule().filters()['min']([10, -5, 2, 4]) == -5
    assert FilterModule().filters()['min']([10.0, -5.0, 2.0, 4.0]) == -5.0
    assert FilterModule().filters()['min']([10, -5, 2, 4], '1') == 2
    assert FilterModule().filters()['min']([10, -5, 2, 4], '<') == 10
    assert FilterModule().filters()['min']([10, -5, 2, 4], '>') == -5
    assert FilterModule().filters()['min']([10, -5, 2, 4], attribute='_') == 10

# Generated at 2022-06-21 04:46:26.583244
# Unit test for function difference
def test_difference():
    assert difference([1, 2, 3], [3, 4, 5]) == [1, 2]
    assert difference([1, 2, 3], [1, 2, 3]) == []
    assert difference([1, 2, 3], [1, 2, 3, 4, 5]) == []
    assert difference([1, 2, 3], []) == [1, 2, 3]
    assert difference([], [1, 2, 3]) == []

# Generated at 2022-06-21 04:46:41.034012
# Unit test for function human_readable
def test_human_readable():
    check = human_readable(1)
    assert check == "1.00 B", "got %s" % check

    check = human_readable(1024)
    assert check == "1.00 KB", "got %s" % check

    check = human_readable(2048)
    assert check == "2.00 KB", "got %s" % check

    check = human_readable(2**20)
    assert check == "1.00 MB", "got %s" % check

    check = human_readable(2**20 + 2**19)
    assert check == "1.50 MB", "got %s" % check

    check = human_readable("2048")
    assert check == "2.00 KB", "got %s" % check

    check = human_readable("not a number")
    # note: human_readable() does

# Generated at 2022-06-21 04:46:45.279472
# Unit test for function unique
def test_unique():
    unique_list = unique([1,2,3,2,1,5,6,5,5,5])
    assert unique_list == [1, 2, 3, 5, 6]


# Generated at 2022-06-21 04:46:47.377140
# Unit test for function max
def test_max():
    assert max(3, 2) == 3


# Generated at 2022-06-21 04:46:48.870404
# Unit test for function power
def test_power():
    assert power(2,2) == 4

# Generated at 2022-06-21 04:46:55.741403
# Unit test for function intersect
def test_intersect():
    assert intersect(10, '10') == []
    assert intersect(range(10), '1') == ['1']
    assert intersect(range(10), 'b') == []
    assert intersect(range(2), range(10)) == [0, 1]
    assert intersect('abcd', 'bce') == ['b', 'c']



# Generated at 2022-06-21 04:46:58.520364
# Unit test for function max
def test_max():
    test_list = [1,2,3]
    assert max(None, test_list) == 3



# Generated at 2022-06-21 04:47:05.919042
# Unit test for function max
def test_max():
    f = FilterModule()
    assert f.filters()['max']([2, 8, 3, 4, 5]) == 8
    assert f.filters()['max']([2, 8, 3, 4, 5], 1) == 7
    assert f.filters()['max']([2, 8, 3, 4, 5], 2) == 6
    assert f.filters()['max']([2, 8, 3, 4, 5], 3) == 5
    assert f.filters()['max']([2, 8, 3, 4, 5], 4) == 4
    assert f.filters()['max']([2, 8, 3, 4, 5], 5) == 3
    assert f.filters()['max']([2, 8, 3, 4, 5], 6) == 2
    assert f.fil

# Generated at 2022-06-21 04:47:23.579319
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [{"a": "val1", "b": "val2", "c": "val3"}, {"a": "val4", "b": "val5", "c": "val6"}]

    # Test rekey_on_member on a list
    result = rekey_on_member(data, "a")
    assert result.keys() == set(["val1", "val4"])

    # Test rekey_on_member on a list - should throw error if member not in list
    data = [{"a": "val1", "b": "val2", "c": "val3"}, {"a": "val4", "b": "val5", "c": "val6"}]
    try:
        result = rekey_on_member(data, "d")
    except AnsibleFilterError as e:
        assert to

# Generated at 2022-06-21 04:47:31.666290
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) >= 25
    assert "min" in filters
    assert "max" in filters
    assert "log" in filters
    assert "pow" in filters
    assert "root" in filters
    assert "unique" in filters
    assert "intersect" in filters
    assert "difference" in filters
    assert "symmetric_difference" in filters
    assert "union" in filters
    assert "product" in filters
    assert "permutations" in filters
    assert "combinations" in filters
    assert "human_readable" in filters
    assert "human_to_bytes" in filters
    assert "rekey_on_member" in filters
    assert "zip" in filters
    assert "zip_longest" in filters
   

# Generated at 2022-06-21 04:47:34.504802
# Unit test for function intersect
def test_intersect():
    assert(intersect([1, 2, 3], [2, 3, 4]) == [2, 3])


# Generated at 2022-06-21 04:47:35.440354
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-21 04:47:39.763790
# Unit test for function min
def test_min():
    assert min(1, 2) == 1
    assert min(1, 2, 3) == 1
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: x ** 2) == 1
    assert min([1, 2, 3], key=lambda x: -x) == 3



# Generated at 2022-06-21 04:47:44.999406
# Unit test for function human_readable
def test_human_readable():
    filter = FilterModule()
    human_readable = filter.filters()['human_readable']

    assert human_readable(1000) == '1.00K'
    assert human_readable(1000, isbits=True) == '1.00Kb'
    assert human_readable(1000, unit='B') == '1000.00B'
    assert human_readable(1000, unit='B', isbits=True) == '1.00Kb'
    assert human_readable(1000, unit='b') == '1,000.00b'
    assert human_readable(1000, unit='b', isbits=True) == '1,000.00b'


# Generated at 2022-06-21 04:47:48.964793
# Unit test for function union
def test_union():
    """
    Test union function
    :return: None
    """
    a = [1, 2, 3, 4]
    b = [3, 4, 5, 6]
    result = union(a, b)
    assert result == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 04:47:50.740111
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-21 04:48:01.695326
# Unit test for function max
def test_max():
    import tempfile
    import subprocess
    import os
    import json

    # Set up jinja environment
    import jinja2
    env = jinja2.Environment()
    env.filters.update(FilterModule().filters())

    # create template and vars to pass to template
    template = '''{%- set var = [1,2,3,4,5] -%}
    {{ var | max }}
    '''
    temp_vars = dict(test_var=[1, 2, 3, 4, 5])

    # render template
    output = env.from_string(template).render()
    assert to_text(output) == u'5'



# Generated at 2022-06-21 04:48:13.678988
# Unit test for function intersect
def test_intersect():
    """
    >>> test_intersect()
    True
    """
    from ansible.module_utils.common._collections_compat import Mapping, Iterable
    from six import string_types
    from itertools import chain, izip_longest


# Generated at 2022-06-21 04:48:26.131582
# Unit test for function union
def test_union():
    ''' test union '''
    assert union([1, 2], [2, 3]) == [1, 2, 3]
    assert union([1], [2, 3]) == [1, 2, 3]
    assert union([], []) == []


# Generated at 2022-06-21 04:48:40.798419
# Unit test for function intersect
def test_intersect():
    assert [] == intersect([], [])
    assert [] == intersect([1, 2, 3], [])
    assert [] == intersect([], [1, 2, 3])
    assert [1, 2] == intersect([1, 2, 3], [1, 2])
    assert [1, 2] == intersect([1, 2, 3], [2, 1])
    assert [1, 2, 3] == intersect([1, 2, 3], [1, 2, 3])
    assert [1, 2, 3] == intersect([1, 1, 2, 2, 3, 3], [1, 2, 3])
    assert ['a', 'b', 'c'] == intersect('abc', 'cba')
    assert [] == intersect('abc', 'def')
    assert ['a', 'b', 'c'] == intersect('aabbccc', 'ccaabb')


# Generated at 2022-06-21 04:48:54.873997
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule().filters()['min'])
    assert callable(FilterModule().filters()['max'])
    assert callable(FilterModule().filters()['log'])
    assert callable(FilterModule().filters()['pow'])
    assert callable(FilterModule().filters()['root'])
    assert callable(FilterModule().filters()['unique'])
    assert callable(FilterModule().filters()['intersect'])
    assert callable(FilterModule().filters()['difference'])
    assert callable(FilterModule().filters()['symmetric_difference'])
    assert callable(FilterModule().filters()['union'])
    assert callable(FilterModule().filters()['product'])

# Generated at 2022-06-21 04:49:01.548440
# Unit test for function union
def test_union():
    test_input = [ ['A', 'B', 'C', 'D'], ['C', 'D', 'E', 'F'] ]
    expected = ['A', 'B', 'C', 'D', 'E', 'F']
    actual = union(None, *test_input)
    assert actual == expected, "union() filter returned %s instead of expected %s" % (actual, expected)

    test_input = [ ['A', 'B', 'C', 'D'], ['C', 'D', 'E', 'F'], ['Z', 'Y', 'X'] ]
    expected = ['A', 'B', 'C', 'D', 'E', 'F', 'Z', 'Y', 'X']
    actual = union(None, *test_input)

# Generated at 2022-06-21 04:49:04.483171
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100) == 4.605170185988092


# Generated at 2022-06-21 04:49:19.895502
# Unit test for function symmetric_difference
def test_symmetric_difference():
    sym_diff = [1, 2, 3, 4, 5, 6, 7]
    env = {}

    a1 = [1, 2, 3]
    b1 = [2, 3, 7]
    assert symmetric_difference(env, a1, b1) == [1, 4, 5, 6, 7]

    a2 = [1, 2, 3]
    b2 = [2, 3, 4, 5, 6, 7]
    assert symmetric_difference(env, a2, b2) == [1, 4, 5, 6, 7]

    a3 = [1, 2, 3, 4, 5, 6, 7]
    b3 = [2, 3, 4, 5]
    assert symmetric_difference(env, a3, b3) == [1, 6, 7]

    a

# Generated at 2022-06-21 04:49:28.325152
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2, "Error: root(4) should return 2"
    assert inversepower(8, 3) == 2, "Error: root(8, 3) should return 2"
    assert inversepower(4, 2) == 2, "Error: root(4, 2) should return 2"
    assert inversepower(0, 2) == 0, "Error: root(0, 2) should return 0"
    assert inversepower(64, 4) == 2, "Error: root(64, 4) should return 2"
    assert inversepower(256, 8) == 2, "Error: root(256, 8) should return 2"

# Generated at 2022-06-21 04:49:34.204422
# Unit test for function min
def test_min():
    assert min([-1, 42, 3, -2, 0]) == -2
    assert min([-1, 42, 3, -2, 0], attribute='real') == 42
    assert min([42, 41, '40', 39], attribute='real') == 39



# Generated at 2022-06-21 04:49:44.319666
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule().filters()
    assert filters['min'] == min
    assert filters['max'] == max
    assert filters['log'] == logarithm
    assert filters['pow'] == power
    assert filters['root'] == inversepower
    assert filters['unique'] == unique
    assert filters['intersect'] == intersect
    assert filters['difference'] == difference
    assert filters['union'] == union
    assert filters['symmetric_difference'] == symmetric_difference
    assert filters['product'] == itertools.product
    assert filters['permutations'] == itertools.permutations
    assert filters['combinations'] == itertools.combinations
    assert filters['human_readable'] == human_readable
    assert filters['human_to_bytes'] == human_to_bytes

# Generated at 2022-06-21 04:49:46.320015
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)


# Generated at 2022-06-21 04:50:11.874830
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['min'] is min
    assert filters['max'] is max
    assert filters['log'] is logarithm
    assert filters['pow'] is power
    assert filters['root'] is inversepower
    assert filters['unique'] is unique
    assert filters['intersect'] is intersect
    assert filters['difference'] is difference
    assert filters['symmetric_difference'] is symmetric_difference
    assert filters['union'] is union
    assert filters['product'] is itertools.product
    assert filters['permutations'] is itertools.permutations
    assert filters['combinations'] is itertools.combinations
    assert filters['human_readable'] is human_readable
    assert filters['human_to_bytes'] is human_to_bytes

# Generated at 2022-06-21 04:50:22.090533
# Unit test for function unique
def test_unique():
    sample = [{"a": 1}, {"b": 2}, {"a": 1}, {"c": 3}]

    # test for bug #18193
    assert unique(sample, case_sensitive=False) == sample

    if HAS_UNIQUE:
        # test that we can call Jinja2's unique filter with case_sensitive=False
        assert unique(sample, case_sensitive=False) == unique(sample)

    assert unique(sample) == [{"a": 1}, {"b": 2}, {"c": 3}]
    assert unique(sample, attribute="c") == [{"a": 1}, {"b": 2}]
    assert unique(sample, case_sensitive=False, attribute="a") == [{"b": 2}, {"c": 3}]