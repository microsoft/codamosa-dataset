

# Generated at 2022-06-21 04:40:36.818817
# Unit test for function max
def test_max():
    module = FilterModule()
    filters = module.filters()
    assert filters['max']([1, 2, 3, 4]) == 4

# Generated at 2022-06-21 04:40:46.595845
# Unit test for function intersect
def test_intersect():
    a = ['foo', 'bar', 'bar', 'fizz', 'buzz', 'foo', 'fizz']
    b = ['foo', 'bar', 'fizz', 'buzz', 'snoz']

    # test the intersect of two lists containing duplicates
    result = intersect(a, b)

    assert result == ['bar', 'foo', 'fizz', 'buzz'], "intersect({}, {}) returned {:} instead of {:}".format(a, b, result, ['bar', 'foo', 'fizz', 'buzz'])

# Generated at 2022-06-21 04:40:54.627763
# Unit test for function intersect
def test_intersect():

    f = FilterModule().filters()
    assert f['intersect']([1,2,3], [2,3,4]) == [2,3]
    assert f['intersect']({'a': 1, 'b': 2, 'c': 3}, {'b': 2, 'c': 3, 'd': 4}) == {'b': 2, 'c': 3}



# Generated at 2022-06-21 04:41:06.530845
# Unit test for function intersect
def test_intersect():
    data = dict(
        list_one=[
            dict(item="one"),
            dict(item="two"),
            dict(item="three"),
        ],
        list_two=[
            dict(item="two"),
            dict(item="three"),
            dict(item="four"),
        ],
        list_three=["two", "three"],
    )

    # Test parameter behavior
    with pytest.raises(AnsibleFilterError):
        list(intersect(data, "one", True))

    # Test with dicts
    assert list(intersect(data, data["list_one"], data["list_two"])) == [
        dict(item="two"),
        dict(item="three"),
    ]

    # Test with list of dicts

# Generated at 2022-06-21 04:41:07.679491
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

# Generated at 2022-06-21 04:41:16.061552
# Unit test for function inversepower
def test_inversepower():
    assert 1.0 == inversepower(1.0)
    assert 1.0 == inversepower(1.0, 2.0)
    assert 1.0 == inversepower(1.0, base=2.0)
    assert 1.0 == inversepower(1.0, base=2)
    # square root
    assert math.sqrt(4.0) == inversepower(4.0)
    assert math.sqrt(4.0) == inversepower(4.0, 2.0)
    assert math.sqrt(4.0) == inversepower(4.0, base=2.0)
    assert math.sqrt(4.0) == inversepower(4.0, base=2)
    # cube root
    assert 4.0 == inversepower(64.0, 3.0)
    assert 4.0 == inverse

# Generated at 2022-06-21 04:41:26.598345
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.compat.tests import unittest

    class TestHumanToBytes(unittest.TestCase):

        bytes_values = dict(
            B=1,
            KB=1000,
            KiB=1024,
            MB=1000**2,
            MiB=1024**2,
            GB=1000**3,
            GiB=1024**3,
            TB=1000**4,
            TiB=1024**4,
            PB=1000**5,
            PiB=1024**5,
            EB=1000**6,
            EiB=1024**6,
            ZB=1000**7,
            ZiB=1024**7,
            YB=1000**8,
            YiB=1024**8,
        )

        def setUp(self):
            pass


# Generated at 2022-06-21 04:41:37.066404
# Unit test for function union
def test_union():
    # Test some basic functionality that is known to work
    v1 = [1, 2]
    v2 = [1, 2, 3]
    v3 = [3, 4]
    assert union(None, v1, v2) == [1, 2, 3]
    assert union(None, v1, v2, v3) == [1, 2, 3, 4]
    assert union(None, v1, v1) == [1, 2]
    assert union(None, v2, v2) == [1, 2, 3]

    # Test with some non-list inputs
    assert union(None, v1, 2) == [1, 2]
    assert union(None, 1, v1) == [1, 2]
    assert union(None, v1, None) == [1, 2]

    # Test with

# Generated at 2022-06-21 04:41:48.014067
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping


# Generated at 2022-06-21 04:41:50.412208
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100) == math.log(100)
    assert logarithm(100, 10) == math.log10(100)



# Generated at 2022-06-21 04:42:07.898996
# Unit test for function symmetric_difference
def test_symmetric_difference():
    d = {'a': [1, 2, 3, 4],
         'b': [2, 3, 4, 5]}
    e = {'expected': [1, 5]}
    f = dict(ansible_symmetric_difference=(d, e))
    assert symmetric_difference(None, f['ansible_symmetric_difference'][0]['a'], f['ansible_symmetric_difference'][0]['b']) == f['ansible_symmetric_difference'][1]['expected']

# Generated at 2022-06-21 04:42:20.125230
# Unit test for function max
def test_max():
    from jinja2 import Template
    from jinja2.utils import undefined

    t1 = Template("{{ x|max }}")
    t2 = Template("{{ [1, 2, 3]|max }}")
    t3 = Template("{{ ['foo', 'bar', 'baz']|max }}")
    t4 = Template("{{ [1, 2, 3]|max(attribute='real') }}")

    assert t1.render(x=undefined) == ''
    assert t1.render(x=[]) == ''
    assert t1.render(x=[1, 2, 3]) == '3'
    assert t1.render(x=['foo', 'bar', 'baz']) == 'foo'

    assert t2.render() == '3'

    assert t3.render() == 'foo'

    assert t4

# Generated at 2022-06-21 04:42:28.530447
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]
    assert intersect([1], [2, 3, 4]) == []
    assert intersect([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert intersect([1, 2, 3], [3, 2, 1]) == [1, 2, 3]


# Generated at 2022-06-21 04:42:37.021673
# Unit test for function logarithm
def test_logarithm():
    # Test a variety of numbers in the function logarithm_filter
    assert logarithm(10) == 2.30258509299
    assert logarithm(1) == 0
    assert logarithm(10, 10) == 1
    assert logarithm(3.1) == 1.14472988585
    assert logarithm(100, 10) == 2


# Generated at 2022-06-21 04:42:45.763783
# Unit test for function symmetric_difference
def test_symmetric_difference():
    f = FilterModule()
    assert f.filters()['symmetric_difference']([2, 5, 4], [1, 6, 5]) == [2, 4, 6]
    assert f.filters()['symmetric_difference']([2, 5, 4], [5, 6, 5]) == [2, 4, 6]
    assert f.filters()['symmetric_difference']([2, 5, 4], [2, 1, 6, 5]) == [4, 6]
    assert f.filters()['symmetric_difference'](['a', 'b'], ['a', 'b', 'c']) == ['c']

# Generated at 2022-06-21 04:42:49.339339
# Unit test for function power
def test_power():
    assert power(1, 2) == 1



# Generated at 2022-06-21 04:42:51.433283
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1


# Generated at 2022-06-21 04:43:00.727577
# Unit test for function min
def test_min():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['min']([1, 6, 2, -1, 10]) == -1
    assert filters['min']([]) == None
    assert filters['min']([1, 2, 3], 2) == 2
    assert filters['min']('hello') == 'e'
    assert filters['min']('hello', 2) == 'e'
    assert filters['min']('hello', 5) == 'hello'
    assert filters['min']('hello', -1) == 'hello'



# Generated at 2022-06-21 04:43:13.471553
# Unit test for function union
def test_union():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

    results = []
    variable_manager.extra_vars = {'hosts': 'localhost', 'groups': {'group1': {'hosts': ['localhost', 'fake_hostname']}}}

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 04:43:22.007347
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected_keys = [
        'min', 'max', 'log', 'pow', 'root',
        'unique', 'intersect', 'difference',
        'symmetric_difference', 'union',
        'product', 'permutations', 'combinations',
        'human_readable', 'human_to_bytes', 'rekey_on_member',
        'zip', 'zip_longest']
    fm = FilterModule()
    filters = fm.filters()
    assert set(expected_keys) == set(filters.keys())

# Generated at 2022-06-21 04:43:41.171283
# Unit test for function union
def test_union():

    # Run the filter
    data = union(['one', 'two'], ['two', 'three'])
    assert data == ['one', 'two', 'three'], data

    # Run the filter
    data = union(['one', 'two', 'three'], ['two', 'three'])
    assert data == ['one', 'two', 'three'], data

    # Run the filter
    data = union(['one', 'two', 'three', 'four'], ['four', 'five', 'one'])
    assert data == ['one', 'two', 'three', 'four', 'five'], data

    # Run the filter
    data = union([1, 2, 3], [2, 3, 4])
    assert data == [1, 2, 3, 4], data

    # Run the filter

# Generated at 2022-06-21 04:43:54.957146
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1,2,3,4,5]

    assert symmetric_difference(None, a, a) == []
    assert symmetric_difference(None, a, []) == a
    assert symmetric_difference(None, a, [5,5,5,5]) == [1,2,3,4]
    assert symmetric_difference(None, a, [1,1,1,1]) == [2,3,4,5]
    assert symmetric_difference(None, a, [1,1,1,1,6,6,6,6]) == [2,3,4,5,6,6,6,6]

# Generated at 2022-06-21 04:44:05.593179
# Unit test for function human_to_bytes
def test_human_to_bytes():
    filters = FilterModule().filters()


# Generated at 2022-06-21 04:44:09.432849
# Unit test for function unique
def test_unique():
    x = [1, 2, 3, 4, 5, 1, 3, 5]
    assert unique(None, x) == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 04:44:17.890286
# Unit test for function power
def test_power():

    class TestPower:
        def test_positive_base_positive_power(self):
            assert power(2, 2) == 4

        def test_positive_base_negative_power(self):
            assert power(2, -2) == 1/4

        def test_negative_base_positive_power(self):
            assert power(-2, 2) == 4

        def test_negative_base_negative_power(self):
            assert power(-2, -2) == 1/4

        def test_zero_raised_to_a_power(self):
            assert power(0, 2) == 0

        def test_base_zero_raised_to_a_power(self):
            assert power(2, 0) == 1


# Generated at 2022-06-21 04:44:27.862087
# Unit test for function intersect
def test_intersect():
    # Simple case
    assert intersect([1, 2, 3], [4, 5, 6]) == []
    assert intersect([1, 2, 3], [3, 2, 5]) == [2, 3]

    # Non-hashable
    assert intersect([1, 2, [3]], [4, 5, 5]) == []
    assert intersect([1, 2, [3]], [1, [3]]) == [1, [3]]

    # Non-hashable
    assert intersect([1, 2, {'a': 1, 'b': 2}], [1, {'a': 1}]) == [1, {'a': 1, 'b': 2}]



# Generated at 2022-06-21 04:44:42.146582
# Unit test for function union
def test_union():
    ''' basic test of union on single values '''

    a = [1,2,3,4]
    b = [5,6,7,8]
    expected = [1,2,3,4,5,6,7,8]
    assert union(a, b) == expected

    a = frozenset([1,2,3,4])
    b = frozenset([5,6,7,8])
    expected = frozenset(expected)
    assert union(a, b) == expected

    a = {1:1,2:2,3:3,4:4}
    b = {5:5,6:6,7:7,8:8}

# Generated at 2022-06-21 04:44:51.870006
# Unit test for function union
def test_union():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    results = basic.AnsibleModule(
        argument_spec = dict(src = dict(required=True, type='list'),
                             dest = dict(required=True, type='list')),
        supports_check_mode=True
    ).run_command()
    loader = DataLoader()
    variable_manager = VariableManager()
    results['ansible_facts'] = dict(nxos=dict(src=results['params']['src'], dest=results['params']['dest']))

# Generated at 2022-06-21 04:44:58.784459
# Unit test for function union
def test_union():
    data = {'a': [1, 2, 3],
            'b': [2, 4],
            'c': [1, 3, 5],
            'd': [6]}
    res = set([1, 2, 3, 4, 5, 6])
    assert union(data, 'a', 'b', 'c', 'd') == res

# Generated at 2022-06-21 04:45:11.120500
# Unit test for function symmetric_difference
def test_symmetric_difference():
    dict_A = {'a': '1', 'b': '2'}
    dict_B = {'a': '1', 'c': '3'}
    dict_C = {'d': '4', 'b': '2'}
    list_A = [1, 2, 3]
    list_B = [3, 4, 5]
    list_C = [1, 2, 4]
    my_filter = FilterModule().filters()

    assert my_filter['symmetric_difference'](dict_A, dict_B) == dict_C
    assert my_filter['symmetric_difference'](list_A, list_B) == list_C

# Generated at 2022-06-21 04:45:25.391017
# Unit test for function union
def test_union():
    result = union([1, 2, 3], [3, 4, 5])
    assert result == [1, 2, 3, 4, 5]
    result = union([1, 2, 3], {'a': 1, 'b': 2, 'c': 3})
    assert isinstance(result, list)
    assert sorted(result) == [1, 2, 3]
    assert union("ab", "cd") == ['a', 'b', 'c', 'd']
    assert union("ab", "b") == ['a', 'b']
    assert union("ab", "a") == ['a', 'b']
    assert union("", "") == []
    assert union("ab", set("bc")) == ['a', 'b', 'c']
    assert union("ab", set("ba")) == ['a', 'b']



# Generated at 2022-06-21 04:45:26.726763
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-21 04:45:32.373842
# Unit test for function min
def test_min():
    # check that the builtin min() is overriden
    # ansible#23953
    assert min((1, 2, 3)) == 1

    # ansible#29389
    assert min((1, 2, 3), default=0) == 0



# Generated at 2022-06-21 04:45:35.789096
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("test_FilterModule_filters()")
    print("---------------------")
    fm = FilterModule()
    for f in fm.filters():
        print("{} - {}".format(f, fm.filters()[f]))

# Generated at 2022-06-21 04:45:45.309234
# Unit test for function intersect
def test_intersect():

    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]
    assert intersect([1, 2, 3], [2, 2, 4]) == [2]
    assert intersect([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert intersect([1, 2, 3], set([1, 2, 3])) == [1, 2, 3]
    assert intersect(set([1, 2, 3]), [1, 2, 3]) == [1, 2, 3]
    assert intersect(set([1, 2, 3]), set([1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-21 04:45:58.653284
# Unit test for function unique
def test_unique():
    """
    Simple unit test for unique filter to
    ensure that it does not error out with unexpected input
    """

    inp_list = [
        [None],
        [{}],
        [[]],
        [[None]],
        [{'a': 1}, {'b': 1}, {'a': 1}, {'b': None}, {'a': 1}],
        [[1], [2], [1], [2], [1]],
    ]
    out_list = [
        [None],
        [{}],
        [[]],
        [[None]],
        [{'a': 1}, {'b': 1}, {'b': None}],
        [[1], [2]],
    ]

    for inp, out in zip(inp_list, out_list):
        assert out == Filter

# Generated at 2022-06-21 04:46:09.184410
# Unit test for function rekey_on_member

# Generated at 2022-06-21 04:46:15.838941
# Unit test for function human_readable
def test_human_readable():
    '''Test the human_readable filter'''
    import re

    pattern = re.compile('([0-9]+) ([a-z]+)')
    value = human_readable(1234)

    if not pattern.match(value):
        raise AssertionError("%s does not match %s" % (value, pattern.pattern))

    value = human_readable(1234, unit='GB')

    if not pattern.match(value):
        raise AssertionError("%s does not match %s" % (value, pattern.pattern))


# Generated at 2022-06-21 04:46:27.937921
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test Parameters
    data = {'d1': {'a': 1, 'b': 2}, 'd2': {'a': 3, 'b': 4}}
    key = 'a'
    duplicates = 'error'

    # Test execution
    result = rekey_on_member(data, key, duplicates)

    # Test assertions
    assert result == {1: {'b': 2, 'a': 1}, 3: {'b': 4, 'a': 3}}, 'Returned value is not equal to expected value'

    # Test Parameters
    data = {'d1': {'a': 1, 'b': 2}, 'd2': {'a': 1, 'b': 4}}
    key = 'a'
    duplicates = 'overwrite'

    # Test execution

# Generated at 2022-06-21 04:46:41.637307
# Unit test for function unique
def test_unique():
    assert unique(None, [1, 2, 1, 2, 3]) == [1, 2, 3]
    assert unique(None, ['a', 'b', 'c', 'c', 'b']) == ['a', 'b', 'c']
    assert unique(None, ['a', 'b', 'c', 'c', 'b'], False) == ['a', 'b', 'c']
    assert unique(None, ['a', 'b', 'c', 'c', 'b'], case_sensitive=False) == ['a', 'b', 'c']
    assert unique(None, ['a', 'B', 'c', 'C', 'b'], case_sensitive=False) == ['a', 'B', 'c', 'C', 'b']

# Generated at 2022-06-21 04:47:00.061601
# Unit test for function power
def test_power():
    x = 2
    y = 3
    result = math.pow(x, y)
    assert result == power(x, y)
    

# Generated at 2022-06-21 04:47:08.009158
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10M') == 10485760
    assert human_to_bytes('10M', default_unit='B') == 10485760
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10', isbits=True) == 1.25
    assert human_to_bytes('10', default_unit='B', isbits=True) == 1.25
    assert human_to_bytes('5KiB') == 5120
    assert human_to_bytes('5KB') == 5000
    assert human_to_bytes('1.2T') == 12000000000000
    assert human_to_bytes('1.2T', default_unit='B') == 12000000000000


# Generated at 2022-06-21 04:47:10.113129
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest

    class TestFilterModule(unittest.TestCase):
        def test_FilterModule(self):
            assert FilterModule().filters()
    unittest.main()

# Generated at 2022-06-21 04:47:14.470673
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    # test with non-hashable list
    assert min([[1], [2], [3]]) == [1]



# Generated at 2022-06-21 04:47:16.053393
# Unit test for function min
def test_min():
    assert FilterModule().filters()['min']([2, 3, 1]) == 1


# Generated at 2022-06-21 04:47:27.814365
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.pycompat24 import get_exception

    # baseline test
    test_dict = {
        "a": {
            "key": "value1",
            "key2": "value2",
        },
        "b": {
            "key": "value3",
            "key2": "value4",
        },
    }
    result_dict = {
        "value1": {
            "key": "value1",
            "key2": "value2",
        },
        "value3": {
            "key": "value3",
            "key2": "value4",
        },
    }

    # test error handling

# Generated at 2022-06-21 04:47:33.660875
# Unit test for function intersect
def test_intersect():
    f = FilterModule().filters()

    a = [1, 2, 3, 4, 5]
    b = [2, 3, 7, 8, 9]

    res = [2, 3]

    assert f['intersect'](a, b) == res

    # Test when elements are strings
    a = ['car', 'bus', 'bike', 'plane']
    b = ['car', 'truck', 'van']

    res = ['car']

    assert f['intersect'](a, b) == res



# Generated at 2022-06-21 04:47:36.830213
# Unit test for function union
def test_union():
    assert union(['a', 1, 2], [3, 1, 4, 'a']) == ['a', 1, 2, 3, 4]
    assert union(['a', 1], [3, 1, 4, 'a']) == ['a', 1, 3, 4]
    assert union([], [1, 3]) == [1, 3]



# Generated at 2022-06-21 04:47:42.237117
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'zip' in fm.filters()

# Generated at 2022-06-21 04:47:51.709502
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from units.compat import unittest
    from units.compat.mock import patch

    from units.modules.utils import set_module_args, AnsibleExitJson, AnsibleFailJson

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            self.module = 'rekey_on_member'

        def execute_module(self, failed=False, changed=False):
            with patch.object(AnsibleExitJson, 'exit_json') as exit_json:
                with patch.object(AnsibleFailJson, 'fail_json') as fail_json:
                    cmd = ''

# Generated at 2022-06-21 04:48:02.625491
# Unit test for function power
def test_power():
    '''
    Unit test for function power
    '''
    assert power(2, 2) == 4
    assert power(3, 2) == 9
    assert power(2, 3) == 8


# Generated at 2022-06-21 04:48:16.976437
# Unit test for function human_readable
def test_human_readable():

    assert human_readable(10) == '10.0B'
    assert human_readable(10, True) == '80.0b'

    assert human_readable(10, unit='B') == '10.0B'
    assert human_readable(10, isbits=True, unit='B') == '80.0b'

    assert human_readable('10') == '10.0B'
    assert human_readable('10', True) == '80.0b'

    assert human_readable('10', unit='B') == '10.0B'
    assert human_readable('10', isbits=True, unit='B') == '80.0b'

    assert human_readable(10, unit='b') == '80.0b'

# Generated at 2022-06-21 04:48:25.224325
# Unit test for function power
def test_power():
    assert power(2, 3) == 8.0
    assert power(-2, 3) == -8.0
    try:
        power('a', 2)
        assert False, "Expected exception"
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)
        assert "only be used on numbers" in to_native(e)

    try:
        power(3, 'b')
        assert False, "Expected exception"
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)
        assert "only be used on numbers" in to_native(e)



# Generated at 2022-06-21 04:48:32.335733
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min((1,2,3)) == 1
    assert min("bca", key=str.lower) == 'a'
    assert min("bca", "abcd", key=str.lower) == 'a'
    assert min("bca", "abcd") == 'a'

# Generated at 2022-06-21 04:48:45.822597
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(1024) == '1.0 KiB'
    assert human_readable(2048) == '2.0 KiB'
    assert human_readable(1024, isbits=True) == '8.0 Kbi'
    assert human_readable(1024, unit='K') == '1.0 K'
    assert human_readable(1024.0, unit='K') == '1.0 K'
    assert human_readable(1204.0, unit='K') == '1.2 K'
    assert human_readable(1048576) == '1.0 MiB'
    assert human_readable(1073741824) == '1.0 GiB'
    assert human_readable(1099511627776) == '1.0 TiB'
    assert human

# Generated at 2022-06-21 04:48:55.774529
# Unit test for function max
def test_max():
    assert 2 == max([1, 2]), 'max() should return 2'
    assert 3 == max([1, 2, 3]), 'max() should return 2'
    assert 'c' == max('a', 'b', 'c'), 'max() should return c (str)'
    assert max() is None, "max() should return None when no arguments are given"
    assert max(object()) is None, "max() should return None when it cannot do anything"
    assert max('') is None, "max() should return None when it cannot do anything"


# Generated at 2022-06-21 04:48:58.554336
# Unit test for constructor of class FilterModule
def test_FilterModule():
    _test = FilterModule()
    assert _test is not None


# Generated at 2022-06-21 04:49:09.055907
# Unit test for function rekey_on_member
def test_rekey_on_member():

    rekey_on_member_error = AnsibleFilterError('rekey_on_member() can only be used on a list of dicts, or a dict: %s')
    rekey_on_member_type_error = AnsibleFilterTypeError('rekey_on_member() requires a key: %s')

    try:
        rekey_on_member('not a dict', 'key')
    except AnsibleFilterError as e:
        assert e.args == rekey_on_member_error.args
    else:
        assert False, 'Should have failed'

    try:
        rekey_on_member(['not', 'a', 'dict'], 'key')
    except AnsibleFilterError as e:
        assert e.args == rekey_on_member_error.args

# Generated at 2022-06-21 04:49:21.750874
# Unit test for function human_readable

# Generated at 2022-06-21 04:49:33.156059
# Unit test for function intersect
def test_intersect():
    if not __name__ == '__main__':
        raise Exception('Can only be invoked as a standalone script.')

    # test for matching hashes
    result = intersect(None, [1,2,3], [2,3,4])
    assert 2 in result and 3 in result
    assert len(result) == 2

    # test for non-matching hashes
    result = intersect(None, ['a','b','c'], ['d','b','a'])
    assert 'a' in result and 'b' in result
    assert len(result) == 2

    print('Intersect test passed.')



# Generated at 2022-06-21 04:49:57.639580
# Unit test for function intersect
def test_intersect():

    # assert isinstance(intersect([1,2,3], [1,2,4]), list)
    assert intersect([1, 2, 3], [1, 2, 4]) == [1, 2]
    assert intersect([1, 2, 3], [1, 2, 4]) != [1, 2, 4]
    assert intersect([1, 2, 3], [1, 2, 4]) != [1, 3]



# Generated at 2022-06-21 04:50:01.723594
# Unit test for function unique
def test_unique():

    # initialize
    text = dict(failed="failed", skipped="skipped", ok="ok", changed="changed")
    expected = dict(failed="failed", skipped="skipped", ok="ok", changed="changed")

    # test
    results = unique(text)

    # assert
    assert expected == results



# Generated at 2022-06-21 04:50:15.880758
# Unit test for function human_to_bytes

# Generated at 2022-06-21 04:50:27.459928
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0B'
    assert human_readable(1) == '1B'
    assert human_readable(2) == '2B'

    assert human_readable(1023) == '1023B'
    assert human_readable(1024) == '1.0K'
    assert human_readable(1 * 1024 * 1024 * 1024 * 1024) == '1.0T'
    assert human_readable(1 << 30) == '1.0G'
    assert human_readable(2 << 30) == '2.0G'
    assert human_readable(1 << 40) == '1.0T'
    assert human_readable(2 << 40) == '2.0T'

    assert human_readable(123456789) == '117.7M'
    assert human_readable(2**10)