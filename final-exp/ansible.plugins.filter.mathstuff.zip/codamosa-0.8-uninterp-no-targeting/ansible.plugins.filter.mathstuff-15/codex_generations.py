

# Generated at 2022-06-21 04:40:44.509389
# Unit test for function max

# Generated at 2022-06-21 04:40:45.480171
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()


# Generated at 2022-06-21 04:40:48.687958
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(81) == 3
    assert inversepower(81, base=4) == 2
    assert inversepower(81, base=12) == 2

# Generated at 2022-06-21 04:40:51.371556
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]


# Generated at 2022-06-21 04:41:03.886525
# Unit test for function logarithm
def test_logarithm():
    ''' test_logarithm '''
    with pytest.raises(AnsibleFilterTypeError) as e:
        logarithm('string')
    assert "can only be used on numbers:" in str(e)

    assert logarithm(1, 10) == 0
    assert logarithm(10, 10) == 1
    assert logarithm(100, 10) == 2

    assert logarithm(1) == 0
    assert logarithm(math.e) == 1
    assert logarithm(math.e*math.e) == 2



# Generated at 2022-06-21 04:41:15.414117
# Unit test for function max
def test_max():
    assert max("ab") == "b"
    assert max("abc") == "c"
    assert max("abc", "az") == "z"
    assert max("abc", "xyz") == "z"
    assert max("abc", "xyz", "za") == "z"
    assert max("abc", "xyz", "zab") == "z"
    assert max("a", "b", "c", "d", "e") == "e"
    assert max("f", "g", "b", "c", "d") == "g"
    assert max("a", "b", "c", "d", "e", "f", "g", "h", "i") == "i"


# Generated at 2022-06-21 04:41:26.329932
# Unit test for function power
def test_power():
    assert pow(2, 3) == power(2, 3)
    assert pow(2.0, 3) == power(2.0, 3)
    assert pow(2, 3.0) == power(2, 3.0)
    assert pow(2.0, 3.0) == power(2.0, 3.0)
    assert pow(2, -3) == power(2, -3)
    assert pow(2, -3.0) == power(2, -3.0)
    assert pow(2.0, -3) == power(2.0, -3)
    assert pow(2.0, -3.0) == power(2.0, -3.0)
    assert power(2, 3) == 8
    assert power(2.0, 3) == 8

# Generated at 2022-06-21 04:41:34.744898
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(81, 2) == 9
    assert inversepower(64, 2) == 8
    assert inversepower(64, 3) == 4
    assert inversepower(100, 2) == 10
    assert inversepower(100, 5) == 2.15443469004
    assert inversepower(100) == 10
    assert inversepower(100, 10) == 1.25892541179
    assert inversepower(4, 2) == 2
    assert inversepower(5, 2) == 2.2360679775
    assert inversepower(16, 2) == 4



# Generated at 2022-06-21 04:41:46.481693
# Unit test for function power
def test_power():
    assert power(2, 8) == 256
    assert power(-2, 8) == 256
    assert power(-2, 5) == -32
    assert power(-5, 2) == 25
    assert power(5, -2) == 0.04
    assert power(5, -3) == 0.008
    assert power(5, -4) == 0.0016
    assert power(2.5, -2) == 0.16
    assert power(2.5, -3) == 0.032
    assert power(2.5, -4) == 0.0064
    assert power(10, 0) == 1
    assert power(0, 0) == 1
    assert power(2, 3) == 8
    assert power(2, 4) == 16

# Generated at 2022-06-21 04:41:51.999248
# Unit test for function min
def test_min():
    fromansible = min( [3, 4, 5], [8, 9, 0] )
    frombuiltin = __builtins__.get('min')
    assert fromansible is frombuiltin, "min filter should use builtin min()"



# Generated at 2022-06-21 04:42:12.690586
# Unit test for function min
def test_min():
    from ansible.plugins.filter import math as filter_math
    from ansible.module_utils.common._collections_compat import Sequence
    import random
    import sys

    # Test if function can handle a list with a string and an int
    assert filter_math.min([5, '10']) == 5

    # Test if function can handle a list with multiple string and int elements
    assert filter_math.min([1, '2', 3, '4']) == 1

    # Test if function can handle a list that contains only strings
    assert filter_math.min(['Afghanistan', 'Albania', 'Algeria']) == 'Afghanistan'

    # Test if function can handle a list that contains duplicate elements

# Generated at 2022-06-21 04:42:17.588672
# Unit test for function difference
def test_difference():
    a = [1, 2, 3, 4, 5]
    b = [2, 3, 4, 5, 6]
    expected = [1]
    actual = difference(a, b)
    assert expected == actual



# Generated at 2022-06-21 04:42:24.980630
# Unit test for function logarithm
def test_logarithm():
    # Test None input
    assert logarithm(None) is None
    # Test int input
    assert logarithm(8) == math.log(8)
    # Test float input
    assert logarithm(3.0) == math.log(3.0)
    assert logarithm(1.0) == math.log(1.0)
    assert logarithm(0.0) == math.log(0.0)
    assert logarithm(-1.0) == math.log(-1.0)
    # Test base
    assert logarithm(8, base=2) == math.log(8, 2)
    # Test wrong type input
    try:
        logarithm('foo')
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:42:35.104666
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import os
    import unittest

    class TestFilterModule_filters(unittest.TestCase):

        def setUp(self):
            self.fil = FilterModule().filters()

        # general math
        def test_min(self):

            self.assertEqual(self.fil['min']([1, 2, 3, 4, 5]), 1)
            self.assertEqual(self.fil['min']([-1, -2, -3, -4, -5]), -5)
            self.assertEqual(self.fil['min']([1]), 1)
            self.assertEqual(self.fil['min']([]), None)
            self.assertEqual(self.fil['min']([], attribute="field"), None)

# Generated at 2022-06-21 04:42:40.668771
# Unit test for function min
def test_min():
    sequence = [3, 1, 4, 6, 5, -2, -3]
    assert min(sequence) == -3
    assert min(sequence, attribute='start') == -3
    assert min(sequence, attribute='start', default=0) == -3
    assert min(sequence, attribute='stop') is None
    assert min(sequence, attribute='stop', default=100) == 100


# Generated at 2022-06-21 04:42:51.240348
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import pytest

    @pytest.mark.parametrize('test_input,expected', [
        ('12B', 12),
        ('1.5K', 1536),
        ('1.6k', 1638.4),
        ('0.5M', 524288),
        ('1M', 1048576),
        ('0.5G', 536870912),
        ('1G', 1073741824),
        ('1.5g', 1610612736),
        ('1.6G', 17179869184),
        ('0.5T', 549755813888)
    ])
    def test_supported_units(test_input, expected):
        assert(human_to_bytes(test_input) == expected)


# Generated at 2022-06-21 04:43:02.253151
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils import basic

    # Test args to the function at runtime
    test_filter = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(required=True, type='raw'),
            key=dict(required=True, type='str'),
            duplicates=dict(required=False, type='str', choices=['error', 'overwrite']),
        )
    )

    # Generic test args
    fail_msg = 'failed'

    # Call function

# Generated at 2022-06-21 04:43:08.761298
# Unit test for function inversepower
def test_inversepower():
    assert None is inversepower(None)
    assert 2 is inversepower(4)
    assert 3 is inversepower(27, 3)
    assert 4.48 is inversepower(45, 4)
    assert 2.71 is inversepower(7.38)


# Generated at 2022-06-21 04:43:17.489395
# Unit test for function inversepower
def test_inversepower():
    from ansible.module_utils.common._collections_compat import Callable

    assert isinstance(inversepower(4), float)
    assert inversepower(4) == 2
    assert inversepower(1) == 1
    assert inversepower(16, 2) == 4
    assert inversepower(100, 1) == 100
    assert inversepower(100, 1, 2) == 100
    assert inversepower(2, 2, 2) == 1
    assert inversepower(2, 2, 3) == 1
    assert inversepower(2, 2, 2) == inversepower(2, 2, 3)
    assert inversepower(2, 2, 2) == inversepower(2, 3, 2)
    assert inversepower(2, 2, 2) == inversepower(3, 2, 2)
    assert isinstance(inversepower, Callable)

# Generated at 2022-06-21 04:43:31.130855
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.common._collections_compat import Mapping

    list_input = [{'a':1,'b':4}, {'b':2,'a':3}]
    list_output = rekey_on_member(list_input,'a')
    assert isinstance(list_output, Mapping)

    # Duplicate key value
    try:
        list_output = rekey_on_member(list_input, 'b')
        assert False, "Did not error out when duplicate key was found"
    except AnsibleFilterError as e:
        assert "was not unique" in to_native(e)

    # Bad input

# Generated at 2022-06-21 04:43:45.165807
# Unit test for function human_readable
def test_human_readable():

    assert human_readable(1) == '1.00 bytes'
    assert human_readable(1.0) == '1.00 bytes'
    assert human_readable(1000) == '1.00 KB'
    assert human_readable(1000.0) == '1.00 KB'
    assert human_readable(1000000) == '1.00 MB'
    assert human_readable(1000000.0) == '1.00 MB'
    assert human_readable(1000000000) == '1.00 GB'
    assert human_readable(1000000000.0) == '1.00 GB'
    assert human_readable(1000000000000) == '1.00 TB'
    assert human_readable(1000000000000.0) == '1.00 TB'
    assert human_readable(1000000000000000) == '1.00 PB'
   

# Generated at 2022-06-21 04:43:49.256470
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(3) == 1.0986122886681098
    assert logarithm(10, 10) == 1


# Generated at 2022-06-21 04:43:52.724838
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    try:
        power('a', 'b')
    except AnsibleFilterTypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 04:44:04.705374
# Unit test for function rekey_on_member
def test_rekey_on_member():
    pass
#     f = FilterModule()
#     data = [{'mac': '01:23:45:67:89:AF', 'port': 1}, {'mac': '01:23:45:67:89:AB', 'port': 2}]
#     assert f.filters()['rekey_on_member'](data, 'mac') == {'01:23:45:67:89:AF': {'mac': '01:23:45:67:89:AF', 'port': 1}, '01:23:45:67:89:AB': {'mac': '01:23:45:67:89:AB', 'port': 2}}
#     assert f.filters()['rekey_on_member'](data, 'port') == {1: {'mac': '01:23:45:67:89:AF

# Generated at 2022-06-21 04:44:13.705070
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(3, 0) == 1
    try:
        power(2, '2')
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError('power() called with a non-number as second argument should have failed')
    try:
        power('2', 2)
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError('power() called with a non-number as first argument should have failed')


# Generated at 2022-06-21 04:44:19.506171
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [1, 100, 3]) == [1, 2, 3, 100]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 2], [1, 100, 3]) == [1, 2, 100, 3]
    assert union(['foo', 'bar'], ['foo', 'bar']) == ['foo', 'bar']
    assert union([], []) == []
    assert union([], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], []) == [1, 2, 3]

# Generated at 2022-06-21 04:44:29.473017
# Unit test for function rekey_on_member
def test_rekey_on_member():
    class UnitTestException(Exception):
        pass
    class AssertionError(UnitTestException):
        pass
    class AssertionFailure(AssertionError):
        pass

    errors = 0

    # Check rekey_on_member() arg handling
    try:
        rekey_on_member('foo', 'bar')
    except AnsibleFilterTypeError:
        pass
    except UnitTestException as e:
        print('FAIL: rekey_on_member() raised unexpected exception for string arg: %s' % to_text(e))
        errors += 1
    else:
        print('FAIL: rekey_on_member() failed to raise exception for string arg')
        errors += 1


# Generated at 2022-06-21 04:44:32.413599
# Unit test for function max
def test_max():
    data = [1, 2, 3, 4, 5]
    assert max(data) == 5


# Generated at 2022-06-21 04:44:43.486912
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = dict(a=dict(key1=1))
    assert rekey_on_member(data, 'key1') == dict(key1=dict(key1=1))

    data = [dict(key1=1)]
    assert rekey_on_member(data, 'key1') == dict(key1=dict(key1=1))

    data = dict(a=dict(key1=1), b=dict(key2=2))
    assert rekey_on_member(data, 'no_key') == dict(a=dict(key1=1), b=dict(key2=2))

    data = dict(a=dict(key1=1), b=dict(key1=2))
    assert rekey_on_member(data, 'key1') == dict(key1=dict(key1=1))

# Generated at 2022-06-21 04:44:46.087731
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters'), "FilterModule must have filters method"



# Generated at 2022-06-21 04:44:55.925786
# Unit test for constructor of class FilterModule
def test_FilterModule():
    flt = FilterModule()
    assert isinstance(flt, FilterModule), 'class FilterModule is not a class'

# Generated at 2022-06-21 04:45:05.377885
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Create a dict and rekey on one of its members
    # {
    #     'a': {'z': 1, 'y': 2, 'x': 3},
    #     'b': {'a': 1, 'b': 2, 'c': 3}
    # }
    test_dict = dict(a=dict(z=1, y=2, x=3), b=dict(a=1, b=2, c=3))
    result = rekey_on_member(test_dict, 'x')
    assert result == dict(z=dict(a=1, b=2, c=3), y=dict(y=2), x=dict(x=3))

    # Test error on duplicate keys
    # {'b': 'b', 'a': 'a', 'c': 'a'}
    test_

# Generated at 2022-06-21 04:45:11.689951
# Unit test for function logarithm
def test_logarithm():
    x = 10.0
    base = 2.0

    res = logarithm(x, base)
    assert res == 3.321928094887362

    base = 10.0
    res = logarithm(x, base)
    assert res == 1.0


# Generated at 2022-06-21 04:45:16.729935
# Unit test for function unique
def test_unique():
    data = [1, 2, 2, 3, 4, 3, 2, 3, 1, 4]

    # test without case_sensitive parameter
    result = unique(data)
    assert result == [1, 2, 3, 4]

    # test with case_sensitive parameter
    result = unique(data, case_sensitive=True)
    assert result == [1, 2, 2, 3, 4, 3, 2, 3, 1, 4]

    # test with attribute
    result = unique(data, attribute=3)
    assert result == [1, 2, 3, 4]

    # Test that duplicates' order is preserved
    data = ['a', 'B', 'A']
    result = unique(data)
    assert result == ['a', 'B', 'A']



# Generated at 2022-06-21 04:45:25.110670
# Unit test for function unique
def test_unique():
    # Test for type error
    try:
        unique([False, True, 1])
    except AnsibleFilterTypeError as e:
        pass
    else:
        assert False, "unique with bool and integers should throw a type error exception"

    # Test with different list types, true and false
    assert unique(['b', 'a', 'a', 'c']) == ['b', 'a', 'c'], "unique returned unexpected result"
    assert unique(['b', 'a', 'a', 'c'], case_sensitive=True) == ['b', 'a', 'a', 'c'], "unique returned unexpected result"
    assert unique(['b', 'a', 'a', 'c'], case_sensitive=False) == ['b', 'a', 'c'], "unique returned unexpected result"

# Generated at 2022-06-21 04:45:33.257033
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.module_utils.common.text import formatters

    cases = {
        '1': 1,
        '1g': 1073741824,
        '1G': 1073741824,
        '1m': 1048576,
        '1M': 1048576,
        '1k': 1024,
        '1K': 1024
    }
    for human, bytes in cases.items():
        assert formatters.human_to_bytes(human) == bytes

# Generated at 2022-06-21 04:45:45.022383
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # Valid input
    assert human_to_bytes("10") == 10
    assert human_to_bytes("1B", default_unit='B') == 1
    assert human_to_bytes("10MB") == 10485760
    assert human_to_bytes("10MiB") == 10485760
    assert human_to_bytes("10GB") == 10737418240
    assert human_to_bytes("10Gb") == 10737418240
    assert human_to_bytes("10TB") == 10995116277760
    assert human_to_bytes("10TIB") == 10995116277760
    assert human_to_bytes("10PB") == 11258999068426240
    assert human_to_bytes("10pib") == 11258999068426240
    assert human_to_bytes("10Eb")

# Generated at 2022-06-21 04:45:49.612523
# Unit test for function difference
def test_difference():
    expected = ['a']
    result = difference(['a', 'b', 'c', 'd'], ['b', 'c', 'd', 'e', 'f'])
    assert set(expected) == set(result)

# Generated at 2022-06-21 04:45:54.510712
# Unit test for function union
def test_union():
    assert union([1, 2, 4], [1, 5]) == [1, 2, 4, 5]
    assert union({1, 2, 4}, {1, 5}) == {1, 2, 4, 5}


# Generated at 2022-06-21 04:46:02.202798
# Unit test for function min
def test_min():
    # Basic usage
    assert min([1, 2, 3]) == 1
    assert min([-10, 0, 10]) == -10
    assert min([1, 2, 3], [4, 5], [6, 7, 8]) == [1, 2, 3]

    # Basic usage - Jinja2 compatibility
    assert min([[1, 2, 3], [4, 5], [6, 7, 8]]) == [1, 2, 3]

    # Basic usage - with support for keyword args
    assert min([1, 2, 3], default=0) == 1
    assert min([], default=0) == 0

    # Basic usage - conflicts due to args
    assert min([1, 2, 3], default=0, key=lambda x: x**2) == 1

    # Basic usage - with key

# Generated at 2022-06-21 04:46:15.962459
# Unit test for function union
def test_union():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    data2 = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    d1 = [1, 2, 3, 4]
    d2 = [5, 6, 7, 8]
    d3 = [9, 10, 11, 12]
    d4 = [13, 14, 15, 16]
    d5 = [17, 18, 19, 20]
    d6 = [21, 22, 23, 24]
    d7 = [25, 26, 27, 28]
    d8 = [29, 30, 31, 32]
    d9 = [33, 34, 35, 36]
    d10 = [37, 38, 39, 40]

# Generated at 2022-06-21 04:46:28.145157
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:46:41.722250
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import ansible.utils.jsonobjects as jsonobjects
    datadict = {"foo0": {"a": 1, "b": 2, "c": 3},
                "foo1": {"a": 2, "b": 3, "c": 4},
                "foo2": {"a": 3, "b": 4, "c": 5},
                "foo3": {"a": 4, "b": 5, "c": 6},
                "foo4": {"a": 5, "b": 6, "c": 7}}
    #
    # Dictionary rekeying
    rdatadict = rekey_on_member(datadict, key='b')
    #
    # Original dict should not be modified.

# Generated at 2022-06-21 04:46:42.989590
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:46:46.751480
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.plugins.filter.core
    assert ansible.plugins.filter.core.FilterModule.filters(\
        ) == FilterModule.filters()


# Generated at 2022-06-21 04:46:50.961379
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # Given
    A = [1, 2, 3]
    B = [1, 3, 5]
    # When
    C = symmetric_difference(None, A, B)
    # Then
    assert C == [2, 5]


# Generated at 2022-06-21 04:46:53.850849
# Unit test for function difference
def test_difference():
    a = [1,2,3,4,5]
    b = [3,4,5,6,7]
    assert difference(a,b) == [1,2]

# Generated at 2022-06-21 04:46:58.451765
# Unit test for function unique
def test_unique():
    env = {'from_string': True}
    a = [1, 2, 2, 3, 4, 5]
    b = [1, 2, 2, 3, 4]
    c = [2, 3, 2, 3, 4, 5]
    d = [2, 3, 2, 3, 4]
    e = []
    f = [1, 2, 2, 3, 4, []]
    g = [1, 2, [1, 2, 3], 2, 3, 4]
    h = [{'name': 'fake_name', 'value': 1}, {'name': 'fake_name', 'value': 2}, {'name': 'fake_name', 'value': 3}, {'name': 'fake_name', 'value': 4}]

# Generated at 2022-06-21 04:47:05.890395
# Unit test for function symmetric_difference
def test_symmetric_difference():
    import jinja2

    # Import class FilterModule to use the 'symmetric_difference' filter
    import ansible.plugins.filter.core
    reload(ansible.plugins.filter.core)

    env = jinja2.Environment()
    the_filter = FilterModule().filters()['symmetric_difference']

    assert the_filter(env, [1, 2, 3, 4], [2, 3]) == [1, 4]
    assert the_filter(env, ['a', 'b', 'c'], ['b', 'c', 'd']) == ['a', 'd']
    assert the_filter(env, ['a', 'b', 'c'], ['a', 'b', 'c']) == []
    assert the_filter(env, [1], [1, 1]) == []
    assert the

# Generated at 2022-06-21 04:47:18.237100
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # Short variables
    a = [1, 2, 3, 4, 5]
    b = [4, 5, 6, 7, 8]

    # Long variables
    a1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    b1 = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

    # Empty list
    a2 = []

    # Testing
    assert symmetric_difference(a, b) == [1, 2, 3, 6, 7, 8]
    assert symmetric_difference(a1, b1) == [1, 2, 3, 4, 11, 12, 13, 14]
    assert symmetric_difference(a2, b) == [4, 5, 6, 7, 8]



# Generated at 2022-06-21 04:47:26.252422
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:47:33.706502
# Unit test for function difference
def test_difference():
    assert difference([1, 2, 3, 4, 5], [2, 4, 6]) == [1, 3, 5]
    assert difference([1, 2, 3, 4, 5], [2, 4, 6], True) == [1, 3, 5]
    assert difference([1, 2, 3, 4, 5], [2, 4, 6], 0) == [1, 3, 5]
    assert difference([1, 2, 3, 4, 5], [2, 4, 6], False) == [1, 3, 5]
    assert difference([1, 2, 3, 4, 5], [2, 4, 6], None) == [1, 3, 5]



# Generated at 2022-06-21 04:47:34.381686
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-21 04:47:46.467874
# Unit test for function unique
def test_unique():
    assert unique(['A', 'B', 'C', 'A', 'B']) == ['A', 'B', 'C']
    assert unique(['A', 'B', 'C', 'A', 'B'], case_sensitive=True) == ['A', 'B', 'C']
    assert unique(['A', 'B', 'C', 'A', 'B'], case_sensitive=False) == ['A', 'B', 'C']
    assert unique(['A', 'B', 'C', 'A', 'B'], attribute='upper') == ['A', 'B', 'C']

    # test case insensitive
    assert unique(['A', 'B', 'C', 'a', 'b'], case_sensitive=True) == ['A', 'B', 'C', 'a', 'b']

# Generated at 2022-06-21 04:47:59.201944
# Unit test for function power
def test_power():

    with open('/tmp/ansible_test_power.yml', 'w') as f:
        f.write("""
---
- hosts: localhost
  gather_facts: no
  vars:
    test_power_value1: 2
    test_power_value2: 3

  tasks:

  - name: AnsibleFilterPluginTest | test power module
    local_action: fail stdout={{ test_power_value1 | power(test_power_value2) }}
    register: test_power_result

  - name: AnsibleFilterPluginTest | debug test_power_result
    local_action: debug msg={{ test_power_result }}
""")

    cmd = 'ansible-playbook /tmp/ansible_test_power.yml --syntax-check'

# Generated at 2022-06-21 04:48:03.814381
# Unit test for function min
def test_min():
    fm = FilterModule()
    env = {}
    fm.filters()['min'](env, 100, 200, 300) == 100
    fm.filters()['min'](env, 100, 0) == 0
    fm.filters()['min'](env, 'a', 'b', 'c', 'd') == 'a'

# Generated at 2022-06-21 04:48:14.392983
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1000) == '1000B'
    assert human_readable(1024) == '1.00K'
    assert human_readable(1024 * 1024) == '1.00M'
    assert human_readable(1024 * 1024 * 1024) == '1.00G'
    assert human_readable(1024 * 1024 * 1024 * 1024) == '1.00T'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024) == '1.00P'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00E'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.00Z'

# Generated at 2022-06-21 04:48:26.005635
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3, 4]) == [1, 2, 3, 4]
    assert unique([1, 2, 3, '1', '2', '3', 4]) == [1, 2, 3, '1', '2', '3', 4]
    assert unique(['a', 'b', 'c', 'b', 'b', 'a', 'e', 'a']) == ['a', 'b', 'c', 'e']
    assert unique(['a', 'b', 'c', 'B', 'b', 'a', 'e', 'a']) == ['a', 'b', 'c', 'B', 'e']

# Generated at 2022-06-21 04:48:29.949088
# Unit test for function logarithm
def test_logarithm():
    assert math.log(8) == logarithm(8)
    assert math.log(8,2) == logarithm(8,2)


# Generated at 2022-06-21 04:48:40.824845
# Unit test for function min
def test_min():
    # test parameters are skipped in case parameter values are tested (e.g. syntax)
    #
    assert min([2, 4, 6, 8]) == 2
    assert min([2, 4, 6, 8], attribute='foo') == 2
    assert min([2, 4, 6, 8], case_sensitive=False) == 2
    assert min([2, 4, 6, 8], 'foo') == 2
    assert min([2, 4, 6, 8], 'foo', case_sensitive=False) == 2
    assert min([2, 4, 6, 8], attribute='foo', case_sensitive=False) == 2


# Generated at 2022-06-21 04:49:01.039393
# Unit test for function min
def test_min():
    for x in (1, '1'):
        for y in (2, 3, '2', '3'):
            assert min(x, y) == 1
    assert min([1, 2, 3]) == 1


# Generated at 2022-06-21 04:49:07.528624
# Unit test for function inversepower
def test_inversepower():
    f = FilterModule()
    assert math.sqrt(2) == f.filters()['root'](2)
    assert math.pow(2, 0.25) == f.filters()['root'](2, 4)
    assert math.sqrt(2) == f.filters()['root'](2, 2)
    assert math.pow(9, 1.0 / 2.0) == f.filters()['root'](9, 2)


# Generated at 2022-06-21 04:49:20.201067
# Unit test for function power
def test_power():
    assert power(4, 1.0/3.0) == 2.0
    assert power(8, 1.0/3.0) == 2.0
    assert power(27, 1.0/3.0) == 3.0
    assert power(64, 1.0/3.0) == 4.0

    assert power(2, 2) == 4
    assert power(2, 3) == 8
    assert power(2, 4) == 16
    assert power(2, 5) == 32
    assert power(2, 6) == 64

    assert power(10, 2) == 100
    assert power(10, 3) == 1000

    try:
        power(1.0, 0.5)
    except TypeError:
        assert True
    except Exception:
        assert False
    else:
        assert False


# Generated at 2022-06-21 04:49:25.909061
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4
    assert max((1, 2, 3, 4)) == 4
    assert max({'a': 1, 'b': 2, 'c': 3, 'd': 4}.values()) == 4
    assert max('abcd') == 'd'



# Generated at 2022-06-21 04:49:40.872045
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1) == '1.0 B'
    assert human_readable(1, isbits=True) == '8.0 b'
    assert human_readable(1024) == '1.0 KB'
    assert human_readable(1024, isbits=True) == '8.0 kb'
    assert human_readable(1024, unit='B') == '1.0 KiB'
    assert human_readable(1024, unit='B', isbits=True) == '8.0 Kib'
    assert human_readable((1024 ** 3) + (1024 ** 2)) == '1.0 GB'
    assert human_readable((1024 ** 3) + (1024 ** 2), isbits=True) == '8.0 gb'
    assert human_readable(1024 ** 4) == '1.0 TB'

# Generated at 2022-06-21 04:49:46.638462
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module is not None
    filters = filter_module.filters()
    assert 'min' in filters and callable(filters['min'])
    assert 'max' in filters and callable(filters['max'])
    assert 'log' in filters and callable(filters['log'])
    assert 'pow' in filters and callable(filters['pow'])
    assert 'root' in filters and callable(filters['root'])
    assert 'unique' in filters and callable(filters['unique'])
    assert 'intersect' in filters and callable(filters['intersect'])
    assert 'difference' in filters and callable(filters['difference'])

# Generated at 2022-06-21 04:49:57.160937
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    test_sets = [
        [1,2],[2,3],[3,4,5,6],[4,5],[5,5],[5,5],[5,5,5,5],[5,5,5,5]
    ]

    env = {
        'vars': {
            'test_sets': test_sets,
        },
    }

    set_1 = [ 1, 2, 3, 4, 5 ]
    set_2 = [ 2, 3, 4, 5, 6 ]
    set_3 = [ 5, 5, 5, 5 ]

# Generated at 2022-06-21 04:50:00.201721
# Unit test for function intersect
def test_intersect():
    assert intersect(set([1, 2]), set([2, 3])) == set([2])



# Generated at 2022-06-21 04:50:08.294606
# Unit test for function min
def test_min():
    f = FilterModule()

    assert f.filters()['min']([1, 2, 3]) == 1

    assert f.filters()['min'](['1', '2', '3'], attribute=True) == '1'

    assert f.filters()['min']([1, 2, 3], start=10) == 1



# Generated at 2022-06-21 04:50:15.345006
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1
    assert min([[1], [2], [3], [4], [5]]) == [1]
    assert min(['abc', 'de', 'fghi'], key=len) == 'de'
    assert min(['bac', 'de', 'afghi'], key=lambda x: x[1]) == 'de'
    assert min({'a': 'bac', 'b': 'de', 'c': 'afghi'}, key=lambda x: x[1]) == 'de'
    assert min({'a': 'bac', 'b': 'de', 'c': 'afghi'}, key=lambda x: 'de') == 'de'