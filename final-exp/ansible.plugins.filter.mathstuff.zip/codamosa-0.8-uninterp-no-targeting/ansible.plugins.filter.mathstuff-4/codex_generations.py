

# Generated at 2022-06-21 04:40:44.248877
# Unit test for function intersect
def test_intersect():
    env = {}
    a = [1, 2, 3, 4, 5, 6]
    b = [1, 3, 5, 7, 9, 11]
    c = intersect(env, a, b)
    assert c == [1, 3, 5], "intersect filter failed"


# Generated at 2022-06-21 04:40:50.728406
# Unit test for function intersect
def test_intersect():
    print("TEST: Testing intersect")
    try:
        a = [1, 2, 3, 4, 5]
        b = [2, 4, 6, 8, 10]
        c = [0, 2, 4, 8, 16]

        test = intersect(a, b)
        assert test == [2, 4]
        assert test == intersect(b, a)

        test = intersect(a, c)
        assert test == [2, 4]
        assert test == intersect(c, a)

        test = intersect(b, c)
        assert test == [2, 4]
        assert test == intersect(c, b)
    except Exception as ex:
        print("EXCEPTION:")
        print(ex)
        assert False


# Generated at 2022-06-21 04:41:03.949333
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 2, 1, 1, 3]) == [1, 2, 3]
    assert unique([1, 2, 2, 1, 1, 3], True) == [1, 2, 3]
    assert unique([1, 2, 2, 1, 1, 3], False) == [1, 2, 2, 1, 1, 3]
    assert unique([{'a': 1}, {'a': 1}, {'a': 2}], attribute='a') == [{'a': 1}, {'a': 2}]
    assert unique([{'a': 1}, {'a': 2}, {'a': 2}], attribute='a') == [{'a': 1}, {'a': 2}]



# Generated at 2022-06-21 04:41:16.199802
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an instance of FilterModule
    obj = FilterModule()

    # test the filters function
    filters = obj.filters()

    assert 'min' in filters
    assert 'max' in filters
    assert 'log' in filters
    assert 'pow' in filters
    assert 'root' in filters
    assert 'unique' in filters
    assert 'intersect' in filters
    assert 'difference' in filters
    assert 'symmetric_difference' in filters
    assert 'union' in filters
    assert 'product' in filters
    assert 'permutations' in filters
    assert 'combinations' in filters
    assert 'human_readable' in filters
    assert 'human_to_bytes' in filters
    assert 'rekey_on_member' in filters
    assert 'zip' in filters
    assert 'zip_longest' in filters

# Generated at 2022-06-21 04:41:18.680677
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule().filters())


# Unit tests for function rekey_on_member

# Generated at 2022-06-21 04:41:24.065597
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filter_module = FilterModule()
    environment = {}
    a = [1,2,3,4]
    b = [3,4,5,6]
    expected = [1,2,5,6]
    actual = filter_module.filters()["symmetric_difference"](environment, a, b)
    assert actual == expected

# Generated at 2022-06-21 04:41:32.767209
# Unit test for function symmetric_difference
def test_symmetric_difference():
    list1 = [1, 2, 3, 4]
    list2 = [3, 4, 5, 6]
    list3 = [1, 2]
    assert symmetric_difference(list1, list2) == [1, 2, 5, 6]
    assert symmetric_difference(list1, list3) == [3, 4]
    assert symmetric_difference(list2, list3) == [5, 6]

# Generated at 2022-06-21 04:41:45.966600
# Unit test for function difference
def test_difference():
    d = {'a': 'x', 'd': 'w', 'b': 'y', 'c': 'z'}
    a = ['a', 'b', 'c', 'd', 'e']
    c = ['w', 'x', 'y', 'z']

    assert set(a) - set(c) == set(difference(None, a, c))
    assert set(a) - set(c) == set(difference(None, set(a), set(c)))
    assert set(a) - set(c) == set(difference(None, list(a), tuple(c)))
    assert set(a) - set(c) == set(difference(None, tuple(a), list(c)))


# Generated at 2022-06-21 04:41:59.365370
# Unit test for function unique
def test_unique():
    # test if unique filter works with attribute
    if HAS_UNIQUE:
        try:
            do_unique([{'name': 'a'}, {'name': 'b'}], attribute='name')
        except TypeError:
            raise AssertionError("jinja2 unique filter does not support attribute parameter.")

    # test if unique filter works with case_sensitive=False
    if HAS_UNIQUE:
        try:
            do_unique(['a', 'A'], case_sensitive=False)
        except TypeError:
            raise AssertionError("jinja2 unique filter does not support case_sensitive=False")

    # test if unique filter works on list of lists
    if HAS_UNIQUE:
        try:
            do_unique([['a'], ['a']])
        except TypeError:
            raise Assert

# Generated at 2022-06-21 04:42:10.686044
# Unit test for function union
def test_union():
    ''' Test union '''
    fm = FilterModule()
    union_filter = fm.filters()['union']

    assert union_filter([1, 2, 3], [3, 5]) == [1, 2, 3, 5]
    assert union_filter([1, 2, 3], [1, 2, 3]) == [1, 2, 3]

    assert union_filter([1, 2, 3], [1, 2, '3']) == [1, 2, 3, '3']
    assert union_filter([1, 2, 3], [1, 2, 3, 3, 3]) == [1, 2, 3]

    assert union_filter([1, 2, 3], (1, 2, 3)) == [1, 2, 3]

# Generated at 2022-06-21 04:42:24.882003
# Unit test for function inversepower
def test_inversepower():
    if inversepower(8) != 2:
        assert False
    if inversepower(8, 3) != 2:
        assert False
    if inversepower(8, 2) != 2.8284271247461903:
        assert False
    if inversepower(16, 2) != 4:
        assert False
    if inversepower(144, power(12, 2)) != 12:
        assert False
    if inversepower(110, power(11, 2)) != 11:
        assert False
    if inversepower(121, power(11, 2)) != 11:
        assert False
    if inversepower(144, power(12, 2), True) != 12:
        assert False
    if inversepower(110, power(11, 2), True) != 11:
        assert False

# Generated at 2022-06-21 04:42:30.501114
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(81, 2) == 9
    assert inversepower(100, 2) == 10
    assert inversepower(100, 3) == 10
    try:
        inversepower(100, -2)
    except (AnsibleFilterError, AnsibleFilterTypeError):
        assert True
    else:
        assert False
    try:
        inversepower(-100, 2)
    except (AnsibleFilterError, AnsibleFilterTypeError):
        assert True
    else:
        assert False


# Generated at 2022-06-21 04:42:41.842525
# Unit test for function difference
def test_difference():

    assert difference([1, 2, 2, 3], [1, 1, 2]) == [3]
    assert difference(['foo', 'bar', 'baz'], ['foo', 'bar', 'qux']) == ['baz']

    # test with list
    assert difference(['a', 'b', 'c'], ['c', 'd', 'e']) == ['a', 'b']

    # test with list and string
    assert difference(['a', 'b', 'c'], 'cde') == ['a', 'b']
    assert difference('abc', ['c', 'd', 'e']) == ['a', 'b']

    # test with string
    assert difference('abc', 'cde') == ['a', 'b']
    assert difference('abc', 'aaa') == ['b', 'c']

    # test with dict


# Generated at 2022-06-21 04:42:50.278532
# Unit test for function human_to_bytes

# Generated at 2022-06-21 04:42:59.596027
# Unit test for function rekey_on_member
def test_rekey_on_member():
    assert len(rekey_on_member({}, 'key')) == 0, "Rekey on empty dict resulted in non-empty dict"
    # Ensure we can create dicts from dicts
    assert len(rekey_on_member({'a': {'key': 'b'}}, 'key')) == 1, "Rekey failed to create dict from dict"
    assert rekey_on_member({'a': {'key': 'b'}}, 'key') == {'b': {'key': 'b'}}, "Output dict incorrect"
    # Ensure we can create dicts from lists
    assert len(rekey_on_member([{'key': 'b'}], 'key')) == 1, "Rekey failed to create dict from list"

# Generated at 2022-06-21 04:43:01.646088
# Unit test for function power
def test_power():
    output = power(2,3)
    assert output == 8


# Generated at 2022-06-21 04:43:13.939107
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # Python 2/3 compat
    try:
        from collections import Mapping
    except ImportError:
        Mapping = dict

    # Basic test
    a = [1, 2, 3, 4]
    b = [3, 4, 5, 6]
    expected = set([1, 2, 5, 6])
    computed = symmetric_difference(None, a, b)
    assert expected == set(computed)

    # Test with strings and unicode
    a = [4, '4', u'4']
    b = [4, '4', u'4', u'伍', '伍']
    expected = set([u'伍', '伍'])
    computed = symmetric_difference(None, a, b)
    assert expected == set(computed)

    # Test with dicts
    a

# Generated at 2022-06-21 04:43:24.841738
# Unit test for function unique
def test_unique():
    test_vars = {
        'list1': ['b', 'a', 'b', 'c'],
        'list2': [{'v': 'a'}, {'v': 'a'}, {'v': 'b'}],
        'list3': [{'v': 'a'}, {'v': 'a'}, {'v': 'b'}],
        'list4': ['b', 'a', 'b', 'c'],
        'list5': ['b', 'a', 'b', 'c'],
        'int1': 1,
        'int2': 2,
        'int3': 3,
        'int_list1': [1, 1, 2],
        'empty_list': [],
        'regex': r'\d+',
    }

    # default case, case_

# Generated at 2022-06-21 04:43:32.504076
# Unit test for function union
def test_union():
    data = {'a': [1, 2, 3], 'b': [2, 3, 4]}
    result = union(data, 'a', 'b')

    assert isinstance(result, list)
    assert len(result) == 4

    data = {'a': (1, 2, 3), 'b': (2, 3, 4)}
    result = union(data, 'a', 'b')

    assert isinstance(result, list)
    assert len(result) == 4

    data = [1, 2, 3]
    result = union(data, 'a', 'b')

    assert isinstance(result, list)
    assert len(result) == 6


# Generated at 2022-06-21 04:43:44.033579
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import unittest
    import ansible.plugins.filter.core
    import jinja2
    import logging

    ####
    #### Define logging handlers to be able to capture log output
    ####
    class MemoryLogHandler(logging.Handler):
        ''' Python logging handler that stores log messages in memory and allows retrieval. '''

        def __init__(self, *args, **kwargs):
            self.log_msgs = []
            super(MemoryLogHandler, self).__init__(*args, **kwargs)

        def emit(self, record):
            self.log_msgs.append(record)

    ####
    #### Begin tests
    ####
    class TestFilterModule(unittest.TestCase):

        def setUp(self):
            self.display = Display()

# Generated at 2022-06-21 04:44:01.905004
# Unit test for function max
def test_max():
    module = FilterModule()

# Generated at 2022-06-21 04:44:05.617380
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(2) == 1.41421356237
    assert inversepower(2, 3) == 1.25992104989

# Generated at 2022-06-21 04:44:07.717438
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-21 04:44:17.350419
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    returns True if human_to_bytes function works properly
    '''

    # Test 0
    answer = formatters.human_to_bytes('1K')
    assert (answer == 1024)
    # Test 1
    answer = formatters.human_to_bytes('1M')
    assert (answer == 1048576)
    # Test 2
    answer = formatters.human_to_bytes('12M')
    assert (answer == 12582912)
    # Test 3
    answer = formatters.human_to_bytes('12.5M')
    assert (answer == 13107200)
    # Test 4
    answer = formatters.human_to_bytes('1Ki')
    assert (answer == 1024)
    # Test 5
    answer = formatters.human_to_bytes('1Gi')

# Generated at 2022-06-21 04:44:28.675625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'min' == filters['min']
    assert 'min' == filters['min']
    assert 'log' == filters['log']
    assert 'pow' == filters['pow']
    assert 'root' == filters['root']
    assert 'unique' == filters['unique']
    assert 'intersect' == filters['intersect']
    assert 'difference' == filters['difference']
    assert 'symmetric_difference' == filters['symmetric_difference']
    assert 'union' == filters['union']
    assert 'product' == filters['product']
    assert 'permutations' == filters['permutations']
    assert 'combinations' == filters['combinations']
    assert 'human_readable' == filters['human_readable']

# Generated at 2022-06-21 04:44:30.329369
# Unit test for function difference
def test_difference():
    assert difference([1,2,3], [1,2]) == [3]


# Generated at 2022-06-21 04:44:40.997211
# Unit test for function unique
def test_unique():

    class Namespace(object):
        # mimics AnsibleEnvironment environment object
        def __init__(self, var1):
            self.environment = var1

        def getattr(self, var2, var3):
            # mimic Jinja2 Environment
            if var2 == 'filters':
                return var3
            if var2 == 'func_name':
                return 'unique'

    var1 = 'foo'
    var2 = ['a', 'a', 'b', 'c', 'b', 'd']
    ns = Namespace(var1)
    unique(ns, var2)

# Generated at 2022-06-21 04:44:47.675852
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1,2,3,4,5,6,7,8,9,10]
    b = [8,9,10,11,12,13,14,15]
    c = [1,2,3,4,5,6,7]
    assert symmetric_difference(None,a,b) == c

# Generated at 2022-06-21 04:44:50.380534
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [2, 3, 4]) == [2, 3]


# Generated at 2022-06-21 04:45:02.407896
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes(u'1024') == 1024
    assert human_to_bytes(u'1024.0') == 1024.0
    assert human_to_bytes(u'1.024K') == 1024
    assert human_to_bytes(u'1.024Ki') == 1024
    assert human_to_bytes(u'1.024M') == 1048576
    assert human_to_bytes(u'1.024Mi') == 1048576
    assert human_to_bytes(u'1.024G') == 1073741824
    assert human_to_bytes(u'1.024Gi') == 1073741824
    assert human_to_bytes(u'1.024T') == 1099511627776
    assert human_to_bytes(u'1.024Ti') == 1099511627776

# Generated at 2022-06-21 04:45:16.194758
# Unit test for function human_readable
def test_human_readable():

    # Test conversion from bytes to human readable
    assert human_readable(0) == "0B"
    assert human_readable(1) == "1B"
    assert human_readable(2) == "2B"
    assert human_readable(999) == "999B"
    assert human_readable(1024) == "1.0KiB"
    assert human_readable(1536) == "1.5KiB"
    assert human_readable(1024 * 1024) == "1.0MiB"
    assert human_readable(1024 * 1024 * 1024) == "1.0GiB"
    assert human_readable(1024 * 1024 * 1024 * 1024) == "1.0TiB"
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024) == "1.0PiB"

    # Test conversion from bits to human

# Generated at 2022-06-21 04:45:20.488503
# Unit test for function symmetric_difference
def test_symmetric_difference():
    x = [1, 2, 3, 4, 5]
    y = [1, 2, 3, 5, 6]
    assert symmetric_difference(None, x, y) == [4, 6]
    assert symmetric_difference(None, y, x) == [4, 6]



# Generated at 2022-06-21 04:45:33.542269
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()

# Generated at 2022-06-21 04:45:39.574517
# Unit test for function symmetric_difference
def test_symmetric_difference():
    import jinja2
    env = jinja2.Environment()
    env.filters['symmetric_difference'] = symmetric_difference
    i = [1,2,3,4,5,6,7,8,9,10]
    x = env.from_string('{{ i | symmetric_difference([1,3,5,7,9,11,13]) }}').render(i=i)
    y = ['2', '4', '6', '8', '10', '11', '13']
    assert(x == y)

# Generated at 2022-06-21 04:45:48.655071
# Unit test for function union
def test_union():
    # first test simple list union
    a = [1, 2, 3]
    b = [1, 4, 5]
    c = union(a, b)
    assert len(c) == 5
    assert 1 in c
    assert 2 in c
    assert 3 in c
    assert 4 in c
    assert 5 in c

    # now list of lists
    a = [['a', 'b'], ['c', 'd']]
    b = [['a', 'b'], ['d', 'f']]
    c = union(a, b)
    assert len(c) == 5
    assert 'a' in c
    assert 'b' in c
    assert 'c' in c
    assert 'd' in c
    assert 'f' in c

    # now list of dicts

# Generated at 2022-06-21 04:46:00.092137
# Unit test for function difference
def test_difference():
    assert difference(None, [1, 2, 3, 4, 5], [5, 6, 7, 8, 9]) == [1, 2, 3, 4]
    assert difference(None, ['a', 'b', 'c', 'b', 'd'], ['a', 'c', 'd', 'e']) == ['b']
    assert difference(None, 'abcde', 'acde') == ['b']
    assert difference(None, 'abcde', 'abcdefgh') == []
    assert difference(None, 'abcde', '') == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-21 04:46:08.804552
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(8, 2) == 3

# Generated at 2022-06-21 04:46:17.627607
# Unit test for function difference
def test_difference():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

       

# Generated at 2022-06-21 04:46:23.870972
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1000) == math.log(1000)
    assert logarithm(1000,10) == math.log10(1000)
    assert logarithm(5,5) == math.log(5,5)


# Generated at 2022-06-21 04:46:39.897552
# Unit test for function human_readable
def test_human_readable():

    # TODO: Test bits
    assert human_readable(12345) == '12.06K'
    assert human_readable(12345678) == '11.77M'
    assert human_readable(123456789012) == '113.07G'

    assert human_readable(12345, unit='b') == '12.06K'
    assert human_readable(12345678, unit='b') == '11.77M'
    assert human_readable(123456789012, unit='b') == '113.07G'

    assert human_readable(12345, unit=None) == '12.1k'
    assert human_readable(12345678, unit=None) == '11.8M'
    assert human_readable(123456789012, unit=None) == '113G'

    # Test that

# Generated at 2022-06-21 04:46:53.783622
# Unit test for function human_to_bytes

# Generated at 2022-06-21 04:46:58.470744
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(getattr(FilterModule, 'filters'))

# Generated at 2022-06-21 04:47:05.196645
# Unit test for function difference
def test_difference():
    import jinja2
    from ansible.utils import template as t
    from ansible.module_utils._text import to_text

    env = jinja2.Environment()
    env.filters['difference'] = difference
    assert list(env.from_string(to_text('{{ [1] | difference([1,2]) }}')).render(t)) == ['2']
    assert list(env.from_string(to_text('{{ [1,2,3] | difference([1,2]) }}')).render(t)) == ['3']
    assert list(env.from_string(to_text('{{ [1,2] | difference([1,2]) }}')).render(t)) == []

# Generated at 2022-06-21 04:47:11.007344
# Unit test for function union
def test_union():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # NOTE: (bcoca) this template function only works on python3
    if not PY3:
        return


# Generated at 2022-06-21 04:47:19.934357
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max({'foo': 'bar'}) == 'bar'
    assert max({'foo': 'bar', 'fie': 'fum'}) == 'foo'
    assert max({'foo': 'bar', 'fie': 'fum'}, 'fie') == 'fum'
    assert max({'foo': 'bar', 'fie': 'fum'}, 'fie', 'foo') == 'fum'

# Generated at 2022-06-21 04:47:20.906657
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule())



# Generated at 2022-06-21 04:47:22.116303
# Unit test for function power
def test_power():
    assert power(4, 2) == 16

# Generated at 2022-06-21 04:47:28.360864
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(1e2) == 10
    assert inversepower(1e2, 3) == 4.641588833612779
    assert inversepower(1e2, math.e) == 6.065306597126334
    assert inversepower(1e2, math.pi) == 4.721898668484724

# Generated at 2022-06-21 04:47:29.670743
# Unit test for function intersect
def test_intersect():
    assert intersect(None, ["hello", "foo", "bar"], ["world", "foo", "bar"]) == ["foo", "bar"]



# Generated at 2022-06-21 04:47:33.958394
# Unit test for function logarithm
def test_logarithm():
    # Check that filter exists
    filter = FilterModule()
    filters = filter.filters()

    # Check that filter returns expected results
    #  Ensure that numbers work
    assert logarithm(7) == math.log(7)
    assert logarithm(7,10) == math.log10(7)
    assert logarithm(-2.5) == math.log(-2.5)
    assert logarithm(-2.5,5) == math.log(-2.5,5)

    #  Ensure that base of one does not raise an exception
    assert logarithm(7,1) == 0

    #  Note that we do not test that the logarithm of zero is -inf, as in python2 that would
    #  fail because -inf is not a float, and in python3 the math library raises

# Generated at 2022-06-21 04:47:49.889562
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ''' Test function human_to_bytes '''
    assert human_to_bytes("0") == 0
    assert human_to_bytes("1") == 1
    assert human_to_bytes("10") == 10
    assert human_to_bytes("1049") == 1049
    assert human_to_bytes("1049k") == 1049000
    assert human_to_bytes("1049K") == 1049000
    assert human_to_bytes("1049m") == 1049000000
    assert human_to_bytes("1049M") == 1049000000
    assert human_to_bytes("1049g") == 1049000000000
    assert human_to_bytes("1049G") == 1049000000000
    assert human_to_bytes("1049t") == 1049000000000000

# Generated at 2022-06-21 04:48:02.477610
# Unit test for function unique
def test_unique():
    # Tests for unique filter

    # Test that unique with no arguments will return the empty list if given an empty list
    # This is consistent with the behaviour of the unique filter in Ansible 2.5+
    assert unique([]) == []

    # Test that unique with no arguments will return a list that is missing duplicates
    assert unique(["a", "b", "a", "c", "c", "b", "a"]) == ["a", "b", "c"]

    # Test that case_sensitive=False will cause ignoring case when comparing elements
    assert unique(["a", "A", "B"], case_sensitive=False) == ["a", "b"]

    # Test that attribute= will cause comparing elements based on the value of the attribute

# Generated at 2022-06-21 04:48:11.773191
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [{
        'key': 'test1',
        'test': 'test1',
    }, {
        'key': 'test2',
        'test': 'test2',
    }]

    result = rekey_on_member(data, 'key')
    assert len(result) == 2
    assert 'test1' in result
    assert 'test2' in result
    assert result['test1']['test'] == 'test1'
    assert result['test2']['test'] == 'test2'

    result = rekey_on_member(data, 'key', 'overwrite')

    assert len(result) == 2
    assert 'test1' in result
    assert 'test2' in result
    assert result['test1']['test'] == 'test2'

# Generated at 2022-06-21 04:48:24.238731
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    my_list = [
        {"name": "first", "value": "some value"},
        {"name": "second", "value": 123},
        {"name": "third", "value": AnsibleVaultEncryptedUnicode(u"vaulted value")}
    ]

    my_dict = {"Hello": {"name": "first", "value": "some value"}, "World": {"name": "second", "value": 123}}

    my_bad_list = [
        "this is not a dict",
        {"name": "first", "value": "some value"}
    ]


# Generated at 2022-06-21 04:48:33.550034
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # (a ∪ b) - (a ∩ b) => a ⊖ b
    # (1, 2, 3, 4, 5, 6) - (2, 4) => (1,3,5,6)

    a = [1, 2, 3, 4, 5, 6]
    b = [2, 4]

    assert list(symmetric_difference(a, b)) == [1, 3, 5, 6]

# Generated at 2022-06-21 04:48:37.998052
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(9, 2) == 3
    assert inversepower(1296, 3) == 6
    assert inversepower(3) == 1.73205080757


# Generated at 2022-06-21 04:48:47.885805
# Unit test for function max
def test_max():
    module = FilterModule()
    res = module.filters()
    max = res['max']
    assert max([1, 2, 3, 4]) == 4
    assert max(['a', 'b', 'c']) == 'c'
    assert max([{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}], attr='a') == {'a': 4}
    assert max([5, 1, 2, 3, 4]) == 5
    assert max(['a', 'b', 'c', 'z']) == 'z'
    assert max([{'a': 5}, {'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}], attr='a') == {'a': 5}

# Generated at 2022-06-21 04:48:58.650415
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1Ki') == 1024
    assert human_to_bytes('1Mi') == 1048576
    assert human_to_bytes('1Gi') == 1073741824
    assert human_to_bytes('1Ti') == 1099511627776
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1.5Ki') == 1536
    assert human_to_bytes('1.5Mi') == 1572864
    assert human_to_bytes('1.5Gi') == 1610612736

# Generated at 2022-06-21 04:49:00.088992
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-21 04:49:09.618601
# Unit test for function power
def test_power():
    assert(power(2, 8) == 256)
    assert(power(7, 2) == 49)
    assert(power(2, 8.0) == 256)
    assert(power(7, 2.0) == 49)

    # Input string is not a number so should raise exception
    try:
        power('a', 2)
    except AnsibleFilterTypeError as e:
        assert(to_native(e) == 'pow() can only be used on numbers: int() argument must be a string, a bytes-like object or a number, not '
                                '\'str\'')
    else:
        assert(0)  # If this point is reached, no exception has been raised

    # Input string is not a number so should raise exception

# Generated at 2022-06-21 04:49:28.012549
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'min' in filters
    assert 'max' in filters
    assert 'log' in filters
    assert 'pow' in filters
    assert 'root' in filters
    assert 'unique' in filters
    assert 'intersect' in filters
    assert 'difference' in filters
    assert 'symmetric_difference' in filters
    assert 'union' in filters
    assert 'product' in filters
    assert 'permutations' in filters
    assert 'combinations' in filters
    assert 'human_readable' in filters
    assert 'human_to_bytes' in filters
    assert 'rekey_on_member' in filters
    assert 'zip' in filters
    assert 'zip_longest' in filters

# Generated at 2022-06-21 04:49:41.640455
# Unit test for function union
def test_union():
    filt = FilterModule()
    union = filt.filters()['union']

    assert union([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert union([1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], [3, 2, 1]) == [1, 2, 3]
    assert union([1, 2, 3], [3, 2, 1, 2]) == [1, 2, 3]
    assert union([1, 2, 3], [3, 2, 1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-21 04:49:44.180009
# Unit test for function min
def test_min():
    assert min(1) == 1
    assert min([1, 2, 3, 4, 2]) == 1
    assert min(1, 2, 3, 4, 2) == 1
    assert min([[1, 2], [3, 4], [5, 6]]) == [1, 2]



# Generated at 2022-06-21 04:49:47.933109
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3
    assert max("123") == "3"
    assert max("123", "2") == "3"


# Generated at 2022-06-21 04:49:53.987196
# Unit test for function unique
def test_unique():
    environment = {'undefined': None}

# Generated at 2022-06-21 04:49:56.016211
# Unit test for function power
def test_power():
    assert power(3,3) == 27


# Generated at 2022-06-21 04:49:58.239843
# Unit test for function min
def test_min():
    args = ['a', 'b', 'a']

    assert min(args) == 'a'


# Generated at 2022-06-21 04:50:10.971566
# Unit test for function human_to_bytes

# Generated at 2022-06-21 04:50:22.336652
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [{'name': 'b', 'id': 2}, {'name': 'a', 'id': 1}, {'name': 'b', 'id': 3}]

    assert rekey_on_member(data, 'name', duplicates='error') == {'a': {'name': 'a', 'id': 1}, 'b': {'name': 'b', 'id': 2}}
    assert rekey_on_member(data, 'name', duplicates='overwrite') == {'a': {'name': 'a', 'id': 1}, 'b': {'name': 'b', 'id': 3}}

    data = [{'name': 'b', 'id': 2}, {'name': 'a', 'id': 1}, {'name': 'b', 'id': 3}]
