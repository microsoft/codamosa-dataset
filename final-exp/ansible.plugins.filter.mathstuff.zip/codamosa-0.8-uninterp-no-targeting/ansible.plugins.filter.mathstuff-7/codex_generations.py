

# Generated at 2022-06-21 04:40:35.079203
# Unit test for function power
def test_power():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['pow'](2, 3) == 8
    assert filters['pow'](3, 2) == 9
    assert filters['pow'](2, 4.0) == 16.0
    assert filters['pow'](2, 3.0) == 8.0
    assert filters['pow'](4.0, 2) == 16.0


# Generated at 2022-06-21 04:40:44.308119
# Unit test for function max
def test_max():
    from ansible.compat.tests.mock import patch, Mock, MagicMock
    from ansible.template import Templar

    try:
        from jinja2.filters import do_max
        has_jinja_max = True
    except ImportError:
        has_jinja_max = False

    f = FilterModule()

    def _mock_max(*a, **ka):

        # Faster than list comprehension
        vals = []
        for arg in a:
            vals.extend(arg)
        return max(vals)

    # Test that max() is called only when Jinja2's version is not present

# Generated at 2022-06-21 04:40:51.105772
# Unit test for function logarithm
def test_logarithm():
    test = FilterModule()
    filters = test.filters()

    log = logarithm(10)
    assert log == math.log(10)
    log = logarithm(10, 10)
    assert log == math.log(10, 10)
    log = logarithm(100, 10)
    assert log == math.log(100, 10)

    try:
        log = logarithm("10")
        assert False
    except AnsibleFilterTypeError:
        pass

    log = filters['log'](10)
    assert log == math.log(10)
    log = filters['log'](10, 10)
    assert log == math.log(10, 10)
    log = filters['log'](100, 10)
    assert log == math.log(100, 10)


# Unit test

# Generated at 2022-06-21 04:41:05.700055
# Unit test for function rekey_on_member

# Generated at 2022-06-21 04:41:20.492792
# Unit test for function human_readable
def test_human_readable():
    # Human Readable size tests
    assert human_readable(2) == "2.0 B"
    assert human_readable(2, False) == "2.0 B"
    assert human_readable(2, True) == "16.0 b"
    assert human_readable(1048576) == "1.0 MB"
    assert human_readable(1073741824) == "1.0 GB"
    assert human_readable(1099511627776) == "1.0 TB"
    assert human_readable(1125899906842624) == "1.0 PB"
    assert human_readable(1152921504606846976) == "1.0 EB"
    assert human_readable(1180591620717411303424) == "1.0 ZB"

# Generated at 2022-06-21 04:41:27.068741
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert set([1, 2, 3]) == set(symmetric_difference([1], [2, 3, 1]))
    assert set([1, 2, 3, 4]) == set(symmetric_difference([1, 2, 4], [2, 3, 1]))
    assert set(['1', '2', '3']) == set(symmetric_difference(['1', '2', '1'], ['2', '3']))
    assert set(['1', '2', '3', '4']) == set(symmetric_difference(['1', '2', '4', '1'], ['2', '3']))


# Generated at 2022-06-21 04:41:31.048299
# Unit test for function inversepower
def test_inversepower():
   assert inversepower(4) == math.sqrt(4)
   assert inversepower(27,3) == 3
   assert inversepower(2500,10) == 5

# Generated at 2022-06-21 04:41:45.547137
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import jinja2
    tests = { 'ceil': [0.1, 1],
              'floor': [0.8, 0],
              'round': [0.1, 0],
              'abs': [-0.1, 0.1]
            }

    t = jinja2.Environment().from_string('''
    {%- for test, expected in tests.items() recursive %}
      {%- set actual = test | math(0.1) %}
      Result of {{ test }} filter:
        expected: {{ expected[0] }}
        actual:   {{ actual }}
        {{ "'ok' if expected[1] == actual else 'ERROR!'" }}
    {%- endfor %}
    ''')
    result = t.render(tests=tests)
    assert 'ERROR!' not in result

# Generated at 2022-06-21 04:41:50.551304
# Unit test for function difference
def test_difference():
    data1 = [
        "192.168.0.1",
        "192.168.0.2",
        "192.168.0.3",
        "192.168.0.4",
        "192.168.0.5",
    ]
    data2 = [
        "192.168.0.1",
        "192.168.0.3",
        "192.168.0.5",
        "192.168.0.7",
        "192.168.0.9",
    ]
    result = difference(None, data1, data2)
    assert result == ["192.168.0.2", "192.168.0.4"]

# Generated at 2022-06-21 04:41:54.473849
# Unit test for function max
def test_max():
    max_result = max([1, 2, 3], [1, 4, 5])
    assert max_result == [1, 4, 5]


# Generated at 2022-06-21 04:42:03.813943
# Unit test for function inversepower
def test_inversepower():
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['test_inversepower'] = inversepower
    assert inversepower(4) == 2
    assert inversepower(4, base=4) == 2
    assert inversepower(9, base=4) == 3
    assert inversepower(16, base=4) == 4
    assert inversepower(3, base=3) == 3
    assert inversepower(27, base=3) == 9
    assert inversepower(81, base=3) == 9
    assert inversepower(83, base=3) == 10
    assert inversepower(98, base=3) == 11


# Generated at 2022-06-21 04:42:07.740235
# Unit test for function max
def test_max():
    f = FilterModule().filters()
    assert f['max']([2, 3, 4, 1, 2, 3]) == 4
    assert f['max']('1234') == '4'

# Generated at 2022-06-21 04:42:18.379274
# Unit test for function logarithm
def test_logarithm():
    """
    Test logarithm function.
    """
    # Test case 1: no problems
    x = logarithm(1024, 2)
    assert x == 10

    # Test case 2: error
    try:
        logarithm("hallo")
    except AnsibleFilterTypeError as e:
        assert str(e) == 'log() can only be used on numbers: argument must be a string or a number, not \'dict\''
    else:
        assert False, "Failed to raise AnsibleFilterTypeError"

# Generated at 2022-06-21 04:42:25.288387
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1024) == '1.0KiB'
    assert human_readable(1024, unit='B') == '1024B'
    assert human_readable(1024, unit='KiB') == '1.0KiB'
    assert human_readable(1024, unit='KB') == '1.0KB'
    assert human_readable(1024, unit='K') == '1.0K'
    assert human_readable(1024, unit='K', isbits=True) == '8.0K'
    assert human_readable(1.1, unit='K') == '1.1K'
    assert human_readable(1.2, unit='K') == '1.2K'
    assert human_readable(-1.1, unit='K') == '-1.1K'

# Generated at 2022-06-21 04:42:35.350471
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Create the object to apply the rekey_on_member filter to

# Generated at 2022-06-21 04:42:38.107889
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_common = FilterModule()
    assert filter_common



# Generated at 2022-06-21 04:42:40.578834
# Unit test for function unique
def test_unique():
    assert unique(None, [1, 1, 2, 3]) == [1, 2, 3]
    assert unique(None, [3, 1, 1, 2, 3]) == [3, 1, 2]


# Generated at 2022-06-21 04:42:45.238394
# Unit test for function difference
def test_difference():
    '''
    >>> difference([1, 2, 3], [2, 3, 4])
    [1]
    >>> difference([1, 2, 3], [1, 2, 3])
    []
    '''
    pass

# Generated at 2022-06-21 04:42:59.191284
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, -1, 2, -2, 3]) == -2
    assert min(x for x in [1, -1, 2, -2, 3]) == -2
    assert min({1: 1, 2: 4, 3: 9}) == 1
    assert min({1: 9, 2: 4, 3: 1}) == 1
    assert min({1: 9, 2: 4, 3: 1}.values()) == 1
    assert min([[1, 4], [9, 1], [9, 4]], key=lambda x: x[1]) == [9, 1]
    assert min((x for x in [1, -1, 2, -2, 3])) == -2



# Generated at 2022-06-21 04:43:01.159488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters == FilterModule().filters



# Generated at 2022-06-21 04:43:09.401334
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['max'] == max
    assert f.filters()['human_readable'] == human_readable
    assert f.filters()['zip_longest'] == zip_longest

# Generated at 2022-06-21 04:43:15.759822
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Initialize class
    filters = FilterModule()
    assert (isinstance(filters, type)) is True, "FilterModule is not a type"
    assert (isinstance(filters.filters(), dict)) is True, "FilterModule.filters() is not a dict"

# Generated at 2022-06-21 04:43:20.301330
# Unit test for function min
def test_min():
    assert min(['a', 'b', 'c']) == 'a', 'min() test failed'
    assert min([1, [1, 2, 3], 3]) == [1, 2, 3], 'min() test failed'


# Generated at 2022-06-21 04:43:22.747411
# Unit test for function inversepower
def test_inversepower():
    r = inversepower(16)
    assert r == 4.0

# Generated at 2022-06-21 04:43:28.572428
# Unit test for function union
def test_union():
    assert union([1,2,3], [2,3,4]) == [1,2,3,4]
    assert union([], [1,2,3]) == [1,2,3]
    assert union([1,2,3], []) == [1,2,3]


# Generated at 2022-06-21 04:43:29.441006
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-21 04:43:43.491014
# Unit test for function rekey_on_member
def test_rekey_on_member():
    test = [{'key': 'value1'}, {'key': 'value2'}, {'key': 'value2'}]
    expect = {'value1': {'key': 'value1'}, 'value2': {'key': 'value2'}}
    assert rekey_on_member(test, 'key') == expect
    expect2 = {'value1': {'key': 'value1'}, 'value2': {'key': 'value2'}}
    assert rekey_on_member([test], 'key') == expect2
    expect3 = {'value1': {'key': 'value1'}}
    assert rekey_on_member([test], 'key', 'overwrite') == expect3

# Generated at 2022-06-21 04:43:55.087554
# Unit test for function unique
def test_unique():
    """
    Test unique
    """
    env = {}
    assert unique(env, [1, 2, 3, 2, 1]) == [1, 2, 3]
    assert unique(env, [1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert unique(env, [1, 2, 3, [1, 2, 3], 2, 1]) == [1, 2, 3, [1, 2, 3]]
    assert unique(env, [[1, 2, 3], [1, 2, 3], [1, 2, 3]]) == [[1, 2, 3], [1, 2, 3], [1, 2, 3]]

# Generated at 2022-06-21 04:44:03.035328
# Unit test for function inversepower
def test_inversepower():
    try:
        inversepower(16)
    except AnsibleFilterTypeError as err:
        assert str(err) == "root() can only be used on numbers: math domain error"
    else:
        assert False, "inversepower() accepts input it should not"

    try:
        inversepower(16, 0)
    except AnsibleFilterTypeError as err:
        assert str(err) == "root() can only be used on numbers: math domain error"
    else:
        assert False, "inversepower() accepts input it should not"



# Generated at 2022-06-21 04:44:17.456463
# Unit test for function inversepower
def test_inversepower():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['inversepower'](9, 3) == 2
    assert filters['inversepower'](27) == 3
    assert filters['inversepower'](9.0, 3) == 2.0
    assert filters['inversepower'](27.0) == 3.0

    try:
        filters['inversepower']("foo", 3)
    except AnsibleFilterTypeError as e:
        assert 'root() can only be used on numbers' in to_text(e)
    else:
        assert False, "inversepower with 'foo' should have failed"


# Generated at 2022-06-21 04:44:31.051785
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1000) == '1.0 K', '1.0 K'
    assert human_readable(1024) == '1.0 K', '1.0 K'
    assert human_readable(1000*1024) == '1.0 M', '1.0 M'
    assert human_readable(1000*1024*1024) == '1.0 G', '1.0 G'
    assert human_readable(1000*1024*1024*1024) == '1.0 T', '1.0 T'
    assert human_readable(1000**3*1024) == '1.0 P', '1.0 P'
    assert human_readable(1000*1024*1024*1024*1024) == '1.0 P', '1.0 P'

# Generated at 2022-06-21 04:44:37.640583
# Unit test for function difference
def test_difference():
    module = AnsibleModule(argument_spec=dict(first=dict(type='list'), second=dict(type='list')))
    result = difference(module.params['first'], module.params['second'])
    module.exit_json(result=result)



# Generated at 2022-06-21 04:44:49.466119
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3]) == [1, 2, 3]
    assert unique([1, 1, 3]) == [1, 3]
    assert unique([1, 2, 2]) == [1, 2]
    assert unique([4, '4', 2]) == [4, '4', 2]
    assert unique([4, '4', 2], case_sensitive=False) == [4, 2]
    assert unique([{'item': 4}, {'item': 4}, {'item': 2}], attribute='item') == [{'item': 4}, {'item': 2}]


# Generated at 2022-06-21 04:45:01.958230
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """
    Contains simple unit tests to ensure rekey_on_member() functions properly.
    """

    import ansible.compat.tests.mock as mock

    from ansible.errors import AnsibleFilterError
    from ansible.utils import plugins
    from ansible.template import filters

    unicode_string = u'unicode \u2713'
    byte_string = u'byte string \u2713'.encode('utf-8')

    # Ensure rekey_on_member() uses Jinja2's "to_native" filter to ensure all text is in unicode
    with mock.patch('ansible.template.safe_eval.to_native') as to_native_mock:
        assert isinstance(filters.rekey_on_member(unicode_string, u'foo'), unicode_string)
        assert to_

# Generated at 2022-06-21 04:45:13.377982
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """ Unit test for function rekey_on_member """
    # Test case 1
    # Test function with dict of dicts

# Generated at 2022-06-21 04:45:23.442950
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert len(filters) == 18

    assert filters['min'] == min
    assert filters['max'] == max

    assert filters['log'] == logarithm
    assert filters['pow'] == power
    assert filters['root'] == inversepower

    assert filters['unique'] == unique
    assert filters['intersect'] == intersect
    assert filters['difference'] == difference
    assert filters['symmetric_difference'] == symmetric_difference
    assert filters['union'] == union

    assert filters['product'] == itertools.product
    assert filters['permutations'] == itertools.permutations
    assert filters['combinations'] == itertools.combinations

    assert filters['human_readable'] == human_readable

# Generated at 2022-06-21 04:45:28.053053
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 1, 2, 3], [2, 3, 3, 1]) == [2, 3, 1]
    assert intersect('abcd', 'bdcab') == ['b', 'd', 'c', 'a']
    assert intersect('abc', 'def') == []



# Generated at 2022-06-21 04:45:36.872412
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([2, 3, 1]) == 3
    assert max([2, 3, 1], key=str) == 3
    assert max((1, 2, 3)) == 3
    assert max((1, 3, 2)) == 3
    assert max((3, 1, 2)) == 3
    assert max((3, 2, 1)) == 3
    assert max((2, 3, 1)) == 3
    assert max((2, 3, 1), key=str) == 3
    assert max({1, 2, 3}) == 3
    assert max({1, 3, 2}) == 3

# Generated at 2022-06-21 04:45:47.080122
# Unit test for function unique
def test_unique():
    env = environmentfilter()

    a = [1, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, 7, 7, 8, 2, 9]
    b = [2, 3, 4, 5, 6, 7, 8, 9, 9]

    # default with no parameter
    assert unique(env, a) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert unique(env, b) == [2, 3, 4, 5, 6, 7, 8, 9]
    assert unique(env, a, case_sensitive=True) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert unique(env, b, case_sensitive=True) == [2, 3, 4, 5, 6, 7, 8, 9]

   

# Generated at 2022-06-21 04:45:58.523387
# Unit test for function human_readable
def test_human_readable():
    test_data = {
        1024: '1K',
        1536: '1.5K',
        2000000: '1.91M',
        15001240: '14.3M',
        1000000000: '953.7M',
        3500000000: '3.3G',
        1024000: '1.02M',
        1048576: '1M',
        10485776: '10M'
    }

    # unit test for function human_readable
    for key, value in list(test_data.items()):
        assert human_readable(key) == value

# Generated at 2022-06-21 04:46:21.977798
# Unit test for function union
def test_union():
    sequence_a = [1, 2, 3]
    sequence_b = [2, 3, 4, 5]

    unique_items = union(None, sequence_a, sequence_b)

    assert unique_items == [1, 2, 3, 4, 5], "'union' function gives unexpected results"


# Generated at 2022-06-21 04:46:29.959745
# Unit test for function min
def test_min():
    f = FilterModule()
    filters = f.filters()
    # list
    assert ['b', 'c', 'd'] == filters['min'](['b', 'c', 'd', 'e'])
    # string
    assert 'b' == filters['min']('bcde')
    # tuple
    assert ('b', 'c', 'd') == filters['min'](('b', 'c', 'd', 'e'))
    # list of dicts
    assert [{'a': 'b', 'c': 'd'}] == filters['min']([{'a': 'b', 'c': 'd'}, {'a': 'e', 'c': 'f'}], 'a')
    # string of dicts

# Generated at 2022-06-21 04:46:31.587938
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:46:38.227404
# Unit test for function min
def test_min():  # noqa: pylint: disable=unused-argument
    assert min([3, 6, 9]) == 3
    assert min([3, 6, 9], 1) == 3
    assert min([[3], [6]], [1, 2]) == [[3], [6]]
    assert min([[3], [6]], 1) == [6]
    assert min([[3], [6]], attribute='last_seen') == [6]
    assert min([[3], [6]], multiple=True) == [[3], [6]]



# Generated at 2022-06-21 04:46:42.853775
# Unit test for function power
def test_power():
    assert power(3, 4) == 81

# Generated at 2022-06-21 04:46:44.510230
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3], [3, 4, 5]) == [3]

# Generated at 2022-06-21 04:46:54.489875
# Unit test for function human_readable

# Generated at 2022-06-21 04:46:59.061249
# Unit test for function max
def test_max():
    assert max(1, 2) == 2
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max((1, 2, 3)) == 3
    assert max({'foo': 1, 'bar': 3, 'baz': 2}) == 3


# Generated at 2022-06-21 04:47:07.915620
# Unit test for function difference
def test_difference():
    from ansible import context
    from jinja2 import DictLoader

    display.verbosity = 4
    context.CLIARGS = {}
    ft = FilterModule()
    env = ft.filters()

    env = Environment(loader=DictLoader({'template': '{{ a | difference(b) }}'}))
    template = env.get_template('template')

    # simple sets
    assert template.render(a=[0, 1, 2, 3, 4], b=[3, 4, 5]) == '[0, 1, 2]'

    # strings are sets in Jinja2
    assert template.render(a="abcd", b="ae") == '"bc"'

    # ensure differences of non-list types produces a list

# Generated at 2022-06-21 04:47:18.820651
# Unit test for function max

# Generated at 2022-06-21 04:47:40.890350
# Unit test for function unique
def test_unique():
    for case_sensitive in (None, True, False):
        for a in [(1, 1, 2, 3, 1, 4, 2, 3), (0, 0, 1, 2, 3, 2, 0)]:
            b = list(unique(None, a, case_sensitive=case_sensitive))
            assert len(b) == len(set(b)), "Failed to remove repeated items from list"
            assert set(a) == set(b), "Failed to preserve order in list"



# Generated at 2022-06-21 04:47:46.682719
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    # Test the math filters
    assert fm.filters()["min"] == min
    assert fm.filters()["max"] == max
    assert fm.filters()["log"] == logarithm
    assert fm.filters()["pow"] == power
    assert fm.filters()["root"] == inversepower

    # Test the set theory filters
    assert fm.filters()["unique"] == unique
    assert fm.filters()["intersect"] == intersect
    assert fm.filters()["difference"] == difference
    assert fm.filters()["symmetric_difference"] == symmetric_difference
    assert fm.filters()["union"] == union

    # Test the combinatorial filters
    assert fm.filters()["product"]

# Generated at 2022-06-21 04:47:48.854872
# Unit test for constructor of class FilterModule
def test_FilterModule():
	print('constructor of class FilterModule')

if __name__ == '__main__':
	test_FilterModule()

# Generated at 2022-06-21 04:48:02.147105
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from .ansible_test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    import sys

    # Use class defined above for unit testing filter plugin
    filter_rekey_on_member = FilterModule()

    class TestRekeyMember(ModuleTestCase):
        def test_aliases_basic(self):
            empty_list = []
            empty_dict = {}
            simple_list_of_dicts = [
                {'key': 'A'},
                {'key': 'B'},
                {'key': 'C'},
                {'key': 'D'},
            ]

# Generated at 2022-06-21 04:48:13.738191
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('10') == 10
    assert human_to_bytes('10') is not str
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1p') == 1125899906842624

# Generated at 2022-06-21 04:48:20.238435
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [3, 4]) == [1, 2, 4]
    assert symmetric_difference(['a', 'b', 'c'], ['c', 'd']) == ['a', 'b', 'd']

# Generated at 2022-06-21 04:48:22.566564
# Unit test for function intersect
def test_intersect():
    a = [1, 2, 3, 4]
    b = [2, 4, 5, 6]
    c = intersect(a, b)
    assert c == [2, 4]


# Generated at 2022-06-21 04:48:38.386360
# Unit test for function max
def test_max():
    max_test_list_object = [2, 3, 1]
    max_test_dict_object = {'a': 2, 'b': 3, 'c': 1}
    max_test_param_object = [{'n': 2}, {'n': 3}, {'n': 1}]

    assert max(max_test_list_object) == 3
    assert max(max_test_dict_object) == 3
    assert max(max_test_param_object, 'n') == 3

    max_test_custom_type = [{'a': 1}, {'a': 10}, {'a': 2}]
    assert max(max_test_custom_type, 'a') == {'a': 10}


# Generated at 2022-06-21 04:48:48.009375
# Unit test for function intersect
def test_intersect():
    module = type('module', (object,), {'params': {'diff': False}})()
    f = itertools.imap(to_text, FilterModule().filters()['intersect'])
    f = f('doesntmatter', module)
    assert f({1, 2, 3}, {2, 3, 4}) == {2, 3}
    assert f([1, 2, 3], set([2, 3, 4])) == {2, 3}
    assert f([1, 2, 3], [2, 3, 4]) == [2, 3]
    assert f({'a': 1, 'b': 2, 'c': 3}, ['c', 'd', 'e']) == {'c', }
    assert f([1, 2, 3], '2,3,4'.split(',')) == [2, 3]

# Generated at 2022-06-21 04:48:58.707665
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert 1 == human_to_bytes('1')
    assert 512 == human_to_bytes('512')
    assert 1024 == human_to_bytes('1k')
    assert 2048 == human_to_bytes('2k')
    assert 3072 == human_to_bytes('3K')
    assert 1048576 == human_to_bytes('1M')
    assert 1073741824 == human_to_bytes('1G')
    assert 1099511627776 == human_to_bytes('1T')
    assert 1125899906842624 == human_to_bytes('1P')
    assert 1152921504606846976 == human_to_bytes('1E')
    assert 1180591620717411303424 == human_to_bytes('1Z')
    assert 1208925819614629174706176 == human_to

# Generated at 2022-06-21 04:49:28.130986
# Unit test for function difference
def test_difference():
    import jinja2
    env = jinja2.Environment()
    template = env.from_string(u"{{[1, 2, 3, 4]|difference([3, 4, 5])}}")
    assert template.render() == u'[1, 2]'


# Generated at 2022-06-21 04:49:39.465563
# Unit test for function human_readable
def test_human_readable():
    numbers = [('5k', 5000), ('5KiB', 5 * 2 ** 10), ('5kB', 5000), ('5m', 5000 * 1000), ('5MiB', 5 * 2 ** 20), ('5MB', 5000 * 1000), ('5g', 5000 * 1000 * 1000), ('5GiB', 5 * 2 ** 30), ('5GB', 5000 * 1000 * 1000), ('5t', 5000 * 1000 * 1000 * 1000), ('5TiB', 5 * 2 ** 40), ('5TB', 5000 * 1000 * 1000 * 1000)]
    for number, value in numbers:
        assert human_readable(number) == str(value)
        assert human_to_bytes(number) == value

# Generated at 2022-06-21 04:49:45.045210
# Unit test for function logarithm
def test_logarithm():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-21 04:49:51.173856
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(16, 2) == 4
    assert inversepower(9, 2) == 3
    assert inversepower(49, 2) == 7
    assert inversepower(64, 2) == 8
    assert inversepower(16, 3) == 2
    assert inversepower(125, 3) == 5
    try:
        inversepower(4, 0)
        fail_msg = "TypeError was not raised for root(x, 0)"
        raise AssertionError(fail_msg)
    except TypeError:
        # Expected, mathdomain error
        pass

# Generated at 2022-06-21 04:49:54.921804
# Unit test for function power
def test_power():
    assert power(31, 5) == 923521
    assert power(11, -4) == 0.00030840039682539685

# Generated at 2022-06-21 04:50:02.500233
# Unit test for function unique
def test_unique():
    assert unique([1, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 1, 2, 3], True) == [1, 1, 2, 3]
    assert unique([1, "1", 2, 3]) == [1, "1", 2, 3]
    assert unique([1, "1", 2, 3], True) == [1, 2, 3]
    assert unique(["xx", "yy", "zz", "xx"]) == ["xx", "yy", "zz"]
    assert unique(["xx", "yy", "zz", "xx"], True) == ["xx", "yy", "zz", "xx"]
    assert unique([1, 1, 2, 3], case_sensitive=True) == [1, 1, 2, 3]

# Generated at 2022-06-21 04:50:07.517651
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, ]) == 4


# Generated at 2022-06-21 04:50:11.611331
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([4, 5, 6], [4, 5, 6]) == []
    assert symmetric_difference([4, None, 6], [6, 5, 4]) == [None, 5]


# Generated at 2022-06-21 04:50:18.138585
# Unit test for function inversepower
def test_inversepower():
    fm = FilterModule()
    environ = fm.filters()
    assert environ['root'](9, 3) == 2
    assert environ['root'](8, 2) == 2.8284271247461903
    assert environ['root'](81, 4) == 3