

# Generated at 2022-06-21 04:40:41.266995
# Unit test for function min
def test_min():
    # Test cases based on examples from https://docs.python.org/3/library/functions.html#min
    assert min(1, 2) == 1, "min(1, 2) should be 1"
    assert min("1", "2") == "1", "min('1', '2') should be '1'"
    assert min((1, "a"), (2)) == (1, "a"), "min((1, 'a'), (2,)) should be (1, 'a')"
    assert min(["a", "b"], ["b", "a"]) == ["a", "b"], "min(['a', 'b'], ['b', 'a']) should be ['a', 'b']"

# Generated at 2022-06-21 04:40:46.276971
# Unit test for function min
def test_min():
    assert min([1,2,3,4])==1
    assert min([1.1,2.1,3.1,4.1])==1.1
    assert min([-1,-2,-3,-4])==-4
    assert min([-1.1,-2.1,-3.1,-4.1])==-4.1
    assert min([1,2,-3,-4])==-4
    assert min([1.1,2.1,-3.1,-4.1])==-4.1
    assert min([1,2,3,4], key = lambda x: -x)==4
    assert min([1.1,2.1,3.1,4.1], key = lambda x: -x)==4.1

# Generated at 2022-06-21 04:41:01.762277
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1kb') == 1000
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('01k') == 1024
    assert human_to_bytes('01K') == 1024
    assert human_to_bytes('01kb') == 1000
    assert human_to_bytes('01KB') == 1000
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1mb') == 1000000
    assert human_to_bytes('1MB') == 1000000

# Generated at 2022-06-21 04:41:15.263531
# Unit test for function human_readable
def test_human_readable():
    assert human_readable('1.2K') == '1.2Kilo'
    assert human_readable('12M') == '12Mega'
    assert human_readable('1.2G') == '1.2Giga'
    assert human_readable('12T') == '12Tera'
    assert human_readable('1.2P') == '1.2Peta'
    assert human_readable('12E') == '12Exa'
    assert human_readable('1.2Z') == '1.2Zetta'
    assert human_readable('12Y') == '12Yotta'
    assert human_readable('12000') == '12Kilo'
    assert human_readable('12000', isbits=True) == '96Kilo'

# Generated at 2022-06-21 04:41:23.905035
# Unit test for function union
def test_union():
    assert union(None, [1, 2, 3], [2, 3, 4]) == [1, 2, 3, 4]
    assert union(None, [1, 2, 3], []) == [1, 2, 3]
    assert union(None, [], [1, 2, 3]) == [1, 2, 3]
    assert union(None, [], []) == []


# Generated at 2022-06-21 04:41:36.051137
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('100k') == 102400)
    assert (human_to_bytes('100K') == 102400)
    assert (human_to_bytes('100KiB') == 102400)
    assert (human_to_bytes('100KB') == 102400)
    assert (human_to_bytes('100Kib') == 102400)
    assert (human_to_bytes('100kb') == 102400)
    assert (human_to_bytes('1MB') == 1048576)
    assert (human_to_bytes('1Mb') == 1048576)
    assert (human_to_bytes('1M') == 1048576)
    assert (human_to_bytes('1m') == 1048576)
    assert (human_to_bytes('1GB') == 1073741824)

# Generated at 2022-06-21 04:41:42.350206
# Unit test for function power
def test_power():
    assert power(2, 2) == 4
    assert power(2, 0) == 1
    assert power(2, -2) == 0.25
    assert power(-2, 2) == 4
    assert power(-2, 0) == 1
    assert power(-2, -2) == 0.25



# Generated at 2022-06-21 04:41:45.448835
# Unit test for function logarithm
def test_logarithm():
    logarithm(1) == 0
    logarithm(2) == 0.69314718056
    logarithm(2, 2) == 1
    logarithm(10, 10) == 1

# Generated at 2022-06-21 04:41:53.966944
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, 2) == 2
    assert inversepower(5, 2) == 2.23606797749979
    assert inversepower(9, 3) == 2
    assert inversepower(5, 1) == 5
    assert inversepower(5, 0) == 1
    assert inversepower(5) == 2.23606797749979

# Generated at 2022-06-21 04:42:09.421319
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1) == '1 B'
    assert human_readable(1024) == '1.0 kB'
    assert human_readable(1021) == '1021 B'
    assert human_readable(1024, isbits=True) == '1.0 Kbit'
    assert human_readable(1023, isbits=True) == '1023 bit'
    assert human_readable(1024, unit='B') == '1.0 kB'
    assert human_readable(1023, unit='B') == '1023 B'
    assert human_readable(1024, unit='B', isbits=True) == '1.0 Kbit'
    assert human_readable(1023, unit='B', isbits=True) == '1023 bit'

# Generated at 2022-06-21 04:42:28.199367
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:42:40.928062
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [1, 2, 4]) == [1, 2, 3, 4]
    assert union([1, 2, 3], [1, 2]) == [1, 2, 3]
    assert union([], []) == []

    assert union([1, 2, 3], [4, 5, 6, 1, 2, 7]) == [1, 2, 3, 4, 5, 6, 7]
    assert union((1, 2, 3), (4, 5, 6, 1, 2, 7)) == (1, 2, 3, 4, 5, 6, 7)
    assert union({1: 'one', 2: 'two'}, {2: 'two', 3: 'three'}) == {1: 'one', 2: 'two', 3: 'three'}

# Generated at 2022-06-21 04:42:45.583711
# Unit test for function difference
def test_difference():
    data = {'a': "1", 'b': "2", 'c': "3"}

    filter_result = difference(None, data, ['1', '2'])
    assert filter_result == ['3']

# Generated at 2022-06-21 04:43:00.102068
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1024') == 1024
    assert human_to_bytes('1M') == 1024*1024
    assert human_to_bytes('1G') == 1024*1024*1024
    assert human_to_bytes('1024B') == 1024
    assert human_to_bytes('1MB') == 1024*1024
    assert human_to_bytes('1GB') == 1024*1024*1024
    assert human_to_bytes('3.4 K') == 3.4*1024
    assert human_to_bytes('3.4 Ki') == 3.4*1024
    assert human_to_bytes('3.4 Kib') == 3.4*1024
    assert human_to_bytes('3.4 k') == 3.4*1000
    assert human_to_bytes('3.4 kb') == 3.4*1000
    assert human

# Generated at 2022-06-21 04:43:13.129336
# Unit test for function human_to_bytes
def test_human_to_bytes():
    import unittest

    class TestHumanToBytes(unittest.TestCase):

        def test_basic(self):
            self.assertEqual(human_to_bytes('1.2M'), 1200000)
            self.assertEqual(human_to_bytes('1.2M', 'M'), 1200000)

        def test_rounding(self):
            self.assertEqual(human_to_bytes('1M'), 1000000)
            self.assertEqual(human_to_bytes('1M', 'M'), 1000000)
            self.assertEqual(human_to_bytes('1.5M'), 1500000)
            self.assertEqual(human_to_bytes('1.5M', 'M'), 1500000)
            self.assertEqual(human_to_bytes('0.5M'), 500000)


# Generated at 2022-06-21 04:43:19.177077
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.plugins.filter.core import rekey_on_member

    data = [{'id': 1, 'name': 'foo'}, {'id': 2, 'name': 'bar'}]
    assert rekey_on_member(data, 'id') == {i['id']: i for i in data}

# Generated at 2022-06-21 04:43:31.738008
# Unit test for function unique
def test_unique():
    a = ['a', 'b', 'a', 'b', 'c', 'd', 'e']
    b = ['a', 'a', 'b', 'b', 'c', 'd', 'e']
    c = ['a', 'b', 'c', 'd', 'e']
    d = ['a', 'b', 'a', 'b', 'c', 'd', 'e', 'd', 'f']
    d_reduced = ['a', 'b', 'c', 'd', 'e', 'f']
    e = ["a", "b", "c", {'a': 1}, {'b': 2}, {'a': 1}, {'b': 2}, {'a': 1, 'b': 3}, {'b': 3, 'c': 4}]

# Generated at 2022-06-21 04:43:33.813122
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert len(module.filters()) > 0

# Generated at 2022-06-21 04:43:44.444755
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'min' in obj.filters()
    assert 'max' in obj.filters()
    assert 'log' in obj.filters()
    assert 'pow' in obj.filters()
    assert 'root' in obj.filters()
    assert 'unique' in obj.filters()
    assert 'intersect' in obj.filters()
    assert 'difference' in obj.filters()
    assert 'symmetric_difference' in obj.filters()
    assert 'union' in obj.filters()
    assert 'product' in obj.filters()
    assert 'permutations' in obj.filters()
    assert 'combinations' in obj.filters()
    assert 'human_readable' in obj.filters()

# Generated at 2022-06-21 04:43:59.635919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert isinstance(filters, dict)
    assert 'min' in filters
    assert 'max' in filters
    assert 'log' in filters
    assert 'pow' in filters
    assert 'root' in filters
    assert 'unique' in filters
    assert 'intersect' in filters
    assert 'difference' in filters
    assert 'symmetric_difference' in filters
    assert 'union' in filters
    assert 'product' in filters
    assert 'permutations' in filters
    assert 'combinations' in filters
    assert 'human_readable' in filters
    assert 'human_to_bytes' in filters
    assert 'rekey_on_member' in filters
    assert 'zip' in filters
    assert 'zip_longest' in filters



# Generated at 2022-06-21 04:44:14.666186
# Unit test for function union
def test_union():
    assert union([], []) == []
    assert union([1, 2, 3], [3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert union([1, 2, 3], [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert union([1, 2, 3, 4, 5], [1, 2, 3]) == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 04:44:27.547587
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # case 1: Both set A and set B contain the same element
    a = {'orange', 'blue', 'white', 'black'}
    b = {'blue', 'green', 'yellow', 'black'}
    c = {'orange', 'white', 'green', 'yellow'}

    if c != symmetric_difference(None, a, b):
        raise AssertionError

    # case 2: Set B is empty
    a = {'orange', 'blue', 'white', 'black'}
    b = set()
    c = {'orange', 'blue', 'white', 'black'}

    if c != symmetric_difference(None, a, b):
        raise AssertionError

    # case 3: Set A is empty
    a = set()

# Generated at 2022-06-21 04:44:42.114242
# Unit test for function symmetric_difference
def test_symmetric_difference():
    mod = FilterModule()
    filters = mod.filters()
    sym_diff = filters['symmetric_difference']

    assert sym_diff([1, 2, 3], [3, 4, 5]) == [1, 2, 4, 5]
    assert sym_diff([1, 2, 3], [4, 5]) == [1, 2, 3, 4, 5]
    assert sym_diff([1, 2, 3], [3]) == [1, 2]
    assert sym_diff([1, 2, 3], [1, 2, 3]) == []
    assert sym_diff([1, 2, 3], [4]) == [1, 2, 3, 4]
    assert sym_diff([1, 2, 3], [1]) == [2, 3]
    assert sym_diff([1], [1]) == []

# Generated at 2022-06-21 04:44:45.346508
# Unit test for function difference
def test_difference():
    assert difference(['a', 'b', 'c', 'd'], ['a', 'c']) == ['b', 'd']



# Generated at 2022-06-21 04:44:50.442947
# Unit test for function union
def test_union():
    # Basic
    assert union([1,2,3], [2,3,4]) == [1,2,3,4]
    # random order
    assert union([3,2,1], [4,3,2]) == [1,2,3,4]
    # return type
    assert union([1,2,3], [1,2,3,4]) == [1,2,3,4]

# Generated at 2022-06-21 04:44:54.406984
# Unit test for function union
def test_union():
    x = [1, 2, 3]
    y = [4, 5, 6]

    assert union(x, y) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 04:45:04.489840
# Unit test for function intersect
def test_intersect():
    filter_module = FilterModule()
    assert filter_module.filters()['intersect'](None, ['abc', 'def', 'ghi'], ['def', 'xyz']) == ['def']
    assert filter_module.filters()['intersect'](None, ['abc', 'def', 'ghi'], ['def', 'def']) == ['def']
    assert filter_module.filters()['intersect'](None, [1, 2], [1, 1]) == [1]
    assert filter_module.filters()['intersect'](None, [1, 2], [3, 4]) == []
    assert filter_module.filters()['intersect'](None, [], []) == []

# Generated at 2022-06-21 04:45:13.832619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    from ansible.module_utils.common.text import formatters
    from ansible.module_utils.six import text_type

    from ansible.module_utils.six.moves import zip, zip_longest

    from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError
    from ansible.utils.display import Display

    # mock the display class
    display = Display()
    display.warning = mock.Mock()

    fm = FilterModule()
    filters = fm.filters()

    x = 5
    y = 3
    z = 2

    # general math
    assert filters['min']([x,y,z]) == min([x,y,z])
    assert filters['max']([x,y,z]) == max([x,y,z])

    # exp

# Generated at 2022-06-21 04:45:17.745584
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([3, 2, 1]) == 1
    assert min(['b', 'c', 'a']) == 'a'



# Generated at 2022-06-21 04:45:21.183337
# Unit test for function union
def test_union():
    f = FilterModule()
    value = f.filters()['union'](None, [1, 2, 3], [4, 5, 6], [4, 5, 1])
    assert value == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 04:45:36.571169
# Unit test for function symmetric_difference
def test_symmetric_difference():
    """Tests the filtering of symmetric_difference."""

    # Set setup
    intersection = set([1, 2])
    a = set([1, 2, 3])
    b = set([2, 4])
    expected = set([1, 3, 4])

    # Iterable test (list)
    result = symmetric_difference(None, list(a), list(b))  # Empty environment
    assert isinstance(result, list) and expected.issubset(result) and len(result) == len(expected)

    # Set test
    result = symmetric_difference(None, a, b)  # Empty environment
    assert isinstance(result, set) and expected.issubset(result) and len(result) == len(expected)

    # Mock environment test

# Generated at 2022-06-21 04:45:46.858464
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2
    assert inversepower(8) == 2.0
    assert inversepower(27, 3) == 3.0
    assert inversepower(128, 4) == 2.0
    assert inversepower(16, 2, 2) == 4.0
    with (raises(AnsibleFilterTypeError)):
        inversepower('thisisnotanumber')
    with (raises(AnsibleFilterTypeError)):
        inversepower(10, 'thisisnotanumber')
    with (raises(AnsibleFilterTypeError)):
        inversepower(10, 2, 'thisisnotanumber')
    with (raises(AnsibleFilterError)):
        inversepower(-10, 2)
    with (raises(AnsibleFilterError)):
        inversepower(10, -2)


# Generated at 2022-06-21 04:45:52.573654
# Unit test for function min
def test_min():
    obj = FilterModule()
    filters = obj.filters()

    assert min([1, 2, 3]) == filters['min']([1, 2, 3])
    assert min(1, 2, 3) == filters['min']([1, 2, 3])


# Generated at 2022-06-21 04:45:54.987867
# Unit test for function min
def test_min():
    assert min([1, 3, 2]) == 1
    assert min([1, 3, 2]) != 2


# Generated at 2022-06-21 04:46:04.058811
# Unit test for function min
def test_min():
    assert min([9, -4, 3, 0]) == -4
    assert min([9, '-4', 3, 0]) == -4
    # Check that we preserve floating point zeros
    assert min([1, 0.0, 2]) == 0.0
    assert min([[9, -4], [3, 0]]) == -4

    # Now test with kwargs
    assert min([9, -4, 3, 0], default=0) == -4
    assert min([], default=0) == 0
    assert min([[], [9, -4], [3, 0]], default=[]) == -4



# Generated at 2022-06-21 04:46:10.836365
# Unit test for function union
def test_union():
    assert union([1, 2, 3], [2, 4, 6]) == [1, 2, 3, 4, 6]
    assert union('abc', ['a', 'b', 'c']) == ['a', 'b', 'c']
    assert union('abc', ['a', 'b', 'c', 'a']) == ['a', 'b', 'c']
    assert union(['a', 'b', 'c'], 'abc') == ['a', 'b', 'c']


# Generated at 2022-06-21 04:46:13.533531
# Unit test for function intersect
def test_intersect():
    data1 = ['a', 'b', 'c']
    data2 = ['b', 'c']
    assert intersect(None, data1, data2) == ['b', 'c']

# Generated at 2022-06-21 04:46:26.581197
# Unit test for function intersect
def test_intersect():
    """Unit test for function intersect"""
    from ansible.module_utils.common.text import format_json
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_function = filters.get('intersect')

    # test with two lists:
    first_list = [1,2,3]
    second_list = [2,3,4]
    assert filter_function(first_list, second_list) == [2,3]

    # test with two dictionaries:
    first_dict = {"first_key" : "first_value", "second_key" : "second_value"}
    second_dict = {"third_key" : "third_value", "second_key" : "second_value"}
    assert filter_function(first_dict, second_dict) == ['second_key']

# Generated at 2022-06-21 04:46:31.533696
# Unit test for function logarithm
def test_logarithm():
    # Test with base as e
    assert(logarithm(math.e) == 1)
    # Test with base as 10
    assert(logarithm(100,10) == 2)



# Generated at 2022-06-21 04:46:33.872461
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3


# Generated at 2022-06-21 04:46:58.250508
# Unit test for function intersect
def test_intersect():
    f = FilterModule()
    lst = ['a', 'b', 'c', 'd']
    for i in range(1, 4):
        for item in itertools.combinations(lst, i):
            res = f.filters()['intersect'](lst, item)
            assert(sorted(res) == sorted(item))
            res = f.filters()['intersect'](item, lst)
            assert(sorted(res) == sorted(item))
        for x in range(i):
            item = list(itertools.combinations(lst, i))[x]
            res = f.filters()['intersect'](item, item)
            assert(sorted(res) == sorted(item))

# Generated at 2022-06-21 04:47:02.976709
# Unit test for function difference
def test_difference():
    a = ['a', 'b', 'c', 'd', 'e']
    b = ['e', 'f', 'g', 'h']

    # Test that the function behaves like a set
    assert difference(None, a, b) == set(a) - set(b)
    # Test that the function behaves when the first argument is not a set
    assert difference(None, b, a) == unique(None, [x for x in b if x not in a], True)


# Generated at 2022-06-21 04:47:18.831251
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils._text import to_bytes
    import json


# Generated at 2022-06-21 04:47:30.762077
# Unit test for function union
def test_union():
    # test intersection of two different lists
    test_list1 = [1, 2, 3, 4]
    test_list2 = [3, 4, 5, 6]
    assert union(None, test_list1, test_list2) == [1, 2, 3, 4, 5, 6]
    # test intersection of two identical lists
    test_list1 = [1, 2, 3, 4]
    test_list2 = [1, 2, 3, 4]
    assert union(None, test_list1, test_list2) == [1, 2, 3, 4]
    # test intersection of two empty lists
    test_list1 = []
    test_list2 = []
    assert union(None, test_list1, test_list2) == []
    # test intersection of two lists, one empty
    test_list

# Generated at 2022-06-21 04:47:42.017037
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from jinja2 import Environment
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    env = Environment()
    env.filters.update(FilterModule().filters())

    a = ['dog', 'cat', 'fish']
    b = ['cat', 'cow', 'fish', 'horse']
    c = env.from_string(
        '{{ a|symmetric_difference(b)|list }}'
    ).render(a=a, b=b)
    assert c == "['cow', 'dog', 'horse']"

    d = env.from_string(
        '{{ a|symmetric_difference(b)|list }}'
    ).render(a=a, b=b)
    assert d == "['cow', 'dog', 'horse']"

    #

# Generated at 2022-06-21 04:47:47.431099
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([[0], [1]]) == [0]
    assert min() == None
    assert min(iter([0, 1])) == 0
    assert min(iter([1, 0])) == 0

    assert min([1, 2, 3], [1, 1, 4]) == [1, 1, 3]
    assert min([[0], [1]], [[1], [3]]) == [[0], [1]]

    assert min('abc') == 'a'
    assert min('abcd', 'abef') == 'abcd'

    assert min(1, 2) == 1
    assert min([1, 2], 2) == 1
    assert min(1, [1, 2]) == 1


# Generated at 2022-06-21 04:48:00.474261
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest

    class TestCases(unittest.TestCase):
        def test_rekey_on_member_001(self):
            test_list = [
                {
                    'a': 1,
                    'b': 2,
                    'c': 3,
                },
                {
                    'a': 5,
                    'b': 6,
                    'c': 7,
                },
            ]
            expected = {
                1: {'a': 1, 'b': 2, 'c': 3},
                5: {'a': 5, 'b': 6, 'c': 7},
            }

            self.assertEqual(rekey_on_member(test_list, 'a'), expected)

        def test_rekey_on_member_002(self):
            test_

# Generated at 2022-06-21 04:48:02.411006
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1
    assert min([1, 2, 3, 4], attribute='seq') == [1, 2, 3, 4]



# Generated at 2022-06-21 04:48:16.749714
# Unit test for function inversepower
def test_inversepower():
    # ValueError integer division
    try:
        inversepower(4, 0)
    except AnsibleFilterTypeError:
        pass
    else:
        print("Failed to raise value error on inversepower with base 0")

    # ValueError for negative base on square root
    try:
        inversepower(-4, 2)
    except AnsibleFilterTypeError:
        pass
    else:
        print("Failed to raise value error on inversepower with negative base 2")

    # ValueError for negative base on other root
    try:
        inversepower(-4, 3)
    except AnsibleFilterTypeError:
        pass
    else:
        print("Failed to raise value error on inversepower with negative base 3")

    # ValueError for negative base on other root

# Generated at 2022-06-21 04:48:26.901466
# Unit test for function union
def test_union():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    my_filter = FilterModule()
    env = {
        'vars': {
            'hostvars': UnsafeProxy(HostVars()),
            'ansible_reserved': Reserved(),
        },
    }

    a = [1, 2, 3, 4]
    b = [3, 4, 5, 6]
    c = [1, 2, 3, 4, 5, 6]
    assert c == my_filter.filters()['union'](env, a, b)


# Generated at 2022-06-21 04:48:53.757516
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:48:58.584277
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10) == math.log(10)
    assert logarithm(10, 10) == math.log10(10)
    assert logarithm(2, 1.5) == math.log(2, 1.5)
    try:
        logarithm("a")
        assert False, 'logarithm("a") must throw AnsibleFilterTypeError'
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-21 04:49:04.204281
# Unit test for function unique
def test_unique():
    def _test_unique(data, ref, case_sensitive=None, attribute=None, expected_exception=None):
        if expected_exception is None:
            expected = ref
        else:
            expected = None

        try:
            ret = unique(data, case_sensitive=case_sensitive, attribute=attribute)
        except Exception as e:
            if expected_exception:
                if isinstance(expected_exception, list):
                    r = False
                    for ex in expected_exception:
                        r = r or isinstance(e, ex)
                    if not r:
                        raise
                else:
                    if not isinstance(e, expected_exception):
                        raise
            else:
                raise
        else:
            if expected_exception:
                raise AssertionError("Expected exception not raised")

# Generated at 2022-06-21 04:49:08.352518
# Unit test for function symmetric_difference
def test_symmetric_difference():

    assert(symmetric_difference([1,2,3], [2,3,4]) == [1, 4])
    assert(symmetric_difference([1,1,1], [2,2,2]) == [1, 1, 1, 2, 2, 2])
    assert(symmetric_difference([1,2,3], [1,2,3]) == [])

# Generated at 2022-06-21 04:49:16.962982
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10) == 2.302585092994046
    assert logarithm(5, 5) == 1.0
    assert logarithm(5, 10) == 0.6989700043360187
    try:
        logarithm("a")
        raise Exception("Logarithm of a string should not return anything but an error")
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-21 04:49:28.602844
# Unit test for function intersect
def test_intersect():
    f = FilterModule()
    assert f.filters()['intersect'](range(10), range(5)) == [0, 1, 2, 3, 4]
    assert f.filters()['intersect'](range(10), range(5, 10)) == [5, 6, 7, 8, 9]
    assert f.filters()['intersect'](range(10), range(5, 12)) == [5, 6, 7, 8, 9]
    assert f.filters()['intersect'](range(5, 10), range(5, 12)) == [5, 6, 7, 8, 9]
    assert f.filters()['intersect'](range(5, 10), range(0, 4)) == []

# Generated at 2022-06-21 04:49:36.518013
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters().keys() == {'min', 'max', 'log', 'pow', 'root', 'unique', 'intersect', 'difference', 'symmetric_difference',
                                   'union', 'product', 'permutations', 'combinations', 'human_readable', 'human_to_bytes',
                                   'rekey_on_member', 'zip', 'zip_longest'}

# Generated at 2022-06-21 04:49:47.739671
# Unit test for function min
def test_min():
    assert min([1, 2, 3], [2, 3, 4]) == 1
    assert min(1, 2, 3) == 1
    assert min(1, 2, 3, key=lambda x: -x) == 3
    assert min(1, 2, 3, default=-1) == 1
    assert min([], default=-1) == -1
    assert min({'a': 1, 'b': 2}, {'a': 2, 'b': 1}) == {'a': 1, 'b': 2}
    assert min(['a', 'b'], ['a', 'b']) == 'a'

# Generated at 2022-06-21 04:49:57.199034
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from units import units

    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1kB') == 1000
    assert human_to_bytes('1KiB') == 1024
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1MiB') == 1048576
    assert human_to_bytes('1GB') == 1000000000
    assert human_to_bytes('1GiB') == 1073741824
    assert human_to_bytes('1TB') == 1000000000000
    assert human_to_bytes('1TiB') == 1099511627776
    assert human_to_bytes('1PB') == 1000000000000000
    assert human_to_bytes('1PiB') == 1125899906842624

# Generated at 2022-06-21 04:50:03.507082
# Unit test for function power
def test_power():
    """
    Test for the power filter.
    """
    t = FilterModule()
    assert t.filters()['pow'](2, 5) == 32
    assert t.filters()['pow'](2.5, 3) == 15.625
    try:
        t.filters()['pow']('a', 2)
    except AnsibleFilterTypeError as e:
        assert '2' in to_native(e)
        assert 'pow() can only be used on numbers:' in to_native(e)