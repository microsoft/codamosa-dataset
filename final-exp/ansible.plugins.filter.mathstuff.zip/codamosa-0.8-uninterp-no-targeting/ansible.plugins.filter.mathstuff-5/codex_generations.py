

# Generated at 2022-06-21 04:40:43.789216
# Unit test for function max
def test_max():
    assert max(1, 2) == 2
    assert max(3.3, 1.1) == 3.3
    assert max(1, 2.2) == 2.2
    assert max([1, 2]) == 2
    assert max([2, 1]) == 2
    assert max([3.3, 1.1]) == 3.3
    assert max([1.1, 3.3]) == 3.3
    assert max((1, 2)) == 2
    assert max((2, 1)) == 2
    assert max((3.3, 1.1)) == 3.3
    assert max((1.1, 3.3)) == 3.3
    assert max(dict(a=1, b=2), key=lambda x: x[1]) == 'b'

# Generated at 2022-06-21 04:40:45.253389
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3



# Generated at 2022-06-21 04:41:00.458412
# Unit test for function symmetric_difference
def test_symmetric_difference():
    # Test 1
    # input1 = [1,2,3,4,5]
    # input2 = [4,5,6,7,8]
    # output = [1,2,3,6,7,8]
    assert symmetric_difference([1, 2, 3, 4, 5], [4, 5, 6, 7, 8]) == [1, 2, 3, 6, 7, 8]

    # Test 2
    # input1 = [1,2,3,4,5]
    # input2 = []
    # output = [1,2,3,4,5]
    assert symmetric_difference([1, 2, 3, 4, 5], []) == [1, 2, 3, 4, 5]

    # Test 3
    # input1 = []
    # input2 = [4,

# Generated at 2022-06-21 04:41:08.448394
# Unit test for function max
def test_max():
    # Create objects to test with
    systest = type('sys', (object,), {'maxint': 2**63-1})
    sys = systest()

    # Test against typical maxint
    assert max([1, 2]) == 2
    assert max([sys.maxint, sys.maxint]) == sys.maxint
    assert max([-1, -2]) == -1
    assert max([-sys.maxint-1, -sys.maxint-1]) == -sys.maxint-1
    assert max([1.0, 2.0]) == 2.0
    assert max([float(sys.maxint), float(sys.maxint)]) == float(sys.maxint)
    assert max([-1.0, -2.0]) == -1.0

# Generated at 2022-06-21 04:41:13.432551
# Unit test for function power
def test_power():
    assert power(2, 3) == 8

    try:
        power(2, "3")
    except AnsibleFilterTypeError as e:
        assert to_text(e) == 'pow() can only be used on numbers: must be real number, not str'
    else:
        assert False, "AnsibleFilterTypeError not raised"



# Generated at 2022-06-21 04:41:25.706668
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1024k') == 1048576
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1') == 0
    assert human_to_bytes('2k') == 2048
    assert human_to_bytes('0') == 0
    assert human_to_bytes('0g') == 0
    assert human_to_bytes('0m') == 0
    assert human_to_bytes('0k') == 0
    assert human_to_bytes('0kb') == 0

# Generated at 2022-06-21 04:41:32.249815
# Unit test for function power
def test_power():
    assert power(1, 1) == 1
    assert power(-1, 1) == -1
    assert power(-1, 2) == 1
    assert power(-1, 3) == -1
    assert power(2, 2) == 4
    assert power(2, 3) == 8
    assert power(2, 4) == 16


# Generated at 2022-06-21 04:41:40.923184
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    filters = filter_module.filters()
    max_int = filters['max']([1, 2, 3])
    max_float = filters['max']([3.3, 1.1, 2.2])
    max_dict = filters['max']([{"name": "B"}, {"name": "A"}], "name")
    max_mixed = filters['max']([None, 3, 2], default=3)
    max_mixed_boolean = filters['max']([None, False, True])
    max_none = filters['max']()
    assert max_int == 3
    assert max_float == 3.3
    assert max_dict == {"name": "B"}
    assert max_mixed == 3
    assert max_mixed_boolean is True
   

# Generated at 2022-06-21 04:41:49.326174
# Unit test for function symmetric_difference
def test_symmetric_difference():
    from jinja2 import DictLoader, Environment

    env = Environment(loader=DictLoader(dict(testcase.j2 for testcase in testcases)))
    for testcase in testcases:
        for test in testcase.tests:
            if testcase.expected_exception is not None:
                try:
                    result = env.from_string('{{ a|symmetric_difference(b) }}').render(**test['input'])
                except Exception as e:
                    if testcase.expected_exception is not None:
                        assert isinstance(e, testcase.expected_exception)
                else:
                    raise Exception("Should have gotten an exception")
            else:
                result = env.from_string('{{ a|symmetric_difference(b) }}').render(**test['input'])
                assert test

# Generated at 2022-06-21 04:42:00.317255
# Unit test for function unique
def test_unique():
    # Basic functionality
    assert unique([1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5], False) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5], True) == [1, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5]
    # Empty list
    assert unique([], False) == []
    # List with one element
    assert unique([1], False) == [1]

    # Test with strings
    # Basic functionality

# Generated at 2022-06-21 04:42:13.267023
# Unit test for function union
def test_union():
    a = [1, 2, 3, 4]
    b = [3, 4, 5, 6]
    assert union(a, b) == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-21 04:42:15.768749
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert hasattr(fm, 'filters')


# Generated at 2022-06-21 04:42:19.511713
# Unit test for function intersect
def test_intersect():
    assert intersect([1, 2, 3, 8, 5], [3, 6, 2, 5, 2, 0]) == [2, 3, 5]

# Generated at 2022-06-21 04:42:23.063520
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1



# Generated at 2022-06-21 04:42:32.989955
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1024) == "1.0K"
    assert human_readable(1024, True) == "1.0Ki"
    assert human_readable(1024, False, "KB") == "1.0KB"
    assert human_readable(1024, True, "KB") == "1.0KiB"
    assert human_readable(1024, False, "B") == "1024.0B"
    assert human_readable(1024, True, "B") == "1024.0B"
    assert human_readable(1024, False, "") == "1024.0"
    assert human_readable(1024, True, "") == "1024.0"
    assert human_readable(1024, False, " ") == "1024.0 "
    assert human_readable(1024, True, " ") == "1024.0 "

# Generated at 2022-06-21 04:42:36.478453
# Unit test for function power
def test_power():

    assert power(2, 3) == 8
    assert power(2.0, 3.5) == 2.0**3.5
    assert power(2.0, -3) == 2.0**-3

    try:
        power(2.0, 'k')
        assert False
    except AnsibleFilterTypeError:
        assert True

# Generated at 2022-06-21 04:42:43.836307
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    f = fm.filters()

    # general math
    assert f['min'][0]([1, 2, 3]) == 1
    assert f['max'][0]([1, 2, 3]) == 3

    # exponents and logarithms
    assert f['log'][0](10, 10) == 1.0
    assert f['pow'][0](2, 10) == 1024.0
    assert f['root'][0](1024, 2) == 32.0

    # set theory
    assert f['unique'][0]([1, 2, 4, 2, 1, 4, 3, 5, 6, 7, 5]) == [1, 2, 4, 3, 5, 6, 7]

# Generated at 2022-06-21 04:42:50.211304
# Unit test for function intersect
def test_intersect():
    # Make sure arguments are lists
    args = ['a', 'b', 'c']
    try:
        assert intersect(None, *args) == set(args)
        assert intersect(None, args[2:], args[1:]) == set(args[1:3])
    except Exception as e:
        print(e)
        raise



# Generated at 2022-06-21 04:42:57.993072
# Unit test for function inversepower
def test_inversepower():
    assert 1 == inversepower(1)
    assert 1 == inversepower(1, 2)
    assert 2 == inversepower(4, 2)
    assert 3 == inversepower(9, 2)
    assert 2 == inversepower(8, 3)
    assert 3 == inversepower(27, 3)
    try:
        inversepower(-1, 2)
        assert False
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:42:58.794231
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:43:20.015087
# Unit test for constructor of class FilterModule
def test_FilterModule():
    t = FilterModule()
    assert t is not None

# Generated at 2022-06-21 04:43:31.847993
# Unit test for function union
def test_union():

    # First set of args
    set_a = set(['foo', 'bar'])
    set_b = set(['baz', 'qux'])

    # Second set of args (list)
    set_c = ['one', 'two']
    set_d = ['three', 'four']

    # Third set of args (list and set)
    set_e = ['one', 'two']
    set_f = set(['three', 'four'])

    # Fourth set of args (actually a list of lists)
    set_g = ['one', ['two', 'three']]
    set_h = ['four', ['five', 'six']]

    # First set of args (should return a set)
    union_a = union(None, set_a, set_b)

# Generated at 2022-06-21 04:43:43.735413
# Unit test for function difference
def test_difference():
    assert ['a','b','c',None] == difference([1,2,3,4], [1,2])
    assert {'a':'b'} == difference({'a':'b', 'c':'d'}, ['c'])
    assert {'a':'b'} != difference({'a':'b', 'c':'d'}, ['c', 'd'])
    assert ['a','b','c',None] == difference(['a','b','c',None], ['b','c',None], case_sensitive=True)
    assert ['a','b','c',None] == difference(['a','B','C',None], ['b','c',None], case_sensitive=False)

# Generated at 2022-06-21 04:43:51.900407
# Unit test for function symmetric_difference
def test_symmetric_difference():
    import jinja2
    e = jinja2.Environment()
    assert symmetric_difference(e, [1, 2, 3, 4, 5], [4, 5, 6, 7, 8]) == [1, 2, 3, 6, 7, 8]
    assert symmetric_difference(e, "abcdefg", "abcdefg") == []



# Generated at 2022-06-21 04:44:00.080219
# Unit test for function power
def test_power():
    import filters
    assert filters.power(2, 3) == 8, "2^3 should be 8"
    assert filters.power(5, 2) == 25, "5^2 should be 25"
    assert filters.power(5, 0) == 1, "5^0 should be 1"
    assert filters.power(2, 5) == 32, "2^5 should be 32"



# Generated at 2022-06-21 04:44:04.788620
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(3, 2) == 9
    assert power(1, 6) == 1
    assert power(2, 0) == 1
    assert power(0, 2) == 0
    assert power(0, 0) == 1
    try:
        power("a", 3)
        raise AssertionError("Failed to raise AnsibleFilterTypeError with bad input")
    except AnsibleFilterTypeError:
        pass
    except Exception:
        raise AssertionError("Raised wrong exception with bad input")


# Generated at 2022-06-21 04:44:16.273963
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([0, 1, 2, 3], 2) == 2
    assert min([0, 1, 2, 3], key=lambda x: -x) == 3
    assert min([0, 1, 2, 3], default=False) == 0
    assert min(['ZZZ', 'AAA', 'bbb']) == 'AAA'
    assert min(['ZZZ', 'AAA', 'bbb'], key=lambda s: s.lower()) == 'AAA'
    assert min(['ZZZ', 'AAA']) == 'AAA'
    assert min(['ZZZ', 'AAA'], key=lambda s: s.lower()) == 'AAA'
    assert min(['AAAA', 'ZZZ', 'aaa']) == 'AAAA'

# Generated at 2022-06-21 04:44:26.009723
# Unit test for function inversepower
def test_inversepower():
    ''' Test Ansible math jinja2 filters '''
    assert inversepower(16) == 4
    assert inversepower(27, 3) == 3

    # Test bad input
    try:
        inversepower('abc', 2)
        assert False, "Failed to raise AnsibleFilterTypeError Exception"
    except AnsibleFilterTypeError as e:
        assert type(e) == AnsibleFilterTypeError

    try:
        inversepower(123, 'abc')
        assert False, "Failed to raise AnsibleFilterTypeError Exception"
    except AnsibleFilterTypeError as e:
        assert type(e) == AnsibleFilterTypeError


# Generated at 2022-06-21 04:44:30.468254
# Unit test for function difference
def test_difference():

    a = [1, 2, 3, 4]
    b = [1, 3, 5, 6]
    c = difference(None, a, b)
    assert c == [2, 4]

# Generated at 2022-06-21 04:44:37.678393
# Unit test for function symmetric_difference
def test_symmetric_difference():
    environment={}
    a=['a', 'b', 'c']
    b=['b', 'c', 'd']
    expected = ['a', 'd']

    # Test function symmetric_difference
    assert symmetric_difference(environment, a, b) == expected


# Generated at 2022-06-21 04:45:12.214397
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_rekey_on_member_errors_in_bad_input(self):
            with self.assertRaises(AnsibleFilterError) as context:
                rekey_on_member('foo', 'bar')
            self.assertIn('something other than a dict', to_text(context.exception))


# Generated at 2022-06-21 04:45:21.616380
# Unit test for function unique
def test_unique():
    for good, bad in (
        ('abcdeabcdeabc', 'abc'),
        ('abc123abc123abc', 'abc123'),
        ('aabbccddeeff', 'abcdef'),
        ('aabbccddeeff', 'fedcba'),
        (['ab', 'ba', 'ac', 'ca', 'cd', 'dc'], 'abc'),
        (['ab', 'ba', 'ac', 'ca', 'cd', 'dc'], 'abc'),
    ):
        assert unique(None, good) == bad, "good=%r bad=%r" % (good, bad)



# Generated at 2022-06-21 04:45:30.869615
# Unit test for function difference
def test_difference():
    assert difference([1, 2, 3], [2, 3, 4]) == [1]
    assert difference([1, 2, 3, 4], [2, 3, 4]) == [1]
    assert difference([1, 2, 3], [3, 4]) == [1, 2]
    assert difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert difference(['white', 'red', 'blue'], ['red', 'black']) == ['white', 'blue']

# Generated at 2022-06-21 04:45:37.774496
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min([-1,1,3]) == -1
    assert min((-1,1,3)) == -1
    assert min(-1,1,3) == -1
    assert min(-1,1,[3,4]) == -1


# Generated at 2022-06-21 04:45:46.111574
# Unit test for function symmetric_difference
def test_symmetric_difference():
    filters = FilterModule().filters()
    assert filters['symmetric_difference']([1, 2, 3, 4], [3, 4, 5, 6]) == [1, 2, 5, 6]
    assert filters['symmetric_difference'](['a', 'b', 'c', 'd'], ['c', 'd', 'e', 'f']) == ['a', 'b', 'e', 'f']
    assert filters['symmetric_difference'](set([1, 2, 3, 4]), set([3, 4, 5, 6])) == [1, 2, 5, 6]

# Generated at 2022-06-21 04:45:49.808247
# Unit test for function intersect
def test_intersect():
    intersect_test = intersect(['a', 'b', 'c', 'd'], ['c', 'd', 'e', 'f'])
    assert intersect_test == ['c', 'd']



# Generated at 2022-06-21 04:45:53.806544
# Unit test for function min
def test_min():
    """ Test Ansible's min jinja filter. """
    randomNumbers = [2, 3, 1]
    assert min(randomNumbers) == 1



# Generated at 2022-06-21 04:46:01.898134
# Unit test for function unique
def test_unique():
    '''test the unique filter'''
    # Test case using a dict with a key/value pair
    test_dict = dict()
    test_dict['key'] = 0
    test_dict['key2'] = 1
    test_dict['key3'] = 0
    test_dict['key4'] = 1
    test_dict['key5'] = 2
    output = unique(test_dict, case_sensitive=True, attribute=None)

    # Test case using a list of ints
    test_list = [0, 0, 1, 2, 3, 1, 2, 3]
    output2 = unique(test_list, case_sensitive=True, attribute=None)

    # Test case using a list of strings
    test_list_str = ['a', 'b', 'a', 'c', 'c', 'd', 'a']

# Generated at 2022-06-21 04:46:12.671259
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('100') == 100)
    assert(human_to_bytes('100') == human_to_bytes('100B'))
    assert(human_to_bytes('1K') == human_to_bytes('1k'))
    assert(human_to_bytes('1M') == human_to_bytes('1m'))
    assert(human_to_bytes('1G') == human_to_bytes('1g'))
    assert(human_to_bytes('1T') == human_to_bytes('1t'))
    assert(human_to_bytes('1P') == human_to_bytes('1p'))
    assert(human_to_bytes('1E') == human_to_bytes('1e'))

# Generated at 2022-06-21 04:46:19.946434
# Unit test for function unique
def test_unique():
    import uuid

    dummy_env = type('dummy_env', (object,), {'globals': {}})()
    strings = ['foo', 'bar', 'bar']
    result = unique(dummy_env, strings)
    assert result == ['foo', 'bar'], result
    result = unique(dummy_env, strings, case_sensitive=False)
    assert result == ['foo', 'bar'], result

    class A(object):
        def __init__(self):
            self.id = uuid.uuid4().hex
        def __eq__(self, other):
            return self.id == other.id
        def __ne__(self, other):
            return self.id != other.id
        def __hash__(self):
            return hash(self.id)


# Generated at 2022-06-21 04:46:35.901660
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:46:36.849329
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:46:45.426284
# Unit test for function inversepower
def test_inversepower():
    fm = FilterModule()
    filters = fm.filters()

    # Testing code
    def _run_test(input_value, expected, base=2):
        actual = filters.get('root')(input_value, base)
        assert actual == expected, "Expected '{0}', got '{1}'".format(expected, actual)

    # Test cases
    _run_test(4, 2)
    _run_test(81, 9)
    _run_test(8, 2, base=3)
    _run_test(27, 3, base=3)
    _run_test(27, 27, base=1)
    _run_test(27, 1, base=27)
    _run_test(27, 1, base=0)

# Generated at 2022-06-21 04:46:48.122672
# Unit test for function power
def test_power():
    assert power(2, 3) == 8, "Failed to compute 2^3"

# Generated at 2022-06-21 04:46:54.407865
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(16, 2) == 4
    assert inversepower(8, 3) == 2
    assert inversepower(100, 2) == 10
    assert inversepower(100, 3) == 4.641588833612779
    assert inversepower(64, 4) == 2


# Generated at 2022-06-21 04:46:56.780248
# Unit test for function logarithm
def test_logarithm():
    assert do_logarithm(10, 10) == 1
    assert do_logarithm(10, 2) == 3.3219280948873622
    assert do_logarithm(100) == 4.605170185988091
    try:
        do_logarithm(100, 4)
        assert False
    except AnsibleFilterTypeError:
        assert True

# Generated at 2022-06-21 04:47:05.166402
# Unit test for function human_readable
def test_human_readable():
    #
    # No scale.
    #

    # Bytes.
    assert human_readable(0) == '0'
    assert human_readable(1) == '1.0'
    assert human_readable(1.1) == '1.1'
    assert human_readable(100) == '100.0'
    assert human_readable(999) == '999.0'
    assert human_readable(1023) == '1023.0'
    assert human_readable(1024) == '1.0 KB'
    assert human_readable(1025) == '1.0 KB'
    assert human_readable(1536) == '1.5 KB'
    assert human_readable(2048) == '2.0 KB'
    assert human_readable(3072) == '3.0 KB'
    assert human_readable

# Generated at 2022-06-21 04:47:20.212143
# Unit test for function human_to_bytes
def test_human_to_bytes():
    test_pairs = {
        "1024": 1024,
        "1k": 1024,
        "1K": 1024,
        "2M": 2097152,
        "2.5G": 268435456,
        "3T": 3221225472,
        "3P": 3298534883328,
        "3E": 34359738368,
        "3Z": 35184372088832,
        "2048GB": 2199023255552,
        "5.5X": 5975229130921984
    }
    for s, value in test_pairs.items():
        assert human_to_bytes(s) == value
        assert human_to_bytes(s.lower()) == value
        assert human_to_bytes(s.upper()) == value

# Generated at 2022-06-21 04:47:32.063092
# Unit test for function intersect
def test_intersect():

    class TestArgs():
        def __init__(self, environment, a, b):
            self.a = a
            self.b = b

    s = {'a', 'b', 'c'}
    t = {'c', 'd', 'e'}
    u = {'a', 'b', 'c', 'd', 'e'}
    v = ['a', 'b', 'c']
    w = ['c', 'd', 'e']
    x = ['a', 'b', 'c', 'd', 'e']

    # testing for case 1: both arguments are sets
    args = TestArgs('filter', s, t)
    result_1 = intersect(args, s, t)

# Generated at 2022-06-21 04:47:35.397485
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 4, 5, 5, 1, 2]) == [1, 2, 3, 4, 5]

# Generated at 2022-06-21 04:48:03.432116
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0.0 B'
    assert human_readable(1) == '1.0 B'
    assert human_readable(2**10) == '1.0 KB'
    assert human_readable(2**20) == '1.0 MB'
    assert human_readable(2**30) == '1.0 GB'
    assert human_readable(2**40) == '1.0 TB'
    assert human_readable(2**50) == '1.0 PB'
    assert human_readable(2**60) == '1.0 EB'
    assert human_readable(2**70) == '1.0 ZB'
    assert human_readable(2**80) == '1.0 YB'
    assert human_readable(2**90) == '1024.0 YB'

# Generated at 2022-06-21 04:48:14.301752
# Unit test for function rekey_on_member
def test_rekey_on_member():
    ''' Unit test function for rekey_on_member '''

    data = dict(zip(string.ascii_letters, range(26)))
    data['_'] = 'bad_value'


# Generated at 2022-06-21 04:48:20.155205
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, base=10) == 1.0
    assert logarithm(100, base=10) == 2.0
    assert logarithm(1000, base=10) == 3.0



# Generated at 2022-06-21 04:48:22.569740
# Unit test for function max
def test_max():

    assert max([1,2,3,4]) == 4
    assert max([1,2,3,4], key=lambda x: -x) == 1


# Generated at 2022-06-21 04:48:33.537734
# Unit test for function inversepower
def test_inversepower():
    filter = FilterModule()
    f = filter.filters()['root']

    # test with valid numbers
    assert f(16, 2) == 4
    assert f(16, 4) == 2
    assert f(343, 3) == 7

    # test with invalid numbers
    import pytest
    with pytest.raises(AnsibleFilterTypeError):
        f(9.5, 2)
    with pytest.raises(AnsibleFilterTypeError):
        f(4, 1.5)



# Generated at 2022-06-21 04:48:44.426990
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Kb') == 1024
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mb') == 1048576
    assert human_to_bytes('1MB') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gb') == 10737418

# Generated at 2022-06-21 04:48:46.556812
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:48:58.074918
# Unit test for function intersect
def test_intersect():
    basic_test_actual = intersect([1, 2, 3, 4], [3, 4, 5, 6])
    basic_test_expected = [3, 4]
    assert basic_test_actual == basic_test_expected, "returned list should be {0}, not {1}".format(basic_test_expected, basic_test_actual)

    # For the rest of the tests, set elements that are not integers to test that this function works
    # with non-integer types

    single_element_test_actual = intersect([1, 3, "a"], [3, "a"])
    single_element_test_expected = [3, "a"]

# Generated at 2022-06-21 04:49:08.889286
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.network_common import dict_merge

    test_data_1 = dict(a=dict(key1='val1', key2='val2'), b=dict(key1='val3', key2='val4'))
    test_result_1 = {'val1': dict(key1='val1', key2='val2'), 'val3': dict(key1='val3', key2='val4')}
    assert test_result_1 == rekey_on_member(test_data_1, 'key1')
    assert test_result_1['val1'] == dict_merge(test_data_1['a'], dict(key1='val1'))


# Generated at 2022-06-21 04:49:21.672712
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024 * 1024
    assert human_to_bytes('1GB') == 1024 * 1024 * 1024
    assert human_to_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1PB') == 1024 ** 5
    assert human_to_bytes('1EB') == 1024 ** 6
    assert human_to_bytes('1ZB') == 1024 ** 7
    assert human_to_bytes('1YB') == 1024 ** 8
    assert human_to_bytes('1BB') == 1024 ** 9

    assert human_to_bytes('1KB', 'B') == 1000
    assert human_to_bytes('1MB', 'B') == 1000 * 1000

# Generated at 2022-06-21 04:49:41.034716
# Unit test for function max
def test_max():
    assert max(range(1, 11)) == 10
    assert max(set(1,3,5,7,2,4,5)) == 7


# Generated at 2022-06-21 04:49:46.783857
# Unit test for function union
def test_union():
    '''
    Test that union computes the proper set-theory union result.
    '''

    # Test data
    sample_a = [1, 8, 3]
    sample_b = [2, 4, 1]

    sample_c = [2, 4, '1']
    sample_d = [1, 8, '3']

    sample_e = ['a', 'b', 'c']
    sample_f = ['b', 'c', 'a']

    # Expected result
    sample_a_b_union = [1, 8, 3, 2, 4]
    sample_c_d_union = [2, 4, '1', 1, 8, '3']
    sample_e_f_union = ['a', 'b', 'c']

    # Test union()

# Generated at 2022-06-21 04:50:00.239988
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert (human_to_bytes('1K') == 1024)
    assert (human_to_bytes('2M') == 2*1024*1024)
    assert (human_to_bytes('1G') == 1*1024*1024*1024)
    assert (human_to_bytes('1T') == 1*1024*1024*1024*1024)
    assert (human_to_bytes('1P') == 1*1024*1024*1024*1024*1024)
    assert (human_to_bytes('1E') == 1*1024*1024*1024*1024*1024*1024)
    assert (human_to_bytes('1Z') == 1*1024*1024*1024*1024*1024*1024*1024)
    assert (human_to_bytes('1Y') == 1*1024*1024*1024*1024*1024*1024*1024*1024)
   

# Generated at 2022-06-21 04:50:11.779614
# Unit test for function symmetric_difference
def test_symmetric_difference():
    '''
    The symmetric difference of any two sets is the union of their differences
    from each other, i.e.,
    A delta B = (A - B) union (B - A)

    https://en.wikipedia.org/wiki/Symmetric_difference
    '''

    try:
        import jinja2
    except ImportError:
        jinja2 = None

    if jinja2:
        env = jinja2.Environment()

        # Test trivial cases
        assert symmetric_difference(env, [1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
        assert symmetric_difference(env, [3, 2, 1], [3, 2, 1]) == []

# Generated at 2022-06-21 04:50:21.029685
# Unit test for function difference
def test_difference():
    assert difference([1,2,3], [2,3,4]) == [1]
    assert difference([1,2,3], [2]) == [1,3]
    assert difference([1,2,3], []) == [1,2,3]
    assert difference([1,2,3], [3,4,5]) == [1,2]
    assert difference([], [1,2,3]) == []
    assert difference({'a': 'b', 'b': 'c', 'c': 'd'}, ['a', 'c']) == [{'b': 'c'}]
