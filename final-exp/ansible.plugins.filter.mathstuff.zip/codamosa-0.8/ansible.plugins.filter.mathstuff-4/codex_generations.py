

# Generated at 2022-06-22 14:12:12.332905
# Unit test for function unique
def test_unique():
    # Test to make sure all the tests pass
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert unique(iterable=['foo', 'foo', 'bar', 'bar']) == ['foo', 'bar']
    assert unique(iterable=['foo', 'FOO', 'bar', 'BAR']) == ['foo', 'FOO', 'bar', 'BAR']
    assert unique(iterable=['foo', 'FOO', 'bar', 'BAR'], case_sensitive=False) == ['foo', 'bar']

# Generated at 2022-06-22 14:12:24.506444
# Unit test for function max
def test_max():
    # Test built-in max with list of numbers
    numbers_list = [1, 2, 3, 4, 5]
    assert 5 == max(numbers_list)

    # Test built-in max with list of strings
    string_list = ['a', 'b', 'c']
    assert 'c' == max(string_list)

    # Test built-in max with list of numbers and strings
    mixed_list = ['a', 'b', 1, 2, 3]
    assert 3 == max(mixed_list)

    # Test Jinja2 max keyword arguments
    keys = ['foo', 'bar', 'baz']
    values = [1, 2, 3]
    input_ = list(zip(keys, values))

# Generated at 2022-06-22 14:12:28.298872
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3

    assert max([1, 4, 2, 5, 3]) == 5


# Generated at 2022-06-22 14:12:38.734055
# Unit test for function min
def test_min():
    from jinja2 import Environment
    from ansible.plugins.filter.core import FilterModule as CoreFilterModule
    from ansible.plugins.filter.mathstuff import FilterModule as MathStuffFilterModule

    c = CoreFilterModule()
    c.filters()
    m = MathStuffFilterModule()
    m.filters()
    env = Environment()
    env.filters.update(c.filters())
    env.filters.update(m.filters())
    template = env.from_string('{{ [{}]|min }}')
    assert template.render() == '{}'
    template = env.from_string('{{ [{}, 1]|min }}')
    assert template.render() == '1'
    template = env.from_string('{{ [2, 1]|min }}')
    assert template

# Generated at 2022-06-22 14:12:51.670305
# Unit test for function rekey_on_member
def test_rekey_on_member():
    '''
    Rekey a dict of dicts on another member. It may also create a dict from a list of dicts.
    '''

    # list of dict

# Generated at 2022-06-22 14:13:01.973868
# Unit test for function human_readable
def test_human_readable():
    assert 0.01 == formatters.human_to_bytes('0.01')
    assert 10 == formatters.human_to_bytes('10')
    assert 1024 == formatters.human_to_bytes('1 KiB')
    assert 1048575 == formatters.human_to_bytes('1.00 MiB')
    assert 10485760 == formatters.human_to_bytes('10 MiB')
    assert 1048739 == formatters.human_to_bytes('1023.99 KiB')
    assert 10485760 == formatters.human_to_bytes('10 MB')
    assert 104857600 == formatters.human_to_bytes('100 MB')
    assert 104857600 == formatters.human_to_bytes('100 mb')

# Generated at 2022-06-22 14:13:08.263626
# Unit test for function min
def test_min():
    from jinja2 import Environment

    env = Environment()
    filters = FilterModule().filters()
    env.filters['min'] = filters['min']

    assert env.from_string("{{ [1,2,3]|min }}").render() == "1"
    assert env.from_string("{{ ['foo', 'bar', 'baz']|min }}").render() == "bar"


# Generated at 2022-06-22 14:13:20.053500
# Unit test for function human_to_bytes

# Generated at 2022-06-22 14:13:30.011657
# Unit test for function min
def test_min():
    assert min([10, 2], [20, 4]) == [10, 2]
    assert min(20, 4) == 4
    assert min(10.0, 2.0) == 2.0
    assert min("abc", "def") == "abc"
    assert min("abc", "ABC") == "ABC"
    assert min("abc", "ABC", key=str.lower) == "abc"
    assert min("abc", "ABC", key=str.upper) == "ABC"

    # expect an error
    try:
        min([1, 2, "string"])
        assert False
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-22 14:13:33.798175
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([-1.0, -2.0, -3.0]) == -3.0
    assert min(1, -2, 3, key=abs) == 1


# Generated at 2022-06-22 14:13:47.519501
# Unit test for function human_readable
def test_human_readable():
    ''' test_human_readable'''
    size = '16M'
    assert human_readable(size) == '16.0M', "human_readable({0}) != {1}".format(size, human_readable(size))
    size = '16.1M'
    assert human_readable(size) == '16.1M', "human_readable({0}) != {1}".format(size, human_readable(size))
    size = '16.000001M'
    assert human_readable(size) == '16.0M', "human_readable({0}) != {1}".format(size, human_readable(size))
    size = '16.0000001M'

# Generated at 2022-06-22 14:13:56.512642
# Unit test for function max
def test_max():
    assert max(range(0, 10)) == 9
    assert max(range(0, 10), start=10) == 19
    assert max(range(0, 10), start=10, step=2) == 9
    assert max(range(10)) == 0
    assert max(range(10), start=10, step=-1) == 10
    assert max("A", "z") == "z"
    assert max("A", "z", attr="upper") == "z"


# Generated at 2022-06-22 14:14:05.353052
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.utils.display import Display
    import ansible.utils.display
    from ansible.errors import AnsibleFilterError

    display = Display()

    def setUpModule():
        ''' Preparing mock objects to patch builtins later '''
        ansible.utils.display.Display = Display
        global MockBuiltin, MockAnsibleFallback
        from ansible.compat.tests.mock import MagicMock

        class MockBuiltin(MagicMock):
            ''' Mock builtins/__builtin__ module '''

            @staticmethod
            def get(name, default=None):
                return getattr(__builtins__, name, default)


# Generated at 2022-06-22 14:14:07.196900
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min(['a','b','c']) == 'a'


# Generated at 2022-06-22 14:14:09.550577
# Unit test for function max
def test_max():
    assert(max([1, 2, 3]) == 3)
    assert(max([5, 6, 3]) == 6)


# Generated at 2022-06-22 14:14:12.468123
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(math.e) == 1
    assert logarithm(10, base=10) == 1

# Unit tests for function power

# Generated at 2022-06-22 14:14:13.793629
# Unit test for function max
def test_max():
    """
    Test used by the test module.
    """
    return max(6, 2)

# Generated at 2022-06-22 14:14:17.183027
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([3, 2, 1]) == 1
    assert min(['3', '2', '1']) == '1'
    assert min(['3', '2', '1'], attribute=lambda x: int(x)) == '1'



# Generated at 2022-06-22 14:14:18.280448
# Unit test for function max
def test_max():
    assert max([0, 1, 2, 3]) == 3


# Generated at 2022-06-22 14:14:24.221234
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(256, 2) == math.log(256, 2)
    assert logarithm(256, 10) == math.log10(256)
    assert logarithm(256, math.e) == math.log(256, math.e)
    assert logarithm(1) == math.log(1)
    assert logarithm(1000, 10) == math.log10(1000)
    assert logarithm(1, 1) == math.log(1, 1)


# Generated at 2022-06-22 14:14:37.728608
# Unit test for function human_to_bytes
def test_human_to_bytes():
    ifhuman_to_bytes = formatters.human_to_bytes
    ifhuman_readable = formatters.bytes_to_human

    # Supported unit types
    assert ifhuman_to_bytes('1') == 1
    assert ifhuman_to_bytes('1T') == 1099511627776
    assert ifhuman_to_bytes('1G') == 1073741824
    assert ifhuman_to_bytes('  1G   ') == 1073741824

    # Unit type error handling
    try:
        ifhuman_to_bytes('1Z')
        assert False, 'Expected a ValueError exception'
    except ValueError:
        pass

    try:
        ifhuman_to_bytes('1 GB')
        assert False, 'Expected a ValueError exception'
    except ValueError:
        pass

    # Test backwards compatibility of

# Generated at 2022-06-22 14:14:43.399632
# Unit test for function max
def test_max():
    error = AnsibleFilterError
    expected = 2
    actual = max([1, 2])
    assert actual == expected
    expected = 'b'
    actual = max('ab')
    assert actual == expected
    expected = error
    actual = max(1)
    assert isinstance(actual, expected)


# Generated at 2022-06-22 14:14:48.946642
# Unit test for function min
def test_min():
    test_cases = [
        ((1, 2), 1),
        ((1, 2, 3), 1),
        (([1, 2], [2, 3]), [1, 2]),
        (([1, 2, 3], [2, 3]), [1, 2])
    ]
    for (data, expected) in test_cases:
        assert min(data) == expected



# Generated at 2022-06-22 14:14:59.607915
# Unit test for function min
def test_min():
    # No args
    # Returns None instead of raising an error
    if min() != None:
        raise AssertionError('min() did not return None')

    # one arg
    # returns the arg if it is a list
    if min([1,2,3,4]) != [1,2,3,4]:
        raise AssertionError('min() did not return the list when only one argument was provided')

    # two args of the same type
    if min(1,2) != 1 or min([1,2],[3,4]) != [1,2] or min((1,2),(3,4)) != (1,2) or min(True, False) != False or min('a', 'b') != 'a':
        raise AssertionError('min() did not return the proper result when two arguments of the same type')



# Generated at 2022-06-22 14:15:11.126842
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test data
    given = [
        { 'b': [4, 5, 6], 'a': 1, 'c': { 'd': 7 }},
        { 'b': [7, 8, 9], 'a': 2, 'c': { 'e': 10 }},
    ]
    expected_key_d = {
        1: { 'b': [4, 5, 6], 'a': 1, 'c': { 'd': 7 }},
    }
    expected_key_e = {
        2: { 'b': [7, 8, 9], 'a': 2, 'c': { 'e': 10 }},
    }

# Generated at 2022-06-22 14:15:21.110471
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([3, 2, 1]) == 1
    assert min([1, 3, 2]) == 1
    assert min(['1', '2', '3']) == '1'
    assert min(['3', '2', '1']) == '1'
    assert min(['1', '3', '2']) == '1'
    assert min(['one', 'two', 'three']) == 'one'
    assert min(['three', 'two', 'one']) == 'one'
    assert min(['one', 'three', 'two']) == 'one'


# Generated at 2022-06-22 14:15:23.545292
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4
    assert max([1.2, 3.4, 3.1]) == 3.4



# Generated at 2022-06-22 14:15:30.666628
# Unit test for function max
def test_max():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters['max']([1, 2, 3]) == 3
    assert filters['max']([1, 3, 2]) == 3
    assert filters['max']([2, 3, 1]) == 3
    assert filters['max']([2, 1, 3]) == 3
    assert filters['max']([3, 2, 1]) == 3
    assert filters['max']([3, 1, 2]) == 3

    assert filters['max']([1, 2, 3], key=lambda x: -x) == 1
    assert filters['max']([1, 3, 2], key=lambda x: -x) == 1
    assert filters['max']([2, 3, 1], key=lambda x: -x) == 1

# Generated at 2022-06-22 14:15:37.556972
# Unit test for function min
def test_min():
    # Min with dictionaries, integer values
    dct1 = {
        1: 10,
        2: 20
    }
    assert min(dct1) == 1

    # Min with dictionaries, string values
    dct2 = {
        'a': 'dog',
        'b': 'cat'
    }
    assert min(dct2) == 'a'

    # Min with a list of strings
    lst1 = ['a', 'b', 'c']
    assert min(lst1) == 'a'

    # Min with a list of integers
    lst2 = [20, 10, 1]
    assert min(lst2) == 1

    # Run with keyword args
    assert min(iterable=lst2) == 1

    # Min with a list of tuples

# Generated at 2022-06-22 14:15:49.453711
# Unit test for function human_to_bytes
def test_human_to_bytes():
    result = human_to_bytes('1')
    assert result == 1.0, 'failed to get 1 byte from human_to_bytes'

    result = human_to_bytes('1.0')
    assert result == 1.0, 'failed to get 1 byte from human_to_bytes'

    result = human_to_bytes('1K')
    assert result == 1024.0, 'failed to get 1024 bytes from human_to_bytes'

    result = human_to_bytes('1M')
    assert result == 1048576.0, 'failed to get 1048576 bytes from human_to_bytes'

    result = human_to_bytes('1G')
    assert result == 1073741824.0, 'failed to get 1073741824 bytes from human_to_bytes'

    result = human_to_bytes('1T')
   

# Generated at 2022-06-22 14:16:05.496663
# Unit test for function max
def test_max():
    # numbers, no keyword arguments
    assert max([3, 1, 4, 1, 5, 9]) == 9
    assert max([-3, 1, -4, -1, -5, -9]) == 1
    # strings, no keyword arguments
    assert max(['3', '1', '4', '1', '5', '9']) == '9'
    assert max(['-3', '1', '-4', '-1', '-5', '-9']) == '1'
    # mixed, no keyword arguments
    assert max(['3', '1', '4', 1, 5, 9]) == '9'
    assert max(['3', 1, '4', '1', 5, 9]) == '9'
    assert max(['3', '1', '4', 1, 5, 9]) == '9'

# Generated at 2022-06-22 14:16:09.758858
# Unit test for function min
def test_min():
    assert min([1,6,3]) == 1
    assert min([10,6.0,8]) == 6.0
    assert min([1,1,1,1,1],**{'start': 6}) == 1
    return


# Generated at 2022-06-22 14:16:22.329961
# Unit test for function max
def test_max():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['max']([1, 2, 3]) == 3
    assert filters['max']([1, 3, 2]) == 3
    assert filters['max']([3, 2, 1]) == 3
    assert filters['max'](['apple', 'cherry', 'banana']) == 'cherry'
    assert filters['max']([0, 'cherry', 'banana']) == 'cherry'
    assert filters['max']([{'name': 'Jill Doe'}, {'name': 'John Doe'}]) == {'name': 'Jill Doe'}
    assert filters['max']([], default='no max') == 'no max'


# Generated at 2022-06-22 14:16:35.305636
# Unit test for function min
def test_min():
    # make sure that empty lists are handled correctly
    assert min([]) == []
    assert min([]) == []

    # mimicing the behavior of the following test on Python 3
    # assert min([None, 1, None]) == None
    assert min([None, 1, None]) == 1

    # the following test does not behave the same on Python 2 or 3
    # assert min([1, "string"]) == 1
    assert min([1, "string"]) == "string"
    assert min([1, None]) == 1

    # make sure types are preserved

# Generated at 2022-06-22 14:16:36.820490
# Unit test for function max
def test_max():
    result = max(range(10))
    assert result == 9



# Generated at 2022-06-22 14:16:47.586200
# Unit test for function min
def test_min():
    # Test scalars
    assert min(1, 3) == 1
    assert min(1, 3, -1) == -1

    # Test iterables
    assert min([1, 3, -1]) == -1
    assert min({1: -1, 2: -2}) == -2

    # Test kwargs
    assert min([1, 3, -1], default=-2) == -1
    assert min([], default=-2) == -2
    assert min([1, 3, -1], default=-2, key=lambda x: 2*x) == -2
    assert min([1, 3, -1], key=lambda x: 2*x) == -1
    # Test scalar as first argument
    assert min(1) == 1
    assert min(default=-2, key=lambda x: 2*x)(1)

# Generated at 2022-06-22 14:16:57.001944
# Unit test for function min
def test_min():
    f = FilterModule()
    flt = f.filters()

    # basic test: min of integers
    raw = [5, 6, 10, 4, 3]
    expected = 3
    res = flt['min'](raw)
    assert res == expected

    # case where the list of numbers needs to be casted to floats
    raw = [5, 6, 10, 4.0]
    expected = 4.0
    res = flt['min'](raw)
    assert res == expected

    # case where the list of numbers are strings
    # min should return a string
    raw = ['5', '6', '10', '4.0']
    expected = '4.0'
    res = flt['min'](raw)
    assert res == expected

    # case where the list of numbers is a mix of numbers and strings

# Generated at 2022-06-22 14:17:10.029513
# Unit test for function max
def test_max():
    filt = FilterModule()
    max_filter = filt.filters()['max']
    assert max_filter([1, 4, 2]) == 4
    assert max_filter([1, 4, 2], 2) == 4
    assert max_filter([4, 1, 2], 4) == 4
    assert max_filter([4, 1, 2.5], 2) == 4
    assert max_filter([4, 1, 2.5], 2.5) == 4
    assert max_filter([4, 1, 2], 2.5) == 4
    assert max_filter([1.5, 1, 2.5], 1.5) == 1.5
    assert max_filter([1.9, 1, 2.5], 1.9) == 1.9
    assert max_filter([4, 1, 2], 1.9) == 4

# Generated at 2022-06-22 14:17:21.749474
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 1, 2, 3, 4, 1, 2, 3]) == [1, 2, 3, 4]
    assert unique([1, 2, 1, 1, 2, 3, 4, 1, 2, 3], case_sensitive=False) == [1, 2, 3, 4]
    assert unique(['lower', 'lower', 'UPPER', 'lower', 'UPPER', 'UPPER'], case_sensitive=False) == ['lower', 'UPPER']
    assert unique(['lower', 'lower', 'UPPER', 'lower', 'UPPER', 'UPPER'], case_sensitive=True) == ['lower', 'lower', 'UPPER', 'UPPER']

    # Attributes

# Generated at 2022-06-22 14:17:33.415563
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1GB') == 1000000000
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1TB') == 1000000000000
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1PB') == 1000000000000000
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1EB') == 1000000000000000000

# Generated at 2022-06-22 14:17:50.518741
# Unit test for function min
def test_min():
    f = FilterModule()
    filters = f.filters()

    assert filters['min']([1, 2, 3, 4, 5]) == 1
    assert filters['min']([1, 2, 3, 4, -5]) == -5
    assert filters['min']([1, 2, 3, 4, '5']) == 1
    assert filters['min']([1, 2, 3, 4, '-5']) == 1
    assert filters['min']([1, 2, 3, 4, '-5', '4']) == 1
    assert filters['min']([1, 2, 3, 4, 5], key=lambda x: -x) == 5
    assert filters['min'](['a', 'b', 'c', 'd', 'e'], key=lambda x: x.upper()) == 'a'

# Generated at 2022-06-22 14:17:59.588775
# Unit test for function rekey_on_member

# Generated at 2022-06-22 14:18:03.689409
# Unit test for function min
def test_min():
    test_cases = (
        ([1, 2, 3], 1),
        ((3, 2, 1), 1),
        ((3, 2, 1, 4, 5, 6), 1)
    )

    for c in test_cases:
        res = min(None, c[0])
        assert res == c[1]

        res = min(None, *c[0])
        assert res == c[1]

# Generated at 2022-06-22 14:18:05.951719
# Unit test for function min
def test_min():
    assert min([4, 2, 1, 3]) == 1



# Generated at 2022-06-22 14:18:07.990800
# Unit test for function min
def test_min():
    assert min(1, 2) == 1
    assert min([0, 1, 2]) == 0
    assert min(range(0, 10)) == 0
    assert min(x=2, y=1) == 1

# Generated at 2022-06-22 14:18:18.789661
# Unit test for function human_readable

# Generated at 2022-06-22 14:18:26.839094
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1
    assert min([1, 2, 'a', 'b', 'c']) == 1
    assert min([1, 2, 'a', 'b', ['a', 'b', 'c']]) == 1
    assert min([[1], [2], [3], [4]]) == [1]
    assert min([x for x in range(100, 0, -1)]) == 1


# Generated at 2022-06-22 14:18:38.458741
# Unit test for function rekey_on_member
def test_rekey_on_member():

    from ansible.template import Templar
    from ansible.module_utils.six.moves import StringIO

    # Create a list of dicts with given keys and values
    def _create_list(keys, values):
        l = []
        for v in values:
            l.append(dict(zip(keys, v)))
        return l

    # Create a list of dicts with random keys and values
    import random
    import string

    def _create_random_list(n_keys, n_list_entries, n_entries_per_list, max_n_letters_per_key, max_n_letters_per_value):
        keys = []

# Generated at 2022-06-22 14:18:45.740946
# Unit test for function min
def test_min():

    # Test with strings
    assert [1, 2, 3] == min([[1, 2, 3], [5, 4, 3], [2, 3, 4]], key=lambda x: x[0])
    assert [2, 3, 4] == min([[1, 2, 3], [5, 4, 3], [2, 3, 4]], key=lambda x: x[1])
    assert [1, 2, 3] == min([[1, 2, 3], [5, 4, 3], [2, 3, 4]], key=lambda x: x[2])

    if HAS_MIN_MAX:
        assert [1, 2, 3] == min([[1, 2, 3], [5, 4, 3], [2, 3, 4]], reverse=True, key=lambda x: x[0])

# Generated at 2022-06-22 14:18:48.131182
# Unit test for function max
def test_max():
    j = dict(a=1, b=2, c=3)
    assert max(j, attribute='value') == 3



# Generated at 2022-06-22 14:19:06.492494
# Unit test for function max
def test_max():
    assert max([1,2,3,4,5,6,7,8,9]) == 9
    assert max([1,2,3,4,5,6,7,8,9], default=0) == 9
    assert max([1,2,3,4,5,6,7,8,9], default=20) == 9
    assert max([1,2,3,4,5,6,7,8,9], default=1) == 9

    assert max([1,2,-3,4,5,6,7,8,9,]) == 9
    assert max([1,2,-3,-4,5,6,7,8,9,]) == 9

    assert max([1,2,3,4,5,6,7,8,9], key=lambda x: -x) == 1

# Generated at 2022-06-22 14:19:17.957124
# Unit test for function min
def test_min():
    # Use case for min() with number inputs
    assert min([4, 2, 1, 5, 3]) == 1
    assert min([100, 2, 1, 5, 300]) == 1
    # Use case for min() with mixed inputs
    assert min([1, 'string']) == 1
    assert min(['string', 1]) == 1
    assert min([1, 'string', 2]) == 1
    assert min(['string', 1, 2]) == 1
    assert min([1, 'one']) == 1
    assert min(['one', 1]) == 1
    assert min(['one', 'two']) == 'one'
    assert min(['two', 'one']) == 'one'
    assert min(['one', 'two', 1]) == 1
    assert min(['two', 'one', 1]) == 1

# Unit

# Generated at 2022-06-22 14:19:24.946332
# Unit test for function min
def test_min():
    assert min([0, 3, 1]) == 0
    assert min(['a', 'b', 'c']) == 'a'
    assert min(['a', 'c', 'b']) == 'a'
    try:
        min([1, 'b', 'c'])
    except AnsibleFilterError:
        pass
    else:
        assert False, 'min should not work on integers and strings'


# Generated at 2022-06-22 14:19:30.632980
# Unit test for function max
def test_max():
    assert max([1,2,3]) == 3
    assert max(1,2,3) == 3
    assert max((1, 2, 3)) == 3
    assert max(1, 3, 2) == 3
    assert max([-1, -2, -3]) == -1
    assert max(range(1, 11)) == 10


# Generated at 2022-06-22 14:19:33.980306
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute="attr") == 1
    assert min([1, 2, 3], attribute="attr", case_sensitive=True) == 1
    assert min([1, 2, 3], attribute="attr", case_sensitive=False) == 1

    assert min([]) is None


# Generated at 2022-06-22 14:19:39.065052
# Unit test for function min
def test_min():
    assert min([0, 1, 2, 3, 4, 5, 6]) == 0
    assert min((0, 1, 2, 3, 4, 5, 6)) == 0
    assert min(0, 1, 2, 3, 4, 5, 6) == 0



# Generated at 2022-06-22 14:19:42.392835
# Unit test for function max
def test_max():
    assert max((1, 2, 3)) == 3, 'Should be 3'
    assert max([1, 2, 3]) == 3, 'Should be 3'
    assert max((1, 3, 2)) == 3, 'Should be 3'


# Generated at 2022-06-22 14:19:52.929589
# Unit test for function min
def test_min():
    from ansible.utils.display import Display
    display = Display()

    try:
        assert min([1, 2, 3], 1, 2, 3) == 1
    except Exception:
        raise AssertionError("Filter min() failed")

    # Test that we raise an error if keyword arguments are provided (Jinja2 2.10 not installed)
    try:
        min([1, 2, 3], foo='bar')
    except AnsibleFilterError as e:
        assert 'Ansible' in e.message
    else:
        raise AssertionError("Filter min() failed")



# Generated at 2022-06-22 14:19:58.604778
# Unit test for function min
def test_min():
    from ansible.compat.tests import unittest

    class MinTest(unittest.TestCase):
        def test_min_int(self):
            self.assertEqual(min([1, 2, 3, 4]), 1)

        def test_min_float(self):
            self.assertEqual(min([1.1, 2.2, 3.3, 4.4]), 1.1)

        def test_min_mixed(self):
            self.assertEqual(min([1.1, 2, 3.3, 4]), 1.1)

        def test_min_negative(self):
            self.assertEqual(min([-1, -2, -3, -4]), -4)

    unittest.main()


# Generated at 2022-06-22 14:20:11.877774
# Unit test for function max
def test_max():
    f = FilterModule()
    math_filters = f.filters()

    # Test for function max
    result = math_filters['max']([1, 2, 3])
    assert result == 3
    result = math_filters['max']([1, 2, 3], 4)
    assert result == 4
    result = math_filters['max']([1, 2, 3], 4, 5)
    assert result == 5
    result = math_filters['max']([1, 2, 3], 5, 4)
    assert result == 5

    try:
        math_filters['max']([1, 2, 3], [4, 5, 6])
    except AnsibleFilterError as e:
        assert to_native(e) == 'max() can take exactly one or two arguments'


# Unit test

# Generated at 2022-06-22 14:20:35.968758
# Unit test for function max
def test_max():
    assert max([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == 9
    assert max([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], start=4) == 9
    assert max([[0, 1, 2], [0, 1, 2], [0, 1, 2]], attribute=lambda x: max(x)) == [0, 1, 2]
    assert max([[0, 1, 2], [0, 1, 2], [0, 1, 2]], attribute=lambda x: max(x), start=3) == [0, 1, 2]
    assert max(['a', 'b', 'c', 'd']) == 'd'
    assert max(['a', 'b', 'c', 'd'], start='z') == 'z'



# Generated at 2022-06-22 14:20:45.132335
# Unit test for function max
def test_max():
    """
    max: Return the largest item in an iterable or the largest of two or more arguments..
    """
    environment = {}

    # Test #1
    data = [1, 5, 9]
    max_val = max(environment, data)
    assert max_val == 9

    # Test #2
    data = [9, 5, 1]
    max_val = max(environment, data)
    assert max_val == 9

    # Test #3
    data = [1, 9, 5]
    max_val = max(environment, data)
    assert max_val == 9

    # Test #4
    max_val = max(environment, 9, 5, 1)
    assert max_val == 9

    # Test #5
    data = [1, 5, 9]

# Generated at 2022-06-22 14:20:48.980031
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == max((1, 2, 3)) == 3
    assert max(1, 2, 3) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1


# Generated at 2022-06-22 14:20:50.495854
# Unit test for function max
def test_max():
    assert(max([1, 1, 2, 3, 4, 5]) == 5)


# Generated at 2022-06-22 14:20:53.832924
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min('1', '2', '3') == '1'



# Generated at 2022-06-22 14:20:55.313269
# Unit test for function min
def test_min():
    assert min([1,2,3,4,5]) == 1


# Generated at 2022-06-22 14:20:59.802410
# Unit test for function max
def test_max():
    assert max([1, 0, 2]) == 2
    assert max(range(6)) == 5

    # string
    assert max("hello") == 'o'

    # multiple bits
    assert max(range(6), range(0, 12, 2)) == (5, 11)

    # key
    assert max(range(6), key=lambda x: -x) == 0

    # key + multiple bits
    assert max(range(6), range(0, 12, 2), key=lambda x: -x) == (0, 10)



# Generated at 2022-06-22 14:21:12.578520
# Unit test for function unique
def test_unique():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vault_secrets(['default'])
    variable_manager.set_available_variables()
    variable_manager._extra_vars = dict(
        ansible_show_custom_stats=True,
        ansible_custom_stats=dict(host=dict(test1=5, test2=10))
    )
    variable_manager.set_inventory(loader.load_inventory("localhost,", variable_manager=variable_manager))

    from jinja2.environment import Environment
    env = Environment(loader=loader)

# Generated at 2022-06-22 14:21:24.897556
# Unit test for function min
def test_min():
    assert min([0, 1, 2, 3]) == 0
    assert min([0, -1, 2, 3]) == -1
    assert min(['a', 'b', 'c', 'd']) == 'a'
    assert min(['aa', 'bb', 'cc', 'dd']) == 'aa'
    assert min(['aaa', 'bbb', 'ccc', 'ddd']) == 'aaa'
    assert min(['bb', 'aa', 'dd', 'cc']) == 'aa'
    assert min(['bbb', 'aaa', 'ddd', 'ccc']) == 'aaa'
    assert min(['bbb', 'aaa', 'ddd', 'ccc'], key=len) == 'aaa'

# Generated at 2022-06-22 14:21:32.723459
# Unit test for function min
def test_min():
    from jinja2 import Environment
    from jinja2.runtime import Undefined
    env = Environment()
    min = env.filters['min']
    assert min([1,2,3]) == 1
    
    #test against Undefined
    assert min([1,Undefined,3]) == 1
    assert min([Undefined,2,3]) == 2
    assert min([1,2,Undefined]) == 1
    assert min([Undefined,Undefined,Undefined]) == Undefined