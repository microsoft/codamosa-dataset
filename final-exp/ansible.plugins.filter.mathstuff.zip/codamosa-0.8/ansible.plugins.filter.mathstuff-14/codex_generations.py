

# Generated at 2022-06-22 14:12:06.511101
# Unit test for function human_readable
def test_human_readable():
    def test_template(val, out):
        assert '{{ "{}" | human_readable }}'.format(val) == '"{}"'.format(out)

    test_template('10m', '10M')
    test_template('10M', '10M')
    test_template('10MiB', '10M')
    test_template('10MB', '10M')
    test_template('10mb', '10M')
    test_template('10MB', '10M')
    test_template('1048576', '1M')
    test_template('1073741824', '1G')
    test_template('1099511627776', '1T')
    test_template('1125899906842624', '1P')
    test_template('1152921504606846976', '1E')


# Generated at 2022-06-22 14:12:11.308196
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4
    assert max("abcd") == 'd'
    assert max((1, 2, 3, 4)) == 4
    assert max({"b": 2, "a": 1, "c": 3, "d": 4}) == 4
    assert max({"a", "b", "c", "d"}) == 'd'


# Generated at 2022-06-22 14:12:23.449273
# Unit test for function unique
def test_unique():
    ''' unique
    Test unique function
    '''
    assert unique([1, 2, 3, 1, 4, 2]) == [1, 2, 3, 4]
    assert unique([1, '2', 3, 1, 4, '2']) == [1, '2', 3, 4]
    assert unique([1, 2, 3, 1, 4, 2], True) == [1, 2, 3, 4]
    assert unique([1, '2', 3, 1, 4, '2'], True) == [1, '2', 3, 4]
    assert unique([1, '2', 3, 1, 4, '2'], case_sensitive=True) == [1, '2', 3, 4]

# Generated at 2022-06-22 14:12:27.766805
# Unit test for function min
def test_min():
    assert min([4, 8, 2, 1, 9, 7]) == 1
    assert min(8, 5) == 5
    assert min([4, 8, 2, 1, 9, 7], 1) == 1
    assert min(8, 5, 1) == 1


# Generated at 2022-06-22 14:12:37.881994
# Unit test for function min
def test_min():
    for arg1 in [10, -10, 0, '10', '-10', '0', 'a', 'b', '', '   ', [], [1, 2, 3], {}, {'a': 0}]:
        for arg2 in [10, -10, 0, '10', '-10', '0', 'a', 'b', '', '   ', [], [1, 2, 3], {}, {'a': 0}]:
            # only test comparison of ints, floats, and strings
            if (isinstance(arg1, int) and isinstance(arg2, int)):
                assert min(arg1, arg2) == min_original(arg1, arg2)
                assert min(arg2, arg1) == min_original(arg2, arg1)
                assert min(arg2, arg2) == min_

# Generated at 2022-06-22 14:12:43.729520
# Unit test for function max
def test_max():
    assert FilterModule().filters()['max'](1, 2) == 2
    assert FilterModule().filters()['max']([1, 2]) == 2
    assert FilterModule().filters()['max']([1, 2], 3, 4) == 4
    assert FilterModule().filters()['max']([1, 2, 3], key=lambda x: x * -1) == 1
    assert FilterModule().filters()['max']([1, 2, 3], key=lambda x: x * -1, default=-3) == -3

# Generated at 2022-06-22 14:12:46.343794
# Unit test for function max
def test_max():
    data = (1, 2, 3, 4)
    assert max(data) == 4, "max failed"


# Generated at 2022-06-22 14:12:49.109251
# Unit test for function max
def test_max():
    test = FilterModule()
    filters = test.filters()
    real = filters['max']([1,2,3])
    assert real == 3



# Generated at 2022-06-22 14:13:00.836315
# Unit test for function max
def test_max():
    """Test the max filter"""
    assert max(None, [1, 2, 3, 4, 5], True) == 5
    assert max(None, [1, 2, 3, 4, 5], False) == 1

    # check that we get error on keyword arguments
    try:
        max(None, [1, 2, 3, 4, 5], invalid_kwarg=1)
        raise AssertionError()
    except AnsibleFilterError as e:
        assert 'Ansible' in to_native(e)

    # check that we get error on bad values
    try:
        max(None, 1, True)
        raise AssertionError()
    except AnsibleFilterTypeError as e:
        assert 'Ansible' in to_native(e)



# Generated at 2022-06-22 14:13:08.158638
# Unit test for function max
def test_max():
    assert max(None, [1, 2, 3]) == 3
    assert max(None, [1, 2, -3]) == 2
    assert max(None, [-1, -2, -3]) == -1
    assert max(None, [1]) == 1
    assert max(None, [-1]) == -1
    assert max(None, [-1, 0]) == 0
    assert max(None, [1, "hello", 2, "world", "hi", 3]) == 3

# Generated at 2022-06-22 14:13:46.937126
# Unit test for function max
def test_max():
    max_filter = FilterModule()
    assert max_filter.filters()['max']([1,2,3]) == 3
    assert max_filter.filters()['max']([3,2,1]) == 3
    assert max_filter.filters()['max']([3,3,3]) == 3
    assert max_filter.filters()['max'](['a', 'b', 'c']) == 'c'
    assert max_filter.filters()['max']([['a', 'b', 'c'], ['a', 'b', 'c'], ['a', 'b', 'c']]) == ['a', 'b', 'c']
    assert max_filter.filters()['max']([1, 'b', 3]) == 'b'

# Generated at 2022-06-22 14:13:51.122838
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1,2,3,4]
    b = [3,4,5,6]
    assert symmetric_difference(None, a, b) == [1,2,5,6]

# Generated at 2022-06-22 14:14:02.379457
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_bytes

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            # Initialize
            self.rekey_on_member = rekey_on_member

        def test_rekey_on_member_error_on_duplicate_key(self):
            with self.assertRaises(AnsibleFilterError) as context:
                self.rekey_on_member([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 1, 'b': 5}], 'a')

            self.assertTrue(to_bytes('Key 1 is not unique, cannot correctly turn into dict') in to_bytes(context.exception))

       

# Generated at 2022-06-22 14:14:07.520885
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([[1, 2], [3, 4], [5, 6]], key=lambda x: x[1]) == [1, 2]

# Generated at 2022-06-22 14:14:15.064886
# Unit test for function min
def test_min():
    # Create a fake env to pass to the filter
    class FakeEnv(object):
        pass

    env = FakeEnv()
    # Create an array of integers
    test_array = [1,2,3,4,5]

    # Test that min returns the correct value
    assert min(env, test_array) == 1
    # Test that min returns the correct value when passing a keyword argument
    assert min(env, test_array, attribute=str) == 1
    # Test that min raises an error when passing an unsupported keyword argument
    try:
        min(env, test_array, attribute=str, unsupported=None)
        assert False
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 14:14:16.457394
# Unit test for function min
def test_min():
    data = [1, 2, 3, 4, 5]

    assert min(data) == 1


# Generated at 2022-06-22 14:14:18.395694
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3]
    b = [5, 4, 3]
    assert symmetric_difference(a, b) == [1, 2, 4]

# Generated at 2022-06-22 14:14:19.816692
# Unit test for function max
def test_max():
    from .test_max import TestMax as TestMaxClass
    TestMaxClass.test_max()

# Generated at 2022-06-22 14:14:26.747091
# Unit test for function max
def test_max():
    from jinja2 import DictLoader, Environment

    template_body = '''
{% for num in list | max %}
{{ num }}
{% endfor %}
'''
    test_list = [17, 26, 29, 41, 53]
    template = Environment(loader=DictLoader({'template': template_body})).get_template('template')
    assert template.render(list=test_list) == '''
53
'''


# Generated at 2022-06-22 14:14:31.820722
# Unit test for function max
def test_max():
    data = [3,1,4,1,5,9,2,6,5,3,5,9]
    expected = 9

    # Test built-in max
    assert max(data) == expected

    # Test Jinja2 filter
    assert max(None, data) == expected


# Generated at 2022-06-22 14:14:52.246205
# Unit test for function human_to_bytes
def test_human_to_bytes():

    f = FilterModule()
    filters = f.filters()

    assert filters['human_to_bytes']('1 byte') == 1
    assert filters['human_to_bytes']('2 bytes') == 2
    assert filters['human_to_bytes']('1k') == 1024
    assert filters['human_to_bytes']('2k') == 2048
    assert filters['human_to_bytes']('1K') == 1024
    assert filters['human_to_bytes']('2K') == 2048
    assert filters['human_to_bytes']('1m') == 1024 * 1024
    assert filters['human_to_bytes']('2m') == 2048 * 1024
    assert filters['human_to_bytes']('1M') == 1024 * 1024
    assert filters['human_to_bytes']('2M') == 2048 * 1024

# Generated at 2022-06-22 14:14:54.921236
# Unit test for function min
def test_min():

    values = ['a']
    assert min(values, default='b') == 'a'
    assert min([] , default='b') == 'b'

# Generated at 2022-06-22 14:15:00.132044
# Unit test for function min
def test_min():
    assert min([1, 4, 2]) == 1
    assert min(1, 4, 2) == 1
    assert min('a', 'ab', 'abc') == 'a'
    assert min('abc', 'a', 'ab') == 'a'
    assert min(1, 4, 2, key=lambda x: -x) == 4
    assert min('a', 'ab', 'abc', key=lambda x: -len(x)) == 'abc'



# Generated at 2022-06-22 14:15:02.626903
# Unit test for function logarithm
def test_logarithm():
    # Test without base
    # Test error when base is not a number
    pass



# Generated at 2022-06-22 14:15:13.077817
# Unit test for function human_readable
def test_human_readable():
    assert 14 == human_readable("14")
    assert 14 == human_readable("14.0")
    assert 14 == human_readable("14.00")
    assert 14 == human_readable("14.000")
    assert 14 == human_readable("14.00 B")
    assert 14 == human_readable("14 B")
    assert 14 == human_readable("14.00b")
    assert 14 == human_readable("14b")
    assert 14 == human_readable("14.00 B")
    assert 14 == human_readable("14 B")
    assert 14 == human_readable("14.00b")
    assert 14 == human_readable("14b")
    assert 14 == human_readable("14.00byte")
    assert 14 == human_readable("14byte")
    assert 14 == human_readable("14.00 bytes")
    assert 14 == human

# Generated at 2022-06-22 14:15:15.335283
# Unit test for function min
def test_min():
    filter_min = min([3, 1, 4, 5])
    assert filter_min == 1

# Generated at 2022-06-22 14:15:23.459302
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min(['a', 'b', 'c']) == 'a'
    assert min((1, 2, 3)) == 1
    assert min((('a', 1), ('b', 2), ('c', 3))) == ('a', 1)
    assert min((('a', 3), ('b', 2), ('c', 3)), key=lambda x: x[1]) == ('b', 2)
    assert min((('a', 3), ('b', 2), ('c', 1)), attribute=1) == ('c', 1)


# Generated at 2022-06-22 14:15:30.639525
# Unit test for function max
def test_max():
    # Test max
    m = [4, 3, 2, 1]
    assert max(m) == 4
    assert max(m, attribute='x') == 4
    assert max(m, attribute=lambda x: x.x) == 4
    assert max(m, attribute='x', default=0) == 4
    assert max(None, attribute='attr', default=5) == 5
    assert max(m, attribute='attr', default=5) == 5
    assert max(m, attribute='attr') == 4
    assert max(m, attribute='x', default=0) == 4
    assert max([], attribute='x', default=0) == 0
    assert max([None, None], attribute='x', default=0) == 0
    assert max(m, key=lambda x: x.x) == 4

# Generated at 2022-06-22 14:15:40.893856
# Unit test for function logarithm
def test_logarithm():
    type_error = None
    try:
        logarithm('a')
    except AnsibleFilterTypeError as e:
        type_error = e

    assert type_error is not None

    # Base is not specified, with a number should return the log(number)
    assert logarithm(1) == 0

    # Base is not specified, with a float should return the log(float)
    assert logarithm(0.5) == -0.6931471805599453

    # Base is specified, should return the log(float, base)
    assert logarithm(2, 3) == 0.6309297535714574

    # Base is 10, should return log10 of the number
    assert logarithm(100, 10) == 2

    # Base is 10, should return log10 of the float

# Generated at 2022-06-22 14:15:52.125756
# Unit test for function max
def test_max():
    data = {'a': -1, 'b': 2, 'c': -3, 'd': 4, 'e': -5, 'f': 6}
    assert max(data, key='value') == 6
    assert max(data, key='value', default='no key') == 6
    assert max(data, key='value', default='no key', attribute='key') == 'f'
    assert max(data, default='no key') == 'no key'
    # Both keys and values are numbers
    assert max(data, 0) == 6
    # Key is a number and value is non-number
    assert max(data, -1) == 'no key'
    # Key is non-number and value is a number
    assert max(data, 'a') == 4
    # Both keys and values are non-number

# Generated at 2022-06-22 14:16:09.886412
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test basic functionality
    data = [
        {
            'foo': 'bar',
            'baz': 1,
            'zap': '',
        },
        {
            'foo': 'baz',
            'baz': 2,
            'zap': '',
        },
    ]
    key = 'foo'
    actual_output = rekey_on_member(data, key)
    expected_output = {
        'bar': {'foo': 'bar', 'baz': 1, 'zap': ''},
        'baz': {'foo': 'baz', 'baz': 2, 'zap': ''},
    }
    assert actual_output == expected_output

    # Test skipping other keys with duplicate values

# Generated at 2022-06-22 14:16:22.975929
# Unit test for function unique
def test_unique():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils import template

    # The tests below only test the argument handling.

    collection = ["a", "a", "b", "c"]
    expected = ["a", "b", "c"]
    assert unique(collection) == expected

    collection = {1, 1, 2, 3}
    expected = {1, 2, 3}
    assert unique(collection) == expected

    collection = ["abcd", "abcd", "hello", 25, 25]
    expected = ["abcd", "hello", 25]
    assert unique(collection) == expected

    collection = [1, 2, 3, 4, 5]
    expected = [1, 2, 3, 4, 5]
    assert unique(collection) == expected


# Generated at 2022-06-22 14:16:35.776240
# Unit test for function min
def test_min():
    f = FilterModule()
    # General math
    assert f.filters()['min']('foo') == 'foo'
    assert f.filters()['min']('foo', 'bar') == 'bar'
    assert f.filters()['min']('bar', 'foo') == 'bar'
    assert f.filters()['min'](['foo', 'bar']) == 'bar'
    assert f.filters()['min'](['bar', 'foo']) == 'bar'
    # For Python 2 and Python 3 compat.
    assert f.filters()['min']([b'bar', b'foo']) == b'bar'
    assert f.filters()['min'](('foo', 'baz', 'bar')) == 'baz'

# Generated at 2022-06-22 14:16:37.880494
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]

# Generated at 2022-06-22 14:16:48.132994
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """
    Assert that the function rekey_on_member() works properly.
    """
    # GIVEN: A list of dictionaries.
    test_data = [{"foo": "bar"}, {"foo": "bar", "spam": "eggs"}]

    # WHEN: We call rekey_on_member() to create a dictionary re-keyed on the "foo" member of each element.
    rekeyed_test_data = rekey_on_member(test_data, "foo")

    # THEN: We get a dictionary keyed on the "foo" member of each element, with elements of the input list as values.
    assert rekeyed_test_data == {"bar": {"foo": "bar", "spam": "eggs"}}

    # WHEN: We call rekey_on_member() to create a dictionary re-key

# Generated at 2022-06-22 14:16:49.834704
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3



# Generated at 2022-06-22 14:16:54.954613
# Unit test for function min
def test_min():
    # test min basic
    assert min([1, 2, 3]) == 1
    # test min no value
    assert min([]) == None
    # test min with number
    assert min([1, 2, 3], 2) == 2
    # test min with list
    assert min([[1, 2, 3], [1, 2]], [1, 2]) == [1, 2]


# Generated at 2022-06-22 14:17:07.781256
# Unit test for function min
def test_min():
    if not HAS_MIN_MAX:
        return
    from jinja2.utils import Markup
    from jinja2 import Environment
    env = Environment()
    env.filters['min'] = min
    env.filters['max'] = max

    # Test with numbers
    assert env.from_string('{{ [1, 2, 3, 4, 5] | min }}').render() == '1'
    assert env.from_string('{{ [1, 2, 3, 4, 5] | max }}').render() == '5'
    assert env.from_string('{{ [1, -5, 3, 8, 5] | min }}').render() == '-5'
    assert env.from_string('{{ [1, -5, 3, 8, 5] | max }}').render() == '8'

    # Test with

# Generated at 2022-06-22 14:17:20.311131
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 2, 3, 4, 1, 3]) == [1, 2, 3, 4]
    assert unique([{'a': 1}, {'a': 1}, {'a': 2}], attribute='a') == [{'a': 1}, {'a': 2}]
    assert unique([{'a': 1}, {'a': 1}, {'a': 2}], case_sensitive=False, attribute='A') == [{'a': 1}, {'a': 2}]
    assert unique([{'B': 1, 'A': 1}, {'b': 1, 'A': 2}], case_sensitive=False, attribute='A') == [{'B': 1, 'A': 1}, {'b': 1, 'A': 2}]

# Generated at 2022-06-22 14:17:25.769716
# Unit test for function human_to_bytes
def test_human_to_bytes():
    tests = [
        # Input, Expected Output
        ('1', 1),
        ('3', 3),
        ('17b', 17),
        ('342MB', 35651584),
        ('7Mb', 7464960),
        ('8EB', 9.007199254740992e+18),
    ]
    for (arg, result) in tests:
        assert human_to_bytes(arg) == result

# Generated at 2022-06-22 14:17:53.318431
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([0]) == 0
    assert max([-1, 0, 1]) == 1
    assert max(['a', 'b', 'c']) == 'c'


# Generated at 2022-06-22 14:18:00.161779
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min('123') == '1'
    assert min((1, 2, 3)) == 1
    assert min({'a': 1, 'b': 2, 'c': 3}) == 1
    assert min(x=1, y=2, z=3) == 1
    assert min(1, y=2, z=3) == 1
    assert min(1, 2, z=3) == 1
    assert min(1, 2, 3, key=int) == 1
    assert min({'a': 1, 'b': 2, 'c': 3}, key=str) == 'a'
    assert min(3, 1, 2) == 1


# Generated at 2022-06-22 14:18:13.869093
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Note: We need to set duplicates to 'overwrite' as we are using dicts rather than dicts of dicts
    # in the tests
    def test_overwrite(in_data, in_key, expected_data, expected_error=None):
        try:
            out_data = rekey_on_member(in_data, in_key, duplicates='overwrite')
        except Exception as e:
            if expected_error is not None:
                assert to_native(e) == expected_error
                return
            raise
        if expected_error is not None:
            assert False, "Did not get expected error ({0})".format(expected_error)
        assert out_data == expected_data


# Generated at 2022-06-22 14:18:19.348775
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(8, 2) == 3
    assert logarithm(100) == 4.605170185988092
    try:
        logarithm("string")
    except AnsibleFilterTypeError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-22 14:18:27.618103
# Unit test for function max
def test_max():
    from ansible.plugins.filter.core import max
    a = [1,2,3]
    b = [3,2,1]
    assert max(a) == 3
    assert max(b) == 3
    assert max([1,2,3], [3,2,1]) == [3,2,1]
    assert max([1,2,3], 5) == 5
    assert max([1,2,3], 5, key=lambda x: x*-1) == 1


# Generated at 2022-06-22 14:18:33.927483
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max((1, 2, 3)) == 3
    assert max({1: 'data', 2: 'data', 3: 'data'}) == 3
    assert max(1, 2) == 2
    assert max('foo', 'bar') == 'foo'
    assert max('foobar', 'foo') == 'foobar'



# Generated at 2022-06-22 14:18:36.523304
# Unit test for function max
def test_max():
    fm = FilterModule()
    max_filter = fm.filters()['max']

    assert max_filter([1, 2, 3]) == 3


# Generated at 2022-06-22 14:18:46.267525
# Unit test for function min
def test_min():
    values = [0, 1, 2, 3, 4]
    # tests of min with mininum value in different positions
    assert min(values) == 0
    values.reverse()
    assert min(values) == 0
    # test of min with negative values
    values = [0, -1, -2, -3]
    assert min(values) == -3
    # test of min with ascending float values
    values = [0.1, 0.2, 0.3, 0.4]
    assert min(values) == 0.1
    # test of min with descending float values
    values.reverse()
    assert min(values) == 0.1



# Generated at 2022-06-22 14:18:49.965181
# Unit test for function max
def test_max():
    max = FilterModule().filters()['max']
    assert max([1, 2, 3, 4]) == 4
    assert max(['a', 'b', 'c', 'd']) == 'd'



# Generated at 2022-06-22 14:18:59.404819
# Unit test for function max
def test_max():
    assert max(range(5)) == 4
    assert max(range(1, 6)) == 5
    assert max(5, 2) == 5
    assert max(1, 5, 2) == 5
    assert max(1, 2, 3, 4, 5, key=abs) == 5
    assert max([1, 2, 3, 4, 5], key=abs) == 5
    assert max("12345") == "5"
    assert max("12345", key=abs) == "5"
    assert max(["1", "2", "3", "4", "5"], key=abs) == "5"

    assert max(range(1, 10), default=100) == 9
    assert max("", default=100) == 100
    assert max([], default=100) == 100

# Generated at 2022-06-22 14:19:31.132315
# Unit test for function unique
def test_unique():
    env = {'from_string': True, 'undefined': None}
    data = [1, 2, 2, 1]
    expected = [1, 2]
    actual = unique(env, data)
    assert actual == expected



# Generated at 2022-06-22 14:19:37.536852
# Unit test for function logarithm
def test_logarithm():
    assert math.log(2) == logarithm(2)
    assert math.log(100, 10) == logarithm(100, 10)
    assert math.log(100, 2) == logarithm(100, 2)
    try:
        # raises a TypeError
        logarithm("test")
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-22 14:19:50.084768
# Unit test for function min
def test_min():
    from jinja2 import Environment
    env = Environment()

    # Test normal behaviour of the min filter
    assert env.from_string('{{ [1,2,3] | min }}').render() == '1'
    assert env.from_string('{{ [3] | min }}').render() == '3'
    assert env.from_string('{{ [-1, -2] | min }}').render() == '-2'
    assert env.from_string('{{ [1.0, 2.0] | min }}').render() == '1.0'

    # Test error handling of the min filter
    try:
        env.from_string('{{ [] | min }}').render()
    except AnsibleFilterError as afe:
        assert "min() arg is an empty sequence" in to_native(afe)

# Generated at 2022-06-22 14:20:02.692441
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('100M') == 1024*1024*100
    assert human_to_bytes('100') == 100
    assert human_to_bytes('100G') == 1024*1024*1024*100
    assert human_to_bytes('1x') == 0
    assert human_to_bytes('1x', default_unit='M') == 0
    assert human_to_bytes('1x', default_unit='M', isbits=True) == 0
    assert human_to_bytes('0.5M') == 512*1024
    assert human_to_bytes('0.5K') == 512
    assert human_to_bytes('0.5G') == 1024*1024*512
    assert human_to_bytes('5120K') == 1024*1024*5

# Generated at 2022-06-22 14:20:14.464256
# Unit test for function unique
def test_unique():
    assert unique(['a','b','a','c','c']) == ['a','b','c']
    assert unique(['a','b','a','c','c'], case_sensitive=False) == ['a','b','c']
    assert unique(['a','b','a','c','c'], case_sensitive=True) == ['a','b','a','c','c']
    assert unique([], case_sensitive=True) == []
    assert unique(['a','b','a','c','c'], case_sensitive=False, attribute='split') == ['a','b','c']
    assert unique(['a','b','a','c','c'], case_sensitive=False, attribute='upper') == ['A','B','C']


# Generated at 2022-06-22 14:20:15.629261
# Unit test for function min
def test_min():
    assert min(1, 2) == 1
    assert min([2, 3, 1]) == 1


# Generated at 2022-06-22 14:20:23.857522
# Unit test for function human_to_bytes
def test_human_to_bytes():
    from ansible.plugins.filter import filters
    from ansible.module_utils.common.text import to_bytes
    h2b = filters.human_to_bytes


# Generated at 2022-06-22 14:20:28.218384
# Unit test for function min
def test_min():
    assert min(1, 2, 3, 4) == 1
    assert min([1, 2, 3, 4]) == 1
    assert min(1, 2, 3, 4, key=lambda x: -x) == 4



# Generated at 2022-06-22 14:20:40.389629
# Unit test for function min
def test_min():
    testobj = [
        1,
        [1, 2, 31],
        {'test1': 1, 'test2': 2, 'test3': 31},
        'test',
        {'test': {1: 'test1', 2: 'test2', 31: 'test3'}},
    ]

    # We use the same pytest fixtures and assert as Jinja2 test_filters.py
    testfilter = FilterModule()
    testfunc = testfilter.filters()['min']

    assert testfunc(testobj) == 1
    assert testfunc(testobj, attribute='test1') == 1
    assert testfunc(testobj, attribute='test2') == 2
    assert testfunc(testobj, attribute='test3') == 31
    assert testfunc(testobj, attribute='test') == 1



# Generated at 2022-06-22 14:20:47.685401
# Unit test for function human_to_bytes
def test_human_to_bytes():

    # Test list and tuple of non-negative numbers
    valid_positive = [(1024, '1 K'), (1024 ** 2, '1 M'), (1024 ** 3, '1 G'),
                      (1024 ** 4, '1 T'), (1024 ** 5, '1 P'), (1024 ** 6, '1 E'),
                      (1024 ** 7, '1 Z'), (1024 ** 8, '1 Y'), (1024 ** 1, '1024 B'),
                      (1024 ** 4 * 1.33, '1.33 T'), ('1024', '1024 B')]
    for input, output in valid_positive:
        assert human_to_bytes(input) == output

    # Test list and tuple of negative numbers

# Generated at 2022-06-22 14:21:29.342271
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.utils.display import Display
    import os
    display = Display()

    def run_test(data, key, duplicates, expected):
        result = rekey_on_member(data, key, duplicates=duplicates)
        if result != expected:
            display.display("TEST FAILED: {0}".format(inspect.stack()[1][3]))
            display.display("DATA: {0}".format(data))
            display.display("KEY: {0}".format(key))
            display.display("DUPLICATES: {0}".format(duplicates))
            display.display("EXPECTED: {0}".format(expected))
            display.display("RESULT: {0}".format(result))
            os._exit(os.EX_OK)

    # These tests

# Generated at 2022-06-22 14:21:33.505013
# Unit test for function max
def test_max():
    assert max([1,2,3,4,5]) == 5
    assert max(['hello','world']) == 'world'
    assert max([1,'hello']) == 'hello'
    assert max([1]) == 1
    assert max([]) == None

# Generated at 2022-06-22 14:21:45.439168
# Unit test for function unique
def test_unique():
    '''
    Test set theory functions
    '''
    # Test normal:
    data = [1, 2, 3, 2, 3]
    res = [1, 2, 3]
    assert unique(data) == res

    # Test case_sensitive=False
    data = [1, 2, 3, 2, 3]
    res = [1, 2, 3]
    assert unique(data, case_sensitive=False) == res

    # Test of attribute
    data = [{'a': 1}, {'a': '1'}, {'a': 2}, {'a': '2'}]
    res = [{'a': 1}, {'a': 2}]
    assert unique(data, False, 'a') == res