

# Generated at 2022-06-22 14:11:59.769311
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4
    assert max([4, 3, 1, 2]) == 4
    assert max(['a', 'b', 'c', 'd']) == 'd'
    assert max(['d', 'b', 'e', 'c']) == 'e'
    assert max(['1', '2', '3', '4']) == '4'
    assert max(['4', '3', '2', '1']) == '4'



# Generated at 2022-06-22 14:12:05.905196
# Unit test for function logarithm
def test_logarithm():
    mylist = [1, 2, 3, 4]
    expected_list = [0, 1, 1.5849625007211563, 2]
    result_list = list()
    for i in mylist:
        result_list.append(logarithm(i))
    assert expected_list == result_list


# Generated at 2022-06-22 14:12:17.517228
# Unit test for function max
def test_max():
    import math
    # Test multiple input types
    assert max([1,2,3]) == 3
    assert max(range(3)) == 2
    assert max([[1,2], [3,4], [5,6]], key=lambda x: x[0]) == [5, 6]
    assert max([[1,2], [3,4], [5,6]], key=lambda x: x[1]) == [3, 4]
    assert max([{'name':'John', 'age':42}, {'name':'John', 'age':43}], key=lambda x: x['age']) == {'name':'John', 'age':43}
    # Test non-keyed max
    assert max(math.sqrt(x) for x in range(10)) == 3

# Generated at 2022-06-22 14:12:29.634990
# Unit test for function min
def test_min():
    import sys
    sys.path.append('../')
    import yaml

    # test min should work with different type of objects

# Generated at 2022-06-22 14:12:41.013872
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [
        {
            "id": 1,
            "value": "abc"
        },
        {
            "id": 2,
            "value": "xyz"
        }
    ]
    key = "id"
    res = rekey_on_member(data, key)
    assert res == {1: {"id": 1, "value": "abc"}, 2: {"id": 2, "value": "xyz"}}
    res = rekey_on_member(data, key, duplicates='overwrite')
    assert res == {1: {"id": 1, "value": "abc"}, 2: {"id": 2, "value": "xyz"}}
    data_dups = data * 2

# Generated at 2022-06-22 14:12:52.129223
# Unit test for function max
def test_max():
    assert max([3, 1, 4, 1, 5]) == 5, 'Failed max([3, 1, 4, 1, 5]) test'
    assert max([[3, 1], 4, [1, 5]]) == [3, 1], 'Failed max([[3, 1], 4, [1, 5]]) test'
    assert max([[3, 1], [4], [1, 5]]) == [4], 'Failed max([[3, 1], [4], [1, 5]]) test'
    assert max([3, 'A', 4, 'B', 5]) == 'B', 'Failed max([3, "A", 4, "B", 5]) test'

# Generated at 2022-06-22 14:12:59.211801
# Unit test for function human_to_bytes

# Generated at 2022-06-22 14:13:11.651168
# Unit test for function min
def test_min():

    def assert_min(a, b, c, d=None):
        assert(a < b)
        assert(b < c)
        assert(min(a, b, c) == a)
        assert(min([a, b, c]) == a)
        assert(min(a, b) == a)
        assert(min([a, b]) == a)
        assert(min(a, b, c, d) == a)
        assert(min([a, b, c, d]) == a)
        assert(min(b, c, a) == a)
        assert(min([b, c, a]) == a)
        assert(min(c, b, a) == a)
        assert(min([c, b, a]) == a)
        assert(min(c, b, a, d) == a)

# Generated at 2022-06-22 14:13:14.620621
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100, 10) == 2
    assert logarithm(100) == math.log(100)



# Generated at 2022-06-22 14:13:18.078984
# Unit test for function inversepower
def test_inversepower():
    filter = FilterModule()
    filters = filter.filters()
    assert (type(filters['inversepower']) is type(filters['root']))


# Generated at 2022-06-22 14:13:32.173871
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert unique(['a', 'c', 'b', 'c', 'd', 'e', 'f']) == ['a', 'c', 'b', 'd', 'e', 'f']
    assert unique(['a', 'c', 'b', 'c', 'd', 'e', 'f'], case_sensitive=False) == ['a', 'c', 'b', 'd', 'e', 'f']
    assert unique([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]

# Generated at 2022-06-22 14:13:44.102681
# Unit test for function max
def test_max():
    """
    Unit test for max filter
    """

    input_list = ['a', 'b', 'c', 'd']
    input_dict_1 = {'key1': 'abc', 'key2': 'def'}
    input_dict_2 = {'key1': 'aaa', 'key2': 'asd'}
    input_dict_3 = {'key1': 'zzz', 'key2': 'zxc'}
    input_dict_4 = {'key1': 'zzz', 'key2': 'bbb'}
    input_dict_5 = {'key1': 'zzz', 'key2': 'ccc'}
    input_dict_6 = {'key1': 'zzz', 'key2': 'ddd'}

# Generated at 2022-06-22 14:13:54.537259
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # Test a dict of dicts
    test_data = {'key_1': {'foo': 'bar', 'baz': 'foz'},
                 'key_2': {'foo': 'bar', 'baz': 'foz'},
                 'key_3': {'foo': 'bar', 'baz': 'foz'}, }

    # Check for duplicates
    try:
        rekey_on_member(test_data, 'foo')
    except Exception as e:
        assert type(e) == AnsibleFilterError and str(e) == "Key bar is not unique, cannot correctly turn into dict"
    else:
        assert False, "Duplicate error not raised"

    # Overwrite on duplicate

# Generated at 2022-06-22 14:14:04.171951
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.plugins.filter.core import FilterModule
    from collections import namedtuple
    from jinja2 import Dict, Template


# Generated at 2022-06-22 14:14:14.291336
# Unit test for function symmetric_difference
def test_symmetric_difference():
    module = FilterModule()
    filters = module.filters()
    test = filters['symmetric_difference']

    assert test([1,2,3,4], [1,2,5]) == [3,4,5]
    assert test([1,2,3,4], [1,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]) == [4]
    assert test([1,2,3,4], [1,2,4]) == [3]
    assert test([1,2,3,4], [1,2,3,4]) == []

# Generated at 2022-06-22 14:14:19.212442
# Unit test for function rekey_on_member
def test_rekey_on_member():
    test_data = {
        'a': {'foo': 'bar', 'baz': 'qux'},
        'b': {'foo': 'quux', 'quux': 'quuz'},
    }
    assert rekey_on_member(test_data, 'foo') == {
        'bar': {'foo': 'bar', 'baz': 'qux'},
        'quux': {'foo': 'quux', 'quux': 'quuz'},
    }

# Generated at 2022-06-22 14:14:22.074069
# Unit test for function min
def test_min():
    filter_ = FilterModule()
    filter_.filters()
    assert filter_.filters()['min']([1, 2, 3]) == 1


# Generated at 2022-06-22 14:14:33.058426
# Unit test for function min
def test_min():
    min_value = min([-1, 0, 1])
    assert (min_value == -1)

    min_value = min([-9, -8, -7, -1])
    assert (min_value == -9)

    min_value = min([1, 9, 10, 11])
    assert (min_value == 1)

    min_value = min([-5, -2, -3, 1])
    assert (min_value == -5)

    min_value = min([-18, -17, -14, -10])
    assert (min_value == -18)

    min_value = min([-6, -2, 1, 3])
    assert (min_value == -6)

    min_value = min([-4, -4, -4, -4])

# Generated at 2022-06-22 14:14:41.688421
# Unit test for function max
def test_max():
    f = FilterModule()
    filters = f.filters()
    assert filters['max']([1, 2, 3]) == 3
    assert filters['max'](("apple", "banana", "cherry")) == "cherry"
    assert filters['max'](("apple", "banana", "cherry"), key=lambda x: len(x)) == "banana"
    assert filters['max'](("apple", "banana", "cherry"), key=lambda x: len(x), reverse=True) == "apple"
    assert filters['max'](("apple", "banana", "cherry"), key=lambda x: len(x), reverse=True, default="None") == "apple"

# Generated at 2022-06-22 14:14:54.139618
# Unit test for function max
def test_max():
    # max of zero elements is None
    assert(max([]) == None)
    # max of 1 element is that element
    assert(max([1]) == 1)
    # max of strings is the alphabetically last
    assert(max(["a", "b"]) == "b")
    # max of string and element is string
    assert(max(["1", 1]) == "1")
    # max() does not work on None
    try:
        max(None)
        assert(False)
    except AnsibleFilterTypeError:
        pass

    # max() does not work on variables
    try:
        max(ansible_version)
        assert(False)
    except AnsibleFilterTypeError:
        pass

    # max() does not work on strings

# Generated at 2022-06-22 14:15:06.460526
# Unit test for function min
def test_min():
    # Function min(a, b) returns min of a and b
    assert min(1, 2) == 1
    assert min([5, 2, 3, 1, 4]) == 1
    assert min([]) == None



# Generated at 2022-06-22 14:15:17.034627
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest
    import jinja2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    env = jinja2.Environment()
    env.filters['rekey_on_member'] = rekey_on_member


# Generated at 2022-06-22 14:15:18.328116
# Unit test for function max
def test_max():
    assert 100 == max([1, 2, 3, 4, 100])


# Generated at 2022-06-22 14:15:30.115610
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2
    assert max([1.0, 2.0]) == 2.0
    assert max([1, 2.0]) == 2.0
    assert max([1, 2], [2, 3]) == [2, 3]
    assert max([1, 2], [2, 1]) == [2, 2]
    assert max([1, 2], [3, -1]) == [3, 2]
    assert max([1, 2], [3, 4], [5, 6]) == [5, 6]
    assert max([1, 2], [3, 4], [2, 3]) == [3, 4]
    assert max([1, 2], [3, 4], [5, 2]) == [5, 4]
    assert max(1, 2) == 2

# Generated at 2022-06-22 14:15:40.554577
# Unit test for function max
def test_max():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.module_utils.common._collections_compat import Mapping, Iterable

    class TestMax(unittest.TestCase):

        def setUp(self):
            # do_max() raises TypeError when the second arg is a bool
            self.bool_patcher = patch('ansible.plugins.filter.core.do_max')
            self.mock_do_max = self.bool_patcher.start()
            self.mock_do_max.side_effect = TypeError

            # do_max() raises ValueError when the first arg is not a list or dict
            self.iter_patcher = patch('ansible.plugins.filter.core.do_max')
            self.m

# Generated at 2022-06-22 14:15:52.066302
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils._text import to_bytes

    from ansible.plugins.filter.core import FilterModule as core_filter

    # Note: the init_jinja_env method is called within the Ansible class
    # C0103: Invalid name (see C0103 in -W)
    # pylint: disable=C0103
    init_jinja_env = core_filter.init_jinja_env

    init_jinja_env(self=None)

    test_filters = FilterModule()


# Generated at 2022-06-22 14:15:56.195531
# Unit test for function symmetric_difference
def test_symmetric_difference():
    sym_data = list(symmetric_difference(None, [1, 2, 3, 4], [1, 2, 5, 6]))
    assert sym_data == [3, 4, 5, 6], sym_data

# Generated at 2022-06-22 14:15:57.581320
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3



# Generated at 2022-06-22 14:16:07.711003
# Unit test for function min
def test_min():
    # test with list
    if min([1, 2, 3, 4, 5, 5]) != 1:
        raise Exception("failed to find minimum of [1, 2, 3, 4, 5, 5]")

    # test with list of strings
    if min(['bar', 'baz', 'foo']) != 'bar':
        raise Exception("failed to find minimum of ['bar', 'baz', 'foo']")

    # test with list of integers and strings
    if min([1, 'bar', 2, 'baz', 'foo']) != 1:
        raise Exception("failed to find minimum of [1, 'bar', 2, 'baz', 'foo']")

    # test with tuple

# Generated at 2022-06-22 14:16:10.887264
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 'a']) == 1
    assert max([]) is None



# Generated at 2022-06-22 14:16:19.435032
# Unit test for function unique
def test_unique():
    environment = {}
    a = [1, 2, 3, 1, 2, 3]
    b = unique(environment, a, True)
    assert(b == [1, 2, 3])
    b = unique(environment, a, False)
    assert(b == [1, 2, 3])


# Generated at 2022-06-22 14:16:22.218978
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([-1, -2, -3]) == -1


# Generated at 2022-06-22 14:16:35.140171
# Unit test for function rekey_on_member
def test_rekey_on_member():
    def _test_rekey_on_member(data, key, expected, duplicates):
        actual = rekey_on_member(data, key, duplicates=duplicates)
        assert actual == expected, "actual: {} != expected: {}".format(actual, expected)

    # Test list to dict of dicts
    _test_rekey_on_member([{'foo': 'bar', 'baz': 'quux'}, {'foo': 'zod', 'baz': 'bam'}], 'foo',
                          {'bar': {'foo': 'bar', 'baz': 'quux'}, 'zod': {'foo': 'zod', 'baz': 'bam'}}, 'error')

    # Test failure on duplicate key values

# Generated at 2022-06-22 14:16:46.457567
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 14:16:52.313818
# Unit test for function min
def test_min():
    result = min([1, 2, 3])
    assert result == 1

    result = min([3, 2, 1])
    assert result == 1

    result = min([-1, -2, -3])
    assert result == -3

    result = min('foobar')
    assert result == 'a'

    result = min(['foo', 'bar'])
    assert result == 'bar'



# Generated at 2022-06-22 14:17:05.787346
# Unit test for function max
def test_max():
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils._text import to_bytes, to_text

    assert max('qwer') == 'w'
    assert max([1, 2, 3]) == 3
    assert max(['abc', 'def']) == 'def'
    assert max([1, 2, '3']) == 2
    assert max(b'abc') == to_bytes('c')
    assert max([1, 2, 3], key=lambda x: -x) == 1

    assert max([dict(a=1), dict(a=2), dict(a=3)], key=lambda x: x['a']) == dict(a=3)
    assert max(['abc', 'xyz'], key=lambda x: -len(x)) == 'abc'

    assert max

# Generated at 2022-06-22 14:17:18.742905
# Unit test for function human_to_bytes
def test_human_to_bytes():
    '''
    Test human_to_bytes function
    '''
    total = 0

# Generated at 2022-06-22 14:17:28.262291
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1023) == '1023.0 B'
    assert human_readable(1024) == '1.0 KB'
    assert human_readable(1024 ** 2) == '1.0 MB'
    assert human_readable(1024 ** 3) == '1.0 GB'
    assert human_readable(1024 ** 4) == '1.0 TB'
    assert human_readable(1024 ** 5) == '1.0 PB'
    assert human_readable(1024 ** 6) == '1024.0 PB'
    assert human_readable(1024 ** 7) == '1048576.0 PB'

    assert human_readable(0, isbits=True) == '0'
    assert human_readable(1023, isbits=True) == '8191 bits'
    assert human

# Generated at 2022-06-22 14:17:29.904921
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: -x) == 3



# Generated at 2022-06-22 14:17:33.295279
# Unit test for function min
def test_min():
    tests = []
    tests.append(([1, 2, 3], 1))
    tests.append(([1.1, 2.2, 3.3], 1.1))
    tests.append((['b', 'a', 'c'], 'a'))
    return tests



# Generated at 2022-06-22 14:17:46.474706
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Function rekey_on_member should generate a new dictionary from an old dictionary
    test_dict = {"a": {"x": "foo", "y": "bar"}, "b": {"x": "foo", "y": "baz"}, "z": {"x": "foo", "y": "bat"}}
    new_dict = rekey_on_member(test_dict, "x")
    assert new_dict == {"foo": {"x": "foo", "y": "bat"}}
    new_dict = rekey_on_member(test_dict, "y")
    assert new_dict == {"bar": {"x": "foo", "y": "bar"}, "baz": {"x": "foo", "y": "baz"}, "bat": {"x": "foo", "y": "bat"}}

    # Function rekey_on_member

# Generated at 2022-06-22 14:17:52.352760
# Unit test for function max
def test_max():
    assert 10 == max([1, 10, 3])
    assert (1, 2, 3) == max([(1, 2, 1), (1, 2, 3)], key=lambda x: x[2])
    assert -10.5 == max([-10.5, -10.6, -10.4])
    assert 'c' == max(['a', 'b', 'c'])


# Generated at 2022-06-22 14:18:02.246914
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    assert PY3
    # data is a dict
    data = {
        "key1": {"inet": "1.2.3.4/24", "hwaddr": "aa:bb:cc:dd:ee:ff", "iface": "eth0"},
        "key2": {"inet": "5.6.7.8/24", "hwaddr": "aa:bb:cc:dd:ee:00", "iface": "eth1"}
    }
    result = rekey_on_member(data, "hwaddr", duplicates='error')

# Generated at 2022-06-22 14:18:05.651004
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min(1,2,3) == 1
    assert min([]) == None



# Generated at 2022-06-22 14:18:16.948333
# Unit test for function human_readable

# Generated at 2022-06-22 14:18:28.948922
# Unit test for function max
def test_max():
    # Old versions of Jinja2 do not have do_max
    if HAS_MIN_MAX:
        return

    # Test int input
    test_int_input = max([1, 2, 3])
    assert test_int_input == 3

    # Test list input
    test_list_input = max([1, [2, 3], 4])
    assert test_list_input == [2, 3]

    # Test float input
    test_float_input = max([1.0, 2.0, 3.0])
    assert test_float_input == 3.0

    # Test str input
    test_str_input = max(['test', 'max', 'this'])
    assert test_str_input == 'this'

    # Test bool input
    test_bool_input = max([True, False, True])
   

# Generated at 2022-06-22 14:18:39.412033
# Unit test for function min
def test_min():
    data1 = [1, 2, 3, 4, 5]
    data2 = [-10, 10, 5, 100]
    data3 = ["foo", "bar", "baz", "qux"]
    data4 = [range(1, 5)]
    data5 = [
        {"a": 1},
        {"a": 2},
        {"a": 3},
        {"a": 4},
        {"a": 5},
    ]
    data6 = [
        {"a": 0, "b": 1},
        {"a": 1, "b": 2},
        {"a": 2, "b": 3},
        {"a": 3, "b": 4},
        {"a": 4, "b": 5},
    ]

# Generated at 2022-06-22 14:18:45.682655
# Unit test for function min
def test_min():
    assert 0 == min([0, 1, 2, 3])
    assert -1 == min([0, -1, 2, 3])
    assert 0 == min([0, 0, 0, 0])
    assert -3 == min([0, -3, 0, 0])
    assert -4 == min([1, 2, 3, -4])
    assert -4 == min([-4, 1, 2, 3])
    assert 0 == min([0, 1, 2, 3], attribute='value')
    assert None == min([False, None, 0, 1, 2, 3], attribute='value')
    assert False == min([False, None, 0, 1, 2, 3], attribute='truth')



# Generated at 2022-06-22 14:18:55.056647
# Unit test for function min
def test_min():
    assert min([1, 2]) == 1
    assert min([2, 1]) == 1
    assert min([1, 2, 3]) == 1
    assert min([3, 1, 2]) == 1
    assert min([-1, -2]) == -2
    assert min([-2, -1]) == -2
    assert min([-1, -2, -3]) == -3
    assert min([-3, -1, -2]) == -3
    assert min([1, -2, 3]) == -2
    assert min([1, 2, 3.0]) == 1.0
    assert min(['a', 'c', 'b']) == 'a'



# Generated at 2022-06-22 14:19:05.081645
# Unit test for function rekey_on_member
def test_rekey_on_member():

    def check_expected_output(args, expected):
        result = rekey_on_member(*args)
        assert result == expected, "With args {0}, expected {1} but got {2}".format(args, expected, result)

    check_expected_output(({'invalid': {'key': 'value'}}, 'key',),
                          {'key': 'value'})
    check_expected_output(({'a': {'key': 'value'}, 'b': {'key': 'value'}}, 'key',),
                          {'value': {'key': 'value'}})

# Generated at 2022-06-22 14:19:30.529925
# Unit test for function unique
def test_unique():
    assert unique(None, [1, 2, 3, 2, 4, 1, 5]) == [1, 2, 3, 4, 5]

    # Test case-insensitive
    assert unique(None, ['hello', 'wOrLD', 'world']) == ['hello', 'wOrLD']
    assert unique(None, ['hello', 'wOrLD', 'world'], case_sensitive=False) == ['hello']

    # Test limiting to specific attribute
    assert unique(None, [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
        {'a': 1, 'b': 4},
    ], attribute='b') == [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
    ]

    # Test error if 'case

# Generated at 2022-06-22 14:19:33.706197
# Unit test for function min
def test_min():
    from ansible.utils import plugins

    min_filter = plugins.lookup_loader.get('min')
    assert(min_filter == min)


# Generated at 2022-06-22 14:19:35.951116
# Unit test for function max
def test_max():
    assert max(list(range(11))) == 10


# Generated at 2022-06-22 14:19:38.578159
# Unit test for function min
def test_min():
    reference = [3, 4, 5, 6, 7]
    filter_result = min(reference)
    assert filter_result == 3


# Generated at 2022-06-22 14:19:50.731095
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, 5, 6]) == 6
    assert max([-2, -4, 0, 1, 5, -10]) == 5
    assert max([1, 2, 3], [5, 6, 7]) == [5, 6, 7]
    assert max([1, 2, 3], [5, 4, 3]) == [5, 4, 3]
    assert max([1, 2, 3], [1, 2, 3]) == [1, 2, 3]
    assert max([1, 2, 3], [5, 6, 7], [9, 10, 11]) == [9, 10, 11]
    assert max([1, 2, 3], [5, 6, 7], [9, 8, 7]) == [9, 8, 7]

# Generated at 2022-06-22 14:19:53.667318
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2
    assert max(['a', 'b']) == 'b'



# Generated at 2022-06-22 14:19:57.050837
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2
    assert max([2, 1]) == 2
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3, 2]) == 3



# Generated at 2022-06-22 14:20:04.854088
# Unit test for function unique
def test_unique():
    """
    Verify that the unique filter works with lists and removes duplicates
    :return:
    """

    from ansible.module_utils import basic

    data = [1, 2, 3, 4, 2, 5, 6, 3, 7, 8, 4, 9, 0, 5, 2, 1, 2, 5, 2, 0, 9]
    module = basic.AnsibleModule(argument_spec={})
    module.exit_json(changed=False, data={'list': data})

# Generated at 2022-06-22 14:20:17.236512
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from jinja2 import Template

    data = [
        {"key1": "value1", "key2": "value2", "key3": 1},
        {"key1": "value1", "key2": "value2-1", "key3": 1},
        {"key1": "value1", "key2": "value2-2", "key3": 2},
        {"key1": "value2", "key3": 3},
    ]

    def _test(tmpl, expect):
        t = Template("{{ data | rekey_on_member('key1', duplicates='overwrite') }}")
        results = t.render(data=tmpl)
        assert results == expect, "failed to get expected result: %s" % results


# Generated at 2022-06-22 14:20:24.637441
# Unit test for function max
def test_max():
    f = FilterModule()
    assert f.filters()['max']([1, 0, 2, -1]) == 2
    assert f.filters()['max']([1, 0, 2, -1], attribute="bar") == 2
    assert f.filters()['max']([{'bar': 1}, {'bar': 0}, {'bar': 2}, {'bar': -1}], attribute="bar") == 2
    assert f.filters()['max'](["a", "b", "B", "c"], attribute="lower") == "c"
    assert f.filters()['max'](["a", "b", "B", "c"], attribute="lower", case_sensitive=False) == "c"

# Generated at 2022-06-22 14:20:59.301044
# Unit test for function max
def test_max():
    ''' min/max filter test cases '''
    test_cases = [
        ["abc", "bcd", "cde", "def"],
        [["abc", "100"], ["bcd", "200"], ["cde", "300"], ["def", "400"]],
        ["abc", ["bcd", "200"], "cde", ["def", "400"]],
        [["abc", "100"], "bcd", ["cde", "300"], "def"],
    ]
    for test_case in test_cases:
        assert max(*test_case) == "def"



# Generated at 2022-06-22 14:21:03.975376
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1
    assert min([1.1, 1.0, 2.0, -3.0]) == -3.0
    assert min([1, 2, 3, 4], key=lambda x: -x) == 4



# Generated at 2022-06-22 14:21:16.878634
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes("1T") == (1 * 1024 * 1024 * 1024 * 1024)
    assert human_to_bytes("1T", default_unit="B", isbits=False) == (1 * 1024 * 1024 * 1024 * 1024)
    assert human_to_bytes("1T", default_unit="B", isbits=True) == (1 * 1024 * 1024 * 1024 * 1024 * 8)
    assert human_to_bytes("100") == 100
    assert human_to_bytes("100", default_unit="b") == 100
    assert human_to_bytes("100", default_unit="b") == 100
    assert human_to_bytes("100", default_unit="B") == 100
    assert human_to_bytes("100", default_unit="B") == 100

# Generated at 2022-06-22 14:21:29.177653
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, 5]) == 5
    assert max([-1, -2, -3, -4, -5]) == -1
    assert max([-1.1, -2.2, -3.3, -4.4, -5.5]) == -1.1
    assert max(1, 2, 3, 4, 5) == 5
    assert max(-1, -2, -3, -4, -5) == -1
    assert max(-1.1, -2.2, -3.3, -4.4, -5.5) == -1.1
    assert max("abcdef") == "f"
    assert max("abcdef", key=lambda x: x.lower()) == "f"

# Generated at 2022-06-22 14:21:42.426942
# Unit test for function human_readable
def test_human_readable():

    assert human_readable(1) == "1 B"
    assert human_readable(1, unit='B') == "1 B"
    assert human_readable(1, unit='B', isbits=True) == "8 b"
    assert human_readable(999) == "999 B"
    assert human_readable(1000) == "1.0 kB"
    assert human_readable(1000, unit='B', isbits=True) == "8.0 Kb"
    assert human_readable(1024) == "1.0 kB"
    assert human_readable(1000, unit='B') == "1000 B"
    assert human_readable(1024, unit='B') == "1024 B"
    assert human_readable(1024, unit='B', isbits=True) == "8.0 Kb"