

# Generated at 2022-06-22 14:12:05.582559
# Unit test for function min
def test_min():
    if HAS_MIN_MAX:
        import jinja2
        env = jinja2.Environment()
        assert env.from_string('{{ [1,2,3,4]|min }}').render() == '1'
    else:
        assert min([1,2,3,4]) == 1


# Generated at 2022-06-22 14:12:16.880148
# Unit test for function rekey_on_member
def test_rekey_on_member():
    """Unit test for function rekey_on_member
    """
    data_1 = [
        {'a': 'key1', 'b': 'val1'},
        {'a': 'key2', 'b': 'val2'},
        {'a': 'key3', 'b': 'val3'}
    ]

    data_2 = {
        'a': {'a': 'key1', 'b': 'val1'},
        'b': {'a': 'key2', 'b': 'val2'},
        'c': {'a': 'key3', 'b': 'val3'}
    }

    # The test input is a list of dicts, which should be valid. The duplicates
    # parameter has a default value of 'error', which should be carry over.

# Generated at 2022-06-22 14:12:25.516267
# Unit test for function human_readable
def test_human_readable():
    tests = [
        10048576,
        1024,
        1000,
        1023,
        123456789,
        123456789123456789,
        1024,
        1023,
        1023000,
        1023456,
        1023000000000,
        102300000000023456789,
        102400000000023456789,
        1023000000123456789,
    ]
    for test in tests:
        human_readable(test)



# Generated at 2022-06-22 14:12:37.041624
# Unit test for function human_readable
def test_human_readable():
    from ansible.plugins.filter import human_readable

    assert human_readable(8) == "8 bytes"
    assert human_readable(8, isbits=True) == "64 bits"
    assert human_readable(8, unit='f') == "8 f"
    assert human_readable(8, isbits=True, unit='f') == "8 f"
    assert human_readable(8, unit='B') == "8 B"
    assert human_readable(8, isbits=True, unit='B') == "8 B"
    assert human_readable(8, unit='B', isbits=True) == "8 B"

    assert human_readable(1024) == "1.0 KiB"
    assert human_readable(1024, isbits=True) == "8.0 Kib"

# Generated at 2022-06-22 14:12:38.485380
# Unit test for function rekey_on_member
def test_rekey_on_member():
    test = dict()
    rekey_on_member(test, 'key')



# Generated at 2022-06-22 14:12:50.896506
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 'a', 'b', 'c']) == 'a'
    assert min(['a', 'ab', 'abc']) == 'a'
    assert min([], default=0) == 0
    assert min([1, 2, 3], by=[4, 3, 2]) == [4, 3, 2]
    assert min([1, 2, 3], by='b') == [1, 2, 3]
    assert min({'a': 1, 'b': 9, 'c': 4}) == {'a': 1}
    assert min({'a': 1, 'b': 9, 'c': 4}, by='b') == {'a': 1}

# Generated at 2022-06-22 14:13:01.823917
# Unit test for function rekey_on_member
def test_rekey_on_member():
    assert rekey_on_member([{'a': 1, 'b': 2}, {'a': 2, 'b': 2}], 'a') == {1: {'a': 1, 'b': 2}, 2: {'a': 2, 'b': 2}}
    try:
        rekey_on_member([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}], 'a')
        assert False
    except AnsibleFilterError:
        pass
    assert rekey_on_member([{'a': 1, 'b': 2}, {'a': 1, 'b': 3}], 'a', 'overwrite') == {1: {'a': 1, 'b': 3}}

# Generated at 2022-06-22 14:13:05.659175
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3


# Generated at 2022-06-22 14:13:18.467375
# Unit test for function human_to_bytes
def test_human_to_bytes():
    # default unit is K
    assert human_to_bytes('1') == 1*1024
    assert human_to_bytes('1') == human_to_bytes('1K')
    assert human_to_bytes('1K') == 1*1024

    # test unit M
    assert human_to_bytes('2M') == 2*1024*1024
    assert human_to_bytes('3m') == 3*1024*1024

    # test unit G
    assert human_to_bytes('2G') == 2*1024*1024*1024
    assert human_to_bytes('3g') == 3*1024*1024*1024

    # test unit T
    assert human_to_bytes('2T') == 2*1024*1024*1024*1024
    assert human_to_bytes('3t') == 3*1024*1024*1024*1024

    #

# Generated at 2022-06-22 14:13:26.480645
# Unit test for function power
def test_power():
    ansible_module = type('Mod', (object,), {'fail_json': lambda *args, **kwargs: None})
    f = FilterModule()
    filters = f.filters()
    assert filters['pow'](2, 2) == 4
    assert filters['pow'](2) == 2
    try:
        filters['pow']('2', 2)
        assert False
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-22 14:13:37.293129
# Unit test for function max
def test_max():
    assert max(['a', 'b', 'c']) == 'c'
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([1, 'b', 'c']) == 'c'
    assert max([1, 'c', 2]) == 'c'



# Generated at 2022-06-22 14:13:47.801600
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import iteritems
    from jinja2 import Environment, meta
    from jinja2.exceptions import UndefinedError

    env = Environment(undefined=UndefinedError)
    loader = env.loader
    env.filters['rekey_on_member'] = rekey_on_member
    template = env.from_string('''{{
        a_dict | dict2items | rekey_on_member('key') | list
        }}''')
    # Check that the template gets properly parsed and doesn't raise errors
    assert meta.find_undeclared_variables(template) == set(['a_dict'])

    # Check that rekey_on_member works as expected and returns a dict or raises an exception
    # when the arguments are missing or wrong

# Generated at 2022-06-22 14:13:51.607167
# Unit test for function max
def test_max():
    ''' Test the max filter '''
    assert max([10, 5]) == 10


if __name__ == "__main__":
    print(test_max())

# Generated at 2022-06-22 14:13:56.231618
# Unit test for function max
def test_max():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    test_obj = UnsafeProxy({"item1": 1, "item2": 2, "item3": 3})
    test_data = {
        'with_data_dict': wrap_var({"item1": 1, "item2": 2, "item3": 3}),
        'with_data_list': wrap_var([1, 2, 3])
    }
    res = max(test_data['with_data_dict'], 'item1')
    assert res == 3, "max should return the max of a given dict, %s is incorrect" % res
    res = max(test_data['with_data_list'])
    assert res == 3, "max should return the max of a given list, %s is incorrect" % res
   

# Generated at 2022-06-22 14:14:02.421223
# Unit test for function max
def test_max():
    # Init test object
    filter_module = FilterModule()
    # If no exception is raised on filter init, attribute exists
    assert filter_module.filters.get('max') is not None
    # If key is not present, return None
    assert filter_module.filters.get('max')(None, [1, 2, 3], default=None) is None
    # General case
    assert filter_module.filters.get('max')(None, [1, 2, 3]) == 3


# Generated at 2022-06-22 14:14:04.410484
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4]) == 4


# Generated at 2022-06-22 14:14:06.640947
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(100, 10) == 2.0


# Generated at 2022-06-22 14:14:10.833323
# Unit test for function min
def test_min():
    assert min([5, 2, 9]) == 2
    assert min([5, 2, 9], True) == 2
    assert min(['a', 'b', 'c']) == 'a'
    assert min(['a', 'b', 'c'], True) == 'a'



# Generated at 2022-06-22 14:14:18.553419
# Unit test for function human_to_bytes

# Generated at 2022-06-22 14:14:23.020462
# Unit test for function power
def test_power():
    assert(power(2, 16) == 2**16)
    assert(power(3, 2) == 9)
    assert(power(3, 3) == 27)
    assert(power(2, 8) == 256)
    assert(power(2, -16) == 1/(2**16))
    assert(power(3, 1) == 3)


# Generated at 2022-06-22 14:14:29.146809
# Unit test for function max
def test_max():
    max_value = 9999
    display.warning("Hello, {:>10}".format(max_value))

# Generated at 2022-06-22 14:14:38.539059
# Unit test for function max
def test_max():
    import jinja2
    env = jinja2.Environment()
    f = max
    assert f(env, [1, 2, 3, 4, 1, 5, 7, 1, 2, 3]) == 7
    assert f(env, ['a', 'b', 'c', 'd']) == 'd'
    assert f(env, [[1, 2, 3], [4, 5, 6]]) == [4, 5, 6]
    assert f(env, [[1, 2, 3], ['abc', 'de', 'fg']]) == [1, 2, 3]
    assert f(env, [[1, 2, 3], [1, [2, 3], 4]]) == [1, [2, 3], 4]

# Generated at 2022-06-22 14:14:51.390517
# Unit test for function unique
def test_unique():
    """
    Test filter unique with following test cases:
        empty list,
        list of integers, floats and strings,
        list of ints from 1 to 1000 (to detect O(n^2) behaviour),
        list of dictionaries,
        list of lists,
        list of strings and dictionaries
    """
    import random
    import string
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text import formatters


# Generated at 2022-06-22 14:15:00.862089
# Unit test for function human_readable
def test_human_readable():
    ''' test human_readable filter '''
    # test kilo
    assert human_readable(1024) == '1.00K'
    assert human_readable(1024, True) == '1.02K'  # 1.024KiB
    assert human_readable(1024 * 2) == '2.00K'
    assert human_readable(1024 * 2, True) == '2.05K'
    assert human_readable(1024 * 1024) == '1.00M'
    assert human_readable(1024 * 1024, True) == '1.05M'
    assert human_readable(1024 * 1024 * 1024) == '1.00G'
    assert human_readable(1024 * 1024 * 1024, True) == '1.07G'
    assert human_readable(1024 * 1024 * 1024 * 1024) == '1.00T'


# Generated at 2022-06-22 14:15:12.140723
# Unit test for function max
def test_max():
    c1 = [1, 2]
    c2 = [1, 2]
    d1 = {'a': 1, 'b': 2}
    d2 = {'a': 1, 'b': 2}
    assert max(c1, c2) == [1, 2]
    assert max(d1, d2) == {'a': 1, 'b': 2}

    assert max(c1, reverse=True) == [1, 2]
    assert max(d1, reverse=True) == {'a': 1, 'b': 2}

    assert max(c1, key=lambda x: x) == [1, 2]

    assert max(c1, c2, key=lambda x: x) == [1, 2]

# Generated at 2022-06-22 14:15:13.338144
# Unit test for function max
def test_max():
    assert max('ab') == 'b', 'should be b'



# Generated at 2022-06-22 14:15:24.617427
# Unit test for function human_readable
def test_human_readable():

    # Test positive numbers
    assert human_readable(0) == '0 Bytes'
    assert human_readable(1) == '1 Byte'
    assert human_readable(1024) == '1.0 KiB'
    assert human_readable(1024, isbits=True) == '8.0 Kib'
    assert human_readable(1024, isbits=True, unit='B') == '0.0 Kib'
    assert human_readable(10240) == '10.0 KiB'
    assert human_readable(10240, isbits=True) == '80.0 Kib'
    assert human_readable(10240, unit='B') == '10240 Bytes'
    assert human_readable(10240, unit='k') == '10.0 kB'

# Generated at 2022-06-22 14:15:37.909833
# Unit test for function unique
def test_unique():
    '''
    Test the unique filter
    '''
    from ansible.plugins.filter.core import FilterModule
    from jinja2 import Environment

    fm = FilterModule()
    env = Environment()
    env.filters.update(fm.filters())

    assert env.from_string('{{ [1,2,1] | unique }}').render() == "[1, 2]"
    assert env.from_string('{{ [1,2,1] | unique(case_sensitive=true) }}').render() == "[1, 2]"
    assert env.from_string('{{ [1,2,1] | unique(case_sensitive=true, attribute=x) }}').render() == "[1, 2]"

# Generated at 2022-06-22 14:15:49.914003
# Unit test for function min
def test_min():
    display.display('test_min')
    assert min([1, 6, 20, 3, 4]) == 1
    assert min({'0': 1, '1': 5, '2': 20, '3': 3, '4': 4}) == 1
    assert min([{'test': 1}, {'test': 5}, {'test': 20}, {'test': 3}, {'test': 4}], attribute='test') == 3
    assert min([[1, 2], [1, 5], [1, 20], [1, 3], [1, 4]], attribute='1') == 2
    assert min([{'test': 1}, {'test': 5}, {'test': 20}, {'test': 3}, {'test': 4}], attribute='test', reverse=True) == 20

    # test [[]] cases

# Generated at 2022-06-22 14:15:52.996313
# Unit test for function max
def test_max():
    min_max = FilterModule().filters()
    assert min_max['max']([1, 2, 3]) == 3



# Generated at 2022-06-22 14:16:02.950365
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, 1.5) == math.pow(2, 1.5)
    assert power(2.1, 2) == math.pow(2.1, 2)
    assert power(2, 2) == 4

    try:
        power("abc", 1)
    except AnsibleFilterTypeError as e:
        assert "pow() can only be used on numbers:" in to_text(e)
    else:
        assert False, "pow() did not raise AnsibleFilterTypeError"



# Generated at 2022-06-22 14:16:04.310561
# Unit test for function max
def test_max():
    assert max([3, 9, 1, -12]) == 9


# Generated at 2022-06-22 14:16:14.142205
# Unit test for function min
def test_min():
    from ansible.tests.unit.compat import unittest
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    class TestMin(unittest.TestCase):
        def test_no_jinja_version(self):
            '''ensure that an error is raised if the jinja environment doesn't have a version'''
            env = {}
            with self.assertRaises(AnsibleFilterError):
                min(env, [])

        def test_jinja2_lt_2_10(self):
            '''ensure that an error is raised if the jinja2 environment's version is < 2.10'''
            env = {'jinja2.environment.Environment.version': '2.5'}

# Generated at 2022-06-22 14:16:17.861359
# Unit test for function unique
def test_unique():
    assert unique(list(range(4))*2, True) == [0, 1, 2, 3]
    assert unique(list(range(4))*2, False) == [0, 1, 2, 3]


# Generated at 2022-06-22 14:16:19.903165
# Unit test for function max
def test_max():
    assert max(list(range(100))) == 99
    assert max(list(range(100000))) == 99999


# Generated at 2022-06-22 14:16:21.343072
# Unit test for function max
def test_max():
    assert max([1,2,3,4,5]) == 5
    assert max([4,4,4,4,4]) == 4


# Generated at 2022-06-22 14:16:33.601339
# Unit test for function unique
def test_unique():
    env = {}
    dummy = None

    assert unique(env, [], case_sensitive=True, attribute=dummy) == []
    assert unique(env, [1], case_sensitive=True, attribute=dummy) == [1]
    assert unique(env, [1, 1], case_sensitive=True, attribute=dummy) == [1]
    assert unique(env, [1, 2, 3], case_sensitive=True, attribute=dummy) == [1, 2, 3]
    assert unique(env, [1, 2, 3, 1], case_sensitive=True, attribute=dummy) == [1, 2, 3]
    assert unique(env, [1, 2, 3, 2], case_sensitive=True, attribute=dummy) == [1, 2, 3]

# Generated at 2022-06-22 14:16:45.896518
# Unit test for function rekey_on_member
def test_rekey_on_member():
    filter = FilterModule()
    data = dict(a=dict(id=1, name="foo"), b=dict(id=2, name="bar"), c=dict(id="3", name="baz"))
    key = "id"
    assert filter.filters()['rekey_on_member'](data, key) == dict(a=dict(name="foo"), b=dict(name="bar"), c=dict(name="baz"))
    assert filter.filters()['rekey_on_member'](data, key, duplicates='overwrite') == dict(a=dict(name="foo"), b=dict(name="bar"), c=dict(name="baz"))

# Generated at 2022-06-22 14:16:53.298896
# Unit test for function max
def test_max():
    f = FilterModule().filters()

    # Max with Python builtin
    max1 = f['max']([1, 2, 3])
    max2 = f['max']('abc')
    assert max1 == 3
    assert max2 == 'c'

    # Max with Jinja2
    max1 = f['max']([1, 2, 3], attribute='real')
    max2 = f['max']([1, 2, 3], attribute='imag')
    assert max1 == 3
    assert max2 == 0


# Generated at 2022-06-22 14:17:07.301127
# Unit test for function max
def test_max():
    from ansible.module_utils.common.text import compat_strings

    assert max([1, 2, 3, 4]) == 4
    assert max([0.0, -1.1, -0.5, 1.5]) == 1.5
    assert max([0, -20, -10, 10]) == 10
    assert max([-5, -10, -5, -15]) == -5
    assert max([1, 2, 3, 'test']) == 3
    assert max([1, 2, 'a', u'test']) == 2
    assert max([compat_strings.String('1', encoding='utf-8'), 2, 'a', u'test']) == 2
    assert max([1, 2, 3, 4], 2) == 4

# Generated at 2022-06-22 14:17:13.798535
# Unit test for function max
def test_max():
    assert len(max([1, 2, 3, 4, 5])) == 1
    assert max([1, 2, 3, 4, 5]) == 5


# Generated at 2022-06-22 14:17:24.959675
# Unit test for function unique
def test_unique():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    host = inventory.get_host('foobar')
    play_source = dict(
        name='Mocked Play',
        hosts='foobar',
        gather_facts='no',
        tasks=[dict(action='debug', args=dict(msg='{{ _unique_test | unique }}'))]
    )

# Generated at 2022-06-22 14:17:35.004649
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([3, 2, 1]) == 3
    assert max([-1, -3, -2]) == -1
    assert max(1, 3, 2) == 3
    assert max(3, 2, 1) == 3


# Generated at 2022-06-22 14:17:42.858226
# Unit test for function rekey_on_member
def test_rekey_on_member():

    # Test that TypeError is raised when non-mapping is passed for data
    try:
        rekey_on_member([1, 2, 3], 'key')
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)
        assert "Type is not a valid" in to_native(e)

    # Test that TypeError is raised when non-mapping is passed in the list
    try:
        rekey_on_member([1, 2, 3], 'key')
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)
        assert "List item is not a valid dict" in to_native(e)

    # Test that KeyError is raised when key is not in any of the dicts

# Generated at 2022-06-22 14:17:47.257124
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(100, 10) == 10
    assert inversepower(100, 2) == 10
    assert inversepower(9, 2) == 3
    assert inversepower(3, 3) == 3
    assert inversepower(2, 3) == 1.2599210498948732

# Generated at 2022-06-22 14:17:55.813680
# Unit test for function max
def test_max():

    from ansible.module_utils import basic

    # initialize
    my_module = basic.AnsibleModule(argument_spec={})

    # Test to ensure that max can be used to find max value in a list
    list_one = [1, 2, 3, 10]
    assert 10 == my_module.from_json(my_module.to_json(max(list_one)))

    # Test to ensure that max can be used to find max value in a dict
    dict_one = {1: 'one', 2: 'two', 3: 'three'}
    assert 3 == my_module.from_json(my_module.to_json(max(dict_one)))

# Generated at 2022-06-22 14:17:59.144766
# Unit test for function max
def test_max():
    display.vvv('test_max')
    results = []
    for value in ['a', 'b', 'c', 'd']:
        result = max(['b', 'c', value])
        results.append(result)
    assert results == ['c', 'c', 'c', 'd']



# Generated at 2022-06-22 14:18:03.357575
# Unit test for function min
def test_min():
    assert min([1,2,3]) == 1
    assert min([1.0,2.0,3.0]) == 1.0
    assert min([-1.0,-2.0,-3.0]) == -3.0
    assert min([-1.0,2.0,-3.0]) == -3.0
    assert min([0,0,0]) == 0


# Generated at 2022-06-22 14:18:15.849866
# Unit test for function min
def test_min():
    from ansible.module_utils.six import PY3

    class T(object):
        def __init__(self, value):
            self.x = value

        def __lt__(self, other):
            return self.x < other.x

        if PY3:
            def __gt__(self, other):
                return self.x > other.x

    class X(object):
        def __init__(self, value):
            self.x = value

    class Y(X):
        def __lt__(self, other):
            return self.x < other.x

        if PY3:
            def __gt__(self, other):
                return self.x > other.x

    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=str) == 1

# Generated at 2022-06-22 14:18:28.477230
# Unit test for function human_readable
def test_human_readable():
    assert 10.0 == human_to_bytes('10')
    assert 0.0 == human_to_bytes('-0')
    assert 0.0 == human_to_bytes(0)
    assert 0.0 == human_to_bytes('-0b')
    assert 0.0 == human_to_bytes('-0B')
    assert 0.0 == human_to_bytes('0b')
    assert 0.0 == human_to_bytes('0B')
    assert 0.0 == human_to_bytes('-0  b')
    assert 0.0 == human_to_bytes('-0  B')
    assert 0.0 == human_to_bytes('0  b')
    assert 0.0 == human_to_bytes('0  B')
    assert 10.0 == human_to_bytes('10B')
   

# Generated at 2022-06-22 14:18:47.515522
# Unit test for function max
def test_max():
    x = [4, 1, 2, 3, 5]
    y = [1, 2, 3, 4, 5]
    assert max(x) == 5
    assert max(x, default=99) == 5
    assert max(y, default=99) == 5
    assert max(x, default=99, attribute="foo") == 4
    assert max(x, attribute="foo") == 4
    assert max(y, attribute="foo") == 5

# Generated at 2022-06-22 14:18:49.153841
# Unit test for function max
def test_max():
    assert max(range(10)) == 9



# Generated at 2022-06-22 14:18:59.052800
# Unit test for function human_readable
def test_human_readable():
    '''
    Tests for the function
    '''
    from ansible.module_utils.common.text import formatters

    result = human_readable(2)
    assert result == '2 B'

    result = human_readable(1024)
    assert result == '1 KB'

    result = human_readable(1048567)
    assert result == '1 MB'

    result = human_readable(1073741000)
    assert result == '1 GB'

    result = human_readable(10995116272)
    assert result == '1 TB'

    result = human_readable(2, isbits=True)
    assert result == '16 b'

    result = human_readable(1024, isbits=True)
    assert result == '8192 b'

    result = human_readable(1048567, isbits=True)


# Generated at 2022-06-22 14:19:10.982096
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(2) == "2.00 B"
    assert human_readable(2, unit='B') == "2.00 B"
    assert human_readable(1025) == "1.00 K"
    assert human_readable(1025, unit='K') == "1.00 K"
    assert human_readable(1000, unit='K') == "1000.00 B"
    assert human_readable(1000) == "1000.00 B"
    assert human_readable(1000, unit='') == "1000.00 "
    assert human_readable(2**10 - 1) == "1023.00 B"
    assert human_readable((2**10 - 1)*2**10) == "1048575.00 K"
    assert human_readable(2**10*2**10) == "1048576.00 K"

# Generated at 2022-06-22 14:19:15.480681
# Unit test for function min
def test_min():
    assert 3 == min([10, 3, 1, 8])
    assert -2.2 == min([3, 7.3, -2.2, 9.7])
    assert -4.5 == min([-4.5, -2])


# Generated at 2022-06-22 14:19:16.434757
# Unit test for function min
def test_min():
    assert min(range(4), 4) == 0

# Generated at 2022-06-22 14:19:18.952713
# Unit test for function max
def test_max():
    my_list = [0, 5, 7, 3, 6, 2, 7]
    assert max(my_list) == 7

# Generated at 2022-06-22 14:19:31.689823
# Unit test for function max
def test_max():
    # To maintain compatibility with the Jinja2 filter, max returns the first argument in case the second argument is not an iterable
    assert FilterModule().filters()['max']([5, 1, 2, 4, 3], 4) == 4
    assert FilterModule().filters()['max']([5, 1, 2, 4, 3], [4]) == 4
    assert FilterModule().filters()['max']([5, 1, 2, 4, 3], [[4]]) == 4
    assert FilterModule().filters()['max']([[5, 1, 2, 4, 3], [4]]) == [5, 1, 2, 4, 3]
    assert FilterModule().filters()['max']([5, 1, 2, 4, 3], [[4]]) == 4

# Generated at 2022-06-22 14:19:43.733879
# Unit test for function max
def test_max():
    from ansible.parsing.yaml.objects import AnsibleSequence
    assert max(AnsibleSequence([1, 2, 3])) == 3
    assert max(AnsibleSequence([-1, -2, -3])) == -1
    assert max(AnsibleSequence(['a', 'b', 'c'])) == 'c'
    assert max(AnsibleSequence([{'a': 1, 'b': 2},
                                {'a': 3, 'b': 2},
                                {'a': 2, 'b': 2}]),
               key='a')['a'] == 3

# Generated at 2022-06-22 14:19:57.051952
# Unit test for function human_readable
def test_human_readable():
    # Based on the tests in jinja2.filters (Ansible: 891e5e9)
    from ansible.module_utils.six import BytesIO

    output = human_readable(12345)
    assert output == '12.1K'

    output = human_readable(1234)
    assert output == '1.2K'

    output = human_readable(123)
    assert output == '123'

    output = human_readable(1234, unit='m')
    assert output == '1.2m'

    output = human_readable(1234, unit='m', isbits=True)
    assert output == '10.0m'

    output = human_readable(1234, unit='K')
    assert output == '1.2K'


# Generated at 2022-06-22 14:20:11.719167
# Unit test for function min
def test_min():
    assert min([42, 2, 3]) == 2, "test_min() failed"



# Generated at 2022-06-22 14:20:21.549453
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Create test data
    data = [{
        "foo": 1,
        "bar": {
            "baz": "foobar",
            "quux": "quuxbar"
        }
    }, {
        "foo": 4,
        "bar": {
            "baz": "foofoo",
            "quux": "quuxfoo"
        }
    }]

    # Test rekey_on_member with bad duplicates value
    for duplicates in ['bad_value', '', 1]:
        try:
            rekey_on_member(data, "foo", duplicates=duplicates)
        except Exception as e:
            assert("duplicates parameter to rekey_on_member has unknown value" in str(e))
            pass

    # Test rekey_on_member with good duplicates value


# Generated at 2022-06-22 14:20:34.010051
# Unit test for function min
def test_min():

    # Test the default case when it is called without any parameters.
    assert min([1, 2, 3, 4]) == 1
    assert min([4, 3, 2, 1]) == 1

    # Test the case when it is called with as an environment filter.
    class Environment(object):
        pass

    env = Environment()
    env.filters = {'min': min}

    assert env.filters['min']([1, 2, 3, 4]) == 1
    assert env.filters['min']([4, 3, 2, 1]) == 1

    # Test the case when it is called with a keyword argument supported by Jinja2 but not by Ansible's version.
    # It should raise an exception stating that the parameter is not supported.

    class Environment(object):
        pass

    env = Environment()

# Generated at 2022-06-22 14:20:44.551932
# Unit test for function min
def test_min():
    assert min(None, None) == None
    assert min([], None) == None
    assert min(None, []) == None
    assert min([1], [1]) == [1]
    assert min([1], [2]) == [1]
    assert min([2], [1]) == [1]
    assert min([1, 2], [1]) == [1]
    assert min([1, 2], [2]) == [1]
    # None as a value is always considered lesser than any other...
    assert min([1, 2], [None]) == [None]
    assert min([None], [1, 2]) == [None]
    # ...except another None
    assert min([None], [None]) == [None]
    assert min([None, 1, 2], [None]) == [None]

# Generated at 2022-06-22 14:20:48.323602
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2, "Simple max call"
    assert max([1, 2], [3, 4]) == [3, 4], "Simple max call with more than one list"



# Generated at 2022-06-22 14:21:01.155317
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # This test provides coverage for a variety of cases
    # including error handling, and cases where the key
    # being used is a list or string.
    #
    # To test the various error conditions, set the include_errors
    # variable to True, which will cause tests to be run that
    # will raise AnsibleFilterError, AnsibleFilterTypeError,
    # and ValueError.  The ValueError is raised in cases where
    # the dictionary being rekeyed has duplicate keys
    include_errors = False

    # Test using a dictionary with integer key values
    data = {
        1: {'a': 1, 'b': 2},
        2: {'a': 3, 'b': 4},
        3: {'a': 5, 'b': 6},
    }


# Generated at 2022-06-22 14:21:14.109727
# Unit test for function max
def test_max():

    min_filter_module = FilterModule()
    test_pass = True

    # List
    test_value = [11, 12, 13, 14, 15, 16, 17]
    test_res = min_filter_module.filters()['max'](test_value)
    if test_res != 17:
        test_pass = False
        display.error("Failed dict max test. Result: '%s'  Expected: '%s'" % (test_res, 17))

    # Dict
    test_value = {'a': 0, 'b': 1, 'c': 2, 'd': 3}
    test_res = min_filter_module.filters()['max'](test_value)
    if test_res != 'd':
        test_pass = False

# Generated at 2022-06-22 14:21:21.949576
# Unit test for function min
def test_min():
    # Test valid input
    assert min([5,0,3]) == 0
    assert min([2.1, 4.1, -5.5, 20.5]) == -5.5
    assert min([3,3,3,3]) == 3
    assert min(['a', 'b', 'c', 'd']) == 'a'
    assert min((5,0,3)) == 0
    assert min(2.1, 4.1, -5.5, 20.5) == -5.5
    assert min(3,3,3,3) == 3
    assert min('a', 'b', 'c', 'd') == 'a'
    # Test invalid input
    # First test None

# Generated at 2022-06-22 14:21:33.714655
# Unit test for function max
def test_max():
    expected = 10
    assert max([1, 5, 10, 8]) == expected, "Max of [1,5,10,8] not %d" % expected
    assert max([1.1, 5.5, 10.1, 8.8]) == expected, "Max of [1.1,5.5,10.1,8.8] not %d" % expected
    assert max([1, 5, 10, 8], key=str) == expected, "Max of [1,5,10,8] with str key not %d" % expected
    assert max([1, 5, 10, 8], key=int) == expected, "Max of [1,5,10,8] with int key not %d" % expected



# Generated at 2022-06-22 14:21:47.140449
# Unit test for function unique
def test_unique():
    def check(a, b, case_sensitive=None, attribute=None):
        env = {}
        c = unique(env, a, case_sensitive=case_sensitive, attribute=attribute)
        if c != b:
            raise Exception("failed to filter "
                            "unique(%s, case_sensitive=%s, attribute=%s) => %s  (should be %s)" % (
                                a, case_sensitive, attribute, c, b))
