

# Generated at 2022-06-22 14:12:11.308556
# Unit test for function max
def test_max():
    assert 1 == max(1, 0, 3, -2)
    assert 'z' == max('abc', 'z')
    assert 1 == max([1, 0, 3, -2])
    assert [1, 2, 3] == max([1, 2], [1, 2, 3])

    min_max_filters = FilterModule()
    assert 1 == min_max_filters.filters()['max'](1, 0, 3, -2)
    assert 'z' == min_max_filters.filters()['max']('abc', 'z')
    assert 1 == min_max_filters.filters()['max']([1, 0, 3, -2])

# Generated at 2022-06-22 14:12:23.449273
# Unit test for function unique
def test_unique():
    display.vvv(u"Testing unique jinja filter")
    data = [1, 2, 1, 2, 3]
    assert unique(None, data, False) == [1, 2, 3]
    assert unique(None, data, True) == [1, 2, 3]
    assert unique(None, data, None) == [1, 2, 3]

    data = ['1', '2', '1', '2', '3']
    assert unique(None, data, False) == ['1', '2', '3']
    assert unique(None, data, True) == ['1', '2', '3']
    assert unique(None, data, None) == ['1', '2', '3']

    data = [1, 2, 1, 2, '3']

# Generated at 2022-06-22 14:12:29.424464
# Unit test for function inversepower
def test_inversepower():
    import pytest
    from ansible.utils import plugin_docs

    assert inversepower(49, 7) == pytest.approx(2)
    assert inversepower(2, 2) == pytest.approx(math.sqrt(2))
    assert inversepower(49) == pytest.approx(math.sqrt(49))
    assert inversepower(49, 2) == pytest.approx(7)
    assert inversepower(8, 3) == pytest.approx(2)

    with pytest.raises(AnsibleFilterTypeError, match=r"root\(\) can only be used on numbers"):
        inversepower(b'foo', 2)


# Generated at 2022-06-22 14:12:33.029588
# Unit test for function min
def test_min():
    min_test = min([1, 2, 3])
    if min_test == 1:
        return True
    else:
        return False


# Generated at 2022-06-22 14:12:42.932691
# Unit test for function human_to_bytes

# Generated at 2022-06-22 14:12:50.292240
# Unit test for function inversepower
def test_inversepower():
    f = FilterModule()
    assert f.filters()['root'](4, base=2) == 4**(1/2)
    assert f.filters()['root'](9, base=2) == 9**(1/2)
    assert f.filters()['root'](9, base=3) == 9**(1/3)
    assert f.filters()['root'](125, base=5) == 5**(1/5)



# Generated at 2022-06-22 14:13:01.014073
# Unit test for function max
def test_max():
    test_val = [
        ([1,2,3], 3),
        ]
    for val, expected in test_val:
        assert(max(None, val) == expected)

    test_val = [
        ([-1,-2,-3], -1),
        ([-1,-2,0], 0),
        ]
    for val, expected in test_val:
        assert(max(None, val, val2=0) == expected)

    test_val = [
        ([-1,-2,-3], -3),
        ([-1,-2,0], -2),
        ]
    for val, expected in test_val:
        assert(max(None, val, val2=-2) == expected)


# Generated at 2022-06-22 14:13:13.084807
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Importing here because this is a filter, so this import won't work at the top
    from ansible.module_utils.common.text import to_text

    # Setup the arguments

# Generated at 2022-06-22 14:13:22.337591
# Unit test for function max
def test_max():
    from ansible.module_utils.common.text import format_size
    assert max([1, 2]) == 2
    assert max([1, 2], attr='size') == 2
    assert max(['foo', 'bar'], attr='size') == 'bar'
    assert max([1, 2.5]) == 2.5
    assert max(['1', '2', '3']) == '3'
    assert max(['1', '2', '3'], attr='size') == '3'
    assert max([], default='foo') == 'foo'
    assert max([], default='foo', attr='size') == 'foo'
    assert max([{'foo': 2}, {'bar': 3}], attr='foo') == {'bar': 3}

# Generated at 2022-06-22 14:13:32.235772
# Unit test for function min
def test_min():
    from ansible.module_utils.common.text import formatters
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters.get('min')([1, 2, 3]) == 1
    assert filters.get('min')([3, 2, 1]) == 1
    assert filters.get('min')([]) is None
    assert filters.get('min')([1, 2, 3], attribute='age') == 1
    assert filters.get('min')([{'age': 3}, {'age': 2}, {'age': 1}], attribute='age') == {'age': 1}
    assert filters.get('min')([{'age': 3}, {'age': 2}, {'age': 1}], attribute='a') == {'age': 3}

# Generated at 2022-06-22 14:13:41.077349
# Unit test for function max
def test_max():
    assert 2 == max([2, 1])
    assert 5 == max(2, 3, 5)
    assert 3 == max([2, 3, 1], first=True, key=abs)
    assert [1, 2] == max([[1, 0], [1, 2]], key=len)
    assert [3, 2] == max([[1, 0], [1, 2], [3, 2]], key=lambda tup: tup[1])
    assert [1, 2] == max([[1, 0], [1, 2]], first=True, key=len)
    assert [3, 2] == max([[1, 0], [3, 2], [1, 2]], first=True, key=len)

# Generated at 2022-06-22 14:13:43.798895
# Unit test for function max
def test_max():
    assert max([1, 2]) == 2

    assert max([1]) == 1

    assert max([1, 2, 3, 'x']) == 3


# Generated at 2022-06-22 14:13:51.788600
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [
        {'x': 1, 'y': 1, 'z': {1: 1}},
        {'x': 2, 'y': 2, 'z': {2: 2}},
        {'x': 3, 'y': 3, 'z': {3: 3}},
        {'x': 4, 'y': 4, 'z': {4: 4}},
    ]
    assert rekey_on_member(data, 'x') == {1: {'x': 1, 'y': 1, 'z': {1: 1}}, 2: {'x': 2, 'y': 2, 'z': {2: 2}}, 3: {'x': 3, 'y': 3, 'z': {3: 3}}, 4: {'x': 4, 'y': 4, 'z': {4: 4}}}

# Generated at 2022-06-22 14:13:52.477480
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, 5]) == 5



# Generated at 2022-06-22 14:13:55.939397
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 1]) == [1, 2]


# Generated at 2022-06-22 14:14:04.949792
# Unit test for function max
def test_max():

    import pytest


# Generated at 2022-06-22 14:14:14.760553
# Unit test for function max
def test_max():
    assert max([1]) == 1
    assert max([1, 2]) == 2
    assert max([2, 1]) == 2
    assert max([[1], [2]]) == [2]
    assert max([[1], [2]], attr='length') == [1]
    assert max([{1}, {2}], attr='issubset') == {2}
    assert max([{2}, {1}], attr='issubset') == {1}
    assert max([{1}, {2}], attr='issuperset') == {1}
    assert max([{1}, {2}], attr='union', unique=True) == {1, 2}
    assert max([{1}, {2}], attr='union', unique=False) == {1, 2}

# Generated at 2022-06-22 14:14:21.631629
# Unit test for function logarithm
def test_logarithm():
    value_pairs = [
        (2, 1),
        (0, 0),
        (math.e, 1),
        (10, 2)
    ]

    for value, expected in value_pairs:
        display.debug("Testing logarithm function for value: %s" % value)
        result = logarithm(value)
        assert result == expected

        # test with base 10
        display.debug("Testing logarithm function for value (base 10): %s" % value)
        result = logarithm(value, 10)
        assert result == expected


# Generated at 2022-06-22 14:14:32.687136
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import pytest
    from ansible.errors import AnsibleFilterError
    from ansible.module_utils._text import to_native
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    # AnsibleFilterError should be raised if key is not found in any member of data
    # ValueError: not enough values to unpack (expected 2, got 1)
    with pytest.raises(AnsibleFilterError) as exc:
        rekey_on_member([{'foo': 0, 'bar': 1}, {'foo': 2, 'bar': 3}], 'baz')
    assert to_native(exc.value) == "Key baz was not found"

    # If a key is not found in a member of data, it will not be in the


# Generated at 2022-06-22 14:14:41.355830
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from . import TestJinjaFilters

    fixture_path = 'tests/fixtures/filter_plugins/rekey_on_member.json'
    fixtures = TestJinjaFilters.read_fixtures(fixture_path)

    for fixture, test_data in fixtures.items():
        if test_data['failed'] is True:
            # Tests that expect to fail
            with pytest.raises(AnsibleFilterError):
                rekey_on_member(data=test_data['data'], key=test_data['key'], duplicates=test_data['duplicates'])
        else:
            assert rekey_on_member(data=test_data['data'], key=test_data['key'], duplicates=test_data['duplicates']) == test_data['expected_result']

# Generated at 2022-06-22 14:14:56.433188
# Unit test for function logarithm
def test_logarithm():
    # Test with two params, base is math.e
    assert math.log(2) == logarithm(2)

    # Test with two params, base = 10
    assert math.log10(2) == logarithm(2, 10)

    # Test with one param
    try:
        logarithm(2, base=math.e)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, 'Expected exception not raised.'


# Generated at 2022-06-22 14:15:08.920395
# Unit test for function unique
def test_unique():
    """ Test unique filter """
    from jinja2 import Environment

    env = Environment()
    env.filters['unique'] = unique
    env.filters['intersect'] = intersect
    env.filters['union'] = union
    env.filters['difference'] = difference
    env.filters['symmetric_difference'] = symmetric_difference
    env.filters['min'] = min
    env.filters['max'] = max


# Generated at 2022-06-22 14:15:15.526141
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max((1, 2, -1)) == 2
    assert max({1: "a", 2: "b", 3: "c"}) == 3
    assert max({1: "abc", 2: "bbb", 3: "c"}) == 2
    assert max((1, 2, 3), 2) == 3
    assert max((1, 2, 3), -2) == 3

# Generated at 2022-06-22 14:15:26.071530
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test single rekey
    obj = {
        'foo': {
            'key': 'value',
            'key2': 'value2',
        },
        'bar': {
            'key': 'value3',
            'key2': 'value4',
        },
    }
    new_obj = rekey_on_member(obj, 'key', duplicates='overwrite')
    assert new_obj['value'] == {'key': 'value', 'key2': 'value2'}
    assert new_obj['value3'] == {'key': 'value3', 'key2': 'value4'}

    # Ensure no exceptions are raised if duplicates is set to 'overwrite'

# Generated at 2022-06-22 14:15:38.775150
# Unit test for function min
def test_min():
    # Test for different input types
    assert min([4, -4]) == -4
    assert min([[4], [-4]]) == -4
    assert min([{'alpha': 9}, {'omega': 2}]) == {'omega': 2}
    assert min([9, 7, 2, 3]) == 2
    assert min([9, 7, 2, 3], key=lambda x: -x) == 9

    # Test for invalid input type
    try:
        min(4)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, 'AnsibleFilterTypeError not raised.'

    # Test for undefined variables
    try:
        min(data)
    except jinja2.exceptions.UndefinedError:
        pass

# Generated at 2022-06-22 14:15:45.504144
# Unit test for function min
def test_min():
    # test with valid data
    data = [2, 1, 3]
    assert min(data) == 1

    # test with invalid data
    data = [2, 'a', 3]
    try:
        assert min(data)
    except AnsibleFilterError:
        pass
    else:
        assert False, 'Expected AnsibleFilterError'


# Generated at 2022-06-22 14:15:55.240031
# Unit test for function max
def test_max():
    assert 5 == max([5, 4, 3, 1])
    assert 5 == max((5, 4, 3, 1))
    assert 5 == max({5, 4, 3, 1})
    assert 5 == max((x for x in [5, 4, 3, 1]))
    assert 5 == max([x for x in [5, 4, 3, 1]])
    assert 5 == max('5431')
    assert 5 == max({'a': 5, 'b': 4, 'c': 3, 'd': 1})
    assert 'd' == max({'a': 5, 'b': 4, 'c': 3, 'd': 1}, key=lambda x: x[0])
    assert 'd' == max({'a': 5, 'b': 4, 'c': 3, 'd': 1}, key=lambda x: x[1])

# Generated at 2022-06-22 14:15:57.285590
# Unit test for function max
def test_max():
    assert 2 == max([2, 1, 2, 3])
    assert 3 == max([2, 1, 0, 3], key=lambda x: -x)


# Generated at 2022-06-22 14:16:04.622805
# Unit test for function min
def test_min():
    # basic function
    assert min(a=[1, 2, 3, 4]) == 1

    # using Jinja2's min filter w/ keyword parameter, ensure we raise an exception as we don't support that
    try:
        min(a=[1, 2, 3, 4], test='wrong')
    except AnsibleFilterError:
        pass
    else:
        assert False

    # single item lists
    assert min(a=[1]) == 1

    # multiple args (not supported by Jinja2's min filter)
    assert min(a=[1, 2], b=[3, 4]) == 1

    # string args
    assert min(a=['a', 'b', 'c']) == 'a'
    assert min(a=['a']) == 'a'

# Generated at 2022-06-22 14:16:14.345260
# Unit test for function min
def test_min():
    def t(m, a, e):
        if m(a) != e:
            print("ERROR: expected %s, got %s" % (e, m(a)))

    t(min, '', '')
    t(min, [], None)
    t(min, [1], 1)
    t(min, 'ab', 'a')
    t(min, [1, 2, 3], 1)
    t(min, (1, 2, 3), 1)
    t(min, {'a': 1, 'b': 2, 'key': 3}, {'a': 1, 'b': 2, 'key': 3})
    t(min, 'abc', 'a')
    t(min, ['a', 'b', 'c'], 'a')

# Generated at 2022-06-22 14:16:19.219291
# Unit test for function max
def test_max():
    assert max([0, -1, 3, -3]) == 3


# Generated at 2022-06-22 14:16:31.641994
# Unit test for function max
def test_max():

    assert 15.1 == max([10.0, 15.1, 12.0, 11.2])
    assert 15.1 == max([10.0, 15.1, 12.0, 11.2], 5.1)
    assert 5.1 == max([])
    assert None == max(None)
    assert 2 == max(2)
    assert "xyzzy" == max("xyzzy")
    assert "xyzzy" == max({'a': 1, 'b': 'xyzzy', 'c': 2})
    assert "xyzzy" == max({'a': 1, 'b': 'xyzzy', 'c': 2}, 'abc')
    assert "xyzzy" == max({'a': 1, 'b': 'xyzzy', 'c': 2}, key='b')

# Generated at 2022-06-22 14:16:44.229015
# Unit test for function rekey_on_member

# Generated at 2022-06-22 14:16:55.396445
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1.1kb') == 1126
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1kb') == 1024
    assert human_to_bytes('1kib') == 1024
    assert human_to_bytes('1kB') == 1000
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1mb') == 1048576
    assert human_to_bytes('1mib') == 1048576
    assert human_to_bytes('1mB') == 1000000
    assert human_to_bytes('1MB') == 1000000
    assert human_to_bytes('1g') == 1073741824


# Generated at 2022-06-22 14:17:07.833702
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert(human_to_bytes('1') == 1)
    assert(human_to_bytes('1b') == 1)
    assert(human_to_bytes('1kb') == 1000)
    assert(human_to_bytes('1mb') == 1000000)
    assert(human_to_bytes('1gb') == 1000000000)
    assert(human_to_bytes('1tb') == 1000000000000)
    assert(human_to_bytes('1K') == 1024)
    assert(human_to_bytes('1M') == 1024**2)
    assert(human_to_bytes('1G') == 1024**3)
    assert(human_to_bytes('1T') == 1024**4)
    assert(human_to_bytes('1PB') == 1024**5)

# Generated at 2022-06-22 14:17:20.356813
# Unit test for function unique
def test_unique():
    from jinja2 import Template
    import pytest


# Generated at 2022-06-22 14:17:31.582778
# Unit test for function human_readable
def test_human_readable():
    from ansible.compat.tests import unittest

    class TestHumanReadable(unittest.TestCase):

        def test_bytes(self):
            self.assertEqual(human_readable(0), '0 B')
            self.assertEqual(human_readable(1), '1 B')
            self.assertEqual(human_readable(10), '10 B')
            self.assertEqual(human_readable(100), '100 B')
            self.assertEqual(human_readable(999), '999 B')
            self.assertEqual(human_readable(1024), '1.00 kB')
            self.assertEqual(human_readable(1024 * 1024), '1.00 MB')
            self.assertEqual(human_readable(1024 * 1024 * 1024), '1.00 GB')

# Generated at 2022-06-22 14:17:35.963599
# Unit test for function min
def test_min():
    assert min([1, 7, 3]) == 1
    assert min([1, 7, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 7}, {'foo': 3}], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 7}, {'foo': 3}], attribute='bar') == 1


# Generated at 2022-06-22 14:17:43.695144
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(10) == '10'
    assert human_readable(100) == '100'
    assert human_readable(1000) == '1.0K'
    assert human_readable(10000) == '9.8K'
    assert human_readable(100000) == '97.7K'
    assert human_readable(1000000) == '977K'
    assert human_readable(10000000) == '9.5M'
    assert human_readable(100000000) == '95.4M'
    assert human_readable(1000000000) == '953M'
    assert human_readable(10000000000) == '9.3G'

# Generated at 2022-06-22 14:17:54.292435
# Unit test for function max
def test_max():
    from ansible.module_utils import basic
    import ansible.plugins.filter.math

    assert ansible.plugins.filter.math.max([2, 3, 4]) == 4

    # Tests for case we must fall back to Ansible's max filter as Jinja2's is missing
    assert ansible.plugins.filter.math.max([2, 3, 4], key=basic.to_text) == 4
    assert ansible.plugins.filter.math.max([2, 3, 4], default=42) == 4
    assert ansible.plugins.filter.math.max([], default=42) == 42
    assert ansible.plugins.filter.math.max([], key=basic.to_text, default=42) == 42
    assert ansible.plugins.filter.math.max({}) == None

# Generated at 2022-06-22 14:18:17.632049
# Unit test for function max

# Generated at 2022-06-22 14:18:29.492857
# Unit test for function max
def test_max():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], default='fail') == 3
    assert max([], default='fail') == 'fail'
    assert max([], default=object()) == object()
    assert max([], default=None) is None
    assert max([], default=[]) == []
    assert max([], default=1) == 1
    assert max([], default=1.0) == 1.0
    assert max([], default=True) is True
    assert max([], default=False) is False
    assert max([], default='')

# Generated at 2022-06-22 14:18:37.582012
# Unit test for function max
def test_max():
    assert max([1, 2, 3, 4, 5]) == 5
    assert max([1, 5, 3, 4, 2]) == 5
    assert max([5, 1, 2, 3, 4]) == 5
    assert max([5, 1, 2, 4, 3]) == 5
    assert max([1, 2, 4, 3, 5]) == 5
    assert max([1, 5, 3, 2, 4]) == 5
    assert max([1, 5, 2, 4, 3]) == 5
    assert max([5, 4, 3, 2, 1]) == 5



# Generated at 2022-06-22 14:18:45.163620
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # define the inputs
    data = [
        {'name': 'theba', 'full_name': 'theba-1/0/10'},
        {'name': 'thebb', 'full_name': 'thebb-1/0/20'},
        {'name': 'thebc', 'full_name': 'thebc-1/0/30'},
    ]
    key = 'name'
    # run the function
    out = rekey_on_member(data, key, duplicates='error')
    assert type(data) is list
    assert type(out) is dict
    # and check the output
    assert out['theba']['name'] == 'theba'
    assert out['thebb']['name'] == 'thebb'

# Generated at 2022-06-22 14:18:56.175694
# Unit test for function max
def test_max():

    # Testing for list of strings
    # This should raise an error saying no keyword arguments are supported
    # with ansible_max if jinja2 has a new enough version to support keywords
    if HAS_MIN_MAX:
        try:
            a = ['a', 'b', 'c']
            y = max(a, reverse=True)
        except:
            y = 'c'
    else:
        y = 'c'

    assert y == 'c'

    # Testing for list of integers
    # This should raise an error saying no keyword arguments are supported
    # with ansible_max if jinja2 has a new enough version to support keywords
    if HAS_MIN_MAX:
        try:
            b = [1, 2, 30]
            z = max(b, reverse=True)
        except:
            z = 30


# Generated at 2022-06-22 14:18:59.144947
# Unit test for function min
def test_min():
    '''
    Test the Ansible min filter.
    '''
    assert min([1, 2, 3, 4]) == 1, 'should be equal'



# Generated at 2022-06-22 14:19:11.052522
# Unit test for function unique
def test_unique():

    try:
        from jinja2.filters import do_unique
        HAS_UNIQUE = True
    except ImportError:
        HAS_UNIQUE = False

    class DummyEnvironment(object):
        """Just need a class with a module attribute to pass as env to do_unique"""
        module = type('module', (object,), {})

    def _test_values(values, case_sensitive, expected_result):

        # test that both filter and jinja2's builtin work on a list
        assert expected_result == unique(None, values, case_sensitive)
        assert expected_result == do_unique(DummyEnvironment(), values, case_sensitive, None)

        # test that both filter and jinja2's builtin work on a set
        assert expected_result == unique(None, set(values), case_sensitive)

# Generated at 2022-06-22 14:19:21.116557
# Unit test for function min
def test_min():
    assert -1 == min([1, -5, -1, 3])
    assert -5 == min([-5, 1, -1, 3])
    assert -10 == min(1, -5, -10, 3)
    assert 'a' == min('b', 'a')
    assert 'a' == min(['b', 'a'])
    assert 'a' == min({'b': 1, 'a': 2})
    assert 'a' == min(iter(['b', 'a']))  # Python 3.x
    assert 'a' == min(iter(('b', 'a')))  # Python 3.x
    assert 1 == min(1)
    assert 1 == min([1])
    assert 1 == min({1: 2})
    assert 1 == min(range(0, 10, 3))

    # Test type

# Generated at 2022-06-22 14:19:22.727152
# Unit test for function min
def test_min():
    assert min([1,3,2]) == 1


# Generated at 2022-06-22 14:19:34.624517
# Unit test for function max
def test_max():
    import ansible.plugins.filter.mathstuff
    the_filter = ansible.plugins.filter.mathstuff.FilterModule().filters()
    assert the_filter['max']([1, 2, 3]) == 3
    assert the_filter['max']([1, '2', 3]) == 3
    assert the_filter['max']([3, 1, 2, 3]) == 3
    assert the_filter['max']([1, '2', '3']) == '3'
    assert the_filter['max'](["a", "b", "c"]) == "c"
    assert the_filter['max'](["a", "B", "c"]) == "c"
    assert the_filter['max'](["a", "B", "c"], key=str.lower) == "a"
    assert the_filter

# Generated at 2022-06-22 14:20:00.937848
# Unit test for function rekey_on_member
def test_rekey_on_member():
    def assert_raises(expected_exception, expected_message, function, *args, **kwargs):
        try:
            function(*args, **kwargs)
        except expected_exception as e:
            if to_native(e) != expected_message:
                raise AssertionError(u"{0}({1!r}, {2!r}) raised {3}({4!r}) instead of expected {3}({5!r})".format(
                    function.__name__, *args, **kwargs
                ))
        else:
            raise AssertionError(u"{0}({1!r}, {2!r}) did not raise {3}".format(
                function.__name__, *args, **kwargs
            ))


# Generated at 2022-06-22 14:20:13.686546
# Unit test for function min
def test_min():
    from ansible.template.safe_eval import safe_eval

    args = [
        42, 42, 42,
        ['a', 'b', 'c'],
        ['a', 'b', 'c', 'd'],
        ['a', 'b', 'c', 'd', 'e'],
        ['b', 'c', 'd', 'e'],
        ['a', 'b'],
        ['b', 'c'],
        ['c', 'd', 'e'],
    ]

    expecteds = [
        42, 42, 42,
        ['a'],
        ['a', 'b'],
        ['a', 'b', 'c'],
        ['b'],
        ['a'],
        ['b'],
        ['c'],
    ]


# Generated at 2022-06-22 14:20:19.851401
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [1, 3, 2]) == [1, 3, 2]
    assert max([1, 2, 3], [1, 3, 2], [1, 2, 4]) == [1, 3, 4]
    assert max([1, 2, 3], [1, 3, 2], [1, 2, 4], [1, 2, 3]) == [1, 3, 4]

# Generated at 2022-06-22 14:20:23.148259
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1]) == 1
    assert max([]) is None
    assert max([1, 2, "ab"]) == 2


# Generated at 2022-06-22 14:20:35.231449
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    # Prerequisites

    # Success cases
    # dict of dicts
    data = {'a':{'data':'a', 'key':'a'},
            'b':{'data':'b', 'key':'b'},
            'c':{'data':'c', 'key':'c'},
            }
    key = 'key'
    try:
        result = rekey_on_member(data, key, 'error')
    except Exception as e:
        assert False, 'rekey_on_member(data,key,"error") failed with exception: ' + to_native(e)

# Generated at 2022-06-22 14:20:38.167438
# Unit test for function min
def test_min():
    assert min([2, 4, 6, 8]) == 2
    assert min([2, 4, 6, 8], 1) == 1
    assert min([2, 4, 6, 8], 1, 2) == 1
    assert min([2, 4, 6, 8], 1, 2, 5) == 1
    assert min([2, 4, 6, 8], 1, 2, 5, 10) == 1
    assert min([2, 4, 6, 8], 1, 2, 5, 10, 100) == 1


# Generated at 2022-06-22 14:20:46.281597
# Unit test for function min
def test_min():
    assert min([1,2,4,6,8,2,1,6,9]) == 1
    assert min(1,2,4,6,8,2,1,6,9) == 1
    assert min(range(3,-3,-1)) == -2
    assert min("") is None
    assert min("abbccc") == "a"
    assert min("abbccc", key=str.upper) == "a"
    assert min("abcba", key=str.upper, reverse=True) == "a"
    assert min([1,2,4,6,8,2,1,6,9], key=lambda x: x % 2 == 0) == 1
    assert min(range(3,-3,-1), key=lambda x: x % 2 == 0) == -2

# Generated at 2022-06-22 14:20:54.415445
# Unit test for function rekey_on_member
def test_rekey_on_member():
    class TestItem(object):

        def __init__(self, attr):
            self.data = attr

    from ansible.module_utils.common.text import to_native
    from ansible.module_utils._text import to_text

    # pylint: disable=too-many-locals
    def test(data, key, out, errmsg=None, duplicates=None):

        if out is None:
            out = {}

        f = FilterModule()

        args = [data, key]
        kwargs = {}
        if duplicates:
            kwargs['duplicates'] = duplicates

        x = f.filters()['rekey_on_member'](*args, **kwargs)


# Generated at 2022-06-22 14:21:01.859333
# Unit test for function max
def test_max():

    # Create the filter manager
    fm = FilterModule()
    filters = fm.filters()

    items = [1, 2, 3, 4]
    assert filters['max'](items) == 4

    items = ['a', 'bbb', 'ccc']
    assert filters['max'](items) == 'ccc'

    items = [[1], [1, 2, 3], [2]]
    assert filters['max'](items) == [1, 2, 3]

    items = [{'a': 1}, {'b': 2}, {'c': 3}]
    assert filters['max'](items) == {'c': 3}

    items = 'hello'
    assert filters['max'](items) == 'o'

    items = (1, 2, 3)
    assert filters['max'](items) == 3

# Generated at 2022-06-22 14:21:08.310898
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # data = dict of dicts
    data = {'ent1': {'id': 'ent1', 'data': 'dat1'},
            'ent2': {'id': 'ent2', 'data': 'dat2'},
            'ent3': {'id': 'ent3', 'data': 'dat3'},
            'ent4': {'id': 'ent4', 'data': 'dat4'}}

    # key = rekey_on_member
    key = 'id'

    # rekeyed_data = desired result

# Generated at 2022-06-22 14:21:35.155022
# Unit test for function rekey_on_member
def test_rekey_on_member():
    import jinja2

    # Test rekey of array
    data = [{'key': 'value1'}, {'key': 'value2'}]
    key = 'key'
    expect = {'value1': {'key': 'value1'}, 'value2': {'key': 'value2'}}
    result = rekey_on_member(data, key)
    assert expect == result

    # Test rekey of array with duplicate key
    data = [{'key': 'value1'}, {'key': 'value2'}, {'key': 'value2'}]
    expect = {'value1': {'key': 'value1'}, 'value2': {'key': 'value2'}}
    result = rekey_on_member(data, key)
    assert expect == result

    # Test rekey

# Generated at 2022-06-22 14:21:36.824539
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4, 5]) == 1


# Generated at 2022-06-22 14:21:49.421087
# Unit test for function unique
def test_unique():
    '''
    list: source list
    dups: how many times the duplicate element appears in the list
    case_sensitive: True/False, if case_sensitive is false, function should
                    return a lowercase string
    attribute: name of attribute to select from list object
    '''