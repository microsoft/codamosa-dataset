

# Generated at 2022-06-22 16:38:27.387928
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.collections import is_dictlike
    from ansible.module_utils.common.collections import is_hashable
    from ansible.module_utils.common.collections import is_collection

# Generated at 2022-06-22 16:38:37.273495
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test rekey_on_member with a dict
    data = {
        'a': {'name': 'a', 'value': 1},
        'b': {'name': 'b', 'value': 2},
        'c': {'name': 'c', 'value': 3},
    }
    assert rekey_on_member(data, 'name') == data

    # Test rekey_on_member with a list
    data = [
        {'name': 'a', 'value': 1},
        {'name': 'b', 'value': 2},
        {'name': 'c', 'value': 3},
    ]

# Generated at 2022-06-22 16:38:48.393016
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='bar') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=True) == 1
    assert min([1, 2, 3], case_sensitive=None) == 1
    assert min([1, 2, 3], case_sensitive=None, attribute='foo') == 1

# Generated at 2022-06-22 16:38:54.389387
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: -x) == 3
    assert min([1, 2, 3], key=lambda x: -x, default=0) == 3
    assert min([1, 2, 3], default=0) == 1
    assert min([], default=0) == 0
    assert min([], default=None) is None
    assert min([], key=lambda x: -x, default=None) is None
    assert min([], key=lambda x: -x, default=0) == 0
    assert min([1, 2, 3], key=lambda x: -x, default=None) == 3


# Generated at 2022-06-22 16:39:03.054208
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:14.855443
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:22.892810
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    import sys
    import pytest

    if PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    # Capture stderr
    old_stderr = sys.stderr
    sys.stderr = StringIO()

    # Test rekey_on_member
    test_data = [
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 4, 'b': 5, 'c': 6},
        {'a': 7, 'b': 8, 'c': 9},
    ]
    test_key = 'b'
   

# Generated at 2022-06-22 16:39:34.279543
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test rekey_on_member with a dict of dicts
    data = {
        'a': {'name': 'a', 'value': 1},
        'b': {'name': 'b', 'value': 2},
        'c': {'name': 'c', 'value': 3},
    }
    key = 'name'

# Generated at 2022-06-22 16:39:42.575535
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5], case_sensitive=False) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5], case_sensitive=True) == [1, 2, 3, 3, 4, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5], case_sensitive=None) == [1, 2, 3, 4, 5]

# Generated at 2022-06-22 16:39:54.536381
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    builtins = __import__(builtin_module_name)
    open_file = getattr(builtins, "open")

    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment variable
    tmp_env_var = 'ANSIBLE_FILTER_TEST_VAR'
    os.environ[tmp_env_var] = tmpdir

    # Create a temporary ansible.cfg
   

# Generated at 2022-06-22 16:40:10.892220
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:40:16.280616
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: -x) == 3
    assert min([1, 2, 3], key=lambda x: x) == 1
    assert min([1, 2, 3], key=lambda x: x, default=0) == 1
    assert min([], key=lambda x: x, default=0) == 0
    assert min([], default=0) == 0


# Generated at 2022-06-22 16:40:27.334159
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(1) == '1 B'
    assert human_readable(10) == '10 B'
    assert human_readable(100) == '100 B'
    assert human_readable(1000) == '1000 B'
    assert human_readable(10000) == '9.8 KB'
    assert human_readable(100000) == '97.7 KB'
    assert human_readable(1000000) == '976.6 KB'
    assert human_readable(10000000) == '9.5 MB'
    assert human_readable(100000000) == '95.4 MB'
    assert human_readable(1000000000) == '953.7 MB'
    assert human_readable(10000000000) == '9.3 GB'

# Generated at 2022-06-22 16:40:36.279322
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test rekey_on_member with a dict of dicts
    data = {
        'a': {'key': 'a', 'value': 'A'},
        'b': {'key': 'b', 'value': 'B'},
        'c': {'key': 'c', 'value': 'C'},
    }
    key = 'key'
    result = rekey_on_member(data, key)
    assert result == {'a': {'key': 'a', 'value': 'A'}, 'b': {'key': 'b', 'value': 'B'}, 'c': {'key': 'c', 'value': 'C'}}

    # Test rekey_on_member with a list of dicts

# Generated at 2022-06-22 16:40:47.039208
# Unit test for function rekey_on_member
def test_rekey_on_member():
    data = [
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 4, 'b': 5, 'c': 6},
        {'a': 7, 'b': 8, 'c': 9},
    ]

    # Test rekeying on a member that exists
    assert rekey_on_member(data, 'a') == {
        1: {'a': 1, 'b': 2, 'c': 3},
        4: {'a': 4, 'b': 5, 'c': 6},
        7: {'a': 7, 'b': 8, 'c': 9},
    }

    # Test rekeying on a member that doesn't exist
    try:
        rekey_on_member(data, 'd')
    except AnsibleFilterError as e:
        assert str

# Generated at 2022-06-22 16:40:59.611839
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(1) == '1 B'
    assert human_readable(2) == '2 B'
    assert human_readable(1024) == '1.0 KiB'
    assert human_readable(1024, unit='B') == '1.0 KB'
    assert human_readable(1024, unit='B', isbits=True) == '8.0 Kbit'
    assert human_readable(1024, unit='B', isbits=True, precision=2) == '8.00 Kbit'
    assert human_readable(1024, unit='B', isbits=True, precision=2, suffix='ps') == '8.00 Kbps'

# Generated at 2022-06-22 16:41:11.257727
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1) == 0
    assert logarithm(math.e) == 1
    assert logarithm(math.e, math.e) == 1
    assert logarithm(10, 10) == 1
    assert logarithm(100, 10) == 2
    assert logarithm(100, 2) == 6.643856189774724
    assert logarithm(100, math.e) == 4.605170185988091
    assert logarithm(100, 1) == 100
    assert logarithm(100, 0) == float("inf")
    assert logarithm(0, 10) == float("-inf")
    assert logarithm(0, 0) == float("-inf")
    assert logarithm(0, 1) == 0
   

# Generated at 2022-06-22 16:41:23.935991
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:41:31.257569
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=True) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=None) == {'foo': 1}

# Generated at 2022-06-22 16:41:39.406945
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:41:56.342092
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    if PY3:
        builtins_name = 'builtins'
    else:
        builtins_name = '__builtin__'
    builtins_module = __import__(builtins_name)
    builtins_dict = builtins_module.__dict__
    builtins_dict['rekey_on_member'] = rekey_on_member

    # Test rekey_on_member with a dict of dicts

# Generated at 2022-06-22 16:42:06.306028
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:14.995320
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([3, 3, 3]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([-1, -3, -2]) == -1
    assert max([-3, -2, -1]) == -1
    assert max([-3, -3, -3]) == -3
    assert max([1, -2, 3]) == 3
    assert max([1, -3, 2]) == 2
    assert max([3, -2, 1]) == 3
    assert max([3, -3, 3]) == 3
    assert max([-1, 2, -3]) == 2

# Generated at 2022-06-22 16:42:26.920212
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:39.193615
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, 2) == 2
    assert inversepower(9, 2) == 3
    assert inversepower(16, 2) == 4
    assert inversepower(25, 2) == 5
    assert inversepower(36, 2) == 6
    assert inversepower(49, 2) == 7
    assert inversepower(64, 2) == 8
    assert inversepower(81, 2) == 9
    assert inversepower(100, 2) == 10
    assert inversepower(121, 2) == 11
    assert inversepower(144, 2) == 12
    assert inversepower(169, 2) == 13
    assert inversepower(196, 2) == 14
    assert inversepower(225, 2) == 15
    assert inversepower(256, 2) == 16
    assert inversepower(289, 2) == 17

# Generated at 2022-06-22 16:42:52.288879
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:42:58.474780
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=False, attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], case_sensitive=False, attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=True) == 1
    assert min([1, 2, 3], case_sensitive=True, attribute='foo') == 1

# Generated at 2022-06-22 16:43:09.847263
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import print_
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    import sys
    import json

    # Test data

# Generated at 2022-06-22 16:43:20.481527
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []
    assert symmetric_difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], []) == [1, 2, 3]
    assert symmetric_difference([], [1, 2, 3]) == [1, 2, 3]
    assert symmetric_difference([], []) == []
    assert symmetric_difference([1, 2, 3], [3, 4, 5]) == [1, 2, 4, 5]

# Generated at 2022-06-22 16:43:32.019587
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2
    assert inversepower(8, 3) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(64, 4) == 4
    assert inversepower(64, 2) == 8
    assert inversepower(64, -2) == 0.125
    assert inversepower(64, -1) == 0.25
    assert inversepower(64, -0.5) == 0.5
    assert inversepower(64, 0.5) == 8
    assert inversepower(64, 0.25) == 4
    assert inversepower(64, 0.125) == 2
    assert inversepower(64, 0.0625) == 1.5
    assert inversepower(64, 0.03125) == 1.25
    assert inversepower(64, 0.015625) == 1.125


# Generated at 2022-06-22 16:43:47.276544
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4) == 2
    assert inversepower(4, 2) == 2
    assert inversepower(9, 3) == 2
    assert inversepower(8, 3) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(27, 3, 2) == 3
    assert inversepower(27, 3, 3) == 3
    assert inversepower(27, 3, 4) == 2
    assert inversepower(27, 3, 5) == 2
    assert inversepower(27, 3, 6) == 2
    assert inversepower(27, 3, 7) == 2
    assert inversepower(27, 3, 8) == 2
    assert inversepower(27, 3, 9) == 2
    assert inversepower(27, 3, 10) == 2
    assert inversepower(27, 3, 11) == 2
   

# Generated at 2022-06-22 16:44:00.529762
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:11.715196
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test with a dict of dicts
    data = {
        'a': {'key': 'a', 'value': 'A'},
        'b': {'key': 'b', 'value': 'B'},
        'c': {'key': 'c', 'value': 'C'},
    }
    assert rekey_on_member(data, 'key') == data

    # Test with a list of dicts
    data = [
        {'key': 'a', 'value': 'A'},
        {'key': 'b', 'value': 'B'},
        {'key': 'c', 'value': 'C'},
    ]

# Generated at 2022-06-22 16:44:21.875136
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:44:31.972022
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:45.402633
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:44:58.426953
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:45:11.485568
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_

# Generated at 2022-06-22 16:45:21.616517
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1b') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1t') == 1099511627776
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1p') == 1125899906842624

# Generated at 2022-06-22 16:45:33.806216
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='name') == 1
    assert min([1, 2, 3], attribute='name', default=0) == 1
    assert min([1, 2, 3], default=0) == 1
    assert min([1, 2, 3], attribute='name', default=0, missing=0) == 1
    assert min([1, 2, 3], attribute='name', default=0, missing=0) == 1
    assert min([1, 2, 3], attribute='name', default=0, missing=0) == 1
    assert min([1, 2, 3], attribute='name', default=0, missing=0) == 1
    assert min([1, 2, 3], attribute='name', default=0, missing=0) == 1

# Generated at 2022-06-22 16:45:49.240992
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=[0, 0, 0]) == [1, 2, 3]

# Generated at 2022-06-22 16:45:59.386816
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=str) == 3
    assert max([1, 3, 2], key=str) == 3
    assert max([3, 1, 2], key=str) == 3
    assert max([3, 2, 1], key=str) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1

# Generated at 2022-06-22 16:46:08.855142
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: max(x)) == [7, 8, 9]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: max(x), default=[0, 0, 0]) == [7, 8, 9]

# Generated at 2022-06-22 16:46:21.258787
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='name') == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=True) == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=None) == 1
    assert min([1, 2, 3], attribute='name', case_sensitive='') == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=0) == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=1) == 1
    assert min([1, 2, 3], attribute='name', case_sensitive=2) == 1

# Generated at 2022-06-22 16:46:33.515806
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:45.343157
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:58.158629
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:08.616221
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import cPickle as pickle

    # Test that rekey_on_member works on a dict of dicts
    data = {'a': {'b': 'c', 'd': 'e'}, 'f': {'g': 'h', 'i': 'j'}}
    assert rekey_on_member(data, 'b') == {'c': {'b': 'c', 'd': 'e'}}
    assert rekey_on_member(data, 'd') == {'e': {'b': 'c', 'd': 'e'}}

# Generated at 2022-06-22 16:47:15.838541
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=[10, 11, 12]) == [1, 2, 3]

# Generated at 2022-06-22 16:47:28.605077
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='bar') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='bar', default=42) == 42
    assert min([1, 2, 3], default=42) == 1
    assert min([], default=42) == 42
    assert min([1, 2, 3], default=42, foo='bar') == 1
    assert min([], default=42, foo='bar') == 42

# Generated at 2022-06-22 16:47:47.563393
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:59.392833
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=str) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max(1, 2, 3) == 3
    assert max(range(1, 10**6)) == 10**6 - 1
    assert max(1, 2, 3, default=0) == 3
    assert max([], default=0) == 0
    assert max([1, 2, 3], default=0) == 3
    assert max([], default=0, key=str) == 0