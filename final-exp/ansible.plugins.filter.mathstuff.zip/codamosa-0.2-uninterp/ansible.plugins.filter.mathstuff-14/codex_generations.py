

# Generated at 2022-06-22 16:38:34.444822
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1


# Generated at 2022-06-22 16:38:46.300175
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.0') == 1
    assert human_to_bytes('1.0k') == 1024
    assert human_to_bytes('1.0K') == 1024
    assert human_to_bytes('1.0kb') == 1024
    assert human_to_bytes('1.0Kb') == 1024
    assert human_to_bytes('1.0m') == 1048576
    assert human_to_bytes('1.0M') == 1048576
    assert human_to_bytes('1.0mb') == 1048576
    assert human_to_bytes('1.0Mb') == 1048576
    assert human_to_bytes('1.0g') == 1073741824

# Generated at 2022-06-22 16:38:53.841690
# Unit test for function inversepower
def test_inversepower():
    assert inversepower(4, 2) == 2
    assert inversepower(8, 3) == 2
    assert inversepower(27, 3) == 3
    assert inversepower(16, 4) == 2
    assert inversepower(16, 2) == 4
    assert inversepower(16) == 4
    assert inversepower(16, 1) == 16
    assert inversepower(16, 0) == 1
    assert inversepower(16, -1) == 0.0625
    assert inversepower(16, -2) == 0.00390625
    assert inversepower(16, -3) == 0.000244140625
    assert inversepower(16, -4) == 0.0000152587890625
    assert inversepower(16, -5) == 9.5367431640625e-7

# Generated at 2022-06-22 16:39:02.788014
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:39:12.726592
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:39:21.609608
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([1, 2, 3], attribute='foo', default=10) == 1
    assert min([1, 2, 3], default=10) == 1
    assert min([1, 2, 3], attribute='foo', default=10, skip_missing=True) == 1
    assert min([1, 2, 3], attribute='foo', default=10, skip_missing=False) == 1
    assert min([1, 2, 3], attribute='foo', default=10, skip_missing=False) == 1
    assert min([1, 2, 3], attribute='foo', default=10, skip_missing=True) == 1

# Generated at 2022-06-22 16:39:32.658302
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:41.471759
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:53.294248
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text import to_text

    if PY3:
        unicode = str

    # Test that rekey_on_member works on a dict of dicts
    test_dict = {
        'a': {'foo': 'bar', 'baz': 'qux'},
        'b': {'foo': 'quux', 'baz': 'quuz'},
    }
    assert rekey_on_member(test_dict, 'foo') == {
        'bar': {'foo': 'bar', 'baz': 'qux'},
        'quux': {'foo': 'quux', 'baz': 'quuz'},
    }

    #

# Generated at 2022-06-22 16:39:59.416504
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: x * -1) == 3
    assert min([1, 2, 3], key=lambda x: x * -1, default=0) == 3
    assert min([], key=lambda x: x * -1, default=0) == 0
    assert min([], key=lambda x: x * -1) == None


# Generated at 2022-06-22 16:40:10.594617
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3, 4], [3, 4, 5, 6]) == [1, 2, 5, 6]

# Generated at 2022-06-22 16:40:18.716733
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:40:28.811995
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:40:36.706294
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:40:47.968085
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:40:59.954985
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1G') == 1024**3
    assert human_to_bytes('1T') == 1024**4
    assert human_to_bytes('1P') == 1024**5
    assert human_to_bytes('1E') == 1024**6
    assert human_to_bytes('1Z') == 1024**7
    assert human_to_bytes('1Y') == 1024**8
    assert human_to_bytes('1KB') == 1000
    assert human_to_bytes('1MB') == 1000**2
    assert human_to_bytes('1GB') == 1000**3

# Generated at 2022-06-22 16:41:11.523417
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([-1, -3, -2]) == -1
    assert max([-3, -1, -2]) == -1
    assert max([-3, -2, -1]) == -1
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1

# Generated at 2022-06-22 16:41:23.984642
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:31.719415
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:39.638869
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:53.534941
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:42:04.580718
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=None) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='foo') == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False, attribute='foo') == [1, 2, 3]

# Generated at 2022-06-22 16:42:13.347263
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1KB') == 1024
    assert human_

# Generated at 2022-06-22 16:42:20.636902
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, -3) == 0.125
    assert power(2, 0) == 1
    assert power(0, 2) == 0
    assert power(0, 0) == 1
    assert power(1, 2) == 1
    assert power(1, 0) == 1
    assert power(-1, 2) == 1
    assert power(-1, 0) == 1
    assert power(-1, 1) == -1
    assert power(-1, -1) == -1
    assert power(-1, -2) == 1
    assert power(-2, 3) == -8
    assert power(-2, -3) == -0.125
    assert power(-2, 0) == 1
    assert power(-2, 1) == -2

# Generated at 2022-06-22 16:42:28.910008
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3, 4, 5], [1, 2, 3, 6, 7]) == [4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3, 4, 5], [1, 2, 3]) == [4, 5]
    assert symmetric_difference([1, 2, 3], [1, 2, 3, 4, 5]) == [4, 5]
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []
    assert symmetric_difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], []) == [1, 2, 3]

# Generated at 2022-06-22 16:42:40.090932
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:52.645213
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:43:00.610726
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import bytes_to_human

    # Test rekey_on_member with a dict
    data = {
        'a': {'name': 'a', 'value': 1},
        'b': {'name': 'b', 'value': 2},
        'c': {'name': 'c', 'value': 3},
    }

# Generated at 2022-06-22 16:43:13.366540
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []
    assert symmetric_difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [3, 4, 5]) == [1, 2, 4, 5]
    assert symmetric_difference([1, 2, 3], [1, 3, 4]) == [2, 4]
    assert symmetric_difference([1, 2, 3], [1, 2, 3, 4]) == [4]

# Generated at 2022-06-22 16:43:21.363251
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:43:34.694717
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='foo') == [1, 2, 3]

# Generated at 2022-06-22 16:43:47.053000
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([3, 3, 3]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([-1, -3, -2]) == -1
    assert max([-3, -2, -1]) == -1
    assert max([-3, -3, -3]) == -3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1

# Generated at 2022-06-22 16:44:00.329616
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys
    import unittest

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            self.test_dict = {
                'a': {'a': 'a', 'b': 'b'},
                'b': {'a': 'c', 'b': 'd'},
                'c': {'a': 'e', 'b': 'f'},
            }


# Generated at 2022-06-22 16:44:11.678367
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:24.283321
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=None) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='foo') == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False, attribute='foo') == [1, 2, 3]

# Generated at 2022-06-22 16:44:33.710611
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:46.302363
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1KB') == 1024
    assert human_

# Generated at 2022-06-22 16:44:58.559394
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test a dict of dicts
    data = {
        'a': {
            'key': 'a',
            'value': 1,
        },
        'b': {
            'key': 'b',
            'value': 2,
        },
        'c': {
            'key': 'c',
            'value': 3,
        },
    }
    assert rekey_on_member(data, 'key') == data

    # Test a list of dicts
    data = [
        {
            'key': 'a',
            'value': 1,
        },
        {
            'key': 'b',
            'value': 2,
        },
        {
            'key': 'c',
            'value': 3,
        },
    ]

# Generated at 2022-06-22 16:45:11.624628
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=0) == [1, 2, 3]

# Generated at 2022-06-22 16:45:21.847794
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='foo') == [1, 2, 3]

# Generated at 2022-06-22 16:45:35.101767
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=0) == [1, 2, 3]

# Generated at 2022-06-22 16:45:46.374403
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 3, 4, 5, 6, 7, 7, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert unique([1, 2, 3, 3, 4, 5, 6, 7, 7, 7, 8, 9, 10], case_sensitive=False) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert unique([1, 2, 3, 3, 4, 5, 6, 7, 7, 7, 8, 9, 10], case_sensitive=True) == [1, 2, 3, 3, 4, 5, 6, 7, 7, 7, 8, 9, 10]

# Generated at 2022-06-22 16:45:58.148607
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1Ki') == 1024
    assert human_to_

# Generated at 2022-06-22 16:46:08.297727
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 4, 4, 5]) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 4, 4, 5], case_sensitive=False) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 4, 4, 5], case_sensitive=True) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 4, 4, 5], case_sensitive=None) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 4, 4, 5], case_sensitive=None, attribute='foo') == [1, 2, 3, 4, 5]

# Generated at 2022-06-22 16:46:20.767016
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:46:33.119221
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:45.305764
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(10) == '10'
    assert human_readable(1023) == '1023'
    assert human_readable(1024) == '1.0K'
    assert human_readable(1025) == '1.0K'
    assert human_readable(1048575) == '1023.9K'
    assert human_readable(1048576) == '1.0M'
    assert human_readable(1048577) == '1.0M'
    assert human_readable(1073741823) == '1023.9M'
    assert human_readable(1073741824) == '1.0G'
    assert human_readable(1073741825) == '1.0G'

# Generated at 2022-06-22 16:46:58.106967
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 3, 2, 1]) == [1, 2, 3]
    assert unique([1, 1, 1, 1, 1, 1]) == [1]
    assert unique([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert unique([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert unique([1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-22 16:47:05.581037
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:14.142809
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(10) == '10'
    assert human_readable(1023) == '1023'
    assert human_readable(1024) == '1.0K'
    assert human_readable(1024 * 1024) == '1.0M'
    assert human_readable(1024 * 1024 * 1024) == '1.0G'
    assert human_readable(1024 * 1024 * 1024 * 1024) == '1.0T'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024) == '1.0P'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.0E'

# Generated at 2022-06-22 16:47:24.406216
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=True) == {'foo': 1}


# Generated at 2022-06-22 16:47:33.005835
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:47:43.536769
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:55.677307
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:48:06.834999
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([3, 3, 3]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1
    assert max([3, 3, 3], key=lambda x: -x) == 3
    assert max([1, 2, 3], key=lambda x: -x, default=0) == 1
    assert max([1, 3, 2], key=lambda x: -x, default=0) == 1

# Generated at 2022-06-22 16:48:15.530260
# Unit test for function max
def test_max():
    assert max(['a', 'b', 'c']) == 'c'
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 2, 3], key=lambda x: x) == 3
    assert max([1, 2, 3], key=lambda x: x, default=0) == 3
    assert max([], key=lambda x: x, default=0) == 0
    assert max([1, 2, 3], key=lambda x: x, default=0) == 3
    assert max([1, 2, 3], key=lambda x: x, default=0) == 3