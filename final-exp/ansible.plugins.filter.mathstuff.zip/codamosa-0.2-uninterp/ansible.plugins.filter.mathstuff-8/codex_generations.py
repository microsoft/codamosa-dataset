

# Generated at 2022-06-22 16:38:35.022451
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3

    # Test data
    data = [
        {'key1': 'value1', 'key2': 'value2'},
        {'key1': 'value3', 'key2': 'value4'},
        {'key1': 'value5', 'key2': 'value6'},
    ]

    # Test rekey_on_member
    rekey_on_member_filter = FilterModule().filters()['rekey_on_member']
    result = rekey_on_member_filter(data, 'key1')

    # Test result
    if PY3:
        assert isinstance(result, dict)
    else:
        assert isinstance(result, basic.AnsibleUnicode)
    assert result

# Generated at 2022-06-22 16:38:46.913985
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.plugins.filter.core import FilterModule

    display = Display()

    class TestRekeyOnMember(unittest.TestCase):
        def setUp(self):
            self.filter = FilterModule()

        def tearDown(self):
            pass


# Generated at 2022-06-22 16:38:54.177149
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:02.963147
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:39:14.762756
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10) == math.log(10)
    assert logarithm(10, 10) == math.log10(10)
    assert logarithm(10, 2) == math.log(10, 2)
    assert logarithm(10, math.e) == math.log(10)
    assert logarithm(10, math.pi) == math.log(10, math.pi)
    assert logarithm(10, 1) == math.log(10, 1)
    assert logarithm(10, 0) == math.log(10, 0)
    assert logarithm(10, -1) == math.log(10, -1)
    assert logarithm(10, -2) == math.log(10, -2)

# Generated at 2022-06-22 16:39:22.854700
# Unit test for function min
def test_min():
    assert min([1, 2, 3, 4]) == 1
    assert min([1, 2, 3, 4], attribute='foo') == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=False) == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=True) == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=None) == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=None) == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=None) == 1
    assert min([1, 2, 3, 4], attribute='foo', case_sensitive=None) == 1

# Generated at 2022-06-22 16:39:33.663508
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:42.177608
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:39:54.149547
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1G') == 1024**3
    assert human_to_bytes('1T') == 1024**4
    assert human_to_bytes('1P') == 1024**5
    assert human_to_bytes('1E') == 1024**6
    assert human_to_bytes('1Z') == 1024**7
    assert human_to_bytes('1Y') == 1024**8

    assert human_to_bytes('1Ki') == 1024
    assert human_to_bytes('1Mi') == 1024**2
    assert human_to_bytes('1Gi') == 1024**3
    assert human_to_bytes('1Ti') == 1024

# Generated at 2022-06-22 16:40:05.210434
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test rekey_on_member with a dict of dicts
    data = {
        'a': {'name': 'a', 'value': 1},
        'b': {'name': 'b', 'value': 2},
        'c': {'name': 'c', 'value': 3},
    }
    result = rekey_on_member(data, 'name')
    assert result == {
        'a': {'name': 'a', 'value': 1},
        'b': {'name': 'b', 'value': 2},
        'c': {'name': 'c', 'value': 3},
    }

    # Test rekey_on_member with a list of dicts

# Generated at 2022-06-22 16:40:19.044075
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=True) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=None) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=None, default=0) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=None, default=0, skip_missing=True) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=None, default=0, skip_missing=False) == 1

# Generated at 2022-06-22 16:40:30.549833
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:40:37.720826
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024**2
    assert human_to_bytes('1G') == 1024**3
    assert human_to_bytes('1T') == 1024**4
    assert human_to_bytes('1P') == 1024**5
    assert human_to_bytes('1E') == 1024**6
    assert human_to_bytes('1Z') == 1024**7
    assert human_to_bytes('1Y') == 1024**8
    assert human_to_bytes('1KB') == 1024
    assert human_to_bytes('1MB') == 1024**2
    assert human_to_bytes('1GB') == 1024**3


# Generated at 2022-06-22 16:40:49.471433
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []
    assert symmetric_difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [1, 2, 3, 4, 5, 6]) == [4, 5, 6]
    assert symmetric_difference([1, 2, 3, 4, 5, 6], [1, 2, 3]) == [4, 5, 6]
    assert symmetric_difference([1, 2, 3, 4, 5, 6], [4, 5, 6]) == [1, 2, 3]
    assert symm

# Generated at 2022-06-22 16:41:01.071027
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=[0, 0, 0]) == [1, 2, 3]

# Generated at 2022-06-22 16:41:12.325201
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1
    assert max([1, 2, 3], key=lambda x: x) == 3
    assert max([1, 3, 2], key=lambda x: x) == 3
    assert max([3, 1, 2], key=lambda x: x) == 3
    assert max

# Generated at 2022-06-22 16:41:24.346446
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3, 4], [2, 3, 4, 5]) == [1, 5]
    assert symmetric_difference([1, 2, 3, 4], [2, 3, 4, 5, 6]) == [1, 5, 6]
    assert symmetric_difference([1, 2, 3, 4, 5], [2, 3, 4, 5, 6]) == [1, 6]

# Generated at 2022-06-22 16:41:28.337361
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:33.898825
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:41:46.856232
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:42:06.114906
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:14.905270
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1B') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1T') == 1099511627776
    assert human_to_bytes('1P') == 1125899906842624
    assert human_to_bytes('1E') == 1152921504606846976
    assert human_to_bytes('1Z') == 1180591620717411303424
    assert human_to_bytes('1Y') == 1208925819614629174706176
    assert human_to_bytes('1.5K') == 1536
    assert human_

# Generated at 2022-06-22 16:42:26.882052
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5]) == [1, 4, 5]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6]) == [1, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7]) == [1, 4, 5, 6, 7]
    assert symmetric_difference([1, 2, 3], [2, 3, 4, 5, 6, 7, 8]) == [1, 4, 5, 6, 7, 8]

# Generated at 2022-06-22 16:42:39.150568
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    builtins = __import__(builtin_module_name)
    setattr(builtins, '__ansible_test_rekey_on_member', rekey_on_member)

    # Test rekey_on_member on a dict
    test_dict = {
        'a': {'a': 1, 'b': 2},
        'b': {'a': 3, 'b': 4},
        'c': {'a': 5, 'b': 6},
    }
    assert __ansible_test_rekey_on

# Generated at 2022-06-22 16:42:52.246111
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1.5') == 1
    assert human_to_bytes('1.5K') == 1536
    assert human_to_bytes('1.5M') == 1572864
    assert human_to_bytes('1.5G') == 1610612736
    assert human_to_bytes('1.5T') == 1649267441664
    assert human_to_bytes('1.5P') == 1688849860263936
    assert human_to_bytes('1.5E') == 1728384842948608000
    assert human_to_bytes('1.5Z') == 1767831138105610240000
    assert human_to_bytes('1.5Y') == 18073264163125760051200000

# Generated at 2022-06-22 16:43:00.340600
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([3, 3, 3]) == 3
    assert max([-1, -2, -3]) == -1
    assert max([-1, -3, -2]) == -1
    assert max([-3, -2, -1]) == -1
    assert max([-3, -3, -3]) == -3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1

# Generated at 2022-06-22 16:43:13.063587
# Unit test for function symmetric_difference
def test_symmetric_difference():
    assert symmetric_difference([1, 2, 3], [2, 3, 4]) == [1, 4]
    assert symmetric_difference([1, 2, 3], [1, 2, 3]) == []
    assert symmetric_difference([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert symmetric_difference([1, 2, 3], [1, 2, 3, 4, 5, 6]) == [4, 5, 6]
    assert symmetric_difference([1, 2, 3, 4, 5, 6], [1, 2, 3]) == [4, 5, 6]
    assert symmetric_difference([1, 2, 3, 4, 5, 6], [4, 5, 6]) == [1, 2, 3]
    assert symm

# Generated at 2022-06-22 16:43:20.453472
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3]
    b = [2, 3, 4]
    c = [1, 2, 3, 4]
    d = [1, 3, 4]
    e = [1, 2, 4]
    f = [1, 2, 3, 4, 5]
    g = [1, 2, 3, 4, 5, 6]
    h = [1, 2, 3, 4, 5, 6, 7]
    i = [1, 2, 3, 4, 5, 6, 7, 8]
    j = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    k = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-22 16:43:31.977567
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:43:44.916537
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=False, attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], case_sensitive=False, attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=True) == 1
    assert min([1, 2, 3], case_sensitive=True, attribute='foo') == 1

# Generated at 2022-06-22 16:44:33.795715
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:44:46.339033
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:44:53.209346
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max(1, 2, 3) == 3
    assert max(1, 2, 3, 4, 5, 6) == 6
    assert max(1, 2, 3, 4, 5, 6, 7, 8, 9) == 9
    assert max(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12) == 12

# Generated at 2022-06-22 16:45:01.540796
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1
    assert max([1, 2, 3], key=lambda x: x) == 3
    assert max([1, 3, 2], key=lambda x: x) == 3
    assert max([3, 1, 2], key=lambda x: x) == 3
    assert max

# Generated at 2022-06-22 16:45:13.400691
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:45:23.227288
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0 B'
    assert human_readable(1) == '1 B'
    assert human_readable(2) == '2 B'
    assert human_readable(1023) == '1023 B'
    assert human_readable(1024) == '1.0 KiB'
    assert human_readable(1024 * 1024) == '1.0 MiB'
    assert human_readable(1024 * 1024 * 1024) == '1.0 GiB'
    assert human_readable(1024 * 1024 * 1024 * 1024) == '1.0 TiB'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024) == '1.0 PiB'
    assert human_readable(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1.0 EiB'

# Generated at 2022-06-22 16:45:35.138506
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([1, 2, 3], attribute='foo', default=10) == 1
    assert min([1, 2, 3], default=10) == 1
    assert min([1, 2, 3], default=10, attribute='foo') == 1
    assert min([1, 2, 3], default=10, attribute='foo', bar='baz') == 1
    assert min([1, 2, 3], default=10, bar='baz') == 1
    assert min([1, 2, 3], bar='baz') == 1
    assert min([1, 2, 3], bar='baz', attribute='foo') == 1

# Generated at 2022-06-22 16:45:46.418335
# Unit test for function unique

# Generated at 2022-06-22 16:45:58.149980
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:08.297366
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=0) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], default=0) == [7, 8, 9]

# Generated at 2022-06-22 16:46:58.788173
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:04.781532
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:47:12.079123
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:47:24.622736
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:33.110670
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:47:43.611195
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='x') == [1, 2, 3]

# Generated at 2022-06-22 16:47:55.724901
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=[0, 0, 0]) == [1, 2, 3]