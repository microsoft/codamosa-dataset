

# Generated at 2022-06-22 16:38:19.974337
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(1) == 0
    assert logarithm(math.e) == 1
    assert logarithm(math.e**2) == 2
    assert logarithm(math.e**3) == 3
    assert logarithm(math.e**4) == 4
    assert logarithm(math.e**5) == 5
    assert logarithm(math.e**6) == 6
    assert logarithm(math.e**7) == 7
    assert logarithm(math.e**8) == 8
    assert logarithm(math.e**9) == 9
    assert logarithm(math.e**10) == 10
    assert logarithm(math.e**11) == 11
    assert logarithm(math.e**12)

# Generated at 2022-06-22 16:38:28.275132
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=False, attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], case_sensitive=False, attribute='foo') == {'foo': 1}


# Generated at 2022-06-22 16:38:39.808583
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, -3) == 0.125
    assert power(-2, 3) == -8
    assert power(-2, -3) == -0.125
    assert power(0, 0) == 1
    assert power(0, 1) == 0
    assert power(0, -1) == 0
    assert power(1, 0) == 1
    assert power(1, 1) == 1
    assert power(1, -1) == 1
    assert power(2, 0) == 1
    assert power(2, 1) == 2
    assert power(2, -1) == 0.5
    assert power(3, 0) == 1
    assert power(3, 1) == 3
    assert power(3, -1) == 1.0/3

# Generated at 2022-06-22 16:38:50.097919
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on_member
    # Test for rekey_on

# Generated at 2022-06-22 16:38:59.342082
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=False, attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], case_sensitive=False, attribute='foo') == {'foo': 1}



# Generated at 2022-06-22 16:39:08.689895
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:39:17.573198
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:39:24.235922
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x)) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], key=lambda x: sum(x), default=[0, 0, 0]) == [7, 8, 9]

# Generated at 2022-06-22 16:39:34.306613
# Unit test for function power
def test_power():
    assert power(2, 3) == 8
    assert power(2, -3) == 0.125
    assert power(2.0, 3) == 8.0
    assert power(2.0, -3) == 0.125
    assert power(2.0, 3.0) == 8.0
    assert power(2.0, -3.0) == 0.125
    assert power(2, 3.0) == 8.0
    assert power(2, -3.0) == 0.125
    assert power(2.0, 3.0) == 8.0
    assert power(2.0, -3.0) == 0.125
    assert power(2, 3.0) == 8.0
    assert power(2, -3.0) == 0.125

# Generated at 2022-06-22 16:39:45.059322
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([1, 2, 3], attribute='foo', default=0) == 0
    assert min([1, 2, 3], default=0) == 0
    assert min([1, 2, 3], attribute='foo', default=0, unique=True) == 0
    assert min([1, 2, 3], attribute='foo', default=0, unique=False) == 0
    assert min([1, 2, 3], attribute='foo', default=0, unique=True, case_sensitive=True) == 0
    assert min([1, 2, 3], attribute='foo', default=0, unique=True, case_sensitive=False) == 0

# Generated at 2022-06-22 16:40:03.054358
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique(['a', 'A', 'b', 'B'], case_sensitive=False) == ['a', 'b']

# Generated at 2022-06-22 16:40:14.019914
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:40:25.475039
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: -x) == 3
    assert min([1, 2, 3], key=lambda x: x) == 1
    assert min([1, 2, 3], key=lambda x: x, default=0) == 1
    assert min([], key=lambda x: x, default=0) == 0
    assert min([1, 2, 3], key=lambda x: x, default=0, default_value=0) == 1
    assert min([], key=lambda x: x, default=0, default_value=0) == 0
    assert min([1, 2, 3], key=lambda x: x, default=0, default_value=0, value=0) == 1

# Generated at 2022-06-22 16:40:37.667350
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=True) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=None) == {'foo': 1}

# Generated at 2022-06-22 16:40:49.426194
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:01.019944
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='foo') == [1, 2, 3]
    assert unique([{'foo': 1}, {'foo': 2}, {'foo': 3}, {'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == [{'foo': 1}, {'foo': 2}, {'foo': 3}]

# Generated at 2022-06-22 16:41:12.324649
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:24.346097
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:41:31.406090
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 3, 4, 4, 5, 5, 5]) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5, 5], case_sensitive=False) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5, 5], case_sensitive=True) == [1, 2, 3, 3, 4, 4, 5, 5, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5, 5], case_sensitive=None) == [1, 2, 3, 4, 5]

# Generated at 2022-06-22 16:41:39.461240
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.compat.tests import unittest

    class TestRekeyOnMember(unittest.TestCase):
        def test_rekey_on_member(self):
            from ansible.plugins.filter.core import rekey_on_member

            # Test rekey_on_member with a dict
            data = {
                'a': {'key': 'a', 'value': 1},
                'b': {'key': 'b', 'value': 2},
                'c': {'key': 'c', 'value': 3},
            }
            key = 'key'
            expected = {
                'a': {'key': 'a', 'value': 1},
                'b': {'key': 'b', 'value': 2},
                'c': {'key': 'c', 'value': 3},
            }

# Generated at 2022-06-22 16:41:58.123964
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:08.137635
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:16.599154
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=None) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], attribute='test') == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False, attribute='test') == [1, 2, 3]

# Generated at 2022-06-22 16:42:27.769365
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=True) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=None) == {'foo': 1}

# Generated at 2022-06-22 16:42:39.578479
# Unit test for function logarithm
def test_logarithm():
    assert logarithm(10, 10) == 1
    assert logarithm(100, 10) == 2
    assert logarithm(1000, 10) == 3
    assert logarithm(2, 2) == 1
    assert logarithm(4, 2) == 2
    assert logarithm(8, 2) == 3
    assert logarithm(16, 2) == 4
    assert logarithm(32, 2) == 5
    assert logarithm(64, 2) == 6
    assert logarithm(128, 2) == 7
    assert logarithm(256, 2) == 8
    assert logarithm(512, 2) == 9
    assert logarithm(1024, 2) == 10
    assert logarithm(2048, 2) == 11

# Generated at 2022-06-22 16:42:52.329374
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:42:58.525636
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 3, 4, 4, 5, 5]) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5], case_sensitive=False) == [1, 2, 3, 4, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5], case_sensitive=True) == [1, 2, 3, 3, 4, 4, 5, 5]
    assert unique([1, 2, 3, 3, 4, 4, 5, 5], case_sensitive=False, attribute='foo') == [1, 2, 3, 4, 5]

# Generated at 2022-06-22 16:43:00.991545
# Unit test for function symmetric_difference
def test_symmetric_difference():
    a = [1, 2, 3, 4, 5]
    b = [3, 4, 5, 6, 7]
    c = [1, 2, 6, 7]
    assert symmetric_difference(None, a, b) == c

# Generated at 2022-06-22 16:43:14.044505
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='bar') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='bar') == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='bar', case_sensitive=False) == {'foo': 1}

# Generated at 2022-06-22 16:43:19.382320
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=str) == 3
    assert max([1, 3, 2], key=str) == 3
    assert max([3, 1, 2], key=str) == 3
    assert max([3, 2, 1], key=str) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1

# Generated at 2022-06-22 16:43:35.837367
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test that rekey_on_member works with a dict of dicts
    data = {'a': {'b': 1, 'c': 2}, 'd': {'b': 3, 'c': 4}}
    assert rekey_on_member(data, 'b') == {1: {'b': 1, 'c': 2}, 3: {'b': 3, 'c': 4}}

    # Test that rekey_on_member works with a list of dicts
    data = [{'b': 1, 'c': 2}, {'b': 3, 'c': 4}]

# Generated at 2022-06-22 16:43:47.992047
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:00.901583
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import sys

    # Create a dict of dicts
    data = {'a': {'key': 'a', 'value': 1}, 'b': {'key': 'b', 'value': 2}}

    # Create a list of dicts
    data_list = [{'key': 'a', 'value': 1}, {'key': 'b', 'value': 2}]

    # Rekey the dict of dicts on the 'key' member
    new_obj = rekey_on_member(data, 'key')
    assert new_obj == {'a': {'key': 'a', 'value': 1}, 'b': {'key': 'b', 'value': 2}}

    # Rekey the list

# Generated at 2022-06-22 16:44:11.978602
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:44:24.650695
# Unit test for function rekey_on_member
def test_rekey_on_member():
    # Test that the function works with a dict of dicts
    data = {
        'a': {'key': 'a', 'value': 1},
        'b': {'key': 'b', 'value': 2},
        'c': {'key': 'c', 'value': 3},
    }
    result = rekey_on_member(data, 'key')
    assert result == data

    # Test that the function works with a list of dicts
    data = [
        {'key': 'a', 'value': 1},
        {'key': 'b', 'value': 2},
        {'key': 'c', 'value': 3},
    ]
    result = rekey_on_member(data, 'key')

# Generated at 2022-06-22 16:44:34.483039
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:44:46.495728
# Unit test for function rekey_on_member
def test_rekey_on_member():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.six import PY3

    # Test that rekey_on_member works on a dict of dicts
    test_dict = {
        'a': {
            'key': 'a',
            'value': 'a_value',
        },
        'b': {
            'key': 'b',
            'value': 'b_value',
        },
        'c': {
            'key': 'c',
            'value': 'c_value',
        },
    }
    rekeyed_dict = rekey_on_member(test_dict, 'key')
    assert isinstance(rekeyed_dict, Mapping)

# Generated at 2022-06-22 16:44:52.314623
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], attribute='foo', case_sensitive=False) == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo', case_sensitive=False) == {'foo': 1}


# Generated at 2022-06-22 16:45:01.207536
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1k') == 1024
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1Ki') == 1024
    assert human_to_bytes('1KiB') == 1024
    assert human_to_bytes('1m') == 1048576
    assert human_to_bytes('1M') == 1048576
    assert human_to_bytes('1Mi') == 1048576
    assert human_to_bytes('1MiB') == 1048576
    assert human_to_bytes('1g') == 1073741824
    assert human_to_bytes('1G') == 1073741824
    assert human_to_bytes('1Gi') == 1073741824

# Generated at 2022-06-22 16:45:13.271998
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:45:32.681815
# Unit test for function human_to_bytes
def test_human_to_bytes():
    assert human_to_bytes('1') == 1
    assert human_to_bytes('1K') == 1024
    assert human_to_bytes('1M') == 1024 * 1024
    assert human_to_bytes('1G') == 1024 * 1024 * 1024
    assert human_to_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1Y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert human_to_bytes('1KB') == 1000
    assert human_

# Generated at 2022-06-22 16:45:44.654979
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 3, 2]) == 3
    assert max([3, 1, 2]) == 3
    assert max([3, 2, 1]) == 3
    assert max([1, 2, 3], key=lambda x: -x) == 1
    assert max([1, 3, 2], key=lambda x: -x) == 1
    assert max([3, 1, 2], key=lambda x: -x) == 1
    assert max([3, 2, 1], key=lambda x: -x) == 1
    assert max([1, 2, 3], key=lambda x: x) == 3
    assert max([1, 3, 2], key=lambda x: x) == 3
    assert max([3, 1, 2], key=lambda x: x) == 3
    assert max

# Generated at 2022-06-22 16:45:51.816822
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(10) == '10'
    assert human_readable(100) == '100'
    assert human_readable(1000) == '1.0K'
    assert human_readable(1024) == '1.0K'
    assert human_readable(10240) == '10K'
    assert human_readable(102400) == '100K'
    assert human_readable(1048576) == '1.0M'
    assert human_readable(10485760) == '10M'
    assert human_readable(104857600) == '100M'
    assert human_readable(1073741824) == '1.0G'

# Generated at 2022-06-22 16:45:59.254240
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], attribute='foo') == {'foo': 1}
    assert min([1, 2, 3], case_sensitive=False) == 1
    assert min([1, 2, 3], case_sensitive=False, attribute='foo') == 1
    assert min([{'foo': 1}, {'foo': 2}, {'foo': 3}], case_sensitive=False, attribute='foo') == {'foo': 1}


# Generated at 2022-06-22 16:46:08.768855
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:21.196038
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:33.477950
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:46:45.342892
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(0) == '0'
    assert human_readable(1) == '1'
    assert human_readable(10) == '10'
    assert human_readable(100) == '100'
    assert human_readable(1000) == '1.0K'
    assert human_readable(1024) == '1.0K'
    assert human_readable(1025) == '1.0K'
    assert human_readable(1536) == '1.5K'
    assert human_readable(1048576) == '1.0M'
    assert human_readable(1073741824) == '1.0G'
    assert human_readable(1099511627776) == '1.0T'
    assert human_readable(1125899906842624) == '1.0P'

# Generated at 2022-06-22 16:46:58.154636
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], [4, 5, 6]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [1, 2, 3]
    assert min([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [1, 2, 3]

# Generated at 2022-06-22 16:47:05.640168
# Unit test for function min
def test_min():
    assert min([1, 2, 3]) == 1
    assert min([1, 2, 3], key=lambda x: x * -1) == 3
    assert min([1, 2, 3], key=lambda x: x * -1, default=0) == 3
    assert min([1, 2, 3], default=0) == 1
    assert min([], default=0) == 0
    assert min([], key=lambda x: x * -1, default=0) == 0
    assert min([1, 2, 3], key=lambda x: x * -1, default=0) == 3
    assert min([1, 2, 3], key=lambda x: x * -1, default=0) == 3
    assert min([1, 2, 3], key=lambda x: x * -1, default=0) == 3

# Generated at 2022-06-22 16:47:30.728810
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:47:42.371590
# Unit test for function human_readable
def test_human_readable():
    assert human_readable(1) == '1 B'
    assert human_readable(1, isbits=True) == '8 b'
    assert human_readable(1, unit='B') == '1 B'
    assert human_readable(1, unit='B', isbits=True) == '8 b'
    assert human_readable(1, unit='B', isbits=False) == '1 B'
    assert human_readable(1, unit='B', isbits=True) == '8 b'
    assert human_readable(1, unit='B', isbits=False) == '1 B'
    assert human_readable(1, unit='B', isbits=True) == '8 b'
    assert human_readable(1, unit='B', isbits=False) == '1 B'

# Generated at 2022-06-22 16:47:48.523359
# Unit test for function max
def test_max():
    assert max([1, 2, 3]) == 3
    assert max([1, 2, 3], [4, 5, 6]) == [4, 5, 6]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9]) == [7, 8, 9]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]) == [10, 11, 12]
    assert max([1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]) == [13, 14, 15]

# Generated at 2022-06-22 16:48:00.549078
# Unit test for function unique
def test_unique():
    assert unique([1, 2, 3, 1, 2, 3]) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=False) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=True) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=None) == [1, 2, 3]
    assert unique([1, 2, 3, 1, 2, 3], case_sensitive=None, attribute='foo') == [1, 2, 3]