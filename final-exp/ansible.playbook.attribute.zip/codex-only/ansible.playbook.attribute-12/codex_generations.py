

# Generated at 2022-06-23 05:42:25.216976
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class A(object):
        a = Attribute(priority=1)
    class B(A):
        b = Attribute(priority=2)
    class C(B):
        c = Attribute(priority=3)

    c = C(a=1, b=2, c=3)

    assert c.a >= c.a
    assert c.a >= c.b
    assert c.a >= c.c
    assert c.b >= c.a
    assert c.b >= c.b
    assert c.b >= c.c
    assert c.c >= c.a
    assert c.c >= c.b
    assert c.c >= c.c



# Generated at 2022-06-23 05:42:26.572269
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute())


# Generated at 2022-06-23 05:42:27.529911
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_att = FieldAttribute()



# Generated at 2022-06-23 05:42:34.997693
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """verify Attribute class method __ne__ works
    """

    # instantiate two equal Attribute objects
    attr1 = Attribute()
    attr2 = Attribute()

    assert attr1.priority == 0
    assert attr2.priority == 0

    assert attr1 == attr2
    assert not attr1 != attr2

    # change priority of second Attribute object
    attr2.priority = 10
    assert attr1.priority != attr2.priority
    assert not attr1 == attr2
    assert attr1 != attr2


# Generated at 2022-06-23 05:42:46.293995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute(isa='str')
    assert field_attr.isa == 'str'
    assert field_attr.private == False
    assert field_attr.default == None
    assert field_attr.required == False
    assert field_attr.listof == None
    assert field_attr.priority == 0
    assert field_attr.class_type == None
    assert field_attr.always_post_validate == False
    assert field_attr.inherit == True
    assert field_attr.alias == None
    assert field_attr.extend == False
    assert field_attr.prepend == False
    assert field_attr.static == False


# Generated at 2022-06-23 05:42:49.432691
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2.__ge__(attr1) == True


# Generated at 2022-06-23 05:42:52.193254
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    A = Attribute(priority=0)
    B = Attribute(priority=1)
    assert A < B
    assert not B < A
    assert not A < A


# Generated at 2022-06-23 05:43:01.121564
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """
    Method __ne__ of class Attribute :
    Make sure that all functions __ne__, __lt__, __gt__, __le__, __ge__ of class Attribute
    return the expected result according to their priority
    """
    obj1 = Attribute(priority = 1)
    obj2 = Attribute(priority = 2)
    obj3 = Attribute(priority = 3)
    obj4 = Attribute(priority = 4)
    obj5 = Attribute(priority = 5)
    expected = [True, False, False, False, False]
    test1   = obj1.__ne__(obj2)
    test2   = obj2.__ne__(obj3)
    test3   = obj3.__ne__(obj4)
    test4   = obj4.__ne__(obj5)
    test5

# Generated at 2022-06-23 05:43:09.809590
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='string', private=False, default='localhost', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'string'
    assert attr.private == False
    assert attr.default == 'localhost'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static

# Generated at 2022-06-23 05:43:16.329984
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert a1.__lt__(a2) == False
    assert a2.__lt__(a1) == True 
    assert a2.__lt__(a2) == False
    assert a1.__lt__(a1) == False


# Generated at 2022-06-23 05:43:20.772695
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    attr_1 = Attribute(priority = 1)
    attr_2 = Attribute(priority = 0)
    assert attr == attr_1," Attribute Unit Test Failed "
    assert not attr == attr_2," Attribute Unit Test Failed "


# Generated at 2022-06-23 05:43:27.030500
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa='boolean', default=False, inherit=False)
    attr2 = FieldAttribute(isa='boolean', default=False, inherit=False)
    assert attr1 == attr2
    assert attr1 != attr2
    assert attr1 <= attr2
    assert attr1 >= attr2
    assert attr1 < attr2
    assert attr1 > attr2


# Generated at 2022-06-23 05:43:33.071939
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print("\ntest_Attribute___ge__")
    attr = Attribute('test', priority=2)
    assert attr.priority == 2
    attr2 = Attribute('test', priority=2)
    assert attr2.priority == 2
    attr3 = Attribute('test', priority=3)
    assert attr3.priority == 3
    assert attr.__ge__(attr2)
    assert attr2.__ge__(attr)
    assert attr2.__ge__(attr3)
    assert attr3.__ge__(attr2)



# Generated at 2022-06-23 05:43:35.171058
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(required=True)
    a2 = Attribute(priority=1)
    assert a1 < a2



# Generated at 2022-06-23 05:43:38.833158
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__ne__(attr2)


# Generated at 2022-06-23 05:43:43.506635
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert a.__lt__(b)

    a = Attribute(priority=20)
    b = Attribute(priority=10)
    assert a.__lt__(b) is False



# Generated at 2022-06-23 05:43:52.371544
# Unit test for constructor of class Attribute
def test_Attribute():
    # test init
    a = Attribute(None, private=False, default=None, required=False,
        listof="blah", priority=1, class_type=object, always_post_validate=False, extend=True,
        alias='morisato_godel_einstein')
    assert a is not None
    assert a.isa is None
    assert not a.private
    assert a.default is None
    assert not a.required
    assert a.listof == "blah"
    assert a.priority == 1
    assert a.class_type == object
    assert not a.always_post_validate
    assert a.extend
    assert a.alias == 'morisato_godel_einstein'

    # test sort
    a1 = Attribute(None, priority=0)
    a2 = Att

# Generated at 2022-06-23 05:43:55.101616
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute(isa='boolean', default=False)
    assert field_attr.isa == 'boolean'
    assert field_attr.default == False



# Generated at 2022-06-23 05:43:56.075804
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.default is None


# Generated at 2022-06-23 05:44:05.121647
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(
        isa='str',
        private=True,
        default='/usr/lib',
        required=True,
        listof=None,
        priority=20,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attribute.isa == 'str'
    assert attribute.private == True
    assert attribute.default == '/usr/lib'
    assert attribute.required == True
    assert attribute.listof == None
    assert attribute.priority == 20
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None

# Generated at 2022-06-23 05:44:09.967560
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute() < Attribute(priority=1)


# Generated at 2022-06-23 05:44:12.139074
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a != b


# Generated at 2022-06-23 05:44:20.142805
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute1 = Attribute(isa=str)
    attribute2 = Attribute(isa=str, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attribute1.isa == str
    assert attribute1.private == False
    assert attribute1.default == None
    assert attribute1.required == False
    assert attribute1.listof == None
    assert attribute1.priority == 0
    assert attribute1.class_type == None
    assert attribute1.always_post_validate == False
    assert attribute1.inherit == True
    assert attribute1.alias == None
    assert attribute1.extend == False

# Generated at 2022-06-23 05:44:29.099767
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print("\n========================================")
    print("Starting test for method __ne__ of class Attribute")

    # Arrange
    test_Attribute = Attribute()
    test_Attribute.priority = 10
    other_Attribute = Attribute()
    other_Attribute.priority = 10

    print("Verify if __ne__ return false")
    if(test_Attribute != other_Attribute):
        print("PASS")
    else:
        print("FAIL")

    test_Attribute.priority = 11

    print("Verify if __ne__ return true")
    if(test_Attribute != other_Attribute):
        print("PASS")
    else:
        print("FAIL")



# Generated at 2022-06-23 05:44:38.768491
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    d = Attribute(priority=2)
    e = Attribute(priority=3)
    f = Attribute(priority=4)
    g = Attribute(priority=5)
    h = Attribute(priority=6)
    i = Attribute(priority=7)
    j = Attribute(priority=8)
    k = Attribute(priority=9)
    l = Attribute(priority=10)

    assert a > b
    assert not b > a

    assert b > a
    assert not a > b

    assert c > b
    assert not b > c

    assert not c > d
    assert not d > c

    assert d > b
    assert not b > d

   

# Generated at 2022-06-23 05:44:43.574156
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2

    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert a2 > a1


# Generated at 2022-06-23 05:44:50.734095
# Unit test for constructor of class Attribute

# Generated at 2022-06-23 05:44:56.084890
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='int')
    a2 = Attribute(isa='int')
    assert a1.__eq__(a2)
    a1 = Attribute(isa='bool')
    a2 = Attribute(isa='int')
    assert not a1.__eq__(a2)


# Generated at 2022-06-23 05:45:00.729001
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # initialize two instances of class Attribute
    # with same priority value
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)

    # verify that __eq__ perform correct comparison
    assert attr1.__eq__(attr2)
    assert attr2.__eq__(attr1)


# Generated at 2022-06-23 05:45:11.717236
# Unit test for constructor of class Attribute
def test_Attribute():
    def test():
        a = Attribute()
        assert a.isa == None
        assert a.private == False
        assert a.default == None
        assert a.required == False
        assert a.listof == None
        assert a.priority == 0
        assert a.class_type == None
        assert a.always_post_validate == False
        assert a.inherit == True
        assert a.alias == None
        assert a.extend == False
        assert a.prepend == False
        assert a.static == False
    test()


# Generated at 2022-06-23 05:45:14.403472
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__le__(attr2) == True
    


# Generated at 2022-06-23 05:45:26.314021
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Remember to set your python environment to avt-pyenv
    """
    field = FieldAttribute(isa="dict", required=True)
    assert isinstance(field.isa, str), "isa should be a required str"

    field = FieldAttribute(isa="dict", private=True)
    assert isinstance(field.private, bool), "private should be a required bool"

    field = FieldAttribute(isa="dict", default=None)
    assert field.default is None, "default should be a required None"

    field = FieldAttribute(isa="dict", required=True)
    assert isinstance(field.required, bool), "required should be a required bool"

    field = FieldAttribute(isa="dict", listof="dict")
    assert isinstance(field.listof, str), "listof should be a required str"

    field = Field

# Generated at 2022-06-23 05:45:34.986818
# Unit test for constructor of class Attribute
def test_Attribute():
    """ Attribute - basic tests """

    try:
        a = Attribute(default=[], isa='list')
    except TypeError:
        pass
    else:
        assert False, "Attribute list default should not be testable"

    # Verify error about reserved word is raised
    try:
        a = Attribute(alias='pass')
    except TypeError:
        pass
    else:
        assert False, "Attribute alias should not be allowed"

    # Verify attribute order (priority) for list
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=20)
    attrs = [a1, a2, a3]
    assert attrs == sorted(attrs), "Attributes not sorted"

    # Verify attribute equality

# Generated at 2022-06-23 05:45:37.897727
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    _Attribute = Attribute(priority=0)
    _Attribute_prio = Attribute(priority=1)
    assert not (_Attribute == _Attribute_prio)


# Generated at 2022-06-23 05:45:40.106801
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=19)
    assert a2 >= a1


# Generated at 2022-06-23 05:45:42.890169
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """Test for the __eq__ method of Attribute class"""
    a = Attribute()
    b = Attribute()
    assert a == b


# Generated at 2022-06-23 05:45:53.645677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# TODO:
# _CONTAINERS should be checked in specific container-related methods
# (e.g. FieldAttribute.listof should be checked in FieldAttribute.__set__)

# Generated at 2022-06-23 05:46:04.165054
# Unit test for constructor of class Attribute
def test_Attribute():

    # Basic test with no arguments passed in
    # Expect the default values
    example = Attribute()

    assert example.isa is None
    assert example.private is False
    assert example.default is None
    assert example.required is False
    assert example.listof is None
    assert example.priority == 0
    assert example.class_type is None
    assert example.always_post_validate is False
    assert example.inherit is True
    assert example.alias is None

    # Basic test with all arguments passed in
    # Expect the values that were passed in

# Generated at 2022-06-23 05:46:08.192470
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    priority = 666
    attr1 = Attribute(isa='Instance of datetime.datetime', priority=priority)
    attr2 = Attribute(isa='Instance of datetime.datetime', priority=priority)
    assert attr1.__eq__(attr2)



# Generated at 2022-06-23 05:46:11.708627
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """
    Unit test for method __ge__ of class Attribute
    """
    local = Attribute()
    local.priority = 1
    remote = Attribute()
    remote.priority = 2
    assert local >= remote



# Generated at 2022-06-23 05:46:12.980429
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-23 05:46:16.783669
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a=Attribute(priority=2)
    b=Attribute(priority=3)
    assert a.__ne__(b)

    b=Attribute(priority=2)
    assert not a.__ne__(b)


# Generated at 2022-06-23 05:46:21.124944
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert attr1 == attr2

    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert not attr1 == attr2


# Generated at 2022-06-23 05:46:27.450175
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: make this into a real unit test
    class Test:
        def __init__(self, foo=None):
            self._foo = foo

        foo = FieldAttribute(isa='str', default='spam', class_type=str, inherit=False)

    t = Test()
    assert t._foo == 'spam'

    t = Test(foo=Attribute(isa='str'))
    assert t._foo.isa == 'str'

    # test attributes that can be inherited
    t = Test()
    assert t.foo == 'spam'
    t.foo = 'eggs'
    assert t.foo == 'eggs'

    # test attributes that are private
    t = Test()
    assert not hasattr(t, 'foo')

    # test attributes that can't be inherited

# Generated at 2022-06-23 05:46:29.386608
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a_attr = Attribute(priority=0)
    assert a_attr != Attribute(priority=1)


# Generated at 2022-06-23 05:46:33.438711
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 4
    a3 = Attribute()
    a3.priority = 1
    assert a1 != a2
    assert a1 == a3


# Generated at 2022-06-23 05:46:43.248879
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_dict = dict(isa=None,
                     private=False,
                     default=None,
                     required=False,
                     listof=None,
                     priority=0,
                     class_type=None,
                     always_post_validate=False,
                     inherit=True,
                     alias=None,
                     extend=False,
                     prepend=False,
                     static=False)

    attr = Attribute(**attr_dict)
    attr_data = deepcopy(attr_dict)
    attr_data['priority'] = 2

    attr2 = Attribute(**attr_data)

    if attr != attr2:
        print("attr is not equal to attr2")
    else:
        print("attr is equal to attr2")

if __name__ == "__main__":
    test

# Generated at 2022-06-23 05:46:48.349518
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority = 2) <= Attribute(priority = 3)
    assert Attribute(priority = 5) >= Attribute(priority = 5)
    assert Attribute(priority = 2) <= Attribute(priority = 2)
    assert not Attribute(priority = 3) <= Attribute(priority = 2)
    assert not Attribute(priority = 1) >= Attribute(priority = 2)



# Generated at 2022-06-23 05:46:55.227600
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    b = Attribute(isa='list', listof='str')
    c = Attribute(isa='list', listof='str')
    assert a == b
    assert a != c
    assert b < c
    assert c > b
    assert b <= c
    assert c >= b
    bad_listof = Attribute(isa='list', listof=2)
    bad_default = Attribute(isa='list', default=['a', 'b'])



# Generated at 2022-06-23 05:46:57.652490
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(default=dict())
        raise Exception("Should have thrown exception")
    except TypeError:
        pass

# Generated at 2022-06-23 05:47:01.084430
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    attribute.priority = 1
    other_attribute = Attribute()
    other_attribute.priority = 1
    if attribute == other_attribute:
        raise AssertionError("expected attribute not to be equal to other_attribute")


# Generated at 2022-06-23 05:47:03.619787
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field=FieldAttribute(isa='int', default=42)
    assert field.isa == 'int'
    assert field.default == 42


# Generated at 2022-06-23 05:47:14.787525
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa="int", default=1, required=True)
    assert a.isa == "int"
    assert a.default == 1
    assert a.required == True
    a = Attribute(isa="int", default=1)
    assert a.isa == "int"
    assert a.default == 1
    assert a.required == False
    try:
        a = Attribute(isa="int", default="string")
        assert False
    except TypeError:
        assert True
    else:
        assert False
    try:
        a = Attribute(isa="int", default=1, required="string")
        assert False
    except TypeError:
        assert True
    else:
        assert False
    print("Constructor of class Attribute works!")



# Generated at 2022-06-23 05:47:18.319782
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a1 <= a0


# Generated at 2022-06-23 05:47:20.698398
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a1 >= a2)



# Generated at 2022-06-23 05:47:24.244359
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='dict', priority=0)
    b = Attribute(isa='dict', priority=0)
    c = Attribute(isa='dict', priority=100)
    assert a == b
    assert a != c


# Generated at 2022-06-23 05:47:26.135531
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=1)
    attr < Attribute(priority=0)

# Generated at 2022-06-23 05:47:32.907639
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = FieldAttribute(priority=0)
    attr2 = FieldAttribute(priority=0)
    assert attr1 == attr2

    attr1 = FieldAttribute(priority=1)
    attr2 = FieldAttribute(priority=0)
    assert attr1 > attr2

    attr1 = FieldAttribute(priority=0)
    attr2 = FieldAttribute(priority=1)
    assert attr1 < attr2


# Generated at 2022-06-23 05:47:42.114771
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    if not (FieldAttribute(priority=1) <= FieldAttribute(priority=2)) or \
        FieldAttribute(priority=2) <= FieldAttribute(priority=2) or \
        FieldAttribute(priority=3) <= FieldAttribute(priority=2) or \
        FieldAttribute(priority=3) <= FieldAttribute(priority=3):
        print("[ERROR] method __le__ of class Attribute is incorrect: failed FieldAttribute(priority=1) <= FieldAttribute(priority=2)")
        print("[ERROR] method __le__ of class Attribute is incorrect: failed FieldAttribute(priority=2) <= FieldAttribute(priority=2)")
        print("[ERROR] method __le__ of class Attribute is incorrect: failed FieldAttribute(priority=3) <= FieldAttribute(priority=2)")

# Generated at 2022-06-23 05:47:45.086415
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)

    assert a <= b
    assert a <= c
    assert b <= c


# Generated at 2022-06-23 05:47:47.188715
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 2)
    assert b > a

# Generated at 2022-06-23 05:47:49.902406
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=7)
    assert attr1 < attr2


# Generated at 2022-06-23 05:47:55.918517
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(
        isa='str',
        private=False,
        default='default',
        required=True,
        listof='dict',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-23 05:48:05.693634
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    import unittest.mock as mock
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=10)

    assert(attr2 > attr1)
    assert(not(attr1 > attr2))
    attr1 = Attribute(priority=5)
    assert(not(attr2 > attr1))
    attr2 = Attribute(priority=5)
    assert(not(attr2 > attr1))

    # __gt__ is not implemented for Attribute, so it should be the same as FieldAttribute().
    with mock.patch('ansible.module_utils.common._collections_compat.FieldAttribute.__gt__') as mock_gt:
        attr1 = Attribute(priority=5)
        attr2 = Attribute(priority=10)
        Attribute

# Generated at 2022-06-23 05:48:11.580774
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # test case 1
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr.__ge__(attr2) == True
    # test case 2
    attr = Attribute(priority=4)
    attr2 = Attribute(priority=2)
    assert attr.__ge__(attr2) == False

# Generated at 2022-06-23 05:48:17.033807
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """
    #Unit test for method __ne__ of class Attribute
    """
    a = Attribute("int",default=0,required=False,priority=0)
    b = Attribute("int",default=0,required=False,priority=0)
    assert a.__ne__(b) == False


# Generated at 2022-06-23 05:48:23.368484
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute()
    attribute2 = Attribute()

    attribute.priority = 5
    attribute2.priority = 5

    output = attribute.__gt__(attribute2)
    correct_result = False

    assert output == correct_result


# Generated at 2022-06-23 05:48:32.485674
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    fail_msg = "Attribute '__le__' method does not work as expected"
    #Test 'less or equal' method for two Attribute objects with equal priorities
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert (attr1 <= attr2) == True, fail_msg
    #Test 'less or equal' method for two Attribute objects with not equal priorities
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert (attr1 <= attr2) == True, fail_msg


# Generated at 2022-06-23 05:48:34.861631
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    return a.__gt__(b)


# Generated at 2022-06-23 05:48:38.199149
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()
    attr.priority = 10
    other = Attribute()
    other.priority = 5

    assert attr > other



# Generated at 2022-06-23 05:48:39.665486
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(default='test', priority=0) != Attribute(default='test', priority=1)


# Generated at 2022-06-23 05:48:41.321309
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert isinstance(f, FieldAttribute)


# Generated at 2022-06-23 05:48:46.606593
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert attr1 >= attr2
    assert attr2 <= attr1
    assert not attr2 >= attr1
    assert not attr1 <= attr2



# Generated at 2022-06-23 05:48:51.082625
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """ test the __ge__ method of class Attribute """
    class C(object):
        attr = FieldAttribute(priority=1)

    class D(object):
        attr = FieldAttribute(priority=2)

    assert C.attr >= D.attr



# Generated at 2022-06-23 05:48:59.469415
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    checked_obj = Attribute()
    other_obj = Attribute()

    # If the two objects have the same priority, then it returns false
    other_obj.priority = 0
    checked_obj.priority = 0

    result = checked_obj.__ne__(other_obj)
    assert result == False, "__ne__ returned incorrect result: {0!s}".format(result)

    # If the two objects have different priority, then it returns true
    other_obj.priority = 0
    checked_obj.priority = 1

    result = checked_obj.__ne__(other_obj)
    assert result == True, "__ne__ returned incorrect result: {0!s}".format(result)


# Generated at 2022-06-23 05:49:01.990022
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute(priority=1)
    assert a != b, 'Assert not passed'


# Generated at 2022-06-23 05:49:05.069229
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr2.priority = 10
    assert attr1.__ge__(attr2)


# Generated at 2022-06-23 05:49:09.825999
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=5)
    assert attr1 == attr2
    attr3 = Attribute(priority=6)
    assert attr1 != attr3


# Generated at 2022-06-23 05:49:13.563018
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    x = Attribute()
    assert x == x
    assert x != "not the same"
    assert x != None
    assert x != []


# Generated at 2022-06-23 05:49:16.690398
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Given
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2

    # When
    result = attr1 > attr2

    # Then
    assert result == False


# Generated at 2022-06-23 05:49:18.720788
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    ansible.utils.unit.unit_test_fieldattribute(Attribute)

# end of file

# Generated at 2022-06-23 05:49:23.498886
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 1
    attr2.priority = 2
    assert attr2.__gt__(attr1) == True


# Generated at 2022-06-23 05:49:25.576669
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Fail: will raise TypeError since default is mutable
    attribute = FieldAttribute(default={'foo': 'bar'})
    pass



# Generated at 2022-06-23 05:49:31.961018
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    class a:
        def __init__(self, priority):
            self.priority = priority
    assert(Attribute(priority=1) < a(priority=42)) is True
    assert(Attribute(priority=42) < a(priority=1)) is False
    assert(Attribute(priority=1) < a(priority=1)) is False
    assert(Attribute(priority=1) < a(priority=2)) is True
    assert(Attribute(priority=1) < a(priority=1)) is False
    assert(Attribute(priority=2) < a(priority=1)) is False

# Generated at 2022-06-23 05:49:40.049165
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """
    This test checks if the method __ne__ of class Attribute works as expected
    """
    a = Attribute()
    b = Attribute()

    if a is not b:
        if a == b:
            print("Unit test failed: Attribute class __ne__ failed")
        else:
            print("Unit test passed: Attribute class __ne__ passed")
    else:
        print("Unit test failed: Attribute class __ne__ failed")

# Generated at 2022-06-23 05:49:46.539575
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=42, required=False, listof='unicode', static=True)
    assert attr.isa == 'int'
    assert attr.default == 42
    assert attr.required == False
    assert attr.listof == 'unicode'
    assert attr.static == True

# Generated at 2022-06-23 05:49:57.279332
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0,
                     class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False,
                     static=False)
    eq_attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0,
                        class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                        prepend=False, static=False)
    assert attr == eq_attr



# Generated at 2022-06-23 05:50:00.107541
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa=5)
    b = Attribute(isa=6)

    assert(a == b)



# Generated at 2022-06-23 05:50:11.030774
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        default=[],
        always_post_validate=True,
        isa=list,
        inherit=True,
        alias='foo_bar',
        private=False,
        class_type=list,
        required=False,
        listof=str,
        priority=0,
        static=False
    )
    assert attr.default == []
    assert attr.always_post_validate == True
    assert attr.isa == list
    assert attr.inherit == True
    assert attr.alias == 'foo_bar'
    assert attr.private == False
    assert attr.class_type == list
    assert attr.required == False
    assert attr.listof == str
    assert attr.priority == 0
    assert attr.static == False



# Generated at 2022-06-23 05:50:18.099339
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    print('Test __gt__ of class Attribute')
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    print(a1.__gt__(a2))


# Generated at 2022-06-23 05:50:21.668147
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(isa='list', default=[])
    b = Attribute(isa='list', default=[])
    c = Attribute(isa='list', default=[])
    assert a < b and b < c and a < c


# Generated at 2022-06-23 05:50:22.741611
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a1 != a2


# Generated at 2022-06-23 05:50:25.263566
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    assert a <= b

# Generated at 2022-06-23 05:50:29.516682
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=20)
    assert a2 > a1

# Generated at 2022-06-23 05:50:31.765243
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b.__gt__(a)

# Generated at 2022-06-23 05:50:42.302950
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    a3 = Attribute(priority=1)
    a4 = Attribute(priority=2)

    assert a1.__ge__(a2)
    assert a2.__ge__(a1)
    assert a1.__ge__(a1)
    assert a2.__ge__(a2)

    assert not a1.__ge__(a3)
    assert not a1.__ge__(a4)

    assert a3.__ge__(a1)
    assert a4.__ge__(a1)

    assert a3.__ge__(a3)
    assert a4.__ge__(a4)

    assert not a3.__ge__(a4)

# Generated at 2022-06-23 05:50:53.587801
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Standard attributes for FieldAttribute
    TestFieldAttribute = FieldAttribute()
    TestFieldAttribute2 = FieldAttribute(isa='list', private=True, default=[], required=False,
                                    listof=None, priority=100, class_type=None, always_post_validate=True,
                                    inherit=False, alias=None)
    TestFieldAttribute3 = FieldAttribute(isa=dict, private=False, default={}, required=True,
                                    listof=int, priority=10, class_type=None, always_post_validate=False,
                                    inherit=True, alias='al')

# Generated at 2022-06-23 05:50:58.173385
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=1)

    result = a1 < a2

    assert result is True


# Generated at 2022-06-23 05:51:02.471601
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=0) <= Attribute(priority=0)
    assert Attribute(priority=1) <= Attribute(priority=0)
    assert not Attribute(priority=0) <= Attribute(priority=1)


# Generated at 2022-06-23 05:51:05.153258
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute()
    attribute2 = Attribute()
    attribute2.priority = 10

    assert attribute1.__gt__(attribute2)
    assert not attribute2.__gt__(attribute1)


# Generated at 2022-06-23 05:51:09.217209
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f=FieldAttribute(isa="list", listof="integer")
    assert f is not None


# Generated at 2022-06-23 05:51:10.382132
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a != b

# Generated at 2022-06-23 05:51:18.474916
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    """Test case 1"""
    print("Test case 1")
    print("Input values:")
    print("a.priority = ", a.priority)
    print("b.priority = ", b.priority)
    # Expected result: True
    expected_result = True
    # Call function
    result = a.__gt__(b)
    print("Return value:")
    print(result)
    # Test case passed or failed
    if result == expected_result:
        print("PASSED")
    else:
        print("FAILED")
    print("\n")
    # Expected result: False
    expected_result = False
    # Call function
    result = b.__gt__(a)
   

# Generated at 2022-06-23 05:51:23.049832
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert((a1 < a2) and (a1 < a3))
    assert((a2 < a3) and (not a3 < a2))



# Generated at 2022-06-23 05:51:28.262217
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_a = Attribute(priority=1)
    attr_b = Attribute(priority=1)
    attr_c = Attribute(priority=2)
    attr_d = Attribute(priority=0)
    assert attr_a.__ge__(attr_b)
    assert attr_a.__ge__(attr_c)
    assert attr_b.__ge__(attr_c)
    assert not attr_a.__ge__(attr_d)
    assert not attr_b.__ge__(attr_d)
    assert attr_c.__ge__(attr_d)

# Generated at 2022-06-23 05:51:33.601956
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert not (a1 == a2)
    a2.priority = a1.priority = 0
    assert a1 == a2
    a2.priority = 1
    assert a1 != a2


# Tests for Attribute class

# Generated at 2022-06-23 05:51:37.201357
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    assert a == b
    b.priority = 1
    assert a != b
    assert a < b
    assert a <= b
    assert b > a
    assert b >= a

# Generated at 2022-06-23 05:51:45.924067
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print("\nIn function test_Attribute___ne__")
    atrb1 = Attribute(priority=0)
    atrb2 = Attribute(priority=9)
    if atrb1.__ne__(atrb2):
        print("TEST CASE: test_Attribute___ne__(True): PASSED")
    else:
        print("TEST CASE: test_Attribute___ne__(True): FAILED")
    if not atrb1.__ne__(atrb1):
        print("TEST CASE: test_Attribute___ne__(False): PASSED")
    else:
        print("TEST CASE: test_Attribute___ne__(False): FAILED")


# Generated at 2022-06-23 05:51:47.822415
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    f1 = FieldAttribute(priority=1)
    f2 = FieldAttribute(priority=2)

    assert f2 > f1

# Generated at 2022-06-23 05:51:54.403682
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert not a.__gt__(b)
    assert not a.__ge__(b)
    assert b.__gt__(a)
    assert b.__ge__(a)
    assert not a.__lt__(b)
    assert not a.__le__(b)
    assert b.__lt__(a)
    assert b.__le__(a)
    assert not a.__eq__(b)
    assert b.__eq__(a)
    assert not a.__ne__(b)
    assert b.__ne__(a)


# Generated at 2022-06-23 05:51:57.040271
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    return a.__ge__(b)



# Generated at 2022-06-23 05:52:00.889086
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=-1)

    assert attribute2 <= attribute1
    assert not attribute1 <= attribute2

    try:
        attribute2 <= 1
        assert False
    except:
        assert True

# Generated at 2022-06-23 05:52:09.764240
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute("dict", True, None, True, None, 0, None, False, True, "attr_alias", False, False, False).private == True
    assert FieldAttribute("dict", False, None, False, None, 1, None, True, True, "attr_alias", False, False, False).private == False
    assert FieldAttribute("dict", False, None, False, None, 2, None, False, True, "attr_alias", True, False, False).always_post_validate == True
    assert FieldAttribute("dict", False, None, False, None, 3, None, False, True, "attr_alias", False, True, False).extend == True
    assert FieldAttribute("dict", False, None, False, None, 4, None, False, True, "attr_alias", False, False, True).prepend == True

#

# Generated at 2022-06-23 05:52:18.175165
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    if a1 > a2:
        raise Exception('Expected a1 <= a2, but it isnt')
    if a1 < a2:
        raise Exception('Expected a2 > a1, but it isnt')
    if a1 == a2:
        raise Exception('Expected a1 != a2, but it isnt')
    if a1 >= a2:
        raise Exception('Expected a1 < a2, but it isnt')
    if a2 <= a1:
        raise Exception('Expected a2 > a1, but it isnt')
