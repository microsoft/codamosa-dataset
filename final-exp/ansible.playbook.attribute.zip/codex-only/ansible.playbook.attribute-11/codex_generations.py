

# Generated at 2022-06-23 05:42:27.008799
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute(default=None, required=False, priority=0, alias=None)
    attribute2 = Attribute(default=None, required=False, priority=0, alias=None)
    assert attribute == attribute2


# Generated at 2022-06-23 05:42:31.198077
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert True == (Attribute() <= Attribute())
    assert False == (Attribute(priority=1) <= Attribute(priority=2))
    assert True == (Attribute(priority=2) <= Attribute(priority=2))
    assert False == (Attribute(priority=2) <= Attribute(priority=1))
    assert False == (Attribute(priority=2) <= Attribute(priority=None))


# Generated at 2022-06-23 05:42:33.553585
# Unit test for constructor of class Attribute
def test_Attribute():
    assert FieldAttribute().priority == 0
    assert FieldAttribute(priority=7).priority == 7
    assert FieldAttribute(required=True).required == True

# Generated at 2022-06-23 05:42:38.319371
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa='dict')
    assert attr.isa == 'dict'
    attr = Attribute(isa='dict', required=True)
    assert attr.isa == 'dict'
    assert attr.required == True
    attr = Attribute(isa='dict', private=True)
    assert attr.isa == 'dict'
    assert attr.private == True



# Generated at 2022-06-23 05:42:43.790276
# Unit test for constructor of class Attribute
def test_Attribute():

    fields = dict(
        name='foo', isa='dict', private=False,
        default=lambda: dict(), required=False, listof=None, priority=0,
        class_type=None, always_post_validate=False, inherit=False,
        alias=None, extend=False, prepend=False, static=False,
    )

    sut = Attribute(**fields)
    for k, v in fields.items():
        assert getattr(sut, k) == v



# Generated at 2022-06-23 05:42:45.844364
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2


# Generated at 2022-06-23 05:42:53.897070
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test attribute with higher priority
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert attr1 >= attr2
    # Test attribute with lower priority
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert not attr1 >= attr2
    # Test attribute with same priority
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert attr1 >= attr2


# Generated at 2022-06-23 05:42:57.877213
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    test_Attribute___lt__: test_Attribute___lt__
    '''
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    attr1 = Attribute(priority=3)
    attr2 = Attribute(priority=3)
    assert attr1 >= attr2



# Generated at 2022-06-23 05:43:02.119766
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    attr2 = Attribute()
    assert attr == attr2

    attr.priority = 1
    assert attr != attr2


# Generated at 2022-06-23 05:43:05.433750
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    fielda = FieldAttribute(priority=3)
    fieldb = FieldAttribute(priority=2)
    assert fielda.__gt__(fieldb) == True



# Generated at 2022-06-23 05:43:08.728506
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    standard_attribute = Attribute(priority = 10)

    try:
        standard_attribute.priority = 11
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-23 05:43:10.597378
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa == None

# Generated at 2022-06-23 05:43:16.230553
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1

    b = Attribute()
    b.priority = 2

    assert(b.__gt__(a) == True)
    assert(a.__gt__(b) == False)
    assert(a.__gt__(a) == False)


# Generated at 2022-06-23 05:43:18.026150
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a != b)



# Generated at 2022-06-23 05:43:20.351485
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=1)

    assert a.__ge__(b)



# Generated at 2022-06-23 05:43:23.189494
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='string')
    assert fa.isa == 'string'

# A subclass, for easier backwards compatibility

# Generated at 2022-06-23 05:43:29.971830
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=0)
    attribute3 = Attribute(priority=1)
    assert(attribute1 < attribute3)
    assert(attribute3 > attribute2)
    assert(attribute1 == attribute2)
    assert(attribute1 == attribute1)
    assert(attribute1 <= attribute1)
    assert(attribute1 >= attribute1)


# Generated at 2022-06-23 05:43:34.536815
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', inherit=True, required=True, default=None)
    assert attr.isa == 'str'
    assert attr.inherit
    assert attr.required
    assert attr.default is None



# Generated at 2022-06-23 05:43:41.290675
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    b1 = FieldAttribute(priority=1)
    b2 = FieldAttribute(priority=2)
    b3 = FieldAttribute(priority=3)
    assert not b1 == b2
    assert b1 < b2
    assert b3 > b2
    assert b1 <= b2
    assert b2 <= b2
    assert b3 >= b2



# Generated at 2022-06-23 05:43:46.266684
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(1,1,1,1,1,1,1,1,1)
    b = Attribute(2,2,2,2,2,2,2,2,2)
    c = TypeError
    assert a.__gt__(b) == c

# Generated at 2022-06-23 05:43:48.854354
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(alias='test_ge', priority=0)
    assert (attribute >= attribute) == True


# Generated at 2022-06-23 05:43:51.226002
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=10)
    attribute2 = Attribute(priority=11)
    assert attribute2.__ge__(attribute1) == True


# Generated at 2022-06-23 05:43:52.430832
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert not FieldAttribute() <= FieldAttribute()



# Generated at 2022-06-23 05:44:00.128411
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='dict', default=dict, required=True)
    assert a.isa == 'dict'
    assert callable(a.default) is True
    b = FieldAttribute(isa='dict', private=True, default=dict, required=True)
    assert b.private is True
    c = FieldAttribute(isa='dict', default=dict, required=False)
    assert c.required is False
    d = FieldAttribute(isa='list', default=list, listof='int', required=True)
    assert d.listof == 'int'

# Generated at 2022-06-23 05:44:04.304347
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    stmt1 = Attribute(priority=1)
    stmt2 = Attribute(priority=2)

    assert stmt1.__le__(stmt2)
    assert not stmt2.__le__(stmt1)



# Generated at 2022-06-23 05:44:11.342701
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=3)

    assert not a1.__gt__(a2)
    assert a2.__gt__(a1)



# Generated at 2022-06-23 05:44:15.949418
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='class', inherit=False, required=True, listof='class', class_type='class')
    assert a.isa == 'class'
    assert a.inherit == False
    assert a.required == True
    assert a.listof == 'class'
    assert a.class_type == 'class'


# Generated at 2022-06-23 05:44:18.486570
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert(Attribute(priority = 5) == Attribute(priority = 5))


# Generated at 2022-06-23 05:44:29.297073
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # test initialization with no parameters
    a = FieldAttribute()
    # set some attributes to check that they are accessible
    a.isa = 'one'
    a.private = 'two'
    a.default = 'three'
    a.required = 'four'
    a.listof = 'five'
    a.priority = 'six'
    a.class_type = 'seven'
    a.always_post_validate = 'eight'
    a.inherit = 'nine'
    a.alias = 'ten'
    a.extend = 'eleven'
    a.prepend = 'twelve'
    a.static = 'thirteen'
    # test that we can access the attributes we just set
    assert a.isa == 'one'
    assert a.private == 'two'

# Generated at 2022-06-23 05:44:34.122961
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=2)

    assert a3 > a2 > a1
    assert a1 <= a2 <= a3
    assert a3 != a2
    assert a3 != a1
    assert a2 != a1



# Generated at 2022-06-23 05:44:36.674732
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(private=False,priority=1)
    b = Attribute(private=False,priority=2)
    assert b < a

# Generated at 2022-06-23 05:44:38.881252
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 < attr2


# Generated at 2022-06-23 05:44:43.432761
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # test data
    attribute = Attribute()
    result = True
    other = Attribute(priority=0)
    attribute.priority = 0
    # target of test
    result = attribute.__le__(other)
    # check result
    assert result is True


# Generated at 2022-06-23 05:44:47.106700
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from collections import OrderedDict
    a = Attribute()
    a.priority = 0
    data = OrderedDict()
    data['priority'] = 1
    res = a.__gt__(data)
    assert res is False


# Generated at 2022-06-23 05:44:51.331005
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class A(Attribute):
        def __init__(self, priority):
            super().__init__(priority=priority)
    assert A.__ge__(A(5), A(5))
    assert A.__ge__(A(5), A(4))
    assert not A.__ge__(A(4), A(5))

# Generated at 2022-06-23 05:45:02.134788
# Unit test for constructor of class Attribute
def test_Attribute():

    fields_to_test = {
        'isa': ['string', 'list', 'dict', 'int', 'float', 'bool', 'None'],
        'private' : [True, False],
        'default': [None],
        'required': [True, False],
        'listof': [None, 'str', 'int', 'bool'],
        'priority': [0],
        'class_type': [None],
        'always_post_validate': [True, False],
        'inherit': [True, False],
        'alias': [None],
        'extend': [True, False],
        'prepend': [True, False],
        'static': [True, False],
    }
    test_count = 0

# Generated at 2022-06-23 05:45:04.073144
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert(Attribute(priority=5) >= Attribute(priority=5))


# Generated at 2022-06-23 05:45:13.835702
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert not a.private
    assert a.default is None
    assert not a.required
    assert a.isa is None
    assert a.listof is None
    assert a.priority == 0
    assert a.inherit
    assert a.alias is None

    def zee_default():
        return "zee_default"
    a = Attribute(isa='list', private=False, default=zee_default,
                  required=True, listof='list', priority=99, class_type=None,
                  inherit=False, alias='zee_alias')
    assert a.private == False
    assert a.default == zee_default
    assert a.required == True
    assert a.isa == 'list'
    assert a.listof == 'list'
    assert a.priority == 99
    assert a

# Generated at 2022-06-23 05:45:17.984344
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert compare(Attribute(priority=1), Attribute(priority=2)) == -1
    assert compare(Attribute(priority=2), Attribute(priority=1)) == 1
    assert compare(Attribute(priority=2), Attribute(priority=2)) == 0



# Generated at 2022-06-23 05:45:20.971338
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert (a > b) is True
    assert (b > a) is False


# Generated at 2022-06-23 05:45:22.967034
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) < Attribute(priority=2) == True


# Generated at 2022-06-23 05:45:26.714565
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    '''
    This unit test tests the method __gt__ of class Attribute
    '''
    # The unit test is passed if the method is correct
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2 > attr1

# Generated at 2022-06-23 05:45:34.699114
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa=1, private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False)
    attr2 = Attribute(isa=2, private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False)
    assert(attr1 == attr2)


# Generated at 2022-06-23 05:45:36.679543
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a < b


# Generated at 2022-06-23 05:45:39.833312
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__ge__(a2) == False
    assert a2.__ge__(a1) == True

# Generated at 2022-06-23 05:45:44.226453
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)

    assert a1 < a2
    assert a2 >= a1
    assert a1 <= a2
    assert a2 > a1
    assert a1 != a2
    assert a2 == a2



# Generated at 2022-06-23 05:45:49.521960
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=1) >= Attribute(priority=1) # should return True
    assert Attribute(priority=3) >= Attribute(priority=1) # should return True
    assert Attribute(priority=1) >= Attribute(priority=2) # should return False


# Generated at 2022-06-23 05:45:51.927828
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='str')
    assert (a.isa == 'str' and a.default == 'str')

# Generated at 2022-06-23 05:45:52.485488
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    pass


# Generated at 2022-06-23 05:45:55.144470
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute()
    try:
        Attribute(default={})
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 05:46:05.032982
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa="class", class_type="local")
    assert attr.isa == "class"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == "local"
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    attr = FieldAttribute(isa="class", class_type="local", priority=1)
    assert attr.isa == "class"
    assert attr.private == False
    assert attr.default

# Generated at 2022-06-23 05:46:14.658826
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Check normal case
    attr1 = Attribute(default=10, priority=0)
    attr2 = Attribute(default=10, priority=1)
    assert attr2 >= attr1

    # Check equal case
    attr1 = Attribute(default=10, priority=0)
    attr2 = Attribute(default=10, priority=0)
    assert attr2 >= attr1

    # Check abnormal case
    attr1 = Attribute(default=10, priority=0)
    attr2 = Attribute(default=10, priority=1)
    assert not attr1 >= attr2



# Generated at 2022-06-23 05:46:20.244554
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False)


# Generated at 2022-06-23 05:46:27.475074
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Basic test for the Attribute constructor.
    """
    a = Attribute(isa='str', private=True, default='SomeDefault')
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'SomeDefault'

# Generated at 2022-06-23 05:46:30.265872
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a < b)
    assert(b > a)



# Generated at 2022-06-23 05:46:37.524786
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute()
    attribute.priority = 10
    other = Attribute()
    other.priority = 20
    assert attribute >= other, "Attribute priority >= other priority"
    assert not attribute <= other, "not attribute priority >= other priority"
    attribute.priority = 20
    assert attribute >= other, "Attribute priority >= other priority"
    assert attribute <= other, "Attribute priority >= other priority"
    attribute.priority = 10
    other.priority = 10
    assert attribute >= other, "Attribute priority >= other priority"
    assert attribute <= other, "Attribute priority >= other priority"


# Generated at 2022-06-23 05:46:41.710430
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_obj = Attribute()
    attr_obj.priority = 1
    attr_obj2 = Attribute()
    attr_obj2.priority = 0
    assert (attr_obj >= attr_obj2) == True


# Generated at 2022-06-23 05:46:44.414828
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    c = Attribute(priority=3)
    assert a < b
    assert b >= c

# Generated at 2022-06-23 05:46:52.397397
# Unit test for constructor of class Attribute
def test_Attribute():
    # empty constructor
    a = Attribute()
    assert (a.isa is None)
    assert (a.private is False)
    assert (a.default is None)
    assert (a.required is False)
    assert (a.listof is None)
    assert (a.priority == 0)
    assert (a.class_type is None)
    assert (a.always_post_validate is False)
    assert (a.inherit is True)
    assert (a.alias is None)

    # constructor with all values
    a = Attribute(True, True, True, True, True, 1, True, True, False, True)
    assert (a.isa is True)
    assert (a.private is True)
    assert (a.default is True)
    assert (a.required is True)

# Generated at 2022-06-23 05:47:00.157513
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert isinstance(fa, Attribute)
    assert fa.isa is None
    assert fa.private == False
    assert fa.default is None
    assert fa.required == False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias is None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

# Generated at 2022-06-23 05:47:05.653133
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

# Generated at 2022-06-23 05:47:07.086083
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attrib = Attribute()
    assert not (attrib == None)


# Generated at 2022-06-23 05:47:09.607788
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    class AttributeUnitTest:
        def __init__(self, priority):
            self.priority = priority

    gt = Attribute(priority=10) > AttributeUnitTest(priority=5)
    assert True == gt



# Generated at 2022-06-23 05:47:13.402332
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a == b
    b = Attribute(priority=1)
    assert not a == b


# Generated at 2022-06-23 05:47:15.884747
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_Attribute = Attribute()
    assert test_Attribute.__ne__(Attribute()) is False, "the Attribute __ne__() method is not working as expected"


# Generated at 2022-06-23 05:47:18.731431
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=3)
    b = Attribute(priority=2)

    assert(b < a)



# Generated at 2022-06-23 05:47:24.913608
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestClass(AnsibleBaseYAMLObject):
        fields = {'one': FieldAttribute(priority=1)}
        _inherits = []
    a = Attribute(priority=2)
    b = FieldAttribute(priority=1)
    assert (a != b) is True
    assert (a != b) is not None


# Generated at 2022-06-23 05:47:27.812713
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()

    attr.priority = 0
    assert attr.__gt__(Attribute(priority = 0)) == False

    attr.priority = 1
    assert attr.__gt__(Attribute(priority = 0)) == True

# Generated at 2022-06-23 05:47:32.641334
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    :func:`test_Attribute___lt__` checks method __lt__ of class `Attribute`
    """
    a1 = Attribute(priority = 80)
    a2 = Attribute(priority = 70)
    assert a1 > a2
    assert a1 >= a2



# Generated at 2022-06-23 05:47:41.898459
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    #__le__ is equal or less than with proper Attribute objects
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1.__le__(a2)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=0)
    assert a1.__le__(a2)
    assert not a2.__le__(a1)

    #__le__ is equal or less than with Attribute and other objects
    a = Attribute(priority=0)
    assert a.__le__(None)
    assert a.__le__(0)
    assert a.__le__('test_string')
    assert a.__le__(u'test_string')
    assert not a.__le__(True)

# Generated at 2022-06-23 05:47:44.528260
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute();
    a.priority = 1
    b = Attribute();
    b.priority = 2
    assert a <= b == True
    assert a >= b == False

# Generated at 2022-06-23 05:47:45.548285
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute


# Generated at 2022-06-23 05:47:49.150124
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert not (Attribute() != Attribute())
    assert not (Attribute(priority=1) != Attribute(priority=1))

    assert Attribute() != Attribute(priority=1)
    assert Attribute(priority=1) != Attribute()



# Generated at 2022-06-23 05:47:52.317457
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=2)
    assert a != b
    assert b != c
    assert c != a

# Generated at 2022-06-23 05:47:55.557810
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert(attr2 < attr1)


# Generated at 2022-06-23 05:48:03.037888
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Create field attribute
    fld_attr = Attribute(priority=3)
    # Test if field attribute is less than or equal to itself
    assert fld_attr <= fld_attr
    # Test if field attribute is less than or equal to another field attribute
    # which has a priority less than the original field attribute.
    assert fld_attr <= Attribute(priority=2)
    # Test if field attribute is less than or equal to another field attribute
    # which has a priority greater than the original field attribute.
    assert not fld_attr <= Attribute(priority=4)


# Generated at 2022-06-23 05:48:05.457203
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert(attr1.__eq__(attr2))


# Generated at 2022-06-23 05:48:09.351967
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert not a1 > a2
    assert not a1 == a2


# Generated at 2022-06-23 05:48:14.061659
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(isa='list', required=True, priority=1)
    attr2 = Attribute(isa='list', priority=2)

    assert attr2 <= attr

    attr = Attribute(isa='list', required=True, priority=1)
    attr2 = Attribute(isa='list', priority=1)

    assert attr2 <= attr



# Generated at 2022-06-23 05:48:17.488947
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    x = Attribute()
    y = Attribute(priority=1)
    assert x > y
    y.priority = -1
    assert x < y
    assert x == y


# Generated at 2022-06-23 05:48:19.699178
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a<b


# Generated at 2022-06-23 05:48:31.600235
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Set up
    name = "name"
    isa = "dict"
    private = True
    default = {}
    required = True
    listof = "dict"
    priority = 0
    class_type = "dict"
    always_post_validate = False
    inherit = True
    alias = "my_alias"
    extend = False
    prepend = False
    static = False
    attribute = FieldAttribute(isa=isa, private=private, default=default,
                               required=required, listof=listof, priority=priority,
                               class_type=class_type, always_post_validate=always_post_validate,
                               inherit=inherit, alias=alias, extend=extend, prepend=prepend,
                               static=static)

    # Test

# Generated at 2022-06-23 05:48:43.002139
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa='int', private=False, default=1, required=False, listof=None, priority=0,
                        class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    if obj.isa != 'int':
        raise AssertionError("isa is int, not %s" % obj.isa)
    if obj.private != False:
        raise AssertionError("private is False, not %s" % obj.private)
    if obj.default != 1:
        raise AssertionError("default is 1, not %s" % obj.default)
    if obj.required != False:
        raise AssertionError("required is False, not %s" % obj.required)

# Generated at 2022-06-23 05:48:45.771766
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    obj = Attribute(priority = 1)
    obj2 = Attribute(priority = 2)
    obj > obj2

# Generated at 2022-06-23 05:48:49.856745
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    a.priority = 2
    b.priority = 11
    assert (b <= a)
    assert not (a <= b)


# Generated at 2022-06-23 05:48:58.517043
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='bool', private=True, default=False, required=False,
                           listof='some type', priority=0, class_type='class type',
                           always_post_validate=False, inherit=True, alias='some alias')

    assert field.isa == 'bool'
    assert field.private == True
    assert field.default == False
    assert field.required == False
    assert field.listof == 'some type'
    assert field.priority == 0
    assert field.class_type == 'class type'
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == 'some alias'


# Generated at 2022-06-23 05:49:05.416830
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list')
    assert(isinstance(fa, FieldAttribute))
    assert(fa.isa == 'list')
    assert(fa.private == False)
    assert(fa.default == None)
    assert(fa.required == False)
    assert(fa.listof == None)
    assert(fa.priority == 0)
    assert(fa.class_type == None)
    assert(fa.always_post_validate == False)
    assert(fa.inherit == True)
    assert(fa.alias == None)
    assert(fa.extend == False)
    assert(fa.prepend == False)
    assert(fa.static == False)


# Generated at 2022-06-23 05:49:12.137329
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test parameterized constructor
    isa = "dict";
    private = False;
    default = None;
    required = False;
    listof = None;
    priority = 0;
    class_type = None;
    always_post_validate = False;
    inherit = True;
    alias = None;
    extend = False;
    prepend = False;
    static = False;
    att1 = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    # Test calling instance method
    result = att1.__le__(att1)

    # Test expected result
    assert(result == True)


# Generated at 2022-06-23 05:49:13.350724
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    pass


# Generated at 2022-06-23 05:49:23.112967
# Unit test for constructor of class Attribute
def test_Attribute():
    kwargs = {
        'isa': 'str',
        'required': True,
        'static': True,
        'prepend': True,
        'extend': True,
        'alias': 'foo',
        'inherit': False,
        'always_post_validate': False,
        'class_type': 'bar',
        'listof': False,
        'private': True,
        'default': 123,
        'priority': 0
    }

    a = Attribute(**kwargs)

    for k, v in kwargs.items():
        assert getattr(a, k) == v

# Generated at 2022-06-23 05:49:23.840912
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    pass



# Generated at 2022-06-23 05:49:27.014531
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr_2 = Attribute()
    attr_2.priority = 1
    assert attr_2 != attr
    attr.priority = 1
    assert attr != attr_2



# Generated at 2022-06-23 05:49:36.282972
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    cls_dict = {
        '__init__': lambda self, *args, **kwargs: Attribute.__init__(self, *args, **kwargs),
        '_Attribute__le__': Attribute.__le__,
    }
    AttributeSubclass = type('AttributeSubclass', (Attribute,), cls_dict)

    a = AttributeSubclass(priority=2)
    b = AttributeSubclass(priority=1)

    assert(a.__le__(b) == False)
    assert(b.__le__(a) == True)
    assert(a.__le__(a) == True)
    assert(b.__le__(b) == True)

# Generated at 2022-06-23 05:49:40.546009
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    attribute_obj = Attribute(isa='str', default='0.0.0.0', required=True, listof='str')
    assert attribute_obj.isa == 'str'
    assert attribute_obj.default == '0.0.0.0'
    assert attribute_obj.required == True
    assert attribute_obj.listof == 'str'
    '''
    pass

# Generated at 2022-06-23 05:49:45.129946
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__ge__(attr2) == False
    assert attr2.__ge__(attr1) == True


# Generated at 2022-06-23 05:49:56.437763
# Unit test for constructor of class Attribute
def test_Attribute():
    import copy
    import pickle
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    attr = Attribute(
        isa='int',
        private=False,
        default='hello',
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert attr.isa == 'int'
    assert attr.private == False
    assert attr.default == 'hello'

# Generated at 2022-06-23 05:50:01.583534
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=10)
    attr3 = Attribute(priority=5)
    assert attr1 <= attr2
    assert attr1 >= attr2
    assert attr3 <= attr1
    assert attr3 <= attr2
    assert attr3 < attr1
    assert attr3 < attr2

# Generated at 2022-06-23 05:50:05.062239
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    assert not attribute.__ne__(0)


# Generated at 2022-06-23 05:50:10.489380
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    if a.__ge__(b):
        # print("Test_Attribute.__ge__: True")
        assert True
    else:
        # print("Test_Attribute.__ge__: False")
        assert False

test_Attribute___ge__()



# Generated at 2022-06-23 05:50:17.042524
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()

    other_attr = Attribute()
    assert attr != other_attr

    other_attr = Attribute(priority=1)
    assert attr != other_attr



# Generated at 2022-06-23 05:50:24.187855
# Unit test for constructor of class Attribute
def test_Attribute():
    # Change the value of inheritable field 'inherit' to True and make sure that
    # the 'default' field is set to a callable.
    attr = FieldAttribute(inherit=True, default='foo')
    assert attr.default() == 'foo'

    # Make sure that passing a non-callable to the 'default' field raises an error
    # when the 'inherit' field is set to True
    try:
        attr = FieldAttribute(inherit=True, default=[])
        raise ValueError('This should not succeed')
    except:
        pass

    # Make sure that passing a non-callable to the 'default' field does not raise
    # an error when the 'inherit' field is set to False
    attr = FieldAttribute(inherit=False, default=[])
    assert att

# Generated at 2022-06-23 05:50:27.391376
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=0)
    att2 = Attribute(priority=1)
    assert att1 < att2
    assert not att2 < att1
    assert not att2 < att2



# Generated at 2022-06-23 05:50:31.172279
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    >>> foo = Attribute(isa='str')
    >>> foo.isa
    'str'
    >>> foo = Attribute(isa='str', required=True)
    >>> foo.isa
    'str'
    >>> foo.required
    True
    """


# Generated at 2022-06-23 05:50:35.212172
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2

    assert a.__ge__(b) is True
    assert b.__ge__(a) is False



# Generated at 2022-06-23 05:50:39.494098
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute(isa='string', default='something', required=True, inherit=False)
    assert attribute is not None
    assert attribute.isa == 'string'
    assert attribute.default == 'something'
    assert attribute.required == True
    assert attribute.inherit == False


# Generated at 2022-06-23 05:50:43.692184
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()
    attr.priority = 3

    attr2 = Attribute()
    attr2.priority = 2

    assert attr2 < attr
    assert attr > attr2
    assert attr >= attr2
    assert attr2 <= attr
    assert not attr2 == attr
    assert attr2 != attr


# Generated at 2022-06-23 05:50:49.452816
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(isa=None, private=False, default=None,
                   required=False, listof=None, priority=0,
                   class_type=None, always_post_validate=False,
                   inherit=True, alias=None, extend=False,
                   prepend=False, static=False)
    a2 = Attribute(isa=None, private=False, default=None,
                   required=False, listof=None, priority=0,
                   class_type=None, always_post_validate=False,
                   inherit=True, alias=None, extend=False,
                   prepend=False, static=False)
    assert a1.__ne__(a2), '__ne__ return value is wrong!'


# Generated at 2022-06-23 05:50:52.105585
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a < a1


# Generated at 2022-06-23 05:51:04.203574
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Should be True for:
    # Priority of object 1 is higher (less) than object 2
    object1 = Attribute(priority = 0)
    object2 = Attribute(priority = 1)
    if object1.__ne__(object2) != True:
        raise Exception("object1.__ne__(object2) should be true")
    # Priority of object 1 is equal to object 2
    object1 = Attribute(priority = 1)
    object2 = Attribute(priority = 1)
    if object1.__ne__(object2) != True:
        raise Exception("object1.__ne__(object2) should be true")
    # Should be False for:
    # Priority of object 1 is lower (higher) than object 2
    object1 = Attribute(priority = 1)
    object2 = Attribute(priority = 0)

# Generated at 2022-06-23 05:51:10.457483
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test a > b
    a = Attribute(priority=300)
    b = Attribute(priority=200)
    assert a.__gt__(b) == True
    # Test a > a
    assert a.__gt__(a) == False
    # Test b > a
    assert b.__gt__(a) == False

# Generated at 2022-06-23 05:51:18.273986
# Unit test for constructor of class Attribute
def test_Attribute():
    def validate_isa(isa, message):
        try:
            attribute = Attribute(isa=isa)
        except:
            assert True
        else:
            assert False, message

    def validate_default(default, message):
        try:
            attribute = Attribute(default=default)
        except:
            assert True
        else:
            assert False, message

    # isa is only checked at post-validation time

    # listof can only be set if isa is set to "list"
    validate_isa('list', 'listof can only be set if isa is set to "list"')

    # If a default is set, it must be a callable
    validate_default([], 'If a default is set, it must be a callable, not a mutable')

# Generated at 2022-06-23 05:51:22.576863
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # setup test environment
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    # assert method __ne__
    assert attr1.__ne__(attr2) == True
    assert attr2.__ne__(attr1) == False


# Generated at 2022-06-23 05:51:27.362650
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    # test a1 <= a2
    if not a1 <= a2:
        raise AssertionError('Attribute a1 <= a2 test failed.')
    # test a2 <= a2
    if not a2 <= a2:
        raise AssertionError('Attribute a2 <= a2 test failed.')

# Generated at 2022-06-23 05:51:32.952931
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr_1 = Attribute(4)
    attr_2 = Attribute(4)
    attr_3 = Attribute(5)

    assert attr_1 == attr_2
    assert not attr_3 == attr_1


# Generated at 2022-06-23 05:51:35.050137
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1.__ge__(a2)

# Generated at 2022-06-23 05:51:41.327533
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=100)
    b = Attribute(priority=100)
    c = Attribute(priority=1)
    d = Attribute(priority=200)

    assert a == b, 'Attributes are not equal'
    assert not a == c, 'Attributes are equal'
    assert not b == c, 'Attributes are equal'
    assert not b == d, 'Attributes are equal'
    assert not c == d, 'Attributes are equal'


# Generated at 2022-06-23 05:51:50.878170
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    attr = Attribute(
        isa='dict',
        required=True,
        listof="str",
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
    )
    try:
        attr = Attribute(
            isa='dict',
            required=True,
            listof="str",
            default=["a"],
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None,
        )
    except TypeError:
        print("Failed to detect an error")
    else:
        print("Succeeded to detect an error")
    '''
    print("Testing class Attribute")

# Generated at 2022-06-23 05:51:57.232615
# Unit test for constructor of class Attribute
def test_Attribute():
    class TestClass:
        foo = Attribute(isa='boo', private=False, default=None, required=False, listof=None,
                priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None,
                extend=False, prepend=False, static=False)

    print(TestClass().foo)

# Generated at 2022-06-23 05:51:59.718281
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    assert attribute_1 >= attribute_2


# Generated at 2022-06-23 05:52:05.136809
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa="dict")
    attr2 = Attribute(isa="dict")
    assert attr1 == attr2

    attr1 = Attribute(isa="dict", priority=5)
    attr2 = Attribute(isa="dict")
    assert attr1 != attr2


# Generated at 2022-06-23 05:52:08.090745
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a1.__lt__(a2)


# Generated at 2022-06-23 05:52:12.890970
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa="int", priority=0)
    attr2 = Attribute(isa="int", priority=0)
    assert (attr1 == attr2) == True
    attr3 = Attribute(isa="int", priority=5)
    assert (attr1 == attr3) == False



# Generated at 2022-06-23 05:52:15.873865
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(isa='list')
    attr2 = Attribute(isa='list')
    assert not attr1 < attr2
    assert attr1 <= attr2


# Generated at 2022-06-23 05:52:22.641383
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_obj_1 = Attribute(priority=123)
    test_obj_2 = Attribute(priority=456)

    try:
        result = test_obj_1.__ne__(test_obj_2)
    except Exception as e:
        print('Raised the exception: ', e)
    else:
        assert result == True

    test_obj_2.priority = 123

    try:
        result = test_obj_1.__ne__(test_obj_2)
    except Exception as e:
        print('Raised the exception: ', e)
    else:
        assert result == False


# Generated at 2022-06-23 05:52:25.374325
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(priority=1)
    other = Attribute(priority=2)
    print(attribute.__ge__(other))
    # Expected result: False
