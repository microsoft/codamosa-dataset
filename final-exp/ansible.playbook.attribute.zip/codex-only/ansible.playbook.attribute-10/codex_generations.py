

# Generated at 2022-06-23 05:42:25.792824
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert (a1 < a2) is True
    assert (a2 < a1) is False



# Generated at 2022-06-23 05:42:35.521219
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    class Base(object):
        basename = Attribute(priority=10)

    class SubClass(Base):
        subname = Attribute(priority=5)

    attrs = SubClass.__dict__

    assert attrs['basename'] >= attrs['subname']

    assert attrs['basename'] >  attrs['subname']

    assert attrs['basename'] != attrs['subname']

    assert not attrs['basename'] <= attrs['subname']

    assert not attrs['basename'] <  attrs['subname']

    assert not attrs['basename'] == attrs['subname']


    assert attrs['subname'] <= attrs['basename']

    assert attrs['subname'] <  attrs['basename']


# Generated at 2022-06-23 05:42:40.640996
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field_a = Attribute(required=True, isa='str', priority=2)
    field_b = Attribute(required=True, isa='str', priority=1)
    assert field_a > field_b


# Generated at 2022-06-23 05:42:45.492131
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(isa='str', default='Hello')
        print(a.isa)
        print(a.default)
        print(type(a))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-23 05:42:47.068892
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    obj = Attribute(priority=1)
    assert obj >= Attribute(priority=2) is False



# Generated at 2022-06-23 05:42:53.833441
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_object = FieldAttribute(isa='string', required=True, default="bob", inherit=False)
    assert test_object.isa == "string"
    assert test_object.required == True
    assert test_object.default == "bob"
    assert test_object.inherit == False



# Generated at 2022-06-23 05:42:55.183692
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.__ge__(Attribute())



# Generated at 2022-06-23 05:43:08.150782
# Unit test for constructor of class Attribute
def test_Attribute():
    # Basic constructor
    a = Attribute(isa='int')
    assert a.isa == 'int'
    assert a.listof is None
    assert a.class_type is None
    assert a.default is None
    assert a.required is False
    assert a.priority == 0
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Constructor with a listof
    a = Attribute(isa='list', listof='str')
    assert a.isa == 'list'
    assert a.listof == 'str'
    assert a.class_type is None
    assert a.default is None
    assert a.required is False
   

# Generated at 2022-06-23 05:43:17.951015
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(
        isa='int',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    a2 = Attribute(
        isa='int',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

   

# Generated at 2022-06-23 05:43:21.972298
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(priority=1)

    assert attribute.__ge__(Attribute(priority=1)) is True
    assert attribute.__ge__(Attribute(priority=0)) is True
    assert attribute.__ge__(Attribute(priority=2)) is False



# Generated at 2022-06-23 05:43:31.437261
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa=list)
    assert attr.isa == list
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.always_post_validate == False
    assert attr.inherit == True

    assert attr.private == False

    attr = Attribute(
        isa=list,
        private=True,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
    )
    assert attr.isa == list
    assert attr.private == True
    assert attr.default

# Generated at 2022-06-23 05:43:32.531366
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(isa="int", default=2)
    attr2 = Attribute(isa="int", default=3)
    assert attr1.__ne__(attr2) is True


# Generated at 2022-06-23 05:43:33.591578
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute() > Attribute()

# Generated at 2022-06-23 05:43:35.762976
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a1 > a0



# Generated at 2022-06-23 05:43:38.368477
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute()
    attribute2 = Attribute()
    assert attribute1 == attribute2


# Generated at 2022-06-23 05:43:43.853232
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute().priority == 0
    assert FieldAttribute().priority == 0
    assert Attribute().__gt__(FieldAttribute()) == False
    assert FieldAttribute().__gt__(Attribute()) == True
    assert Attribute().__gt__(FieldAttribute(priority=2)) == False
    assert FieldAttribute().__gt__(Attribute(priority=2)) == True


# Generated at 2022-06-23 05:43:47.116001
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=1)
    assert(attr_2 > attr_1)


# Generated at 2022-06-23 05:43:55.416894
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(1, 1, 1, 1, 1, 1, 1, 1, 1)
    a2 = Attribute(2, 2, 2, 2, 2, 2, 2, 2, 2)
    a3 = Attribute(3, 3, 3, 3, 3, 3, 3, 3, 3)

    assert (a1 >= a1)
    assert (a1 >= a2)
    assert (a1 >= a3)
    assert (a2 >= a1)
    assert (a2 >= a2)
    assert (a2 >= a3)
    assert (a3 >= a1)
    assert (a3 >= a2)
    assert (a3 >= a3)



# Generated at 2022-06-23 05:44:02.175482
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that required attributes are present after initialization
    for attribute in ['isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type', 'always_post_validate', 'inherit', 'alias']:
        if attribute not in dir(Attribute):
            raise AssertionError("Attribute `%s` is not present in a new instance of class `Attribute`" % attribute)


# Test that the constructor of the class FieldAttribute raises an error on
# immutable defaults

# Generated at 2022-06-23 05:44:03.599339
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    constructor = FieldAttribute(isa='dict', default={}, required=True)

# Generated at 2022-06-23 05:44:12.094414
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    obj1 = Attribute(priority=1)
    obj2 = Attribute(priority=2)
    obj3 = Attribute(priority=1)

    # obj2 should be less than or equal to obj1
    if obj2 <= obj1:
        print("obj2 <= obj1")
    else:
        print("obj2 > obj1")

    # obj3 should be less than or equal to obj1
    if obj3 <= obj1:
        print("obj3 <= obj1")
    else:
        print("obj3 > obj1")

if __name__ == "__main__":
    test_Attribute___le__()

# Generated at 2022-06-23 05:44:20.101858
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # pylint: disable=no-member
    a = Attribute()
    # we need to check that __ge__ works as expected in the following way
    # let p1 and p2 be two priorities, p2 <= p1 if and only if p1 >= p2
    # let f1 and f2 be two FieldAttribute objects
    # then, f2 <= f1 if and only if f1 >= f2
    # the test is done with 5 priorities
    a.priority = 1
    assert a >= 1 # pylint: disable=no-member
    assert a >= 2 # pylint: disable=no-member
    assert a >= 3 # pylint: disable=no-member
    assert a >= 4 # pylint: disable=no-member
    assert a >= 5 # pylint: disable=no-member

    b = Attribute

# Generated at 2022-06-23 05:44:30.803402
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    class Foo(object):
        foo = Attribute(priority=10)
        bar = Attribute(priority=20)
        baz = Attribute(priority=30)

    # Base test
    assert Foo.bar < Foo.baz
    assert Foo.baz > Foo.bar

    # Test __lt__ / __gt__ are protocol methods by implementing __lt__ method
    class Bar(object):
        def __lt__(self, other):
            return self.__class__.__name__ < other.__class__.__name__
        def __gt__(self, other):
            return self.__class__.__name__ > other.__class__.__name__

    class Foo(Bar):
        foo = Attribute(priority=10)
        bar = Attribute(priority=20)

# Generated at 2022-06-23 05:44:33.052910
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(0) == Attribute(0)
    assert not Attribute(0) == Attribute(1)


# Generated at 2022-06-23 05:44:43.047541
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa=list, listof=str, required=False, default=[], alias='test1', class_type=str, inherit=False)
    b = Attribute(isa=list, listof=str, required=False, default=[], alias='test2', class_type=str, inherit=False)
    c = Attribute(isa=list, listof=str, required=False, default=[], alias='test3', class_type=str, inherit=False)
    d = Attribute(isa=list, listof=str, required=False, default=[], alias='test4', class_type=str, inherit=False)
    e = Attribute(isa=list, listof=str, required=False, default=[], alias='test5', class_type=str, inherit=False)

# Generated at 2022-06-23 05:44:48.278773
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().inherit == True
    assert Attribute().alias == None
    assert Attribute().extend == False
    assert Attribute().prepend == False
    assert Attribute().static == False

# Generated at 2022-06-23 05:44:52.028849
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    f1 = FieldAttribute()

    f2 = FieldAttribute(priority=1)
    assert f1 < f2

    f2 = FieldAttribute(priority=0)
    assert not (f1 < f2)

    f2 = FieldAttribute(priority=-1)
    assert not (f1 < f2)

# Generated at 2022-06-23 05:44:54.176542
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    assert a < b

# Generated at 2022-06-23 05:44:56.890924
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert not a.__gt__(b)

# Generated at 2022-06-23 05:44:59.936393
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute().__eq__(Attribute()) is True, "Test Attribute().__eq__(Attribute()) is True failed."
    return True


# Generated at 2022-06-23 05:45:02.992704
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a1.priority = 100
    a2 = Attribute()
    a2.priority = 200

    assert a2 >= a1

# Generated at 2022-06-23 05:45:04.626055
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().__class__.__name__ == 'Attribute'


# Generated at 2022-06-23 05:45:14.420207
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    class FakeAttr():
        def __init__ (self,priority):
            self.priority = priority

    attr_1 = FakeAttr(priority=10)
    attr = Attribute()

    attr.priority = 1
    assert attr < attr_1 
    assert not attr >= attr_1 

    attr.priority = 20
    assert attr > attr_1 
    assert not attr <= attr_1 
 
    attr.priority = 10
    assert attr == attr_1 
    assert not attr != attr_1 
    assert not attr > attr_1 
    assert attr >= attr_1 
    assert not attr <  attr_1 
    assert attr <=  attr_1 

    # If the 'priority' attribute

# Generated at 2022-06-23 05:45:18.268052
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert(attr1 < attr2)


# Generated at 2022-06-23 05:45:29.105588
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    a = Attribute(isa=AnsibleUnicode, default='abc')
    b = Attribute(isa=AnsibleUnicode, default='xyz')
    c = Attribute(isa=AnsibleUnicode, default='xyz', priority=1)
    assert a != b
    assert b != c
    assert a.__ne__(b)
    assert b.__ne__(c)
    d = Attribute(isa=AnsibleSequence, listof=AnsibleUnicode, default=['abc'])

# Generated at 2022-06-23 05:45:33.080333
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=0)
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    return (attr1 != attr2) and not (attr1 != attr) and not (attr != attr)


# Generated at 2022-06-23 05:45:43.985866
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # A greater priority should be returned as GreateThan
    isa = "some_isa"
    private = "some_private"
    default = "some_default"
    required = "some_required"
    listof = "some_listof"
    priority = 5
    class_type = "some_class_type"
    always_post_validate = "some_always_post_validate"
    inherit = "some_inherit"
    alias = "some_alias"
    extend = "some_extend"
    prepend = "some_prepend"
    static = "some_static"

    attr1 = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate,
                              inherit, alias, extend, prepend, static)
    attr

# Generated at 2022-06-23 05:45:48.509690
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a >= b:
        print("Error")
    else:
        print("Good")

# Generated at 2022-06-23 05:45:50.711945
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute(priority=1)
    assert a != b

# Generated at 2022-06-23 05:45:58.949395
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(
        isa='dict',
    )
    assert field.isa == 'dict'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False



# Generated at 2022-06-23 05:46:03.506084
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'
    assert attr.static is False
    assert attr.priority == 0

    attr = FieldAttribute(isa='str', static=True)
    assert attr.isa == 'str'
    assert attr.static is True


# Defaults for all Parameters

# Generated at 2022-06-23 05:46:07.291639
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=0) == Attribute(priority=0)
    assert Attribute(priority=1) == Attribute(priority=1)
    assert not Attribute(priority=1) == Attribute(priority=0)


# Generated at 2022-06-23 05:46:08.772095
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field = Attribute()
    assert (field != Attribute())



# Generated at 2022-06-23 05:46:10.714375
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    assert attr.__ne__(attr) == False



# Generated at 2022-06-23 05:46:14.486604
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    x = Attribute(priority=0)
    y = Attribute(priority=1)

    assert(x < y) is True
    assert(y < x) is False
    assert(x < x) is False
    assert(y < y) is False


# Generated at 2022-06-23 05:46:19.036530
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    import pytest
    a1 = Attribute(priority=4)
    a2 = Attribute(priority=5)
    assert (a1 < a2) == (a1.__lt__(a2))
    assert (a2 < a1) == (a2.__lt__(a1))
    assert (a1 < a1) == (a1.__lt__(a1))


# Generated at 2022-06-23 05:46:19.560676
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-23 05:46:24.344383
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(private=True,default=True,required=True,listof=True,priority=0,class_type=False)
    attr2 = Attribute(private=False,default=False,required=False,listof=False,priority=1)
    print("Attribute: %s" % attr)
    print("Attribute2: %s" % attr2)
    print("Attribute not equal to Attribute2: %s" % (attr != attr2))


# Generated at 2022-06-23 05:46:34.099573
# Unit test for constructor of class Attribute
def test_Attribute():
    #check required
    try:
        Attribute(required=True)
    except TypeError:
        pass

    #check isa percent
    Attribute(isa='percent')
    Attribute(isa='float')
    Attribute(isa='int')
    Attribute(isa='bool')
    try:
        Attribute(isa='percent', listof="string")
    except TypeError:
        pass
    Attribute(isa='list', listof="string")
    Attribute(isa='dict', listof="string")
    Attribute(isa='set', listof="string")
    try:
        Attribute(default=[1,2,3])
    except TypeError:
        pass

# Generated at 2022-06-23 05:46:40.227559
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = FieldAttribute()
    b = FieldAttribute()
    a.priority = 1
    b.priority = 2
    assert not a <= b
    assert a >= b
    assert not a < b
    assert a > b

    b.priority = 1
    assert a <= b
    assert a >= b
    assert not a < b
    assert not a > b

    b.priority = 0
    assert not a <= b
    assert a >= b
    assert a < b
    assert not a > b


# Generated at 2022-06-23 05:46:48.701576
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str',
                          listof=['str'])
    assert attr.isa == 'str'
    assert attr.listof == ['str']
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-23 05:46:51.261296
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    with pytest.raises(TypeError):
        Attribute(default=dict())

# Generated at 2022-06-23 05:46:54.662839
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute(
        isa = 'int',
        default = 0,
    )
    assert(attribute == Attribute(priority=1))



# Generated at 2022-06-23 05:47:05.103562
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with a valid isa
    f = FieldAttribute(isa='string')
    assert f.isa == 'string'
    assert f.default is None
    assert not f.private
    assert not f.required
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert not f.always_post_validate
    assert f.inherit
    assert f.alias is None
    assert not f.extend
    assert not f.prepend
    assert not f.static

    # Test with an invalid isa.  Should be a string or a class.

# Generated at 2022-06-23 05:47:16.278392
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    f = FieldAttribute()

    assert f.isa is None
    assert not f.private
    assert f.default is None
    assert not f.required
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert not f.always_post_validate
    assert f.inherit
    assert not f.extend
    assert not f.prepend
    assert not f.static

    f = FieldAttribute(isa='list')

    assert f.isa is 'list'
    assert not f.private
    assert f.default is None
    assert not f.required
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert not f.always_post_validate
    assert f.inherit

# Generated at 2022-06-23 05:47:20.117458
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    fieldattr1 = FieldAttribute()
    fieldattr1.priority = 4
    fieldattr2 = FieldAttribute()
    fieldattr2.priority = 2

    assert fieldattr2.__lt__(fieldattr1) == True

# Generated at 2022-06-23 05:47:23.663545
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    assert a1.__ge__(a1)
    assert a1.__ge__(Attribute(priority=1))
    assert not a1.__ge__(Attribute(priority=2))
    assert a1.__ge__(Attribute(priority=0))


# Generated at 2022-06-23 05:47:28.524706
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)

    assert not (a <= b)
    assert a <= c
    assert c <= a

# Generated at 2022-06-23 05:47:34.368080
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # init variable for test
    obj = Attribute()
    obj1 = Attribute()
    # call function
    result = obj <= obj1
    # check result
    assert result == (other.priority <= self.priority)


# Generated at 2022-06-23 05:47:38.222331
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    d = Attribute(priority=2)

    assert not (a != b)
    assert a != c
    assert not (c != d)


# Generated at 2022-06-23 05:47:48.630338
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # test_Attribute_instance___lt___with_lower_priority
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=10)
    assert attr1 < attr2
    # test_Attribute_instance___lt___with_higher_priority
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=0)
    assert not(attr1 < attr2)
    # test_Attribute_instance___lt___with_equal_priority
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=5)
    assert not(attr1 < attr2)


# Generated at 2022-06-23 05:47:58.459591
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attrs = [Attribute(required=True, always_post_validate=False, default=None, listof=None, class_type=None, isa=None, alias=None, inherit=True, priority=0),
             Attribute(required=True, always_post_validate=False, default=None, listof=None, class_type=None, isa=None, alias=None, inherit=True, priority=1)]

    assert(attrs[0] <= attrs[1])
    assert(attrs[1] >= attrs[0])
    assert(attrs[0] != attrs[1])
    assert(attrs[1] != attrs[0])
    assert(attrs[0] < attrs[1])
    assert(attrs[1] > attrs[0])

# Generated at 2022-06-23 05:48:04.784932
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute_1 = Attribute(isa="class", priority=1)
    attribute_2 = Attribute(isa="class", priority=2)
    attribute_3 = Attribute(isa="class", priority=1)
    assert attribute_1 == attribute_1
    assert attribute_1 == attribute_3
    assert attribute_1 != attribute_2



# Generated at 2022-06-23 05:48:15.132075
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    class A:

        a1 = FieldAttribute(isa='list')
        a2 = FieldAttribute(isa='int', default=5)
        a3 = FieldAttribute(isa='dict', default={})
        a4 = FieldAttribute(isa='bool', default=False)
        a5 = FieldAttribute(isa='int', required=True)
        a6 = FieldAttribute(isa='int', listof=int)
        a7 = FieldAttribute(isa='int', class_type=int)
        a8 = FieldAttribute(isa='list', class_type=list)

    a = A()
    assert(a.a1 == [])
    assert(a.a2 == 5)
    assert(a.a3 == {})
    assert(a.a4 == False)

    # None is not a valid value for integer
    # So, Value

# Generated at 2022-06-23 05:48:17.037592
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute('dict', default={}, extend=True)
    #print("a:", a)



# Generated at 2022-06-23 05:48:26.582896
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    assert attr == attr # pylint: disable=literal-comparison
    attr2 = Attribute(priority=attr.priority)
    assert not (attr != attr2) # pylint: disable=literal-comparison
    attr3 = Attribute(priority=attr2.priority+1)
    assert attr != attr3 # pylint: disable=literal-comparison


# Generated at 2022-06-23 05:48:29.346151
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
  le_operation = Attribute(priority=1, inherit=False) <= Attribute(priority=0, inherit=False)
  assert (le_operation == True)



# Generated at 2022-06-23 05:48:31.687876
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    assert attr == attr
    assert attr.__eq__(attr)


# Generated at 2022-06-23 05:48:38.299361
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(default=None, priority=0)
    b = Attribute(default=None, priority=0)
    assert a.__le__(b) == True
    assert b.__le__(a) == True
    assert a.__ge__(b) == True
    assert b.__ge__(a) == True
    assert a.__lt__(b) == False
    assert b.__lt__(a) == False
    assert a.__gt__(b) == False
    assert b.__gt__(a) == False

# Generated at 2022-06-23 05:48:46.634295
# Unit test for constructor of class Attribute
def test_Attribute():
    valid_isa_values = ['dict', 'set', 'str', 'bool', 'none', 'int',
                        'float', 'list', 'percent', 'uri']
    invalid_isa_values = ['strn', 'intg', 'lis',
                          'perce', 'percentage']

    valid_listof_values = ['dict', 'set', 'str', 'bool', 'none', 'int',
                           'float', 'list']
    invalid_listof_values = ['strn', 'intg', 'lis',
                             'perce', 'percentage']

    for value in valid_isa_values:
        Attribute(isa=value)

    for value in invalid_isa_values:
        try:
            Attribute(isa=value)
        except (TypeError, ValueError):
            pass

# Generated at 2022-06-23 05:48:48.170873
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1= Attribute(priority=0)
    field2= Attribute(priority=10)

    assert field1 == field2


# Generated at 2022-06-23 05:48:51.338649
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=1)
    a10 = Attribute(priority=10)
    assert a1 != a10
    assert not (a1 != a1)


# Generated at 2022-06-23 05:48:53.485340
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=10)
    assert a1 >= a2
    assert a2 <= a1


# Generated at 2022-06-23 05:48:55.998214
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    test_obj_a = Attribute()
    test_obj_a.priority = 1

    test_obj_b = Attribute()
    test_obj_b.priority = 1

    assert test_obj_a == test_obj_b


# Generated at 2022-06-23 05:49:05.707460
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        f = FieldAttribute(isa='list', default=[])
    except TypeError:
        pass
    else:
        assert False, "should have thrown TypeError for mutable default"

    try:
        f = FieldAttribute(isa='list', default=['foo'])
    except TypeError:
        pass
    else:
        assert False, "should have thrown TypeError for mutable default"

    try:
        f = FieldAttribute(isa='bool', default=True)
    except TypeError:
        assert False, "should not have thrown TypeError for immutable default"
    else:
        assert True, "no exception thrown for immutable default"

    try:
        f = FieldAttribute(isa='list', default=lambda: ['foo'])
    except TypeError:
        assert False, "should not have thrown TypeError for immutable default"

# Generated at 2022-06-23 05:49:14.438074
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    instances = [
        Attribute(priority=10),
        Attribute(priority=11),
        Attribute(priority=11),
        Attribute(priority=12),
        Attribute(priority=12),
        Attribute(priority=42),
    ]
    for i, instance in enumerate(instances):
        assert instance.__le__(instance)
        for j, other in enumerate(instances):
            if i == j:
                continue
            if i < j:
                assert instance.__le__(other)
            else:
                assert not instance.__le__(other)

# Generated at 2022-06-23 05:49:25.546551
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Arrange
    a = Attribute(default=None, private=False, priority=1)
    b = Attribute(default=None, private=False, priority=2)
    c = Attribute(default=None, private=False, priority=1)

    # Act
    result_a_b = a.__ne__(b)
    result_b_a = b.__ne__(a)
    result_a_c = a.__ne__(c)
    result_c_a = c.__ne__(a)

    # Assert
    assert result_a_b == True
    assert result_b_a == True
    assert result_a_c == False
    assert result_c_a == False



# Generated at 2022-06-23 05:49:31.785247
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(isa='int', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a2 = Attribute(isa='int', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert(a1.__ge__(a2) == True)


# Generated at 2022-06-23 05:49:43.906770
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(isa='list', default=['test'])
        assert False, 'Should not get here'
    except TypeError:
        pass

    a = Attribute(isa='list', default=lambda: ['test'])
    assert a.default() == ['test']
    a = Attribute(isa='list', default=lambda: [])
    assert a.default() == []
    a = Attribute(isa='list', default=lambda: [1,2,3])
    assert a.default() == [1,2,3]
    a = Attribute(isa='dict', default=lambda: {1:1,2:2,3:3})
    assert a.default() == {1:1,2:2,3:3}

# Generated at 2022-06-23 05:49:55.528607
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    
    #Create a Attribute object
    obj = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    #Create a Attribute object

# Generated at 2022-06-23 05:50:07.124177
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(alias=None, default=None, isa=None, inherit=True, listof=None,
        priority=0, private=False, required=False)
    attr2 = Attribute(alias=None, default=None, isa=None, inherit=True, listof=None,
        priority=1, private=False, required=False)
    attr3 = Attribute(alias=None, default=None, isa=None, inherit=True, listof=None,
        priority=0, private=False, required=False)

    assert attr1 != attr2

    assert attr1 <= attr2
    assert attr2 >= attr1

    assert not attr1 < attr2
    assert not attr2 > attr1

    assert attr1 == attr3

# Generated at 2022-06-23 05:50:09.336372
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert (Attribute('1', 0) >= Attribute('2', 0))

if __name__ == '__main__':
    test_Attribute___le__()

# Generated at 2022-06-23 05:50:12.890816
# Unit test for constructor of class Attribute
def test_Attribute():
    import unittest

    class TestAttribute(unittest.TestCase):
        def test_Attribute(self):
            attr = Attribute(isa='foo')
            self.assertEqual(attr.isa, 'foo')

    unittest.main()


# Generated at 2022-06-23 05:50:17.125627
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attrib = Attribute(isa='int', default=10, priority=1)
    attrib_test = Attribute(isa='int', default=11, priority=2)
    assert attrib.__ge__(attrib_test) == False
    assert attrib.__ge__(attrib) == True
    attrib_test = Attribute(isa='int', default=10, priority=2)
    assert attrib.__ge__(attrib_test) == False
    attrib_test = Attribute(isa='int', default=9, priority=1)
    assert attrib.__ge__(attrib_test) == True
    attrib_test = Attribute(isa='int', default=9, priority=0)
    assert attrib.__ge__(attrib_test) == True
    attrib_test = Attribute

# Generated at 2022-06-23 05:50:21.191347
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=5)
    att2 = Attribute(priority=5)
    att3 = Attribute(priority=25)
    assert(att1 == att2)
    assert(att1 != att3)
    assert(att3 > att1)
    assert(att3 >= att1)
    assert(att1 < att3)
    assert(att1 <= att3)

# Generated at 2022-06-23 05:50:33.057215
# Unit test for method __ne__ of class Attribute

# Generated at 2022-06-23 05:50:35.110723
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute().__lt__(FieldAttribute())
    assert FieldAttribute().__gt__(Attribute())


# Generated at 2022-06-23 05:50:39.042932
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', listof='int')
    # Just verify that we don't hit an exception

# NB: FieldAttribute is a subclass of Attribute, and the constructor of Attribute does
#     all the checking and set the fields of the attribute object.


# Generated at 2022-06-23 05:50:40.179427
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    # both objects have the same priority
    assert a1 == a2


# Generated at 2022-06-23 05:50:43.085916
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert(Attribute(priority=1) >= Attribute(priority=1))
    assert(Attribute(priority=1) >= Attribute(priority=0))
    assert(not Attribute(priority=0) >= Attribute(priority=1))


# Generated at 2022-06-23 05:50:50.054383
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # arrange
    field = Attribute(isa=str, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    field2 = Attribute(isa=str, private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-23 05:51:01.176880
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 > attr1
    assert attr1 < attr2
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=2)
    assert not attr1 > attr2
    assert not attr1 < attr2
    attr1 = Attribute(priority=1)
    assert attr1 > attr2


# Generated at 2022-06-23 05:51:02.426871
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert FieldAttribute() < FieldAttribute(priority=1)



# Generated at 2022-06-23 05:51:05.071161
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a1.priority = 10 
    a2 = Attribute()
    a2.priority = 1 
    assert a1 >= a2

# Generated at 2022-06-23 05:51:11.055360
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    test = FieldAttribute(isa='str', default='foobar')
    assert test.isa == 'str'
    assert test.default == 'foobar'

    try:
        test = FieldAttribute(isa='str', default={})
        raise AssertionError
    except TypeError:
        pass



# Generated at 2022-06-23 05:51:11.975248
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert FieldAttribute() == FieldAttribute()


# Generated at 2022-06-23 05:51:18.308578
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1 == attr2
    assert not attr1 < attr2
    assert not attr2 < attr1
    attr3 = Attribute(priority=1)
    assert not attr1 == attr3
    assert not attr1 < attr3
    assert attr3 > attr1
    assert attr2 != attr3
    assert attr2 < attr3
    assert attr3 > attr2

if __name__ == '__main__':
    test_Attribute___lt__()

# Generated at 2022-06-23 05:51:21.072186
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=3)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert(a > b)
    assert(b > c)
    assert(b <= a)
    assert(c <= b)
    assert(not (c > b))


# Generated at 2022-06-23 05:51:24.302260
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    p1 = Attribute(isa='list',priority=10)
    p2 = Attribute(isa='list',priority=5)
    #
    assert p1 >= p2


# Generated at 2022-06-23 05:51:26.183190
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    assert a <= b


# Generated at 2022-06-23 05:51:34.805797
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(required=True, priority=5)
    a2 = Attribute(required=True, priority=5)
    a3 = Attribute(required=True, priority=2)
    a4 = Attribute(required=True, priority=-2)
    assert a1 > a2
    assert a1 > a3
    assert a1 > a4
    assert a3 < a4
    assert a3 < a2
    assert a3 < a1
    assert a4 > a1
    assert a4 > a2
    assert a4 > a3
    assert a1 == a2
    assert a3 != a4


# Generated at 2022-06-23 05:51:37.456479
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute()
    attribute.priority = 0
    other = Attribute()
    other.priority = 10
    res = attribute.__gt__(other)
    assert res == False

# Generated at 2022-06-23 05:51:47.468340
# Unit test for constructor of class Attribute
def test_Attribute():

    good = dict(
            isa='class',
            private=False,
            default=None,
            required=False,
            listof='list',
            priority=0,
            class_type='list',
            always_post_validate=False,
            inherit=True,
            alias='alias',
            extend=True,
            prepend=False,
            static=False,
            )

    a = Attribute(**good)

    for k, v in good.items():
        assert(v==getattr(a,k))


# Generated at 2022-06-23 05:51:55.788627
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test Attribute.__init__():
    #   params isa, default, required, listof, priority, class_type, always_post_validate, inherit, alias
    #   are optional, and all have their default values.
    #   isa, private, required, listof, and class_type, must be set to None if not specified.
    attribute = Attribute()

    assert attribute.isa == None
    assert attribute.private == None
    assert attribute.default == None
    assert attribute.required == None
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == None
    assert attribute.inherit == None
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.static == False

   

# Generated at 2022-06-23 05:52:06.450728
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa is not None
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False


# Generated at 2022-06-23 05:52:07.289858
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()

# Generated at 2022-06-23 05:52:10.164737
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute()
    attr.priority = 10
    assert attr <= attr, 'Attribute class should implement __le__ method'


# Generated at 2022-06-23 05:52:19.790504
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a
    assert a.isa is None
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a == a
    assert not a != a
    assert not a > a
    assert a >= a
    assert not a < a
    assert a <= a

# Generated at 2022-06-23 05:52:30.229622
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=1)
    att2 = Attribute(priority=2)
    att3 = Attribute(priority=3)
    att4 = Attribute(priority=4)

    assert att1 < att2
    assert att1 <= att2
    assert att2 >= att1
    assert att2 > att1
    assert not att1 == att2

    assert att1 < att3
    assert att1 <= att3
    assert att3 >= att1
    assert att3 > att1
    assert not att1 == att3

    assert att2 < att3
    assert att2 <= att3
    assert att3 >= att2
    assert att3 > att2
    assert not att2 == att3

    assert att1 < att4
    assert att1 <= att4
    assert att4 >= att1
    assert att4