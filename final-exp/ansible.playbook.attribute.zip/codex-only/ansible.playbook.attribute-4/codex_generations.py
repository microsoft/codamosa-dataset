

# Generated at 2022-06-23 05:42:27.006474
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a2 < a1


# Generated at 2022-06-23 05:42:34.040517
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    fail_values = (None, 1, 0, "", "a", {}, [], ())

    attr1 = Attribute()
    attr2 = Attribute()

    assert attr1.__ne__(attr2)
    assert not attr1.__ne__(attr1)

    for fail_value in fail_values:
        try:
            attr1.__ne__(fail_value)
        except Exception as e:
            assert isinstance(e, TypeError)
        else:
            assert False, "Expected TypeError"


# Generated at 2022-06-23 05:42:37.107247
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a >= b

# Generated at 2022-06-23 05:42:43.469145
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert FieldAttribute(priority=5) == FieldAttribute(priority=5)
    assert not FieldAttribute(priority=5) != FieldAttribute(priority=5)
    assert FieldAttribute(priority=5) >= FieldAttribute(priority=5)
    assert FieldAttribute(priority=5) <= FieldAttribute(priority=5)
    assert FieldAttribute(priority=5) >= FieldAttribute(priority=4)
    assert FieldAttribute(priority=5) <= FieldAttribute(priority=6)
    assert FieldAttribute(priority=5) > FieldAttribute(priority=4)
    assert FieldAttribute(priority=5) < FieldAttribute(priority=6)


# Generated at 2022-06-23 05:42:45.958051
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert not a2 < a1


# Generated at 2022-06-23 05:42:53.709696
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Test the method __lt__ of class Attribute
    """

    # Testcase 1: constructor of the class Attribute assigns the value 2 to instance variable priority
    # This value is compared to an other value.
    attribute1 = Attribute(priority=2)
    assert attribute1.priority < 1
    assert attribute1.priority < 2
    assert attribute1.priority < 3

    # Testcase 2: constructor of the class Attribute assigns the value 0 to instance variable priority
    # This value is compared to an other value.
    attribute2 = Attribute(priority=0)
    assert attribute2.priority < 1
    assert attribute2.priority > -1

    # Testcase 3: constructor of the class Attribute assigns the value 1 to instance variable priority
    # This value is compared to an other value.
    attribute3 = Attribute(priority=1)


# Generated at 2022-06-23 05:42:56.834813
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1000)
    b = Attribute(priority=500)
    c = Attribute(priority=1000)

    assert a <= b
    assert not b <= a
    assert a <= c
    assert c <= a



# Generated at 2022-06-23 05:43:01.184369
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b


# Generated at 2022-06-23 05:43:03.748619
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert (a1 < a2) is True


# Generated at 2022-06-23 05:43:14.840731
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=str)
    assert a.isa == str
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa=bool, default=False)
    assert a.isa == bool
    assert a.private == False
    assert a.default == False
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0

# Generated at 2022-06-23 05:43:18.145810
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=1)
    attr1 = Attribute(priority=2)
    assert attr1 <= attr == True, "Attribute class __le__ method failure"

# Generated at 2022-06-23 05:43:27.474675
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='int', default=5)
    assert f1.isa == 'int'
    assert f1.default == 5
    assert f1.required == False

    # test that defaults for lists and dicts must be callables
    try:
        f2 = FieldAttribute(isa='list', default=['hello'])
    except TypeError as e:
        assert str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'
    else:
        assert False, 'default should not accept a mutable type as a default'
    f3 = FieldAttribute(isa='list', default=lambda: ['hello'])
    assert f3.default() == ['hello']



# Generated at 2022-06-23 05:43:30.977452
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    att = Attribute()
    att.priority = 1
    other = Attribute()
    other.priority = 1
    assert att.__ge__(other)
    other.priority = 2
    assert not att.__ge__(other)



# Generated at 2022-06-23 05:43:40.548287
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=True, default='default', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=False)
    assert attr.isa == 'str'
    assert attr.private is True
    assert attr.required is True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate is True
    assert attr.inherit is True
    assert attr.alias == 'alias'
    assert attr.extend is True
    assert attr.prepend is True
    assert attr.static is False

#

# Generated at 2022-06-23 05:43:44.222274
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # No exception raised
    a = Attribute()
    a.priority = 10
    b = Attribute()
    b.priority = 20
    assert a < b



# Generated at 2022-06-23 05:43:48.092147
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    att1 = Attribute()
    att1.priority = 1

    att2 = Attribute()
    att2.priority = 2

    assert att1 != att2
    assert att1 != 1



# Generated at 2022-06-23 05:43:50.212179
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute()
    attribute == attribute
    new_attribute = Attribute()
    attribute == new_attribute



# Generated at 2022-06-23 05:43:51.883678
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert (Attribute() != Attribute(isa='int'))



# Generated at 2022-06-23 05:44:02.025390
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # init Attribute
    x = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    # call method __ne__ of Attribute
    y = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    flag = x.__ne__(x)



# Generated at 2022-06-23 05:44:12.974031
# Unit test for constructor of class Attribute
def test_Attribute():
    # special isa:
    # 'AnyOf'
    # 'AllOf'
    # 'AllOfAnyOf'
    # 'NoneOf'
    # 'NoneOfAnyOf'
    # 'OneOf'
    # 'AnyString'
    # 'AnyInt'
    # 'AnyBool'
    # 'AnyFloat'
    # 'AnyList'
    # 'AnyDict'
    # 'AnySet'
    # 'AnyObject'
    # 'AnyScalar'
    # 'AnyURI'
    # 'AnyUUID'

    assert Attribute(isa='str').isa == 'str'
    assert Attribute(isa='int').isa == 'int'
    assert Attribute(isa='bool').isa == 'bool'
    assert Attribute(isa='float').isa == 'float'
    assert Attribute

# Generated at 2022-06-23 05:44:15.253515
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert (a != b) == True



# Generated at 2022-06-23 05:44:23.831192
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    priority_proper_1 = Attribute(priority=1)
    priority_proper_2 = Attribute(priority=2)
    priority_non_proper = Attribute(priority=1)

    assert priority_proper_1 <= priority_proper_2
    assert not priority_proper_2 <= priority_proper_1
    assert not priority_non_proper <= priority_proper_1
    assert priority_proper_1 <= priority_non_proper

# Generated at 2022-06-23 05:44:26.285277
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    if a != b:
        print("test_Attribute___ne__ failed")


# Generated at 2022-06-23 05:44:29.718404
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = FieldAttribute(priority=0)
    field2 = FieldAttribute(priority=1)

    assert(field1 == field2)



# Generated at 2022-06-23 05:44:31.810515
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a != b



# Generated at 2022-06-23 05:44:36.972582
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority=0)
    attribute_2 = Attribute(priority=1)

    assert(attribute_1 >= attribute_2)
    assert(attribute_2 <= attribute_1)
    assert(not (attribute_1 < attribute_2))
    assert(attribute_2 > attribute_1)



# Generated at 2022-06-23 05:44:41.526265
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    aL = Attribute(priority=1)
    aR = Attribute(priority=2)
    assert aR <= aR
    assert aL <= aL
    assert not(aR <= aL)
    assert aL <= aR


# Generated at 2022-06-23 05:44:43.864301
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute(priority = 3)
    oth_attribute = Attribute(priority = 5)
    assert attribute.__ne__(oth_attribute)


# Generated at 2022-06-23 05:44:51.774710
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='int')
    assert f1.isa == 'int'
    assert f1.private == False
    assert f1.default == None
    assert f1.required == False
    assert f1.listof == None
    assert f1.priority == 0
    assert f1.class_type == None
    assert f1.always_post_validate == False
    assert f1.inherit == True
    assert f1.alias == None
    assert f1.extend == False
    assert f1.prepend == False
    assert f1.static == False

    def def_func_int():
        return 1

# Generated at 2022-06-23 05:44:53.969784
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a > b

# Generated at 2022-06-23 05:44:58.008214
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    a.priority = 2
    b.priority = 2
    assert a.__ge__(b)

    a.priority = 3
    b.priority = 2
    assert a.__ge__(b)


# Generated at 2022-06-23 05:45:12.877925
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa == None, 'isa should be None'
    assert fa.private == False, 'private should be False'
    assert fa.default == None, 'default should be None'
    assert fa.required == False, 'required should be False'
    assert fa.listof == None, 'listof should be None'
    assert fa.priority == 0, 'priority should be 0'
    assert fa.class_type == None, 'class_type should be None'
    assert fa.always_post_validate == False, 'always_post_validate should be False'
    assert fa.inherit == True, 'inherit should be True'
    assert fa.alias == None, 'alias should be None'
    assert fa.extend == False, 'extend should be False'
    assert fa.pre

# Generated at 2022-06-23 05:45:24.067627
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Attributes with None priority are equal
    a0 = FieldAttribute()
    b0 = FieldAttribute()
    assert a0 is not b0
    assert a0 == b0
    assert not a0 < b0
    assert not a0 > b0

    # Attributes with different priorities are not equal
    c1 = FieldAttribute(priority=1)
    d2 = FieldAttribute(priority=2)
    assert c1 < d2
    assert d2 > c1

    # Attributes with different priorities are comparable
    assert a0 < c1
    assert a0 < d2
    assert b0 < c1
    assert b0 < d2

    # Attributes with different priorities are comparable
    assert c1 > a0
    assert c1 > b0
    assert d2 > a0
    assert d2 > b0

# Generated at 2022-06-23 05:45:27.852741
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=100) != Attribute(priority=200)
    assert Attribute(priority=0) != Attribute(priority=1)
    assert Attribute(priority=0) != Attribute(priority="1")
    assert not (Attribute(priority=100) != Attribute(priority=100))


# Generated at 2022-06-23 05:45:32.333928
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='int', priority=1)
    a2 = Attribute(isa='bool', priority=1)
    a3 = Attribute(isa='str', priority=1)
    assert a1 == a3
    assert a2 == a3
    assert a1 != a2


# Generated at 2022-06-23 05:45:35.787007
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = FieldAttribute()
    a.priority = 0

    a1 = FieldAttribute()
    a1.priority = 0

    assert a1 <= a


# Generated at 2022-06-23 05:45:38.151189
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=10)
    b = Attribute(priority=11)
    assert b <= a


# Generated at 2022-06-23 05:45:45.506387
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa='str', required=True, priority=3, default='default_value')
    assert attr1.__dict__ == {'isa': 'str', 'private': False, 'default': 'default_value', 'required': True,
                              'listof': None, 'priority': 3, 'class_type': None, 'always_post_validate': False,
                              'inherit': True, 'alias': None, 'extend': False, 'prepend': False, 'static': False}

# Generated at 2022-06-23 05:45:47.635407
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    assert a.__ge__(Attribute())


# Generated at 2022-06-23 05:45:51.029099
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 100
    b = Attribute()
    b.priority = 101
    return a.__gt__(b)


# Generated at 2022-06-23 05:45:53.481170
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(required=False, priority=0)
    b = Attribute(required=False, priority=1)
    assert a <= b


# Generated at 2022-06-23 05:45:55.780058
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    attr.priority = 2
    assert attr == attr


# Generated at 2022-06-23 05:46:00.034320
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='bool', default=False)
    a2 = Attribute(isa='bool', default=False)
    assert a1 == a2  # __eq__ method of Attribute class can work well



# Generated at 2022-06-23 05:46:04.878297
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_1 = Attribute(priority=1)
    field_2 = Attribute(priority=2)
    field_3 = Attribute(priority=3)
    field_4 = Attribute(priority=4)

    assert field_1 < field_2
    assert not field_2 < field_3
    assert not field_3 < field_4
    assert not field_1 < field_1


# Generated at 2022-06-23 05:46:07.741042
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=10) > Attribute(priority=5) is True


# Generated at 2022-06-23 05:46:17.190744
# Unit test for constructor of class Attribute
def test_Attribute():
    # test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # test all overriden values

# Generated at 2022-06-23 05:46:19.480446
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a >= b


# Generated at 2022-06-23 05:46:21.598739
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(isa="int", required=True)
    attr2 = Attribute(isa="str", required=False)
    assert attr != attr2



# Generated at 2022-06-23 05:46:23.940266
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=3)
    b = Attribute(priority=5)
    c = Attribute(priority=7)
    assert a <= b
    assert b <= c
    assert c <= c



# Generated at 2022-06-23 05:46:31.923603
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False


# Generated at 2022-06-23 05:46:36.146211
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Arrange
    from UnitTest import MockAttribute, MockAttribute2
    mock_attr = MockAttribute()
    mock_attr2 = MockAttribute2()

    # Act
    result = mock_attr != mock_attr2

    # Assert
    assert result is True, 'must be equal'


# Generated at 2022-06-23 05:46:41.821801
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    f1 = FieldAttribute(priority = 1)
    f2 = FieldAttribute(priority = 2)
    assert(f1.__ge__(f2) == False)
    assert(f2.__ge__(f1) == True)
    f3 = FieldAttribute(priority = 1)
    assert(f1.__ge__(f3) == True)

# Generated at 2022-06-23 05:46:48.156007
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field1 = FieldAttribute(required=False, isa='list', default=[], class_type=None, priority=10)
    field2 = FieldAttribute(required=False, isa='list', default=[], class_type=None, priority=10)
    field3 = FieldAttribute(required=False, isa='dict', default={}, class_type=None, priority=-1)
    assert field1 == field2
    assert not field1 < field2
    assert field3 < field1



# Generated at 2022-06-23 05:46:48.805501
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass

# Generated at 2022-06-23 05:46:55.268017
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute_1 = Attribute(isa=int, default=3, priority=2)
    attribute_2 = Attribute(isa=int, default=3, priority=1)
    attribute_3 = Attribute(isa=int, default=3, priority=2)
    assert attribute_1 == attribute_3
    assert not attribute_1 == attribute_2


# Generated at 2022-06-23 05:47:04.199491
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    import unittest
    from unittest import TestCase
    from unittest import TestLoader

    class test_Attribute___gt__(TestCase):
        def setUp(self):
            self.a1 = Attribute(priority = 1)
            self.a2 = Attribute(priority = 2)

        def test__gt__(self):
            self.assertTrue(self.a2>self.a1)
            self.assertFalse(self.a1>self.a2)

    suite = TestLoader().loadTestsFromTestCase(test_Attribute___gt__)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-23 05:47:06.858293
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)
    assert Attribute(priority=2) == Attribute(priority=2)


# Generated at 2022-06-23 05:47:12.536318
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    a = Attribute(isa='list', default=lambda: [])
    with pytest.raises(TypeError) as excinfo:
        a = Attribute(isa='list', default=[])


# Prevents the Attribute from being doc'd when the docs are built
_FieldAttribute = FieldAttribute(private=True)



# Generated at 2022-06-23 05:47:15.334950
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = FieldAttribute(priority=5)
    field2 = FieldAttribute(priority=5)
    assert field1.__ge__(field2)


# Generated at 2022-06-23 05:47:24.808927
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                   priority=0, class_type=None, always_post_validate=False, inherit=True,
                   alias=None, extend=False, prepend=False, static=False)
    a2 = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                   priority=1, class_type=None, always_post_validate=False, inherit=True,
                   alias=None, extend=False, prepend=False, static=False)
    assert a1 != a2


# Generated at 2022-06-23 05:47:35.320298
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    first_attr = FieldAttribute()
    assert first_attr.isa == None
    assert first_attr.private == False
    assert first_attr.default == None
    assert first_attr.required == False
    assert first_attr.listof == None
    assert first_attr.priority == 0
    assert first_attr.class_type == None
    assert first_attr.always_post_validate == False
    assert first_attr.inherit == True
    assert first_attr.alias == None
    assert first_attr.extend == False
    assert first_attr.prepend == False
    assert first_attr.static == False


# Generated at 2022-06-23 05:47:43.812828
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute()
    a4 = Attribute()
    a1.priority = 0
    a2.priority = 1
    a3.priority = 1
    a4.priority = 2

    # a1 priority = 0
    # a2 priority = 1
    # a3 priority = 1
    # a4 priority = 2
    assert a1 > a2, 'a1 priority is lower than a2 priority (0 < 1), a1 > a2 must be False'
    assert a1 < a2, 'a1 priority is lower than a2 priority (0 < 1), a1 < a2 must be True'
    assert a2 == a3, 'a2 priority is equal than a3 priority (1 == 1), a2 == a3 must be True'
    assert a2

# Generated at 2022-06-23 05:47:47.348962
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default=dict(derived_state=True))
        # should raise TypeError
        assert False
    except TypeError:
        pass



# Generated at 2022-06-23 05:47:52.513401
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    attr = Attribute(private=True)
    with pytest.raises(TypeError):
        attr = Attribute(default=2)
    with pytest.raises(TypeError):
        attr = Attribute(default=set())
    with pytest.raises(TypeError):
        attr = Attribute(default=dict())


# Generated at 2022-06-23 05:47:54.122317
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute(priority=10))



# Generated at 2022-06-23 05:48:04.253584
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof='str', priority=0,
                          class_type='str', always_post_validate=False, inherit=True, alias=None, extend=False,
                          prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-23 05:48:07.272359
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private == False
    assert f.default is None
    assert f.required == False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate == False
    assert f.inherit == True



# Generated at 2022-06-23 05:48:08.936973
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=10)
    attribute2 = Attribute(priority=9)
    assert attribute1 >= attribute2


# Generated at 2022-06-23 05:48:11.631065
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert FieldAttribute(
        isa='int',
        default=0) != Attribute(
        isa='int',
        default=1)



# Generated at 2022-06-23 05:48:22.208076
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # pylint: disable=invalid-name
    # if self < other:

    atrb_1 = Attribute(priority=1)
    atrb_2 = Attribute(priority=2)

    assert atrb_1 < atrb_2
    assert not atrb_2 < atrb_1

    atrb_1_1 = Attribute(priority=1)
    assert atrb_1 <= atrb_2
    assert atrb_1_1 <= atrb_2
    assert not atrb_2 <= atrb_1
    assert not atrb_2 <= atrb_1_1

    # if self > other:

    assert atrb_2 > atrb_1
    assert not atrb_1 > atrb_2

    assert atrb_2 >= atrb_1
    assert atrb_2 >= atrb_

# Generated at 2022-06-23 05:48:25.010648
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a1 == a2
    assert not a1 != a2


# Generated at 2022-06-23 05:48:27.436784
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1 < attribute2



# Generated at 2022-06-23 05:48:29.944942
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)
    assert (field1 >= field2)



# Generated at 2022-06-23 05:48:32.536944
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=20)
    assert a1 < a2



# Generated at 2022-06-23 05:48:36.885777
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute() > Attribute()
    assert Attribute(priority=0) > Attribute(priority=1)
    assert Attribute(priority=1) < Attribute(priority=0)
    assert (Attribute(priority=1) > Attribute(priority=0)) == (Attribute(priority=0) < Attribute(priority=1))


# Generated at 2022-06-23 05:48:40.096077
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr1.priority = 1

    attr2 = Attribute()
    attr2.priority = 2

    assert attr1 < attr2


# Generated at 2022-06-23 05:48:44.836962
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert(a < b)
    assert(not a > b)
    assert(b > a)
    assert(not b < a)



# Generated at 2022-06-23 05:48:55.094112
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import sys
    sys.path.insert(0, "..")
    import unittest

    class MyFieldAttribute(object):
        def __init__(self, isa=None, private=None, default=None, required=None, listof=None, priority=0, class_type=None, always_post_validate=None, inherit=None, alias=None):
            self.isa = isa
            self.private = private
            self.default = default
            self.required = required
            self.listof = listof
            self.priority = priority
            self.class_type = class_type
            self.always_post_validate = always_post_validate
            self.inherit = inherit
            self.alias = alias


# Generated at 2022-06-23 05:49:04.671294
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert FieldAttribute(priority=7) == FieldAttribute(priority=7)
    assert FieldAttribute(priority=7) >= FieldAttribute(priority=7)
    assert FieldAttribute(priority=7) <= FieldAttribute(priority=7)

    assert not (FieldAttribute(priority=7) > FieldAttribute(priority=7))
    assert not (FieldAttribute(priority=7) < FieldAttribute(priority=7))

    assert FieldAttribute(priority=7) != FieldAttribute(priority=8)
    assert FieldAttribute(priority=7) < FieldAttribute(priority=8)
    assert FieldAttribute(priority=7) <= FieldAttribute(priority=8)

    assert FieldAttribute(priority=8) > FieldAttribute(priority=7)
    assert FieldAttribute(priority=8) >= FieldAttribute(priority=7)



# Generated at 2022-06-23 05:49:16.548136
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute()

    assert a.isa is None
    assert a.private is False
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False
    try:
        Attribute(default=dict())
        assert "AnsibleException not raised"
    except TypeError:
        pass


# Generated at 2022-06-23 05:49:20.315593
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # unit test python 2 and python 3
    import sys
    if sys.version_info < (3, 4):
        assert Attribute() <= Attribute()
    else:
        assert (Attribute() <= Attribute()) is NotImplemented


# Generated at 2022-06-23 05:49:30.543932
# Unit test for constructor of class Attribute
def test_Attribute():

    # test defaults for attributes
    a = Attribute()
    assert(a.isa           is None)
    assert(a.private       is False)
    assert(a.default       is None)
    assert(a.required      is False)
    assert(a.listof        is None)
    assert(a.priority      == 0)
    assert(a.class_type    is None)
    assert(a.always_post_validate is False)
    assert(a.inherit == True)
    assert(a.alias is None)
    assert(a.extend is False)
    assert(a.prepend is False)
    assert(a.static is False)

    # test all attribute values

# Generated at 2022-06-23 05:49:35.370109
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Test that __le__ method of class Attribute returns false
    when __eq__ of both objects are set to true by changing the
    priority of a copy of both objects.
    """
    test_attr = Attribute()
    test_attr2 = Attribute()
    test_attr.priority = 2
    test_attr2.priority = 2
    assert test_attr <= test_attr2



# Generated at 2022-06-23 05:49:40.156789
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a1.priority = 1

    a2 = Attribute()
    a2.priority = 2

    a3 = Attribute()
    a3.priority = 2

    assert a1 != a2
    assert a2 == a3


# Generated at 2022-06-23 05:49:44.511703
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 10
    attr2.priority = 5
    assert attr1 > attr2


# Generated at 2022-06-23 05:49:55.993351
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None, 'FieldAttribute: isa must be None'
    assert attr.private == False, 'FieldAttribute: private must be False'
    assert attr.default == None, 'FieldAttribute: default must be None'
    assert attr.required == False, 'FieldAttribute: required must be False'
    assert attr.listof == None, 'FieldAttribute: listof must be None'
    assert attr.priority == 0, 'FieldAttribute: priority must be 0'
    assert attr.class_type == None, 'FieldAttribute: class_type must be None'
    assert attr.always_post_validate == False, 'FieldAttribute: always_post_validate must be False'
    assert attr.inherit == True, 'FieldAttribute: inherit must be True'
   

# Generated at 2022-06-23 05:50:03.762883
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=4, isa=None, private=False, default=None, required=False, listof=None,
                      class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                      prepend=False, static=False)
    attr2 = Attribute(priority=4, isa=None, private=False, default=None, required=False, listof=None,
                      class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                      prepend=False, static=False)
    assert attr1.__ge__(attr2)


# Generated at 2022-06-23 05:50:06.957422
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a0 = Attribute()
    a1 = Attribute()
    assert a0 <= a0
    assert a1 <= a0
    assert a1 <= a1
    assert a0 <= a1


# Generated at 2022-06-23 05:50:16.769561
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test for constructor of Attribute class
    """
    attr = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                     priority=0, class_type=None, inherit=True, alias=None, extend=False, prepend=False)

    assert(attr.isa == 'dict')
    assert(attr.private == False)
    assert (attr.default == None)
    assert(attr.required == False)
    assert(attr.listof == None)
    assert(attr.priority == 0)
    assert(attr.class_type == None)
    assert(attr.inherit == True)
    assert(attr.alias == None)
    assert(attr.extend == False)
    assert(attr.prepend == False)



# Generated at 2022-06-23 05:50:18.398295
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    # Unit test to test the Attribute __ne__ method

    a = Attribute()
    b = Attribute()

    a.priority = 1
    b.priority = 2

    assert a != b



# Generated at 2022-06-23 05:50:24.042887
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    c = Attribute(priority=3)

    assert not a <= b  # False
    assert a <= c      # True



# Generated at 2022-06-23 05:50:32.007803
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    f1 = FieldAttribute(priority=0)
    f2 = FieldAttribute(priority=1)
    a1 = f1 == f2
    assert a1 == False, a1
    a2 = f1 != f2
    assert a2 == True, a2
    a3 = f1 > f2
    assert a3 == False, a3
    a4 = f1 >= f2
    assert a4 == False, a4
    a5 = f1 < f2
    assert a5 == True, a5
    a6 = f1 <= f2
    assert a6 == True, a6

    return True



# Generated at 2022-06-23 05:50:42.424023
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """Test method __eq__ of class Attribute"""

    # Test with required
    attr = Attribute(required=True)
    other = Attribute(required=True)
    assert attr == other

    # Test with different required values
    attr = Attribute(required=True)
    other = Attribute(required=False)
    assert attr != other

    # Test with different isa values
    attr = Attribute(isa='string')
    other = Attribute(isa='integer')
    assert attr != other

    # Test with different isa types
    attr = Attribute(isa='string')
    other = Attribute(isa=42)
    assert attr != other

    # Test with different default values
    attr = Attribute(default='string')
    other = Attribute(default='integer')
    assert att

# Generated at 2022-06-23 05:50:47.772100
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_a = Attribute(priority=0)
    attr_b = Attribute(priority=1)
    assert attr_a.__le__(attr_b) == True
    assert attr_b.__le__(attr_a) == False
    #
    attr_a = Attribute(priority=1)
    attr_b = Attribute(priority=1)
    assert attr_a.__le__(attr_b) == True
    assert attr_b.__le__(attr_a) == True


# Generated at 2022-06-23 05:50:50.115764
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority = 0)
    attr2 = Attribute(priority = 0)
    assert attr.__ge__(attr2)


# Generated at 2022-06-23 05:51:00.910855
# Unit test for constructor of class Attribute
def test_Attribute():
    # Make sure that we can't create an Attribute object with a mutable default
    from nose.tools import assert_raises
    assert_raises(TypeError, Attribute, default=[])

    # Make sure that we can create an Attribute object with an immutable default
    Attribute(default=42)
    Attribute(default=None)
    Attribute(default=True)

    # Make sure that we can create an Attribute object with a callable default
    Attribute(default=lambda: [])
    Attribute(default=lambda: None)
    Attribute(default=lambda: True)

    # Make sure that we can use the comparison operators on Attribute objects
    assert(Attribute(default=42) == Attribute(default=42))
    assert(Attribute(default=42) != Attribute(default=43))

# Generated at 2022-06-23 05:51:03.841440
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from ansible.module_utils.basic.FieldAttribute import FieldAttribute
    x=FieldAttribute(priority=1)
    y=FieldAttribute(priority=1)
    assert x <= y
    assert y <= x


# Generated at 2022-06-23 05:51:05.274666
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # TODO: create unit test
    pass


# Generated at 2022-06-23 05:51:11.517379
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    attr2 = Attribute(private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr1 != attr2
test_Attribute___eq__()


# Generated at 2022-06-23 05:51:17.228302
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    #Test with different priority numbers
    attribute1=Attribute(priority=123)
    attribute2=Attribute(priority=345)
    assert attribute1 == attribute2
    #Test with different priority numbers
    attribute1=Attribute(priority=123)
    attribute2=Attribute(priority=123)
    assert attr

# Generated at 2022-06-23 05:51:21.195700
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert (a == c) == True
    assert (a == b) == False


# Generated at 2022-06-23 05:51:26.577304
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute().__gt__(Attribute()) == False
    assert Attribute().__gt__(Attribute()) == False
    assert Attribute(priority=1).__gt__(Attribute(priority=0)) == True
    assert Attribute(priority=0).__gt__(Attribute(priority=1)) == False
    assert Attribute(priority=1).__gt__(Attribute(priority=1)) == False


# Generated at 2022-06-23 05:51:35.171209
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(default=None, required=False, always_post_validate=False, alias=None, prepend=False, static=False, inherit=True, extend=False, isa=None, listof=None, class_type=None, private=False, priority=0)
    b = Attribute(default=None, required=False, always_post_validate=False, alias=None, prepend=False, static=False, inherit=True, extend=False, isa=None, listof=None, class_type=None, private=False, priority=-1)
    result = a.__ne__(b)
    assert result


# Generated at 2022-06-23 05:51:37.405592
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr < attr2

# Generated at 2022-06-23 05:51:40.090057
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert not a1 > a2
    assert a2 > a1


# Generated at 2022-06-23 05:51:45.770755
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    '''
    This is the unit test for constructor of class FieldAttribute
    '''
    field_attribute = FieldAttribute(isa=dict, inherit=False, class_type='some_class')
    assert field_attribute.isa == dict
    assert field_attribute.inherit == False
    assert field_attribute.class_type == 'some_class'


# Generated at 2022-06-23 05:51:48.657835
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=5)
    assert attr >= Attribute(priority=5)
    assert attr >= Attribute(priority=4)
    assert not attr >= Attribute(priority=6)


# Generated at 2022-06-23 05:51:56.680503
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.errors import AnsibleParserError
    #test_Attribute1 Test constructor of class Attribute
    field = Attribute(isa='bool')
    assert field.isa == 'bool'

    #test_Attribute2 Test constructor of class Attribute
    field = Attribute(isa='bool',private=True)
    assert (field.private == True and field.isa == 'bool')

    #test_Attribute3 Test constructor of class Attribute
    field = Attribute(isa='bool',private=True,default=True)
    assert (field.private == True and field.isa == 'bool' and field.default == True)

    #test_Attribute4 Test constructor of class Attribute
    field = Attribute(isa='bool',private=True,default=True,required=True)

# Generated at 2022-06-23 05:52:01.712375
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(None, False, None, False, False, 0)
    b = Attribute(None, False, None, False, False, 1)
    assert a < b
    assert b > a
    assert b >= a
    assert a <= b
    assert a != b
    assert b == b
    assert a == a


# Generated at 2022-06-23 05:52:10.211308
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    import unittest

    class TestAttribute___lt__(unittest.TestCase):

        def test_attr1_lt_attr2(self):
            attr1 = Attribute(priority=1)
            attr2 = Attribute(priority=2)

            self.assertTrue(attr1 < attr2)

        def test_attr1_not_lt_attr2(self):
            attr1 = Attribute(priority=2)
            attr2 = Attribute(priority=2)

            self.assertFalse(attr1 < attr2)

        def test_attr1_not_lt_attr1(self):
            attr1 = Attribute(priority=1)
            attr2 = Attribute(priority=1)

            self.assertFalse(attr1 < attr2)

    unittest.main()



# Generated at 2022-06-23 05:52:12.367271
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field1 = FieldAttribute()
    field2 = FieldAttribute()
    assert field1 != field2


# Generated at 2022-06-23 05:52:15.669843
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    f = Attribute()
    f.priority = 5
    assert f > Attribute()
    assert f > Attribute(priority=4)
    assert not f > Attribute(priority=5)
    assert not f > Attribute(priority=6)

# Generated at 2022-06-23 05:52:17.391059
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a <= b

# Generated at 2022-06-23 05:52:26.348415
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', private=True, default=10, required=True,
                  listof='string', priority=0, class_type='test',
                  always_post_validate=True, inherit=True, alias='alias')
    for attr in ['isa', 'private', 'default', 'required', 'listof', 'priority',
                 'class_type', 'always_post_validate', 'inherit', 'alias']:
        assert getattr(a, attr) == locals()[attr]

