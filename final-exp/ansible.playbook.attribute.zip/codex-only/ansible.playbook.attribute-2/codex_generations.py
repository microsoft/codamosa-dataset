

# Generated at 2022-06-23 05:42:18.019610
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=1)
    assert attr < Attribute(priority=2)


# Generated at 2022-06-23 05:42:27.425557
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=True)
    b = Attribute(isa='str', default_value='hello')
    c = Attribute(isa='str', required=True)
    d = Attribute(isa='list', listof='str')
    e = Attribute(isa='list', listof='str', priority=10)
    f = Attribute(isa='class', class_type=Attribute)
    g = Attribute(always_post_validate=True)
    h = Attribute(inherit=False)
    i = Attribute(alias='foo')
    j = Attribute(extend=True)
    k = Attribute(prepend=True)
    l = Attribute(static=True)

    assert a.isa == 'str'
    assert a.private == True

# Generated at 2022-06-23 05:42:34.711235
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    test __lt__
    """
    attr1 = FieldAttribute()
    assert attr1.priority == 0
    attr2 = FieldAttribute()
    assert attr2.priority == 0
    attr3 = FieldAttribute()
    assert attr3.priority == 0
    attr3.priority = 2
    assert attr3.priority == 2
    assert attr1.__lt__(attr3) is False
    assert attr3.__lt__(attr1) is True
    assert attr2.__lt__(attr1) is False
    assert attr1.__lt__(attr2) is False
    assert attr2.__lt__(attr3) is True
    assert attr3.__lt__(attr2) is False



# Generated at 2022-06-23 05:42:44.521411
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Calling class Attribute()
    a1 = Attribute(is_a='1', priority=0)
    a2 = Attribute(is_a='2', priority=1)
    a3 = Attribute(is_a='3', priority=2)
    a4 = Attribute(is_a='4', priority=3)
    a5 = Attribute(is_a='5', priority=4)
    print('Attribute_List: ', a1, a2, a3, a4, a5)

    # Creating an instance of list
    l = [a1, a2, a3, a4, a5]
    print('List', l)

    l.sort()
    print('Sorted list', l)

    # Calling class Attribute()
    b1 = Attribute(is_a='11', priority=0)

# Generated at 2022-06-23 05:42:47.816431
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(
        private=False,
        default=False,
        required=False,
        listof=None,
        always_post_validate=False,
        inherit=True,
    )
    assert isinstance(a, Attribute)



# Generated at 2022-06-23 05:42:51.711254
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 2)
    assert(a != b)


# Generated at 2022-06-23 05:42:58.872973
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    assert( (a < b) == True )
    assert( (a > b) == False )

    b.priority = 1
    assert( (a < b) == True )
    assert( (a > b) == False )

    a.priority = 2
    assert( (a < b) == False )
    assert( (a > b) == True )

    a.priority = 1
    assert( (a < b) == False )
    assert( (a == b) == True )
    assert( (a > b) == False )


# Generated at 2022-06-23 05:43:01.035783
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute(isa='list', default=list())
    assert obj is not None, "Attribute object is null"

# Generated at 2022-06-23 05:43:03.964715
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()

    if not (a1 >= a2):
        raise AssertionError("Attribute.__ge__ not working")


# Generated at 2022-06-23 05:43:15.024310
# Unit test for constructor of class Attribute
def test_Attribute():

    # Testing initalization of Attribute object
    test_attr = Attribute()

    # Should be a set of Attribute object
    assert test_attr.isa is None, "isa is not None"
    assert not test_attr.private, "private is not False"
    assert test_attr.default is None, "default is not None"
    assert not test_attr.required, "required is not False"
    assert test_attr.listof is None, "listof is not None"
    assert test_attr.priority == 0, "priority is not 0"
    assert test_attr.class_type is None, "class_type is not None"
    assert not test_attr.always_post_validate, "always_post_validate is not False"
    assert test_attr.inherit, "inherit is not True"


# Generated at 2022-06-23 05:43:23.160983
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attrOne = Attribute(priority=1)
    attrTwo = Attribute(priority=2)
    if not attrOne.__ne__(attrTwo):
        raise AssertionError('method __ne__ should be true for priority 1 != priority 2')
    if not attrTwo.__ne__(attrOne):
        raise AssertionError('method __ne__ should be true for priority 2 != priority 1')

    attrOne = Attribute(priority=2)
    attrTwo = Attribute(priority=2)
    if attrOne.__ne__(attrTwo):
        raise AssertionError('method __ne__ should be false for priority 2 == priority 2')
    if attrTwo.__ne__(attrOne):
        raise AssertionError('method __ne__ should be false for priority 2 == priority 2')




# Generated at 2022-06-23 05:43:26.431895
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    '''
    This is a method to test __ne__ function of Attribute class.
    :return:
    '''
    # TODO
    attribute = Attribute(priority=100)
    assert attribute.__ne__(attribute)

# Generated at 2022-06-23 05:43:37.219441
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from six import text_type

    class DummyClass(AnsibleBaseYAMLObject):
        def __init__(self, a=None, b=None, c=None, d=None, e=None, f=None, g=None, list1=None,
                     list2=None, list3=None, list4=None, list5=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self

# Generated at 2022-06-23 05:43:43.925766
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    assert a.__gt__(b) == False
    assert a.__gt__(c) == False
    assert b.__gt__(a) == True
    assert b.__gt__(c) == True
    assert c.__gt__(a) == False
    assert c.__gt__(b) == False
    assert c.__gt__(c) == False


# Generated at 2022-06-23 05:43:45.802531
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict',default='mike')
    assert a

# Generated at 2022-06-23 05:43:55.493398
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import StringIO

    fmt = StringIO()
    fmt.write("=============================================\n")
    fmt.write("======= Attribute.__init__() test =======\n")
    fmt.write("=============================================\n\n")

    # test for error
    fmt.write("Should raise an error because the default is a mutable datatype.\n")
    try:
        Attribute(default=[])
    except TypeError as e:
        fmt.write(str(e)+"\n")
    fmt.write("\n")

    # test for listof
    fmt.write("Should accept listof and bea.\n")

# Generated at 2022-06-23 05:43:56.605445
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=10) == Attribute(priority=10)



# Generated at 2022-06-23 05:44:01.102204
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)
    assert not attribute_1 <= attribute_2
    assert attribute_1 <= attribute_1
    assert attribute_2 <= attribute_2
    assert attribute_2 <= attribute_1



# Generated at 2022-06-23 05:44:09.759276
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa=None, private=False)
    Attribute(isa=None, private=True)
    Attribute(isa=None, private=False, default=False)
    Attribute(isa=None, private=False, default=1.2)
    Attribute(isa=None, private=False, default='hello')
    Attribute(isa=None, private=False, default=['hello','world'])
    Attribute(isa=None, private=False, default=('hello','world'))
    Attribute(isa=None, private=False, default=set(('hello','world')))
    Attribute(isa=None, private=False, default={'hello':'world'})
    Attribute(isa=None, private=False, default=False, required=True)

# Generated at 2022-06-23 05:44:19.861777
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test a basic constructor
    # expect no exception
    Attribute()

    # test a constructor with a single key-value pair
    try:
        Attribute(isa='dict')
    # check for the correct exception type
    except TypeError:
        assert True, "The data type for default must be immutable " \
                      "or a callable."
    # check for the right exception message
    except Exception as err:
        assert False, "Wrong error message: %s" % err.message

    # test a constructor with required=True and default=None
    # expect no exception
    Attribute(required=True, default=None)
    # test a constructor with required=True and no default value
    # expect no exception
    Attribute(required=True)

    # test a constructor with invalid value

# Generated at 2022-06-23 05:44:23.883408
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) < Attribute(priority=2)
    assert not Attribute(priority=2) < Attribute(priority=1)
    assert not Attribute(priority=1) < Attribute(priority=1)


# Generated at 2022-06-23 05:44:28.146447
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    attribute.priority = 5
    other = Attribute()
    other.priority = 3
    if attribute != other:
        print("test_Attribute___ne__() pass")
    else:
        print("test_Attribute___ne__() fail")

test_Attribute___ne__()


# Generated at 2022-06-23 05:44:32.170335
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute(priority=0)
    attribute1 = Attribute(priority=10)
    assert attribute1.__gt__(attribute) is True


# Generated at 2022-06-23 05:44:35.066465
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 >= attr1


# Generated at 2022-06-23 05:44:39.466604
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='boolean', default=False, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False)

# Generated at 2022-06-23 05:44:44.518445
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class MyObject:
        """This object is used to test whether the class FieldAttribute works well"""
        attr = FieldAttribute(isa="str", default="abc")

    obj = MyObject()
    assert obj.attr == "abc"
    obj.attr = "xyz"
    assert obj.attr == "xyz"


# Generated at 2022-06-23 05:44:48.790753
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    import pytest
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    assert a1 >= a2
    assert not a2 >= a1
    with pytest.raises(TypeError):
        a1 >= 'a1'


# Generated at 2022-06-23 05:44:50.572378
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert (a >= b)



# Generated at 2022-06-23 05:44:54.122977
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from collections import namedtuple
    attribute = Attribute
    a = attribute(priority=1)
    b = attribute(priority=0)
    assert a > b
    assert b < a


# Generated at 2022-06-23 05:44:56.729484
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=20)
    assert attr1.__lt__(attr2) == True
    assert attr2.__lt__(attr1) == False


# Generated at 2022-06-23 05:45:08.422229
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute(
        isa='list',
        class_type="list",
        always_post_validate=True,
    )

    FieldAttribute(
        isa='list',
        default=["a"],
        always_post_validate=True,
    )

    # defaults for FieldAttribute may not be mutable
    from nose.plugins.skip import SkipTest
    raise SkipTest("unable to test this case")
    FieldAttribute(
        isa='list',
        default=set(),
        always_post_validate=True,
    )


# Generated at 2022-06-23 05:45:12.419528
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
     a1 = Attribute(priority=1)
     a2 = Attribute(priority=2)
     assert a2 > a1
     assert not a1 > a2
     assert not a1 > a1
     assert not a2 > a2


# Generated at 2022-06-23 05:45:14.949525
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    expected = True
    t1 = Attribute(priority=0)
    t2 = Attribute(priority=1)
    actual = t1 >= t2
    assert actual == expected


# Generated at 2022-06-23 05:45:17.584456
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__lt__(b) is True


# Generated at 2022-06-23 05:45:25.534443
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    obj1 = Attribute(priority=1)
    obj2 = Attribute(priority=2)
    obj3 = Attribute(priority=1)

    # test __lt__ and __gt__
    assert obj1 < obj2
    assert obj1 <= obj2
    assert obj2 > obj1
    assert obj2 >= obj1
    # test __eq__ and __ne__
    assert obj1 == obj3
    assert obj1 <= obj3
    assert obj1 >= obj3
    assert not obj1 != obj3
    assert obj1 < obj3
    assert not obj1 > obj3

# Generated at 2022-06-23 05:45:34.513559
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultAES256
    import os
    test_vault_path = os.path.join(os.getcwd(), "vault_test.yml")
    if os.path.exists(test_vault_path):
        os.unlink(test_vault_path)
    test_vault_password = "test"
    test_vault_content = "test_vault_content"
    vault_lib = VaultLib(test_vault_password)
    ascii_vault = VaultAES256.encrypt(test_vault_password, test_vault_content)
    vault_lib.write_vaultfile(test_vault_path, ascii_vault)
    a

# Generated at 2022-06-23 05:45:38.151715
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    class TestAttribute:
        def __ge__(self, other):
            return other.priority >= self.priority

    test = TestAttribute()
    test.priority = 1

    test_attribute = Attribute(priority=2)

    assert test_attribute.__ge__(test) == True



# Generated at 2022-06-23 05:45:46.825390
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='integer', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=False, alias=None)
    assert f is not None
    assert f.isa == 'integer'
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is False
    assert f.alias is None


# Generated at 2022-06-23 05:45:59.062767
# Unit test for constructor of class Attribute
def test_Attribute():

    # Default settings
    a = Attribute()
    assert a.required == False
    assert a.private == False
    assert a.inherit == True
    assert a.always_post_validate == False
    assert a.default == None

    # Required
    a = Attribute(required=True)
    assert a.required == True

    # Private
    a = Attribute(private=True)
    assert a.private == True

    # Default
    a = Attribute(default=False)
    assert a.default == False
    a = Attribute(default='foo')
    assert a.default == 'foo'
    a = Attribute(default=[1, 2, 3])
    assert a.default == [1, 2, 3]
    a = Attribute(default=(1, 2, 3))

# Generated at 2022-06-23 05:46:02.342419
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_0 = Attribute()
    attribute_1 = Attribute()
    bool_0 = attribute_0.__ge__(attribute_1)
    assert bool_0 == False



# Generated at 2022-06-23 05:46:06.856925
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=1)
    assert attribute1.__ge__(attribute2) == False
    assert attribute2.__ge__(attribute1) == True


# Generated at 2022-06-23 05:46:16.504933
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa=list,
        private=True,
        default=list,
        required=False,
        listof=int,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert(attribute.isa == list)
    assert(attribute.private == True)
    assert(attribute.default == list)
    assert(attribute.required == False)
    assert(attribute.listof == int)
    assert(attribute.priority == 0)
    assert(attribute.class_type == None)
    assert(attribute.always_post_validate == False)
    assert(attribute.inherit == True)
   

# Generated at 2022-06-23 05:46:26.593285
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    from ansible.module_utils.six import iteritems, string_types
    from ansible.parsing.yaml.loader import AttributeDict

    with pytest.raises(TypeError):
        field = FieldAttribute(isa='dict', default={})
    with pytest.raises(TypeError):
        field = FieldAttribute(isa='list', default=[1, 2, 3])
    with pytest.raises(TypeError):
        field = FieldAttribute(isa='set', default=set([1, 2, 3]))

    field = FieldAttribute(isa='dict', default=AttributeDict)

# Generated at 2022-06-23 05:46:30.809119
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=3)
    b = Attribute(priority=3)
    assert a.__ge__(b)
    assert b.__ge__(a)
    c = Attribute(priority=2)
    assert not a.__ge__(c)
    assert not c.__ge__(a)


# Generated at 2022-06-23 05:46:34.774693
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a0 = Attribute(isa=int, default=42, required=True, priority=0)
    a1 = Attribute(isa=int, default=43, required=True, priority=1)
    assert a0 == a0
    assert not a0 == a1



# Generated at 2022-06-23 05:46:38.149881
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a < b
    assert b > a
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b



# Generated at 2022-06-23 05:46:44.066595
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=42)
    a2 = Attribute(priority=42)
    if a1.__lt__(a2):
        assert False
    if a2.__lt__(a1):
        assert False
    a1 = Attribute(priority=-42)
    a2 = Attribute(priority=42)
    if not a1.__lt__(a2):
        assert False
    if a2.__lt__(a1):
        assert False

# Unit tests for class FieldAttribute

# Generated at 2022-06-23 05:46:45.538208
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print(Attribute().__ne__(Attribute(priority=1)))


# Generated at 2022-06-23 05:46:54.400594
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)
    attr4 = Attribute(priority=3)

    assert attr1.__gt__(attr2) == False
    assert attr2.__gt__(attr1) == False
    assert attr1.__gt__(attr3) == False
    assert attr3.__gt__(attr1) == True
    assert attr1.__gt__(attr4) == False
    assert attr4.__gt__(attr1) == True
    assert attr2.__gt__(attr3) == False
    assert attr3.__gt__(attr2) == True
    assert attr2.__gt__(attr4) == False
    assert att

# Generated at 2022-06-23 05:46:57.688421
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """Test __ne__ method of the Attribute class"""
    # Init an instance of Attribute
    obj = Attribute()

    # Test the __ne__ method
    assert (obj != None) is True
    obj.priority = 1
    assert (obj != None) is False


# Generated at 2022-06-23 05:47:00.032007
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2

    assert a.__ne__(b) is True


# Generated at 2022-06-23 05:47:02.720421
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    fieldattr1 = FieldAttribute(priority=1)
    fieldattr2 = FieldAttribute(priority=2)

    assert fieldattr2.__ge__(fieldattr1)



# Generated at 2022-06-23 05:47:05.176686
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    with pytest.raises(TypeError):
        fa = FieldAttribute(default=[1,2,3])

# Generated at 2022-06-23 05:47:08.896242
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    myAttribute = Attribute()
    myAttribute2 = Attribute()
    myAttribute.priority = 1
    myAttribute2.priority = 2
    assert myAttribute2 >= myAttribute


# Generated at 2022-06-23 05:47:12.110514
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr1.priority = 3
    
    attr2 = Attribute()
    attr2.priority = 4

    assert attr1 != attr2


# Generated at 2022-06-23 05:47:15.646507
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    Attribute_obj = Attribute()
    Attribute_other_obj = Attribute()
    Attribute_obj.priority = 3
    Attribute_other_obj.priority = 5
    assert Attribute_obj == Attribute_other_obj


# Generated at 2022-06-23 05:47:22.016968
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Verify that __ne__() returns True when priorities are different.
    a = Attribute(priority=5)
    b = Attribute(priority=7)
    assert(a != b)

    # Verify that __ne__() returns False when priorities are the same.
    c = Attribute(priority=9)
    d = Attribute(priority=9)
    assert(c != d == False)


# Generated at 2022-06-23 05:47:26.966099
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    expected = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        extend=False,
        prepend=False,
    )
    assert attr == expected


# Generated at 2022-06-23 05:47:30.790083
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    attr3 = Attribute(priority=1)
    assert (attr1 != attr2) == False
    assert (attr1 != attr3) == True


# Generated at 2022-06-23 05:47:33.320489
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 > a1)



# Generated at 2022-06-23 05:47:40.364804
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    test_cases = (
        (Attribute(priority=1), Attribute(priority=0), True),
        (Attribute(priority=0), Attribute(priority=0), False),
        (Attribute(priority=0), Attribute(priority=1), False),
    )
    for a,b,expected in test_cases:
        result = a.__lt__(b)
        assert expected == result, 'Attribute.__lt__(%s, %s) => %s, expected %s' % (a.priority, b.priority, result, expected)



# Generated at 2022-06-23 05:47:51.562413
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 <= a1)
    assert(a1.__le__(a2))
    assert(a2 >= a1)
    assert(a1.__ge__(a2))
    assert(not a1 <= a1)
    assert(not a1.__le__(a1))
    assert(not a1 >= a1)
    assert(not a1.__ge__(a1))

    a3 = Attribute(priority=1)
    assert(a1 <= a3)
    assert(a3.__le__(a1))
    assert(a1 >= a3)
    assert(a3.__ge__(a1))
    assert(not a1 <= a1)

# Generated at 2022-06-23 05:47:54.372611
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a1 < a2


# Generated at 2022-06-23 05:48:04.568782
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(
        isa = list,
        private = False,
        default = [],
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
    )

    assert a.isa == list
    b = a
    assert a == b

# Generated at 2022-06-23 05:48:14.941765
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleError
    from ansible.parsing import vault
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_yaml_config_file
    from ansible.utils.vars import preprocess_vars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-23 05:48:24.161384
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def tmp_func():
        return 1
    # tests for defaults and exception throws
    assert FieldAttribute().isa == None
    assert FieldAttribute().private == False
    assert FieldAttribute().default == None
    assert FieldAttribute().required == False
    assert FieldAttribute().inherit == True
    assert FieldAttribute().listof == None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type == None
    assert FieldAttribute().always_post_validate == False
    assert FieldAttribute(isa='dict').isa == "dict"
    assert FieldAttribute(isa='method', default=tmp_func).isa == "method"
    assert FieldAttribute(isa='list', default=[]).isa == "list"
    assert FieldAttribute(isa='int', default=0).isa == "int"
    assert FieldAttribute(isa='str', default='').isa

# Generated at 2022-06-23 05:48:30.446215
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='str',
                          private=False,
                          default=None,
                          required=False,
                          listof=None,
                          priority=0,
                          class_type=None,
                          always_post_validate=False,
                          inherit=True,
                          alias=None,
                          extend=False,
                          prepend=False,
                          static=False) is not None



# Generated at 2022-06-23 05:48:35.430476
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    c = Attribute(priority=1)
    d = Attribute(priority=2)
    e = Attribute(priority=3)
    assert a.__ge__(a)
    assert a.__ge__(b)
    assert a.__ge__(c)
    assert b.__ge__(a)
    assert c.__ge__(a)
    assert a.__ge__(d)
    assert d.__ge__(a)


# Generated at 2022-06-23 05:48:38.096904
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', required=True)
    assert a.isa == 'list'
    assert a.required is True


# Generated at 2022-06-23 05:48:43.055195
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=2)
    assert not Attribute(priority=1) > Attribute(priority=1)
    assert not Attribute(priority=2) > Attribute(priority=1)

# Generated at 2022-06-23 05:48:47.231819
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    # __ne__ is not implemented in the class
    # so should always return NotImplemented
    assert attr.__ne__(1) == NotImplemented
#

# Generated at 2022-06-23 05:48:50.109699
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    assert attribute_1 <= attribute_2


# Generated at 2022-06-23 05:48:56.474380
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(1)
    assert attr.priority == 1
    assert attr.isa is None
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False
    assert attr.private is False


# Generated at 2022-06-23 05:49:07.456516
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    d = dict(isa='dict', default={}, required=False, inherit=True)
    a = FieldAttribute(isa='dict', default={}, required=False, inherit=True)
    assert d == a.__dict__
    a = FieldAttribute(isa='ISA', default=1, required=False, inherit=True)
    assert a.isa == 'ISA'
    assert a.default == 1
    assert a.required == False
    assert a.inherit == True
    a = FieldAttribute(isa='dict', default=[], required=False, inherit=True)
    assert a.isa == 'dict'
    assert a.default == []
    assert a.required == False
    assert a.inherit == True



# Generated at 2022-06-23 05:49:12.216385
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attributeA = Attribute(priority=0)
    attributeB = Attribute(priority=0)
    attributeC = Attribute(priority=1)

    assert attributeA.__eq__(attributeB)
    assert not attributeA.__eq__(attributeC)
# end of function test_Attribute___eq__



# Generated at 2022-06-23 05:49:19.964361
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute(isa='str', required=True)
    x2 = FieldAttribute(isa='str')
    assert x.isa == 'str'
    assert x.required == True
    assert x.inherit == True
    assert x.default == None

    assert x2.isa == 'str'
    assert x2.required == False
    assert x2.inherit == True
    assert x2.default == None




# Generated at 2022-06-23 05:49:28.156939
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='boolean')
    assert attr.isa == 'boolean'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-23 05:49:31.534691
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_attribute = FieldAttribute(priority=1)
    field_attribute_2 = FieldAttribute(priority=2)
    assert field_attribute.__lt__(field_attribute_2)

# Generated at 2022-06-23 05:49:41.540968
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def field():
        return FieldAttribute(
            isa='str',
            private=True,
            default=None,
            required=False,
            listof='str',
            priority=0,
            class_type='str'
        )

    assert field().isa == 'str'
    assert field().private == True
    assert field().default is None
    assert field().required == False
    assert field().listof == 'str'
    assert field().priority == 0
    assert field().class_type == 'str'


# ignore the docstring for this class, it's not meant for public consumption

# Generated at 2022-06-23 05:49:43.495128
# Unit test for constructor of class Attribute
def test_Attribute():
    default = [ 'foo', 'bar' ]
    assert Attribute(default=default)

# Generated at 2022-06-23 05:49:45.015170
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute() # compare the same class


# Generated at 2022-06-23 05:49:56.404046
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a, b = Attribute(), Attribute()

    # should return False for same priorities
    a.priority = 0
    b.priority = 0
    assert not a.__lt__(b)
    assert not b.__lt__(a)
    assert not b.__lt__(b)

    # higher priority comes first
    a.priority = 1
    b.priority = 0
    assert a.__lt__(b)
    assert not b.__lt__(a)

    # lower priority comes last
    a.priority = 0
    b.priority = 1
    assert b.__lt__(a)
    assert not a.__lt__(b)


    # when priorities are equal, it falls back to comparing object ids,
    # but only if one of the objects doesn't have a priority set
    a.priority = 0

# Generated at 2022-06-23 05:50:00.049840
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    p = Attribute()
    p.priority = 1
    assert p.__ne__(Attribute()) == True
    assert p.__ne__(Attribute(priority=1)) == False


# Generated at 2022-06-23 05:50:06.590136
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=100)
    b = Attribute(priority=200)
    assert a < b
    assert b > a
    a = Attribute(priority=300)
    b = Attribute(priority=300)
    assert a >= b
    assert b <= a
    a = Attribute(priority=400)
    b = Attribute(priority=500)
    assert a <= b
    assert b >= a



# Generated at 2022-06-23 05:50:13.183426
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', default={}, required=True)
    assert attr.isa == 'dict'
    assert attr.default == {}
    assert attr.required == True

    dict = {'a': '1', 'b': 2}
    attr = Attribute(isa='dict', default=dict, required=False)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == False

# Generated at 2022-06-23 05:50:16.515591
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr2 = Attribute()

    attr1.priority = 4
    attr2.priority = 4
    result = attr1.__lt__(attr2)
    assert(result == False)

    attr1.priority = 4
    attr2.priority = 3
    result = attr1.__lt__(attr2)
    assert(result == False)

    attr1.priority = 4
    attr2.priority = 5
    result = attr1.__lt__(attr2)
    assert(result == True)


# Generated at 2022-06-23 05:50:26.365021
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class MyObject(object):
        field = FieldAttribute(isa='dict')

    # isa
    try:
        MyObject(field=dict())
    except TypeError:
        test = False
    assert test
    try:
        MyObject(field=list())
        test = False
    except TypeError:
        test = True
    assert test

    # default
    try:
        MyObject(field=None)
    except TypeError:
        test = False
    assert test

    # required
    try:
        MyObject()
        test = False
    except TypeError:
        test = True
    assert test

    # class_type
    MyObject(field=dict(a=1))

    # always_post_validate
    # inherit
    # alias
    # extend
    # prepend
    # static



# Generated at 2022-06-23 05:50:29.345325
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority=1
    b = Attribute()
    b.priority=2
    c = Attribute()
    c.priority=1
    assert (a != b)
    assert (a != c) is False


# Generated at 2022-06-23 05:50:30.385873
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    pass


# Generated at 2022-06-23 05:50:33.563091
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__ge__(attr2) == False
    assert attr2.__ge__(attr1) == True



# Generated at 2022-06-23 05:50:42.383912
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Tests the method __gt__ of class Attribute for the case when the
    # priority of the two objects are not equal.
    attrib = Attribute(priority=50)
    attrib1 = Attribute(priority=20)
    assert attrib.__gt__(attrib1) is True
    assert attrib1.__gt__(attrib) is False

    # Tests the method __gt__ of class Attribute for the case when the
    # priority of the two objects are equal.
    attrib2 = Attribute(priority=20)
    assert attrib1.__gt__(attrib2) is False
    assert attrib2.__gt__(attrib1) is False


# Generated at 2022-06-23 05:50:46.826541
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(priority=3)
    attr_2 = Attribute(priority=3)
    assert not attr_1.__ne__(attr_2)



# Generated at 2022-06-23 05:50:56.238437
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # basic comparison
    a1 = Attribute(priority=-4)
    a2 = Attribute(priority=-1)
    assert a1 <= a2   # a1.priority <= a2.priority
    assert a2 >= a1   # a1.priority <= a2.priority
    # comparison with equal priority
    a1 = Attribute(priority=-4)
    a2 = Attribute(priority=-4)
    assert a1 <= a2   # a1.priority <= a2.priority (for equality)
    assert a2 >= a1   # a1.priority <= a2.priority (for equality)


# Generated at 2022-06-23 05:50:59.108591
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2



# Generated at 2022-06-23 05:51:02.422028
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    Attribute1 = Attribute(priority=4)
    Attribute2 = Attribute(priority=4)
    assert Attribute1.__ge__(Attribute2)


# Generated at 2022-06-23 05:51:03.248682
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute is not None



# Generated at 2022-06-23 05:51:11.197930
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    from collections import namedtuple

    TestClass = namedtuple('TestClass', ['value'])

    attr = Attribute(
        isa=TestClass,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    TestClass1 = namedtuple('TestClass1', ['value'])


# Generated at 2022-06-23 05:51:16.242248
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print('Unit test for method __ge__ of class Attribute starts')

    attr1 = FieldAttribute(default=0, priority=7)
    attr2 = FieldAttribute(default=0, priority=1)
    if attr1.__ge__(attr2):
        print('Attribute __ge__ test passed.')
    else:
        print('Attribute __ge__ test failed')

    print('Unit test for method __ge__ of class Attribute ends')


# Generated at 2022-06-23 05:51:19.179529
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = "{'isa': 'str'}"
    b = "{'isa': 'str'}"
    assert a != b


# Generated at 2022-06-23 05:51:30.286436
# Unit test for constructor of class Attribute
def test_Attribute():

    # Dummy class
    class Dummy:
        pass

    # Ensure all attributes are set to the proper values
    d = Dummy()
    d.aka = 'test'
    d.bar = 'yes'
    a = Attribute(isa='test',
                  private=True,
                  default='yes',
                  required=True,
                  listof='yes',
                  priority=1,
                  class_type=d,
                  always_post_validate=True,
                  inherit=True,
                  alias='aka',
                  extend=False,
                  prepend=False)

    assert a.isa == 'test'
    assert a.private is True
    assert a.default == 'yes'
    assert a.required is True
    assert a.listof == 'yes'
    assert a.priority == 1
    assert a.class_

# Generated at 2022-06-23 05:51:34.068573
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    obj = Attribute('', False, None, False, None, 0)
    obj1 = Attribute('', False, None, False, None, 0)
    # Test with two same object
    assert obj == obj1



# Generated at 2022-06-23 05:51:38.051200
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert (Attribute(priority=2) > Attribute(priority=1)) is True
    assert (Attribute(priority=1) > Attribute(priority=1)) is False
    assert (Attribute(priority=1) > Attribute(priority=2)) is False


# Generated at 2022-06-23 05:51:42.842804
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=5)
    attribute2 = Attribute(priority=5)
    attribute3 = Attribute(priority=1)
    assert attribute1 < attribute3
    assert not (attribute3 < attribute1)
    try:
        attribute1 < attribute2
        assert False
    except:
        pass


# Generated at 2022-06-23 05:51:47.413217
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'

# Generated at 2022-06-23 05:51:56.778660
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa='dict',
        private=False,
        default=False,
        required=True,
        listof='str',
        priority=10,
        class_type=False,
        always_post_validate=False,
        inherit=False,
        alias='foo',
    )
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == False
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 10
    assert attr.class_type == False
    assert attr.always_post_validate == False
    assert attr.inherit == False
    assert attr.alias == 'foo'



# Generated at 2022-06-23 05:52:00.632713
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert (Attribute(priority=5) >= Attribute(priority=5))
    assert (Attribute(priority=5) >= Attribute(priority=4))
    assert not(Attribute(priority=4) >= Attribute(priority=5))


# Generated at 2022-06-23 05:52:03.505776
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    print(a >= b)
    print(b >= a)



# Generated at 2022-06-23 05:52:07.613473
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute()
    attribute2 = Attribute()
    attribute3 = Attribute(priority=100)
    assert attribute1 == attribute2
    assert attribute1 != attribute3

# Unit Tests for methods __lt__ and __gt__ of class Attribute

# Generated at 2022-06-23 05:52:11.724502
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    var1 = Attribute(priority=1)
    var2 = Attribute(priority=2)
    print(type(var1.__gt__(var2)))
    assert var1.__gt__(var2) is False
    assert var2.__gt__(var1) is True

# Generated at 2022-06-23 05:52:14.754382
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a1.priority = 2
    a2 = Attribute()
    a2.priority = 2
    assert a1.__ge__(a2) is True


# Generated at 2022-06-23 05:52:19.873385
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    attr_first = Attribute(priority = 1)
    attr_second = Attribute(priority = 2)

    assert attr_first.priority <= attr_second.priority
    assert attr_first <= attr_second
    assert attr_second.priority > attr_first.priority
    assert attr_second > attr_first