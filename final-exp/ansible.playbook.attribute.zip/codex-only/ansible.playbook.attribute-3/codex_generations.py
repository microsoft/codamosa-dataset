

# Generated at 2022-06-23 05:42:30.008035
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    foo = Attribute(priority=0)
    bar = Attribute(priority=1)

    assert not (foo >= bar)
    assert not (foo >= 0)
    assert not (foo >= False)
    assert foo >= None
    assert foo >= foo
    assert foo >= Attribute(priority=0)
    assert bar >= Attribute(priority=1)
    assert not (foo >= Attribute(priority=1))
    assert not (bar >= Attribute(priority=0))
    assert bar >= Attribute(priority=0)


# Generated at 2022-06-23 05:42:32.077775
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    b.priority = 1
    assert a.__ge__(b)


# Generated at 2022-06-23 05:42:41.758740
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # The 'isa' field can be a string representation of any yaml basic datatype, python class, or percent
    # Note that if 'default' is set, 'required' must also be set
    assert FieldAttribute(isa='list', default=[])
    assert FieldAttribute(isa='str', default='')
    assert FieldAttribute(isa='dict', default={})
    assert FieldAttribute(isa='bool', default=False)
    assert FieldAttribute(isa='complex', default=complex('2 - 3j'))
    assert FieldAttribute(isa='float', default=2.0)
    assert FieldAttribute(isa='int', default=2)
    assert FieldAttribute(isa='long', default=2)
    assert FieldAttribute(isa='unicode', default=u'unicode')
    assert FieldAttribute(isa='class', class_type=copy)
   

# Generated at 2022-06-23 05:42:46.431878
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    f1 = FieldAttribute()
    f1.priority = 5
    f2 = FieldAttribute()
    f2.priority = 5
    assert f1.__ge__(f2) == True
    f2.priority = 8
    assert f1.__ge__(f2) == False


# Generated at 2022-06-23 05:42:49.145378
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=6)
    if not (attr1 <= attr2):
        raise AssertionError("Attribute.__le__ test failed")



# Generated at 2022-06-23 05:42:58.195778
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    b = Attribute(isa=int)
    c = Attribute(isa=int, class_type=str)
    d = Attribute(isa='class', class_type=str)

    assert a.isa is None
    assert a.private is False
    assert a.required is False
    assert a.listof is None

    assert b.isa is int
    assert b.private is False
    assert b.required is False
    assert b.listof is None

    assert c.isa is int
    assert c.private is False
    assert c.required is False
    assert c.listof is None
    assert c.class_type == str

    assert d.isa == 'class'
    assert d.private is False
    assert d.required is False
    assert d.listof is None
    assert d

# Generated at 2022-06-23 05:43:07.563447
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    a = FieldAttribute()

    # These fields are set to None or False by default
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False

    # These fields should not be None or False
    assert a.isa is not False
    assert a.isa is not True
    assert a.isa is not ''

    assert a.private is not None
    assert a.private is not ''
    assert a.private is not True


# Generated at 2022-06-23 05:43:11.289363
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)
    assert not attr == attr2
    assert attr == attr3


# Generated at 2022-06-23 05:43:17.243712
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print("test Attribute __le__")
    a = Attribute()
    a.priority = 10
    b = Attribute()
    b.priority = 10
    print(a.__le__(b))
    c = Attribute()
    c.priority = 9
    print(a.__le__(c))


# Generated at 2022-06-23 05:43:19.554273
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=4)
    b = Attribute(priority=5)
    assert (a >= b)



# Generated at 2022-06-23 05:43:20.690095
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute() == Attribute()



# Generated at 2022-06-23 05:43:23.189876
# Unit test for constructor of class Attribute
def test_Attribute():
    foo = Attribute()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-23 05:43:26.138574
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute(priority=2)
    attribute2 = Attribute(priority=2)

    assert attribute1 <= attribute2
    assert attribute1 <= attribute1
    assert not attribute1 < attribute2



# Generated at 2022-06-23 05:43:30.974054
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=2)
    assert a2 != a1
    assert a2 != a3
    assert a3 != a1



# Generated at 2022-06-23 05:43:41.207794
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    data_type = ("str", "bool", "int", "dict", "list")
    #test required = False, isa = a basic datatype, listof=None, default = None
    for isa in data_type:
        a = FieldAttribute(isa = isa,required = False,listof = None, default = None)
        assert a.required == False
        assert a.isa == isa
        assert a.listof is None
        assert a.default is None
    #test required = True, isa = a basic datatype, listof=None, default = None
    for isa in data_type:
        a = FieldAttribute(isa = isa,required = True,listof = None, default = None)
        assert a.required == True
        assert a.isa == isa

# Generated at 2022-06-23 05:43:51.979434
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    class A:
        pass

    assert Attribute(priority=1) < Attribute(priority=2)
    assert Attribute(priority=2) > Attribute(priority=1)
    assert Attribute(priority=1) >= Attribute(priority=1)
    assert Attribute(priority=1) <= Attribute(priority=2)
    assert Attribute(priority=1) >= Attribute(priority=1)
    assert not Attribute(priority=2) <= Attribute(priority=1)
    assert not Attribute(priority=1) > Attribute(priority=2)
    assert Attribute(priority=1) == Attribute(priority=1)
    assert Attribute(priority=1) != Attribute(priority=2)


# Generated at 2022-06-23 05:43:54.300328
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    var1 = Attribute(priority=1)
    var2 = Attribute(priority=2)
    assert var2 != var1


# Generated at 2022-06-23 05:44:05.063265
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test constructor of Attribute class with all the parameters
    field_attribute = Attribute(
        isa=str,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )
    assert field_attribute.isa == str
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 1
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True

# Generated at 2022-06-23 05:44:15.912818
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test defaults
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority is 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False

    # Test instantiation with values

# Generated at 2022-06-23 05:44:20.500722
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b >= a
    assert a <= b
    assert a != b
    assert b != a


# Generated at 2022-06-23 05:44:24.430007
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=1)

    assert attribute2 > attribute1
    assert attribute2 >= attribute1
    assert not attribute2 < attribute1
    assert not attribute2 <= attribute1



# Generated at 2022-06-23 05:44:27.266375
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a != b



# Generated at 2022-06-23 05:44:31.299285
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a.priority < b.priority:
        return True
    else:
        return False


# Generated at 2022-06-23 05:44:33.796207
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    return_value = Attribute(priority=1000).__gt__(Attribute(priority=1))
    assert return_value is True


# Generated at 2022-06-23 05:44:38.368433
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    obj_a = Attribute() # Create a new Attribute object
    obj_b = Attribute() # Create a new Attribute object
    assert Attribute.__ge__ == obj_a.__ge__ == obj_b.__ge__
    assert obj_a.__ge__(obj_b)


# Generated at 2022-06-23 05:44:43.530284
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = FieldAttribute(priority=1)
    field2 = FieldAttribute(priority=2)
    assert field1.__ge__(field2) == False
    field3 = FieldAttribute(priority=3)
    assert field3.__ge__(field2) == True

# Generated at 2022-06-23 05:44:47.646830
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1=Attribute()
    attr2=Attribute()
    attr1.priority=attr2.priority=1
    assert (attr1==attr2)
    attr2.priority=2
    assert (not(attr1==attr2))


# Generated at 2022-06-23 05:44:50.842264
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    obj1=Attribute()
    obj1.priority=1
    obj2=Attribute()
    obj2.priority=1
    if obj1 != obj2:
        raise ValueError("obj1 != obj2")


# Generated at 2022-06-23 05:44:54.901457
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute_a = Attribute(priority=1)
    attribute_b = Attribute(priority=2)
    assert not attribute_a.__gt__(attribute_b)
    assert not attribute_b.__gt__(attribute_a)


# Generated at 2022-06-23 05:44:57.616670
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority = 3)
    b = Attribute(priority = 1)
    assert(a > b) == True
    assert(b > a) == False


# Generated at 2022-06-23 05:45:01.028499
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert(attr1 < attr2)



# Generated at 2022-06-23 05:45:04.278748
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1.__eq__(attribute2) == (False)


# Generated at 2022-06-23 05:45:14.049258
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Test if the function Attribute.__lt__() works correctly:
    #   Two Attribute objects with the same priority should not be <.
    a1 = Attribute()
    a2 = Attribute()
    if a1 < a2:
        raise Exception('Attribute.__lt__() failed on two objects with the same priority.')

    # Test if the function Attribute.__lt__() works correctly:
    #   Two Attribute objects with different priorities should make the one with lower
    #   priority smaller at the one with bigger priority.
    a3 = Attribute(priority=3)
    a5 = Attribute(priority=5)
    a7 = Attribute(priority=7)
    if not a5 < a7:
        raise Exception('Attribute.__lt__() failed on two objects with different priorities.')

    # Test if the function

# Generated at 2022-06-23 05:45:17.349241
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    print(a.__gt__(b))

if __name__ == '__main__':
    test_Attribute___gt__()

# Generated at 2022-06-23 05:45:20.824377
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert (Attribute(priorit=0) != Attribute(priorit=1))
    assert not (Attribute(priorit=1) != Attribute(priorit=1))


# Generated at 2022-06-23 05:45:26.020494
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )
    assert isinstance(f, FieldAttribute)



# Generated at 2022-06-23 05:45:29.937459
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a.__ne__(b) != True:
        return (False, "Attribute.__ne__() failed")
    return (True, None)


# Generated at 2022-06-23 05:45:33.897861
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    res = a.__lt__(b)
    if res is True or res is False:
        print("Attribute___lt__: Test Passed")
    else:
        print("Attribute___lt__: Test Failed")


# Generated at 2022-06-23 05:45:37.614406
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert a == b
    c = Attribute(priority=1)
    assert not a == c


# Generated at 2022-06-23 05:45:40.250279
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=0)
    b = Attribute(priority=2)
    assert a != b
    assert not a.__ne__(b)


# Generated at 2022-06-23 05:45:52.210273
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    attribute = Attribute(isa='test')
    assert isinstance(attribute, Attribute)
    assert attribute.isa == 'test'
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False

    attribute = Attribute(isa='test', private=True)
    assert attribute.private is True

# Generated at 2022-06-23 05:45:55.317489
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority = 3)
    b = Attribute(priority = 2)
    assert (a < b)
    assert not (b < a)


# Generated at 2022-06-23 05:45:57.302877
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 == a2


# Generated at 2022-06-23 05:46:00.045031
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Testing method __lt__ of class Attribute
    """

    attr = Attribute(priority=0)
    other = Attribute(priority=1)

    assert attr < other
    assert not (other < attr)



# Generated at 2022-06-23 05:46:04.545353
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    c = Attribute(priority=3)

    assert a < b
    assert not a > b
    assert b < a
    assert b > a
    assert not b < c
    assert not b > c


# Unit tests for method __init__ of class Attribute

# Generated at 2022-06-23 05:46:08.607594
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    first_attribute = Attribute(priority=1)
    second_attribute = Attribute(priority=2)
    assert first_attribute >= second_attribute


# Generated at 2022-06-23 05:46:12.190205
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='int', priority=0)
    a2 = Attribute(isa='bool', priority=0)
    yield (a1 == a2), "Attribute '__eq__' method test failed"


# Generated at 2022-06-23 05:46:23.031486
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    i = Attribute(None, False, None, False, None, 0, None, False, True, None, False, False, False)
    j = Attribute(None, False, None, False, None, 1, None, False, True, None, False, False, False)
    print('i > j is', i > j)
    print('j > i is', j > i)
    print('i < j is', i < j)
    print('j < i is', j < i)
    print('i >= j is', i >= j)
    print('j >= i is', j >= i)
    print('i <= j is', i <= j)
    print('j <= i is', j <= i)
    print('i == j is', i == j)
    print('j == i is', j == i)

# Generated at 2022-06-23 05:46:34.872085
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa=FieldAttribute(isa="string", private=True, default="a", required=True, listof="b", priority=0, class_type="c",
                      always_post_validate=True, inherit=False, alias="d", extend=False, prepend=False, static=True)
    assert fa.isa=="string"
    assert fa.private==True
    assert fa.default=="a"
    assert fa.required==True
    assert fa.listof=="b"
    assert fa.priority==0
    assert fa.class_type=="c"
    assert fa.always_post_validate==True
    assert fa.inherit==False
    assert fa.alias=="d"
    assert fa.extend==False
    assert fa.prepend==False
    assert fa.static==True



# Generated at 2022-06-23 05:46:38.802820
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)

    if not attribute_1 <= attribute_2:
        print("attribute_1 <= attribute_2 failed")
    if attribute_2 <= attribute_1:
        print("attribute_2 <= attribute_1 failed")

# Generated at 2022-06-23 05:46:44.406440
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    '''
    Check if Attribute implements comparison correctly
    '''

    a = Attribute(priority=1)
    b = Attribute(priority=2)

    # Check if Attribute really compares the priorities
    assert a < b
    assert a <= b
    assert not a == b
    assert a != b
    assert not a > b
    assert not a >= b

# Generated at 2022-06-23 05:46:47.531436
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert attr2.__lt__(attr1)



# Generated at 2022-06-23 05:46:48.900055
# Unit test for constructor of class Attribute
def test_Attribute():
    assert isinstance(Attribute(), Attribute)



# Generated at 2022-06-23 05:46:57.861134
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a1 <= a2)
    assert(not a2 <= a1)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    assert(a1 <= a2)
    assert(a2 <= a1)
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert(not a1 <= a2)
    assert(a2 <= a1)


# Generated at 2022-06-23 05:47:02.979238
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.playbook.base import Attribute

    a = Attribute(1)
    b = Attribute(2)

    assert a != b
    assert not(a != a)

    c = Attribute(1)
    c.priority = 2
    assert c == a


# Generated at 2022-06-23 05:47:05.412981
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=5)
    attr2 = Attribute(priority=6)
    assert attr2 >= attr

# Generated at 2022-06-23 05:47:15.513255
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a2_copy = Attribute(priority=2)
    a3 = Attribute(priority=3)

    assert (a1 <= a2) is True
    assert (a2 <= a3) is True

    assert (a1 <= a1) is True
    assert (a2 <= a2_copy) is True
    assert (a2 <= a2) is True

    assert (a1 <= a3) is True
    assert (a3 <= a3) is True

    assert (a3 <= a2) is False
    assert (a3 <= a1) is False

    assert (a2 <= a1) is False



# Generated at 2022-06-23 05:47:24.809673
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    p0 = Attribute(priority=0)
    p1 = Attribute(priority=1)
    p2 = Attribute(priority=2)
    p3 = Attribute(priority=3)

    assert p0 < p1
    assert p0 < p2
    assert p0 < p3

    assert p1 < p2
    assert p1 < p3

    assert p2 < p3

    assert not p3 < p2
    assert not p3 < p1
    assert not p3 < p0

    assert not p2 < p1
    assert not p2 < p0

    assert not p1 < p0



# Generated at 2022-06-23 05:47:25.865137
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=1) >= Attribute(priority=2)


# Generated at 2022-06-23 05:47:34.517479
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list', default=lambda: [])
    assert hasattr(field, 'isa')
    assert hasattr(field, 'private')
    assert hasattr(field, 'default')
    assert hasattr(field, 'required')
    assert hasattr(field, 'listof')
    assert hasattr(field, 'priority')
    assert hasattr(field, 'class_type')
    assert hasattr(field, 'always_post_validate')
    assert hasattr(field, 'inherit')
    assert hasattr(field, 'alias')
    assert field.isa == 'list'
    assert callable(field.default)



# Generated at 2022-06-23 05:47:39.236982
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert not Attribute() < Attribute()

    assert Attribute(priority=1) < Attribute(priority=10)
    assert not Attribute(priority=10) < Attribute(priority=1)

    assert Attribute(priority=None) < Attribute(priority=10)
    assert not Attribute(priority=10) < Attribute(priority=None)

    assert Attribute(priority=None, inherit=True) < Attribute(priority=None, inherit=False)

# Generated at 2022-06-23 05:47:49.002226
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa='string', required=True)
    assert attr.isa == 'string'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-23 05:47:50.153907
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(default='test')



# Generated at 2022-06-23 05:47:54.181457
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute()
    print(type(field_attr))
    print(field_attr.isa)
    print(field_attr.private)
    print(field_attr.default)
    print(field_attr.required)
    print(field_attr.listof)
    print(field_attr.priority)


# Generated at 2022-06-23 05:48:04.353563
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    fa = FieldAttribute('some_isa', True, 'some_default', True, 'some_listof', 1, 'some_class_type', True, False, 'some_alias', True, True, True)
    assert fa.isa == 'some_isa'
    assert fa.private == True

# Generated at 2022-06-23 05:48:12.049032
# Unit test for constructor of class Attribute
def test_Attribute():

    #is a
    test_this = Attribute(isa='list')
    assert test_this.isa == 'list'

    #private
    test_this = Attribute(private=True)
    assert test_this.private == True

    #default
    test_this = Attribute(default='default')
    assert test_this.default == 'default'

    #required
    test_this = Attribute(required=True)
    assert test_this.required == True

    #listof
    test_this = Attribute(listof='listof')
    assert test_this.listof == 'listof'

    #priority
    test_this = Attribute(priority=1)
    assert test_this.priority == 1

    #class_type
    test_this = Attribute(class_type='dict')
    assert test_

# Generated at 2022-06-23 05:48:19.098399
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(default='a').default == 'a'
    assert Attribute(isa='list', default='a').isa == 'list'
    assert Attribute(isa='dict', default='a').isa == 'dict'
    assert Attribute(isa='set', default='a').isa == 'set'

    try:
        Attribute(isa='list', default=['a'])
        assert False, "Attribute constructor should have failed"
    except TypeError:
        pass



# Generated at 2022-06-23 05:48:25.232857
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    attribute3 = Attribute(priority=3)
    
    assert attribute1 < attribute2
    assert attribute1 <= attribute2
    assert attribute1 != attribute2
    assert attribute2 == attribute3
    assert attribute2 >= attribute3
    assert attribute2 > attribute3

# Generated at 2022-06-23 05:48:29.346942
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert attr1 <= attr2
    assert attr2 > attr1
    assert attr2 >= attr1


# Generated at 2022-06-23 05:48:31.969657
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a < b
    assert not b < a
    assert not a < a


# Generated at 2022-06-23 05:48:35.884672
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert(attr1 == attr1)
    assert(attr2 == attr2)
    assert(attr1 != attr2)


# Generated at 2022-06-23 05:48:43.634685
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_1 = Attribute(priority=-1)
    attr_2 = Attribute(priority=0)
    attr_3 = Attribute(priority=1)

    assert attr_3 <= attr_2
    assert not attr_3 <= attr_3
    assert not attr_3 <= attr_1

    assert attr_1 <= attr_1
    assert attr_1 <= attr_2
    assert attr_1 <= attr_3

    assert not attr_2 <= attr_1
    assert attr_2 <= attr_2
    assert attr_2 <= attr_3



# Generated at 2022-06-23 05:48:47.809471
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Can compare two attributes
    a = Attribute()
    b = Attribute()
    assert(b.__gt__(a))

    # Can compare with itself
    assert(a.__gt__(a))

# Generated at 2022-06-23 05:48:52.604028
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='test1', private='test2', default='test3', required='test4', listof='test5', priority='test6', class_type='test7', always_post_validate='test8', inherit='test9', alias='test10', extend='test11', prepend='test12', static='test13')


# Generated at 2022-06-23 05:49:02.437760
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a_1 = Attribute(priorirty=1)
    a_3 = Attribute(priorirty=3)
    a_5 = Attribute(priorirty=5)

    assert a_5 > a_3
    assert a_5 > a_1
    assert a_5 > a_5
    assert a_5 >= a_5

    assert a_1 < a_5
    assert a_3 < a_5
    assert a_5 < a_5
    assert a_5 <= a_5

    assert a_3 <= a_5
    assert a_5 <= a_5

    assert not (a_5 < a_5)
    assert not (a_5 > a_5)



# Generated at 2022-06-23 05:49:06.126085
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert not Attribute(priority=1) > Attribute(priority=1)
    assert Attribute(priority=2) > Attribute(priority=1)
    assert not Attribute(priority=1) > Attribute(priority=2)

# Generated at 2022-06-23 05:49:07.294768
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    TODO


# Generated at 2022-06-23 05:49:12.097311
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    if a >= b:
        return False
    if b >= a:
        return True
    if a >= c:
        return True
    else:
        return False


# Generated at 2022-06-23 05:49:14.912435
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field = Attribute(priority=1)
    test_field = Attribute(priority=1)
    assert (test_field == field) == True


# Generated at 2022-06-23 05:49:17.680871
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    x = Attribute(priority=1)
    y = Attribute(priority=2)
    assert x.__gt__(y)



# Generated at 2022-06-23 05:49:21.383741
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute()

x = FieldAttribute(default=lambda x: [], always_post_validate=True, extend=True)

d = FieldAttribute(default={}, always_post_validate=True, extend=True)


# Generated at 2022-06-23 05:49:24.110039
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=20)

    assert attr2 >= attr1


# Generated at 2022-06-23 05:49:32.902928
# Unit test for constructor of class Attribute
def test_Attribute():

    #############################
    # Test the default constructor
    #############################

    # make sure the field class is created with defaults
    test_field = Attribute()

    # make sure the class has all of the default values
    assert test_field.isa is None
    assert test_field.private is False
    assert test_field.default is None
    assert test_field.required is False
    assert test_field.listof is None
    assert test_field.priority == 0
    assert test_field.class_type is None
    assert test_field.always_post_validate is False
    assert test_field.inherit is True
    assert test_field.alias is None
    assert test_field.extend is False

    ###########################
    # Test the overloaded constructor
    ###########################

    test_field = Att

# Generated at 2022-06-23 05:49:34.930927
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()



# Generated at 2022-06-23 05:49:38.311233
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert(a1.__le__(a2))

    a3 = Attribute(priority=1)
    assert(a3.__le__(a1))


# Generated at 2022-06-23 05:49:45.015014
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a >= a.priority
    assert not b >= a.priority
    assert b >= b.priority


# Make sure that @property methods in a class also get this descriptor

from ansible.parsing.yaml.dumper import AnsibleDumper
from ansible.parsing.utils import extract_hash



# Generated at 2022-06-23 05:49:50.271730
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute()
    a1.priority = 10
    a2 = Attribute()
    a2.priority = 20

    assert a1.__gt__(a2)
    assert not a1.__gt__(a1)
    assert not a2.__gt__(a1)


# Generated at 2022-06-23 05:49:52.723072
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=3)
    assert attr1 >= attr2


# Generated at 2022-06-23 05:50:02.835802
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private == False
    assert f.default is None
    assert f.required == False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias is None
    assert f.extend == False
    assert f.prepend == False

    f = FieldAttribute(123, 456, 'hello', ['a', 'b', 'c'], inherit=False)
    assert f.isa == 123
    assert f.private == 456
    assert f.default == 'hello'
    assert f.required == ['a', 'b', 'c']
    assert f.listof is None
    assert f

# Generated at 2022-06-23 05:50:05.777375
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=5)
    assert not (4 <= attr)
    assert (5 <= attr)
    assert (6 <= attr)


# Generated at 2022-06-23 05:50:11.267104
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Test that __ne__ works when priority attribute are different
    attr1 = FieldAttribute()
    attr1.priority = 1
    attr2 = FieldAttribute()
    attr2.priority = 2
    if attr1.priority == attr2.priority:
        raise Exception("Unit test for method __ne__ of class Attribute failed")


# Generated at 2022-06-23 05:50:17.408790
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    at1 = Attribute()
    at1.priority = 1
    at2 = Attribute()
    at2.priority = 2
    assert at1 == at2


# Generated at 2022-06-23 05:50:19.391288
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 > attr1


# Generated at 2022-06-23 05:50:31.957662
# Unit test for constructor of class Attribute
def test_Attribute():
    # test if constructor of Attribute can accept required argument
    a = Attribute(required=True)
    assert a.required
    assert not a.private
    assert isinstance(a, Attribute)

    # test if constructor of Attribute can accept default argument
    a = Attribute(default='foo')
    assert a.default == 'foo'
    assert not a.private
    assert isinstance(a, Attribute)

    # test if constructor of Attribute can accept private argument
    a = Attribute(private=True)
    assert a.private
    assert isinstance(a, Attribute)

    # test if constructor of Attribute can accept priority argument
    a = Attribute(priority=1)
    assert a.priority == 1
    assert not a.private
    assert isinstance(a, Attribute)

    # test if constructor of Attribute

# Generated at 2022-06-23 05:50:37.388126
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority = 10)
    y = Attribute(priority = 20)
    z = Attribute(priority = 20)
    assert(x <= y)
    assert(not (y <= x))
    assert(y <= z)
    assert(z <= y)
    assert(y <= y)


# Generated at 2022-06-23 05:50:45.825813
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Scenario 1: default is correctly copied and not overwritten
    my_field = FieldAttribute(isa='list', default=[])
    my_field.default.append(1)
    assert my_field.default == []

    # Scenario 2: default is correctly deepcopied and not overwritten
    my_dict = {}
    my_field = FieldAttribute(isa='dict', default=my_dict)
    my_dict['a'] = 1
    assert my_field.default == {}

    # Scenario 3: default is correctly deepcopied and not overwritten
    my_dict = {}
    default = lambda: my_dict
    my_field = FieldAttribute(isa='dict', default=default)
    my_dict['a'] = 1
    assert my_field.default == {}

    # Scenario 4: default is correctly deepcopied and

# Generated at 2022-06-23 05:50:48.918052
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    att1 = Attribute(priority=1)
    att2 = Attribute(priority=2)
    assert att2 <= att1, "attribute %r should have atrribute %r <= than itself" % (att2, att1)


# Generated at 2022-06-23 05:50:49.824287
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute() > Attribute()



# Generated at 2022-06-23 05:50:52.388687
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a2 <= a1


# Generated at 2022-06-23 05:51:04.203849
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute(is_a='name_test')
    assert attribute.isa == 'name_test'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None

    attribute = Attribute(private=True, is_a='private_test')
    assert attribute.isa == 'private_test'
    assert attribute.private == True
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_

# Generated at 2022-06-23 05:51:07.409817
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert(attr1 != attr2)
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=0)
    assert(attr1 > attr2)
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert(attr1 < attr2)


# Generated at 2022-06-23 05:51:14.097566
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-23 05:51:20.209269
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    #Data
    attribute_a = Attribute()
    attribute_a.priority = 0

    attribute_b = Attribute()
    attribute_b.priority = 0

    attribute_c = Attribute()
    attribute_c.priority = 1

    #Tests
    assert attribute_a == attribute_b
    assert attribute_a != attribute_c

    return True


# Generated at 2022-06-23 05:51:26.856864
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    att1 = Attribute(priority=0)
    att2 = Attribute(priority=1)
    att3 = Attribute(priority=2)
    att4 = Attribute(priority=3)
    att5 = Attribute(priority=4)
    assert att1.__lt__(att2)
    assert att1.__lt__(att3)
    assert att1.__lt__(att4)
    assert att1.__lt__(att5)


# Generated at 2022-06-23 05:51:31.292918
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__gt__(attr1) is True


# Generated at 2022-06-23 05:51:42.127046
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Testing for case 1: if other.priority == self.priority,
    # __eq__ return True

    a1 = Attribute(isa=int, private=False, default=0, required=False, listof=None,
                   priority=1, class_type=int, always_post_validate=False, inherit=True,
                   alias=None, extend=False, prepend=False, static=False)

    assert a1.__eq__(a1)

    # Testing for case 2: if other.priority != self.priority,
    # __eq__ return False


# Generated at 2022-06-23 05:51:44.058733
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(static=True)
    assert(field.static == True)



# Generated at 2022-06-23 05:51:46.219861
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=11)
    a2 = Attribute(priority=12)

    assert (a1==a2)


# Generated at 2022-06-23 05:51:47.443132
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='default_value')


# Generated at 2022-06-23 05:51:48.985174
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=7)
    b = Attribute(priority=5)
    assert a >= b


# Generated at 2022-06-23 05:51:53.424923
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=1)

    assert a1 == a3
    assert a1 != a2
	

# Generated at 2022-06-23 05:51:59.629942
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()
    FA = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
        )



# Generated at 2022-06-23 05:52:05.759747
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute(priority=1)
    a4 = Attribute(priority=1)
    a5 = Attribute(priority=2)

    # Test equals
    assert a1 == a2

    # Test not equals
    assert a3 != a1
    assert a3 != a2
    assert a3 != a5



# Generated at 2022-06-23 05:52:08.173471
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = Attribute(priority = "")
    field2 = Attribute(priority = "")
    assert field1 == field2


# Generated at 2022-06-23 05:52:16.437197
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attrs = {
        'required': True,
        'private': False,
        'default': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None
    }

    f = FieldAttribute('str', **attrs)
    for k, v in attrs.items():
        assert f.__dict__[k] == v

    f = FieldAttribute(private=True, **attrs)
    for k, v in attrs.items():
        assert f.__dict__[k] == v



# Generated at 2022-06-23 05:52:20.638872
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr2 = Attribute()
    if attr1 != attr2:
        raise AssertionError("Attributes with same priority should be equal")


# Generated at 2022-06-23 05:52:25.643963
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(isa='abc', priority=1)
    a2 = Attribute(isa='abc', priority=1)
    a3 = Attribute(isa='abc', priority=2)

    assert a1 <= a2
    assert a2 <= a3
    assert not a3 <= a1
