

# Generated at 2022-06-23 05:42:25.526720
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    fake_obj = Attribute(priority=1)
    fake_obj_two = Attribute(priority=0)
    assert fake_obj.__gt__(fake_obj_two)


# Generated at 2022-06-23 05:42:26.910717
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)


# Generated at 2022-06-23 05:42:36.555619
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = "test"
    private = True
    default = 42
    required = False
    listof = "listofval"
    priority = 2
    class_type = "classType"
    always_post_validate = False
    inherit = True
    alias = "alias"

    at = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    # check the attributes of object
    assert at.default == default
    assert at.required == required
    assert at.listof == listof
    assert at.priority == priority
    assert at.class_type == class_type
    assert at.always_post_validate == always_post_validate
    assert at.inherit == inherit
    assert at.alias == alias
    # check the

# Generated at 2022-06-23 05:42:42.451582
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    # __eq__(other)
    attr_obj_1 = Attribute()
    attr_obj_2 = Attribute()

    attr_obj_2.priority = 0

    assert(attr_obj_1 == attr_obj_2)
    assert(attr_obj_2 == attr_obj_1)



# Generated at 2022-06-23 05:42:47.072873
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()

    assert a.alias is None
    assert a.class_type is None
    assert a.default is None
    assert a.inherit is True
    assert a.isa is None
    assert a.private is False
    assert a.priority == 0
    assert a.required is False
    assert a.always_post_validate is False



# Generated at 2022-06-23 05:42:52.363837
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a <= b
    assert not b <= a
    assert a <= a
    assert b <= b


# Generated at 2022-06-23 05:42:59.148560
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )

    attribute__ge__ = attribute.__ge__(Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    ))
    assert (attribute__ge__ == False)



# Generated at 2022-06-23 05:43:04.615957
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a == b
    assert b == a
    a = Attribute(priority=10)
    b = Attribute(priority=10)
    assert a == b
    assert b == a
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert a != b
    assert b != a


# Generated at 2022-06-23 05:43:09.132386
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=0)
    assert a.__le__(a1)
    assert not a.__le__(a2)


# Generated at 2022-06-23 05:43:11.884985
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Setup test objects
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 1
    attr2.priority = 2

    assert attr1.__ge__(attr2) == True


# Generated at 2022-06-23 05:43:17.016423
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default attribute constructor
    a = Attribute()
    assert a.private == False
    assert a.required == False
    assert a.inherit == True

    # Test custom attribute constructor
    a = Attribute(private=True, required=True, inherit=False)
    assert a.private == True
    assert a.required == True
    assert a.inherit == False


# Generated at 2022-06-23 05:43:21.036678
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    assert attr != attr2

    attr2.priority = 1
    assert attr == attr2


# Generated at 2022-06-23 05:43:23.605080
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    return a != b

# Generated at 2022-06-23 05:43:25.460657
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority = 10)
    b = Attribute(priority = 1)
    assert a > b


# Generated at 2022-06-23 05:43:30.466407
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr_dict = dict(isa='str', private=False, default='test', required=True,
                          listof='str', priority=0, class_type='str',
                          always_post_validate=False, inherit=True, alias=None,
                          extend=False, prepend=False, static=False)
    assert test_attr_dict == Attribute(**test_attr_dict).__dict__


# Generated at 2022-06-23 05:43:36.185756
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute().__gt__(Attribute(priority=1)) is True
    assert Attribute(priority=5).__gt__(Attribute(priority=1)) is True
    assert Attribute(priority=1).__gt__(Attribute(priority=5)) is False
    assert Attribute().__gt__(Attribute()) is False
    assert Attribute(priority=1).__gt__(Attribute()) is True


# Generated at 2022-06-23 05:43:39.140568
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 == attr2


# Generated at 2022-06-23 05:43:46.163809
# Unit test for constructor of class Attribute
def test_Attribute():

    class test(Attribute):
        test = Attribute(isa='str', default='a')
        test2 = Attribute(isa='str', default='a')
        test3 = Attribute(isa='str', default='b')
        test4 = Attribute(isa='str', default='c')

    assert not test.test == test.test2
    assert test.test == 0
    assert test.test2 == 0
    assert test.test3 == 1
    assert test.test4 == 2


# Generated at 2022-06-23 05:43:47.894853
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    defa = FieldAttribute(default='test')
    assert defa is not None



# Generated at 2022-06-23 05:43:59.590682
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    kv_args_1 = {
            'isa':'integer',
            'private':True,
            'default':None,
            'required':True,
            'listof':'string',
            'priority':3,
            'class_type':None,
            'always_post_validate':False,
            'inherit':True,
            'alias':None,
            'extend':False,
            'prepend':False,
            'static':False,
        }

# Generated at 2022-06-23 05:44:06.978228
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a  = Attribute(priority=1)
    b  = Attribute(priority=2)
    a1 = Attribute(priority=2)
    b1 = Attribute(priority=1)

    assert not a.__gt__(b)
    assert a.__gt__(b1)
    assert not a1.__gt__(b)
    assert not b1.__gt__(a)

    print('Unit test for testAttribute___gt__() passed!')

# Generated at 2022-06-23 05:44:11.361075
# Unit test for constructor of class Attribute
def test_Attribute():
    dm_object = Attribute(isa='str', default="test", required=False)
    assert dm_object.isa == 'str'
    assert dm_object.default == "test"
    assert dm_object.required == False
    assert dm_object.priority == 0

# Generated at 2022-06-23 05:44:16.140727
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test attribute 1
    a1 = Attribute(isa='str')
    a1.priority = 0
    assert a1.priority == 0
    # Test attribute 2
    a2 = Attribute(isa='bool')
    a2.priority = 0
    assert a2.priority == 0
    assert a1 == a2



# Generated at 2022-06-23 05:44:28.260485
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    The method __lt__ of class Attribute should return True when
    the priority of Attribute 'b' is greater than the priority
    of Attribute 'a', and False when the priorities of both
    Attributes are equal or when the priority of Attribute 'a'
    is greater than the priority of Attribute 'b'.

    :returns: ``True`` if the unit test succeeds, ``False`` otherwise
    """
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert b < a
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert not (b < a)
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert not (b < a)
    return True


# Generated at 2022-06-23 05:44:31.490816
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    assert a.__ne__(b)


# Generated at 2022-06-23 05:44:35.216215
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=2)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)
    assert attr <= attr2
    assert not attr <= attr3


# Generated at 2022-06-23 05:44:40.619197
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 0
    b = Attribute()
    b.priority = 1
    assert(a <= b)
    b.priority = 0
    assert(a <= b)
    a.priority = 0
    b.priority = 0
    assert(a <= b)


# Generated at 2022-06-23 05:44:42.433392
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute(priority=0)
    y = Attribute(priority=1)

    assert(y >= x) == True


# Generated at 2022-06-23 05:44:47.787757
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    a3 = Attribute(priority=1)
    a4 = Attribute(priority=2)
    assert a1.__le__(a1) is True
    assert a1.__le__(a2) is True
    assert a1.__le__(a3) is True
    assert a1.__le__(a4) is True
    assert a4.__le__(a1) is False


# Generated at 2022-06-23 05:44:55.878975
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type='class',
        always_post_validate=False,
        inherit=False,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == 'class'
    assert attr.always_post_validate == False
    assert attr.inherit == False

# Generated at 2022-06-23 05:45:00.448036
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2
    assert not (a1 <= a1)
    assert not (a2 <= a1)


# Generated at 2022-06-23 05:45:05.062597
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    test_value = Attribute(priority=1)
    expected_value = Attribute(priority=2)
    assert test_value.__gt__(expected_value) # true
    negative_expected_value = Attribute(priority=0)
    assert not test_value.__gt__(negative_expected_value) # false


# Generated at 2022-06-23 05:45:08.857968
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_attribute_1 = FieldAttribute(priority=1)
    field_attribute_2 = FieldAttribute(priority=2)
    # Check __lt__ method
    assert not field_attribute_1.__lt__(field_attribute_2)
    assert field_attribute_2.__lt__(field_attribute_1)



# Generated at 2022-06-23 05:45:17.625197
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict', default=dict())
    assert fa.isa == 'dict'
    assert fa.private is False
    assert fa.default == dict()
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False
    fa.isa = 'list'
    with pytest.raises(TypeError):
        fa.default = []
    fa.default = list
    fa.isa = 'dict'
    with pytest.raises(TypeError):
        fa.default = dict()
   

# Generated at 2022-06-23 05:45:20.176281
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    if not(Attribute.__ne__.__doc__):
        print('Method Attribute.__ne__ has not docstring')



# Generated at 2022-06-23 05:45:24.355060
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from operator import lt

    assert not lt(Attribute(priority=10), Attribute(priority=10))
    assert lt(Attribute(priority=0), Attribute(priority=10))
    assert not lt(Attribute(priority=10), Attribute(priority=0))



# Generated at 2022-06-23 05:45:27.025524
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute()
    assert isinstance(field, Attribute)


# TODO: should we have a mutable and immutable attribute?

# Generated at 2022-06-23 05:45:30.079092
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute()
    attribute1.priority = 5
    attribute2 = Attribute()
    attribute2.priority = 10

    assert attribute1 < attribute2



# Generated at 2022-06-23 05:45:34.407137
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__ge__(attr1)
    assert not attr1.__ge__(attr2)
    assert attr2.__ge__(attr1)


# Generated at 2022-06-23 05:45:41.459127
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(default=True)
    attribute2 = Attribute(default=False)
    attribute3 = Attribute(default=True)

    assert isinstance(attribute, Attribute)
    assert isinstance(attribute2, Attribute)
    assert isinstance(attribute3, Attribute)

    assert attribute >= attribute2
    assert attribute >= attribute3
    assert attribute2 >= attribute3

    assert not attribute2 >= attribute
    assert not attribute3 >= attribute


# Generated at 2022-06-23 05:45:50.386152
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        required=True,
        private=True,
        listof=None,
        priority=10,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        extend=True,
        prepend=False,
    )
    assert field_attribute.required, "constructor of class FieldAttribute failed to set attribute 'required'"
    assert field_attribute.private, "constructor of class FieldAttribute failed to set attribute 'private'"
    assert field_attribute.priority == 10, "constructor of class FieldAttribute failed to set attribute 'priority'"
    assert field_attribute.listof == None, "constructor of class FieldAttribute failed to set attribute 'listof'"

# Generated at 2022-06-23 05:45:53.965387
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)
    field3 = Attribute(priority=1)
    assert field1 == field3
    assert field1 != field2


# Generated at 2022-06-23 05:45:58.037768
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert(a1.__lt__(a2) == False)
    assert(a2.__lt__(a1) == True)

# Generated at 2022-06-23 05:46:01.338339
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    test_attribute = Attribute(priority=1)
    other_attribute = Attribute(priority=2)
    assert test_attribute.__lt__(other_attribute)


# Generated at 2022-06-23 05:46:04.513414
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert (a < b)



# Generated at 2022-06-23 05:46:10.360800
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='foo')
    f2 = FieldAttribute(isa='bar')
    f3 = FieldAttribute(isa='baz', priority=1)
    assert(f1 < f3 and f3 > f1 and f1 == f1)
    assert(f1 > f2)


# Generated at 2022-06-23 05:46:12.985264
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    fail = False
    try:
        Attribute() < Attribute()
    except:
        fail = True
    if fail:
        raise AssertionError()


# Generated at 2022-06-23 05:46:15.551677
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2



# Generated at 2022-06-23 05:46:17.823176
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b



# Generated at 2022-06-23 05:46:20.974283
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert a == b
    assert a != c


# Generated at 2022-06-23 05:46:23.596491
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=11)
    assert a1.__le__(a2) == True
    assert a1.__le__(a1) == True
    assert a2.__le__(a1) == False


# Generated at 2022-06-23 05:46:33.741302
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert(fieldattr.isa == 'str')
    assert(fieldattr.private == False)
    assert(fieldattr.default == None)
    assert(fieldattr.required == False)
    assert(fieldattr.listof == None)
    assert(fieldattr.class_type == None)
    assert(fieldattr.always_post_validate == False)
    assert(fieldattr.inherit == True)
    assert(fieldattr.alias == None)


# Generated at 2022-06-23 05:46:43.482997
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print(Attribute(isa = "str")!=Attribute(isa = "str"))
    print(Attribute(isa = "str", private = True)!=Attribute(isa = "str", private = True))
    print(Attribute(isa = "str", default = "test")!=Attribute(isa = "str", default = "test"))
    print(Attribute(isa = "str", required = True)!=Attribute(isa = "str", required = True))
    print(Attribute(isa = "str", listof = "str")!=Attribute(isa = "str", listof = "str"))
    print(Attribute(isa = "str", priority = 1)!=Attribute(isa = "str", priority = 1))
    print(Attribute(isa = "str", class_type = str)!=Attribute(isa = "str", class_type = str))

# Generated at 2022-06-23 05:46:51.335463
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattribute = FieldAttribute(isa="str")
    assert fieldattribute.isa == "str"
    assert fieldattribute.private == False
    assert fieldattribute.required == False
    assert fieldattribute.listof == None
    assert fieldattribute.default == None
    assert fieldattribute.priority == 0
    assert fieldattribute.class_type == None
    assert fieldattribute.always_post_validate == False
    assert fieldattribute.inherit == True
    assert fieldattribute.alias == None
    assert fieldattribute.static == False
    assert fieldattribute.extend == False
    assert fieldattribute.prepend == False
    print("Success, FieldAttribute works!")

test_FieldAttribute()



# Generated at 2022-06-23 05:46:54.353806
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a <= b


# Generated at 2022-06-23 05:46:56.994797
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert a == b


# Generated at 2022-06-23 05:46:59.777700
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    self = Attribute(100)
    other = Attribute(100)
    self.__ne__(other) == False


# Generated at 2022-06-23 05:47:02.476443
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    assert attr == Attribute(priority=1)
    assert attr != Attribute(priority=2)


# Generated at 2022-06-23 05:47:13.945892
# Unit test for constructor of class Attribute
def test_Attribute():
    class TestAttribute:

        def __init__(self):
            self.a = Attribute()
            self.b = Attribute(isa='str')
            self.c = Attribute(private=True)
            self.d = Attribute(default='default')
            self.e = Attribute(required=True)
            self.f = Attribute(listof='bool')
            self.g = Attribute(priority=9999)
            self.h = Attribute(class_type=int)
            self.i = Attribute(always_post_validate=True)
            self.j = Attribute(inherit=False)
            self.k = Attribute(alias='alias')
            self.l = Attribute(extend=True)
            self.m = Attribute(prepend=True)
            self.n = Attribute

# Generated at 2022-06-23 05:47:24.034725
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    if not(Attribute(priority=1) < Attribute(priority=2)):
        raise AssertionError('Attribute(priority=1) < Attribute(priority=2) does not return True')

    if Attribute(priority=2) < Attribute(priority=1):
        raise AssertionError('Attribute(priority=2) < Attribute(priority=1) does not return False')

    if Attribute(priority=1) < Attribute(priority=1):
        raise AssertionError('Attribute(priority=1) < Attribute(priority=1) does not return False')

if __name__ == "__main__":
    test_Attribute___lt__()

# Generated at 2022-06-23 05:47:28.005198
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    default_attrib = Attribute()
    default_attrib_clone = Attribute()

    assert (default_attrib == default_attrib_clone)


# Generated at 2022-06-23 05:47:32.442674
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    class A1:
        foo = FieldAttribute(priority=1)

    class A2:
        foo = FieldAttribute(priority=10)

    assert A2.foo > A1.foo, 'test 1 __gt__: method not working as expected'



# Generated at 2022-06-23 05:47:34.220070
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute()
    assert Attribute() >= FieldAttribute()


# Generated at 2022-06-23 05:47:36.685918
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = FieldAttribute(priority=10)
    b = FieldAttribute(priority=30)

    assert not (a > b)
    assert b > a


# Generated at 2022-06-23 05:47:43.510533
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    sample_list = ['s1', 's2', 's3']
    class_type_list = ['s1', 's2', 's3']
    most_of_attrs = dict(isa='boolean', private=False, default=None, required=False, listof=sample_list, priority=0, class_type=class_type_list, always_post_validate=False, inherit=True, alias='boolean_alias', extend=False, prepend=False, static=False)
    # Test all attributes
    attr_all = FieldAttribute(**most_of_attrs)
    assert attr_all.isa == 'boolean'
    assert attr_all.private == False
    assert attr_all.default == None
    assert attr_all.required == False
    assert attr_all.list

# Generated at 2022-06-23 05:47:54.219505
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='test_isa',
                        private=False,
                        default=None,
                        required=False,
                        listof=None,
                        priority=0,
                        class_type=None,
                        always_post_validate=False,
                        inherit=True,
                        alias=None,
                        extend=False,
                        prepend=False,
                        static=False
                        )
    assert attr.isa == 'test_isa'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True

# Generated at 2022-06-23 05:48:01.000476
# Unit test for constructor of class Attribute
def test_Attribute():
    # Ensure missing required keyword arguments are caught
    try:
        attribute_missing_required_keyword_arg = Attribute(isa='string')
    except TypeError:
        pass
    else:
        raise Exception("Attribute with missing required keyword argument did not raise TypeError")

    # Ensure attribute defaults are set correctly
    attribute_defaults = Attribute(isa='string')
    assert attribute_defaults.isa == 'string'
    assert attribute_defaults.private == False
    assert attribute_defaults.default == None
    assert attribute_defaults.required == False
    assert attribute_defaults.listof == None
    assert attribute_defaults.priority == 0
    assert attribute_defaults.class_type == None
    assert attribute_defaults.always_post_validate == False
    assert attribute_defaults.inherit == True
   

# Generated at 2022-06-23 05:48:03.159692
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a < b
    assert b > a

# Generated at 2022-06-23 05:48:05.531112
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.other = Attribute(priority = 2)
    assert a > a.other


# Generated at 2022-06-23 05:48:15.716465
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a1 = FieldAttribute()
    assert a1.isa is None
    assert a1.private is False
    assert a1.default is None
    assert a1.required is False
    assert a1.listof is None
    assert a1.priority == 0
    assert a1.class_type is None
    assert a1.always_post_validate is False
    assert a1.inherit is True
    assert a1.alias is None
    assert a1.extend is False
    assert a1.prepend is False
    assert a1.static is False

    a2 = FieldAttribute(isa='int')
    assert a2.isa == 'int'

    a3 = FieldAttribute(private=True)
    assert a3.private is True

    a4 = FieldAttribute(default=1)
    assert a4.default

# Generated at 2022-06-23 05:48:24.418300
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test with Attribute.priority < other.priority
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=30)
    assert a1.__ge__(a2) == False, 'Attribute.__ge__ test failed'

    # Test with Attribute.priority == other.priority
    a3 = Attribute(priority=10)
    a4 = Attribute(priority=10)
    assert a3.__ge__(a4) == True, 'Attribute.__ge__ test failed'

    # Test with Attribute.priority > other.priority
    a5 = Attribute(priority=30)
    a6 = Attribute(priority=10)
    assert a5.__ge__(a6) == True, 'Attribute.__ge__ test failed'


# Generated at 2022-06-23 05:48:27.328921
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority='a')
    b = Attribute(priority='b')
    assert a <= b
    assert not a >= b


# Generated at 2022-06-23 05:48:31.348783
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Arrange
    attribute1 = Attribute()
    attribute1.priority = 1
    attribute2 = Attribute()
    attribute2.priority = 2

    # Act
    compare = attribute2 < attribute1

    # Assert
    assert compare == False


# Generated at 2022-06-23 05:48:33.306660
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__le__(b)


# Generated at 2022-06-23 05:48:38.883051
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    '''
    This function was added for testing the method __gt__ of class Attribute
    '''

    attr1 = Attribute()
    attr2 = Attribute(priority = 2)

    assert attr2.__gt__(attr1) == True
    assert attr1.__gt__(attr2) == False

# Generated at 2022-06-23 05:48:41.695939
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()
    assert(isinstance(x, Attribute))

# Generated at 2022-06-23 05:48:48.099482
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = FieldAttribute(priority=1)
    field2 = FieldAttribute(priority=2)
    field3 = FieldAttribute(priority=1)
    field4 = FieldAttribute(priority=1)
    assert not field1 >= field2
    assert field1 >= field3
    assert field2 >= field3
    assert field2 >= field4


# Generated at 2022-06-23 05:48:53.700332
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list')
    f.isa = 'list'
    f.private = False
    assert f.isa == 'list'
    assert f.private == False
    assert f is not None
    f2 = FieldAttribute(isa='list')
    assert f == f2
    assert f < f2
    assert f <= f2
    assert f >= f2
    assert f > f2

# Generated at 2022-06-23 05:49:04.117051
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    f1 = FieldAttribute(priority=1)
    f2 = FieldAttribute(priority=2)
    # f1 == f2
    assert(f1 == f2)
    assert(f2 == f1)
    # f1 != f2
    assert(f1 != f2)
    assert(f2 != f1)
    # f1 < f2
    assert(f1 < f2)
    assert(f2 > f1)
    # f1 <= f2
    assert(f1 <= f2)
    assert(f2 >= f1)
    # f1 > f2
    assert(f1 > f2)
    assert(f2 < f1)
    # f1 >= f2
    assert(f1 >= f2)
    assert(f2 <= f1)

# Generated at 2022-06-23 05:49:13.350840
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a is not None
    assert a.isa is None
    assert a.private is None
    assert a.default is None
    assert a.required is None
    assert a.listof is None
    assert a.priority is None
    assert a.class_type is None
    assert a.always_post_validate is None
    assert a.inherit is None
    assert a.alias is None
    assert a.extend is None
    assert a.prepend is None
    assert a.static is None


# Generated at 2022-06-23 05:49:16.134200
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=0) > Attribute(priority=1)


# Generated at 2022-06-23 05:49:19.203100
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=20)
    assert a1 < a2
    assert not a2 < a1


# Generated at 2022-06-23 05:49:26.438082
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    att1 = Attribute(priority=100)
    att2 = Attribute(priority=100)

    assert not att1.__ne__(att2)
    assert not att2.__ne__(att1)

    att3 = Attribute(priority=200)

    assert att1.__ne__(att3)
    assert att3.__ne__(att1)

    assert not att2.__ne__(att3)
    assert not att3.__ne__(att2)


# Generated at 2022-06-23 05:49:29.042019
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Ensure that FieldAttribute is an Attribute
    """
    f = FieldAttribute()
    if not isinstance(f, Attribute):
        raise Exception("FieldAttribute is not an Attribute")

# Generated at 2022-06-23 05:49:32.845278
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)

    assert a1 <= a2
    assert a1 < a2
    assert not a1 >= a2
    assert not a1 > a2


# Generated at 2022-06-23 05:49:38.263396
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 0
    if not a1 < a2:
        raise Exception('Attribute class (__lt__) not implemented properly')


# Generated at 2022-06-23 05:49:42.093895
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a.__ne__(b)
    assert b.__ne__(a)



# Generated at 2022-06-23 05:49:54.204986
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = ['list', 'dict', 'set']
    private = True
    default = dict()
    required = False
    listof = ['list', 'set', 'dict']
    priority = 0
    always_post_validate = False
    inherit = False
    attributes = {
        'isa': isa,
        'private': private,
        'default': default,
        'required': required,
        'listof': listof,
        'priority': priority,
        'always_post_validate': always_post_validate,
        'inherit': inherit,
    }


# Generated at 2022-06-23 05:49:58.130427
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(default=True, priority=1)
    b = Attribute(default=True, priority=2)
    assert a.__le__(b) == False
    assert b.__le__(a) == True



# Generated at 2022-06-23 05:50:09.582658
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import ansible.playbook.play
    import ansible.playbook.taskexecutor
    import ansible.playbook.task_include
    import ansible.playbook.block

    attr = FieldAttribute(isa='str')
    attr1 = FieldAttribute(isa='str')
    assert(attr.isa == 'str')
    assert(attr1.isa == 'str')
    assert(attr == attr1)
    assert(attr <= attr1)
    assert(attr >= attr1)
    assert(not attr < attr1)
    assert(not attr > attr1)
    assert(not attr != attr1)

    attr2 = FieldAttribute(isa='int')
    assert(attr != attr2)
    assert(attr < attr2)

# Generated at 2022-06-23 05:50:15.541172
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(default=12)
    attr_2 = Attribute(default=5)
    assert(attr_1 != attr_2)



# Generated at 2022-06-23 05:50:22.889409
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field_attributes = []

    attribute = Attribute(priority=1)
    field_attributes.append(attribute)
    attribute = Attribute(priority=3)
    field_attributes.append(attribute)
    attribute = Attribute(priority=2)
    field_attributes.append(attribute)

    assert field_attributes[0] >= field_attributes[1]
    assert field_attributes[1] <= field_attributes[2]
    assert field_attributes[2] >= field_attributes[0]



# Generated at 2022-06-23 05:50:24.998569
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
   assert Attribute(priority=1) < Attribute(priority=2)


# Generated at 2022-06-23 05:50:31.267289
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Positive unit test
    attr = Attribute(priority=1)
    attr_lt = Attribute(priority=2)
    assert attr.__lt__(attr_lt)
    # Negative unit test
    attr_gt = Attribute(priority=0)
    assert not attr.__lt__(attr_gt)
    assert not attr_gt.__lt__(attr)
    assert not attr_lt.__lt__(attr_lt)


# Generated at 2022-06-23 05:50:36.429659
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 0
    attr2.priority = 1
    assert(not attr1.__ge__(attr2))
    assert(attr2.__ge__(attr1))
    attr1.priority = 1
    assert(attr1.__ge__(attr2))
    assert(attr2.__ge__(attr1))
# Unit test over



# Generated at 2022-06-23 05:50:37.619544
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    myatt = FieldAttribute()



# Generated at 2022-06-23 05:50:45.991387
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=0)

    assert a1 < a2
    assert a2 > a1
    assert a1 <= a2
    assert a2 >= a1
    assert not a1 > a2
    assert not a2 < a1
    assert not a1 >= a2
    assert not a2 <= a1
    assert a1 <= a1
    assert a1 >= a1
    assert a1 < a3
    assert a3 > a1
    assert a1 <= a3
    assert a3 >= a1
    assert not a1 > a3
    assert not a3 < a1
    assert not a1 >= a3
    assert not a3 <= a1
    assert not a3 > a3

# Generated at 2022-06-23 05:50:58.041819
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa=dict,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )

    # Test that no Mutable default value for attribute with isa in _CONTAINERS
    # raises TypeError

# Generated at 2022-06-23 05:51:03.946649
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr_1 = Attribute(priority=-1)
    assert attr1.__gt__(attr2) == False
    assert attr1.__gt__(attr_1) == True
    assert attr2.__gt__(attr1) == True



# Generated at 2022-06-23 05:51:07.393748
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert not a.__ne__(b)

    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__ne__(b)


# Generated at 2022-06-23 05:51:09.598259
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert not (a < b)
    assert b < a


# Generated at 2022-06-23 05:51:15.040174
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        class Attr1:
            attr1 = FieldAttribute(isa='dict')
            attr2 = FieldAttribute(isa='list', default=[1, 2, 3])
            attr3 = FieldAttribute(isa='dict', default={})
            attr4 = FieldAttribute(isa='list', default=('a', 'b', 'c'))
            attr5 = FieldAttribute(isa='str', default='Hello World!')
    except TypeError:
        assert False, 'Expected FieldAttribute(isa=\'dict\') to be allowed. '

# Unit tests for __eq__, overloaded operators and __ne__

# Generated at 2022-06-23 05:51:18.167200
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert a < b
    assert not b < a
    assert a <= b
    assert not b <= a
    assert not a == b
    assert not a >= b
    assert b >= a
    assert a != b

# Generated at 2022-06-23 05:51:27.429116
# Unit test for constructor of class Attribute
def test_Attribute():
    """This is a test"""
    obj = Attribute(isa='str',
                    private=True,
                    default='foo',
                    required=False,
                    listof='str',
                    priority=2,
                    always_post_validate=True,
                    inherit=False,
                    alias='bar',
                    extend=True,
                    prepend=False,
                    static=True)
    obj.isa
    obj.private
    obj.default
    obj.required
    obj.listof
    obj.priority
    obj.always_post_validate
    obj.inherit
    obj.alias
    obj.extend
    obj.prepend
    obj.static


# Generated at 2022-06-23 05:51:31.145004
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a1 <= a2



# Generated at 2022-06-23 05:51:34.022934
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=10)
    assert attr_1 < attr_2



# Generated at 2022-06-23 05:51:35.203843
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    #TODO: Write this unit test
    return

# Generated at 2022-06-23 05:51:37.404323
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2 < attr1



# Generated at 2022-06-23 05:51:43.737551
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert(a1 < a2)
    assert(a1 <= a2)
    assert(not(a1 == a2))
    assert(a1 != a2)
    assert(not(a1 > a2))
    assert(not(a1 >= a2))
    assert(a2 > a1)
    assert(a2 >= a1)



# Generated at 2022-06-23 05:51:53.594363
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa='list'
    private=False
    default=[1,2,3]
    required=True
    listof=int
    priority=1
    class_type=None
    always_post_validate=False
    inherit=True
    alias='test_alias'
    extend=False
    prepend=False
    static=False

    attr = FieldAttribute(
        isa=isa,
        private=private,
        default=default,
        required=required,
        listof=listof,
        priority=priority,
        class_type=class_type,
        always_post_validate=always_post_validate,
        inherit=inherit,
        alias=alias,
        extend=extend,
        prepend=prepend,
        static=static,
    )

    assert attr

# Generated at 2022-06-23 05:51:54.750773
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    pass



# Generated at 2022-06-23 05:52:01.414422
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr1.priority = 0
    attr2 = Attribute()
    attr2.priority = 0
    attr3 = Attribute()
    attr3.priority = 1
    assert(attr1 <= attr2)
    assert(attr1 <= attr3)
    assert(not attr3 <= attr2)
    assert(not attr2 <= attr3)


# Generated at 2022-06-23 05:52:03.782173
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    aaa = Attribute(priority=1)
    bbb = Attribute(priority=2)
    return aaa > bbb


# Generated at 2022-06-23 05:52:14.655364
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    attr2 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-23 05:52:22.922670
# Unit test for constructor of class Attribute
def test_Attribute():
    _test_isa(Attribute)
    _test_private(Attribute)
    _test_default(Attribute)
    _test_required(Attribute)
    _test_listof(Attribute)
    _test_priority(Attribute)
    _test_class_type(Attribute)
    _test_always_post_validate(Attribute)
    _test_inherit(Attribute)
    _test_alias(Attribute)
    _test_extend(Attribute)
    _test_prepend(Attribute)
    _test_static(Attribute)
