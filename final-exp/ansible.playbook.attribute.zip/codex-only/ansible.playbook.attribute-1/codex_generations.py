

# Generated at 2022-06-23 05:42:25.419356
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=6)
    assert a1.__ge__(a2)
    assert a1.__ge__(a3)
    assert a3.__ge__(a2)


# Generated at 2022-06-23 05:42:27.143825
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute() == Attribute()
    assert not (Attribute() != Attribute())


# Generated at 2022-06-23 05:42:36.394686
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Build a FieldAttribute object containing all possible
    # attributes set to non-default values
    f = FieldAttribute(
        isa='string',
        private=True,
        default='foo',
        required=True,
        listof='dict',
        priority=1,
        class_type=dict,
        always_post_validate=True,
        inherit=False,
        alias='foo',
    )

    # Assert that all values have been initialized
    assert f.isa == 'string', 'FieldAttribute.isa not properly initialized'
    assert f.private == True, 'FieldAttribute.private not properly initialized'
    assert f.default == 'foo', 'FieldAttribute.default not properly initialized'
    assert f.required == True, 'FieldAttribute.required not properly initialized'

# Generated at 2022-06-23 05:42:38.388723
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=2)
    assert a1 == a2


# Generated at 2022-06-23 05:42:40.519196
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 >= a1


# Generated at 2022-06-23 05:42:44.972805
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.priority == attr2.priority
    assert attr1.priority == attr2
    assert attr1 == attr2


# Generated at 2022-06-23 05:42:51.759590
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='int')
    assert fa.isa == 'int'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True


# Generated at 2022-06-23 05:42:55.881634
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()

    import sys
    if sys.version_info >= (3, 2):
        assert not a.__ge__(b)
        assert not b.__ge__(a)
        assert a.__ge__(a)
        assert b.__ge__(b)

# Generated at 2022-06-23 05:43:08.222064
# Unit test for method __eq__ of class Attribute

# Generated at 2022-06-23 05:43:12.822800
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute()
    y = Attribute()
    x.priority = 1
    y.priority = 2
    assert x != y
    y.priority = 1
    assert x == y

# Generated at 2022-06-23 05:43:24.104960
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa='int', default=4, required=True)
    attr2 = FieldAttribute(isa='string', default='')
    attr3 = FieldAttribute(isa='list', default=[])
    attr2.alias = 'str_attr'
    assert attr1.isa == attr2.isa == attr3.isa == 'list'
    assert attr1.default == 4
    assert attr2.default == ''
    assert attr3.default == []
    assert attr1.required
    assert not attr2.required
    assert not attr3.required
    assert not attr1.private
    assert attr1.alias is None
    assert attr2.alias == 'str_attr'
    return True

# Test the comparison operators

# Generated at 2022-06-23 05:43:26.492412
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute() > Attribute(priority=1)
    assert not Attribute() > Attribute()
    assert not Attribute(priority=1) > Attribute()



# Generated at 2022-06-23 05:43:28.188848
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute()



# Generated at 2022-06-23 05:43:32.462091
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(default=dict())
    except TypeError:
        pass
    else:
        raise Exception("Expected a TypeError")


# Generated at 2022-06-23 05:43:34.633440
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority=1)
    y = Attribute(priority=3)

    assert x <= y
    assert not x >= y


# Generated at 2022-06-23 05:43:39.585975
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='str')
    assert attribute.isa == 'str'
    assert attribute.private == False
    assert attribute.default is None
    assert attribute.required == False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.always_post_validate is False


# Generated at 2022-06-23 05:43:51.342976
# Unit test for constructor of class Attribute
def test_Attribute():

    def default():
        return dict(a=1, b=2)

    a = Attribute(isa='str', private=True, default=default, required=True, listof='str', priority=1, class_type=None,
                  always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == default
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

    # test with valid isa's
    a = Attribute(isa='str')
    assert a.isa == 'str'


# Generated at 2022-06-23 05:44:02.757314
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create object without any parameter
    a = FieldAttribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

    # Create object with all parameters
    a = FieldAttribute(
        isa='list',
        private=True,
        default='default',
        required=True,
        listof='listof',
        priority=1,
        class_type='class_type',
        always_post_validate=True,
        inherit=False,
        alias='alias',
    )

# Generated at 2022-06-23 05:44:04.200218
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=0)



# Generated at 2022-06-23 05:44:13.463440
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default={}, required=True)
    assert attr
    assert attr.isa == 'dict'
    assert attr.default == {}
    assert attr.required
    try:
        attr = FieldAttribute(isa='dict', default={'x':1}, required=True)
        assert False, 'FieldAttribute constructor did not throw exception on non-callable default'
    except Exception:
        pass
    attr = FieldAttribute(isa='dict', default=lambda: {}, required=True)
    assert attr
    assert attr.isa == 'dict'
    assert attr.default() == {}
    assert attr.required


# Generated at 2022-06-23 05:44:15.152554
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_attribute_constructor(FieldAttribute)


# Generated at 2022-06-23 05:44:17.199511
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    other = Attribute(priority=1)
    assert attr == other


# Generated at 2022-06-23 05:44:19.682442
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    att1 = Attribute()
    att1.priority = 1
    att2 = Attribute()
    att2.priority = 2
    assert att2 >= att1



# Generated at 2022-06-23 05:44:23.368993
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert c >= b
    assert b <= c
    assert c > b



# Generated at 2022-06-23 05:44:27.835026
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    assert a >= b
    assert a >= c
    assert b >= a
    assert b >= c
    assert c >= a
    assert c >= b

# Generated at 2022-06-23 05:44:31.344423
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_a = Attribute(priority = 0)
    attr_b = Attribute(priority = 5)
    assert attr_a < attr_b

# Generated at 2022-06-23 05:44:32.779768
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    Attribute(1) == Attribute(1)


# Generated at 2022-06-23 05:44:38.449211
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    attr3 = Attribute(priority=1)
    assert attr1 == attr2, "method __eq__ of class Attribute is not behaving correctly"
    assert not attr1 == attr3, "method __eq__ of class Attribute is not behaving correctly"


# Generated at 2022-06-23 05:44:44.441278
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(required=True, priority=0)
    attr2 = Attribute(required=False, priority=0)
    assert (attr1 == attr2)

    attr1 = Attribute(required=True, priority=1)
    attr2 = Attribute(required=False, priority=0)
    assert (attr1 != attr2)


# Generated at 2022-06-23 05:44:50.572487
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field=FieldAttribute()
    assert field.isa == None
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None

# Generated at 2022-06-23 05:45:01.341530
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa='dict')
    attr2 = FieldAttribute(isa='list')
    assert(attr1 == attr2)
    assert(attr1 <= attr2)
    assert(attr1 >= attr2)
    assert(not attr1 < attr2)
    assert(not attr1 > attr2)
    assert(not attr1 != attr2)

    attr3 = FieldAttribute(isa='dict', priority=1)
    assert(attr3 != attr1)
    assert(attr3 != attr2)
    assert(attr3 > attr1)
    assert(attr3 > attr2)
    assert(not attr1 > attr3)
    assert(not attr2 > attr3)
    assert(attr3 >= attr1)

# Generated at 2022-06-23 05:45:10.286895
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a0 = Attribute(
    isa=None,
    private=False,
    default=None,
    required=False,
    listof=None,
    priority=0,
    class_type=None,
    always_post_validate=False,
    inherit=True,
    alias=None,
    extend=False,
    prepend=False,
    static=False,
)
    a1 = Attribute(
    isa=None,
    private=False,
    default=None,
    required=False,
    listof=None,
    priority=100,
    class_type=None,
    always_post_validate=False,
    inherit=True,
    alias=None,
    extend=False,
    prepend=False,
    static=False,
)
    assert a

# Generated at 2022-06-23 05:45:17.828024
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
                   class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                   prepend=False, static=False)
    a2 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
                   class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                   prepend=False, static=False)

    # a1.__eq__(a2) == True
    assert (a1 == a2)


# Generated at 2022-06-23 05:45:20.393276
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 < a1)



# Generated at 2022-06-23 05:45:22.758093
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(required=False)

    assert a is not None
    assert a.required is False
    assert a.private is False



# Generated at 2022-06-23 05:45:34.748757
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Basic
    a = FieldAttribute(isa='str')
    assert a.isa == 'str' and a.private is False and a.default is None and a.required is False and a.listof is None and a.priority == 0 and a.class_type is None and a.always_post_validate is False and a.inherit is True and a.alias is None and a.extend is False and a.prepend is False and a.static is False

    # str to int
    a = FieldAttribute(isa='int')
    assert a.isa == 'int' and a.private is False and a.default is None and a.required is False and a.listof is None and a.priority == 0 and a.class_type is None and a.always_post_validate is False and a.inherit is True and a.alias is None

# Generated at 2022-06-23 05:45:39.612698
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Create a couple of Attribute objects
    attributes_A = Attribute(0)
    attributes_B = Attribute(1)

    # Inserting the same object into a set should overwrite it
    assert attributes_A.__le__(attributes_B) == False
    assert attributes_B.__le__(attributes_A) == True

# Generated at 2022-06-23 05:45:42.142576
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict', default={}, required=True)
    assert fa.isa == 'dict'
    assert fa.default == {}
    assert fa.required == True



# Generated at 2022-06-23 05:45:45.548369
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(required=True)
    a2 = Attribute(required=True)
    assert(a1.__ne__(a2) == False)



# Generated at 2022-06-23 05:45:48.660582
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a != b



# Generated at 2022-06-23 05:45:50.905357
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a.__le__(b)



# Generated at 2022-06-23 05:45:53.251233
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2

    assert a != b


# Generated at 2022-06-23 05:46:03.825953
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    field = FieldAttribute()
    assert (field.isa is None)
    assert (field.private is False)
    assert (field.default is None)
    assert (field.required is False)
    assert (field.listof is None)
    assert (field.priority == 0)
    assert (field.class_type is None)
    assert (field.always_post_validate is False)
    assert (field.inherit is True)
    assert (field.static is False)


# Generated at 2022-06-23 05:46:08.279856
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()

# Generated at 2022-06-23 05:46:11.112842
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    import pytest
    attribute_a = Attribute(priority=1)
    attribute_b = Attribute(priority=2)
    assert attribute_b > attribute_a


# Generated at 2022-06-23 05:46:14.771948
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute().__lt__(Attribute(priority=1))
    assert not Attribute(priority=1).__lt__(Attribute())
    assert not Attribute().__lt__(Attribute())


# Generated at 2022-06-23 05:46:16.924106
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2


# Generated at 2022-06-23 05:46:24.927813
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1_priority = 1
    b1_priority = 2
    b2_priority = 3

    a1 = Attribute(priority=a1_priority)
    b1 = Attribute(priority=b1_priority)
    b2 = Attribute(priority=b2_priority)

    # assert a1 >= b1
    # assert not a1 >= b2
    # assert a1 <= b1
    # assert a1 <= b2
    # assert not a1 < b1
    # assert a1 < b2
    # assert not a1 > b1
    # assert not a1 > b2

test_Attribute___ge__()


# Generated at 2022-06-23 05:46:27.993854
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    FA1 = Attribute(priority=1)
    FA2 = Attribute(priority=2)
    assert(FA1.__ne__(FA2) == True)


# Generated at 2022-06-23 05:46:31.233026
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=1) <= Attribute(priority=2)
    assert Attribute(priority=1) <= Attribute(priority=1)
    assert not Attribute(priority=2) <= Attribute(priority=1)

# Generated at 2022-06-23 05:46:38.747268
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=2)
    a4 = Attribute(priority=0)
    assert(a3 > a2)
    assert(a3 > a1)
    assert(a2 > a1)
    assert(a1 >= a2 == False)
    assert(a1 <= a3 == True)
    assert(a1 == a1)
    assert(a1 == a4)
    assert(a1 != a2)
    assert(a1 != a3)


# Generated at 2022-06-23 05:46:49.514242
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    # test with equal priority
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert (attr1 >= attr2) == True
    assert (attr2 >= attr1) == True

    # test with 'attr1' having greater priority than 'attr2'
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=0)
    assert (attr1 >= attr2) == True
    assert (attr2 >= attr1) == False

    # test with 'attr1' having greater priority than 'attr2'
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert (attr1 >= attr2) == False
    assert (attr2 >= attr1) == True

#

# Generated at 2022-06-23 05:46:52.397197
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_a = FieldAttribute(priority=1)
    attr_b = FieldAttribute(priority=2)
    assert attr_b < attr_a



# Generated at 2022-06-23 05:46:53.957213
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert isinstance(a, Attribute)


# Generated at 2022-06-23 05:47:04.628816
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Missing isa
    try:
        attr = FieldAttribute(
            private=False,
            default=None,
            required=False,
            listof=None,
            priority=0,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None
        )
    except TypeError:
        pass
    else:
        raise Exception("FieldAttribute Constructor: Test #1: Failed")

    # Missing private

# Generated at 2022-06-23 05:47:07.609870
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    assert a == b
    assert a != c


# Generated at 2022-06-23 05:47:09.504642
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    if not (Attribute() > Attribute(priority=1)):
        raise Exception('test_Attribute___gt__ failed')



# Generated at 2022-06-23 05:47:13.778931
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    assert attr >= Attribute()
    assert attr >= Attribute(priority=1)
    assert not( attr >= Attribute(priority=2) )



# Generated at 2022-06-23 05:47:19.142668
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=42)
    b = Attribute(priority=42)
    c = Attribute(priority=1234)
    assert not a < b
    assert not a < a
    assert a < c
    assert not c < a


# Generated at 2022-06-23 05:47:20.709091
# Unit test for constructor of class Attribute
def test_Attribute():
    # check empty constructor
    myAttr = Attribute()
    assert myAttr is not None


# Generated at 2022-06-23 05:47:24.791251
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute()
    attr.priority = 10
    attr_1 = Attribute()
    attr_1.priority = 11
    attr_2 = Attribute()
    attr_2.priority = 12
    assert attr < attr_1 and attr < attr_2
    assert attr_1 < attr_2


# Generated at 2022-06-23 05:47:26.425348
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute()



# Generated at 2022-06-23 05:47:31.275086
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # create two instances
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    # they are unequal
    assert a != b

    # b is greater than a
    assert b > a
    assert b >= a
    assert a < b
    assert a <= b


# Generated at 2022-06-23 05:47:32.985004
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(1, private=1) != Attribute(2, private=2)


# Generated at 2022-06-23 05:47:35.880198
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    attr.priority = 4
    attr1 = Attribute()
    attr1.priority = 4
    assert(attr >= attr1)



# Generated at 2022-06-23 05:47:37.927916
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=5)
    b = Attribute(priority=5)
    assert a >= b


# Generated at 2022-06-23 05:47:45.944584
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert not a1.__ge__(a2)

    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert a1.__ge__(a2)

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    assert a1.__ge__(a2)

# Generated at 2022-06-23 05:47:48.374263
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert (a <= b)


# Generated at 2022-06-23 05:47:51.913811
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute = Attribute()
    attribute.priority = 1
    assert attribute < Attribute(priority=2)
    assert not attribute < Attribute(priority=1)
    assert not attribute < Attribute(priority=0)



# Generated at 2022-06-23 05:48:02.844907
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='bool',
        private=False,
        default=True,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='test1_alias',
    )
    assert attr.isa == 'bool'
    assert attr.private == False
    assert attr.default == True
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'test1_alias'
    attr.isa = 'int'

# Generated at 2022-06-23 05:48:05.889139
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from operator import le
    attr1 = Attribute(isa='int')
    attr2 = Attribute(isa='int', priority=10)
    print(le(attr1, attr2))


# Generated at 2022-06-23 05:48:14.510880
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    class TestAttribute(Attribute):
        def __init__(self, priority = 0):
            Attribute.__init__(self, priority=priority)

    assert TestAttribute(1) >= TestAttribute(2)
    assert TestAttribute(1) <= TestAttribute(2)
    assert TestAttribute(1) >= TestAttribute(1)
    assert TestAttribute(1) <= TestAttribute(1)
    # TestAttribute(1) == TestAttribute(1)
    # TestAttribute(1) != TestAttribute(1)
    assert not TestAttribute(1) == TestAttribute(2)
    assert not TestAttribute(1) != TestAttribute(2)


# Generated at 2022-06-23 05:48:17.695112
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    
    attribute1 = Attribute()
    attribute1.priority = 1
   
    attribute2 = Attribute()
    attribute2.priority = 2

    assert (attribute2 <= attribute1)


# Generated at 2022-06-23 05:48:19.880438
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a2 > a1


# Generated at 2022-06-23 05:48:27.970180
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

# Unit test to test the equality of two same Attributes, i.e. priority = 0

# Generated at 2022-06-23 05:48:34.812983
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # ('test_Attribute___ne__',
    #  '''
    #  Attribute Object Method
    #  -------------------------
    #
    #  Tests relevant method of class Attribute object:
    #
    #  __ne__
    #
    #  '''),

    # Setup
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2

    # Test string comparison
    if a.__ne__(b) == True:
        pass
    else:
        print("Error: __ne__ method has error")

    # Teardown
    del a
    del b


# Generated at 2022-06-23 05:48:37.659056
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.priority = 10

    b = Attribute()
    b.priority = 8

    assert a > b


# Generated at 2022-06-23 05:48:41.719661
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Given
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)

    # Then
    assert a3 < a2
    assert not a3 < a3
    assert not a3 < a1


# Generated at 2022-06-23 05:48:53.562765
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    a = Attribute(isa=str, default='foo', inherit=False)
    assert a.isa is str
    assert a.default == 'foo'
    assert a.inherit is False
    a = Attribute(isa=str, default=AnsibleUnsafeText('foo'), inherit=False)
    assert a.isa is str
    assert a.default == 'foo'
    assert a.inherit is False
    a = Attribute(isa=str, default=AnsibleUnsafeText(u'foo'), inherit=False)
    assert a.isa is str
    assert a.default == 'foo'
    assert a.inherit is False

# Generated at 2022-06-23 05:48:55.721490
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a=Attribute(priority=1)
    b=Attribute(priority=0)
    assert not a<b

# Generated at 2022-06-23 05:49:05.496934
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-23 05:49:07.719873
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if a1 >= a2:
        raise AssertionError()
    if a2 <= a1:
        raise AssertionError()
    if a1 < a2:
        pass
    else:
        raise AssertionError()
    if a2 > a1:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-23 05:49:17.762797
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa="class_execution", private=True, default="dict", required=False)
    assert attr.isa == "class_execution"
    assert attr.private == True
    assert attr.default == "dict"
    assert attr.required == False
    
    #verify defaults
    attr = FieldAttribute(isa="class_execution")
    assert attr.isa == "class_execution"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False

    #verify fail

# Generated at 2022-06-23 05:49:21.074954
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa='string', priority=5)
    attr2 = Attribute(isa='string', priority=5)
    assert attr1 == attr2



# Generated at 2022-06-23 05:49:31.389148
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(
        isa='str',
        private=False,
        default='test',
        required=True,
        listof='str',
        priority=0,
        class_type='str',
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    assert 'str' == f.isa
    assert False == f.private
    assert 'test' == f.default
    assert True == f.required
    assert 'str' == f.listof
    assert 0 == f.priority
    assert 'str' == f.class_type
    assert False == f.always_post_validate
    assert True == f.inherit
    assert None == f.alias

# Generated at 2022-06-23 05:49:43.708381
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test Attribute with no argument
    # FIXME: Need a better test
    a1 = Attribute()
    print(a1)
    assert a1 == a1
    assert a1 >= a1
    assert a1 <= a1
    assert not a1 > a1
    assert not a1 < a1
    assert a1 != None

    a2 = Attribute(priority=0)
    print(a2)
    assert a2 == a2
    assert a2 >= a2
    assert a2 <= a2
    assert not a2 > a2
    assert not a2 < a2
    assert a2 != None

    a3 = Attribute(priority=1)
    assert not a1 == a3
    assert a1 != a3
    assert a1 <= a3
    assert not a1 >= a3

# Generated at 2022-06-23 05:49:51.637484
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """
    Unit test for method __gt__ of class Attribute
    """
    attribute_obj = Attribute()
    other_attribute_obj = Attribute()
    attribute_obj.priority = 1
    other_attribute_obj.priority = 2
    assert attribute_obj.__gt__(other_attribute_obj) == False
    attribute_obj.priority = 2
    other_attribute_obj.priority = 1
    assert attribute_obj.__gt__(other_attribute_obj) == True



# Generated at 2022-06-23 05:49:54.797872
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 < a1


# Generated at 2022-06-23 05:49:57.315880
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr == attr2


# Generated at 2022-06-23 05:50:01.009025
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 0
    assert a > b , "Attribute class __gt__ test failed."


# Generated at 2022-06-23 05:50:04.900989
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=2)
    assert a1.__lt__(a2) is False
    assert a2.__lt__(a1) is True


# Generated at 2022-06-23 05:50:08.093544
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a.__eq__(b)
    assert not b.__eq__(a)


# Generated at 2022-06-23 05:50:10.712811
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(is_a='int', default=0, required=True)
    assert isinstance(fa, FieldAttribute)



# Generated at 2022-06-23 05:50:17.737326
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr2 = Attribute()

    # set priority of attr
    attr.priority = 0
    attr2.priority = 1

    # assert __ne__
    assert attr != attr2


# Generated at 2022-06-23 05:50:19.425975
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 2)
    return a < b


# Generated at 2022-06-23 05:50:21.081189
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    default = 42
    f = FieldAttribute(default=default)
    assert f.default == default, "Unexpected value for f.default"



# Generated at 2022-06-23 05:50:32.973638
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.playbook.attribute import FieldAttribute
    r = FieldAttribute(isa='str', required=True, default=None)
    assert r.isa == 'str'
    assert r.required == True
    assert r.default == None

    r = FieldAttribute(isa='list', required=True)
    assert r.isa == 'list'
    assert r.required == True
    assert r.default is None

    # test that objects with mutable defaults raise an exception
    try:
        r = FieldAttribute(isa='list', required=True, default=[])
        assert False
    except TypeError:
        pass

    # test that objects with mutable defaults do not raise an exception if
    # they provide a callable as a default
    r = FieldAttribute(isa='list', required=True, default=lambda: [])



# Generated at 2022-06-23 05:50:44.498587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(isa='str', private=False,
                          default=None,
                          required=False,
                          listof=None,
                          priority=0,
                          class_type=None,
                          always_post_validate=False,
                          inherit=True,
                          alias=None,
                          extend=False,
                          prepend=False,
                          static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr

# Generated at 2022-06-23 05:50:45.837396
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a != b


# Generated at 2022-06-23 05:50:50.488453
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert a3 < a2 < a1



# Generated at 2022-06-23 05:50:54.133417
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    c = Attribute(priority=1)

    assert a == b
    assert a != c


# Generated at 2022-06-23 05:50:57.446616
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    temp_attribute = Attribute()
    if temp_attribute != temp_attribute:
        raise AssertionError()


# Generated at 2022-06-23 05:51:08.516845
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set

    # isa
    assert Attribute(isa=None)
    assert Attribute(isa=str)
    assert Attribute(isa=unicode)
    assert Attribute(isa='str')
    assert Attribute(isa='unicode')
    assert Attribute(isa='list')
    assert Attribute(isa='dict')
    assert Attribute(isa='set')
    assert Attribute(isa='bool')
    assert Attribute(isa='boolean')
    assert Attribute(isa='int')
    assert Attribute(isa='float')
    assert Attribute(isa='none')
    assert Attribute(isa='path')
    assert Attribute(isa='raw')
    assert Attribute(isa='class')

# Generated at 2022-06-23 05:51:13.372857
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attrA = Attribute(priority=2)
    attrB = Attribute(priority=2)
    attrC = Attribute(priority=3)
    assert attrA == attrB
    assert attrB == attrA
    assert not attrA == attrC
    assert not attrC == attrA


# Generated at 2022-06-23 05:51:17.367944
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr = Attribute(priority=1)
    other = Attribute()
    other = Attribute(priority=2)
    assert attr.__ne__(other) == True

# Generated at 2022-06-23 05:51:22.243111
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # instantiating Attribute object
    attr = Attribute()

    # calling method __ge__ of class Attribute with different values
    assert attr.__ge__(attr) == True
    # calling method __ge__ of class Attribute with different values
    assert attr.__ge__(attr) == True



# Generated at 2022-06-23 05:51:27.591428
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=3)
    b = Attribute(priority=5)
    c = Attribute(priority=3)
    assert a < b
    assert b > a
    assert b >= a
    assert a <= b
    assert a is not b
    assert a is not c
    assert b is not c
    assert a == c
    assert b != c

# Generated at 2022-06-23 05:51:35.456567
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test Attribute.__le__() method
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=5)
    assert not a1 < a2
    assert not a2 < a1
    assert a1 <= a2
    assert a2 <= a1
    assert a1 < a3
    assert not a3 < a1
    assert a1 <= a3
    assert not a3 <= a1

# Generated at 2022-06-23 05:51:37.713403
# Unit test for constructor of class Attribute
def test_Attribute():
    _Attr = Attribute('list')
    assert _Attr is not None
    assert _Attr.isa == 'list'

# Generated at 2022-06-23 05:51:42.487408
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=1)
    attribute3 = Attribute(priority=100)

    assert attribute1.__eq__(attribute2) == True
    assert attribute1.__eq__(attribute3) == False
    assert attribute2.__eq__(attribute3) == False


# Generated at 2022-06-23 05:51:46.124014
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a_lt = Attribute(priority=1)
    a_gt = Attribute(priority=2)
    assert(a_lt < a_gt)


# FieldAttribute is deprecated in favour of Attribute

# Generated at 2022-06-23 05:51:49.412949
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_attribute_1 = FieldAttribute(priority=1)
    field_attribute_2 = FieldAttribute(priority=0)
    assert(field_attribute_2 < field_attribute_1)
    assert(not field_attribute_1 < field_attribute_2)

# Generated at 2022-06-23 05:51:52.226703
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=0) > Attribute(priority=-1)
    assert not Attribute(priority=-1) > Attribute(priority=-1)
    assert Attribute(priority=-1) > Attribute(priority=-2)


# Generated at 2022-06-23 05:52:04.302375
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml import objects

    attr = Attribute(
        isa='foo',
        private=True,
        default='bar',
        required=True,
        listof='items',
        priority=50,
        class_type=objects.AnsibleSequence,
        always_post_validate=True,
        inherit=True,
        alias='bar',
        extend=True,
        prepend=True,
        static=True,
    )
    assert attr.isa == 'foo'
    assert attr.private == True
    assert attr.default == 'bar'
    assert attr.required == True
    assert attr.listof == 'items'
    assert attr.priority == 50
    assert attr.class_type == objects.AnsibleSequence

# Generated at 2022-06-23 05:52:15.192234
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print("test_Attribute___le__()")

    def print_compare(a, b):
        print("a: %s" % a)
        print("b: %s" % b)
        print("a < b: %s" % (a < b))
        print("a <= b: %s" % (a <= b))
        print("a > b: %s" % (a > b))
        print("a >= b: %s" % (a >= b))
        print("a == b: %s" % (a == b))
        print("a != b: %s" % (a != b))
        print("")
        
    def print_compare_attributes(a, b):
        print("a: %s" % a.priority)
        print("b: %s" % b.priority)

# Generated at 2022-06-23 05:52:19.741223
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    assert (attr1 < attr3) == False
    assert (attr2 < attr3) == True
    assert (attr1 < attr2) == True
    assert (attr2 < attr1) == False

FieldAttribute.__doc__ = Attribute.__doc__
