

# Generated at 2022-06-23 05:42:34.421954
# Unit test for constructor of class Attribute

# Generated at 2022-06-23 05:42:44.521538
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # If a default is set and isa is set to anything that is a container type
    # (list, dict or set) then an exception is raised
    try:
        field = FieldAttribute(isa='list', default=['foo'])
    except TypeError:
        assert True
    else:
        assert False
    try:
        field = FieldAttribute(isa='dict', default=dict(foo='bar'))
    except TypeError:
        assert True
    else:
        assert False
    try:
        field = FieldAttribute(isa='set', default=set(['foo']))
    except TypeError:
        assert True
    else:
        assert False
    # A default can be anything that is not a container type
    field = FieldAttribute(isa='str', default=1)

# Generated at 2022-06-23 05:42:48.406219
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='str')
    assert isinstance(attribute, FieldAttribute)
    assert attribute.isa is 'str'

    attribute = FieldAttribute(isa='str', default='test')
    assert isinstance(attribute, FieldAttribute)
    assert attribute.isa is 'str'
    assert attribute.default is 'test'


# Generated at 2022-06-23 05:42:52.354574
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1, isa='int')
    b = Attribute(priority=2, isa='int')

    assert a == b
    assert not a != b
    assert a < b
    assert not a > b
    assert a <= b
    assert not a >= b


# Generated at 2022-06-23 05:43:01.281563
# Unit test for constructor of class Attribute
def test_Attribute():

    # valid default types for a Attribute object
    valid_default = [None, 1, "1", {}, {'a': 'b'}, [], ["a", "b"], set(), set(['a', 'b'])]
    for default in valid_default:
        a = Attribute(isa=None, private=None, default=default, required=None, listof=None, priority=None, class_type=None, always_post_validate=None, inherit=True)

    # invalid default types for a Attribute object
    invalid_default = [{1: 2}, set([{'a': 'b'}])]

# Generated at 2022-06-23 05:43:02.426230
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a is not None


# Generated at 2022-06-23 05:43:11.834379
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = Attribute()
    field2 = Attribute()

    # given two Attribute objects, __eq__ should return True
    # if the priority of two Attribute objects is the same
    field1.priority = 1
    field2.priority = 1
    assert field1 == field2
    assert field1.__eq__(field2)

    # given two Attribute objects, __eq__ should return False
    # if the priority of two Attribute objects is different
    field1.priority = 1
    field2.priority = 2
    assert field1 != field2
    assert not field1.__eq__(field2)


# Generated at 2022-06-23 05:43:13.737326
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)


# Generated at 2022-06-23 05:43:16.967371
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute(priority=3)

    assert not(a.priority >= b.priority)
    assert b.priority >= a.priority


# Generated at 2022-06-23 05:43:21.391406
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute(private=False, default=None, required=False, priority=0, inherit=False)
    y = Attribute(private=False, default=None, required=False, priority=0, inherit=False)
    assert x.__ne__(y) == False


# Generated at 2022-06-23 05:43:31.326242
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    f = FieldAttribute(isa='foo', private=1, default='bar', required=2, listof='baz', priority=3, class_type=5, always_post_validate=6, inherit=7, alias=8, extend=9, prepend=10, static=11)
    g = FieldAttribute(isa='foo', private=1, default='bar', required=2, listof='baz', priority=3, class_type=5, always_post_validate=6, inherit=7, alias=8, extend=9, prepend=10, static=11)

# Generated at 2022-06-23 05:43:33.381266
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    ta = Attribute()
    ta.priority = 1
    tb = Attribute()
    tb.priority = 2
    assert ta != tb
    return True


# Generated at 2022-06-23 05:43:35.568132
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(listof=int)
    b = Attribute(listof=int)
    assert a < b




# Generated at 2022-06-23 05:43:38.313224
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    obj1 = Attribute()
    obj2 = Attribute()
    assert obj1 == obj2



# Generated at 2022-06-23 05:43:43.376921
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=0,is_required=False,default=None)
    print(attr1.__le__(attr1))
    attr2 = Attribute(priority=1,is_required=False,default=None)
    print(attr1.__le__(attr2))


# Generated at 2022-06-23 05:43:46.136265
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
  a = Attribute(priority=1)
  b = Attribute(priority=2)
  return a.__ne__(b)


# Generated at 2022-06-23 05:43:47.895079
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute().__eq__(Attribute(priority=2)) is True


# Generated at 2022-06-23 05:43:52.918285
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute('str')
    assert attr.isa == 'str'
    assert not attr.private
    assert attr.required == False
    assert attr.priority == 0
    assert attr.extend == False
    assert attr.always_post_validate == False
    assert attr.class_type == None
    assert attr.inherit == True



# Generated at 2022-06-23 05:43:57.257611
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    print('attr1 %r == attr2 %r: %r' % (attr1, attr2, attr1 == attr2))
    print('attr1 %r != attr2 %r: %r' % (attr1, attr2, attr1 != attr2))


# Generated at 2022-06-23 05:43:59.020203
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # TODO: implement this unit test
    pass


# Generated at 2022-06-23 05:44:05.854456
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    f1 = FieldAttribute(priority=1)
    f2 = FieldAttribute(priority=1)
    f3 = FieldAttribute(priority=3)
    assert f3.__ge__(f1) == True
    assert f1.__ge__(f2) == True
    assert f2.__ge__(f1) == True
    assert f1.__ge__(f3) == False


# Generated at 2022-06-23 05:44:11.525616
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=9)
    b = Attribute(priority=10)
    c = Attribute(priority=11)

    # Return value of __ne__() method
    assert a.__ne__(b) == True
    assert b.__ne__(c) == False
    assert c.__ne__(b) == True


# Generated at 2022-06-23 05:44:20.775429
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='list', listof='str', static=True)
    assert a.listof == 'str'

    a = Attribute(isa='list', default=[])
    assert a.default == []
    assert isinstance(a.default, list)

    a = Attribute

# Generated at 2022-06-23 05:44:24.687296
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    v1 = Attribute(isa="test1", default=1, priority=1)
    v2 = Attribute(isa="test2", default=2, priority=2)
    assert v1.__gt__(v2)


# Generated at 2022-06-23 05:44:29.008054
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=2)
    assert attribute2.__gt__(attribute1)


# Generated at 2022-06-23 05:44:32.356654
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    a.priority = 2
    b = Attribute()
    b.priority = 1
    res = a < b
    assert res


# Generated at 2022-06-23 05:44:35.215937
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=10)
    attr2 = Attribute(priority=20)
    assert (attr2 <= attr)


# Generated at 2022-06-23 05:44:47.119830
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Check if __init__() called with isa
    isa = 'test_isa'
    default = 'test_default'
    private = 'test_private'
    required = 'test_required'
    listof = 'test_listof'
    priority = 'test_priority'
    class_type = 'test_class_type'
    always_post_validate = 'test_post_validate'
    inherit = 'test_inherit'
    alias = 'test_alias'
    extend = 'test_extend'
    prepend = 'test_prepend'
    static = 'test_static'
    attr = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)
    assert attr.isa

# Generated at 2022-06-23 05:44:49.300550
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute()
    a2 = Attribute()
    a1.priority = 1
    a2.priority = 2
    print(a1.__le__(a2))
    return



# Generated at 2022-06-23 05:44:54.177544
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    assert attr != attr2
    assert not attr == attr2



# Generated at 2022-06-23 05:44:58.996398
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils import basic

    # Test that constructor of class Attribute with different options
    attr = Attribute()
    basic.assert_equal(attr.isa, None)
    basic.assert_equal(attr.private, False)
    basic.assert_equal(attr.default, None)
    basic.assert_equal(attr.required, False)
    basic.assert_equal(attr.listof, None)
    basic.assert_equal(attr.priority, 0)
    basic.assert_equal(attr.class_type, None)
    basic.assert_equal(attr.always_post_validate, False)
    basic.assert_equal(attr.inherit, True)
    basic.assert_equal(attr.alias, None)


# Generated at 2022-06-23 05:45:13.309092
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    d = Attribute(priority=4)
    assert a.__gt__(b) == False
    assert a.__gt__(a) == False
    assert a.__gt__(c) == True
    assert a.__gt__(d) == True
    assert b.__gt__(a) == True
    assert b.__gt__(b) == False
    assert b.__gt__(c) == True
    assert b.__gt__(d) == True
    assert c.__gt__(a) == False
    assert c.__gt__(b) == False
    assert c.__gt__(c) == False
    assert c.__gt__(d) == True

# Generated at 2022-06-23 05:45:21.570758
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    def _test_Attribute___lt__(actual_priority, other_priority, expected_result):
        attribute = Attribute(priority=actual_priority)
        other = Attribute(priority=other_priority)
        assert (attribute < other) == expected_result

    _test_Attribute___lt__(0, 0, False)
    _test_Attribute___lt__(0, 1, True)
    _test_Attribute___lt__(1, 0, False)
    _test_Attribute___lt__(1, 1, False)



# Generated at 2022-06-23 05:45:24.364489
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=3)
    attribute2 = Attribute(priority=4)
    assert(attribute1.__ge__(attribute2))


# Generated at 2022-06-23 05:45:33.748241
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    a2 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

   

# Generated at 2022-06-23 05:45:44.266231
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0).__ne__(Attribute(priority=0)) 
    assert Attribute(priority=0).__ne__(Attribute(priority=1)) 
    assert Attribute(priority=0).__ne__(Attribute(priority=2)) 
    assert Attribute(priority=1).__ne__(Attribute(priority=0)) 
    assert Attribute(priority=1).__ne__(Attribute(priority=1)) 
    assert Attribute(priority=1).__ne__(Attribute(priority=2)) 
    assert Attribute(priority=2).__ne__(Attribute(priority=0)) 
    assert Attribute(priority=2).__ne__(Attribute(priority=1)) 
    assert Attribute(priority=2).__ne__(Attribute(priority=2)) 
    return True

# Generated at 2022-06-23 05:45:53.768741
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', required=True, static=True)
    assert a.isa == 'list'
    assert a.required == True
    assert a.static == True

    try:
        a = Attribute(isa='list', default=['first'])
        assert False
    except:
        assert True

    try:
        a = Attribute(isa='dict', default={'first': 'second'})
        assert False
    except:
        assert True

    try:
        a = Attribute(isa='set', default={'first'})
        assert False
    except:
        assert True


# Generated at 2022-06-23 05:45:57.879901
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert not attr.__lt__(attr2)
    assert attr2.__lt__(attr)



# Generated at 2022-06-23 05:46:08.002969
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    b = Attribute(isa="foo", alias="bar")
    assert b.isa == "foo"
    assert b.private == False
    assert b.default == None
    assert b.required == False
    assert b.listof == None
    assert b.priority == 0
    assert b.class_type == None


# Generated at 2022-06-23 05:46:10.915876
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a.__ge__(b) is False
    assert b.__ge__(a) is False


# Generated at 2022-06-23 05:46:13.936182
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa="boolean")
    b = Attribute(isa="boolean")

    assert (a == b) == True
    assert (a != b) == False


# Generated at 2022-06-23 05:46:17.927969
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # The two arguments of attr1 and attr2 and the return value should be changed
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    return attr2 > attr1
    


# Generated at 2022-06-23 05:46:20.706203
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__le__(a2) == True
    assert a2.__le__(a1) == False

# Generated at 2022-06-23 05:46:24.293367
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    d = Attribute(priority=4)
    assert a < b
    assert b < c
    assert c < d



# Generated at 2022-06-23 05:46:35.325380
# Unit test for constructor of class Attribute
def test_Attribute():
    def default_func():
        return 1
    a = Attribute(
        isa=unicode,
        private=False,
        default=default_func,
        required=True,
        listof=unicode,
        priority=0,
        always_post_validate=False,
        inherit=True,
        alias=None,
        static=False,
    )
    assert a.isa is unicode
    assert a.private is False
    assert a.default is default_func
    assert a.required is True
    assert a.listof is unicode
    assert a.priority == 0
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.static is False



# Generated at 2022-06-23 05:46:37.461432
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 >= attr2

# Generated at 2022-06-23 05:46:48.157185
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    assert attr1.__gt__(attr2) == False
    assert attr1.__gt__(attr3) == False
    assert attr2.__gt__(attr3) == False
    assert attr3.__gt__(attr2) == True
    #
    # Unit test for method __lt__ of class Attribute
    #
    assert attr1.__lt__(attr2) == True
    assert attr1.__lt__(attr3) == True
    assert attr2.__lt__(attr3) == True
    assert attr3.__lt__(attr2) == False



# Generated at 2022-06-23 05:46:53.340746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest

    with pytest.raises(TypeError):
        FieldAttribute(default=['foo', 'bar'])

    f = FieldAttribute(default=['foo', 'bar'])
    assert f.default() == ['foo', 'bar']



# Generated at 2022-06-23 05:46:54.867524
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert FieldAttribute() >= FieldAttribute()



# Generated at 2022-06-23 05:46:57.828525
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 10)
    b = Attribute(priority = 9)
    assert a >= b

# Test for method __gt__ of class Attribute

# Generated at 2022-06-23 05:47:00.918628
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 6
    assert attr != 3
    # __ne__ should return True when priority of attr != other
    assert attr.__ne__(3)


# Generated at 2022-06-23 05:47:07.492673
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert not attr1 > attr2
    assert not attr1 == attr2
    assert attr1 != attr2
    assert attr1 <= attr2
    assert attr1 >= attr2
    assert not attr2 < attr1
    assert attr2 > attr1
    assert not attr2 == attr1
    assert attr2 != attr1
    assert not attr2 <= attr1
    assert attr2 >= attr1


# Generated at 2022-06-23 05:47:11.063787
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = FieldAttribute(priority=1)
    attr2 = FieldAttribute(priority=2)
    assert attr1.__ne__(attr2)
    assert not attr1.__ne__(attr1)


# Generated at 2022-06-23 05:47:21.894846
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    b = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-23 05:47:26.289043
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(isa=int)
    a2 = Attribute(isa=int)
    a1.priority = 0
    a2.priority = 1
    assert(a1.__lt__(a2) == True)
    assert(a2.__lt__(a1) == False)


# Generated at 2022-06-23 05:47:36.425096
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute()
    a4 = Attribute()
    a1.priority = 7
    a2.priority = 7
    a3.priority = 7
    a4.priority = 7
    assert(a1.__lt__(a2) == False)
    assert(a2.__lt__(a3) == False)
    assert(a3.__lt__(a4) == False)
    assert(a4.__lt__(a1) == False)
    a1.priority = 5
    a2.priority = 7
    a3.priority = 5
    a4.priority = 7

# Generated at 2022-06-23 05:47:42.667875
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=str)
    assert a.isa == str
    assert a.listof is None
    assert a.class_type is None

    b = Attribute(isa=str, listof=str)
    assert b.isa == str
    assert b.listof == str

    c = Attribute(isa=str, listof=str, class_type=str)
    assert c.isa == str
    assert c.listof == str
    assert c.class_type == str

# Generated at 2022-06-23 05:47:50.828434
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default={})
    except TypeError:
        pass
    else:
        assert False, "FieldAttribute accepted bad data"
    try:
        FieldAttribute(default=[])
    except TypeError:
        pass
    else:
        assert False, "FieldAttribute accepted bad data"
    try:
        FieldAttribute(default=set())
    except TypeError:
        pass
    else:
        assert False, "FieldAttribute accepted bad data"
    try:
        FieldAttribute(default=())
    except TypeError:
        pass
    else:
        assert False, "FieldAttribute accepted bad data"

# Generated at 2022-06-23 05:47:56.394193
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print('In test_Attribute___ne__')
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=3)
    assert (a1.__ne__(a2) == True)
    a2 = Attribute(priority=2)
    assert (a1.__ne__(a2) == False)


# Generated at 2022-06-23 05:48:03.578299
# Unit test for constructor of class Attribute
def test_Attribute():

    print(Attribute())
    print(Attribute(isa='int'))
    print(Attribute(isa='str', default='test'))
    print(Attribute(isa='list', default=['test']))
    print(Attribute(isa='list', default=[]))
    print(Attribute(isa='list', listof=list))
    print(Attribute(isa='list', listof='str'))
    print(Attribute(isa='list', listof='list', default=[]))
    print(Attribute(isa='list', listof='list', default=list()))



# Generated at 2022-06-23 05:48:10.125807
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Unit test for method __le__ of class Attribute
    #
    # This test case tests that the __le__ method of class Attribute works correctly
    #
    # Input:
    #   - None
    #
    # Expected result:
    #   - priority attribute of two objects is the same.
    #
    # Procedure:
    #   - 1. Create two objects of class Attribute.
    #   - 2. Check that the __le__ method works correctly for objects with the same priority attribute.
    #
    # Pass/Fail criteria:
    #   - The test case passes if the __le__ method works correctly for objects with the same priority attribute.

    a = Attribute()
    b = Attribute()

    a.priority = 1
    b.priority = 1

    assert(a <= b)


    # Unit test for

# Generated at 2022-06-23 05:48:18.567511
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa = None, private = False, default = None, required = False, listof = None, class_type = None, always_post_validate = False, inherit = True, alias = None, static = False)
    b = Attribute(isa = None, private = False, default = None, required = False, listof = None, class_type = None, always_post_validate = False, inherit = True, alias = None, static = False)
    result = a.__eq__(b)
    assert result == True;


# Generated at 2022-06-23 05:48:20.734775
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority = 0) > Attribute(priority = 1)


# Generated at 2022-06-23 05:48:26.140990
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    Attr1 = Attribute(default=None, priority=0)
    Attr2 = Attribute(default=None, priority=0)
    Attr3 = Attribute(default=None, priority=1)
    assert Attr1 == Attr2
    assert Attr1 != Attr3


# Generated at 2022-06-23 05:48:29.462362
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert a3 >= a2
    assert a2 >= a1



# Generated at 2022-06-23 05:48:32.759356
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_le = Attribute()
    attr_le.priority = 2
    attr_ge = Attribute()
    attr_ge.priority = 2
    assert attr_le <= attr_ge


# Generated at 2022-06-23 05:48:38.631420
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    c = Attribute(priority = 10)
    d = Attribute(priority = 20)

    # b <= a
    assert not (b <= a)

    # a <= b
    assert (a <= b)


# Generated at 2022-06-23 05:48:41.390651
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='float', default=0.0)
    # basic smoke test...
    assert fa.isa == 'float'
    assert fa.default == 0.0


# Generated at 2022-06-23 05:48:53.330102
# Unit test for constructor of class Attribute
def test_Attribute():
    import sys
    import ansible.parsing.yaml.constructor
    from ansible.parsing.yaml.constructor import SafeConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_text

    # (1) Constructor accepts None as an argument

# Generated at 2022-06-23 05:48:56.255080
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    r = a > b
    pri_r = r.priority

    assert pri_r == 1


# Generated at 2022-06-23 05:49:00.901724
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2
    assert not attr2 <= attr1


# Generated at 2022-06-23 05:49:03.164084
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute.__gt__(Attribute()) == Attribute.__eq__(Attribute())
    pass


# Generated at 2022-06-23 05:49:06.639468
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_attribute1 = Attribute(priority=0)
    field_attribute2 = Attribute(priority=1)
    assert field_attribute1 < field_attribute2
    assert not field_attribute2 < field_attribute1


# Generated at 2022-06-23 05:49:09.237267
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.play_context import PlayContext
    assert type(PlayContext.become) == FieldAttribute # type(attribute) is FieldAttribute


# Generated at 2022-06-23 05:49:18.951766
# Unit test for constructor of class Attribute
def test_Attribute():
    import inspect

    # try to init with a wrong parameter
    try:
        Attribute(environ='this is a test')
        raise Exception('constructor of class Attribute must throw an exception')
    except:
        pass

    a = Attribute()

    # check if all attributes are existent
    try:
        for name in inspect.getmembers(a, lambda a: not(inspect.isroutine(a))):
            if not name[0].startswith('_'):
                if not hasattr(a, name[0]):
                    raise Exception('class attribute \'%s\' not existent' % name[0])
    except:
        print('check error')
        raise

    # check if all parameters are set to the correct type

# Generated at 2022-06-23 05:49:22.068169
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute()
    a2 = Attribute()
    a1.priority = 10
    a2.priority = 20
    assert a2.priority > a1.priority


# Generated at 2022-06-23 05:49:24.788491
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert b < a


# Generated at 2022-06-23 05:49:32.611620
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test the comparison of two Attribute objects
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=1)
    assert a1 < a2
    assert a1 <= a2
    assert a2 > a1
    assert a2 >= a1
    assert a2 < a3
    assert a2 <= a3
    assert a3 > a2
    assert a3 >= a2
    assert a1 == a4
    assert a1 <= a4
    assert a1 >= a4
    assert a2 != a4
    assert a2 > a4
    assert a2 < a4


# Generated at 2022-06-23 05:49:35.196351
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f is not None


# Generated at 2022-06-23 05:49:44.298340
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa1 = FieldAttribute()
    assert(fa1.isa == None)
    assert(fa1.private == False)
    assert(fa1.default == None)
    assert(fa1.required == False)
    assert(fa1.listof == None)
    assert(fa1.priority == 0)
    assert(fa1.class_type == None)
    assert(fa1.always_post_validate == False)
    assert(fa1.inherit == True)
    assert(fa1.alias == None)
    assert(fa1.extend == False)
    assert(fa1.prepend == False)
    assert(fa1.static == False)



# Generated at 2022-06-23 05:49:50.967957
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test normal parameters
    a = Attribute(default=False)
    assert a.default == False
    # Test optional parameters
    a = Attribute(private=True)
    assert a.private == True


# Test class FieldAttribute inherits from Attribute

# Generated at 2022-06-23 05:50:00.146258
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test_alias', extend=True, prepend=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test_alias'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-23 05:50:04.584681
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    b.priority = 1
    if a == b:
        raise Exception("Not equal.")



# Generated at 2022-06-23 05:50:14.067828
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None

    # Test that we don't allow mutable defaults for FieldAttribute objects
    with pytest.raises(TypeError):
        FieldAttribute(default=[])
    with pytest.raises(TypeError):
        FieldAttribute(default={})
    with pytest.raises(TypeError):
        FieldAttribute(default=set())



# Generated at 2022-06-23 05:50:17.995216
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)

    assert a == b
    assert not (a == c)


# Generated at 2022-06-23 05:50:27.484865
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                  prepend=False, static=False)
    b = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=1,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                  prepend=False, static=False)

    if (a != b):
        print("Attribute has method __ne__. This is good.")
        return 1
    else:
        print("Method __ne__ of Attribute is incorrect.")
        return 0


# Generated at 2022-06-23 05:50:37.094827
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # class variable initialisation
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=4)
    a5 = Attribute(priority=5)
    a6 = Attribute(priority=6)
    a7 = Attribute(priority=7)
    a8 = Attribute(priority=8)
    a9 = Attribute(priority=9)
    a10 = Attribute(priority=10)
    a11 = Attribute(priority=11)
    a_test = Attribute(priority=0)

    # tests with normal situation
    assert a1.__gt__(a2)
    assert a2.__gt__(a3)
    assert a3.__gt__(a4)
   

# Generated at 2022-06-23 05:50:45.620333
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(
        isa='complex',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert f.isa == 'complex'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False


# Generated at 2022-06-23 05:50:47.731151
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    f = FieldAttribute(priority=0, private=True)
    assert (Attribute(priority=1, private=True)) != f


# Generated at 2022-06-23 05:50:51.670295
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=100)
    attr2 = Attribute(priority=200)
    assert attr1 < attr2, "attr1 and attr2 comparision failed"


# Generated at 2022-06-23 05:51:00.047529
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    class Parent:
        field = FieldAttribute(priority=5)

    parent = Parent()
    parent.field = 'Parent'

    class Child(Parent):
        field = FieldAttribute(priority=1)

    child = Child()
    child.field = 'Child'

    assert parent.field == 'Parent'
    assert child.field == 'Child'
    assert parent.field > child.field

# Generated at 2022-06-23 05:51:04.509567
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def test_attribute():
        try:
            attribute = FieldAttribute(isa='bool', default=[])
            print(attribute.isa, attribute.default)
        except:
            print('failed to create attribute')
    test_attribute()

# test_FieldAttribute()

# Generated at 2022-06-23 05:51:09.480831
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """Unit test for method __le__ of class Attribute"""
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)

    assert(attribute_1.__le__(attribute_2)) == True
    assert(attribute_1.__le__(attribute_1)) == True
    assert(attribute_2.__le__(attribute_1)) == False


# Generated at 2022-06-23 05:51:11.150546
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    tmp1 = Attribute(priority=1)
    tmp2 = Attribute(priority=2)
    assert tmp1 <= tmp2


# Generated at 2022-06-23 05:51:18.735914
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(isa='list', default=[1,2,3])
        Attribute(isa='list', default=(1,2,3))
        Attribute(isa='list', default=set([1,2,3]))
        Attribute(isa='list', default={1: 1, 2: 2, 3: 3})
        Attribute(isa='list', default=set([1,2,3]))
        Attribute(isa='list', default=frozenset([1,2,3]))
        Attribute(isa='list', default='foo')
    except TypeError as e:
        raise AssertionError('Attribute constructor raises TypeError on mutable default value')
    def fn():
        return []
    Attribute(isa='list', default=fn)



# Generated at 2022-06-23 05:51:24.563277
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )



# Generated at 2022-06-23 05:51:29.686918
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Default case
    item = FieldAttribute()
    # All attributes are present
    item = FieldAttribute(
        isa='string',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    # test wrong default value
    try:
        item = FieldAttribute(default={'a':1})
        assert False, 'Exception expected'
    except TypeError:
        pass


# Generated at 2022-06-23 05:51:32.921585
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    attr1 = FieldAttribute()
    attr2 = FieldAttribute()

    attr1.priority = 10
    attr2.priority = 20

    assert attr2 < attr1


# Generated at 2022-06-23 05:51:37.897529
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field_attribute_1 = FieldAttribute(priority=1)
    field_attribute_1_1 = FieldAttribute(priority=1)
    field_attribute_2 = FieldAttribute(priority=2)
    assert(field_attribute_1 == field_attribute_1_1)
    assert(field_attribute_1 != field_attribute_2)



# Generated at 2022-06-23 05:51:43.445420
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute()
    a1.priority = 10
    a2 = Attribute()
    a2.priority = 20
    assert a1.priority < a2.priority
    assert a2.priority >= a1.priority
    assert not a1 < a1
    assert a1 < a2
    assert not a2 < a1
    assert not a2 < a2


# Generated at 2022-06-23 05:51:48.605406
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    c=10
    for i in range(0,c):
        for j in range(0,c):
            a=Attribute(isa='str', priority = i)
            b=Attribute(isa='str', priority = j)
            assert (i < j and a < b) or (i >= j and not a < b)
test_Attribute___lt__()



# Generated at 2022-06-23 05:51:53.969362
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = FieldAttribute()
    b = FieldAttribute()
    a.priority = 0
    b.priority = 0
    assert a is not b
    assert a == b
    assert a >= b
    assert b >= a
    assert b <= a
    assert a <= b
    assert not (a > b)
    assert not (a < b)
    assert not (b > a)
    assert not (b < a)


# Generated at 2022-06-23 05:51:55.044768
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    pass


# Generated at 2022-06-23 05:51:58.816761
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    class A(Attribute):
        pass
    class B(Attribute):
        pass
    a = A()
    b = B()
    a.priority = 1
    b.priority = 1
    assert a == b


# Generated at 2022-06-23 05:52:07.527100
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # all these should pass without any exceptions raised
    try:
        FieldAttribute(isa = 'dict') # 1
        FieldAttribute(isa = 'string') # 2
        FieldAttribute(isa = 'dict', default = dict()) # 3
        FieldAttribute(isa = 'dict', default = dict) # 4
        FieldAttribute(isa = 'dict', default = lambda: dict()) # 5
        FieldAttribute() # 6
    except Exception as e:
        raise AssertionError("FieldAttribute constructor allowed an invalid argument")
    # all these should raise an exception
    try:
        FieldAttribute(isa = 'dict', default = dict())
        assert False, "FieldAttribute constructor allowed a mutable default value"
    except TypeError:
        pass

# Generated at 2022-06-23 05:52:12.270912
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b
    assert a >= b
    assert not a != b

    c = Attribute(priority=2)
    assert c > b
    assert not c < b
    assert not a == c



# Generated at 2022-06-23 05:52:17.147963
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    o1 = Attribute()
    o2 = Attribute()
    o3 = Attribute()

    o1.priority = 0
    o2.priority = 1
    o3.priority = 1

    assert(o2 >= o1)
    assert(o2 >= o3)
    assert(o3 >= o2)
    assert(o1 <= o2)
    assert(o3 <= o2)


# Generated at 2022-06-23 05:52:26.172261
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Test when self.priority == other.priority
    self_priority = 1
    other_priority = 1
    self = Attribute(priority = self_priority)
    other = Attribute(priority = other_priority)
    assert not self.__ne__(other)

    # Test when self.priority != other.priority
    self_priority = 1
    other_priority = 2
    self = Attribute(priority = self_priority)
    other = Attribute(priority = other_priority)
    assert self.__ne__(other)
