

# Generated at 2022-06-23 05:42:32.546608
# Unit test for constructor of class Attribute
def test_Attribute():

    fn = Attribute(isa='str', default='abc', private=True, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias='hello')
    assert fn.isa == 'str'
    assert fn.private == True
    assert fn.default == 'abc'
    assert fn.required == True
    assert fn.priority == 0
    assert fn.inherit == True
    assert fn.alias == 'hello'

    fn = Attribute(isa='str', default='abc', private=True, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias='hello')
    assert fn.isa == 'str'
    assert fn.private == True

# Generated at 2022-06-23 05:42:38.152964
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=5)
    attr3 = Attribute(priority=5)

    assert attr1 <= attr2
    assert attr1 < attr2
    assert attr2 >= attr1
    assert attr2 > attr1

    assert attr2 >= attr3
    assert attr2 <= attr3
    assert attr2 == attr3

# Generated at 2022-06-23 05:42:49.363389
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(isa="c", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    a2 = Attribute(isa="c", private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    if (a1.__ne__(a2) == a2.__ne__(a1)) and (a1.__ne__(a2) == True):
        print("a1.__ne__(a2) and a2.__ne__(a1) return True")
   

# Generated at 2022-06-23 05:42:57.583310
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(isa='string', default='Success')
    assert field.isa == 'string', 'FieldAttribute constuctor failed!'
    assert field.default == 'Success', 'FieldAttribute constuctor failed!'
    assert field.private == False, 'FieldAttribute constuctor failed!'
    assert field.required == False, 'FieldAttribute constuctor failed!'
    assert field.listof == None, 'FieldAttribute constuctor failed!'
    assert field.priority == 0, 'FieldAttribute constuctor failed!'
    assert field.class_type == None, 'FieldAttribute constuctor failed!'
    assert field.inherit == True, 'FieldAttribute constuctor failed!'
    assert field.alias == None, 'FieldAttribute constuctor failed!'



# Generated at 2022-06-23 05:43:01.706982
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Setup
    foo=Attribute()
    res=foo.__ne__(Attribute())
    # Verification
    assert res == False
    # Cleanup - none necessary



# Generated at 2022-06-23 05:43:03.369209
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert (attr1.__ne__(attr2) == True)
    assert (attr2.__ne__(attr1) == True)


# Generated at 2022-06-23 05:43:05.381722
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(isa='str', required=True) == Attribute(isa='str', required=True)


# Generated at 2022-06-23 05:43:07.645508
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert FieldAttribute() <= FieldAttribute()
    assert not (FieldAttribute() <= FieldAttribute(priority=1))



# Generated at 2022-06-23 05:43:17.645740
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute()
    assert obj.isa == None
    assert obj.private == False
    assert obj.default == None
    assert obj.required == False
    assert obj.listof == None
    assert obj.priority == 0
    assert obj.class_type == None
    assert obj.always_post_validate == False
    assert obj.inherit == True
    assert obj.alias == None
    assert obj.extend == False
    assert obj.prepend == False
    assert obj.static == False

    # test_Attribute_object_with_args
    obj = Attribute(isa='test')
    assert obj.isa == 'test'
    assert obj.private == False
    assert obj.default == None
    assert obj.required == False
    assert obj.listof == None
    assert obj.priority == 0

# Generated at 2022-06-23 05:43:27.685269
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr_def_1 = Attribute(isa='int', private=True,
                           default=None, required=True,
                           listof=None, priority=0,
                           class_type=None, always_post_validate=False,
                           inherit=True, alias=None,
                           extend=False, prepend=False, static=False)
    attr_def_2 = Attribute(isa='int', private=True,
                           default=None, required=True,
                           listof=None, priority=0,
                           class_type=None,
                           always_post_validate=False, inherit=False,
                           alias=None, extend=False, prepend=False, static=False)
    assert attr_def_1 == attr_def_2


# Generated at 2022-06-23 05:43:33.316057
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test = FieldAttribute()
    for kwarg in ['isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type', 'always_post_validate', 'inherit', 'alias']:
        assert kwarg in dir(test)


# Generated at 2022-06-23 05:43:43.211161
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    i = FieldAttribute()
    assert(i.isa                           == None)
    assert(i.private                       == False)
    assert(i.default                       == None)
    assert(i.required                      == False)
    assert(i.listof                        == None)
    assert(i.priority                      == 0)
    assert(i.class_type                    == None)
    assert(i.always_post_validate          == False)
    assert(i.inherit                       == True)
    assert(i.alias                         == None)
    assert(i.extend                        == False)
    assert(i.prepend                       == False)
    assert(i.static                        == False)


# Generated at 2022-06-23 05:43:46.615843
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 != attr2


# Generated at 2022-06-23 05:43:48.291807
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=10) == Attribute(priority=10)


# Generated at 2022-06-23 05:43:55.570115
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa='int', private=False, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    attr2 = Attribute(isa='int', private=False, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr1 == attr2


# Generated at 2022-06-23 05:44:01.762260
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Attribute.__lt__()
    """
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1.__lt__(attr2)
    assert not attr2.__lt__(attr1)
    assert not attr1.__lt__(attr1)
    assert not attr2.__lt__(attr2)

# Generated at 2022-06-23 05:44:07.684747
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.playbook.attribute import Attribute
    attr = Attribute(priority=0)

    # Test when 'other' argument has a lower priority number
    other = Attribute(priority=-1)
    assert attr.__lt__(other) == True

    # Test when 'other' argument has a higher priority number
    other = Attribute(priority=1)
    assert attr.__lt__(other) == False


# Generated at 2022-06-23 05:44:11.018733
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if not (a1 <= a2):
        raise AssertionError("Attribute.__le__() failed")



# Generated at 2022-06-23 05:44:15.588969
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute() == Attribute()
    assert Attribute(priority=0) == Attribute(priority=0)
    assert Attribute(priority=1) == Attribute(priority=1)
    assert Attribute() != Attribute(priority=0)
    assert Attribute(priority=0) != Attribute(priority=1)
    assert Attribute(priority=0) != Attribute()



# Generated at 2022-06-23 05:44:18.713042
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b


# Generated at 2022-06-23 05:44:21.560723
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    print(a <= b)



# Generated at 2022-06-23 05:44:25.270532
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    inst1 = Attribute(priority=0)
    inst2 = Attribute(priority=1)
    return (Attribute.__ge__(inst1, inst2), Attribute.__ge__(inst2, inst1))


# Generated at 2022-06-23 05:44:30.290999
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=0) > Attribute(priority=1)
    assert Attribute(priority=1) > Attribute(priority=0)
    assert not Attribute(priority=0) > Attribute(priority=0)


# Generated at 2022-06-23 05:44:33.691749
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 != attr2
    attr2.priority = 1
    assert attr1 == attr2


# Generated at 2022-06-23 05:44:38.624539
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=2)
    assert a1 != a2
    assert a2 == a3
    assert a2 >= a3
    assert a3 <= a2
    assert a3 >= a1


# Generated at 2022-06-23 05:44:42.735522
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    # a.__ne__(b)
    c = (a != b)
    d = (b != a)
    return c and d


# Generated at 2022-06-23 05:44:43.645721
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert FieldAttribute() != FieldAttribute()

# Generated at 2022-06-23 05:44:47.699560
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    assert a <= b

    b = Attribute()
    b.priority = 1
    assert not a <= b

    b = Attribute()
    b.priority = -1
    assert a <= b


# Generated at 2022-06-23 05:44:50.608071
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    x=Attribute(priority=1)
    y=Attribute(priority=1)
    z=Attribute(priority=2)
    assert x==y
    assert x!=z


# Generated at 2022-06-23 05:44:54.177086
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    if not attr1 > attr2:
        raise AssertionError

# Generated at 2022-06-23 05:45:00.529338
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    print("Running Test :: Unit test for method __lt__ of class Attribute")
    # Test Case #1
    name1 = ''
    isa1 = ''
    private1 = False
    default1 = ''
    required1 = False
    listof1 = ''
    priority1 = 0

    name2 = ''
    isa2 = ''
    private2 = False
    default2 = ''
    required2 = False
    listof2 = ''
    priority2 = 1

    val1 = FieldAttribute(isa=isa1, private=private1, default=default1, required=required1, listof=listof1, priority=priority1)
    val2 = FieldAttribute(isa=isa2, private=private2, default=default2, required=required2, listof=listof2, priority=priority2)
    res = val1

# Generated at 2022-06-23 05:45:03.564220
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2 <= attr1


# Generated at 2022-06-23 05:45:10.325914
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    assert field_attribute.static is False



# Generated at 2022-06-23 05:45:13.528602
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 >= a2


# Generated at 2022-06-23 05:45:20.140629
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='str',default='a',private=True)
    b = Attribute(isa='str',default='a',private=True)
    assert a == b
    assert not (a != b)
    assert not (a < b)
    assert not (a > b)
    assert a <= b
    assert b <= a
    assert a >= b
    assert b >= a


# Generated at 2022-06-23 05:45:28.994955
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    FA1 = Attribute(priority=2)
    FA2 = Attribute(priority=1)
    FA3 = Attribute(priority=3)
    FA4 = Attribute(priority=2.5)
    FA5 = Attribute(priority=2)
    FA6 = Attribute(priority=3)

    # FA1 <= FA2
    assert FA1 <= FA2, 'FA1 <= FA2'

    # FA1 <= FA3
    assert FA1 <= FA3, 'FA1 <= FA3'
    
    # FA1 <= FA4
    assert FA1 <= FA4, 'FA1 <= FA4'
    
    # FA1 <= FA5
    assert FA1 <= FA5, 'FA1 <= FA5'
    
    # FA3 <= FA6
    assert FA3 <= FA6, 'FA3 <= FA6'

# Generated at 2022-06-23 05:45:29.725216
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # method __lt__ of class Attribute tested by test_priority
    pass



# Generated at 2022-06-23 05:45:31.871229
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    assert a.__le__(b) is True


# Generated at 2022-06-23 05:45:34.396229
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute(isa='dict', default=dict())

# Generated at 2022-06-23 05:45:40.122365
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert not a1 == a2

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert not a1 == a2

    a1 = Attribute(priority=2)
    a2 = Attribute(priority=2)
    assert a1 == a2


# Generated at 2022-06-23 05:45:43.983563
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    left = Attribute(priority=5)
    right = Attribute(priority=10)
    assert left.__gt__(right)
    assert not left.__gt__(left)
    assert not right.__gt__(right)
    assert not right.__gt__(left)



# Generated at 2022-06-23 05:45:48.919258
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=1)
    attribute3 = Attribute(priority=3)
    assert attribute1 == attribute2
    assert attribute1 != attribute3


# Generated at 2022-06-23 05:45:53.036457
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(isa="list", default=['a'])
        assert False, "Constructor of FieldAttribute failed"
    except TypeError:
        assert True


# class AnsibleBase(metaclass=AnsibleBaseMetaclass):

# Generated at 2022-06-23 05:45:57.932266
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute()
    a1.priority = 2

    a2 = Attribute()
    a2.priority = 2

    a3 = Attribute()
    a3.priority = 4

    assert(a1 <= a2)
    assert(a1 <= a3)
    assert(a2 <= a3)

# Generated at 2022-06-23 05:46:01.288015
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 != attr2


# Generated at 2022-06-23 05:46:02.351314
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=2) != Attribute(priority=1)


# Generated at 2022-06-23 05:46:06.902982
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a1 <= a2
    assert not a2 <= a1
    assert a2 <= a2
    assert a1 <= a1


# Generated at 2022-06-23 05:46:17.444837
# Unit test for constructor of class Attribute
def test_Attribute():
   a = Attribute()

   assert a.isa is None
   assert a.private is False
   assert a.default is None
   assert a.required is False
   assert a.listof is None
   assert a.priority is 0
   assert a.class_type is None

   b = Attribute(isa='int', private=True, default=0, required=True, listof='set',
                 priority=1, class_type=int, always_post_validate=False, inherit=True,
                 alias=None)

   assert b.isa is 'int'
   assert b.private is True
   assert b.default == 0
   assert b.required is True
   assert b.listof is 'set'
   assert b.priority is 1
   assert b.class_type is int

# Generated at 2022-06-23 05:46:24.891854
# Unit test for constructor of class Attribute
def test_Attribute():
    # test isa
    attr = Attribute(isa='list')
    assert attr.isa == 'list'

    # test private
    attr = Attribute(private=True)
    assert attr.private == True

    # test default
    attr = Attribute(default='wow')
    assert attr.default == 'wow'

    # test required
    attr = Attribute(required=True)
    assert attr.required == True

    # test listof
    attr = Attribute(listof='dict')
    assert attr.listof == 'dict'

    # test priority
    attr = Attribute(priority=1)
    assert attr.priority == 1

    # test class_type
    attr = Attribute(class_type='foo')
    assert attr.class_type == 'foo'

# Generated at 2022-06-23 05:46:30.954010
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    Attribute1 = Attribute(priority=1)
    Attribute2 = Attribute(priority=2)

# Generated at 2022-06-23 05:46:34.100082
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()

    a.priority = 1
    b.priority = 1
    assert a == b
    b.priority = 2
    assert a != b


# Generated at 2022-06-23 05:46:39.529918
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert FieldAttribute().__gt__(FieldAttribute(priority=0)) is True, 'Basic test __gt__ failed!'
    assert FieldAttribute().__gt__(FieldAttribute(priority=1)) is False, 'Basic test __gt__ failed!'
    assert FieldAttribute(priority=1).__gt__(FieldAttribute(priority=0)) is False, 'Basic test __gt__ failed!'

# Generated at 2022-06-23 05:46:40.913328
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert isinstance(Attribute.__le__(Attribute, Attribute), bool)

# Generated at 2022-06-23 05:46:46.634048
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 >= attr1, "Attribute of priority 2 should be ge than attribute of priority 1"


# Generated at 2022-06-23 05:46:51.464201
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a1 >= a0, "Attribute class __ge__ method failed"


# Generated at 2022-06-23 05:46:56.066747
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='dict', default=dict, required=False)
    # attributes must not be mutable
    try:
        attribute = Attribute(isa='dict', default=dict(), required=False)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 05:46:58.829230
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=20)
    attr2 = Attribute(priority=10)
    assert attr2 <= attr1



# Generated at 2022-06-23 05:47:01.799251
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    class Test:
        pass
    test1 = Test()
    test2 = Test()
    test1.priority = 1
    test2.priority = 2
    print('test1 < test2 => ',test1 < test2)


# Generated at 2022-06-23 05:47:04.355345
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    a.priority = 2
    b.priority = 3
    assert b < a
    assert a > b
    assert not a < b
    assert not b > a

# Generated at 2022-06-23 05:47:07.652213
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 <= attr2
    assert not attr2 <= attr1
    assert attr1 <= attr1



# Generated at 2022-06-23 05:47:10.060193
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    test=Attribute(priority=0)
    print(test==Attribute(priority=0))
test_Attribute___eq__()


# Generated at 2022-06-23 05:47:13.726039
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    _attribute1 = Attribute(priority=1)
    _attribute2 = Attribute(priority=2)
    assert(_attribute1 >= _attribute2)


# Generated at 2022-06-23 05:47:14.997152
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute



# Generated at 2022-06-23 05:47:19.194275
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    '''
    Test for method __ge__ of class Attribute
    '''
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert(a >= b)



# Generated at 2022-06-23 05:47:25.364489
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test the case where other.priority <= self.priority
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    c = Attribute(priority=10)
    assert (b <= a) == True
    assert (c <= a) == True
    # Test the case where other.priority > self.priority
    d = Attribute(priority=8)
    assert (d <= a) == False



# Generated at 2022-06-23 05:47:29.288778
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=1)
    assert attr_1 != attr_2
    attr_2 = Attribute(priority=2)
    assert attr_1 != attr_2


# Generated at 2022-06-23 05:47:33.488604
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__le__(b) == True
    assert a.__ge__(b) == False
    assert a.__lt__(b) == True
    assert a.__gt__(b) == False


# Generated at 2022-06-23 05:47:42.573757
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a_1 = Attribute(priority=1)
    a_2 = Attribute(priority=2)
    a_3 = Attribute(priority=3)

    assert (a_1 != a_2) == True, ('Attribute 1 was not "!=" attribute 2')
    assert (a_1 != a_3) == True, ('Attribute 1 was not "!=" attribute 3')
    assert (a_2 != a_3) == True, ('Attribute 2 was not "!=" attribute 3')

    assert (a_1 != a_1) == False, ('Attribute 1 was "!=" attribute 1')
    assert (a_2 != a_2) == False, ('Attribute 2 was "!=" attribute 2')
    assert (a_3 != a_3) == False, ('Attribute 3 was "!=" attribute 3')


# Generated at 2022-06-23 05:47:49.001216
# Unit test for constructor of class Attribute
def test_Attribute():
    # test basic usage
    f = Attribute()

    # test default values
    f = Attribute(isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False)


# Generated at 2022-06-23 05:47:51.323611
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute('string', False, 'test', False, None, 0)
    assert attr.isa == 'string'


# Generated at 2022-06-23 05:47:56.440747
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # 1, 0 > 0
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a > b

    # 1, 1 >= 1
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a >= b


# Generated at 2022-06-23 05:48:00.342744
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', class_type='thing')
    assert f.isa == 'list'
    assert f.class_type == 'thing'



# Generated at 2022-06-23 05:48:02.734870
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert(a < b)



# Generated at 2022-06-23 05:48:07.556419
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr1.priority = 0
    attr2 = Attribute()
    attr2.priority = 1
    assert (attr1 < attr2)


# Generated at 2022-06-23 05:48:14.427601
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    import attrdict

    class TestClass(attrdict.AttrDict):
        def __init__(self):
            attrs = {'some_bool': FieldAttribute(isa='bool')}
            super(TestClass, self).__init__(attrs)

    test1 = TestClass()
    test1.some_bool = True

    test2 = TestClass()
    test2.some_bool = False

    if test1 == test2:
        raise AssertionError('Test1 and test2 are not equal')



# Generated at 2022-06-23 05:48:18.465138
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if a1.__ge__(a2):
        raise Exception("Fail")
    if a2.__ge__(a1):
        print("Success")


# Generated at 2022-06-23 05:48:22.460523
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a<=b
    assert not b<=a



# Generated at 2022-06-23 05:48:33.223709
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(isa='str', priority=0, default=None, required=False,
                   listof=None, class_type=None, always_post_validate=False,
                   inherit=True, alias=None)
    a2 = Attribute(isa='str', priority=1, default=None, required=False,
                   listof=None, class_type=None, always_post_validate=False,
                   inherit=True, alias=None)

    assert a1.__le__(a2) is True
    assert a2.__le__(a1) is False
    assert a1.__ge__(a2) is False
    assert a2.__ge__(a1) is True
    assert a1.__lt__(a2) is True
    assert a2.__lt__(a1)

# Generated at 2022-06-23 05:48:37.219676
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute(priority=30)
    attribute2 = Attribute(priority=40)

    assert attribute1.__le__(attribute2) == False
    assert attribute2.__le__(attribute1) == True
    assert attribute1.__ge__(attribute2) == True
    assert attribute2.__ge__(attribute1) == False



# Generated at 2022-06-23 05:48:39.287417
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    print(a <= b)
    print(a >= b)


# Generated at 2022-06-23 05:48:42.112351
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute(priority=1)
    assert attribute == Attribute(priority=1)
    assert not attribute == Attribute(priority=2)


# Generated at 2022-06-23 05:48:46.606740
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    A = Attribute(priority=0)
    B = Attribute(priority=1)
    C = Attribute(priority=0)
    assert A == C
    assert A != B


# Generated at 2022-06-23 05:48:57.365327
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    fail_count = 0

    # Test 1
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    if attr1 < attr2:
        fail_count += 1

    # Test 2
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    if attr1 < attr2:
        fail_count += 1

    # Test 3
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    if attr1 < attr2:
        fail_count += 1

    # Test 4
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=2)
    if attr1 < attr2:
        fail_

# Generated at 2022-06-23 05:49:06.031216
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute = Attribute()
    other = Attribute()
    # default value of three attributes with __le__
    # method is 0
    assert attribute.priority == 0
    assert other.priority == 0
    assert attribute >= other
    assert other <= attribute

    # when other.priority > attribute.priority
    # then attribute >= other
    other.priority = 1
    assert attribute >= other

    # when other.priority < attribute.priority
    # then attribute <= other
    other.priority = -1
    assert attribute <= other



# Generated at 2022-06-23 05:49:10.415039
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=0)
    assert attr_1 == attr_2


# Generated at 2022-06-23 05:49:14.930815
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    test_Attribute___lt__ - Unit test for method __lt__ of class Attribute
    """
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 2
    assert a1 < a2



# Generated at 2022-06-23 05:49:18.313280
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 == attr2


# Generated at 2022-06-23 05:49:22.179376
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print("Attribute___ne__")
    attrib = Attribute()
    attrib._Attribute__ne__(attrib)


# Generated at 2022-06-23 05:49:26.670907
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute()
    attribute2 = Attribute()
    assert attribute1 is not attribute2
    assert attribute1 == attribute2
    attribute1.priority = 1
    assert attribute1 != attribute2
    attribute2.priority = 1
    assert attribute1 == attribute2


# Generated at 2022-06-23 05:49:29.489383
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    orig = Attribute()
    new = Attribute(priority=2)
    assert orig != new


# Generated at 2022-06-23 05:49:31.401616
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute=Attribute()
    attribute2=Attribute()
    attribute2.priority=10
    assert attribute<attribute2


# Generated at 2022-06-23 05:49:40.792292
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()

    assert attr.isa == None
    assert attr.private is False
    assert attr.default == None
    assert attr.required is False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias == None
    assert attr.extend is False
    assert attr.prepend is False


# Generated at 2022-06-23 05:49:45.627270
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    c = Attribute(priority=1)
    assert a.__eq__(b) is False
    assert a.__eq__(c) is True


# Generated at 2022-06-23 05:49:53.764296
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=3)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=1)
    a4 = Attribute(priority=1)
    a5 = Attribute(priority=0)
    assert a1 > a2
    assert a2 > a3
    assert a3 >= a4
    assert a4 <= a3
    assert a4 >= a4
    assert a5 < a4

# Generated at 2022-06-23 05:49:56.157761
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    one = Attribute(priority=1)
    two = Attribute(priority=2)
    assert one != two


# Generated at 2022-06-23 05:50:07.792418
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    attribute_2 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-23 05:50:11.322549
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)

    if not a1.__ne__(a2):
        raise AssertionError()


# Generated at 2022-06-23 05:50:18.256375
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Arrange
    expected = True
    a1 = Attribute()
    a2 = Attribute()
    # Act
    result = a1.__eq__(a2)
    # Assert
    assert result == expected


# Generated at 2022-06-23 05:50:27.633542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(
        isa='str',
        private=False,
        default='xyz',
        required=True,
        listof='str',
        priority=0,
        class_type='Test',
        always_post_validate=False,
        inherit=True,
        alias='MyAlias',
    )

    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'xyz'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'Test'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'MyAlias'

# Generated at 2022-06-23 05:50:30.150202
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    assert(attr==attr)


# Generated at 2022-06-23 05:50:32.408647
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert (a < b) == True



# Generated at 2022-06-23 05:50:42.017061
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    def verify_Attribute___lt__(a, b, expected):
        attr_a = Attribute(priority=a)
        attr_b = Attribute(priority=b)
        ans = attr_a < attr_b
        assert ans == expected, 'a: %s, b: %s, expected: %s, but got: %s' \
                                % (a, b, expected, ans)
    verify_Attribute___lt__(0, 1, True)
    verify_Attribute___lt__(100, -100, False)
    verify_Attribute___lt__(10, -10, False)
    verify_Attribute___lt__(-100, 100, True)
    verify_Attribute___lt__(-10, 10, True)


# Generated at 2022-06-23 05:50:46.096575
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)

    assert a1 < a2

# Generated at 2022-06-23 05:50:46.986739
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()



# Generated at 2022-06-23 05:50:50.075002
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)

    assert attribute1.__le__(attribute2) == False
    assert attribute2.__le__(attribute1) == True


# Generated at 2022-06-23 05:50:51.779487
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=1) != Attribute(priority=0)


# Generated at 2022-06-23 05:50:56.970076
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute()
    y = Attribute()
    assert x.__le__(y)


# Generated at 2022-06-23 05:51:00.999338
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=False, required=False, listof=False,
                  priority=0, class_type=None, always_post_validate=False)


# Generated at 2022-06-23 05:51:04.576750
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    fieldattribute1 = FieldAttribute()
    fieldattribute1.priority = 10
    fieldattribute2 = FieldAttribute()
    fieldattribute2.priority = 15
    assert fieldattribute1.__lt__(fieldattribute2)
    assert not fieldattribute2.__lt__(fieldattribute1)


# Generated at 2022-06-23 05:51:08.226222
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    "Test method __eq__ of class Attribute"
    attr_a = Attribute(priority = 0)
    attr_b = Attribute(priority = 0)
    attr_c = Attribute(priority = 1)
    assert attr_a == attr_b
    assert not attr_a == attr_c


# Generated at 2022-06-23 05:51:09.439744
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=0) == Attribute(priority=0)


# Generated at 2022-06-23 05:51:15.200920
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(isa='dict', default=dict(), required=True, private=False, listof=False, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    attr2 = Attribute(isa='dict', default=dict(), required=True, private=False, listof=False, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attr1 != attr2


# Generated at 2022-06-23 05:51:18.232672
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=100)
    a2 = Attribute(priority=200)
    assert a1 != a2


# Generated at 2022-06-23 05:51:21.475618
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 1
    if a1 == a2:
        return True


# Generated at 2022-06-23 05:51:32.568486
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    t1 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False)
    t2 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False)

# Generated at 2022-06-23 05:51:35.709789
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_a = Attribute()
    attribute_a.priority = 10
    attribute_b = Attribute()
    attribute_b.priority = 15
    print (attribute_b <= attribute_a)


# Generated at 2022-06-23 05:51:38.753332
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 1
    attr2 = Attribute()
    attr2.priority = 1
    assert not attr.__ne__(attr2)

# Generated at 2022-06-23 05:51:44.972605
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test case 1
    attr1 = Attribute(priority=100)
    attr2 = Attribute(priority=10)
    # Test attr1 should be greater than attr2
    assert attr1 > attr2
    # Test case 2
    attr3 = Attribute(priority=100)
    attr4 = Attribute(priority=10)
    # Test attr4 should not be greater than attr3
    assert not attr4 > attr3



# Generated at 2022-06-23 05:51:48.822730
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=2)
    assert a < b
    assert a <= b
    assert b <= c
    assert not a >= b
    assert not a > b
    assert not (a < c)


# Generated at 2022-06-23 05:51:51.470065
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if not (a1 < a2):
        raise AssertionError("Attribute __gt__ failed")



# Generated at 2022-06-23 05:51:55.087031
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=2)
    b = Attribute(priority=2)
    assert a.__ne__(b) == False


# Generated at 2022-06-23 05:52:00.691887
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """ 
    Test method that the attribute is correctly greater than or not other attribute

    """
    attr1 = Attribute(isa='basestring', default='toto', priority=3)
    attr2 = Attribute(isa='basestring', default='toto', priority=4)

    assert attr1 < attr2

    attr3 = Attribute(isa='basestring', default='toto', priority=4)

    assert attr2 >= attr3


# Unit tests for the class Attribute

# Generated at 2022-06-23 05:52:05.562369
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_1 = FieldAttribute(priority=0)
    attr_2 = FieldAttribute(priority=0)
    if attr_1 <= attr_2:
        print('test_Attribute___le__()    SUCCESS')
    else:
        print('test_Attribute___le__()    FAILED')



# Generated at 2022-06-23 05:52:10.825168
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(isa=int, default=1, priority=10)
    attr2 = Attribute(isa=int, default=1, priority=9)
    attr3 = Attribute(isa=int, default=1, priority=10)
    assert attr1 >= attr2
    assert attr1 >= attr3


# Generated at 2022-06-23 05:52:17.720734
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    assert a != b
    assert a != c

    # __ne__ of other type should raise TypeError
    assert isinstance(a, Attribute)
    assert not isinstance(b, Attribute)
    with pytest.raises(TypeError):
        a.__ne__(b)
    with pytest.raises(TypeError):
        b.__ne__(a)


# Generated at 2022-06-23 05:52:20.894323
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2


# Generated at 2022-06-23 05:52:30.131509
# Unit test for constructor of class Attribute
def test_Attribute():
    arg = Attribute()

    assert arg.isa is None
    assert arg.private is False
    assert arg.default is None
    assert arg.required is False
    assert arg.listof is None
    assert arg.priority == 0
    assert arg.class_type is None
    assert arg.always_post_validate is False
    assert arg.inherit is True
    assert arg.alias is None
    assert arg.extend is False
    assert arg.prepend is False
    assert arg.static is False

    #try to initialize with a mutable default value
    try:
        arg = Attribute(default=[])

    except TypeError:
        pass
    else:
        print("mutable default value improperly accepted")