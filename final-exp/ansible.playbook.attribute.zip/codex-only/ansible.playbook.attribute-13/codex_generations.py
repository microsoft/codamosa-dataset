

# Generated at 2022-06-23 05:42:27.358515
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    This is a test
    """
    list_of_number_expected = {'isa': 'list', 'private':False, 'default': None, 'required': False, 'listof': 'number', \
                            'priority': 0, 'class_type': None, 'always_post_validate': False, 'inherit': True, 'alias': None, \
                            'extend': False, 'prepend': False, 'static': False}
    attr = Attribute('list', default=None, listof='number')
    assert attr.isa == list_of_number_expected['isa']
    assert attr.private == list_of_number_expected['private']
    assert attr.default == list_of_number_expected['default']

# Generated at 2022-06-23 05:42:34.122606
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a=Attribute(priority=1)
    b=Attribute(priority=2)
    true_case_1=(a<=b)
    true_case_2=(a<=a)
    false_case_1=(a>=b)
    false_case_2=(b>=a)
    if true_case_1 and true_case_2 and not false_case_1 and not false_case_2:
        print('test_Attribute___le__ passed')
    else:
        print('test_Attribute___le__ failed')


# Generated at 2022-06-23 05:42:37.814262
# Unit test for constructor of class Attribute
def test_Attribute():
    # test if the constructor is working correctly
    # None is the default value of required
    test_case = Attribute(isa='dict', default='hi', required=True)
    assert(test_case.isa == 'dict' and test_case.default == 'hi' and test_case.required == True)

# Generated at 2022-06-23 05:42:49.092346
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute(isa='int')

    assert a1.isa == 'int'
    assert a1.private is False
    assert a1.default is None
    assert a1.required is False
    assert a1.listof is None
    assert a1.priority == 0
    assert a1.class_type is None
    assert a1.always_post_validate is False
    assert a1.inherit is True
    assert a1.alias is None

    a2 = Attribute(isa='int', static=True)

    assert a2.isa == 'int'
    assert a2.private is False
    assert a2.default is None
    assert a2.required is False
    assert a2.listof is None
    assert a2.priority == 0
    assert a2.class_type is None
   

# Generated at 2022-06-23 05:42:51.498731
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute(priority=0), 'Attribute:__ge__ method failed.'


# Generated at 2022-06-23 05:42:54.885637
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(default=1)
    a2 = Attribute(default=2)
    a3 = Attribute(default=3)
    assert a1 < a2 < a3
    assert a3 > a2 > a1


# Generated at 2022-06-23 05:43:02.612900
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    att1 = Attribute(isa='int', default=8, private=True, required=False)
    att2 = Attribute(isa='int', default=8, private=True, required=False)
    assert att1.__eq__(att2) == True



# Generated at 2022-06-23 05:43:09.440691
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=4)
    a2 = Attribute(priority=5)
    assert a1.__le__(a2)
    a1 = Attribute(priority=4)
    a2 = Attribute(priority=3)
    assert not a1.__le__(a2)
    a1 = Attribute(priority=4)
    assert a1.__le__(a1)


# Generated at 2022-06-23 05:43:14.543108
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    attr_copy = attr
    attr_copy.priority = 1
    assert attr != attr_copy
    attr_copy.priority = 0
    assert attr == attr_copy



# Generated at 2022-06-23 05:43:18.092127
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    print("Test __eq__:")
    a = Attribute()
    b = Attribute()
    if a == b:
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-23 05:43:20.825936
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(isa='dict', priority=0)
    attr2 = Attribute(isa='list', priority=0)
    assert(attr2.__ne__(attr))

# Generated at 2022-06-23 05:43:26.718624
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    att = Attribute()
    att.priority = 100
    att2 = Attribute()
    att2.priority = 100
    assert att.__le__(att2)
    assert att2.__le__(att)
    att3 = Attribute()
    att3.priority = 200
    assert att3.__le__(att2)
    assert not att2.__le__(att3)


# Generated at 2022-06-23 05:43:32.726745
# Unit test for constructor of class Attribute
def test_Attribute():
    Actor = type('Actor', (FieldAttribute,), {})
    a = Actor()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

# Unit test to raise exception

# Generated at 2022-06-23 05:43:37.116349
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    obj1 = Attribute(required=True)
    obj2 = Attribute()
    obj3 = Attribute(priority=111)
    obj4 = Attribute(required=True, priority=1000)
    assert obj1 == obj1
    assert obj1 != obj2
    assert obj1 != obj3
    assert obj4 != obj3



# Generated at 2022-06-23 05:43:46.351889
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        alias='attr_alias',
        default='some_default',
        extend=True,
        isa='some_isa',
        listof='some_list_of_type',
        prepend=True,
        private=True,
        required=True,
        static=True,
    )
    assert attr.isa == 'some_isa'
    assert attr.private == True
    assert attr.default == 'some_default'
    assert attr.required == True
    assert attr.listof == 'some_list_of_type'
    assert attr.priority == 0
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'attr_alias'
    assert attr.extend == True


# Generated at 2022-06-23 05:43:55.921313
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj1 = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    obj2 = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
   

# Generated at 2022-06-23 05:43:58.865861
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = Attribute(isa='dict')

    assert isinstance(attribute, Attribute)



# Generated at 2022-06-23 05:44:07.500469
# Unit test for constructor of class Attribute
def test_Attribute():
    test_obj = Attribute(
        isa='dict',
        required=True,
        listof='dict',
        class_type={},
        default={},
        extend=True,
    )
    assert test_obj.isa == 'dict', 'Attribute.isa set correctly?'
    assert test_obj.required == True, 'Attribute.required set correctly?'
    assert test_obj.listof == 'dict', 'Attribute.listof set correctly?'
    assert test_obj.class_type == 'dict', 'Attribute.class_type set correctly?'
    assert test_obj.default == {}, 'Attribute.default set correctly?'
    assert test_obj.extend == True, 'Attribute.extend set correctly?'



# Generated at 2022-06-23 05:44:12.298138
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=20)
    assert attr2.__ge__(attr1) == True
    assert attr1.__ge__(attr2) == False
    assert attr1.__ge__(attr1) == True


# Generated at 2022-06-23 05:44:15.696005
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert(a > b) == False
    assert(b > a) == True
    assert(a > c) == False

# Generated at 2022-06-23 05:44:22.680811
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Setup
    A = Attribute()
    B = Attribute()
    C = Attribute()
    # Exercise
    A.priority = 1
    B.priority = 2
    C.priority = 3
    # Verify
    assert A > B
    assert A > C
    assert B < C
    assert B > A
    assert C > A
    assert C > B



# Generated at 2022-06-23 05:44:25.567816
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    assert(a!=None)



# Generated at 2022-06-23 05:44:31.566768
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    # Create a new Attribute object
    attr = Attribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # Call Attribute method
    result = attr.__ne__(attr)
    assert result



# Generated at 2022-06-23 05:44:33.259759
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = FieldAttribute()
    attr1.priority = 1
    attr2 = FieldAttribute()
    attr2.priority = 2
    result = attr2 > attr1
    assert result == True


# Generated at 2022-06-23 05:44:36.223781
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """ Unit test for method __gt__ of class Attribute """
    priority = 10
    attribute = Attribute(priority=priority)
    assert attribute.__gt__(priority) == False
    

# Generated at 2022-06-23 05:44:47.881427
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # When constructor of class FieldAttribute is called with keyword argument default is None,
    # then it should not raise a TypeError.
    FieldAttribute(default=None)

    # When constructor of class FieldAttribute is called with keyword argument default
    # is not None and isa is a list, then it should raise a TypeError.
    from ansible.playbook.base import FieldAttribute
    from ansible.utils import compat
    import sys
    if compat.PY3:
        my_type_error = TypeError
    else:
        my_type_error = AttributeError
    if sys.version_info >= (2, 7):
        expected_msg = "'FieldAttribute' object has no attribute '_FieldAttribute__got_default'"
    else:
        expected_msg = "'FieldAttribute' object has no attribute '__got_default'"
    pytest

# Generated at 2022-06-23 05:44:49.916397
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1 > attribute2



# Generated at 2022-06-23 05:44:52.458123
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    # Create 2 objects of class Attribute with different priority
    x = Attribute(priority=2)
    y = Attribute(priority=3)

    # Check if __eq__ method works as expected
    assert not x.__eq__(y), "Failed"


# Generated at 2022-06-23 05:44:56.223343
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    assert a <= a
    assert a >= a


# Generated at 2022-06-23 05:45:11.326154
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    ''' Unit test for constructor of class FieldAttribute '''

    # Test invalid value for isa
    try:
        attr = FieldAttribute(isa='invalid')
    except TypeError as e:
        assert 'isa must be one of:' in str(e)

    # Test invalid value for listof
    try:
        attr = FieldAttribute(isa='list', listof='invalid')
    except TypeError as e:
        assert 'listof must be one of:' in str(e)

    # Test valid values for isa and listof
    attr = FieldAttribute(isa='list', listof='int')
    assert attr.isa == 'list'
    assert attr.listof == 'int'
    attr.isa = 'int'
    assert attr.isa == 'int'

# Generated at 2022-06-23 05:45:14.882575
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(b < a)
    assert(not (a < b))


# Generated at 2022-06-23 05:45:25.022024
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    
    attribute = Attribute()
    assert(isinstance(attribute,Attribute))
    
    # Testing TypeError
    try:
        attribute.__ge__('string')
        assert False
    except TypeError:
        pass
    
    # TypeError
    try:
        attribute.__ge__(1)
        assert False
    except TypeError:
        pass
    
    # TypeError
    try:
        attribute.__ge__(1.0)
        assert False
    except TypeError:
        pass
    
    # TypeError
    try:
        attribute.__ge__(1+1j)
        assert False
    except TypeError:
        pass
    
    # Testing Boolean values
    # True
    assert attribute.__ge__(attribute)
    
    # Unit test for method __gt__ of class Att

# Generated at 2022-06-23 05:45:28.490839
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        attribute = Attribute(isa='dict', default={})
        raise AssertionError("default should not have been accepted")
    except TypeError:
        pass

# Generated at 2022-06-23 05:45:38.269561
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    attr = Attribute(isa='list', private=True)
    assert attr.isa == 'list'
    assert attr.private


# Generated at 2022-06-23 05:45:40.835507
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=10)
    assert a.__ge__(b) == True


# Generated at 2022-06-23 05:45:52.766827
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    obj_dict = {
        "key_1": AnsibleUnicode("string"),
        "key_2": AnsibleUnicode("string"),
        "key_3": AnsibleUnicode("string"),
        "key_4": AnsibleUnicode("string"),
        "key_5": AnsibleUnicode("string"),
        "key_6": AnsibleUnicode("string"),
    }
    obj_dict_copy = copy(obj_dict)
    obj_dict_

# Generated at 2022-06-23 05:45:55.891157
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2


# Generated at 2022-06-23 05:46:00.293113
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert attr2.priority == attr.priority
    assert attr == attr2
    assert attr2 == attr



# Generated at 2022-06-23 05:46:04.192051
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='A', private=True, required=True)
    assert a.isa == 'A'
    assert a.private == True
    assert a.required == True
    assert a.default is None

# Generated at 2022-06-23 05:46:07.621855
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    assert a >= b


# Generated at 2022-06-23 05:46:16.291135
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_attr = FieldAttribute()
    assert test_attr.isa is None
    assert test_attr.private is False
    assert test_attr.default is None
    assert test_attr.required is False
    assert test_attr.listof is None
    assert test_attr.priority == 0
    assert test_attr.class_type is None
    assert test_attr.always_post_validate is False
    assert test_attr.inherit is True
    assert test_attr.alias is None
    assert test_attr.extend is False
    assert test_attr.prepend is False
    assert test_attr.static is False



# Generated at 2022-06-23 05:46:21.500146
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=50)
    b = Attribute(priority=50)
    c = Attribute(priority=0)
    d = Attribute(priority=100)
    assert a <= b
    assert a <= c
    assert a <= d
    assert not b <= c
    assert not b <= d
    assert c <= a
    assert not d <= c

# Generated at 2022-06-23 05:46:27.756753
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    my_attribute = Attribute(
        isa='test_type',
        private=False,
        default=None,
        required=False,
        listof='',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='',
        extend=False,
        prepend=False,
        static=False,
    )
    assert my_attribute == my_attribute


# Generated at 2022-06-23 05:46:31.017338
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    obj1 = Attribute(priority=3)
    obj2 = Attribute(priority=4)
    result = obj1.__gt__(obj2)
    assert not result


# Generated at 2022-06-23 05:46:40.880016
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.module_utils.six import with_metaclass
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class DummyClass(with_metaclass(AnsibleMapping, object)):
        fields = {
            'priority_zero': FieldAttribute(priority=0),
            'priority_one': FieldAttribute(priority=1),
            'priority_two': FieldAttribute(priority=2)
        }

    d = DummyClass()
    d.priority_zero = 'priority_zero'
    d.priority_one = 'priority_one'
    d.priority_two = 'priority_two'

# Generated at 2022-06-23 05:46:46.633742
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    #
    assert (attr1 != attr2) == True
    assert (attr1 != attr1) == False


# Generated at 2022-06-23 05:46:52.313274
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    assert a.__ge__(a) == True
    assert a.__ge__(b) == False



# Generated at 2022-06-23 05:46:56.449114
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2.priority > a1.priority
    assert a1 < a2
    assert not a2 < a1


# Generated at 2022-06-23 05:47:01.530360
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # __eq__ fields with different values
    attr1 = Attribute()
    attr2 = Attribute(required=True)
    assert not (attr1 == attr2)
    # __eq__ fields with equal values
    attr1 = Attribute(required=True)
    attr2 = Attribute(required=True)
    assert (attr1 == attr2)


# Generated at 2022-06-23 05:47:04.265949
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert (Attribute(priority=0) <= Attribute(priority=1))
    assert not (Attribute(priority=1) <= Attribute(priority=0))

# Generated at 2022-06-23 05:47:06.961115
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # set of objects that don't exist
    for f in field_list:
        for other in field_list:
            if f != other:
                assert field_list[f].__ne__(field_list[other])



# Generated at 2022-06-23 05:47:13.139491
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa=1, private="a", default=1, required=True, listof=1, priority=1, class_type=1, always_post_validate=True, inherit=True, alias=1, extend=True, prepend=True)
    b = Attribute(isa=2, private="b", default=2, required=False, listof=2, priority=2, class_type=2, always_post_validate=False, inherit=False, alias=2, extend=False, prepend=False)
    assert a != b


# Generated at 2022-06-23 05:47:22.967940
# Unit test for constructor of class Attribute
def test_Attribute():

    f = Attribute(
        isa='str',
        private=True,
        default='default',
        required=True,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert f.isa == 'str'
    assert f.private == True
    assert f.default == 'default'
    assert f.required == True
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None

# Generated at 2022-06-23 05:47:26.277841
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute('isa', 3) == Attribute('isa', 3)


# Generated at 2022-06-23 05:47:30.126716
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=2)
    assert not Attribute(priority=2) > Attribute(priority=2)
    assert not Attribute(priority=3) > Attribute(priority=2)


# Generated at 2022-06-23 05:47:36.012556
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    attr3 = Attribute()
    attr3.priority = 3

    assert(attr3 < attr2)
    assert(attr3 > attr1)
    assert(attr2 > attr3)
    assert(attr2 < attr1)
    assert(attr1 < attr2)
    assert(attr1 > attr3)

# Generated at 2022-06-23 05:47:40.318827
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test case 1
    assert (Attribute(priority=1) > Attribute(priority=2)) is False
    # Test case 2
    assert (Attribute(priority=1) > Attribute(priority=1)) is False
    # Test case 3
    assert (Attribute(priority=1) > Attribute(priority=0)) is True



# Generated at 2022-06-23 05:47:48.209553
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=5)
    assert a2 < a1

    a1 = Attribute(priority=10)
    a2 = Attribute(priority=10)
    assert not a1 < a2

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=10)
    assert not a1 < a2

    a1 = Attribute(priority=10)
    a2 = Attribute(priority=10)
    assert not a1 < a2    



# Generated at 2022-06-23 05:47:49.806272
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a is not None


# Generated at 2022-06-23 05:47:55.404187
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    import copy
    a1 = Attribute()
    a2 = copy.copy(a1)
    a1.priority = 100
    a2.priority = 100
    assert(a1 == a2)
    assert(a1 != a2)
    a1.priority = 100
    a2.priority = 101
    assert(a1 < a2)


# Generated at 2022-06-23 05:48:05.284822
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    attr_3 = Attribute(priority=3)
    attr_4 = Attribute(priority=4)

    assert attr_1 != attr_1   # should be False
    assert attr_1 != attr_2
    assert attr_1 != attr_3
    assert attr_1 != attr_4
    assert attr_2 != attr_1
    assert attr_2 != attr_3
    assert attr_2 != attr_4
    assert attr_3 != attr_1
    assert attr_3 != attr_2
    assert attr_3 != attr_4
    assert attr_4 != attr_1
    assert attr_4

# Generated at 2022-06-23 05:48:07.614318
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()

    assert a == b


# Generated at 2022-06-23 05:48:09.558173
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    attr_other = Attribute(priority=1)
    assert (attr_other == attr) == True


# Generated at 2022-06-23 05:48:12.569509
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    FieldAttribute(default='', priority=1) >= FieldAttribute(default='', priority=2)
    FieldAttribute(default='', priority=1) >= FieldAttribute(default='', priority=1)



# Generated at 2022-06-23 05:48:15.929579
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 0)
    result = a.__gt__(b)
    assert result is True


# Generated at 2022-06-23 05:48:20.820431
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert a2 > a1
    assert a1 != a2
    assert a2 != a1
    assert a1 <= a2
    assert a2 <= a2
    assert a1 >= a1
    assert a2 >= a1



# Generated at 2022-06-23 05:48:25.292961
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a_1 = Attribute(priority=1)
    assert a_1.priority == 1

    a_2 = Attribute(priority=2)
    assert a_2.priority == 2

    assert a_2 > a_1

# Generated at 2022-06-23 05:48:29.461825
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert (Attribute(priority=2) > Attribute(priority=1)) == True
    assert (Attribute(priority=1) > Attribute(priority=1)) == False
    assert (Attribute(priority=1) > Attribute(priority=2)) == False


# Generated at 2022-06-23 05:48:34.902399
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()

    assert a >= b
    assert not(a < b)
    assert not(a > b)

    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert not(a >= b)
    assert a < b
    assert not(a > b)



# Generated at 2022-06-23 05:48:38.630248
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute()
    y = Attribute()
    if not (Attribute.__ne__(x,y)):
        print("test_Attribute___ne__() failed")



# Generated at 2022-06-23 05:48:42.515394
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = FieldAttribute(private=False, isa='list')
    b = FieldAttribute(private=False, isa='list', priority=0)
    print(a.__le__(b))
    print(a.__ge__(b))
    b.priority = 1
    print(a.__le__(b))
    print(a.__ge__(b))



# Generated at 2022-06-23 05:48:53.990684
# Unit test for constructor of class Attribute
def test_Attribute():
    # Let's try with default parameters
    attr=Attribute()
    assert attr
    assert not attr.isa
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert not attr.listof
    assert not attr.priority
    assert not attr.class_type
    assert not attr.always_post_validate
    assert attr.inherit
    assert not attr.alias
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static

    attr=Attribute(isa='Lorem ipsum', private=True, default='Default')
    assert attr
    assert attr.isa == 'Lorem ipsum'
    assert attr.private
    assert attr.default == 'Default'
   

# Generated at 2022-06-23 05:48:59.714123
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_0 = Attribute(priority=5)
    attribute_1 = Attribute(priority=1)
    assert attribute_0.__le__(attribute_1)
    attribute_0.priority = 1
    assert attribute_0.__le__(attribute_1)
    attribute_0.priority = 5
    assert attribute_0.__le__(attribute_0)


attribute_type = FieldAttribute


# Generated at 2022-06-23 05:49:03.215117
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # create an instance of Attribute
    a = Attribute(priority=0)
    # create a second instance of Attribute
    b = Attribute(priority=0)

    # verify that the two instances are equal
    assert a.__eq__(b) == b.__eq__(a)


# Generated at 2022-06-23 05:49:12.167018
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa='list')
    print(x)
    print(x.isa)
    print(x.private)
    print(x.default)
    print(x.required)
    print(x.listof)
    print(x.priority)
    print(x.class_type)
    print(x.always_post_validate)
    print(x.inherit)
    print(x.alias)
    print(x.extend)
    print(x.prepend)
    print(x.static)


# Generated at 2022-06-23 05:49:20.426005
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils.six import string_types

    # Basic type
    attr = Attribute(isa='str')
    assert attr.isa == 'str', repr(attr)
    assert attr.private is False, repr(attr)
    assert attr.default is None, repr(attr)
    assert attr.required is False, repr(attr)
    assert attr.listof is None, repr(attr)
    assert attr.priority == 0, repr(attr)
    assert attr.class_type is None, repr(attr)
    assert attr.always_post_validate is False, repr(attr)
    assert attr.inherit is True, repr(attr)
    assert attr.alias is None, repr(attr)
    assert attr.extend is False, repr(attr)
   

# Generated at 2022-06-23 05:49:26.579824
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=3)
    attr3 = Attribute(priority=5)

    assert (attr1 < attr2) is False
    assert (attr2 < attr1) is True
    assert (attr1 < attr3) is False
    assert (attr3 < attr1) is False



# Generated at 2022-06-23 05:49:32.498364
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattr = FieldAttribute()
    assert fieldattr.isa is None
    assert fieldattr.private == False
    assert fieldattr.default is None
    assert fieldattr.required == False
    assert fieldattr.listof is None
    assert fieldattr.priority == 0
    assert fieldattr.class_type is None
    assert fieldattr.always_post_validate == False
    assert fieldattr.inherit == True
    assert fieldattr.alias is None
    assert fieldattr.extend == False
    assert fieldattr.prepend == False


# Generated at 2022-06-23 05:49:37.260418
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1.__gt__(attr2)


# Generated at 2022-06-23 05:49:41.104341
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Arrange
    att1 = Attribute(isa = str, default = 'default_value')
    att2 = Attribute(isa = str, default = 'default_value')

    # Act
    result = att1 == att2

    # Assert
    assert result


# Generated at 2022-06-23 05:49:44.457399
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a.__eq__(b) == True


# Generated at 2022-06-23 05:49:49.240744
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    first = Attribute(priority=1)
    second = Attribute(priority=2)
    if not (first > second) :
        raise AssertionError('Attribute compare : %s > %s returns False' % (first.priority,second.priority))


# Generated at 2022-06-23 05:49:52.184736
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 >= attr2


# Generated at 2022-06-23 05:50:02.654265
# Unit test for constructor of class Attribute
def test_Attribute():

    # Create an attribute
    isa = "str"
    private = False
    default = "default-str"
    required = False
    listof = None
    priority = 0
    class_type = str
    always_post_validate = True
    inherit = False
    alias = "alias_str"
    extend = False
    prepend = False
    static = False

    attr = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    # Check the Attribute
    assert attr.isa == "str"
    assert attr.private == False
    assert attr.default == "default-str"
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority

# Generated at 2022-06-23 05:50:06.041995
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    assert a.__ge__(Attribute(priority=1)) == True
    assert a.__ge__(Attribute(priority=10)) == True


# Generated at 2022-06-23 05:50:07.972206
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa="str", default="test")
    assert isinstance(attribute, Attribute)

# Generated at 2022-06-23 05:50:17.044613
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='list', private=True, default=None, required=False,
                   listof='2', priority=0, class_type='3', always_post_validate=False,
                   inherit=True, alias='4', extend=False, prepend=False, static=False)
    assert a1.__eq__(a1)



# Generated at 2022-06-23 05:50:21.671884
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Is this test necessary?
    It's to test the code in the constructor (not __init__() itself)
    It's also to try to have tests for each callable in the file
    """

    try:
        FieldAttribute(default=[])
    except TypeError:
        pass # TypeError: defaults for FieldAttribute may not be mutable, please provide a callable instead
    else:
        assert False, "Default value should not be a list" # fail if no exception



# Generated at 2022-06-23 05:50:26.117619
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    pa1 = Attribute()
    pa2 = Attribute()
    pa1.priority = 3
    pa2.priority = 2
    try:
        assert pa1.__gt__(pa2)
    except AssertionError:
        print('test_Attribute___gt__ failed')
    else:
        print('test_Attribute___gt__ passed')


# Generated at 2022-06-23 05:50:33.288628
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=-5)
    a4 = Attribute(priority=0)
    assert (a1 >= a2) == True
    assert (a1 >= a3) == False
    assert (a1 >= a4) == True



# Generated at 2022-06-23 05:50:43.095997
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    from collections import namedtuple, defaultdict
    from operator import itemgetter
    attr1 = Attribute(isa='dict', priority=defaultdict(int))
    attr2 = Attribute(isa='int', priority=3)
    attr3 = Attribute(isa='dict', priority=1)
    attr4 = Attribute(isa='int', priority=1)
    attr5 = Attribute(isa='str', priority='priority')
    field = namedtuple('field', 'a b c d e')
    test_field = field(attr1, attr2, attr3, attr4, attr5)

    sorted_field = sorted(test_field, key=itemgetter(1))

# Generated at 2022-06-23 05:50:47.286912
# Unit test for constructor of class Attribute
def test_Attribute():
    attr1 = Attribute(isa='int', private=True, alias='my_name')
    assert attr1.isa == 'int'
    assert attr1.private
    assert attr1.alias == 'my_name'

    attr2 = Attribute(isa='bool', required=True)
    assert attr2.isa == 'bool'
    assert attr2.required



# Generated at 2022-06-23 05:50:52.937940
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=20)
    attr3 = Attribute(priority=5)
    attr4 = Attribute(priority=20)

    assert attr1 <= attr1
    assert attr1 <= attr2
    assert attr2 >= attr2
    assert attr1 <= attr3
    assert attr2 <= attr4


# Generated at 2022-06-23 05:51:02.409388
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    obj1 = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    obj2 = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=2,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
   

# Generated at 2022-06-23 05:51:06.910847
# Unit test for constructor of class Attribute
def test_Attribute():
    required = Attribute(isa='str', required=True)
    assert(required.isa == 'str')
    assert(required.required == True)
    non_required = Attribute(isa='str', required=False)
    assert(non_required.isa == 'str')
    assert(non_required.required == False)
    assert(required != non_required)
    assert(non_required != required)

# Generated at 2022-06-23 05:51:12.262115
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    '''
    This is a test function of class Attribute and
    function __ne__.\n
    Notice: This unit test is designed for function __ne__.
    '''
    # Test 1
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert((attr1!=attr2) == True)

    # Test 2
    assert((attr2!=attr1) == False)

    # Test 3
    assert((attr1!=attr1) == False)



# Generated at 2022-06-23 05:51:16.660159
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    Attribute_instance_1 = Attribute()
    Attribute_instance_2 = Attribute()

    equal_result = Attribute_instance_1.__eq__(Attribute_instance_1)
    assert equal_result == True



# Generated at 2022-06-23 05:51:20.209551
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 1
    assert(attr1 <= attr2)


# Generated at 2022-06-23 05:51:23.514187
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a2 > a1
    pass


# Generated at 2022-06-23 05:51:24.689598
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=1)
    assert not attr <= attr



# Generated at 2022-06-23 05:51:25.740912
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert (Attribute(priority=0) != Attribute(priority=1))

# Generated at 2022-06-23 05:51:36.196593
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(name='attr1', private=False, default='attr1', required=False, priority=1)
    attr2 = Attribute(name='attr2', private=False, default='attr2', required=False, priority=0)
    attr3 = Attribute(name='attr3', private=False, default='attr3', required=False, priority=2)
    attr4 = Attribute(name='attr4', private=False, default='attr4', required=False, priority=1)

    assert attr1 < attr3
    assert attr2 < attr1
    assert attr2 < attr3
    assert attr4 < attr3
    assert False == (attr1 < attr4)
    assert False == (attr1 < attr2)

# Generated at 2022-06-23 05:51:40.449228
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1, a2 = Attribute(priority=1), Attribute(priority=2)
    assert a1 < a2
    assert a1 <= a2
    assert a2 > a1
    assert a2 >= a1
    assert a2 == a2
    assert a2 != a1


# Generated at 2022-06-23 05:51:42.741872
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b < a


# Generated at 2022-06-23 05:51:50.713893
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from collections import namedtuple
    TestCase = namedtuple(
        'TestCase',
        ['priority', 'expected_priority', 'expected_result'],
    )

    test_cases = [
        TestCase(priority=12, expected_priority=10, expected_result=True),
        TestCase(priority=5,  expected_priority=12, expected_result=False),
        TestCase(priority=5,  expected_priority=5,  expected_result=False),
    ]

    for test_case in test_cases:
        attr = Attribute(priority=test_case.priority)
        assert attr > test_case.expected_priority == test_case.expected_result

# Generated at 2022-06-23 05:51:51.753892
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    return a

# Generated at 2022-06-23 05:52:03.918546
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    import sys

    class FieldAttribute2(Attribute):
        def __init__(self, name='', isa=None, private=False, default=None, required=False, listof=None, priority=0, **kwargs):
            super(FieldAttribute2, self).__init__(name, isa, private, default, required, listof, priority, **kwargs)

    class TestFieldAttribute(unittest.TestCase):
        """
        FieldAttribute Unit Test Class
        """
        def assertException(self, message, exception, method, *args):
            try:
                method(*args)
            except exception as ex:
                self.assertEqual(ex.message, message)
            else:
                self.fail('Exception %s was not raised' % exception)


# Generated at 2022-06-23 05:52:14.754556
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    var = Attribute(isa='str', private=False, default="na", required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    var1 = Attribute(isa='str', private=False, default="na", required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-23 05:52:17.650805
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test case for Attribute.__eq__(self, other)
    # when Attribute.priority == other.priority
    # true
    field_attri_1 = FieldAttribute(priority=1)
    field_attri_2 = FieldAttribute(priority=1)
    assert(field_attri_1.__eq__(field_attri_2) == True)

    # when Attribute.priority != other.priority
    # false
    field_attri_2 = FieldAttribute(priority=2)
    assert(field_attri_1.__eq__(field_attri_2) == False)


# Generated at 2022-06-23 05:52:22.414204
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    f1 = FieldAttribute()
    f1.priority = 0
    f2 = FieldAttribute()
    f2.priority = 0
    assert f1.__ne__(f2) == False
