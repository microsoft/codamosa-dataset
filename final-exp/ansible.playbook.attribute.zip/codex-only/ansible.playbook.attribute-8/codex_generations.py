

# Generated at 2022-06-23 05:42:20.439001
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1.__ge__(a2) == a2.__ge__(a1)


# Generated at 2022-06-23 05:42:22.065696
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """Test for Attribute's method __ne__"""
    pass


# Generated at 2022-06-23 05:42:32.501019
# Unit test for constructor of class Attribute
def test_Attribute():
    class FooClass(object):
        pass


# Generated at 2022-06-23 05:42:33.192536
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert(Attribute.__gt__('', ''))

# Generated at 2022-06-23 05:42:38.663218
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    f1 = Attribute(priority=1)
    f2 = Attribute(priority=2)
    assert f1 < f2
    f1 = Attribute(priority=2)
    f2 = Attribute(priority=1)
    assert not f1 < f2
    f1 = Attribute(priority=1)
    f2 = Attribute(priority=1)
    assert not f1 < f2


# Generated at 2022-06-23 05:42:42.977209
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2
    a3 = Attribute(priority=2)
    assert a2 <= a3


# Generated at 2022-06-23 05:42:46.109671
# Unit test for constructor of class Attribute
def test_Attribute():

    Attribute(
        isa='string',
        private=False,
        default='hello',
        required=False,
        listof='boolean',
        priority=0,
        class_type='myclass',
    )

# Generated at 2022-06-23 05:42:48.548750
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)
    field3 = Attribute(priority=3)
    assert field3.__ge__(field2)


# Generated at 2022-06-23 05:42:53.883517
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute(priority=-1))
    assert Attribute(priority=1).__le__(Attribute())
    assert Attribute(priority=1).__le__(Attribute(priority=1))
    assert not Attribute(priority=1).__le__(Attribute(priority=-1))


# Generated at 2022-06-23 05:42:59.088196
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    # could expand to cover more of the class, but these test is_valid
    assert a.isa is None
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-23 05:43:02.834735
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='foo')
    a2 = Attribute(isa='foo')
    a3 = Attribute(isa='bar')
    assert a1 == a2
    assert a2 == a3


# Generated at 2022-06-23 05:43:14.040330
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='class')
    assert a.isa == 'class'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    a = Attribute(isa='class', private=True, default='test', required=True, listof='test', priority=10, class_type='test',
                 always_post_validate=True, inherit=False, alias='test', extend=True, prepend=True, static=True)


# Generated at 2022-06-23 05:43:16.019044
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_attribute = Attribute()
    assert test_attribute != None



# Generated at 2022-06-23 05:43:26.364194
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    assert attr != None
    assert attr == attr

#def test_FieldAttribute_constructor_error():
#    attr = FieldAttribute(isa='dict', default='string')


# Generated at 2022-06-23 05:43:30.622272
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=2) == Attribute(priority=2)
    assert not Attribute(priority=2) == Attribute(priority=1)
    assert not Attribute(priority=2) == Attribute()


# Generated at 2022-06-23 05:43:37.063987
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute()
    attribute2 = Attribute()
    attribute1.priority = 1
    attribute2.priority = 0
    assert attribute2 < attribute1
    assert not attribute1 < attribute2
    attribute1.priority = 0
    attribute2.priority = 1
    assert attribute1 < attribute2
    assert not attribute2 < attribute1
    attribute1.priority = 1
    attribute2.priority = 1
    assert not attribute1 < attribute2
    assert not attribute2 < attribute1


# Generated at 2022-06-23 05:43:42.840821
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a1 = Attribute(priority=1)
    a10 = Attribute(priority=10)
    a_1 = Attribute(priority=-1)
    assert a1 <= a1
    assert a10 >= a10
    assert a_1 <= a_1
    assert a10 >= a1
    assert a1 <= a10
    assert a_1 >= a
    assert a <= a_1


# Generated at 2022-06-23 05:43:47.459704
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = FieldAttribute()
    attr2 = FieldAttribute()
    # set priority of attr1 to be lesser than attr2
    attr1.priority = 2
    attr2.priority = 5
    assert attr2 >= attr1


# Generated at 2022-06-23 05:43:50.119581
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr2 != attr1



# Generated at 2022-06-23 05:43:54.287622
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        attr = FieldAttribute(default=['a', 'b'])
        assert False, 'Expected a TypeError here'
    except TypeError:
        pass
    attr = FieldAttribute(default=lambda: ['a', 'b'])
    assert attr



# Generated at 2022-06-23 05:43:58.560482
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    class MyClass(Attribute):
        def __init__(self):
            Attribute.__init__(self)
            self.priority = 1

    t1 = Attribute()
    t2 = MyClass()

    assert t2 > t1
    assert not t2 < t1



# Generated at 2022-06-23 05:44:08.203519
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa="list", required=True, alias="roles")
    assert f.isa == 'list'
    assert f.private == False
    assert f.default == None
    assert f.required == True
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == 'roles'
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False

    # Validation of FieldAttribute isa value types
    try:
        f = FieldAttribute(isa=1)
    except TypeError:
        pass
    else:
        assert False, 'isa should not be allowed to be Integer'

    # Val

# Generated at 2022-06-23 05:44:09.888357
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert not a > b


# Generated at 2022-06-23 05:44:13.117258
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    a = Attribute(priority=10)
    b = Attribute(priority=20)
    if a != b:
        return True
    else:
        return False


# Generated at 2022-06-23 05:44:15.560203
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    x = Attribute(priority=5)
    y = Attribute(priority=6)
    assert y < x

# Generated at 2022-06-23 05:44:22.157288
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)
    assert attr2.__ge__(attr1)
    assert attr1.__ge__(attr1)
    assert not attr1.__ge__(attr2)



# Generated at 2022-06-23 05:44:23.830477
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert(Attribute(priority=0) < Attribute(priority=1))


# Generated at 2022-06-23 05:44:29.787572
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute()
    assert x.default is None
    assert x.required == False
    assert x.private == False
    assert x.priority == 0
    assert x.inherit == True
    assert x.alias is None

    x = Attribute(required=True, priority=8)
    assert x.default is None
    assert x.required == True
    assert x.private == False
    assert x.priority == 8
    assert x.inherit == True
    assert x.alias is None


# Generated at 2022-06-23 05:44:40.668540
# Unit test for constructor of class Attribute
def test_Attribute():
    def assert_raises(e, f, *args, **kwargs):
        try:
            f(*args, **kwargs)
        except e:
            return
        assert False

    # test default
    a = Attribute()
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # test simple

# Generated at 2022-06-23 05:44:48.434488
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    '''
    Unit test for method __ge__ of class Attribute
    '''
    # test for Attribute.__ge__() when 'self' has higher priority ('self' >= other)
    priority1 = 4
    priority2 = 5
    instance1 = Attribute(priority=priority1)
    instance2 = Attribute(priority=priority2)
    test1_result = instance1.__ge__(instance2)
    expected_result = True
    assert test1_result == expected_result,\
            "Attribute.__ge__() fails with 'self' has higher priority!"

    # test for Attribute.__ge__() when 'self' has lower priority (other >= 'self')
    priority1 = 4
    priority2 = 3
    instance1 = Attribute(priority=priority1)

# Generated at 2022-06-23 05:44:55.572752
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.priority = 5
    b = Attribute()
    b.priority = 5
    assert a.__ge__(b) == True
    assert b.__ge__(a) == True
    
    a = Attribute()
    a.priority = 5
    b = Attribute()
    b.priority = 6
    assert a.__ge__(b) == False
    assert b.__ge__(a) == True
   
    a = Attribute()
    a.priority = 6
    b = Attribute()
    b.priority = 5
    assert a.__ge__(b) == True
    assert b.__ge__(a) == False

# Generated at 2022-06-23 05:44:59.745677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    att = FieldAttribute(isa='int', private=False, default=0, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert att.isa == 'int'


# Generated at 2022-06-23 05:45:08.776656
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Create an instance of Attribute.
    fieldattribute_instance = Attribute()

    # Create a new instance of Attribute.
    other_fieldattribute_instance = Attribute()

    # Test: Use __lt__ to compare the two instances of Attribute.
    # Expected result: other.priority < self.priority
    assert(fieldattribute_instance.__lt__(other_fieldattribute_instance))



# Generated at 2022-06-23 05:45:10.607110
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(3)
    attr2 = Attribute(3)
    assert(attr1 == attr2)


# Generated at 2022-06-23 05:45:20.135020
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    data1 = FieldAttribute(
        isa='int',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    data2 = FieldAttribute(
        isa='int',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
   

# Generated at 2022-06-23 05:45:22.967102
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_0 = Attribute(priority=0)
    attr_1 = Attribute(priority=1)

    assert attr_1 > attr_0



# Generated at 2022-06-23 05:45:25.167454
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=4)
    assert a1 > a2


# Generated at 2022-06-23 05:45:29.496975
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field_attribute = Attribute()
    field_attribute2 = Attribute()
    field_attribute2.priority = 2
    #executed_result = field_attribute < field_attribute2
    assert field_attribute == field_attribute2


# Generated at 2022-06-23 05:45:32.231012
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    attr_ge = Attribute()
    attr_ge.priority = 200

    assert attr.__ge__(attr_ge)



# Generated at 2022-06-23 05:45:39.544919
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)
    field3 = Attribute(priority=3)
    # 1 >= 1 (true)
    assert field1 >= field1
    # 1 <= 2, 3 (true)
    assert field1 <= field2
    assert field1 <= field3
    # 2 <= 1, 2, 3 (true)
    assert field2 <= field1
    assert field2 <= field2
    assert field2 <= field3
    # 3 <= 1, 2, 3 (true)
    assert field3 <= field1
    assert field3 <= field2
    assert field3 <= field3



# Generated at 2022-06-23 05:45:40.930104
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_item = FieldAttribute()
    assert isinstance(test_item, Attribute)

# Generated at 2022-06-23 05:45:42.888798
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute.__ge__(Attribute(priority=1), Attribute(priority=1))


# Generated at 2022-06-23 05:45:46.383802
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(default=None, priority=10)
    b = Attribute(default='test', priority=5)
    assert a > b


# Generated at 2022-06-23 05:45:50.561847
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute()
    y = Attribute()
    # __ge__ should return False since priority numbers are equal
    return not x.__ge__(y)


# Generated at 2022-06-23 05:45:54.184921
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()
    attr.priority = 1
    other = Attribute()
    other.priority = 2

    assert attr.__gt__(other) is False
    assert other.__gt__(attr) is True


# Generated at 2022-06-23 05:46:00.678865
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    a = Attribute(isa='bool', priority=5)
    assert(a == a)
    assert(not (a != a))

    b = Attribute(isa='bool', priority=5)
    assert(a == b)
    assert(not (a != b))

    c = Attribute(isa='bool', priority=10)
    assert(a != c)
    assert(not (a == c))


# Generated at 2022-06-23 05:46:01.221882
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-23 05:46:03.969870
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=3)
    b = Attribute(priority=3)
    c = Attribute(priority=2)

    assert a <= b
    assert not a <= c



# Generated at 2022-06-23 05:46:06.759169
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    import pytest
    a=Attribute()
    b=Attribute()
    a.priority=12
    b.priority=2
    assert a < b


# Generated at 2022-06-23 05:46:17.344500
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class TestYAML(AnsibleBaseYAMLObject):
        """
        This is a class for testing the FieldAttribute class.

        It doesn't do much for now but it is used for the
        FieldAttribute test cases and may grow in the future.
        """
        __test__ = True # For the purposes of pytest discovery, this class should not be discovered
        def __init__(self):
            self._parent = None
            self._name = None
            self._load_name = None

        def get_name(self):
            return self._name

        def set_name(self, name):
            self._name = name

        def get_load_name(self):
            return self._load_name


# Generated at 2022-06-23 05:46:18.870655
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 >= a2



# Generated at 2022-06-23 05:46:23.330725
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)

    assert a2 < a3
    assert not a3 < a2

    assert a2 <= a3
    assert not a3 <= a2

    assert a3 > a2
    assert not a2 > a3

    assert a3 >= a2
    assert not a2 >= a3



# Generated at 2022-06-23 05:46:29.124204
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)

    assert a.__ge__(b)
    assert not a.__ge__(c)
    assert b.__ge__(a)
    assert c.__ge__(a)


# Generated at 2022-06-23 05:46:29.952620
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    pass


# Generated at 2022-06-23 05:46:37.563307
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    attr.priority = 10
    attr1 = Attribute()
    attr1.priority = 10
    assert attr1.__ge__(attr) is True
    attr2 = Attribute()
    attr2.priority = 12
    assert attr2.__ge__(attr) is True
    attr3 = Attribute()
    attr3.priority = 8
    assert attr3.__ge__(attr) is False

# Generated at 2022-06-23 05:46:40.455993
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 != a2
    assert not (a1 != a2)

# Generated at 2022-06-23 05:46:50.646743
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_object1 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=6,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-23 05:47:01.450602
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(
        isa='dict',
        private=True,
        default="default",
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=True,
        inherit=False,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr1.isa == 'dict'
    assert attr1.private == True
    assert attr1.default == "default"
    assert attr1.required == False
    assert attr1.listof == None
    assert attr1.priority == 0
    assert attr1.class_type == None
    assert attr1.always_post_validate == True

# Generated at 2022-06-23 05:47:04.161888
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    assert a.__le__(b) == False
    assert a.__ge__(b) == False


# Generated at 2022-06-23 05:47:10.952213
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    assert a >= b
    assert not a < b
    assert not a <= b
    assert not a > b
    assert a >= a
    assert not a < a
    assert a <= a
    assert not a > a
    assert not b >= a
    assert b < a
    assert b <= a
    assert not b > a


# Generated at 2022-06-23 05:47:18.429660
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from ..splitter import FieldAttribute
    import pytest

    attr_a = FieldAttribute(priority=0, isa='')
    attr_b = FieldAttribute(priority=0, isa='')
    attr_c = FieldAttribute(priority=1, isa='')

    assert attr_a <= attr_b
    assert attr_a <= attr_c
    assert attr_b <= attr_c



# Generated at 2022-06-23 05:47:27.076651
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    #Prepare test data
    isa="list"
    private=False
    default=[1,2,3]
    required=True
    listof="dict"
    priority=0
    class_type=list
    always_post_validate=True
    inherit=True
    alias="list_alias"
    extend=True
    prepend=True
    static=True

    #Create and initialize instances of class Attribute
    instance_1=Attribute(isa,private,default,required,listof,priority,class_type,always_post_validate,inherit,alias,extend,prepend,static)

# Generated at 2022-06-23 05:47:28.103172
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().default is None

# Generated at 2022-06-23 05:47:30.306096
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=1)
    att2 = Attribute(priority=2)
    assert att2 > att1


# Generated at 2022-06-23 05:47:33.619878
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1.__ge__(attr2) == True


# Generated at 2022-06-23 05:47:41.350260
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)

    a_list = [a, b, c]
    b_list = [b, c]
    c_list = [c]

    a_list.sort()
    # a_list must contain: a, b, c
    if a_list[0] != a or a_list[1] != b or a_list[2] != c:
        return False

    b_list.sort()
    # b_list must contain: b, c
    if b_list[0] != b or b_list[1] != c:
        return False

    c_list.sort()
    # c_list must contain: c
    if c_list[0] != c:
        return

# Generated at 2022-06-23 05:47:43.630102
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a.__ge__(b) == True


# Generated at 2022-06-23 05:47:54.467921
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', required=True)
    assert attr.isa == 'str'
    assert attr.required == True
    attr = FieldAttribute(isa='str', required=False)
    assert attr.required == False
    attr = FieldAttribute(isa='str', private=False)
    assert attr.private == False
    attr = FieldAttribute(isa='str', default='kjkj')
    assert attr.default == 'kjkj'
    attr = FieldAttribute(isa='str', listof="1")
    assert attr.listof == "1"
    attr = FieldAttribute(isa='str', priority=1)
    assert attr.priority == 1
    attr = FieldAttribute(isa='str', class_type="1")
    assert attr.class_type == "1"

# Generated at 2022-06-23 05:47:58.799578
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list', default=list, required=True, listof='dict')
    assert attribute.isa == 'list'
    assert attribute.default == list
    assert attribute.required == True
    assert attribute.listof == 'dict'
    assert attribute.priority == 0

# Unittest for method in Attribute

# Generated at 2022-06-23 05:48:08.223188
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

# test__lt__A
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b < a

# test__lt__B
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert not b < b

# test__lt__C
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert not b < a

# test__lt__D
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert not b < a

# test__lt__E
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    assert a < b



# Generated at 2022-06-23 05:48:10.606917
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=10)
    assert attr.__ge__(Attribute(priority=9))


# Generated at 2022-06-23 05:48:15.023111
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class FooClass(object):
        bar_attr = FieldAttribute(priority=5)

    foo = FooClass()
    my_attribute = Attribute(priority=5)
    assert my_attribute.__ge__(foo.bar_attr)


# Generated at 2022-06-23 05:48:17.750564
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert (Attribute(priority=1) == Attribute(priority=1)) is True
    assert (Attribute(priority=1) == Attribute(priority=2)) is False


# Generated at 2022-06-23 05:48:21.517259
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(0)
    attr_2 = Attribute(1)
    attr_3 = Attribute(1)
    attr_4 = Attribute(-1)

    assert attr_1 != attr_2
    assert attr_2 != attr_1
    assert attr_2 != attr_3
    assert attr_3 != attr_4
    assert attr_4 != attr_3


# Generated at 2022-06-23 05:48:32.753626
# Unit test for constructor of class Attribute
def test_Attribute():
    doc = "A test"

    # Test case 1: isa is str, private is False, default is None, listof is None, class_type is None, inherit is True, priority is 0 and alias is None
    a1 = Attribute(isa="list")
    assert a1.isa == "list"
    assert a1.class_type is None
    assert a1.private == False
    assert a1.default is None
    assert a1.listof is None
    assert a1.inherit == True
    assert a1.priority == 0
    assert a1.alias is None

    # Test case 2: isa is str, private is True, default is [1,2,3], listof is "int", class_type is None, inherit is True, priority is 2 and alias is None

# Generated at 2022-06-23 05:48:36.190612
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    Attr1 = Attribute(priority=1)
    Attr2 = Attribute(priority=2)
    Attr3 = Attribute(priority=1)
    assert (Attr1 != Attr2) is True
    assert (Attr1 != Attr3) is False



# Generated at 2022-06-23 05:48:39.082630
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    FieldAttribute_obj = FieldAttribute()
    other_FieldAttribute_obj = FieldAttribute(priority=1)
    assert(FieldAttribute_obj.__ne__(other_FieldAttribute_obj))

# Generated at 2022-06-23 05:48:42.289745
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
  foo = Attribute(isa='int', default=0)
  bar = Attribute(isa='int', default=0)
  assert foo == bar
  assert not foo != bar


# Generated at 2022-06-23 05:48:48.586244
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a > b)
    assert(not (a < b))
    assert(a != b)
    assert(not (a == b))
    assert(a <= b)
    assert(not (a >= b))


# Generated at 2022-06-23 05:48:58.517743
# Unit test for method __gt__ of class Attribute

# Generated at 2022-06-23 05:49:06.948868
# Unit test for constructor of class Attribute
def test_Attribute():
    # testing constructor of class Attribute
    # the constructor initializes the attributes
    # the attributes are specified as keyword arguments
    # the keyword arguments are {name:value}
    # name is one of (isa|private|required|default|listof)
    foo_attribute = Attribute(isa='list', required=True, listof='int', default=[])
    # test if the attributes in the constructor have been set correctly
    assert foo_attribute.isa == 'list'
    assert foo_attribute.required == True
    assert foo_attribute.listof == 'int'
    assert foo_attribute.default == []
    # no exception should be raised
    foo_attribute = Attribute(isa='list', required=True, default=[])


# Generated at 2022-06-23 05:49:09.139743
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2

# Generated at 2022-06-23 05:49:11.893953
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=7)
    assert a2 > a1

# Generated at 2022-06-23 05:49:15.413188
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert(a1.__ne__(a2))
    assert(not a1.__ne__(a1))


# Generated at 2022-06-23 05:49:24.895353
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_field_attribute = FieldAttribute(isa='str', required=False, inherit=True, priority=0, prepend=False, extend=False, always_post_validate=False, alias=None)
    assert test_field_attribute.isa == 'str'
    assert not test_field_attribute.required
    assert test_field_attribute.inherit
    assert test_field_attribute.priority == 0
    assert not test_field_attribute.prepend
    assert not test_field_attribute.extend
    assert not test_field_attribute.always_post_validate
    assert test_field_attribute.alias is None


# Generated at 2022-06-23 05:49:27.059327
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute(priority=0)
    other = Attribute(priority=1)
    assert (attribute != other)



# Generated at 2022-06-23 05:49:34.196867
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """Test for Attribute __lt__ method"""

    # Unit test for method __lt__ of class Attribute
    testAttribute1 = Attribute(priority=1)
    testAttribute2 = Attribute(priority=2)
    testAttribute3 = Attribute(priority=1)
    assert testAttribute1 < testAttribute2
    assert testAttribute2 < testAttribute1 is False
    assert testAttribute1 < testAttribute3 is False


# unit test for method __eq__ of class Attribute

# Generated at 2022-06-23 05:49:42.441131
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', required=True)
    assert a.isa == 'dict'
    assert a.required == True
    assert a.private == False
    assert a.default == None
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-23 05:49:54.406083
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # FieldAttribute constructor test
    # isa value None test
    fields_attrib_null = FieldAttribute()
    assert fields_attrib_null.isa is None
    assert fields_attrib_null.private is False
    assert fields_attrib_null.default is None
    assert fields_attrib_null.required is False
    assert fields_attrib_null.listof is None
    assert fields_attrib_null.priority == 0
    assert fields_attrib_null.class_type is None
    assert fields_attrib_null.always_post_validate is False
    assert fields_attrib_null.inherit is True
    assert fields_attrib_null.alias is None
    assert fields_attrib_null.extend is False
    assert fields_attrib_null.prepend is False
    assert fields_

# Generated at 2022-06-23 05:49:55.764867
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    pass


# Generated at 2022-06-23 05:50:07.384516
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute()
    attribute2 = Attribute()

    attribute1.priority = 2
    attribute2.priority = 2

    assert attribute1 == attribute2
    assert attribute1 <= attribute2
    assert not attribute1 < attribute2
    assert attribute1 >= attribute2
    assert not attribute1 > attribute2

    attribute1.priority = 1
    attribute2.priority = 2

    assert attribute1 != attribute2
    assert attribute1 < attribute2
    assert attribute1 <= attribute2
    assert not attribute1 >= attribute2
    assert not attribute1 > attribute2

    attribute1.priority = 3
    attribute2.priority = 2

    assert attribute1 != attribute2
    assert not attribute1 < attribute2
    assert not attribute1 <= attribute2
    assert attribute1 >= attribute2
    assert attribute1 > attribute2

# Generated at 2022-06-23 05:50:10.599951
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a.__ne__(b) == False
    assert b.__ne__(a) == False


# Generated at 2022-06-23 05:50:18.463397
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_ne_1 = Attribute(isa='int', priority=1)
    attr_ne_2 = Attribute(isa='int', priority=2)
    assert not attr_ne_1 == attr_ne_2
    assert attr_ne_1 != attr_ne_2


# Generated at 2022-06-23 05:50:21.194163
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=1)
    assert attr == Attribute(priority=1)
    assert not attr == Attribute(priority=2)


# Generated at 2022-06-23 05:50:25.221497
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert(attr2 > attr1)

# Generated at 2022-06-23 05:50:29.951124
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    b.priority = 1
    assert a.__eq__(b) == False
    assert a.__ne__(b) == True
    a.priority = 1
    assert a.__eq__(b) == True
    assert a.__ne__(b) == False


# Generated at 2022-06-23 05:50:31.417385
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=0)


# Generated at 2022-06-23 05:50:33.584389
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute.__class__
    assert FA(isa='list') == FA(isa='list')



# Generated at 2022-06-23 05:50:37.710747
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=6)
    return a1.__le__(a2) and a1.__le__(a3)


# Generated at 2022-06-23 05:50:41.833740
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # object attribute1, object should not eq object attribute2
    attribute1 = Attribute()
    attribute2 = Attribute()
    assert attribute1 != attribute2

    # object attribute1, object should eq object attribute3
    attribute3 = attribute1
    assert attribute1 == attribute3



# Generated at 2022-06-23 05:50:48.654854
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # define ISA
    FA_ISA = 'I'
    # define private
    FA_PRIVATE = 'P'
    # define default
    FA_DEFAULT = 'D'
    # define required
    FA_REQUIRED = 'R'
    # define listof
    FA_LISTOF = 'L'
    # define priority
    FA_PRIORITY = 'X'
    # define class_type
    FA_CLASS_TYPE = 'C'
    # define always_post_validate
    FA_ALWAYS_POST_VALIDATE = 'A'
    # define inherit
    FA_INHERIT = 'I'
    # define alias
    FA_ALIAS = 'A'
    # define extend
    FA_EXTEND = 'E'
    # define prepend

# Generated at 2022-06-23 05:50:50.808566
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute() >= Attribute()
    

# Generated at 2022-06-23 05:50:55.772085
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    class Test(object):
        attr = Attribute(priority=5)
    t1 = Test()
    t2 = Test()
    t2.attr = Attribute(priority=10)
    assert not t1.attr.__ne__(t1.attr)
    assert t1.attr.__ne__(t2.attr)



# Generated at 2022-06-23 05:51:01.028337
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    '''
    This function will return a failed test if the __gt__ method of object of type Attribute is not working properly
    '''

    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    if attr1.__gt__(attr2):
        return "__gt__ of class Attribute is not working properly"
    else:
        return



# Generated at 2022-06-23 05:51:03.256520
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priotity = 1)
    b = Attribute(priotity = 2)
    return a.__ne__(b) == 1


# Generated at 2022-06-23 05:51:07.341235
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = 1
    y = 2
    class Attribute:
        def __init__(self, priority):
            self.priority = priority
    Attribute1 = Attribute
    Attribute2 = Attribute
    Attribute1.priority = x
    Attribute2.priority = y
    assert Attribute1.priority != Attribute2.priority
    assert not Attribute1.priority == Attribute2.priority


# Generated at 2022-06-23 05:51:11.404565
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    o1 = Attribute(priority=1)
    o2 = Attribute(priority=2)
    assert o1.__gt__(o2) == False

    o2 = Attribute(priority=1)
    assert o1.__gt__(o2) == False

    o2 = Attribute(priority=0)
    assert o1.__gt__(o2) == True


FieldAttribute = FieldAttribute



# Generated at 2022-06-23 05:51:14.274080
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert(a1 >= a1)
    assert(a0 >= a1)
    assert(not a1 >= a0)


# Generated at 2022-06-23 05:51:16.508161
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    FA = Attribute()
    FA.priority = 1
    assert FA != 0



# Generated at 2022-06-23 05:51:20.380548
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    a = Attribute(isa='date')
    a = Attribute(isa='date', default=datetime.datetime.now())
    a = Attribute(isa='dict', default=dict)


# Generated at 2022-06-23 05:51:24.041149
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(isa='string')
    attr2 = Attribute(isa='string')
    attr3 = Attribute(isa='list')

    assert attr == attr2
    assert attr != attr3


# Generated at 2022-06-23 05:51:28.956733
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Output of __ne__ method
    expected = True
    # Method test
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    res = a.__ne__(b)
    # Assertion for method __ne__ with parameters 'a' and 'b'
    assert res == expected


# Generated at 2022-06-23 05:51:40.110082
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # prepend and extend not supported
    # expected_prepend_with_extend = Attribute(prepend=True, extend=True)
    # expected_extend_with_prepend = Attribute(extend=True, prepend=True)
    # expected_extend = Attribute(extend=True)
    # expected_prepend = Attribute(prepend=True)

    expected_default = Attribute(default=True)
    expected_extend_with_default = Attribute(default=True, extend=True)

    # prepend and extend not supported
    # assert expected_prepend_with_extend != expected_extend_with_prepend
    # assert expected_prepend_with_extend != expected_extend
    # assert expected_prepend_with_extend != expected_prepend
    # assert expected

# Generated at 2022-06-23 05:51:43.634529
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attrib1 = Attribute()
    attrib1.priority = 0
    attrib2 = Attribute()
    attrib2.priority = 1
    assert attrib2 > attrib1


# Generated at 2022-06-23 05:51:46.525267
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(isa='bool')
    attr2 = Attribute(isa='list', priority=3)
    assert attr1.__gt__(attr2) == False


# Generated at 2022-06-23 05:51:49.544290
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=0)
    assert not Attribute(priority=0) > Attribute(priority=0)
    assert not Attribute(priority=0) > Attribute(priority=1)


# Generated at 2022-06-23 05:51:50.998856
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute(priority=1)
    assert(attribute == attribute)



# Generated at 2022-06-23 05:51:52.908545
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=1) <= Attribute(priority=2)


# Generated at 2022-06-23 05:51:57.464839
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    assert a1 == a2
    a3 = Attribute(priority=0)
    assert a1 != a3
    assert a1 != a3



# Generated at 2022-06-23 05:52:01.074468
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
     a = Attribute()
     a.priority = 0
     b = Attribute()
     b.priority = 1
     c = Attribute()
     c.priority = 0

     return (not (a != b) and (a != c))


# Generated at 2022-06-23 05:52:05.479232
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    print(a.__eq__(Attribute(priority=1)))
    print(a.__eq__(Attribute(priority=1)))
    print(a.__eq__(Attribute(priority=2)))
    print(a.__eq__(Attribute(priority=2)))



# Generated at 2022-06-23 05:52:07.512667
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr = Attribute(isa='dict')


# Generated at 2022-06-23 05:52:12.443472
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Arrange
    fieldAttr = FieldAttribute()
    fieldAttr.priority = 1
    fieldAttr2 = FieldAttribute()
    fieldAttr2.priority = 2
    # Act
    boolean = fieldAttr.__ne__(fieldAttr2)
    # Assert
    assert boolean == True



# Generated at 2022-06-23 05:52:14.029418
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=0) > Attribute(priority=1)


# Generated at 2022-06-23 05:52:14.955491
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    pass


# Generated at 2022-06-23 05:52:19.014650
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    '''
    unit test for method Attribute.__eq__()
    '''
    obj = Attribute(priority=1)
    assert obj == Attribute(priority=1)
    assert not(obj == Attribute(priority=0))
    assert not(obj == 1)
    assert not(obj == 'foo')
    assert not(obj == [])
