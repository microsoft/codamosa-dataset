

# Generated at 2022-06-23 05:42:26.431352
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Foo(object):
        def __init__(self, default=None):
            foo = FieldAttribute(default=default)

    def test_fail(value):
        try:
            Foo(default=value)
        except TypeError as e:
            assert 'defaults for FieldAttribute may not be mutable' in str(e)
            pass
        else:
            raise AssertionError('Should have been an error')

    test_fail(1)
    test_fail([1])
    test_fail((1, ))
    test_fail({'foo': 'bar'})
    test_fail(set([1]))
    test_fail({'key': 'val'}.keys())
    test_fail({'key': 'val'}.values())
    test_fail({'key': 'val'}.items())



# Generated at 2022-06-23 05:42:34.545344
# Unit test for constructor of class Attribute
def test_Attribute():
   import types

   # Create instance of class Attribute
   attr = Attribute(isa=types.IntType)

   # Test constructor
   assert isinstance(attr, Attribute)
   assert isinstance(attr.isa, types.TypeType)
   assert attr.isa == types.IntType
   assert attr.private is False
   assert attr.default is None
   assert attr.required is False
   assert attr.listof is None
   assert attr.priority == 0
   assert attr.class_type is None
   assert attr.always_post_validate is False
   assert attr.inherit is True
   assert attr.alias is None



# Generated at 2022-06-23 05:42:44.521217
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='bool', default=False)
    b = FieldAttribute(isa='bool', default=False)

    c = FieldAttribute(isa='bool', default=True)
    d = FieldAttribute(isa='bool', default=True)

    assert a == b
    assert c == d

    assert a < c
    assert b < d
    assert c > a
    assert d > b

    assert a <= b
    assert b <= a
    assert c <= d
    assert d <= c
    assert a <= c
    assert b <= d
    assert c >= a
    assert d >= b

    x = copy(a)
    y = copy(b)
    z = copy(a)

    assert x == y
    assert a == x
    assert b == x
    assert a == x
    assert a == y
   

# Generated at 2022-06-23 05:42:47.451551
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert b > a
    assert not a > b
    assert not b > b
    assert not a > a

# Generated at 2022-06-23 05:42:50.940926
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
   attribute = FieldAttribute(isa='task', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
   assert isinstance(attribute, FieldAttribute)



# Generated at 2022-06-23 05:42:52.342319
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute(priority=1) > Attribute(priority=0)



# Generated at 2022-06-23 05:42:55.569387
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    This function tests the function __lt__ of the class Attribute.
    '''
    attribute1 = Attribute(priority=100)
    attribute2 = Attribute(priority=1)
    assert attribute2 < attribute1



# Generated at 2022-06-23 05:43:08.190225
# Unit test for constructor of class Attribute
def test_Attribute():
    test_isa_int = Attribute(isa='int')
    assert test_isa_int.isa == 'int'
    test_isa_list = Attribute(isa='list')
    assert test_isa_list.isa == 'list'
    test_isa_dict = Attribute(isa='dict')
    assert test_isa_dict.isa == 'dict'
    test_isa_bool = Attribute(isa='bool')
    assert test_isa_bool.isa == 'bool'
    test_isa_str = Attribute(isa='str')
    assert test_isa_str.isa == 'str'
    test_isa_class = Attribute(isa='class')
    assert test_isa_class.isa == 'class'
    test_isa_listof_int = Attribute(isa='list', listof='int')

# Generated at 2022-06-23 05:43:12.175955
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    b.priority = 4
    assert a.__le__(b) is not False



# Generated at 2022-06-23 05:43:15.260876
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a <= b


# Generated at 2022-06-23 05:43:25.741090
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=4)
    a5 = Attribute(priority=5)
    assert a1 >= a2 == False
    assert a1 >= a3 == False
    assert a1 >= a4 == False
    assert a1 >= a5 == False
    assert a2 >= a1 == True
    assert a3 >= a1 == True
    assert a4 >= a1 == True
    assert a5 >= a1 == True
    assert a2 <= a1 == False
    assert a3 <= a1 == False
    assert a4 <= a1 == False
    assert a5 <= a1 == False
    assert a1 <= a2 == True
    assert a1 <= a3 == True

# Generated at 2022-06-23 05:43:31.730683
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    class A:
        attr = FieldAttribute()

    class B:
        attr = FieldAttribute(priority=0)

    class C:
        attr = FieldAttribute(priority=1)

    assert A.attr <= B.attr
    assert B.attr <= C.attr
    assert A.attr <= C.attr



# Generated at 2022-06-23 05:43:34.574558
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    first = Attribute(priority=0)
    second = Attribute(priority=1)
    assert first.__ge__(second) == True
    assert second.__ge__(first) == False


# Generated at 2022-06-23 05:43:38.933228
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    aa = Attribute()
    aa.priority = 1
    aa2 = Attribute()
    aa2.priority = 1
    aa.__le__(aa2)


# Generated at 2022-06-23 05:43:45.858653
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
   attr1 = Attribute(priority=1)
   attr2 = Attribute(priority=2)
   if not attr2.__gt__(attr1):
       raise AssertionError("attr1 should be less than attr2, instead " + str(attr1.priority) + " is greater than " + str(attr2.priority))


# Generated at 2022-06-23 05:43:48.850034
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    attr1 = Attribute(priority=100)
    attr2 = Attribute(priority=50)

    assert attr1 > attr2


# Generated at 2022-06-23 05:43:50.767599
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) < Attribute(priority=2)


# Generated at 2022-06-23 05:43:55.898051
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa=int, default=0)
    assert attribute.isa == int
    assert attribute.default == 0

    attribute = FieldAttribute(isa=int, default=0, listof=str)
    assert attribute.isa == int
    assert attribute.default == 0
    assert attribute.listof == str



# Generated at 2022-06-23 05:43:59.968186
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)
    if attribute_1 > attribute_2:
        raise AssertionError()


# Generated at 2022-06-23 05:44:03.673285
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att = Attribute()
    att1 = Attribute()
    att.priority = 1
    att1.priority = 2
    assert att.__gt__(att1) == False
    assert att.__gt__(att) == False
    assert att1.__gt__(att1) == False
    assert att1.__gt__(att) == True



# Generated at 2022-06-23 05:44:08.013696
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute(priority=1)
    c = Attribute(priority=1)

    assert a == b
    assert b == c

    assert not a != b
    assert not b != c

    assert a != c
    assert b != c


# Generated at 2022-06-23 05:44:09.583425
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field_attribute = FieldAttribute(priority = 3)
    assert field_attribute.__eq__(Attribute(priority = 3))

# Generated at 2022-06-23 05:44:12.898980
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # attribute with default value
    a = Attribute(isa='str', default='test')
    # attribute without default value
    b = Attribute(isa='str')
    assert a != None
    assert b != None
    assert a != b


# Generated at 2022-06-23 05:44:14.110831
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert (Attribute()).__ne__(Attribute())


# Generated at 2022-06-23 05:44:21.336279
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert(a <= b)
    assert(b <= a)
    assert(not (a <= c))
    assert(not (c <= a))
    assert(c <= c)


# Generated at 2022-06-23 05:44:24.284034
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 > a2
    assert a1 < a2 == False


# Generated at 2022-06-23 05:44:30.724755
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 2)
    attr3 = Attribute(priority = 2)
    assert attr1 == attr1
    assert attr2 == attr2
    assert attr2 == attr3
    assert not attr1 == attr2
    # assert not attr1 == attr3  # Fails with TypeError: invalid comparison
    assert not attr2 == attr1
    # assert not attr3 == attr1  # Fails with TypeError: invalid comparison
    print("\n")


# Generated at 2022-06-23 05:44:34.476537
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority = 3) <= Attribute(priority = 3)
    assert Attribute(priority = 3) <= Attribute(priority = 4)
    assert not (Attribute(priority = 4) <= Attribute(priority = 3))


# Generated at 2022-06-23 05:44:42.693933
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class A(AnsibleBaseYAMLObject):
        fields = {
            'a': FieldAttribute(isa='int', priority=10),
            'b': FieldAttribute(isa='int', priority=20),
            'c': FieldAttribute(isa='int', priority=0)
        }

    a = A()
    a.a = 10
    a.b = 20
    a.c = 30
    assert a.a == 10
    assert a.b == 20
    assert a.c == 30
    assert a.a > a.b
    assert a.a < a.c


# Generated at 2022-06-23 05:44:45.106017
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    return a1 < a2


# Generated at 2022-06-23 05:44:51.741587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    att = FieldAttribute('string', static=True)
    assert att.isa == 'string'
    assert att.private == False
    assert att.default == None
    assert att.required == False
    assert att.listof == None
    assert att.priority == 0
    assert att.class_type == None
    assert att.always_post_validate == False
    assert att.inherit == True
    assert att.alias == None
    assert att.extend == False
    assert att.prepend == False
    assert att.static == True



# Generated at 2022-06-23 05:44:56.456541
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    assert a1 >= a2
    assert a2 <= a1



# Generated at 2022-06-23 05:44:57.622302
# Unit test for constructor of class Attribute
def test_Attribute():
    raise NotImplementedError()



# Generated at 2022-06-23 05:45:01.863488
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_instance = Attribute()
    attribute_instance.priority = 2
    other_attribute_instance = Attribute()
    other_attribute_instance.priority = 3
    assert attribute_instance.__ge__(other_attribute_instance)


# Generated at 2022-06-23 05:45:04.950530
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=2)
    if not (b >= a):
        raise AssertionError('Expected True for b >= a')


# Generated at 2022-06-23 05:45:06.784157
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    assert a.__ne__(b)


# Generated at 2022-06-23 05:45:09.585287
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    assert a != b
    a.priority = 2
    b.priority = 2
    assert a == b


# Generated at 2022-06-23 05:45:10.490925
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert not Attribute()>=Attribute()


# Generated at 2022-06-23 05:45:15.865748
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa='dict', private=False, default=dict(name='David', age=21), required=True, listof=None, priority=100, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert isinstance(attr, Attribute)

# Generated at 2022-06-23 05:45:22.730319
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute(isa='int', default=0, required=False, priority=100)
    a2 = Attribute(isa='int', default=0, required=False, priority=100)
    a3 = Attribute(isa='int', default=1, required=False, priority=100)
    assert a1 == a2
    assert a1 != a3
    assert a1 <= a2
    assert a1 >= a2
    assert a1 < a3
    assert a1 <= a3
    assert a3 > a2
    assert a3 >= a2
    a4 = Attribute(isa='int', default=0, required=False, priority=101)
    assert a4 > a1
    assert a4 >= a1
    assert a1 < a4
    assert a1 <= a4


# Generated at 2022-06-23 05:45:28.963936
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    fieldattribute = FieldAttribute(default=None, always_post_validate=False, inherit=True, isa="int", required=True, listof=None, private=False, alias=None, extend=False, prepend=False, static=False, class_type=None, priority=1)
    assert fieldattribute != 1


# Generated at 2022-06-23 05:45:31.793877
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1

    b = Attribute()
    b.priority = 2

    assert b.__gt__(a)
    assert not a.__gt__(b)

# Generated at 2022-06-23 05:45:36.674754
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)

    assert attr1.__ge__(attr2) == True
    assert attr2.__ge__(attr1) == True

# Generated at 2022-06-23 05:45:39.906368
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 1
    attr2.priority = 2
    assert attr2 >= attr1


# Generated at 2022-06-23 05:45:51.909488
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Setup cases
    # Case 1
    print("Test Case 1...")
    a1 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    a1_copy = deepcopy(a1)
    # Case 2
    print("Test Case 2...")
    a2 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    # Case 3
    print("Test Case 3...")
   

# Generated at 2022-06-23 05:45:54.300174
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority=100)
    y = Attribute(priority=100)

    assert x <= y
    assert y <= x



# Generated at 2022-06-23 05:45:57.432160
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute()
    attr2 = Attribute()

    # expectation is that attr < attr2 returns False
    assert not attr.__lt__(attr2)

# Generated at 2022-06-23 05:46:01.369113
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    same_attr = Attribute(priority=0)
    diff_attr = Attribute(priority=1)
    assert (attr == same_attr)
    assert not (attr == diff_attr)
# Test ends


# Generated at 2022-06-23 05:46:10.938943
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert isinstance(a.isa, type(None))
    assert a.private is False
    assert isinstance(a.default, type(None))
    assert a.required is False
    assert isinstance(a.listof, type(None))
    assert a.priority == 0
    assert isinstance(a.class_type, type(None))
    assert a.always_post_validate is False
    assert a.inherit is True
    assert isinstance(a.alias, type(None))
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False



# Generated at 2022-06-23 05:46:14.346573
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa = "str", private = True, default = None, required = False,
                  listof = None, priority = 0, class_type = None, always_post_validate = False,
                  inherit = True, alias = None)

# Generated at 2022-06-23 05:46:17.876997
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert(not a < a)
    assert(a < b)
    assert(not b < a)
    assert(not b < b)


# Generated at 2022-06-23 05:46:22.536983
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    x = Attribute(
        isa='int',
        private=False,
        default=10,
        required=False,
        priority=-1
    )
    y = Attribute(
        isa='int',
        private=False,
        default=10,
        required=False,
        priority=1
    )

    assert y.__ge__(x)



# Generated at 2022-06-23 05:46:26.762990
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=10)
    new_attr = Attribute(priority=20)
    assert attr < new_attr, "This should be True as priority is less for attr"



# Generated at 2022-06-23 05:46:31.231270
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    print("test_Attribute___gt__: Given a.priority = 1, b.priority = 2, then, a > b: {0}".format(a.__gt__(b)))



# Generated at 2022-06-23 05:46:42.145053
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # no error if isa is a string
    attr = Attribute(isa='string')
    assert attr.isa == 'string'
    # no error if isa is a class
    attr = Attribute(isa=Attribute)
    assert attr.isa == Attribute
    # no error if alias is a string
    attr = Attribute(alias='string')
    assert attr.alias == 'string'
    # no error if private is a boolean
    attr = Attribute(private=True)
    assert attr.private == True
    attr = Attribute(private=False)
    assert attr.private == False
    # no error if default is a string
    attr = Attribute(default='string')
    assert attr.default == 'string'
    # no error if default is a callable
    attr

# Generated at 2022-06-23 05:46:51.822407
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    required_object = Attribute(isa="str", default="This is a default value", required=True)
    required_object_1 = Attribute(isa="str", required=True)
    required_object_2 = Attribute(isa="str")

    assert required_object.isa == "str"
    assert required_object.default == "This is a default value"
    assert required_object.required == True
    assert required_object.listof is None
    assert required_object.priority == 0
    assert required_object.class_type is None
    assert required_object.always_post_validate == False
    assert required_object.inherit == True
    assert required_object.alias is None


# Generated at 2022-06-23 05:46:54.399579
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    global Attribute
    Attribute = Attribute(priority=3)
    assert Attribute < Attribute1


# Generated at 2022-06-23 05:46:58.349562
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=3)
    attr2 = Attribute(priority=4)
    attr3 = Attribute(priority=3)
    assert attr1 <= attr2
    assert attr2 >= attr3


# Generated at 2022-06-23 05:47:00.750227
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Purpose: test __eq__ method with equal priority
    # Expectation:  return True
    assert (Attribute(priority=1) == Attribute(priority=1)) == True


# Generated at 2022-06-23 05:47:06.163803
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(default=None, priority=0)
    b = Attribute(default=None, priority=0)
    assert(a == b)

    a = Attribute(default=None, priority=0)
    b = Attribute(default=None, priority=1)
    assert(a != b)



# Generated at 2022-06-23 05:47:15.132757
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute('string')
    assert isinstance(fa, FieldAttribute)
    assert fa.isa == 'string'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False
    assert not hasattr(fa, 'foo')

# Generated at 2022-06-23 05:47:17.918917
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert not Attribute() < Attribute()
    assert Attribute(priority=1) < Attribute(default=2)


# Generated at 2022-06-23 05:47:19.810843
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    a.priority = 10
    b = Attribute()
    b.priority = 20
    assert a < b


# Generated at 2022-06-23 05:47:24.787121
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Test for expected behavior
    a1 = Attribute()
    a2 = Attribute( priority = 1 )
    a3 = Attribute( priority = 0 )

    assert a1.__lt__( a2 ) == False
    assert a1.__lt__( a3 ) == True

    assert a2.__lt__( a1 ) == True
    assert a2.__lt__( a3 ) == True

    assert a3.__lt__( a1 ) == False
    assert a3.__lt__( a2 ) == False

# Generated at 2022-06-23 05:47:34.689895
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

  # Test constructor without arguments
  fa = FieldAttribute()
  assert fa.isa is None
  assert not fa.private
  assert fa.default is None
  assert not fa.required
  assert fa.listof is None
  assert fa.priority == 0
  assert fa.class_type is None
  assert not fa.always_post_validate
  assert fa.inherit
  assert fa.alias is None

  # Test constructor with arguments
  fa = FieldAttribute(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
  assert fa.isa == 1
  assert fa.private == 2
  assert fa.default == 3
  assert fa.required == 4
  assert fa.listof == 5
  assert fa.priority == 6
  assert fa.class_type == 7
  assert fa.always_post

# Generated at 2022-06-23 05:47:38.836032
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    class Class1(object):
        def __init__(self):
            self.attr1 = Attribute()
    class1 = Class1()
    class Class2(object):
        def __init__(self):
            self.attr1 = Attribute()
    class2 = Class2()

    assert class1.attr1 == class2.attr1


# Generated at 2022-06-23 05:47:43.082202
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=1) >= Attribute(priority=2)
    assert Attribute(priority=2) >= Attribute(priority=2)
    assert not Attribute(priority=3) >= Attribute(priority=2)


# Generated at 2022-06-23 05:47:53.832133
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    # test supported arguments
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # test unsupported arguments
   

# Generated at 2022-06-23 05:48:01.477765
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    Fields = {
        'foo': Attribute(default='bar'),
    }

    data = Block.load(
        dict(
            foo='baz',
        ),
        task=Task(),
        role=None,
        loader=None,
        variable_manager=None,
        all_vars=dict(),
    )

    assert data.foo == 'baz'
    assert data._attributes['foo'] == Attribute(default='bar')



# Generated at 2022-06-23 05:48:06.563639
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=0)
    c = Attribute(priority=10)
    assert c >= a  # c.priority = a.priority
    assert b >= a  # b.priority = a.priority
    assert c >= b  # c.priority > b.priority
    assert a >= b  # a.priority > b.priority



# Generated at 2022-06-23 05:48:16.219444
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    new_field_attribute = FieldAttribute(
        isa='string',
        private=False,
        default='',
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    assert new_field_attribute.isa == 'string'
    assert new_field_attribute.default == ''
    assert not new_field_attribute.private
    assert not new_field_attribute.required
    assert new_field_attribute.listof is None
    assert new_field_attribute.priority == 0
    assert new_field_attribute.class_type is None
    assert not new_field_attribute.always_post

# Generated at 2022-06-23 05:48:27.868808
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print("Running test_Attribute___le__")
    attr1 = Attribute()
    attr2 = Attribute()
    if attr1 <= attr2:
        assert False
    attr2.priority = 1    
    if not attr1 <= attr2:
        assert False
    attr1.priority = 2
    if not attr1 <= attr2:
        assert False
    attr2.priority = 2
    if not attr1 <= attr2:
        assert False
    print("test_Attribute___le__ PASSED")


# Generated at 2022-06-23 05:48:31.082013
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    class Attr1(Attribute):
        pass

    class Attr2(Attribute):
        pass

    a1 = Attr1()
    a2 = Attr2()
    assert a1 == a2


# Generated at 2022-06-23 05:48:40.528294
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(isa='list', default={})
        assert False # should have thrown error
    except TypeError:
        pass

    try:
        a = Attribute(isa='dict', default=[1,2,3])
        assert False # should have thrown error
    except TypeError:
        pass

    try:
        a = Attribute(isa='dict', default=(1,2,3))
        assert False # should have thrown error
    except TypeError:
        pass

    try:
        a = Attribute(isa='list', default=(1,2,3))
        assert False # should have thrown error
    except TypeError:
        pass

    try:
        a = Attribute(isa='set', default=[1,2,3])
        assert False # should have thrown error
    except TypeError:
        pass

# Generated at 2022-06-23 05:48:43.492968
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    inp = Attribute()
    state = inp.__ge__(Attribute())
    return state is True


# Generated at 2022-06-23 05:48:49.628352
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(default=[], priority=10)
    a1 = Attribute(default=[], priority=20)
    print('10 is less than 20 : %s' % (a0 < a1))
    print('20 is less than 10 : %s' % (a1 < a0))

if __name__ == '__main__':
    test_Attribute___lt__()

# Generated at 2022-06-23 05:48:57.361193
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test whether Attribute's method __le__ returns the expect result.
    # Test case 1: attribute a and b are equal.
    a = Attribute()
    b = Attribute()
    assert(a.__le__(b))
    # Test case 2: attribute a is less than attribute b.
    a = Attribute(priority = 10)
    b = Attribute()
    assert(a.__le__(b))
    # Test case 3: attribute a is greater than attribute b.
    a = Attribute()
    b = Attribute(priority = 10)
    assert(a.__le__(b))



# Generated at 2022-06-23 05:49:06.782183
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=200,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    b = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=300,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert b > a

# Generated at 2022-06-23 05:49:08.261488
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)


# Generated at 2022-06-23 05:49:16.378727
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa=int, default=7)
    b = Attribute(isa=float, default=7.0)
    c = Attribute(isa=str, default='7')

    assert( a == a )
    assert( b == b )
    assert( c == c )

    assert( a != b )
    assert( a != c )
    assert( b != a )
    assert( b != c )
    assert( c != a )
    assert( c != b )


# Generated at 2022-06-23 05:49:17.882049
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
  assert Attribute(priority=1) > Attribute(priority=0)

# Generated at 2022-06-23 05:49:20.365607
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    test_attr = Attribute(priority=1)
    assert test_attr >= Attribute(priority=2)


# Generated at 2022-06-23 05:49:23.905018
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute = Attribute(priority=0)
    other = Attribute(priority=1)
    assert attribute.__lt__(other)
    assert other.__gt__(attribute)


# Generated at 2022-06-23 05:49:24.822135
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    raise NotImplementedError



# Generated at 2022-06-23 05:49:26.970575
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(
            default=[],
        )
        assert False
    except TypeError:
        pass



# Generated at 2022-06-23 05:49:31.231806
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1 != attr_2, 'failed test_Attribute___ne__'


# Generated at 2022-06-23 05:49:43.713307
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.compat.tests.mock import patch
    from ansible.utils.compat import reload_module

    with patch.dict('sys.modules', {'ansible.errors': reload_module(Attribute)}):
        from ansible.errors import AnsibleError

        test_attribute_obj_1 = Attribute(isa='list', private=True, default=None, required=True, listof='string', priority=1)
        test_attribute_obj_2 = Attribute(isa='list', private=True, default=None, required=True, listof='string', priority=99)
        test_attribute_obj_3 = Attribute(isa='list', private=False, default='[]', required=False, listof='string', priority=0)

# Generated at 2022-06-23 05:49:48.892945
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=2)
    assert a < b
    assert a <= b
    assert b > a
    assert b >= a
    assert c > a
    assert c >= a



# Generated at 2022-06-23 05:49:51.413680
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert (a >= b)


# Generated at 2022-06-23 05:49:55.709244
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    f1 = FieldAttribute(1, 'f1')
    f2 = FieldAttribute(2, 'f2')

    assert f2 <= f1 == False
    assert f1 <= f2 == True
    assert f1 <= f1 == True



# Generated at 2022-06-23 05:50:07.329709
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None,
                          priority=0, class_type=None, always_post_validate=False, inherit=True,
                          alias=None, extend=False, prepend=False)

    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None
    assert attr.extend == False
    assert attr.prepend == False


# The private Attribute

# Generated at 2022-06-23 05:50:10.097984
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=50)
    assert attr >= Attribute(priority=50), "Should be equal and true"


# Generated at 2022-06-23 05:50:19.281414
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    attr4 = Attribute(priority=1)
    assert(attr1.__eq__(attr4))
    assert(not attr2.__eq__(attr1))
    assert(not attr3.__eq__(attr1))


# Generated at 2022-06-23 05:50:25.796235
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    _FieldAttribute = FieldAttribute(isa='string', private=False, default=None, required=False,
                                     listof=None, priority=0, class_type=None, always_post_validate=False,
                                     inherit=True, alias=None, extend=False, prepend=False,
                                     static=False)
    _FieldAttribute.isa
    _FieldAttribute.private
    _FieldAttribute.default
    _FieldAttribute.required
    _FieldAttribute.listof
    _FieldAttribute.priority
    _FieldAttribute.class_type
    _FieldAttribute.always_post_validate
    _FieldAttribute.inherit
    _FieldAttribute.alias
    _FieldAttribute.extend
    _FieldAttribute.prepend
    _FieldAttribute.static
    return _FieldAttribute


# Generated at 2022-06-23 05:50:32.427261
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa==None
    assert field.private==False
    assert field.default==None
    assert field.required==False
    assert field.listof==None
    assert field.priority==0
    assert field.class_type==None
    assert field.always_post_validate==False
    assert field.alias==None
    assert field.extend==False
    assert field.prepend==False
    assert field.static==False
    assert field.inherit==True

# Generated at 2022-06-23 05:50:41.700586
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list',
                     private=False,
                     default='test',
                     required=False,
                     priority=0,
                     class_type='Warn',
                     always_post_validate=False,
                     inherit=True,
                     alias='test_alias')
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.priority == 0
    assert attr.class_type == 'Warn'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'test_alias'



# Generated at 2022-06-23 05:50:42.539987
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.priority == 0

# Generated at 2022-06-23 05:50:46.683547
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    FA = FieldAttribute()
    FA2 = FieldAttribute(priority=1)

    FA__gt__ = FA.__gt__(FA2)
    expected__gt__ = False

    assert FA__gt__ == expected__gt__, 'FA__gt__ != expected__gt__:\nFA__gt__={0}' \
                                       '\nexpected__gt__={1}'.format(FA__gt__, expected__gt__)


# Generated at 2022-06-23 05:50:50.628787
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__gt__(a2)


# Generated at 2022-06-23 05:50:53.847007
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    f1 = FieldAttribute(priority=0)
    f2 = FieldAttribute(priority=9)
    assert f1 <= f2
    assert not f2 <= f1



# Generated at 2022-06-23 05:50:58.554381
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    a.priority = 2
    b.priority = 1

    assert a.__le__(b) == True
    assert b.__le__(a) == False

# Generated at 2022-06-23 05:51:01.571902
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a < b)



# Generated at 2022-06-23 05:51:06.134782
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    if not (a1 >= a1):
        assert False, 'a1 >= a1'
    if not (a2 >= a1):
        assert False, 'a2 >= a1'
    if (a1 >= a2):
        assert False, 'a1 >= a2'
    assert True


# Generated at 2022-06-23 05:51:14.116903
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print("testing __le__ method of class Attribute")
    a = Attribute(priority=10)
    b = Attribute(priority=10)
    # Test case with equal priorities
    if not a.__le__(b):
        raise AssertionError("__le__ method of class Attribute is not working as expected")
    # Test case with a < b
    a.priority = 9
    if not a.__le__(b):
        raise AssertionError("__le__ method of class Attribute is not working as expected")
    # Test case with a > b
    a.priority = 11
    if a.__le__(b):
        raise AssertionError("__le__ method of class Attribute is not working as expected")
    # Test case with a = b
    b.priority = 11

# Generated at 2022-06-23 05:51:16.945240
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert(a.__le__(b))


# Generated at 2022-06-23 05:51:23.536976
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2

    a1.priority = 2
    a2.priority = 3
    assert a1 < a2

    a1.priority = 4
    a2.priority = 3
    assert not a1 < a2

    a1.priority = 3
    a2.priority = 3
    assert not a1 < a2


# Generated at 2022-06-23 05:51:25.259694
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2
    assert not a1 >= a2


# Generated at 2022-06-23 05:51:29.267226
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute('foo', isa='bar')
    assert attr.isa == 'bar'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-23 05:51:38.416330
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    '''
    Test __le__() of class Attribute
    '''
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)

    assert attr1.__le__(attr2) == True
    assert attr1.__le__(attr3) == True
    assert attr2.__le__(attr1) == False
    assert attr2.__le__(attr3) == True
    assert attr3.__le__(attr1) == False
    assert attr3.__le__(attr2) == False


# Generated at 2022-06-23 05:51:43.428580
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=4)
    a2 = Attribute(priority=5)
    assert(a1 > a2)
    assert(a1 < a2)
    assert(a1 <= a2)
    assert(a1 >= a2)
    assert(a1 != a2)
    assert(a2 == a2)



# Generated at 2022-06-23 05:51:53.357549
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.display import Display
    display = Display()

    class AttrTest(AnsibleBaseYAMLObject):
        yaml_tag = u'!attr'

        def __init__(self):
            self._test = None

        def post_validate(self, attr_test, value):
            if not isinstance(value, int):
                raise TypeError('attr_test accepts integers only')

        @property
        def test(self):
            return self._test

        @test.setter
        def test(self, value):
            self._test = value

        # test isa constraint
        test = FieldAttribute(isa='integer')


    obj = AttrTest()


# Generated at 2022-06-23 05:51:55.444610
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=3)
    a2 = Attribute(priority=2)
    assert a1 > a2



# Generated at 2022-06-23 05:51:59.421675
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1, isa="String")
    attr2 = Attribute(priority=2, isa="String")
    result = attr2.__ge__(attr1)
    assert result == True


# Generated at 2022-06-23 05:52:03.970535
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from unit.compat.mock import MagicMock
    from ansible.playbook.attribute import Attribute
    a1 = Attribute()
    a2 = Attribute()
    # a1 <= a2 should be True
    a2.priority = 1
    a1.priority = 0
    assert a1 <= a2


# Generated at 2022-06-23 05:52:14.847114
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # True condition
    attribute1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True)
    attribute2 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True)
    assert attribute1.__eq__(attribute2) is True
    # False condition
    attribute1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True)

# Generated at 2022-06-23 05:52:22.653603
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_attributes = FieldAttribute(isa="list", required=True)
    required_list_attributes = FieldAttribute(isa="list", listof="str", required=True)
    optional_attributes = FieldAttribute(isa="dict", default={})
    non_required_list_attributes_with_default = FieldAttribute(isa="list", listof="str", required=False, default=[])
    required_list_attributes_with_default = FieldAttribute(isa="list", listof="str", required=True, default=[1, 2, 3])
    required_list_with_priority = FieldAttribute(isa="list", listof="str", required=True, default=[1, 2, 3], priority=10)