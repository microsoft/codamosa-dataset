

# Generated at 2022-06-23 05:42:22.451493
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    desc = "This is a field attribute test"
    fa = FieldAttribute(isa='str', default=desc, required=True, always_post_validate=True, inherit=False)
    assert fa.isa == 'str'
    assert fa.default == desc
    assert fa.required
    assert fa.always_post_validate
    assert not fa.inherit



# Generated at 2022-06-23 05:42:28.322051
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # lt == less than
    # The higher the priority, the sooner it is parsed.
    # Priority is a positive or negative integer.
    # The default priority is 0, which is defined in this constructor.
    a = Attribute()
    b = Attribute(priority=10)
    c = Attribute(priority=-1)
    d = Attribute()
    assert a < b
    assert b > a
    assert b > c
    assert c < b
    assert a == d

# Generated at 2022-06-23 05:42:35.514689
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    class A(Attribute):
        pass
    a1 = A()
    a2 = A()

    assert(a1.__le__(a2) == True)
    assert(a1.__ge__(a2) == True)
    assert(a1.__lt__(a2) == False)
    assert(a1.__gt__(a2) == False)
    assert(a1.__eq__(a2) == True)
    assert(a1.__ne__(a2) == False)

    a1.priority = 2
    a2.priority = 2
    assert(a1.__le__(a2) == True)
    assert(a1.__ge__(a2) == True)
    assert(a1.__lt__(a2) == False)

# Generated at 2022-06-23 05:42:39.457617
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa='string', private=True, default=None, required=True, listof='list', priority=0, class_type='class', always_post_validate=True, inherit=False, alias='new_name', extend=True, prepend=True, static=True)


# Generated at 2022-06-23 05:42:45.130860
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # test non-equal comparison
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a < b)
    # test equal comparison
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert(not (a < b))


# Generated at 2022-06-23 05:42:48.525387
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(isa=int, private=True, default=10, required=True, priority=2)
    assert FA.isa == int
    assert FA.private == True
    assert FA.default == 10
    assert FA.required == True
    assert FA.listof == None
    assert FA.priority == 2



# Generated at 2022-06-23 05:42:50.566346
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)

    assert(a.__le__(b))

# Generated at 2022-06-23 05:42:58.055901
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', required=True, priority=1)
    b = Attribute(isa='str', required=False, priority=1)
    c = Attribute(isa='int', required=False, priority=1)
    assert (a != b)
    assert (a != c)
    assert (b != c)
    assert (a == b) == False
    assert (a == c) == False
    assert (b == c) == False
    assert (a != b) == True
    assert (a != c) == True
    assert (b != c) == True
    assert (a == b) == False
    assert (a == c) == False
    assert (b == c) == False



# Generated at 2022-06-23 05:43:08.354349
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Testing FieldAttribute constructor")
    args={'isa': 'test',
          'private': False,
          'default': 'test',
          'required': False,
          'listof': 'test',
          'priority': 0,
          'class_type': 'test',
          'always_post_validate': False,
          'inherit': True,
          'alias': 'test',
          'extend': False,
          'prepend': False,
          'static': False,
          }
    f = FieldAttribute(**args)
    assert f.isa == args.get('isa')
    assert f.private == args.get('private')
    assert f.default == args.get('default')
    assert f.required == args.get('required')
    assert f.listof == args.get('listof')


# Generated at 2022-06-23 05:43:12.235487
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a <= b)


# Generated at 2022-06-23 05:43:14.363773
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    class Attribute(Attribute):
        def __le__(self, other):
            return True

    attr = Attribute()
    assert attr <= Attribute()



# Generated at 2022-06-23 05:43:17.078095
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    assert b >= a


# Generated at 2022-06-23 05:43:27.121083
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=list(), required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == list()
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    # TODO: check __eq__, __ne__, __lt__, __gt__, __le__, __ge__
    assert True

# Generated at 2022-06-23 05:43:36.218205
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    # Assert that:
    #    Attribute(priority=1) < Attribute(priority=0)
    # is true.

    # Assert that:
    #    Attribute(priority=1) <= Attribute(priority=1)
    # is true.

    # Assert that:
    #    Attribute(priority=0) < Attribute(priority=1)
    # is false.

    # Assert that:
    #    Attribute(priority=0) <= Attribute(priority=1)
    # is false.
    assert Attribute(priority=1) <= Attribute(priority=1)


# Generated at 2022-06-23 05:43:39.795246
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    gt = FieldAttribute()
    gt.priority = 5
    lt = FieldAttribute()
    lt.priority = 3
    assert gt > lt


# Generated at 2022-06-23 05:43:42.752406
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert (attr1 <= attr2)


# Generated at 2022-06-23 05:43:44.634728
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field = Attribute()
    field.priority = 1
    assert(field != 2)



# Generated at 2022-06-23 05:43:46.529747
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute(priority=0)) == True


# Generated at 2022-06-23 05:43:55.100446
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    aa = Attribute()
    bb = Attribute()

    # test: aa.priority == bb.priority
    aa.priority = 2
    bb.priority = 2
    if not (aa <= bb):
        raise AssertionError()
    if not (bb <= aa):
        raise AssertionError()

    # test: aa.priority < bb.priority
    aa.priority = 2
    bb.priority = 3
    if not (aa <= bb):
        raise AssertionError()
    if (bb <= aa):
        raise AssertionError()

    # test: aa.priority > bb.priority
    aa.priority = 3
    bb.priority = 2
    if (aa <= bb):
        raise AssertionError()

# Generated at 2022-06-23 05:43:59.339029
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Attribute __lt__ returns True
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    if attribute_1.__lt__(attribute_2):
        assert True
    else:
        assert False



# Generated at 2022-06-23 05:44:09.374259
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa="test", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == "test"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None



# Generated at 2022-06-23 05:44:12.107503
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__lt__(attr1)


# Generated at 2022-06-23 05:44:14.034527
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    assert attr.__ne__(attr)



# Generated at 2022-06-23 05:44:18.716655
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority = 9)
    b = Attribute(priority = 10)
    result = a.__lt__(b)
    expected = False
    assert result == expected

# Generated at 2022-06-23 05:44:21.279749
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=10) == Attribute(priority=10)
    assert not Attribute(priority=1) == Attribute(priority=2)


# Generated at 2022-06-23 05:44:29.678918
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(default=0, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    other = Attribute(default=0, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    result = attribute.__ge__(other)
    expected = True
    assert result == expected, 'Test failed: got %s instead of %s' % (str(result),str(expected))


# Generated at 2022-06-23 05:44:33.235911
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # TODO: Remove this unit test when method __eq__ is removed from class Attribute
    assert Attribute(alias='abc') == Attribute(alias='abc')
    assert Attribute(alias='abc') != Attribute(alias='def')

# Generated at 2022-06-23 05:44:37.603222
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 > attr1
    assert attr1 < attr2
    assert attr1 <= attr2
    assert attr2 >= attr1



# Generated at 2022-06-23 05:44:39.237312
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list')
    assert f.isa == 'list'

# Generated at 2022-06-23 05:44:44.851637
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=0)
    assert attr.__eq__(attr)
    assert attr.__ne__(attr)
    assert attr.__lt__(attr)
    assert attr.__gt__(attr)
    assert attr.__le__(attr)
    assert attr.__ge__(attr)


# Generated at 2022-06-23 05:44:54.091843
# Unit test for constructor of class Attribute
def test_Attribute():
    def func():
        pass

    f = FieldAttribute(isa="bool", default=True, class_type="Group")
    assert f.isa == "bool"
    assert f.private is False
    assert f.default is True
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type == "Group"
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None
    assert f.extend is False
    assert f.prepend is False
    assert f.static is False

    # Ensure that we don't allow mutable default values.
    try:
        Attribute(isa="list", default=[])
    except TypeError:
        pass

    # Test that the special constructor function is supported


# Generated at 2022-06-23 05:45:01.387062
# Unit test for constructor of class Attribute
def test_Attribute():
    attr=Attribute(isa="list", inherit=False, alias="connection")
    assert attr
    try:
        attr=Attribute(isa="list", inherit=False, alias="connection", default=[])
        assert False # Attribute constructor should fail for mutable defaults
    except TypeError:
        pass
    try:
        attr=Attribute(isa="list", inherit=False, alias="connection", default=set())
        assert False # Attribute constructor should fail for mutable defaults
    except TypeError:
        pass

test_Attribute()

# Generated at 2022-06-23 05:45:04.176686
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)

    assert a > b


# Generated at 2022-06-23 05:45:05.396290
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    assert attr.__ne__(0) == 1

# Generated at 2022-06-23 05:45:17.322063
# Unit test for constructor of class Attribute
def test_Attribute():
    from types import FunctionType, MethodType

    # simple test
    assert Attribute(isa=bool).isa is bool

    # test list (ensuring immutability)
    a = Attribute(default=lambda: [])
    assert isinstance(a.default, FunctionType)
    assert a.default() == []
    assert a.default() is not a.default()

    # test dict (ensuring immutability)
    a = Attribute(default=lambda: {})
    assert isinstance(a.default, FunctionType)
    assert a.default() == {}
    assert a.default() is not a.default()

    # test callable
    a = Attribute(default=list)
    assert a.default is list

    # test non-callable

# Generated at 2022-06-23 05:45:20.392979
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_a = Attribute(priority=1)
    attr_b = Attribute(priority=2)
    assert attr_b < attr_a

# Generated at 2022-06-23 05:45:24.499521
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field_attribute = FieldAttribute()
    field_attribute.priority = 1
    assert field_attribute.__gt__(Attribute(priority=2))
    assert not field_attribute.__gt__(Attribute(priority=1))
    assert not field_attribute.__gt__(Attribute(priority=0))

test_Attribute___gt__()



# Generated at 2022-06-23 05:45:27.885783
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(listof='str', default=[])
    except TypeError as err:
        assert 'may not be mutable' in str(err)



# Generated at 2022-06-23 05:45:29.540923
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    assert(a > b)


# Generated at 2022-06-23 05:45:39.087353
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa = None,
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False
    )

    assert attribute.isa is None
    assert not attribute.private
    assert attribute.default is None
    assert not attribute.required
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert not attribute.always_post_validate
    assert attribute.inherit
    assert attribute.alias is None
    assert not attribute.extend
    assert not attribute.prepend
   

# Generated at 2022-06-23 05:45:51.002933
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test all constructors
    attr = Attribute()
    attr_b = Attribute(isa='bool', private=True, required=True, always_post_validate=True)
    attr_c = Attribute(listof='dict')

    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

    assert attr_b.isa == 'bool'
    assert attr_b.private is True
    assert attr_b.default is None
    assert att

# Generated at 2022-06-23 05:45:55.374358
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa="file", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

# Generated at 2022-06-23 05:46:00.930020
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1 == a2
    assert not a1 != a2
    a3 = Attribute(priority=1)
    assert a3 != a1 and a3 != a2
    assert a1 != a3 and a2 != a3


# Generated at 2022-06-23 05:46:04.403505
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=12)
    attr2 = Attribute(priority=11)
    assert attr2.priority != attr.priority

# Generated at 2022-06-23 05:46:05.972536
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute()


# Generated at 2022-06-23 05:46:08.323361
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    A = Attribute()
    B = Attribute()
    assert (A == B) == (B == A)


# Generated at 2022-06-23 05:46:12.124149
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert not Attribute(priority=10) != Attribute(priority=10), 'Priorities should be compared as "equal" in __ne__'
    assert Attribute(priority=9) != Attribute(priority=10), 'Priorities should be compared as "not equal" in __ne__'

# Generated at 2022-06-23 05:46:15.245699
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_one = Attribute(priority=5)
    attr_two = Attribute(priority=2)
    assert attr_one.priority > attr_two.priority

# Generated at 2022-06-23 05:46:17.928104
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=10)
    assert a1 >= a2
    assert a2 >= a1



# Generated at 2022-06-23 05:46:28.281936
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # For all these tests lower-case 'test' means constructor test
    #   and upper-case 'test' means test for the created object
    # FieldAttribute() is invalid because isa must be defined
    try:
        Attribute()
        assert False
    except KeyError:
        pass

    # FieldAttribute(listof=None)
    test = Attribute(listof=None)
    assert test.listof is None

    # FieldAttribute(listof='str')
    test = Attribute(listof='str')
    assert test.listof == 'str'

    # # FieldAttribute(listof=['str']) is invalid because 'listof' must be a string
    try:
        Attribute(listof=['str'])
        assert False
    except TypeError:
        pass

    # FieldAttribute(default='str')


# Generated at 2022-06-23 05:46:31.549857
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    '''
    Ensure that Attribute class __ne__() method works correctly.
    '''
    a = Attribute()
    b = Attribute()
    
    assert a.__ne__(b) == False

# Generated at 2022-06-23 05:46:35.471159
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_left = Attribute()
    attr_right = Attribute()
    attr_left.priority = 1
    attr_right.priority = 1
    assert attr_left.__ge__(attr_right) == True

__all__ = ['Attribute', 'FieldAttribute']

# Generated at 2022-06-23 05:46:36.518164
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert True is not False


# Generated at 2022-06-23 05:46:41.226418
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # create object
    obj = Attribute()
    # init object
    obj.priority = 1
    # create object
    obj1 = Attribute()
    # init object
    obj1.priority = 2
    # compare
    assert obj1 >= obj


# Generated at 2022-06-23 05:46:51.600939
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.errors import AnsibleError

    # Default Attribute without any initialization
    a = Attribute()
    print("Attribute: %s" % a)

    # Construct Attribute using all available keywords
    a = Attribute(isa="list", private=False, \
                  default="default", required=False, listof="dict", priority=0, class_type=dict, \
                  always_post_validate=False, inherit=True, alias="alias_name")
    print("Attribute: %s" % a)

    # Construct Attribute using isa and listof keywords
    a = Attribute(isa="list", listof="dict")
    print("Attribute: %s" % a)

    # Construct Attribute using isa, listof and class_type keywords

# Generated at 2022-06-23 05:46:54.191785
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = Attribute()
    field2 = Attribute()
    assert field1 == field2



# Generated at 2022-06-23 05:46:55.220155
# Unit test for method __eq__ of class Attribute

# Generated at 2022-06-23 05:47:04.485886
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict')
    assert attr.isa=='dict'
    assert not attr.private
    assert not attr.extend
    assert attr.prepend == False
    attr = Attribute(isa='dict', private=True, extend=True, prepend=False)
    assert attr.isa=='dict'
    assert attr.private
    assert attr.extend
    assert attr.prepend == False
    attr = Attribute(isa='list')
    assert attr.isa=='list'
    assert not attr.private
    assert not attr.extend
    assert attr.prepend == False
    attr = Attribute(isa='bool')
    assert attr.isa=='bool'
    assert not attr.private
    assert not attr.ext

# Generated at 2022-06-23 05:47:08.388982
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    args = [
            ('a', 'b'),
            ('b', 'a'),
            ('a', 'a'),
            ]
    expected = [
            False,
            True,
            False,
            ]
    for i in range(len(args)):
        assert Attribute(priority=args[i][0]) < Attribute(priority=args[i][1]) == expected[i]

# Generated at 2022-06-23 05:47:20.043319
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    global_attributes = {
        'priority' : 0,
        'isa' : 'str',
        'private' : False,
        'default' : 'localhost',
        'required' : False,
        'listof' : None,
        'class_type' : None,
        'always_post_validate' : False,
        'inherit' : True,
        'alias' : None,
        'extend' : False,
        'prepend' : False,
        'static' : False,
    }

# Generated at 2022-06-23 05:47:24.035190
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print(Attribute(priority=2) <=  Attribute(priority=2))
    print(Attribute(priority=3) <=  Attribute(priority=2))
    print(Attribute(priority=1) <=  Attribute(priority=2))

#test_Attribute___le__()


# Generated at 2022-06-23 05:47:25.928463
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    assert not attribute.__ne__(attribute)



# Generated at 2022-06-23 05:47:29.721046
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert FieldAttribute(priority=0) < FieldAttribute(priority=1)
    assert not (FieldAttribute(priority=0) < FieldAttribute(priority=0))
    assert not (FieldAttribute(priority=1) < FieldAttribute(priority=0))


# Generated at 2022-06-23 05:47:33.535678
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=10)
    assert attr1.__eq__(attr2)


# Generated at 2022-06-23 05:47:34.638165
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()



# Generated at 2022-06-23 05:47:38.474740
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    default_priority = 0
    # negative priority
    a = Attribute(priority=-1)
    assert a <= Attribute()
    # positive priority
    b = Attribute(priority=1)
    assert b >= Attribute()
    print("test_Attribute___le__() passed")



# Generated at 2022-06-23 05:47:41.228625
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)
    assert not Attribute(priority=2) == Attribute(priority=1)


# Generated at 2022-06-23 05:47:43.481459
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=10)
    assert a1 > a2

# Generated at 2022-06-23 05:47:51.078825
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    attr3 = Attribute(priority=1)

    assert attr1 == attr2
    assert attr1 <= attr2
    assert attr1 >= attr2

    assert attr1 < attr3
    assert attr1 <= attr3
    assert attr1 != attr3
    assert attr1 >= attr3



# Generated at 2022-06-23 05:47:59.035831
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # 1. Create instance of FieldAttribute with default parameters
    a1 = Attribute()
    # 2. Create instance of FieldAttribute with priority = -1
    a2 = Attribute(priority=-1)
    # 3. Create instance of FieldAttribute with priority = 1
    a3 = Attribute(priority=1)
    # 4. Test __ne__()
    #    Test1: compare a1 and a2, expected result True
    #    Test2: compare a1 and a1, expected result False
    #    Test3: compare a2 and a3, expected result True
    assert (a1 != a2)
    assert (a1 != a1)
    assert (a2 != a3)

# Generated at 2022-06-23 05:48:02.503306
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    a1 = Attribute(priority=1)
    # True
    assert a1.__ge__(a) == True



# Generated at 2022-06-23 05:48:07.492166
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute(priority=0)
    a3 = Attribute(priority=1)
    assert a1 == a2
    assert a2 != a3


# Generated at 2022-06-23 05:48:11.221768
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr_1 = Attribute()
    attr_1.priority = 1
    attr_2 = Attribute()
    attr_2.priority = 1
    assert (attr_1 == attr_2)


# Generated at 2022-06-23 05:48:13.103603
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.__class__ == FieldAttribute
    return a


# Generated at 2022-06-23 05:48:16.879088
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(isa='list', default=['a', 'b'])
    except TypeError:
        pass
    else:
        raise AssertionError("Did not raise TypeError")


# Generated at 2022-06-23 05:48:19.983887
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(None)
    assert True

# Generated at 2022-06-23 05:48:25.873400
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    f1 = Attribute()
    f2 = Attribute()
    f3 = Attribute()

    f1.priority = 3
    f2.priority = 2
    f3.priority = 3

    assert f1 <= f2
    assert f1 <= f3
    assert not f2 <= f1
    assert not f3 <= f1



# Generated at 2022-06-23 05:48:33.633680
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', inherit=False, extend=False, prepend=False)
    assert attr.isa == 'dict'
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is False
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False



# Generated at 2022-06-23 05:48:39.131234
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a_first = Attribute(priority=100)
    a_second = Attribute(priority=100)
    a_third = Attribute(priority=101)
    assert a_first == a_second
    assert not a_first == a_third

test_Attribute___eq__()


# Generated at 2022-06-23 05:48:43.267179
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=0) >= Attribute(priority=20)
    assert not Attribute(priority=21) >= Attribute(priority=20)
    assert Attribute(priority=20) >= Attribute(priority=20)



# Generated at 2022-06-23 05:48:46.810471
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=10)
    attribute2 = Attribute(priority=20)
    assert(attribute2.__ge__(attribute1))


# Generated at 2022-06-23 05:48:57.448035
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with all arguments
    field = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, inherit=True)
    assert field.isa == 'list'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.inherit == True

    # Test with no arguments
    field = FieldAttribute()
    assert field.isa == None
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.inherit == True

    # Test with most arguments

# Generated at 2022-06-23 05:48:59.203016
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute()


# Generated at 2022-06-23 05:49:05.883805
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_fst = Attribute(priority=1)
    attr_snd = Attribute(priority=2)
    assert attr_fst <= attr_fst
    assert attr_fst <= attr_snd
    assert not attr_fst == attr_snd
    assert not attr_fst >= attr_snd

#######################################
# METHODS
#######################################


# Generated at 2022-06-23 05:49:09.717426
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=3)
    b = Attribute(priority=5)
    assert a < b


# Generated at 2022-06-23 05:49:13.855919
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=10)
    c = Attribute(priority=5)
    assert a < b
    assert a <= c
    assert not a < c

# Generated at 2022-06-23 05:49:17.986452
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    obj1 = Attribute()
    obj2 = Attribute()
    obj1.priority = 1
    obj2.priority = 2
    assert obj2.__gt__(obj1)

# Generated at 2022-06-23 05:49:22.957991
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    c = Attribute()
    e = Attribute()
    a.priority = 1
    b.priority = 1
    c.priority = 2
    e.priority = 1
    assert a != b
    assert b != c
    assert c != b
    assert a == e

# Generated at 2022-06-23 05:49:32.651963
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr0 = Attribute()
    attr1 = Attribute()

    # test for the case that priority number of attr0 is higher than that of attr1
    attr0.priority = 1
    attr1.priority = 0
    assert (attr0 >= attr1)
    assert (attr1 <= attr0)

    # test for the case that priority number of attr0 is lower than that of attr1
    attr0.priority = 0
    attr1.priority = 1
    assert (attr0 <= attr1)
    assert (attr1 >= attr0)

    # test for the case that priority number of attr0 is equal to that of attr1
    attr0.priority = 1
    attr1.priority = 1
    assert (attr0 <= attr1)

# Generated at 2022-06-23 05:49:33.191923
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()

# Generated at 2022-06-23 05:49:41.148077
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) > Attribute(priority=2)
    assert Attribute(priority=2) < Attribute(priority=3)
    assert not Attribute(priority=1) < Attribute(priority=2)
    assert not Attribute(priority=2) > Attribute(priority=3)
    assert not Attribute(priority=1) > Attribute(priority=2)
    assert not Attribute(priority=2) < Attribute(priority=3)


# Generated at 2022-06-23 05:49:53.476919
# Unit test for constructor of class Attribute
def test_Attribute():

    # Calls constructor with keyword arguments
    attr = Attribute(isa="dict",
                     private=True,
                     default=None,
                     required=False,
                     listof=None,
                     priority=0,
                     class_type=None,
                     always_post_validate=False,
                     inherit=True,
                     alias=None,
                     extend=False,
                     prepend=False,
                     static=False)

    assert attr.isa == "dict"
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True

# Generated at 2022-06-23 05:49:56.590292
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)


# Generated at 2022-06-23 05:49:59.760461
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority = 0)
    assert a == a
    assert not a != a
    assert a == Attribute(priority = 0)



# Generated at 2022-06-23 05:50:10.740831
# Unit test for constructor of class Attribute
def test_Attribute():
    field1 = Attribute("string", "test_private", "test_default", "test_required",
        "listof", "test_priority", "test_class_type", "test_always_post_validate",
        "test_inherit")
    assert field1.isa == "string"
    assert field1.private == "test_private"
    assert field1.default == "test_default"
    assert field1.required == "test_required"
    assert field1.listof == "listof"
    assert field1.priority == "test_priority"
    assert field1.class_type == "test_class_type"
    assert field1.always_post_validate == "test_always_post_validate"
    assert field1.inherit == "test_inherit"



# Generated at 2022-06-23 05:50:24.471463
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor
    test_attr = Attribute(isa='list', private=False, default=['hello'], required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert test_attr.isa == 'list'
    assert test_attr.private == False
    assert test_attr.default == ['hello']
    assert test_attr.required == False
    assert test_attr.listof == 'str'
    assert test_attr.priority == 0
    assert test_attr.class_type == None
    assert test_attr.always_post_validate == False
    assert test_attr.inherit == True
    assert test_attr.alias == None

    # Test default value cannot be mutable
    #assert_raises(ValueError

# Generated at 2022-06-23 05:50:30.823332
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a_field_attribute = FieldAttribute()
    # if priorities of either self or other are not set then return False always
    assert a_field_attribute.__ne__(a_field_attribute) is False
    # if priorities of either self or other are set then return False if priorities are equal, True if priorities are not equal
    b_field_attribute = FieldAttribute()
    b_field_attribute.priority = 1
    assert a_field_attribute.__ne__(b_field_attribute) is True

# Generated at 2022-06-23 05:50:33.373885
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()

    with pytest.raises(NotImplementedError):
        a.__ge__(Attribute())

# Generated at 2022-06-23 05:50:35.762251
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a.__ne__(b)


# Generated at 2022-06-23 05:50:44.819472
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Defaults
    fa = FieldAttribute()
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    # With arguments
    fa = FieldAttribute(
        isa = 'boolean',
        private = 'Nope',
        default = "Voyage",
        required = 'True',
        listof = 'string',
        priority = 10,
        class_type = 'NoClass',
        always_post_validate = 'Yes',
        inherit = 'False',
        alias = 'Emma'
    )
    assert fa.isa == 'boolean'
    assert fa

# Generated at 2022-06-23 05:50:48.007119
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    class test_object(object):
        test_value = Attribute()

    t = test_object()
    t.test_value.priority = 5
    t2 = test_object()
    t2.test_value.priority = 5

    # Test if result is boolean
    assert isinstance((t.test_value == t2.test_value),bool)


# Generated at 2022-06-23 05:50:53.548125
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    test_a = Attribute()
    test_b = Attribute()
    test_1 = Attribute(priority = 1)
    test_2 = Attribute(priority = 2)
    assert test_a == test_b
    assert test_1 != test_2
    assert test_2 != test_1


# Generated at 2022-06-23 05:50:58.174516
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(default=1, priority=1)
    b = Attribute(default=2, priority=2)
    assert a >= b


# Generated at 2022-06-23 05:51:06.669360
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a=Attribute(priority=1)
    b=Attribute(priority=2)
    #c=Attribute(priority=1)
    #d=Attribute(priority=1)
    assert b > a
    #assert c >= a
    #assert not c == d
    #assert c <= a
    #assert a != b
    #assert d < b
    #assert a <= b
    #assert b >= a
    #assert not b < a
    #assert not a > b
    #assert not b == a
    #assert a != b
    #assert not a == c
    #assert a < b
    #assert c <= b
    #assert not b <= a
    #assert not a >= b
    #assert not a == b
    #assert not a < c
    #assert not c > a
    #assert a <= c
   

# Generated at 2022-06-23 05:51:09.603053
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 0)
    assert a.__ge__(b)



# Generated at 2022-06-23 05:51:12.053204
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__lt__(b) == False
    assert b.__lt__(a) == True



# Generated at 2022-06-23 05:51:16.388644
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # The purpose of this test is to ensure if one of the attributes of the compared Attributes is None,
    # it will be assigned the default value, i.e. 0.
    test_Attribute = Attribute(priority=1)
    test_other_Attribute = Attribute()
    assert test_Attribute.__le__(test_other_Attribute)
    assert test_other_Attribute.__le__(test_Attribute)



# Generated at 2022-06-23 05:51:20.504276
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=5)
    assert attr1.__gt__(attr2) == True
    assert attr2.__gt__(attr1) == False


# Generated at 2022-06-23 05:51:31.579558
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from datetime import datetime
    from ansible.parsing.vault import VaultLib
    # Case when self.priority >= other.priority
    self = Attribute(isa = 'bool')
    other = Attribute (isa = 'bool', priority = 0)
    assert self.__ge__(other) == True
    # Case when self.priority < other.priority
    self = Attribute(isa = 'bool', priority = 0)
    other = Attribute (isa = 'bool')
    assert self.__ge__(other) == False
    # Case when self.priority == other.priority
    self = Attribute(isa = 'bool', priority = 0)
    other = Attribute (isa = 'bool', priority = 0)
    assert self.__ge__(other) == True
    # Case when self.priority is not integer
    self

# Generated at 2022-06-23 05:51:34.381358
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    >>> a = Attribute()
    >>> b = Attribute(priority=1)
    >>> a < b
    True
    """


# Generated at 2022-06-23 05:51:35.863959
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    pass #FIXME: implement your test here


# Generated at 2022-06-23 05:51:46.140021
# Unit test for constructor of class Attribute
def test_Attribute():
    args = {
        'private': False,
        'default': None,
        'required': False,
        'listof': None,
        'priority': 0,
        'always_post_validate': False,
        'inherit': True,
        'extend': False,
        'prepend': False,
        'static': False,
    }

    a1 = Attribute('int', alias='a1_alias')
    a2 = Attribute('int', **args)
    a3 = Attribute('int', **args)

    assert a1.alias == 'a1_alias'
    assert a1.isa == 'int'

    assert a2.alias is None
    assert a2.isa == 'int'
    assert a2.private == False
    assert a2.default == None

# Generated at 2022-06-23 05:51:49.024365
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert(Attribute(priority=1) < Attribute(priority=2))
    assert(not Attribute(priority=1) < Attribute(priority=1))
    assert(not Attribute(priority=2) < Attribute(priority=1))

# Generated at 2022-06-23 05:51:57.019770
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='dict', private=False, default={}, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    b = Attribute(isa='dict', private=False, default={}, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-23 05:52:01.661296
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        test_attr = Attribute(isa='list', default=[])
        assert False
    except TypeError:
        pass
    test_attr = Attribute(isa='list', default=lambda: [])
    assert test_attr.isa == 'list'
    assert test_attr.default() == []



# Generated at 2022-06-23 05:52:04.354153
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    a.priority = 0
    assert a<=b

    b.priority = 1
    assert b>=a


# Generated at 2022-06-23 05:52:07.285385
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a.__le__(b) == True


# Generated at 2022-06-23 05:52:16.591823
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    # Execute the code to be tested
    attribute0 = Attribute(priority=0)
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)

    # Check the result
    assert attribute1 == attribute1
    assert attribute1 != attribute2
    assert attribute2 > attribute1
    assert attribute1 < attribute2
    assert attribute2 >= attribute1
    assert attribute1 <= attribute2

    # check aliases
    assert attribute1 == AnsibleUnsafeText(attribute1)
    assert attribute1 == AnsibleUnsafeBytes(attribute1)

# Generated at 2022-06-23 05:52:21.608769
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    #Given
    f1 = Attribute(priority=0)
    f2 = Attribute(priority=1)
    #When
    result = f2.__ne__(f1)
    #Then
    assert result == True
