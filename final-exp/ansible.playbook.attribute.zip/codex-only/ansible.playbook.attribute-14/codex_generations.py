

# Generated at 2022-06-23 05:42:19.453311
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert (a1 == a2) is True
    a2.priority = 1
    assert (a1 == a2) is False

# Generated at 2022-06-23 05:42:20.773997
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute().__ne__(Attribute())


# Generated at 2022-06-23 05:42:26.451146
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute(
        priority=3
    )
    y = Attribute(
        priority=4
    )
    assert(y.__ne__(x) == True)
    assert(x.__ne__(x) == False)
    assert(x.__ne__(y) == False)
    assert(y.__ne__(y) == False)


# Generated at 2022-06-23 05:42:27.432420
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()



# Generated at 2022-06-23 05:42:28.220678
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: add tests here
    assert True

# Generated at 2022-06-23 05:42:30.244233
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute()
    attr.priority = 10
    assert attr.__lt__(Attribute(5)) == True

# Generated at 2022-06-23 05:42:34.816233
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a0 > a1
    assert a0 > a2
    assert a1 < a0
    assert a1 < a2
    assert a2 < a0
    assert a2 < a1



# Generated at 2022-06-23 05:42:40.467382
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    other = Attribute(priority=0)
    assert (attr == other) is True
    other = Attribute(priority=1)
    assert (attr == other) is False


# Generated at 2022-06-23 05:42:42.739084
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=5)
    b = Attribute(priority=4)
    if not a.__ge__(b):
        raise Exception("Failed test for method __ge__ of class Attribute")



# Generated at 2022-06-23 05:42:46.189698
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        class_ = Attribute(isa='test', required=True, default=[], inherit=False, class_type=type)
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute: Invalid default should cause TypeError')



# Generated at 2022-06-23 05:42:48.038804
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='foo')

    if attr.isa != 'foo':
        raise Exception('Error: FieldAttribute')



# Generated at 2022-06-23 05:42:50.805393
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = FieldAttribute()
    attr2 = FieldAttribute()
    attr3 = FieldAttribute(priority=1)
    assert attr == attr2
    assert not attr == attr3


# Generated at 2022-06-23 05:42:52.033117
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    print(f)


# Generated at 2022-06-23 05:42:56.709871
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(default='test_default', always_post_validate=True)
    attr2 = Attribute(default='test_default', always_post_validate=True)
    print ("attr1==attr2? {}".format(attr1==attr2))
    print ("attr1 is attr2? {}".format(attr1 is attr2))


# Generated at 2022-06-23 05:42:59.371212
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority=10)
    attribute_2 = Attribute(priority=12)
    assert attribute_1 <= attribute_2


# Generated at 2022-06-23 05:43:02.657916
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=3)
    assert a1.__ne__(Attribute(priority=5)) != False
    assert a1.__ne__(Attribute(priority=3)) == False

# Generated at 2022-06-23 05:43:04.294822
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute is not None

# Test that we can inherit from FieldAttribute

# Generated at 2022-06-23 05:43:06.344277
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from ansible.playbook.attribute import Attribute, FieldAttribute
    assert Attribute() >= FieldAttribute()


# Generated at 2022-06-23 05:43:10.651329
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert (a <= b)

    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert (a <= b)


# Generated at 2022-06-23 05:43:21.342253
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    x = Attribute(isa = 'list', private = False, default = None, required = False, listof = None, priority = 2, class_type = None, always_post_validate = False, inherit = True, alias = None, extend = False, prepend = False, static = False)
    y = Attribute(isa = 'list', private = False, default = None, required = False, listof = None, priority = 1, class_type = None, always_post_validate = False, inherit = True, alias = None, extend = False, prepend = False, static = False)
    if x < y:
        print("Test FAILED")
    else:
        print("Test PASSED")



# Generated at 2022-06-23 05:43:26.880960
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)

    assert (attr3 < attr2)
    assert not (attr2 < attr2)
    assert (attr1 < attr2)
    assert not (attr2 < attr1)


# Generated at 2022-06-23 05:43:31.171702
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_object = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, extend=False, prepend=False)
    assert attribute_object is not None
    assert attribute_object.isa == 'dict'
    assert type(attribute_object) == Attribute

# Generated at 2022-06-23 05:43:33.110977
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=10) >= Attribute(priority=10)


# Generated at 2022-06-23 05:43:34.806751
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority = 3)
    b = Attribute(priority = 5)
    assert (a < b)


# Generated at 2022-06-23 05:43:44.404196
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.alias is None
    assert attr.inherit == True
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    attr = Attribute(isa='list')
    assert attr.isa == 'list'

    attr = Attribute(isa='int', priority=5)
    assert attr.isa == 'int'
    assert attr.priority == 5


# Generated at 2022-06-23 05:43:54.761652
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(default={})
        assert False, "Attribute constructor didn't fail with a mutable type"
    except Exception as e:
        pass
    try:
        Attribute(default=set())
        assert False, "Attribute constructor didn't fail with a mutable type"
    except Exception as e:
        pass
    try:
        Attribute(default=list())
        assert False, "Attribute constructor didn't fail with a mutable type"
    except Exception as e:
        pass
    try:
        Attribute(default=dict())
        assert False, "Attribute constructor didn't fail with a mutable type"
    except Exception as e:
        pass
    Attribute(default=lambda: [])
    Attribute(default=lambda: {})
    Attribute(default=lambda: set())

# Generated at 2022-06-23 05:44:01.107251
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default='test')
    except TypeError:
        pass
    else:
        raise AssertionError("FieldAttribute(default='test') did not raise an exception")
    try:
        FieldAttribute(default=['test'])
    except TypeError:
        pass
    else:
        raise AssertionError("FieldAttribute(default=['test']) did not raise an exception")



# Generated at 2022-06-23 05:44:04.206097
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    obj1 = Attribute(priority=1)
    obj2 = Attribute(priority=2)
    obj3 = Attribute(priority=1)

    # obj2 is greater than obj1
    assert obj2 >= obj1

    # obj1 is less than obj2
    assert obj1 < obj2

    # obj1 is equal to obj3
    assert obj1 >= obj3


# Generated at 2022-06-23 05:44:11.343036
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=1)
    assert attr1 >= attr2
    assert attr2 >= attr3


# Generated at 2022-06-23 05:44:20.174494
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    FA1 = FieldAttribute(priority=1)
    FA2 = FieldAttribute(priority=2)
    FA3 = FieldAttribute(priority=3)
    FA4 = FieldAttribute(priority=4)
    assert (FA1 >= FA2) == False
    assert (FA2 >= FA3) == False
    assert (FA3 >= FA4) == False
    assert (FA2 >= FA1) == True
    assert (FA3 >= FA2) == True
    assert (FA4 >= FA3) == True
    assert (FA1 >= FA1) == True
    assert (FA2 >= FA2) == True
    assert (FA3 >= FA3) == True
    assert (FA4 >= FA4) == True


# Generated at 2022-06-23 05:44:28.551984
# Unit test for constructor of class Attribute
def test_Attribute():
    inst = Attribute(isa='foo', private=False, default=None, required=False, listof=None, priority=5, class_type=None, always_post_validate=False)
    assert inst.isa == 'foo'
    assert inst.private == False
    assert inst.default is None
    assert inst.required == False
    assert inst.listof is None
    assert inst.priority == 5
    assert inst.class_type is None
    assert inst.always_post_validate == False
    assert inst.inherit == True



# Generated at 2022-06-23 05:44:32.572083
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """Test for method __ne__ of class Attribute"""
    attr1 = Attribute(default='test')
    attr2 = Attribute(default='test2')
    assert attr1 != attr2


# Generated at 2022-06-23 05:44:35.077647
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    low = Attribute(priority=0)
    high = Attribute(priority=1)

    assert low.__gt__(high)



# Generated at 2022-06-23 05:44:46.973113
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    test the constructor of a :class:`FieldAttribute`
    """
    # test with no config
    a = FieldAttribute()
    # test with all config options
    b = FieldAttribute(
        isa='string',
        private=True,
        default='foobar',
        required=True,
        listof='int',
        priority=0,
        class_type='builtin_module',
        always_post_validate=True,
        inherit=True,
        alias='alias_foo',
        extend=True,
        prepend=True,
        static=True,
    )
    # not gonna work.
    try:
        c = FieldAttribute(
            default=[],
        )
    except TypeError:
        pass

# Generated at 2022-06-23 05:44:50.152306
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute('str')
    b = Attribute('str')
    assert a == b
    c = Attribute('str', priority=1)
    d = Attribute('str', priority=2)
    assert c != d



# Generated at 2022-06-23 05:44:57.859805
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(False, False, False, False, False, False, False, False, False)
    assert field.isa is False
    assert field.private is False
    assert field.default is False
    assert field.required is False
    assert field.listof is False
    assert field.priority == 0
    assert field.class_type is False
    assert field.always_post_validate is False
    assert field.inherit is False
    assert field.alias is False


# Generated at 2022-06-23 05:45:01.681194
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 0
    attr2 = Attribute()
    attr2.priority = 1
    assert attr != attr2


# Generated at 2022-06-23 05:45:10.605618
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    a2 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a1 == a2
    assert not a1 != a2
    assert not a1 < a2
    assert not a1 > a2
    assert a1 <= a2
    assert a1 >= a2


# Generated at 2022-06-23 05:45:14.501303
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert (attr1 > attr2)
    assert (not attr2 > attr1)


# Generated at 2022-06-23 05:45:19.810035
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default='default', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

# Generated at 2022-06-23 05:45:23.831025
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a2 < a1
    assert a1 >= a2
    assert a1.__lt__(a2)
    assert a2.__ge__(a1)


# Generated at 2022-06-23 05:45:34.749453
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='bool', private=True, default=False,
            required=False, listof='None', priority=0, class_type=None,
            always_post_validate=False, inherit=True, alias=None, extend=False,
            prepend=False)
    assert attribute.isa == 'bool'
    assert attribute.private == True
    assert attribute.default == False
    assert attribute.required == False
    assert attribute.listof == 'None'
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False



# Generated at 2022-06-23 05:45:37.541101
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(1, 0)
    a2 = Attribute(2, 0)

    assert a2.__le__(a1)



# Generated at 2022-06-23 05:45:41.763287
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority = 1

    b = Attribute()
    b.priority = 2

    c = Attribute()
    c.priority = 1

    assert(a != b)
    assert(a != c)
    assert(b != a)
    assert(c != a)



# Generated at 2022-06-23 05:45:44.226991
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b


# Generated at 2022-06-23 05:45:55.274390
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='foo')
    assert a.isa == 'foo'
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='foo', default=1)
    assert a.isa == 'foo'
    assert a.default == 1

    a = Attribute(isa='foo', default=[])
    assert a.isa == 'foo'
    assert a.default == []

    a = Attribute

# Generated at 2022-06-23 05:45:57.719781
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a < b



# Generated at 2022-06-23 05:46:01.979483
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert a <= b
    assert b <= c
    assert c <= b
    assert not c <= a


# Generated at 2022-06-23 05:46:05.335027
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test with equal objects
    attribute1 = Attribute()
    attribute2 = Attribute()
    assert attribute1 == attribute2


# Generated at 2022-06-23 05:46:13.307722
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Test for Attribute with priority
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__lt__(attr2)
    assert not attr2.__lt__(attr1)

    # Test for Attribute without priority
    attr1 = Attribute()
    attr2 = Attribute()
    assert not attr1.__lt__(attr2)
    assert not attr2.__lt__(attr1)

# Generated at 2022-06-23 05:46:19.399351
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    Unit test for method Attribute.__lt__
    '''

    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    attr_3 = Attribute(priority=3)
    attr_10 = Attribute(priority=10)

    assert attr_10 < attr_3
    assert attr_3 < attr_2
    assert attr_2 < attr_1
    assert not attr_10 < attr_10



# Generated at 2022-06-23 05:46:28.909332
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='dict', required=True)
    assert field.isa == 'dict'
    assert field.required is True
    assert field.private is False
    assert field.default is None
    assert field.priority == 0
    assert field.class_type is None

    field = FieldAttribute(isa='dict', required=True, default=dict)
    assert field.default == dict

    try:
        field = FieldAttribute(isa='dict', required=True, default={})
    except TypeError as e:
        assert True, "Error when creating FieldAttribute: default is not None for container"
    except BaseException as e:
        assert False, "Unexpected error when creating FieldAttribute: %s" % str(e)



# Generated at 2022-06-23 05:46:39.927979
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str')
    assert fa == fa
    assert (fa == fa) is not None
    #assert fa == FieldAttribute(isa='str')

    fa1 = FieldAttribute(isa='str', private=True)
    assert fa1 != fa
    #assert fa1 == FieldAttribute(isa='str', private=True)

    fa2 = FieldAttribute(isa='str', private=True, default=True)
    assert fa2 != fa
    #assert fa2 == FieldAttribute(isa='str', private=True, default=True)

    try:
        fa3 = FieldAttribute(isa='list', default='This is a test')
        # This will never be executed
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-23 05:46:45.227922
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    att = Attribute()
    other1 = Attributepriority = 4
    other2 = Attributepriority = 5
    res1 = att.__ne__(other1)
    res2 = att.__ne__(other2)
    if res1 != 0:
        return 1
    if res2 != 1:
        return 1
    return 0


# Generated at 2022-06-23 05:46:54.168404
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='test')
    assert a.isa == 'test'

FieldAttribute.TASK = FieldAttribute(isa='task')
FieldAttribute.PLAY = FieldAttribute(isa='play')
FieldAttribute.ROLE = FieldAttribute(isa='role')
FieldAttribute.STRING = FieldAttribute(isa='string', listof=True)
FieldAttribute.LIST = FieldAttribute(isa='list')
FieldAttribute.DICT = FieldAttribute(isa='dict', default=dict)
FieldAttribute.BOOL = FieldAttribute(isa='bool')
FieldAttribute.INTEGER = FieldAttribute(isa='int')

FieldAttribute.TASK_LIST = FieldAttribute(isa='task', listof=True)
FieldAttribute.PLAY_LIST = FieldAttribute(isa='play', listof=True)

# Generated at 2022-06-23 05:47:00.106487
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    if not a1.__gt__(a2):
        raise Exception("Failure: %s is greater than %s" % (a1, a2))

    if a2.__gt__(a1):
        raise Exception("Failure: %s is not greater than %s" % (a2, a1))



# Generated at 2022-06-23 05:47:07.770674
# Unit test for constructor of class Attribute
def test_Attribute():
    # No default
    a1 = Attribute()
    assert a1.isa is None
    assert a1.private is False
    assert a1.default is None
    assert a1.required is False
    assert a1.listof is None
    assert a1.priority == 0
    assert a1.class_type is None
    assert a1.always_post_validate is False
    assert a1.inherit is True
    assert a1.alias is None
    assert a1.extend is False
    assert a1.prepend is False
    assert a1.static is False
    # Default
    a1 = Attribute(isa="bool")
    assert a1.isa == "bool"
    assert a1.private is Fa

# Generated at 2022-06-23 05:47:10.317397
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='foo')
    assert isinstance(f, FieldAttribute)



# Generated at 2022-06-23 05:47:13.971409
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    atr = Attribute(priority=1)
    atr2 = Attribute(priority=2)
    assert atr.__gt__(atr2) == False


# Generated at 2022-06-23 05:47:18.020430
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute( priority = 9)
    b = Attribute( priority = 20)
    if a < b:
        return True

    return False


# Generated at 2022-06-23 05:47:28.375356
# Unit test for constructor of class Attribute
def test_Attribute():

    test_kwargs = {
        "isa": "str",
        "private": True,
        "default": "DevOps",
        "required": True,
        "listof": None,
        "priority": 10,
        "class_type": None,
        "always_post_validate": False,
        "inherit": True,
    }

    field = Attribute(**test_kwargs)

    assert field.isa == "str"
    assert field.private == True
    assert field.default == "DevOps"
    assert field.required == True
    assert field.listof == None
    assert field.priority == 10
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True

# Generated at 2022-06-23 05:47:32.676831
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    '''
    This function is used to test __ge__ method of class 'Attribute'
    '''
    f1 = Attribute(10)
    f2 = Attribute(11)
    print(f1.__ge__(f2))


# Generated at 2022-06-23 05:47:36.734886
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
     Test for Attribute.__le__ method
    """
    attributes = (Attribute(priority=0), Attribute(priority=1))
    for attribute in attributes:
        assert not attribute.__le__(attributes[0])
        assert attribute.__le__(attributes[1])



# Generated at 2022-06-23 05:47:43.434537
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    #A = Attribute()
    attr_1 = Attribute(priority = 1)
    attr_2 = Attribute(priority = 2)
    assert attr_1 < attr_2
    assert attr_2 > attr_1
    assert not (attr_1 > attr_2)
    assert not (attr_2 < attr_1)


# Generated at 2022-06-23 05:47:47.868502
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert FieldAttribute(priority=1).__ge__(FieldAttribute(priority=2)) is False
    assert FieldAttribute(priority=2).__ge__(FieldAttribute(priority=2)) is True
    assert FieldAttribute(priority=3).__ge__(FieldAttribute(priority=2)) is True



# Generated at 2022-06-23 05:47:59.684055
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Create instance of FieldAttribute
    fieldAttr = FieldAttribute(
        isa="class",
        private="True",
        default="True",
        required="True",
        listof="True",
        priority="0",
        class_type="True",
        always_post_validate="True",
        inherit="True",
        alias="True",
        extend="True",
        prepend="True",
        static="True"
    )

    # Check all variables
    assert "class" == fieldAttr.isa
    assert "True" == fieldAttr.private
    assert "True" == fieldAttr.default
    assert "True" == fieldAttr.required
    assert "True" == fieldAttr.listof
    assert "0" == fieldAttr.priority
    assert "True" == fieldAttr.class_

# Generated at 2022-06-23 05:48:08.617245
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """
    Unit test for method __gt__ of class Attribute

    """
    current_test = Attribute(priority=1)
    with_higher_priority = Attribute(priority=2)
    with_lower_priority = Attribute(priority=0)

    assert not with_higher_priority.__gt__(current_test)
    assert with_higher_priority.__ge__(current_test)
    assert current_test.__lt__(with_higher_priority)
    assert current_test.__le__(with_higher_priority)

    assert not with_lower_priority.__lt__(current_test)
    assert with_lower_priority.__le__(current_test)
    assert current_test.__gt__(with_lower_priority)
    assert current_test.__ge__(with_lower_priority)

# Generated at 2022-06-23 05:48:17.312877
# Unit test for constructor of class Attribute
def test_Attribute():

    # everything is unicode in yaml
    # (ISA, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    # TODO: class_type
    attr = Attribute(isa='list', default=list(), required=True, listof='dict', priority=5)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == []
    assert attr.required == True
    assert attr.listof == 'dict'
    assert attr.priority == 5

    attr = Attribute(isa='list', default=[], required=True, listof='dict', priority=5)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == []
    assert att

# Generated at 2022-06-23 05:48:23.478847
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(isa="int", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a2 = Attribute(isa="int", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    print(a1.__gt__(a2))
    

# Generated at 2022-06-23 05:48:30.181629
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert (a == b)
    assert (a <= b)
    assert not (a > b)
    assert not (a >= b)
    assert (b > a)
    assert (b >= a)
    assert not (b < a)
    assert not (b <= a)
    print('All tests passed!!!')


# Generated at 2022-06-23 05:48:35.598578
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 > attr1

    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert not attr2 > attr1

    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert not attr2 > attr1


# Generated at 2022-06-23 05:48:39.486199
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=1)
    assert a != b
    assert b != a
    assert b != c
    assert c != b



# Generated at 2022-06-23 05:48:50.103230
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='list', priority=1)
    a2 = Attribute(isa='list', priority=2)
    a3 = Attribute(isa='list', priority=2)

    assert len([a1, a2, a3]) == 3
    assert len(set([a1, a2, a3])) == 2
    assert (a2 in set([a1, a2, a3])) == True
    assert (a3 in set([a1, a2, a3])) == True
    assert (a1 in set([a1, a2, a3])) == False

    assert a1 != a2
    assert a2 == a3

# Generated at 2022-06-23 05:48:52.808461
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 != a2
    #assert "is not" in result
    #assert not result



# Generated at 2022-06-23 05:49:03.283752
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    def test_field_priority():
        field1=FieldAttribute(priority=12)
        field2=FieldAttribute(priority=1)
        field3=FieldAttribute(priority=2)
        assert field1 >= field2
        assert field1 < field3
    test_field_priority()
    def test_field_priority_eq():
        field1=FieldAttribute(priority=1)
        field2=FieldAttribute(priority=1)
        assert field1 >= field2
    test_field_priority_eq()

"""
Module attribute which stores a dict of all attributes defined for all Ansible
modules.  This is primarily useful for hacking around with in the debugger,
since it can be hard to figure out where a field is defined.
"""
MODULE_ATTRIBUTE_MAP = dict()



# Generated at 2022-06-23 05:49:09.139223
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field_attribute_one = FieldAttribute(priority=1)
    field_attribute_two = FieldAttribute(priority=2)
    field_attribute_two_gt_one = field_attribute_two.__gt__(field_attribute_one)
    assert field_attribute_two_gt_one == True

# Generated at 2022-06-23 05:49:12.904240
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute(priority=0)
    other_attr = Attribute(priority=1)
    res = attr.__gt__(other_attr)
    assert res == False


# Generated at 2022-06-23 05:49:14.228306
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='string')
    assert attr.isa == 'string'

# Generated at 2022-06-23 05:49:22.784118
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', class_type=str, private=True, default='foo', required=True, listof='str', priority=1,
        always_post_validate=True, inherit=False, alias='foo', extend=False, prepend=False, static=False)

    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    # assert a.class_type == str
    assert a.always_post_validate == True
    assert a.inherit == False
    assert a.alias == 'foo'
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Unit test

# Generated at 2022-06-23 05:49:32.554697
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'dict'
    class_type = 'dict'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    assert isa == Attribute(
        isa=isa,
        private=private,
        default=default,
        required=required,
        listof=listof,
        priority=priority,
        class_type=class_type,
        always_post_validate=always_post_validate,
        inherit=inherit,
        alias=alias,
        extend=extend,
        prepend=prepend,
        static=static
    ).isa

# Generated at 2022-06-23 05:49:36.027502
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a >= b


# Generated at 2022-06-23 05:49:44.568022
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority = 1)
    attr2 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority = 1)
    assert attr1 == attr2
    attr1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority = 1)
    attr2 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority = 2)
    assert attr1 != attr2


# Generated at 2022-06-23 05:49:55.355696
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=4)
    assert a1 >= a1
    assert a1 >= a2
    assert a1 >= a3
    assert a1 >= a4
    assert a2 >= a1
    assert a2 >= a2
    assert a2 >= a3
    assert a2 >= a4
    assert a3 >= a1
    assert a3 >= a2
    assert a3 >= a3
    assert a3 >= a4
    assert a4 >= a1
    assert a4 >= a2
    assert a4 >= a3
    assert a4 >= a4


# Generated at 2022-06-23 05:49:59.762418
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr1.priority = 1

    attr2 = Attribute()
    attr2.priority = 2

    assert attr1.__lt__(attr2) == True
    assert attr2.__lt__(attr1) == False

# Generated at 2022-06-23 05:50:07.755573
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import Attribute

    class SubBase(Base):
        _base_attribute = Attribute(isa='integer')

        def _validate_base_attribute(self, value):
            return True

    with pytest.raises(TypeError):
        SubBase(base_attribute='string')
    assert SubBase(base_attribute=1).base_attribute == 1

# Generated at 2022-06-23 05:50:17.230281
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='int',
        private=False,
        default=42,
        required=False,
        listof='int',
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=False,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert a.isa == 'int'
    assert a.private == False
    assert a.default == 42
    assert a.required == False
    assert a.listof == 'int'
    assert a.priority == 1
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == False
    assert a.alias == None

# Generated at 2022-06-23 05:50:17.721317
# Unit test for constructor of class Attribute
def test_Attribute():
    pass



# Generated at 2022-06-23 05:50:21.717085
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # test_a is less than test_b
    test_a = Attribute(priority=1)
    test_b = Attribute(priority=2)
    assert(test_a < test_b)
    assert(not (test_a >= test_b))


# Generated at 2022-06-23 05:50:23.935956
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # test case 1
    priority_1 = 1
    priority_2 = 2

    test_attr_1 = Attribute(priority = priority_1)
    test_attr_2 = Attribute(priority = priority_2)

    assert test_attr_1 < test_attr_2
    assert not test_attr_1 > test_attr_2


# Generated at 2022-06-23 05:50:27.545503
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=3)
    attr2 = Attribute(priority=2)
    assert(attr.__le__(attr2)) == False
    assert(attr.__le__(attr)) == True


# Generated at 2022-06-23 05:50:33.859150
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """Unit test for method __gt__ of class Attribute"""

    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)

    assert attribute2.__gt__(attribute1)
    assert not attribute1.__gt__(attribute2)
    assert not attribute1.__gt__(attribute1)
    assert not attribute2.__gt__(attribute2)


# Generated at 2022-06-23 05:50:43.539329
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test 1. isa=None, private=False, default=None, required=False,
    # listof=None, priority=0, class_type=None, always_post_validate=False,
    # inherit=True, alias=None, extend=False, prepend=False,
    # static=False,
    att = Attribute()
    assert att.isa == None
    assert att.private == False
    assert att.default == None
    assert att.required == False
    assert att.listof == None
    assert att.priority == 0
    assert att.class_type == None
    assert att.always_post_validate == False
    assert att.inherit == True
    assert att.alias == None
    assert att.extend == False
    assert att.prepend == False
    assert att.static == False

# Generated at 2022-06-23 05:50:45.707161
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    return a.__ge__(b) and c.__ge__(a)

# Generated at 2022-06-23 05:50:57.966765
# Unit test for constructor of class Attribute
def test_Attribute():
    f1 = FieldAttribute()
    assert f1.isa                      == None
    assert f1.private                  == False
    assert f1.default                  == None
    assert f1.required                 == False
    assert f1.listof                   == None
    assert f1.priority                 == 0
    assert f1.class_type               == None
    assert f1.always_post_validate     == False
    assert f1.inherit                  == True
    assert f1.alias                    == None


# Generated at 2022-06-23 05:51:01.863838
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field1 = FieldAttribute(priority=1)
    field2 = FieldAttribute(priority=2)
    value = field1.__ne__(field2)
    assert value == False


# Generated at 2022-06-23 05:51:08.257160
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr3 = Attribute(priority=10)

    assert attr1 <= attr2
    assert not (attr1 >= attr2)
    assert not (attr1 > attr2)
    assert attr1 <= attr2

    assert attr2 <= attr3
    assert attr1 <= attr3

    assert not (attr3 <= attr1)
    assert not (attr3 <= attr2)



# Generated at 2022-06-23 05:51:10.381131
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=3)
    assert False == a.__le__(b)


# Generated at 2022-06-23 05:51:13.066483
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 2)
    assert a.__le__(b)
    assert not b.__le__(a)


# Generated at 2022-06-23 05:51:16.944897
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=-1)
    a2 = Attribute(priority=-2)
    assert a1.__ne__(a2)
    assert a2.__ne__(a1)



# Generated at 2022-06-23 05:51:26.028004
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Test that 2 attributes with the same priority are not sorted and that
    attributes are sorted by priority number (highest priority number first)
    """
    attr_a = Attribute(priority=1)
    attr_b = Attribute(priority=1)
    assert attr_a < attr_b == False
    assert attr_b.priority > attr_a.priority == True
    assert attr_a.priority < attr_b.priority == False
    attr_c = Attribute(priority=2)
    assert attr_c < attr_b == True
    assert attr_b < attr_c == False


# Generated at 2022-06-23 05:51:28.431347
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = FieldAttribute(priority=1)
    other = FieldAttribute(priority=2)
    assert(attr != other)


# Generated at 2022-06-23 05:51:33.652372
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute()
    b = Attribute()
    assert (a == b)
    assert (a <= b)
    assert (a >= b)

    a = Attribute()
    b = Attribute(priority=100)
    assert (a != b)
    assert (a < b)


# Generated at 2022-06-23 05:51:37.249744
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(isa='test1')
    attr2 = Attribute(isa='test2', priority=2)
    assert (attr1 >= attr2) is True
    assert (attr2 >= attr1) is False



# Generated at 2022-06-23 05:51:39.881483
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    ''' assert a > b'''
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a > b


# Generated at 2022-06-23 05:51:42.992084
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', required=True, priority=20)
    assert(a.isa == 'dict')
    assert(a.required)
    assert(a.priority == 20)

# Generated at 2022-06-23 05:51:45.683292
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1 == a2


# Generated at 2022-06-23 05:51:47.906687
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute() < Attribute(priority=1)
    assert not Attribute() < Attribute()
    assert not Attribute(priority=1) < Attribute()

# Generated at 2022-06-23 05:51:50.713396
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(required=True, default="default", isa="str", listof="str")
    b = Attribute(isa="int")
    assert a.__ne__(b)




# Generated at 2022-06-23 05:52:02.984539
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute( isa='test', private=False, default=None, required=False, listof='test', priority=0,class_type=None, always_post_validate=False, inherit=True, alias='test', extend=False, prepend=False, static=False )
    attr2 = Attribute( isa='test', private=False, default=None, required=False, listof='test', priority=0,class_type=None, always_post_validate=False, inherit=True, alias='test', extend=False, prepend=False, static=False )

# Generated at 2022-06-23 05:52:05.227411
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute()
    x.priority = 11
    y = Attribute()
    y.priority = 1
    assert x <= y


# Generated at 2022-06-23 05:52:07.507730
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a != b
    assert not (a != a)


# Generated at 2022-06-23 05:52:17.805321
# Unit test for constructor of class Attribute
def test_Attribute():

    #test_Attribute_init
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

    #test_Attribute_init_default
    a = Attribute(isa=False, private=False, default=False, required=False, listof=False, class_type=False, always_post_validate=False, inherit=False, alias=False)
    assert a.isa == False
    assert a.private == False
    assert a.default == False
    assert a.required == False
   