

# Generated at 2022-06-23 05:42:25.955976
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_1 = Attribute(priority=10)
    attr_2 = Attribute(priority=20)
    assert attr_1 < attr_2, "Attribute class __lt__ method is broken"



# Generated at 2022-06-23 05:42:28.839358
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    print("Attribute a __ge__ Attribute b: %s" %(a.__ge__(b)))


# Generated at 2022-06-23 05:42:38.233897
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import wrap_var

    class AnsibleTestObject(AnsibleBaseYAMLObject):
        _schema = {
            'name': FieldAttribute(isa='str'),
            'value': FieldAttribute(isa='str', default=wrap_var('2')),
        }

        def __init__(self, data=None):
            super(AnsibleTestObject, self).__init__(data)

    test_obj = AnsibleTestObject({'name': 'test1'})
    test_obj2 = AnsibleTestObject({'name': 'test2'})

    assert(test_obj > test_obj2)

# Generated at 2022-06-23 05:42:44.549786
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    c = Attribute()

    a.priority = 100
    b.priority = 200
    c.priority = 300

    assert a > b
    assert a > c
    assert b < c
    assert not a < c
    assert c > b
    assert not b > c
    assert b < a
    assert not c < a

# Generated at 2022-06-23 05:42:49.280057
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fa = FieldAttribute(
        isa = 'str',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )
    return fa



# Generated at 2022-06-23 05:42:53.344099
# Unit test for constructor of class Attribute
def test_Attribute():

    attr_obj = Attribute(isa='list')
    if attr_obj.isa != 'list':
        print('Attribute Constructor is not working properly')
        sys.exit(1)
    else:
        print('Attribute Constructor is working properly')

# Generated at 2022-06-23 05:42:55.389151
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='integer', default=1)
    assert field.isa == 'integer'
    assert field.default == 1


# Generated at 2022-06-23 05:43:02.657908
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)
    assert attr1 == attr2
    assert attr1 != attr3


# Generated at 2022-06-23 05:43:04.928766
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=20)
    assert a <= b
    assert not (b <= a)


# Generated at 2022-06-23 05:43:08.890944
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert FieldAttribute(priority=1) <= FieldAttribute(priority=1)
    assert FieldAttribute(priority=0) <= FieldAttribute(priority=1)
    assert FieldAttribute(priority=0) <= FieldAttribute(priority=0)
    assert not FieldAttribute(priority=2) <= FieldAttribute(priority=1)


# Generated at 2022-06-23 05:43:11.191384
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    t0 = Attribute(priority=0)
    t1 = Attribute(priority=1)
    assert t1 > t0


# Generated at 2022-06-23 05:43:14.120433
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = Attribute(isa='foo')
    assert isinstance(f, Attribute)
    assert f.isa == 'foo'


# Generated at 2022-06-23 05:43:21.088923
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """Unit test for method __le__ of class Attribute"""
    import sys
    if sys.version_info < (2, 7):
        raise TypeError()

    attr1 = Attribute()
    attr1.priority = 0
    attr2 = Attribute()
    attr2.priority = 1
    assert attr1.__le__(attr2) == False
    assert attr2.__le__(attr1) == True



# Generated at 2022-06-23 05:43:23.998652
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a.__gt__(b)



# Generated at 2022-06-23 05:43:26.839709
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa='list', required=True, priority=10)
    assert isinstance(obj, FieldAttribute)

    obj = FieldAttribute(isa='list')
    assert isinstance(obj, FieldAttribute)



# Generated at 2022-06-23 05:43:31.753299
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(isa='dict')
    if field.isa != 'dict':
        raise Exception('Attribute isa should be dict')
    field_is_not_defined = False
    try:
        field = Attribute(foo='bar')
    except TypeError:
        field_is_not_defined = True
    if not field_is_not_defined:
        raise Exception('Attribute constructor should assert unknown parameter')

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-23 05:43:38.237732
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # test default is not mutable
    a = Attribute(isa='list', default=[])
    assert a.isa is 'list'
    assert a.default == []
    assert a.default is not []

    # test default is mutable
    a = Attribute(isa='list', default=lambda: [])
   

# Generated at 2022-06-23 05:43:42.109090
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(isa='int', priority=1)
    b = Attribute(isa='int', priority=0)
    if not (a >= b) and (b >= a):
        return False
    return True


# Generated at 2022-06-23 05:43:46.084037
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=10)
    assert a1 < a2
    assert a1 < a3
    assert a2 < a3

# Generated at 2022-06-23 05:43:49.097869
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(isa='1', priority=0)
    a1 = Attribute(isa='1', priority=1)
    assert(a1 < a0)


# Generated at 2022-06-23 05:43:57.889370
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    g1 = Attribute()
    g1.priority = 1
    g2 = Attribute()
    g2.priority = 1
    g3 = Attribute()
    g3.priority = 2
    assert g3.__ge__(g1) == True
    assert g2.__ge__(g1) == True
    assert g2.__ge__(g3) == False
    assert g1.__ge__(g3) == False
    assert g1.__ge__(g2) == True
    assert g3.__ge__(g2) == True


# Generated at 2022-06-23 05:44:07.657392
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """Unit test for method __eq__ of class Attribute."""
    args = dict(
        isa = "test",
        private = True,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )
    attr1 = Attribute(**args)
    attr2 = Attribute(**args)
    assert(attr1 == attr2)


# Generated at 2022-06-23 05:44:10.339275
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b.__lt__(a) == True


# Generated at 2022-06-23 05:44:15.065920
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    if not a < b:
        raise AssertionError('a < b expected to be true')

    if b < a:
        raise AssertionError('b < a expected to be false')


# Generated at 2022-06-23 05:44:18.908228
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    assert a < b


# Generated at 2022-06-23 05:44:22.522795
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert (b.__ge__(a)), "Attribute.__ge__() failed"


# Generated at 2022-06-23 05:44:27.485809
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 < a2
    a2 = Attribute(priority=1)
    assert a1 < a2
    a1 = Attribute(priority=2)
    assert a1 > a2



# Generated at 2022-06-23 05:44:32.230266
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1.__gt__(a2) == a2.__lt__(a1)



# Generated at 2022-06-23 05:44:34.728977
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a <= b



# Generated at 2022-06-23 05:44:38.049045
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute(priority=0)
    attr_gt = Attribute(priority=1)
    assert attr_gt > attr


# Generated at 2022-06-23 05:44:40.399320
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute(priority=1)
    assert(a >= b)


# Generated at 2022-06-23 05:44:44.944533
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    :return: None
    """
    # Priority of the first attribute is 0
    # Priority of the second attribute is 10
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=10)
    assert attr_1 < attr_2


# Generated at 2022-06-23 05:44:47.292291
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 1

    b = Attribute()
    b.priority = 2

    assert a <= b


# Generated at 2022-06-23 05:44:52.489071
# Unit test for constructor of class Attribute
def test_Attribute():

    # Given an Attribute class for a list with a "required" attribute
    attr = Attribute(isa='list', required=True)

    # Then an error is raised with a default value
    try:
        attr = Attribute(isa='list', required=True, default=[])
        raise AssertionError("default value not prevented")
    except TypeError as e:
        assert str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'

# Generated at 2022-06-23 05:45:03.622801
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    a = FieldAttribute(isa='str')
    assert a.isa == 'str'
    with pytest.raises(TypeError):
        a = FieldAttribute(isa='str', default=['a'])
    a = FieldAttribute(isa='str', default=None)
    assert a.default is None
    a = FieldAttribute(isa='str', default=False)
    assert a.default is False
    a = FieldAttribute(isa='str', default=True)
    assert a.default is True
    a = FieldAttribute(isa='str', default=0)
    assert a.default == 0
    a = FieldAttribute(isa='str', default='')
    assert a.default == ''
    a = FieldAttribute(isa='list', default=list)
    assert callable(a.default)

# Generated at 2022-06-23 05:45:05.477747
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority = 100)
    y = Attribute(priority = 200)
    assert (y <= x) == True


# Generated at 2022-06-23 05:45:11.803797
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    assert not attribute.__ne__(attribute),\
        'the method __ne__() of class Attribute should not return False when input parameter is the same object'


# Generated at 2022-06-23 05:45:15.399853
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """
        FieldAttribute.__ge__() Simple unit test
    """
    a1 = Attribute()
    a1.priority = 3
    a2 = Attribute()
    a2.priority = 4
    assert a2.__ge__(a1)
    return True


# Generated at 2022-06-23 05:45:19.100917
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=6)
    assert attr1.__gt__(attr2) == True



# Generated at 2022-06-23 05:45:23.573576
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    Attribute.__le__(Attribute(priority=1), Attribute(priority=1))
    Attribute.__le__(Attribute(priority=1), Attribute(priority=3))
    Attribute.__le__(Attribute(priority=3), Attribute(priority=1))

test_Attribute___le__()

# Generated at 2022-06-23 05:45:29.253922
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)

    # Verify that __ge__ is correct
    assert(field2.__ge__(field1))
    assert(not field1.__ge__(field2))
    assert(field2.__ge__(field2))
    assert(field1.__ge__(field1))


# Generated at 2022-06-23 05:45:31.133006
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    t = Attribute(priority=5)
    assert (t > Attribute(priority=4)) == True


# Generated at 2022-06-23 05:45:33.032326
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert FieldAttribute() < FieldAttribute(priority=1)
    assert not FieldAttribute() < FieldAttribute()


# Generated at 2022-06-23 05:45:37.952837
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=1, required=True, listof='int', class_type=int, inherit=True)
    assert attr.isa == 'int'
    assert attr.default == 1
    assert attr.required == True
    assert attr.listof == 'int'
    assert attr.class_type == int
    assert attr.inherit == True


# Generated at 2022-06-23 05:45:41.713116
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if not a.__ne__(b):
        raise Exception("Priority %s not equal to %s" % (a.priority, b.priority))



# Generated at 2022-06-23 05:45:53.522246
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)

    assert a == b
    assert a >= b
    assert a <= b
    assert not a != b
    assert not a > b
    assert not a < b

    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert a == b
    assert a >= b
    assert a <= b
    assert not a != b
    assert not a > b
    assert not a < b

    a = Attribute(priority=1)
    b = Attribute(priority=1)

    assert a == b
    assert a >= b
    assert a <= b
    assert not a != b
    assert not a > b
    assert not a < b

    a = Attribute(priority=2)
    b = Attribute

# Generated at 2022-06-23 05:46:00.443429
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    a3 = Attribute(priority=1)
    a4 = Attribute(priority=1)

    assert a1 == a2
    assert a3 == a4
    assert not a2 == a3
    assert not a1 == a3
    assert not a1 == a4
    assert not a2 == a4


# Generated at 2022-06-23 05:46:01.694313
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    _test_method(Attribute.__ne__)


# Generated at 2022-06-23 05:46:12.948479
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    m = FieldAttribute(isa=None,
                       private=True,
                       default='default',
                       required=False,
                       listof=None,
                       priority=0,
                       class_type=None,
                       always_post_validate=False,
                       inherit=True,
                       alias=None,
                       extend=False,
                       prepend=False,
                       static=False,
                       )
    assert m.isa is None
    assert m.private is True
    assert m.default == 'default'
    assert m.required is False
    assert m.listof is None
    assert m.priority == 0
    assert m.class_type is None
    assert m.always_post_validate is False
    assert m.inherit is True
    assert m.alias is None
    assert m.extend is False
    assert m

# Generated at 2022-06-23 05:46:15.896388
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(None,priority=1)
    b = Attribute(None,priority=2)
    # a > b
    assert a > b


# Generated at 2022-06-23 05:46:19.041109
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 != attr1
    assert not attr2 == attr1



# Generated at 2022-06-23 05:46:23.073887
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
  attr1 = Attribute(isa = 'test', default = 'test', required = True, priority = 1, class_type = 'test', extend = True, prepend = True, static = True)
  attr2 = Attribute(isa = 'test', default = 'test', required = True, priority = 1, class_type = 'test', extend = True, prepend = True, static = True)
  assert attr1 == attr2



# Generated at 2022-06-23 05:46:26.071798
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='boolean')
    assert field_attribute.isa == 'boolean'

# Generated at 2022-06-23 05:46:28.216619
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute is not None
    assert attribute.__class__.__name__ == 'FieldAttribute'

# Generated at 2022-06-23 05:46:35.226678
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.errors import AnsibleError

    a = FieldAttribute()
    b = FieldAttribute()
    try:
        assert a == b
        assert a >= b
        assert a <= b
        assert a != b
        assert not a > b
        assert not a < b
        assert not a < a
        assert not a < b
    except AssertionError as e:
        raise AnsibleError('test_Attribute___lt__ failed with error %s' % to_native(e))



# Generated at 2022-06-23 05:46:41.946832
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
  a = FieldAttribute()
  assert a.isa is None
  assert a.private is False
  assert a.default is None
  assert a.required is False
  assert a.listof is None
  assert a.priority == 0
  assert a.class_type is None
  assert a.always_post_validate is False
  assert a.inherit is True
  assert a.alias is None
  assert a.extend is False
  assert a.prepend is False
  assert a.static is False

# Generated at 2022-06-23 05:46:45.487306
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert (attr1 <= attr2) == True
    assert (attr2 <= attr1) == False


# Generated at 2022-06-23 05:46:50.602367
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # method Attribute.__eq__() should return True if priorities are the same
    Attribute1 = Attribute(priority=1)
    Attribute2 = Attribute(priority=1)
    Attribute3 = Attribute(priority=2)

    assert Attribute1 == Attribute2 and Attribute2 == Attribute1
    assert not (Attribute1 == Attribute3) and not (Attribute3 == Attribute1)


# Generated at 2022-06-23 05:46:53.736624
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    a1 = Attribute(prioriry=5)
    a2 = Attribute(prioriry=5)

    assert a1 == a2


# Generated at 2022-06-23 05:46:58.993386
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a.__ge__(b)
    b.priority = 1
    assert not a.__ge__(b)
    b.priority = -1
    assert a.__ge__(b)
    b.priority = 0
    assert a.__ge__(b)



# Generated at 2022-06-23 05:47:02.072352
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a1 <= a2
    assert a1 <= a1
    assert not (a2 <= a1)


# Generated at 2022-06-23 05:47:11.258046
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    def default_callable():
        pass

    field_attribute = FieldAttribute(
        isa='str',
        private=False,
        default=default_callable,
        required=True,
        listof='str',
        priority=0,
        class_type=str,
        always_post_validate=False,
        inherit=True,
        alias='my_str',
        extend=False,
        prepend=False,
        static=False,
    )

    assert field_attribute.isa == 'str'
    assert field_attribute.private == False
    assert field_attribute.default == default_callable
    assert field_attribute.required == True
    assert field_attribute.listof == 'str'
    assert field_attribute.priority == 0
    assert field_attribute.class_type == str
    assert field

# Generated at 2022-06-23 05:47:22.101888
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    assert field.isa == None
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field

# Generated at 2022-06-23 05:47:26.355905
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """Test method __ge__ of class Attribute"""

    SUT = Attribute(priority=17)

    result = SUT.__ge__(Attribute(priority=17))
    assert result

    result = SUT.__ge__(Attribute(priority=16))
    assert result

    result = SUT.__ge__(Attribute(priority=18))
    assert not result



# Generated at 2022-06-23 05:47:36.463061
# Unit test for constructor of class Attribute
def test_Attribute():
    # test with some invalid data to ensure exception is thrown
    threw = False
    try:
        field = Attribute(isa='list', listof='list', default=[1,2,3])
    except TypeError as e:
        threw = True
    assert threw

    # test with valid data
    data = {
        'isa'             : 'dict',
        'private'         : False,
        'default'         : dict,
        'required'        : False,
        'listof'          : None,
        'priority'        : 0,
        'class_type'      : None,
        'always_post_validate'   : False,
        'inherit'         : True,
        'alias'           : None
    }
    field = Attribute(**data)

# Generated at 2022-06-23 05:47:40.718257
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    instance_1 = Attribute(isa='list', private=True, required=False)
    instance_2 = Attribute(isa='list', private=True, required=False)
    assert (instance_1 == instance_2)

    instance_2.isa = 'dict'
    assert (instance_1 != instance_2)


# Generated at 2022-06-23 05:47:45.536307
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1 <= attr_2, "attr_2 has higher priority and should be less or equal"


# Generated at 2022-06-23 05:47:51.694427
# Unit test for constructor of class Attribute
def test_Attribute():
    print("Testing Attribute")

    # private=False, default=None, required=False, listof=None , priority=0
    a = Attribute(always_post_validate=True)
    assert a.always_post_validate == True
    assert isinstance(a.listof, type(None))
    assert isinstance(a.default, type(None))

# Generated at 2022-06-23 05:47:55.869423
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    f1 = Attribute(priority=1)
    f1_1 = Attribute(priority=1)
    f2 = Attribute(priority=2)

    assert f2 != f1
    assert not f1_1 != f1


# Generated at 2022-06-23 05:48:00.268710
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    field1 = Attribute(default=None, required=False, isa='string', priority=0)
    field2 = Attribute(default=None, required=False, isa='string', priority=0)

    print("The two fields are equal: %s" % (field1 == field2))


# Generated at 2022-06-23 05:48:07.673013
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        # Test exception for mutable default
        FieldAttribute(default={})
    except Exception as e:
        assert isinstance(e, TypeError)
    else:
        assert False, 'Exception not raised'

    attr = FieldAttribute(default=lambda: {})
    assert isinstance(attr.default, type(lambda: None))
    assert attr.default() == {}

    attr = FieldAttribute(default=lambda: defaultdict(lambda: defaultdict(lambda: {})))
    assert isinstance(attr.default, type(lambda: None))
    assert attr.default() == defaultdict(lambda: defaultdict(lambda: {}))

# Generated at 2022-06-23 05:48:09.047574
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 2)
    assert( a <= b )

# Generated at 2022-06-23 05:48:17.531313
# Unit test for constructor of class Attribute
def test_Attribute():

    # Attribute(
    #    isa=None,
    #    private=False,
    #    default=None,
    #    required=False,
    #    listof=None,
    #    priority=0,
    #    class_type=None,
    #    always_post_validate=False,
    #    inherit=True,
    #    alias=None,
    #    extend=False,
    #    prepend=False,
    #    static=False,
    # )

    attr = Attribute(isa='list', private=True, default='test', required=True, listof='dict', priority=10, class_type='dict', always_post_validate=True, inherit=False, alias='mylist')

    assert attr.isa == 'list'

# Generated at 2022-06-23 05:48:20.777260
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert (Attribute(priority=1) >= Attribute(priority=2))
    assert not (Attribute(priority=2) >= Attribute(priority=1))
    assert (Attribute(priority=2) >= Attribute(priority=2))


# Generated at 2022-06-23 05:48:32.325201
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(
        isa='test',
        private=False,
        default=None,
        required=False,
        listof='test',
        priority=0,
        class_type='test',
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert f.isa == 'test'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == 'test'
    assert f.priority == 0
    assert f.class_type == 'test'
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.ext

# Generated at 2022-06-23 05:48:34.022719
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print(Attribute(priority=1) <= Attribute(priority=2))

# Generated at 2022-06-23 05:48:40.367443
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=4)

    assert not a1.__le__(a3)
    assert a3.__le__(a1)
    assert a1.__le__(a2)
    assert a2.__le__(a1)

# Generated at 2022-06-23 05:48:43.824048
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_1 = Attribute(priority=5)
    attr_2 = Attribute(priority=4)
    assert attr_1 >= attr_2


# Generated at 2022-06-23 05:48:49.216585
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    att1 = Attribute()
    att2 = Attribute()
    att1.priority = 1
    att2.priority = 0
    assert att1 >= att1
    assert att1 >= att2
    assert att2 >= att2
    assert not att2 >= att1
test_Attribute___ge__()

# Generated at 2022-06-23 05:48:49.890832
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()

# Generated at 2022-06-23 05:48:59.508831
# Unit test for constructor of class Attribute
def test_Attribute():
    # Basic test with no arguments
    x = Attribute()
    assert (x.isa is None)
    assert (x.private is False)
    assert (x.default is None)
    assert (x.required is False)
    assert (x.listof is None)
    assert (x.priority == 0)
    assert (x.class_type is None)
    assert (x.always_post_validate is False)
    assert (x.inherit is True)
    assert (x.alias is None)

    # Test with valid arguments

    x = Attribute(isa='dict', private=True, default='foo', required=True, listof='bar', priority=1, class_type='baz', always_post_validate=True, inherit=False, alias='baz')
    assert (x.isa == 'dict')

# Generated at 2022-06-23 05:49:08.249747
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    import datetime

    class TestFieldAttribute(unittest.TestCase):
        """Unit tests for the constructor of class FieldAttribute"""
        yaml_ise_type = Attribute(isa='ise')
        yaml_show_type = Attribute(isa='show')
        yaml_config_type = Attribute(isa='config')
        yaml_list_type = Attribute(isa='list')
        yaml_dict_type = Attribute(isa='dict')
        yaml_set_type = Attribute(isa='set')
        yaml_int_type = Attribute(isa='int')
        yaml_float_type = Attribute(isa='float')
        yaml_bool_type = Attribute(isa='bool')
        yaml_str_type = Attribute(isa='str')
       

# Generated at 2022-06-23 05:49:12.549641
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    fa = Attribute(priority=5)
    fa2 = Attribute(priority=5)
    assert fa >= fa2


# Generated at 2022-06-23 05:49:15.637293
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    one = Attribute(priority=1)
    two = Attribute(priority=2)
    assert two.__ne__(one)
    assert one.__ne__(two)
    assert not two.__ne__(two)


# Generated at 2022-06-23 05:49:20.467404
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    assert a == c
    assert a <= c
    assert a < b
    assert not a > b
    assert a <= b
    assert not a >= b


# Generated at 2022-06-23 05:49:25.447537
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field_attribute = FieldAttribute()
    field_attribute1 = FieldAttribute(priority=10)
    assert field_attribute == field_attribute
    assert not field_attribute == field_attribute1
    assert not field_attribute1 == field_attribute
    assert field_attribute1 == field_attribute1


# Generated at 2022-06-23 05:49:27.774884
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    f1 = Attribute(priority=0)
    f2 = Attribute(priority=0)
    assert (f1 == f2) == True


# Generated at 2022-06-23 05:49:37.926729
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo', extend=True)
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.extend is True
    assert a.prepend is False
    assert a.alias is None

    # test assigning an immutable value to the default
    try:
        a = Attribute(isa='list', default=['foo', 'bar'])
        assert False
    except TypeError:
        assert True

    # test assigning a callable to the default
    try:
        a = Attribute(isa='list', default=lambda: ['foo', 'bar'])
        assert True
    except TypeError:
        assert False

    # test prepend
    a = Attribute(isa='str', default='foo', prepend=True)

# Generated at 2022-06-23 05:49:41.371518
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 != attr2


# Generated at 2022-06-23 05:49:47.288137
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='int', default=42, required=True)
    assert field.isa == 'int'
    assert field.private == False
    assert field.default == 42
    assert field.required == True
    assert field.listof == None
    assert field.priority == 0

# Create a FieldAttribute with a non-callable default

# Generated at 2022-06-23 05:49:52.640701
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=10)
    att2 = Attribute(priority=20)
    att3 = Attribute(priority=20)
    assert att1 < att2
    assert att2 <= att3
    assert att2 > att1
    assert att3 >= att2
    assert att1 != att2
    assert att3 == att2


# Generated at 2022-06-23 05:50:01.353732
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """Unit test for method __lt__ of class Attribute
    """

    import unittest
    import sys

    class TestAttribute___lt__(unittest.TestCase):
        def test__lt__(self):
            self.assertEqual(Attribute(0) < Attribute(1), True)
            self.assertEqual(Attribute(0) < Attribute(0), False)
            self.assertEqual(Attribute(1) < Attribute(0), False)

    res = unittest.main(
        exit=False
    ).result

    if res.wasSuccessful():
        sys.exit(0)



# Generated at 2022-06-23 05:50:05.740628
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute()
    attr2 = Attribute()
    attr2.priority = 2
    assert attr <= attr2


# Generated at 2022-06-23 05:50:08.490418
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_f = FieldAttribute(required=True)
    assert required_f.required
    required_f = FieldAttribute('str', required=True)
    assert required_f.required


# Generated at 2022-06-23 05:50:22.711059
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class Dummy(AnsibleBaseYAMLObject):
        pass
    attr = Attribute(isa=Dummy, class_type=Dummy)

    assert attr.isa == Dummy
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type == Dummy
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # With specified kwargs


# Generated at 2022-06-23 05:50:33.432283
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict')
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    a = Attribute(isa='dict', private=True, default='123', required=True)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == '123'
    assert a.required == True
    assert a.listof == None

# Generated at 2022-06-23 05:50:43.209944
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor test.
    a = Attribute()
    assert a.isa is None
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Constructor test with a large number of parameters.

# Generated at 2022-06-23 05:50:46.577698
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    f1 = FieldAttribute(priority=3)
    f2 = FieldAttribute(priority=4)
    r1 = f1 <= f2

    assert r1


# Generated at 2022-06-23 05:50:52.388808
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test for errors in the method __ge__ for class Attribute
    print("\n# Test for errors in the method __ge__ for class Attribute")
    attribute_instance_0 = Attribute()
    assert (attribute_instance_0.__ge__(2) == False)


# Generated at 2022-06-23 05:51:00.654263
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='something', priority=0)
    b = Attribute(isa='something else', priority=0)
    assert (a == b), "Attributes with equal priority should be equal"

    a = Attribute(isa='something', priority=0)
    b = Attribute(isa='something else', priority=1)
    assert (not (a == b)), "Attributes with different priority should not be equal"



# Generated at 2022-06-23 05:51:10.451139
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    f = FieldAttribute()
    f1 = FieldAttribute(priority=1)
    f2 = FieldAttribute(priority=2)
    print(f1 == f2)
    print(f2 == f1)
    print('------------------------')
    print(f1 == f)
    print(f2 == f)
    print('------------------------')
    print(f == f)
    print(f1 == f1)
    print(f2 == f2)
    print('------------------------')
    print(f == f1)
    print(f == f2)
    print(f1 == f2)
    print(f2 == f1)
    print('------------------------')
    f1.priority = 1
    f2.priority = 1
    print(f == f1)
    print(f1 == f2)

# Generated at 2022-06-23 05:51:13.790738
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr1_equal = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 == attr1_equal
    assert not attr1 == attr2


# Generated at 2022-06-23 05:51:16.735454
# Unit test for constructor of class Attribute
def test_Attribute():
    atrb = Attribute(isa='int', private=False)
    assert atrb.isa == 'int'
    assert atrb.private == False

# Generated at 2022-06-23 05:51:24.660678
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    attribute_2_1 = Attribute(priority=2)

    assert(attribute_1 < attribute_2)
    assert(attribute_1 <= attribute_2)
    assert(attribute_2 > attribute_1)
    assert(attribute_2 >= attribute_1)
    assert(attribute_2 == attribute_2_1)
    assert(attribute_2 >= attribute_2_1)
    assert(attribute_2 <= attribute_2_1)



# Generated at 2022-06-23 05:51:26.207016
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='string')
    b = Attribute(isa='int')
    assert (a == b) is True



# Generated at 2022-06-23 05:51:32.642039
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof='list',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    ) == Attribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof='list',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )

# Generated at 2022-06-23 05:51:38.796333
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(alias="foo", priority=0)
    attr2 = Attribute(alias="foo", priority=0)
    attr3 = Attribute(alias="foo", priority=1)
    assert (attr1 == attr2) is True
    assert (attr2 == attr3) is False
    assert (attr1 != attr2) is False
    assert (attr2 != attr3) is True


# Generated at 2022-06-23 05:51:43.547056
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    Attribute_a = Attribute()
    Attribute_a.priority = 3
    Attribute_b = Attribute()
    Attribute_b.priority = 4
    assert Attribute_a < Attribute_b
    Attribute_a.priority = 4
    Attribute_b.priority = 3
    assert Attribute_a > Attribute_b

# Generated at 2022-06-23 05:51:47.844765
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert a.__ge__(b) == False
    assert b.__ge__(a) == True
    assert a.__ge__(c) == True


# Generated at 2022-06-23 05:51:52.160977
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    assert a < b
    assert b > a
    assert not a == b
    assert not a >= b
    assert not a <= b
    a.priority = 2
    assert not a < b
    assert not b > a
    assert a == b
    assert a >= b
    assert a <= b



# Generated at 2022-06-23 05:51:58.029633
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Create two objects of class Attribute
    AttributeObj1 = Attribute(priority = 1)
    AttributeObj2 = Attribute(priority = 2)

    # Functionality test
    if AttributeObj1.__le__(AttributeObj2):
        print("Test passed")
    else:
        print("Test failed")



# Generated at 2022-06-23 05:52:05.641965
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False

# Generated at 2022-06-23 05:52:11.224487
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute()) is False
    assert Attribute(True).__le__(Attribute(False)) is True
    assert Attribute(priority=2).__le__(Attribute(priority=3)) is True
    assert Attribute(priority=3).__le__(Attribute(priority=3)) is True
    assert Attribute(priority=3).__le__(Attribute(priority=2)) is False


# Generated at 2022-06-23 05:52:13.440711
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert a.__ge__(b) == False
    assert b.__ge__(a) == True



# Generated at 2022-06-23 05:52:14.122365
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    pass


# Generated at 2022-06-23 05:52:16.665510
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Test that it compares attributes properly.
    """
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=0)
    assert attr1 < attr2


# Generated at 2022-06-23 05:52:22.414329
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=5)
    attribute2 = Attribute(priority=10)
    attribute3 = Attribute(priority=5)
    assert attribute1 < attribute2
    assert not attribute2 < attribute1
    assert not attribute2 < attribute3

