

# Generated at 2022-06-25 04:42:34.285582
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert (attribute_0.isa is None)
    assert (not attribute_0.private)
    assert (attribute_0.default is None)
    assert (not attribute_0.required)
    assert (attribute_0.listof is None)
    assert (attribute_0.priority == 0)
    assert (attribute_0.class_type is None)
    assert (not attribute_0.always_post_validate)
    assert (attribute_0.inherit)
    assert (attribute_0.alias is None)
    assert (not attribute_0.extend)
    assert (not attribute_0.prepend)
    assert (not attribute_0.static)
    attribute_0 = FieldAttribute(isa='string')
    assert (attribute_0.isa == 'string')

# Generated at 2022-06-25 04:42:35.241657
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()



# Generated at 2022-06-25 04:42:37.646421
# Unit test for constructor of class Attribute
def test_Attribute():
    str_for_test = 'Jk9d{LRe'
    attribute_0 = Attribute(str_for_test)


# Generated at 2022-06-25 04:42:46.747089
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Cc%'
    field_attribute_0 = FieldAttribute(str_0)
    field_attribute_0 = FieldAttribute(str_0, alias='lP^RWqI', class_type=str, listof=str, prepend=True, extend=True, always_post_validate=True, inherit=False, priority=1, required=False, private=False, default=None)
    field_attribute_0 = FieldAttribute('Yg', class_type=str, alias='Za!')
    field_attribute_0 = FieldAttribute('AuVQv1', listof=str)
    str_1 = field_attribute_0.listof
    str_2 = field_attribute_0.default
    print('field_attribute_0.listof: ', str_1)

# Generated at 2022-06-25 04:42:48.279686
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert Attribute.isa == 'Jk9d{LRe'


# Generated at 2022-06-25 04:42:52.633571
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """Test for constructor of FieldAttribute class.

    Test description:
    

    """
    # Test 0
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)


if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:02.827184
# Unit test for constructor of class Attribute
def test_Attribute():
    str_1 = 'j1eWGGpv'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()


# Generated at 2022-06-25 04:43:06.200548
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=True)

    assert field_attribute_0 == field_attribute_1

    # self.isa, self.private, self.default, self.required, self.listof, self.priority, self.class_type, self.always_post_validate, self.inherit, self.alias, self.extend, self.prepend, self.static,

# Generated at 2022-06-25 04:43:09.515033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

# Testing Constructor of class FieldAttribute
print("Testing Constructor of class FieldAttribute")
test_FieldAttribute()

# Generated at 2022-06-25 04:43:20.950416
# Unit test for constructor of class Attribute
def test_Attribute():
    # Try to create an instance of the class Attribute
    field_attribute_0 = FieldAttribute(isa='list', class_type=list, required=True, default=list)
    # Try to create an instance of the class Attribute
    field_attribute_1 = FieldAttribute(isa='list', class_type=list, required=True, default=list) 


###############################################################################
# Generated tests:
#
# WARNING: all assertions are commented-out as they crash the test suite at
#          this moment.
#
#  test_Attribute()
#  test_case_0()
#  test_case_1()
#  test_case_2()
#  test_case_3()
#  test_case_4()
#  test_case_5()
#  test_case_6()
#  test_

# Generated at 2022-06-25 04:43:24.563748
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test the constructor of class Attribute
    """
    str_0 = "eeiFtMbE"
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0 != None

if __name__ == "__main__":
    test_Attribute()
    test_case_0()

# Generated at 2022-06-25 04:43:30.412094
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'v|8WGedK*tH=G-fY7,@+]e<~JjZ&>!'
    field_attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:43:34.629515
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    assert isinstance(field_attribute_0, FieldAttribute)

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:41.605134
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 't@,b?d'
    bool_0 = True
    field_attribute_0 = FieldAttribute(str_0)
    eq_1 = (field_attribute_0.isa, str_0)
    field_attribute_0.private = bool_0
    eq_2 = (field_attribute_0.private, bool_0)
    str_1 = '73P-N+'
    field_attribute_0.default = str_1
    eq_3 = (field_attribute_0.default, str_1)
    bool_1 = False
    field_attribute_0.required = bool_1
    eq_4 = (field_attribute_0.required, bool_1)
    str_2 = 'P_oG{,o'
    field_attribute_0.listof = str_2

# Generated at 2022-06-25 04:43:53.052444
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_0.alias = 'jqHWRQ'
    field_attribute_0.always_post_validate = ';P!o?Xu(7'
    field_attribute_0.inherit = True
    field_attribute_0.listof = ';P!o?Xu(7'
    field_attribute_0.private = True
    field_attribute_0.required = 'v9>W)%z'
    field_attribute_0.static = True
    field_attribute_0.prepend = True
    field_attribute_0.extend = True
    field_attribute_0.default = 'y%&+~L5rv'
    field_attribute_0.class_type = 'y%&+~L5rv'
   

# Generated at 2022-06-25 04:43:55.852225
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '1ie?=1}'
    field_attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:44:01.614637
# Unit test for constructor of class Attribute
def test_Attribute():
    # Setting up object value
    int_0 = 9

    # Instantiating object
    attribute_0 = Attribute()
    attribute_0.isa = int_0

    # Getting field values from object
    int_1 = attribute_0.isa

    # Testing field values for equality
    assert int_1 == int_0



# Generated at 2022-06-25 04:44:08.425974
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    str_1 = 'n[=H$5oK'
    field_attribute_1 = FieldAttribute(str_1)
    str_2 = '@a"9f^>'
    field_attribute_2 = FieldAttribute(str_2)
    bool_0 = field_attribute_0 == field_attribute_1
    bool_1 = field_attribute_0 == field_attribute_2
    bool_2 = field_attribute_1 == field_attribute_2


# Generated at 2022-06-25 04:44:09.887514
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'j#o{v'
    field_attribute_0 = FieldAttribute(str_0)
    assert (field_attribute_0 is not None)


# Generated at 2022-06-25 04:44:13.513038
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Jk9d{LRe'
    assert Attribute.__init__(None, str_0) == 'Jk9d{LRe'



# Generated at 2022-06-25 04:44:20.181975
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'lOfX9bEr'
    field_attribute_0 = Attribute(str_0)



# Generated at 2022-06-25 04:44:30.825057
# Unit test for constructor of class Attribute
def test_Attribute():

    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    assert field_attribute_0 != str


# Generated at 2022-06-25 04:44:37.054827
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute('M4dGF2X')
    if str(field_attribute_0.isa) != 'M4dGF2X':
        print('Failed to construct an instance of Attribute')
        raise RuntimeError('Test failed')
    pass



# Generated at 2022-06-25 04:44:41.943555
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'u}7)^W{=9M'
    field_attribute_0 = FieldAttribute(str_0)
    class_type_0 = field_attribute_0.__class__
    print(class_type_0)
    var_0 = isinstance(field_attribute_0, class_type_0)
    print(var_0)


if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:44:48.876214
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Jk9d{LRe'
    str_1 = '8Ov>'
    str_2 = 'wW7G8'
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.private == False
    assert field_attribute_0.class_type == None
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.isa == str_0
    assert field_attribute_0.default == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field

# Generated at 2022-06-25 04:44:59.000275
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test case 0
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    # Test case 1
    str_0 = 'Jk9d{LRe'
    boolean_0 = False
    dict_0 = dict()
    dict_0['default'] = dict_0
    dict_0['required'] = dict_0
    dict_0['private'] = dict_0
    dict_0['isa'] = dict_0
    dict_0['listof'] = dict_0
    dict_0['priority'] = dict_0
    dict_0['class_type'] = dict_0
    dict_0['always_post_validate'] = dict_0
    dict_0['inherit'] = dict_0
    dict_0['alias'] = dict

# Generated at 2022-06-25 04:45:00.343954
# Unit test for constructor of class Attribute
def test_Attribute():
    assert FieldAttribute('Jk9dLRe') != None



# Generated at 2022-06-25 04:45:01.223418
# Unit test for constructor of class Attribute
def test_Attribute():
    pass


# Generated at 2022-06-25 04:45:10.163917
# Unit test for constructor of class Attribute
def test_Attribute():
    print("Testing constructor of class Attribute")
    isa = "str"
    default = "value"
    required = True
    listof = "str"
    priority = 0
    class_type = object
    always_post_validate = False
    inherit = True
    alias = None
    field_attribute_0 = FieldAttribute(isa, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    print(field_attribute_0.isa)
    print(field_attribute_0.default)
    print(field_attribute_0.required)
    print(field_attribute_0.listof)
    print(field_attribute_0.priority)
    print(type(field_attribute_0.class_type))

# Generated at 2022-06-25 04:45:21.292234
# Unit test for constructor of class Attribute
def test_Attribute():

    # test with valid parameters
    str_0 = 'Jk9d{LRe'
    bool_0 = bool('HWX')
    bool_1 = bool('q')
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    #list_0 = [bool_0, bool_1, bool_0]
    
    #str_1 = 'Jk9d{L

# Generated at 2022-06-25 04:45:38.630365
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor test
    str_0 = 'Pch!&_NN'
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.isa == "Pch!&_NN"
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
   

# Generated at 2022-06-25 04:45:39.544678
# Unit test for constructor of class Attribute
def test_Attribute():
    obj_0 = Attribute()


# Generated at 2022-06-25 04:45:40.417459
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
	# REVIEW: Should be tested for coverage
	test_case_0()


# Generated at 2022-06-25 04:45:42.324822
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'z'
    field_attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:45:45.407010
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0) # expected: Pass
    str_1 = 'XB6Qe'
    field_attribute_0 = FieldAttribute(str_1) # expected: Pass


# Generated at 2022-06-25 04:45:50.195067
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute('')
    field_attribute_2 = FieldAttribute('')
    str_0 = 'jO`~Eo0*ZO]u'
    field_attribute_3 = FieldAttribute(str_0)

# Unit test to test equality operator of class FieldAttribute

# Generated at 2022-06-25 04:45:52.675013
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute('Jk9d{LRe')
    field_attribute_1 = FieldAttribute('required=False', 'prepend=False')

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:45:55.479553
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'QAaT6Jw'
    field_attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:45:56.560712
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()



# Generated at 2022-06-25 04:45:59.056355
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'N<8~|QH'
    field_attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:46:20.510958
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Testing 'FieldAttribute' constructor
    assert callable(FieldAttribute)
    # FieldAttribute should be callable
    assert callable(FieldAttribute)
    # Testing if an exception is raised and if it's the correct type
    try:
        field_attribute_0 = FieldAttribute()
        # test if an exception was raised
        assert False
    except TypeError as e:
        # test if the correct exception was raised
        assert e.args[0] == "__init__() missing 1 required positional argument: 'isa'"
    try:
        field_attribute_0 = FieldAttribute()
        # test if an exception was raised
        assert False
    except TypeError as e:
        # test if the correct exception was raised
        assert e.args[0] == "__init__() missing 1 required positional argument: 'isa'"
    # Testing 'FieldAttribute'

# Generated at 2022-06-25 04:46:26.406660
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.isa == 'Jk9d{LRe'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute

# Generated at 2022-06-25 04:46:29.008489
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:46:30.327992
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        test_case_0()
    except Exception as exc:
        assert False, "Exception fail: " + exc.message



# Generated at 2022-06-25 04:46:41.444220
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Do we get the right value for instance variable isa?
    attr = FieldAttribute('string')
    assert attr.isa == 'string'
    # Do we get the right value for instance variable private?
    attr = FieldAttribute(private=True)
    assert attr.private == True
    # Do we get the right value for instance variable default?
    attr = FieldAttribute(default='default string')
    assert attr.default == 'default string'
    # Do we get the right value for instance variable required?
    attr = FieldAttribute(required=True)
    assert attr.required == True
    # Do we get the right value for instance variable listof?
    attr = FieldAttribute(listof='list string')
    assert attr.listof == 'list string'
    # Do we get the right value for instance variable priority

# Generated at 2022-06-25 04:46:51.638464
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Qf=L-!_'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()


# Generated at 2022-06-25 04:46:53.476892
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    with pytest.raises(TypeError) as error_info:
        test_case_0()


# Generated at 2022-06-25 04:47:02.240698
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute('wE[*')
    assert field_attribute_1.default is None
    assert field_attribute_1.required is False
    assert field_attribute_1.listof is None
    assert field_attribute_1.inherit is True
    assert field_attribute_1.priority == 0

    field_attribute_2 = FieldAttribute('MCZa9')
    assert field_attribute_2.default is None
    assert field_attribute_2.required is False
    assert field_attribute_2.listof is None
    assert field_attribute_2.inherit is True
    assert field_attribute_2.priority == 0

    field_attribute_3 = FieldAttribute('yI25')
    assert field_attribute_3.default is None
    assert field_attribute_3.required is False

# Generated at 2022-06-25 04:47:07.076620
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'A9Y7KVO'
    str_1 = 'wF62Pb'
    attr = Attribute()
    attr = Attribute(str_0)
    attr = Attribute(str_0, str_1)


# Generated at 2022-06-25 04:47:11.679060
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test that a value error is raised when no arguments are provided
    try:
        attribute_0 = Attribute()
        assert False
    except ValueError:
        assert True

    str_0 = 'HGZFogn8'
    dict_0 = dict()
    dict_0['8fv_'] = str_0
    field_attribute_0 = FieldAttribute(**dict_0)


# Generated at 2022-06-25 04:47:34.483880
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    first_name = FieldAttribute(alias='first_name')
    last_name = FieldAttribute(alias='last_name')
    print('i am in FieldAttribute')
    print('The value of first_name is:', first_name)
    print('The value of last_name is:', last_name)
test_FieldAttribute()


# This test will verify the above class Field_Attribute is working fine or not

# Generated at 2022-06-25 04:47:37.237294
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'wYJZD|3q'
    field_attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:47:38.189222
# Unit test for constructor of class Attribute
def test_Attribute():
    pass


# Generated at 2022-06-25 04:47:45.394424
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Testing constructor
    constructor_test_0 = FieldAttribute('kxuK7VON')
    assert constructor_test_0.isa =='kxuK7VON'
    assert constructor_test_0.private == False
    assert constructor_test_0.default is None
    assert constructor_test_0.required == False
    assert constructor_test_0.listof is None
    assert constructor_test_0.priority == 0
    assert constructor_test_0.class_type is None
    assert constructor_test_0.always_post_validate == False
    assert constructor_test_0.inherit == True
    assert constructor_test_0.alias is None
    assert constructor_test_0.extend == False
    assert constructor_test_0.prepend == False
    assert constructor_test_0.static == False

# Generated at 2022-06-25 04:47:55.875441
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute()
    assert obj.isa is None, "Field constructor does not match"
    assert obj.private is False, "Field constructor does not match"
    assert obj.default is None, "Field constructor does not match"
    assert obj.required is False, "Field constructor does not match"
    assert obj.listof is None, "Field constructor does not match"
    assert obj.priority == 0, "Field constructor does not match"
    assert obj.class_type is None, "Field constructor does not match"
    assert obj.always_post_validate is False, "Field constructor does not match"
    assert obj.inherit is True, "Field constructor does not match"
    assert obj.alias is None, "Field constructor does not match"
    assert obj.extend is False, "Field constructor does not match"
    assert obj.pre

# Generated at 2022-06-25 04:47:59.355440
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # First, test constructor
    FieldAttribute_attribute = FieldAttribute()
    # No other unit test method.


# Generated at 2022-06-25 04:48:07.741099
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '8[uFbqE'
    field_attribute_0 = FieldAttribute(str_0)
    str_1 = 'W8c{;b[3'
    field_attribute_0 = FieldAttribute(str_1)
    str_2 = 'z{f?;2}x'
    field_attribute_0 = FieldAttribute(str_2)
    str_3 = 'X)4!b6h|'
    field_attribute_0 = FieldAttribute(str_3)
    str_4 = 'yG`^z`Er'
    field_attribute_0 = FieldAttribute(str_4)
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:48:18.524523
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    attribute_1 = Attribute(dict())
    attribute_2 = Attribute(set())
    attribute_3 = Attribute(bool())
    attribute_4 = Attribute(float())
    attribute_5 = Attribute(list())
    attribute_6 = Attribute(int())
    attribute_7 = Attribute(str())
    attribute_8 = Attribute('#chW2OU1')
    attribute_9 = Attribute(str_0=str())
    attribute_10 = Attribute(str_0=str())
    attribute_11 = Attribute(str_0=str('hello world'))
    attribute_12 = Attribute(str_0=str())
    attribute_13 = Attribute(str_0=str())
    attribute_14 = Attribute(str_0=str())
    attribute_

# Generated at 2022-06-25 04:48:22.394650
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Hk9d{LRe'
    str_1 = 'Hk9d{LRe'
    str_2 = 'Hk9d{LRe'
    str_3 = 'Hk9d{LRe'
    str_4 = 'Hk9d{LRe'
    str_5 = 'Hk9d{LRe'
    str_6 = 'Hk9d{LRe'
    str_7 = 'Hk9d{LRe'
    str_8 = 'Hk9d{LRe'
    str_9 = 'Hk9d{LRe'

# Generated at 2022-06-25 04:48:30.325052
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0
    field_attribute_2 = FieldAttribute()
    assert field_attribute_2
    field_attribute_1 = FieldAttribute()
    assert field_attribute_1
    field_attribute_3 = FieldAttribute()
    assert field_attribute_3
    field_attribute_4 = FieldAttribute()
    assert field_attribute_4
    field_attribute_5 = FieldAttribute()
    assert field_attribute_5
    field_attribute_6 = FieldAttribute()
    assert field_attribute_6
    field_attribute_7 = FieldAttribute()
    assert field_attribute_7
    field_attribute_8 = FieldAttribute()
    assert field_attribute_8
    field_attribute_9 = FieldAttribute()
    assert field_attribute_9
    field_attribute_10 = FieldAttribute

# Generated at 2022-06-25 04:49:19.857598
# Unit test for constructor of class Attribute
def test_Attribute():
    #__init__(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False)

    # Test the case where isa is not one of the types allowed
    try:
        field_attribute_0 = FieldAttribute('int')
        assert(False)
    except TypeError:
        assert(True)

    # Test the case where isa is a stringified native type
    field_attribute_0 = FieldAttribute('int')
    assert(field_attribute_0.isa == 'int')

    # Test the case where isa is a class
    field_attribute_0 = FieldAttribute(int)
    assert(field_attribute_0.class_type == int)

    # Test the case

# Generated at 2022-06-25 04:49:27.242444
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.isa == 'Jk9d{LRe'
    assert field_attribute_0.private == False
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    assert field_attribute

# Generated at 2022-06-25 04:49:31.610501
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Jk9d{LRe'
    field_attribute_0 = FieldAttribute(str_0)
    print(field_attribute_0.isa)



# Generated at 2022-06-25 04:49:40.026218
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Jk9d{LRe'
    assert Attribute(str_0).isa == 'Jk9d{LRe'
    str_0 = 'k~2310'
    assert Attribute(str_0).isa == 'k~2310'
    str_0 = 'Y;Fw]*'
    assert Attribute(str_0).isa == 'Y;Fw]*'
    str_0 = 'Jk9d{LRe'
    assert Attribute(str_0).isa == 'Jk9d{LRe'
    str_0 = 'VuQrD8'
    assert Attribute(str_0).isa == 'VuQrD8'
    str_0 = 'uD}P8V'

# Generated at 2022-06-25 04:49:41.563112
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()
if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:49:51.865320
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Jk9d{LRe'
    str_1 = 'dsz$Dm>|'
    str_2 = '-j?SZljo'
    field_attribute_0 = FieldAttribute(str_0, str_1, str_2)
    assert field_attribute_0.isa == str_0
    assert field_attribute_0.private == str_1
    assert field_attribute_0.default == str_2
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True


# Generated at 2022-06-25 04:49:53.945160
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # If
    str_0 = 'Jk9d{LRe'

    # When
    field_attribute_0 = FieldAttribute(str_0)

    # Then assert
    assert True



# Generated at 2022-06-25 04:49:54.869630
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:50:03.000530
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '8o.PdFp'
    field_attribute_0 = FieldAttribute(str_0)
    class_0 = field_attribute_0.__class__
    str_1 = 'Attribute'
    assert(str_1 == class_0.__name__)
    field_attribute_1 = Attribute()
    class_1 = field_attribute_1.__class__
    str_2 = 'Attribute'
    assert(str_2 == class_1.__name__)


# Generated at 2022-06-25 04:50:09.687762
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        test_case_0()
        assert True
    except TypeError as e:
        print('Exception: ', e)
        return
    except Exception as e:
        print('Exception: ', e)
        return
    else:
        print('SUCCESS: test_FieldAttribute() ')

if __name__ == "__main__":
    test_FieldAttribute()