

# Generated at 2022-06-25 04:42:31.802950
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "Rw)P:lN<j+n#A0"
    str_1 = "A;p~,?@%]}qHAu"
    str_2 = ").&O#?jB]8'&s)"
    str_3 = "O(T\\T[:r^l*F"
    str_4 = "F`-;G#x;)!"
    str_5 = "YQ7<:Dg=uQXo]?t"
    str_6 = "f!T[BSG1J$E(}c@"
    str_7 = "\x1c\x7f"
    str_8 = "\x8b\xa1"
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}

# Generated at 2022-06-25 04:42:33.036828
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:42:38.590507
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "MU^W5Zv}L<|f&;(JE/W1"
    bytes_0 = b'\xd5\x0e\x01\xd5\x97\x1b\x8b\x1c\xb4\xcd\x8d\x05\x0e\x95\xab\xb2\xf2\x0b\xf7\xe9\x90\xe3\x06\xbd\xcb'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert field_attribute_0 is not None

# Unit test to check constructor of class FieldAttribute

# Generated at 2022-06-25 04:42:42.727537
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\x81\xd9\xd9<\x9c\xa6\x1d\xb3\x10\xda\xae\x0b\x9fH\xd4\xa1\t'
    str_0 = ".\xe3\xeb\x06\x9f&\x9f'\xed\xe4\xda\x1f&\xbc\x05\xaf\x9c\\"
    str_1 = '(\xd1\x16\xea\xae\x17\x11\xca\x1c\xd9\xdd\xb5\xdc\x0f\x94\x1b\x80\xb0\x11\x1c'

# Generated at 2022-06-25 04:42:46.315799
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "FG\x03rG\x0e;\x1e"
    field_attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:42:57.038245
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "GL)"
    str_1 = "h"
    str_2 = "e\\|"
    bool_0 = False
    field_attribute_0 = FieldAttribute(str_0, bool_0, str_1, str_2)
    assert isinstance(field_attribute_0, FieldAttribute)
    assert field_attribute_0.isa == str_0
    assert field_attribute_0.private == bool_0
    assert field_attribute_0.default == str_1
    assert field_attribute_0.required == str_2

    str_0 = "w7@L<~"
    str_1 = "1"
    str_2 = "=!>"
    field_attribute_0 = FieldAttribute(str_0, str_2, default=str_1)
    assert field_attribute_0

# Generated at 2022-06-25 04:43:05.008785
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "ut^zs{=xC('s1[S0C49+kP{JZML0@<f9b4P+tIaEt*}mG.HkIq~YwG/f<2JhE_O9`+R=l`1W8\x7fJKB;_uR7aA:~MkV7E]|"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:43:10.258624
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "*&pozjK)5"
    field_attribute_0 = FieldAttribute(str_0)
    @test_FieldAttribute.register('test_FieldAttribute')
    def test_FieldAttribute():
        assert field_attribute_0.class_type is None
        assert field_attribute_0.default is None
        assert field_attribute_0.inherit is True
        assert field_attribute_0.isa == str_0
        assert field_attribute_0.listof is None
        assert field_attribute_0.prepend is False
        assert field_attribute_0.private is False
        assert field_attribute_0.required is False
        assert field_attribute_0.static is False
        assert field_attribute_0.priority == 0
        assert field_attribute_0.extend is False
        assert field_

# Generated at 2022-06-25 04:43:21.555038
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "!a2v"
    bytes_0 = b'6\xa2\xbe\x98\xfc\xf7\xde'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert not hasattr(field_attribute_0, "isa")
    assert not hasattr(field_attribute_0, "private")
    assert not hasattr(field_attribute_0, "default")
    assert not hasattr(field_attribute_0, "required")
    assert not hasattr(field_attribute_0, "listof")
    assert not hasattr(field_attribute_0, "priority")
    assert not hasattr(field_attribute_0, "class_type")
    assert not hasattr(field_attribute_0, "always_post_validate")

# Generated at 2022-06-25 04:43:25.320762
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    print(str_0)
    print(field_attribute_0)

if __name__ == '__main__':
    test_FieldAttribute()
    print('[*] done')

# Generated at 2022-06-25 04:43:39.989784
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    int_0 = 2141114

# Generated at 2022-06-25 04:43:52.131502
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "Rd\x1a\xfe\x04\x01\x0e\x00\x04\x00)\\\x1a\x00\x00\x01\x00\x00"
    bytes_0 = b'\xbc\xd2\x8b5\xbf\xcc\x95j\x8c\x1d\xef\x14\x9d\xbd\xd3\xabC\xea.\xf8\xd1\xa2\xef\xe5'
    field_attribute_0 = FieldAttribute(bytes_0)
    class_0 = field_attribute_0.class_type
    assert class_0 is None
    isa_0 = field_attribute_0.isa
    assert isa_0 == bytes_0
    list

# Generated at 2022-06-25 04:43:59.816184
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = ""
    bytes_0 = b'}$\xda\xed\x9f\x92\xa9\xae\xeb\x85\x84\xbe5\x0e\xe2\xad\xb3\x9d\x9cU\xbb\xdc'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:44:09.722645
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa=str)
    field_attribute_2 = FieldAttribute(isa='a_string')
    field_attribute_3 = FieldAttribute(isa='int')
    field_attribute_4 = FieldAttribute(isa='float')
    field_attribute_5 = FieldAttribute(isa='bool')
    field_attribute_6 = FieldAttribute(isa=None)
    field_attribute_7 = FieldAttribute(isa='list')
    field_attribute_8 = FieldAttribute(isa='dict')
    field_attribute_9 = FieldAttribute(isa='set')
    field_attribute_10 = FieldAttribute(isa=1337)
    field_attribute_11 = FieldAttribute(isa=3.14159)
    field_attribute_12 = FieldAttribute(isa=True)
    field

# Generated at 2022-06-25 04:44:18.905489
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    expected_str = "_/X%T*eB'4SA$N.^<Uj"
    expected_bytes = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    test_var_0 = FieldAttribute(expected_bytes)
    actual_str = test_var_0.isa
    actual_bytes = test_var_0.listof
    assert actual_str == expected_str
    assert actual_bytes == expected_bytes
    expected_str = "_/X%T*eB'4SA$N.^<Uj"

# Generated at 2022-06-25 04:44:20.964429
# Unit test for constructor of class Attribute
def test_Attribute():
    A = Attribute()
    # Checks that A is an instance of class Attribute
    assert isinstance(A, Attribute)



# Generated at 2022-06-25 04:44:21.830356
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Unit tests for Attribute class

# Generated at 2022-06-25 04:44:24.067488
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:44:33.053368
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:44:40.783089
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert callable(FieldAttribute.__init__)

str_0 = "_/X%T*eB'4SA$N.^<Uj"
bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
field_attribute_0 = FieldAttribute(bytes_0)

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:44:54.335721
# Unit test for constructor of class Attribute
def test_Attribute():
    # Define the parameters with default values
    #Initialise the class
    myAttribute = Attribute()
    
    assert class_params(Attribute, myAttribute) == {'alias': None, 'always_post_validate': False, 'class_type': None, 'default': None, 'extend': False, 'inherit': True, 'isa': None, 'listof': None, 'prepend': False, 'priority': 0, 'private': False, 'required': False, 'static': False}
    #Verify the result

# Generated at 2022-06-25 04:44:57.713701
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "m2l,$a'`SJ( "
    field_attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:45:06.210815
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "w,[Mq\\x1a\x1d;\x9c"
    int_0 = -1801721
    str_1 = "w,[Mq\\x1a\x1d;\x9c"
    int_1 = -1801721
    str_2 = "w,[Mq\\x1a\x1d;\x9c"
    int_2 = -1801721
    str_3 = "w,[Mq\\x1a\x1d;\x9c"
    int_3 = -1801721
    str_4 = "w,[Mq\\x1a\x1d;\x9c"
    int_4 = -1801721
    str_5 = "w,[Mq\\x1a\x1d;\x9c"

# Generated at 2022-06-25 04:45:15.233198
# Unit test for constructor of class Attribute

# Generated at 2022-06-25 04:45:26.907531
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Run test with expected results
    str_0 = "f\x07\xef\xc3\xbd~\x9a\x19\xf3\xe4\x94\xe1\x19\xa5\x99\xc5"
    bytes_0 = b'\x1e\xaf\xd8\x98M\x0f\xb5\xbc\xb2\x9b\xbe\xa6\xac\xce\xd0\xf6\x94'
    bytes_1 = b'\xd4\x15\xfb\x99\xbf\x84\xa5\x96\xe5\x9d\xaa\x9b\x9b\xfd\xeb\xfd'

# Generated at 2022-06-25 04:45:38.657494
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Assumption: that there exists a class named 'FieldAttribute' and that it
    # has at least one constructor
    class_0 = FieldAttribute
    # Assumption: that the  constructor 'FieldAttribute' has a parameter
    # named 'isa'
    isa_0 = FieldAttribute.__init__.__code__.co_varnames[2]
    # Assumption: that the  constructor 'FieldAttribute' has a parameter
    # named 'private'
    private_0 = FieldAttribute.__init__.__code__.co_varnames[1]
    # Assumption: that the  constructor 'FieldAttribute' has a parameter
    # named 'default'
    default_0 = FieldAttribute.__init__.__code__.co_varnames[3]
    # Assumption: that the  constructor 'FieldAttribute' has a parameter

# Generated at 2022-06-25 04:45:43.630246
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "LQXhvO{C:Q0[D)"
    bytes_0 = b"8l\xf6\xfc\x12\x14\x8c\xcd\xc5\x0f\x95\xfb\xfb>\xbf\xf9\x9f\x8c\xc2\x06\xbc\x12\x8a\x84\x1c\x9a\x95n\xc7\xed\x14\x15"
    field_attribute_0 = FieldAttribute(bytes_0, alias=str_0)
    field_attribute_0 = FieldAttribute(bytes_0, class_type=bytes_0)
    field_attribute_0 = FieldAttribute(bytes_0, default=bytes_0)
    field_attribute_0 = FieldAttribute

# Generated at 2022-06-25 04:45:50.208645
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute.__init__(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert( field_attribute_0.isa == bytes_0 )
    assert( field_attribute_0.private == False )

# Generated at 2022-06-25 04:46:01.775907
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "u\x15\xd7\xa0\xdc\xdf\x04\xab\x03\x9d\x92\x17\x15\x1b\x91V\x17\\Q\x08\x9f\x10\xb3\x89\x1a\x95\x18\xfa\xa9\x1b\x9c"
    field_attribute_2 = FieldAttribute(str_0)

    # Verify that this class can be instantiated.
    integer_0 = 1672213232
    unicode_0 = u'\u5d70\u6c57\u8a1b\u5b13'
    long_0 = -8176748377755581543

# Generated at 2022-06-25 04:46:09.137224
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "Q'#d\x84c%/F\x99y\x95\x9e\x16\xac\x95\x90\x83\x12\x8a\x84\xdc)@\x8cQ"

# Generated at 2022-06-25 04:46:16.897685
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Initialize a FieldAttribute object
    field_attribute_0 = FieldAttribute('__')


# Generated at 2022-06-25 04:46:24.879875
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "^Kd\x06b\xcb\xc5\xa1\xc5\x95\xa2"
    bytes_0 = b'\x10\xcc\x1e\xb4\xf4\xcfP\x19\xa3\xec\x92\x1d\xa8\x18\xa0\x1f\x9f\xa2'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert isinstance(field_attribute_0, FieldAttribute) == True


# Generated at 2022-06-25 04:46:28.801375
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "T($p*\xf7\x10U2"
    bytes_0 = b'\xa6\x7f\x94\xe2\xe5_\xad\xd9\x9b\xdb\x0c-'
    bool_0 = True
    attribute_0 = Attribute(listof=bool_0, class_type=str_0, default=bytes_0)


# Generated at 2022-06-25 04:46:35.979432
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "k-jK)Ft<8BZWmBd%-"
    str_1 = "T2(yFbk-\x0f]"
    str_2 = "~sK\\\x17Cc%\x15\x1ej"
    str_3 = "\x0b\x15\x1e\x1a\x1a\x1f\x14\x19\x13\x1f\x0b\x1b\x1b\x1b\x08"
    str_4 = "\x13\x19\x13\x11\x1f\x19\x1b\x18\x1d"
    FieldAttribute()
    FieldAttribute(str_0, str_1, str_2, str_3)

# Generated at 2022-06-25 04:46:47.490451
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "fM?o0S2|S1>J{Z"
    bytes_0 = b'\xc1\xcc\x02\xc0\x0f\r\xb6m\xee\xe9\x1c\x13\xce\xfa\xa1G\xbd\xa0\xe0\x0c\xea'
    field_attribute_0 = FieldAttribute(bytes_0)
    str_1 = 'B[z9Moj\x0c0\x7f'

# Generated at 2022-06-25 04:46:54.897377
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "oC`L\xeb+\x1b\xd6\x10"
    bytes_0 = b'V\x92\x1f\x9e\xfe\\\xf8\xe3\xaa\xef\xba'
    str_1 = "^\xc1\x1d\x0f9A\xad\x0f\x93"
    str_list_0 = [str_0, str_1]

# Generated at 2022-06-25 04:47:02.824185
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_3 = ''
    bytes_3 = b'\xe9\x9f\xbe\x01b\xef\x16\x88\x93\x1d\xef\xcc\x9d\xcca\x11\xd0\xf5\xb7'
    isa_0 = str_3
    private_0 = False
    default_0 = None
    required_0 = False
    listof_0 = None
    priority_0 = 0
    class_type_0 = None
    always_post_validate_0 = False
    inherit_0 = True
    alias_0 = None
    extend_0 = False
    prepend_0 = False
    static_0 = False

# Generated at 2022-06-25 04:47:12.594237
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert field_attribute_0.isa == bytes_0
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False

# Generated at 2022-06-25 04:47:18.257962
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "g.a;wf:M(H:~j!Y$_"
    bytes_0 = b'A\x8c\xcc\x98\x03\xa2\xc8\xa1\xeb\xec\xe4\x0f\x06\x14\x03\xdc'
    FieldAttribute(bytes_0, str_0)


# Generated at 2022-06-25 04:47:25.539821
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "1#~&C@!tJHL,t[>oY.p"
    bytes_0 = b'\xb0\xeeS\x84\x8e\x0e\xbe\x13\x04\xd1\x9d)\xba\xc6\x88\x8a\x1b\xa5'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:47:38.616287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    if field_attribute_0.isa is not None:
        # test constructors of FieldAttribute
        test_case_0()
    else:
        assert(False)



# Generated at 2022-06-25 04:47:42.184481
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "k/)SOz^h'Sg}6O?[6"
    bytes_0 = b'\xa8\xa5\xe6\x14\xdb\xc0\xcd\xd2\x9c\x1d\xf8\xe5\x1e\x0e\xd6S\xa6\x82\x9b\xd4\xdb'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert field_attribute_0.isa == bytes_0
    assert field_attribute_0.private == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True

# Generated at 2022-06-25 04:47:48.117878
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:47:57.296652
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '&'
    attribute_0 = Attribute(
        alias=str_0
    )
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.required is True
    assert attribute_0.default is None
    assert attribute_0.listof is True
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False
    assert attribute_0.static is False


# Generated at 2022-06-25 04:48:01.637044
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "t1zH?IY"
    str_1 = "5$5"
    bytes_0 = b"Dl\xbf"
    field_attribute_0 = FieldAttribute(str_0, str_1, default=bytes_0, class_type=str_1, listof=str_0)
    assert field_attribute_0 is not None, 'Failed to test FieldAttribute()'


# Generated at 2022-06-25 04:48:12.935787
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:48:18.542186
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = ":"
    field_attribute_0 = FieldAttribute()

    field_attribute_0 = FieldAttribute(str_0)
    assert (field_attribute_0.isa == str_0)
    field_attribute_1 = FieldAttribute()
    assert (field_attribute_1.isa == field_attribute_0.isa)

    field_attribute_0 = FieldAttribute(private=True)
    assert (field_attribute_0.private == True)
    field_attribute_1 = FieldAttribute()
    assert (field_attribute_1.private == field_attribute_0.private)

    field_attribute_0 = FieldAttribute(required=True)
    assert (field_attribute_0.required == True)
    field_attribute_1 = FieldAttribute()

# Generated at 2022-06-25 04:48:22.716410
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    dict_0 = dict()
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    field_attribute_1 = FieldAttribute(isa=int)
    assert(field_attribute_1.isa == int)
    assert(field_attribute_1.private == False)
    assert(field_attribute_1.default == None)
    assert(field_attribute_1.required == False)
    assert(field_attribute_1.listof == None)

# Generated at 2022-06-25 04:48:30.279537
# Unit test for constructor of class Attribute
def test_Attribute():
    print("Testing Attribute")
    str_1 = "TZ,?N=:o*Rj#p`f,$y4("
    field_attribute_0 = FieldAttribute(str_1)
    assert field_attribute_0.isa == "TZ,?N=:o*Rj#p`f,$y4("
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.alias == None


# Generated at 2022-06-25 04:48:36.889047
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "8fT@!G!?y2N:R:k"
    int_0 = -7611
    str_1 = "8fT@!G!?y2N:R:k"
    int_1 = -7611
    str_2 = "8fT@!G!?y2N:R:k"
    int_2 = -7611
    str_3 = "8fT@!G!?y2N:R:k"
    int_3 = -7611
    str_4 = "8fT@!G!?y2N:R:k"
    int_4 = -7611
    str_5 = "8fT@!G!?y2N:R:k"
    int_5 = -7611

# Generated at 2022-06-25 04:49:21.973360
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'file'
    list_0 = []
    field_attribute_0 = FieldAttribute(str_0, required=True, extend=True, prepend=True, default=list_0)
    str_1 = 'list'
    str_2 = 'file'
    field_attribute_1 = FieldAttribute(str_1, listof=str_2, required=True, extend=True, prepend=True, default=list_0)
    str_3 = 'jK4+9|8{n'
    bytes_0 = _CONTAINERS
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['35'] = field_attribute_0
    dict_1['36'] = field_attribute_1
    dict_2['34'] = dict_1

# Generated at 2022-06-25 04:49:27.105318
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = ".X_KM|8F,rq3v;k^C5"
    str_1 = "x\x1e\x9b\\#\x8d\x85\x00}\x01\x07\x1d\x14\x9b\x0b\x8c\x0f\xdb\xaa\xec\x8e\x1f\x84\xbc\xdf\x94"
    field_attribute_0 = FieldAttribute(str_1, str_0)



# Generated at 2022-06-25 04:49:38.971831
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    assert isinstance(field_attribute_0, Attribute)
    assert field_attribute_0.isa == bytes_0
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
   

# Generated at 2022-06-25 04:49:46.308715
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:49:54.251965
# Unit test for constructor of class Attribute
def test_Attribute():
    # Signature: (isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    str_0 = "n(a(t/'A9dz}t"
    field_attribute_1 = FieldAttribute(str_0)

    assert "n(a(t/'A9dz}t" in field_attribute_1.isa
    str_0 = "n(a(t/'A9dz}t"

# Generated at 2022-06-25 04:50:04.881003
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        FieldAttribute(default=1)

    with pytest.raises(TypeError):
        FieldAttribute(prepend=None)

    with pytest.raises(TypeError):
        FieldAttribute(extend=None)

    with pytest.raises(TypeError):
        FieldAttribute(listof=None)

    with pytest.raises(TypeError):
        FieldAttribute(class_type=None)

    with pytest.raises(TypeError):
        FieldAttribute(inherit=None)

    with pytest.raises(TypeError):
        FieldAttribute(isa=None)

    with pytest.raises(TypeError):
        FieldAttribute(priority=None)

    with pytest.raises(TypeError):
        FieldAttribute(required=None)


# Generated at 2022-06-25 04:50:12.406800
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6\""
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
# END tests for class FieldAttribute



# Generated at 2022-06-25 04:50:20.316672
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    field_attribute_2 = FieldAttribute()
    field_attribute_3 = FieldAttribute()
    field_attribute_4 = FieldAttribute()
    field_attribute_5 = FieldAttribute()
    field_attribute_6 = FieldAttribute()
    field_attribute_7 = FieldAttribute()
    field_attribute_8 = FieldAttribute()
    field_attribute_9 = FieldAttribute()
    field_attribute_10 = FieldAttribute()
    field_attribute_11 = FieldAttribute()
    field_attribute_12 = FieldAttribute()
    field_attribute_13 = FieldAttribute()
    field_attribute_14 = FieldAttribute()
    field_attribute_15 = FieldAttribute()
    field_attribute_16 = FieldAttribute()
    field_attribute_17 = FieldAttribute()
    field_attribute_18 = FieldAttribute()
   

# Generated at 2022-06-25 04:50:28.705255
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "3\x1b"
    str_1 = "\\"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)
    field_attribute_1 = FieldAttribute(bytes_0)
    str_2 = "#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6\""
    field_attribute_0.listof = str_0
    assert field_attribute_0.listof == str_1
    field_attribute_0.default = field_

# Generated at 2022-06-25 04:50:38.897525
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test instance
    str_0 = '%c.68'
    str_1 = "`GA\\m'\\5xV7"
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.isa == '%c.68'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
   

# Generated at 2022-06-25 04:51:25.391556
# Unit test for constructor of class Attribute
def test_Attribute():
  str_0 = "dd]D;\x94<@3i0:U|"
  bytes_0 = b'q\x89\xa3\x1a\x0f\x80\x8d\xfe\x15\x0c\x94\x9eW\xfe\x14\x97\x1e\xd5\x0f\xd7\xab\x9dW\xaf4\xeb'
  bytes_1 = b'\xdf\x91\xf7\x0b\x9d\xe1\xcf\x0f\x8c\xf5\x84\xd0\xab\xf9\x13\x11\x93\x81\x0b\x8b'
  int_0 = -1

# Generated at 2022-06-25 04:51:28.481389
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'jd"G4&q]'
    field_attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:51:38.754661
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bytes_0 = b'Xo\x80\xf1\xfc\x0f\x0e\xc3\x17\xb0\x19\x9eb\xdc\xbd\x1d\x1a"\xc8'
    field_attribute_0 = FieldAttribute(bytes_0)
    bytes_1 = b'F\x0f\x00\xf2\x05\x83\xeb\x03\x08\x84\xdd}\x13\xda\x8e\x00\x05'
    field_attribute_0 = FieldAttribute(bytes_1)

# Generated at 2022-06-25 04:51:41.929638
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "l@l\x17|\x99\x0f\x9c\x1a\xdf"
    str_1 = "{"
    field_attribute_0 = FieldAttribute(str_1)


# Generated at 2022-06-25 04:51:46.513067
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "8QgXKF"
    bytes_0 = b'\n\xf4@<\xe4\xc5\xda\x0e\xe5\x94\xde\xdf\xe0\x1d\xc6\x0e\x0b\x9b\xc1\x1b\xcf\xd2\xdb\x0c\xa7\x80\x14\x9c\xab\xe1\x98\xd8L\xb7\xa3'
    str_1 = "^q@!X9"
    bytes_1 = b'2\xc0\xbd\xb0\xe2T\xcd\xd9\x88\xae\x96\xf5\xb8\xe7\x0b\x02'
    instance

# Generated at 2022-06-25 04:51:50.567288
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "_/X%T*eB'4SA$N.^<Uj"
    bytes_0 = b'#\xe8\xf9\x81\x91o\xa2.\xff\xfdP\xebk\xea\xef\x12F\x8b\xa6"'
    field_attribute_0 = FieldAttribute(bytes_0)


# Generated at 2022-06-25 04:51:55.187875
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "d)_p)@&q%*b8C[yk"
    bytes_0 = b'f\xb8=\xd6\x91\xcc\xb7\x8a\x1aw\x1a\x18x\x8d\xb9\xf7\xb1\xfd\x8d\x98\x94\x0e\xed\x9b'
    field_attribute_0 = FieldAttribute(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:52:05.731506
# Unit test for constructor of class Attribute
def test_Attribute():
    str_a = "Z!_b7xdr~|,sVqT3T*h{"
    bytes_a = b'\xb1\xfaD\xfa\xaa\x84\x80\xd8\xbd\xbd\x1b\x0b\x8fK\x12\x03'
    class_type_a = type(type(str_a, (object,), dict()))

# Generated at 2022-06-25 04:52:11.422792
# Unit test for constructor of class Attribute
def test_Attribute():
    # test constructor
    a = Attribute()

    # test isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias and extend
    b = Attribute(isa="string", private=True, default="test", required=True, listof="string", priority=1, class_type="",
                  always_post_validate=True, inherit=True, alias="test", extend=True)


# Generated at 2022-06-25 04:52:15.368914
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        test_case_0()
    except Exception as ex:
        raise ex
    else:
        print("test_FieldAttribute: OK")

