

# Generated at 2022-06-25 04:42:31.751262
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'

# Generated at 2022-06-25 04:42:38.438739
# Unit test for constructor of class Attribute
def test_Attribute():
    int_0 = 5396
    float_0 = -837.732
    field_attribute_0 = Attribute(float_0)
    assert field_attribute_0.isa == float_0
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_

# Generated at 2022-06-25 04:42:39.581565
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # tests for other methods?
    test_case_0()



# Generated at 2022-06-25 04:42:48.280278
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('test_FieldAttribute')
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    int_1 = 2363
    bool_1 = True
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'

# Generated at 2022-06-25 04:42:54.819597
# Unit test for constructor of class Attribute
def test_Attribute():
    callback = {
        'type': 'callable',
        #'default': lambda: [],
        'default': list,
        'aliases': ['cbs'],
        'serialize': True
    }

    # Create an instance of the Attribute class.
    attribute = Attribute(**callback)

    assert attribute.default is list
    assert attribute.alias == 'cbs'
    assert attribute.static is False


# Generated at 2022-06-25 04:43:04.017595
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'
    assert setattr(field_attribute_0, 'isa', float_1) is None
    assert setattr(field_attribute_0, 'private', False) is None
    assert setattr(field_attribute_0, 'default', bytes_0) is None
    assert setattr(field_attribute_0, 'required', True) is None
    assert setattr(field_attribute_0, 'listof', None) is None
   

# Generated at 2022-06-25 04:43:09.612011
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    str_0 = str(field_attribute_0)
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'
    assert str_0 == str([float_0, bool_0])


# Generated at 2022-06-25 04:43:19.333260
# Unit test for constructor of class Attribute
def test_Attribute():
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'
    attribute = Attribute(int_0, field_attribute_0, int_0, field_attribute_0, float_1, field_attribute_0, field_attribute_0, True, bytes_0)


# Generated at 2022-06-25 04:43:25.557508
# Unit test for constructor of class Attribute
def test_Attribute():
    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'
    str_0 = 'CMYK'
    str_1 = 'hue'
    str_2 = 'HSL'
    str_3 = 'CMYK'
    str_4 = 'CMYK'
    str_5 = 'CMYK'
    str_6 = 'CMYK'
    str_7 = 'CMYK'
    str_8 = 'CMYK'
    str_9

# Generated at 2022-06-25 04:43:37.595638
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('Testing TestClass.test_FieldAttribute()')

    int_0 = -1335
    float_0 = -1066.0
    bool_0 = True
    field_attribute_0 = FieldAttribute(float_0, bool_0)
    float_1 = -872.755
    bytes_0 = b'\x97\xe2\x16\x88\xb7\x04\x9a\xe9\x9d\xfb'

    assert field_attribute_0.isa == bool_0
    assert field_attribute_0.default == float_0
    assert field_attribute_0.required == bool_0
    assert field_attribute_0.listof == bool_0
    assert field_attribute_0.priority == float_0
    assert field_attribute_0.class_type == bool_0


# Generated at 2022-06-25 04:43:50.879860
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        float_0 = -829.481899876721
        attribute_0 = Attribute(float_0)
    except:
        assert False
    float_0 = -829.481899876721
    attribute_0 = Attribute(float_0)
    str_0 = "Ansi*be.YYQ^"
    attribute_1 = Attribute(str_0)
    str_1 = "h2JU6]5jG"
    attribute_2 = Attribute(str_1)
    try:
        float_0 = -829.481899876721
        attribute_0 = Attribute(float_0)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 04:43:56.327866
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
#@attribute = Attribute
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-25 04:44:03.415867
# Unit test for constructor of class Attribute
def test_Attribute():
    float_0 = -829.481899876721
    attribute_0 = Attribute(float_0)
    assert attribute_0.isa == float_0
    assert not attribute_0.private
    assert attribute_0.default == None
    assert not attribute_0.required
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert not attribute_0.always_post_validate
    assert attribute_0.inherit
    assert attribute_0.alias == None



# Generated at 2022-06-25 04:44:03.891292
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()



# Generated at 2022-06-25 04:44:14.790604
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False
    assert attribute_0.static is False
    attribute_0 = Attribute(default=False, required=True, extend=False)
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default

# Generated at 2022-06-25 04:44:17.708714
# Unit test for constructor of class Attribute
def test_Attribute():
    float_1 = -829.481899876721
    attribute_1 = Attribute(float_1)
    assert attribute_1.isa == float_1


# Generated at 2022-06-25 04:44:18.469589
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:44:19.358262
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

# Generated at 2022-06-25 04:44:21.602472
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = Attribute(0)
    float_0 = -829.481899876721
    attribute_1 = FieldAttribute(float_0)


# Generated at 2022-06-25 04:44:23.783394
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:44:26.097555
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute()



# Generated at 2022-06-25 04:44:27.877962
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    p1 = Attribute()
    assert p1.isa == None


# Generated at 2022-06-25 04:44:28.808034
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()



# Generated at 2022-06-25 04:44:29.696218
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:44:30.516579
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:44:35.632157
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Try to use case 0
    try:
        test_case_0()
    except:
        pass


if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:44:42.837525
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa="string")
    assert attribute_1.isa == "string"

    attribute_2 = Attribute(isa="string", default=False)
    assert attribute_2.isa == "string"
    assert attribute_2.default is False

    attribute_3 = Attribute(isa="integer", default=123)
    assert attribute_3.isa == "integer"
    assert attribute_3.default == 123

    attribute_4 = Attribute(isa="list", default=["value1", "value2"])
    assert attribute_4.isa == "list"
    assert attribute_4.default == ["value1", "value2"]


# Generated at 2022-06-25 04:44:49.428763
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    expected_isa="class"
    expected_private=True
    expected_default=None
    expected_required=True
    expected_listof=None
    expected_priority=1
    expected_class_type="test_class"
    expected_always_post_validate=True
    expected_inherit=True
    expected_alias="this_is_alias"


# Generated at 2022-06-25 04:44:53.073908
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-25 04:44:56.637611
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    # Field 'private' is missing
    attribute_1 = Attribute(
        isa = 'str',
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False
    )
    # Field 'isa' is missing

# Generated at 2022-06-25 04:45:08.497656
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:45:09.418314
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:45:14.023272
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #default constructor
    actual = FieldAttribute()
    assert actual.isa == None
    assert actual.private == False
    assert actual.default == None
    assert actual.required == False
    assert actual.listof == None
    assert actual.priority == 0
    assert actual.class_type == None
    assert actual.always_post_validate == False
    assert actual.inherit == True
    assert actual.alias == None
    assert actual.extend == False
    assert actual.prepend == False
    assert actual.static == False


    #custom constructor
    actual = FieldAttribute("value")
    assert actual.isa == "value"
    assert actual.private == False
    assert actual.default == None
    assert actual.required == False
    assert actual.listof == None
    assert actual.priority == 0

# Generated at 2022-06-25 04:45:15.921851
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    unit test for constructor of class Attribute
    '''
    test_case_0()




# Generated at 2022-06-25 04:45:20.850894
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-25 04:45:29.138140
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """Test case for Attribute constructor."""

    print("Start test_FieldAttribute\n")

    # test case 1
    attribute_1 = Attribute(isa='list', private=False, default=None, required=False,
                            listof=None, priority=0, class_type=None,
                            always_post_validate=False, inherit=True, alias=None,
                            extend=False, prepend=False)

    # test case 2
    attribute_2 = Attribute(isa='dict', private=True, default=None, required=False,
                            listof=None, priority=2, class_type=None,
                            always_post_validate=False, inherit=True, alias=None,
                            extend=False, prepend=False)

    # test case 3

# Generated at 2022-06-25 04:45:39.171154
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(
        required=False,
        default=None,
        priority=0,
        private=False,
        always_post_validate=False,
        inherit=True,
        extend=False,
        prepend=False,
        static=False,
        alias=None
    )
    assert attribute_0.isa is None
    assert not attribute_0.private
    assert attribute_0.default is None
    assert not attribute_0.required
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert not attribute_0.always_post_validate
    assert attribute_0.inherit
    assert not attribute_0.extend
    assert not attribute_0.prepend

# Generated at 2022-06-25 04:45:49.931311
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    if attribute.isa != None:
        raise Exception("ISA not equal to None")
    if not attribute.private:
        raise Exception("Private not equal to False")
    if attribute.default != None:
        raise Exception("Default not equal to None")
    if attribute.required:
        raise Exception("Required not equal to False")
    if attribute.listof != None:
        raise Exception("ListOf not equal to None")
    if attribute.priority != 0:
        raise Exception("Priority not equal to 0")
    if attribute.class_type != None:
        raise Exception("ClassType not equal to None")
    if attribute.always_post_validate:
        raise Exception("AlwaysPostValidate not equal to False")
    if not attribute.inherit:
        raise Exception("Inherit not equal to True")


# Generated at 2022-06-25 04:45:57.778809
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert hasattr(attribute_0, 'isa')
    assert hasattr(attribute_0, 'private')
    assert hasattr(attribute_0, 'default')
    assert hasattr(attribute_0, 'required')
    assert hasattr(attribute_0, 'listof')
    assert hasattr(attribute_0, 'priority')
    assert hasattr(attribute_0, 'class_type')
    assert hasattr(attribute_0, 'always_post_validate')
    assert hasattr(attribute_0, 'inherit')
    assert hasattr(attribute_0, 'alias')
    assert hasattr(attribute_0, 'extend')
    assert hasattr(attribute_0, 'prepend')
    assert hasattr(attribute_0, 'static')

test_Attribute()

# Unit

# Generated at 2022-06-25 04:46:04.880964
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None



# Generated at 2022-06-25 04:46:18.514660
# Unit test for constructor of class Attribute
def test_Attribute():
    """Unit-test for constructor of class Attribute"""
    # 1. Create Attribute object without parameters
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is None
    assert attribute_0.default is None
    assert attribute_0.required is None
    assert attribute_0.listof is None
    assert attribute_0.priority is None
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is None
    assert attribute_0.inherit is None
    assert attribute_0.alias is None
    assert attribute_0.extend is None
    assert attribute_0.prepend is None
    assert attribute_0.static is None

    # 2. Create Attribute object with all parameters

# Generated at 2022-06-25 04:46:24.618155
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa="dict", private=False, default=None, required=True, listof="list", priority=0, class_type=None, always_post_validate=False, inherit=False, alias=None)
    assert attribute_1.isa == "dict"
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == True
    assert attribute_1.listof == "list"
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.always_post_validate == False
    assert attribute_1.inherit == False
    assert attribute_1.alias == None

# Test cases of class FieldAttribute

# Generated at 2022-06-25 04:46:30.974187
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(
        default='True',
        isa='True',
        listof='True',
        required='True',
        static='True',
        private='True',
        always_post_validate='True',
        inherit='True',
        extend='True',
        prepend='True',
        alias='True',
        priority='True',
        class_type='True')
    # Check if the constructor is working
    assert attribute_0.default == 'True'
    assert attribute_0.isa == 'True'
    assert attribute_0.listof == 'True'
    assert attribute_0.required == 'True'
    assert attribute_0.static == 'True'
    assert attribute_0.private == 'True'
    assert attribute_0.always_post_validate == 'True'
    assert attribute

# Generated at 2022-06-25 04:46:35.093202
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.priority == 0
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True


# Generated at 2022-06-25 04:46:36.757686
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 04:46:39.576487
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().__class__.__name__ == 'Attribute'


# Generated at 2022-06-25 04:46:48.396538
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute_1 = Attribute(isa='list')
    assert attribute_1.isa == 'list'

    attribute_2 = Attribute(isa='class')
    assert attribute_2.isa == 'class'

    attribute_3 = Attribute(isa='dict')
    assert attribute_3.isa == 'dict'

    attribute_4 = Attribute(isa='set')
    assert attribute_4.isa == 'set'

    attribute_5 = Attribute(isa='integer')
    assert attribute_5.isa == 'integer'

    try:
        attribute_6 = Attribute(isa='invalid')
        assert False
    except TypeError:
        pass



# Generated at 2022-06-25 04:46:50.719152
# Unit test for constructor of class Attribute
def test_Attribute():
    isa="string"
    a = Attribute(isa=isa)
    assert a.isa ==  isa
    assert a.private == False


# Generated at 2022-06-25 04:46:53.363386
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:46:54.862500
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:47:03.868442
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a is not None



# Generated at 2022-06-25 04:47:07.806407
# Unit test for constructor of class Attribute
def test_Attribute():
    expected_isa = 'string'
    expected_private = True
    expected_default = 'default'
    expected_required = True
    expected_listof = 'list'
    expected_priority = 0
    expected_class_type = type
    expected_always_post_validate = False
    expected_inherit = True
    expected_alias = 'alias'
    expected_extend = False
    expected_prepend = False
    expected_static = False


# Generated at 2022-06-25 04:47:08.801558
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    t = FieldAttribute()


# Generated at 2022-06-25 04:47:15.676014
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test instantiation by passing positional arguments
    attribute_1 = Attribute('list')
    assert attribute_1.isa == 'list'
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0

    # Test instantiation by passing keyword arguments
    attribute_2 = Attribute(isa='list')
    assert attribute_2.isa == 'list'
    assert attribute_2.private == False
    assert attribute_2.default == None
    assert attribute_2.required == False
    assert attribute_2.listof == None
    assert attribute_2.priority == 0


# Generated at 2022-06-25 04:47:23.131571
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()

# Generated at 2022-06-25 04:47:26.316955
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    attribute_1 = FieldAttribute(isa='foo')
    attribute_2 = FieldAttribute(private=False)
    attribute_3 = FieldAttribute(default=None)
    attribute_4 = FieldAttribute(required=False)
    attribute_5 = FieldAttribute(listof=None)
    attribute_6 = FieldAttribute(priority=0)
    attribute_7 = FieldAttribute(class_type=None)
    attribute_8 = FieldAttribute(always_post_validate=False)
    attribute_9 = FieldAttribute(inherit=True)
    attribute_10 = FieldAttribute(alias=None)



# Generated at 2022-06-25 04:47:33.331146
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()

    assert field.isa is None
    assert not field.private
    assert field.default == None
    assert not field.required
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert not field.always_post_validate
    assert field.inherit
    assert field.alias is None
    assert not field.extend
    assert not field.prepend
    assert not field.static


# Generated at 2022-06-25 04:47:42.623247
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    print(attribute_0.__dict__)
    assert(attribute_0.__dict__=={'isa':None, 'private':False, 'default':None, 'required':False, 'listof':None, 'priority':0, 'class_type':None, 'always_post_validate':False, 'inherit':True, 'alias':None, 'extend':False, 'prepend':False, 'static':False})
    attribute_1 = FieldAttribute(isa="str")
    print(attribute_1.__dict__)

# Generated at 2022-06-25 04:47:53.672914
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with no arguments
    attribute_0 = Attribute()
    assert(attribute_0.iesa == None)
    assert(attribute_0.private == False)
    assert(attribute_0.default == None)
    assert(attribute_0.required == False)
    assert(attribute_0.listof == None)
    assert(attribute_0.priority == 0)
    assert(attribute_0.class_type == None)
    assert(attribute_0.always_post_validate == False)
    assert(attribute_0.inherit == True)
    assert(attribute_0.alias == None)
    assert(attribute_0.extend == False)
    assert(attribute_0.prepend == False)
    assert(attribute_0.static == False)
    
    # Test with all arguments

# Generated at 2022-06-25 04:48:01.872790
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    print ('attribute_0.isa=',attribute_0.isa)
    print ('attribute_0.private=',attribute_0.private)
    print ('attribute_0.default=',attribute_0.default)
    print ('attribute_0.required=',attribute_0.required)
    print ('attribute_0.listof=',attribute_0.listof)
    print ('attribute_0.priority=',attribute_0.priority)
    print ('attribute_0.class_type=',attribute_0.class_type)
    print ('attribute_0.always_post_validate=',attribute_0.always_post_validate)
    print ('attribute_0.inherit=',attribute_0.inherit)
    print ('attribute_0.alias=',attribute_0.alias)


# Generated at 2022-06-25 04:48:16.455733
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute__0 = Attribute(isa="str")
    print(attribute__0.class_type)
    print(attribute__0.default)
    print(attribute__0.extend)
    print(attribute__0.inherit)
    print(attribute__0.listof)
    print(attribute__0.priority)
    print(attribute__0.private)
    print(attribute__0.required)

# Test the equality operators of class Attribute

# Generated at 2022-06-25 04:48:18.827013
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()


# Generated at 2022-06-25 04:48:28.253298
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor with no arguments
    attribute_0 = Attribute()
    # Constructor with all arguments
    attribute_1 = Attribute(
        isa='dict',
        private=True,
        default=None,
        required=False,
        listof = None,
        priority=0,
        class_type = 'test',
        always_post_validate = False,
        inherit = True,
        alias = 'test',
        extend = False,
        prepend = False,
        static = False,
    )
    print(attribute_0)
    print(attribute_1)
    # Check the attribute properties
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False

# Generated at 2022-06-25 04:48:35.331711
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list',
                          private=True,
                          default=copy,
                          listof="string",
                          required=False,
                          class_type="AnsibleModule",
                          always_post_validate=True,
                          inherit=True,
                          alias="test",
                          extend=True,
                          prepend=True,
                          static=True)
    assert isinstance(attribute,Attribute),'attribute is not Attribute instance'
    assert isinstance(attribute.isa,str),'attribute.isa is not str instance'
    assert isinstance(attribute.listof,str),'attribute.listof is not str instance'
    assert isinstance(attribute.class_type,str),'attribute.class_type is not str instance'

# Generated at 2022-06-25 04:48:37.415674
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert isinstance(attribute_0, Attribute)

    with pytest.raises(TypeError):
        attribute_0 = FieldAttribute(default=dict())

# Generated at 2022-06-25 04:48:46.640689
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None, "Attribute init failed"
    assert attr.private is False, "Attribute init failed"
    assert attr.default is None, "Attribute init failed"
    assert attr.required is False, "Attribute init failed"
    assert attr.listof is None, "Attribute init failed"
    assert attr.priority == 0, "Attribute init failed"
    assert attr.class_type is None, "Attribute init failed"
    assert attr.always_post_validate is False, "Attribute init failed"
    assert attr.inherit is True, "Attribute init failed"
    assert attr.alias is None, "Attribute init failed"
    assert attr.extend is False, "Attribute init failed"
    assert attr.prepend is False, "Attribute init failed"

# Generated at 2022-06-25 04:48:57.461109
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(alias='alias_0', always_post_validate=False, class_type=None, default=None, extend=False, isa=None, inherit=True, listof='listof_0', prepend=False, private=False, priority=0, required=False, static=False)
    attribute_0 = FieldAttribute(alias='alias_1', always_post_validate=False, class_type='class_type_1', default=None, extend=False, isa=None, inherit=True, listof='listof_1', prepend=False, private=False, priority=1, required=False, static=False)

# Generated at 2022-06-25 04:48:58.866504
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0 is not None



# Generated at 2022-06-25 04:49:08.365814
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Attributes
    attribute_0 = FieldAttribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None


# Generated at 2022-06-25 04:49:15.207467
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    assert attribute_1.isa == None
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.class_type == None
    assert attribute_1.inherit == True
    assert attribute_1.alias == None



# Generated at 2022-06-25 04:49:42.273026
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='class')
    assert attribute.isa == 'class'

# Generated at 2022-06-25 04:49:45.535923
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(Attribute(), Attribute)
    assert isinstance(FieldAttribute(), FieldAttribute)



# Generated at 2022-06-25 04:49:51.036038
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0 is not None


# Generated at 2022-06-25 04:50:00.308654
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert isinstance(attribute_0, Attribute)
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False

# Generated at 2022-06-25 04:50:11.592398
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test the first constructor
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True

    # Test the second constructor
    field_attribute_0 = FieldAttribute('isa')
    assert field_attribute_0.isa == 'isa'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute

# Generated at 2022-06-25 04:50:13.117099
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0 is attribute_0
    assert isinstance(attribute_0, FieldAttribute)
    return



# Generated at 2022-06-25 04:50:19.925794
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # check if all fields of FieldAttribute is initialized correctly by
    # FieldAttribute constructor.
    attr = FieldAttribute(isa='int', default=0, required=True)
    assert attr.isa == 'int' and attr.default == 0 and attr.required is True

# unit test for comparison methods of class FieldAttribute

# Generated at 2022-06-25 04:50:26.182475
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with a no-args constructor
    attribute_0 = FieldAttribute();
    assert(attribute_0 != None);

    # Test with another constructor
    attribute_1 = FieldAttribute(
        alias="test_alias",
        class_type=bool,
        extend=True,
        prepend=False,
        always_post_validate=False,
        default=True,
        required=True,
        isa="boolean"
    );
    assert(attribute_1 != None);
    assert(attribute_1.class_type == bool);
    assert(attribute_1.alias == "test_alias");
    assert(attribute_1.extend == True);
    assert(attribute_1.prepend == False);
    assert(attribute_1.always_post_validate == False);

# Generated at 2022-06-25 04:50:37.080854
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa='str', private=False, default=None, required=False, listof='str', priority=0, class_type='str', always_post_validate=False, inherit=True, alias='alias_1')
    # check if isa is copied correctly
    assert 'str' == attribute_1.isa
    assert 'str' is not attribute_1.isa

    # check if private is copied correctly
    assert False == attribute_1.private
    assert False is not attribute_1.private

    # check if default is copied correctly
    assert None == attribute_1.default
    assert None is attribute_1.default

    # check if required is copied correctly
    assert False == attribute_1.required
    assert False is not attribute_1.required

    # check if listof is copied correctly

# Generated at 2022-06-25 04:50:43.443751
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    '''
    Unit test for constructor of class FieldAttribute.
    '''
    class object_0:
        def __init__(self):
            self.field_0 = FieldAttribute()
    object_0 = object_0()
    object_0.field_0 = 'value_0'
    assert object_0.field_0 == 'value_0'



# Generated at 2022-06-25 04:51:57.063348
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0 is not None


# Generated at 2022-06-25 04:52:02.556586
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attrib = FieldAttribute()
    assert attrib.isa is None
    assert attrib.private == False
    assert attrib.default == None
    assert attrib.required == False
    assert attrib.listof == None
    assert attrib.priority == 0
    assert attrib.class_type == None
    assert attrib.always_post_validate == False
    assert attrib.inherit == True
    assert attrib.alias == None
    assert attrib.extend == False
    assert attrib.prepend == False
    assert attrib.static == False


# Generated at 2022-06-25 04:52:13.190395
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(
        private=True,
        default=False,
        required=False,
        listof=None,
        priority=9,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='test',
    )
    print(attribute_1.private)
    print(attribute_1.default)
    print(attribute_1.required)
    print(attribute_1.listof)
    print(attribute_1.priority)
    print(attribute_1.class_type)
    print(attribute_1.always_post_validate)
    print(attribute_1.inherit)
    print(attribute_1.alias)


# Generated at 2022-06-25 04:52:22.965347
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='bool').isa == 'bool'
    assert Attribute(private=True).private == True
    assert Attribute(default=True).default == True
    assert Attribute(required=True).required == True
    assert Attribute(listof='list').listof == 'list'
    assert Attribute(priority=0).priority == 0
    assert Attribute(class_type='True').class_type == 'True'
    assert Attribute(always_post_validate=True).always_post_validate == True
    assert Attribute(inherit=True).inherit == True
    assert Attribute(alias='True').alias == 'True'