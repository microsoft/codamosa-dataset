

# Generated at 2022-06-25 04:42:34.286434
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = 0
    str_0 = 'Df`FF'
    str_1 = 'Name: %s'
    str_2 = 'ftp'
    attribute_0 = Attribute(str_2, str_0)
    # test of the __init__ method
    attribute_1 = FieldAttribute(str_2, private=str_0)
    # test of the __init__ method
    attribute_2 = FieldAttribute(str_2, alias=str_0)
    attribute_3 = Attribute()
    # test of the __init__ method
    attribute_4 = FieldAttribute()
    # test of the __init__ method
    attribute_5 = FieldAttribute(str_2, str_0)
    # test of the __init__ method
    attribute_6 = FieldAttribute(str_2)
    # test of the

# Generated at 2022-06-25 04:42:38.614016
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = FieldAttribute(str_1, str_2)

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:42:46.794924
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    from importlib import import_module
    import sys
    import types
    import unittest
    from ansible.module_utils.six import PY3

    class TestAnsibleAttribute(unittest.TestCase):
        ''' Unit test for ansible.playbook.attribute_functions.FieldAttribute '''

        def test_constant_0(self):
            ''' Test constructor with no parameters '''
            attribute_0 = Attribute()
            self.assertEqual(attribute_0.isa, None)

        def test_constant_1(self):
            ''' Test constructor with a single parameter '''
            attribute_0 = Attribute('ftp')
            self.assertEqual(attribute_0.isa, 'ftp')


# Generated at 2022-06-25 04:42:52.861750
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = Attribute(str_1, str_2)
    if attribute_0.isa != str_1:
        raise RuntimeError(str_0)
    if attribute_0.private != str_2:
        raise RuntimeError(str_0)


# Generated at 2022-06-25 04:43:00.277301
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = Attribute(str_1, str_2)
    # AssertionError in class 'Attribute' is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class 'Attribute' is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # AssertionError in class Attribute is caught
    # Ass

# Generated at 2022-06-25 04:43:04.718853
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
  if (__name__ == '__main__'):
      test_case_0()
      print('TEST PASSED')

# Generated at 2022-06-25 04:43:08.748820
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = Attribute(str_1, str_2)
    assert(attribute_0.isa == str_1)
    assert(attribute_0.private == str_2)

test_Attribute()


# Generated at 2022-06-25 04:43:14.795434
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = FieldAttribute(str_1, str_2)
    dict_0 = attribute_0.__dict__.copy()
    str_3 = 'isa'
    str_4 = 'private'
    str_5 = 'default'
    str_6 = 'required'
    str_7 = 'listof'
    str_8 = 'priority'
    str_9 = 'class_type'
    str_10 = 'always_post_validate'
    str_11 = 'inherit'
    str_12 = 'alias'
    str_13 = 'extend'
    str_14 = 'prepend'
    str_15 = 'static'

# Generated at 2022-06-25 04:43:23.914514
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
  #
  #
  # Test case 0
  #
  #
  attribute0 = Attribute('Name: %s', 'ftp', 'Df`FF')
  # Test case 1
  #
  #
  # Test case 2
  #
  #
  # Test case 3
  #
  #
  # Test case 4
  #
  #
  # Test case 5
  #
  #
  # Test case 6
  #
  #
  # Test case 7
  #
  #
  # Test case 8
  #
  #
  # Test case 9
  #
  #
  # Test case 10
  #
  #
  # Test case 11
  #
  #
  # Test case 12
  #
  #
  # Test case 13
  #
  #
  #

# Generated at 2022-06-25 04:43:28.916924
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    str_1 = 'ftp'
    str_2 = 'Df`FF'
    attribute_0 = Attribute(str_1, str_2)

# Generated at 2022-06-25 04:43:33.344937
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    field_attribute_0 = FieldAttribute(str_0, str_0)
    assert (str_0, str_0) == (field_attribute_0.isa, field_attribute_0.private)



# Generated at 2022-06-25 04:43:37.071714
# Unit test for constructor of class Attribute
def test_Attribute():
    FieldAttribute()


# Generated at 2022-06-25 04:43:46.734787
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    str_1 = 'changed'
    attribute_inst = Attribute(default=str_0)
    assert (attribute_inst.isa == None)
    assert (attribute_inst.private == False)
    assert (attribute_inst.default == str_0)
    assert (attribute_inst.required == False)
    assert (attribute_inst.listof == None)
    assert (attribute_inst.priority == 0)
    assert (attribute_inst.class_type == None)
    assert (attribute_inst.always_post_validate == False)
    assert (attribute_inst.inherit == True)
    assert (attribute_inst.alias == None)
    assert (attribute_inst.extend == False)
    assert (attribute_inst.prepend == False)

# Generated at 2022-06-25 04:43:50.175480
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:43:58.081867
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    field_attribute_0 = FieldAttribute(str_0, str_0)
    field_attribute_1 = FieldAttribute(str_0, str_0)
    assert field_attribute_0 == field_attribute_1
    assert field_attribute_0 > field_attribute_1
    assert field_attribute_0 >= field_attribute_1
    assert field_attribute_0 < field_attribute_1
    assert field_attribute_0 <= field_attribute_1
    assert type(field_attribute_0) == FieldAttribute
    assert type(field_attribute_1) == FieldAttribute
    assert type(str_0) == str
    assert field_attribute_0.isa == str_0
    assert field_attribute_0.private == field_attribute_1.private

# Generated at 2022-06-25 04:44:02.443982
# Unit test for constructor of class Attribute
def test_Attribute():
    print("In test_Attribute")
    str_attr = 'Name: %s'
    field_attribute_0 = FieldAttribute(str_attr, str_attr)
    field_attribute_1 = FieldAttribute(str_attr, str_attr)
    assert field_attribute_0 == field_attribute_1
    field_attribute_2 = FieldAttribute(str_attr, str_attr, priority=1)
    assert field_attribute_0 < field_attribute_2
    assert field_attribute_2 > field_attribute_0

# Generated at 2022-06-25 04:44:04.539585
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute('Name: %s', 'Name: %s')


# Generated at 2022-06-25 04:44:14.493338
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Name: %s'
    field_attribute_0 = FieldAttribute(str_0, str_0)
    list_0 = [field_attribute_0, field_attribute_0]
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False

# Generated at 2022-06-25 04:44:24.368988
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Name: %s'
    field_attribute_0 = FieldAttribute(str_0)
    assert field_attribute_0.isa is not None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False
    assert field

# Generated at 2022-06-25 04:44:31.767657
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(default='string', class_type='AnsibleAttribute', inherit='boolean', listof='string', priority='integer', required='boolean', static='boolean', extend='boolean', alias='string', always_post_validate='boolean', isa='string', prepend='boolean')
    str_0 = 'FieldAttribute(class_type=AnsibleAttribute, isa=string)'
    assert str_0 == str(field_attribute_0)
    str_0 = 'Name: %s'
    # field_attribute_1 = FieldAttribute(str_0, str_0)



# Generated at 2022-06-25 04:44:38.055318
# Unit test for constructor of class Attribute
def test_Attribute():
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:44:46.890858
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute(isa=int, default=1)
    assert isinstance(field_attribute, Attribute)
    assert field_attribute.isa == int
    assert field_attribute.default == 1
    assert field_attribute.private == False
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False


# Generated at 2022-06-25 04:44:47.813548
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:44:48.583497
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 04:44:49.998218
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    field_attribute_2 = FieldAttribute()


# Generated at 2022-06-25 04:44:54.372297
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_0 = Attribute()
    print('Testing constructor of Attribute class...')
    print('Here is an instance of the Attribute class:')
    print(attr_0)

# Generated at 2022-06-25 04:44:56.565856
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute()


# Generated at 2022-06-25 04:45:05.375737
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_0 = Attribute(isa=None,
          private=False,
          default=None,
          required=False,
          listof=None,
          priority=0,
          class_type=None,
          always_post_validate=False,
          inherit=True,
          alias=None,
          extend=False,
          prepend=False,
          static=False)

    attr_1 = Attribute(isa=None,
          private=False,
          default=None,
          required=False,
          listof=None,
          priority=0,
          class_type=None,
          always_post_validate=False,
          inherit=True,
          alias=None,
          extend=False,
          prepend=False,
          static=False)


# Generated at 2022-06-25 04:45:13.005210
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    # FieldAttribute has no attribute 'isa'
    assert not hasattr(field_attribute_0, 'isa')
    field_attribute_1 = FieldAttribute(isa="list")
    # FieldAttribute has no attribute 'isa'
    assert not hasattr(field_attribute_1, 'isa')
    # FieldAttribute has no attribute 'private'
    assert not hasattr(field_attribute_1, 'private')
    # FieldAttribute has no attribute 'default'
    assert not hasattr(field_attribute_1, 'default')
    # FieldAttribute has no attribute 'required'
    assert not hasattr(field_attribute_1, 'required')
    # FieldAttribute has no attribute 'listof'
    assert not hasattr(field_attribute_1, 'listof')
    # FieldAttribute has no attribute 'priority

# Generated at 2022-06-25 04:45:24.905816
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        field_attribute_0 = FieldAttribute()
        if field_attribute_0 is not None:
            print("Test 0 passed")
        else:
            print("Test 0 failed")
    except Exception:
        print("Test 0 failed")


# Generated at 2022-06-25 04:45:33.162784
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='list',default=None,required=False,listof=None,priority=0,class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,prepend=False, static=False)



# Generated at 2022-06-25 04:45:45.594569
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='bool', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert field_attribute_0.isa == 'bool'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0

# Generated at 2022-06-25 04:45:52.201515
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test if isa is of type string
    field_attribute_0 = FieldAttribute(isa='str')
    # Test if isa is of type list
    field_attribute_1 = FieldAttribute(isa='list')
    # Test if isa accepts a list of a list of strings
    field_attribute_2 = FieldAttribute(isa=['str', 'list[str]'])
    # Test if isa accepts a list of lists of lists of lists of strings
    field_attribute_3 = FieldAttribute(isa=['str', ['list', ['list', 'str']]])


# Generated at 2022-06-25 04:46:02.931510
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = Attribute(isa="list", private=False, default="", required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field_attribute.isa == "list"
    assert field_attribute.private == False
    assert field_attribute.default == ""
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.pre

# Generated at 2022-06-25 04:46:09.232607
# Unit test for constructor of class Attribute
def test_Attribute():
    print("Testing constructor of Attribute")
    try:
        field_attribute_1 = FieldAttribute(isa=dict, private=True, required=True, inherit=False, extend=True, prepend=True, static=True)
        print("Constructor of Attribute Test: test_1 passed")
    except Exception as err:
        print("Constructor of Attribute Test: test_1 failed")
        print("Exception thrown: " + str(err))

    try:
        field_attribute_2 = FieldAttribute(isa=list, listof=dict, private=False, required=True, inherit=True, extend=True, prepend=True, static=True)
        print("Constructor of Attribute Test: test_2 passed")
    except Exception as err:
        print("Constructor of Attribute Test: test_2 failed")

# Generated at 2022-06-25 04:46:20.748020
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor when all arguments are provided
    field_attribute = Attribute(
        isa = 'list',
        private = True,
        default = [1,2,3,4],
        required = False,
        listof = 'int',
        priority = 5,
        class_type = None,
        always_post_validate = True,
        inherit = False,
        alias = 'name',
        extend = True,
        prepend = True,
        static = True
    )
    # Test constructor when all arguments are not provided
    field_attribute = Attribute()
    # Test constructor when default is not provided

# Generated at 2022-06-25 04:46:29.066618
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='bool',
                                     private=False,
                                     default=None,
                                     required=False,
                                     priority=0,
                                     class_type=None,
                                     always_post_validate=False,
                                     inherit=True,
                                     alias=None,
                                     extend=False,
                                     prepend=False,
                                     static=False)
    assert field_attribute.isa == 'bool'
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None


# Generated at 2022-06-25 04:46:37.398533
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test normal case
    try:
        field_attribute_0 = FieldAttribute()
    except Exception as e:
        print(e)
        assert 0, str(e)

    # test with arguments

# Generated at 2022-06-25 04:46:38.856563
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = Attribute()
    field_attribute_1 = Attribute(alias='param_alias')


# Generated at 2022-06-25 04:46:45.562966
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = Attribute(
        isa='foo-is-a',
        private=True,
        default=None,
        required=False,
        listof=False,
        priority=10,
        class_type=None,
        always_post_validate=True,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert field_attribute.isa == 'foo-is-a'
    assert field_attribute.private == True
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == Fal

# Generated at 2022-06-25 04:46:55.045550
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.class_type is None
    assert field_attribute_0.default is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.isa is None
    assert field_attribute_0.alias is None
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.private is False
    assert field_attribute_0.required is False


if __name__ == '__main__':
    test_FieldAttribute()
    test_case_0()

# Generated at 2022-06-25 04:46:57.396726
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field_attribute = fieldAttribute()
    except:
        print("Error: Constructor of class FieldAttribute failed")
        assert False


# Generated at 2022-06-25 04:47:03.218730
# Unit test for constructor of class Attribute
def test_Attribute():
    # instantiate a FieldAttribute object
    field_attribute_1 = FieldAttribute(isa='dict', private=False, default=None, required=False,
                                       listof=None, priority=0, class_type=None,
                                       always_post_validate=False, inherit=True, alias=None)

    # instantiate an Attribute object
    attribute_1 = Attribute(isa='dict', private=False, default=None, required=False,
                            listof=None, priority=0, class_type=None,
                            always_post_validate=False, inherit=True, alias=None)


# Generated at 2022-06-25 04:47:05.832171
# Unit test for constructor of class Attribute
def test_Attribute():
    field = FieldAttribute(alias='test_field')
    assert field.alias == 'test_field'



# Generated at 2022-06-25 04:47:10.416004
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 04:47:13.007858
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import TaskResult
    from ansible.playbook.play_context import PlayContext

    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute()


# Generated at 2022-06-25 04:47:21.136663
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # u'isa': u'', u'private': False, u'default': None, u'required': False, u'listof': None, u'priority': 0L, u'class_type': None
    class_type = None

# Generated at 2022-06-25 04:47:32.976377
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    field_attribute_1 = FieldAttribute(alias = 'alias_1')

# Generated at 2022-06-25 04:47:42.396449
# Unit test for constructor of class Attribute
def test_Attribute():
    # test default
    field_attribute_1 = Attribute()
    assert field_attribute_1.isa == None
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias == None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False

    # test default callable()

# Generated at 2022-06-25 04:47:53.483319
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = Attribute(isa='str', private=False, default=None, required=False,
        listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True,
        alias=None, extend=False, prepend=False, static=False)
    field_attribute_2 = Attribute(isa='str', private=True, default=None, required=True,
        listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True,
        alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-25 04:48:02.264834
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='int')
    print('field_attribute_0.isa: ' + field_attribute_0.isa)
    assert field_attribute_0.isa == 'int'


# Generated at 2022-06-25 04:48:07.649267
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field_attribute_0 = FieldAttribute()
    except TypeError as error:
        print(error)
        return False
    return True


# Generated at 2022-06-25 04:48:10.933880
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass # TODO: implement your test here

# --------------------------------------------------------------------------------------------------
# Testing.
# --------------------------------------------------------------------------------------------------


# Generated at 2022-06-25 04:48:22.008105
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:48:30.274323
# Unit test for constructor of class Attribute
def test_Attribute():

    for attribute_name in ['isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type', 'always_post_validate',
                           'inherit', 'alias', 'extend', 'prepend', 'static']:

        field_attribute_0 = FieldAttribute(**{attribute_name: False})
        assert field_attribute_0.__dict__[attribute_name] is False, 'field_attribute_0.__dict__[attribute_name] was not False, it was %s' % field_attribute_0.__dict__[attribute_name]

    field_attribute_1 = FieldAttribute(isa='string')
    field_attribute_2 = FieldAttribute(isa='int')
    field_attribute_3 = FieldAttribute(isa='list')
    field_attribute_4 = FieldAttribute(isa='dict')

# Generated at 2022-06-25 04:48:32.821646
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(True, False, None, False, None, 0, None, False, True)

    field_attribute_2 = FieldAttribute('list', True, 'default', True, 'listof', 1, 'class_type', True, False)



# Generated at 2022-06-25 04:48:34.819186
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 04:48:42.699432
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Explicitly test default values
    field_attribute_1 = FieldAttribute()
    assert isinstance(field_attribute_1.isa, type(None))
    assert field_attribute_1.private is False
    assert field_attribute_1.required is False
    assert field_attribute_1.always_post_validate is False
    assert isinstance(field_attribute_1.alias, type(None))

    # Set all values explicitly

# Generated at 2022-06-25 04:48:51.369136
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute('foo', False, 'bar')
    assert fa.isa == 'foo'
    assert fa.private == False
    assert fa.default == 'bar'
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False



# Generated at 2022-06-25 04:48:59.068206
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute(
        isa='string', private=False, default=None, required=False,
        listof=None, priority=0, class_type=None, always_post_validate=False,
        inherit=True, alias=None, extend=False, prepend=False, static=False
    )
    assert field_attribute_1.isa == 'string'
    assert field_attribute_1.private == False
    assert field_attribute_1.default is None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof is None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type is None
    assert field_attribute_1.always_post_validate == False

# Generated at 2022-06-25 04:49:06.255780
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

# Generated at 2022-06-25 04:49:11.984579
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert field_attribute_0
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None

test_case_0()

# Generated at 2022-06-25 04:49:15.911853
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', default=dict())
    b = Attribute(isa='dict', default=dict())

    assert a == b
    assert not a < b
    assert not a > b
    assert a <= b
    assert a >= b

# Generated at 2022-06-25 04:49:26.248713
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    attribute_1 = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=True, static=False)
    attribute_2 = Attribute(isa='dict', private=False, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=True, static=False)

# Generated at 2022-06-25 04:49:38.694208
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute()

    assert field_attribute_1.isa == None
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias == None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False


# Generated at 2022-06-25 04:49:45.195349
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import defaultdict
    from operator import attrgetter

    # constructors without any argument
    attribute1 = Attribute()
    attribute2 = Attribute()
    assert attribute1.__dict__ != attribute2.__dict__, "Attribute() constructor is not working properly."

    # constructor with arguments
    attribute3 = Attribute(isa="int", private=True, default=1)
    assert attribute3.__dict__ != attribute2.__dict__, "Attribute() constructor is not working properly."
    assert attribute3.isa == "int", "Attribute() constructor is not working properly."
    assert attribute3.private is True, "Attribute() constructor is not working properly."
    assert attribute3.default == 1, "Attribute() constructor is not working properly."

    # constructor with arguments with listof

# Generated at 2022-06-25 04:49:50.415972
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    return field_attribute_0



# Generated at 2022-06-25 04:49:55.262176
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_0 = Attribute()
    attr_1 = Attribute(isa='string')
    attr_2 = Attribute(isa='list')
    attr_3 = Attribute(listof='string')
    attr_4 = Attribute(default=['a', 'b'])
    attr_5 = Attribute(default=['a', 'b'], isa='list', listof='string')
    attr_6 = Attribute(default=['a', 'b'], isa='list', listof=None)
    attr_7 = Attribute(default={'key': 'value'})
    attr_8 = Attribute(default={'key': 'value'}, isa='dict')

# Generated at 2022-06-25 04:50:00.923595
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(default=0, inherit=True)
    field_attribute_2 = FieldAttribute(prepend=True)
    field_attribute_3 = FieldAttribute(class_type=True)


# Generated at 2022-06-25 04:50:05.669821
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    arg = 'isa'
    isa = None
    field_attribute_0 = FieldAttribute(isa=isa)
    assert field_attribute_0.isa is None

# Generated at 2022-06-25 04:50:18.197757
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:50:21.220647
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute()

# Generated at 2022-06-25 04:50:21.926418
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:50:24.644822
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    value_field_attribute = FieldAttribute(isa="any")
    assert value_field_attribute.isa == "any"


# Generated at 2022-06-25 04:50:34.760887
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()

    assert(field_attribute.isa == None)
    assert(field_attribute.private == False)
    assert(field_attribute.default == None)
    assert(field_attribute.required == False)
    assert(field_attribute.listof == None)
    assert(field_attribute.priority == 0)
    assert(field_attribute.class_type == None)
    assert(field_attribute.always_post_validate == False)
    assert(field_attribute.inherit == True)
    assert(field_attribute.alias == None)


# Generated at 2022-06-25 04:50:46.605517
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(default=False, required=True, static=False, alias='test_ alias', isa='bool', listof=None, inherit=True, always_post_validate=True, class_type='ClassType', prepend=False, private=True, extend=True, priority=0)

    if field_attribute_1.priority == 0:
        pass
    else:
        raise AssertionError("Test case 0 failed")

    if field_attribute_1.default == False:
        pass
    else:
        raise AssertionError("Test case 1 failed")

    if field_attribute_1.required == True:
        pass
    else:
        raise AssertionError("Test case 2 failed")

    if field_attribute_1.static == False:
        pass
    else:
        raise Assert

# Generated at 2022-06-25 04:50:49.220430
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:50:57.703087
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa == None
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False



# Generated at 2022-06-25 04:51:06.964401
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert not field_attribute_0.private
    assert field_attribute_0.default is None
    assert not field_attribute_0.required
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert not field_attribute_0.always_post_validate
    assert field_attribute_0.inherit
    assert not field_attribute_0.extend
    assert not field_attribute_0.prepend
    assert not field_attribute_0.static


# Unit tests for methods of class Attribute

# Generated at 2022-06-25 04:51:14.480911
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(isa='dict')
    assert field_attribute_1.isa == 'dict'

    field_attribute_2 = FieldAttribute(isa='', private=True, default='default')
    assert field_attribute_2.isa == ''
    assert field_attribute_2.private is True
    assert field_attribute_2.default == 'default'

    field_attribute_3 = FieldAttribute(isa='', private=True, default='default', required=False)
    assert field_attribute_3.isa == ''
    assert field_attribute_3.private is True
    assert field_attribute_3.default == 'default'
    assert field_attribute_3.required is False

    field_attribute_4 = FieldAttribute(isa='', private=True, default='default', required=False, listof='list')
    assert field

# Generated at 2022-06-25 04:51:47.934733
# Unit test for constructor of class Attribute
def test_Attribute():
    #
    # test class does not inherit from Attribute
    #
    class TestClass:
        pass

    attribute_0 = Attribute(isa="string")

    try:
        attribute_1 = Attribute(isa=TestClass())
    except AssertionError as e:
        print(str(e))

    #
    # test isa
    #
    try:
        attribute_0 = Attribute(isa="TestClass")
    except AssertionError as e:
        print(str(e))

    try:
        attribute_0 = Attribute(isa="int")
    except AssertionError as e:
        print(str(e))

    try:
        attribute_0 = Attribute(isa="float")
    except AssertionError as e:
        print(str(e))


# Generated at 2022-06-25 04:51:55.532332
# Unit test for constructor of class Attribute
def test_Attribute():
    f = FieldAttribute()
    # Make sure we get the same as the one we set
    assert isinstance(f.isa, type(None))
    assert f.private == False
    assert isinstance(f.default, type(None))
    assert f.required == False
    assert isinstance(f.listof, type(None))
    assert f.priority == 0
    assert isinstance(f.class_type, type(None))
    assert f.always_post_validate == False
    assert f.inherit == True
    assert isinstance(f.alias, type(None))
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-25 04:51:57.129688
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()


if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:52:03.710203
# Unit test for constructor of class Attribute
def test_Attribute():
    # test with no arguments
    attr1 = Attribute()
    assert attr1.isa is None
    assert attr1.private is False
    assert attr1.default is None
    assert attr1.required is False
    assert attr1.listof is None
    assert attr1.priority == 0
    assert attr1.class_type is None
    assert attr1.always_post_validate is False
    assert attr1.inherit is True
    assert attr1.alias is None
    assert attr1.extend is False
    assert attr1.prepend is False
    assert attr1.static is False

    # test with args

# Generated at 2022-06-25 04:52:08.692487
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr.class_type = 'str'
    attr.default = 'jess'
    attr.isa = 'str'
    attr.listof = 'jess'
    attr.private = False
    attr.priority = 0
    attr.required = False
    assert attr.class_type == 'str'
    assert attr.default == 'jess'
    assert attr.isa == 'str'
    assert attr.listof == 'jess'
    assert attr.private == False
    assert attr.priority == 0
    assert attr.required == False


# Generated at 2022-06-25 04:52:10.366456
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False

# Generated at 2022-06-25 04:52:11.573557
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().static == False
    assert Attribute(static=True).static == True


# Generated at 2022-06-25 04:52:12.803864
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attribute_0 = FieldAttribute()
    assert isinstance(field_attribute_0, FieldAttribute)



# Generated at 2022-06-25 04:52:17.400049
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False

    # Test for exception in __init__ of FieldAttribute

# Generated at 2022-06-25 04:52:21.853844
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()
    assert x.isa is None
    assert x.private is False
    assert x.default is None
    assert x.required is False
    assert x.listof is None
    assert x.priority == 0
    assert x.class_type is None
