

# Generated at 2022-06-25 04:42:31.027006
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute("isa", False, "default", True, "listof", 0, "class_type", True, True, "alias")
    assert attribute.isa == "isa"
    assert attribute.private == False
    assert attribute.default == "default"
    assert attribute.required == True
    assert attribute.listof == "listof"
    assert attribute.priority == 0
    assert attribute.class_type == "class_type"
    assert attribute.always_post_validate == True
    assert attribute.inherit == True
    assert attribute.alias == "alias"


# Generated at 2022-06-25 04:42:38.811697
# Unit test for constructor of class Attribute
def test_Attribute():
    float_0 = -1732.5
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    str_0 = 'ODQr6l'
    attribute_0 = Attribute(str_0)
    var_0 = attribute_0.__gt__(dict_0)


# Generated at 2022-06-25 04:42:39.333060
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-25 04:42:47.020292
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'JrcPmHyIywOwWqd3otv'
    attribute_0 = FieldAttribute(listof=str_0)
    assert isinstance(attribute_0, FieldAttribute)
    dict_1 = {}
    assert attribute_0.isa == str_0
    assert attribute_0.required == False
    assert attribute_0.default == None
    assert attribute_0.listof == str_0
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False
    bool_

# Generated at 2022-06-25 04:42:51.363048
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        # NOTE: test has been commented out because some Kinds of attributes cannot be constructed with an invalid isa.
        # Should be uncommented when attribute isa is set to the correct Kind.
        # test_FieldAttribute_with_ok_args()
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:42:58.167701
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Test: FieldAttribute")
    float_0 = -1732.5
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    str_0 = 'ODQr6l'
    attribute_0 = Attribute(str_0)
    var_0 = attribute_0.__gt__(dict_0)
    print("Pass: FieldAttribute")

test_FieldAttribute()


# Generated at 2022-06-25 04:43:03.480677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    float_0 = -1459.9
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    str_0 = 'ODQr6l'
    attribute_0 = Attribute(str_0)
    attribute_1 = Attribute(str_0)
    attribute_2 = Attribute(str_0)
    dict_1 = {str_0: attribute_2}
    dict_2 = {str_0: attribute_2}
    attribute_3 = Attribute(str_0)
    attribute_4 = Attribute(str_0)
    attribute_5 = Attribute(str_0)
    dict_3 = {str_0: attribute_5}
    dict_4 = {str_0: attribute_5}
    attribute_6 = Att

# Generated at 2022-06-25 04:43:09.508161
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    float_0 = -1732.5
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    str_0 = 'ODQr6l'
    attribute_0 = Attribute(str_0)
    var_0 = attribute_0.__gt__(dict_0)
    str_1 = 'V'
    attribute_1 = Attribute(str_0)
    var_1 = attribute_1.__eq__(dict_0)
    str_2 = 'C'
    attribute_2 = Attribute(str_0)
    var_2 = attribute_2.__ge__(dict_0)
    attribute_3 = Attribute(str_0)
    str_3 = '2W'

# Generated at 2022-06-25 04:43:11.275910
# Unit test for constructor of class Attribute
def test_Attribute():
    # create a new Attribute
    new_Attribute = Attribute()
    # test if Attribute is a subclass of Attribute
    assert issubclass(Attribute, Attribute)



# Generated at 2022-06-25 04:43:15.954821
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    ansible_0 = 'r'
    attribute_0 = FieldAttribute(ansible_0)
    str_0 = 'jvjiA6'
    ansible_0 = attribute_0.__ge__(str_0)


# Generated at 2022-06-25 04:43:21.318447
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

print("Hello World!")
test_Attribute()

# Generated at 2022-06-25 04:43:27.762500
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    str_1 = 'ecn_mo_y'
    bool_3 = False
    attribute_1 = Attribute(str_1, bool_3, str_0, bool_3, str_0, bool_3, str_0, bool_3, bool_3, str_0)
    bool_2 = attribute_0 != attribute_1
    str_2 = "Attribute('str', False, 'listuf', False, 'listuf', False, 'listuf', False, False, 'listuf')"
    str_3 = attribute_0.__str__

# Generated at 2022-06-25 04:43:40.026503
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    Attribute(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    Attribute(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    Attribute('', '', '', '', '', '', '', '', '', '')

# Generated at 2022-06-25 04:43:52.131184
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = False
    bool_8 = True
    bool_9 = True
    bool_10 = False
    str_0 = 'YERzTJTBTG'
    str_1 = 'L\x00Wl2|q'
    str_2 = 'tJhW8*5qm'
    str_3 = 'oO\x06\'XuB"'
    str_4 = '7\x1e\x0eq'
    str_5 = 'P\x17XU\x10'
    str_6 = 'ZDpnMx\x1b!c'
    float

# Generated at 2022-06-25 04:43:53.937646
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:43:58.382998
# Unit test for constructor of class Attribute
def test_Attribute():
    # Verify that the following line of code compiles
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:44:00.179817
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    assert test_case_0() == None
# end class FieldAttribute



# Generated at 2022-06-25 04:44:02.273867
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:44:06.909718
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # Test if the default value of attribute alias is None
    assert attribute_0.alias is None


# Generated at 2022-06-25 04:44:17.655486
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from copy import copy, deepcopy

    # Test for constructor without any arguments
    def test_0():
        fieldattribute_0 = FieldAttribute()

    # Test for constructor with valid arguments
    def test_1():
        bool_0 = False
        str_0 = 'listuf'
        fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

    # Test for constructor with invalid arguments
    def test_2():
        bool_0 = True
        str_0 = 'liscdf'

# Generated at 2022-06-25 04:44:23.783247
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)



# Generated at 2022-06-25 04:44:32.846336
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == 'listuf'
    assert attribute_0.private == False
    assert attribute_0.default == 'listuf'
    assert attribute_0.required == False
    assert attribute_0.listof == 'listuf'
    assert attribute_0.priority == False
    assert attribute_0.class_type == 'listuf'
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == False
    assert attribute_0.alias == 'listuf'
    assert attribute_0.extend

# Generated at 2022-06-25 04:44:42.917386
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert bool_0 == attribute_0.static
    assert str_0 == attribute_0.alias
    assert bool_0 == attribute_0.inherit
    assert bool_0 == attribute_0.always_post_validate
    assert str_0 == attribute_0.class_type
    assert bool_0 == attribute_0.required
    assert str_0 == attribute_0.listof
    assert str_0 == attribute_0.isa
    assert bool_0 == attribute_0.private
    assert str_0 == attribute_0.default



# Generated at 2022-06-25 04:44:45.695452
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='list', private=False, default='listuf', required=False, listof='listuf', priority=False, class_type='listuf', always_post_validate=False, inherit=False, alias='listuf')
    assert attribute is not None


# Generated at 2022-06-25 04:44:48.002454
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    str_1 = attribute_0.isa
    assert str_1 == str_0


# Generated at 2022-06-25 04:44:58.297250
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    bool_1 = bool_0
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == str_0
    assert attribute_0.required == bool_0
    assert attribute_0.listof == str_0
    assert attribute_0.priority == bool_0
    assert attribute_0.class_type == str_0
    assert attribute_0.always_post_validate == bool_0
    assert attribute_0.inherit == bool_0

# Generated at 2022-06-25 04:45:08.635006
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == 'listuf'
    assert attribute_0.private == False
    assert attribute_0.default == 'listuf'
    assert attribute_0.required == False
    assert attribute_0.listof == 'listuf'
    assert attribute_0.priority == False
    assert attribute_0.class_type == 'listuf'
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == False
    assert attribute_0.alias == 'listuf'


# Generated at 2022-06-25 04:45:10.608424
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(str, False, 'str', False, str, False, str, False, False, str, False, False, False, False)


# Generated at 2022-06-25 04:45:21.314719
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attr_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attr_0.isa is None and attr_0.private is None and attr_0.default is None and attr_0.required is None and attr_0.listof is None and attr_0.priority == 0 and attr_0.class_type is None and attr_0.always_post_validate is None and attr_0.inherit is None and attr_0.alias == str_0

# Generated at 2022-06-25 04:45:23.450169
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:45:33.110477
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'x'
    test_Attribute = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    bool_0 = True
    str_0 = field_attribute_0.isa
    bool_0 = field_attribute_0.private
    str_0 = field_attribute_0.default
    bool_0 = field_attribute_0.required
    str_0 = field_attribute_0.listof
    str_0 = field_attribute_0.priority
    str_0 = field_attribute_0.class_type
    bool_0 = field_attribute_0.always_post_validate
    bool_0 = field_attribute_0.inherit


# Generated at 2022-06-25 04:45:45.552683
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # constructor with parameters
    # parameter "isa" of type "str"
    str_1 = 'listuf'
    # parameter "private" of type "bool"
    bool_1 = False
    # parameter "default" of type "str"
    str_2 = 'listuf'
    # parameter "required" of type "bool"
    bool_2 = False
    # parameter "listof" of type "str"
    str_3 = 'listuf'
    # parameter "priority" of type "bool"
    bool_3 = False
    # parameter "class_type" of type "str"
    str_4 = 'listuf'
    # parameter "always_post_validate" of type "bool"
    bool_4 = False
    # parameter "inherit" of type "bool"
    bool_5 = False


# Generated at 2022-06-25 04:45:47.710118
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(static='1 ')


# Generated at 2022-06-25 04:45:57.193304
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    str_1 = 'jiki1'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    field_attribute_0 = FieldAttribute(str_1, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


if __name__ == '__main__':
    # For a more comprehensive test, see the next test case
    test_case_0()
    # Unit test for constructor of class FieldAttribute
    test_FieldAttribute()

# Generated at 2022-06-25 04:46:01.221739
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

# Generated at 2022-06-25 04:46:06.103325
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:46:06.794328
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:46:12.079439
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

# Generated at 2022-06-25 04:46:22.872644
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    attribute_0 = FieldAttribute(isa=False, alias=None)
    assert attribute_0.isa == False
    assert attribute_0.alias == None
    attribute_1 = FieldAttribute(isa='listuf', alias=None, extend=None)
    assert attribute_1.isa == 'listuf'
    assert attribute_

# Generated at 2022-06-25 04:46:35.759149
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor arguments are of type '<type 'str'>'
    bool_0 = False
    str_0 = 'listuf'
    # No error
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

    # Constructor arguments are of type '<type 'bool'>'
    bool_0 = False
    str_0 = 'listuf'
    # No error
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

    # Constructor arguments are of type '<type 'str'>'
    bool_0 = False
    str

# Generated at 2022-06-25 04:46:41.460183
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0.inherit == True

# Generated at 2022-06-25 04:46:46.164463
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:46:51.989139
# Unit test for constructor of class Attribute
def test_Attribute():
    '''Test case 0'''
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # Test if the fields of Attribute object are set correctly.
    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == str_0
    assert attribute_0.required == bool_0
    assert attribute_0.listof == str_0
    assert attribute_0.priority == bool_0
    assert attribute_0.class_type == str_0
    assert attribute_0.always_post_validate == bool_0
    assert attribute_0

# Generated at 2022-06-25 04:46:57.415041
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    attribute_1 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # Verify that the first object is the same as the second
    assert attribute_0 == attribute_1


# Generated at 2022-06-25 04:46:58.933401
# Unit test for constructor of class Attribute
def test_Attribute():

    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)



# Generated at 2022-06-25 04:47:01.420183
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    FieldAttribute(bool_0)

# Generated at 2022-06-25 04:47:06.889297
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)



# Generated at 2022-06-25 04:47:14.976909
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=False, alias='listof')
    assert(attribute.isa == 'list')
    assert(attribute.private == True)
    assert(attribute.required == True)
    assert(attribute.priority == 0)
    assert(attribute.class_type == None)
    assert(attribute.always_post_validate == False)
    assert(attribute.inherit == False)
    assert(attribute.alias == 'listof')



# Generated at 2022-06-25 04:47:19.570611
# Unit test for constructor of class Attribute
def test_Attribute():
    print('Testing constructor of Attribute')
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:47:29.212630
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    field_attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

# Generated at 2022-06-25 04:47:36.188736
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: implement this test when implemented the constructor of Attribute class
    pass


# Generated at 2022-06-25 04:47:44.040873
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('test_FieldAttribute')
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    field_attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert isinstance(field_attribute_0, FieldAttribute)
    assert field_attribute_0.isa == str_0
    assert field_attribute_0.required == bool_0
    assert field_attribute_0.alias == str_0
    assert field_attribute_0.listof == str_0
   

# Generated at 2022-06-25 04:47:51.661651
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        # test that Attribute class does not allow a non-callable default value for a mutable data type (list, dict or set)
        mutable_default = []
        attribute_0 = Attribute(None, None, mutable_default)
    except TypeError as e:
        pass
    else:
        assert False

    try:
        attribute_0 = Attribute(None, None, None, None, None, None, None, None, None, None)
    except TypeError as e:
        pass
    else:
        assert False


# Generated at 2022-06-25 04:47:59.930090
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    bool_1 = True
    str_0 = 'Zv=l'
    int_0 = 0
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, int_0, str_0, bool_0, bool_0, str_0)
    print(attribute_0.listof)
    print(attribute_0.required)
    print(attribute_0.isa)
    print(attribute_0.default)
    print(attribute_0.extend)
    print(attribute_0.private)
    print(attribute_0.class_type)
    print(attribute_0.inherit)
    print(attribute_0.static)
    print(attribute_0.priority)
    print(attribute_0.prepend)


# Generated at 2022-06-25 04:48:01.315885
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    str_0 = 'yh2'
    attribute_0 = FieldAttribute('ENU0kp', 'Z6U5')


# Generated at 2022-06-25 04:48:08.146316
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    assert __new__(Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)) is not None



# Generated at 2022-06-25 04:48:13.762489
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # TEST CASE 0
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # END OF TEST CASE 0


# Generated at 2022-06-25 04:48:14.469094
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:48:18.431467
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    str_0 = 'str'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    bool_1 = False
    str_1 = 'listuf'
    attribute_1 = FieldAttribute(str_0, bool_0, str_1, bool_0, str_0, bool_1, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:48:19.702400
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()



# Generated at 2022-06-25 04:48:36.186992
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'g'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    attribute_1 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == attribute_1.isa
    assert attribute_0.private == attribute_1.private
    assert attribute_0.default == attribute_1.default
    assert attribute_0.required == attribute_1.required
    assert attribute_0.listof == attribute_1.listof
    assert attribute_0.priority == attribute_1.priority

# Generated at 2022-06-25 04:48:39.355533
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = '_'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:48:40.134827
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:44.117529
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'listuf'
    bool_0 = False
    obj_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0)



# Generated at 2022-06-25 04:48:46.509167
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:48:50.464555
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa=TypeError, private=complex, default=complex, required=complex, listof=TypeError, priority=complex, class_type=complex, always_post_validate=complex, inherit=complex, alias=TypeError, extend=complex, prepend=complex, static=complex)


# Generated at 2022-06-25 04:48:53.227456
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'listuf'
    Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:49:03.724930
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.listof == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == str_0
    assert attribute_0.required == bool_0
    assert attribute_0.priority == bool_0
    assert attribute_0.class_type == str_0
    assert attribute_0.alias == str_0
    assert attribute_0.extend == bool_0
    assert attribute_0.prepend == False

# Generated at 2022-06-25 04:49:09.320836
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # Test for constructor of class FieldAttribute with parameters
    field_attribute_0 = FieldAttribute(attribute_0)



# Generated at 2022-06-25 04:49:15.912188
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    bool_1 = True
    str_0 = 'listuf'
    str_1 = 'listuf'
    int_0 = 1
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:49:38.060015
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:49:40.563174
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:49:49.628319
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:49:59.994928
# Unit test for constructor of class Attribute
def test_Attribute():
    # no docstring
    # class_type: str
    str_2 = 'class'
    # boolean: bool
    bool_0 = False
    # isa: str
    str_0 = 'listuf'
    # priority: int
    int_0 = 0
    # required: bool
    bool_1 = False
    # private: bool
    bool_2 = False
    # default: str
    str_1 = 'listuf'
    # listof: str
    str_3 = 'listuf'
    # inherit: bool
    bool_3 = False
    # alias: str
    str_4 = 'listuf'
    # extend: bool
    bool_4 = False
    # prepend: bool
    bool_5 = False

# Generated at 2022-06-25 04:50:07.562225
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    assert Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0).isa == str_0
    assert Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0).private == bool_0
    assert Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0).default == str_0

# Generated at 2022-06-25 04:50:14.408743
# Unit test for constructor of class Attribute
def test_Attribute():
    # Initialize field default_value to value of parameter default_value
    default_value = 'listuf'
    # Initialize field require to value of parameter require
    require = False
    # Initialize field alias to value of parameter alias
    alias = 'listuf'
    # Initialize field isa to value of parameter isa
    isa = 'listuf'
    # Initialize field always_post_validate to value of parameter always_post_validate
    always_post_validate = False
    # Initialize field inherit to value of parameter inherit
    inherit = False
    # Initialize field priority to value of parameter priority
    priority = False
    # Initialize field listof to value of parameter listof
    listof = 'listuf'
    # Initialize field class_type to value of parameter class_type

# Generated at 2022-06-25 04:50:19.783244
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    str_1 = 'kf!@y'
    attribute_0 = Attribute(str_1, bool_0, str_1, bool_0, str_1, bool_0, str_1, bool_0, bool_0, str_1)

# Generated at 2022-06-25 04:50:22.849813
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # params
    bool_0 = False
    str_0 = 'listuf'
    # test constructor
    FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


test_case_0()
test_FieldAttribute()

# Generated at 2022-06-25 04:50:26.848006
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:50:37.300359
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    str_0 = 'amrF9%9JT,T+'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    attribute_1 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    field_attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    # Assert class type of 'field_attribute_0' is 'FieldAttribute'
    assert field_

# Generated at 2022-06-25 04:51:21.321249
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructors of class FieldAttribute
    # Test type of Attribute (type 'FieldAttribute')
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

    assert isinstance(attribute_0, Attribute)

# Generated at 2022-06-25 04:51:24.776824
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:51:28.114169
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)


if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:51:34.118631
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:51:45.052013
# Unit test for constructor of class Attribute
def test_Attribute():
    # constructor
    attribute_0 = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    attribute_1 = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    attribute_2 = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)

# Generated at 2022-06-25 04:51:55.643303
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == "listuf"
    assert attribute_0.private == False
    assert attribute_0.default == "listuf"
    assert attribute_0.required == False
    assert attribute_0.listof == "listuf"
    assert attribute_0.priority == False
    assert attribute_0.class_type == "listuf"
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == False
    assert attribute_0.alias == "listuf"

    class_None = None
   

# Generated at 2022-06-25 04:52:06.027560
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = False
    str_0 = 'foo'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    assert attribute_0.isa == str_0, 'attribute_0.isa not as expected. Actual value: ' + str(attribute_0.isa)
    assert attribute_0.private == bool_0, 'attribute_0.private not as expected. Actual value: ' + str(attribute_0.private)
    assert attribute_0.default == str_0, 'attribute_0.default not as expected. Actual value: ' + str(attribute_0.default)
    assert attribute_0.required == bool_0, 'attribute_0.required not as expected. Actual value: '

# Generated at 2022-06-25 04:52:14.333255
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    
    bool_0 = False
    str_0 = 'listuf'
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)

    field_attribute_0 = FieldAttribute(attribute_0)
    assert field_attribute_0.required == attribute_0.required
    assert isinstance(field_attribute_0, Attribute)
    assert field_attribute_0.extend == attribute_0.extend
    assert field_attribute_0.priority == attribute_0.priority
    assert field_attribute_0.prepend == attribute_0.prepend
    assert field_attribute_0.inherit == attribute_0.inherit
    assert field_attribute_0.class_type == attribute

# Generated at 2022-06-25 04:52:22.720995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        bool_0 = False
        str_0 = 'listuf'
        field_attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0)
    except Exception as e:
        print(e)
    else:
        assert True

if __name__ == '__main__':
    test_FieldAttribute()