

# Generated at 2022-06-25 04:42:31.801536
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # get instance of class FieldAttribute
    field_attribute_obj = FieldAttribute()

    assert field_attribute_obj.isa == None
    assert field_attribute_obj.private == False
    assert field_attribute_obj.default == None
    assert field_attribute_obj.required == False
    assert field_attribute_obj.listof == None
    assert field_attribute_obj.priority == 0
    assert field_attribute_obj.class_type == None
    assert field_attribute_obj.always_post_validate == False
    assert field_attribute_obj.inherit == True
    assert field_attribute_obj.alias == None
    assert field_attribute_obj.extend == False
    assert field_attribute_obj.prepend == False
    assert field_attribute_obj.static == False


# Generated at 2022-06-25 04:42:38.456721
# Unit test for constructor of class Attribute
def test_Attribute():

    # set up some attributes
    test_attribute_1 = Attribute(isa='test_isa', default='test_default',
                                 required='test_required', listof='test_listof',
                                 priority='test_priority', class_type='test_class_type',
                                 always_post_validate=True, alias='test_alias')

    assert test_attribute_1.isa == 'test_isa'
    assert test_attribute_1.default == 'test_default'
    assert test_attribute_1.required == 'test_required'
    assert test_attribute_1.listof == 'test_listof'
    assert test_attribute_1.priority == 'test_priority'
    assert test_attribute_1.class_type == 'test_class_type'
    assert test_attribute_1.always_post_valid

# Generated at 2022-06-25 04:42:40.229238
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0 != None, 'Constructor Attribute() did not return value expected'


# Generated at 2022-06-25 04:42:46.123088
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    float_0 = 0.0001
    dict_0 = {float_0: float_0}
    attribute_0 = Attribute(float_0, dict_0)



# Generated at 2022-06-25 04:42:56.826753
# Unit test for constructor of class Attribute
def test_Attribute():
    print('----- test_Attribute -----')
    float_0 = 0.0001
    dict_0 = {float_0: float_0}
    attribute_0 = Attribute(float_0, dict_0)
    if str(attribute_0.isa) != str(float_0):
        raise RuntimeError('isa is wrong')
    if str(attribute_0.private) != str(dict_0):
        raise RuntimeError('private is wrong')
    if not attribute_0.always_post_validate:
        raise RuntimeError('always_post_validate is wrong')
    if attribute_0.priority != 0:
        raise RuntimeError('priority is wrong')
    if attribute_0.class_type is not None:
        raise RuntimeError('class_type is wrong')
    if attribute_0.default is not None:
        raise Runtime

# Generated at 2022-06-25 04:42:57.709443
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:43:02.908482
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(0.0001, dict())
    assert attribute_0.isa == 0.0001
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None


# Generated at 2022-06-25 04:43:11.459443
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    var_manager = VariableManager(loader=loader)

    float_0 = float()
    float_1 = float()
    float_1 = 0.0001
    dict_0 = {}
    dict_0 = {float_1: float_1}
    attribute_0 = FieldAttribute(float_1, dict_0)

    # Constructor test case 0
    float_1 = float()
    float_1 = 0.0001
    dict_0 = {}
    dict_0 = {float_1: float_1}
    attribute_0 = FieldAttribute(float_1, dict_0)

   

# Generated at 2022-06-25 04:43:20.030835
# Unit test for constructor of class Attribute
def test_Attribute():
    float_0 = 0.0001
    dict_0 = {float_0: float_0}
    isa_0 = 0.0001
    dict_1 = {isa_0: isa_0}
    attribute_0 = Attribute(isa_0, dict_1)
    attribute_1 = Attribute()
    str_0 = attribute_0.isa
    str_1 = attribute_1.listof

    assert str_0 == '0.0001'
    assert str_1 is None

    assert dict_1 != dict_0
    assert dict_1 != {}

    assert dict_0 != dict_1
    assert {} != dict_1

    # NB: higher priority numbers sort first
    assert dict_1 < dict_0
    assert dict_1 > dict_0
    assert dict_0 == dict_0
    assert dict_

# Generated at 2022-06-25 04:43:21.238542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute.priority == 0


# Generated at 2022-06-25 04:43:24.817107
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = FieldAttribute(alias='aliased_attr')

    assert attr.alias == 'aliased_attr'



# Generated at 2022-06-25 04:43:37.441412
# Unit test for constructor of class Attribute
def test_Attribute():
    # default: set None, None, False, False, False, 0, None, False, True
    assert Attribute() == Attribute(None, False, None, False, False, 0, None, False, True)
    # set 'test' for isa
    field_attribute_0 = FieldAttribute(isa='test')
    assert field_attribute_0.isa == 'test'

    # set 'test' for listof
    field_attribute_1 = FieldAttribute(listof='test')
    assert field_attribute_1.listof == 'test'

    # set 'test' for class_type
    field_attribute_2 = FieldAttribute(class_type='test')
    assert field_attribute_2.class_type == 'test'

    # set 'test', 'test', True, True, True, 10, 'test', True, True,

# Generated at 2022-06-25 04:43:46.969962
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    #  static::Property declaration
    assert field_attribute_0.name=='FieldAttribute'
    assert field_attribute_0.isa==None
    assert field_attribute_0.private==False
    assert field_attribute_0.default==None
    assert field_attribute_0.required==False
    assert field_attribute_0.listof==None
    assert field_attribute_0.priority==0
    assert field_attribute_0.class_type==None
    assert field_attribute_0.always_post_validate==False
    assert field_attribute_0.inherit==True
    assert field_attribute_0.alias==None
    assert field_attribute_0.extend==False
    assert field_attribute_0.prepend==False
    assert field_attribute_0.static

# Generated at 2022-06-25 04:43:54.141961
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='str',
        private=False,
        default='default',
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert isinstance(attr, FieldAttribute)



# Generated at 2022-06-25 04:43:56.870383
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa='dict',
        private=False,
        default=dict,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=True,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    assert isinstance(field_attribute, FieldAttribute)


# Generated at 2022-06-25 04:44:02.503799
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().inherit == True
    assert Attribute().static == False



# Generated at 2022-06-25 04:44:08.304862
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().default == None
    assert Attribute().private == False
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().inherit == True
    assert Attribute().extend == False
    assert Attribute().prepend == False
    assert Attribute().static == False
    assert Attribute().isa == None
    assert Attribute().alias == None
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False


# Generated at 2022-06-25 04:44:10.850535
# Unit test for constructor of class Attribute
def test_Attribute():

    field_attribute_1 = FieldAttribute(isa='str',
                                       private=True,
                                       default=['0', '1', '2'],
                                       required=False,
                                       listof=False,
                                       priority=0,
                                       class_type='module',
                                       always_post_validate=False,
                                       inherit=True,
                                       alias=None,
                                       extend=False,
                                       prepend=False,
                                       static=False)


# Generated at 2022-06-25 04:44:22.930618
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    if field_attribute_0.isa is not None:
        raise ValueError('isa member is not None.')
    if field_attribute_0.private is not False:
        raise ValueError('private member is not False.')
    if field_attribute_0.default is not None:
        raise ValueError('default member is not None.')
    if field_attribute_0.required is not False:
        raise ValueError('required member is not False.')
    if field_attribute_0.listof is not None:
        raise ValueError('listof member is not None.')
    if field_attribute_0.priority is not 0:
        raise ValueError('priority member is not 0.')

# Generated at 2022-06-25 04:44:24.297203
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:44:31.731072
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()

    assert field_attribute_0.default is None
    assert field_attribute_0.listof is None
    assert field_attribute_0.required is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.alias is None


# Generated at 2022-06-25 04:44:36.490668
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    test_case_0()
    search_path_0 = field_attribute_0.extend
    return None



# Generated at 2022-06-25 04:44:37.666539
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Check isa parameter
    test_case_0()



# Generated at 2022-06-25 04:44:45.499995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False


# Generated at 2022-06-25 04:44:48.614480
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    if isinstance(field_attribute_0, Attribute):
        print("Pass")


# Generated at 2022-06-25 04:44:57.906100
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0
    assert not field_attribute_0.isa
    assert not field_attribute_0.private
    assert not field_attribute_0.default
    assert not field_attribute_0.required
    assert not field_attribute_0.listof
    assert field_attribute_0.priority == 0
    assert not field_attribute_0.class_type
    assert not field_attribute_0.always_post_validate
    assert field_attribute_0.inherit
    assert not field_attribute_0.alias
    assert not field_attribute_0.static


# Generated at 2022-06-25 04:45:08.336744
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa_1 = FieldAttribute(isa='int', private=True)
    fa_2 = FieldAttribute(isa='int', default=5)
    fa_3 = FieldAttribute(isa='int', required=True)
    fa_4 = FieldAttribute(isa='int', listof='bool')
    fa_5 = FieldAttribute(isa='int', priority=1)
    fa_6 = FieldAttribute(isa='int', class_type=int)
    fa_7 = FieldAttribute(isa='int', always_post_validate=True)
    fa_8 = FieldAttribute(isa='int', inherit=True)
    fa_9 = FieldAttribute(isa='int', alias='foo')
    fa_10 = FieldAttribute(isa='int', extend=True)
    fa_11 = FieldAttribute(isa='int', prepend=True)
    fa_

# Generated at 2022-06-25 04:45:14.259954
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test: isa not specified and private not specified
    field_attribute_0 = FieldAttribute(isa=None, private=False)
    # Test: isa specified and private not specified
    field_attribute_1 = FieldAttribute(isa='foo', private=False)
    # Test: isa not specified and private specified
    field_attribute_2 = FieldAttribute(isa=None, private=True)
    # Test: isa specified and private specified
    field_attribute_3 = FieldAttribute(isa='bar', private=True)
    test_case_0()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:45:15.124835
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:45:26.609847
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr1 = Attribute()
    assert id(attr) == id(attr1), '1'
    attr2 = attr
    attr3 = deepcopy(attr)
    assert id(attr2) == id(attr3), '2'
    attr4 = Attribute(alias='test_attr')
    assert attr4.alias == 'test_attr', '3'
    attr5 = Attribute(alias='test_attr', isa='str')
    assert attr5.alias == 'test_attr'
    assert attr5.isa == 'str'
    assert id(attr5) != id(attr4), '4'
    print('Attribute test done')


if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:45:30.479745
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:45:33.808114
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()



# Generated at 2022-06-25 04:45:38.614185
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private == False
    assert attribute.default is None
    assert attribute.required == False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias is None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-25 04:45:40.890830
# Unit test for constructor of class Attribute
def test_Attribute():
    attr0 = Attribute()
    assert attr0.default == None
    attr1 = Attribute(default=True)
    assert attr1.default == True
    attr2 = Attribute(default=False)
    assert attr2.default == False

# Generated at 2022-06-25 04:45:47.987509
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(
        isa=str,
        private=True,
        default=None,
        required=True,
        listof=str,
        priority=0,
        class_type=str,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False
    )
    assert copy is not None
    assert deepcopy is not None
    assert FA.isa is str
    assert FA.private is True
    assert FA.default is None
    assert FA.required is True
    assert FA.listof is str
    assert FA.priority == 0
    assert FA.class_type is str
    assert FA.always_post_validate is False
    assert FA.inherit is True
    assert FA.alias is None
    assert FA

# Generated at 2022-06-25 04:45:57.665816
# Unit test for constructor of class Attribute
def test_Attribute():

    # Make sure Attribute instance can be created with no arguments
    field_attribute = Attribute()

    assert field_attribute.isa is None
    assert field_attribute.private == False
    assert field_attribute.default is None
    assert field_attribute.required == False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias is None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False

    # Make sure Attribute instance can be created with arguments

# Generated at 2022-06-25 04:46:06.237124
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='extend', private=True, default=Attribute, required=True, listof='required', priority=0, class_type='class_type', always_post_validate=True, inherit=False, alias=Attribute, extend=True, prepend=True, static=True)
    assert field_attribute_0.isa == 'extend'
    assert field_attribute_0.private == True
    assert field_attribute_0.default == Attribute
    assert field_attribute_0.required == True
    assert field_attribute_0.listof == 'required'
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == 'class_type'
    assert field_attribute_0.always_post_validate == True
    assert field_attribute_0.inher

# Generated at 2022-06-25 04:46:10.655772
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute()
    field_attribute_2 = FieldAttribute(isa = "str", private = True, default = "OK", required = True, listof = "int", priority = 1, class_type = "int", always_post_validate = True, inherit = False, alias = "test_case_2_alias")

    if __name__ == '__main__':
        print(field_attribute_1)
        print(field_attribute_1.isa)
        print(field_attribute_1.private)
        print(field_attribute_1.default)
        print(field_attribute_1.required)
        print(field_attribute_1.listof)
        print(field_attribute_1.priority)
        print(field_attribute_1.class_type)

# Generated at 2022-06-25 04:46:21.844676
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    if isinstance(field_attribute_0, FieldAttribute) != True:
        raise Exception('Attribute is not initialized as FieldAttribute')
    if field_attribute_0.isa != None:
        raise Exception('The value of field_attribute_0.isa is not set as expected.')
    if field_attribute_0.private != False:
        raise Exception('The value of field_attribute_0.private is not set as expected.')
    if field_attribute_0.default != None:
        raise Exception('The value of field_attribute_0.default is not set as expected.')
    if field_attribute_0.required != False:
        raise Exception('The value of field_attribute_0.required is not set as expected.')
    if field_attribute_0.listof != None:
        raise Exception

# Generated at 2022-06-25 04:46:26.938947
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # default is not mutable data structure
    assert_raises(TypeError, Attribute, default={})



# Generated at 2022-06-25 04:46:35.724812
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor with no parameters
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None, "field_attribute_0.isa is not as expected: " + str(field_attribute_0.isa)

    # Constructor with parameters
    field_attribute_1 = FieldAttribute(isa='list')
    assert field_attribute_1.isa == 'list', "field_attribute_1.isa is not as expected: " + str(field_attribute_1.isa)

# Unit test to check comparison operators of class FieldAttribute

# Generated at 2022-06-25 04:46:40.724850
# Unit test for constructor of class Attribute
def test_Attribute():
    constructor_attribute1 = Attribute()
    print(constructor_attribute1)

    constructor_attribute2 = Attribute('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j')
    print(constructor_attribute2)


# Generated at 2022-06-25 04:46:41.573941
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:46:45.604148
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field_attribute_0 = FieldAttribute()
    except(TypeError):
        assert True
    else:
        assert False

# unit test for method FieldAttribute.__eq__

# Generated at 2022-06-25 04:46:46.931889
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0 != None


# Generated at 2022-06-25 04:46:54.547450
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(isa='str', private=False, required=False, default=None, listof=None,
                                       priority=0, class_type=None, always_post_validate=False, inherit=True, alias="",
                                       extend=True, prepend=True, static=False)
    assert field_attribute_0.isa == 'str'
    assert field_attribute_0.private == False
    assert field_attribute_0.required == False
    assert field_attribute_0.default == None
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True

# Generated at 2022-06-25 04:47:00.715826
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(
        prepend=False,
        default=False,
        class_type=False,
        always_post_validate=False,
        isa=False,
        inherit=False,
        listof=False,
        private=False,
        priority=0,
        required=False,
        alias=False,
        extend=False,
        static=False,
    )
    if not field_attribute_0:
        raise AssertionError('FieldAttribute() failed')
    # assert field_attribute_0 != None
    if python3:
        if not isinstance(field_attribute_0, Attribute):
            raise AssertionError('FieldAttribute() failed')

# Generated at 2022-06-25 04:47:08.580712
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert(f.isa == None)
    assert(f.private == False)
    assert(f.default == None)
    assert(f.required == False)
    assert(f.listof == None)
    assert(f.priority == 0)
    assert(f.class_type == None)
    assert(f.always_post_validate == False)
    assert(f.inherit == True)

# Test cases for comparison operators of class FieldAttribute

# Generated at 2022-06-25 04:47:17.735265
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

# These tests prove that isa must be a string.
# The error message we receive is:
# AssertionError: expected TypeError not AssertionError
# Usage examples:
#     attr = Attribute(isa=23)
#     attr = Att

# Generated at 2022-06-25 04:47:19.149166
# Unit test for constructor of class Attribute
def test_Attribute():
    # test no args constructor
    def test_func():
        Attribute()

    # test constructor args
    def test_func():
        Attribute("attr1", False, None, False, None, 0, None, False, True, None)


# Generated at 2022-06-25 04:47:27.522097
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str',
    priority=5, class_type=__name__, always_post_validate=True, inherit=True, alias='test_alias',
    extend=True, prepend=True, static=True)
    assert field_attribute_1.isa == 'str'
    assert field_attribute_1.private == True
    assert field_attribute_1.default == 'test'
    assert field_attribute_1.required == True
    assert field_attribute_1.listof == 'str'
    assert field_attribute_1.priority == 5
    assert field_attribute_1.class_type == __name__
    assert field_attribute_1.always_post_validate == True
    assert field_attribute_1

# Generated at 2022-06-25 04:47:28.672945
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()



# Generated at 2022-06-25 04:47:38.936009
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa='ansible.freebsd.freebsd_service_module')
    field_attribute_2 = FieldAttribute(isa='ansible.freebsd.freebsd_service_module', private=True)
    field_attribute_3 = FieldAttribute(isa='ansible.freebsd.freebsd_service_module', private=True, default=0)
    field_attribute_4 = FieldAttribute(isa='ansible.freebsd.freebsd_service_module', private=True, default=0, required=True)
    field_attribute_5 = FieldAttribute(isa='ansible.freebsd.freebsd_service_module', private=True, default=0, required=True, listof=None)

# Generated at 2022-06-25 04:47:44.764548
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False

# Generated at 2022-06-25 04:47:50.270306
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    expected_isa = 'foo'
    field_attribute_0 = FieldAttribute(isa=expected_isa)

    actual_isa = field_attribute_0.isa
    assert actual_isa == expected_isa


# Generated at 2022-06-25 04:47:54.567331
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:48:02.425907
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test Attribute with only isa parameter
    test_attribute_0 = Attribute(isa='entity_id')
    assert test_attribute_0.isa == 'entity_id'
    assert test_attribute_0.private == False
    assert test_attribute_0.default == None
    assert test_attribute_0.required == False
    assert test_attribute_0.listof == None
    assert test_attribute_0.priority == 0
    assert test_attribute_0.class_type == None
    assert test_attribute_0.always_post_validate == False
    assert test_attribute_0.inherit == True
    assert test_attribute_0.alias == None
    assert test_attribute_0.extend == False
    assert test_attribute_0.prepend == False
    assert test_attribute_0.static == False

# Generated at 2022-06-25 04:48:07.284533
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = Attribute()

    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:48:18.519298
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='str', private=False, default='default_value', required=True, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=False, alias=None, extend=False, prepend=False, static=False)
    assert isinstance(field_attribute_0, Attribute)
    assert field_attribute_0.isa == 'str'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == 'default_value'
    assert field_attribute_0.required == True
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 1
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False


# Generated at 2022-06-25 04:48:28.123491
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False



# Generated at 2022-06-25 04:48:35.904830
# Unit test for constructor of class Attribute
def test_Attribute():
   field_attribute_0 = FieldAttribute()
   if not field_attribute_0:
        raise AssertionError('Issue creating FieldAttribute')


# Generated at 2022-06-25 04:48:40.546854
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa="bool", private=False, default=True, required=False, listof="bool", priority=0, class_type="bool", always_post_validate=False, inherit=True, alias="ansible_boole")
    assert attr.isa == "bool"
    assert attr.private == False
    assert attr.default == True
    assert attr.required == False
    assert attr.listof == "bool"
    assert attr.priority == 0
    assert attr.class_type == "bool"
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == "ansible_boole"
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-25 04:48:42.243689
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0 != None

# Generated at 2022-06-25 04:48:53.136566
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:48:59.820411
# Unit test for constructor of class Attribute
def test_Attribute():
    _isa = 'str'
    _private = False
    _default = 'test'
    _required = False
    _listof = None
    _priority = 0
    _class_type = None
    _always_post_validate = False
    _inherit = True
    _alias = None
    _extends = False
    _prepend = False
    _static = False

    field_attribute_0 = FieldAttribute(_isa,
                                       _private,
                                       _default,
                                       _required,
                                       _listof,
                                       _priority,
                                       _class_type,
                                       _always_post_validate,
                                       _inherit,
                                       _alias,
                                       _extends,
                                       _prepend,
                                       _static)


# Generated at 2022-06-25 04:49:03.387684
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: Fix test case
    field_attribute_0 = FieldAttribute()
    # assert field_attribute_0.isa



# Generated at 2022-06-25 04:49:12.202471
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_test = Attribute(
        isa='str',
        private=True,
        default=(lambda: ['foo', 'bar']),
        required=True,
        listof='int',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert attribute_test.isa == 'str'
    assert attribute_test.private is True
    assert callable(attribute_test.default)
    assert attribute_test.default() == ['foo', 'bar']
    assert attribute_test.required is True
    assert attribute_test.listof == 'int'
    assert attribute_test.priority == 0
    assert attribute_test.class_type

# Generated at 2022-06-25 04:49:21.934035
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    expected_result_0 = {'isa': None, 'private': False, 'default': None, 'required': False, 'listof': None, 'priority': 0, 'class_type': None, 'always_post_validate': False, 'inherit': True, 'alias': None}
    # Constructor invocation
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is expected_result_0['isa']
    assert field_attribute_0.private is expected_result_0['private']
    assert field_attribute_0.default is expected_result_0['default']
    assert field_attribute_0.required is expected_result_0['required']
    assert field_attribute_0.listof is expected_result_0['listof']

# Generated at 2022-06-25 04:49:28.603352
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attribute_0 = FieldAttribute(prepend=False)
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.prepend is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.default is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.private is False
    assert field_attribute_0.required is False
    assert field_attribute_0.class_type is None
    assert field_attribute_0.static is False
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.isa is None


# Generated at 2022-06-25 04:49:39.377178
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    assert field_attribute_1.isa is None
    assert field_attribute_1.private is False
    assert field_attribute_1.default is None
    assert field_attribute_1.required is False
    assert field_attribute_1.listof is None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type is None
    assert field_attribute_1.always_post_validate is False
    assert field_attribute_1.inherit is True
    assert field_attribute_1.alias is None
    assert field_attribute_1.extend is False
    assert field_attribute_1.prepend is False
    assert field_attribute_1.static is False
    # assert field_attribute_1 is instance of FieldAttribute class

# Generated at 2022-06-25 04:49:50.020334
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()

    assert field_attribute_0.default is None
    assert not field_attribute_0.private
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert not field_attribute_0.always_post_validate
    assert field_attribute_0.inherit
    assert field_attribute_0.alias is None
    assert not field_attribute_0.extend
    assert not field_attribute_0.prepend
    assert not field_attribute_0.static
    assert field_attribute_0.isa is None


# Generated at 2022-06-25 04:50:00.117009
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute()
    assert field_attribute != None, "Error constructing FieldAttribute"
    assert field_attribute.isa == None, "Error constructing FieldAttribute"
    assert field_attribute.private == False, "Error constructing FieldAttribute"
    assert field_attribute.default == None, "Error constructing FieldAttribute"
    assert field_attribute.required == False, "Error constructing FieldAttribute"
    assert field_attribute.listof == None, "Error constructing FieldAttribute"
    assert field_attribute.priority == 0, "Error constructing FieldAttribute"
    assert field_attribute.class_type == None, "Error constructing FieldAttribute"
    assert field_attribute.inherit == True, "Error constructing FieldAttribute"
    assert field_attribute.alias == None, "Error constructing FieldAttribute"


# Generated at 2022-06-25 04:50:07.614495
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:50:13.006890
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.alias == None
    assert field_attribute_0.private == False
    assert field_attribute_0.class_type == None
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.isa == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.priority == 0
    assert field_attribute_0.default == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    # constructor __init__ with multiple arguments

# Generated at 2022-06-25 04:50:16.570388
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute()
    assert(obj.isa == None)
    assert(obj.private == False)
    assert(obj.default == None)
    assert(obj.required == False)
    assert(obj.listof == None)
    assert(obj.priority == 0)
    assert(obj.class_type == None)
    assert(obj.always_post_validate == False)
    assert(obj.inherit == True)
    assert(obj.alias == None)
    assert(obj.extend == False)
    assert(obj.prepend == False)
    assert(obj.static == False)



# Generated at 2022-06-25 04:50:18.019823
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:50:19.063832
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:50:23.742080
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        field_attribute_0 = FieldAttribute()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:50:27.400201
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Testing FieldAttribute

# Generated at 2022-06-25 04:50:29.152325
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0


# Generated at 2022-06-25 04:50:42.543635
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:50:49.413962
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    try:
        assert field_attribute_0
    except AssertionError as e:
        print("AssertionError: ", e)
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False

# Generated at 2022-06-25 04:50:51.897668
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0
    assert isinstance(field_attribute_0, FieldAttribute)


# Generated at 2022-06-25 04:50:53.540641
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(required=True)


# Generated at 2022-06-25 04:50:56.482335
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_test = FieldAttribute()
    assert isinstance(field_attribute_test, FieldAttribute)
    assert isinstance(field_attribute_test, Attribute)


# Generated at 2022-06-25 04:51:02.477213
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:51:12.583940
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert not field_attribute_0.isa
    assert not field_attribute_0.extend
    assert not field_attribute_0.prepend
    assert not field_attribute_0.static
    assert not field_attribute_0.private
    assert field_attribute_0.default is None
    assert not field_attribute_0.required
    assert not field_attribute_0.listof
    assert field_attribute_0.priority == 0
    #assert not field_attribute_0.inherit
    #assert field_attribute_0.alias == None
    assert not field_attribute_0.always_post_validate
    #assert not field_attribute_0.class_type
    #assert field_attribute_0.isa == "dict"
    #assert field_attribute_0.isa == "

# Generated at 2022-06-25 04:51:15.335775
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict')



# Generated at 2022-06-25 04:51:25.408959
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:51:37.123830
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_0 = Attribute()
    assert attr_0.static == False
    assert attr_0.inherit == True
    assert attr_0.prepend == False
    assert attr_0.extend == False
    attr_1 = Attribute(prepend=True, extend=True, inherit=False)
    assert attr_1.static == False
    assert attr_1.inherit == False
    assert attr_1.prepend == True
    assert attr_1.extend == True
    attr_2 = Attribute(extend=[1,2,3,4,5], inherit=False)
    assert attr_2.static == False
    assert attr_2.inherit == False
    assert attr_2.prepend == False

# Generated at 2022-06-25 04:52:09.474753
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        test_case_0()
    except Exception:
        import traceback
        errorMsg = traceback.format_exc()
        print(errorMsg)
        assert False
    else:
        assert True


# Generated at 2022-06-25 04:52:14.885457
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa=FieldAttribute,
                                     private=True,
                                     default=None,
                                     required=False,
                                     listof=FieldAttribute,
                                     priority=0,
                                     class_type=None,
                                     always_post_validate=False,
                                     inherit=True,
                                     alias=None,
                                     extend=False,
                                     prepend=False,
                                     static=False
                                     )
    assert type(field_attribute) == FieldAttribute
    assert field_attribute.isa == FieldAttribute
    assert field_attribute.private == True
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == FieldAttribute
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
   

# Generated at 2022-06-25 04:52:24.466578
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False

