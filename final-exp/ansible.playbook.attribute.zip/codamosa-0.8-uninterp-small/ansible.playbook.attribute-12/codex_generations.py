

# Generated at 2022-06-25 04:42:33.027472
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "8o]W_9vco'\x1b\x1c\x0c"
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    attribute_0 = Attribute(str_0, bool_0, bool_1, bool_2, str_0, bool_3, bool_4, bool_5, bool_6, bool_7)


# Generated at 2022-06-25 04:42:42.547545
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    dict_1 = {'n': 'n', 'n': 'n', 'n': 'n'}
    bytes_1 = b'\xcc\xa2\x11\x0e[\x1b\xba\x0f\xdd'
    int_1 = -88
    field_attribute_1 = FieldAttribute(dict_1, bytes_1, int_1, bytes_1, bytes_1)
    str_1 = "sVhk!\x1eV\x9d\x0b7\xbd"
    dict_2 = {str_1: str_1, str_1: str_1, str_1: str_1}

# Generated at 2022-06-25 04:42:49.010772
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "Ry*tqB'G@](nUfdkr\x0b"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'-\x05\xb0\x1f4U\x878k\xa9'
    int_0 = -83
    field_attribute_0 = FieldAttribute(dict_0, bytes_0, int_0, bytes_0, bytes_0)



# Generated at 2022-06-25 04:42:51.173390
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()



# Generated at 2022-06-25 04:43:02.135271
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "Ry*tqB'G@](nUfdkr\x0b"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'-\x05\xb0\x1f4U\x878k\xa9'
    int_0 = -83
    attribute_0 = Attribute(dict_0, int_0, dict_0, dict_0, bytes_0)

    assert attribute_0.isa is dict_0
    assert attribute_0.private is int_0
    assert attribute_0.default is dict_0
    assert attribute_0.required is dict_0
    assert attribute_0.listof is bytes_0
    assert attribute_0.priority == 0

# Generated at 2022-06-25 04:43:07.093417
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    dict_0 = dict()
    bytes_0 = b'{\x0e\x1f\xdb\x13\x16\x07\x1c\x1b}p'
    int_0 = -40
    field_attribute_0 = FieldAttribute(dict_0, bytes_0, int_0, bytes_0, bytes_0)
    str_0 = "i4/4X/u@'^x/{=\x1bS\x16|"
    str_1 = "[B\x16\x0f\x1f\x1a8\x82\x1a\n\x16\x17\x1d\x1c\x0f_\x15"

# Generated at 2022-06-25 04:43:16.299846
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "Ry*tqB'G@](nUfdkr\x0b"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'-\x05\xb0\x1f4U\x878k\xa9'
    int_0 = -83
    test_Attribute_0 = Attribute(dict_0, bytes_0, int_0, bytes_0, bytes_0)
    print (test_Attribute_0)


# Generated at 2022-06-25 04:43:24.783493
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 't%cYt-\x1c\x1d\x17\x06\xc2\x18\x8d'
    dict_0 = {str_0: str_0}
    int_0 = -18
    str_1 = 'z\x11\xdd\x0f\x06\x98\x1f\x0c\xc0F\x8e\xfe\x01\x13'
    int_1 = -7
    str_2 = '\x1c\x0bz\xb3\x13\x9f\xcd\x93\x05'
    int_2 = -45

# Generated at 2022-06-25 04:43:37.394415
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "Ry*tqB'G@](nUfdkr\x0b"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'-\x05\xb0\x1f4U\x878k\xa9'
    int_0 = -83
    # Function FieldAttribute calls constructor FieldAttribute.__init__,
    # assertion is made that attributes of instance of FieldAttribute
    # are initialized to desired values
    assert FieldAttribute(dict_0, bytes_0, int_0, bytes_0, bytes_0).isa == dict_0
    assert FieldAttribute(dict_0, bytes_0, int_0, bytes_0, bytes_0).private == bytes_0

# Generated at 2022-06-25 04:43:39.703936
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

# Generated at 2022-06-25 04:43:52.751493
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.color import ANSIBLE_COLOR, stringc
    from ansible.errors import AnsibleOptionsError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.collections import is_sequence

    # Setting up arguments
    attr_name_str = "attr_name"
    attr_type_str = "str"
    attr_default_str = "default"
    attr_required_bool = True
    attr_always_post_validate_bool

# Generated at 2022-06-25 04:43:59.266137
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)

if __name__ == "__main__":
    import sys, os

    try:
        import coverage
        cov = coverage.coverage(source=[os.path.abspath(__file__)])
        cov.start()

        sys.exit(
            nose.run(
                argv=[
                    sys.argv[0],
                    os.path.abspath(__file__),
                    '-v'
                ]
            )
        )
    except KeyboardInterrupt:
        raise
    except:
        pass

    cov.stop()

# Generated at 2022-06-25 04:44:09.697361
# Unit test for constructor of class Attribute
def test_Attribute():
    print('Testing constructor of Attribute')
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    assert Attribute(tuple_0, str_0).private == str_0
    assert Attribute(tuple_0, str_0).isa == tuple_0

    #Test with the alias argument
    str_1 = "test_alias"
    assert Attribute(tuple_0, str_0, alias=str_1).alias == str_1

    #Test with the extend argument
    assert Attribute(tuple_0, str_0, extend=True).extend == True

    #Test with the prepend argument
    assert Attribute(tuple_0, str_0, prepend=True).prepend == True

    #Test with the static argument

# Generated at 2022-06-25 04:44:14.800623
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    list_0 = []
    str_0 = ''
    dict_0 = dict()
    set_0 = set()
    field_attribute_0 = FieldAttribute(tuple_0, list_0, str_0, dict_0, set_0)


# Generated at 2022-06-25 04:44:24.561183
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert field_attribute_0.isa == tuple_0
    assert field_attribute_0.private == str_0
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False

# Generated at 2022-06-25 04:44:33.404411
# Unit test for constructor of class Attribute
def test_Attribute():
    #  Set the first attribute
    isa = "(*a'%cbo<MX+{~P!uw7VH"
    private = '[V'
    default = 'Y&ZJ:tG+0-dD4y_1'
    required = 'xR%cO$9Zaw[SZ|$T'
    listof = 'y#6l=U&gbBud6Dv#'
    priority = '!{[!b#}|>'
    class_type = 'JB'
    always_post_validate = 'h{'
    inherit = '!%.;!c+hr}VyHh^'
    alias = '(q3uSEY&`#*'
    extend = 'Rp?G'
    prepend = 'wHV7'

# Generated at 2022-06-25 04:44:38.325649
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert field_attribute_0.isa == tuple_0
    assert field_attribute_0.private == str_0



# Generated at 2022-06-25 04:44:40.187779
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert type(test_case_0()) == FieldAttribute


# Generated at 2022-06-25 04:44:47.677114
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_1 = Attribute()
    attr_2 = Attribute('list', True, 'Test 1 list', True, 'str')
    attr_3 = Attribute('True', True, 'Test 2 bool', True, 'str', 1, 'IS_TRUE')
    attr_4 = Attribute('int', True, 'Test 3 int', True, 'str', 2, 'IS_INT')
    attr_5 = Attribute('str', True, 'Test 4 str', True, 'str', 3, 'IS_STRING')
    attr_6 = Attribute('dict', True, 'Test 5 dict', True, 'str', 4, 'IS_DICT')
    attr_7 = Attribute('none', True, 'Test 6 none', True, 'str', 5, 'IS_NONE')

# Generated at 2022-06-25 04:44:50.823373
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'

    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    field_attribute_1 = FieldAttribute(tuple_0, str_0)

    # equality test for FieldAttribute
    assert hash(field_attribute_0) == hash(field_attribute_1)



# Generated at 2022-06-25 04:44:59.534355
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert field_attribute_0.isa == ()
    assert field_attribute_0.private == '|&X4L[#~Q!Zrb:Q}P\n'
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias

# Generated at 2022-06-25 04:45:04.449005
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)


# Generated at 2022-06-25 04:45:13.548739
# Unit test for constructor of class Attribute
def test_Attribute():
    class A(object):
        def __init__(self):
            self.attr = Attribute(str)

    class B(object):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @property
        def static_attr(self):
            return "static_attr"

    a = A()
    b = B()

    if hasattr(a, 'attr'):
        pass
    if hasattr(a, 'static_attr'):
        pass

# Generated at 2022-06-25 04:45:18.739409
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    # constructor did not raise an Exception

# Generated at 2022-06-25 04:45:21.466106
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor test:
    try:
        test_case_0()
    except:
        print("Failed to construct FieldAttribute expected")


# Generated at 2022-06-25 04:45:25.155147
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    del field_attribute_0


# Generated at 2022-06-25 04:45:29.864000
# Unit test for constructor of class Attribute
def test_Attribute():

    # init_0: default values for all attributes
    tuple_0 = ()
    str_0 = 'I}v7V$xcR\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)


# Generated at 2022-06-25 04:45:39.485247
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class_attribute_0 = FieldAttribute()
    return_value_0 = class_attribute_0.listof
    assert return_value_0 == None
    return_value_0 = class_attribute_0.required
    assert return_value_0 == False
    return_value_0 = class_attribute_0.priority
    assert return_value_0 == 0
    return_value_0 = class_attribute_0.private
    assert return_value_0 == False
    return_value_0 = class_attribute_0.always_post_validate
    assert return_value_0 == False
    return_value_0 = class_attribute_0.default
    assert return_value_0 == None
    return_value_0 = class_attribute_0.prepend
    assert return_value_0 == False
    return_value_0

# Generated at 2022-06-25 04:45:43.132034
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)



# Generated at 2022-06-25 04:45:46.625357
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    try:
        field_attribute_0 = FieldAttribute(tuple_0, str_0)
    except TypeError as e:
        print('caught TypeError', e)



# Generated at 2022-06-25 04:46:02.275298
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(always_post_validate=True)
    assert f.isa == None
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == True
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False

    attr = FieldAttribute(always_post_validate=False)
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr

# Generated at 2022-06-25 04:46:05.233995
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '^(!L@z'
    attribute_0 = Attribute(str_0)
    assert attribute_0 is not None


# Generated at 2022-06-25 04:46:13.764762
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:46:24.685382
# Unit test for constructor of class Attribute
def test_Attribute():

    # Placeholder code to demonstrate passing tests
    attribute_0 = Attribute()
    attribute_1 = Attribute('a','b','c','d','e','f','g','h','i','j','k','l','m')
    
    assert attribute_0 != attribute_1
    assert attribute_0 == attribute_0
    assert attribute_1 == attribute_1
    assert attribute_0 != attribute_1
    assert attribute_0 != attribute_1

    assert attribute_0 != attribute_1
    assert attribute_0 == attribute_0
    assert attribute_1 == attribute_1
    assert attribute_0 != attribute_1

    assert attribute_0 != attribute_1
    assert attribute_0 == attribute_0
    assert attribute_1 == attribute_1
    assert attribute_0 != attribute_1

    assert attribute_0 != attribute_1
    assert attribute

# Generated at 2022-06-25 04:46:30.434046
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)


# Generated at 2022-06-25 04:46:33.843248
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)



# Generated at 2022-06-25 04:46:34.559837
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

# Generated at 2022-06-25 04:46:41.128046
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test creation of instance of Attribute class
    isa = 'list'
    private = False
    default = None
    required = True
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    attribute0 = Attribute(isa, private, default, required, listof, priority,
                           class_type, always_post_validate, inherit, alias,
                           extend, prepend, static)

    assert attribute0.isa == 'list'
    assert attribute0.private == False
    assert attribute0.default == None
    assert attribute0.required == True
    assert attribute0.listof == None
    assert attribute0.priority == 0

# Generated at 2022-06-25 04:46:51.360430
# Unit test for constructor of class Attribute
def test_Attribute():
    class_type_0 = 'dp}6\nU6'
    class_type_1 = 'dp}6\nU6'
    field_attribute_0 = FieldAttribute(listof='ZU*E`T', class_type=class_type_0)
    field_attribute_1 = FieldAttribute(listof='ZU*E`T', class_type=class_type_1)
    field_attribute_2 = FieldAttribute(listof='ZU*E`T', class_type=class_type_1)
    field_attribute_3 = FieldAttribute(listof='ZU*E`T', class_type=class_type_1)
    field_attribute_4 = FieldAttribute(listof='ZU*E`T', class_type=class_type_1)

# Generated at 2022-06-25 04:46:53.425532
# Unit test for constructor of class Attribute
def test_Attribute():
    # Verify that the resulting objects have the appropriate properties set by the constructor
    test_case_0()

# Generated at 2022-06-25 04:47:08.300956
# Unit test for constructor of class Attribute
def test_Attribute():
    # No exception is thrown
    attribute_0 = Attribute(class_type="", isa="", listof="")
    # No exception is thrown
    attribute_1 = Attribute(class_type="", isa="", listof="")
    # Test attribute inheritance
    assert attribute_1.__class__.__bases__[0] == attribute_0.__class__.__bases__[0]



# Generated at 2022-06-25 04:47:10.645064
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("---Testing class FieldAttribute---")
    for i in range(10):
        test_case_0()
    print("Unit testing finished")



# Generated at 2022-06-25 04:47:16.697920
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)

    assert field_attribute_0.isa == tuple_0 
    assert field_attribute_0.private == str_0

# Generated at 2022-06-25 04:47:23.777418
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = ';I>1<\r8W?p\n\'fPm!\\m'
    str_1 = '|&X4L[#~Q!Zrb:Q}P\n'
    attribute_0 = Attribute(None, None, None, None, None, None, str_0, str_1, False, None)
    attribute_1 = Attribute(isa = tuple_0, alias = str_0, inherit = False)
    attribute_2 = Attribute(isa = tuple_1, inherit = False, alias = str_0)
    attribute_3 = Attribute(isa = tuple_0, alias = str_1, inherit = False)

# Generated at 2022-06-25 04:47:27.822904
# Unit test for constructor of class Attribute
def test_Attribute():

    with pytest.raises(TypeError):
        Attribute(default=1)
    #Test the create of Attribute instance
    A = Attribute()
    assert isinstance(A, Attribute)


# Generated at 2022-06-25 04:47:31.284968
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = ']xQ<#?~^LAep\x17\x7f@'
    attribute_0 = Attribute(tuple_0, str_0)



# Generated at 2022-06-25 04:47:38.971900
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleParserError
    from ansible.vars.manager import VariableManager

    vault_password_0 = 'vault_password'
    vault_password = VaultLib(vault_password_0)
    field_attribute_0 = FieldAttribute(vault_password)
    field_attribute_1 = FieldAttribute(vault_password_0)


# Generated at 2022-06-25 04:47:43.475759
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    class_0 = '/'
    field_attribute_1 = FieldAttribute(class_0)
    class_1 = '!2'
    field_attribute_2 = FieldAttribute(class_1)
    field_attribute_2.isa = 'i'
    field_attribute_1.isa = 't'
    field_attribute_1.isa = 'u'

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:47:45.651859
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=dict)
    assert a.isa == dict


# Generated at 2022-06-25 04:47:48.938474
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)


# Generated at 2022-06-25 04:48:18.361336
# Unit test for constructor of class Attribute
def test_Attribute():

    tuple_0 = ()
    str_0 = 'd+,M<>|:Zj^6Uuu[@U-|\n'
    dict_0 = dict()

    field_attribute_0 = FieldAttribute(tuple_0, str_0)

    # test for instance attributes

    assert field_attribute_0.isa == tuple_0
    assert field_attribute_0.private == str_0
    assert field_attribute_0.default == dict_0
    assert field_attribute_0.required == dict_0
    assert field_attribute_0.listof == dict_0
    assert field_attribute_0.priority == dict_0
    assert field_attribute_0.class_type == dict_0
    assert field_attribute_0.always_post_validate == dict_0
    assert field_attribute_0.inher

# Generated at 2022-06-25 04:48:22.589810
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert field_attribute_0.isa == tuple_0
    assert field_attribute_0.private == str_0

# Generated at 2022-06-25 04:48:29.391444
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = []
    private = "private"
    default = "default"
    required = "required"
    listof = "listof"
    priority = "priority"
    class_type = "class_type"
    always_post_validate = "always_post_validate"
    inherit = "inherit"
    alias = "alias"
    extend = "extend"
    prepend = "prepend"
    static = "static"
    attribute = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)


# Generated at 2022-06-25 04:48:30.870292
# Unit test for constructor of class Attribute
def test_Attribute():
    # verify object creation
    attribute_0 = Attribute()
    print(type(attribute_0))


# Generated at 2022-06-25 04:48:41.372578
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    tuple_1 = ()
    str_1 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_2 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_3 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_4 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_5 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_6 = '|&X4L[#~Q!Zrb:Q}P\n'
    str_

# Generated at 2022-06-25 04:48:52.161736
# Unit test for constructor of class Attribute
def test_Attribute():

    # Arrange
    expected_isa = "set"
    expected_private = False
    expected_default = [1,2,3]
    expected_required = True
    expected_listof = "int"
    expected_priority = 1
    expected_class_type = list
    expected_inherit = False
    expected_always_post_validate = False
    expected_alias = "some_alternative_name"
    
    # Act

# Generated at 2022-06-25 04:48:55.617403
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Attribute is tested with two parameters, isa and private,
    and test isa is a tuple (not supported) and private is 'false'
    '''
    tuple_0 = ()
    Str_0 = 'false'
    field_attribute_0 = FieldAttribute(tuple_0, Str_0)


# Generated at 2022-06-25 04:49:05.506676
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'foo'
    private = False
    default = None
    required = False
    listof = 'bar'
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = 'baz'

    Attribute_test = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)

    # Test isa
    assert Attribute_test.isa == isa

    # Test private
    assert Attribute_test.private == private

    # Test default
    assert Attribute_test.default == default

    # Test required
    assert Attribute_test.required == required

    # Test listof
    assert Attribute_test.listof == listof

    # Test priority
    assert Attribute_

# Generated at 2022-06-25 04:49:11.321309
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    attribute_0 = Attribute(tuple_0, str_0)
    assert attribute_0.static
    assert attribute_0.static_cache is None
    assert attribute_0.static_loader is None


# Generated at 2022-06-25 04:49:16.425999
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    assert Attribute(tuple_0, str_0) == {'isa': (), 'private': '|&X4L[#~Q!Zrb:Q}P\n'}


# Generated at 2022-06-25 04:49:47.838911
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test default constructor
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:49:52.912320
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert field_attribute_0 is not None


# Generated at 2022-06-25 04:49:55.575571
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    assert(isinstance(field_attribute_0, FieldAttribute))
    assert(isinstance(field_attribute_0, Attribute))


# Generated at 2022-06-25 04:50:05.858089
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = max
    str_0 = 'rZ?%J|'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    field_attribute_0 = FieldAttribute(required=True, listof=tuple_0)
    field_attribute_0 = FieldAttribute(attribute=tuple_0, format='dissp', always_post_validate=True)

# Generated at 2022-06-25 04:50:11.358949
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Set up test data
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    # Verify test passed
    print('Test passed')

test_FieldAttribute()

# Generated at 2022-06-25 04:50:16.217643
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    attribute_0 = Attribute()
    str_0 = "set()"
    assert(str(attribute_0) == str_0)

    isa_0 = 'set'
    private_0 = False
    default_0 = 'set()'
    required_0 = False
    listof_0 = 'set'
    priority_0 = 0
    class_type_0 = list
    always_post_validate_0 = False
    inherit_0 = True
    alias_0 = 'monitor_type'
    extend_0 = False
    prepend_0 = False
    static_0 = False

# Generated at 2022-06-25 04:50:18.839225
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    attribute_0 = Attribute(tuple_0, str_0)


# Generated at 2022-06-25 04:50:28.407092
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    field_attribute_0 = FieldAttribute(tuple_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    field_attribute_0 = FieldAttribute(tuple_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, bool_0=True)



# Generated at 2022-06-25 04:50:38.349664
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    #
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    #
    assert field_attribute_0.listof == tuple()
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.default == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.private == '|&X4L[#~Q!Zrb:Q}P\n'
    assert field_attribute_0.prepend == False
    assert field_attribute_0.required == False
    assert field_attribute_0.extend == False

# Generated at 2022-06-25 04:50:48.007848
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)

    # Verify that str_0 and field_attribute_0.isa are equal
    assert str_0 == field_attribute_0.isa, "Verify that str_0 and field_attribute_0.isa are equal"
    # Verify that tuple_0 and field_attribute_0.required are not equal
    assert tuple_0 != field_attribute_0.required, "Verify that tuple_0 and field_attribute_0.required are not equal"
    # Verify that 0.143388 and field_attribute_0.inherit are equal

# Generated at 2022-06-25 04:51:42.810709
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)

    # test with hashable values
    assert field_attribute_0 != Attribute(isa=True)
    assert field_attribute_0 != Attribute(default=True)
    assert field_attribute_0 != Attribute(required=True)
    assert field_attribute_0 != Attribute(listof=True)
    assert field_attribute_0 != Attribute(priority=1)
    assert field_attribute_0 != Attribute(class_type=True)
    assert field_attribute_0 != Attribute(always_post_validate=True)
    assert field_attribute_0 != Attribute(inherit=True)


# Generated at 2022-06-25 04:51:44.542172
# Unit test for constructor of class Attribute
def test_Attribute():
   value_attribute_0 = Attribute(listof=bool)
   assert value_attribute_0.listof == bool


# Generated at 2022-06-25 04:51:46.961221
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)
    print(field_attribute_0)


# Generated at 2022-06-25 04:51:49.626574
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = FieldAttribute(tuple_0, str_0)



# Generated at 2022-06-25 04:51:51.873417
# Unit test for constructor of class Attribute
def test_Attribute():
    tuple_0 = ()
    str_0 = '|&X4L[#~Q!Zrb:Q}P\n'
    field_attribute_0 = Attribute(tuple_0, str_0)


# Generated at 2022-06-25 04:52:02.717879
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    val = FieldAttribute(isa='michael')
    assert val.isa == 'michael'

    val = FieldAttribute(isa=str, private=True)
    assert val.isa == str
    assert val.private == True
    assert val.default == None

    val = FieldAttribute(isa=str, private=True, default=1)
    assert val.isa == str
    assert val.private == True
    assert val.default == 1

    val = FieldAttribute(isa=str, private=True, default=1, required=True)
    assert val.isa == str
    assert val.private == True
    assert val.default == 1
    assert val.required == True

    val = FieldAttribute(isa=str, private=True, default=1, required=True, listof=1)
    assert val.isa == str
    assert val

# Generated at 2022-06-25 04:52:12.756432
# Unit test for constructor of class Attribute
def test_Attribute():
    string_0 = '|JdYVLhNM{%'
    field_0 = FieldAttribute('I<;`C,xB', string_0, 0)
    field_1 = FieldAttribute()
    field_2 = FieldAttribute()
    field_3 = FieldAttribute(False, False, 0)
    field_4 = FieldAttribute()
    field_5 = FieldAttribute()
    field_6 = FieldAttribute(False, False, 0)
    field_7 = FieldAttribute()
    field_8 = FieldAttribute('QTWx#+>|C', False, True)
    field_9 = FieldAttribute()

test_case_0()
test_Attribute()

# Generated at 2022-06-25 04:52:22.173339
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()