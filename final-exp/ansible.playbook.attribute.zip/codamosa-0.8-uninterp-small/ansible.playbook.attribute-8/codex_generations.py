

# Generated at 2022-06-25 04:42:32.895970
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'nab\\oZ4[3FW|}U!1'
    str_1 = 'v'
    bool_0 = False
    attribute_0 = Attribute(str_0, str_1, bool_0)
    assert (attribute_0.isa == 'v')
    assert (attribute_0.default is None)
    assert (attribute_0.static == bool_0)
    assert (attribute_0.inherit == bool_0)
    assert (attribute_0.private == bool_0)
    assert (attribute_0.required == bool_0)
    assert (attribute_0.extend == bool_0)
    assert (attribute_0.prepend == bool_0)
    assert (attribute_0.priority == 0)


# Generated at 2022-06-25 04:42:39.291863
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '%s must be installed to use check mode'
    str_1 = '|P%<]2Y.:P-=z33L\\5'
    bool_0 = False
    attribute_0 = Attribute(str_0, str_1, bool_0)
    attribute_1 = Attribute(str_0, str_1, bool_0)
    assert not attribute_0 == attribute_1

# Generated at 2022-06-25 04:42:44.651698
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Class is not instantiated.
    string_0 = '{}vD|!PKh_p'
    string_1 = '#LV.4*4Zq`z'
    bool_0 = True
    attribute_0 = Attribute(string_0, string_1, bool_0)
    field_attribute_0 = FieldAttribute(string_0, string_1, bool_0)
    string_2 = 'test'
    assert(string_2 == str(field_attribute_0))


# Generated at 2022-06-25 04:42:54.528914
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '~O8{iT$)pRAedw&'
    bool_0 = False
    field_attribute_0 = FieldAttribute(str_0, bool_0)
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is True
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority is 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None


# Generated at 2022-06-25 04:42:58.627225
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '%s must be installed to use check mode'
    str_1 = '|P%<]2Y.:P-=z33L\\5'
    bool_0 = False
    attribute_1 = FieldAttribute(str_0, str_1, bool_0)

test_case_0()
test_FieldAttribute()

# Generated at 2022-06-25 04:43:00.650059
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute("string", bool(0), bool(0))
    assert isinstance(attribute, Attribute)


# Generated at 2022-06-25 04:43:05.107590
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0.extend == False
    assert attribute_0.prepend == False


# Generated at 2022-06-25 04:43:10.709592
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'o9p'
    str_1 = 'Y(?}W3Ha5[>#'
    bool_0 = True
    list_0 = ['B', '#', 'w', 'W', '0', '%', 'N']
    FieldAttribute_0 = FieldAttribute(str_0, str_1, bool_0, list_0)
    assert FieldAttribute_0.alias is None
    default_value = []
    FieldAttribute_0.default = default_value
    assert len(FieldAttribute_0.default) == 0


# Generated at 2022-06-25 04:43:19.838413
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '%s must be installed to use check mode'
    str_1 = '|P%<]2Y.:P-=z33L\\5'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, str_1, bool_0)
    assert isinstance(attribute_0, Attribute)

    attr_dict = {
        'isa': 'str',
        'default': 'oops',
        'required': False,
        'private': True,
        'priority': 1,
        'aliases': ['oops'],
    }
    attr_kwargs = {
        'isa': 'str',
        'default': 'oops',
        'required': False,
        'private': True,
        'priority': 1,
        'alias': 'oops',
    }
    fa

# Generated at 2022-06-25 04:43:23.228580
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_2 = '%s must be installed to use check mode'
    str_3 = '|P%<]2Y.:P-=z33L\\5'
    bool_1 = False
    attribute_1 = FieldAttribute(str_2, str_3, bool_1)


# Generated at 2022-06-25 04:43:37.482517
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a_1 = Attribute(
        isa='int',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    # Test string representation of this object
    assert str(a_1) == 'Attribute(isa=\'int\', private=False, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)'

# Generated at 2022-06-25 04:43:40.097260
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()
    print("FieldAttribute constructor test finished successfully")
    return

# Generated at 2022-06-25 04:43:47.620677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    assert field_attribute_1.isa == None
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias == None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False

# Generated at 2022-06-25 04:43:48.324412
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert(test_case_0())

# Generated at 2022-06-25 04:43:56.759199
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='boolean', default=False, always_post_validate=False,static=False)
    if field_attribute.isa != 'boolean':
        raise Exception("Incorrect value in constructor")
    if field_attribute.private != False:
        raise Exception("Incorrect value in constructor")
    if field_attribute.default != False:
        raise Exception("Incorrect value in constructor")
    if field_attribute.required != False:
        raise Exception("Incorrect value in constructor")
    if field_attribute.listof != None:
        raise Exception("Incorrect value in constructor")
    if field_attribute.priority != 0:
        raise Exception("Incorrect value in constructor")
    if field_attribute.class_type != None:
        raise Exception("Incorrect value in constructor")

# Generated at 2022-06-25 04:44:05.234115
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = Attribute()
    assert field_attribute_1.isa == None
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias == None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False


# Generated at 2022-06-25 04:44:16.806886
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False)
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False

# Generated at 2022-06-25 04:44:25.436653
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0
    assert isinstance(field_attribute_0, Attribute) is True
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0

# Generated at 2022-06-25 04:44:31.333336
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(isa="dict", private=False,required=True, listof="string")
    assert field_attribute_1.isa == "dict", "field_attribute_1.isa should be 'dict', it is {}".format(field_attribute_1.isa)
    assert field_attribute_1.private == False, "field_attribute_1.private should be False, it is true"
    assert field_attribute_1.required == True, "FieldAttribute_1.required should be True, it is false"
    assert field_attribute_1.listof == "string", "field_attribute_1.listof should be 'string', it is {}".format(field_attribute_1.listof)



# Generated at 2022-06-25 04:44:42.105276
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    print(field_attribute_0.isa)
    print(field_attribute_0.private)
    print(field_attribute_0.default)
    print(field_attribute_0.required)
    print(field_attribute_0.listof)
    print(field_attribute_0.priority)
    print(field_attribute_0.class_type)
    print(field_attribute_0.always_post_validate)
    print(field_attribute_0.inherit)
    print(field_attribute_0.alias)
    print(field_attribute_0.extend)
    print(field_attribute_0.prepend)
    print(field_attribute_0.static)


# Generated at 2022-06-25 04:44:53.710820
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(extend=False)
    field_attribute_1 = FieldAttribute()
    field_attribute_2 = FieldAttribute(extend=False, isa='str', class_type='str', default=0, priority=0)
    assert field_attribute_0.extend is False
    print('test 2')
    assert field_attribute_1.extend is False
    print('test 3')
    assert field_attribute_2.extend is False
    assert field_attribute_2.isa == 'str'
    assert field_attribute_2.class_type == 'str'
    assert field_attribute_2.priority == 0
    print('test success for FieldAttribute constructor')

test_FieldAttribute()

# Generated at 2022-06-25 04:45:04.453450
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test create new object, success
    # Test create new object, success

    field_attribute_0 = FieldAttribute()


#     # Test attributes of new object are correct, success
#     # Test attributes of new object are correct, success
#
#     assert field_attribute_0.isa == 'dict'
#     assert field_attribute_0.private == True
#     assert field_attribute_0.default == None
#     assert field_attribute_0.required == False
#     assert field_attribute_0.listof == None
#     assert field_attribute_0.priority == 0
#     assert field_attribute_0.class_type == None
#     assert field_attribute_0.always_post_validate == False
#     assert field_attribute_0.inherit == True
#     assert field_attribute_0.alias == None

# Generated at 2022-06-25 04:45:09.777242
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Testing Constructor of FieldAttribute")
    assert(test_case_0())



# Generated at 2022-06-25 04:45:14.904818
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:45:26.703600
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()

    if not isinstance(attr, Attribute):
        raise AssertionError("Check Attribute class failed, new Attribute is not instance of Attribute")

    if attr.isa != None:
        raise AssertionError("Check Attribute class failed, attribute isa is not initialized to None")

    if attr.private != False:
        raise AssertionError("Check Attribute class failed, attribute private is not initialized to False")

    if attr.default != None:
        raise AssertionError("Check Attribute class failed, attribute default is not initialized to None")

    if attr.required != False:
        raise AssertionError("Check Attribute class failed, attribute required is not initialized to False")


# Generated at 2022-06-25 04:45:38.657787
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute(isa='int', default=10, required=False, listof='int', priority=0, class_type='int', alias='listofall')
    # test class member variable "isa"
    assert field_attribute_1.isa == 'int'
    # test class member variable "private"
    assert field_attribute_1.private == False
    # test class member variable "default"
    assert field_attribute_1.default == 10
    # test class member variable "required"
    assert field_attribute_1.required == False
    # test class member variable "listof"
    assert field_attribute_1.listof == 'int'
    # test class member variable "priority"
    assert field_attribute_1.priority == 0
    # test class member variable "class_type"
    assert field_attribute

# Generated at 2022-06-25 04:45:43.591286
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with no input arguments
    field_attribute_0 = Attribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False

    # Test with some input arguments
    field_attribute

# Generated at 2022-06-25 04:45:50.674142
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False


# Generated at 2022-06-25 04:45:55.025157
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None,
                    priority=0,
                    class_type=None,
                    always_post_validate=False,
                    inherit=True,
                    alias=None,
                    extend=False,
                    prepend=False,
                    static=False)
    assert field_attribute_1.isa == "list"

# Generated at 2022-06-25 04:46:00.197952
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_test = FieldAttribute()
    assert field_attribute_test.isa is None
    assert field_attribute_test.private is False
    assert field_attribute_test.default is None
    assert field_attribute_test.required is False
    assert field_attribute_test.listof is None
    assert field_attribute_test.priority == 0
    assert field_attribute_test.class_type is None
    assert field_attribute_test.always_post_validate is False
    assert field_attribute_test.inherit is True
    assert field_attribute_test.alias is None
    assert field_attribute_test.extend is False
    assert field_attribute_test.prepend is False
    assert field_attribute_test.static is False

    # Testing with parameters

# Generated at 2022-06-25 04:46:09.178748
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute(isa="bool")
    assert field_attribute_1.isa == "bool"
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias == None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False


# Generated at 2022-06-25 04:46:11.678364
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert isinstance(field_attribute_0, Attribute)


# Generated at 2022-06-25 04:46:21.742459
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()

    assert field_attribute_1.isa is None
    assert field_attribute_1.private == False
    assert field_attribute_1.default is None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof is None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type is None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1.alias is None
    assert field_attribute_1.extend == False
    assert field_attribute_1.prepend == False
    assert field_attribute_1.static == False

# Generated at 2022-06-25 04:46:29.530832
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa='str')
    field_attribute_2 = FieldAttribute(isa='str', private=False)
    field_attribute_3 = FieldAttribute(isa='str', listof=field_attribute_1)
    field_attribute_4 = FieldAttribute(
        isa='str',
        listof=field_attribute_2,
        private=False,
        required=False,
        priority=0,
        class_type=None,
        always_post_validate=False,
        extend=False,
        prepend=False,
        static=False
    )
    default = 'test'

# Generated at 2022-06-25 04:46:36.886564
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(prepend=True, isa='Isa', default=Attribute, listof='listof', alias='alias')
    field_attribute_1 = FieldAttribute(prepend=True, isa='Isa', default=Attribute, listof='listof', alias='alias', inherit=True)
    field_attribute_2 = FieldAttribute(prepend=True, isa='Isa', default=Attribute, listof='listof', alias='alias', inherit=True, extend=False)
    field_attribute_3 = FieldAttribute(prepend=True, isa='Isa', default=Attribute, listof='listof', alias='alias', inherit=True, extend=False, priority=1, private=False)

# Generated at 2022-06-25 04:46:45.799004
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    field_attribute_1 = FieldAttribute(isa='dict', private=True, default=False, required=True, listof=False, priority=2)
    assert field_attribute_1.isa == 'dict'
    assert field_attribute_1.private == True
    assert field_attribute_1.default == False
    assert field_attribute_1.required == True
    assert field_attribute_1.listof == False
    assert field_attribute_1.priority == 2
# Test for comparison

# Generated at 2022-06-25 04:46:53.902696
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute(isa='int', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert field_attribute_1.isa == 'int'
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type == None
    assert field_attribute_1.always_post_validate == False
    assert field_attribute_1.inherit == True
    assert field_attribute_1

# Generated at 2022-06-25 04:47:04.488944
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False

    # test with some dummy values

# Generated at 2022-06-25 04:47:14.028398
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()

    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False



# Generated at 2022-06-25 04:47:22.381744
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    :class: `Attribute` is a representation of
    """
    # default contructor
    Attribute_0 = Attribute()
    assert Attribute_0.isa is None
    assert Attribute_0.private is False
    assert Attribute_0.default is None
    assert Attribute_0.required is False
    assert Attribute_0.listof is None
    assert Attribute_0.priority is 0
    assert Attribute_0.class_type is None
    assert Attribute_0.always_post_validate is False
    assert Attribute_0.inherit is True
    assert Attribute_0.alias is None
    assert Attribute_0.extend is False
    assert Attribute_0.prepend is False

    # Contructor with parameters isa, private, default, required, listof, priority

# Generated at 2022-06-25 04:47:28.432382
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:47:38.789496
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa = bool,
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False
    )
    assert field_attribute.isa == bool
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True


# Generated at 2022-06-25 04:47:50.496682
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa='list', default=list(), required=True, inherit=False, alias='block', extend=False, prepend=False)
    field_attribute_2 = FieldAttribute(isa='list', default=list(), required=True, inherit=False, alias='block', extend=False, prepend=False)
    field_attribute_3 = FieldAttribute(isa='list', default=list(), required=True, inherit=False, alias='block', extend=True, prepend=False)
    if field_attribute_1 == field_attribute_2:
        print("pass")
    else:
        print("fail")

    print(field_attribute_1.prepend)
    print("------------------")
    print(field_attribute_3.prepend)


# Generated at 2022-06-25 04:47:54.375775
# Unit test for constructor of class Attribute
def test_Attribute():
    fieldatt_0 = FieldAttribute()
    fieldatt_1 = FieldAttribute(
        isa = 'list',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )

    assert fieldatt_0.isa == fieldatt_1.isa
    assert fieldatt_0.private == fieldatt_1.private
    assert fieldatt_0.default == fieldatt_1.default
    assert fieldatt_0.required == fieldatt_1.required
    assert fieldatt_0.listof == fieldatt_1.listof
    assert fieldatt_

# Generated at 2022-06-25 04:48:02.294001
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = None
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    field_attribute_0 = FieldAttribute()
    # Test for exception in constructor
    assert field_attribute_0.isa == isa
    assert field_attribute_0.private == private
    assert field_attribute_0.default == default
    assert field_attribute_0.required == required
    assert field_attribute_0.listof == listof
    assert field_attribute_0.priority == priority
    assert field_attribute_0.class_type == class_type
    assert field_attribute_0.always_post_validate

# Generated at 2022-06-25 04:48:13.372151
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False
    # Test constructor with 1 argument passed
    attribute_1 = Attribute(isa=None)
    assert attribute_1.isa == None
    assert attribute_1.private == False
   

# Generated at 2022-06-25 04:48:14.320602
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:15.390235
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attribute_0 = FieldAttribute(isa = 'bool')
    assert field_attribute_0.isa == 'bool'

# Generated at 2022-06-25 04:48:19.265464
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:28.027762
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute()
    assert field.isa is None
    assert field.private == False
    assert field.default is None
    assert field.required == False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False


# Generated at 2022-06-25 04:48:47.332937
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    assert field_attribute_1 is not None
    assert field_attribute_1.isa is None
    assert field_attribute_1.private is False
    assert field_attribute_1.default is None
    assert field_attribute_1.required is False
    assert field_attribute_1.listof is None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.class_type is None
    assert field_attribute_1.always_post_validate is False
    assert field_attribute_1.inherit is True
    assert field_attribute_1.alias is None
    assert field_attribute_1.extend is False
    assert field_attribute_1.prepend is False
    assert field_attribute_1.static is False
    assert field_attribute_1.__

# Generated at 2022-06-25 04:48:55.033736
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        field_attribute_0 = FieldAttribute(listof=1)
    except TypeError as e:
        pass
    else:
        assert False, 'Expected Exception'

    try:
        field_attribute_0 = FieldAttribute(default={})
    except TypeError as e:
        pass
    else:
        assert False, 'Expected Exception'

    try:
        field_attribute_0 = FieldAttribute(default=())
    except TypeError as e:
        pass
    else:
        assert False, 'Expected Exception'

    try:
        field_attribute_0 = FieldAttribute(default='')
    except TypeError as e:
        pass
    else:
        assert False, 'Expected Exception'


# Generated at 2022-06-25 04:49:05.361840
# Unit test for constructor of class Attribute
def test_Attribute():
    # test case 1
    a = Attribute(isa='some_type')

    assert a.isa == 'some_type'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

    # test case 2
    a = Attribute(isa='some_type', private=True)

    assert a.isa == 'some_type'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None


# Generated at 2022-06-25 04:49:16.782870
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    # Verify that field isa of class FieldAttribute is set to default value None
    assert field_attribute_0.isa == None
    # Verify that field private of class FieldAttribute is set to default value False
    assert field_attribute_0.private == False
    # Verify that field default of class FieldAttribute is set to default value None
    assert field_attribute_0.default == None
    # Verify that field required of class FieldAttribute is set to default value False
    assert field_attribute_0.required == False
    # Verify that field listof of class FieldAttribute is set to default value None
    assert field_attribute_0.listof == None
    # Verify that field priority of class FieldAttribute is set to default value 0
    assert field_attribute_0.priority == 0
    # Verify that field class_type of class Field

# Generated at 2022-06-25 04:49:26.293213
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Unit test for the constructor of the class FieldAttribute
    """
    field_attribute_object = FieldAttribute(isa="string", private=True, default="test_default",
                                            required=True, listof=False, priority=0,
                                            class_type="string", always_post_validate=True,
                                            inherit=False, alias="test_alias", extend=True,
                                            prepend=True, static=True)

    assert field_attribute_object.isa == "string"
    assert field_attribute_object.private == True
    assert field_attribute_object.default == "test_default"
    assert field_attribute_object.required == True
    assert field_attribute_object.listof == False
    assert field_attribute_object.priority == 0
    assert field_attribute_object.class_

# Generated at 2022-06-25 04:49:28.588517
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert test_case_0() == None

# Generated at 2022-06-25 04:49:31.150494
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

# TestCase for testing equality of class FieldAttribute

# Generated at 2022-06-25 04:49:39.893006
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list', private=True, default={}, required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='thing', extend=True, prepend=True, static=True)
    assert (attribute.isa == 'list')
    assert (attribute.private == True)
    assert (attribute.default == {})
    assert (attribute.required == True)
    assert (attribute.listof == 'str')
    assert (attribute.priority == 1)
    assert (attribute.class_type == 'str')
    assert (attribute.always_post_validate == True)
    assert (attribute.inherit == True)
    assert (attribute.alias == 'thing')
    assert (attribute.extend == True)

# Generated at 2022-06-25 04:49:48.373951
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute = Attribute
    attribute = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=3,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert isinstance(attribute, Attribute)



# Generated at 2022-06-25 04:49:49.393279
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()

# Generated at 2022-06-25 04:50:09.861954
# Unit test for constructor of class Attribute
def test_Attribute():
    pass



# Generated at 2022-06-25 04:50:12.389620
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test the constructor of Attribute.
    """
    test_attribute = Attribute()
    assert test_attribute.__class__ == Attribute

# Generated at 2022-06-25 04:50:13.666134
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute is not None

# Generated at 2022-06-25 04:50:21.287177
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0 is not None
    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False

    # Test with param isa
   

# Generated at 2022-06-25 04:50:26.551663
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    field_attribute_2 = FieldAttribute(isa='int')
    field_attribute_3 = FieldAttribute(isa='dict')
    field_attribute_4 = FieldAttribute(isa='list')
    field_attribute_5 = FieldAttribute(isa='set')
    field_attribute_6 = FieldAttribute(isa='string')
    field_attribute_7 = FieldAttribute(isa='class')


# Generated at 2022-06-25 04:50:34.021145
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    #__init__(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0


# Generated at 2022-06-25 04:50:37.045641
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.__dict__ == {'isa': None, 'private': False, 'default': None, 'required': False, 'listof': None, 'priority': 0, 'class_type': None, 'always_post_validate': False, 'inherit': True, 'alias': None, 'extend': False, 'prepend': False, 'static': False}

# Generated at 2022-06-25 04:50:38.448667
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().__class__.__name__ == 'FieldAttribute'


# Generated at 2022-06-25 04:50:46.827552
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False
    # TODO: assert field_attribute_0 == field_attribute_0
    #

# Generated at 2022-06-25 04:50:58.353098
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    assert field_attribute_0.static is False


# Generated at 2022-06-25 04:51:43.609844
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa='dict')


# Generated at 2022-06-25 04:51:44.319602
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:51:49.318545
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # default vaules used by the FieldAttribute
    default_values = [
        (FieldAttribute().isa, None),
        (FieldAttribute().private, False),
        (FieldAttribute().required, False),
        (FieldAttribute().listof, None),
        (FieldAttribute().priority, 0),
        (FieldAttribute().class_type, None),
        (FieldAttribute().always_post_validate, False),
        (FieldAttribute().extend, False),
        (FieldAttribute().prepend, False),
        (FieldAttribute().static, False),
    ]

    for (actual, expected) in default_values:
        assert actual == expected



# Generated at 2022-06-25 04:51:56.011932
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(required=False)
    field_attribute_2 = FieldAttribute(AlwaysPostValidate=False)
    field_attribute_3 = FieldAttribute(Inherit=True)
    field_attribute_4 = FieldAttribute(default='foo')
    field_attribute_5 = FieldAttribute(Alias=None)
    field_attribute_6 = FieldAttribute(Extend=False)
    field_attribute_7 = FieldAttribute(Prepend=False)
    field_attribute_8 = FieldAttribute(Static=False)
    field_attribute_9 = FieldAttribute(isa='bool')
    field_attribute_10 = FieldAttribute(ListOf=None)
    field_attribute_11 = FieldAttribute(ClassType=None)

# Generated at 2022-06-25 04:52:03.180363
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attribute_0 = FieldAttribute(prepend=True)
    assert field_attribute_0.prepend

    field_attribute_1 = FieldAttribute(priority=0)
    assert field_attribute_1.priority == 0

    field_attribute_2 = FieldAttribute(private=True)
    assert field_attribute_2.private

    field_attribute_3 = FieldAttribute(required=True)
    assert field_attribute_3.required

    field_attribute_4 = FieldAttribute(static=True)
    assert field_attribute_4.static

    field_attribute_5 = FieldAttribute(extend=True)
    assert field_attribute_5.extend

    field_attribute_6 = FieldAttribute(default=None)
    assert field_attribute_6.default is None

    field_attribute_7 = FieldAttribute(inherit=True)

# Generated at 2022-06-25 04:52:13.027898
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False


# Generated at 2022-06-25 04:52:22.561986
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    print(field_attribute_0.isa)
    print(field_attribute_0.private)
    print(field_attribute_0.default)
    print(field_attribute_0.required)
    print(field_attribute_0.listof)
    print(field_attribute_0.priority)
    print(field_attribute_0.class_type)
    print(field_attribute_0.always_post_validate)
    print(field_attribute_0.inherit)
    print(field_attribute_0.alias)
