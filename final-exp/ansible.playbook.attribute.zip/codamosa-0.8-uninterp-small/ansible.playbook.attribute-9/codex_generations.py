

# Generated at 2022-06-25 04:42:31.738648
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'rjxpyvr'
    bool_0 = False
    bool_1 = False
    bool_2 = False
    attribute_0 = Attribute(str_0, bool_0, bool_1, bool_2)
    assert attribute_0.default is False
    assert attribute_0.class_type == None
    assert attribute_0.static is False
    assert attribute_0.prepend is False
    assert attribute_0.alias == None
    assert attribute_0.private is False
    assert attribute_0.required is False
    assert attribute_0.extend is False
    assert attribute_0.inherit is True
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.always_post_validate is False

# Generated at 2022-06-25 04:42:38.537650
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'u'
    bool_0 = False
    attribute_0 = Attribute(bool_0, bool_0, str_0)
    fieldAttribute = FieldAttribute(bool_0, bool_0, str_0)
    attribute_0 = fieldAttribute.__init__(bool_0, bool_0, str_0)


# Generated at 2022-06-25 04:42:40.272509
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    #assert field_attribute_0.__class__.__name__ == 'FieldAttribute'


# Generated at 2022-06-25 04:42:46.715260
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute.__name__ == 'FieldAttribute'
    assert FieldAttribute.__doc__ == 'Placeholder docstring until code is written'
    assert FieldAttribute.__module__ == 'ansible.module_utils.common.collections'


# Generated at 2022-06-25 04:42:57.425423
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    attr_0 = attribute_0.isa
    attr_1 = attribute_0.required
    attr_2 = attribute_0.extend
    attr_3 = attribute_0.prepend
    attr_4 = attribute_0.priority
    attr_5 = attribute_0.extend
    attr_6 = attribute_0.listof
    attr_7 = attribute_0.isa
    attr_8 = attribute_0.default
    attr_9 = attribute_0.extend
    attr_10 = attribute_0.static
    attr_11 = attribute_0.static
    attr_12 = attribute_0.static

# Generated at 2022-06-25 04:43:04.453331
# Unit test for constructor of class Attribute
def test_Attribute():
    # Declare the object to be tested.
    attribute_0 = Attribute()
    # Test the constructor.
    assert attribute_0 is not None
    # Test the object / class for equality.
    # Test for attribute existance.
    assert attribute_0.isa is not None
    assert attribute_0.private is not None
    assert attribute_0.default is not None
    assert attribute_0.required is not None
    assert attribute_0.listof is not None
    assert attribute_0.priority is not None
    assert attribute_0.class_type is not None
    assert attribute_0.always_post_validate is not None
    assert attribute_0.inherit is not None
    assert attribute_0.alias is not None
    # Test for attribute type.
    assert type(attribute_0.isa) == type(str())

# Generated at 2022-06-25 04:43:08.032320
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('Creating FieldAttribute')
    attribute_0 = FieldAttribute('reerece')
    assert attribute_0.isa == 'reerece'
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False


# Generated at 2022-06-25 04:43:12.051916
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    bool_1 = False
    attribute_0 = FieldAttribute(bool_1, bool_0, bool_0, bool_0, bool_0, bool_1, bool_1, bool_0, bool_0)


# Generated at 2022-06-25 04:43:17.253163
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'frefre'
    bool_0 = False
    attribute_0 = FieldAttribute(required=bool_0, isa=str_0)

if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:25.391730
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    var_0 = FieldAttribute(attribute_0, attribute_0, attribute_0, attribute_0, attribute_0, attribute_0, attribute_0)
    var_1 = FieldAttribute(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    var_2 = FieldAttribute(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 04:43:39.989085
# Unit test for constructor of class Attribute
def test_Attribute():
    #initialize fields
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)

    #test equal method
    assert attribute_0.__eq__() == True

    #test nequal method
    assert attribute_0.__ne__() == False

    #test lt method
    assert attribute_0.__lt__() == True

    #test gt method
    assert attribute_0.__gt__() == False

    #test lte method
    assert attribute_0.__le__() == True

    #test gte method
    assert attribute_0.__ge__() == False

    #test default not mutable attribute
    #attribute_0 = Attribute(bool_0, bool_0, str_0)
    #print(

# Generated at 2022-06-25 04:43:52.131176
# Unit test for constructor of class Attribute
def test_Attribute():

    # following is the constructor of class Attribute
    # def __init__(
    #     self,
    #     isa=None,
    #     private=False,
    #     default=None,
    #     required=False,
    #     listof=None,
    #     priority=0,
    #     class_type=None,
    #     always_post_validate=False,
    #     inherit=True,
    #     alias=None
    # ):

    isa = True
    private = True
    default = True
    required = True
    listof = True
    priority = 0
    class_type = True
    always_post_validate = True
    inherit = True
    alias = None


# Generated at 2022-06-25 04:43:54.837528
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with valid parameters
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    var_0 = FieldAttribute(bool_0, bool_0, bool_0)
    # Test with invalid parameters
    str_1 = 'reerece'
    var_1 = attribute_0.__eq__(str_1)


# Generated at 2022-06-25 04:44:01.479710
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    fieldattribute_0 = FieldAttribute(attribute_0, attribute_0)
    var_0 = fieldattribute_0.__eq__(str_0)



# Generated at 2022-06-25 04:44:02.500613
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-25 04:44:06.257023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    var_0 = attribute_0.__eq__(str_0)
    assert var_0 == False

# Generated at 2022-06-25 04:44:17.189015
# Unit test for constructor of class Attribute
def test_Attribute():
    # Create attributes
    isa = 'fake_type'
    private = 'fake_private'
    default = 'fake_default'
    required = 'fake_required'
    listof = 'fake_listof'
    priority = 'fake_priority'
    class_type = 'fake_class_type'
    always_post_validate = 'fake_always_post_validate'
    inherit = 'fake_inherit'
    alias = 'fake_alias'

    # Instantiate Attribute object
    Attribute_object = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)

    # Check if object's variables are all set
    assert isa == Attribute_object.isa
    assert private == Attribute_object.private
    assert default == Att

# Generated at 2022-06-25 04:44:28.548416
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'vU8WqYB$9&'
    bool_0 = False
    attribute_0 = Attribute(bool_0, bool_0, str_0)
    attribute_1 = FieldAttribute(bool_0, bool_0, str_0)
    if (attribute_1.isa != bool_0) or (attribute_1.private != bool_0) or (attribute_1.default != str_0):
        raise RuntimeError('test error 2')
    if (attribute_0.isa != bool_0) or (attribute_0.private != bool_0) or (attribute_0.default != str_0):
        raise RuntimeError('test error 3')

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:44:29.777704
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test Object Attribute
    test_case_0()



# Generated at 2022-06-25 04:44:33.743742
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'reerece'
    bool_0 = True

    try:
        attribute_0 = FieldAttribute(str_0, bool_0, bool_0)
        result = attribute_0.isa == str_0 and attribute_0.private == bool_0 and attribute_0.default == bool_0
        assert result
    except Exception as error:
        print(error)
        raise AssertionError


# Generated at 2022-06-25 04:44:44.542800
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eerec'
    int_0 = 22
    attribute_0 = Attribute(str_0, str_0, str_0)
    assert attribute_0.isa == 'eerec'
    assert attribute_0.private == 'eerec'
    assert attribute_0.default == 'eerec'
    assert attribute_0.required != True
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate != True
    assert attribute_0.inherit != True
    assert attribute_0.alias is None
    assert attribute_0.extend != True
    assert attribute_0.prepend != True

# Generated at 2022-06-25 04:44:54.339176
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'a'
    str_1 = 'int'
    bool_0 = True
    int_0 = 0
    attribute_0 = Attribute(str_1, bool_0, str_0, bool_0, str_1, int_0)
    assert attribute_0.class_type == None
    assert attribute_0.listof == 'int'
    assert attribute_0.always_post_validate == False
    assert attribute_0.priority == 0
    assert attribute_0.name == None
    assert attribute_0.default == 'a'
    assert attribute_0.required == True
    assert attribute_0.inherit == True
    assert attribute_0.static == False
    assert attribute_0.path == None
    assert attribute_0.extend == False

# Generated at 2022-06-25 04:44:56.565685
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    c_0 = FieldAttribute()




# Generated at 2022-06-25 04:45:05.376347
# Unit test for constructor of class Attribute
def test_Attribute():
    # 11.15.16
    assert Attribute(isa='string', private=True, default=True, required=True).__dict__ == \
        {'listof': None, 'priority': 0, 'class_type': None, 'private': True, 'required': True, 'isa': 'string', 'inherit': True,
         'default': True, 'always_post_validate': False, 'alias': None, 'extend': False, 'prepend': False, 'static': False}
    # 11.15.17

# Generated at 2022-06-25 04:45:13.005386
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    attribute_0.isa = str_0
    attribute_0.private = bool_0
    attribute_0.default = bool_0
    attribute_0.required = bool_0
    attribute_0.listof = str_0
    attribute_0.priority = 0
    attribute_0.class_type = str_0
    attribute_0.always_post_validate = bool_0
    attribute_0.inherit = bool_0
    attribute_0.alias = str_0
    attribute_0.extend = bool_0
    attribute_0.prepend = bool_0
    attribute_0.static = bool_0
    var_0 = attribute_

# Generated at 2022-06-25 04:45:20.290543
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'fir'
    int_0 = 0
    boolean_0 = True
    attr_0 = Attribute(str_0, boolean_0, int_0)
    assert attr_0 == attr_0
    assert attr_0 != None
    assert attr_0 != str_0

    test_case_0()
    testAttribute()


# Generated at 2022-06-25 04:45:28.841155
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'reerece'
    bool_0 = True
    attribute_0 = Attribute(bool_0, bool_0, bool_0)
    var_0 = attribute_0.__eq__(str_0)
    assert var_0 == False, "Expected False, got {}".format(var_0)
    var_1 = attribute_0.__ne__(str_0)
    assert var_1 == True, "Expected True, got {}".format(var_1)
    var_2 = attribute_0.__lt__(str_0)
    assert var_2 == True, "Expected True, got {}".format(var_2)
    var_3 = attribute_0.__gt__(str_0)

# Generated at 2022-06-25 04:45:32.664650
# Unit test for constructor of class Attribute
def test_Attribute():
    class_0 = Attribute()
    print(class_0)
    print(attribute_0)


if __name__ == '__main__':
    #test_case_0()
    test_Attribute()

# Generated at 2022-06-25 04:45:34.444260
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'hello'
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == str_0

# Generated at 2022-06-25 04:45:41.178335
# Unit test for constructor of class Attribute
def test_Attribute():
    # FIXME: I'm not entirely sure why this was added, this is not a valid Attribute
    str_0 = 'hányÁrvíztűrőTűrőKékTuskók'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    assert isinstance(attribute_0, Attribute)

# Generated at 2022-06-25 04:45:45.757939
# Unit test for constructor of class Attribute
def test_Attribute():
    # tests a single attribute
    # new Attribute(isa=None)
    test_case_0()


# Generated at 2022-06-25 04:45:48.557935
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class FieldAttribute
    test_FieldAttribute()

# Generated at 2022-06-25 04:45:49.445265
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:45:51.376888
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'exest'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:46:02.315904
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '**wt#?X_zAO*'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    attribute_1 = FieldAttribute(attribute_0.isa, attribute_0.private, attribute_0.default, attribute_0.required, attribute_0.listof, attribute_0.priority, attribute_0.class_type, attribute_0.always_post_validate, attribute_0.inherit, attribute_0.alias, attribute_0.extend, attribute_0.prepend, attribute_0.static)
    assert attribute_1.default == attribute_0.default
    assert attribute_1.always_post_validate == attribute_0.always_post_validate
    assert attribute_1.listof == attribute_0.listof


# Generated at 2022-06-25 04:46:04.721086
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    assert attribute_0 != None



# Generated at 2022-06-25 04:46:06.500056
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:46:18.196146
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    attribute_1 = FieldAttribute(default=attribute_0, private=bool_0, isa=str_0)
    str_1 = '8ssa0k'
    str_2 = '56vts8'
    str_3 = '0go2u0'
    str_4 = 'q0dmpk'
    int_0 = 4935
    bool_1 = True

# Generated at 2022-06-25 04:46:19.856127
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:46:21.065425
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: implement
    pass


# Generated at 2022-06-25 04:46:30.477819
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Gwo.'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)



# Generated at 2022-06-25 04:46:34.311075
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    (str_0, bool_0) = ('s', True)
    attribute = FieldAttribute(str_0, bool_0, bool_0)
    assert bool_0 == attribute.private == attribute.required
    assert str_0 == attribute.isa


# Generated at 2022-06-25 04:46:37.102189
# Unit test for constructor of class Attribute
def test_Attribute():
    # Basic test
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    # Test the priority of attribute_0
    assert attribute_0.priority == 0


# Generated at 2022-06-25 04:46:39.522289
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Testing FieldAttribute")
    try:
        field_attribute = FieldAttribute('test')
        print(field_attribute)
    except:
        print("Unhandled exception!")
        assert False

if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:46:41.037852
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-25 04:46:41.874813
# Unit test for constructor of class Attribute
def test_Attribute():
    pass


# Generated at 2022-06-25 04:46:46.932807
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    test_case_0()


# Generated at 2022-06-25 04:46:54.950696
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'W8_S+(L=)%I0U_nI4Y;6UH`'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    bool_1 = attribute_0.private
    assert bool_1 == bool_0
    bool_2 = attribute_0.required
    assert bool_2 == bool_0
    str_1 = attribute_0.listof
    assert str_1 == str_0
    int_0 = attribute_0.priority
    assert int_0 == 0
    bool_3 = attribute_0.always_post_validate
    assert bool_3 == bool_0
    bool_4 = attribute_0.inherit
    assert bool_4 == True


# Generated at 2022-06-25 04:46:58.386916
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Tgh9KWd'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    attribute_1 = FieldAttribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:47:05.121945
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'iostr'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0)
    attribute_1 = Attribute(str_0, bool_0, bool_0)
    attribute_2 = Attribute(str_0, bool_0)
    attribute_3 = Attribute(str_0, bool_0, bool_0, bool_0)
    attribute_4 = Attribute(str_0, bool_0, bool_0, bool_0)
    attribute_5 = Attribute(str_0, bool_0, bool_0, bool_0)
    attribute_6 = Attribute(str_0, bool_0, bool_0, bool_0)
    attribute_7 = Attribute(str_0, bool_0, bool_0, bool_0)
   

# Generated at 2022-06-25 04:47:18.842746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'arguments'
    bool_0 = False
    FieldAttribute(str_0, bool_0)


if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:47:22.779470
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attribute_0 = FieldAttribute()
    assert attribute_0.isa == None
    assert not attribute_0.private
    assert attribute_0.default == None
    assert not attribute_0.required
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert not attribute_0.always_post_validate
    assert attribute_0.inherit
    assert attribute_0.alias == None
    assert not attribute_0.extend
    assert not attribute_0.prepend
    assert not attribute_0.static


# Generated at 2022-06-25 04:47:34.654041
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Passed values are of unsupported type
    with pytest.raises(TypeError) as excinfo:
        FieldAttribute(isa=1)
    assert "__init__() keywords must be strings" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        FieldAttribute(private=1)
    assert "__init__() keywords must be strings" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        FieldAttribute(required=1)
    assert "__init__() keywords must be strings" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        FieldAttribute(listof=1)
    assert "__init__() keywords must be strings" in str(excinfo.value)


# Generated at 2022-06-25 04:47:43.476421
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        FieldAttribute()
    with pytest.raises(TypeError):
        FieldAttribute('oe', 'lufzif')
    with pytest.raises(TypeError):
        FieldAttribute('hglx', 'ynjz', 'vzxgtw')
    with pytest.raises(TypeError):
        FieldAttribute('o', 'xjao', 'b', 'sme')
    with pytest.raises(TypeError):
        FieldAttribute('qbqb', 'tvu', 'x', 'y', 'fz')
    with pytest.raises(TypeError):
        FieldAttribute('ul', 'x', 'f', 'k', 'c', 'j')

# Generated at 2022-06-25 04:47:54.477720
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    fieldattribute_0 = FieldAttribute(str_0, bool_0, bool_0)
    fieldattribute_0 = FieldAttribute(str_0, bool_0)
    fieldattribute_0 = FieldAttribute(str_0)
    fieldattribute_1 = FieldAttribute()
    assert fieldattribute_0.isa == 'eoist'
    assert fieldattribute_1.isa == ''
    assert fieldattribute_0.private == False
    assert fieldattribute_1.private == False
    assert fieldattribute_0.default == False
    assert fieldattribute_1.default == None
    assert fieldattribute_0.required == False
    assert fieldattribute_1.required == False
    assert fieldattribute

# Generated at 2022-06-25 04:47:55.414698
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:48:02.488309
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'spc'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    bool_0 = False
    attribute_1 = FieldAttribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:48:04.062156
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:48:14.120740
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test attributes with all valid parameters
    x = Attribute(isa='str', private=True, default='xyz', required=True)
    assert x.isa == 'str'
    assert x.private == True
    assert x.default == 'xyz'
    assert x.required == True

    # Test when the required attribute is not passed
    y = Attribute(isa='str', private=True, default='xyz')
    assert y.required == False

    # Test when isa is list type
    z = Attribute(isa='list', listof='str')
    assert z.isa == 'list'
    assert z.listof == 'str'

    # Test if default is mutable
    a = Attribute(isa='str', default={'abc':'xyz'})

# Generated at 2022-06-25 04:48:17.770245
# Unit test for constructor of class Attribute
def test_Attribute():
    str_2 = 'eoist'
    bool_2 = False
    attribute_1 = Attribute(str_2, bool_2, bool_2)

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:48:53.138128
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'dpaqh'
    str_1 = '!*'
    bool_0 = False
    attribute_0 = Attribute(str_0)
    attribute_1 = Attribute(str_0)
    attribute_2 = Attribute()
    assert attribute_0 is not None
    assert attribute_1 is not None
    assert attribute_2 is not None
    assert attribute_2 != attribute_1 and attribute_0 != attribute_1 and attribute_2 != attribute_0
    #assert attribute_0 == attribute_1 and attribute_1 == attribute_2 and attribute_0 == attribute_2
    #assert attribute_0 != attribute_1 and attribute_1 != attribute_2 and attribute_0 != attribute_2
    assert attribute_0 == attribute_1 and attribute_1 == attribute_2 and attribute_0 == attribute_2

#

# Generated at 2022-06-25 04:49:00.251748
# Unit test for constructor of class Attribute
def test_Attribute():
    #
    # Class Attribute constructor
    #
    # test 1
    str_0 = 'uqiee'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    bool_1 = attribute_0.isa == 'uqiee'
    attribute_0 = Attribute(str_0, bool_0)
    bool_2 = attribute_0.isa == 'uqiee'
    attribute_0 = Attribute(bool_0, bool_0)
    bool_3 = attribute_0.isa is bool
    attribute_0 = Attribute(bool_0)
    bool_4 = attribute_0.isa is bool
    #
    # if self.isa not in ALLOWED_TYPES:
    #
    # test 2
    bool_0

# Generated at 2022-06-25 04:49:10.775545
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Parameters of test case init_0
    str_0 = 'yjvtx'
    bool_0 = False
    bool_1 = True
    attribute_0 = Attribute(str_0, bool_0, bool_1)

    fieldattribute_0 = FieldAttribute(attribute_0)
    assert fieldattribute_0.isa == str_0
    assert fieldattribute_0.private == bool_0
    assert fieldattribute_0.default == bool_1
    assert fieldattribute_0.required == bool_0
    assert fieldattribute_0.listof == None
    assert fieldattribute_0.priority == 0
    assert fieldattribute_0.class_type == None
    assert fieldattribute_0.always_post_validate == False
    assert fieldattribute_0.inherit == True
    assert fieldattribute_0.alias == None


# Generated at 2022-06-25 04:49:20.937093
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default: Attribute()
    # Example: Attribute()
    str_0 = 'curse'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)

    # Default: Attribute(isa='joist', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    # Example: Attribute()
    str_0 = 'joist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0, bool_0, None, 0, None, False, True, None, False, False, False)

# Generated at 2022-06-25 04:49:26.063437
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test = FieldAttribute(isa='boolean')
    assert test.isa == 'boolean'
    assert test.private == False
    assert test.default == None
    assert test.alias == None
    assert test.required == False
    assert test.listof == None
    assert test.priority == 0
    assert test.class_type == None
    assert test.always_post_validate == False
    assert test.inherit == True
    assert test.extend == False
    assert test.prepend == False
    assert test.static == False



# Generated at 2022-06-25 04:49:31.554023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create test case variables
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:49:36.597449
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '*W8hv]{VSbT'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == bool_0



# Generated at 2022-06-25 04:49:46.159574
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'uqdmv'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)
    assert attribute_0.isa == 'uqdmv'
    assert attribute_0.private == False
    assert attribute_0.default == False
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False


# Test that defaults for FieldAttribute may not be mut

# Generated at 2022-06-25 04:49:55.301994
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)
    fieldattribute_1 = FieldAttribute(attribute_0.isa, attribute_0.private, attribute_0.default, attribute_0.required, attribute_0.listof, attribute_0.priority, attribute_0.class_type, attribute_0.always_post_validate, attribute_0.inherit, attribute_0.alias, attribute_0.extend, attribute_0.prepend, attribute_0.static)


# Generated at 2022-06-25 04:49:59.702921
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)



# Generated at 2022-06-25 04:50:58.526425
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'trflkt'
    bool_0 = False
    dict_0 = dict()
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0, bool_0, dict_0)


if __name__ == '__main__':
    import sys
    import unittest

    from . import base

    suite = unittest.TestLoader().loadTestsFromModule(base)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-25 04:51:07.983712
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)

    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == bool_0
    assert attribute_0.required == bool_0
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate == bool_0
    assert attribute_0.inherit == True
    assert attribute_0.alias is None
    assert attribute_0.extend == bool_0
    assert attribute_0.prepend == bool_0
    assert attribute_0.static == bool_0

# Generated at 2022-06-25 04:51:10.886490
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'aysrem'
    bool_1 = True
    str_1 = 'hgglau'
    bool_2 = True
    attribute_0 = FieldAttribute(str_0, bool_1, str_1, bool_2)



# Generated at 2022-06-25 04:51:23.246279
# Unit test for constructor of class Attribute
def test_Attribute():
    # All fields initialized to None
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == None
    assert attribute.default == None
    assert attribute.required == None
    assert attribute.listof == None
    assert attribute.priority == None
    assert attribute.class_type == None
    assert attribute.always_post_validate == None
    assert attribute.inherit == None
    assert attribute.alias == None
    assert attribute.extend == None
    assert attribute.prepend == None
    assert attribute.static == None

    # All fields initialized
    expected_isa = 'eoist'
    expected_private = False
    expected_default = False
    attribute = Attribute(expected_isa, expected_private, expected_default)
    assert attribute.isa == expected_isa
    assert attribute.private == expected_

# Generated at 2022-06-25 04:51:24.716350
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:51:27.278928
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '^p\\[\\]'
    str_1 = 'K2T!_'
    str_2 = 'lJ{rU'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, str_1)


# Generated at 2022-06-25 04:51:31.394781
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'home'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, bool_0)


# Generated at 2022-06-25 04:51:34.890812
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    str_0 = 'eoist'
    bool_0 = False
    attribute_0 = FieldAttribute(str_0, bool_0, bool_0)
    assert attribute_0.isa == 'eoist'
    assert attribute_0.private is False
    assert attribute_0.default is False


# Generated at 2022-06-25 04:51:41.743334
# Unit test for constructor of class Attribute
def test_Attribute():
    params_0 = 'extension'
    bool_0 = False
    attribute_0 = Attribute(params_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert attribute_0.isa == 'extension'
    assert attribute_0.private == False
    assert attribute_0.default == False
    assert attribute_0.required == False
    assert attribute_0.listof == False
    assert attribute_0.priority == 0
    assert attribute_0.class_type == False
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == False
    assert attribute_0.alias == False
    assert attribute_0.extend == False
   

# Generated at 2022-06-25 04:51:43.641421
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_1 = 'inherit'
    bool_1 = False
    attribute_1 = FieldAttribute(str_1, bool_1, bool_1)
