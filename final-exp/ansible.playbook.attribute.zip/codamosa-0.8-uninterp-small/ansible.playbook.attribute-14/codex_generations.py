

# Generated at 2022-06-25 04:42:27.528968
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = FieldAttribute(list_0, set_0)
    assert attribute_0 is not None



# Generated at 2022-06-25 04:42:32.769555
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)
    attribute_1 = FieldAttribute(list_0, set_0)


# Generated at 2022-06-25 04:42:42.522155
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='Isa', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert Attribute()
    assert Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-25 04:42:43.433871
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute is not None


# Generated at 2022-06-25 04:42:51.072319
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)
    str_1 = '\nGaCuq'
    return_value_0 = Attribute(str_1)
    field_attribute_0 = FieldAttribute(return_value_0)
    field_attribute_0 = FieldAttribute(return_value_0)
    field_attribute_0 = FieldAttribute(return_value_0)


# Generated at 2022-06-25 04:43:02.043895
# Unit test for constructor of class Attribute
def test_Attribute():

    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)
    value_0 = str_0
    attribute_0.default = value_0
    value_0 = list_0
    attribute_0.listof = value_0
    value_0 = set_0
    attribute_0.listof = value_0
    value_0 = str_0
    attribute_0.listof = value_0
    value_0 = bool()
    attribute_0.inherit = value_0
    value_0 = list_0
    attribute_0.listof = value_0
    value_0 = list_0
    attribute_0.default = value_

# Generated at 2022-06-25 04:43:06.528814
# Unit test for constructor of class Attribute
def test_Attribute():
    value1 = Attribute()
    value2 = Attribute(isa="list", listof="bool")
    value3 = Attribute(isa="dict", listof="int")
    assert type(value1) == type(value2) == type(value3) == Attribute

# Generated at 2022-06-25 04:43:12.581299
# Unit test for constructor of class Attribute
def test_Attribute():
    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)
    attribute_0 = Attribute(list_0, set_0)
    attribute_0 = Attribute(list_0, set_0)


# Generated at 2022-06-25 04:43:23.078848
# Unit test for constructor of class Attribute
def test_Attribute():
    list_0 = []
    str_0 = '\nGaCuq'
    dict_0 = {}
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)
    attribute_1 = Attribute(always_post_validate=True, listof=dict_0, isa=list_0)
    str_1 = "\n\t (b'D\x06sz\x14\x01\x10\x1b\x1c^\x0f\x04\t\x1c\x0f\x0e\\Og"
    attribute_0 = Attribute(static=str_1)

# Generated at 2022-06-25 04:43:30.412275
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute.__init__.__doc__ == Attribute.__doc__

    list_0 = []
    str_0 = '\nGaCuq'
    set_0 = {list_0, list_0, str_0}
    attribute_0 = Attribute(list_0, set_0)

    assert attribute_0.isa == list_0
    assert attribute_0.private == set_0


# Generated at 2022-06-25 04:43:43.677268
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    field_attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    str_1 = "alias"
    str_2 = "Isa"
    bool_1 = True

# Generated at 2022-06-25 04:43:53.465981
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


if __name__ == '__main__':
    import sys
    import os
    import logging
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')
    logging.info("Testing %s", sys.executable)
    logging.info("Python %s", sys.version)
    print(os.getcwd())

    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:56.624937
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0)

# Generated at 2022-06-25 04:44:01.677096
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:44:03.787144
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:44:11.269106
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:44:18.369087
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert attribute_0 is not None



# Generated at 2022-06-25 04:44:23.131559
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    str_1 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_1, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:44:29.634327
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(attribute_0, Attribute)
    assert isinstance(attribute_0, FieldAttribute)

    assert str(attribute_0) == "<FieldAttribute isa='Isa', private='True', default='Isa', required='True', listof='Isa', priority='True', class_type='Isa', always_post_validate='True', inherit='True', alias='Isa', extend='True', prepend='True', static='True'>"



# Generated at 2022-06-25 04:44:33.403977
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


test_case_0()
test_FieldAttribute()

# Generated at 2022-06-25 04:44:41.085890
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:44:47.342076
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)



if __name__ == '__main__':
    test_FieldAttribute()
    test_case_0()

# Generated at 2022-06-25 04:44:57.594647
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for constructor for class Attribute
    print("Test for constructor for class Attribute")
    test_case_0()

    # Test for __eq__ method for class Attribute
    print("Test for __eq__ method for class Attribute")
    try:
        attribute_0 = Attribute(1)
        attribute_1 = Attribute(1)
        assert attribute_0 == attribute_1
    except:
        assert False

    attribute_2 = Attribute(2)
    assert attribute_0 != attribute_2

    # Test for __lt__ method for class Attribute
    print("Test for __lt__ method for class Attribute")
    try:
        assert attribute_0 < attribute_2
    except:
        assert False

    # Test for __gt__ method for class Attribute

# Generated at 2022-06-25 04:45:06.747226
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    field_attribute_0 = FieldAttribute(str_0, False, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert field_attribute_0.prepend is True
    assert field_attribute_0.static is False
    assert field_attribute_0.extend is False


# Generated at 2022-06-25 04:45:13.455222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        str_0 = 'Isa'
        bool_0 = True
        attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    except:
        exception_flag = 1
    else:
        exception_flag = 0
    if exception_flag:
        return False
    return True

# Generated at 2022-06-25 04:45:19.366570
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:45:28.143993
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    str_1 = 'Isa'
    attribute_0 = Attribute(str_1, bool_0, str_0, bool_0, str_1, bool_0, str_0, bool_0, bool_0, str_1, bool_0, bool_0, bool_0)
    assert attribute_0.default == 'Isa'
    assert attribute_0.private == True
    assert attribute_0.prepend == True
    assert attribute_0.alias == 'Isa'
    assert attribute_0.inherit == False
    assert attribute_0.required == False
    assert attribute_0.static == True
    assert attribute_0.extend == True
    assert attribute_0.listof == 'Isa'
    assert attribute_0.priority == True

# Generated at 2022-06-25 04:45:35.868955
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    str_0 = str()
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_1, str_0, bool_2, str_0, bool_3, bool_4, str_0, bool_5, bool_6, bool_7)



# Generated at 2022-06-25 04:45:38.931543
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert attribute is not None

# Test case for __eq__ method of class Attribute

# Generated at 2022-06-25 04:45:49.777414
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    str_0 = 'Isa'
    bool_0 = True
    str_1 = 'Isa'
    str_2 = 'Isa'
    int_0 = 0
    #str_3 = 'Isa'
    str_3 = AnsibleUnicode('Isa')
    bool_1 = False
    bool_2 = True
    str_4 = 'Isa'
    bool_3 = False
    bool_4 = True
    bool_5 = False
    attribute_0 = Attribute(str_0, bool_0, str_1, bool_1, str_2, int_0, str_3, bool_2, bool_3, str_4, bool_4, bool_5, bool_5)

# Generated at 2022-06-25 04:45:56.212083
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0.isa == None
    if attribute_0.isa == None:
        assert attribute_0.private == False


# Generated at 2022-06-25 04:46:00.703009
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:46:06.321208
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:46:12.857543
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_2 = 'Isa'
    bool_2 = True
    attribute_2 = FieldAttribute(str_2, bool_2, str_2, bool_2, str_2, bool_2, str_2, bool_2, bool_2, str_2, bool_2, bool_2, bool_2)



# Generated at 2022-06-25 04:46:24.050305
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == str_0
    assert attribute_0.required == bool_0
    assert attribute_0.listof == str_0
    assert attribute_0.priority == bool_0
    assert attribute_0.class_type == str_0
    assert attribute_0.always_post_validate == bool_0
    assert attribute_0.inherit == bool_0
    assert attribute_

# Generated at 2022-06-25 04:46:35.790299
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    str_0 = 'Isa'
    int_0 = 0
    boolean_0 = True
    Attribute_0 = Attribute(str_0, boolean_0, str_0, boolean_0, str_0, int_0, str_0, boolean_0, boolean_0, str_0, boolean_0, boolean_0, boolean_0)
    fieldattribute_0 = FieldAttribute(str_0, boolean_0, str_0, boolean_0, str_0, int_0, str_0, boolean_0, boolean_0, str_0, boolean_0, boolean_0, boolean_0)
    boolean_1 = fieldattribute_0 == Attribute_0
    print(boolean_1)
    boolean_2 = fieldattribute_0 != Attribute_0
    print(boolean_2)


test_Field

# Generated at 2022-06-25 04:46:47.361362
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'isa'
    bool_0 = True
    str_1 = 'default'
    bool_1 = True
    str_2 = 'listof'
    bool_2 = True
    str_3 = 'class_type'
    bool_3 = True
    str_4 = 'always_post_validate'
    bool_4 = True
    str_5 = 'inherit'
    bool_5 = True
    str_6 = 'alias'
    bool_6 = True
    str_7 = 'extend'
    bool_7 = True
    str_8 = 'prepend'
    bool_8 = True
    str_9 = 'static'
    attribute_1 = Attribute(str_0)
    attribute_2 = Attribute(str_0, bool_0)
    attribute_3

# Generated at 2022-06-25 04:46:55.350812
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute('Isa', True, 'Isa', True, 'Isa', True, 'Isa', True, True, 'Isa', True, True, True)
    assert(attribute_0.isa == 'Isa')
    assert(attribute_0.private == True)
    assert(attribute_0.default == 'Isa')
    assert(attribute_0.required == True)
    assert(attribute_0.listof == 'Isa')
    assert(attribute_0.priority == True)
    assert(attribute_0.class_type == 'Isa')
    assert(attribute_0.always_post_validate == True)
    assert(attribute_0.inherit == 'Isa')
    assert(attribute_0.alias == True)
    assert(attribute_0.extend == True)
    assert(attribute_0.prepend == True)

# Generated at 2022-06-25 04:47:00.767011
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    str_2 = attribute_0.alias
    str_3 = attribute_0.class_type
    bool_2 = attribute_0.private
    bool_3 = attribute_0.required
    assert str_2 == 'Isa'
    assert str_3 == 'Isa'
    assert bool_2 == bool_0
    assert bool_3 == bool_0
# testing the Attribute class
test_Attribute()

# Generated at 2022-06-25 04:47:07.241720
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:47:14.871704
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        test_case_0()
    except Exception:
        print('Exception raised expected')



# Generated at 2022-06-25 04:47:23.130134
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    assert attribute_0.default == str_0
    assert attribute_0.required == bool_0
    assert attribute_0.listof == str_0
    assert attribute_0.priority == bool_0
    assert attribute_0.class_type == str_0
    assert attribute_0.always_post_validate == bool_0
    assert attribute_0.inherit == bool_0
    assert attribute_

# Generated at 2022-06-25 04:47:31.022871
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_1 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    # Check if 'FieldAttribute.__init__' is implemented correctly.
    assert hasattr(attribute_1, '__init__')


# Generated at 2022-06-25 04:47:35.951410
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:47:39.386249
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0)
    print(fieldattribute_0.alias)
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:47:46.348510
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:47:56.764122
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    # Verify if the value of attribute 'isa' of class Attribute has been set
    str_1 = attribute_0.isa
    assert 'Isa' == str_1
    # Verify if the value of attribute 'private' of class Attribute has been set
    bool_1 = attribute_0.private
    assert True == bool_1
    # Verify if the value of attribute 'default' of class Attribute has been set
    str_2 = attribute_0.default
    assert 'Isa' == str_2
    # Verify if

# Generated at 2022-06-25 04:48:07.691888
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test for constructor of class Attribute
    isa = 'Isa'
    private = True
    default = 'default'
    required = True
    listof = 'listof'
    priority = True
    class_type = 'class_type'
    always_post_validate = True
    inherit = True
    alias = 'alias'
    extend = True
    prepend = True
    static = True
    attribute_1 = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)
    isa = 'Isa'
    private = True
    default = 'default'
    required = True
    listof = 'listof'
    priority = True
    class_type = 'class_type'
    always_post_validate

# Generated at 2022-06-25 04:48:11.877290
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0 is not None
    assert attribute_0.isa is None



# Generated at 2022-06-25 04:48:20.920879
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    fieldattribut_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:48:38.628282
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 04:48:42.076559
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:48:47.955208
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:48:53.151455
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 04:49:03.662959
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert attribute_0.isa == 'Isa'
    assert attribute_0.private == True
    assert attribute_0.default == 'Isa'
    assert attribute_0.required == True
    assert attribute_0.listof == 'Isa'
    assert attribute_0.priority == True
    assert attribute_0.class_type == 'Isa'
    assert attribute_0.always_post_validate == True
    assert attribute_0.inherit == 'Isa'
    assert attribute_0.alias == True

# Generated at 2022-06-25 04:49:08.701224
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = False
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:49:16.051973
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    # Testing if attribute_0 is of type FieldAttribute
    assert isinstance(attribute_0, FieldAttribute)


# Generated at 2022-06-25 04:49:19.776593
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:49:27.163481
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert attribute_0.isa == 'Isa'
    assert attribute_0.private == True
    assert attribute_0.default == 'Isa'
    assert attribute_0.required == True
    assert attribute_0.listof == 'Isa'
    assert attribute_0.priority == True
    assert attribute_0.class_type == 'Isa'
    assert attribute_0.always_post_validate == True
    assert attribute_0.inherit == 'Isa'
    assert attribute_0.alias == True

# Generated at 2022-06-25 04:49:28.745489
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:49:59.115691
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    fieldattribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:50:05.427765
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

    assert str(attribute_0) == 'Attribute(isa=Isa, listof=Isa, class_type=Isa, always_post_validate=True)'

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

    print("Module attribute passed all tests")

# Generated at 2022-06-25 04:50:14.299626
# Unit test for constructor of class Attribute
def test_Attribute():

    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    assert_equal(attribute_0.isa, 'Isa')
    assert_equal(attribute_0.private, True)
    assert_equal(attribute_0.default, 'Isa')
    assert_equal(attribute_0.required, True)
    assert_equal(attribute_0.listof, 'Isa')
    assert_equal(attribute_0.priority, True)
    assert_equal(attribute_0.class_type, 'Isa')

# Generated at 2022-06-25 04:50:21.833859
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

    if (attribute_0.priority == bool_0):
        print("Wrong value: " + str(attribute_0.priority))
        return False

    if (not attribute_0.prepend == bool_0):
        print("Wrong value: " + str(attribute_0.prepend))
        return False
    if (not attribute_0.extend == bool_0):
        print("Wrong value: " + str(attribute_0.extend))
        return False


# Generated at 2022-06-25 04:50:24.223360
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:50:29.590490
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Inputs
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

    # Usage
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

    # Unit test for __eq__
    assert attribute_0.__eq__(attribute_0)

    # Unit test for __ne__
    assert attribute

# Generated at 2022-06-25 04:50:35.179260
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 04:50:41.755827
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    bool_0 = True
    Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:50:46.237731
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:50:52.720446
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 04:52:08.849613
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'Isa'
    str_1 = 'Isa'
    bool_0 = True
    attribute_0 = Attribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)
    attribute_1 = Attribute(isa=str_1, private=bool_0, default=str_1, required=bool_0, listof=str_1, priority=bool_0, class_type=str_1, always_post_validate=bool_0, inherit=bool_0, alias=str_1, extend=bool_0, prepend=bool_0, static=bool_0)

# Generated at 2022-06-25 04:52:15.699153
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Isa'
    bool_0 = True
    attribute_0 = FieldAttribute(str_0, bool_0, str_0, bool_0, str_0, bool_0, str_0, bool_0, bool_0, str_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 04:52:20.716260
# Unit test for constructor of class Attribute
def test_Attribute():
    # Make sure we can successfully create a Attribute object
    attribute = Attribute()
    # Make sure object is of the correct class
    assert(isinstance(attribute, Attribute))
