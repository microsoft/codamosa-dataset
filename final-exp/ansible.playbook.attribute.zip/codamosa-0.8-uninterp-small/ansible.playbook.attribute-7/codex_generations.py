

# Generated at 2022-06-25 04:42:26.770879
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()


# Generated at 2022-06-25 04:42:31.981307
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\x9d'
    bool_0 = False
    set_0 = {bytes_0}
    attribute_0 = Attribute(bool_0, set_0)
    attribute_1 = Attribute(bytes_0, bytes_0, attribute_0)


# Generated at 2022-06-25 04:42:38.274617
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\x9d'
    bool_0 = False
    set_0 = {bytes_0}
    attribute_0 = Attribute(bool_0, set_0)
    attribute_1 = Attribute(bytes_0, bytes_0, attribute_0)


# Generated at 2022-06-25 04:42:46.761554
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bytes_0 = b'\x8e\x0e6U'
    bytes_1 = b'\x9d'
    bytes_2 = b'\n\xb1\x19\xb7\x11\xa6\x9f\xab\xae\x9b\xb8'
    int_0 = -1524631970
    int_1 = -58911036
    int_2 = -1173835688
    str_0 = 'riTWlA'
    str_1 = '\x94\x9f\xbb\xd2\r\xbf/\xc1\xed\x8e\x0e6U\x93\x0b\x8b\x1d\tq\x15'

# Generated at 2022-06-25 04:42:51.194000
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    set_0 = {b'\x9d'}
    attribute_0 = Attribute(False, set_0)
    attribute_1 = Attribute(b'\x9d', b'\x9d', attribute_0)
    var_1 = False
    attribute_2 = FieldAttribute(attribute_1, var_1)



# Generated at 2022-06-25 04:43:02.168188
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.class_type is None
    assert attribute_0.alias is None
    assert attribute_0.static is False
    attribute_1 = Attribute(bytes)
    assert attribute_1.isa == bytes
    assert attribute_1.alias is None
    attribute_2 = Attribute(bytes, always_post_validate=True)
    assert attribute_2.always_post_validate is True
    attribute_4 = Attribute(alias='attribute_0')
    assert attribute_4.alias == 'attribute_0'


# Generated at 2022-06-25 04:43:04.086487
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\x9d'
    bool_0 = False
    set_0 = {bytes_0}
    attribute_0 = Attribute(bool_0, set_0)



# Generated at 2022-06-25 04:43:07.280306
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #
    # Create a new instance of the Attribute class
    #
    attribute_0 = Attribute()
    #
    # Create an instance of the FieldAttribute class
    #
    field_attribute_0 = FieldAttribute(attribute_0, bool_0)


# Generated at 2022-06-25 04:43:08.097261
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:43:18.446096
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    attribute_1 = Attribute(bool_0=False, set_0=set_0)
    assert attribute_1.isa == False
    assert attribute_1.private == set()
    assert attribute_1.default == None
    assert attribute_

# Generated at 2022-06-25 04:43:21.475842
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:43:27.845236
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    attribute_1 = deepcopy(attribute_0)
    assert attribute_1.isa == attribute_0.isa
    assert attribute_1.private == attribute_0.private
    assert attribute_1.default == attribute_0.default
    assert attribute_1.required == attribute_0.required
    assert attribute_1.listof == attribute_0.listof
    assert attribute_1.priority == attribute_0.priority
    assert attribute_1.class_type == attribute_0.class_type
    assert attribute_1.always_post_validate == attribute_0.always_post_validate
    assert attribute_1.inherit == attribute_0.inherit
    assert attribute_1.alias == attribute_0.alias
    assert attribute_1.extend == attribute_0.extend
   

# Generated at 2022-06-25 04:43:40.062066
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    # test default values
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True

    # test custom values
    attr = Attribute(private=True,default=False,required=True,listof="list")
    assert attr.private is True
    assert attr.default is False
    assert attr.required is True
    assert attr.listof == "list"
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.always_post_validate is False

# Generated at 2022-06-25 04:43:41.985131
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    instance = FieldAttribute()
    assert isinstance(instance, FieldAttribute)


# Generated at 2022-06-25 04:43:48.805601
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute()
    test_case_0()


# Test case for constructor of class FieldAttribute:
# parameter isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False

# Generated at 2022-06-25 04:43:49.904598
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0();

if __name__ == '__main__':
    test_FieldAttribute();

# Generated at 2022-06-25 04:43:57.874235
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    if attribute.isa != None:
        raise RuntimeError("FieldAttribute.isa must be None")
    if attribute.private != False:
        raise RuntimeError("FieldAttribute.private must be False")
    if attribute.default != None:
        raise RuntimeError("FieldAttribute.default must be None")
    if attribute.required != False:
        raise RuntimeError("FieldAttribute.required must be False")
    if attribute.listof != None:
        raise RuntimeError("FieldAttribute.listof must be None")
    if attribute.priority != 0:
        raise RuntimeError("FieldAttribute.priority must be zero")
    if attribute.class_type != None:
        raise RuntimeError("FieldAttribute.class_type must be None")

# Generated at 2022-06-25 04:43:58.564442
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:43:59.141643
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:44:03.618498
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list')
    assert attribute.isa == 'list'



# Generated at 2022-06-25 04:44:16.839800
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute()
    # A new attribute must have priority = 0
    assert attribute.priority == 0
    # A new attribute must NOT be private
    assert attribute.private == False
    # A new attribute must NOT have default value
    assert attribute.default is None
    # A new attribute must NOT be required
    assert attribute.required == False
    # A new attribute must NOT have listof
    assert attribute.listof is None
    # A new attribute must NOT have class_type
    assert attribute.class_type is None
    # A new attribute must NOT be always_post_validate
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias is None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False

    attribute = Att

# Generated at 2022-06-25 04:44:24.025070
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(required=False)
    assert attribute_0.private == False
    attribute_1 = FieldAttribute(isa='list')
    attribute_2 = FieldAttribute(isa='dict')
    attribute_3 = FieldAttribute(isa='set')
    attribute_4 = FieldAttribute(isa='string')
    attribute_5 = FieldAttribute(isa='str', alias='foo')
    attribute_6 = FieldAttribute(isa='list', listof='str')
    attribute_7 = FieldAttribute(isa='list', listof='str', alias='foo')
    attribute_8 = FieldAttribute(isa='list', listof='foo', static=False)
    attribute_9 = FieldAttribute(isa='list', listof='foo', static=True)
    attribute_10 = FieldAttribute(isa='list', listof='foo', prepend=False)


# Generated at 2022-06-25 04:44:26.081413
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test a blank instance
    test_case_0()


if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:44:34.383655
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa='dict')
    print("Test Constructor of class FieldAttribute")
    print("Constructor of FieldAttribute test_01: " + str(attribute_1.isa))
    print("Constructor of FieldAttribute test_02: " + str(attribute_1.private))
    print("Constructor of FieldAttribute test_03: " + str(attribute_1.default))
    print("Constructor of FieldAttribute test_04: " + str(attribute_1.required))
    print("Constructor of FieldAttribute test_05: " + str(attribute_1.listof))
    print("Constructor of FieldAttribute test_06: " + str(attribute_1.priority))
    print("Constructor of FieldAttribute test_07: " + str(attribute_1.class_type))

# Generated at 2022-06-25 04:44:35.568753
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 04:44:43.300343
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    assert field_attribute.static is False


# Generated at 2022-06-25 04:44:51.876797
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    0.0  # dummy statement for breakpoint
    attribute_0 = FieldAttribute(
     isa=None,
     private=False,
     default=None,
     required=False,
     listof=None,
     priority=0,
     class_type=None,
     always_post_validate=False,
     inherit=True,
     alias=None,
     extend=False,
     prepend=False,
     static=False,
    )

# Generated at 2022-06-25 04:45:01.154820
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa="string", private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False)
    assert attribute_1.isa == "string"
    assert attribute_1.private ==  True
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.always_post_validate == False

    attribute_2 = FieldAttribute(isa="list", private=True, default=None, required=False, listof="string", priority=0, class_type=None, always_post_validate=False)

# Generated at 2022-06-25 04:45:02.608499
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()



# Generated at 2022-06-25 04:45:09.532693
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    assert attribute_1.isa is None
    assert attribute_1.private is False
    assert attribute_1.default is None
    assert attribute_1.required is False
    assert attribute_1.listof is None
    assert attribute_1.priority == 0
    assert attribute_1.class_type is None
    assert attribute_1.always_post_validate is False
    assert attribute_1.inherit is True
    assert attribute_1.alias is None
    assert attribute_1.extend is False
    assert attribute_1.prepend is False
    assert attribute_1.static is False

# Test for getattr for class Attribute

# Generated at 2022-06-25 04:45:19.517000
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    dl = DataLoader()
    play_source =  dl.load_from_file('foo')
    play = Play().load(play_source[0], play_source[1], dl=dl)
    assert isinstance(play.hosts, str)
    assert isinstance(play.name, str)
    assert isinstance(play.user, str)


# Generated at 2022-06-25 04:45:26.091147
# Unit test for constructor of class Attribute
def test_Attribute():
    """ if the object is created with no arguments, assigning the class
    init variables to  their default values """
    a = Attribute()
    assert a.isa == None
    assert not a.private
    assert a.default == None
    assert not a.required
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert not a.always_post_validate
    assert a.inherit



# Generated at 2022-06-25 04:45:38.601293
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(default='test_value')
    attribute_1 = FieldAttribute(default='test_value')
    # Verify that
    # instance attribute 'default' is equal to parameter 'default'
    assert attribute_0.default == 'test_value'
    # Instance attribute '_inherit' is equal to the defualt value
    assert attribute_0.inherit == True
    # Instance attribute '_always_post_validate' is equal to the default value
    assert attribute_0.always_post_validate == False
    # Instance attribute '_class_type' is equal to the default value
    assert attribute_0.class_type == None
    # Instance attribute '_priority' is equal to the default value
    assert attribute_0.priority == 0
    # Instance attribute '_listof' is

# Generated at 2022-06-25 04:45:40.119370
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute.__init__(Attribute())

# Generated at 2022-06-25 04:45:50.271703
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute_1 = Attribute(isa='dict', default='default', required=True, listof='list', priority=1000, class_type=Attribute,
              always_post_validate=True, inherit=False, alias='alias')

    print("isa=%s" % attribute_1.isa)
    print("default=%s" % attribute_1.default)
    print("required=%s" % attribute_1.required)
    print("listof=%s" % attribute_1.listof)
    print("priority=%s" % attribute_1.priority)
    print("class_type=%s" % attribute_1.class_type)
    print("always_post_validate=%s" % attribute_1.always_post_validate)

# Generated at 2022-06-25 04:45:57.796117
# Unit test for constructor of class Attribute
def test_Attribute():

    #Create an Attribute instance.
    attribute = Attribute()

    #Check if the value of Attribute.isa is None
    assert not attribute.isa

    #Check if the value of Attribute.private is False
    assert not attribute.private

    #Check if the value of Attribute.default is None
    assert not attribute.default

    #Check if the value of Attribute.required is False
    assert not attribute.required

    #Check if the value of Attribute.listof is None
    assert not attribute.listof

    #Check if the value of Attribute.priority is 0
    assert attribute.priority == 0

    #Check if the value of Attribute.class_type is None
    assert not attribute.class_type

    #Check if the value of Attribute.always_post_validate is False
    assert not attribute.always_post_valid

# Generated at 2022-06-25 04:46:07.660561
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attribute.isa == 'str'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == 'str'
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None

# Generated at 2022-06-25 04:46:08.943248
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:46:20.308720
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False

    attribute = Attribute(isa='object', private=True, default=False, required=True, listof=False,
                          priority=10, class_type=Attribute, always_post_validate=True, inherit=False,
                          alias='test', extend=True, prepend=True, static=True)

# Generated at 2022-06-25 04:46:21.895080
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.required is False

# Generated at 2022-06-25 04:46:27.234918
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:46:27.826141
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:46:36.009021
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Test the constructor of class Attribute
    '''
    attribute = Attribute(
        isa="string",
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=None,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attribute.isa == "string", "expected true, got %r" % attribute.isa
    assert attribute.private == False, "expected False, got %r" % attribute.private
    assert attribute.default == None, "expected None, got %r" % attribute.default
    assert attribute.required == False, "expected False, got %r" % attribute.required

# Generated at 2022-06-25 04:46:40.648936
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', default=dict, required=True, listof='string')
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True
    assert attr.listof == 'string'



# Generated at 2022-06-25 04:46:45.925678
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0 is not None

    attribute_1 = Attribute()
    assert attribute_1 is not None

    assert attribute_0.private == attribute_1.private
    assert attribute_0.required == attribute_1.required
    assert attribute_0.priority == attribute_1.priority


# Generated at 2022-06-25 04:46:47.035471
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:46:52.267762
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test normal constructor
    attribute_0 = Attribute(
        default=None,
        alias=None,
        required=False,
        listof=None,
        class_type=None,
        always_post_validate=False,
        isa='dict',
        private=False,
        inherit=True,
        static=False,
        priority=0,
        extend=False,
        prepend=False
    )
    assert attribute_0.default == None
    assert attribute_0.alias == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.isa == 'dict'
    assert attribute_0.private == False
    assert attribute_

# Generated at 2022-06-25 04:47:00.111963
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False
    assert attribute_0.static is False


# Generated at 2022-06-25 04:47:10.619578
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    if attribute.isa != None:
        raise Error('Attribute isa test failed')
    if attribute.private != False:
        raise Error('Attribute private test failed')
    if attribute.default != None:
        raise Error('Attribute default test failed')
    if attribute.required != False:
        raise Error('Attribute required test failed')
    if attribute.listof != None:
        raise Error('Attribute listof test failed')
    if attribute.priority != 0:
        raise Error('Attribute priority test failed')
    if attribute.class_type != None:
        raise Error('Attribute class_type test failed')
    if attribute.always_post_validate != False:
        raise Error('Attribute always_post_validate test failed')
    if attribute.inherit != True:
        raise Error('Attribute inherit test failed')

# Generated at 2022-06-25 04:47:15.153240
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:47:25.822655
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
# test_FieldAttribute ends here.


# Generated at 2022-06-25 04:47:29.483547
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test an empty instantiation of Attribute
    attribute_empty = Attribute()
    assert attribute_empty.isa is None

# TODO: Write tests for all of the Attribute options


# Generated at 2022-06-25 04:47:38.323743
# Unit test for constructor of class Attribute
def test_Attribute():
    assert getattr(test_case_0(), 'private') == False
    assert getattr(test_case_0(), 'default') == None
    assert getattr(test_case_0(), 'required') == False
    assert getattr(test_case_0(), 'isa') == None
    assert getattr(test_case_0(), 'listof') == None
    assert getattr(test_case_0(), 'priority') == 0
    assert getattr(test_case_0(), 'class_type') == None
    assert getattr(test_case_0(), 'always_post_validate') == False
    assert getattr(test_case_0(), 'inherit') == True


# Generated at 2022-06-25 04:47:45.483165
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    print(attribute_0)

    attribute_0 = FieldAttribute(isa='str', private=True, default='True', required=True, listof='str', priority=1, class_type=None, always_post_validate=True, inherit=True, alias='str', extend=True, prepend=True, static=True)
    print(attribute_0)

    attribute_0 = FieldAttribute()
    print(attribute_0)

    attribute_0 = FieldAttribute(isa='str', private=True, default='True', required=True, listof='str', priority=1, class_type=None, always_post_validate=True, inherit=True, alias='str', extend=True, prepend=True, static=True)
    print(attribute_0)

test_FieldAttribute()

# Generated at 2022-06-25 04:47:54.153531
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False



# Generated at 2022-06-25 04:47:58.745778
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa='dict')
    attribute_1 = Attribute(isa='str')
    attribute_2 = Attribute(isa='str', default='foo')
    assert attribute_0.isa == 'dict'
    assert attribute_1.isa == 'str'
    assert attribute_2.isa == 'str'
    assert attribute_2.default == 'foo'


# Generated at 2022-06-25 04:48:05.000369
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # This is a test case to verify the constructor of class FieldAttribute
    '''
    try:
        attribute_0 = FieldAttribute(exception=KeyError)
        print("Unit Test Failed\n")
    except Exception:
        print("Unit Test Passed\n")
    '''
    try:
        attribute_0 = FieldAttribute(listof=int)
        print("Unit Test Failed\n")
    except Exception:
        print("Unit Test Passed\n")
    try:
        attribute_0 = FieldAttribute(class_type=int)
        print("Unit Test Failed\n")
    except Exception:
        print("Unit Test Passed\n")
    try:
        attribute_0 = FieldAttribute(extend=True)
        print("Unit Test Failed\n")
    except Exception:
        print("Unit Test Passed\n")
   

# Generated at 2022-06-25 04:48:06.686013
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa='class')


# Generated at 2022-06-25 04:48:13.925354
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    attribute_2 = Attribute(isa='str', private=True, default='test attribute', required=True, listof='boolean', priority=100, class_type='int', always_post_validate=True, inherit=False, alias='test alias')
    assert str(attribute_1) == str(attribute_2)


# Generated at 2022-06-25 04:48:19.146258
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattr = FieldAttribute()
    assert fieldattr.isa is None
    assert fieldattr.private is False
    assert fieldattr.default is None
    assert fieldattr.required is False
    assert fieldattr.listof is None
    assert fieldattr.priority == 0
    assert fieldattr.class_type is None
    assert fieldattr.always_post_validate is False
    assert fieldattr.inherit is True
    assert fieldattr.alias is None
    assert fieldattr.extend is False
    assert fieldattr.prepend is False
    assert fieldattr.static is False


# Generated at 2022-06-25 04:48:42.817777
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='dict')
    assert Attribute(isa='list')
    assert Attribute(isa='string')
    assert Attribute(isa='number')
    assert Attribute(isa='bool')
    print('Collection of Attribute instances can be constructed')
    # Required is of type boolean
    assert Attribute(required=True)
    assert Attribute(required=False)
    print('Attribute can be required or not')
    # Default value
    assert Attribute(default='foo')
    assert Attribute(default=['foo', 'bar'])
    print('Default data is set')
    # Listof
    assert Attribute(isa='list', listof='string')
    print('Listof data is set')
    # Class type
    assert Attribute(isa='class', class_type='bool')

# Generated at 2022-06-25 04:48:44.032077
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:48:46.505341
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:48:56.225057
# Unit test for constructor of class Attribute
def test_Attribute():
    # test with empty args
    attribute_0 = Attribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False

    # test with non-empty args

# Generated at 2022-06-25 04:49:05.652385
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='some_isa', private=True, default='some_default', required=True, listof='listof', priority=50, class_type='some_class', always_post_validate=True, inherit=True, alias='some_alias')

    assert attr.isa == 'some_isa'
    assert attr.private == True
    assert attr.default == 'some_default'
    assert attr.required == True
    assert attr.listof == 'listof'
    assert attr.priority == 50
    assert attr.class_type == 'some_class'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'some_alias'


# Generated at 2022-06-25 04:49:17.094600
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    This function tests the constructor of class Attribute.
    This function tests the following cases:
        1 - Create Attribute with no parameters
    '''

    # Test case 0: Create Attribute with no parameters
    try:
        Attribute()
    except:
        assert False, 'Creation of Attribute with no parameters failed!'
    assert True

    #Test case 1: Create Attribute with alias
    try:
        Attribute(alias='test')
    except:
        assert False, 'Creation of Attribute with alias failed!'
    assert True

    #Test case 2: Create Attribute with static and static=False
    try:
        Attribute(static=True)
        Attribute(static=False)
    except:
        assert False, 'Creation of Attribute with static failed!'
    assert True

    #Test case 3

# Generated at 2022-06-25 04:49:18.001193
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:49:24.164032
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute1 = FieldAttribute()
    assert attribute1.isa == None
    assert attribute1.private == False
    assert attribute1.default == None
    assert attribute1.required == False
    assert attribute1.listof == None
    assert attribute1.priority == 0
    assert attribute1.class_type == None
    assert attribute1.always_post_validate == False
    assert attribute1.inherit == True
    assert attribute1.alias == None
    assert attribute1.extend == False
    assert attribute1.prepend == False
    assert attribute1.static == False


# Generated at 2022-06-25 04:49:26.981174
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(isa='test_isa', private=True, default=None, required=True, listof=None, priority=False, class_type=None, always_post_validate=True, inherit=False, alias=True, extend=False, prepend=False, static=False)


# Generated at 2022-06-25 04:49:33.019218
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='dict', private=False, default=None, required=False,
                                     listof='str', priority=0, class_type=None, always_post_validate=False,
                                     inherit=True, alias=None, extend=False, prepend=False, static=False)



# Generated at 2022-06-25 04:50:13.999314
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        attribute_3 = FieldAttribute(isa="string")
        assert attribute_3.isa == "string"
    except:
        pass

    try:
        attribute_4 = FieldAttribute(isa="dict")
        assert attribute_4.isa == "dict"
    except:
        pass

    try:
        attribute_5 = FieldAttribute(isa="list")
        assert attribute_5.isa == "list"
    except:
        pass

    try:
        attribute_6 = FieldAttribute(isa="class")
        assert attribute_6.isa == "class"
    except:
        pass

    try:
        attribute_7 = FieldAttribute(isa="percent")
        assert attribute_7.isa == "percent"
    except:
        pass


# Generated at 2022-06-25 04:50:21.738508
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    import sys
    import inspect

    # Find functions whose name begins with "test_"
    test_funcs = [o for o in inspect.getmembers(sys.modules[__name__]) if (inspect.isfunction(o[1]) and o[0].startswith('test_'))]
    for test_func in test_funcs:
        # Execute the test function
        print("Executing test: " + test_func[0])
        test_func[1]()

# Generated at 2022-06-25 04:50:31.976365
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Attribute.isa must be None, str
    attribute_1 = FieldAttribute(isa=None)
    attribute_2 = FieldAttribute(isa="str")
    # Attribute.private must be bool
    attribute_3 = FieldAttribute(private=True)
    # Attribute.required must be bool
    attribute_4 = FieldAttribute(required=False)
    # Attribute.priority must be int
    attribute_5 = FieldAttribute(priority=1)
    # Attribute.class_type must be type
    class_type_1 = "str"
    attribute_6 = FieldAttribute(class_type=class_type_1)
    class_type_2 = type(None)
    attribute_7 = FieldAttribute(class_type=class_type_2)

test_FieldAttribute()

# Generated at 2022-06-25 04:50:43.220078
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Constructor with no parameter
    test_case_0 = FieldAttribute()

    assert isinstance(test_case_0, Attribute)
    assert test_case_0.isa == None
    assert test_case_0.private == False
    assert test_case_0.default == None
    assert test_case_0.required == False
    assert test_case_0.listof == None
    assert test_case_0.priority == 0
    assert test_case_0.class_type == None
    assert test_case_0.always_post_validate == False
    assert test_case_0.inherit == True
    assert test_case_0.alias == None

    # Constructor with full parameterization

# Generated at 2022-06-25 04:50:44.717299
# Unit test for constructor of class Attribute
def test_Attribute():
    required_attribute = Attribute(True)
    optional_attribute = Attribute(False)


# Generated at 2022-06-25 04:50:45.832505
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0 is not None


# Generated at 2022-06-25 04:50:52.367289
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    test_case_0()


if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:50:59.386419
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    assert field_attribute.static is False

# Generated at 2022-06-25 04:51:01.924405
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa='list')
    assert attribute_1.isa == 'list'


# Generated at 2022-06-25 04:51:09.691826
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    assert attribute_1.isa == None
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.inherit == True
    assert attribute_1.alias == None
    assert attribute_1.extend == False
    assert attribute_1.prepend == False
    assert attribute_1.static == False

    attribute_2 = Attribute(isa=dict, default='bogus')
    assert attribute_2.isa == dict
    assert attribute_2.default == 'bogus'

    attribute_3 = Attribute(extend=True)

# Generated at 2022-06-25 04:52:24.821159
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(
        isa='string', default=None, inherit=False, listof=None, required=False,
        priority=0, private=False, class_type=None, always_post_validate=False,
        alias=None, extend=False, prepend=False, static=False,
    )
    attribute_1 = Attribute(
        isa='string', default=None, inherit=False, listof=None, required=False,
        priority=0, private=False, class_type=None, always_post_validate=False,
        alias=None, extend=False, prepend=False, static=False,
    )
    attribute_2 = copy(attribute_1)
    attribute_3 = deepcopy(attribute_1)