

# Generated at 2022-06-25 04:42:34.255714
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test implementation of __lt__ method
    int_0 = -77
    list_0 = ['\xb1\xd8\x1a', '\x9a\x9e\xfb', '\xb1\xd8\x1a\x8e\x07\x82\x07\x9e\xa4\xfc\x06\x18\x1e\x04\xbe\x06\x90\x9a\xe3']
    dict_0 = {'\x9a': '\x9a', '\xb1\xd8\x1a\x8e\x07\x82\x07\x9e\xa4\xfc\x06\x18\x1e\x04\xbe\x06\x90\x9a\xe3': list_0}

# Generated at 2022-06-25 04:42:38.274463
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '\\nyi>8~Uly'
    bytes_0 = b'\xd1\xb2:`(X\x95<\xf9o\x15\x98\x03'
    attribute_0 = Attribute(bytes_0)



# Generated at 2022-06-25 04:42:44.546248
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert str_0.isalnum()
    assert str_0.isprintable()
    assert str_0.isnumeric()
    str_1 = '\\nyi>8~Uly'
    bytes_0 = b'\xd1\xb2:`(X\x95<\xf9o\x15\x98\x03'
    attribute_1 = Attribute(bytes_0)
    float_0 = -517.8

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:42:48.641145
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()
    Attribute(isa=None, always_post_validate=False, static=False, inherit=True, extend=False, prepend=False, alias=None, default=None, listof=None, required=False, class_type=None, priority=0, private=False)


# Generated at 2022-06-25 04:42:53.644018
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '\\nyi>8~Uly' # value for attribute 'isa' of class Attribute
    bytes_0 = b'\xd1\xb2:`(X\x95<\xf9o\x15\x98\x03' # value for attribute 'isa' of class Attribute
    return Attribute(bytes_0)

# Generated at 2022-06-25 04:42:55.207478
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = ''
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:43:02.093335
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(None, False, None, False, None, 0, None, False, True, None)
    assert Attribute(None, True, None, False, None, 0, None, False, True, None)
    assert Attribute(None, False, None, False, None, 0, None, False, False, None)
    assert Attribute(None, True, None, True, None, 0, None, False, True, None)
    assert Attribute(None, True, None, True, None, 0, None, False, False, None)



# Generated at 2022-06-25 04:43:07.074554
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:43:18.225944
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '\x7f:)R\xe0\xa6\xac\xed\xd2\x94'
    bytes_0 = b'\xdf\x1fJ\xd5\x99\x90'
    attribute_0 = Attribute(bytes_0)
    attribute_1 = Attribute(bytes_0, static=True)
    attribute_2 = Attribute(bytes_0, static=True)
    attribute_3 = Attribute(bytes_0, static=True)
    attribute_4 = Attribute(bytes_0, static=True)
    attribute_5 = Attribute(bytes_0, static=True)
    attribute_6 = Attribute(bytes_0, static=True)
    attribute_7 = Attribute(bytes_0, static=True)

# Generated at 2022-06-25 04:43:22.924724
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '\x1a'
    float_0 = -58.0
    attribute_0 = FieldAttribute(str_0, float_0)
    assert(attribute_0.private == bool(str_0))


# Generated at 2022-06-25 04:43:37.481379
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-25 04:43:39.791487
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(FieldAttribute(), FieldAttribute)


# Generated at 2022-06-25 04:43:42.284015
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:43:46.933023
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\xe7\xcak'
    attribute_0 = Attribute(bytes_0)
    assert attribute_0.isa == b'\xe7\xcak'
    assert attribute_0.private == False
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert not isinstance(attribute_0, dict)
    assert not isinstance(attribute_0, list)


# Generated at 2022-06-25 04:43:50.728060
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'-\x95\x80\x8c\x1b:n\x12\x8e\xce\xd9\x9f<'
    bytes_1 = b'\xfd\xf3'
    bytes_2 = b'\xe7\xcak'
    attribute_0 = Attribute(bytes_0, bytes_1, bytes_2)


# Generated at 2022-06-25 04:43:52.955136
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(str)
    assert attribute_0.isa is str
    assert attribute_0.extend is False
    assert attribute_0.private is False



# Generated at 2022-06-25 04:44:03.983141
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bytes_0 = b'\xae\xdc\xdc\x94\xba\x90\x9a\xd6\x9a\x8e\xeb\xfc'
    field_invalid_type_0 = Attribute(bytes_0, True)
    print(field_invalid_type_0.required)
    print(field_invalid_type_0.private)
    name_0 = field_invalid_type_0.required
    print(name_0)
    print(field_invalid_type_0.private)
    path_0 = name_0
    print(path_0)
    field_invalid_type_0 = Attribute(bytes_0, True)
    name_0 = field_invalid_type_0.required
    print(name_0)
   

# Generated at 2022-06-25 04:44:12.153033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # The constructor for FieldAttribute expects zero or more arguments,
    # which can be of type Attribute.
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0._FieldAttribute__attributes == {}

    # The constructor for FieldAttribute expects zero or more arguments,
    # which can be of type Attribute.
    field_attribute_1 = FieldAttribute(Attribute())
    assert field_attribute_1._FieldAttribute__attributes == {}

    return



# Generated at 2022-06-25 04:44:22.321176
# Unit test for constructor of class Attribute
def test_Attribute():

    from collections import OrderedDict

    data = OrderedDict()
    data['isa'] = 'list'
    data['private'] = False
    data['default'] = None
    data['required'] = False
    data['listof'] = 'list'
    data['priority'] = 0
    data['class_type'] = None
    data['always_post_validate'] = False
    data['inherit'] = True
    data['alias'] = None
    data['extend'] = False
    data['prepend'] = False
    data['static'] = False

    Attribute(**data)


if __name__ == '__main__':

    test_Attribute()
    test_case_0()

# Generated at 2022-06-25 04:44:31.694747
# Unit test for constructor of class Attribute
def test_Attribute():
    bytes_0 = b'\xe7\xcak'
    attribute_0 = Attribute(bytes_0)
    assert attribute_0.private == False
    assert attribute_0.static == False
    assert attribute_0.prepend == False
    assert attribute_0.extend == False
    assert attribute_0.default == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.listof == None
    assert attribute_0.required == False
    assert attribute_0.class_type == None
    assert attribute_0.inherit == True
    assert attribute_0.priority == 0
    assert attribute_0.isa == b'\xe7\xcak'
    assert attribute_0.alias == None


# Generated at 2022-06-25 04:44:35.046037
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:44:42.877952
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None and attr.private is False and attr.default is None and attr.required is False and attr.listof is None and attr.priority == 0 and attr.class_type is None and attr.always_post_validate is False and attr.inherit is True and attr.alias is None

    attr_1 = Attribute(isa='test', default='test')
    assert attr_1.isa == 'test' and attr_1.default == 'test'

    attr_2 = Attribute(isa='test', static=True)
    assert attr_2.isa == 'test' and attr_2.static is True



# Generated at 2022-06-25 04:44:44.000376
# Unit test for constructor of class Attribute
def test_Attribute():
    # testing default constructor
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:44:54.337757
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa='ansible',
                                       private='private',
                                       default='default',
                                       required=True,
                                       listof='listof',
                                       priority=42,
                                       class_type='class',
                                       always_post_validate=True,
                                       inherit=False,
                                       alias='Alias',
                                       extend=True,
                                       prepend=True,
                                       static=True)

# Generated at 2022-06-25 04:44:59.757804
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field_attribute_0 = FieldAttribute()
        print('FieldAttribute class constructor')
    except NameError:
        print('failed to initialize')
    except:
        print('failed to initialize')

if __name__ == '__main__':
    test_FieldAttribute()
    print("finish")

# Generated at 2022-06-25 04:45:07.792032
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute(isa=['unicode'], private=False, default='abc', required=False, listof=['unicode'], priority=1, class_type=['unicode'], always_post_validate=False, inherit=False, alias=['unicode'], extend=False, prepend=False, static=False)
    assert field_attribute_0.isa is not None
    field_attribute_0.isa = ["unicode"]  # list[unicode]
    assert field_attribute_0.isa == ["unicode"]  # list[unicode]
    assert field_attribute_0.private is not None
    field_attribute_0.private = False  # bool
    assert field_attribute_0.private is False  # bool
    assert field_attribute_0.default is not None
    field_attribute

# Generated at 2022-06-25 04:45:14.232835
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None


# Generated at 2022-06-25 04:45:21.223272
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(alias='alias_0')
    assert field_attribute_1.alias == 'alias_0'
    field_attribute_2 = FieldAttribute(prepend='prepend_0')
    assert field_attribute_2.prepend == 'prepend_0'
    return 0


# Generated at 2022-06-25 04:45:28.969621
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    _field_attribute = FieldAttribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert _field_attribute.isa == None
    assert _field_attribute.private == False
    assert _field_attribute.default == None
    assert _field_attribute.required == False
    assert _field_attribute.listof == None
    assert _field_attribute.priority == 0
    assert _field_attribute.class_type == None
    assert _field_attribute.always_post_validate == False
    assert _field_attribute.inherit == True
    assert _field_attribute.alias == None

# Generated at 2022-06-25 04:45:38.291004
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:45:40.855838
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 04:45:41.689133
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:45:48.706769
# Unit test for constructor of class Attribute
def test_Attribute():

    test_attr_json = dict(
        dict(
            isa=str,
            private=False,
            default="default",
            required=True,
            listof=str,
            priority=1,
            class_type=str,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False,
        )
    )
    test_attr = Attribute(**test_attr_json)
    for attr in test_attr_json:
        if attr == "default":
            assert test_attr_json[attr] == "default"
        else:
            assert test_attr_json[attr] == getattr(test_attr, attr)


# Generated at 2022-06-25 04:45:54.642361
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_0.__init__(isa=None, private=False, default=None,
                               required=False, listof=None, priority=0,
                               class_type=None, always_post_validate=False,
                               inherit=True, alias=None, extend=False,
                               prepend=False)
    field_attribute_1 = FieldAttribute(isa=None, private=False,
                                       default=None, required=False,
                                       listof=None, priority=0,
                                       class_type=None,
                                       always_post_validate=False,
                                       inherit=True, alias=None, extend=False,
                                       prepend=False)

# Generated at 2022-06-25 04:46:04.393215
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:46:10.347850
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_1 = FieldAttribute()
    assert isinstance(field_attribute_1, FieldAttribute)
    assert field_attribute_1.inherit
    assert field_attribute_1.isa is None
    assert field_attribute_1.private is False
    assert field_attribute_1.default is None
    assert field_attribute_1.required is False
    assert field_attribute_1.listof is None
    assert field_attribute_1.priority == 0
    assert field_attribute_1.always_post_validate is False
    assert field_attribute_1.alias is None
    assert field_attribute_1.extend is False
    assert field_attribute_1.prepend is False
    assert field_attribute_1.static is False


# Generated at 2022-06-25 04:46:20.906170
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()


# Unit tests for method __str__
# Starting with Python 3.0, the repr() of a class instance returns
# something like <__main__.A instance at 0xb7db732c>.  Since this is
# sobering for those who liked the pre-3.0 repr() output of <A instance>,
# and because those classes are readily instantiated, Python's new
# default repr() of classes is the same as Python 2.6's repr() of classes.
# Before Python 3.0, the repr() of a class instance returns
# something like <A instance at 0xb7db732c>.
# The reprlib module provides a version of repr() customized for
# abbreviated displays of large or deeply nested containers:

# Generated at 2022-06-25 04:46:26.736642
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        field_attribute_0 = Attribute()
        field_attribute_1 = Attribute(isa='test_isa', private=True, default='test_default', required=True, listof='test_listof', priority=1, class_type='test_class_type',
                                      always_post_validate=True, inherit=True, alias='test_alias')
    except Exception as e:
        print(e)

# Test for equality of class Attribute

# Generated at 2022-06-25 04:46:36.219667
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_test = Attribute()
    assert attribute_test.isa == None, "isa not set to None"
    assert attribute_test.private == False, "private not set to False"
    assert attribute_test.default == None, "default not set to None"
    assert attribute_test.required == False, "required not set to False"
    assert attribute_test.listof == None, "listof not set to None"
    assert attribute_test.priority == 0, "priority not set to 0"
    assert attribute_test.class_type == None, "class_type not set to None"
    assert attribute_test.always_post_validate == False, "always_post_validate not set to False"
    assert attribute_test.inherit == True, "inherit not set to True"

# Generated at 2022-06-25 04:46:40.125429
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for __init__
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0 is not None


if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:46:51.459048
# Unit test for constructor of class Attribute
def test_Attribute():
    assert hasattr(Attribute, '__init__')
    assert hasattr(Attribute, '__eq__')
    assert hasattr(Attribute, '__ne__')
    assert hasattr(Attribute, '__lt__')
    assert hasattr(Attribute, '__gt__')
    assert hasattr(Attribute, '__le__')
    assert hasattr(Attribute, '__ge__')
    assert callable(Attribute.__init__)
    assert callable(Attribute.__eq__)
    assert callable(Attribute.__ne__)
    assert callable(Attribute.__lt__)
    assert callable(Attribute.__gt__)
    assert callable(Attribute.__le__)
    assert callable(Attribute.__ge__)


# Generated at 2022-06-25 04:46:52.237202
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()



# Generated at 2022-06-25 04:46:59.535620
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.default is None
    assert field_attribute_0.alias is None
    assert not field_attribute_0.extend
    assert not field_attribute_0.inherit
    assert field_attribute_0.isa is None
    assert field_attribute_0.listof is None
    assert not field_attribute_0.prepend
    assert field_attribute_0.priority == 0
    assert not field_attribute_0.private
    assert not field_attribute_0.required
    assert not field_attribute_0.static

# Generated at 2022-06-25 04:47:10.595308
# Unit test for constructor of class Attribute
def test_Attribute():
    """Test class Attribute constructor"""
    attr1 = Attribute()
    attr2 = Attribute(isa=int, default=1234, required=True, listof=float, priority=1, class_type=list)
    attr3 = Attribute(alias=FieldAttribute(isa='list'))
    assert attr1.isa == attr2.isa == attr3.isa == None
    assert attr1.default == attr2.default == attr3.default == None
    assert attr1.required == attr2.required == attr3.required == False
    assert attr1.listof == attr2.listof == attr3.listof == None
    assert attr1.priority == attr2.priority == attr3.priority == 0
    assert attr1.class_type == attr

# Generated at 2022-06-25 04:47:19.353770
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute()
    field_attribute.isa = "dict"
    field_attribute.private = True
    field_attribute.default = "mydefault"
    field_attribute.required = True
    field_attribute.listof = "list"
    field_attribute.priority = 10
    field_attribute.class_type = "dict"
    field_attribute.always_post_validate = False
    field_attribute.inherit = True
    field_attribute.alias = "myalias"

    assert field_attribute.isa == "dict"
    assert field_attribute.private == True
    assert field_attribute.default == "mydefault"
    assert field_attribute.required == True
    assert field_attribute.listof == "list"
    assert field_attribute.priority == 10

# Generated at 2022-06-25 04:47:22.999259
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_1 = FieldAttribute()
    field_attribute_1.isa = 'str'
    field_attribute_1.private = False
    field_attribute_1.default = None
    field_attribute_1.required = False
    field_attribute_1.listof = None
    field_attribute_1.priority = 0
    field_attribute_1.class_type = None
    field_attribute_1.always_post_validate = False
    field_attribute_1.inherit = True
    field_attribute_1.alias = None
    field_attribute_1.extend = False
    field_attribute_1.prepend = False
    field_attribute_1.static = False



# Generated at 2022-06-25 04:47:32.763269
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # this will fail without passing isa argument:
    # AttributeError: __init__() missing 1 required positional argument: 'isa'
    field_attribute_1 = FieldAttribute(isa='str')
    assert field_attribute_1.isa == 'str'
    # this fails because default is mutable:
    # TypeError: defaults for FieldAttribute may not be mutable
    field_attribute_2 = FieldAttribute(isa='list', default=['test'])
    # but this works:
    field_attribute_3 = FieldAttribute(isa='list', default=lambda: ['test'])
    assert field_attribute_3.default() == ['test']



# Generated at 2022-06-25 04:47:34.569063
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print()
    test_case_0()
    print("Unit test for FieldAttribute is done")



# Generated at 2022-06-25 04:47:37.698236
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('Testing class FieldAttribute...')
    test_FieldAttribute_constructor()
    print ('FieldAttribute constructor test passed!')
    print('FieldAttribute class tests passed!')


# Generated at 2022-06-25 04:47:38.975896
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr_0 = FieldAttribute()
    assert attr_0


# Generated at 2022-06-25 04:47:51.796170
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa="String")
    field_attribute_2 = FieldAttribute(isa="String",
                               private=False,
                               default=None,
                               required=False,
                               listof=None,
                               priority=0,
                               class_type=None,
                               always_post_validate=False,
                               inherit=True,
                               alias=None,
                               extend=False,
                               prepend=False,
                               static=False,
                               )

test_Attribute()

# Generated at 2022-06-25 04:47:56.203503
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(
        default=1,
        listof=1,
        private=True,
        class_type=object,
        required=False,
        isa='string'
    )



# Generated at 2022-06-25 04:48:07.638046
# Unit test for constructor of class Attribute
def test_Attribute():
    # test passing all parameters
    field_attribute = FieldAttribute(isa='str',
                                     private=False,
                                     default=True,
                                     required=True,
                                     listof=True,
                                     priority=0,
                                     class_type=True,
                                     always_post_validate=True,
                                     inherit=True,
                                     alias=True)
    # test passing only required parameters, default values should be set
    field_attribute = FieldAttribute(isa='str')

    # test passing only optional parameters
    # TypeError should be raised because isa is required

# Generated at 2022-06-25 04:48:10.933319
# Unit test for constructor of class Attribute
def test_Attribute():
    assert isinstance(Attribute(), Attribute)

# Unit tests for properties of class Attribute

# Generated at 2022-06-25 04:48:22.004632
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_1 = FieldAttribute(isa="str")
    field_attribute_2 = FieldAttribute(isa="int")
    field_attribute_3 = FieldAttribute(isa="bool")
    field_attribute_4 = FieldAttribute(isa="dict")
    field_attribute_5 = FieldAttribute(isa="list")
    field_attribute_6 = FieldAttribute(isa="set")
    field_attribute_7 = FieldAttribute(isa="dict")
    field_attribute_8 = FieldAttribute(isa="list")
    field_attribute_9 = FieldAttribute(isa="set")
    #self.assertIsInstance(field_attribute, basestring)
    #self.assertIsInstance(field_attribute, basestring)
    #self.assertIsInstance(field_attribute, basestring)
    #

# Generated at 2022-06-25 04:48:23.857296
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert isinstance(field_attribute_0, FieldAttribute)


# Generated at 2022-06-25 04:48:30.251863
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa == None
    assert field_attribute_0.private == False
    assert field_attribute_0.default == None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias == None


# Generated at 2022-06-25 04:48:35.481101
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None


# =====

# Generated at 2022-06-25 04:48:40.297578
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import types
    field_attribute_0 = FieldAttribute()

    assert isinstance(field_attribute_0, Attribute)
    assert isinstance(field_attribute_0.isa, str)
    assert isinstance(field_attribute_0.private, bool)
    assert field_attribute_0.default is None

    assert isinstance(field_attribute_0.required, bool)
    assert isinstance(field_attribute_0.listof, str)
    assert isinstance(field_attribute_0.priority, int)
    assert isinstance(field_attribute_0.class_type, type)
    assert isinstance(field_attribute_0.always_post_validate, bool)
    assert field_attribute_0.inherit is True
    assert isinstance(field_attribute_0.alias, str)

# Generated at 2022-06-25 04:48:48.516815
# Unit test for constructor of class Attribute
def test_Attribute():
    # Check that isa is a string
    try:
        field_attribute_0 = FieldAttribute(isa=1)
        # assert False
    except:
        assert(True)

    # Check that isa is not a class
    try:
        field_attribute_0 = FieldAttribute(isa=FieldAttribute)
        # assert False
    except:
        assert(True)

    # Check that private is a boolean
    try:
        field_attribute_0 = FieldAttribute(private='true')
        # assert False
    except:
        assert(True)

    # Check that default is a boolean, string or number
    try:
        field_attribute_0 = FieldAttribute(default=[])
        # assert False
    except:
        assert(True)

    # Check that required is a boolean

# Generated at 2022-06-25 04:49:05.295461
# Unit test for constructor of class Attribute
def test_Attribute():

    field_attribute_0 = FieldAttribute()

    field_attribute_1 = FieldAttribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof='dict',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert field_attribute_1.isa == 'list'
    assert field_attribute_1.private == False
    assert field_attribute_1.default == None
    assert field_attribute_1.required == False
    assert field_attribute_1.listof == 'dict'
    assert field_attribute_1.priority == 0

# Generated at 2022-06-25 04:49:06.093539
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:49:07.100097
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    temp1 = FieldAttribute()

    assert temp1 is not None


# Generated at 2022-06-25 04:49:18.729068
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa = 'master_key', private = 'is_private', default = 'def_val', required = 'is_req', listof = 'list_of', priority = 'prio_level', class_type = 'class_type', always_post_validate = 'always_post_validate', inherit = 'inherit', alias = 'alias', extend = 'extend', prepend = 'prepend', static = 'static')

# Generated at 2022-06-25 04:49:23.740354
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa='str',
        private=True,
        default=False,
        required=True,
        listof='str',
        priority=3,
        class_type='str',
        always_post_validate=True,
        inherit=True,
        alias='str',
        extend=True,
        prepend=True,
        static=True,
    )


# Generated at 2022-06-25 04:49:24.502727
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert test_case_0() is None


# Generated at 2022-06-25 04:49:26.241995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = Attribute()
    field_attribute_1 = FieldAttribute()


# Generated at 2022-06-25 04:49:38.919814
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa = 'String', private = True, default = None, required = False, listof = 'String', priority = 1, class_type = None, always_post_validate = False, inherit = True, alias = None, extend = False, prepend = False)
    assert attr.isa == 'String'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'String'
    assert attr.priority == 1
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-25 04:49:40.536884
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        assert FieldAttribute is not None
        test_case_0()
    except AssertionError:
        return False
    return True


# Generated at 2022-06-25 04:49:46.407941
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = Attribute('bool', private=True, default=False, required=True, listof=None,
                                priority=1, class_type=None, always_post_validate=True, inherit=None, alias='foobar')
    assert field_attribute.isa == 'bool'
    assert field_attribute.private == True
    assert field_attribute.default == False
    assert field_attribute.required == True
    assert field_attribute.listof == None
    assert field_attribute.priority == 1
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == True
    assert field_attribute.inherit == None
    assert field_attribute.alias == 'foobar'


# Generated at 2022-06-25 04:50:08.748698
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = "list"
    private = False
    default = ["127.0.0.1"]
    required = True
    listof = "string"
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = True
    static = False
    attribute = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    assert_equals(isa, attribute.isa)
    assert_equals(private, attribute.private)
    assert_equals(required, attribute.required)
    assert_equals(listof, attribute.listof)
    assert_equals(priority, attribute.priority)
    assert_

# Generated at 2022-06-25 04:50:13.505576
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        attribute = Attribute(private=False, listof=None, required=False, isa="string", default=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    except Exception as e:
        print(e)

# Unit tests for methods of class Attribute

# Generated at 2022-06-25 04:50:16.915394
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:50:17.976503
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    print("field_attribute_0 = FieldAttribute()")
    print("field_attribute_0 = ", field_attribute_0)


# Generated at 2022-06-25 04:50:18.760456
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:50:28.608607
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    config_0 = field_attribute_0.config
    assert (config_0 == {})
    parent_0 = field_attribute_0.parent
    assert (parent_0 == None)
    aliases_0 = field_attribute_0.aliases
    assert (aliases_0 == {})
    alias_0 = field_attribute_0.alias
    assert (alias_0 == None)
    isa_0 = field_attribute_0.isa
    assert (isa_0 == None)
    static_0 = field_attribute_0.static
    assert (static_0 == False)
    priority_0 = field_attribute_0.priority
    assert (priority_0 == 0)
    default_0 = field_attribute_0.default
    assert (default_0 == None)
   

# Generated at 2022-06-25 04:50:32.733403
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    ansible_attribute_0 = field_attribute_0
    assert (isinstance(ansible_attribute_0 , Attribute ) )


# test Attribute.__eq__():

# Generated at 2022-06-25 04:50:43.608777
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor with no arguments
    field_attribute = FieldAttribute()

    assert field_attribute.isa == None
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False

    # Constructor with arguments

# Generated at 2022-06-25 04:50:46.905677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute.__init__.__doc__ is not None


# Generated at 2022-06-25 04:50:58.691379
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor
    attribute_0 = Attribute()
    # Check if instance attribute 'isa' is set to None
    assert attribute_0.isa is None
    # Check if instance attribute 'private' is set to False
    assert attribute_0.private is False
    # Check if instance attribute 'default' is set to None
    assert attribute_0.default is None
    # Check if instance attribute 'required' is set to False
    assert attribute_0.required is False
    # Check if instance attribute 'listof' is set to None
    assert attribute_0.listof is None
    # Check if instance attribute 'priority' is set to 0
    assert attribute_0.priority == 0
    # Check if instance attribute 'class_type' is set to None
    assert attribute_0.class_type is None
    # Check if instance attribute 'always_post_

# Generated at 2022-06-25 04:51:28.158101
# Unit test for constructor of class Attribute
def test_Attribute():
    # The default fully-populated attribute
    field_attribute_0 = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof='list',
        priority=0,
        class_type='dict',
        always_post_validate=False,
        inherit=True,
        alias='dict',
        extend=False,
        prepend=False,
        static=False
    )

    # The default unpopulated attribute
    field_attribute_1 = FieldAttribute()

    # Build new dictionary
    new_dict = {}
    # Create a deepcopy of the fully-populated attribute
    new_dict['field_attribute_0'] = deepcopy(field_attribute_0)
    # Create a deepcopy of the empty attribute

# Generated at 2022-06-25 04:51:38.613900
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(isa='what', private=False, default='what', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert field_attribute_0.isa == 'what'
    assert field_attribute_0.private == False
    assert field_attribute_0.default == 'what'
    assert field_attribute_0.required == False
    assert field_attribute_0.listof == None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type == None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias

# Generated at 2022-06-25 04:51:45.107923
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False



# Generated at 2022-06-25 04:51:51.876852
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute = FieldAttribute(listof="foo")
    assert field_attribute.listof == "foo"
    assert field_attribute.inherit



# Generated at 2022-06-25 04:52:00.094635
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(default = {}, isa = "list", required = True, listof = "dict", alias = "field_attribute_alias")
    assert field_attribute.default == {}
    assert field_attribute.isa == "list"
    assert field_attribute.required == True
    assert field_attribute.listof == "dict"
    assert field_attribute.alias == "field_attribute_alias"


# Generated at 2022-06-25 04:52:07.529987
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private is False
    assert field_attribute_0.default is None
    assert field_attribute_0.required is False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate is False
    assert field_attribute_0.inherit is True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend is False
    assert field_attribute_0.prepend is False
    field_attribute_0.prepend = True
    assert field_attribute_0.prepend is True

# Generated at 2022-06-25 04:52:14.616978
# Unit test for constructor of class Attribute
def test_Attribute():
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.isa is None
    assert field_attribute_0.private == False
    assert field_attribute_0.default is None
    assert field_attribute_0.required == False
    assert field_attribute_0.listof is None
    assert field_attribute_0.priority == 0
    assert field_attribute_0.class_type is None
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.alias is None
    assert field_attribute_0.extend == False
    assert field_attribute_0.prepend == False
    assert field_attribute_0.static == False


# Generated at 2022-06-25 04:52:19.803067
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Execute tests
if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:52:29.738388
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute(alias='alias', always_post_validate=False, class_type=None, default='default', extend=False, inherit=True, isa='isa', listof=None, prepend=False, private=False, priority=0, required=False, static=False)
    assert field_attribute_0.alias == 'alias'
    assert field_attribute_0.always_post_validate == False
    assert field_attribute_0.class_type == None
    assert field_attribute_0.default == 'default'
    assert field_attribute_0.extend == False
    assert field_attribute_0.inherit == True
    assert field_attribute_0.isa == 'isa'
    assert field_attribute_0.listof == None
    assert field_attribute_0.prepend == False
