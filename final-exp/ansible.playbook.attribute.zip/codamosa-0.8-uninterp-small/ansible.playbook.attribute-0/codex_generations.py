

# Generated at 2022-06-25 04:42:27.647844
# Unit test for constructor of class Attribute
def test_Attribute():
    # Create a new Attribute object
    # Pass:
    # Return: A new Attribute object
    attribute = Attribute()
    print(attribute)


# Generated at 2022-06-25 04:42:32.311979
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test if argument of Attribute instance is a string or not
    str_1 = '3l!r^L-9gH'
    attribute_1 = Attribute()
    var_1 = attribute_1.__ge__(str_1)
    var_1 = attribute_1.__ge__(str_1)

    str_2 = 'L#uyc%?2[s/'
    attribute_2 = Attribute()
    var_2 = attribute_2.__ge__(str_2)
    var_2 = attribute_2.__ge__(str_2)

    str_3 = '=2@Y<Bb:S|>8w'
    attribute_3 = Attribute()
    var_3 = attribute_3.__ne__(str_3)
    var_3 = attribute_3.__

# Generated at 2022-06-25 04:42:42.492029
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    # ctor() -> default constructor
    attribute_0 = FieldAttribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False
    # ctor(isa) -> constructor with isa parameter
    attribute_1 = FieldAttribute

# Generated at 2022-06-25 04:42:53.283366
# Unit test for constructor of class Attribute
def test_Attribute():
    test_Attribute_0()
    test_Attribute_1()
    test_Attribute_2()
    test_Attribute_3()
    test_Attribute_4()
    test_Attribute_5()
    test_Attribute_6()
    test_Attribute_7()
    test_Attribute_8()
    test_Attribute_9()
    test_Attribute_10()
    test_Attribute_11()
    test_Attribute_12()
    test_Attribute_13()
    test_Attribute_14()
    test_Attribute_15()
    test_Attribute_16()
    test_Attribute_17()
    test_Attribute_18()
    test_Attribute_19()
    test_Attribute_20()
    test_Attribute_21()
    test_Attribute_22()
    test_Attribute_23()
    test_Attribute_24()

# Generated at 2022-06-25 04:42:55.278174
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)


# Generated at 2022-06-25 04:43:04.596374
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    str_1 = '3l!r^L-9gH'
    attribute_0 = Attribute(str_0, str_0, str_0, str_0, str_0)
    assert str_0 == attribute_0.isa
    assert str_0 == attribute_0.private
    assert str_0 == attribute_0.default
    attribute_1 = FieldAttribute(str_0, str_1, str_1, str_1, str_1)
    assert str_0 == attribute_1.isa
    assert str_1 == attribute_1.private
    assert str_1 == attribute_1.default
    assert str_1 == attribute_1.required
    assert str_1 == attribute_1.listof
    assert str_1 == attribute_

# Generated at 2022-06-25 04:43:12.033086
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(listof='5hYJ*HfcyA')
    assert attribute_0.listof == '5hYJ*HfcyA'
    assert attribute_0.private == False
    assert attribute_0.required == False
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False
    assert attribute_0.priority == 0
    attribute_1 = Attribute(class_type='jL6$?^x;wa', default='test_value_1', isa='test_value_2', static=True)
    assert attribute_1.class_type == 'jL6$?^x;wa'
   

# Generated at 2022-06-25 04:43:17.560535
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = ':(v26_e*2Q'
    bool_0 = True
    list_0 = [str_0]
    attribute_0 = FieldAttribute(list_0, private=bool_0)
    attribute_0.__ge__('*xU:e*1N*')


# Generated at 2022-06-25 04:43:25.613720
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '\x05\r\r\r\r-\x0c\x0f\x1d\x12\x0c\x02\x1e\x12\x1c\x10\x01\x16\x1f\x18\x1d\x1a\x1a\x0f\x04\x1f\x0c\x0e\x1f\x1e\x0c\x07\x10\x08\x1d\x0b\x0e\x1d\x0f\x19\x1c\x07\x0f\x11\x1b\x02\x12\r\r\r\r'

# Generated at 2022-06-25 04:43:30.259028
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    fieldattribute_0 = FieldAttribute(isa=str_0)
    assert fieldattribute_0.isa == str_0


# Generated at 2022-06-25 04:43:34.725290
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def test_0(str):
        pass  # Placeholder for call to constructor
    # Assign parameter to assignable reference
    str = str_0
    # Call to constructor
    assert test_0(str)


# Generated at 2022-06-25 04:43:45.314211
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa="bool", private=True, default=False,
        required=True, listof=None, priority=10, class_type=None,
        always_post_validate=False, inherit=True, alias='attrs')

    # Test attribute 'isa' using getter
    assert a.isa == 'bool'

    # Test attribute 'isa' using setter
    a.isa = 'list'
    assert a.isa == 'list'

    # Test attribute 'private' using getter
    assert a.private == True

    # Test attribute 'private' using setter
    a.private = False
    assert a.private == False

    # Test attribute 'default' using getter
    assert a.default == False

    # Test attribute 'default' using setter
    a.default = True

# Generated at 2022-06-25 04:43:56.998524
# Unit test for constructor of class Attribute
def test_Attribute():
    class_0 = Attribute()
    class_1 = Attribute(isa = 'isa', class_type = 'class_type', prepend = True, default = 'default', always_post_validate = True, priority = 3513, alias = 'alias', required = True, private = True, listof = 'listof', static = True, extend = True, inherit = True, )
    assert class_1.isa == 'isa'
    assert class_1.class_type == 'class_type'
    assert class_1.prepend == True
    assert class_1.default == 'default'
    assert class_1.always_post_validate == True
    assert class_1.priority == 3513
    assert class_1.alias == 'alias'
    assert class_1.required == True
    assert class_1.private == True
   

# Generated at 2022-06-25 04:43:58.771515
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()



# Generated at 2022-06-25 04:44:01.053179
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test class instantiation
    obj = Attribute()

    # Test __eq__()
    param_0 = obj == None


# Generated at 2022-06-25 04:44:06.615587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    ca = FieldAttribute(isa='foo', private=False, default='test', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert isinstance(ca, FieldAttribute)
    assert isinstance(ca, Attribute)


# Generated at 2022-06-25 04:44:17.437825
# Unit test for constructor of class Attribute
def test_Attribute():
    # test signature 0
    args_0 = {}
    a_0 = Attribute(**args_0)
    assert isinstance(a_0, Attribute)
    assert a_0.private is False
    assert a_0.priority == 0
    assert a_0.extend is False
    assert a_0.inherit is True
    assert a_0.prepend is False
    assert a_0.listof is None
    assert a_0.class_type is None
    assert a_0.required is False
    assert a_0.always_post_validate is False
    assert a_0.isa is None
    assert a_0.static is False
    assert a_0.default is None
    assert a_0.alias is None

    args_1 = {}

# Generated at 2022-06-25 04:44:28.892213
# Unit test for constructor of class Attribute
def test_Attribute():
    # Possible types for class Attribute
    attr_type = ['list', 'dict', 'set']
    isa = attr_type[0]
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None

    # Calling constructor
    obj = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    print(obj.isa)
    print(obj.private)
    print(obj.default)
    print(obj.required)
    print(obj.listof)
    print(obj.priority)
    print(obj.class_type)

# Generated at 2022-06-25 04:44:35.788076
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '\x05\r\r\r\r-\x0c\x0f\x1d\x12\x0c\x02\x1e\x12\x1c\x10\x01\x16\x1f\x18\x1d\x1a\x1a\x0f\x04\x1f\x0c\x0e\x1f\x1e\x0c\x07\x10\x08\x1d\x0b\x0e\x1d\x0f\x19\x1c\x07\x0f\x11\x1b\x02\x12\r\r\r\r'
    test_Attr_0 = Attribute()

# Generated at 2022-06-25 04:44:44.222095
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test class FieldAttribute without params 
    obj = FieldAttribute()
    assert obj.isa is None
    assert obj.private == False
    assert obj.default is None
    assert obj.required == False
    assert obj.listof is None
    assert obj.priority == 0
    assert obj.class_type is None
    assert obj.always_post_validate == False
    assert obj.inherit == True
    assert obj.alias is None
    assert obj.extend == False
    assert obj.prepend == False
    assert obj.static == False
    # Test class FieldAttribute with params 

# Generated at 2022-06-25 04:44:47.259505
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'gl:l!R^i_eH'
    attribute_0 = Attribute(prepend=True, listof=str_0, class_type='Q6;')

# Generated at 2022-06-25 04:44:57.564517
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = 0
    str_0 = 'c%>0=EVOuV7'
    attribute_0 = Attribute()
    attribute_1 = FieldAttribute()
    attribute_2 = FieldAttribute(
        always_post_validate=attribute_0.required,
        isa=None,
        default=None,
        required=attribute_1.private,
        listof=None,
        priority=attribute_0.priority,
        class_type=None,
        alias=None,
        inherit=attribute_1.inherit,
        extend=attribute_0.always_post_validate,
        prepend=attribute_1.extend,
        static=attribute_1.prepend,
        private=False)

# Generated at 2022-06-25 04:45:01.140803
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    str_1 = '3l!r^L-9gH'
    attribute_0 = Attribute(str_0, True, str_1)
    field_attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:45:02.996658
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_attribute = FieldAttribute()
    assert str_attribute.__class__.__name__ == 'FieldAttribute'



# Generated at 2022-06-25 04:45:05.303808
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_1 = '|f;IVI$;=M'
    attribute_1 = FieldAttribute()
    var_1 = attribute_1.__ge__(str_1)


# Generated at 2022-06-25 04:45:12.941289
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import random
    from itertools import product
    from ansible.utils.color import ANSIBLE_COLOR, colorize, hostcolor
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.basic import AnsibleModule

    def test_1():
        str_0 = '3l!r^L-9gH'
        test_case_1_1 = Attribute(
            private=True,
            alias='attr_0',
            default=None,
            required=True,
            always_post_validate=True,
            inherit=False,
            extend=False,
            prepend=False,
            static=False
        )

# Generated at 2022-06-25 04:45:17.333510
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'nI7+Gp!-F&'
    attribute_0 = FieldAttribute()
    var_0 = attribute_0.__ge__(str_0)



# Generated at 2022-06-25 04:45:21.728416
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert True


# Generated at 2022-06-25 04:45:22.059917
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-25 04:45:28.470969
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    assert 'isa' in attribute_1.__dict__
    assert 'private' in attribute_1.__dict__
    assert 'default' in attribute_1.__dict__
    assert 'required' in attribute_1.__dict__
    assert 'listof' in attribute_1.__dict__
    assert 'priority' in attribute_1.__dict__
    assert 'class_type' in attribute_1.__dict__
    assert 'always_post_validate' in attribute_1.__dict__
    assert 'inherit' in attribute_1.__dict__
    assert 'alias' in attribute_1.__dict__
    assert 'extend' in attribute_1.__dict__
    assert 'prepend' in attribute_1.__dict__

# Generated at 2022-06-25 04:45:32.992696
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute()
    print('Successfully created an instance of FieldAttribute')

# Generated at 2022-06-25 04:45:45.552239
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    dict_0 = dict()
    dict_0['isa'] = str_0
    dict_0['private'] = False
    dict_0['default'] = None
    dict_0['required'] = True
    dict_0['listof'] = str_0
    dict_0['priority'] = 0
    dict_0['class_type'] = None
    dict_0['always_post_validate'] = False
    dict_0['inherit'] = True
    dict_0['alias'] = str_0
    dict_0['extend'] = True
    dict_0['prepend'] = True
    dict_0['static'] = True
    attribute_0 = Attribute(**dict_0)
    var_0 = attribute_0.isa


# Generated at 2022-06-25 04:45:53.743711
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        str_0 = 'j'
        attribute_0 = FieldAttribute(
            class_type=str_0,
            # static=True, # TODO: static is not supported right now
            inherit=False,
            prepend=False,
            alias='ansible.module_utils.six.print_function',
            required=False,
            default=None,
            always_post_validate=True,
            extend=False,
            private=True,
            isa='bool',
            listof=False,
            priority=0
        )
        var_0 = attribute_0.__ne__('Hb3q')
        print('Test cases for FieldAttribute passed successfully.')
    except Exception as e:
        err_msg = 'Exception encountered during test case for FieldAttribute.py constructor. Exception: {0}'

# Generated at 2022-06-25 04:45:55.614094
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor of FieldAttribute
    newFieldAttribute = FieldAttribute('String', True, 'code', True, 'code', 0, 'code', True)


# Generated at 2022-06-25 04:46:05.109365
# Unit test for constructor of class Attribute
def test_Attribute():
    obj_0 = Attribute(isa=None, required=False, default=None, class_type=None, inherit=True, priority=0, alias=None, prepend=False, extend=False, always_post_validate=False, static=False, listof=None, private=False)
    assert obj_0.isa == None
    assert obj_0.required == False
    assert obj_0.default == None
    assert obj_0.class_type == None
    assert obj_0.inherit == True
    assert obj_0.priority == 0
    assert obj_0.alias == None
    assert obj_0.prepend == False
    assert obj_0.extend == False
    assert obj_0.always_post_validate == False
    assert obj_0.static == False
    assert obj_0.listof

# Generated at 2022-06-25 04:46:07.531302
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute(isa=str_0)
    var_0 = attribute_0.__ge__(str_0)

if __name__ == "__main__":
    test_Attribute()
    test_case_0()

# Generated at 2022-06-25 04:46:18.396657
# Unit test for constructor of class Attribute
def test_Attribute():
    print('Testing constructor of class Attribute')
    str_1 = 'We&p>l=,'
    attribute_1 = Attribute(str_1)
    print(attribute_1.isa)
    assert attribute_1.isa == str_1
    int_0 = 17
    attribute_2 = Attribute(str_1,int_0)
    assert attribute_2.isa == str_1
    assert attribute_2.private == int_0
    print(attribute_2.isa)
    print(attribute_2.private)
    int_1 = 23
    attribute_3 = Attribute(str_1,int_0,int_1)
    assert attribute_3.isa == str_1
    assert attribute_3.private == int_0
    assert attribute_3.default == int_1

# Generated at 2022-06-25 04:46:26.503104
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'r@J$]|'
    str_1 = 'V?#tm'
    str_2 = 'W1N<9E'
    str_3 = '|/6U'
    attribute_0 = FieldAttribute(str_0, str_1, str_2, str_3)
    str_4 = 'V?#tm'
    str_5 = 'W1N<9E'
    str_6 = '|/6U'
    attribute_1 = FieldAttribute(str_4, str_5, str_6)

# Generated at 2022-06-25 04:46:29.499305
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'gYpL-&{'
    attribute_0 = Attribute(isa='string', listof=str_0)

# Generated at 2022-06-25 04:46:37.727830
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test 1: no exception should be thrown
    try:
        FieldAttribute(isa=int, class_type=str, extend=True, prepend=True)
    except TypeError:
        assert False

    # Test 2: no exception should be thrown
    try:
        FieldAttribute(isa=int, class_type=str, extend=False, prepend=False)
    except TypeError:
        assert False

    # Test 3: no exception should be thrown
    try:
        FieldAttribute(isa=int, class_type=str, extend=True, prepend=True, static=True)
    except TypeError:
        assert False

    # Test 4: no exception should be thrown

# Generated at 2022-06-25 04:46:52.747069
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with no args
    attribute_0 = Attribute()
    print(attribute_0.isa)
    print(attribute_0.private)
    print(attribute_0.default)
    print(attribute_0.required)
    print(attribute_0.listof)
    print(attribute_0.priority)
    print(attribute_0.class_type)
    print(attribute_0.always_post_validate)
    print(attribute_0.inherit)
    print(attribute_0.alias)
    print(attribute_0.extend)
    print(attribute_0.prepend)
    print(attribute_0.static)
    # Test with args

# Generated at 2022-06-25 04:46:57.981477
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list', private=True, default='foo', required=True, listof='dictionary', priority=4,
                          class_type='bar', always_post_validate=True, inherit=False, alias='baz', extend=True,
                          prepend=True, static=True)
    assert isinstance(attribute, Attribute)



# Generated at 2022-06-25 04:46:59.789260
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'W&9XZv!_F6'
    attribute_0 = Attribute()
    assert attribute_0


# Generated at 2022-06-25 04:47:10.597473
# Unit test for constructor of class Attribute

# Generated at 2022-06-25 04:47:15.830444
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'U77x.x'
    attribute_0 = Attribute(private=True, isa=str_0)
    assert attribute_0.private == True
    assert attribute_0.isa == str_0


# Generated at 2022-06-25 04:47:23.709124
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute(str_0)
    var_0 = attribute_0.inherit
    var_1 = attribute_0.isa
    var_2 = attribute_0.listof
    var_3 = attribute_0.class_type
    var_4 = attribute_0.always_post_validate
    var_5 = attribute_0.alias
    var_6 = attribute_0.extend
    var_7 = attribute_0.prepend
    var_8 = attribute_0.static
    var_9 = attribute_0.__ge__(str_0)
    var_10 = attribute_0.__eq__(str_0)
    var_11 = attribute_0.__ne__(str_0)
    var_

# Generated at 2022-06-25 04:47:27.770088
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print ("test_FieldAttribute")
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)

# Generated at 2022-06-25 04:47:28.869668
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()


# Generated at 2022-06-25 04:47:32.548888
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert(True)

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:47:38.324305
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    FieldAttribute(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)


if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:47:48.668487
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    str_1 = 'NOw0K}_0M'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)


# Generated at 2022-06-25 04:47:58.637847
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()

    # Unit test for __eq__ method of class Attribute
    var_0 = attribute_0.__eq__(str_0)

    # Unit test for __ne__ method of class Attribute
    var_1 = attribute_0.__ne__(str_0)

    # Unit test for __lt__ method of class Attribute
    var_2 = attribute_0.__lt__(str_0)

    # Unit test for __gt__ method of class Attribute
    var_3 = attribute_0.__gt__(str_0)

    # Unit test for __le__ method of class Attribute
    var_4 = attribute_0.__le__(str_0)

    # Unit test for __ge__ method of class Att

# Generated at 2022-06-25 04:47:59.432925
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()


# Generated at 2022-06-25 04:48:01.972128
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa='3l!r^L-9gH')
    assert attribute_1 is not None
# TEST CASES


# main()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:48:09.962916
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '0iA4B?&:3#'
    str_1 = 'pzdL#R$x=0'
    str_2 = 'D'
    attribute_0 = Attribute()
    assert attribute_0.__ge__(str_0)
    assert attribute_0.__ge__(str_1)
    assert attribute_0.__ge__(str_2)


# Generated at 2022-06-25 04:48:12.101952
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '4Ft(n:V7N`'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)


# Generated at 2022-06-25 04:48:18.956409
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()
    attribute_0.__ge__(str_0)

if __name__ == '__main__':
    #test_FieldAttribute()

    from timeit import Timer
    t1 = Timer("test_FieldAttribute()", "from __main__ import test_FieldAttribute")
    print("test_FieldAttribute", t1.timeit(1000))

# Generated at 2022-06-25 04:48:28.286287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'c-m'
    attribute_0 = Attribute()
    var_0 = attribute_0.__le__(str_0)
    str_1 = '}'
    attribute_1 = Attribute()
    var_1 = attribute_1.__lt__(str_1)
    str_2 = '@R8G'
    attribute_2 = Attribute()
    var_2 = attribute_2.__lt__(str_2)
    str_3 = 'l)'
    attribute_3 = Attribute()
    var_3 = attribute_3.__ne__(str_3)
    str_4 = '9'
    attribute_4 = Attribute()
    var_4 = attribute_4.__eq__(str_4)
    str_5 = 'yD'
    attribute_5

# Generated at 2022-06-25 04:48:32.046486
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)


# Generated at 2022-06-25 04:48:40.166059
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute._isa == 'str'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-25 04:48:58.608851
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_FieldAttribute_0()
    test_FieldAttribute_1()
    test_FieldAttribute_2()
    test_FieldAttribute_3()
    test_FieldAttribute_4()
    test_FieldAttribute_5()
    test_FieldAttribute_6()
    test_FieldAttribute_7()
    test_FieldAttribute_8()
    test_FieldAttribute_9()
    test_FieldAttribute_10()
    test_FieldAttribute_11()
    test_FieldAttribute_12()
    test_FieldAttribute_13()
    test_FieldAttribute_14()
    test_FieldAttribute_15()
    test_FieldAttribute_16()
    test_FieldAttribute_17()
    test_FieldAttribute_18()
    test_FieldAttribute_19()
    test_FieldAttribute_20()
    test_FieldAttribute_21()
   

# Generated at 2022-06-25 04:49:10.357907
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()
    attribute_1 = Attribute(isa='Yyk@j;M')
    attribute_2 = Attribute(isa='N9X,{A')
    attribute_3 = Attribute(class_type=str)
    attribute_4 = Attribute(class_type=str, isa='6vm2TZ')
    attribute_5 = Attribute(isa='Z7gCd')
    attribute_6 = FieldAttribute()
    attribute_7 = FieldAttribute(isa='9X1xD')
    attribute_8 = FieldAttribute(isa='~QF(Oq6U')
    attribute_9 = FieldAttribute(class_type='3l!r^L-9gH')

# Generated at 2022-06-25 04:49:20.896119
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # init with default
    var_0 = FieldAttribute()
    assert not var_0.private
    assert var_0.default is None
    assert not var_0.required
    assert var_0.listof is None
    assert var_0.priority == 0
    assert var_0.class_type is None
    assert not var_0.always_post_validate
    assert var_0.inherit
    assert var_0.alias is None
    assert not var_0.extend
    # init with values
    var_0 = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, \
                class_type=None, always_post_validate=False)
    assert not var_0.private
    assert var_0.default is None
    assert not var_0

# Generated at 2022-06-25 04:49:27.700452
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa=object(), private=False, default=int(), required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    print(attribute.isa)
    print(attribute.private)
    print(attribute.default)
    print(attribute.required)
    print(attribute.listof)
    print(attribute.priority)
    print(attribute.class_type)
    print(attribute.always_post_validate)
    print(attribute.inherit)
    print(attribute.alias)
    print(attribute.extend)
    print(attribute.prepend)
    print(attribute.static)


# Generated at 2022-06-25 04:49:31.375862
# Unit test for constructor of class Attribute
def test_Attribute():

    print("Doing test_Attribute")
    attribute = Attribute('Test')
    assert(attribute.isa == 'Test')


# Generated at 2022-06-25 04:49:35.239293
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'E7X_x]x\'=I|$e>t'
    attribute_0 = Attribute()
    var_0 = attribute_0.__lt__(str_0)


# Generated at 2022-06-25 04:49:36.034326
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:49:41.225055
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = '3l!r^L-9gH'
    var_0 = FieldAttribute(isa)
    assert var_0.isa == '3l!r^L-9gH'


CONFIGURABLE_ATTRIBUTES = frozenset((
    'isa',
    'private',
    'default',
    'required',
    'listof',
    'priority',
    'class_type',
    'always_post_validate',
    'inherit',
    'alias',
    'extend',
    'prepend',
    'static',
))



# Generated at 2022-06-25 04:49:51.838003
# Unit test for constructor of class Attribute
def test_Attribute(): 
    # INITIALIZATION
    var_0 = Attribute()
    var_0 = Attribute()
    var_1 = var_0.__ge__(var_0)
    var_2 = var_0.__le__(var_0)
    var_3 = var_0.__lt__(var_0)
    var_4 = var_0.__gt__(var_0)
    var_5 = var_0.__ne__(var_0)
    var_6 = var_0.__eq__(var_0)
    # assert(var_1.__dict__ == var_0.__dict__) # assert does not work for comparing dict, as order can change 
    assert(var_2.__dict__ == var_0.__dict__)

# Generated at 2022-06-25 04:49:53.923810
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'Xy2QV7_!*DnH'
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(str_0)



# Generated at 2022-06-25 04:50:28.534624
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = FieldAttribute()
    var_0 = attribute_0.__ge__(str_0)
    var_1 = attribute_0.__ge__(attribute_0)
    var_2 = attribute_0.__gt__(attribute_0)
    var_3 = attribute_0.__gt__(str_0)
    var_4 = attribute_0.__lt__(attribute_0)
    var_5 = attribute_0.__lt__(str_0)


# Generated at 2022-06-25 04:50:33.097825
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    assert str(field_attribute_0) == "Attribute(default=None, required=False, inherit=True, static=False, private=False, prepend=False, extend=False, class_type=None)"


# Generated at 2022-06-25 04:50:36.263784
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute.__init__(
            isa=str,
            private=False,
            default=None,
            required=True,
            listof=None,
            priority=0,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False,
        )


# Generated at 2022-06-25 04:50:47.140831
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for appropriate type of attribute isa
    attribute_0 = Attribute()
    # Test for appropriate type of attribute private
    attribute_0 = Attribute()
    # Test for inappropriate type of attribute private
    #attribute_0 = Attribute(private='g!')
    # Test for appropriate type of attribute default
    attribute_0 = Attribute()
    # Test for appropriate type of attribute required
    attribute_0 = Attribute()
    # Test for appropriate type of attribute listof
    attribute_0 = Attribute()
    # Test for appropriate type of attribute priority
    attribute_0 = Attribute()
    # Test for appropriate type of attribute class_type
    attribute_0 = Attribute()
    # Test for appropriate type of attribute always_post_validate
    attribute_0 = Attribute()
    # Test for appropriate type of attribute inherit
    attribute_

# Generated at 2022-06-25 04:50:50.930586
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='str')
    assert(attribute.isa == 'str')


# Generated at 2022-06-25 04:50:59.849695
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    var_0 = attribute_0.__ge__(list)
    var_1 = attribute_0.__ne__(list)
    var_2 = attribute_0.__ne__(dict)
    var_3 = attribute_0.__ne__(set)
    var_4 = attribute_0.__ne__(list)
    var_5 = attribute_0.__ne__(dict)
    var_6 = attribute_0.__ne__(set)
    var_7 = attribute_0.__ne__(list)
    var_8 = attribute_0.__ne__(dict)
    var_9 = attribute_0.__ne__(set)
    var_10 = attribute_0.__ge__(list)

# Generated at 2022-06-25 04:51:02.951137
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = '3l!r^L-9gH'
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:51:05.128657
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    int_0 = Attribute()
    field_attribute_0 = FieldAttribute()
    assert field_attribute_0.__ge__(int_0) is False


# Generated at 2022-06-25 04:51:07.760655
# Unit test for constructor of class Attribute
def test_Attribute():
    default_0 = Attribute(isa='dict', default='default_0', static=True)
    empty_0_dict = {}
    static_0 = Attribute(isa='dict', static=True)
    static_0_dict = static_0.default()
    if static_0_dict is not static_0.default():
        raise ValueError('Incorrect object returned - test_Attribute')


# Generated at 2022-06-25 04:51:10.856023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'xE@R?w-1LF'
    attribute_0 = FieldAttribute(str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private is False
    assert attribute_0.default is None


# Generated at 2022-06-25 04:52:10.439525
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'list'
    attribute_0 = Attribute(str_0, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 04:52:11.675813
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:52:15.400272
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'list'
    attribute_0 = Attribute(str_0, str_0, str_0, str_0, str_0, str_0)



# Generated at 2022-06-25 04:52:23.438514
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'list'
    attribute_0 = Attribute(str_0, str_0, str_0, str_0, str_0, str_0)
    str_1 = 'dict'
    attribute_1 = Attribute(str_1, str_1, str_1, str_1, str_1, str_1)
    attribute_2 = Attribute(attribute_1, attribute_0, attribute_0, attribute_1, attribute_0, attribute_1)

    assert True