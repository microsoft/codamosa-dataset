

# Generated at 2022-06-25 04:42:32.338768
# Unit test for constructor of class Attribute
def test_Attribute():
    # args: isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias
    attribute_0 = Attribute(isa=None, private=None, default=None, required=None, listof=None, priority=None, class_type=None, always_post_validate=None, inherit=None, alias=None)
    try:
        assert attribute_0
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 04:42:37.458525
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'g'
    bool_0 = False
    bool_1 = False
    attribute_0 = Attribute(str_0, bool_0, bool_1)
    attribute_0.isa = 'mpdehaan'


# Generated at 2022-06-25 04:42:39.145261
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = True
    attribute_0 = Attribute(bool_0)


# Generated at 2022-06-25 04:42:41.237778
# Unit test for constructor of class Attribute
def test_Attribute():
    print()
    test_case_0()

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:42:43.228337
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        test_case_0()
    except Exception as e:
        print("An exception was raised during its execution: " + str(e))



# Generated at 2022-06-25 04:42:46.043681
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = True
    attribute_0 = Attribute(bool_0)
    assert attribute_0 is not None


# Generated at 2022-06-25 04:42:47.915390
# Unit test for constructor of class Attribute
def test_Attribute():
    bool_0 = True
    attribute_0 = Attribute(bool_0)


# Generated at 2022-06-25 04:42:51.999349
# Unit test for constructor of class Attribute
def test_Attribute():
    post_validate_0 = Attribute(isa=None, static=False)
    assert post_validate_0 is not None
    attribute_0 = Attribute(bool_0)
    assert attribute_0 is not None
    assert attribute_0.isa is not None
    test_case_0()


# Generated at 2022-06-25 04:43:02.789957
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    bool_0 = False
    bool_1 = True
    boolean_0 = [None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, bool_1]
    boolean_1 = [None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, bool_0]
    attribute_0 = FieldAttribute(boolean_0)
    boolean_

# Generated at 2022-06-25 04:43:04.503515
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:43:10.825340
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        test_case_0()
        # Successful test_case_0
    except Exception:
        print("Failed test_case_0")

if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:12.459095
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    print(field)


# Generated at 2022-06-25 04:43:15.162025
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_object = FieldAttribute('bin/ansible-doc')


# Generated at 2022-06-25 04:43:19.740169
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute('int', True, 'test_var_0', False, 'test_var_1', 'test_var_2', 'test_var_3', True, 'test_var_4', 'test_var_5', 'test_var_6', 'test_var_7', 'test_var_8')


# Generated at 2022-06-25 04:43:22.083638
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute
    assert type(attribute) == type
    assert isinstance(attribute, type)


# Generated at 2022-06-25 04:43:25.922255
# Unit test for constructor of class Attribute
def test_Attribute():
    var_0 = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )



# Generated at 2022-06-25 04:43:29.492995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    if var_0 is not None:
        print(var_0)
        print()
    return True

# Function of unit test

# Generated at 2022-06-25 04:43:41.561564
# Unit test for constructor of class Attribute
def test_Attribute():
    print("Testing Attribute")
    print()

    # test with empty Arguments
    print("Test case 0")
    try:
        test_case_0()
    except Exception as e:
        print("Exception caught:", e)
    print()

    # test with isa = list
    print("Test case 1")
    var_1 = Attribute(isa='list')
    print("Result obtained: ", var_1)
    print("Expected result: Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)")
    print()

    # test with isa = dict
    print("Test case 2")
    var_2 = Att

# Generated at 2022-06-25 04:43:53.011218
# Unit test for constructor of class Attribute
def test_Attribute():
    # Check if the default constructor works correct
    var_1 = Attribute()

    # Check if the constructor with these parameters works correct
    var_2 = Attribute(
        isa="list",
        private=False,
        default=None,
        required=False,
        listof="set",
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )

    # Check if the constructor with these parameters works correct

# Generated at 2022-06-25 04:44:04.009895
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Testing for object creation
    var_0 = print()

    # Test for multiple object creation
    var_1 = print()

    # Test for both object creation and multiple object creation
    var_2 = print()

    # Testing for object creation
    var_3 = print()

    # Test for multiple object creation
    var_4 = print()

    # Test for both object creation and multiple object creation
    var_5 = print()

    # Testing for object creation
    var_6 = print()

    # Test for multiple object creation
    var_7 = print()

    # Test for both object creation and multiple object creation
    var_8 = print()

    # Testing for object creation
    var_9 = print()

    # Test for multiple object creation
    var_10 = print()

    # Test for both object creation and multiple object creation
    var_

# Generated at 2022-06-25 04:44:16.806195
# Unit test for constructor of class Attribute
def test_Attribute():
    # str
    var_1 = Attribute('str')
    assert var_1.isa == 'str'
    assert var_1.private == False
    assert var_1.default == None
    assert var_1.required == False
    assert var_1.listof == None
    assert var_1.priority == 0
    assert var_1.class_type == None
    assert var_1.always_post_validate == False
    assert var_1.inherit == True
    assert var_1.alias == None
    assert var_1.extend == False
    assert var_1.prepend == False
    assert var_1.static == False
    # int
    var_2 = Attribute(1)
    assert var_2.isa == 1
    assert var_2.private == False
    assert var_2

# Generated at 2022-06-25 04:44:25.436047
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert var_1.isa==None
    assert var_1.private==False
    assert var_1.default==None
    assert var_1.required==False
    assert var_1.listof==None
    assert var_1.priority==0
    assert var_1.class_type==None
    assert var_1.always_post_validate==False
    assert var_1.inherit==True
    assert var_1.alias==None
    assert var_1.extend==False
    assert var_1.prepend

# Generated at 2022-06-25 04:44:33.951714
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=bool,
                  private = False,
                  default = None,
                  required = False,
                  listof = None,
                  priority = 0,
                  class_type = None,
                  always_post_validate = False,
                  inherit = True,
                  alias = None,
                  extend = False,
                  prepend = False,
                  static = False)

# Generated at 2022-06-25 04:44:42.346862
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor test
    var_0 = Attribute()
    # Constructor with explicit default value test
    var_1 = Attribute(isa="", private=None, default="", required=None, listof=None, priority=None, class_type=None, always_post_validate=None, inherit=None, alias=None, extend=None, prepend=None, static=None)
    # Constructor with explicit value test
    var_2 = Attribute(isa="dnsname", private=None, default="dnsname", required=None, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)


# Generated at 2022-06-25 04:44:44.410763
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Constructor test: Construct a new `Attribute` class
    """
    # Construct a new `Attribute` class
    var_1 = Attribute()


# Generated at 2022-06-25 04:44:50.585423
# Unit test for constructor of class Attribute
def test_Attribute():
    var1 = Attribute()
    assert var1.isa == None
    assert var1.listof == None
    assert var1.default == None
    assert var1.private == False
    assert var1.alias == None
    assert var1.extend == False
    assert var1.prepend == False
    assert var1.static == False
    assert var1.required == False
    assert var1.priority == 0
    assert var1.class_type == None
    assert var1.always_post_validate == False
    assert var1.inherit == True

    # test mutable objects as defaults
    try:
        var2 = Attribute(default={})
    except TypeError:
        pass
    else:
        assert False, "should have raised TypeError"

    var3 = Attribute(default=lambda: {})

# Generated at 2022-06-25 04:44:51.634248
# Unit test for constructor of class Attribute
def test_Attribute():
    var_0 = Attribute()


# Generated at 2022-06-25 04:44:55.579033
# Unit test for constructor of class Attribute
def test_Attribute():
    f = Attribute(isa=int,
                  private=True,
                  default=2,
                  required=True,
                  listof=int,
                  priority=0,
                  class_type=int,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False,)


# Generated at 2022-06-25 04:44:58.539383
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute("dict", private=True)
    var_2 = print("dict")
    var_3 = print("private=True")



# Generated at 2022-06-25 04:44:59.488891
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    return True

# Generated at 2022-06-25 04:45:02.508748
# Unit test for constructor of class Attribute
def test_Attribute():
    var_0 = Attribute()


# Generated at 2022-06-25 04:45:03.970054
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute()
    assert var_1
    print(var_1)


# Generated at 2022-06-25 04:45:08.102379
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', required=True, listof='string', priority=1,
                  inherit=True, extend=False, prepend=False)
    assert a.isa == 'string' and a.required == True and a.listof == 'string' and a.priority == 1 \
    and a.inherit == True and a.extend == False and a.prepend == False


# Generated at 2022-06-25 04:45:09.215077
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute()
    assert var_1


# Generated at 2022-06-25 04:45:13.099692
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test case for default constructor
    var_1 = FieldAttribute()
    # Test case for constructor with arguments
    var_2 = FieldAttribute(isa="isa", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)



# Generated at 2022-06-25 04:45:14.223257
# Unit test for constructor of class Attribute
def test_Attribute():
    testAttribute = Attribute()

    assert(isinstance(testAttribute, Attribute))


# Generated at 2022-06-25 04:45:20.316511
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # We initialize a dummy FieldAttribute object
    var_0 = FieldAttribute(isa=None, class_type=None, always_post_validate=False, default=None, listof=None, required=False, alias=None, inherit=True, prepend=False, private=False, extend=False, priority=0, static=False)
    assert(var_0.isa == None)
    assert(var_0.class_type == None)
    assert(var_0.always_post_validate == False)
    assert(var_0.default == None)
    assert(var_0.listof == None)
    assert(var_0.required == False)
    assert(var_0.alias == None)
    assert(var_0.inherit == True)
    assert(var_0.prepend == False)


# Generated at 2022-06-25 04:45:24.484163
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test 1: valid arguments
    var_0 = Attribute(isa=int, private=True, default=False, required=True, listof=str, priority=4, class_type=list, always_post_validate=True, inherit=False, alias=False, extend=True, prepend=True)


# Generated at 2022-06-25 04:45:33.110477
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = None
    # 1. test that constructor is recognized
    # 2. test constructor when attribute isa is present
    # 3. test constructor when attribute isa is a string representation of a yaml basic datatype
    # 4. test constructor when attribute isa is class_type
    # 5. test constructor when attribute isa is a python class
    # 6. test constructor when attribute required is present
    # 7. test constructor when attribute inherit is present
    # 8. test constructor when attribute alias is present
    # 9. test constructor when attribute listof is present
    # 10. test constructor when attribute listof is a string representation of a yaml basic datatype
    # 11. test constructor when attribute listof is class_type
    # 12. test constructor when attribute listof is a python class
    # 13. test constructor when attribute default is present
    #

# Generated at 2022-06-25 04:45:41.029126
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var = FieldAttribute()
    assert var.isa == None
    assert var.private == False
    assert var.default == None
    assert var.required == False
    assert var.listof == None
    assert var.priority == 0
    assert var.class_type == None
    assert var.always_post_validate == False
    assert var.inherit == True
    assert var.alias == None
    assert var.extend == False
    assert var.prepend == False
    assert var.static == False

    var = FieldAttribute(isa="const", private=False, default=None, required=True, listof=None, priority=1, class_type=None,
                         always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)


# Generated at 2022-06-25 04:45:51.876632
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-25 04:45:59.768268
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False



# Generated at 2022-06-25 04:46:03.140144
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute


# Generated at 2022-06-25 04:46:05.812057
# Unit test for constructor of class Attribute
def test_Attribute():
    attrib = Attribute(isa='bool', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    var = bool()
    assert type(var) == type(attrib.isa)  # Should be NoneType, bool


# Generated at 2022-06-25 04:46:10.473760
# Unit test for constructor of class Attribute
def test_Attribute():
    # Create an object of the class Attribute
    var_0 = Attribute()

    # Attribute.__init__() takes another argument besides self
    var_1 = Attribute( var_0 )


# Generated at 2022-06-25 04:46:21.793583
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute()
    assert var_1.isa == None, 'Field attribute "isa" should be None'
    assert var_1.private == False, 'Field attribute "private" should be False'
    assert var_1.default == None, 'Field attribute "default" should be None'
    assert var_1.required == False, 'Field attribute "required" should be False'
    assert var_1.listof == None, 'Field attribute "listof" should be None'
    assert var_1.priority == 0, 'Field attribute "priority" should be 0'
    assert var_1.class_type == None, 'Field attribute "class_type" should be None'
    assert var_1.always_post_validate == False, 'Field attribute "always_post_validate" should be False'

# Generated at 2022-06-25 04:46:22.742266
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()


# Generated at 2022-06-25 04:46:24.244868
# Unit test for constructor of class Attribute
def test_Attribute():
    var_0 = Attribute()


# Generated at 2022-06-25 04:46:35.821234
# Unit test for constructor of class Attribute
def test_Attribute():
    # Verify initial values of Attribute attributes
    var_0 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
            class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False,
            static=False)
    assert var_0.isa is None
    assert var_0.private == False
    assert var_0.default is None
    assert var_0.required == False
    assert var_0.listof is None
    assert var_0.priority == 0
    assert var_0.class_type is None
    assert var_0.always_post_validate == False
    assert var_0.inherit == True
    assert var_0.alias is None
    assert var_0

# Generated at 2022-06-25 04:46:47.361213
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_attribute = FieldAttribute(
        isa = 'list',
        private = False,
        default = ['localhost'],
        required = True,
        listof = None,
        priority = 0,
        class_type = {},
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False
    )

    # Output
    print("is_a: " + str(test_attribute.isa))
    print("private: " + str(test_attribute.private))
    print("default: " + str(test_attribute.default))
    print("required: " + str(test_attribute.required))
    print("listof: " + str(test_attribute.listof))

# Generated at 2022-06-25 04:46:58.990506
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: write the unit test
    assert False


# Generated at 2022-06-25 04:47:00.075832
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute()
    assert var_1 is not None

# Generated at 2022-06-25 04:47:10.375539
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = FieldAttribute(isa=print())
    assert (var_0.isa == None)
    assert (var_0.private == None)
    assert (var_0.default == print())
    assert (var_0.required == None)
    assert (var_0.listof == None)
    assert (var_0.priority == None)
    assert (var_0.class_type == print())
    assert (var_0.always_post_validate == None)
    assert (var_0.inherit == None)
    assert (var_0.alias == None)
    assert (var_0.extend == None)
    assert (var_0.prepend == None)
    assert (var_0.static == print())


# Generated at 2022-06-25 04:47:14.218907
# Unit test for constructor of class Attribute
def test_Attribute():
    test_vars = Attribute()
    assert test_vars != ''


# Generated at 2022-06-25 04:47:15.011085
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute()
    return


# Generated at 2022-06-25 04:47:19.612416
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None)



# Generated at 2022-06-25 04:47:21.900369
# Unit test for constructor of class Attribute
def test_Attribute():
    attrib = Attribute()
    if attrib is not None:
        print("Test Case 0 - test_Attribute(): PASSED")
    else:
        print("Test Case 0 - test_Attribute(): FAILED")


# Generated at 2022-06-25 04:47:27.458496
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = print()
    var_0 = Attribute()
    assert isinstance(var_0, Attribute)
    assert hasattr(var_0, 'isa')
    assert hasattr(var_0, 'private')
    assert hasattr(var_0, 'default')
    assert hasattr(var_0, 'required')
    assert hasattr(var_0, 'listof')
    assert hasattr(var_0, 'priority')
    assert hasattr(var_0, 'class_type')
    assert hasattr(var_0, 'always_post_validate')
    assert hasattr(var_0, 'inherit')
    assert hasattr(var_0, 'alias')
    assert hasattr(var_0, 'extend')
    assert hasattr(var_0, 'prepend')
   

# Generated at 2022-06-25 04:47:29.384348
# Unit test for constructor of class Attribute
def test_Attribute():
    var_2 = Attribute()
    assert isinstance(var_2, Attribute) is True


# Generated at 2022-06-25 04:47:39.552716
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.ajson import AnsibleJSONEncoder
    #from ansible.vars import post_validate
    #from ansible.vars import hostvars
    #from ansible.config import DEFAULTS as C
    #from ansible.parsing.vault import KeyringFile
    #from collections import namedtuple
    #from ansible.vars import hostvars
    #from ansible.vars import combine_vars

    var_0 = Attribute(isa='list', listof='dict')
    var_1 = Attribute(isa='list', listof='list')
    var_2 = Attribute(isa='list', listof='set')
    var_3 = Attribute(isa='list', listof='bool')


# Generated at 2022-06-25 04:48:04.696710
# Unit test for constructor of class Attribute
def test_Attribute():
    var_0 = Attribute(alias="foo")


# Generated at 2022-06-25 04:48:10.393771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-25 04:48:11.200466
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:15.409554
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    var_1 = test_case_0()
    return var_1

# Generated at 2022-06-25 04:48:25.932357
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute()
    assert var_1.isa is None
    assert var_1.private == False
    assert var_1.default is None
    assert var_1.required == False
    assert var_1.listof is None
    assert var_1.priority == 0
    assert var_1.class_type is None
    assert var_1.always_post_validate == False
    assert var_1.inherit == True
    assert var_1.alias is None
    assert var_1.extend == False
    assert var_1.prepend == False
    assert var_1.static == False


# Generated at 2022-06-25 04:48:28.173051
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute()


# Generated at 2022-06-25 04:48:35.481210
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.vault import VaultLib
    instance = VaultLib(password=None)

# Generated at 2022-06-25 04:48:39.929836
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    print(var_1)

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:48:44.837324
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute(isa='True', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:48:47.924208
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Unit test for constructor of class FieldAttribute")

    attr1 = FieldAttribute()
    assert not attr1.private
    assert attr1.inherit
    assert attr1.default is None
    assert attr1.listof is None
    assert attr1.priority == 0



# Generated at 2022-06-25 04:49:40.997550
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int')
    assert isinstance(attr, Attribute)



# Generated at 2022-06-25 04:49:45.100550
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_1 = FieldAttribute(isa='list')


# Generated at 2022-06-25 04:49:50.353748
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create an instance of class FieldAttribute (default constructor)
    obj0_FieldAttribute = FieldAttribute()
    # Access the member attribute isa of obj0_FieldAttribute
    var_isa = getattr(obj0_FieldAttribute, 'isa')
    assert var_isa == None, "Test failed: 'isa' is not equal to None"
    # Access the member attribute private of obj0_FieldAttribute
    var_private = getattr(obj0_FieldAttribute, 'private')
    assert var_private == False, "Test failed: 'private' is not equal to False"
    # Access the member attribute default of obj0_FieldAttribute
    var_default = getattr(obj0_FieldAttribute, 'default')
    assert var_default == None, "Test failed: 'default' is not equal to None"
    # Access the member attribute required of obj0_

# Generated at 2022-06-25 04:49:58.311056
# Unit test for constructor of class Attribute
def test_Attribute():
    # Create instance of class Attribute
    var_0 = Attribute(isa='isa', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    # Check if instance is created
    print(isinstance(var_0, Attribute))


# Generated at 2022-06-25 04:50:05.139837
# Unit test for constructor of class Attribute
def test_Attribute():
    var_1 = Attribute(isa=test_case_0(),
                      private=test_case_0(),
                      default=test_case_0(),
                      required=test_case_0(),
                      listof=test_case_0(),
                      priority=test_case_0(),
                      class_type=test_case_0(),
                      always_post_validate=test_case_0(),
                      inherit=test_case_0(),
                      alias=test_case_0(),
                      extend=test_case_0(),
                      prepend=test_case_0(),
                      static=test_case_0()
                      )


# Generated at 2022-06-25 04:50:14.278932
# Unit test for constructor of class Attribute
def test_Attribute():
    ans_attr = Attribute('is_a',
                         private=False,
                         default=None,
                         required=False,
                         listof=None,
                         priority=0,
                         class_type=None,
                         always_post_validate=False,
                         inherit=True,
                         alias=None)
    assert ans_attr.isa == 'is_a'
    assert ans_attr.private is False
    assert ans_attr.default is None
    assert ans_attr.required is False
    assert ans_attr.listof is None
    assert ans_attr.priority == 0
    assert ans_attr.class_type is None
    assert ans_attr.always_post_validate is False
    assert ans_attr.inherit is True
    assert ans_attr.alias is None

# Test Positive case for setter() and

# Generated at 2022-06-25 04:50:21.835778
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Testing FieldAttribute constructor")

    # Test with empty required args
    var_0 = FieldAttribute()
    if var_0.isa is not None:
        print("Failed to initialize isa for FieldAttribute")
        sys.exit(-1)
    if var_0.private is not True:
        print("Failed to initialize private for FieldAttribute")
        sys.exit(-1)
    if var_0.default is not None:
        print("Failed to initialize default for FieldAttribute")
        sys.exit(-1)
    if var_0.required is not True:
        print("Failed to initialize required for FieldAttribute")
        sys.exit(-1)
    if var_0.listof is not None:
        print("Failed to initialize listof for FieldAttribute")
        sys.exit(-1)

# Generated at 2022-06-25 04:50:30.975193
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert(a.isa is None)
    assert(a.private is False)
    assert(a.default is None)
    assert(a.required is False)
    assert(a.listof is None)
    assert(a.priority is 0)
    assert(a.class_type is None)
    assert(a.always_post_validate is False)
    assert(a.inherit is True)
    assert(a.alias is None)
    assert(a.extend is False)
    assert(a.prepend is False)
    assert(a.static is False)


# Generated at 2022-06-25 04:50:34.256999
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    test_case_0()
    assert a != None, "Problem in class Attribute"

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-25 04:50:37.580451
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    var_0 = FieldAttribute()
    var_1 = isinstance(var_0, Attribute)
    print(var_1)
    print(var_0.isa)

if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()