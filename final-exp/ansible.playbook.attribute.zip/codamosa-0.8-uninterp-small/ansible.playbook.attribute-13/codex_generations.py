

# Generated at 2022-06-25 04:42:32.266771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test Attribute init method
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()



# Generated at 2022-06-25 04:42:42.491726
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 's\x1cr\x1b\x1d\x1f\x1e\n\n'
    str_1 = 'Executor'
    str_2 = 'ssssssssss sssssssss'
    str_3 = 'iof\x1a\x1b\x1d\x1a\x1a\x11\n\x05'
    list_0 = [str_0, str_0, str_0, str_1]
    tuple_0 = ()
    attribute_0 = FieldAttribute(str_0, str_2, list_0, str_3, str_3, list_0, tuple_0)
    assert attribute_0.default == [str_0, str_0, str_0, 'Executor']
    assert attribute_0.required

# Generated at 2022-06-25 04:42:44.369923
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'tcp_wrappers'
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:42:55.066222
# Unit test for constructor of class Attribute
def test_Attribute():
    default = ()
    alias = 'attr'
    bool_0 = False
    isa = 'str'
    int_0 = 16384
    attribute_0 = Attribute(isa, bool_0, default, bool_0, int_0, int_0, default, bool_0, bool_0, alias)
    assert attribute_0.alias == 'attr'
    assert attribute_0.required == False
    assert attribute_0.listof == 16384
    assert attribute_0.always_post_validate == False
    assert attribute_0.private == False
    assert attribute_0.class_type == ()
    assert attribute_0.extend == False
    assert attribute_0.default == ()
    assert attribute_0.priority == 16384
    assert attribute_0.inherit == False
    assert attribute_0.prepend

# Generated at 2022-06-25 04:42:59.546353
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Given an instance of FieldAttribute
    str_0 = '''\
foo bar baz'''
    int_0 = (8192 + 128) - 255
    tuple_0 = ()
    attribute_0 = FieldAttribute(str_0, int_0, tuple_0)
    # Then it should be an instance of class FieldAttribute
    test_case_0()


# Generated at 2022-06-25 04:43:05.306353
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'pl[yboo\rs'
    int_0 = 8192
    tuple_0 = ()
    FieldAttribute(str_0, int_0, tuple_0)

# Generated at 2022-06-25 04:43:08.673141
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'pl[yboo\rs'
    int_0 = 8192
    tuple_0 = ()
    attribute_0 = FieldAttribute(str_0, int_0, tuple_0)


if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:43:14.654233
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'playb\x6frk'
    tuple_0 = ()
    attribute_0 = Attribute(str_0, private=False, default=None, required=True, listof=tuple_0, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    attribute_0 = Attribute(str_0, private=False, default=None, required=True, listof=tuple_0, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=True, prepend=False, static=True)

# Generated at 2022-06-25 04:43:23.763564
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test case with arguments
    str_0 = 'pl[yboo\rs'
    int_0 = 8192
    tuple_0 = ()
    attribute_0 = Attribute(str_0, int_0, tuple_0)

    # Test case with arguments
    str_0 = 'pl[yboo\rs'
    int_0 = -4196
    list_0 = []
    tuple_0 = ('me/h\xA8\xA1',)
    attribute_0 = Attribute(str_0, int_0, list_0, tuple_0)

    # Test case with arguments
    str_0 = '\x8E\x1F??\xC2Q'
    int_0 = -4196
    list_0 = []

# Generated at 2022-06-25 04:43:36.410978
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test correct use of constructor
    str_0 = 'pl[yboo\rs'
    int_0 = 8192
    tuple_0 = ()
    attribute_0 = Attribute(str_0, int_0, tuple_0)
    assert (attribute_0.isa == 'pl[yboo\rs')
    assert (attribute_0.private == 8192)
    assert (attribute_0.default == ())
    assert (attribute_0.required is True)
    assert (attribute_0.listof is False)
    assert (attribute_0.priority == 0)
    assert (attribute_0.class_type is None)
    assert (attribute_0.always_post_validate is False)
    assert (attribute_0.inherit is True)
    # Test incorrect use of constructor

# Generated at 2022-06-25 04:43:42.227780
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = 'tcp_wrappers'
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None


# Generated at 2022-06-25 04:43:45.333050
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'tcp_wrappers'
    attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:43:55.356339
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_1 = 'tcp_wrappers'
    attribute_1 = Attribute(str_1)
    bool_0 = attribute_1 == attribute_1
    print(bool_0)
    print(attribute_1.default)
    print(attribute_1.required)
    print(attribute_1.always_post_validate)
    print(attribute_1.inherit)
    print(attribute_1.extend)
    print(attribute_1.prepend)
    print(attribute_1.static)
    print(attribute_1.listof)
    bool_1 = bool_0
    print(bool_1)
    print(attribute_1.class_type)
    print(attribute_1.priority)
    print(attribute_1.alias)
    print(attribute_1.private)

# Generated at 2022-06-25 04:43:58.123980
# Unit test for constructor of class Attribute
def test_Attribute():
    str_1 = 'tcp_wrappers'
    attribute_1 = Attribute(str_1)
    assert(isinstance(attribute_1.isa, str))

# Generated at 2022-06-25 04:43:59.913105
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = 'tcp_wrappers'
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:44:09.721972
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # noinspection PyUnresolvedReferences
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import sys

    str_0 = "list"
    str_1 = "dict"
    str_2 = "list"
    str_3 = "default"
    str_4 = "required"
    str_5 = "listof"
    str_6 = "priority"
    str_7 = "class_type"
    str_8 = "always_post_validate"
    str_9 = "inherit"
    str_10 = "alias"

    str_11 = 'tcp_wrappers'
    str_12 = 'become_method'
    str_13 = 'vars_prompt'

    class_0 = AnsibleBaseYAMLObject
    attribute

# Generated at 2022-06-25 04:44:12.717931
# Unit test for constructor of class Attribute
def test_Attribute():
    # Verify the constructor of class Attribute
    test_case_0()
    

# Generated at 2022-06-25 04:44:20.471068
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test for case where none of the values are part of the constructor
    attribute_0 = FieldAttribute()

    # Test for another case where none of the values are part of the constructor
    attribute_1 = FieldAttribute()

    # Test for case where all the values are part of the constructor
    attribute_2 = FieldAttribute('tcp_wrappers')

    # Test for another case where all the values are part of the constructor
    attribute_3 = FieldAttribute('tcp_wrappers')

    # Test for case where all the values are part of the constructor
    attribute_4 = FieldAttribute('tcp_wrappers')

    # Test for another case where all the values are part of the constructor
    attribute_5 = FieldAttribute('tcp_wrappers')

    # Test for case where all the values are part of the constructor

# Generated at 2022-06-25 04:44:22.496978
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute()



# Generated at 2022-06-25 04:44:24.859018
# Unit test for constructor of class Attribute
def test_Attribute():
    #str_0 = 'tcp_wrappers'
    attribute_0 = Attribute()



# Generated at 2022-06-25 04:44:28.010705
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# Unit tests for copy methods in class FieldAttribute

# Generated at 2022-06-25 04:44:34.645811
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert isinstance(attribute_0, Attribute)
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False



# Generated at 2022-06-25 04:44:38.244072
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa='str', private=True, default='test', required=True, listof='test', priority=1, class_type='test', always_post_validate=True, inherit=False, alias='test', extend=True, prepend=True, static=True)

test_FieldAttribute()

# Generated at 2022-06-25 04:44:46.172432
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False,
                     listof=None, priority=0, class_type=None, always_post_validate=False,
                     inherit=True, alias=None, extend=False, prepend=False, static=False)
    print(attr.isa)
    print(attr.private)
    print(attr.default)
    print(attr.required)
    print(attr.listof)
    print(attr.priority)
    print(attr.class_type)
    print(attr.always_post_validate)
    print(attr.inherit)
    print(attr.alias)
    print(attr.extend)
    print(attr.prepend)
    print(attr.static)
    assert attr.isa == 'list'

# Generated at 2022-06-25 04:44:46.664261
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()

# Generated at 2022-06-25 04:44:56.790106
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(isa = 'str')
    attribute_1 = FieldAttribute(isa = 'list')
    attribute_2 = FieldAttribute(isa = 'dict')
    attribute_3 = FieldAttribute(isa = 'set')
    attribute_4 = FieldAttribute(isa = bool)
    attribute_5 = FieldAttribute(isa = int)
    attribute_6 = FieldAttribute(isa = 'bool')
    attribute_7 = FieldAttribute(isa = 'int')
    attribute_8 = FieldAttribute(isa = 'float')
    attribute_9 = FieldAttribute(isa = 'list', listof = 'str')
    attribute_10 = FieldAttribute(isa = 'list', listof = 'list')
    attribute_11 = FieldAttribute(isa = 'list', listof = 'dict')

# Generated at 2022-06-25 04:45:04.969835
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert(attribute_0.isa == None)
    assert(attribute_0.private == False)
    assert(attribute_0.default == None)
    assert(attribute_0.required == False)
    assert(attribute_0.listof == None)
    assert(attribute_0.priority == 0)
    assert(attribute_0.class_type == None)
    assert(attribute_0.always_post_validate == False)
    assert(attribute_0.inherit == True)
    assert(attribute_0.alias == None)
    assert(attribute_0.extend == False)
    assert(attribute_0.prepend == False)
    assert(attribute_0.static == False)


# Generated at 2022-06-25 04:45:13.327409
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False


# Generated at 2022-06-25 04:45:14.787783
# Unit test for constructor of class Attribute
def test_Attribute():
    ansible_definition = Attribute()
    assert(ansible_definition is not None)


# Generated at 2022-06-25 04:45:18.287041
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert True == True
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:45:26.758516
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().inherit == True
    assert Attribute().alias == None
    assert Attribute().extend == False
    assert Attribute().prepend == False
    assert Attribute().static == False
    return 0


# Generated at 2022-06-25 04:45:30.635746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute()
    assert isinstance(attribute_1, Attribute)


# Generated at 2022-06-25 04:45:39.931256
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attribute_1.isa == 'str'
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.always_post_validate == False
    assert attribute_1.inherit == True
    assert attribute_1.alias == None
    assert attribute_1.extend == False

# Generated at 2022-06-25 04:45:41.025864
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()



# Generated at 2022-06-25 04:45:50.883746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Testing parameters are not None
    parameter_types = (str, bool, (type(None),), bool, (type(None),), int, (type(None),), bool, bool, str)
    parameter_names = ('isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type', 'always_post_validate', 'inherit', 'alias')
    for parameter_type, parameter_name in zip(parameter_types, parameter_names):
        if parameter_type == (type(None),) or parameter_type == bool:
            assert type(getattr(attribute_0, parameter_name)) == parameter_type[0], 'Type of ' + parameter_name + ' is wrong.'
        else:
            assert isinstance(getattr(attribute_0, parameter_name), parameter_type), 'Type of '

# Generated at 2022-06-25 04:45:52.310905
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute()


# Generated at 2022-06-25 04:46:03.075145
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    # test isa
    assert attribute_0.isa is None
    attribute_1 = Attribute(isa=u'')
    assert attribute_1.isa == ''
    attribute_2 = Attribute(isa='package')
    assert attribute_2.isa == 'package'
    attribute_3 = Attribute(isa='{package,file}')
    assert attribute_3.isa == '{package,file}'
    attribute_4 = Attribute(isa='molecule')
    assert attribute_4.isa == 'molecule'
    # test private
    attribute_5 = Attribute(private=False)
    assert attribute_5.private == False
    attribute_6 = Attribute(private=True)
    assert attribute_6.private == True
    attribute_7 = Attribute(private=False)

# Generated at 2022-06-25 04:46:09.141548
# Unit test for constructor of class Attribute
def test_Attribute():
    # Check that attributes are initialized as expected
    attribute_0 = Attribute()
    assert attribute_0 is not None
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False
    print('Pass test_Attribute')


# Generated at 2022-06-25 04:46:14.977732
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True


# Generated at 2022-06-25 04:46:16.572918
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
	attribute_0 = FieldAttribute(isa="dict")


# Generated at 2022-06-25 04:46:18.709935
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()


# Generated at 2022-06-25 04:46:21.118079
# Unit test for constructor of class Attribute
def test_Attribute():
    default = Attribute()
    assert default is not None


# Generated at 2022-06-25 04:46:28.997397
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test constructor of class Attribute when called with no parameters
    attribute_0 = Attribute()

    # Test constructor of class Attribute when called with required parameters
    attribute_1 = Attribute(isa = 'bool', private = 'False', default = 'None', required = 'False', listof = 'None', priority = 1, class_type = 'None', always_post_validate = 'False', inherit = 'True', alias = 'None')

    # Test constructor of class Attribute when called with all parameters
    attribute_2 = Attribute(isa = 'bool', private = 'False', default = 'None', required = 'False', listof = 'None', priority = 1, class_type = 'None', always_post_validate = 'False', inherit = 'True', alias = 'None')



# Generated at 2022-06-25 04:46:29.933290
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(FieldAttribute(), FieldAttribute)



# Generated at 2022-06-25 04:46:31.614784
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        attribute_0 = Attribute()
        assert False
    except:
        assert True
    return True

# Generated at 2022-06-25 04:46:41.446967
# Unit test for constructor of class Attribute
def test_Attribute():
    class_name = 'test_Attribute'
    field_name = '_test_field'
    attribute_0 = Attribute()

    assert attribute_0.isa is None
    assert attribute_0.private == False
    assert attribute_0.default is None
    assert attribute_0.required == False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias is None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False

    return


# Generated at 2022-06-25 04:46:44.151984
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='list', default=dict, class_type=dict)


# Generated at 2022-06-25 04:46:45.652390
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:46:53.786259
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    attribute_1 = FieldAttribute(isa='int')
    attribute_1.isa = '2'
    attribute_1.private = False
    attribute_1.default = 4
    attribute_1.required = False
    attribute_1.listof = 'int'
    attribute_1.priority = 0
    attribute_1.class_type = None
    attribute_1.always_post_validate = False
    attribute_1.inherit = True
    attribute_1.alias = None
    attribute_1.extend = False
    attribute_1.prepend = False
    attribute_1.static = False

    # Call methods of class FieldAttribute
    assert(attribute_1.__eq__(Attribute()) == True)
    assert(attribute_1.__ne__(Attribute()) == False)
   

# Generated at 2022-06-25 04:47:04.488292
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute('string', True, default='default_val', required=False, listof='string', priority=5, class_type='string', always_post_validate=True, inherit=True, alias='alias', static=True)
    assert attribute_1.isa == 'string' and attribute_1.private == True and attribute_1.default == 'default_val' and attribute_1.required == False and attribute_1.listof == 'string' and attribute_1.priority == 5 and attribute_1.class_type == 'string' and attribute_1.always_post_validate == True and attribute_1.inherit == True and attribute_1.alias == 'alias' and attribute_1.static == True

# Generated at 2022-06-25 04:47:08.802368
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:47:12.785394
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Constructor for Attribute class using all parameters

# Generated at 2022-06-25 04:47:15.013175
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test initialize with unknown attribute, isa must be None
    """
    attribute_0 = Attribute(haha=True)
    assert attribute_0.isa == None



# Generated at 2022-06-25 04:47:23.223300
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    # default arguments of constructor
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-25 04:47:24.930701
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    my_attribute = FieldAttribute()
    assert(my_attribute is not None)



# Generated at 2022-06-25 04:47:36.200594
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert (attribute_0 == attribute_0)
    assert (attribute_0 != attribute_0)
    assert (attribute_0 < attribute_0)
    assert (attribute_0 > attribute_0)
    assert (attribute_0 >= attribute_0)
    assert (attribute_0 <= attribute_0)
    assert (attribute_0.isa is None)
    assert (attribute_0.private == False)
    assert (attribute_0.default is None)
    assert (attribute_0.required == False)
    assert (attribute_0.listof is None)
    assert (attribute_0.priority == 0)
    assert (attribute_0.class_type is None)
    assert (attribute_0.always_post_validate == False)
    assert (attribute_0.inherit == True)


# Generated at 2022-06-25 04:47:38.345946
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute()
    assert isinstance(attribute_1, FieldAttribute), "__init__() doesn't create an instance of FieldAttribute"
    assert isinstance(attribute_1, Attribute), "__init__() doesn't create an instance of Attribute"


# Generated at 2022-06-25 04:47:38.763925
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass

# Generated at 2022-06-25 04:47:48.799725
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    assert attribute_1.isa is None
    assert attribute_1.private is False
    assert attribute_1.default is None
    assert attribute_1.required is False
    assert attribute_1.listof is None
    assert attribute_1.priority == 0
    assert attribute_1.class_type is None
    assert attribute_1.always_post_validate is False
    assert attribute_1.inherit is True
    assert attribute_1.alias is None
    assert attribute_1.extend is False
    assert attribute_1.prepend is False
    assert attribute_1.static is False

# Generated at 2022-06-25 04:47:49.245577
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute()

# Generated at 2022-06-25 04:48:01.420179
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(
        isa = 'dict',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = 'the alias',
        extend = False,
        prepend = False,
        static = False,
        )
    print ("The attribute is " + str(attribute))
    print ("The attribute isa is " + str(attribute.isa))
    print ("The attribute private is " + str(attribute.private))
    print ("The attribute default is " + str(attribute.default))
    print ("The attribute required is " + str(attribute.required))
    print ("The attribute listof is " + str(attribute.listof))
    print

# Generated at 2022-06-25 04:48:02.325564
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:06.236128
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute is not None


# Generated at 2022-06-25 04:48:08.182975
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# vim: set expandtab ts=4 sw=4 ai ft=python

# Generated at 2022-06-25 04:48:09.245980
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()


# Generated at 2022-06-25 04:48:17.428096
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_FieldAttribute_0 = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    test_FieldAttribute_1 = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

    assert test_FieldAttribute_0 == test_FieldAttribute_1


# Generated at 2022-06-25 04:48:21.298003
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa='str', private=False, default='false', required=False, listof='str', priority=0,
                            class_type='str', always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

# Generated at 2022-06-25 04:48:22.175493
# Unit test for constructor of class Attribute
def test_Attribute():
    assert(test_case_0())

# Generated at 2022-06-25 04:48:30.600222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    # a.__dict__: {'__module__': 'ansible.parsing.yaml.objects', 'required': False, 'inherit': True, 'class_type': None, 'private': False, 'extend': False, 'alias': None, 'listof': None, 'default': None, 'priority': 0, 'always_post_validate': False, 'prepend': False, 'isa': None, 'static': False}
    # a.__dict__: {'__module__': 'ansible.parsing.yaml.objects', 'required': True, 'inherit': True, 'class_type': None, 'private': False, 'extend': False, 'alias': None, 'listof': None, 'default': None, 'priority': 0, 'always_post_validate': False

# Generated at 2022-06-25 04:48:37.091026
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(
        isa='name',
        private=True,
        default=None,
        required=True,
        listof='boolean',
        priority=2,
        class_type='type',
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=True,
        prepend=True,
        static=True,
    )
    print(attribute_0.__dict__)
    attribute_1 = Attribute()
    print(attribute_1.__dict__)
    attribute_2 = Attribute(isa='dict')
    print(attribute_2.__dict__)
    print(attribute_2)
    print(dir(attribute_2))
    print(attribute_2.isa)
    attribute_3 = Attribute(isa='list')

# Generated at 2022-06-25 04:48:43.077118
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa='int', priority=0, default=0)
    assert attribute_1.isa == 'int'
    assert attribute_1.priority == 0
    assert attribute_1.default == 0



# Generated at 2022-06-25 04:48:51.951792
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False


# Generated at 2022-06-25 04:48:52.836322
# Unit test for constructor of class Attribute
def test_Attribute():
    assert (isinstance(Attribute(), Attribute))



# Generated at 2022-06-25 04:48:56.307216
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()

    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None



# Generated at 2022-06-25 04:49:04.841090
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0 is not None
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False
    assert attribute_0.static is False



# Generated at 2022-06-25 04:49:16.173831
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute(isa='test_isa', private=False, default='test_default', required=False,
                            listof=None, priority=0, class_type=None, always_post_validate=False,
                            inherit=True, alias='test_alias', extend=False, prepend=False, static=False)
    assert attribute_1.isa == 'test_isa'
    assert attribute_1.private == False
    assert attribute_1.default == 'test_default'
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.always_post_validate == False
    assert attribute_1.inherit == True

# Generated at 2022-06-25 04:49:17.711077
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """

    :return:
    """
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:49:25.520164
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa='str', default='Hi', class_type='module_utils.basic.Basic')
    assert attribute_0.isa == 'str'
    assert attribute_0.private == False
    assert attribute_0.default == 'Hi'
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == 'module_utils.basic.Basic'
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False


# Generated at 2022-06-25 04:49:28.540229
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-25 04:49:32.397006
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(default=0, isa='int')
    attribute_2 = FieldAttribute(default='string', isa='string')


# Generated at 2022-06-25 04:49:40.393013
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(isa="str",private=True,default="some_default")
    assert(attribute_0.isa=="str")
    assert(attribute_0.private)
    assert(attribute_0.default=="some_default")


# Generated at 2022-06-25 04:49:42.128502
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_1 = Attribute()
    if attribute_1 is not None:
        return True
    else:
        return False


# Generated at 2022-06-25 04:49:45.132199
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    attribute_0.private = True
    attribute_0.isa = 'list'
    attribute_0.required = False
    attribute_0.default = 'dict'
    attribute_0.listof = 'list'
    attribute_0.priority = 0
    assert isinstance(attribute_0, FieldAttribute)


# Generated at 2022-06-25 04:49:48.928864
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False



# Generated at 2022-06-25 04:49:56.148220
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_FieldAttribute = FieldAttribute(isa='string',
                                         private=False,
                                         default=None,
                                         required=False,
                                         listof=None,
                                         priority=0,
                                         class_type=None,
                                         always_post_validate=False,
                                         inherit=True,
                                         alias=None,
                                         extend=False,
                                         prepend=False,
                                         static=False)

# Generated at 2022-06-25 04:49:58.577533
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:50:06.756435
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # In this test we are creating the attribute object 'attribute_1' which has isa=list,
    # default = None, listof = None, priority = 0
    attribute_1 = FieldAttribute(isa=list, default=None, listof=None, priority=0)
    
    # In this test we are creating the attribute object 'attribute_2' which has isa=None,
    # default = None, listof = None, priority = 0
    attribute_2 = FieldAttribute(isa=None, default=None, listof=None, priority=0)
    
    # In this test we are creating the attribute object 'attribute_3' which has isa=None,
    # default = None, listof = None, priority = 0
    attribute_3 = FieldAttribute(isa=None, default=None, listof=None, priority=0)


# Generated at 2022-06-25 04:50:17.176808
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None

    attribute = Attribute(isa='int', private=True, default=5, required=True, listof=str, priority=1, class_type=str,
                          always_post_validate=True, inherit=False, alias='name alias')
    assert attribute.isa == 'int'
    assert attribute.private == True
    assert attribute.default == 5
    assert attribute.required == True
    assert attribute.listof == str


# Generated at 2022-06-25 04:50:21.067110
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()


# Generated at 2022-06-25 04:50:26.612292
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(
        isa='str',
        private=True,
        default=None,
        required=True,
        listof='',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    print("FieldAttribute constructor returns valid object")


# Generated at 2022-06-25 04:50:47.202722
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute(default='mocked_default',
            isa='mocked_isa',
            private=True,
            required=False,
            listof=None,
            priority=5,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False)
    if not x.default =='mocked_default':
        raise AssertionError()
    if not x.isa =='mocked_isa':
        raise AssertionError()
    if not x.private == True:
        raise AssertionError()
    if not x.required == False:
        raise AssertionError()
    if not x.listof == None:
        raise AssertionError()
   

# Generated at 2022-06-25 04:50:58.753770
# Unit test for constructor of class Attribute
def test_Attribute():
    print("--------------------")
    print("Unit test of __init__ function for Attribute")
    print("--------------------")
    attribute = Attribute(
        isa = "a",
        private = True,
        default = None,
        required = True,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = True,
        inherit = True,
        extend = False,
        prepend = False
    )
    print(attribute.isa)
    print(attribute.private)
    print(attribute.default)
    print(attribute.required)
    print(attribute.listof)
    print(attribute.priority)
    print(attribute.class_type)
    print(attribute.always_post_validate)
    print(attribute.inherit)

# Generated at 2022-06-25 04:51:02.106102
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute('', False, '', False, '', 0, '', False, True, '', False, False, False, False)


# Generated at 2022-06-25 04:51:04.506507
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa='dict')
    assert(attribute_0.isa == 'dict')


# Generated at 2022-06-25 04:51:09.401304
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False


# Generated at 2022-06-25 04:51:10.515788
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Instance of class FieldAttribute
    field_attribute_0 = FieldAttribute()



# Generated at 2022-06-25 04:51:14.916172
# Unit test for constructor of class Attribute
def test_Attribute():
    def_value = [{'unit_test': 'unit_test_attribute'}]
    attribute_0 = Attribute(default=def_value, isa='list', inherit=True, listof='dict')
    assert isinstance(attribute_0, Attribute)
    assert attribute_0.default == def_value
    assert attribute_0.inherit == True
    assert attribute_0.listof == 'dict'
    assert attribute_0.isa == 'list'
    # test code can't check private and required, but it will show
    # if they get assigned
    assert attribute_0.private == False
    assert attribute_0.required == False



# Generated at 2022-06-25 04:51:15.481061
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()


# Generated at 2022-06-25 04:51:25.661041
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor
    attribute_0 = Attribute()
    assert attribute_0.isa is None
    assert attribute_0.private is False
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False
    assert attribute_0.inherit is True
    assert attribute_0.alias is None
    assert attribute_0.extend is False
    assert attribute_0.prepend is False
    assert attribute_0.static is False

    # Constructor with values for all the attributes

# Generated at 2022-06-25 04:51:27.359045
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

# Generated at 2022-06-25 04:51:54.965192
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()
    assert attribute_0.isa == None
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False



# Generated at 2022-06-25 04:51:56.942953
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-25 04:51:58.657452
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attribute_0 = Attribute(default='ANSIBLE')


# Generated at 2022-06-25 04:52:05.308410
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute(isa="list", listof="string", default='test', required=True,
    priority=0, inherit=True, alias='test_attr')
    assert attribute_0.isa == 'list'
    assert attribute_0.default == 'test'
    assert attribute_0.required == True
    assert attribute_0.priority == 0
    assert attribute_0.inherit == True
    assert attribute_0.alias == 'test_attr'



# Generated at 2022-06-25 04:52:06.375036
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f is not None


# Generated at 2022-06-25 04:52:08.672827
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()


# Generated at 2022-06-25 04:52:10.613684
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute('isa', True, 'default', True, 'listof', 'priority', 'class_type', True, True, 'alias', True, True, 1)


# Generated at 2022-06-25 04:52:12.047627
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute()

if __name__ == "__main__":
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:52:15.554587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Test for constructor of class FieldAttribute")

    attribute_0 = FieldAttribute()
    assert attribute_0.prepend == False
    assert attribute_0.extend == False
    assert attribute_0.static == False
    assert attribute_0.alias is None
    assert attribute_0.required == False
    assert attribute_0.private == False
    assert attribute_0.default is None
    assert attribute_0.priority == 0
    assert attribute_0.isa is None
    assert attribute_0.always_post_validate == False
    assert attribute_0.class_type is None
    assert attribute_0.listof is None


# Generated at 2022-06-25 04:52:23.673381
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()
    field_attribute_0 = FieldAttribute(isa='str')
    field_attribute_0 = FieldAttribute(isa='str', private=False)
    field_attribute_0 = FieldAttribute(isa='str', private=False, required=False)
    field_attribute_0 = FieldAttribute(isa='str', private=False, required=False, inherit=False)
    field_attribute_0 = FieldAttribute(isa='str', private=False, required=False, inherit=False, class_type='str')
    field_attribute_0 = FieldAttribute(isa='str', private=False, required=False, inherit=False, class_type='str', always_post_validate=False)