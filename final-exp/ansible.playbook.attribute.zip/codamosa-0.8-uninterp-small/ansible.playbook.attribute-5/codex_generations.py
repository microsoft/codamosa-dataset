

# Generated at 2022-06-25 04:42:32.173100
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    value = 0
    FieldAttribute(value)

# Test code for deepcopy()
# Test code for __str__()
# Test code for __repr__()
# Test code for __eq__()
# Test code for __ne__()
# Test code for __lt__()
# Test code for __gt__()
# Test code for __le__()
# Test code for __ge__()
# Test code for __copy__()
# Test code for __deepcopy__()

# Generated at 2022-06-25 04:42:38.737924
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test attribute constructor with valid isa type 'int' and default value 1.

    attribute_0 = Attribute("int", False, 1)

    # Test attribute constructor with a valid isa type 'str' and default value
    # 'string'

    attribute_1 = Attribute("str", False, "string")

    # Test attribute constructor with a valid isa type 'str' and default value
    # 'string'

    attribute_2 = Attribute("str", True, "string")

    # Test attribute constructor with a valid isa type 'list' and default value

    attribute_3 = Attribute("list", False, [1, 2, 3])

    # Test attribute constructor with a invalid isa type 'list' and default value
    # 1. Since isa is a complex data type, default should be a callable.


# Generated at 2022-06-25 04:42:44.578085
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    str_1 = "N/fz5c5U6@nUZ0L-9M_A"

# Generated at 2022-06-25 04:42:46.833254
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:42:55.447588
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute('isa_0')
    assert attribute_0.isa == 'isa_0'
    assert attribute_0.private == False
    assert attribute_0.default is None
    assert attribute_0.required == False
    assert attribute_0.listof is None
    assert attribute_0.priority == 0
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias is None
    attribute_1 = Attribute('isa_1', True, 'default_1', True, 'listof_1', 1, 'class_type_1', True, False, 'alias_1')
    assert attribute_1.isa == 'isa_1'
    assert attribute_1.private == True

# Generated at 2022-06-25 04:43:03.224528
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute('list')
    assert(attribute.isa == 'list')
    assert(attribute.private == False)
    assert(attribute.default == None)
    assert(attribute.required == False)
    assert(attribute.listof == None)
    assert(attribute.priority == 0)
    assert(attribute.class_type == None)
    assert(attribute.always_post_validate == False)
    assert(attribute.inherit == True)
    assert(attribute.alias == None)
    assert(attribute.extend == False)
    assert(attribute.prepend == False)
    assert(attribute.static == False)





# Generated at 2022-06-25 04:43:07.905991
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_str = "{rWb'F@8Wz:uy@s:w7"
    attribute = FieldAttribute(attribute_str)
    print(attribute)

    attribute_str = "U&_+UuL%U^dN*Y9'+>V2"
    attribute = FieldAttribute(attribute_str)
    print(attribute)



# Generated at 2022-06-25 04:43:10.254588
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:43:15.678045
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test_FieldAttribute_0
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    bool_0 = True
    str_1 = "a]y?<o(M4W`4w2hYz:$1"
    attribute_0 = FieldAttribute(str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private == bool_0
    attribute_1 = FieldAttribute(str_0, private=bool_0)
    assert attribute_1.private == bool_0
    attribute_2 = FieldAttribute(str_0, private=bool_0, default=str_1)
    assert attribute_2.default == str_1

# Generated at 2022-06-25 04:43:18.799974
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    attribute_1 = FieldAttribute()


# Generated at 2022-06-25 04:43:27.028774
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "C%c<X2IK$h)yP@o,P&"
    str_1 = "KZ'p8@mW9mvH,5f.O^c5'K"
    str_2 = "Y,~IQ)`^]lN<],vhb'e3<4"
    attribute_0 = Attribute(str_0, True, int(0), True, str_1, int(3), str_2)
    attribute_1 = FieldAttribute(str_0, True, int(0), True, str_1, int(3), str_2)
    assert (attribute_1.isa) == str_0
    assert (attribute_1.private) == True
    assert (attribute_1.default) == int(0)
    assert (attribute_1.required)

# Generated at 2022-06-25 04:43:35.453925
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert attribute_0.isa == str_0
    assert attribute_0.private == True
    assert attribute_0.required == True
    assert attribute_0.listof == str_0
    assert attribute_0.priority == -402790357
    assert attribute_0.class_type == str_0
    assert attribute_0.always_post_validate == True
    assert attribute_0.inherit == True
    assert attribute_0.alias == str_0


# Generated at 2022-06-25 04:43:41.629527
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_0 = FieldAttribute(None)
    assert attribute_0.isa == None, "Expected False, but got {0}".format(attribute_0.isa)
    assert attribute_0.private == False, "Expected False, but got {0}".format(attribute_0.private)
    assert attribute_0.default == None, "Expected None, but got {0}".format(attribute_0.default)
    assert attribute_0.required == False, "Expected False, but got {0}".format(attribute_0.required)
    assert attribute_0.listof == None, "Expected None, but got {0}".format(attribute_0.listof)
    assert attribute_0.priority == 0, "Expected 0, but got {0}".format(attribute_0.priority)

# Generated at 2022-06-25 04:43:49.446931
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    str_1 = 'JnM<8fv$-m'
    int_0 = 0
    boolean_0 = False
    attribute_0 = Attribute(str_0)
    attribute_1 = Attribute(str_1)
    attribute_2 = Attribute(int_0)
    attribute_3 = Attribute(boolean_0)


# Generated at 2022-06-25 04:43:57.577841
# Unit test for constructor of class Attribute
def test_Attribute():

    # Negative test case 0
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    try:
        attribute_0 = Attribute(str_0)
    except:
        pass
    else:
        raise Exception("Test case 0 fails.\nExpected: Attribute() raises a TypeError exception.\nBut: Nothing happens.")

    # Negative test case 1
    int_0 = 0
    try:
        attribute_0 = Attribute(int_0)
    except:
        pass
    else:
        raise Exception("Test case 1 fails.\nExpected: Attribute() raises a TypeError exception.\nBut: Nothing happens.")

    # Negative test case 2
    float_0 = 0.0

# Generated at 2022-06-25 04:44:03.546673
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test case for Attribute
    attribute_1 = Attribute()
    assert attribute_1.isa == None
    assert attribute_1.private == False
    assert attribute_1.default == None
    assert attribute_1.required == False
    assert attribute_1.listof == None
    assert attribute_1.priority == 0
    assert attribute_1.class_type == None
    assert attribute_1.always_post_validate == False
    assert attribute_1.inherit == True
    assert attribute_1.alias == None
    assert attribute_1.extend == False
    assert attribute_1.prepend == False
    assert attribute_1.static == False

    # Test case for Attribute
    str_2 = "{rWb'F@8Wz:uy@s:w7"

# Generated at 2022-06-25 04:44:10.288974
# Unit test for constructor of class Attribute
def test_Attribute():
    _CONTAINERS = 'list'
    _CONTAINERS = tuple()
    default = 'str'
    required = False
    listof = None
    priority = 0
    _CONTAINERS = tuple()
    always_post_validate = False
    inherit = True
    str_0 = 'list'
    str_1 = 'list'
    str_2 = 'list'
    attribute_0 = Attribute()
    attribute_1 = Attribute(_CONTAINERS, default, required, listof, priority, _CONTAINERS, always_post_validate, inherit)
    assert_equal(attribute_0.listof, None)
    assert_equal(attribute_1.listof, None)
    assert_equal(attribute_0.priority, 0)
    assert_equal(attribute_1.priority, 0)
    assert_

# Generated at 2022-06-25 04:44:14.246045
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:44:21.491721
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "c,$y:^1b@G}Oo`P-#XjZ=C_tr"
    attribute_0 = Attribute(str_0)
    attribute_1 = Attribute(listof="9Rf@M(0V?w4j0wa4)Gte:~jn")
    attribute_1 = FieldAttribute(listof="9Rf@M(0V?w4j0wa4)Gte:~jn")
    str_1 = "p'N<*NjxM+)f;N]HiM6|WU{D"
    attribute_2 = Attribute(str_1)
    attribute_2 = FieldAttribute(str_1)

# Generated at 2022-06-25 04:44:31.903606
# Unit test for constructor of class Attribute
def test_Attribute():

    # In this test, we will construct an Attribute instance.
    attribute_0 = Attribute(isa = 'dict')
    attribute_0_0 = Attribute(isa = 'dict')

    # Pass the constructed Attribute instance to the == method.
    if (attribute_0 == attribute_0_0):
        print("Same attribute\n")

    # Pass the constructed Attribute instance to the != method.
    if (attribute_0 != attribute_0_0):
        print("Different attribute\n")

    attribute_1 = Attribute(isa = 'dict', private = False)
    attribute_2 = Attribute(isa = 'dict', private = True)

    if (attribute_1 == attribute_2):
        print("Same attribute\n")

    if (attribute_1 != attribute_2):
        print("Different attributes\n")

    attribute

# Generated at 2022-06-25 04:44:36.499058
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    concept_attribute_0 = FieldAttribute('.')
#
# class TestClass:
#     def __init__(self):
#         self.attr = Attribute('.')
#
#     def get_attribute(self):
#         return self.attr
#
#
# test_inst = TestClass()
#
# test_inst.get_attribute()

# Generated at 2022-06-25 04:44:40.741749
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == str_0
    assert attribute_0.private == False
    assert attribute_0.default == None
    assert attribute_0.required == False
    assert attribute_0.listof == None
    assert attribute_0.priority == 0
    assert attribute_0.class_type == None
    assert attribute_0.always_post_validate == False
    assert attribute_0.inherit == True
    assert attribute_0.alias == None
    assert attribute_0.extend == False
    assert attribute_0.prepend == False
    assert attribute_0.static == False

# Generated at 2022-06-25 04:44:42.958334
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:44:53.641993
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    assert(attribute_0.isa is None)
    assert(attribute_0.private is False)
    assert(attribute_0.default is None)
    assert(attribute_0.required is False)
    assert(attribute_0.listof is None)
    assert(attribute_0.priority == 0)
    assert(attribute_0.class_type is None)
    assert(attribute_0.always_post_validate is False)
    assert(attribute_0.inherit is True)
    assert(attribute_0.alias is None)
    assert(attribute_0.extend is False)
    assert(attribute_0.prepend is False)
    assert(attribute_0.static is False)



# Generated at 2022-06-25 04:44:57.872510
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # init should take a single argument
    test_case_0()
    # Add an assertion to confirm that the type of Attribute.default is set to None
    assert Attribute().default is None

# Generated at 2022-06-25 04:44:59.458556
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute('dictionary')
    assert attribute_0.isa == 'dictionary'


# Generated at 2022-06-25 04:45:09.412928
# Unit test for constructor of class Attribute
def test_Attribute():
  str_0 = "{rWb'F@8Wz:uy@s:w7"
  attribute_0 = Attribute(str_0)
  str_1 = ",g`ZNdPn>Yq#rf:Bny=c"
  attribute_1 = Attribute(str_1)
  str_2 = "@5w'S@:!;5!5y9'=d%m<"
  attribute_2 = Attribute(str_2)
  str_3 = "vG;X?Bfhrt+#WtJ8xv[e"
  attribute_3 = Attribute(str_3)
  str_4 = "E|-Pl3)8?x&.m~`9,dJm"
  attribute_4 = Attribute(str_4)
  str_5

# Generated at 2022-06-25 04:45:11.132398
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "3'tb@s7gTz(YrQ7r"
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:45:21.357808
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = "{rWb'F@8Wz:uy@s:w7"
    private = "{rWb'F@8Wz:uy@s:w7"
    default = "{rWb'F@8Wz:uy@s:w7"
    required = "{rWb'F@8Wz:uy@s:w7"
    listof = "{rWb'F@8Wz:uy@s:w7"
    priority = "{rWb'F@8Wz:uy@s:w7"
    class_type = "{rWb'F@8Wz:uy@s:w7"
    always_post_validate = "{rWb'F@8Wz:uy@s:w7"

# Generated at 2022-06-25 04:45:26.404209
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.attribute  import Attribute
    from ansible.playbook.attribute  import FieldAttribute
    from ansible.playbook.base       import Base
    from ansible.playbook.task       import Task
    from ansible.playbook.handler    import Handler

    task = Task()
    attribute = FieldAttribute('metasyntatic')
    method = task._load_attr_from_yaml
    task._load_attr_from_yaml = lambda x, y: None
    task.load_attr('metasyntatic', attribute)
    task._load_attr_from_yaml = method
    task.metasyntatic = 'foo'
    #print (task.metasyntatic)
    assert task.metasyntatic == 'foo'

    # pylint: disable=too-many-function-args

# Generated at 2022-06-25 04:45:35.116071
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(default=30)
    Attribute(extend=True)
    Attribute(prepend=True)
    Attribute(static=True)


# Generated at 2022-06-25 04:45:40.339407
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_1 = "{rWb'F@8Wz:uy@s:w7"
    attribute_1 = Attribute(str_1)
    field_attribute_1 = FieldAttribute(attribute_1)


if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:45:43.002837
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "y2%v,t9Xr5r?Z*p:Zt"
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:45:44.038222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    t = FieldAttribute()


# Generated at 2022-06-25 04:45:45.497898
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '1<f/*G*2'
    attribute_0 = Attribute(str_0)

# Generated at 2022-06-25 04:45:48.681517
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:45:53.819766
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa=None, private=None, default=None, required=None, listof=None, priority=None, class_type=None, always_post_validate=None, inherit=True, alias=None, extend=False, prepend=False, static=False)


# Generated at 2022-06-25 04:45:57.890665
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Initialize class attribute
    isa = str
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    attribute_0 = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)



# Generated at 2022-06-25 04:45:59.362294
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute()
    except:
        pass


# Generated at 2022-06-25 04:46:06.523633
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute_0 = Attribute()
    isa = 'str'
    private = False
    default = "{rWb'F@8Wz:uy@s:w7"
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = True
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    attribute_1 = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)
    assert attribute_0 is not None
    assert attribute_1 is not None



# Generated at 2022-06-25 04:46:19.200605
# Unit test for constructor of class Attribute
def test_Attribute():
    data_0 = Attribute(
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object(),
        object()
    )

# Generated at 2022-06-25 04:46:22.478568
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:46:24.327957
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute.__init__.__doc__ != None



# Generated at 2022-06-25 04:46:29.008559
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "D+6!_y&p:z0c%jK?0$"
    attribute_0 = Fiel

# Generated at 2022-06-25 04:46:32.961795
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Check the initial state of the object
    str_0 = '{x8x'
    attribute_0 = FieldAttribute(str_0)
    assert attribute_0.isa is not None
    assert attribute_0.extend is False
    assert attribute_0.alias is None
    assert attribute_0.private is False
    assert attribute_0.prepend is False
    assert attribute_0.isa is not None
    assert attribute_0.static is False
    assert attribute_0.inherit is True
    assert attribute_0.priority is 0
    assert attribute_0.default is None
    assert attribute_0.required is False
    assert attribute_0.listof is None
    assert attribute_0.class_type is None
    assert attribute_0.always_post_validate is False


# Generated at 2022-06-25 04:46:39.783093
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    str_1 = ":6%cX9UJR|6j4(6wz!@"
    listof_0 = str_1
    str_2 = "s0B/jT`#/{e#3qxC2KA"
    isa_0 = str_2
    bool_0 = True
    bool_1 = False
    str_3 = "=fWTn(xt;i`:RLaX`$"
    alias_0 = str_3
    attribute_1 = Attribute(isa=isa_0, listof=listof_0, alias=alias_0, inherit=bool_0, private=bool_1)
    str_

# Generated at 2022-06-25 04:46:42.306023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = '4>4<|w4@+b}c%=NXH1'
    dict_0 = {}
    dict_1 = {}
    dict_0[str_0] = dict_1
    attribute_0 = Attribute(str_0)
    attribute_1 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:46:46.691743
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = FieldAttribute(str_0)


# Generated at 2022-06-25 04:46:47.571701
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_case_0()

# Generated at 2022-06-25 04:46:52.303413
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test with wrong type of parameter as isa
    try:
        str_1 = 'z'
        attribute_1 = FieldAttribute(str_1)
        assert False
    except TypeError as e:
        assert str(e) == "isa must be something found in yaml"
    # test with correct type of parameter
    str_2 = 'str'
    attribute_2 = FieldAttribute(str_2)



# Generated at 2022-06-25 04:47:11.261517
# Unit test for constructor of class Attribute
def test_Attribute():
    name = "sender"
    isa = "unicode"
    attribute = Attribute(name, isa)
    assert name == attribute.name
    assert isa == attribute.isa



# Generated at 2022-06-25 04:47:20.119386
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = ":t<!c@"
    str_1 = "&'w"
    str_2 = "&'w"
    attribute_0 = Attribute(isa=str_0)
    fieldattribute_0 = FieldAttribute(isa=str_1, private=attribute_0)
    fieldattribute_1 = FieldAttribute(isa=str_2)

if __name__ == '__main__':
    import sys
    import timer
    import types

    t = timer.Timer()

    # if '-i' in sys.argv:
    # import __builtin__
    # __builtin__.__dict__.update(locals())
    # from IPython.Shell import IPShellEmbed; IPShellEmbed(argv=[])()


# Generated at 2022-06-25 04:47:24.533349
# Unit test for constructor of class Attribute
def test_Attribute():

    try:
        Attribute()
    except TypeError as e:
        if str(e) == "__init__() missing 1 required positional argument: 'isa'":
            return
    except:
        raise AssertionError("Something went wrong")

    raise AssertionError("Something went wrong")


# Generated at 2022-06-25 04:47:35.811365
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == str_0


if __name__ == "__main__":
    import __main__
    import sys
    print('Version      :', sys.version)
    print('Python Path  :', sys.path)
    print('Version      :', sys.version)
    print('Python Path  :', sys.path)
    print('Main:', __main__.__file__)
    print('')
    for k, v in list(locals().items()):
        if k[0].islower():
            print('Test:', k)

# Generated at 2022-06-25 04:47:39.022458
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "~Owtd.pM^ ![ :'"
    attribute_0 = Attribute(str_0)
    # verify value of attribute_0.isa
    assert(isinstance(attribute_0.isa, str))


# Generated at 2022-06-25 04:47:39.834136
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    if 0:
        #default: Copy of None
        test_case_0()



# Generated at 2022-06-25 04:47:49.361272
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    # Execution of the constructor for class FieldAttribute
    # Assertion whether the constructor for class FieldAttribute
    # has executed successfully or not
    assert attribute_0.isa == str_0
    # Assertion whether the constructor for class FieldAttribute
    # has executed successfully or not
    assert attribute_0.private == False
    # Assertion whether the constructor for class FieldAttribute
    # has executed successfully or not
    assert attribute_0.default == None


# Generated at 2022-06-25 04:47:54.076432
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # TODO: Implement the constructor of class FieldAttribute
    # Test that the constructor of class FieldAttribute does not raise an exception
    assert FieldAttribute


# Generated at 2022-06-25 04:47:59.853796
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == "{rWb'F@8Wz:uy@s:w7" and attribute_0.private == False and attribute_0.default == None and attribute_0.required == False and attribute_0.listof == None and attribute_0.priority == 0 and attribute_0.class_type == None and attribute_0.always_post_validate == False and attribute_0.inherit == True and attribute_0.alias == None and attribute_0.extend == False and attribute_0.prepend == False and attribute_0.static == False


# Generated at 2022-06-25 04:48:02.297500
# Unit test for constructor of class Attribute
def test_Attribute():
    # create Attribute object
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    Attribute_0 = Attribute(str_0)
    assert Attribute_0 is not None


# Generated at 2022-06-25 04:48:38.485561
# Unit test for constructor of class Attribute
def test_Attribute():
    str = "ixD2xo&P(r;Myz:p%jE"
    try:
        attribute = Attribute(str)
    except (e):
        print("Test Case 0 FAILED: Attribute()")
    else:
        print("Test Case 0 PASS: Attribute()")


# Generated at 2022-06-25 04:48:41.075234
# Unit test for constructor of class Attribute
def test_Attribute():
    ansible_spec = Attribute(isa='list', default=[], listof='str', required=True)
    print(ansible_spec)

# Test case for Attribute class

# Generated at 2022-06-25 04:48:43.404004
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "m"
    assert Attribute(str_0) == None
    assert Attribute(str_0) != None


# Generated at 2022-06-25 04:48:44.672387
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_0 = FieldAttribute()

if __name__ == '__main__':
    test_case_0()
    test_FieldAttribute()

# Generated at 2022-06-25 04:48:48.521697
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)


# Generated at 2022-06-25 04:48:50.853275
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)

test_Attribute()

# Generated at 2022-06-25 04:48:52.004572
# Unit test for constructor of class Attribute
def test_Attribute():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:48:54.086988
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:48:57.385840
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "P'^M:n;Pe*sU6m9U6Y"
    attribute_0 = FieldAttribute(str_0)

# Generated at 2022-06-25 04:49:06.569790
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "1zQMk-7dF`O[1DyR{h*"
    bool_0 = False
    str_1 = "rWb'F@8Wz:uy@s:w7"
    str_2 = "1zQMk-7dF`O[1DyR{h*"
    str_3 = "1zQMk-7dF`O[1DyR{h*"
    str_4 = "`'P`<D`w'(Oe{z#_(|R"

# Generated at 2022-06-25 04:50:22.204640
# Unit test for constructor of class Attribute
def test_Attribute():
    # Setup and Exercise
    attribute = Attribute("isa", False, "default", True, "listof", "1", "class_type", True, False, "alias", True, True, True)

    # Verify
    assert attribute.isa == "isa"
    assert attribute.private == False
    assert attribute.default == "default"
    assert attribute.required == True
    assert attribute.listof == "listof"
    assert attribute.priority == "1"
    assert attribute.class_type == "class_type"
    assert attribute.always_post_validate == True
    assert attribute.inherit == False
    assert attribute.alias == "alias"
    assert attribute.extend == True
    assert attribute.prepend == True
    assert attribute.static == True


# Generated at 2022-06-25 04:50:30.069102
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    list_0 = [True, 1, 'error', Attribute(1), Attribute(list)]
    list_0[0] = Attribute(list_0)
    str_0 = '5m5'
    assert (not (Attribute(str_0) == Attribute(float)) and Attribute(int) != Attribute(float))



# Generated at 2022-06-25 04:50:40.797610
# Unit test for constructor of class Attribute
def test_Attribute():
    constructor_arguments = [['list', 'dict', 'set'], None, False, None, False, 0, None, False, True, None, False, False]
    attribute = Attribute(*constructor_arguments)
    assert attribute.isa == 'list'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False

test_Attribute()

# Generated at 2022-06-25 04:50:43.924858
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa == str_0

# Generated at 2022-06-25 04:50:46.518473
# Unit test for constructor of class Attribute
def test_Attribute():
    test_case_0()


# Generated at 2022-06-25 04:50:58.388936
# Unit test for constructor of class Attribute
def test_Attribute():
    # class Attribute object creation
    attribute_0 = Attribute()
    print(attribute_0.isa, attribute_0.private, attribute_0.default, attribute_0.required, attribute_0.listof, attribute_0.priority, attribute_0.class_type, attribute_0.always_post_validate, attribute_0.inherit, attribute_0.alias)
    attribute_0 = Attribute(isa='foobar')
    print(attribute_0.isa, attribute_0.private, attribute_0.default, attribute_0.required, attribute_0.listof, attribute_0.priority, attribute_0.class_type, attribute_0.always_post_validate, attribute_0.inherit, attribute_0.alias)
    attribute_0 = Attribute(isa='foobar', default='foobar')
   

# Generated at 2022-06-25 04:51:07.069884
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    str_0 = "N4p0{`H#8W$rsD?@SgS"
    Attribute_1 = attribute_0 = FieldAttribute(str_0)
    assert Attribute_1.default is None
    assert Attribute_1.required is False
    assert Attribute_1.listof is None
    assert Attribute_1.priority == 0
    assert Attribute_1.class_type is None
    assert Attribute_1.always_post_validate is False
    assert Attribute_1.inherit is True
    assert Attribute_1.alias is None
    assert Attribute_1.isa == str_0
    assert Attribute_1.private is False



# Generated at 2022-06-25 04:51:08.586058
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # attribute_0 = FieldAttribute()
    attribute_0 = FieldAttribute('list')
    assert attribute_0.isa == 'list'


# Generated at 2022-06-25 04:51:10.239996
# Unit test for constructor of class Attribute
def test_Attribute():
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)



# Generated at 2022-06-25 04:51:16.598709
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor Tests
    str_0 = "{rWb'F@8Wz:uy@s:w7"
    attribute_0 = Attribute(str_0)
    assert attribute_0.isa != None
    assert attribute_0.private != True
    assert attribute_0.default != None
    assert attribute_0.required != True
    assert attribute_0.listof != None
    assert attribute_0.class_type != None
    assert attribute_0.always_post_validate != True
    assert attribute_0.inherit != True
    assert attribute_0.alias != None