

# Generated at 2022-06-17 06:54:17.160737
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with non-default values

# Generated at 2022-06-17 06:54:25.003100
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', default='test')
    assert fa.isa == 'str'
    assert fa.default == 'test'
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 06:54:28.178969
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default=dict, required=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True


# Generated at 2022-06-17 06:54:38.927350
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:49.659129
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:54:59.795159
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:55:10.870789
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with no arguments
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with all arguments

# Generated at 2022-06-17 06:55:20.040496
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test for default values
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # test for non-default values

# Generated at 2022-06-17 06:55:30.252109
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:36.089566
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False



# Generated at 2022-06-17 06:55:50.535055
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', default=0)
    assert attr.isa == 'int'
    assert attr.default == 0
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-17 06:56:01.468775
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:56:10.567163
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='test')
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'


# Generated at 2022-06-17 06:56:20.207893
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-17 06:56:25.697689
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default=dict, required=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True


# Generated at 2022-06-17 06:56:34.399521
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:56:42.667442
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with no arguments
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with all arguments

# Generated at 2022-06-17 06:56:50.533331
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:57:00.272263
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default values
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # test non-default values

# Generated at 2022-06-17 06:57:09.347834
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default constructor
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:57:19.017846
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', default=lambda: [])
    assert f.isa == 'list'
    assert f.default() == []
    assert f.private == False
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 06:57:24.872603
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list', listof='str')
    assert fa.isa == 'list'
    assert fa.listof == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False



# Generated at 2022-06-17 06:57:38.319181
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:57:48.397741
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:00.463096
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=True, default='foo', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='str', extend=True, prepend=True, static=True)
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == 'str'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'str'
    assert a.extend == True
    assert a.prepend == True
    assert a.static == True


# Generated at 2022-06-17 06:58:10.103328
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:17.811077
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:27.974763
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=0, class_type='str', always_post_validate=False, inherit=True, alias='str', extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == 'str'
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == 'str'
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-17 06:58:36.499257
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:45.103321
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:58:57.431464
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:06.818728
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:14.355688
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:26.478737
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for the constructor of class Attribute
    # Test for the default value of the constructor
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    # Test for the value of the constructor

# Generated at 2022-06-17 06:59:33.936929
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:59:40.875210
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a.private == False


# Generated at 2022-06-17 06:59:51.432764
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', default={}, required=True, listof='str')
    assert attr.isa == 'dict'
    assert attr.default == {}
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    attr = Attribute(isa='list', default=[], required=True, listof='str')
    assert attr.isa == 'list'
    assert attr.default == []

# Generated at 2022-06-17 06:59:59.115106
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=True, default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='bar', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'foo'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == False
    assert attr.alias == 'bar'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 07:00:06.769691
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:00:18.243544
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:00:34.184813
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for constructor of class FieldAttribute
    # Expected result:
    #   Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    # Actual result:
    #   Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert FieldAttribute() == Attribute()



# Generated at 2022-06-17 07:00:40.345154
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='dict', default={})
    assert field_attribute.isa == 'dict'
    assert field_attribute.default == {}
    assert field_attribute.private == False
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False



# Generated at 2022-06-17 07:00:50.443123
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=[], required=True, listof='str')
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    attr = Attribute(isa='list', default=lambda: [], required=True, listof='str')
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr

# Generated at 2022-06-17 07:01:00.137851
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=True, default=dict(), required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'dict'
    assert attr.private == True
    assert attr.default == dict()
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False

# Generated at 2022-06-17 07:01:08.908333
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list', default=[], required=True, listof='str')
    assert fa.isa == 'list'
    assert fa.default == []
    assert fa.required == True
    assert fa.listof == 'str'
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias is None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False
    assert fa.private == False



# Generated at 2022-06-17 07:01:12.841264
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[], required=True)
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == True
    try:
        attr = FieldAttribute(isa='list', default=[1,2,3], required=True)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 07:01:25.906835
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 07:01:30.617121
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for constructor of class FieldAttribute
    # Test for isa
    try:
        FieldAttribute(isa='test')
    except TypeError:
        assert False
    # Test for private
    try:
        FieldAttribute(private=True)
    except TypeError:
        assert False
    # Test for default
    try:
        FieldAttribute(default='test')
    except TypeError:
        assert False
    # Test for required
    try:
        FieldAttribute(required=True)
    except TypeError:
        assert False
    # Test for listof
    try:
        FieldAttribute(listof='test')
    except TypeError:
        assert False
    # Test for priority
    try:
        FieldAttribute(priority=1)
    except TypeError:
        assert False
    # Test for class_type

# Generated at 2022-06-17 07:01:37.044483
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'int'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:01:45.654104
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False



# Generated at 2022-06-17 07:02:07.095541
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for the constructor of class FieldAttribute
    # Test for the default value of the constructor
    assert FieldAttribute().isa == None
    assert FieldAttribute().private == False
    assert FieldAttribute().default == None
    assert FieldAttribute().required == False
    assert FieldAttribute().listof == None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type == None
    assert FieldAttribute().always_post_validate == False
    assert FieldAttribute().inherit == True
    assert FieldAttribute().alias == None
    assert FieldAttribute().extend == False
    assert FieldAttribute().prepend == False
    assert FieldAttribute().static == False

    # Test for the value of the constructor

# Generated at 2022-06-17 07:02:14.804100
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 07:02:27.754917
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:02:35.587964
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:02:46.274590
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor
    attr = Attribute(isa='str', private=True, default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'
    assert attr.extend == True

# Generated at 2022-06-17 07:02:56.081028
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor with no arguments
    a = FieldAttribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    # Test constructor with arguments

# Generated at 2022-06-17 07:03:06.757403
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:03:12.474356
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list')
    assert fa.isa == 'list'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    fa = FieldAttribute(isa='list', private=True, default='foo', required=True, listof='bar', priority=1, class_type='baz', always_post_validate=True, inherit=False, alias='qux', extend=True, prepend=True, static=True)


# Generated at 2022-06-17 07:03:26.101357
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:03:28.367152
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=lambda: [])
    assert a.isa == 'list'
    assert a.default() == []
    try:
        a = Attribute(isa='list', default=[])
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-17 07:03:55.882172
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-17 07:04:06.666784
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='str', private=False, default='test', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.pre