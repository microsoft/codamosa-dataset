

# Generated at 2022-06-17 06:54:10.397490
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test')
    assert field.isa == 'str'
    assert field.default == 'test'


# Generated at 2022-06-17 06:54:19.068732
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default value
    assert FieldAttribute().default is None

    # Test for default value of isa
    assert FieldAttribute().isa is None

    # Test for default value of private
    assert FieldAttribute().private is False

    # Test for default value of required
    assert FieldAttribute().required is False

    # Test for default value of listof
    assert FieldAttribute().listof is None

    # Test for default value of priority
    assert FieldAttribute().priority == 0

    # Test for default value of class_type
    assert FieldAttribute().class_type is None

    # Test for default value of always_post_validate
    assert FieldAttribute().always_post_validate is False

    # Test for default value of inherit
    assert FieldAttribute().inherit is True

    # Test for default value of alias
    assert FieldAttribute().alias is None

    #

# Generated at 2022-06-17 06:54:29.987704
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # Test with non-default values

# Generated at 2022-06-17 06:54:37.819484
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-17 06:54:45.603235
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:54:54.364967
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:55:00.778939
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of class FieldAttribute
    # Test with all parameters
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'
    assert attr

# Generated at 2022-06-17 06:55:12.225674
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict')
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='dict', private=True, default=True, required=True, listof='dict', priority=1, class_type='dict', always_post_validate=True, inherit=False, alias='dict', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 06:55:21.705417
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    try:
        attr = Attribute(isa='list', default={})
        assert False
    except TypeError:
        pass
    attr = Attribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default == []

# Generated at 2022-06-17 06:55:29.792306
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', default=[], required=True, listof='str')
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = FieldAttribute(isa='list', default=[], required=True, listof='str', priority=1)
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == 'str'


# Generated at 2022-06-17 06:55:36.855591
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', default=0)
    assert attr.isa == 'int'
    assert attr.default == 0
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:55:42.126019
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test for default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # test for constructor with all parameters

# Generated at 2022-06-17 06:55:47.473349
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test constructor of class FieldAttribute
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False

# Generated at 2022-06-17 06:55:57.493074
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-17 06:56:04.224433
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-17 06:56:07.126022
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo', required=True)
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == True



# Generated at 2022-06-17 06:56:18.429350
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:56:29.942890
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:56:40.166466
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='list', default=[], required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert a.isa == 'list'

# Generated at 2022-06-17 06:56:46.978165
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:59.808446
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='list', private=True, default='test', required=True, listof='dict', priority=1, class_type='class', always_post_validate=True, inherit=False, alias='test', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 06:57:08.747081
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:14.180943
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False



# Generated at 2022-06-17 06:57:26.123859
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='foo', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='foo', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'foo'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'foo'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:57:39.166273
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    fa = FieldAttribute(isa='str', private=True, default='default', required=True,
                        listof='list', priority=1, class_type='class', always_post_validate=True,
                        inherit=False, alias='alias', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 06:57:48.985416
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 06:57:58.289024
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    assert field_attribute.static is False


# Generated at 2022-06-17 06:58:07.916122
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test non-default values

# Generated at 2022-06-17 06:58:19.196534
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:58:30.436317
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:58:43.585172
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:54.707221
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for the constructor of class FieldAttribute
    # Test for the default value of the constructor
    assert FieldAttribute().isa == None
    assert FieldAttribute().private == False
    assert FieldAttribute().default == None
    assert FieldAttribute().required == False
    assert FieldAttribute().listof == None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type == None
    assert FieldAttribute().always_post_validate == False
    assert FieldAttribute().inherit == True
    assert FieldAttribute().alias == None
    assert FieldAttribute().extend == False
    assert FieldAttribute().prepend == False
    assert FieldAttribute().static == False

    # Test for the constructor of class FieldAttribute with parameters

# Generated at 2022-06-17 06:59:02.384905
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with no parameters
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    # Test with all parameters

# Generated at 2022-06-17 06:59:11.821277
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=list)
    assert attr.isa == 'list'
    assert attr.default == list
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:59:18.878947
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=0, required=True, listof='int', priority=1)
    assert attr.isa == 'int'
    assert attr.default == 0
    assert attr.required == True
    assert attr.listof == 'int'
    assert attr.priority == 1


# Generated at 2022-06-17 06:59:26.363899
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 06:59:33.688783
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:59:43.072936
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:59:52.137159
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 07:00:01.216343
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=True, default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='foo', extend=True, prepend=True, static=True)
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == 'str'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'foo'
    assert a.extend == True
    assert a.prepend == True
    assert a.static == True


# Generated at 2022-06-17 07:00:15.971005
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:00:26.220611
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:00:32.100741
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default() == []
    try:
        attr = Attribute(isa='list', default=[])
        assert False
    except TypeError:
        pass
    attr = Attribute(isa='list', default=None)
    assert attr.default is None

# Generated at 2022-06-17 07:00:40.008731
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 07:00:50.275735
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:00:58.148393
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:01:05.472415
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:01:16.934818
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor with all parameters
    attr = FieldAttribute(
        isa='list',
        private=True,
        default=None,
        required=True,
        listof='str',
        priority=0,
        class_type='str',
        always_post_validate=True,
        inherit=False,
        alias='alias',
        extend=True,
        prepend=True,
        static=True,
    )
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True

# Generated at 2022-06-17 07:01:27.137065
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='list', default=[], required=True, listof='str', priority=1, class_type=str,
                  always_post_validate=True, inherit=False, alias='foo', extend=True, prepend=True, static=True)
    assert a.isa == 'list'


# Generated at 2022-06-17 07:01:33.189911
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=[], required=True, listof='str')
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == True
    assert attr.listof == 'str'


# Generated at 2022-06-17 07:01:56.433468
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None
    assert f.extend is False
    assert f.prepend is False
    assert f.static is False



# Generated at 2022-06-17 07:02:07.778918
# Unit test for constructor of class Attribute
def test_Attribute():
    # test default values
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    # test setting values

# Generated at 2022-06-17 07:02:15.080097
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'list'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 07:02:24.999961
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='foo')
    assert field.isa == 'str'
    assert field.default == 'foo'
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 07:02:33.704432
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='list', default=[], required=True)
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None

# Generated at 2022-06-17 07:02:44.075538
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for constructor of class FieldAttribute
    # Test for constructor with all parameters
    field_attribute = FieldAttribute(isa='str', private=True, default='default', required=True, listof='list', priority=1, class_type='class', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert field_attribute.isa == 'str'
    assert field_attribute.private == True
    assert field_attribute.default == 'default'
    assert field_attribute.required == True
    assert field_attribute.listof == 'list'
    assert field_attribute.priority == 1
    assert field_attribute.class_type == 'class'
    assert field_attribute.always_post_validate == True
    assert field_attribute.inherit == False

# Generated at 2022-06-17 07:02:52.371171
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default values
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # Test for constructor values

# Generated at 2022-06-17 07:03:02.571698
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:03:13.253975
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # Test non-default values

# Generated at 2022-06-17 07:03:24.719792
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:04:06.204209
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='int', default=0)
    assert f.isa == 'int'
    assert f.default == 0
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False
