

# Generated at 2022-06-17 06:54:15.224743
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:24.404937
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:29.021581
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field.isa == 'str'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:54:37.576458
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo')
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:54:48.344089
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='list', private=True, default='foo', required=True, listof='dict', priority=1, class_type='class',
                  always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 06:54:54.999974
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # test constructor values

# Generated at 2022-06-17 06:55:07.807005
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:55:18.972011
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    try:
        a = Attribute(isa='list', default=[1,2,3])
        assert False
    except TypeError:
        assert True
    a = Attribute(isa='list', default=lambda: [])
    assert a.default() == []
    assert a.default() == []

# Generated at 2022-06-17 06:55:26.095731
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default values
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None
    assert f.extend is False
    assert f.prepend is False
    assert f.static is False

    # Test for custom values

# Generated at 2022-06-17 06:55:36.905797
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    fa = FieldAttribute(isa='str')
    assert fa.isa == 'str'
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None

# Generated at 2022-06-17 06:55:44.942364
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:55:56.478405
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=True, default='default', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'default'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'alias'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:56:04.813771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default='foo', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static

# Generated at 2022-06-17 06:56:14.889331
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:56:25.927336
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None

    # Test constructor with default value
    attr = Attribute(isa='str', default='test')
    assert attr.default == 'test'

   

# Generated at 2022-06-17 06:56:34.373365
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:37.442082
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list', default=[], required=True)
    assert field.isa == 'list'
    assert field.default == []
    assert field.required == True


# Generated at 2022-06-17 06:56:49.287636
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:57:00.133436
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default constructor
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all arguments

# Generated at 2022-06-17 06:57:08.944727
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:21.334230
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # test all values

# Generated at 2022-06-17 06:57:29.248799
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-17 06:57:40.878205
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert f.isa == 'str'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 06:57:50.080829
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test for the constructor of class FieldAttribute
    # test for the default value of the constructor
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # test for the constructor with all the parameters

# Generated at 2022-06-17 06:57:55.973861
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test')
    assert field.isa == 'str'
    assert field.default == 'test'



# Generated at 2022-06-17 06:58:07.059808
# Unit test for constructor of class Attribute
def test_Attribute():
    # test for isa
    a = Attribute(isa='dict')
    assert a.isa == 'dict'
    a = Attribute(isa='list')
    assert a.isa == 'list'
    a = Attribute(isa='set')
    assert a.isa == 'set'
    a = Attribute(isa='str')
    assert a.isa == 'str'
    a = Attribute(isa='int')
    assert a.isa == 'int'
    a = Attribute(isa='float')
    assert a.isa == 'float'
    a = Attribute(isa='bool')
    assert a.isa == 'bool'
    a = Attribute(isa='none')
    assert a.isa == 'none'
    a = Attribute(isa='path')
    assert a.isa == 'path'

# Generated at 2022-06-17 06:58:15.178292
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', default='foo')
    assert f.isa == 'str'
    assert f.default == 'foo'
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 06:58:27.149896
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'int'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:35.184659
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', listof='str', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.listof == 'str'
    assert attr.default() == []
    assert attr.private == False
    assert attr.required == False
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:43.900668
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of class FieldAttribute
    # Test case 1: isa is None
    # Expected result: isa is None
    attr = FieldAttribute()
    assert attr.isa is None

    # Test case 2: isa is not None
    # Expected result: isa is not None
    attr = FieldAttribute(isa='list')
    assert attr.isa == 'list'

    # Test case 3: isa is not None and default is not None
    # Expected result: isa is not None and default is not None
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []

    # Test case 4: isa is not None and default is not None and default is mutable
    # Expected result: raise TypeError

# Generated at 2022-06-17 06:58:55.081364
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:59:05.349127
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test_alias', extend=True, prepend=True, static=True)
    assert a.isa == 'str'
    assert a.default == 'test'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == 'str'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'test_alias'
    assert a.extend == True
    assert a.prepend == True
    assert a.static == True


# Generated at 2022-06-17 06:59:10.118568
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='dict', default={})
    assert field.isa == 'dict'
    assert field.default == {}
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:59:24.499968
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 06:59:31.650826
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:59:39.727817
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor with no arguments
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all arguments

# Generated at 2022-06-17 06:59:50.762203
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:58.672612
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:00:09.536253
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:00:14.711815
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static

# Generated at 2022-06-17 07:00:33.965776
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default values
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 07:00:37.192751
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list', default=[])
    assert field.default == []
    assert field.isa == 'list'
    try:
        field = FieldAttribute(isa='list', default={})
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 07:00:49.040840
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='str', default='foo', required=True, listof='str', priority=1, class_type='str',
                  always_post_validate=True, inherit=False, alias='foo', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 07:00:59.166403
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert f.isa == 'str'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False



# Generated at 2022-06-17 07:01:08.291626
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    assert field_attribute.static is False



# Generated at 2022-06-17 07:01:17.117543
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default values
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # Test for non-default values

# Generated at 2022-06-17 07:01:26.991940
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='test_alias', extend=True, prepend=True, static=True)
    assert field.isa == 'str'
    assert field.default == 'test'
    assert field.required == True
    assert field.listof == 'str'
    assert field.priority == 1
    assert field.class_type == 'str'
    assert field.always_post_validate == True
    assert field.inherit == False
    assert field.alias == 'test_alias'
    assert field.extend == True
    assert field.prepend == True
    assert field.static == True


# Generated at 2022-06-17 07:01:33.349781
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[], required=True, listof='str', priority=1)
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1



# Generated at 2022-06-17 07:01:43.563398
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default='test', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static

# Generated at 2022-06-17 07:01:56.959954
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field_attribute.isa == 'list'
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False

# Generated at 2022-06-17 07:02:17.486359
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:02:29.236723
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:02:36.744626
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-17 07:02:47.367573
# Unit test for constructor of class Attribute
def test_Attribute():
    # test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # test setting values

# Generated at 2022-06-17 07:02:56.546912
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=dict(), required=True, listof='str', priority=0, class_type=dict, always_post_validate=True, inherit=False, alias='test_alias', extend=True, prepend=True, static=True)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == dict()
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == dict
    assert a.always_post_validate == True
    assert a.inherit == False
    assert a.alias == 'test_alias'
    assert a.extend == True
    assert a.prepend == True
    assert a.static == True

# Unit test

# Generated at 2022-06-17 07:03:06.602312
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:03:12.871415
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:03:25.449149
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None



# Generated at 2022-06-17 07:03:33.614549
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:03:44.757450
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test all values