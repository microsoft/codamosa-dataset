

# Generated at 2022-06-17 06:54:15.515795
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with no arguments
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with all arguments

# Generated at 2022-06-17 06:54:24.961711
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='list', private=True, default='foo', required=True, listof='dict', priority=1, class_type='class', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 06:54:34.286536
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:54:41.958741
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', default=[], required=True)
    assert f.isa == 'list'
    assert f.default == []
    assert f.required == True
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 06:54:48.437532
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:54:57.100470
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False



# Generated at 2022-06-17 06:55:02.544996
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:07.804558
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:17.912529
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-17 06:55:29.522501
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for invalid isa
    try:
        Attribute(isa='invalid')
        assert False
    except TypeError:
        pass

    # Test for invalid default
    try:
        Attribute(isa='list', default=[])
        assert False
    except TypeError:
        pass

    # Test for invalid listof
    try:
        Attribute(isa='list', listof='invalid')
        assert False
    except TypeError:
        pass

    # Test for invalid class_type
    try:
        Attribute(isa='class', class_type='invalid')
        assert False
    except TypeError:
        pass

    # Test for invalid inherit
    try:
        Attribute(inherit='invalid')
        assert False
    except TypeError:
        pass

    # Test for invalid alias

# Generated at 2022-06-17 06:55:34.818301
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for invalid default value
    try:
        FieldAttribute(default=[])
    except TypeError:
        pass
    else:
        raise AssertionError('FieldAttribute constructor did not raise TypeError for invalid default value')

    # Test for valid default value
    FieldAttribute(default=lambda: [])



# Generated at 2022-06-17 06:55:43.620561
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='foo')
    assert field.isa == 'str'
    assert field.default == 'foo'
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:55:55.833030
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    # Test case 1: isa is None
    attr = Attribute()
    assert attr.isa is None

    # Test case 2: isa is a string
    attr = Attribute(isa='str')
    assert attr.isa == 'str'

    # Test case 3: isa is a class
    class A:
        pass
    attr = Attribute(isa=A)
    assert attr.isa == A

    # Test case 4: isa is a percent
    attr = Attribute(isa='%')
    assert attr.isa == '%'

    # Test case 5: private is True
    attr = Attribute(private=True)
    assert attr.private is True

    # Test case 6: private is False

# Generated at 2022-06-17 06:55:58.265088
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[], listof='str')
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.listof == 'str'


# Generated at 2022-06-17 06:56:08.457156
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:56:15.909652
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='dict', default={})
    assert a.isa == 'dict'
    assert a.default == {}
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:26.061869
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:37.578897
# Unit test for constructor of class Attribute
def test_Attribute():
    # test that the constructor works
    a = Attribute(isa='list', private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:49.392995
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 06:56:59.982142
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:14.075359
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:26.122611
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for constructor of class Attribute
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Unit

# Generated at 2022-06-17 06:57:39.163706
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Test for valid values

# Generated at 2022-06-17 06:57:44.993926
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=0, class_type='str', always_post_validate=False, inherit=True, alias='str', extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'str'
    assert attr.extend == False

# Generated at 2022-06-17 06:57:51.645151
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='bar')
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == False
    assert attr.alias == 'bar'


# Generated at 2022-06-17 06:57:59.621138
# Unit test for constructor of class Attribute
def test_Attribute():
    class TestClass(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    attr = Attribute(isa='dict', default=dict, class_type=TestClass, always_post_validate=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.class_type == TestClass
    assert attr.always_post_validate == True

    attr = Attribute(isa='dict', default=dict, class_type=TestClass, always_post_validate=False)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.class_type == TestClass
    assert attr.always_post_validate == False

# Generated at 2022-06-17 06:58:06.976457
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False



# Generated at 2022-06-17 06:58:13.575061
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:26.703124
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []

    attr = FieldAttribute(isa='list', default=None)
    assert attr.isa == 'list'
    assert attr.default is None

    attr = FieldAttribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default() == []

    attr = FieldAttribute(isa='list', default=lambda: None)
    assert attr.isa == 'list'
    assert attr.default() is None

    attr = FieldAttribute(isa='list', default=lambda: [1, 2, 3])
    assert attr.isa == 'list'
    assert attr.default() == [1, 2, 3]



# Generated at 2022-06-17 06:58:29.273091
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[1,2,3])
    assert attr.isa == 'list'
    assert attr.default == [1,2,3]
    try:
        attr = FieldAttribute(isa='list', default=[1,2,3], extend=True)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 06:58:38.908746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default() == []
    try:
        attr = FieldAttribute(isa='list', default=[])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 06:58:45.104439
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo')
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:54.341758
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='default')
    assert attr.isa == 'str'
    assert attr.default == 'default'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:59:01.860498
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:10.862535
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test')
    assert field.isa == 'str'
    assert field.default == 'test'
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:59:20.128009
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for isa
    a = Attribute(isa='list')
    assert a.isa == 'list'
    a = Attribute(isa='dict')
    assert a.isa == 'dict'
    a = Attribute(isa='set')
    assert a.isa == 'set'
    a = Attribute(isa='int')
    assert a.isa == 'int'
    a = Attribute(isa='float')
    assert a.isa == 'float'
    a = Attribute(isa='bool')
    assert a.isa == 'bool'
    a = Attribute(isa='str')
    assert a.isa == 'str'
    a = Attribute(isa='unicode')
    assert a.isa == 'unicode'
    a = Attribute(isa='NoneType')
    assert a.isa == 'NoneType'

# Generated at 2022-06-17 06:59:29.725331
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Unit test

# Generated at 2022-06-17 06:59:34.646621
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:59:42.718049
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:59:50.747025
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field.isa == 'str'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 07:00:11.379897
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:00:19.932470
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 07:00:27.699418
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test the constructor of class FieldAttribute
    # Test with no arguments
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with all arguments

# Generated at 2022-06-17 07:00:37.642287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', default=list)
    assert a.isa == 'list'
    assert a.default == list
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = FieldAttribute(isa='list', default=list, required=True, listof='str', priority=1, class_type=str, always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert a.isa == 'list'


# Generated at 2022-06-17 07:00:48.303260
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None


# Generated at 2022-06-17 07:00:57.446715
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.private == False
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:04.460058
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='test')
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'


# Generated at 2022-06-17 07:01:14.934897
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    assert attr.private == False



# Generated at 2022-06-17 07:01:26.486957
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:01:34.482798
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list')
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:02:07.779370
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:02:15.293900
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default constructor
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # test constructor with all arguments

# Generated at 2022-06-17 07:02:25.749700
# Unit test for constructor of class Attribute
def test_Attribute():
    # test for default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # test for custom values

# Generated at 2022-06-17 07:02:31.743846
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='int', private=True, default=0, required=True, listof='int', priority=1, class_type='int', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 07:02:40.442047
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'list'
    assert a.default is None
    assert a.required is False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None


# Generated at 2022-06-17 07:02:50.138219
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', listof='dict')
    assert attr.isa == 'list'
    assert attr.listof == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    assert attr.__eq__(attr) == True
    assert attr.__ne__(attr) == False
    assert attr.__lt__(attr) == False
    assert attr.__gt

# Generated at 2022-06-17 07:02:58.935315
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-17 07:03:08.203381
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', default={})
    assert a.isa == 'dict'
    assert a.default == {}
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='dict', default={}, required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert a.isa == 'dict'

# Generated at 2022-06-17 07:03:16.129407
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that a mutable default raises an exception
    try:
        Attribute(default={})
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute constructor did not raise TypeError for mutable default')

    # Test that a callable default does not raise an exception
    try:
        Attribute(default=lambda: {})
    except TypeError:
        raise AssertionError('Attribute constructor raised TypeError for callable default')



# Generated at 2022-06-17 07:03:25.762381
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.private == False
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
