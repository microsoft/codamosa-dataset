

# Generated at 2022-06-17 06:54:15.947970
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', default=0)
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a.private == False

    a = Attribute(isa='int', default=0, required=True)
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0

# Generated at 2022-06-17 06:54:25.857397
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-17 06:54:34.894106
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor with no arguments
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

    # Test constructor with all arguments

# Generated at 2022-06-17 06:54:44.935570
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True

# Generated at 2022-06-17 06:54:54.111847
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:02.265138
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field_attribute.isa == 'str'
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False

# Generated at 2022-06-17 06:55:13.536530
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 06:55:24.514779
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo')
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False



# Generated at 2022-06-17 06:55:31.417713
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:55:38.870555
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:55:53.065403
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:03.010295
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=True, default='test', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:56:13.403008
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', default=dict, required=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:56:25.345068
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:56:31.985699
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:37.495611
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', default={})
    assert a.isa == 'dict'
    assert a.default == {}
    assert a.private == False
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:56:49.327250
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor with no arguments
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

    # Test constructor with all arguments
    attr = Attribute(isa='list', private=True, default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='bar')
    assert attr.isa == 'list'
    assert attr.private is True

# Generated at 2022-06-17 06:56:59.926757
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:08.818968
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo', required=True)
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == True
    assert a.private == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:57:17.007161
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:57:27.178621
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='default', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'default'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'alias'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:57:39.396710
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[])
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='list', default=[], required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert a.isa == 'list'

# Generated at 2022-06-17 06:57:46.780367
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a.private == False



# Generated at 2022-06-17 06:57:53.934473
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    # Test 1: isa is None
    attr = Attribute()
    assert attr.isa is None

    # Test 2: isa is a string
    attr = Attribute(isa='str')
    assert attr.isa == 'str'

    # Test 3: isa is a class
    attr = Attribute(isa=Attribute)
    assert attr.isa == Attribute

    # Test 4: isa is a percent
    attr = Attribute(isa='%')
    assert attr.isa == '%'

    # Test 5: isa is a list
    attr = Attribute(isa='list')
    assert attr.isa == 'list'

    # Test 6: isa is a dict
    attr = Attribute(isa='dict')

# Generated at 2022-06-17 06:58:04.877542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert field.isa == 'str'
    assert field.default == 'test'
    assert field.required == True
    assert field.listof == 'str'
    assert field.priority == 1
    assert field.class_type == 'str'
    assert field.always_post_validate == True
    assert field.inherit == True
    assert field.alias == 'test'
    assert field.extend == True
    assert field.prepend == True
    assert field.static == True


# Generated at 2022-06-17 06:58:11.856160
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of class FieldAttribute
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-17 06:58:24.617091
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:33.947491
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict', default=dict)
    assert fa.isa == 'dict'
    assert fa.default == dict
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 06:58:41.820170
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:58:53.825612
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:10.119267
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='bar', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'foo'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == False
    assert attr.alias == 'bar'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:59:24.496858
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=0)
    assert attr.isa == 'int'
    assert attr.default == 0
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:59:33.504850
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert att

# Generated at 2022-06-17 06:59:39.700820
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='foo')
    assert field.isa == 'str'
    assert field.default == 'foo'
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:59:51.088834
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test for custom values

# Generated at 2022-06-17 07:00:02.572265
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[], required=True, listof='str')
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    try:
        a = Attribute(isa='list', default=[], required=True, listof='str', static=True)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-17 07:00:10.632669
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None,
                        priority=0, class_type=None, always_post_validate=False, inherit=True,
                        alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'list'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 07:00:17.908720
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:00:24.397977
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:00:35.607297
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=dict(), required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == dict()
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-17 07:00:58.418626
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-17 07:01:06.940099
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list', default=[], required=True)
    assert field.isa == 'list'
    assert field.default == []
    assert field.required == True
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 07:01:13.601792
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='foo')
    assert attr.isa == 'str'
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:24.474056
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:32.852517
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default={}, required=True, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'dict'
    assert attr.default == {}
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:43.536673
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default values
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # Test for non-default values

# Generated at 2022-06-17 07:01:50.737527
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:01:58.565402
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None


# Generated at 2022-06-17 07:02:08.265724
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # Test with non-default values

# Generated at 2022-06-17 07:02:15.794821
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 07:02:48.404429
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:02:58.638663
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='alias', extend=True, prepend=True, static=True)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == False
    assert attr.alias == 'alias'
    assert attr.extend == True
    assert attr.prepend == True

# Generated at 2022-06-17 07:03:08.017026
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 07:03:14.232379
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='int', default=0, required=True)
    assert fa.isa == 'int'
    assert fa.default == 0
    assert fa.required == True


# Generated at 2022-06-17 07:03:23.648434
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:03:33.411853
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    fa = FieldAttribute(isa='str', private=True, default='foo', required=True, listof='int', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='bar', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 07:03:44.528840
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'string'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:03:52.627374
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 07:04:02.749927
# Unit test for constructor of class Attribute
def test_Attribute():
    # test constructor
    attr = Attribute(isa='str', private=True, default='test', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='test_alias')
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test_alias'

    # test constructor with invalid default

# Generated at 2022-06-17 07:04:07.860286
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='dict', default=dict, required=True)
    assert field.isa == 'dict'
    assert field.default == dict
    assert field.required == True
