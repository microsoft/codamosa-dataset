

# Generated at 2022-06-17 06:54:11.069709
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []
    try:
        attr = FieldAttribute(isa='list', default=[1,2,3])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 06:54:19.114541
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:27.703443
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False



# Generated at 2022-06-17 06:54:38.458436
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default() == []
    assert attr.private == False
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    try:
        attr = Attribute(isa='list', default=[])
        raise Exception('Attribute constructor should have raised an exception')
    except TypeError:
        pass


# Generated at 2022-06-17 06:54:46.055867
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:54:51.917345
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='str', private=False, default='test', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field_attribute.isa == 'str'
    assert field_attribute.private == False
    assert field_attribute.default == 'test'
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_

# Generated at 2022-06-17 06:54:59.950162
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', default='test')
    assert attr.isa == 'str'
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:55:11.117226
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=lambda: [])
    assert a.isa == 'list'
    assert a.default() == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='list', default=lambda: [], required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=False, alias='test', extend=True, prepend=True, static=True)
    assert a.isa

# Generated at 2022-06-17 06:55:20.179587
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all arguments

# Generated at 2022-06-17 06:55:28.278934
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False
