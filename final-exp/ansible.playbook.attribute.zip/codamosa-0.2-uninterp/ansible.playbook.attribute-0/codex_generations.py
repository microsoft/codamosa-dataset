

# Generated at 2022-06-17 06:54:15.329210
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:24.671014
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:54:29.319586
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:54:37.630408
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=[], required=True)
    assert a.isa == 'list'
    assert a.default == []
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    b = Attribute(isa='list', default=lambda: [], required=True)
    assert b.isa == 'list'
    assert b.default == []
    assert b.required == True
    assert b.listof == None
    assert b.priority == 0
    assert b.class_type

# Generated at 2022-06-17 06:54:48.416127
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-17 06:54:58.486365
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-17 06:55:05.285302
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:55:15.964452
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:26.954310
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:55:38.340519
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a.private == False


# Generated at 2022-06-17 06:55:52.968974
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', default=[], listof='str')
    assert attr.isa == 'list'
    assert attr.default == []
    assert attr.listof == 'str'
    assert attr.private == False
    assert attr.required == False
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 06:56:02.760407
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for constructor of class FieldAttribute
    attr = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 06:56:13.629287
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=None, required=True, listof='str', priority=0, class_type='str', always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == None
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == 'str'
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False


# Generated at 2022-06-17 06:56:25.438970
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False

# Generated at 2022-06-17 06:56:32.231397
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of class FieldAttribute
    # isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
   

# Generated at 2022-06-17 06:56:42.490123
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=True, default='test', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True, alias='test', extend=True, prepend=True, static=True)
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == 'test'
    assert attr.extend == True
    assert attr.prepend == True


# Generated at 2022-06-17 06:56:52.755098
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='int', default=0)
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    b = FieldAttribute(isa='int', default=0, required=True)
    assert b.isa == 'int'
    assert b.default == 0
    assert b.required == True
    assert b.listof == None
    assert b.priority == 0
    assert b.class_type == None

# Generated at 2022-06-17 06:57:01.262998
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='foo')
    assert field.isa == 'str'
    assert field.default == 'foo'
    assert field.private == False
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:57:13.262374
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:57:25.830656
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:57:39.305143
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all parameters

# Generated at 2022-06-17 06:57:49.062625
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test non-default values

# Generated at 2022-06-17 06:58:00.549366
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='test', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'test'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:09.896809
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field.isa == 'string'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False


# Generated at 2022-06-17 06:58:19.956870
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:30.717455
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='list', default=['foo'])
    assert a.isa == 'list'
    assert a.default == ['foo']
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None


# Generated at 2022-06-17 06:58:41.292932
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:58:48.556434
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 06:58:58.845681
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for isa
    a = Attribute(isa='list')
    assert a.isa == 'list'
    a = Attribute(isa='dict')
    assert a.isa == 'dict'
    a = Attribute(isa='set')
    assert a.isa == 'set'
    a = Attribute(isa='str')
    assert a.isa == 'str'
    a = Attribute(isa='int')
    assert a.isa == 'int'
    a = Attribute(isa='bool')
    assert a.isa == 'bool'
    a = Attribute(isa='float')
    assert a.isa == 'float'
    a = Attribute(isa='complex')
    assert a.isa == 'complex'
    a = Attribute(isa='none')
    assert a.isa == 'none'

# Generated at 2022-06-17 06:59:08.205373
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    a = Attribute(isa='list', private=True, default='foo', required=True, listof='str', priority=1, class_type='foo', always_post_validate=True, inherit=False, alias='bar')
    assert a.isa == 'list'
    assert a.private is True
    assert a.default == 'foo'
    assert a.required is True
    assert a.listof == 'str'


# Generated at 2022-06-17 06:59:19.848432
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test valid values for isa
    Attribute(isa='dict')
    Attribute(isa='list')
    Attribute(isa='set')
    Attribute(isa='string')
    Attribute(isa='int')
    Attribute(isa='bool')
    Attribute(isa='float')
    Attribute(isa='complex')
    Attribute(isa='dict')
    Attribute(isa='list')
    Attribute(isa='set')
    Attribute(isa='frozenset')
    Attribute(isa='tuple')
    Attribute(isa='unicode')
    Attribute(isa='bytes')
    Attribute(isa='bytearray')
    Attribute(isa='memoryview')
    Attribute(isa='NoneType')
    Attribute(isa='type')
    Attribute(isa='object')


# Generated at 2022-06-17 06:59:29.621070
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test that the constructor of class FieldAttribute works correctly
    # with all the arguments
    field_attribute = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert field_attribute.isa == 'str'
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_

# Generated at 2022-06-17 06:59:32.981465
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list', default=[])
    assert field.isa == 'list'
    assert field.default == []
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False



# Generated at 2022-06-17 06:59:40.706021
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-17 06:59:51.304135
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # Test for non-default values

# Generated at 2022-06-17 06:59:57.940813
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default values
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    # test constructor with all parameters

# Generated at 2022-06-17 07:00:07.195736
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='int', default=0)
    assert a.isa == 'int'
    assert a.default == 0

    a = FieldAttribute(isa='int', default=0, required=True)
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == True

    a = FieldAttribute(isa='int', default=0, required=True, listof='int')
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == True
    assert a.listof == 'int'

    a = FieldAttribute(isa='int', default=0, required=True, listof='int', priority=1)
    assert a.isa == 'int'
    assert a.default == 0
    assert a.required == True
    assert a.listof

# Generated at 2022-06-17 07:00:18.269922
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with no arguments
    field_attribute = FieldAttribute()
    assert field_attribute.isa == None
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False

    # Test with all arguments

# Generated at 2022-06-17 07:00:26.412638
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:00:36.632188
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with default values
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False

    # Test with non-default values

# Generated at 2022-06-17 07:00:50.872207
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:01:00.453168
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor with no arguments
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test constructor with all arguments

# Generated at 2022-06-17 07:01:07.390620
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:13.975671
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of class FieldAttribute
    # Test default value of isa
    attr = FieldAttribute()
    assert attr.isa is None

    # Test default value of private
    assert attr.private is False

    # Test default value of default
    assert attr.default is None

    # Test default value of required
    assert attr.required is False

    # Test default value of listof
    assert attr.listof is None

    # Test default value of priority
    assert attr.priority == 0

    # Test default value of class_type
    assert attr.class_type is None

    # Test default value of always_post_validate
    assert attr.always_post_validate is False

    # Test default value of inherit
    assert attr.inherit is True

    # Test default value of alias

# Generated at 2022-06-17 07:01:18.997500
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-17 07:01:29.500268
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    fa = FieldAttribute(isa='string', private=True, default='foo', required=True, listof='string',
                        priority=1, class_type='string', always_post_validate=True, inherit=False,
                        alias='bar', extend=True, prepend=True, static=True)

# Generated at 2022-06-17 07:01:37.776050
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list')
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-17 07:01:44.138007
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='string', default='foo')
    assert f.isa == 'string'
    assert f.default == 'foo'
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False

    # test that we can't set a mutable default
    try:
        f = FieldAttribute(isa='list', default=[])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-17 07:01:57.154231
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 07:02:07.841573
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False

    assert Attribute(isa='str').isa == 'str'
    assert Attribute(private=True).private is True
    assert Attribute(default='default').default == 'default'
    assert Attribute(required=True).required is True

# Generated at 2022-06-17 07:02:25.651153
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert f.isa == 'list'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 07:02:31.636753
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False


# Generated at 2022-06-17 07:02:43.331249
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=None, required=True, listof='str')
    assert attr.isa == 'list'
    assert attr.default is None
    assert attr.required is True
    assert attr.listof == 'str'

    attr = Attribute(isa='list', default=None, required=True, listof='str', static=True)
    assert attr.isa == 'list'
    assert attr.default is None
    assert attr.required is True
    assert attr.listof == 'str'
    assert attr.static is True

    attr = Attribute(isa='list', default=None, required=True, listof='str', static=False)
    assert attr.isa == 'list'
    assert attr.default is None

# Generated at 2022-06-17 07:02:50.386274
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', default=dict, required=True, listof='str', priority=1, class_type=dict, always_post_validate=True, inherit=True, alias='test_alias')
    assert a.isa == 'dict'
    assert a.default == dict
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == dict
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'test_alias'


# Generated at 2022-06-17 07:02:59.344498
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with no arguments
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    # Test with all arguments

# Generated at 2022-06-17 07:03:06.440643
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    attr = Attribute(isa='list', default=lambda: [], required=True)
    assert attr.isa == 'list'
    assert attr.default() == []
    assert attr.required == True

    # Test constructor of class Attribute with mutable default
    try:
        attr = Attribute(isa='list', default=[], required=True)
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute constructor did not raise TypeError for mutable default')

# Generated at 2022-06-17 07:03:14.181629
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert f.isa == 'list'
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False


# Generated at 2022-06-17 07:03:23.894380
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default='foo', required=True, listof='str', priority=1, class_type='str', always_post_validate=True, inherit=True, alias='bar')
    assert a.isa == 'str'
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == 'str'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'bar'



# Generated at 2022-06-17 07:03:33.437113
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for constructor of class Attribute
    attr = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-17 07:03:44.528282
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', default=dict, required=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
