

# Generated at 2022-06-11 09:36:04.916931
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    >>> a = Attribute()
    '''


# Generated at 2022-06-11 09:36:12.463319
# Unit test for constructor of class Attribute
def test_Attribute():
    class MyClass(object):
        def __init__(self, my_setup_param):
            self.my_setup_param = my_setup_param

    my_attribute = Attribute(isa='list', listof='dict', default=lambda: [{'foo': 'bar'}], class_type=MyClass)
    # This is the same as:
    # my_attribute = Attribute(isa='list', listof='dict',
    #                          default=lambda: [{'foo': 'bar'}],
    #                          class_type=MyClass(my_setup_param='my_value'))

    my_class = my_attribute.class_type('my_value')
    assert isinstance(my_class, MyClass)
    assert not isinstance(my_class, Attribute)

# Generated at 2022-06-11 09:36:19.770034
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert not a.private
    assert a.default == None
    assert not a.required
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert not a.always_post_validate
    assert a.inherit
    assert a.alias == None
    assert not a.extend
    assert not a.prepend
    assert not a.static


# Generated at 2022-06-11 09:36:27.468169
# Unit test for constructor of class Attribute
def test_Attribute():

    # If a string is passed in for the isa parameter
    field = Attribute(isa='str')
    assert field.isa == 'str', 'Attribute constructor failed for isa as string'

    # If a class is passed in for the isa parameter
    field = Attribute(isa=Attribute)
    assert field.isa == Attribute, 'Attribute constructor failed for isa as class'

    # If the listof parameter isa 'str'
    field = Attribute(isa='list', listof='str')
    assert field.isa == 'list', 'Attribute constructor failed for isa as string and isa as string'
    assert field.listof == 'str', 'Attribute constructor failed for isa as string and isa as string'

    # If the listof parameter is a class
    field = Attribute(isa='list', listof=Attribute)

# Generated at 2022-06-11 09:36:28.173772
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='dict')

# Generated at 2022-06-11 09:36:32.023815
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for failed construction
    try:
        field = FieldAttribute(isa='list', default='default')
    except TypeError:
        assert True
    field = FieldAttribute(isa='list', default=lambda: 'default')
    assert field.isa == 'list' and field.default() == 'default'


# Generated at 2022-06-11 09:36:38.505238
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', default=10, required=False)

    assert attr.isa == 'int'
    assert attr.private is False
    assert attr.default == 10
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None



# Generated at 2022-06-11 09:36:50.203399
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None,
                       always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-11 09:37:00.124736
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class TestClass:
        a = FieldAttribute()
        b = FieldAttribute(isa='str')
        c = FieldAttribute(isa='list', listof='str')
        d = FieldAttribute(isa='list', listof='list of str')
        e = FieldAttribute(isa='str')
        f = FieldAttribute()
        g = FieldAttribute(isa='str', default='test')
        h = FieldAttribute(isa='str', default=['test'])
        i = FieldAttribute(isa='str', default='test', listof=True)
        j = FieldAttribute(isa='str', default='test', listof='str')
        k = FieldAttribute(isa='str', default='test', listof='list')


# Generated at 2022-06-11 09:37:01.468801
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test = FieldAttribute()

FieldAttribute = FieldAttribute



# Generated at 2022-06-11 09:37:12.460506
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', default=4)
    assert(a.isa == 'str')
    assert(a.private == False)
    assert(a.default == 4)
    assert(a.required == False)
    assert(a.listof == None)
    assert(a.priority == 0)
    assert(a.class_type == None)
    assert(a.always_post_validate == False)
    assert(a.inherit == True)
    assert(a.alias == None)
    assert(a.extend == False)
    assert(a.prepend == False)
    assert(a.static == False)

# Tests for all of the comparisons

# Generated at 2022-06-11 09:37:13.081598
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()



# Generated at 2022-06-11 09:37:20.320810
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import sys
    myfieldattr = FieldAttribute(
        isa='list',
        private=False,
        default=sys.stdout,
        required=False,
        listof=('str',),
        priority=0,
        class_type=False,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
        )
    test_result = True
    if not isinstance(myfieldattr, FieldAttribute):
        test_result = False
    if myfieldattr.isa != 'list':
        test_result = False
    if myfieldattr.private != False:
        test_result = False
    if myfieldattr.default != sys.stdout:
        test_result = False

# Generated at 2022-06-11 09:37:29.823940
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='bool')
    assert a.isa == 'bool'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    a = Attribute(isa='bool', private=False, required=False, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'bool'
   

# Generated at 2022-06-11 09:37:30.753972
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute()



# Generated at 2022-06-11 09:37:38.352877
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    field = FieldAttribute()
    assert field != None

    # test fiel attribute isa
    field = FieldAttribute(isa='string')
    assert field.isa == 'string'

    # test field attribute private
    field = FieldAttribute(private=True)
    assert field.private == True

    # test field attribute required
    field = FieldAttribute(required=True)
    assert field.required == True

    # test field attribute default
    field = FieldAttribute(default='test string')
    assert field.default == 'test string'

    # test field attribute priority
    field = FieldAttribute(priority=5)
    assert field.priority == 5

    # test field attribute class_type and required
    field = FieldAttribute(class_type=FieldAttribute, required=True)
    assert field.class_type == FieldAttribute and field.required

# Generated at 2022-06-11 09:37:43.354734
# Unit test for constructor of class Attribute
def test_Attribute():
    #  default = None,
    #, required = False,
    #     listof = None, priority = 0,
    #     class_type = None, always_post_validate = False,
    #     inherit = True, alias = None):
    import pytest
    with pytest.raises(TypeError):
        Attribute(default=set())
    Attribute(default=set, isa='set')
    Attribute(isa='set')

# Generated at 2022-06-11 09:37:44.732364
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(default="foo").default == "foo"



# Generated at 2022-06-11 09:37:47.231785
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    A = Attribute()
    # pass the initialization into FieldAttribute
    B = FieldAttribute(**A.__dict__)


# Generated at 2022-06-11 09:37:56.165507
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    db = FieldAttribute(class_type='network_os', isa='list', default=[])
    assert db.class_type == 'network_os'
    assert db.isa == 'list'
    assert db.default == []
    assert db.required == False
    assert db.listof == None
    assert db.priority == 0
    assert db.always_post_validate == False
    assert db.inherit == True
    assert db.alias == None
    assert db.extend == False
    assert db.prepend == False
    assert db.static == False

# Generated at 2022-06-11 09:38:09.197553
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        alias='alias_attr',
        isa='str',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=10,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.required
    assert attr.alias == 'alias_attr'
    assert attr.priority == 10
    assert attr.__eq__(attr)
    assert attr.__ne__(attr)
    assert attr.__lt__(attr)
    assert attr.__gt__(attr)
    assert attr.__le__(attr)

# Generated at 2022-06-11 09:38:09.856825
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute()

# Generated at 2022-06-11 09:38:20.497198
# Unit test for constructor of class Attribute
def test_Attribute():
    # test default values
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False

    # test setting values
    a = Attribute(isa="str", private=True, default='test', required=True,
                  listof="bool", priority=1, class_type=str,
                  always_post_validate=True,
                  inherit=False, alias="test", extend=True, prepend=True)

# Generated at 2022-06-11 09:38:27.242236
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    b = Attribute(isa='string')
    c = Attribute(isa='string', default='default')
    d = Attribute(isa='string', default='default', inherit=False)
    e = Attribute(isa='list', listof='string')

    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    assert b.isa == 'string'
    assert b.private is False
    assert b.default is None
    assert b.required is False

# Generated at 2022-06-11 09:38:31.570614
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute(isa = 'str', private = False, default = 'hello', required = False, listof = 'str', \
                   priority = 0, class_type = None, always_post_validate = False, inherit = True, alias = 'a1')
    assert a1.isa == 'str'
    assert a1.private == False
    assert a1.default == 'hello'
    assert a1.required == False
    assert a1.listof == 'str'
    assert a1.priority == 0
    assert a1.class_type == None
    assert a1.always_post_validate == False
    assert a1.inherit == True
    assert a1.alias == 'a1'


# Generated at 2022-06-11 09:38:35.571894
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    b = Attribute(isa = 'list')
    c = Attribute(default = 'a string', listof = 'str')
    assert a
    assert b
    assert c

# Generated at 2022-06-11 09:38:36.123329
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor of class Attribute
    Attribute()



# Generated at 2022-06-11 09:38:38.756933
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

# Generated at 2022-06-11 09:38:46.560020
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Case 1 : The default value for the key is 'default'
    FieldAttribute_test1 = FieldAttribute(
        isa = 'dict',
        default = {
            "test_key" : "test_val"
        },
    )

    assert FieldAttribute_test1.default["test_key"] == "test_val"

    # Case 2 : The default value for the key is 'default' which is a dictionary
    FieldAttribute_test2 = FieldAttribute(
        isa = 'dict',
        default = {
            "test_key" : {
                "test_key2" : "test_val2"
            }
        },
    )

    assert FieldAttribute_test2.default["test_key"]["test_key2"] == "test_val2"

#test_FieldAttribute()



# Generated at 2022-06-11 09:38:50.410398
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', required=True)
    assert isinstance(attr, FieldAttribute)
    assert attr.isa == 'int'
    assert attr.required is True


# Generated at 2022-06-11 09:39:03.709743
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority is 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa="test", private=True, default="test",
                  required=True, listof="test", priority=0,
                  class_type="test", always_post_validate=True,
                  inherit=False, alias="test", extend=True,
                  prepend=True, static=True)


# Generated at 2022-06-11 09:39:12.977287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa=int,
        private=True,
        default=42,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.isa is int
    assert attr.private is True
    assert attr.default == 42
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None


# Generated at 2022-06-11 09:39:23.405705
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa=int, default=42)
    assert f1.isa == int
    assert f1.default == 42
    assert f1.private is False
    assert f1.required is False
    assert f1.listof is None
    assert f1.priority == 0
    assert f1.class_type is None
    assert f1.always_post_validate is False
    assert f1.inherit is True
    assert f1.alias is None
    assert f1.extend is False
    assert f1.prepend is False
    assert f1.static is False


# Generated at 2022-06-11 09:39:28.229195
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert not a.private
    assert a.default is None
    assert not a.required
    assert a.listof is None
    assert a.priority is 0
    assert a.class_type is None
    assert not a.always_post_validate
    assert a.inherit
    assert a.alias is None



# Generated at 2022-06-11 09:39:33.096905
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute()
    f2 = FieldAttribute(default='hello')
    f3 = FieldAttribute(default='hello', required=True)
    assert f1.default is None
    assert f2.default == 'hello'
    assert f2.required is False
    assert f3.default == 'hello'
    assert f3.required is True



# Generated at 2022-06-11 09:39:44.516272
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False


# Generated at 2022-06-11 09:39:55.473082
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def create_valid_FieldAttribute():
        return FieldAttribute(isa='dict')

    def create_valid_FieldAttribute_from_init():
        def create_valid_FieldAttribute():
            return FieldAttribute(isa='dict')
        create_valid_FieldAttribute()

    def create_valid_FieldAttribute_from_init_from_another_init():
        def create_valid_FieldAttribute():
            return FieldAttribute(isa='dict')
        def create_valid_FieldAttribute_from_init():
            def create_valid_FieldAttribute():
                return FieldAttribute(isa='dict')
            create_valid_FieldAttribute()
        create_valid_FieldAttribute_from_init()

    def create_invalid_FieldAttribute():
        return FieldAttribute(isa='something else')


# Generated at 2022-06-11 09:40:02.766690
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr = Attribute(isa='str', default='test', required=True, priority=20, class_type=None, inherit=True, alias='test_alias')

    assert test_attr.isa == 'str'
    assert test_attr.default == 'test'
    assert test_attr.required == True
    assert test_attr.priority == 20
    assert test_attr.class_type == None
    assert test_attr.alias == 'test_alias'


# Generated at 2022-06-11 09:40:13.121279
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.module_utils.common.validation import check_type_ompound

    attrib = FieldAttribute('dict',default=dict(),extend=True)
    assert attrib.isa == 'dict'
    assert attrib.default == dict()
    assert attrib.extend == True

    attrib = FieldAttribute('dict',default='dict',extend=True)
    assert attrib.isa == 'dict'
    assert attrib.default == dict()
    assert attrib.extend == True

    attrib = FieldAttribute('dict',default=[],extend=True,listof='bool')
    assert attrib.isa == 'dict'
    assert attrib.default == dict()
    assert attrib.listof == 'bool'
    assert attrib.extend == True


# Generated at 2022-06-11 09:40:16.659296
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils.six import PY3

    if not PY3:
        reload(Attribute)

    assert Attribute(isa='str', default='default', required=True, class_type=str)



# Generated at 2022-06-11 09:40:30.626858
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(True)
    assert fa.private == False
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False
    # Test for isa
    assert fa.isa == True
    # Test for private
    fa = FieldAttribute(private=True)
    assert fa.private == True
    # Test for required
    fa = FieldAttribute(required=True)
    assert fa.required == True
    # Test for listof
    fa = FieldAttribute(listof=True)
    assert fa.listof == True
    # Test for priority
    fa = FieldAttribute(priority=1)
    assert fa.priority == 1
    # Test for extend

# Generated at 2022-06-11 09:40:35.906263
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', private=False, default=None, required=False,
                       listof=None, priority=0, class_type=None,
                       always_post_validate=False, inherit=True, alias=None,
                       extend=False, prepend=False, static=False)
    assert a

# FieldAttribute class doesn't have any method for comparison, it is then
# using the comparison operators of Attribute

# Generated at 2022-06-11 09:40:37.619655
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(
        private=True,
    )
    assert attribute.private == True

# Generated at 2022-06-11 09:40:38.951899
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute != None


# Generated at 2022-06-11 09:40:41.253334
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(default=True)
    # Test success
    assert attribute
    # Test object is of correct type
    assert isinstance(attribute, FieldAttribute)

# Generated at 2022-06-11 09:40:42.908139
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='bool')
    assert f.isa == 'bool'



# Generated at 2022-06-11 09:40:53.364569
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    kw = dict(isa='list',
              private=True,
              default=[1, 2, 3],
              required=True,
              listof='int',
              priority=2,
              class_type=int,
              always_post_validate=True,
              inherit=True,
              alias='field_attr',
              extend=False,
              prepend=False)

    fa = FieldAttribute(**kw)

    assert fa.isa == 'list'
    assert fa.private == True
    assert fa.default == [1, 2, 3]
    assert fa.required == True
    assert fa.listof == 'int'
    assert fa.priority == 2
    assert fa.class_type == int
    assert fa.always_post_validate == True
    assert fa.inherit == True
    assert fa.alias

# Generated at 2022-06-11 09:40:54.394835
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(isa='list', default=[1, 2, 3])
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 09:41:05.019113
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # try to initialize the constructor
    field_attribute = FieldAttribute()

    # try to initialize the constructor with parameters
    f_a = FieldAttribute(private=True, default=1, required=True, listof="dict",
        priority=0, class_type=None, always_post_validate=False,
        inherit=True, alias="alias_Field_Attribute", extend=False, prepend=False,
        static=False)

    assert type(f_a) == FieldAttribute, "Invalid object type"
    assert f_a.private == True, "Invalid value"
    assert f_a.default == 1, "Invalid value"
    assert f_a.required == True, "Invalid value"
    assert f_a.listof == "dict", "Invalid value"
    assert f_a.priority == 0, "Invalid value"
   

# Generated at 2022-06-11 09:41:12.101165
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-11 09:41:31.892383
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible.base.exceptions as exceptions
    a = Attribute(isa='list', default=False)
    assert a.isa == 'list'
    assert a.default == False
    assert a.required == False

    a = Attribute(isa='list', default=False, required=True)
    assert a.isa == 'list'
    assert a.default == False
    assert a.required == True

    a = Attribute(isa='list', default=False, required=True, listof=True)
    assert a.isa == 'list'
    assert a.default == False
    assert a.required == True
    assert a.listof == True

    a = Attribute(isa='list', default=False, required=True, listof='str')
    assert a.isa == 'list'
    assert a.default == False


# Generated at 2022-06-11 09:41:44.252940
# Unit test for constructor of class Attribute
def test_Attribute():
    #
    # OK the unit test
    #
    class ClassAttribute(Attribute):
        pass

    good_attr = ClassAttribute(isa='int')
    assert good_attr.isa == 'int'
    assert good_attr.private is False
    assert good_attr.default is None
    assert good_attr.required is False
    assert good_attr.listof is None
    assert good_attr.priority == 0
    assert good_attr.class_type is None
    assert good_attr.always_post_validate is False
    assert good_attr.inherit is True
    assert good_attr.alias is None

    legacy_attr = ClassAttribute('int', False, None, False, None, 1, None, False, True, None, True)
    assert legacy_attr.isa == 'int'
    assert legacy_attr.private

# Generated at 2022-06-11 09:41:49.386584
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr = Attribute(
        isa='str',
        private=False,
        default='test_default',
        required=True,
        listof=None,
        priority=0,
    )

    assert(test_attr.isa == 'str')
    assert(test_attr.private == False)
    assert(test_attr.default == 'test_default')
    assert(test_attr.required == True)
    assert(test_attr.listof is None)
    assert(test_attr.priority == 0)



# Generated at 2022-06-11 09:41:53.061222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    exitcode = 0

    try:
        a = FieldAttribute(isa='list', default=[])
    except:
        exitcode = 1

    try:
        b = FieldAttribute(isa='list', default=list)
    except:
        exitcode = 2

    try:
        c = FieldAttribute(isa='list', default={})
    except TypeError:
        exitcode = 0

    return exitcode



# Generated at 2022-06-11 09:42:04.375306
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest

    # Will work
    test = FieldAttribute()
    test = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )

    # Will fail
    with pytest.raises(TypeError):
        test = FieldAttribute(
            isa=None,
            private=False,
            default="this is a test",
            required=False,
            listof=None,
            priority=0,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None
        )



# Generated at 2022-06-11 09:42:14.975176
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    
    attr = Attribute(isa="size")
    assert attr.isa == "size"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0


# Generated at 2022-06-11 09:42:26.330905
# Unit test for constructor of class Attribute
def test_Attribute():
    empty = Attribute()
    assert empty.isa is None
    assert empty.private is False
    assert empty.default is None
    assert empty.required is False
    assert empty.listof is None
    assert empty.priority == 0
    assert empty.class_type is None
    assert empty.always_post_validate is False
    assert empty.inherit is True
    assert empty.alias is None

    default = Attribute(isa='dict', private=False, default=dict, required=True, listof='str', priority=1)
    assert default.isa == 'dict'
    assert default.private is False
    assert default.default is dict
    assert default.required is True
    assert default.listof == 'str'
    assert default.priority == 1
    assert default.class_type is None
    assert default.always_post

# Generated at 2022-06-11 09:42:36.732544
# Unit test for constructor of class Attribute
def test_Attribute():
    import os
    import tempfile

    # Test no default value, no type
    a = Attribute()
    assert a.isa is None
    assert a.default is None

    # Test no default value, string type
    a = Attribute(isa='str')
    assert a.isa is None
    assert a.default is None

    # Test no default value, file type
    a = Attribute(isa='file')
    assert a.isa is None
    assert a.default is None

    # Test no default value, float type
    a = Attribute(isa='float')
    assert a.isa is None
    assert a.default is None

    # Test default value, no type
    default_value = "default_value"
    a = Attribute(default=default_value)
    assert a.isa is None
    assert a.default

# Generated at 2022-06-11 09:42:44.815298
# Unit test for constructor of class Attribute
def test_Attribute():

    # no error when using list or dict as default value. 
    # see https://github.com/ansible/ansible/issues/13921
    # and https://github.com/ansible/ansible/issues/13963 
    Attribute(isa='list', default=[])
    Attribute(isa='dict', default={})
    Attribute(isa='set', default=set())
    try: 
        Attribute(isa='list')
    except TypeError:
        pass
    else:
        raise AssertionError('Default value required for immutable type')
    try: 
        Attribute(isa='dict')
    except TypeError:
        pass
    else:
        raise AssertionError('Default value required for immutable type')

# Generated at 2022-06-11 09:42:51.560784
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa="dict")
    expected = {"isa": "dict", "private": False, "default": None, "required": False, "listof": None, "priority": 0,
                "class_type": None, "always_post_validate": False, "extend": False, "prepend": False, "static": False}
    assert dict(attribute.__dict__) == expected


# Generated at 2022-06-11 09:43:22.333774
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    field1 = FieldAttribute(isa='bool',
                            private=False,
                            default=None,
                            required=False,
                            listof=None,
                            priority=0,
                            class_type=None,
                            always_post_validate=False,
                            inherit=True,
                            alias=None,
                            extend=False)
    assert field == field1
    assert field.isa == field1.isa
    assert field.private == field1.private
    assert field.default == field1.default
    assert field.required == field1.required
    assert field.listof == field1.listof
    assert field.priority == field1.priority
    assert field.class_type == field1.class_type
    assert field.always_post_validate == field

# Generated at 2022-06-11 09:43:25.639983
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(isa='int', default=10)


# a custom keyword that can be defined by plugins or modules to affect the
# behavior of parameters passed to them.  For instance, to provide warnings
# or deprecations.


# Generated at 2022-06-11 09:43:27.410401
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa='dict', static=True)
    assert attribute_1.isa == 'dict'
    assert attribute_1.static == True



# Generated at 2022-06-11 09:43:36.663008
# Unit test for constructor of class Attribute
def test_Attribute():
    class Foo(object):
        def __init__(self, bar=None):
            pass

    from ansible.utils import module_docs
    from ansible.utils.module_docs import FieldInclude

    x = Attribute(isa='list', default=[1,2,3], listof='int')
    assert x.isa == 'list'
    assert x.default == [1,2,3]
    assert x.listof == 'int'

    # test inheritance:
    y = Attribute(isa='int', default=7, required=True, inherit=False)
    z = Attribute(isa='int', default=9, required=True, inherit=True)
    assert y.isa == 'int'
    assert y.default == 7
    assert y.required == True
    assert y.inherit == False
    assert z

# Generated at 2022-06-11 09:43:39.733429
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a = FieldAttribute(isa='dict', default='foo')
    except Exception as e:
        print(e)
        assert isinstance(e, TypeError)
    else:
        assert False, 'test_FieldAttribute FAILED'

# Generated at 2022-06-11 09:43:48.894188
# Unit test for constructor of class Attribute
def test_Attribute():
    test = Attribute(isa='list', default=[])
    assert isinstance(test.default, list)
    try:
        test = Attribute(isa='list', default={'a': 'b'})
        assert False, "Mutable default should fail"
    except TypeError as e:
        assert "defaults for FieldAttribute may not be mutable" in str(e)
    test = Attribute(isa='list', default=(3, 4))
    assert isinstance(test.default, tuple)
    test = Attribute(isa='list', default=set(['test']))
    assert isinstance(test.default, set)
    test = Attribute(isa='list', default=set(['test']))
    assert isinstance(test.default, set)

# Generated at 2022-06-11 09:43:50.926308
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa='bool',
        private=False
    )
    assert attr.isa == 'bool'

# Generated at 2022-06-11 09:43:55.737944
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    foo = FieldAttribute(isa='list',
                         private=False,
                         default=None,
                         required=False,
                         listof=None,
                         priority=0,
                         class_type=None,
                         always_post_validate=False,
                         inherit=True,
                         alias=None,
                         extend=False,
                         prepend=False,
                         static=False)
    assert foo


# Generated at 2022-06-11 09:43:56.495977
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-11 09:44:04.302973
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute(isa='bool', default=True, required=True)
    x = FieldAttribute(isa='int', default=10, static=True)
    x = FieldAttribute(isa='str', default='hello')
    x = FieldAttribute(isa='list', default=['a', 'b', 'c'])
    x = FieldAttribute(isa='dict', default={'a':'b', 'c':'d'})
    x = FieldAttribute(isa='float', default=1.0)
    x = FieldAttribute(isa='percent', default=0.97)
    x = FieldAttribute(isa='bool', default=False, required=True)

# Generated at 2022-06-11 09:44:44.433641
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='bar', private=True)
    assert a.isa == 'bar'
    assert a.private == True


# used to make a copy of an attribute - this actually creates class objects
attribute_class_cache = {}

# Generated at 2022-06-11 09:44:49.563268
# Unit test for constructor of class Attribute
def test_Attribute():

    def default_generated():
        return {}

    try:
        aa = Attribute(isa="dict")
        assert False, "should have raised an exception"
    except TypeError:
        pass

    aa = Attribute(isa="dict", default=default_generated)
    assert aa.isa == "dict", "isa should be 'dict'"
    assert aa.default() == {}, "default should be dict"


fieldattribute = FieldAttribute


# Generated at 2022-06-11 09:44:59.938725
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    FA = FieldAttribute

    # test default construction
    default_attribute = FA()
    assert(default_attribute.isa is None)
    assert(default_attribute.private is False)
    assert(default_attribute.default is None)
    assert(default_attribute.required is False)
    assert(default_attribute.listof is None)
    assert(default_attribute.priority == 0)
    assert(default_attribute.class_type is None)
    assert(default_attribute.always_post_validate is False)

# Generated at 2022-06-11 09:45:01.601804
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.isa == 'list'


# Generated at 2022-06-11 09:45:11.216346
# Unit test for constructor of class Attribute
def test_Attribute():
    def take_number(number):
        return number * 3

    # noinspection PyUnusedLocal
    def take_list(a_list):
        return a_list

    # noinspection PyUnusedLocal
    def take_set(a_set):
        return a_set

    # noinspection PyUnusedLocal
    def take_dict(a_dict):
        return a_dict

    Attribute(isa='int')
    Attribute(isa='int', default=1)
    Attribute(isa='int', default=take_number)
    Attribute(isa='int', listof='int')
    Attribute(isa='int', listof='int', default=take_list)
    Attribute(isa='int', listof='int', default=[5])

# Generated at 2022-06-11 09:45:19.235017
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()
    assert x.isa == None
    assert x.private == False
    assert x.default == None
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None
    assert x.extend == False
    assert x.prepend == False
    assert x.static == False
    print('FieldAttribute conscructor test completed')



# Generated at 2022-06-11 09:45:28.651495
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor
    atr = Attribute()
    assert atr.isa is None
    assert not atr.private
    assert atr.default is None
    assert not atr.required
    assert atr.listof is None
    assert atr.priority == 0
    assert atr.class_type is None
    assert not atr.always_post_validate
    assert atr.inherit
    assert atr.alias is None
    assert not atr.extend
    assert not atr.prepend
    assert not atr.static

    # Custom constructor

# Generated at 2022-06-11 09:45:37.425197
# Unit test for constructor of class Attribute
def test_Attribute():
    ''' test class constructor
    '''

    attrib = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attrib.isa == 'dict'
    assert attrib.private == False
    assert attrib.default == None
    assert attrib.required == False
    assert attrib.listof == None
    assert attrib.priority == 0
    assert attrib.class_type == None
    assert attrib.always_post_validate == False
    assert attrib.inherit == True
    assert attrib.alias == None
    assert attrib.extend == False
    assert attrib.prepend

# Generated at 2022-06-11 09:45:42.872965
# Unit test for constructor of class Attribute
def test_Attribute():
    d = Attribute(isa='dict', private=True, default={}, listof='string')

    assert d.isa == 'dict'
    assert d.private == True
    assert d.default == {}
    assert d.listof == 'string'
    assert d.priority == 0

    try:
        d = Attribute(isa='dict', private=True, default='should fail', listof='string')
        assert 0
    except TypeError:
        pass


# Generated at 2022-06-11 09:45:43.502347
# Unit test for constructor of class Attribute
def test_Attribute():
    pass