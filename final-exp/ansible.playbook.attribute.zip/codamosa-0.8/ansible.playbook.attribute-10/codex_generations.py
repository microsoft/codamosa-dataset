

# Generated at 2022-06-11 09:36:04.123208
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='TheType', default='TheDefault')

    assert field_attribute.isa == 'TheType'
    assert field_attribute.default == 'TheDefault'



# Generated at 2022-06-11 09:36:08.920660
# Unit test for constructor of class Attribute
def test_Attribute():
    print("[unittest]: Class Attribute constructor test")
    attr = Attribute()
    print(attr)

    attr = Attribute(isa="int")
    print(attr)

    attr = Attribute(required=True, default=123)
    print(attr)

    attr = Attribute(isa="list", listof="str", default=["a","b","c"])
    print(attr)

if __name__ == "__main__":
    test_Attribute()

# Generated at 2022-06-11 09:36:16.039421
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.vars import combine_vars
    a = FieldAttribute(isa='list', default=dict, required=True, listof=int)
    assert a.default == dict, a.default
    assert a.required == True, a.required
    assert a.listof == int, a.listof

    b = FieldAttribute(isa=str, default=dict, required=True, listof=int)
    assert b.default == dict, b.default
    assert b.required == True, b.required
    assert b.listof == int, b.listof

    # isa=dict should override default=dict
    c = FieldAttribute(isa=dict, default=dict, required=True, listof=int)
    assert c.default is None, c.default
    assert c.required == True, c.required


# Generated at 2022-06-11 09:36:16.873076
# Unit test for constructor of class Attribute
def test_Attribute():
    foo = Attribute()



# Generated at 2022-06-11 09:36:24.858024
# Unit test for constructor of class Attribute
def test_Attribute():
    pass
#    a = Attribute(default='Test', private=True, required=True, priority=1, isa='Unittest', inherit=False, alias="test")
#    assert a.default == 'Test'
#    assert a.private == True
#    assert a.required == True
#    assert a.inherit == False
#    assert a.alias == "test"
#    assert a.priority == 1
#    assert a.isa == 'Unittest'
#    try:
#        a = Attribute(default=['Test'], private=True, required=True, priority=1, isa='Unittest', inherit=False, alias="test")
#    except TypeError:
#        pass
#    else:
#        assert False, 'defaults for FieldAttribute may not be mutable, please provide a callable

# Generated at 2022-06-11 09:36:26.728333
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        f = FieldAttribute(isa='list', default=[1,2,3])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-11 09:36:35.617531
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default='Hello World', required=False,
                  listof=None, priority=0, class_type=None, always_post_validate=False,
                  inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == 'Hello World'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:36:38.112542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute('foo', default='bar')
    # This is more of an implicit test that the constructor works than anything.
    assert(attr.default == 'bar')


# Generated at 2022-06-11 09:36:40.069832
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute()
    fa = FieldAttribute()

# ===== DEPRECATED CLASSES =====


# Generated at 2022-06-11 09:36:52.919154
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False

    try:
        a = Attribute(default=dict())
        assert False, 'Mutable data type was used without callable'
    except TypeError:
        pass

    a = Attribute(default=dict)
    assert isinstance(a.default, dict) is True
    assert callable(a.default) is True

    a = Attribute(default=list)
    assert isinstance(a.default, list) is True
    assert callable(a.default) is True


# Generated at 2022-06-11 09:36:57.947627
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        field_object = FieldAttribute(default={})
    field_object = FieldAttribute(default=lambda: {})
    assert field_object.default() == {}


# Generated at 2022-06-11 09:36:59.638917
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()

# Class to define basic Dataclass types

# Generated at 2022-06-11 09:37:05.226225
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.listof == None
    assert attr.alias == None
    assert attr.class_type == None
    assert attr.default == None
    assert attr.inherit == True
    assert attr.isa == None
    assert attr.extend == False
    assert attr.prepend == False

# Unit test String class using the constructor of class FieldAttribute

# Generated at 2022-06-11 09:37:12.754657
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    kwargs = {
        'isa': Attribute,
        'private': False,
        'default': None,
        'required': False,
        'listof': Attribute,
        'priority': 0,
        'class_type': Attribute,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False
    }

    field = FieldAttribute(**kwargs)
    for key, value in kwargs.items():
        assert getattr(field, key) == value

# Generated at 2022-06-11 09:37:19.915703
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

    a = Attribute(isa='str',
                 private=True,
                 default='default',
                 required=True,
                 listof='list_of_items',
                 priority=1,
                 class_type='class_type',
                 always_post_validate=True,
                 inherit=False,
                 alias='alias',)
    assert a.isa == 'str'

# Generated at 2022-06-11 09:37:29.346202
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:37:30.620864
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute is not None


# Generated at 2022-06-11 09:37:37.832245
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute(isa='foo', default='bar', required=True)
    assert a.isa == 'foo'
    assert a.private == False
    assert a.default == 'bar'
    assert a.priority == 0
    assert a.required == True
    assert a.listof is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    # Duplicated test because it's a frequent mistake
    try:
        a = Attribute(isa='list', default=[])
        assert(False)
    except TypeError:
        assert(True)

    a = Attribute(isa='list', default=lambda: [])
    assert(True)


# Generated at 2022-06-11 09:37:43.892953
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='int', default=4, private=False, required=True, listof=int, priority=1, class_type=int, always_post_validate=True, alias='fred')
    assert f.isa == 'int'
    assert f.default == 4
    assert f.private == False
    assert f.required == True
    assert f.listof == int
    assert f.priority == 1
    assert f.class_type == int
    assert f.always_post_validate == True
    assert f.alias == 'fred'

# Generated at 2022-06-11 09:37:51.263198
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute('str', default='foo')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'foo'
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None



# Generated at 2022-06-11 09:38:01.999790
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    foo = FieldAttribute(isa = dict, class_type = dict)
    assert foo.isa == dict
    assert foo.class_type == dict
    assert foo.private is False
    assert foo.default is None
    assert foo.required is False
    assert foo.listof is None
    assert foo.priority == 0
    assert foo.always_post_validate is False
    assert foo.inherit is True
    assert foo.alias is None


# Generated at 2022-06-11 09:38:08.654615
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(False, False, None, False, None, 0, None, False, True, None, None, None, None)
    assert attribute
    assert not hasattr(attribute, 'private')
    assert not hasattr(attribute, 'required')
    assert not hasattr(attribute, 'alias')
    assert not hasattr(attribute, 'always_post_validate')
    assert not hasattr(attribute, 'inherit')
    assert not attribute


# Generated at 2022-06-11 09:38:16.105298
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:38:24.906551
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import OrderedDict
    field = FieldAttribute()
    assert field.isa is None
    assert not field.private
    assert field.default is None
    assert not field.required
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert not field.always_post_validate
    assert field.inherit
    assert field.alias is None
    assert not field.extend
    assert not field.prepend
    assert not field.static
    field = FieldAttribute(isa=dict)
    assert field.isa is dict
    assert not field.private
    assert field.default is None
    assert not field.required
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert not field.always_

# Generated at 2022-06-11 09:38:30.192659
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='foo', private=False)
    assert attr.isa == 'foo'
    assert attr.private == False
    attr = Attribute(isa='foo', private=True)
    assert attr.isa == 'foo'
    assert attr.private == True


# Generated at 2022-06-11 09:38:39.967389
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', listof='str')
    assert attr.isa == 'list'
    assert attr.listof == 'str'
    # assert that Attribute is not a frozenset
    assert not isinstance(attr, frozenset)
    # assert that its default is None
    assert attr.default == None
    try:
        Attribute(isa='list', listof='list')
        raise Exception('could set list to isa')
    except TypeError:
        pass
    else:
        raise Exception('could set list to isa')


# test for Attribute.__lt__

# Generated at 2022-06-11 09:38:40.899033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute()



# Generated at 2022-06-11 09:38:47.676170
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default of constructor
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

    # Test constructor with different arguments
    attr = FieldAttribute(isa='string', private=True, default=42, required=True, listof='bool',
                         priority=1, class_type='Toto', always_post_validate=True, inherit=False,
                         alias='alias')
    assert attr.isa == 'string'
    assert attr

# Generated at 2022-06-11 09:38:59.765310
# Unit test for constructor of class Attribute
def test_Attribute():
    # Error test #1: No attribute
    attribute = Attribute()
    assert attribute.__dict__ == {'alias': None, 'always_post_validate': False, 'class_type': None, 'default': None, \
                                  'extend': False, 'inherit': True, 'isa': None, 'listof': None, 'prepend': False, \
                                  'priority': 0, 'private': False, 'required': False, 'static': False}
    # Error test #2: No attribute and a bad value
    attribute = Attribute(listof="something")

# Generated at 2022-06-11 09:39:00.827836
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()


# Generated at 2022-06-11 09:39:10.677745
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    for name in ['isa', 'private', 'default', 'required', 'listof',
                 'priority', 'class_type', 'always_post_validate',
                 'inherit', 'alias', 'extend', 'prepend', 'static']:
        assert hasattr(fa, name)



# Generated at 2022-06-11 09:39:17.315919
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Testing FieldAttribute with all the ctor arguments
    f = FieldAttribute(
        isa=int,
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # Making sure the attribute 'inherit' is a boolean
    assert isinstance(f.inherit, bool)


# Generated at 2022-06-11 09:39:23.298724
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        FieldAttribute(default=[1,2,3], isa='list')
    with pytest.raises(TypeError):
        FieldAttribute(default={'foo': 'bar'}, isa='dict')
    with pytest.raises(TypeError):
        FieldAttribute(default=set([1, 2, 3]), isa='set')



# Generated at 2022-06-11 09:39:31.314106
# Unit test for constructor of class Attribute
def test_Attribute():
    f1 = Attribute()
    assert f1.default is None
    assert f1.private is False
    assert f1.required is False
    assert f1.priority == 0
    assert f1.alias is None
    assert f1.extend is False

    f2 = Attribute(private=True, default=True, required=True, inherit=False, alias='b', extend=True)
    assert f2.default is True
    assert f2.private is True
    assert f2.required is True
    assert f2.priority == 0
    assert f2.alias == 'b'
    assert f2.extend is True



# Generated at 2022-06-11 09:39:42.102736
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute(isa = int, private = True, default = 5, required = True, listof = int, priority = 1, class_type = int, always_post_validate = True)

    assert field_attr.isa == int
    assert field_attr.private == True
    assert field_attr.default == 5
    assert field_attr.required == True
    assert field_attr.listof == int
    assert field_attr.priority == 1
    assert field_attr.class_type == int
    assert field_attr.always_post_validate == True

    assert field_attr.inherit == True
    assert field_attr.alias == None
    assert field_attr.extend == False
    assert field_attr.prepend == False
    assert field_attr.static == False

    field_attr_2 = Field

# Generated at 2022-06-11 09:39:54.036053
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute1 = FieldAttribute(isa='dict')
    field_attribute2 = FieldAttribute(isa='str')
    assert field_attribute1.isa == 'dict'
    assert field_attribute1.private == False
    assert field_attribute1.default == None
    assert field_attribute1.required == False
    assert field_attribute1.listof == None
    assert field_attribute1.priority == 0
    assert field_attribute1.class_type == None
    assert field_attribute1.always_post_validate == False
    assert field_attribute1.inherit == True
    assert field_attribute1.alias == None
    assert field_attribute1.extend == False
    assert field_attribute1.prepend == False
    assert field_attribute1.static == False
    assert field_attribute2.isa == 'str'
   

# Generated at 2022-06-11 09:40:00.677374
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list')
    assert fa.__dict__ == {'always_post_validate': False, 'alias': None, 'class_type': None, 'default': None, 'extend': False, 'inherit': True, 'isa': 'list', 'listof': None, 'private': False, 'priority': 0, 'prepend': False, 'required': False, 'static': False}

# Generated at 2022-06-11 09:40:05.052942
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test that the constructor of class FieldAttribute
    # works as expected when called with a single argument
    # and without any arguments
    try:
        f = FieldAttribute()
    except TypeError:
        assert False

    try:
        f = FieldAttribute(isa=None)
    except TypeError:
        assert False



# Generated at 2022-06-11 09:40:15.674974
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='test')
    assert a.isa == 'test'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:40:18.139260
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_name = 'test_field'
    field = FieldAttribute(isa='test_isa')
    field.field_name = field_name
    assert field_name == field.field_name

# Generated at 2022-06-11 09:40:39.214268
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fa = FieldAttribute(
        isa='list',
        private=False,
        default=[],
        required=False,
        listof='int',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # Test for type of isa
    assert(fa.isa == 'list')

    # Test constructor can assign a value to the attribute private
    assert(fa.private == False)

    # Test constructor can assign a value to the attribute default
    assert(fa.default == [])

    # Test constructor can assign a value to the attribute required
    assert(fa.required == False)

    # Test constructor can assign a value to the attribute listof

# Generated at 2022-06-11 09:40:45.649992
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict', default='ok')
    assert fa.isa == 'dict'
    assert fa.default == 'ok'
    assert fa.private == False
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

# Generated at 2022-06-11 09:40:54.399222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='boolean', private=True)
    assert attr.isa == 'boolean'
    assert attr.private is True

    attr = FieldAttribute(isa='boolean', extend=True)
    assert attr.isa == 'boolean'
    assert attr.extend is True

    attr = FieldAttribute(isa='boolean', prepend=True)
    assert attr.isa == 'boolean'
    assert attr.prepend is True

    attr = FieldAttribute(isa='boolean', static=True)
    assert attr.isa == 'boolean'
    assert attr.static is True


# Generated at 2022-06-11 09:41:04.341736
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=None,
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=0,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False)

    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False



# Generated at 2022-06-11 09:41:14.466094
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # test mixed valid kwargs
    attr = FieldAttribute(
        isa=str,
        private=True,
        default='',
        required=True,
        listof=int,
        priority=0,
        class_type=int,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert isinstance(attr, FieldAttribute)

    # test missing required kwargs

# Generated at 2022-06-11 09:41:15.969250
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert isinstance(attr, Attribute)



# Generated at 2022-06-11 09:41:19.250752
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', class_type=list)
    assert f.isa == 'list', f.isa
    assert f.class_type == list, f.class_type
    assert callable(f.default), f.default



# Generated at 2022-06-11 09:41:24.745902
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #default_value = None
    #if isinstance(default_value, list):
    #   print('true')
    #else:
    #   print('false')
    #print(default_value)
    attr = FieldAttribute(default=[])
    if attr.default is not None and attr.isa in _CONTAINERS:
        print('true')
    else:
        print('false')



# Generated at 2022-06-11 09:41:32.692357
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False


# Generated at 2022-06-11 09:41:33.950330
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='list')

# Generated at 2022-06-11 09:42:08.244877
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa = 'list')
    assert attribute.isa == 'list'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False

    try:
        attribute = FieldAttribute(isa = 'list', default = [])
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-11 09:42:15.767434
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='dict', private=False, default=dict(), required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attribute.isa == 'dict'
    assert attribute.private == False
    assert attribute.default == dict()
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None


# Generated at 2022-06-11 09:42:26.924503
# Unit test for constructor of class Attribute
def test_Attribute():
    ''' ... '''

    assert Attribute(isa='bool', default=True).default == True
    assert Attribute(isa='bool', default=False).default == False
    assert Attribute(isa='bool', default=None).default is None

    assert Attribute(isa='dict', default={'a': 1}).default == {'a': 1}
    assert Attribute(isa='dict', default={}).default == {}
    assert Attribute(isa='dict', default=None).default is None

    assert Attribute(isa='list', default=['a', 'b']).default == ['a', 'b']
    assert Attribute(isa='list', default=[]).default == []
    assert Attribute(isa='list', default=None).default is None


# Generated at 2022-06-11 09:42:28.166123
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute(isa='int')
    print(x)



# Generated at 2022-06-11 09:42:38.689481
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.role.definition import RoleDefinition

    # RoleDefinition has a FieldAttribute inside of it.
    # This test will show that default specified for the field has been taken
    # and the data has been set.
    # Also testing the basic way of creating an object of a class, i.e.
    # attribute_test_object = Attribute()
    # This is to make sure the constructor is working fine.

    def test_default():
        attribute_test_object = Attribute(default='test')
        assert attribute_test_object.default == 'test'

        role_definition_object = RoleDefinition()
        assert role_definition_object.default_vars == {}

    def test_role_definition_default():
        role_definition_object = RoleDefinition()
        assert role_definition_object.name == ''
        assert role

# Generated at 2022-06-11 09:42:41.236619
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Add an alias to the class FieldAttribute
    attribute = FieldAttribute(alias='foo')

    # Check if alias is set to 'foo'
    assert attribute.alias == 'foo'


# Generated at 2022-06-11 09:42:52.122848
# Unit test for constructor of class Attribute
def test_Attribute():
    # isa
    try:
        a = Attribute(default=None)
    except TypeError:
        pass
    else:
        raise Exception("Attribute constructor allowed 'isa' to be None")

    # default
    try:
        a = Attribute(isa='dict')
    except TypeError:
        pass
    else:
        raise Exception("Attribute constructor allowed a default to not be set")

    a = Attribute(isa='dict', default=None)
    assert a.default is None, a.default

    a = Attribute(isa='dict', default=[])
    assert a.default == [], a.default

    a = Attribute(isa='dict', default=set())
    assert a.default == set(), a.default

    # listof

# Generated at 2022-06-11 09:42:57.086062
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='list',
        private=False,
        default=None,
        listof='dict',
    )
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.listof == 'dict'
    assert attr.required == False
    assert attr.priority == 0



# Generated at 2022-06-11 09:43:05.912441
# Unit test for constructor of class Attribute
def test_Attribute():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    #
    # Test __init__()
    #

    assert Attribute(isa='list', default={}).isa == 'list', 'Attribute(isa=list, default={}) failed'
    assert Attribute(isa='list', default=set()).isa == 'list', 'Attribute(isa=list, default=set()) failed'
    assert Attribute(isa='list', default=[]).isa == 'list', 'Attribute(isa=list, default=[]) failed'
    assert Attribute(isa='list', default=()).isa == 'list', 'Attribute(isa=list, default=()) failed'

# Generated at 2022-06-11 09:43:15.657278
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='test', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)

    assert field.isa == 'test'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None



# Generated at 2022-06-11 09:44:18.335262
# Unit test for constructor of class Attribute
def test_Attribute():

    # Constructor without kwargs
    attr_a = Attribute()

    # Constructor with all kwargs set
    attr_b = Attribute(
        isa='dict',
        private=True,
        default={},
        required=True,
        listof='list',
        priority=0,
        class_type=list,
        always_post_validate=True,
        inherit=True,
        alias='foo',
    )

    # Test all kwargs set
    assert attr_b.isa == 'dict'
    assert attr_b.private == True
    assert attr_b.default == {}
    assert attr_b.required == True
    assert attr_b.listof == 'list'
    assert attr_b.priority == 0

# Generated at 2022-06-11 09:44:30.175707
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA1 = FieldAttribute(isa='string')
    assert FA1.isa == 'string'
    FA2 = FieldAttribute(isa='string', default='This is a test')
    assert FA2.isa == 'string'
    assert FA2.default == 'This is a test'
    FA3 = FieldAttribute(isa='string', required=False)
    assert FA3.isa == 'string'
    assert FA3.required is False
    FA4 = FieldAttribute(isa='list', listof='string')
    assert FA4.isa == 'list'
    assert FA4.listof == 'string'
    FA5 = FieldAttribute(isa='string', priority=2)
    assert FA5.isa == 'string'
    assert FA5.priority == 2
    FA6 = FieldAttribute(isa='string', class_type=dict)

# Generated at 2022-06-11 09:44:32.842392
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    a = Attribute(isa='str')
    assert a.isa == 'str'


# Generated at 2022-06-11 09:44:42.558132
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='bool', inherit=False)
    assert attr.isa == 'bool'
    assert not attr.inherit
    assert attr.private == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.alias is None
    attr = Attribute(alias='foo', listof=str, priority=1, inherit=False)
    assert attr.alias == 'foo'
    assert attr.listof == str
    assert attr.priority == 1
    assert not attr.inherit
    assert attr.isa is None
    attr = Attribute(isa='bool', inherit=False, default='a default value')
    assert attr

# Generated at 2022-06-11 09:44:45.509230
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='bool', private='True', required='False', listof='None', priority='0', class_type='None', always_post_validate='False', inherit='True', alias='None', extend='False', prepend='False', static='False')


# Generated at 2022-06-11 09:44:46.806211
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    This is a unit test for class Attribute.
    """
    pass

# Generated at 2022-06-11 09:44:55.098724
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.playbook.base import FieldAttribute
    attr = FieldAttribute(isa='str', default='', required=False)
    assert attr.isa == 'str'
    assert attr.default == ''
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static
    assert not attr.private



# Generated at 2022-06-11 09:45:04.502310
# Unit test for constructor of class Attribute
def test_Attribute():
    # No error should be raised
    Attribute()

    # No error should be raised
    Attribute(isa='list', default=[])

    # No error should be raised
    Attribute(isa='dict', default={})

    # No error should be raised
    Attribute(isa='set', default=set())

    # TypeError should be raised
    try:
        Attribute(isa='list', default=[1,2,3])
    except TypeError:
        pass
    else:
        assert False, "Attribute() did not raise TypeError"

    # TypeError should be raised
    try:
        Attribute(isa='dict', default={'a': 1, 'b': 2, 'c': 3})
    except TypeError:
        pass
    else:
        assert False, "Attribute() did not raise TypeError"

    # TypeError

# Generated at 2022-06-11 09:45:14.745379
# Unit test for constructor of class Attribute
def test_Attribute():
    def_val = [1, 2, 3]
    a = Attribute(isa='list',
                  private=False,
                  default=def_val,
                  required=False,
                  listof='any',
                  priority=1,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False)

# Generated at 2022-06-11 09:45:24.763048
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing import vault
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_text

    attr = Attribute(isa='list', default=list, listof=dict)
    assert attr.isa == 'list'
    assert attr.default == list
    assert attr.listof == dict
    assert attr.private is False
    assert attr.required is False
    assert attr.priority == 0

    attr = Attribute(isa='set', default=set, listof=dict)
    assert attr.isa == 'set'
    assert attr.default == set
    assert attr.listof == dict
    assert attr.private is False
    assert attr.required is False
    assert attr.priority == 0

