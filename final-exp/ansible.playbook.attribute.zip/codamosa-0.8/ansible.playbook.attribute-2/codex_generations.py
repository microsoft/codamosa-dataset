

# Generated at 2022-06-11 09:36:07.846575
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    value1 = None
    value2 = "hello"
    field_attribute_1 = FieldAttribute(isa=value1, private=True, default=value2, required=False, listof=value1, priority=0, class_type=value1, always_post_validate=False, inherit=True, alias=value1, extend=False, prepend=False, static=False)
    field_attribute_2 = FieldAttribute(isa=value1, private=True, default=value2, required=False, listof=value1, priority=0, class_type=value1, always_post_validate=False, inherit=True, alias=value1, extend=False, prepend=False, static=False)
    assert field_attribute_1 == field_attribute_2
    assert not field_attribute_1 != field_attribute_2

# Generated at 2022-06-11 09:36:15.221695
# Unit test for constructor of class Attribute
def test_Attribute():

    # Note: The following test cases don't include tests for instantiating Attribute class
    #       w/ invalid or incompatible values as given in the doc string.

    # Check: empty instantiation
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

    # Check: testing against all params


# Generated at 2022-06-11 09:36:23.251849
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Default value for isa is string
    attr = FieldAttribute()
    assert attr.isa == 'string'

    # Default value for private is False
    assert attr.private == False

    # Default value for default is None
    assert attr.default == None

    # Default value for required is False
    assert attr.required == False

    # Default value for listof is None
    assert attr.listof == None

    # Default value for priority is 0
    assert attr.priority == 0

    # Default value for class_type is None
    assert attr.class_type == None

    # Default value for always_post_validate is False
    assert attr.always_post_validate == False

    # Default value for inherit is True
    assert attr.inherit == True

    # Default value for alias is None

# Generated at 2022-06-11 09:36:26.593852
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(private=True, required=True, listof=dict, isa=list, class_type='test')
    print(field.private)
    print(field.isa)
    print(field.listof)
    print(field.class_type)
    print(field.required)

test_FieldAttribute()



# Generated at 2022-06-11 09:36:34.073676
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(
        isa = 'example',
        private = True,
        default = [],
        required = False,
        listof = 'example',
        priority = 0,
        class_type = 'example',
        always_post_validate = True,
        inherit = False,
        alias = 'example',
    )

    assert field.isa == 'example'
    assert field.private == True
    assert field.default == []
    assert field.required == False
    assert field.listof == 'example'
    assert field.priority == 0
    assert field.class_type == 'example'
    assert field.always_post_validate == True
    assert field.inherit == False
    assert field.alias == 'example'

# Generated at 2022-06-11 09:36:38.269537
# Unit test for constructor of class Attribute
def test_Attribute():
    import unittest2 as unittest
    class TestAttribute(unittest.TestCase):
        def test_constructor(self):
            attr = Attribute(default='data')
            self.assertEqual('data', attr.default)

# Generated at 2022-06-11 09:36:50.446132
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible.constants as C
    from ansible.module_utils.basic import AnsibleModule

    t = Attribute(required=True, always_post_validate=True, alias='to')
    assert t.required is True
    assert t.always_post_validate is True
    assert t.alias is 'to'

    with AnsibleModule('', config=dict(ANSIBLE_MODULE_ARGS={'from': 'world', 'to': 'world'}, ANSIBLE_MODULE_REQUIRE=['from'])) as m:
        if m.params.get('from') != 'world' or C.ANSIBLE_MODULE_REQUIRE not in m.datasource.keys():
            raise ValueError("failed to create an AnsibleModule")

        if m.params.get('from') != 'world':
            raise Value

# Generated at 2022-06-11 09:37:00.853093
# Unit test for constructor of class Attribute
def test_Attribute():
    for class_type in ['network.linux.interface.NetworkInterface',
                       'netdot.net.interface.NetworkInterface',
                       'netdot.net.interface.NetworkInterface',
                       'netdot.net.interface.NetworkInterface',
                       'netdot.net.interface.NetworkInterface',
                       'netdot.net.interface.NetworkInterface']:
        fieldAttribute = Attribute(
            isa=class_type,
            private=False,
            default=None,
            required=False,
            listof=None,
            priority=0,
            class_type=class_type,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False,
        )

# Generated at 2022-06-11 09:37:08.568627
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    e = Exception
    try:
        FieldAttribute(default={1: 'a'})
    except TypeError:
        pass
    else:
        raise e('X')
    FieldAttribute(default=set())
    class A():
        def __call__(self):
            return {}
    FieldAttribute(default=A())
    class B():
        pass
    try:
        FieldAttribute(default=B())
    except TypeError:
        pass
    else:
        raise e('X')



# Generated at 2022-06-11 09:37:15.985253
# Unit test for constructor of class Attribute
def test_Attribute():
    # test static defaults
    a = Attribute()
    assert(a.isa                    is None)
    assert(a.private                is False)
    assert(a.default                is None)
    assert(a.required               is False)
    assert(a.listof                 is None)
    assert(a.priority               == 0)
    assert(a.class_type             is None)
    assert(a.always_post_validate   is False)
    assert(a.inherit                is True)
    assert(a.alias                  is None)
    assert(a.extend                 is False)
    assert(a.prepend                is False)
    assert(a.static                 is False)


# Generated at 2022-06-11 09:37:26.050228
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='dict', private=False, default=1, required=False, listof=None, priority=0, \
                                     class_type=None, inherit=True, always_post_validate=False, extend=False, \
                                     prepend=False, static=False)
    assert field_attribute.isa == 'dict'
    assert field_attribute.private == False
    assert field_attribute.default == 1
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.inherit == True
    assert field_attribute.always_post_validate == False
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
   

# Generated at 2022-06-11 09:37:27.234131
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='test')
    assert attr is not None



# Generated at 2022-06-11 09:37:32.963797
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().extend == False
    assert Attribute().prepend == False



# Generated at 2022-06-11 09:37:35.980276
# Unit test for constructor of class Attribute
def test_Attribute():
    import inspect

    try:
        a = Attribute()
    except TypeError:
        assert False, 'Attribute should have no required arguments'

    assert len(inspect.getargspec(Attribute.__init__)[0]) == 14, 'Attribute should have 14 total arguments'


# Generated at 2022-06-11 09:37:41.668840
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert(a.isa is None)
    assert(a.private is False)
    assert(a.default is None)
    assert(a.required is False)
    assert(a.listof is None)
    assert(a.priority == 0)
    assert(a.class_type is None)
    assert(a.always_post_validate is False)
    assert(a.inherit is True)
    assert(a.alias is None)
    assert(a.extend is False)
    assert(a.prepend is False)
    assert(a.static is False)

    a = FieldAttribute(isa='string')
    assert(a.isa is 'string')
    assert(a.private is False)
    assert(a.default is None)

# Generated at 2022-06-11 09:37:42.525827
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None

# Generated at 2022-06-11 09:37:54.074028
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert isinstance(f, FieldAttribute)
    assert isinstance(f, Attribute)

    f = FieldAttribute(isa=int)
    assert f.isa == int
    assert f.private == False

    f = FieldAttribute(isa=int, private=True)
    assert f.isa == int
    assert f.private == True

    f = FieldAttribute(isa=int, default=0)
    assert f.isa == int
    assert f.default == 0

    assert f.required == False
    f = FieldAttribute(isa=int, required=True)
    assert f.isa == int
    assert f.required == True

    assert f.listof is None
    f = FieldAttribute(isa=int, listof=int)
    assert f.isa == int
    assert f.listof == int



# Generated at 2022-06-11 09:38:06.576717
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_attributes = {
        'required': False,
        'listof': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    for isa in ['list', 'dict', 'set']:
        attrs = {'isa': isa, 'default': lambda: [], 'private': False}
        attrs.update(required_attributes)
        fa = FieldAttribute(**attrs)

# Generated at 2022-06-11 09:38:17.091935
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa == None
    assert attr.required == False
    assert attr.default == None
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True

    attr = Attribute(isa=str)
    assert attr.isa == str
    assert attr.required == False
    assert attr.default == None
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True


# Generated at 2022-06-11 09:38:25.561841
# Unit test for constructor of class Attribute
def test_Attribute():
    import sys
    if sys.version_info < (2, 7):
        from nose.plugins.skip import SkipTest
        raise SkipTest()

    from ansible.utils.class_loader import ModuleLoader

    loader = ModuleLoader()
    for attr_name, attr_type in loader._yaml_classes['Configuration']._attributes.items():
        assert isinstance(attr_name, str)
        assert isinstance(attr_type, Attribute)
        assert isinstance(attr_type.isa, str)
        assert isinstance(attr_type.alias, (str, type(None)))
        assert isinstance(attr_type.private, bool)
        assert isinstance(attr_type.default, (str, int, bool, type(None)))
        assert isinstance(attr_type.required, bool)

# Generated at 2022-06-11 09:38:31.486019
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa='list')
    assert a.isa == 'list'

    try:
        a = Attribute(isa='list', default=['a'])
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 09:38:42.709687
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()

    assert(a.isa is None)
    assert(a.private is False)
    assert(a.default is None)
    assert(a.required is False)
    assert(a.listof is None)
    assert(a.priority == 0)
    assert(a.class_type is None)
    assert(a.always_post_validate is False)

    a = Attribute(
        isa='foo',
        private=True,
        default=False,
        required=True,
        listof='bar',
        priority=1,
        class_type='baz',
        always_post_validate=True,
        inherit=True,
        alias='foo_bar'
    )

    assert(a.isa == 'foo')
    assert(a.private == True)
   

# Generated at 2022-06-11 09:38:53.715713
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attr = FieldAttribute(
        isa='str',
        private=False,
        default='default',
        required=False,
        listof='list',
        priority=1,
        class_type='class_type',
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=True,
        prepend=True,
        static=True,
    )

    assert field_attr.isa == 'str', 'FieldAttribute isa should be str'
    assert field_attr.private == False, 'FieldAttribute private should be False'
    assert field_attr.default == 'default', 'FieldAttribute default should be default'
    assert field_attr.required == False, 'FieldAttribute required should be False'

# Generated at 2022-06-11 09:38:58.788768
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa = 'str',
        private = False,
        default = 'hello',
        required = False,
        listof = 'str',
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
    )



# Generated at 2022-06-11 09:39:01.633193
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Constructor of class FieldAttribute
    """
    test_FieldAttribute = FieldAttribute()
    assert test_FieldAttribute != None, "test_FieldAttribute is None"



# Generated at 2022-06-11 09:39:11.437700
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute.__doc__ is not None

    # Internal class variables
    obj = Attribute(isa = 'list',
                    private = False,
                    default = None,
                    required = False,
                    listof = None,
                    priority = 3,
                    class_type = None,
                    always_post_validate = False,
                    inherit = True,
                    alias = None,
                    extend = False,
                    prepend = False,
                    static = False)

    assert obj.isa == 'list'
    assert obj.private == False
    assert obj.default == None
    assert obj.required == False
    assert obj.listof == None
    assert obj.priority == 3
    assert obj.class_type == None
    assert obj.always_post_validate == False
    assert obj.inherit == True

# Generated at 2022-06-11 09:39:15.515418
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa = "class", required = True)

    assert a.isa == "class"
    assert a.private == False
    assert a.default == None
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False


# Generated at 2022-06-11 09:39:17.880076
# Unit test for constructor of class Attribute
def test_Attribute():
    att = Attribute(isa='dict', require=True)
    assert att.isa == 'dict'
    assert att.required == True

# Generated at 2022-06-11 09:39:22.444073
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
    )

# Generated at 2022-06-11 09:39:30.751408
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    fa = FieldAttribute(prepend=True, static=True)
    assert fa.prepend is True
    assert fa.static is True



# Generated at 2022-06-11 09:39:34.970395
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute(default={})



# Generated at 2022-06-11 09:39:47.229154
# Unit test for constructor of class Attribute
def test_Attribute():

    # None required, isa and default are OK
    Attribute(isa=int)

    # None default
    Attribute(isa=int, default=None)

    # None required, int isa and list default OK
    Attribute(isa=int, default=[1, 2])

    # None required, list isa and default is a list of ints
    Attribute(isa=list, default=[1, 2])

    # None required, list isa, list default and listof are OK
    Attribute(isa=list, listof=int, default=[1, 2])

    # None required, list isa, not list default and listof is not int
    Attribute(isa=list, listof='int', default=1)

    # None required, dict isa, dict default and listof are OK

# Generated at 2022-06-11 09:39:48.678340
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute(isa='str')



# Generated at 2022-06-11 09:39:53.632250
# Unit test for constructor of class Attribute
def test_Attribute():
    required = False
    name = 'some_name'
    isa = 'int'
    private = False
    default = None
    attribute = Attribute(isa=isa, private=private, default=default, required=required)
    assert attribute.isa == isa
    assert attribute.private == private
    assert attribute.default == default
    assert attribute.required == required

# Generated at 2022-06-11 09:39:59.865106
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(
        isa='list',
        private=True,
        default='Test',
        required=True,
        listof='Test',
        priority=0,
        class_type='Test',
        always_post_validate=True,
        inherit=True,
        alias='Test',
        extend=True,
        prepend=True,
        static=True,
    )

    assert field.isa == 'list'
    assert field.private == True
    assert field.default == 'Test'
    assert field.required == True
    assert field.listof == 'Test'
    assert field.priority == 0
    assert field.class_type == 'Test'
    assert field.always_post_validate == True
    assert field.inherit == True
    assert field.alias == 'Test'
   

# Generated at 2022-06-11 09:40:01.861227
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(None)
    assert isinstance(a, Attribute)



# Generated at 2022-06-11 09:40:12.265464
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Constructor for FieldAttribute class
    test_obj = FieldAttribute()
    for attribute in ("isa", "private", "default", "listof", "priority", "class_type", "inherit", "alias", "extend", "prepend", "static"):
        # Check if the attribute is initialized to None
        assert getattr(test_obj, attribute) is None  
    assert test_obj.required == False
    assert test_obj.always_post_validate == False

    # Required is set to True
    test_obj1 = FieldAttribute(required=True)
    assert test_obj1.required == True

    # Default is set to False
    test_obj2 = FieldAttribute(required=False)
    assert test_obj2.required == False

    # Isa is set to dict

# Generated at 2022-06-11 09:40:17.744835
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str')
    assert a.isa == 'str'
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None



# Generated at 2022-06-11 09:40:27.254593
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='bool')
    assert a.isa is 'bool'
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None

# Generated at 2022-06-11 09:40:36.448459
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa=int)
    assert a.isa == int
    assert a.private is False
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(isa='string')


# Generated at 2022-06-11 09:40:47.055772
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.priority == 0
    assert fa.listof is None

    fa = FieldAttribute(priority=1)
    assert fa.priority == 1
    assert fa.listof is None

    fa = FieldAttribute(priority=1, listof='some_value')
    assert fa.priority == 1
    assert fa.listof == 'some_value'



# Generated at 2022-06-11 09:40:57.981028
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        # test isa and default is not None
        FieldAttribute(isa='dict', default=False)
        assert False, "the default value should be a callable"
    except TypeError:
        pass

    try:
        # test isa and default is not None
        FieldAttribute(isa='dict', default=lambda: False)
        assert True, "the default value should be a callable"
    except TypeError:
        assert False, "the default value should be a callable"

_DATATYPES = frozenset((
    'boolean', 'bool', 'complex', 'dict', 'float', 'int', 'integer',
    'list', 'long', 'number', 'set', 'string', 'unicode', 'none'
))


# Generated at 2022-06-11 09:41:08.525543
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    import unittest.mock

    class TestFieldAttribute(unittest.TestCase):
        def setUp(self):
            self.field = FieldAttribute()

        def test_default_value(self):
            self.assertEqual(self.field.isa, None)
            self.assertEqual(self.field.private, False)
            self.assertEqual(self.field.default, None)
            self.assertEqual(self.field.required, False)
            self.assertEqual(self.field.listof, None)
            self.assertEqual(self.field.priority, 0)
            self.assertEqual(self.field.class_type, None)
            self.assertEqual(self.field.always_post_validate, False)
            self.assertEqual

# Generated at 2022-06-11 09:41:17.838555
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # This is a trivial test to ensure that the FieldAttribute constructor
    # does not raise an exception.
    #
    # This test is in the collection_loader module so that it will be
    # executed by test/runner/test_connection_loader.py
    try: 
        a = FieldAttribute()
    except Exception:
        assert False
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False

# Generated at 2022-06-11 09:41:28.274470
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='string', private=True, default='n/a', required=True, listof='set', priority=1, class_type='string', always_post_validate=True, inherit=False, alias='test', extend=False, prepend=True, static=True)
    assert attribute.isa == 'string'
    assert attribute.private == True
    assert attribute.default == 'n/a'
    assert attribute.required == True
    assert attribute.listof == 'set'
    assert attribute.priority == 1
    assert attribute.class_type == 'string'
    assert attribute.always_post_validate == True
    assert attribute.inherit == False
    assert attribute.alias == 'test'
    assert attribute.extend == False
    assert attribute.prepend == True
    assert attribute.static == True
   

# Generated at 2022-06-11 09:41:40.381047
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    attr_defaults = FieldAttribute(default=['a', 'b', 'c'], isa='list')
    assert attr_defaults.default() == ['a', 'b', 'c']

# Generated at 2022-06-11 09:41:45.077026
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default='DefaultValue', required=False)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == 'DefaultValue'
    assert a.required == False

# Generated at 2022-06-11 09:41:53.657752
# Unit test for constructor of class Attribute
def test_Attribute():
    # isa
    attr = Attribute(isa=str)
    assert attr.isa == str
    # private
    attr = Attribute(private=True)
    assert attr.private == True
    # default
    attr = Attribute(default="test")
    assert attr.default == "test"
    # required
    attr = Attribute(required=True)
    assert attr.required == True
    # listof
    attr = Attribute(listof=str)
    assert attr.listof == str
    # priority
    attr = Attribute(priority = 2)
    assert attr.priority == 2
    # class_type
    attr = Attribute(class_type=str)
    assert attr.class_type == str
    # always_post_validate
    attr

# Generated at 2022-06-11 09:42:05.222315
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    my_Attribute = FieldAttribute(isa='string',
                                  private=False,
                                  default=None,
                                  required=True,
                                  listof=None,
                                  priority=0,
                                  class_type=None,
                                  always_post_validate=False,
                                  inherit=True,
                                  alias='TestAlias',
                                  extend=False,
                                  prepend=False,
                                  static=False)
    assert my_Attribute.isa == 'string'
    assert my_Attribute.private == False
    assert my_Attribute.default == None
    assert my_Attribute.required == True
    assert my_Attribute.listof == None
    assert my_Attribute.priority == 0
    assert my_Attribute.class_type == None
    assert my_Attribute.always_post_validate == False

# Generated at 2022-06-11 09:42:15.436350
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', required=True)
    assert attr.private == False
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    attr = Attribute(isa='dict', default='foo')
    assert attr.default == 'foo'
    # Can have a default that is a list, but not a mutable one
    attr = Attribute(isa='list', default=['foo', 'bar'])
    assert attr.default == ['foo', 'bar']
    # Can have a default that is a list by providing a callable
   

# Generated at 2022-06-11 09:42:39.436454
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test creation with named arguments
    class1 = FieldAttribute(isa="string",
                            private=True,
                            default="defaultValue",
                            required=True,
                            listof="list",
                            priority=5,
                            class_type="classType",
                            always_post_validate=True,
                            inherit=True,
                            alias="aliasName")
    assert class1.isa == "string"
    assert class1.private == True
    assert class1.default == "defaultValue"
    assert class1.required == True
    assert class1.listof == "list"
    assert class1.priority == 5
    assert class1.class_type == "classType"
    assert class1.always_post_validate == True
    assert class1.inherit == True
    assert class1

# Generated at 2022-06-11 09:42:45.340500
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    import sys

    class TestFieldAttribute(unittest.TestCase):
        def test_ok_default(self):
            a = FieldAttribute(default='my default')
            self.assertEquals(a.default, 'my default')

        def test_nok_default(self):
            self.assertRaises(TypeError, FieldAttribute, default=[])
            self.assertRaises(TypeError, FieldAttribute, default={})

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    return unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 09:42:56.062187
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # FieldAttribute
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'

    attr = FieldAttribute(isa='str', required=True)
    assert attr.isa == 'str'
    assert attr.required == True

    attr = FieldAttribute(isa='str', default='foobar')
    assert attr.isa == 'str'
    assert attr.default == 'foobar'

    attr = FieldAttribute(isa='list', default=[])
    assert attr.isa == 'list'
    assert attr.default == []

    attr = FieldAttribute(isa='bool', default=False)
    assert attr.isa == 'bool'
    assert attr.default == False

    attr = FieldAttribute(isa='int', default=0)

# Generated at 2022-06-11 09:42:58.523598
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    >>> test = FieldAttribute()
    Traceback (most recent call last):
    TypeError: __init__() takes at least 1 argument (0 given)
    """



# Generated at 2022-06-11 09:43:03.450437
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattribute = FieldAttribute(
        isa = 'list',
        default = ['test'],
        listof = 'dict'
    )
    assert fieldattribute.isa == 'list', 'Fails to set isa correctly'
    assert fieldattribute.default == ['test'], 'Fails to set default correctly'
    assert fieldattribute.listof == 'dict', 'Fails to set listof correctly'



# Generated at 2022-06-11 09:43:11.653791
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa="string", private=False, default=None, required=False, listof=None,
                         priority=1, class_type=None, always_post_validate=False, inherit=False,
                         alias=None, extend=False, prepend=False)
    assert obj.isa == "string"
    assert obj.private == False
    assert obj.default == None
    assert obj.required == False
    assert obj.listof == None
    assert obj.priority == 1
    assert obj.class_type == None
    assert obj.always_post_validate == False
    assert obj.inherit == False
    assert obj.alias == None
    assert obj.extend == False
    assert obj.prepend == False



# Generated at 2022-06-11 09:43:24.057284
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-11 09:43:25.943172
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = 'test'
    b = FieldAttribute(a)
    assert a == b.isa
    # TODO: add more tests here

# Generated at 2022-06-11 09:43:28.786704
# Unit test for constructor of class Attribute
def test_Attribute():

    try:
        Attribute(default=dict())
    except TypeError as e:
        assert "may not be mutable" in str(e)
    else:
        assert False, "Mutable default arguments not caught"

    assert Attribute(default=dict)
    assert Attribute(default=lambda: dict())



# Generated at 2022-06-11 09:43:31.896747
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', default='abc', required=True)
    assert a
    assert a.isa == 'string'
    assert a.default == 'abc'
    assert a.required == True


# Generated at 2022-06-11 09:44:12.442287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml.constructor import ConstructorError

    class YAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_dumper = AnsibleDumper
        yaml_constructor = AnsibleConstructor
        yaml_multi_constructor = AnsibleMultiConstructor

    # Test if FieldAttribute with default value and class_type set works as expected.
    class TestFieldAttribute(YAMLObject):
        def __init__(self):
            self.test = FieldAttribute(class_type=TestFieldAttribute, default=TestFieldAttribute())

    fa = TestFieldAttribute.yaml_loader.get_single_

# Generated at 2022-06-11 09:44:18.392421
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test the Attribute constructor
    """
    test1 = Attribute(isa='list', default=[])
    assert test1.isa == 'list', test1.isa
    assert test1.default == [], test1.default
    assert test1.listof is None, test1.listof
    try:
        test2 = Attribute(isa='list', default=[], listof='string')
        assert test2 is not None, "no error occurred when listof and default were both used"
    except TypeError:
        assert True, "TypeError was raised when listof and default were both used"



# Generated at 2022-06-11 09:44:30.287195
# Unit test for constructor of class Attribute
def test_Attribute():
    required = Attribute(required=True)
    assert required.required == True
    assert required.inherit == True

    not_required = Attribute(required=False)
    assert not_required.required == False
    assert not_required.inherit == True

    default = Attribute(default="hello world")
    assert default.default == "hello world"
    assert default.inherit == True

    not_default = Attribute()
    assert not_default.default is None
    assert not_default.inherit == True

    required_and_default = Attribute(required=True, default="hello world", inherit=False)
    assert required_and_default.required == True
    assert required_and_default.default == "hello world"
    assert required_and_default.inherit == False

    required_and_default

# Generated at 2022-06-11 09:44:40.441060
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='str').isa == 'str'
    assert FieldAttribute(isa='str', default='a').default == 'a'
    assert FieldAttribute(isa='str', default='a').required is False
    assert FieldAttribute(isa='str', default='a', required=True).required is True
    assert FieldAttribute(isa='list', listof='str').listof == 'str'
    assert FieldAttribute(isa='list', listof='str').class_type is None
    assert FieldAttribute(isa='list', listof='str').default is None
    assert FieldAttribute(isa='list', default=[]).default == []
    assert FieldAttribute(isa='dict').default is None
    assert FieldAttribute(isa='dict', default={}).default == {}
    assert FieldAttribute(isa='dict', default=lambda: {}).default() == {}
   

# Generated at 2022-06-11 09:44:42.315617
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    # test success cases
    with pytest.raises(TypeError):
        Attribute(default=dict())

# Generated at 2022-06-11 09:44:44.673349
# Unit test for constructor of class Attribute
def test_Attribute():
    #Test that Attribute constructor has not changed!
    assert Attribute.__init__.__defaults__ == (None, False, None, False, None, 0, None, False, True, None, False, False, False)

# Generated at 2022-06-11 09:44:45.472166
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None

# Generated at 2022-06-11 09:44:51.208146
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_data = FieldAttribute(isa='dict', default={})
    assert isinstance(test_data, FieldAttribute)
    assert test_data.isa == 'dict'
    assert test_data.default == {}
    assert test_data.required == False
    assert test_data.listof == None
    assert test_data.priority == 0
    assert test_data.inherit == True
    assert test_data.alias == None

# test copy of class FieldAttribute

# Generated at 2022-06-11 09:45:01.562088
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'int'
    default = 1
    required = True
    listof = 'dict'
    priority = 3
    class_type = dict
    always_post_validate = False
    inherit = True
    alias = False
    extend = False
    prepend = False
    static = False

    test = Attribute(isa=isa, default=default, required=required, listof=listof, priority=priority,
                    class_type=class_type, always_post_validate=always_post_validate, inherit=inherit,
                    alias=alias, extend=extend, prepend=prepend, static=static)

    assert test.isa == isa
    assert test.default == default
    assert test.required == required
    assert test.listof == listof
    assert test.priority == priority

# Generated at 2022-06-11 09:45:07.651317
# Unit test for constructor of class Attribute
def test_Attribute():
    a=Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority is 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False
