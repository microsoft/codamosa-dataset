

# Generated at 2022-06-11 09:36:03.963797
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute=FieldAttribute(isa='str',required=True,default='admin')
    print(field_attribute)


if __name__ == "__main__":
    test_FieldAttribute()

# Generated at 2022-06-11 09:36:11.451722
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()

# a dict of dicts, which the field attribute machinery uses as a schema
# and also to store the defaults
DATA_ATTRIBUTES = dict()

# a dict of dicts, which the field attribute machinery uses as a schema
# and also to store the defaults
VARIABLE_ATTRIBUTES = dict()

# SETUP ATTRIBUTES

DATA_ATTRIBUTES['all'] = dict()
VARIABLE_ATTRIBUTES['all'] = dict()

DATA_ATTRIBUTES['host'] = dict()
VARIABLE_ATTRIBUTES['host'] = dict()

DATA_ATTRIBUTES['host_group'] = dict()
VARIABLE_ATTRIBUTES['host_group'] = dict()

DATA_ATTR

# Generated at 2022-06-11 09:36:18.408106
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False
    a = FieldAttribute(isa='list', class_type=list, default=[])
    assert a.isa == 'list'
    assert a.class_type == list
    assert a.default == []
    try:
        a = FieldAttribute(default=list())
    except TypeError as e:
        pass

# Generated at 2022-06-11 09:36:19.207488
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()



# Generated at 2022-06-11 09:36:25.379144
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='listofstrings')
    assert attr
    assert attr.isa == 'listofstrings'
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static



# Generated at 2022-06-11 09:36:26.554991
# Unit test for constructor of class Attribute
def test_Attribute():
    myattr = Attribute('dict')
    assert myattr.isa == 'dict'



# Generated at 2022-06-11 09:36:27.528935
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    foo = FieldAttribute(isa='int')
    assert foo.isa == 'int'

# Generated at 2022-06-11 09:36:36.887702
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a = Attribute(default=[1, 2, 3])
    except TypeError:
        pass
    else:
        assert False, "defaults for FieldAttribute must be callable"

    # Main arguments
    a = Attribute(isa='str', private=True, default='foo', required=True,
        listof='int', priority=42, class_type=str, always_post_validate=True,
        inherit=False, alias='bar')
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'int'
    assert a.priority == 42
    assert a.class_type == str
    assert a.always_post_validate == True
    assert a.inherit == False

# Generated at 2022-06-11 09:36:39.170983
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list')
    assert isinstance(a, Attribute), "Attribute() should return an instance of class Attribute"


# Generated at 2022-06-11 09:36:42.004187
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    FA = FieldAttribute(isa='list', listof='dict')
    assert FA.isa == 'list'
    assert FA.listof == 'dict'


# Generated at 2022-06-11 09:36:51.770355
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute(isa='dict', default='foo')
    a = Attribute(isa=dict, default='foo')
    a = Attribute(isa='list', default='foo', listof='dict')
    a = Attribute(isa='list', default='foo', listof=dict)
    try:
        a = Attribute(isa='list', default={})
    except TypeError:
        pass
    else:
        assert False, 'FieldAttribute with default dict is not caught'


# Generated at 2022-06-11 09:37:01.801028
# Unit test for constructor of class Attribute
def test_Attribute():
    # Verify that the constructor works
    a = Attribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
    )

    # Ensure the parameter values are what we expect
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False

    # Save the parameters so we can make a copy of the existing "a" object
    isa = a.isa
    private = a.private

# Generated at 2022-06-11 09:37:12.338801
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', private=False, default=1, required=False, listof=None,
        priority=5, class_type=None, always_post_validate=False, inherit=True,
        alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'int'
    assert a.private == False
    assert a.default == 1
    assert a.required == False
    assert a.listof == None
    assert a.priority == 5
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:37:12.835223
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-11 09:37:14.809396
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute('str', True, 'default_value', True, 'list', 1)
    assert len(a.__dict__) == 7



# Generated at 2022-06-11 09:37:22.533802
# Unit test for constructor of class Attribute
def test_Attribute():
    # test constructor for Attribute, isa required
    try:
        Attribute()
    except TypeError as e:
        assert str(e) == "__init__() missing 1 required keyword-only argument: 'isa'"

    # test constructor for Attribute, isa default value
    a = Attribute(isa='string')
    assert a.isa == 'string'
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # test constructor

# Generated at 2022-06-11 09:37:28.982912
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string')
    assert field.isa == 'string'
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False

# Generated at 2022-06-11 09:37:35.833207
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("***** test_FieldAttribute *****")
    field_attribute = FieldAttribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert field_attribute.isa == 'list'
    print("SUCCESS: test_FieldAttribute")


# TaskAttribute is used to specify attributes of Task objects

# Generated at 2022-06-11 09:37:42.408055
# Unit test for constructor of class Attribute
def test_Attribute():
    ''' test the Attribute class '''

    obj = Attribute()
    assert(obj.isa == None)
    assert(obj.private == False)
    assert(obj.required == False)
    assert(obj.default == None)
    assert(obj.priority == 0)

    obj = Attribute(isa='int', private=False, required=True, default=False, priority=1)
    assert(obj.isa == 'int')
    assert(obj.private == False)
    assert(obj.required == True)
    assert(obj.default == False)
    assert(obj.priority == 1)

# Generated at 2022-06-11 09:37:43.258811
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().default == None


# Generated at 2022-06-11 09:37:49.339434
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=15,
                  class_type=None, always_post_validate=False, inherit=False, alias=None, extend=False)
    assert a.isa == 'str'



# Generated at 2022-06-11 09:37:56.602095
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default=[]).default
    except TypeError:
        pass
    else:
        raise AssertionError("FieldAttribute cannot be initialized with mutable objects")
    FieldAttribute(isa="string", listof="string")
    FieldAttribute()
    try:
        FieldAttribute(default=1, isa=str)
    except TypeError:
        pass
    else:
        raise AssertionError("FieldAttribute cannot be initialized with conflicting types")



# Generated at 2022-06-11 09:38:08.696828
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(
        isa='dict',
    )
    assert attr.isa == 'dict'

    attr = Attribute(
        isa='dict',
        private=True,
    )
    assert attr.private == True
    assert attr.isa == 'dict'

    attr = Attribute(
        isa='dict',
        private=True,
        default="ok",
    )
    assert attr.default == "ok"
    assert attr.private == True
    assert attr.isa == 'dict'

    attr = Attribute(
        isa='dict',
        private=True,
        default="ok",
        required=True
    )
    assert attr.default == "ok"
    assert attr.private == True
    assert attr.required == True
   

# Generated at 2022-06-11 09:38:12.572863
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', listof='str', required=False, default=None)

    assert attr.isa == 'list'
    assert attr.listof == 'str'
    assert attr.required == False
    assert attr.default == None


# Generated at 2022-06-11 09:38:22.823753
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import inspect
    # Now we can inspect the constructor of class FieldAttribute
    class_attrs = inspect.getargspec(FieldAttribute.__init__)
    # Lets check some basic conditions
    assert len(class_attrs.args) == 13
    assert class_attrs.defaults is None
    assert class_attrs.varargs is None
    assert class_attrs.keywords is None
    # The following is a list of default value of parameters

# Generated at 2022-06-11 09:38:24.622379
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa='dict')
    assert obj.isa == 'dict'


# Generated at 2022-06-11 09:38:37.473859
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # First call of the constructor with appropriate arguments
    fa1 = FieldAttribute(isa='list', extend=False, prepend=False, static=False, listof='int')
    assert fa1.isa == 'list'
    assert fa1.extend == False
    assert fa1.prepend == False
    assert fa1.static == False
    assert fa1.listof == 'int'

    # Second call of the constructor with appropriate arguments
    fa2 = FieldAttribute(isa='int', extend=True, prepend=True, static=True, listof='int')
    assert fa2.isa == 'int'
    assert fa2.extend == True
    assert fa2.prepend == True
    assert fa2.static == True
    assert fa2.listof == 'int'

    # Call of the constructor with a wrong argument in 'list

# Generated at 2022-06-11 09:38:45.213463
# Unit test for constructor of class Attribute
def test_Attribute():

    # Constructor of class Attribute should take no parameters.
    assert Attribute()

    # Constructor of class Attribute should take parameters isa, private, default, required,
    # listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend and static.
    # isa, priority and always_post_validate should be int or float
    # others should be boolean
    assert not Attribute(
        isa=123,
        private=True,
        default=1,
        required=False,
        listof=23,
        priority=3.3,
        class_type=1.1,
        always_post_validate=True,
        inherit=False,
        alias=None,
        extend=True,
        prepend=False,
        static=True,
    )



# Generated at 2022-06-11 09:38:57.065735
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'list of boolean'
    private = False
    default = None
    required = False
    listof = str
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False

    test = Attribute(isa=isa, private=private, default=default, required=required, listof=listof, priority=priority, class_type=class_type, always_post_validate=always_post_validate, inherit=inherit, alias=alias, extend=extend, prepend=prepend)

    assert test.isa == isa
    assert test.private == private
    assert test.default == default
    assert test.required == required
    assert test.listof == listof

# Generated at 2022-06-11 09:39:07.813647
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Foo:
        pass

    attr = FieldAttribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True

# Generated at 2022-06-11 09:39:09.499182
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:39:11.089908
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(default=['testlist'])
    assert a.default == ['testlist']

# Generated at 2022-06-11 09:39:11.941540
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(Attribute(), FieldAttribute)


# Generated at 2022-06-11 09:39:13.104625
# Unit test for constructor of class Attribute
def test_Attribute():
    assert isinstance(Attribute(), Attribute)



# Generated at 2022-06-11 09:39:23.533499
# Unit test for constructor of class Attribute
def test_Attribute():
    import collections
    import inspect
    import sys

    # test a basic Attribute
    a = Attribute(isa='list')
    assert a.isa == 'list'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False

    # test all the options

# Generated at 2022-06-11 09:39:33.486542
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute()
    a2 = Attribute(isa='str', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True)
    assert a1.isa == None
    assert a2.isa == 'str'
    assert a1.private == False
    assert a2.private == True
    assert a1.default == None
    assert a2.default == None
    assert a1.required == False
    assert a2.required == True
    assert a1.listof == None
    assert a2.listof == None
    assert a1.priority == 0
    assert a2.priority == 0
    assert a1.class_type == None
    assert a2.class_type == None

# Generated at 2022-06-11 09:39:38.675283
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    return fa

# Generated at 2022-06-11 09:39:51.908504
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None

    attr = Attribute(isa='dict', private=True, default='a', required=False, listof=False, priority=0,
                     class_type='class', always_post_validate=True, inherit=False, alias='boo', extend=True,
                     prepend=True, static=True)
    assert attr.isa == 'dict'
    assert attr.private

# Generated at 2022-06-11 09:39:58.032315
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(
        isa='int',
        private=False,
        default=0,
        required=True,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-11 09:40:09.213349
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test that default value for isa is None
    attr = FieldAttribute()
    assert attr.isa is None

    # Test that parameters are set correctly
    attr = FieldAttribute(isa='something', private=True, default='something', required=True, priority=1)
    assert attr.isa == 'something'
    assert attr.private is True
    assert attr.default == 'something'
    assert attr.required is True
    assert attr.priority == 1

    # Test that the static attribute is always false
    assert attr.static is False

    # Test that it raises exception if the default value is not None nor callable
    # and the type is a container
    try:
        attr = FieldAttribute(isa='list', default=[1, 2, 3])
    except TypeError:
        pass

# Generated at 2022-06-11 09:40:21.203325
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    att = FieldAttribute(
        isa = 'str',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )

    assert att.isa == 'str'
    assert att.private == False
    assert att.default == None
    assert att.required == False
    assert att.listof == None
    assert att.priority == 0
    assert att.class_type == None
    assert att.always_post_validate == False
    assert att.inherit == True
    assert att.alias == None
    assert att.extend == False

# Generated at 2022-06-11 09:40:24.477117
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test of description metadata
    try:
        field_attribute = FieldAttribute(isa='test', description='test description')
    except AttributeError:
        pass
    else:
        raise Exception('class FieldAttribute allows description metadata')



# Generated at 2022-06-11 09:40:32.554543
# Unit test for constructor of class Attribute
def test_Attribute():

    # Define an Attribute instance
    a = Attribute(isa='str', private=False, default='hello', required=False, listof=None, priority=0,
                  class_type=None, always_post_validate=False, inherit=True, alias=None)

    # Make sure that it has all the attributes
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == 'hello'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

# Generated at 2022-06-11 09:40:41.803141
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test inheritance
    obj = FieldAttribute(isa="dict", default={})
    assert obj.isa == 'dict' and obj.default == {}

    # Test immutable args
    obj = FieldAttribute(isa="dict", default={})
    obj.isa = 'list'
    assert obj.isa == 'dict' and obj.default == {}

    # Test that invalid defaults are not allowed
    try:
        obj = FieldAttribute(isa="dict", default=["test"])
    except TypeError:
        # TypeError is expected
        pass
    else:
        # TypeError was not raised
        assert False

    # Test that invalid defaults are not allowed
    try:
        obj = FieldAttribute(isa="dict", default="test")
    except TypeError:
        # TypeError is expected
        pass

# Generated at 2022-06-11 09:40:43.120595
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = Attribute(isa='list')
    assert isa.isa == 'list'

# Generated at 2022-06-11 09:40:49.811141
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='int', default=0)
    try:
        Attribute(isa='int', default=[])
        raise Exception('Default for isa=int was list, should not be possible')
    except TypeError:
        pass
    assert Attribute(isa='list')
    assert Attribute(isa='dict')
    try:
        Attribute(isa='int', default={})
        raise Exception('Default for isa=int was dict, should not be possible')
    except TypeError:
        pass



# Generated at 2022-06-11 09:40:52.560630
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Foo(object):
        ATTRIBUTE = FieldAttribute(isa='something')

    f = Foo()
    assert f.ATTRIBUTE.isa == 'something'



# Generated at 2022-06-11 09:41:03.294268
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest

    class TestFieldAttribute(unittest.TestCase):

        def test_FieldAttribute(self):
            attr = FieldAttribute(
                isa=1,
                private=False,
                default=None,
                required=False,
                listof=None,
                priority=0,
                class_type=None,
                always_post_validate=False,
                inherit=True,
                alias=None,
                extend=False,
                prepend=False,
                static=False,
            )
            self.assertEqual(attr.isa, 1)
            self.assertEqual(attr.private, False)
            self.assertEqual(attr.default, None)
            self.assertEqual(attr.required, False)
            self.assertEqual(attr.listof, None)

# Generated at 2022-06-11 09:41:13.632410
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias='test')
    attr2 = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias='dummy')
    attr3 = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias='dummy')

    assert attr1 < attr3
    assert attr3 > attr1

# Generated at 2022-06-11 09:41:24.001021
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test Attribute __init__
    attr = Attribute(isa='bool', default=False, required=True, inherit=False)
    assert attr.isa == 'bool'
    assert attr.default == False
    assert attr.required == True
    assert attr.inherit == False
    assert attr.priority == 0

    # Test Attribute __init__
    attr = Attribute(isa='bool', default=False, required=True, inherit=False, priority=1)
    assert attr.isa == 'bool'
    assert attr.default == False
    assert attr.required == True
    assert attr.priority == 1
    assert attr.inherit == False

    # Test Attribute __init__ exception

# Generated at 2022-06-11 09:41:40.038963
# Unit test for constructor of class Attribute
def test_Attribute():
    # no values set
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    # Only private flag set
    a = Attribute(private=True)
    assert a.isa is None
    assert a.private is True
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inher

# Generated at 2022-06-11 09:41:50.647853
# Unit test for constructor of class Attribute
def test_Attribute():
    # Unit test for Attribute
    test_attrib = Attribute(default='foo')
    assert test_attrib.default == 'foo'

    # Unit test for FieldAttribute
    test_fieldattrib = FieldAttribute()
    assert test_fieldattrib.__class__ == FieldAttribute

    # Test the errors raised by constructors of Attribute and FieldAttribute
    try:
        test_attrib2 = Attribute(default=['foo'])
    except TypeError:
        pass
    else:
        assert "should have raised TypeError"

    try:
        test_attrib3 = Attribute(listof=['foo'])
    except TypeError:
        pass
    else:
        assert "should have raised TypeError"


# Generated at 2022-06-11 09:41:57.294239
# Unit test for constructor of class Attribute
def test_Attribute():
    a_list=['test', 'list']
    a_dict={'test': 'dict'}
    a_set=set(['test', 'set'])

    result_list=copy(a_list)
    result_dict=copy(a_dict)
    result_set=copy(a_set)

    a = Attribute(default=a_list)
    assert a.default == result_list
    a = Attribute(default=a_dict)
    assert a.default == result_dict
    a = Attribute(default=a_set)
    assert a.default == result_set


# Generated at 2022-06-11 09:42:03.329331
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute(
        isa='str',
        private=True,
        default='xyz',
        required=True,
        listof='dict',
        priority=1,
        class_type='int',
        always_post_validate=True,
        inherit=False,
        alias='abc',
        extend=True,
        prepend=False,
        static=True
    )



# Generated at 2022-06-11 09:42:07.214874
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='bar', listof='baz')
    assert a.isa == 'bar'
    assert a.listof == 'baz'



# Generated at 2022-06-11 09:42:09.581612
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(static=True, default=True)
    if not isinstance(a, Attribute):
        raise Exception('Attribute not correct')

# Generated at 2022-06-11 09:42:17.854248
# Unit test for constructor of class Attribute
def test_Attribute():
    from units.compat.mock import patch, MagicMock

    def test_attr_error(msg):
        with patch('ansible.module_utils._text.AnsibleModule.fail_json') as mock_fail:
            mock_module = MagicMock()
            mock_module.params = {}
            mock_module.params['name'] = 'Test-Name'
            mock_module.params['state'] = 'present'
            a = Attribute(isa='str')
            a.post_validate(mock_module, 'Test-Attribute', "")
            mock_fail.assert_called_with(msg=msg)

    def test_attr_validation(isa, var, msg):
        with patch('ansible.module_utils._text.AnsibleModule.fail_json') as mock_fail:
            mock_

# Generated at 2022-06-11 09:42:28.323579
# Unit test for constructor of class Attribute
def test_Attribute():
    # Setup of tests
    # test 1
    a1 = Attribute(isa="str", private=True, default=None, required=True, listof=None, priority=10, class_type=None,
                   always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)

    try:
        Attribute(isa="str", private=True, default=None, required=True, listof=None, priority=10,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False,
                  static=False)
    except Exception as err:
        assert str(
            err) == "__init__() got multiple values for keyword argument 'private'", "Did not get expected exception"

    # test 2

# Generated at 2022-06-11 09:42:38.840065
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test for constructor of 'FieldAttribute'
    attr1 = FieldAttribute()
    assert attr1.isa is None
    assert attr1.private is False
    assert attr1.default is None
    assert attr1.required is False
    assert attr1.listof is None
    assert attr1.priority == 0
    assert attr1.class_type is None
    assert attr1.always_post_validate is False
    assert attr1.inherit is True
    assert attr1.alias is None
    assert attr1.extend is False
    assert attr1.prepend is False
    assert attr1.static is False

    # Test for constructor of 'FieldAttribute' with an argument
    attr2 = FieldAttribute(isa='bool')

# Generated at 2022-06-11 09:42:45.993865
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test constructor without arguments
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False

    # test constructor with all arguments

# Generated at 2022-06-11 09:43:03.539151
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that we get an error for an invalid constructor arg
    try:
        Attribute(foo='bar')
        assert False
    except TypeError as e:
        assert 'got an unexpected keyword argument \'foo\'' in str(e)

    # Test that we get an error if the default value is a container type and
    # is not callable
    try:
        Attribute(default=[], isa='list')
        assert False
    except TypeError as e:
        assert 'defaults for FieldAttribute may not be mutable' in str(e)

    # Test that we get an error if isa is not a string representation of any
    # yaml/python type, percent or class

# Generated at 2022-06-11 09:43:13.044804
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='bool', inherit=False, listof='str', default=dict)

    # isa
    assert isinstance(fa.isa, str)
    assert fa.isa == 'bool'

    # private
    assert fa.private is False

    # default
    assert callable(fa.default)
    assert fa.default is dict

    # required
    assert fa.required is False

    # listof
    assert isinstance(fa.listof, str)
    assert fa.listof == 'str'

    # priority
    assert isinstance(fa.priority, int)
    assert fa.priority == 0

    # class_type
    assert fa.class_type is None

    # always_post_validate
    assert fa.always_post_validate is False

    # inherit
    assert fa.inherit

# Generated at 2022-06-11 09:43:24.357735
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa='SomeType',
        private=True,
        default='SomeDefault',
        required=True,
        listof='SomeType',
        priority=0,
        class_type='SomeClass',
        always_post_validate=True,
        inherit=True,
        alias='SomeAlias'
    )

    assert attribute.isa == 'SomeType'
    assert attribute.private == True
    assert attribute.default == 'SomeDefault'
    assert attribute.required == True
    assert attribute.listof == 'SomeType'
    assert attribute.priority == 0
    assert attribute.class_type == 'SomeClass'
    assert attribute.always_post_validate == True
    assert attribute.inherit == True
    assert attribute.alias == 'SomeAlias'

# Generated at 2022-06-11 09:43:25.332999
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create an empty attribute
    attr = FieldAttribute()
    assert attr is not None
    assert attr.inherit


# Generated at 2022-06-11 09:43:27.569013
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.priority == 0
    f2 = FieldAttribute(priority=9)
    assert f2.priority == 9
    assert f2 > f
    assert f < f2


# Generated at 2022-06-11 09:43:36.689816
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test: all default value
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True

    # Test: all value
    attribute = Attribute(
        isa='str',
        private=True,
        default='default_value',
        required=True,
        listof=list,
        priority=10,
        class_type=list,
        always_post_validate=True,
        inherit=False,
    )

    assert attribute.isa == 'str'
    assert attribute.private == True

# Generated at 2022-06-11 09:43:45.817814
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:43:50.702862
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute(isa='test',
                   private=False,
                   default=None,
                   required=False,
                   listof=None,
                   priority=0,
                   class_type=None,
                   always_post_validate=False,
                   inherit=True,
                   alias=None,
                   extend=False,
                   prepend=False,
                   static=False)


# Generated at 2022-06-11 09:43:55.485569
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()
    assert x.isa == None
    assert x.private == False
    assert x.default == None
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None

# Generated at 2022-06-11 09:43:57.396777
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(default="abc")
    assert a.default == "abc"



# Generated at 2022-06-11 09:44:22.503011
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import sys

    if sys.version_info[0] >= 3:
        from importlib import reload
    else:
        from imp import reload

    reload(sys)
    # sys.setdefaultencoding("UTF-8")

    f = FieldAttribute(
        isa='list',
        listof='dict',
        extend=True,
        )

    print(f)
    print(f.isa)
    print(f.listof)
    print(f.extend)

test_FieldAttribute()

# Generated at 2022-06-11 09:44:27.146301
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest

    attr = Attribute(isa='list', default=lambda: [])
    assert attr.isa == 'list'
    assert attr.default() == []

    with pytest.raises(TypeError):
        attr = Attribute(isa='list', default=[])



# Generated at 2022-06-11 09:44:31.350703
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(None, False, False, False, False, 0)
    assert field.isa == None
    assert field.private == False
    assert field.default == False
    assert field.required == False
    assert field.listof == False
    assert field.priority == 0

# Generated at 2022-06-11 09:44:41.329017
# Unit test for constructor of class Attribute
def test_Attribute():

    class MyClass(object):
        pass

    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    attr = Attribute(isa='bool')
    assert attr.isa == 'bool'

    attr = Attribute(private=True)
    assert attr.private == True


# Generated at 2022-06-11 09:44:47.656679
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa = 'dict',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
    )
    assert attribute.isa == 'dict'
    assert attribute.private == False
    assert attribute.required == False
    assert attribute.priority == 0
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias is None




# Generated at 2022-06-11 09:44:58.131362
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Test:
        test_inherit = FieldAttribute(inherit=True)
        test_inherit_default = FieldAttribute(inherit=True, default=[])
        test_not_inherit = FieldAttribute()
        test_not_inherit_default = FieldAttribute(default=[])

    parent = Test()
    child = Test()

    assert child.test_inherit is None
    assert child.test_inherit_default == []

    assert child.test_not_inherit is None
    assert child.test_not_inherit_default == []

    parent.test_inherit = 'a'
    assert child.test_inherit == 'a'

    parent.test_inherit_default = 'a'

# Generated at 2022-06-11 09:45:07.532484
# Unit test for constructor of class Attribute
def test_Attribute():

    # default value of Attribute
    isa = None
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    att = Attribute()
    # no kwarg
    assert att.isa == isa
    assert att.private == private
    assert att.default == default
    assert att.required == required
    assert att.listof == listof
    assert att.priority == priority
    assert att.class_type == class_type
    assert att.always_post_validate == always_post_validate
    assert att.inherit == inherit
    assert att.alias == alias
    assert att

# Generated at 2022-06-11 09:45:09.207970
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute(isa='int')
    assert field_attr.isa == 'int'


# Generated at 2022-06-11 09:45:19.931231
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # By default, the constructor validates the following arguments and 
    # returns an object of type Attribute
    attribute1 = FieldAttribute()
    assert type(attribute1) == Attribute

    # If the values of all the arguments are valid, it returns objects 
    # of type Attribute
    attribute2 = FieldAttribute(False, True, 'somevalue', False, 'somevalue', 0, 'someclass')
    assert type(attribute2) == Attribute

    # If the default value is not None and the isa argument is of type 
    # class - 'list', 'dict', and 'set' - it raises an exception
    # ToDo - find a better way to check if the value of the 'isa' argument 
    # is in a set of values
    attribute3 = FieldAttribute(default='somevalue', isa='list')

# Generated at 2022-06-11 09:45:22.755155
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(isa=str, default='foo')
    except TypeError as e:
        assert False, "Failed to instantiate the attribute class"
    a = Attribute(isa=str, default=['foo'])

