

# Generated at 2022-06-11 09:36:12.904033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(
        isa='integer',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.__class__ == FieldAttribute
    assert attr.isa == 'integer'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False

# Generated at 2022-06-11 09:36:13.677897
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert Attribute is FieldAttribute



# Generated at 2022-06-11 09:36:18.832494
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False



# Generated at 2022-06-11 09:36:24.713111
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(default=42)

    try:
        Attribute(required=True, default='foo')
    except TypeError:
        pass
    else:
        assert False, 'Should not get here, above should throw exception'

    try:
        Attribute(default=dict())
    except TypeError:
        pass
    else:
        assert False, 'Should not get here, above should throw exception'

    try:
        Attribute(default=[])
    except TypeError:
        pass
    else:
        assert False, 'Should not get here, above should throw exception'



# Generated at 2022-06-11 09:36:30.838802
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute(isa='int')
    FieldAttribute(isa='int', private=False)
    FieldAttribute(isa='int', private=True)
    FieldAttribute(isa='int', default=42)
    FieldAttribute(isa='int', default='int')  # invalid default value
    FieldAttribute(isa='int', listof='int')
    FieldAttribute(isa='int', required=False)
    FieldAttribute(isa='int', required=True)
    FieldAttribute(isa='int', priority=1)
    FieldAttribute(isa='int', class_type=int)
    FieldAttribute(isa='int', always_post_validate=False)
    FieldAttribute(isa='int', always_post_validate=True)
    FieldAttribute(isa='int', inherit=True)
    FieldAttribute(isa='int', inherit=False)
    FieldAttribute

# Generated at 2022-06-11 09:36:37.410348
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', default='foobar', required=True, priority=10, inherit=False, private=True)
    assert f.isa == 'str'
    assert f.private is True
    assert f.default == 'foobar'
    assert f.required is True
    assert f.priority == 10
    assert f.static is False
    assert f.inherit is False
    assert f.alias is None
    assert f.extend is False
    assert f.prepend is False
    assert f.static is False



# Generated at 2022-06-11 09:36:49.527254
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa='list')
    assert attr.isa == 'list'
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


    attr = Attribute(isa='integer', required=True, default=0, priority=10)
    assert attr.isa == 'integer'
    assert attr.private is False
    assert attr.default is 0

# Generated at 2022-06-11 09:37:00.568459
# Unit test for constructor of class Attribute
def test_Attribute():
    # 'abc' is the default string value
    attr1 = Attribute(default='abc')
    # {} is the default dict value
    attr2 = Attribute(default={})
    # [1,2,3] is the default list value
    attr3 = Attribute(default=[1,2,3])
    # Non-mutable things like a string can be set as a default value
    assert attr1.default == 'abc'
    # Mutable things like an empty list or dict can be set as a default value
    assert attr2.default == {}
    assert attr3.default == [1,2,3]
    # Make sure the values are not aliased
    attr2.default['foo'] = 'bar'
    assert 'foo' in attr2.default
    assert 'foo' not in attr1

# Generated at 2022-06-11 09:37:06.861009
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None

# Generated at 2022-06-11 09:37:14.741394
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test all the acceptable constructor arguments and their values
    def test_constructor(isa=None, private=False, default=None, required=False,
                         listof=None, priority=0, class_type=None,
                         always_post_validate=False, inherit=True, alias=None):
        obj = FieldAttribute(isa, private, default, required, listof, priority,
                             class_type, always_post_validate, inherit, alias)
        assert obj.isa == isa
        assert obj.private == private
        assert (obj.default == default) or not isinstance(default, dict)
        assert (obj.default == default) or not isinstance(default, list)
        assert obj.required == required
        assert obj.listof == listof
        assert obj.priority == priority

# Generated at 2022-06-11 09:37:24.487242
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert hasattr(obj, 'isa')
    assert hasattr(obj, 'private')
    assert hasattr(obj, 'default')
    assert hasattr(obj, 'required')
    assert hasattr(obj, 'listof')
    assert hasattr(obj, 'priority')
    assert hasattr(obj, 'class_type')
    assert hasattr(obj, 'always_post_validate')

# Generated at 2022-06-11 09:37:33.781846
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr1 = Attribute(isa='int')
    attr2 = Attribute(isa='int', required=False)
    attr3 = Attribute(isa='int', required=True)
    attr4 = Attribute(isa='int', required=False, default=10)
    attr5 = Attribute(isa='int', required=True, default=10)

    # The following 2 lines are commented out, as they are not compatible in py3
    # attr6 = Attribute(isa='list', listof=int)
    # attr7 = Attribute(isa='list', listof='int')

    attr8 = Attribute(isa='int', class_type=int)
    #attr9 = Attribute(isa='int', default=10, class_type=int)

# Generated at 2022-06-11 09:37:41.782578
# Unit test for constructor of class Attribute
def test_Attribute():

    # isa
    attr = Attribute()
    assert(attr.isa is None)
    assert(attr.private is False)
    assert(attr.default is None)
    assert(attr.required is False)
    assert(attr.listof is None)
    assert(attr.priority == 0)
    assert(attr.class_type is None)
    assert(attr.always_post_validate is False)
    assert(attr.inherit is True)
    assert(attr.alias is None)
    assert(attr.extend is False)
    assert(attr.prepend is False)

    # isa: dict
    attr = Attribute(isa='dict')
    assert(attr.isa == 'dict')
    assert(attr.private is False)
    assert(attr.default is None)

# Generated at 2022-06-11 09:37:52.816090
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of class Attribute
    attr = Attribute(isa='test_isa',
                     private=True,
                     default='test_default',
                     required=True,
                     listof='test_listof',
                     priority=1,
                     class_type='test_class_type',
                     always_post_validate=False,
                     inherit=True,
                     alias='test_alias')
    assert attr.isa == 'test_isa'
    assert attr.private == True
    assert attr.default == 'test_default'
    assert attr.required == True
    assert attr.listof == 'test_listof'
    assert attr.priority == 1
    assert attr.class_type == 'test_class_type'
    assert attr.always_post_validate == False
    assert att

# Generated at 2022-06-11 09:37:58.202369
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    def generate_default():
        return [1, 2, 3]

    field_attribute = FieldAttribute(
            default=generate_default,
            isa='list',
            listof='int',
            private=False,
            required=True,
            class_type=None,
            priority=0,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False,
    )

    assert field_attribute.isa == 'list'
    assert field_attribute.listof == 'int'
    assert field_attribute.private == False
    assert field_attribute.required == True
    assert field_attribute.class_type == None
    assert field_attribute.priority == 0
    assert field_attribute.always_post_validate

# Generated at 2022-06-11 09:38:05.437765
# Unit test for constructor of class Attribute
def test_Attribute():
    # These are the defaults
    x = Attribute()
    assert x.isa == None
    assert x.private == False
    assert x.default == None
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None


# Generated at 2022-06-11 09:38:06.032334
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-11 09:38:16.537562
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert(field.isa == None)
    assert(field.private == False)
    assert(field.default == None)
    assert(field.required == False)
    assert(field.always_post_validate == False)
    assert(field.listof == None)
    assert(field.priority == 0)
    assert(field.class_type == None)
    assert(field.inherit == True)
    assert(field.alias == None)
    assert(field.extend == False)
    assert(field.prepend == False)
    assert(field.static == False)

    field = FieldAttribute(default = 'test')
    assert(field.default == 'test')

    # Mutable defaults are not allowed
    l = []

# Generated at 2022-06-11 09:38:23.400661
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # field_attribute = FieldAttribute()
    field_attribute = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof='int',
        priority=0,
        class_type=dict,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    print(field_attribute)

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-11 09:38:35.974641
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_object = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert test_object.isa is None
    assert test_object.private is False
    assert test_object.default is None
    assert test_object.required is False
    assert test_object.listof is None
    assert test_object.priority is 0
    assert test_object.class_type is None
    assert test_object.always_post_validate is False
    assert test_object.inherit is True

# Generated at 2022-06-11 09:38:45.922885
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    # ISA
    b = FieldAttribute(isa='dict')
    c = FieldAttribute(isa='list')
    d = FieldAttribute(isa='bool')
    e = FieldAttribute(isa='int')
    f = FieldAttribute(isa='float')
    g = FieldAttribute(isa='bool')
    h = FieldAttribute(isa='str')
    i = FieldAttribute(isa='unicode')
    j = FieldAttribute(isa='class')
    k = FieldAttribute(isa='dict')
    l = FieldAttribute(isa='list')
    m = FieldAttribute(isa='foo')

    # PRIVATE
    n = FieldAttribute(private=True)
    o = FieldAttribute(private=False)

    # DEFAULT
    pp = FieldAttribute(default=None)
    q = FieldAttribute(default=1)

# Generated at 2022-06-11 09:38:47.946672
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
     # ...

     attribute = FieldAttribute(True)
     assert attribute.isa == True


# Generated at 2022-06-11 09:38:59.972319
# Unit test for constructor of class Attribute
def test_Attribute():
    import datetime

    attr = Attribute()
    assert isinstance(attr.isa, str) == False
    assert attr.privte == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    #assert isinstance(attr.alias, str) == False

    attr = Attribute(isa='datetime')
    assert isinstance(attr.isa, str) == True
    attr = Attribute(isa=datetime.datetime)
    assert isinstance(attr.isa, str) == False

    attr = Attribute(isa='list', listof='datetime')
    assert isinstance(attr.isa, str) == True
    attr = Attribute(isa='list', listof=datetime.datetime)


# Generated at 2022-06-11 09:39:02.147367
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import doctest
    doctest.testmod(verbose=True)
    doctest.testfile('FieldAttribute_test.txt', verbose=True)

# Generated at 2022-06-11 09:39:11.827902
# Unit test for constructor of class Attribute
def test_Attribute():

    # isa
    attr_isa = Attribute(isa='str')
    assert attr_isa.isa == 'str'

    attr_isa = Attribute(isa='dict')
    assert attr_isa.isa == 'dict'

    attr_isa = Attribute(isa='list')
    assert attr_isa.isa == 'list'

    attr_isa = Attribute(isa='set')
    assert attr_isa.isa == 'set'

    # private
    attr_private = Attribute(private=True)
    assert attr_private.private is True

    # default
    attr_default = Attribute(default='test')
    assert attr_default.default == 'test'

    # required
    attr_required = Attribute(required=True)
    assert attr_required.required

# Generated at 2022-06-11 09:39:21.654139
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_field = FieldAttribute(
        isa='str',
        private=True,
        default='hello',
        required=True,
        listof='str',
        priority=5,
        class_type='str',
        always_post_validate=True,
        inherit=False,
        alias=thisshouldfail
    )
    assert (required_field.priority == 5)
    assert (required_field.inherit == False)
    assert (required_field.private == True)
    assert (required_field.always_post_validate == True)
    assert (required_field.default == 'hello')
    assert (required_field.required == True)
    assert (required_field.alias == 'thisshouldfail')
    assert (required_field.isa == 'str')

# Generated at 2022-06-11 09:39:26.421288
# Unit test for constructor of class Attribute
def test_Attribute():
    # check for required parameter for Attribute class isa
    try:
        a = Attribute(isa=None, private=False, default=None, required=False)
        print ('This statement should not be reached') # this should not be executed and there should be a raised Exception
    except TypeError:
        print ('Expected TypeError exception raised')

# Generated at 2022-06-11 09:39:28.136892
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-11 09:39:38.124186
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa='dict', default=dict, inherit=True, extend=True, prepend=True)
    assert a.isa == 'dict'
    assert a.default == dict
    assert a.inherit == True
    assert a.extend == True
    assert a.prepend == True

    a = Attribute(isa='list', default=list, inherit=True, extend=True)
    assert a.isa == 'list'
    assert a.default == list
    assert a.inherit == True
    assert a.extend == True
    assert a.prepend == False

    a = Attribute(isa='bool', default=True, inherit=True, prepend=True)
    assert a.isa == 'bool'
    assert a.default == True
    assert a.inherit == True

# Generated at 2022-06-11 09:39:41.034854
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, \
    class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)



# Generated at 2022-06-11 09:39:54.656498
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa=None)
    assert tuple(field_attribute.__dict__.keys()) == (
        'isa',
        'private',
        'default',
        'required',
        'listof',
        'priority',
        'class_type',
        'always_post_validate',
        'inherit',
        'alias',
        'extend',
        'prepend',
        'static',
    )
    assert field_attribute.__dict__.values() == [
        None,
        False,
        None,
        False,
        None,
        0,
        None,
        False,
        True,
        None,
        False,
        False,
        False,
    ]



# Generated at 2022-06-11 09:40:02.205859
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # This is a bad FieldAttribute object because it has a mutable default
    # which is not allowed.
    fa1 = FieldAttribute(default="this is not allowed")

    # This is not a good FieldAttribute object because the default is
    # required to be a callable
    fa2 = FieldAttribute(default=[])

    # This is a good FieldAttribute object because the default is a callable.
    fa3 = FieldAttribute(default=lambda: [])

test_FieldAttribute()

# Generated at 2022-06-11 09:40:12.531929
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Try to instantiate an object FieldAttribute
    """
    fldattr = FieldAttribute(isa='string', private=False, default='def', required=False,
                             listof=None, priority=0, class_type=None, always_post_validate=False,
                             inherit=True, alias=None, extend=False, prepend=False)
    assert fldattr.isa == 'string'
    assert fldattr.private == False
    assert fldattr.default == 'def'
    assert fldattr.required == False
    assert fldattr.listof is None
    assert fldattr.priority == 0
    assert fldattr.class_type is None
    assert fldattr.always_post_validate == False
    assert fldattr.inherit == True
    assert fldattr.alias

# Generated at 2022-06-11 09:40:13.572697
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    t = FieldAttribute()



# Generated at 2022-06-11 09:40:18.268022
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute(isa='bool',
                         private=False,
                         default=False,
                         required=False,
                         listof=None,
                         priority=0,
                         class_type=None,
                         always_post_validate=False,
                         inherit=True,
                         alias=None)
    assert obj is not None


# Generated at 2022-06-11 09:40:21.116050
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Execute the constructor of class FieldAttribute
    field_attribute = FieldAttribute()

    # Verify that field atttribute is of class FieldAttribute
    assert field_attribute.__class__.__name__ == 'FieldAttribute'

# Generated at 2022-06-11 09:40:25.091832
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        attr = Attribute(default=[])
    with pytest.raises(TypeError):
        attr = Attribute(default={})
    with pytest.raises(TypeError):
        attr = Attribute(default=set())



# Generated at 2022-06-11 09:40:25.744469
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-11 09:40:30.920849
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', required=True, priority=10)
    assert attr.isa == 'list'
    assert attr.private is False
    assert attr.required is True
    assert attr.priority == 10
    assert attr.listof is None
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True



# Generated at 2022-06-11 09:40:38.457777
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(
        isa='list',
        listof='str',
        default='abc',
        required=True,
        always_post_validate=True
    )
    assert field.isa == 'list'
    assert field.listof == 'str'
    assert field.default == 'abc'
    assert field.required == True
    assert field.always_post_validate == True

    try:
        field = FieldAttribute(
            isa='list',
            listof='str',
            default=[],
            required=True,
            always_post_validate=True
        )
        assert False
    except:
        pass

# Generated at 2022-06-11 09:40:51.974280
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Test case to verify the constructor of class FieldAttribute.
    """
    def assert_equals(parameter, value):
        """
        Asserts equality between an attribute value and the expected value
        """
        assert getattr(result, parameter) == value

    result = FieldAttribute(
        isa='list',
        private=True,
        default='my_list',
        required=True,
        listof='int',
        priority=10,
        class_type='my_class',
        always_post_validate=True,
        inherit=True,
        alias='my_alias',
        extend=True,
        prepend=True,
        # static=True,
    )

    assert_equals('isa', 'list')
    assert_equals('private', True)

# Generated at 2022-06-11 09:40:59.301956
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='list')
    assert field.isa == 'list'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False



# Generated at 2022-06-11 09:41:08.233520
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='class',private=False,default='test',required=False,listof=None,priority=0,class_type=None,always_post_validate=False,inherit=True,alias=None)
    assert a is not None
    assert a.isa == 'class'
    assert a.private == False
    assert a.default == 'test'
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None



# Generated at 2022-06-11 09:41:13.587788
# Unit test for constructor of class Attribute
def test_Attribute():
    class Foo(object):
        def __init__(self):
            self.x = Attribute(isa='list', default=[])

    bar = Foo()
    bar.x.append("foo")
    bar.x.append("bar")
    bar.x.append("fubar")

    foo2 = Foo()

    assert foo2.x != bar.x
    assert len(bar.x) == 3


# Generated at 2022-06-11 09:41:20.618565
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """Test constructor of class FieldAttribute"""
    # Test with callable default
    fa = FieldAttribute(isa='dict', default=dict)
    # Test with non-callable default
    try:
        FieldAttribute(isa='dict', default=None)
    except TypeError:
        pass
    else:
        raise AssertionError
    # Test with non-callable default
    try:
        FieldAttribute(isa='dict', default={})
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-11 09:41:30.061282
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='int').isa == 'int'
    assert FieldAttribute(isa='int', default=[1,2,3], required=True).isa == 'int'
    try:
        FieldAttribute(isa='int', default=[1,2,3])
    except TypeError:
        # Expected to catch a TypeError because default is a mutable type
        pass
    else:
        raise AssertionError("default of FieldAttribute was not properly checked for being mutable")
    assert FieldAttribute(isa='int', default=lambda: [1,2,3]).isa == 'int'
    assert FieldAttribute(isa='int', default=lambda: [1,2,3]).default() == [1,2,3]

# Generated at 2022-06-11 09:41:31.278806
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field


# Generated at 2022-06-11 09:41:36.377096
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    attr = Attribute('str', default=1)
    with pytest.raises(TypeError):
        attr.default

    assert Attribute(default=1)

    attr = Attribute(default=lambda: 1)
    assert attr.default() == 1



# Generated at 2022-06-11 09:41:44.802730
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-11 09:41:52.109424
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x= FieldAttribute(isa=dict,
                      private=False,
                      default={},
                      required=False,
                      listof=None,
                      priority=0,
                      class_type=None,
                      always_post_validate=False,
                      inherit=True,
                      alias=None,
                      extend=False,
                      prepend=False,
                      static=False)
    assert x.isa == dict
    assert x.private == False
    assert x.default == {}
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None
    assert x.extend == False
    assert x.prepend == False


# Generated at 2022-06-11 09:42:10.598654
# Unit test for constructor of class Attribute
def test_Attribute():
    # Define a set of cases:
    # Default value of isa is not None
    data_struct1 = {'isa': 'dict', 'private': True, 'default': None, 'required': False, 'listof': 'string', 'priority': 0, 'class_type': None, 'always_post_validate': False, 'inherit': True, 'alias': 'alias1'}
    Attribute1 = Attribute(**data_struct1)

# Generated at 2022-06-11 09:42:14.537600
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0,
                     class_type=None, always_post_validate=False, inherit=True, alias=None,
                     extend=False, prepend=False, static=False);

# Generated at 2022-06-11 09:42:25.902214
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def assertIsEqual(expected, actual, name):
        if actual != expected:
            raise Exception('Constructor of class FieldAttribute failed to set {0}. Expected {1}, got {2}'.format(
                name, expected, actual))

    attr = FieldAttribute(isa='list',
                          private=False,
                          required=True,
                          default=['default'],
                          listof='string',
                          priority=0,
                          class_type='string',
                          always_post_validate=True,
                          inherit=False,
                          alias='realname',
                          extend=True,
                          prepend=True,
                          static=True,
                       )

    assertIsEqual('list', attr.isa, 'isa')

# Generated at 2022-06-11 09:42:35.739125
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor with default arguments
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    # Constructor with non default arguments
    attr = Attribute(isa='dict', private=True)
    assert attr.isa == 'dict'
    assert attr.private == True

# Generated at 2022-06-11 09:42:39.857614
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert not a.private
    assert a.default is None
    assert not a.required
    assert a.priority == 0
    assert a.class_type is None
    assert not a.always_post_validate
    assert a.inherit
    assert a.alias is None
    assert not a.extend
    assert not a.prepend
    assert not a.static

    a = FieldAttribute(isa='str', private=True, default=dict, required=True, priority=2)
    assert a.isa == 'str'
    assert a.private
    assert a.default == dict
    assert a.required
    assert a.priority == 2


# Generated at 2022-06-11 09:42:49.231493
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='dict', private=True, default='default', required=True, listof='test', priority=1, class_type='test', always_post_validate=True, inherit=True, alias='alias_for_attribute', extend=True, prepend=True, static=True)
    assert attribute.isa == 'dict'
    assert attribute.private == True
    assert attribute.default == 'default'
    assert attribute.required
    assert attribute.listof == 'test'
    assert attribute.priority == 1
    assert attribute.class_type == 'test'
    assert attribute.always_post_validate == True
    assert attribute.inherit == True
    assert attribute.alias == 'alias_for_attribute'
    assert attribute.extend == True
    assert attribute.prepend == True
    assert attribute.static == True

# Generated at 2022-06-11 09:42:57.087497
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    attr = Attribute(isa='list', listof='dict', required=True, inherit=True, static=True)
    assert attr.isa == 'list'
    assert attr.listof == 'dict'
    assert attr.required == True
    assert attr.inherit == True
    assert attr.static == True

    attr = Attribute(isa='bool', default=True, required=False, inherit=False)
    assert attr.isa == 'bool'
    assert attr.default == True
    assert attr.required == False
    assert attr.inherit == False



# Generated at 2022-06-11 09:43:04.168128
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr=FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

# Test for exception in constructor of class FieldAttribute

# Generated at 2022-06-11 09:43:14.233371
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fa1 = FieldAttribute(isa='int', default=10, required=True, priority=10)
    assert fa1.isa == 'int'
    assert fa1.default == 10
    assert fa1.required == True
    assert fa1.priority == 10

    fa2 = FieldAttribute(isa='str',default=10, required=True, priority=10)
    assert fa2.isa == 'str'
    assert fa2.default == 10
    assert fa2.required == True
    assert fa2.priority == 10

    fa3 = FieldAttribute(isa='float',default=11.2, required=True, priority=10)
    assert fa3.isa == 'float'
    assert fa3.default == 11.2
    assert fa3.required == True
    assert fa3.priority == 10


# Generated at 2022-06-11 09:43:19.146604
# Unit test for constructor of class Attribute
def test_Attribute():
    # Invalid
    try:
        Attribute(isa='dict', default={'foo':'bar'})
        assert 0
    except TypeError:
        pass

    # Valid
    x = Attribute(isa='dict', default=lambda: dict(foo='bar'))
    assert isinstance(x.default(), dict)



# Generated at 2022-06-11 09:43:36.650726
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    a = Attribute()
    assert isinstance(a, Attribute)



# Generated at 2022-06-11 09:43:38.691628
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert isinstance(a, FieldAttribute)
    assert isinstance(a, Attribute)



# Generated at 2022-06-11 09:43:42.183187
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa='test', listof='list')
    assert x.isa == 'test'
    assert x.listof == 'list'

    y = Attribute(isa='test')
    assert y.isa == 'test'
    assert y.listof == None


# Generated at 2022-06-11 09:43:44.532679
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """ test FieldAttribute constructor"""
    assert isinstance(FieldAttribute(), FieldAttribute)
    assert isinstance(FieldAttribute(isa='foo', class_type=list), FieldAttribute)


# Generated at 2022-06-11 09:43:52.338161
# Unit test for constructor of class Attribute
def test_Attribute():

    def __init__(self,
                 isa=None,
                 private=False,
                 default=None,
                 required=False,
                 listof=None,
                 priority=0,
                 class_type=None,
                 always_post_validate=False,
                 inherit=True,
                 alias=None):

        self.isa = isa
        self.private = private
        self.default = default
        self.required = required
        self.listof = listof
        self.priority = priority
        self.class_type = class_type
        self.always_post_validate = always_post_validate
        self.inherit = inherit
        self.alias = alias


# Generated at 2022-06-11 09:43:53.614771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa = 'int', default = 0)
    assert field_attribute.isa == 'int'
    assert field_attribute.default == 0


# Generated at 2022-06-11 09:44:03.690139
# Unit test for constructor of class Attribute
def test_Attribute():

    # This class is used in modules that requires this
    # to be present:
    import sys
    if sys.version_info >= (3, 0):
        unicode = str

    # Test the constructor:
    test_attr = Attribute(
        isa='custom',
        alias='foobar',
        class_type='custom',
        required=False,
        listof='custom',
        default='foobar',
        priority=1,
        always_post_validate=False,
        private=True,
        inherit=False,
        extend=False,
        prepend=False,
        static=False,
    )

    # Test for isa
    assert test_attr.isa == 'custom'

    # Test for alias
    assert test_attr.alias == 'foobar'

    # Test for class_type
   

# Generated at 2022-06-11 09:44:13.707672
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str',
                     private=False,
                     default='a',
                     required=False,
                     listof=None,
                     priority=0,
                     class_type=None,
                     always_post_validate=False,
                     inherit=True,
                     alias=None,
                     extend=False,
                     prepend=False,
                     static=False)
    # Test __init__
    assert attr.isa == 'str'
    assert not attr.private
    assert attr.default == 'a'
    assert not attr.required
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None


# Generated at 2022-06-11 09:44:20.458566
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    attr = Attribute(isa="str", private=False, default=None, required=False, listof="str", priority=1, class_type="str", inherit=True, alias="alias", extend=True, prepend=True, static=True)
    assert attr.isa == "str"

# Generated at 2022-06-11 09:44:23.750870
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create an instance of FieldAttribute
    attr = FieldAttribute()

    # Verify the instance is of type FieldAttribute
    assert isinstance(attr, FieldAttribute)



# Generated at 2022-06-11 09:44:54.038107
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:45:01.519567
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute(isa='dict', default={}, listof='dict', priority=1)
    a2 = Attribute(isa='dict', default={}, listof='dict', priority=1)
    a3 = Attribute(isa='dict', default={}, listof='str', priority=1)
    a4 = Attribute(isa='dict', default={}, listof='str', priority=2)
    assert a1 == a2
    assert a1 != a3
    assert a1 < a4
    assert a1 <= a4
    assert a4 > a1
    assert a4 >= a1
    raise Exception

# Generated at 2022-06-11 09:45:02.046869
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass

# Generated at 2022-06-11 09:45:05.018302
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    data = {
        'default': None,
        'inherit': True,
        'isa': 'list',
        'listof': 'dict',
        'priority': 0
    }
    a = FieldAttribute(**data)



# Generated at 2022-06-11 09:45:15.452627
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute()
    # Attribute.__init__(a)
    new_attr = Attribute(isa='list')
    # Attribute.__init__(Attribute, isa='list')
    # new_attr = Attribute(Attribute, isa='list')
    assert new_attr.isa == 'list'
    assert new_attr.private == False
    assert new_attr.default == None
    assert new_attr.required == False
    assert new_attr.listof == None
    assert new_attr.priority == 0
    assert new_attr.class_type == None
    assert new_attr.always_post_validate == False
    assert new_attr.inherit == True
    assert new_attr.alias == None
    assert new_attr.extend == False
    assert new_attr.prepend == False

# Generated at 2022-06-11 09:45:22.837837
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    my_field = FieldAttribute()
    assert my_field.isa is None
    assert my_field.private is False
    assert my_field.default is None
    assert my_field.required is False
    assert my_field.listof is None
    assert my_field.priority == 0
    assert my_field.class_type is None
    assert my_field.always_post_validate is False
    assert my_field.inherit is True
    assert my_field.alias is None
    assert my_field.extend is False
    assert my_field.prepend is False



# Generated at 2022-06-11 09:45:32.056510
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='string')
    assert attr.isa == 'string'
    assert not attr.private
    assert attr.default == None
    assert not attr.required
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias == None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static

    attr = FieldAttribute(alias='fake_attr')
    assert attr.alias == 'fake_attr'

    l = []
    attr = FieldAttribute(default=l)
    assert attr.default == l

    attr = FieldAttribute()
    assert att

# Generated at 2022-06-11 09:45:35.465051
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa=int, required=False, default=0, class_type=list)
    assert attr.isa == int
    assert attr.required == False
    assert attr.default == 0
    assert attr.class_type == list


# Generated at 2022-06-11 09:45:37.192341
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa="bar")
    assert attr.isa == "bar"


# Generated at 2022-06-11 09:45:47.137001
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr1 = FieldAttribute(isa="int")
    assert attr1.isa == "int"
    assert attr1.private == False
    assert attr1.default == None
    assert attr1.required == False
    assert attr1.listof == None
    assert attr1.priority == 0
    assert attr1.class_type == None
    assert attr1.always_post_validate == False
    assert attr1.inherit == True
    assert attr1.alias == None
    assert attr1.extend == False
    assert attr1.prepend == False
    assert attr1.static == False
    #assert attr1.dest == None
    #assert attr1.data == None
    #assert attr1.obj == None
    #assert attr1.parent ==