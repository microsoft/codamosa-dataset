

# Generated at 2022-06-11 09:36:05.454160
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    del Attribute
    del _CONTAINERS

    FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False
    )


# Generated at 2022-06-11 09:36:11.011897
# Unit test for constructor of class Attribute
def test_Attribute():
    f = Attribute(isa='integer', default='10', required=True, class_type='test_class')
    assert f.isa == 'integer'
    assert f.private == False
    assert f.default == '10'
    assert f.required == True
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == 'test_class'
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None

# Unit test to check whether the type is container

# Generated at 2022-06-11 09:36:17.583964
# Unit test for constructor of class Attribute
def test_Attribute():

    # Tests for the default values
    a1 = Attribute()
    assert a1.default is None
    assert a1.private is False
    assert a1.required is False
    assert a1.listof is None
    assert a1.priority is 0
    assert a1.class_type is None
    assert a1.always_post_validate is False
    assert a1.inherit is True
    assert a1.alias is None
    assert a1.extend is False
    assert a1.prepend is False

    # Tests passing values

# Generated at 2022-06-11 09:36:19.282379
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', alias='_attr_')
    assert attr.alias == '_attr_'


# Generated at 2022-06-11 09:36:27.106997
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for isa
    try:
        Attribute(isa="int")
    except TypeError:
        raise AssertionError("Attribute constructor isa failed")

    # Test for private
    try:
        Attribute(private=True)
    except TypeError:
        raise AssertionError("Attribute constructor private failed")

    # Test for default
    try:
        Attribute(default="test")
    except TypeError:
        raise AssertionError("Attribute constructor default failed")

    # Test for required
    try:
        Attribute(required=True)
    except TypeError:
        raise AssertionError("Attribute constructor required failed")

    # Test for listof
    try:
        Attribute(listof="test")
    except TypeError:
        raise AssertionError("Attribute constructor listof failed")

    # Test for

# Generated at 2022-06-11 09:36:36.258133
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(isa='int', default=1, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    FA2 = FieldAttribute(isa='int', default=1, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    FA3 = FieldAttribute(isa='int', default=3, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert(FA==FA2)
    assert(FA!=FA3)
    assert(FA<FA3)
    assert(FA>FA3)

# Generated at 2022-06-11 09:36:47.711181
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(isa='list')
    assert isinstance(attr.isa, str)
    assert isinstance(attr.private, bool)
    assert isinstance(attr.default, type(None))
    assert isinstance(attr.required, bool)
    assert isinstance(attr.listof, type(None))
    assert isinstance(attr.priority, int)
    assert isinstance(attr.class_type, type(None))
    assert isinstance(attr.always_post_validate, bool)
    assert isinstance(attr.inherit, bool)
    assert isinstance(attr.alias, type(None))

    attr = Attribute(isa='list', private=True, default=True, required=True, priority=1)
    assert isinstance(attr.isa, str)

# Generated at 2022-06-11 09:36:59.594514
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_field = FieldAttribute(required=True)
    assert required_field.required == True
    non_required_field = FieldAttribute(required=False)
    assert non_required_field.required == False
    non_required_field = FieldAttribute()
    assert non_required_field.required == False

    # test that a default value is validated to be immutable
    # at the time of class creation
    # https://github.com/ansible/ansible/issues/23955
    from ansible.parsing.yaml.objects import AnsibleUnicode
    try:
        mutable_field = FieldAttribute(default={})
    except TypeError:
        pass
    else:
        raise
    try:
        mutable_field = FieldAttribute(default=[])
    except TypeError:
        pass
    else:
        raise

# Generated at 2022-06-11 09:37:05.171255
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Negative test
    try:
        f = FieldAttribute(default=['a', 'b'])
        assert False
    except TypeError as e:
        pass
    # Positive test
    default_value = [1,2,3]
    f = FieldAttribute(default=lambda: copy(default_value))
    v = f.default
    v.append(4)
    assert f.default == default_value

# Generated at 2022-06-11 09:37:14.386164
# Unit test for constructor of class Attribute
def test_Attribute():
    test_object = Attribute(isa='test', private=True, default='default', required=True, listof=None,
                            priority=0, class_type=None, always_post_validate=False, inherit=True,
                            alias='alias', extend=False, prepend=False, static=False)

    assert test_object.isa == 'test'
    assert test_object.private == True
    assert test_object.default == 'default'
    assert test_object.required == True
    assert test_object.listof is None
    assert test_object.priority == 0
    assert test_object.class_type is None
    assert test_object.always_post_validate == False
    assert test_object.inherit == True
    assert test_object.alias == 'alias'
    assert test_object.ext

# Generated at 2022-06-11 09:37:19.026533
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='dict', private=False, default=None, required=False, listof=None,
                        priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert isinstance(a, FieldAttribute)


# Generated at 2022-06-11 09:37:27.253756
# Unit test for constructor of class Attribute
def test_Attribute():
    # Create an attribute with all parameters
    attr = Attribute(isa='bool', private=True, default=False,
                     required=True, listof=False, priority=10,
                     class_type=bool, always_post_validate=True,
                     inherit=False, alias='some_alias', extend=False)

    attributes = ('isa', 'private', 'default', 'required', 'listof',
                  'priority', 'class_type', 'always_post_validate', 'inherit', 'alias')
    for a in attributes:
        assert getattr(attr, a)

    # Create an attribute with minimal parameters
    attr = Attribute()


# Generated at 2022-06-11 09:37:28.439180
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:37:35.071669
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(
        isa="str",
        private=False,
        default=None,
        required=True,
        always_post_validate=True,
        alias="test_alias",
        extend=False,
        prepend=False,
    )
    assert FA.isa == "str"
    assert FA.private == False
    assert FA.default == None
    assert FA.required == True
    assert FA.always_post_validate == True
    assert FA.alias == "test_alias"
    assert FA.extend == False
    assert FA.prepend == False



# Generated at 2022-06-11 09:37:43.498008
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.type_check import is_iterable
    fa1 = FieldAttribute(isa='string', default='hello')
    assert fa1.isa == 'string'
    assert fa1.default == 'hello'
    assert fa1.private == False
    assert fa1.required == False
    assert fa1.listof == None
    assert fa1.priority == 0
    assert fa1.class_type == None
    assert fa1.always_post_validate == False
    assert fa1.inherit == True
    assert fa1.alias == None
    assert fa1.extend == False
    assert fa1.prepend == False
    assert fa1.static == False
    assert fa1 == fa1

    fa2 = FieldAttribute(isa='string', default='hello')
    assert fa1 == fa2

    fa

# Generated at 2022-06-11 09:37:55.401938
# Unit test for constructor of class Attribute
def test_Attribute():
    # set default value to None as it should be
    def test_no_default_value():
        attr1 = Attribute()
        attr2 = Attribute()
        assert (attr1.isa == attr2.isa == None)
        assert (attr1.private == attr2.private == False)
        assert (attr1.default == attr2.default == None)
        assert (attr1.required == attr2.required == False)
        assert (attr1.listof == attr2.listof == None)
        assert (attr1.priority == attr2.priority == 0)
        assert (attr1.class_type == attr2.class_type == None)
        assert (attr1.always_post_validate == attr2.always_post_validate == False)

# Generated at 2022-06-11 09:37:56.462862
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    return True

# Generated at 2022-06-11 09:38:08.612479
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa='blarg')
    assert a.isa == 'blarg'

    a = Attribute(isa='blarg', private=True)
    assert a.isa == 'blarg'
    assert a.private == True

    a = Attribute(isa='blarg', default=dict())
    assert a.isa == 'blarg'
    assert a.default == dict()

    a = Attribute(isa='blarg', required=False)
    assert a.isa == 'blarg'
    assert a.required == False

    a = Attribute(isa='blarg', listof='list')
    assert a.isa == 'blarg'
    assert a.listof == 'list'

    a = Attribute(isa='blarg', alias="my_keyword")
    assert a.isa == 'blarg'
   

# Generated at 2022-06-11 09:38:17.225320
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #test init
    a = FieldAttribute(isa = 'int', default = 1)
    assert a
    assert a.isa == 'int'
    assert a.default == 1

    #test init with unknown key
    try:
        a = FieldAttribute(unexist = 'aaa')
        assert False
    except TypeError:
        assert True

    #test inherited isa
    a = FieldAttribute(isa = 'int')
    assert a
    assert a.isa == 'int'
    assert not a.default

    b = FieldAttribute(isa = a)
    assert b
    assert b.isa == 'int'
    assert not b.default


# Generated at 2022-06-11 09:38:25.645609
# Unit test for constructor of class Attribute
def test_Attribute():

    foo = Attribute(isa='int')
    assert foo.isa == 'int'

    foo = Attribute(isa='percent')
    assert foo.isa == 'percent'

    foo = Attribute(isa='list')
    assert foo.isa == 'list'

    foo = Attribute(isa='dict')
    assert foo.isa == 'dict'

    foo = Attribute(isa='set')
    assert foo.isa == 'set'

    class Foo:
        pass

    foo = Attribute(isa='Foo')
    assert foo.isa == 'Foo'

    foo = Attribute(isa=Foo)
    assert foo.isa == Foo

    foo = Attribute(isa=Foo, listof='int')
    assert foo.isa == Foo
    assert foo.listof == 'int'


# Generated at 2022-06-11 09:38:39.034918
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(False,True,'Hello',True,[1,2,3],0,'attr',True,False,True,False,False,False)
    assert fa is not None
    fa2 = FieldAttribute(False,True,'Hello',True,[1,2,3],0,'attr',True,False,True,False,False,False)
    assert fa == fa2
    fa3 = FieldAttribute(False,True,'Hello',True,[1,2,3],2,'attr',True,False,True,False,False,False)
    assert fa != fa3
    assert fa < fa3
    assert fa3 > fa
    assert fa <= fa3
    assert fa3 >= fa


# Generated at 2022-06-11 09:38:42.440111
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(isa='dict', default={'a':1})
    except TypeError as e:
        assert e.message == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'
    else:
        assert False, 'Should have raised a TypeError'

# Generated at 2022-06-11 09:38:53.449688
# Unit test for constructor of class Attribute
def test_Attribute():
    attr1 = Attribute()
    assert attr1.isa is None
    assert attr1.private is False
    assert attr1.default is None
    assert attr1.required is False
    assert attr1.listof is None
    assert attr1.priority == 0
    assert attr1.class_type is None
    assert attr1.always_post_validate is False
    assert attr1.inherit is True
    assert attr1.alias is None
    assert attr1.extend is False
    assert attr1.prepend is False
    assert attr1.static is False


# Generated at 2022-06-11 09:39:04.609698
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', default=42)
    assert a.isa == 'int'
    assert a.private == False
    assert a.default == 42
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False

    a = Attribute(isa='int', default=42.0)
    assert a.isa == 'int'
    assert a.private == False
    assert a.default == 42.0
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0

# Generated at 2022-06-11 09:39:10.014337
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'list'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None

    f = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)

    assert isa == f.isa

# Generated at 2022-06-11 09:39:16.044806
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='int',
        private=True,
        default=1,
        required=True,
        listof='foo',
        priority=0,
        class_type='handle',
        always_post_validate=True,
        inherit=False,
        alias='baz',
        extend=False,
        prepend=False,
        static=False,
    )

    assert fa.isa == 'int'
    assert fa.private == True
    assert fa.default == 1
    assert fa.required == True
    assert fa.listof == 'foo'
    assert fa.priority == 0
    assert fa.class_type == 'handle'
    assert fa.always_post_validate == True
    assert fa.inherit == False
    assert fa.alias == 'baz'
   

# Generated at 2022-06-11 09:39:26.669994
# Unit test for constructor of class Attribute
def test_Attribute():

    # Should not throw an exception
    Attribute(
        isa='set',
        private=False,
        default=set(["test"]),
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # Should throw an exception

# Generated at 2022-06-11 09:39:34.677354
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that 'default' must not be mutable
    failed = False
    try:
        f = Attribute(isa='list', default={})
    except TypeError:
        failed = True
    assert failed

    # Test that 'default' can be a function which returns a valid value
    f = Attribute(isa='list', default=lambda: [])
    default_value = f.default
    assert default_value == []

    # Test that 'default' can be a function which returns None
    f = Attribute(isa='list', default=lambda: None)
    default_value = f.default
    assert default_value is None



# Generated at 2022-06-11 09:39:46.790614
# Unit test for constructor of class Attribute
def test_Attribute():
    isa='test_isa'
    private=True
    default='test_default'
    required='test_required'
    listof='test_listof'
    priority=1
    class_type='test_class_type'
    always_post_validate='test_always_post_validate'
    alias='test_alias'
    extend='test_extend'
    prepend='test_prepend'
    static='test_static'

    a = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, alias=alias, extend=extend, prepend=prepend, static=static)

    assert a.isa == isa
    assert a.private == private
    assert a.default == default
    assert a.required == required
    assert a.listof

# Generated at 2022-06-11 09:39:54.575746
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(default='some')
    assert attr.default == 'some'

    # Passing in a non-callable default should raise an exception
    try:
        attr = Attribute(default=[])
    except TypeError:
        pass
    else:
        raise Exception('Attribute constructor did not raise a TypeError on an non-callable default')

    # Passing in a callable default should not raise an exception
    try:
        attr = Attribute(default=lambda: [])
    except:
        raise Exception('Attribute constructor raised an exception on a callable default')

# Generated at 2022-06-11 09:40:06.832507
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()
    Attribute(isa=None)
    Attribute(isa=False)
    Attribute(isa="something")
    Attribute(isa="dict")
    Attribute(private="private")
    Attribute(default=["default1", "default2"])
    Attribute(required=True)
    Attribute(listof="listof")
    Attribute(priority=1)
    Attribute(class_type=Exception)
    Attribute(always_post_validate=True)


# Generated at 2022-06-11 09:40:12.444083
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa == None
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False

# Unit test to test if defaults for FieldAttribute are not mutable

# Generated at 2022-06-11 09:40:16.087970
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test that constructor does not accept a mutable default
    try:
        Attribute(default={})
    except TypeError:
        pass
    else:
        raise AssertionError('{} constructor accepted mutable default')


# Generated at 2022-06-11 09:40:20.129045
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field = FieldAttribute(default=list())
        assert False
    except TypeError:
        pass

    try:
        field = FieldAttribute(default=dict())
        assert False
    except TypeError:
        pass

    field = FieldAttribute(default=set())
    assert field is not None



# Generated at 2022-06-11 09:40:20.693990
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-11 09:40:30.065321
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    spec_file = "/home/vitaly/pycharm/ansible//lib/ansible/parsing/dataloader.py"
    test_file = "./test_file.txt"
    error_message = "Test failed."

    with open(spec_file, "r") as f:
        with open(test_file, "w") as f1:
            for line in f:
                f1.write(line)

    # test case 1
    try:
        default = {'1': '1'}
        field_attr_1 = FieldAttribute(isa='dict', default=default)
        if field_attr_1.isa != 'dict' or field_attr_1.default != default:
            print(error_message)
            exit(1)
    except TypeError:
        pass


# Generated at 2022-06-11 09:40:39.343079
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test defaults
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False

    # Test basic datatype
    a = Attribute(isa='str')
    assert a.isa == 'str'

    # Test basic datatype
    a = Attribute(isa='path')
    assert a.isa == 'path'

    # Test class
    a = Attribute(isa='class')
    assert a.isa

# Generated at 2022-06-11 09:40:41.301095
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    new_Attribute=FieldAttribute(isa='test')
    assert new_Attribute is not None
    assert new_Attribute.isa is 'test'



# Generated at 2022-06-11 09:40:49.363985
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert a.isa == 'str'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None


# Generated at 2022-06-11 09:41:00.211618
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert not attribute.private
    assert attribute.default is None
    assert not attribute.required
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert not attribute.always_post_validate
    assert attribute.inherit
    assert attribute.alias is None

    attribute = Attribute(
        isa='list',
        private=True,
        default='the_default',
        required=True,
        listof='dict',
        priority=100,
        class_type=list,
        always_post_validate=True,
        inherit=False,
        alias='the_alias'
    )
    assert attribute.isa == 'list'
    assert attribute.private

# Generated at 2022-06-11 09:41:13.977171
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create a FieldAttribute object
    attribute = FieldAttribute()
    # Check that the type of the object is FieldAttribute
    assert type(attribute) is FieldAttribute


# Generated at 2022-06-11 09:41:18.940821
# Unit test for constructor of class Attribute
def test_Attribute():

    # The defaults of this class are the following
    # isa = None
    # private = False
    # default = None
    # required = False
    # listof = None
    # priority = 0
    # class_type = None
    # Doesn't make sense to test this because this class is only used by the
    # Ansible classes.

    pass



# Generated at 2022-06-11 09:41:20.819704
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.__class__.__name__ == 'Attribute'

# Generated at 2022-06-11 09:41:25.018193
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
  try:
    field_attribute = FieldAttribute(default="test", isa="dict")
  except:
    pass
  else:
    raise Exception("Default values of type list or dict should raise a TypeError")
  field_attribute = FieldAttribute(default=lambda: {}, isa="dict")


# Generated at 2022-06-11 09:41:36.816727
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    No assert: only print()
    """
    attr = Attribute()
    attr2 = Attribute()
    print(attr)
    print(attr2)
    print(attr == attr2)
    print(attr < attr2)
    print(attr > attr2)
    print(attr <= attr2)
    print(attr >= attr2)
    print(attr != attr2)
    attr.private = not attr.private
    print(attr != attr2)
    attr2.private = not attr2.private
    print(attr != attr2)
    attr.private = not attr.private
    attr.default = None
    print(attr != attr2)
    attr.default = 1
    print(attr != attr2)
   

# Generated at 2022-06-11 09:41:48.321681
# Unit test for constructor of class Attribute
def test_Attribute():
    """This is a basic test of the Attribute constructor"""
    test_attr = Attribute(isa=int,
                          default=123,
                          required=True,
                          listof=str,
                          priority=0,
                          class_type=Attribute,
                          always_post_validate=True,
                          inherit=True,
                          alias='testing_alias')

    assert test_attr.isa == int
    assert test_attr.private is False
    assert test_attr.default == 123
    assert test_attr.required is True
    assert test_attr.listof == str
    assert test_attr.priority == 0
    assert test_attr.class_type == Attribute
    assert test_attr.always_post_validate is True
    assert test_attr.inherit is True
    assert test_attr

# Generated at 2022-06-11 09:41:56.297418
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test empty constructor
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.priority == 0
    assert a.class_type == None
    assert a.inherit == True
    assert a.alias == None

    # Test full constructor
    a = Attribute(
        isa='list',
        private=False,
        default=None,
        required=True,
        listof='str',
        priority=10,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='foo'
    )
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == True

# Generated at 2022-06-11 09:42:08.601099
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    default = []
    attr = FieldAttribute(isa='class', default=default)
    assert attr.isa == 'class'
    assert isinstance(attr.default, list)
    assert attr.default is not default

    attr = FieldAttribute(default=[])
    assert isinstance(attr.default, list)
    assert attr.default is not default

    # You may not use mutable types as defaults directly

    try:
        attr = FieldAttribute(isa='class', default=[])
    except TypeError as e:
        assert 'defaults for FieldAttribute may not be mutable' in str(e)
    else:
        assert False

    # however, default callables are fine

    default = []
    attr = FieldAttribute(isa='class', default=lambda: default)
    assert isinstance(attr.default, list)

# Generated at 2022-06-11 09:42:10.005360
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    metadata = FieldAttribute(default='test')
    assert metadata.default == 'test'

# Generated at 2022-06-11 09:42:17.881677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert not isinstance(FieldAttribute(), FieldAttribute)
    assert isinstance(FieldAttribute(isa='list'), FieldAttribute)
    assert isinstance(FieldAttribute(isa='list', default=[]), FieldAttribute)
    assert isinstance(FieldAttribute(isa='list', default=None), FieldAttribute)
    assert isinstance(FieldAttribute(isa='list', default=lambda: []), FieldAttribute)
    try:
        FieldAttribute(isa='list', default=[])
        assert False
    except TypeError:
        assert True
    try:
        FieldAttribute(isa='list', default={})
        assert False
    except TypeError:
        assert True
    try:
        FieldAttribute(isa='list', default=set([]))
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-11 09:42:47.310995
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    with pytest.raises(TypeError):
        a = Attribute(default={})

    a = Attribute(isa='list', default=[], required=True)
    assert a.isa == 'list'
    assert a.default == []

    a = Attribute(isa='list', default=lambda: [])
    assert a.isa == 'list'
    assert a.default != []
    assert a.default != None

   

# Generated at 2022-06-11 09:42:51.833894
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa="str", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)


# Generated at 2022-06-11 09:42:58.351874
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='str')
    assert not Attribute(required=True, default='foo')
    try:
        Attribute(isa='list', default={})
        assert False
    except TypeError as e:
        assert True
    try:
        Attribute(isa='list', default=[])
        assert False
    except TypeError as e:
        assert True
    try:
        Attribute(isa='list', default=lambda: [])
        assert False
    except TypeError as e:
        assert True



# Generated at 2022-06-11 09:43:03.615498
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str', required=True)
    assert a.isa == 'str' and a.required is True and a.private is False and a.default is None and a.listof is None and \
        a.priority == 0 and a.class_type is None and a.always_post_validate is False and a.inherit is True and a.alias is None and a.extend is False and a.prepend is False


# Generated at 2022-06-11 09:43:12.049864
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False

    attr = FieldAttribute(isa='list', default=7, required=True, listof='str', priority=5, class_type=str, always_post_validate=True)
    assert attr.default == 7
    assert attr.required is True
    assert attr.listof == 'str'
    assert attr.priority == 5
    assert attr.class_type == str
    assert attr.always_post_validate is True



# Generated at 2022-06-11 09:43:24.508405
# Unit test for constructor of class Attribute
def test_Attribute():
    listof_set = set([1,2,3])
    class_type = 1
    a = Attribute(isa='int', private=False, default=1, required=False, listof=listof_set, priority=0, class_type=class_type, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert(a.isa == 'int' and a.private == False and a.default == 1 and a.required == False and a.listof == listof_set and a.priority == 0 and a.class_type == class_type and a.always_post_validate == False and a.inherit == True and a.alias == None and a.extend == False and a.prepend == False and a.static == False)

# Unit

# Generated at 2022-06-11 09:43:30.885398
# Unit test for constructor of class Attribute
def test_Attribute():
    attr1 = Attribute(isa="string", private=True, default='', required=True, listof=None, priority=0)
    attr2 = Attribute(isa="dict", private=False, default={}, required=False, listof=None, priority=1)
    attr3 = Attribute(isa="list", private=False, default=[], required=False, listof='dict', priority=2)
    attr4 = Attribute(isa="str", private=False, default=None, required=True, listof=None, priority=3)

    assert attr1.isa == 'string'
    assert attr1.private == True
    assert attr1.default == ''
    assert attr1.required == True
    assert attr1.listof == None
    assert attr1.priority == 0

    assert att

# Generated at 2022-06-11 09:43:32.292176
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f is not None


# Generated at 2022-06-11 09:43:41.419330
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test normal calls
    assert FieldAttribute()
    assert FieldAttribute("dict", private=True, default=dict())
    assert FieldAttribute("dict", private=True, default=dict())
    assert FieldAttribute("str", private=True, default="")
    assert FieldAttribute("list", private=True, default=list())
    assert FieldAttribute("str", private=True, default="", required=True)
    assert FieldAttribute("list", private=True, default=list(), listof="str")
    assert FieldAttribute("list", private=True, default="", listof="str")
    assert FieldAttribute("dict", private=True, default=dict(), listof="dict")
    assert FieldAttribute("dict", private=True, default=dict(a="b"), listof="dict")

# Generated at 2022-06-11 09:43:45.817211
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Inherit all the defaults
    fa = FieldAttribute()
    # Lightly exercise the constructor of class FieldAttribute
    fa = FieldAttribute(isa='list')
    assert fa.isa == 'list'
    fa = FieldAttribute(isa='dict')
    assert fa.isa == 'dict'
    fa = FieldAttribute(isa='set')
    assert fa.isa == 'set'

# Generated at 2022-06-11 09:44:43.398505
# Unit test for constructor of class Attribute
def test_Attribute():
    _field = Attribute(isa='str', private = False, default = None, required = True, listof = None, priority = 0, class_type = None, always_post_validate = False, inherit = True, alias = None, extend = False, prepend = False)
    assert _field.isa == 'str'
    assert _field.private == False
    assert _field.default == None
    assert _field.required == True
    assert _field.listof == None
    assert _field.priority == 0
    assert _field.class_type == None
    assert _field.always_post_validate == False
    assert _field.inherit == True
    assert _field.alias == None
    assert _field.extend == False
    assert _field.prepend == False


# Generated at 2022-06-11 09:44:48.811205
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.base import Base as test_base

    class test_object(test_base):
        test_field = FieldAttribute(isa='list', default=list, required=True, listof=str, priority=0)
        test_field2 = FieldAttribute(isa='list', default=list, required=True, listof=str, priority=1)
        test_field3 = FieldAttribute(isa='list', default=list, required=True, listof=str, priority=1)
        test_field4 = FieldAttribute(isa='list', default=list, required=True, listof=str, priority=2)
        test_field5 = FieldAttribute(isa='list', default=list, required=True, listof=str, priority=2)

        # Make sure that non-priority ordering is not an issue
        test_field

# Generated at 2022-06-11 09:44:59.127636
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='some_value', default='hello', required=True)
    assert attr.isa == 'some_value'
    assert attr.private == False
    assert attr.default == 'hello'
    assert attr.required == True
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.alias is None

    attr = Attribute(isa='some_value', default=set(), required=True)
    assert attr.default == set()

    # defaults for FieldAttribute may not be mutable, please provide a callable instead
    try:
        attr = Attribute(isa='some_value', default=[], required=True)
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-11 09:45:08.425713
# Unit test for constructor of class Attribute
def test_Attribute():

    # Until this test passes, 'Attribute' is still not a class
    assert Attribute is not None, "'Attribute' constructor is not a class!"

    # Ensure that 'Attribute' raises an exception when the argument 'default' is not a callable
    assert Attribute(default=1) is not None, "'Attribute' raises exception when the argument 'default' is not a callable"
    assert Attribute(default=dict) is not None, "'Attribute' raises exception when the argument 'default' is not a callable"
    assert Attribute(default=[]) is not None, "'Attribute' raises exception when the argument 'default' is not a callable"
    assert Attribute(default=set) is not None, "'Attribute' raises exception when the argument 'default' is not a callable"

# Generated at 2022-06-11 09:45:15.741970
# Unit test for constructor of class Attribute
def test_Attribute():
    expected_result = dict( class_type=None,
                            default=None,
                            extend=False,
                            inherit=True,
                            isa='AnsibleModuleTest',
                            listof=None,
                            prepend=False,
                            private=False,
                            required=False,
                            static=False,
                            validate=True
                            )
    actual_result = Attribute(isa='AnsibleModuleTest', static=True)
    assert actual_result.__dict__ == expected_result

# Generated at 2022-06-11 09:45:25.679809
# Unit test for constructor of class Attribute
def test_Attribute():
    from jinja2.exceptions import UndefinedError
    from ansible.parsing import vault

    class TestClass:
        class_attr = FieldAttribute(
            isa='class',
            always_post_validate=True,
        )
        data_attr = FieldAttribute(
            isa='dict',
            always_post_validate=True,
        )
        list_attr = FieldAttribute(
            isa='list',
            always_post_validate=True,
        )
        set_attr = FieldAttribute(
            isa='set',
            always_post_validate=True,
        )
        extend_attr = FieldAttribute(
            isa='list',
            extend=True,
        )

# Generated at 2022-06-11 09:45:34.201408
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(
        isa='str',
        private=False,
        default=None,
        required=True,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False
       )
    assert attribute.isa == 'str'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == True
    assert attribute.listof == 'str'
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.pre

# Generated at 2022-06-11 09:45:39.638714
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-11 09:45:49.376898
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str',
                     private=False,
                     default='test',
                     required=False,
                     listof=False,
                     priority=0,
                     class_type=None,
                     always_post_validate=False,
                     inherit=True,
                     alias=None)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'test'
    assert attr.required == False
    assert attr.listof == False
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-11 09:45:58.223250
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa='string', private=True, default='my_default', required=True, listof='string',
                     priority=0, class_type='dict', always_post_validate=False,
                     inherit=True, alias='my_alias', extend=False, prepend=False)
    assert isinstance(attr, Attribute)
    assert attr.isa == 'string'
    assert attr.private is True
    assert attr.default == 'my_default'
    assert attr.required is True
    assert attr.listof == 'string'
    assert attr.priority == 0
    assert attr.class_type == 'dict'
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias == 'my_alias'
   