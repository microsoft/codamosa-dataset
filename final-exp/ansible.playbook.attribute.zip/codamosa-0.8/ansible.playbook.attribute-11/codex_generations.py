

# Generated at 2022-06-11 09:36:07.525631
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string')
    assert field.isa == 'string'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False



# Generated at 2022-06-11 09:36:08.628863
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr1 = FieldAttribute()
    assert field_attr1 is not None



# Generated at 2022-06-11 09:36:15.811510
# Unit test for constructor of class Attribute
def test_Attribute():
    # default
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    # dict
    a = Attribute(isa='dict')
    assert a.isa == 'dict'

    # custom
    a = Attribute(default='foo')
    assert a.default == 'foo'

    # listof
    a = Attribute(listof='string')
    assert a.list

# Generated at 2022-06-11 09:36:23.783092
# Unit test for constructor of class Attribute
def test_Attribute():

    # Expected:
    #   private=False
    #   default=None
    #   required=False
    #   listof=None
    #   priority=0
    #   class_type=None
    #   always_post_validate=False
    #   inherit=True
    #   alias=None
    attribute = Attribute()

    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority is 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None

    # Expected:
    #   private=False
    #   default=None
    #   required=False
    #   listof=

# Generated at 2022-06-11 09:36:31.045683
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(1).__dict__ == Attribute(isa = 1).__dict__

# Generated at 2022-06-11 09:36:41.058964
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible import constants as C
    from ansible.utils.boolean import boolean

    FA = FieldAttribute
    fa = FA(isa='boolean', default=True, required=True, listof='string')
    assert fa
    assert isinstance(fa, Attribute)
    assert fa.isa == 'boolean'
    assert fa.default is True
    assert fa.required is True
    assert fa.listof == 'string'
    assert fa.inherit is True
    assert fa.static is False

    fa.default = '{{ansible_user_dir}}'
    d = copy(C.DEFAULT_HANDLER_ATTRIBUTE_WARNINGS)

    fa.default = dict(a=1, b=2)
    assert fa.default == dict(a=1, b=2)

# Generated at 2022-06-11 09:36:41.694932
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute



# Generated at 2022-06-11 09:36:54.694981
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils.facts.system.apparmor import ApparmorFactCollector

    def mycallable():
        pass

    attribute = Attribute(isa='list', alias='test')
    assert attribute.isa == 'list'
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias == 'test'
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False


# Generated at 2022-06-11 09:36:55.847360
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr=FieldAttribute()
    assert attr.alias is None

# Generated at 2022-06-11 09:37:03.424068
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    # Test initial defaults
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False
    # Test setting/getting defaults
    attr.isa = 'str'
    assert attr.isa == 'str'
    attr.private = True
    assert attr.private is True
    attr.default = 'default'


# Generated at 2022-06-11 09:37:14.254914
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list',
                  private=False,
                  default=None,
                  required=True,
                  listof='int',
                  priority=10,
                  class_type='json',
                  always_post_validate=False,
                  inherit=False,
                  alias='rabbit',
                  extend=False,
                  prepend=True,
                  static=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == True
    assert a.listof == 'int'
    assert a.priority == 10
    assert a.class_type == 'json'
    assert a.always_post_validate == False
    assert a.inherit == False
    assert a.alias == 'rabbit'

# Generated at 2022-06-11 09:37:22.052333
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test field atrribute with default
    attribute = FieldAttribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False

    # Test field atrribute with parameter
    attribute = FieldAttribute(isa='list')
    assert attribute.isa == 'list'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None

# Generated at 2022-06-11 09:37:23.251232
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
   attribute = Attribute(isa="hello",default=10)


# Generated at 2022-06-11 09:37:24.141687
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field



# Generated at 2022-06-11 09:37:25.328411
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(None, default=None)



# Generated at 2022-06-11 09:37:26.497917
# Unit test for constructor of class Attribute
def test_Attribute():
    p = Attribute(isa='list')
    assert p.isa == 'list'

# Generated at 2022-06-11 09:37:35.719524
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # Validate that an exception is raised when an invalid value is provided
    # for the 'isa' parameter.
    with pytest.raises(TypeError) as excinfo:
        fa = FieldAttribute(isa = 'string')
    assert 'Invalid isa' in str(excinfo.value)

    # Validate that an

# Generated at 2022-06-11 09:37:38.475345
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test = FieldAttribute()
    assert test.isa is None
    assert test.default is None
    assert test.required is False
    assert test.listof is None
    assert test.priority == 0
    assert test.class_type is None

# Generated at 2022-06-11 09:37:45.900764
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr_0 = FieldAttribute(isa='list', listof='dict', default=deepcopy)
    assert attr_0.isa == 'list'
    assert attr_0.listof == 'dict'
    assert attr_0.default == deepcopy
    assert attr_0.inherit

    attr_1 = FieldAttribute(isa='list', listof='dict', default=deepcopy, inherit=False)
    assert attr_1.isa == 'list'
    assert attr_1.listof == 'dict'
    assert attr_1.default == deepcopy
    assert not attr_1.inherit


# Generated at 2022-06-11 09:37:50.334528
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    class TestFieldAttribute(unittest.TestCase):
        def test_FieldAttribute(self):
            try:
                FieldAttribute('dict', default={}, prepend=True)
            except TypeError:
                self.assertTrue(False, "Default should not be mutable, "
                    "please provide a callable instead.")
            except:
                pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFieldAttribute)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-11 09:38:02.643246
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    result = str(FieldAttribute(isa='string', private=False, default='test', required=False, listof=False, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False))
    print(result)
    assert result == '<FieldAttribute isa=string private=False default=test required=False listof=False priority=0 class_type=None always_post_validate=False inherit=True alias=None extend=False prepend=False static=False>'
    print("FieldAttribute unit test finished successfully")

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-11 09:38:09.991334
# Unit test for constructor of class Attribute
def test_Attribute():
    field = Attribute(isa='list', default=[])
    assert field.isa == 'list'
    assert field.private == False
    assert field.default == []
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False
    assert field.static == False



# Generated at 2022-06-11 09:38:15.907606
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(
        isa=int,
        private=False,
        default=0,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# Generated at 2022-06-11 09:38:22.567550
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field is not None
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is None
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False



# Generated at 2022-06-11 09:38:30.508717
# Unit test for constructor of class Attribute
def test_Attribute():
    # pylint: disable=unused-argument
    def make_dict():
        return dict()

    class Foo(object):
        bar = FieldAttribute(default=make_dict)

    foo = Foo()
    assert isinstance(foo.bar, dict)

    try:
        class Bar(object):
            foo = FieldAttribute(default={})
    except TypeError as e:
        assert str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'
    else:
        raise Exception('expected TypeError to be raised')

# Generated at 2022-06-11 09:38:38.303968
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='str',
        private=False,
        default='my_str',
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    assert not fa.private
    assert fa.inherit



# Generated at 2022-06-11 09:38:45.161625
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(private=True, default='private', required=True, listof='str', priority=1)
    assert a.private is True, 'Attribute should be private'
    assert a.default == 'private', 'Attribute should be private'
    assert a.required is True, 'Attribute should be required'
    assert a.listof == 'str', 'Attribute should be list of str'
    assert a.priority == 1, 'Attribute should be priority 1'
    try:
        a = Attribute(default=[], required=True)
        raise ValueError('default should not be mutable')
    except TypeError:
        pass



# Generated at 2022-06-11 09:38:56.914363
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # False for all types
    for _type in ('dict', 'list', 'set', None):
        try:
            field = FieldAttribute(default={}, isa=_type)
            assert False, "FieldAttribute(default={}, isa=%s) should fail" % _type
        except TypeError:
            pass
    # False for specific types
    for _type in ('dict', 'list', 'set'):
        for _default in ({}, [], set()):
            try:
                field = FieldAttribute(default=_default, isa=_type)
                assert False, "FieldAttribute(default=%s, isa=%s) should fail" % (_default, _type)
            except TypeError:
                pass
    # True for all types

# Generated at 2022-06-11 09:39:07.671087
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test the default value for priority
    f = FieldAttribute(isa='int')
    assert f.priority == 0

    f = FieldAttribute(isa='int', priority=10)
    assert f.priority == 10

    # Test a normal constructor
    f = FieldAttribute(
        isa='int',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True
    )
    assert f.isa == 'int'
    assert f.private == False
    assert f.default is None
    assert f.required == False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_

# Generated at 2022-06-11 09:39:13.362714
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute()
    assert a
    assert not a.required
    assert a.alias is None
    assert a.default is None
    a = Attribute(isa="list", default=list)
    assert a
    assert not a.required
    assert a.alias is None
    assert a.default is list
    a = Attribute(isa="list", default=[1, 2, 3])
    assert a
    assert not a.required
    assert a.alias is None
    assert a.default == [1, 2, 3]


# Generated at 2022-06-11 09:39:17.316198
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='int')


# Generated at 2022-06-11 09:39:21.395303
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # OK if no error
    assert FieldAttribute() is not None
    # OK if no error
    assert FieldAttribute(isa='int', default=0) is not None
    # OK if no error
    assert FieldAttribute(isa='str', default=0) is not None


# Generated at 2022-06-11 09:39:31.616118
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    This test exists for the constructor of the class FieldAttribute. It tests
    the class initialization with each possible string for the 'isa' parameter,
    and the 'private' parameter.

    This test is needed because the code that executes after the initialization
    is only executed if the initialization is successful.
    """

    # This class is used in an isinstance() call
    class TestClass:
        pass

    # Test all basic types; these are the only types which are valid for
    # the 'isa' parameter.
    for isa in ('bool', 'boolean', 'dict', 'float', 'int', 'integer',
                'list', 'none', 'path', 'regexp', 'set', 'str', 'string'):
        FieldAttribute(isa=isa)

    # Test with a class type

# Generated at 2022-06-11 09:39:33.001184
# Unit test for constructor of class Attribute
def test_Attribute():
    tmp = Attribute()
    assert isinstance(tmp, Attribute)



# Generated at 2022-06-11 09:39:35.582463
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='dict', default=dict)
    assert field_attribute.isa == 'dict'
    assert callable(field_attribute.default)


# Generated at 2022-06-11 09:39:43.150056
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert not Attribute().private
    assert Attribute().default == None
    assert not Attribute().required
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert not Attribute().always_post_validate
    assert Attribute().inherit
    assert Attribute().alias == None
    assert not Attribute().extend
    assert not Attribute().prepend
    assert not Attribute().static



# Generated at 2022-06-11 09:39:54.616447
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(default="this is a default", isa='string')
    assert attr.default == "this is a default"

    attr = Attribute(default=None, isa='string')
    assert attr.default == None

    attr = Attribute(default=[], isa='list')
    assert attr.default == []

    attr = Attribute(default=dict(), isa='dict')
    assert attr.default == dict()

    attr = Attribute(default=dict(), isa=dict)
    assert attr.default == dict()

    attr = Attribute(default=set(), isa='set')
    assert attr.default == set()

    attr = Attribute(default=set(), isa=set)
    assert attr.default == set()

#    attr =

# Generated at 2022-06-11 09:40:06.137161
# Unit test for constructor of class Attribute
def test_Attribute():

    import pytest
    from ansible.module_utils import basic

    with pytest.raises(TypeError) as excinfo:
        Attribute(isa='list', default=[1, 2, 3])
    assert "may not be mutable" in str(excinfo.value)

    # Should use the callable default and add 4 to the list
    a = Attribute(isa='list', default=lambda: [1, 2, 3])
    assert a.default() == [1, 2, 3]
    assert a.default() == [1, 2, 3]
    assert a.default() == [1, 2, 3]

    a = Attribute(isa='list', default=lambda: [1, 2, 3])
    assert a.default() == [1, 2, 3]

# Generated at 2022-06-11 09:40:15.579917
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa = 'int',
        default = 0
    )
    assert(attr.isa == 'int')
    assert(attr.default == 0)

    assert (attr.__eq__(attr) == True)
    assert (attr.__ne__(attr) == False)

    attr2 = Attribute(
        isa = 'int',
        default = 0,
        priority = 1
    )

    assert (attr2 < attr)
    assert (attr2 > attr) == False
    assert (attr == attr2) == False
    assert (attr != attr2) == True
    assert (attr2 >= attr)
    assert (attr2 <= attr) == False

# Generated at 2022-06-11 09:40:16.525336
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute() is not None


# Generated at 2022-06-11 09:40:30.541819
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    '''Constructor FieldAttribute()'''
    def def_func():
        return 'something'
    # test all keyword inputs
    f1 = FieldAttribute(isa=int, private=True, default=def_func, required=True,
                        listof=str, priority=1, class_type=dict, alias="test_attr")
    f2 = FieldAttribute(isa=int, private=True, default=def_func, required=True,
                        listof=str, priority=1, class_type=dict, alias="test_attr")
    assert f1 == f2
    assert f1 <= f2
    assert f1 >= f2
    assert not f1 != f2
    assert not f1 > f2
    assert not f1 < f2
    # test no keyword inputs
    f3 = FieldAttribute()
    assert f3

# Generated at 2022-06-11 09:40:31.502547
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute()



# Generated at 2022-06-11 09:40:34.903673
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Test the constructor of the class Attribute
    '''
    # Create an instance of the class Attribute
    attr = Attribute(isa='foo')
    # Check the value of the attribute 'isa'
    assert attr.isa == 'foo'


# Generated at 2022-06-11 09:40:36.278180
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f is not None


# Generated at 2022-06-11 09:40:42.619849
# Unit test for constructor of class Attribute
def test_Attribute():

    # For test purpose these parameters are chosen.
    isa="int"
    private=False
    default=None
    required=False
    listof=None
    priority=0
    class_type=None
    always_post_validate=False
    inherit=True
    alias="No Alias"

    try:
        attr = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    except:
        return 0

    # Attribute object is created successfully
    return 1

# Generated at 2022-06-11 09:40:44.005996
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa is not None


# Generated at 2022-06-11 09:40:46.064201
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        f = FieldAttribute(default=[])
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-11 09:40:56.904977
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = int
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False


# Generated at 2022-06-11 09:41:00.659865
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str',
                  private=False,
                  default='default',
                  required=True,
                  listof='str',
                  priority=0,
                  class_type='class',
                  always_post_validate=True,
                  inherit=True,
                  alias='alias',
                  extend=False,
                  prepend=True,
                  static=False)

    assert a.isa == 'str'
    assert a.private == False
    assert a.default == 'default'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == 'class'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'alias'

# Generated at 2022-06-11 09:41:08.371178
# Unit test for constructor of class Attribute
def test_Attribute():
    f = FieldAttribute
    assert f().priority == 0
    assert f(priority=100).priority == 100
    assert f(default='foo').default == 'foo'
    assert f().listof is None
    assert f(listof='bool').listof == 'bool'
    assert f(class_type=int).class_type is int
    assert f(class_type='int').class_type == 'int'
    assert f().inherit
    assert not f(required=True).inherit
    assert not f(inherit=False).inherit
    assert f().alias is None

# Generated at 2022-06-11 09:41:18.710383
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute()



# Generated at 2022-06-11 09:41:20.981443
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False

# Generated at 2022-06-11 09:41:31.953926
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa="test", private=False, default=None, required=False, listof="list", priority=0, class_type="class", always_post_validate=True, inherit=True, alias="alias", extend=False, prepend=False, static=False)
    assert attr.isa == "test"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == "list"
    assert attr.priority == 0
    assert attr.class_type == "class"
    assert attr.always_post_validate == True
    assert attr.inherit == True
    assert attr.alias == "alias"
    assert attr.extend == False
    assert attr.prepend == False

# Generated at 2022-06-11 09:41:33.264214
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute(isa="list", default=[])


# Generated at 2022-06-11 09:41:44.552482
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa='string', private=True, default='foo', required=True,
                  listof='string', priority=1, class_type='class', inherit=True,
                  alias='foo', extend=False, prepend=False, static=True)

    assert a.isa == 'string'
    assert a.private == True
    assert a.default == 'foo'
    assert a.required == True
    assert a.listof == 'string'
    assert a.priority == 1
    assert a.class_type == 'class'
    assert a.inherit == True
    assert a.alias == 'foo'
    assert a.extend == False
    assert a.prepend == False
    assert a.static == True



# Generated at 2022-06-11 09:41:53.347247
# Unit test for constructor of class Attribute
def test_Attribute():
    attributes = ('isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type', 'always_post_validate', 'inherit', 'alias', 'extend', 'prepend', 'static')
    # Test required arguments
    initialized_attr = Attribute()
    for attr in attributes:
        assert hasattr(initialized_attr, attr)
    # Test all arguments
    initialized_attr_2 = Attribute(isa=str, private=True, default='default', required=True, listof='listof', priority=0, class_type=FieldAttribute, always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=True)
    for attr in attributes:
        assert getattr(initialized_attr_2, attr)



# Generated at 2022-06-11 09:42:01.792285
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default=lambda: {}, always_post_validate=True, alias='test_name')
    print(attr.isa)
    print(attr.private)
    print(attr.default)
    print(attr.required)
    print(attr.listof)
    print(attr.priority)
    print(attr.class_type)
    print(attr.always_post_validate)
    print(attr.inherit)
    print(attr.alias)
    print(attr.extend)
    print(attr.prepend)
    print(attr.static)

test_FieldAttribute()


# Generated at 2022-06-11 09:42:13.531096
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert FA.isa == 'dict'
    assert FA.private == False
    assert FA.default == None
    assert FA.required == False
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert FA.always_post_validate == False
    assert FA.inherit == True
    assert FA.alias == None
    assert FA.extend == False


# Generated at 2022-06-11 09:42:16.148859
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_field_attribute = FieldAttribute(isa='test')
    assert test_field_attribute.isa == 'test'


# Generated at 2022-06-11 09:42:18.641790
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert Attribute().__class__.__name__ == 'Attribute'
    assert FieldAttribute().__class__.__name__ == 'FieldAttribute'



# Generated at 2022-06-11 09:42:45.340988
# Unit test for constructor of class Attribute
def test_Attribute():
    class testclass: 
        pass
    t = testclass()
    t.required = Attribute(isa='boolean')
    t.private = Attribute(isa='boolean', private=True)
    t.default = Attribute(isa='boolean', default=True)
    t.required = Attribute(isa='boolean', required=True)
    t.listof = Attribute(isa='boolean', listof='boolean')
    t.priority = Attribute(isa='boolean', priority=5)
    t.class_type = Attribute(isa='boolean', class_type=testclass)
    t.always_post_validate = Attribute(isa='boolean', always_post_validate=True)
    t.inherit = Attribute(isa='boolean', inherit=True)
    t.alias

# Generated at 2022-06-11 09:42:49.067995
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(default='xyz')
    assert hasattr(f, 'default')
    assert f.default == 'xyz'
    assert isinstance(f, FieldAttribute)


# Generated at 2022-06-11 09:42:58.782162
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Check that the required arguments are verified
    try:
        FieldAttribute()
        assert False
    except TypeError:
        pass

    # Check that the accepted types are right
    try:
        FieldAttribute(isa=1)
        assert False
    except TypeError:
        pass

    try:
        FieldAttribute(alias=1)
        assert False
    except TypeError:
        pass

    try:
        FieldAttribute(required=1)
        assert False
    except TypeError:
        pass

    try:
        FieldAttribute(always_post_validate=1)
        assert False
    except TypeError:
        pass

    try:
        FieldAttribute(inherit=1)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-11 09:43:03.341410
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=int, required=True, default=3)
    assert a.isa == int
    assert a.private is False
    assert a.default == 3
    assert a.required is True
    assert a.priority == 0
    assert a.always_post_validate is False
    assert a.inherit is True


__all__ = ['Attribute', 'FieldAttribute']

# Generated at 2022-06-11 09:43:10.353906
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test Code
    attr = FieldAttribute('testattr')
    # Test

    assert attr.__dict__['isa'] == 'testattr'
    assert attr.__dict__['private'] == False
    assert attr.__dict__['default'] == None
    assert attr.__dict__['required'] == False
    assert attr.__dict__['listof'] == None
    assert attr.__dict__['class_type'] == None
    assert attr.__dict__['always_post_validate'] == False
    assert attr.__dict__['inherit'] == True
    assert attr.__dict__['alias'] == None
    assert attr.__dict__['extend'] == False
    assert attr.__dict__['prepend'] == False

# Generated at 2022-06-11 09:43:15.158443
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    if a.required or a.private or a.default or a.priority or a.inherit or a.static:
        print("constructor of Attribute is wrong")

# test code for __eq__ and __lt__

# Generated at 2022-06-11 09:43:19.744465
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='int', private=True, default=1, required=True, listof='int', priority=0, class_type='int',
                        always_post_validate=True, inherit=False, alias=2, extend=False, prepend=True, static=False)



# Generated at 2022-06-11 09:43:25.751770
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', default=3, required=True, listof='str', priority=5, class_type='int')
    if a.isa != 'int' or a.default != 3 or a.required != True or a.listof != 'str' or a.priority != 5 or a.class_type != 'int':
        raise Exception("FAIL")
    else:
        print("test_Attribute OK")


# Generated at 2022-06-11 09:43:32.436190
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa = "test", private=True, default="test")
    assert x.isa == "test"
    assert x.private == True
    assert x.default == "test"
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None
    assert x.extend == False
    assert x.prepend == False
    assert x.static == False


# Generated at 2022-06-11 09:43:41.648570
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    f.isa = 'a'
    f.private = 'b'
    f.default = 'c'
    f.required = True
    f.listof = 'd'
    f.priority = 1
    f.class_type = 'e'
    f.always_post_validate = True
    f.inherit = True
    f.alias = 'myflag'
    f.extend = True
    f.prepend = False
    f.static = True
    assert f.isa == 'a'
    assert f.private == 'b'
    assert f.default == 'c'
    assert f.required == True
    assert f.listof == 'd'
    assert f.priority == 1
    assert f.class_type == 'e'
    assert f.always_post

# Generated at 2022-06-11 09:44:23.526870
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(listof='hostname')
    assert f.isa == 'list'

# Generated at 2022-06-11 09:44:34.512785
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', private=True, default=None, required=False, listof=None,
                  priority=0, class_type=None, always_post_validate=False,
                  inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert type(a) is Attribute
    assert a.isa == 'int'
    assert a.private == True
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-11 09:44:37.421473
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa=int, required=True)
    assert a.isa == int
    assert a.required == True
    assert a.private == False
    assert a.default == None

# Generated at 2022-06-11 09:44:45.758319
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test for raising TypeError for mutable defaults for FieldAttribute
    # For list
    try:
        l = Attribute(isa = 'list', default = {})
    except TypeError as e:
        assert "defaults for FieldAttribute" in str(e)
    # For dict
    try:
        l = Attribute(isa = 'dict', default = {})
    except TypeError as e:
        assert "defaults for FieldAttribute" in str(e)
    # For set
    try:
        l = Attribute(isa = 'set', default = {})
    except TypeError as e:
        assert "defaults for FieldAttribute" in str(e)
    # For callable
    l = Attribute(isa = 'list', default = lambda: None)
    assert l.default() == None
    # For None
    l

# Generated at 2022-06-11 09:44:53.985512
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert(field.isa == None)
    assert(field.private == False)
    assert(field.default == None)
    assert(field.required == False)
    assert(field.listof == None)
    assert(field.priority == 0)
    assert(field.class_type == None)
    assert(field.always_post_validate == False)
    assert(field.inherit == True)
    assert(field.alias == None)
    assert(field.extend == False)
    assert(field.prepend == False)
    assert(field.static == False)


# Generated at 2022-06-11 09:44:55.823330
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_type = Attribute(isa=int)
    assert isinstance(attr_type, Attribute)



# Generated at 2022-06-11 09:44:57.325337
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', default=[])
    assert a is not None

# Generated at 2022-06-11 09:45:06.803039
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'str'
    private = False
    default = '23'
    required = False
    listof = 123
    priority = 0
    class_type = 'TestClass'
    always_post_validate = False
    inherit = True
    alias = 'alias_test_word'

    attribute_constraint = Attribute(
        isa=isa,
        private=private,
        default=default,
        required=required,
        listof=listof,
        priority=priority,
        class_type=class_type,
        always_post_validate=always_post_validate,
        inherit=inherit,
        alias=alias
    )

    assert attribute_constraint.isa is isa
    assert attribute_constraint.private is private

# Generated at 2022-06-11 09:45:09.109597
# Unit test for constructor of class Attribute
def test_Attribute():
    '''creat a Attribute class
    '''
    a = Attribute()
    a.isa = 'list'
    assert a.isa == 'list'


# Generated at 2022-06-11 09:45:19.851117
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    b = Attribute(isa="Test", private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert b.isa == "Test"
    assert b.private == False
    assert b.default == None
    assert b.required == False
    assert b.listof == None