

# Generated at 2022-06-11 09:36:08.176280
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None,
                               priority=0, class_type=None, always_post_validate=False, inherit=True,
                               alias=None, extend=False, prepend=False, static=False)

    assert attribute.isa == 'list'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False




# Generated at 2022-06-11 09:36:15.465845
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private='True', default='Test', required='True', listof='dict2', priority='0', class_type='a', always_post_validate=True, inherit=False, alias='b', extend=True, prepend=False, static=True)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == 'Test'
    assert a.required == True
    assert a.listof == 'dict2'
    assert a.priority == 0
    assert a.class_type == 'a'
    assert a.always_post_validate == True
    assert a.inherit == False
    assert a.alias == 'b'
    assert a.extend == True
    assert a.prepend == False
    assert a.static == True

# Unit

# Generated at 2022-06-11 09:36:23.444818
# Unit test for constructor of class Attribute
def test_Attribute():

    data = dict(
        isa = 'dict',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
    )
    attr = Attribute(**data)

    assert attr.isa == data['isa']
    assert attr.private == data['private']
    assert attr.default == data['default']
    assert attr.required == data['required']
    assert attr.listof == data['listof']
    assert attr.priority == data['priority']
    assert attr.class_type == data['class_type']
    assert attr.always

# Generated at 2022-06-11 09:36:24.274093
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute

# Generated at 2022-06-11 09:36:30.542874
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute1 = Attribute(isa='dict', private=False, default='value', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attribute1.isa == 'dict'
    assert attribute1.private == False
    assert attribute1.default == 'value'
    assert attribute1.required == False
    assert attribute1.listof == None
    assert attribute1.priority == 0
    assert attribute1.class_type == None
    assert attribute1.always_post_validate == False
    assert attribute1.inherit == True
    assert attribute1.alias == None
    assert attribute1.extend == False
    assert attribute1.prepend == False
    assert attribute1.static

# Generated at 2022-06-11 09:36:40.344858
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-11 09:36:42.423908
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='bool')
    assert fa.isa == 'bool'



# Generated at 2022-06-11 09:36:55.393014
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldAttribute = FieldAttribute()
    assert fieldAttribute.isa == None
    assert fieldAttribute.private == False
    assert fieldAttribute.default == None
    assert fieldAttribute.required == False
    assert fieldAttribute.listof == None
    assert fieldAttribute.priority == 0
    assert fieldAttribute.class_type == None
    assert fieldAttribute.always_post_validate == False
    assert fieldAttribute.inherit == True
    assert fieldAttribute.alias == None
    assert fieldAttribute.extend == False
    assert fieldAttribute.prepend == False


# Generated at 2022-06-11 09:37:05.861058
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible.parsing.yaml.objects
    import collections
    import yaml
    import distutils.version
    import sys

    a = Attribute()
    assert a.isa is None
    assert a.required is False

    # NotImplementedError: abstract-class-instantiated
    #b = Attribute(alias="foo", default="bar")
    #assert b.default == "bar"

    # default values are not allowed to be mutable
    try:
        a = Attribute(default={'foo': 'bar'})
        assert False
    except TypeError:
        pass

    # but this should be OK
    a = Attribute(default=lambda: {'foo': 'bar'})
    assert a.default() == {'foo': 'bar'}


# Generated at 2022-06-11 09:37:06.659849
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:37:09.522457
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr is not None

# Generated at 2022-06-11 09:37:14.170813
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(default=None, required=True, isa='list')
    assert FA.isa == 'list'
    assert FA.private == False
    assert FA.default == None
    assert FA.required == True
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert FA.always_post_validate == False
    assert FA.inherit == True
    assert FA.alias == None


# Generated at 2022-06-11 09:37:18.222031
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test that the constructor works
    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None


# Generated at 2022-06-11 09:37:20.054209
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(default=['a'])

    assert isinstance(f, FieldAttribute)
    assert isinstance(f, Attribute)



# Generated at 2022-06-11 09:37:29.520174
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor of class Attribute

    # test if the default values are all the same as the initialized values
    assert Attribute() == Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # test the values when initialized with the values
    # in the function declaration

# Generated at 2022-06-11 09:37:37.556835
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    ############################
    ## Default  is required = False, always_post_validate = False, inherit = True
    ############################
    attr1 = FieldAttribute()
    assert attr1.isa is None
    assert attr1.private is False
    assert attr1.default is None
    assert attr1.required is False
    assert attr1.listof is None
    assert attr1.priority == 0
    assert attr1.class_type is None
    assert attr1.always_post_validate is False
    assert attr1.inherit is True
    assert attr1.alias is None

    ############################
    ## Setting default = 0 is required = False, always_post_validate = False, inherit = True
    ############################

# Generated at 2022-06-11 09:37:47.066872
# Unit test for constructor of class Attribute
def test_Attribute():
    # Alias
    attr1 = Attribute(isa='list', alias='foo')
    assert attr1.isa == 'list'
    assert attr1.alias == 'foo'

    # Default
    attr2 = Attribute(isa='int', default=1)
    assert attr2.isa == 'int'
    assert attr2.default == 1

    # Required
    attr3 = Attribute(isa='bool', required=True)
    assert attr3.isa == 'bool'
    assert attr3.required

    # Listof
    attr4 = Attribute(isa='list', listof='str')
    assert attr4.isa == 'list'
    assert attr4.listof == 'str'

    # Priority
    attr5 = Attribute(isa='str', priority=1)


# Generated at 2022-06-11 09:37:59.576604
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int')
    assert attr.isa == 'int'
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    assert attr == FieldAttribute(priority=0)
    assert attr == FieldAttribute(priority=0)
    assert attr != FieldAttribute(priority=1)
    assert attr != FieldAttribute(priority=1)
    assert attr

# Generated at 2022-06-11 09:38:10.787799
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible.playbook.play_context
    import ansible.playbook.task

    attr = Attribute(isa='not', required=True)
    assert attr.isa == 'not', "isa property was not set correctly"
    assert attr.required is True, "required property was not set correctly"

    obj = ansible.playbook.play_context.PlayContext()
    attr = Attribute(isa=ansible.playbook.task.Task, required=True)
    assert attr.isa == ansible.playbook.task.Task, "isa property was not set correctly"
    assert attr.required is True, "required property was not set correctly"

    obj = ansible.playbook.play_context.PlayContext()
    attr = Attribute(isa=obj, required=True)
    assert attr.isa

# Generated at 2022-06-11 09:38:21.390431
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert None is FieldAttribute().isa
    assert None is FieldAttribute().default
    assert False is FieldAttribute().required
    assert None is FieldAttribute().listof
    assert 0 == FieldAttribute().priority
    assert False is FieldAttribute().private
    assert None is FieldAttribute().class_type
    assert False is FieldAttribute().always_post_validate
    assert True is FieldAttribute().inherit
    assert None is FieldAttribute().alias
    assert False is FieldAttribute().extend
    assert False is FieldAttribute().prepend
    assert False is FieldAttribute().static

    assert str is FieldAttribute(isa='string').isa

    assert dict is type(FieldAttribute(default={'a': 'b'}).default)
    assert {'a': 'b'} == FieldAttribute(default={'a': 'b'}).default


# Generated at 2022-06-11 09:38:35.712965
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority is 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False

    fa = FieldAttribute(private=True)
    assert fa.private is True

    # Python 3.5+ will blow up here due to non-hashable default value
    fa = FieldAttribute(default=dict())
    assert fa.default is None

    # This is a non-modifiable default

# Generated at 2022-06-11 09:38:45.032427
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute_1 = FieldAttribute(isa=str, private=True, default=None, required=True, listof=None, priority=0, class_type=dict,
                                 always_post_validate=False, inherit=False, alias='alias_1', extend=True, prepend=False, static=False)

    attribute_2 = FieldAttribute(isa=str, private=True, default=None, required=True, listof=None, priority=0, class_type=dict,
                                 always_post_validate=False, inherit=False, alias='alias_1', extend=True, prepend=False, static=False)

    assert attribute_1 == attribute_2


# Generated at 2022-06-11 09:38:47.402163
# Unit test for constructor of class Attribute
def test_Attribute():
    field1 = Attribute(isa='list')
    field2 = Attribute(isa='list')

    assert field1 == field2

# Generated at 2022-06-11 09:38:59.271356
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', private=False, default=None, required=False)

    #validate defaults and provided values
    assert attr.isa == 'int'
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert attr.inherit is True
    assert attr.listof is None
    assert attr.class_type is None
    assert attr.priority == 0
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static
    assert not attr.always_post_validate

    # validate the callable default
    attr = Attribute(isa='dict', default=lambda: {'foo': 'bar'})
    assert attr.default() == {'foo': 'bar'}

   

# Generated at 2022-06-11 09:39:07.073900
# Unit test for constructor of class Attribute
def test_Attribute():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    test_data = {'login_user': 'admin'}
    test_loader = DictDataLoader(test_data)
    test_inventory = InventoryManager(loader=test_loader, sources='localhost,')

    test_host = test_inventory.get_host("localhost")
    assert test_host.login_user == 'admin'

test_Attribute.unfrackpath_warning = False
test_Attribute.suppress_ansible_warnings = True

# Generated at 2022-06-11 09:39:11.477190
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', default="abc", private=True, required=False, listof=None,
                     priority=10, class_type=None, always_post_validate=False, inherit=True)

    assert attr.isa == 'str'
    assert attr.default == "abc"
    assert attr.private == True



# Generated at 2022-06-11 09:39:20.191591
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAtrributeTest1 = FieldAttribute()
    assert FieldAtrributeTest1.isa == None
    assert FieldAtrributeTest1.private == False
    assert FieldAtrributeTest1.required == False
    assert FieldAtrributeTest1.listof == None
    assert FieldAtrributeTest1.priority == 0
    assert FieldAtrributeTest1.class_type == None
    assert FieldAtrributeTest1.always_post_validate == False
    assert FieldAtrributeTest1.inherit == True
    assert FieldAtrributeTest1.alias == None
    assert FieldAtrributeTest1.extend == False
    assert FieldAtrributeTest1.prepend == False
    assert FieldAtrributeTest1.static == False



# Generated at 2022-06-11 09:39:29.999322
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = 'dict'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False

    attr = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate)
    
    assert attr.isa == isa
    assert attr.private == private
    assert attr.default == default
    assert attr.required == required
    assert attr.listof == listof
    assert attr.priority == priority
    assert attr.class_type == class_type
    assert attr.always_post_validate == always_post_validate
    

# Generated at 2022-06-11 09:39:40.047066
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_obj = FieldAttribute(isa='dict')
    # assert isinstance(test_obj, FieldAttribute)
    assert hasattr(test_obj, 'isa')
    assert hasattr(test_obj, 'private')
    assert hasattr(test_obj, 'default')
    assert hasattr(test_obj, 'required')
    assert hasattr(test_obj, 'listof')
    assert hasattr(test_obj, 'priority')
    assert hasattr(test_obj, 'class_type')
    assert hasattr(test_obj, 'always_post_validate')
    assert hasattr(test_obj, 'inherit')
    assert hasattr(test_obj, 'alias')
    assert hasattr(test_obj, 'extend')
    assert hasattr(test_obj, 'prepend')
    assert hasattr

# Generated at 2022-06-11 09:39:50.741422
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='int', priority=1)
    assert attr.isa == 'int'
    assert attr.priority == 1
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-11 09:40:05.755117
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # simple cases
    f1 = FieldAttribute()
    assert f1.isa is None
    assert f1.private is False
    assert f1.default is None
    assert f1.required is False
    assert f1.listof is None
    assert f1.priority == 0
    assert f1.class_type is None
    assert f1.always_post_validate is False
    assert f1.inherit is True
    assert f1.alias is None

    # non-simple cases

# Generated at 2022-06-11 09:40:09.503279
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', default={})
    assert a.isa == 'dict'
    assert a.default == {}
    assert repr(a) == '<Attribute isa=dict, default={}>'



# Generated at 2022-06-11 09:40:19.654068
# Unit test for constructor of class Attribute
def test_Attribute():
    test_dict = dict()
    test_dict['isa'] = "test_isa"
    test_dict['private'] = False
    test_dict['default'] = None
    test_dict['required'] = False
    test_dict['listof'] = 'test_list'
    test_dict['priority'] = 1
    test_dict['class_type'] = None
    test_dict['always_post_validate'] = False
    test_dict['inherit'] = True
    test_dict['alias'] = 'test_alias'
    test_dict['extend'] = False
    test_dict['prepend'] = False
    test_dict['static'] = False

    # Container as default

# Generated at 2022-06-11 09:40:28.980950
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test of valid type keys
    a = Attribute(isa='string', default='ansible')
    assert a.isa == 'string'
    assert a.default == 'ansible'

    a = Attribute(isa='list', default='ansible')
    assert a.isa == 'list'
    assert a.default == 'ansible'

    a = Attribute(isa='dict', default='ansible')
    assert a.isa == 'dict'
    assert a.default == 'ansible'

    a = Attribute(isa='bool', default='ansible')
    assert a.isa == 'bool'
    assert a.default == 'ansible'

    a = Attribute(isa='number', default='ansible')
    assert a.isa == 'number'
    assert a.default == 'ansible'


# Generated at 2022-06-11 09:40:38.283600
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test all attributes
    attr = Attribute(isa='list', private=True, default=dict(), required=True,
                     listof='str', priority=1, class_type=dict, inherit=False,
                     alias='my_alias', extend=True, prepend=True, static=False)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == dict()
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 1
    assert attr.class_type == dict
    assert attr.inherit == False
    assert attr.alias == 'my_alias'
    assert attr.extend == True
    assert attr.prepend == True
    assert attr.static == False

    # Test

# Generated at 2022-06-11 09:40:47.819059
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a.__doc__ != None
    assert a.__doc__.__class__.__name__ == 'str'
    assert a.__eq__(a) == True
    assert a.__ne__(a) == False
    assert a.__lt__(a) == False
    assert a.__gt__

# Generated at 2022-06-11 09:40:57.877726
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default=dict)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required is False
    assert attr.private is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static
    try:
        attr = FieldAttribute(isa='dict', default={})
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-11 09:40:58.484952
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='dict', default={}, required=True)



# Generated at 2022-06-11 09:41:01.177742
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(alias='foo', private="bar")
    assert f.private == 'bar'
    assert f.alias == 'foo'


# Generated at 2022-06-11 09:41:02.706807
# Unit test for constructor of class Attribute
def test_Attribute():
    test = Attribute()
    assert test.__class__ == Attribute


# Generated at 2022-06-11 09:41:13.132352
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class F(object):
        FA = FieldAttribute(isa = "list", listof = "int")

    f = F()
    assert f.FA.isa == 'list'
    assert f.FA.listof == 'int'



# Generated at 2022-06-11 09:41:23.336958
# Unit test for constructor of class Attribute
def test_Attribute():

    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=DictDataLoader(), variables={})

    test_list = [1, 2, 3]
    test_set = set(test_list)

    attribute = FieldAttribute(isa='list', default=test_list, prepend=True)
    assert attribute.isa == 'list'
    assert attribute.default == test_list
    assert attribute.prepend is True

    attribute = FieldAttribute(isa='set', default=test_set)
    assert attribute.isa == 'set'
    assert attribute.default == test_set

    # test passing a list of a particular type

# Generated at 2022-06-11 09:41:30.005958
# Unit test for constructor of class Attribute
def test_Attribute():
    # object with all metadata attributes set
    a1 = Attribute(isa='dict', private=True, default=None, required=False, listof=None,
        priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)

    # object with only required attributes set
    a2 = Attribute(isa='dict')

    assert a1.isa == 'dict'
    assert a2.isa == 'dict'



# Generated at 2022-06-11 09:41:31.716479
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor requires no arguments
    a = Attribute()



# Generated at 2022-06-11 09:41:44.093153
# Unit test for constructor of class Attribute
def test_Attribute():

    from ansible.errors import AnsibleError
    from ansible.playbook.attribute import Attribute

    x = Attribute(isa='list', listof='str', required=True)
    assert x.isa == 'list'
    assert x.listof == 'str'
    assert x.required == True

    y = Attribute(isa='str', listof='str')
    assert y.isa == 'str'
    assert y.listof == 'str'
    assert y.required == False

    # isa must be one of the valid types
    try:
        z = Attribute(isa='bogus', listof='str')
    except AnsibleError as e:
        print(e)
        assert 'bogus' in e.message
    else:
        raise Exception('should have thrown')

    # listof must be one

# Generated at 2022-06-11 09:41:53.060061
# Unit test for constructor of class Attribute
def test_Attribute():
    expected_data = {
        'isa': None,
        'private': False,
        'default': None,
        'required': False,
        'listof': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    attr = Attribute()

    assert attr.__dict__ == expected_data

    assert attr.isa is None
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
   

# Generated at 2022-06-11 09:42:04.375588
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # basic constructor
    field_attribute = FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None

    # constructor with a few parameters
    field_attribute = FieldAttribute(
        isa='class',
        private=True,
        default=None,
        required=True,
        listof='str',
        priority=10,
        class_type=None,
    )
    assert field_attribute.isa == 'class'
    assert field_attribute.private is True
    assert field_attribute.default is None
    assert field_attribute.required is True
    assert field_attribute.listof == 'str'
    assert field_attribute.priority == 10
    assert field_attribute.class_type is None

# Generated at 2022-06-11 09:42:12.583761
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False

#test the sort order

# Generated at 2022-06-11 09:42:23.571072
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test isa
    Attribute(isa='str')
    Attribute(isa='bool')
    Attribute(isa='int')
    Attribute(isa='dict')
    Attribute(isa='list')
    Attribute(isa='class')
    Attribute(isa='float')

    # Test private
    Attribute(private=False)
    Attribute(private=True)

    # Test default
    Attribute(default=None)
    Attribute(default=1)
    Attribute(default='boo')
    Attribute(default=dict())
    Attribute(default=list())

    # Test required
    Attribute(required=False)
    Attribute(required=True)

    # Test listof
    Attribute(listof=None)
    Attribute(listof=1)

# Generated at 2022-06-11 09:42:25.773527
# Unit test for constructor of class Attribute
def test_Attribute():
    default = dict()
    default['test'] = True
    attr = Attribute(default=default)
    assert attr.default == default

# Generated at 2022-06-11 09:42:49.232054
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test default value of __init__
    a = FieldAttribute()
    assert a.private         == False
    assert a.default         == None
    assert a.required        == False
    assert a.listof          == None
    assert a.priority        == 0
    assert a.class_type      == None
    assert a.always_post_validate == False
    assert a.inherit         == True
    assert a.alias           == None
    assert a.extend          == False
    assert a.prepend         == False
    assert a.static          == False

    # test whether the arguments are set correctly

# Generated at 2022-06-11 09:42:50.350247
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f is not None

# Generated at 2022-06-11 09:42:55.829018
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    wf = FieldAttribute(isa='dict', listof='string', default={}, priority=1)
    print(wf.isa)
    print(wf.priority)
    print(wf.listof)
    print(wf.default)
    assert wf.isa == 'dict'
    assert wf.priority == 1
    assert wf.listof == 'string'
    assert list(wf.default) == []


# Generated at 2022-06-11 09:43:04.841423
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='foo', private=False, default='bar', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'foo'
    assert fa.private == False
    assert fa.default == 'bar'
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-11 09:43:10.517233
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False



# Generated at 2022-06-11 09:43:22.739660
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='foo', required=False, default='bar')
    assert a.isa == 'foo'
    assert not a.required
    assert a.default == 'bar'

    a = Attribute(isa='foo', required=False, default=['bar'])
    assert a.isa == 'foo'
    assert not a.required
    assert a.default == ['bar']
    assert a.listof is None

    a = Attribute(isa='list', required=False, default=['bar', 'baz'], listof='string')
    assert a.isa == 'list'
    assert not a.required
    assert a.default == ['bar', 'baz']
    assert a.listof == 'string'

    a = Attribute(isa='foo', required=False, default=['bar', 'baz'])

# Generated at 2022-06-11 09:43:26.783222
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    field = FieldAttribute(isa='str', default='a')
    field = FieldAttribute(isa='str', default='a', required=True)
    field = FieldAttribute(isa='str', default='a', required=True, listof='str')

# the legacy class, kept for backward compatibility
Field = FieldAttribute



# Generated at 2022-06-11 09:43:28.436925
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute is not None

test_Attribute()


# Generated at 2022-06-11 09:43:36.839944
# Unit test for constructor of class Attribute
def test_Attribute():
    # Expected: No error
    try:
        test_var = Attribute()
    except:
        assert False

    # Expected: TypeError
    try:
        test_var = Attribute(default=1)
        assert False
    except TypeError:
        pass

    # Expected: No error
    try:
        test_var = Attribute(default=['1'])
    except:
        assert False

    # Expected: No error
    try:
        test_var = Attribute(default=[])
    except:
        assert False

    # Expected: No error
    try:
        test_var = Attribute(default=[1,2,3])
    except:
        assert False


# Generated at 2022-06-11 09:43:45.984728
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(default=42)
    assert fa.default == 42

    # check that defaults for container types require a callable
    try:
        fa = FieldAttribute(default={})
        assert False, "expected ValueError"
    except ValueError:
        pass
    try:
        fa = FieldAttribute(default=[])
        assert False, "expected ValueError"
    except ValueError:
        pass
    try:
        fa = FieldAttribute(default=set())
        assert False, "expected ValueError"
    except ValueError:
        pass

    # check that we can still use mutable defaults with a callable
    fa = FieldAttribute(default=lambda: {})
    assert isinstance(fa.default, dict)

    # check contextual flag
    fa = FieldAttribute(required=True)
    assert fa.required



# Generated at 2022-06-11 09:44:24.836547
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa="str")
    assert a.isa == "str"
    assert a.private == False
    assert a.default == None

    # This should raise a type error as only immutable defaults are supported
    # for attributes having a container as a value
    try:
        a = Attribute(isa="list", default=[])
    except TypeError:
        pass
    else:
        assert False, "FieldAttribute allowing mutable default when isa is a container"

    # Test that callable defaults are allowed
    a = Attribute(isa="list", default=lambda: [])
    assert isinstance(a.default, type(lambda:None))

# Generated at 2022-06-11 09:44:35.797903
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'str'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    field_attribute = Attribute(isa=isa, private=private, default=default, required=required, listof=listof,
                                priority=priority, class_type=class_type, always_post_validate=always_post_validate,
                                inherit=inherit, alias=alias, extend=extend, prepend=prepend, static=static)
    assert field_attribute.isa == isa
    assert field_attribute.private == private
    assert field_attribute.default == default
    assert field

# Generated at 2022-06-11 09:44:38.429916
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute()
        assert False, "Exception expected"
    except TypeError:
        pass


# Generated at 2022-06-11 09:44:41.371180
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(always_post_validate=False, class_type=None, default=None, extend=False,
        inherit=True,isa=None,listof=None,prepend=False,private=False,priority=0,required=False)

# Generated at 2022-06-11 09:44:47.249604
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Note on above:
    1) Default value should be a callable object
    2) Default value should not be a mutable object in case of containers
    3) Class_type should be None or Class object, not a string
    4) if isa is 'list' and listof is specified, listof should be a valid isa
    7) isa should be a valid container type or a callable
    8) isa can be a list, dict or a set
    '''
    # Positive tests:
    # 1,2) Default value should be a callable object
    assert Attribute(isa=list)
    assert Attribute(isa=list, default=[])
    assert Attribute(isa=list, default=lambda: [])
    assert Attribute(isa=list, default=None)

# Generated at 2022-06-11 09:44:55.226218
# Unit test for constructor of class Attribute
def test_Attribute():
    fieldattributes = [
        FieldAttribute(isa='int', default=5),
        FieldAttribute(isa='list', default=['hello']),
        FieldAttribute(isa='dict', default={'hello': 'world'}),
        FieldAttribute(isa='set', default={'hello'}),
    ]

    for fieldattribute in fieldattributes:
        assert fieldattribute.isa in _CONTAINERS
        assert callable(fieldattribute.default)

    try:
        FieldAttribute(isa='list', default=[5])
    except TypeError as e:
        assert 'defaults for FieldAttribute may not be mutable' in str(e)

# Generated at 2022-06-11 09:44:57.861232
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute('name', 'str', False, None, '', '', None, 0, True, None)
    print('PASS: FieldAttribute constructor')

test_FieldAttribute()



# Generated at 2022-06-11 09:44:59.937859
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()


# FIXME: this is a hack to avoid circular import problems
#        it should probably be moved to a different file


# Generated at 2022-06-11 09:45:09.286919
# Unit test for constructor of class Attribute
def test_Attribute():
    # Valid isa - basic yaml type
    a = Attribute(isa='int')
    assert a.isa == 'int'
    # Invalid isa - 'bool' is not a valid yaml type
    try:
        a = Attribute(isa='bool')
    except AssertionError:
        pass
    # Valid isa - Python class reference
    a = Attribute(isa=str)
    assert a.isa is str
    # Valid isa - percent reference
    a = Attribute(isa='percent')
    assert a.isa == 'percent'
    # Default is None - no validations
    a = Attribute(isa=str, default=None)
    assert a.default == None
    assert a.isa == str
    # Default is valid
    a = Attribute(isa=str, default='hello')
    assert a

# Generated at 2022-06-11 09:45:19.969033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # attribute with only isa
    fa = FieldAttribute(isa='bool')

    assert fa.isa == 'bool'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    # attribute with isa and all kwargs