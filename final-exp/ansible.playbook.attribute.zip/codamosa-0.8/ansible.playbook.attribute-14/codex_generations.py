

# Generated at 2022-06-11 09:36:07.937020
# Unit test for constructor of class Attribute
def test_Attribute():

    # test default constructor
    default = Attribute()
    assert default.isa is None
    assert default.private == False
    assert default.default is None
    assert default.required == False
    assert default.listof is None
    assert default.priority == 0
    assert default.always_post_validate == False
    assert default.inherit == True
    assert default.alias is None

    # test constructor with kwargs

# Generated at 2022-06-11 09:36:15.287488
# Unit test for constructor of class Attribute
def test_Attribute():
    # Class name
    assert Attribute.__name__ == 'Attribute'
    # Class docstring

# Generated at 2022-06-11 09:36:23.290526
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', private=False, default=None, required=False,
                          listof='str', priority=0, class_type=None, always_post_validate=False,
                          inherit=True, alias=None, extend=False, prepend=False, static=False)

    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-11 09:36:29.852899
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a1 = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )

    assert a1.isa == 'str'
    assert a1.private == False
    assert a1.default is None
    assert a1.required == False
    assert a1.listof is None
    assert a1.priority == 0
    assert a1.class_type is None
    assert a1.always_post_validate == False
    assert a1.inherit == True
    assert a1.alias is None

# Generated at 2022-06-11 09:36:31.240824
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(isa='dict', default=dict())
    except TypeError as e:
        assert 'mutable' in str(e)



# Generated at 2022-06-11 09:36:35.050089
# Unit test for constructor of class Attribute
def test_Attribute():
    #my_Attribute = Attribute(isa='class', default='some default', required=True, listof='list', priority=2, class_type='some type', always_post_validate=True, inherit=True, alias='some alias')
    my_Attribute = Attribute(isa='class', default='some default', required=True, listof='list', priority=2, class_type='some type', always_post_validate=True, inherit=True, alias='some alias', extend=True, prepend=True, static=True)
    assert isinstance(my_Attribute, FieldAttribute)



# Generated at 2022-06-11 09:36:46.272030
# Unit test for constructor of class Attribute
def test_Attribute():

    # Default Attribute constructor
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True

    # Attribute constructor with extra argument
    attr = Attribute(alias='foobar')
    assert attr.alias == 'foobar'

    # Attribute constructor with argument value
    attr = Attribute(alias='foobar', required=True)
    assert attr.alias == 'foobar'
    assert attr.required is True

    # Attribute constructor with arguments values
    attr

# Generated at 2022-06-11 09:36:58.588204
# Unit test for constructor of class Attribute
def test_Attribute():
    print('Testing Attribute constructor')

    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    a = Attribute(isa='list', private=True, default=False, required=True,
                  listof='str', priority=3, class_type='Foo',
                  always_post_validate=True, inherit=False, alias='foo')
    assert a.isa == 'list'
    assert a.private is True
    assert a.default is False
    assert a.required is True

# Generated at 2022-06-11 09:37:04.525225
# Unit test for constructor of class Attribute
def test_Attribute():
    IA = Attribute(isa='list')
    assert IA.isa == 'list'
    assert not IA.private
    assert IA.default is None
    assert not IA.required
    assert IA.listof is None
    assert IA.priority == 0
    assert IA.class_type is None
    assert not IA.always_post_validate
    assert IA.inherit
    assert IA.alias is None
    assert not IA.extend
    assert not IA.prepend
    assert not IA.static
    try:
        IA = Attribute(isa='list', default=[])
        assert False
    except Exception:
        pass
    IA = Attribute(isa='list', default=None)
    assert IA.isa == 'list'
    # print(IA)


# Generated at 2022-06-11 09:37:11.996351
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-11 09:37:21.816883
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='str',
        private=None,
        default=None,
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.isa == 'str'
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True

# Generated at 2022-06-11 09:37:25.618445
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa=str,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        static=False,
        class_type=None,
        always_post_validate=False,
    )
    assert attr


# Generated at 2022-06-11 09:37:34.881080
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test 1
    # test with valid parameters
    try:
        att = FieldAttribute(isa='class',
                              class_type='System',
                              required=True,
                              extend=True,
                              prepend=True)
        assert att.__dict__['extend'] is True
        assert att.__dict__['prepend'] is True
        assert att.__dict__['required'] is True
    # Test 2
    # type of 'required' is invalid
    except TypeError:
        raise AssertionError('Type of \'required\' is invalid')
    except ValueError:
        raise AssertionError('No return value')
    # Test 3
    # type of 'prepend' is invalid

# Generated at 2022-06-11 09:37:38.711014
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', default='', inherit=False, extend=False)
    f = FieldAttribute(isa='str', default='', inherit=False, extend=True)
    f = FieldAttribute(isa='str', default='', inherit=True, extend=False)
    f = FieldAttribute(isa='str', default='', inherit=True, extend=True)



# Generated at 2022-06-11 09:37:48.897782
# Unit test for constructor of class Attribute
def test_Attribute():
    # Bare minimum definition with default values
    a = Attribute(isa='string')
    assert a.isa == 'string'
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # All arguments set

# Generated at 2022-06-11 09:37:54.278866
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(private=False,default=None,required=False,
                        priority=1)
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.priority == 1
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-11 09:37:56.412887
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='dict')
    assert field_attribute.isa == 'dict'



# Generated at 2022-06-11 09:38:08.562750
# Unit test for constructor of class Attribute
def test_Attribute():
    kwargs = {'isa': 'list', 'required': True, 'private': True, 'priority': 2}
    attr = Attribute(**kwargs)
    for key, value in kwargs.iteritems():
        assert attr.__dict__[key] == value
    # test default value
    assert attr.default is None
    assert attr.listof is None

if __name__ == "__main__":
    import unittest
    #from ansible.test import AttributeTestCase
    #from ansible.test import run_suite
    #from ansible.test import AttributeTestCase
    from tests.unit.test_utils import AnsibleTestCase as AttributeTestCase

    class AttributeTest(AttributeTestCase):
        def test_attr(self):
            test_Attribute()

    run_

# Generated at 2022-06-11 09:38:14.740839
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='list')
    assert FieldAttribute(private=True)
    assert FieldAttribute(default=None)
    assert FieldAttribute(required=True)
    assert FieldAttribute(listof='str')
    assert FieldAttribute(priority=0)
    assert FieldAttribute(class_type='class')
    assert FieldAttribute(always_post_validate=False)
    assert FieldAttribute(inherit=True)
    assert FieldAttribute(alias='alias')

# Generated at 2022-06-11 09:38:22.650952
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a_field = FieldAttribute()
    assert a_field.isa == None
    assert a_field.private == False
    assert a_field.default == None
    assert a_field.required == False
    assert a_field.listof == None
    assert a_field.priority == 0
    assert a_field.class_type == None
    assert a_field.always_post_validate == False
    assert a_field.inherit == True
    assert a_field.alias == None
    assert a_field.extend == False
    assert a_field.prepend == False
    assert a_field.static == False


# Generated at 2022-06-11 09:38:30.086450
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa="str", class_type=str)
    assert(attr.isa == "str")
    assert(attr.class_type == str)

# Generated at 2022-06-11 09:38:37.469299
# Unit test for constructor of class Attribute
def test_Attribute():
   # First test with all of the parameters
   a = Attribute(isa="test", private=False, default=None, required=False, listof=None,
                 priority=0, class_type=None, always_post_validate=False, inherit=True,
                 alias=None)
   # Now test with only some of the parameters
   a = Attribute(isa="test", default=None, priority=0, alias=None)



# Generated at 2022-06-11 09:38:42.782963
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from units.compat.mock import patch

    default = {'key': 'value'}
    field = FieldAttribute(default=default, always_post_validate=True)
    with patch('units.modules.platform.Attribute._assert_default_is_copyable') as mock_assert:
        field.post_validate(default, 'key')
        mock_assert.assert_called_once_with(default)



# Generated at 2022-06-11 09:38:50.572047
# Unit test for constructor of class Attribute
def test_Attribute():
    def assertEquals(name, actual, expected):
        if actual != expected:
            raise AssertionError('%s != %s' % (repr(actual), repr(expected)))

    field = Attribute(isa='int', required=True)
    assertEquals('isa', field.isa, 'int')
    assertEquals('private', field.private, False)
    assertEquals('required', field.required, True)

    field = Attribute(listof='int')
    assertEquals('listof', field.listof, 'int')

    field = Attribute()

# Generated at 2022-06-11 09:38:52.190493
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().__class__.__name__ == 'Attribute'

# Generated at 2022-06-11 09:39:01.668634
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # A simple FieldAttribute
    a = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None,
                       priority=0, class_type='class', always_post_validate=False,
                       inherit=True, alias=None, extend=False, prepend=False, static=False)

    # An complex FieldAttribute
    b = FieldAttribute(isa=None, private=False, default=['key'], required=False, listof='ansible',
                       priority=0, class_type='class', always_post_validate=False,
                       inherit=True, alias=None, extend=False, prepend=False, static=False)



# Generated at 2022-06-11 09:39:09.452499
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False

# Test if the default values are equal to the instance of class FieldAttribute's constructor

# Generated at 2022-06-11 09:39:13.826232
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldAttribute = FieldAttribute(isa='str',
                                    private=False,
                                    default=None,
                                    required=False,
                                    listof=None,
                                    priority=0,
                                    class_type=None,
                                    always_post_validate=False,
                                    inherit=True,
                                    alias=None,
                                    extend=False,
                                    prepend=False,
                                    static=False)


# Generated at 2022-06-11 09:39:22.141534
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa == None
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False


# Generated at 2022-06-11 09:39:28.801916
# Unit test for constructor of class Attribute
def test_Attribute():   # pylint: disable=no-self-use
    attr = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=str)
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == str


# Generated at 2022-06-11 09:39:37.691170
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', listof='dict')
    assert attr.isa == 'list'
    assert attr.listof == 'dict'
    

# Generated at 2022-06-11 09:39:50.626464
# Unit test for constructor of class Attribute
def test_Attribute():
    def func():
        pass

    # Some tests for the Attribute constructor
    attr = Attribute()
    assert (attr.isa == None)
    assert (attr.private == False)
    assert (attr.default == None)
    assert (attr.required == False)
    assert (attr.listof == None)
    assert (attr.priority == 0)
    assert (attr.class_type == None)

    attr = Attribute(
        isa = 'test_isa',
        private = 'test_private',
        default = 'test_default',
        required = 'test_required',
        listof = 'test_listof',
        priority = 'test_priority',
        class_type = 'test_class_type'
    )
    assert (attr.isa == 'test_isa')

# Generated at 2022-06-11 09:39:58.369878
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = None
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate=False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    attr = Attribute(
        isa = isa,
        private = private,
        default = default,
        required = required,
        listof = listof,
        priority = priority,
        class_type = class_type,
        always_post_validate = always_post_validate,
        inherit = inherit,
        alias = alias,
        extend = extend,
        prepend = prepend,
        static = static
    )

    assert attr.isa == isa
    assert attr.private

# Generated at 2022-06-11 09:40:04.048526
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='str', private=True, default=['test'], required=True, listof='str', priority=0,
                   class_type='str', always_post_validate=False, inherit=True, alias='myalias',
                   extend=False, prepend=False, static=True)
    assert f1 is not None
    return


# Generated at 2022-06-11 09:40:14.710636
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    This test tests the constructor of class Attribute
    '''

    # Test isa parameter
    a = Attribute()
    assert a.isa is None
    a = Attribute(isa = 'list')
    assert a.isa == 'list'
    a = Attribute(isa = 'dict')
    assert a.isa == 'dict'
    a = Attribute(isa = 'bool')
    assert a.isa == 'bool'
    a = Attribute(isa = 'int')
    assert a.isa == 'int'
    a = Attribute(isa = 'str')
    assert a.isa == 'str'
    a = Attribute(isa = 'float')
    assert a.isa == 'float'
    a = Attribute(isa = 'percent')
    assert a.isa == 'percent'

    # Test private

# Generated at 2022-06-11 09:40:19.526975
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list')
    assert attr.isa == 'list'
    attr.listof = 'set'
    assert attr.listof == 'set'

    # Constructor argument default has mutable default
    def f():
        return {}
    attr = Attribute(default=f)
    assert attr.default() == {}

# Generated at 2022-06-11 09:40:26.345341
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(default=['a', 'b', 'c'])
    except:
        pass
    else:
        raise AssertionError("Failed to fail on mutable default")

        # make sure we can create an instance with a function
    try:
        a = Attribute(default=lambda:['a', 'b', 'c'])
    except:
        raise AssertionError("Failed to instance with a function as default")


#
# The rest of this file is for future use, it is not currently used.
#



# Generated at 2022-06-11 09:40:35.498687
# Unit test for constructor of class Attribute
def test_Attribute():
    # tests with defaults
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    # tests with non-defaults

# Generated at 2022-06-11 09:40:37.628912
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fb = FieldAttribute(isa=str, default='str_attribute')
    assert isinstance(fb, FieldAttribute)



# Generated at 2022-06-11 09:40:41.386475
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
    )

# Generated at 2022-06-11 09:41:06.638356
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fail_message = "should fail"

    # Create an object with a list default
    try:
        fatt1 = FieldAttribute(isa='dict', default=[])
        assert False, fail_message
    except TypeError:
        pass

    # Create an object with a dict default
    try:
        fatt2 = FieldAttribute(isa='list', default={})
        assert False, fail_message
    except TypeError:
        pass

    # Create an object with a dict default
    try:
        fatt3 = FieldAttribute(isa='list', default=set())
        assert False, fail_message
    except TypeError:
        pass

    # Create an object with a dict default

# Generated at 2022-06-11 09:41:10.873530
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test cases
    # Valid inputs
    testcases = [
        {'default': 'host',
         'required': True,
         'alias': 'hostname',
         }
        ]

    for testcase in testcases:
        fa = FieldAttribute(**testcase)
        print(fa)



# Generated at 2022-06-11 09:41:20.928091
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    expected_data = {
        'isa': None,
        'private': False,
        'default': None,
        'required': False,
        'listof': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    obj = FieldAttribute()
    for k, v in expected_data.items():
        assert getattr(obj, k) == v, '%s: %s != %s' % (k, getattr(obj, k), v)

# Generated at 2022-06-11 09:41:31.892777
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_instance = FieldAttribute()
  
    field_attributes = {
        'isa' : str,
        'private' : bool,
        'default' : type(int),
        'required' : bool,
        'listof' : str,
        'priority' : int,
        'class_type' : bool,
        'always_post_validate' : bool,
        'inherit' : bool,
        'alias' : str,
        'extend' : bool,
        'prepend' : bool
    }

    for attribute in field_attributes:
       assert type(getattr(test_instance, attribute)) == field_attributes[attribute]
       print("%s is the correct type: %s" %(attribute, type(getattr(test_instance, attribute))))

# Generated at 2022-06-11 09:41:34.719070
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='int', default=10)
    assert attribute.isa == 'int'
    assert attribute.default == 10



# Generated at 2022-06-11 09:41:37.157889
# Unit test for constructor of class Attribute
def test_Attribute():
    field=FieldAttribute(isa='list', listof='string')
    assert field.isa == 'list'
    assert field.listof == 'string'

# Generated at 2022-06-11 09:41:48.606351
# Unit test for constructor of class Attribute
def test_Attribute():
    """Tests the constructor of class Attribute"""

    attribute = Attribute()
    assert attribute is not None, "attribute should be an Attribute object"
    assert attribute.isa is None, "isa should be None"
    assert attribute.private == False, "private should be False"
    assert attribute.default is None, "default should be None"
    assert attribute.required == False, "required should be False"
    assert attribute.listof is None, "listof should be None"
    assert attribute.priority == 0, "priority should be 0"
    assert attribute.class_type is None, "class_type should be None"
    assert attribute.always_post_validate == False, "always_post_validate should be False"
    assert attribute.inherit == True, "inherit should be True"

# Generated at 2022-06-11 09:41:51.502968
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='string', private=True, default='test', required=True, listof='list', priority=1, class_type='string')
    assert not Attribute(isa=1, private='test', default=1, required='test', listof=1, priority=1.1)



# Generated at 2022-06-11 09:42:01.233797
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa == None
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False

f = FieldAttribute()
assert f.isa == None
assert f.private == False
assert f.default == None
assert f.required == False
assert f.listof == None
assert f.priority == 0
assert f.class_type == None
assert f.always_post_validate == False
assert f.inher

# Generated at 2022-06-11 09:42:13.047326
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa="string")
    assert fa.isa == "string"
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    assert fa.__eq__(fa)
    assert not fa.__ne__(fa)
    assert not fa.__lt__(fa)
    assert not fa.__gt__(fa)
    assert fa.__le__(fa)
    assert fa.__ge__(fa)

   

# Generated at 2022-06-11 09:42:42.984746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa="dict")
    assert a.isa == 'dict'


# Generated at 2022-06-11 09:42:54.547175
# Unit test for constructor of class Attribute
def test_Attribute():
    from ds import DataDS
    from templates import Templating
    from units.compat.mock import MagicMock
    from ansible import constants as C

    is_piped = False
    templar = Templating(loader=None, variables={}, shared_loader_obj=None,
                         disable_lookup_templates=C.DISABLE_LOOKUP_TEMPLATES,
                         disable_lookup_templar=False, disable_lookup_jinja2=False,
                         disable_lookup_json=False)
    templar.is_piped = MagicMock(return_value=is_piped)

    # test constructor with default values
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False

# Generated at 2022-06-11 09:43:03.737800
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-11 09:43:10.462584
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert(FieldAttribute().isa == None)
    assert(FieldAttribute().private == False)
    assert(FieldAttribute().default == None)
    assert(FieldAttribute().required == False)
    assert(FieldAttribute().listof == None)
    assert(FieldAttribute().priority == 0)
    assert(FieldAttribute().class_type == None)
    assert(FieldAttribute().always_post_validate == False)
    assert(FieldAttribute().inherit == True)
    assert(FieldAttribute().alias == None)
    assert(FieldAttribute().extend == False)
    assert(FieldAttribute().prepend == False)
    assert(FieldAttribute().static == False)


# Generated at 2022-06-11 09:43:11.898689
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='dict', default=None, required=True, extend=False)

# Generated at 2022-06-11 09:43:24.319334
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().isa == None
    assert FieldAttribute().private == False
    assert FieldAttribute().default == None
    assert FieldAttribute().required == False
    assert FieldAttribute().listof == None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type == None
    assert FieldAttribute().always_post_validate == False
    assert FieldAttribute().inherit == True
    assert FieldAttribute().alias == None
    assert FieldAttribute().extend == False
    assert FieldAttribute().prepend == False
    assert FieldAttribute().static == False

    assert FieldAttribute(isa='string').isa == 'string'
    assert FieldAttribute(isa='string').private == False
    assert FieldAttribute(isa='string').default == None
    assert FieldAttribute(isa='string').required == False
    assert FieldAttribute(isa='string').listof == None

# Generated at 2022-06-11 09:43:30.794147
# Unit test for constructor of class Attribute
def test_Attribute():
    # test basic requirements
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None

    # test change to default value
    assert Attribute(default=True).default == True
    assert Attribute(default=False).default == False

    # test change to required value
    assert Attribute(required=True).required == True
    assert Attribute(required=False).required == False

    # test change to listof value
    assert Attribute(listof='string').listof == 'string'
    assert Attribute(listof=None).listof == None

    # test change to class_type value
    assert Attribute(class_type=Attribute).class_type == Attribute

# Generated at 2022-06-11 09:43:31.609449
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:43:34.120786
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a = FieldAttribute(default=['a', 'b'])
    except:
        assert True
    assert FieldAttribute(default=('a', 'b'))

# Generated at 2022-06-11 09:43:40.101750
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(isa='list')
    #print(attr.isa)

    #attr.default = ['a', 'b']
    #if not isinstance(attr.default, list):
    #    print('attr.default is not a list')

    #attr.default = None
    attr.default = copy(['a', 'b'])
    #attr.default = ['a', 'b']
    #attr.default = 'a,b' # this raises TypeError
    #print(attr.default)

test_FieldAttribute()

# Generated at 2022-06-11 09:44:46.923075
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(
        isa='str',
        private=False,
        default='xyz',
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert a
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == 'xyz'
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

# Generated at 2022-06-11 09:44:54.088509
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='float')
    print(f)
    assert f.isa == 'float'
    f = FieldAttribute(isa='list')
    print(f)
    assert f.isa == 'list'
    f = FieldAttribute(isa='list', default=list)
    print(f)
    assert f.default == list
    assert f.isa == 'list'
    f = FieldAttribute(isa='list', default=set)
    print(f)
    assert f.default == set
    assert f.isa == 'list'


# Generated at 2022-06-11 09:45:03.581560
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    dict2 = dict()
    dict2["isa"] = "bool"
    dict2["private"] = False
    dict2["default"] = False
    dict2["required"] = True
    dict2["priority"] = 0
    dict2["inherit"] = False
    dict2["alias"] = None
    dict2["extend"] = False
    dict2["static"] = False

    i = FieldAttribute(isa="bool", private=False, default=False, required=True,
                       priority=0, inherit=False, alias=None, extend=False, static=False)
    assert dict2["isa"] == i.isa
    assert dict2["private"] == i.private
    assert dict2["default"] == i.default
    assert dict2["required"] == i.required
    assert dict2["priority"] == i.priority
   

# Generated at 2022-06-11 09:45:13.789162
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test case for function __init__ of class Attribute
    def checkAttribute(attribute, expected):
        assert attribute.isa == expected[0]
        assert attribute.private == expected[1]
        assert attribute.default == expected[2]
        assert attribute.required == expected[3]
        assert attribute.listof == expected[4]
        assert attribute.priority == expected[5]
        assert attribute.class_type == expected[6]
        assert attribute.always_post_validate == expected[7]
        assert attribute.inherit == expected[8]
        assert attribute.alias == expected[9]

    list_attr = Attribute(isa='list',
                          private=False,
                          default=[],
                          priority=0,
                          class_type=None)

# Generated at 2022-06-11 09:45:23.606131
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str')
    attr = Attribute(isa='str', private=False)
    attr = Attribute(isa='str', private=False, default='default')
    attr = Attribute(isa='str', private=False, default='default', required=True)
    attr = Attribute(isa='str', private=False, default='default', required=True, listof='str')
    attr = Attribute(isa='str', private=False, default='default', required=True, listof='str', priority=5)
    attr = Attribute(isa='str', private=False, default='default', required=True, listof='str', priority=5, class_type=Attribute)

# Generated at 2022-06-11 09:45:24.330856
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert isinstance(attr, Attribute)



# Generated at 2022-06-11 09:45:32.221309
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', private=False, default='default_value', required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'str' and fa.private == False and fa.default == 'default_value' and fa.required == False and fa.listof == None and fa.priority == 0 and fa.class_type == None and fa.always_post_validate == False and fa.inherit == True and fa.alias == None and fa.extend == False and fa.prepend == False and fa.static == False

# Generated at 2022-06-11 09:45:32.674071
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-11 09:45:42.128824
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #Attrib1 = FieldAttribute()
    Attrib1 = FieldAttribute(isa=int, private=False, default=False, required=False, listof=None, priority=0,
                             class_type=None, always_post_validate=False, inherit=True, alias=None)
    Attrib2 = FieldAttribute(isa=int, private=False, default=False, required=False, listof=None, priority=0,
                             class_type=None, always_post_validate=False, inherit=True, alias=None)
    Attrib3 = FieldAttribute(isa="list", private=False, default=False, required=False, listof=None, priority=0,
                             class_type=None, always_post_validate=False, inherit=True, alias=None)

    assert Attrib1.priority == Att

# Generated at 2022-06-11 09:45:42.655232
# Unit test for constructor of class Attribute
def test_Attribute():
    pass