

# Generated at 2022-06-11 09:36:04.450011
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = Attribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False

# Generated at 2022-06-11 09:36:11.960718
# Unit test for constructor of class Attribute
def test_Attribute():

    # test copy constructor
    a = Attribute(isa='string')
    b = Attribute(isa='string')

    assert a == b
    assert not a.required
    assert a.private == b.private
    assert a.private == False

    # test legacy options
    a = Attribute(required=True)
    assert a.required == True

    try:
        a = Attribute(unknown_option=True)
        raise AssertionError('should not get here')
    except TypeError:
        pass

    # test that defaults can't be mutable
    try:
        a = Attribute(isa='list', default={})
        raise AssertionError('should not get here')
    except TypeError:
        pass

    a = Attribute(isa='list', default=lambda: [])
    assert a.default() == []

# Generated at 2022-06-11 09:36:16.946774
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa="string", default="one")
    f2 = deepcopy(f)
    assert f == f2
    f3 = deepcopy(f)
    assert f == f3
    f.default = "two"
    assert f != f2
    assert f != f3
    f2.default = "two"
    assert f == f2
    assert f != f3

    # Make sure it was deepcopied properly
    assert f.default == "two"
    assert f2.default == "two"
    assert f3.default == "one"



# Generated at 2022-06-11 09:36:24.929530
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor
    # Test that it accepts all types
    test_types = (
        'bool',
        'dict',
        'str',
        'list',
        'float',
        'int',
        'complex',
        'type',
        'class',
    )
    for test_type in test_types:

        test_attr = FieldAttribute(isa=test_type)
        if test_type != 'type':
            assert test_attr.isa == test_type
        else:
            # isa was 'class' and got converted to 'type'
            assert test_attr.isa == 'class'

    # Test that it fails on bad types
    # Test that it fails on bad types

# Generated at 2022-06-11 09:36:29.178453
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():    
    FA = FieldAttribute()
    assert FA.isa == None
    assert FA.private == False
    assert FA.default == None
    assert FA.required == False
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert FA.always_post_validate == False
    assert FA.inherit == True
    assert FA.alias == None
    assert FA.extend == False
    assert FA.prepend == False
    assert FA.static == False



# Generated at 2022-06-11 09:36:32.301502
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    input = {'isa': 'int', 'required': True}
    output = FieldAttribute(**input)
    result = (output.isa, output.required)

    assert result == ('int', True)


# Generated at 2022-06-11 09:36:33.156583
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute()


# Generated at 2022-06-11 09:36:40.398088
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(isa='int')
    assert FA.isa == 'int'
    assert FA.private == False
    assert FA.default == None
    assert FA.required == False
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert FA.always_post_validate == False
    assert FA.inherit == True
    assert FA.alias == None
    assert FA.extend == False
    assert FA.prepend == False
    assert FA.static == False

# Generated at 2022-06-11 09:36:49.951666
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', listof='string', default=['a', 'b'])
    assert len(a.default) == 2
    a = Attribute(isa='list', listof='string', default=lambda: ['a', 'b'])
    assert len(a.default()) == 2
    a = Attribute(isa='dict', default=dict(a=1, b=2))
    assert len(a.default) == 2
    a = Attribute(isa='dict', default=lambda: dict(a=1, b=2))
    assert len(a.default()) == 2

# Generated at 2022-06-11 09:37:00.852614
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
    assert a == a


# Generated at 2022-06-11 09:37:12.378280
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.boolean import boolean
    from ansible.module_utils._text import to_text

    x = FieldAttribute(isa='list', default=list(), required=True)
    assert x.isa == 'list'
    assert x.default == list()
    assert x.required == True

    x.default = to_text('pass')
    assert x.default == 'pass'

    x = FieldAttribute(isa='int', default=5, required=True)
    assert x.default == 5
    x.default = 10
    assert x.default == 10

    x = FieldAttribute(isa='bool', default=True, required=True)
    assert x.default == True
    x.default = False
    assert x.default == False

    x = FieldAttribute(isa='bool', default=False, required=True)
   

# Generated at 2022-06-11 09:37:12.840286
# Unit test for constructor of class Attribute
def test_Attribute():
    FieldAttribute()

# Generated at 2022-06-11 09:37:18.658553
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(Attribute(alias="a"), FieldAttribute)
    assert FieldAttribute(alias="a").alias == "a"
    assert FieldAttribute(alias="a").__class__ == FieldAttribute
    assert FieldAttribute(alias="a") == FieldAttribute(priority="0")
    assert FieldAttribute(alias="a") != FieldAttribute(priority="1")
    assert FieldAttribute(alias="a") < FieldAttribute(priority="1")
    assert FieldAttribute(alias="a") > FieldAttribute(priority="-1")
    assert FieldAttribute(alias="a") <= FieldAttribute(priority="1")
    assert FieldAttribute(alias="a") >= FieldAttribute(priority="-1")



# Generated at 2022-06-11 09:37:27.077258
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    attr = FieldAttribute(isa='int')
    attr = FieldAttribute(isa='list')
    attr = FieldAttribute(isa='list', listof='dict')
    attr = FieldAttribute(isa='dict', listof='dict')
    attr = FieldAttribute(isa='dict', listof='int')
    attr = FieldAttribute(isa='percent', default=100)
    attr = FieldAttribute(isa='bool', default=False)
    attr = FieldAttribute(isa='dict', class_type=dict)
    attr = FieldAttribute(isa='list', listof='dict', class_type=dict)
    attr = FieldAttribute(isa='list', listof='int', class_type=int)
    attr = FieldAttribute(isa='list', listof='int', default=[])


# Generated at 2022-06-11 09:37:36.233849
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.display import Display
    display = Display()

    # Test that an attempt to assign a mutable default is rejected
    with display.override_verbosity(1):
        class Foo(AnsibleBaseYAMLObject):
            _required_fields = ('bar',)
            _fields = ('bar',)
            bar = FieldAttribute(isa='list', default=[])
    #
    # Test that a mutable default which is a callable is accepted
    #
    class Foo(AnsibleBaseYAMLObject):
        _required_fields = ('bar',)
        _fields = ('bar',)
        bar = FieldAttribute(isa='list', default=list)
    #
    # Test that a mutable default which is

# Generated at 2022-06-11 09:37:37.343621
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(required=True)
    assert a.required == True

# Generated at 2022-06-11 09:37:44.043015
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert x.isa is None
    assert x.private is False
    assert x.default is None
    assert x.required is False
    assert x.listof is None
    assert x.priority is 0
    assert x.class_type is None
    assert x.always_post_validate is False
    assert x.inherit is True
    assert x.alias is None

# Generated at 2022-06-11 09:37:46.322052
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', static=True)

# -----------------
# Other Test Methods
# -----------------


# Generated at 2022-06-11 09:37:50.945701
# Unit test for constructor of class Attribute
def test_Attribute():
    class ATestObject(object):
        def __init__(self):
            self.foo = Attribute(isa='string')
            self.bar = Attribute(isa='int', default=42)
            self.baz = Attribute(isa='list', default=lambda obj: [])
            self.qux = Attribute(isa='listof', listof='string', default=lambda obj: [obj.foo])

    o = ATestObject()
    assert o.foo is None
    assert o.bar == 42
    assert o.baz == []
    assert o.qux == []

# Generated at 2022-06-11 09:37:53.986784
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', default=list())
    assert attr.isa is 'list' and len(attr.default) is 0



# Generated at 2022-06-11 09:38:08.116876
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True

# Generated at 2022-06-11 09:38:18.568192
# Unit test for constructor of class Attribute
def test_Attribute():
    # Constructor requires only attribute isa, if not set it will set default
    # value for default, private, required and priority to False, True, 0
    # attributes respectively
    _isa = "string"
    _example_obj1 = Attribute(isa=_isa)
    _expected_default_obj1 = Attribute(isa=_isa, private=False, default=None,
                                       required=False, priority=0)
    assert _example_obj1 == _expected_default_obj1

    # Test the constructor
    _example_obj2 = Attribute(isa=_isa, private=True, default="hello",
                              required=True, priority=1)
    assert _example_obj2.isa == "string"
    assert _example_obj2.private is True
    assert _example_obj2.default == "hello"


# Generated at 2022-06-11 09:38:24.057942
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='bool',
        private=False,
        default=False,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )


# TODO: make this do something?

# Generated at 2022-06-11 09:38:28.504605
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)


# Generated at 2022-06-11 09:38:37.416871
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa="string", class_type="myclass")
    assert a.isa == "string"
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.priority == 0
    assert a.class_type == "myclass"
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-11 09:38:45.839382
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    a = Attribute(isa='string', default='yoyo')
    assert a.isa == 'string'
    assert a.default == 'yoyo'
    assert a.alias is None

    a = Attribute(isa='string', default='yoyo', alias='new_name')
    assert a.isa == 'string'
    assert a.default == 'yoyo'
    assert a.alias == 'new_name'

    a = Attribute(isa='list', default=['a', 'b', 'c'])
    assert a.isa == 'list'
    assert a.default == ['a', 'b', 'c']

    a = Attribute(isa='list', default=list())

# Generated at 2022-06-11 09:38:48.291888
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', listof='str')
    assert a.isa == 'list'
    assert a.listof == 'str'

# Generated at 2022-06-11 09:39:00.272505
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Foo:
        pass

    assert Foo(isa='class', class_type=Foo) is None
    assert Foo(isa='class', class_type=Foo) is not None
    assert Foo(isa='class', class_type=Foo, inherit=True) is None
    assert Foo(isa='class', class_type=Foo, inherit=True) is not None
    assert Foo(isa='class', class_type=Foo, alias='foo', inherit=True) is None
    assert Foo(isa='class', class_type=Foo, alias='foo', inherit=True) is not None
    assert Foo(isa='class', class_type=Foo, alias='foo', inherit=False) is None
    assert Foo(isa='class', class_type=Foo, alias='foo', inherit=False) is not None


# Generated at 2022-06-11 09:39:02.047391
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute(isa='a')
    assert obj.isa == 'a'


# Generated at 2022-06-11 09:39:11.750090
# Unit test for constructor of class Attribute
def test_Attribute():
    field = FieldAttribute()
    if not field.isa == None:
        raise AssertionError('FieldAttribute:Attribute:isa: isa should be None, but it is not')
    if not field.private == False:
        raise AssertionError('FieldAttribute:Attribute:private: private should be False, but it is not')
    if not field.default == None:
        raise AssertionError('FieldAttribute:Attribute:default: default should be None, but it is not')
    if not field.required == False:
        raise AssertionError('FieldAttribute:Attribute:required: required should be False, but it is not')
    if not field.listof == None:
        raise AssertionError('FieldAttribute:Attribute:listof: listof should be None, but it is not')
    if not field.priority == 0:
        raise Ass

# Generated at 2022-06-11 09:39:25.479565
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa="str",
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )
    assert attr.isa == "str"
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None


# Generated at 2022-06-11 09:39:35.401683
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with correct values
    field_attribute = FieldAttribute(isa='str', private=True, default='string', required=True, listof='str', priority=0, class_type='str', always_post_validate=True, inherit=True)
    assert field_attribute.isa == 'str'
    assert field_attribute.private == True
    assert field_attribute.default == 'string'
    assert field_attribute.required == True
    assert field_attribute.listof == 'str'
    assert field_attribute.priority == 0
    assert field_attribute.class_type == 'str'
    assert field_attribute.always_post_validate == True
    assert field_attribute.inherit == True

    # Test with mutable value for default

# Generated at 2022-06-11 09:39:43.618736
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', default=0)

    assert(a.isa == 'int')
    assert(a.default == 0)
    assert(a.private == False)
    assert(a.required == False)
    assert(a.listof == None)
    assert(a.priority == 0)
    assert(a.class_type == None)
    assert(a.always_post_validate == False)
    assert(a.inherit == True)
    assert(a.alias == None)


# Generated at 2022-06-11 09:39:54.853776
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test 1
    try:
        f = FieldAttribute(isa='dict', default=dict(a=1))
    except TypeError as e:
        assert "defaults for FieldAttribute may not be mutable" in to_text(e)
    else:
        assert False, "Exception expected"

    # Test 2
    f = FieldAttribute(isa='dict', default=lambda: dict(a=1))
    assert f.default() == dict(a=1)

    # Test 3
    f = FieldAttribute(isa='dict', default=lambda: dict(a=1), extend=True)
    assert f.default() == dict(a=1)

    # Test 4
    f = FieldAttribute(isa='dict', default=lambda: dict(a=1), prepend=True)
    assert f.default() == dict(a=1)

# Generated at 2022-06-11 09:40:06.315079
# Unit test for constructor of class Attribute
def test_Attribute():
    # isa or listof must be provided else ValueError
    try:
        Attribute()
    except ValueError as e:
        assert 'isa' in str(e)

    # both isa and listof cannot be provided else ValueError
    try:
        Attribute(isa='dict', listof='dict')
    except ValueError as e:
        assert 'isa' in str(e) and 'listof' in str(e)

    # isa or listof cannot be 'class' else ValueError
    try:
        Attribute(isa='class')
    except ValueError as e:
        assert 'class' in str(e)

    # isa or listof cannot be 'class' else ValueError

# Generated at 2022-06-11 09:40:16.123949
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute('/path/to/test/test.py')
    assert field_attribute.isa == '/path/to/test/test.py'
    assert field_attribute.private == False
    assert field_attribute.default is None
    assert field_attribute.required == False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias is None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False


# Generated at 2022-06-11 09:40:20.859846
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import sys
    field_attribute = FieldAttribute(isa='list', class_type=list, extend=False)
    field_attribute.isa = 'list'
    field_attribute.class_type = list
    field_attribute.extend = False
    assert field_attribute.isa == 'list'
    assert field_attribute.class_type == list
    assert field_attribute.extend == False

# Generated at 2022-06-11 09:40:30.242217
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test should not raise exceptions
    Attribute()

    # Test isa
    Attribute(isa='int')
    Attribute(isa='float')
    Attribute(isa='bool')
    Attribute(isa='string')
    Attribute(isa='list')
    Attribute(isa='dict')
    Attribute(isa='set')
    Attribute(isa='class')
    Attribute(isa='percent')
    class Foo(object):
        pass
    Attribute(isa=Foo)

    # Test private
    Attribute(private=True)

    # Test default
    Attribute(default=lambda : {})
    Attribute(default=lambda : [])
    Attribute(default=lambda : None)
    Attribute(default=lambda : {'foo': 'bar'})

# Generated at 2022-06-11 09:40:31.127927
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute()



# Generated at 2022-06-11 09:40:31.759387
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()

# Generated at 2022-06-11 09:40:44.096257
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(required=True, isa='bool', default=False, listof='str')
    assert attr.required is True
    assert attr.isa == 'bool'
    assert attr.default is False
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.inherit is True
    assert attr.class_type is None
    assert attr.always_post_validate is False

# Generated at 2022-06-11 09:40:46.952123
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    from ansible.playbook.attribute import FieldAttribute, Attribute

    assert(FieldAttribute == Attribute)

    with pytest.raises(TypeError):
        FieldAttribute(default=dict())

# Generated at 2022-06-11 09:40:53.680272
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa = 'string',
        private = True,
        default = '42',
        required = True,
        listof = 'int',
        priority = 0,
        class_type = 'int',
        always_post_validate = False,
        inherit = False,
        extend = True,
        prepend = False,
        static = False,
    )
    # Syntactically, this test should do something
    assert attr

# Generated at 2022-06-11 09:41:04.385741
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that Attribute fails when default is mutable
    # and isa is list or dict
    # Test successful when default is callable
    # and isa is list or dict
    a = Attribute(isa="list")
    assert a.isa == "list" and a.private == False and a.default == None and\
           a.required == False and a.listof == None and a.priority == 0 and\
           a.class_type == None and a.always_post_validate == False and\
           a.inherit == True and a.alias == None and a.extend == False and\
           a.prepend == False
    assert a.__eq__(a) != a.__ne__(a)
    # Check for mutable defaults and raise TypeError

# Generated at 2022-06-11 09:41:14.515618
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string', static=False, alias='my_alias', extend=False, prepend=False, private=False, required=True, listof=None, inherit=False, always_post_validate=False, class_type=None, default=None, priority=0)
    assert field.isa == 'string'
    assert field.static == False
    assert field.alias == 'my_alias'
    assert field.extend == False
    assert field.prepend == False
    assert field.private == False
    assert field.required == True
    assert field.listof == None
    assert field.inherit == False
    assert field.always_post_validate == False
    assert field.class_type == None
    assert field.default == None
    assert field.priority == 0



# Generated at 2022-06-11 09:41:24.747678
# Unit test for constructor of class Attribute
def test_Attribute():

    Attribute(isa='dict', default={})
    Attribute(isa='str', default='')
    Attribute(isa='list', default=[])
    Attribute(isa='list', default=[], listof = 'dict')
    Attribute(isa='list', default=[])
    Attribute(isa='list', default=[], listof = 'str')
    Attribute(isa='list', default=[], listof = 'list')
    Attribute(isa='bool', default=False)

    # Test that the defaults do not masks errors
    try:
        Attribute(isa='int', default='')
        raise Exception('Attribute test code is broken')
    except TypeError:
        pass

    # Test that 'dict', 'list' and 'str' can't be used simultaneously as 'isa'
    # and 'listof'

# Generated at 2022-06-11 09:41:27.685696
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', required=True)
    assert a.isa == 'str'
    assert a.required == True
    try:
        a = Attribute(isa='list', default=['foo'])
        assert False
    except TypeError:
        pass
    a = Attribute(isa='list', default=lambda: ['foo'])
    assert a.default() == ['foo']

# Generated at 2022-06-11 09:41:38.301112
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', private='False', default='', required='True', listof='None', priority='0')
    assert a.isa == "string"
    assert a.private == False
    assert a.default == ""
    assert a.required == True
    assert a.listof == None
    assert a.priority == 0


    a = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0)
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0


# Generated at 2022-06-11 09:41:49.493361
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )
    assert attribute.isa == 'dict'
    assert attribute.private == False
    assert attribute.default is None
    assert attribute.required == False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias is None
    assert attribute.extend == False
   

# Generated at 2022-06-11 09:41:55.889153
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.dataloader import DataLoader

    # Test for containers (list, dict, set)
    # test for list
    attribute = Attribute(isa='list', default=['a', 'b', 'c'])
    assert attribute.default == ['a', 'b', 'c']

    # test for dict
    attribute = Attribute(isa='dict', default={'a': 1, 'b': 2, 'c': 3})
    assert attribute.default == {'a': 1, 'b': 2, 'c': 3}

    # test for set
    attribute = Attribute(isa='set', default={'a', 'b', 'c'})
    assert attribute.default == {'a', 'b', 'c'}

    # test for yaml_dumper:
    yaml_dumper = DataLoader

# Generated at 2022-06-11 09:42:15.659516
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority is 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-11 09:42:23.370814
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert not fa.private
    assert fa.default is None
    assert not fa.required
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert not fa.always_post_validate
    assert fa.inherit
    assert fa.alias is None
    assert not fa.extend
    assert not fa.prepend
    assert not fa.static


# Generated at 2022-06-11 09:42:33.333768
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute('list', True, ['foo'], False, 'percent', 1, 'bar', True, True, 'baz', True, True, False)
    assert a.isa =='list'
    assert a.private == True
    assert a.default == ['foo']
    assert a.required == False
    assert a.listof == 'percent'
    assert a.priority == 1
    assert a.class_type == 'bar'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'baz'
    assert a.extend == True
    assert a.prepend == True
    assert a.static == False
    try:
        a = Attribute(default="foo")
        assert False, "Expected exception"
    except TypeError:
        pass

# Generated at 2022-06-11 09:42:40.912759
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', default='test', required=False)
    assert field.isa == 'str'
    assert field.private == False
    assert field.default == 'test'
    assert field.required == False
    assert field.priority == 0
    assert field.static == False

    field = FieldAttribute(isa='str', private=True, default='test', required=False)
    assert field.isa == 'str'
    assert field.private == True
    assert field.default == 'test'
    assert field.required == False
    assert field.priority == 0
    assert field.static == False


# Generated at 2022-06-11 09:42:43.282160
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa=ALLOW_NULL)
    assert attr.isa == ALLOW_NULL
    attr = Attribute(isa='list')
    assert attr.isa == 'list'



# Generated at 2022-06-11 09:42:52.578973
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', class_type=dict, default={0: 1})
    assert isinstance(attr.default, dict), 'default value should be dict'
    attr2 = Attribute(isa='dict', class_type=dict, default=lambda: {0: 1})
    assert isinstance(attr2.default(), dict), 'default value should be dict'

    try:
        attr = Attribute(isa='dict', class_type=dict, default=[0, 1])
    except TypeError:
        pass
    else:
        raise AssertionError('default value should not be list')



# Generated at 2022-06-11 09:42:56.387183
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr = Attribute(isa='list', listof='dict')
    assert test_attr is not None
    assert test_attr.isa is not None
    assert test_attr.isa == 'list'
    assert test_attr.listof is not None
    assert test_attr.listof == 'dict'

# Generated at 2022-06-11 09:43:05.326125
# Unit test for constructor of class Attribute
def test_Attribute():
    #TODO: this test is not really a unit test...
    # Should we remove it, or refactor it?
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False

    a = Attribute(alias='foo', listof='bar')
    assert a.alias == 'foo'
    assert a.listof == 'bar'

    a = Attribute(default=[])
    assert a.default == []



# Generated at 2022-06-11 09:43:10.665244
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa="bool",
                                     private=False,
                                     default="mydefault",
                                     required=False,
                                     listof=False,
                                     priority=0,
                                     class_type=False,
                                     always_post_validate=False,
                                     inherit=True,
                                     alias=None,
                                     extend=False,
                                     prepend=False,
                                     static=False)

# Generated at 2022-06-11 09:43:19.798427
# Unit test for constructor of class Attribute
def test_Attribute():
    # Attribute - isa, default, required, listof, priority, class_type, always_post_validate, inherit
    attribute = Attribute(
        isa='str',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    assert isinstance(attribute, Attribute)



# Generated at 2022-06-11 09:43:54.020307
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='dict', private=False, default=None, required=False, listof=None, priority=0, always_post_validate=False, inherit=True, alias=None)



# Generated at 2022-06-11 09:43:59.065657
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', private=True, required=True, default=True, listof='int')
    assert isinstance(attr.isa, basestring)
    assert isinstance(attr.private, bool)
    assert isinstance(attr.required, bool)
    assert isinstance(attr.default, bool)
    assert isinstance(attr.listof, basestring)

# Generated at 2022-06-11 09:44:09.036271
# Unit test for constructor of class Attribute
def test_Attribute():

    # constructor has 6 required inputs
    try:
        a = Attribute()
    except:
        pass
    else:
        raise AssertionError("creating attribute with no inputs should be impossible")

    # constructor has 6 required inputs + 7 optional inputs
    try:
        a = Attribute(
            'list',
            True,
            [],
            False,
            'string',
            100,
            str,
            True,
            True,
            'alias',
            True,
            True,
            True
        )
    except:
        raise AssertionError("creating attribute with all inputs should be possible")

    # constructor accepts non-mutable default values

# Generated at 2022-06-11 09:44:09.608796
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()



# Generated at 2022-06-11 09:44:14.947012
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None

# Generated at 2022-06-11 09:44:26.049552
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute('str',
                          private=False,
                          default=None,
                          required=False,
                          listof=None,
                          priority=0,
                          class_type=None,
                          always_post_validate=False,
                          inherit=True,
                          alias=None,
                          extend=False,
                          prepend=False,
                          static=False
                         )
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
   

# Generated at 2022-06-11 09:44:37.111527
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None


# Generated at 2022-06-11 09:44:45.547247
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:44:55.723682
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr = Attribute(
        isa = 'list',
        private = False,
        default= 'default',
        required = True,
        listof = 'type',
        priority = 0,
        class_type = False,
        always_post_validate = False,
        inherit = True,
        alias = 'type'
    )
    assert test_attr.isa == 'list'
    assert test_attr.private == False
    assert test_attr.default == 'default'
    assert test_attr.required == True
    assert test_attr.listof == 'type'
    assert test_attr.priority == 0
    assert test_attr.class_type == False
    assert test_attr.always_post_validate == False
    assert test_attr.inherit == True

# Generated at 2022-06-11 09:44:57.625364
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.isa == 'list'


# Generated at 2022-06-11 09:45:30.561813
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', listof='dict')
    assert a.isa == 'list'
    assert a.listof == 'dict'

# Generated at 2022-06-11 09:45:33.212635
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa='list',
        default=['a', 'b', 'c'],
    )
    assert attr.isa == 'list'
    assert isinstance(attr.default, list)
    assert len(attr.default) == 3



# Generated at 2022-06-11 09:45:42.755346
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest

    # test with no arguments
    with pytest.raises(TypeError):
        assert FieldAttribute()

    # test with wrong arguments
    with pytest.raises(TypeError):
        assert FieldAttribute('str', 1234, static='here')

    # test with wrong arguments
    with pytest.raises(TypeError):
        assert FieldAttribute(static='here')

    # test with wrong keyword arguments
    with pytest.raises(TypeError):
        assert FieldAttribute(a='b')

    # test with wrong keyword argument
    with pytest.raises(TypeError):
        assert FieldAttribute(static=None)

    # test with good keyword arguments
    assert FieldAttribute(static=True)

    # test with good keyword arguments
    assert FieldAttribute(static=False)


# Generated at 2022-06-11 09:45:51.720924
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    >>> priority = 0
    >>> listof = None
    >>> required = False
    >>> class_type = None
    >>> isa = 'str'
    >>> private = False
    >>> default = None
    >>> isa_listof = None
    >>> always_post_validate = False
    >>> inherit = True
    >>> alias = None
    >>> extend = False
    >>> prepend = False
    >>> static = False
    >>> field_attribute = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    """



# Generated at 2022-06-11 09:46:00.479407
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa1 = FieldAttribute(isa='str')
    assert isinstance(fa1.isa, str)

    fa2 = FieldAttribute(isa=int, default=7)
    assert isinstance(fa2.isa, type)
    if callable(fa2.default):
        assert fa2.default() == 7
    else:
        assert fa2.default == 7

    # This will fail because a mutable datatype was passed in as the default
    raise_error = False
    try:
        fa3 = FieldAttribute(isa='dict', default={'foo': 'bar'})
    except TypeError:
        raise_error = True
    assert raise_error

    # This will pass because a callable has been provided that returns a dict
    fa4 = FieldAttribute(isa='dict', default=lambda: {'foo':'bar'})
