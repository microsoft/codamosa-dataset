

# Generated at 2022-06-11 09:36:07.846447
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # generate a class called "TestFieldAttribute"
    # that is a subclass of FieldAttribute
    class TestFieldAttribute(FieldAttribute):
        def post_validate(self, obj, value):
            return value

    # create an instance of class TestFieldAttribute
    attr = TestFieldAttribute(isa='int',
                              private=False,
                              default=None,
                              required=False,
                              listof=None,
                              priority=0,
                              class_type=int,
                              always_post_validate=False,
                              inherit=True,
                              alias=None,
                              extend=False,
                              prepend=False,)

    assert attr.isa == 'int'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
   

# Generated at 2022-06-11 09:36:15.187584
# Unit test for constructor of class Attribute
def test_Attribute():
    FieldAttribute(isa='local')
    FieldAttribute(isa='local',
                   private=True)
    FieldAttribute(isa='local',
                   private=False)
    FieldAttribute(isa='local',
                   private=True,
                   default=None)
    FieldAttribute(isa='local',
                   private=True,
                   default=None,
                   required=False)
    FieldAttribute(isa='local',
                   private=True,
                   default=None,
                   required=False,
                   listof='dict')
    FieldAttribute(isa='local',
                   private=True,
                   default=None,
                   required=False,
                   listof='dict',
                   priority=0)

# Generated at 2022-06-11 09:36:21.967426
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = "test"
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    field_attribute = FieldAttribute(isa=isa, private=private, default=default, required=required, listof=listof, priority=priority, class_type=class_type, always_post_validate=always_post_validate, inherit=inherit, alias=alias, extend=extend, prepend=prepend, static=static)



# Generated at 2022-06-11 09:36:28.984220
# Unit test for constructor of class Attribute
def test_Attribute():
    import unittest
    import pytest
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    class MockCollectionConfig(AnsibleCollectionConfig):
        attr1 = FieldAttribute(isa='bool', default=False)

    mcc = MockCollectionConfig()
    assert mcc.attr1.isa == 'bool'
    assert mcc.attr1.default == False
    assert mcc.attr1.private == False
    assert mcc.attr1.required == False
    assert mcc.attr1.listof is None
    assert mcc.attr1.priority == 0
    assert mcc.attr1.class_type is None
    assert mcc.attr1.always_post_validate == False
    assert mcc.attr1.inherit == True
    assert mcc.attr1.extend == False


# Generated at 2022-06-11 09:36:39.231113
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Check that isa and private are optional, but default and required are
    # not
    attr1 = FieldAttribute()
    assert attr1.isa is None
    assert attr1.private is False
    assert attr1.default is None
    assert attr1.required is False

    # Check that isa and private are optional, but default and required are
    # not
    attr2 = FieldAttribute(isa='dict')
    assert attr2.isa == 'dict'
    assert attr2.private is False
    assert attr2.default is None
    assert attr2.required is False

    # Check that isa and private are optional, but default and required are
    # not
    attr3 = FieldAttribute(private=True)
    assert attr3.isa is None
    assert attr3.private is True

# Generated at 2022-06-11 09:36:45.608754
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict',
                        private=False,
                        default=None,
                        required=False,
                        listof=None,
                        priority=2,
                        class_type=None,
                        always_post_validate=True,
                        inherit=True,
                        alias=None,
                        )
    if fa:
        pass  # if no exceptions raised then no errors.




# Generated at 2022-06-11 09:36:58.124249
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='str',
        private=True,
        default='arbitrary default',
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        extend=False,
        prepend=False,
        static=False,
    )
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'arbitrary default'
    assert a.required == False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.extend == False

# Generated at 2022-06-11 09:37:03.427328
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        extend=False,
    )
    assert fa is not None

if __name__ == '__main__':
    test_FieldAttribute()

# Generated at 2022-06-11 09:37:13.457221
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # pylint: disable=too-many-statements,bare-except
    attr = FieldAttribute()
    assert attr.isa is None, "isa is not None"
    assert attr.private is False, "private is not False"
    assert attr.default is None, "default is not None"
    assert attr.required is False, "required is not False"
    assert attr.listof is None, "listof is not None"
    assert attr.priority is 0, "priority is not 0"
    assert attr.class_type is None, "class_type is not None"
    assert attr.always_post_validate is False, "always_post_validate is not False"
    assert attr.inherit is True, "inherit is not True"
    assert attr.alias is None

# Generated at 2022-06-11 09:37:20.913374
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test 1: Call FieldAttribute.__init__() with no args
    # Expected: 1. FieldAttribute.isa is None
    #           2. FieldAttribute.private is False
    #           3. FieldAttribute.default is None
    #           4. FieldAttribute.required is False
    #           5. FieldAttribute.lisof is None
    #           6. FieldAttribute.priority is 0
    #           7. FieldAttribute.class_type is None
    #           8. FieldAttribute.always_post_validate is False
    #           9. FieldAttribute.inherit is True
    #           10. FieldAttribute.alias is None
    #           11. FieldAttribute.extend is False
    #           12. FieldAttribute.prepend is False
    #           13. FieldAttribute.static is False
    fa = FieldAttribute()
    assert fa.isa

# Generated at 2022-06-11 09:37:31.533250
# Unit test for constructor of class Attribute
def test_Attribute():
    at = Attribute(default=True)
    at1 = Attribute(default="default")
    at2 = Attribute(default="default", priority=1)
    assert at != at1, "Attribute objects are not equal"
    assert at2 != at1, "Attribute objects are not equal"
    assert at1 > at, "Attribute is not less than another attribute"
    assert at2 >= at1, "Attribute is not greater than or equal to another attribute"
    assert at1 < at2, "Attribute is not less than another attribute"
    assert at1 <= at2, "Attribute is not less than or equal to another attribute"
    assert at1 == at2, "Attribute is greater than or equal to another attribute"

# Extend the Attribute class with a class method to create
# a new Attribute object based on an existing Attribute
# but which overrides

# Generated at 2022-06-11 09:37:33.420044
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa="str",default="test")
    assert f.isa == "str"
    assert f.default == "test"

# Generated at 2022-06-11 09:37:36.902977
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_object = FieldAttribute(isa='str', private=True, default=None, required=True, listof='str', priority=0, class_type='str', always_post_validate=False, inherit=True, alias='str', extend=False, prepend=False)
    assert test_object is not None, 'No object instantiated'



# Generated at 2022-06-11 09:37:42.527603
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the constructor of Attribute
    a = Attribute()
    # Test for __eq__()
    assert(a == a)
    # Test for __ne__()
    assert(a != FieldAttribute())
    # Test for __lt__()
    assert(a < FieldAttribute())
    # Test for __gt__()
    assert(FieldAttribute() > a)
    # Test for __le__()
    assert(a <= a)
    # Test for __ge__()
    assert(FieldAttribute() >= a)

# Generated at 2022-06-11 09:37:54.072486
# Unit test for constructor of class Attribute
def test_Attribute():

    assert Attribute().private == False
    assert Attribute().required == False
    assert Attribute().inherit == True

    assert Attribute(private=True).private == True
    assert Attribute(required=True).required == True
    assert Attribute(inherit=False).inherit == False

    assert Attribute(default=dict()).default == dict()
    assert Attribute(default=list()).default == list()
    assert Attribute(default=set()).default == set()

    try:
        Attribute(default=dict(a='a'))
    except TypeError:
        pass
    else:
        assert False, 'defaults for FieldAttribute may not be mutable, please provide a callable instead'

    try:
        Attribute(default=list(['a']))
    except TypeError:
        pass
   

# Generated at 2022-06-11 09:38:06.618403
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test 1 : test the set of the value of isa, private, default, required, listof, priority, class_type, always_post_validate,
    # inherit, alias and extend is true
    result = True
    fieldAttribute = FieldAttribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None,
    always_post_validate=False, inherit=True, alias=None, extend=False)

# Generated at 2022-06-11 09:38:09.156809
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert not attr.private

    attr = Attribute(private=True)
    assert attr.private



# Generated at 2022-06-11 09:38:13.390713
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(
        isa='list',
        default=lambda: [],
        required=False,
        listof='dict',
        priority=0,
        class_type='string',
        always_post_validate=False,
        inherit=True,
        alias='FieldAttribute.f1')


# Generated at 2022-06-11 09:38:23.511868
# Unit test for constructor of class Attribute
def test_Attribute():
    class MyClass:
        a = Attribute(isa='int', default='super')
        b = Attribute(isa='int', default='super')
        c = Attribute(isa='class', default='super')
        d = Attribute(isa='bool', default=True)
        e = FieldAttribute(isa='list', default=list())
        f = FieldAttribute(isa='bool', default=True)
        g = FieldAttribute(isa='list', default=list())
        h = FieldAttribute(isa='dict', default=dict)
        i = FieldAttribute(isa='set', default=set)
        j = FieldAttribute(isa='list', default=list, listof='int')
        k = FieldAttribute(isa='list', default=list, listof='int')

# Generated at 2022-06-11 09:38:28.555168
# Unit test for constructor of class Attribute
def test_Attribute():
    testAttributeDefault = Attribute(isa='list', default=list, required=True)
    assert(testAttributeDefault.default() == [])
    assert(testAttributeDefault.required == True)

    with pytest.raises(TypeError):
        Attribute(isa='list', default=[], required=True)

# Generated at 2022-06-11 09:38:41.254287
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # attribute is a single field of a complex data type
    f1 = FieldAttribute()
    assert f1.isa == None
    assert f1.private == False
    assert f1.default == None
    assert f1.required == False
    assert f1.listof == None
    assert f1.priority == 0
    assert f1.class_type == None
    assert f1.always_post_validate == False
    assert f1.inherit == True
    assert f1.alias == None
    assert f1.extend == False
    assert f1.prepend == False
    assert f1.static == False


# Generated at 2022-06-11 09:38:43.279060
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='unicode', required=True)
    assert field.required == True
    assert field.isa == 'unicode'

# Generated at 2022-06-11 09:38:43.813150
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-11 09:38:51.032870
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', listof='int')
    assert f.isa == 'list'
    assert f.listof == 'int'
    try:
        FieldAttribute(isa='list', listof='int', default=[1, 2, 3])
        raise AssertionError('defaults for FieldAttribute may not be mutable, please provide a callable instead')
    except TypeError as e:
        assert 'defaults for FieldAttribute may not be mutable' in str(e)


# Generated at 2022-06-11 09:38:53.660842
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', default='hello world')
    assert a.isa == 'string'
    assert a.default == 'hello world'

# Generated at 2022-06-11 09:38:54.733519
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute


# Generated at 2022-06-11 09:39:05.893794
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # We'll use this to test that __init__ is working properly.
    class TestClass:
        def __init__(self):
            self.isa = None
            self.private = False
            self.default = None
            self.required = False
            self.listof = None
            self.priority = 0
            self.class_type = None
            self.always_post_validate = False
            self.inherit = True
            self.alias = None
            self.extend = False
            self.prepend = False
            self.static = False
    # This should be the same as __init__ is with no arguments.
    empty = TestClass()
    test_empty = FieldAttribute()
    assert test_empty == empty
    # Test that __init__ expects the following keyword arguments.

# Generated at 2022-06-11 09:39:12.017212
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        Attribute(isa='list', default=[])
    except TypeError:
        assert True
    else:
        assert False

    assert Attribute(isa='list', default=[]) != Attribute(isa='str', default='foo')
    assert Attribute(isa='str', default='foo', priority=1) > Attribute(isa='str', default='foo', priority=0)
    assert Attribute(isa='str', default='foo', priority=0) < Attribute(isa='str', default='foo', priority=1)


# Generated at 2022-06-11 09:39:21.955169
# Unit test for constructor of class Attribute
def test_Attribute():
    # pylint: disable=dangerous-default-value,too-many-arguments
    obj = Attribute(isa=str, private=True, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert obj.isa == str
    assert obj.private == True
    assert obj.default == None
    assert obj.required == False
    assert obj.listof == None
    assert obj.priority == 0
    assert obj.class_type == None
    assert obj.always_post_validate == False
    assert obj.inherit == True
    assert obj.alias == None
    assert obj.extend == False
    assert obj.prepend == False
   

# Generated at 2022-06-11 09:39:31.788827
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list',
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=0,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False)

    assert a.isa == 'list'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False


# Generated at 2022-06-11 09:39:44.393198
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attribute = FieldAttribute()

    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False



# Generated at 2022-06-11 09:39:48.734173
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # check that constructor raises TypeError when default is mutable and isa is a container
    import pytest
    with pytest.raises(TypeError):
        field = FieldAttribute(isa='list', default=list())

# Generated at 2022-06-11 09:39:49.357475
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()

# Generated at 2022-06-11 09:39:57.740199
# Unit test for constructor of class Attribute
def test_Attribute():
    # first test, isa is optional
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # second test, all the values are set

# Generated at 2022-06-11 09:40:09.010946
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str',
                       private=False,
                       default='test',
                       required=True,
                       listof='str',
                       priority=0,
                       class_type='str',
                       always_post_validate=False,
                       inherit=True,
                       alias='test_alias',
                       extend=False,
                       prepend=False,
                       static=False)

    assert f.isa == 'str'
    assert f.private == False
    assert f.default == 'test'
    assert f.required == True
    assert f.listof == 'str'
    assert f.priority == 0
    assert f.class_type == 'str'
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == 'test_alias'
    assert f

# Generated at 2022-06-11 09:40:10.016660
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute()


# Generated at 2022-06-11 09:40:16.659683
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().isa is None
    assert FieldAttribute().private is False
    assert FieldAttribute().default is None
    assert FieldAttribute().required is False
    assert FieldAttribute().listof is None
    assert FieldAttribute().priority is 0
    assert FieldAttribute().class_type is None
    assert FieldAttribute().always_post_validate is False
    assert FieldAttribute().inherit is True
    assert FieldAttribute().alias is None
    assert FieldAttribute().extend is False
    assert FieldAttribute().prepend is False



# Generated at 2022-06-11 09:40:26.215036
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject


# Generated at 2022-06-11 09:40:31.797463
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0, class_type=None, extend=False, prepend=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None


# Generated at 2022-06-11 09:40:41.007276
# Unit test for constructor of class Attribute
def test_Attribute():
    # Can specify the type that the attribute should be
    attr = Attribute(isa='dict', private=True)
    assert attr.isa == 'dict'
    assert attr.private is True

    # Can specify a default value
    attr = Attribute(isa='dict', default={'test': 'value'})
    assert attr.default == {'test': 'value'}

    # can specify a required flag
    attr = Attribute(isa='dict', required=True)
    assert attr.required is True

    # can specify a listof type
    attr = Attribute(listof='str')
    assert attr.listof == 'str'

    # can specify a priority
    attr = Attribute(priority=10)
    assert attr.priority == 10

    # can specify class type

# Generated at 2022-06-11 09:40:53.832386
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor with all arguments
    a = FieldAttribute(
        isa='string',
        private=True,
        default='test',
        required=True,
        listof='string',
        priority=1,
        class_type='Base',
        always_post_validate=True,
        inherit=True,
        alias='alias_attr',
        extend=False,
        prepend=False,
        static=False,
    )
    assert a.isa == 'string'
    assert a.private is True
    assert a.default == 'test'
    assert a.required is True
    assert a.listof == 'string'
    assert a.priority == 1
    assert a.class_type == 'Base'
    assert a.always_post_validate is True
    assert a.inherit is True
   

# Generated at 2022-06-11 09:41:04.519270
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print('\nTest FieldAttribute')
    isa = 'list'
    private = True
    default = 123
    required = True
    listof = 'dict'
    priority = 1
    class_type = dict
    always_post_validate = True
    inherit = True
    alias = 'a1'
    extend = True
    prepend = True
    static = True
    attr = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)
    print('  isa=', attr.isa)
    print('  private=', attr.private)
    print('  default=', attr.default)
    print('  required=', attr.required)

# Generated at 2022-06-11 09:41:06.049628
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_field_attribute = FieldAttribute()
    assert test_field_attribute

# Generated at 2022-06-11 09:41:16.163551
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Tests Attribute class constructor
    """
    a = FieldAttribute(
        isa='list',
        default='test',
        required=True,
        listof='int',
        priority=0,
        class_type='Test',
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=False,
        prepend=True
    )

    assert a.isa == 'list'
    assert a.default == 'test'
    assert a.required == True
    assert a.listof == 'int'
    assert a.priority == 0
    assert a.class_type == 'Test'
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'alias'
    assert a.extend == False


# Generated at 2022-06-11 09:41:23.194491
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()

    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-11 09:41:34.779148
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='bool', private=True, default=False, required=True, listof=None,
                          priority=50, class_type=None, always_post_validate=True,
                          inherit=False, alias=None, extend=True, prepend=True, static=False)

    assert attr.isa == 'bool'
    assert attr.private == True
    assert attr.default == False
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 50
    assert attr.class_type == None
    assert attr.always_post_validate == True
    assert attr.inherit == False
    assert attr.alias == None
    assert attr.extend == True
    assert attr.prepend == True

# Generated at 2022-06-11 09:41:36.817118
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    # This test should pass always as it's just checking a "do nothing" constructor
    assert True

# Generated at 2022-06-11 09:41:46.475711
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    def func() means default is mutable???
    def func():
        pass
    """
    #test default
    Attribute(default=dict())
    Attribute(default=list())
    Attribute(default=set())
    Attribute(default=lambda : dict())
    Attribute(default=lambda : list())
    Attribute(default=lambda : set())

    # test error exception
    try:
        Attribute(default=func)
    except TypeError:
        pass
    try:
        Attribute(default=lambda: func)
    except TypeError:
        pass

test_Attribute()
# Unit test end

# Generated at 2022-06-11 09:41:49.703050
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='bool', private=True, default=None, required=False, listof=None,
        priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert a
    assert a.isa == 'bool'



# Generated at 2022-06-11 09:41:54.784821
# Unit test for constructor of class Attribute
def test_Attribute():

    x = Attribute(isa=int, default=5, required=True,
                  listof=str, priority=10, class_type=int, always_post_validate=True, inherit=False, alias='test')
    assert x.isa == int
    assert x.default == 5
    assert x.required == True
    assert x.listof == str
    assert x.priority == 10
    assert x.class_type == int
    assert x.always_post_validate == True
    assert x.inherit == False
    assert x.alias == 'test'


# Generated at 2022-06-11 09:42:11.604243
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.__eq__(Attribute()) == True
    assert attr.__ne__(Attribute()) == False
    assert attr.__lt__(Attribute()) == False
    assert attr.__gt__(Attribute()) == False
    assert attr.__le__(Attribute()) == True
    assert attr.__ge__(Attribute()) == True

    attr = Attribute(default=None)
    assert attr.default == None

    attr = Attribute(default=['a','b','c'])
    assert attr.default == ['a','b','c']
    assert attr.default != ['a','b','c','d']

    attr = Attribute(default=['a','b','c'], isa='list')

# Generated at 2022-06-11 09:42:16.387220
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private == False
    assert fa.default is None
    assert fa.required == False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias is None
    assert fa.static == False


# Generated at 2022-06-11 09:42:27.325451
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='bool', private=False, default=False, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=False, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'bool'
    assert attr.private == False
    assert attr.default == False
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == False
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-11 09:42:37.722264
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = 'dict'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    attr = FieldAttribute(
        isa,
        private,
        default,
        required,
        listof,
        priority,
        class_type,
        always_post_validate,
        inherit,
        alias,
        extend,
        prepend,
        static
    )

    assert attr.isa == isa
    assert attr.private == private
    assert attr.default == default
    assert attr.required == required
    assert attr.listof == listof

# Generated at 2022-06-11 09:42:45.150395
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    class Foo:
        pass

    a = Attribute(isa='Foo')
    assert a.isa == 'Foo'

    with pytest.raises(TypeError):
        a = Attribute(isa='list', default=['foo', 'bar'])

    a = Attribute(isa='list', default=lambda: ['foo', 'bar'])


# Generated at 2022-06-11 09:42:55.664396
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list')

    assert isinstance(a, Attribute)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:43:02.011124
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute(isa='string', private=True, default=False, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert isinstance(a, Attribute)
    assert a.isa == 'string'
    assert a.private == True
    assert a.default == False
    assert a.listof == None
    assert a.class_type == None
    assert a.alias == None


# Generated at 2022-06-11 09:43:04.615775
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    >>> a = Attribute(isa='dict')
    >>> a.isa
    'dict'
    >>> a.default
    >>> a.required
    False
    >>> a.listof
    """


# Generated at 2022-06-11 09:43:11.364191
# Unit test for constructor of class Attribute
def test_Attribute():
    f = Attribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    # Test attributes are set correctly
    assert f.isa == 'list'
    assert f.private == False
    assert f.default is None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
   

# Generated at 2022-06-11 09:43:14.935408
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # We can create an instance of fieldattribute class
    f = FieldAttribute()
    assert isinstance(f, FieldAttribute)



# Generated at 2022-06-11 09:43:28.690989
# Unit test for constructor of class Attribute
def test_Attribute():
    import unittest
    class TestAttribute(unittest.TestCase):
        def test_Attribute_constructor(self):
            def test_raise():
                Attribute(default=['a', 'b']) # mutable default
            self.assertRaises(TypeError, test_raise)  # exception should be raised

    unittest.main()

# Generated at 2022-06-11 09:43:35.438653
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create a FieldAttribute object
    c1 = FieldAttribute(isa='list')
    c2 = FieldAttribute(isa='list')

    # Test __eq__
    assert (c1 == c2)

    # Test __ne__
    assert (c1 != c2)

    # Test __lt__
    assert (c1 < c2)

    # Test __gt__
    assert (c1 > c2)

    # Test __le__
    assert (c1 <= c2)

    # Test __ge__
    assert (c1 >= c2)



# Generated at 2022-06-11 09:43:36.294923
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='string')



# Generated at 2022-06-11 09:43:45.400384
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-11 09:43:48.492676
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        field_attribute = FieldAttribute(isa='dict', private=False, default=None, required=False, extend=True)
    except:
        field_attribute = None
    assert field_attribute is not None



# Generated at 2022-06-11 09:43:49.723902
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute(default={})

# Generated at 2022-06-11 09:43:50.702164
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    o = FieldAttribute(isa="str")



# Generated at 2022-06-11 09:43:54.190607
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    try:
        a = Attribute(default={})
    except TypeError:
        pass
    a = Attribute(static=True)
    assert a.static == True


# Generated at 2022-06-11 09:44:04.296338
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(
        isa=dict,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert FA.isa == dict
    assert FA.private == False
    assert FA.default == None
    assert FA.required == False
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert FA.always_post_validate == False
    assert FA.inherit == True
    assert FA.alias == None
    assert FA.extend == False

# Generated at 2022-06-11 09:44:10.944961
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attributes = [
        "isa",
        "private",
        "default",
        "required",
        "listof",
        "priority",
        "class_type",
        "always_post_validate",
        "inherit",
        "alias",
        "extend",
        "prepend",
        "static",
    ]

    fa = FieldAttribute()
    for attribute in attributes:
        assert hasattr(fa, attribute), "FieldAttribute does not have expected attribute: %s" % attribute



# Generated at 2022-06-11 09:44:40.204645
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-11 09:44:41.413804
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Fa = FieldAttribute()
    assert Fa.isa == None


# Generated at 2022-06-11 09:44:47.300030
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest
    import numbers

    class MyClass(object):
        def __init__(self, a, b, d=None):
            self.a = a
            self.b = b
            self.d = d

    class MyNumber(numbers.Number):
        pass

    class TestFieldAttribute(unittest.TestCase):
        def test_FieldAttribute(self):
            # Test Class
            try:
                FieldAttribute(isa='class', class_type=MyClass, default={'a': 1, 'b': 'test'})
            except TypeError as e:
                self.fail('FieldAttribute constructor with class_type keyword raises unexpected TypeError: %s' % e)

# Generated at 2022-06-11 09:44:49.102825
# Unit test for constructor of class Attribute
def test_Attribute():
    f = Attribute(isa='test')
    assert f.isa == 'test', f.isa

# Generated at 2022-06-11 09:44:59.466771
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:45:03.834147
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute('dict', default=[1,2,3,4])
    with pytest.raises(TypeError):
        Attribute('list', default={'a':'b', 'c':'d'})
    with pytest.raises(TypeError):
        Attribute('set', default={'a', 'b'})

# Generated at 2022-06-11 09:45:14.083776
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert field_attribute.private == False
    assert field_attribute.inherit == True
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False
    assert field_attribute.isa == 'str'
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.alias == None
    
    
    
    
# Test

# Generated at 2022-06-11 09:45:24.017163
# Unit test for constructor of class Attribute
def test_Attribute():

    isa = 'a'
    private = 'b'
    default = 'c'
    required = 'd'
    listof = 'e'
    priority = 'f'
    class_type = 'g'
    always_post_validate = 'h'
    inherit = 'i'
    alias = 'j'
    extend = 'k'
    prepend = 'l'
    static = 'm'

    test = Attribute(
        isa,
        private,
        default,
        required,
        listof,
        priority,
        class_type,
        always_post_validate,
        inherit,
        alias,
        extend,
        prepend,
        static
    )

    assert test.isa == 'a'
    assert test.private == 'b'

# Generated at 2022-06-11 09:45:32.766625
# Unit test for constructor of class Attribute
def test_Attribute():
    class MyClass(object):
        '''
        This class is created for testing purpose
        '''
        # Define a Attribute instance
        myattribute_value = Attribute(isa='int', required=True, default=1)
        myattribute_list = Attribute(isa='list', listof='int')
        myattribute_dict = Attribute(isa='dict', listof='int')
        myattribute_set = Attribute(isa='set', listof='int')
        myattribute_class = Attribute(isa='class', listof='int')
        myattribute_other = Attribute(isa='other', listof='int', default=None, class_type='MyClass')

    # Define a class instance
    myinstance = MyClass()

    assert isinstance(myinstance.myattribute_value, int)

# Generated at 2022-06-11 09:45:42.309880
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.required is False
    assert attr.default is None
    assert attr.listof is None

    attr = Attribute(isa='int', required=True, default=10, listof='str')
    assert attr.isa == 'int'
    assert attr.required is True
    assert attr.default == 10
    assert attr.listof == 'str'

    attr = Attribute(isa='int', required=True, default={}, listof='str')
    # assert attr.isa == None
    # assert attr.required is False
    # assert attr.default is None
    # assert attr.listof is None

if __name__ == "__main__":
    test_Attribute()