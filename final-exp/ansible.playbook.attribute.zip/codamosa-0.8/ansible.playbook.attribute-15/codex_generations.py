

# Generated at 2022-06-11 09:36:11.048731
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    if a.isa != None:
        raise TypeError
    if a.private != False:
        raise TypeError
    if a.default != None:
        raise TypeError
    if a.required != False:
        raise TypeError
    if a.listof != None:
        raise TypeError
    if a.priority != 0:
        raise TypeError
    if a.class_type != None:
        raise TypeError
    if a.always_post_validate != False:
        raise TypeError
    if a.inherit != True:
        raise TypeError
    if a.alias != None:
        raise TypeError
    if a.extend != False:
        raise TypeError
    if a.prepend != False:
        raise TypeError
    if a.static != False:
        raise Type

# Generated at 2022-06-11 09:36:12.138349
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #TODO: implement test_FieldAttribute
    return True


# Generated at 2022-06-11 09:36:17.349789
# Unit test for constructor of class Attribute
def test_Attribute():
    assert hasattr(Attribute, 'isa')
    assert hasattr(Attribute, 'private')
    assert hasattr(Attribute, 'default')
    assert hasattr(Attribute, 'required')
    assert hasattr(Attribute, 'listof')
    assert hasattr(Attribute, 'priority')
    assert hasattr(Attribute, 'class_type')
    assert hasattr(Attribute, 'always_post_validate')
    assert hasattr(Attribute, 'inherit')
    assert hasattr(Attribute, 'alias')
    assert hasattr(Attribute, 'extend')
    assert hasattr(Attribute, 'prepend')
    assert hasattr(Attribute, 'static')

# Generated at 2022-06-11 09:36:25.343942
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: need a few more tests here
    # test the isa listof combination
    attr = Attribute(isa='list', listof='str', static=True)
    assert attr.static is True
    attr = Attribute(isa='list', listof='str', static=False)
    assert attr.static is False

    # test inherit
    attr = Attribute(inherit=True)
    assert attr.inherit is True
    attr = Attribute(inherit=False)
    assert attr.inherit is False

    # test the isa strings that are correct
    try:
        attr = Attribute(isa='list')
    except TypeError:
        assert False, "Didn't expect to raise a TypeError here"


# Generated at 2022-06-11 09:36:33.105339
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().inherit == True
    assert Attribute().alias == None
    assert Attribute().extend == False
    assert Attribute().prepend == False
    assert Attribute().static == False

    assert Attribute(isa='foo').isa == 'foo'
    assert Attribute(private=True).private == True
    assert Attribute(default='foo').default == 'foo'
    assert Attribute(required=True).required == True

# Generated at 2022-06-11 09:36:42.439964
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='string')
    assert field_attribute
    assert field_attribute.isa == 'string'
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False


# Generated at 2022-06-11 09:36:55.390569
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    import sys

    class Test:

        def __init__(self):
            self.data = FieldAttribute(isa='list', private=False, default=None, required=False,
                                       listof=None, priority=0, class_type=None, always_post_validate=False,
                                       inherit=True, alias=None, extend=False, prepend=False, static=False)


    test = Test()

    if sys.version_info[0] == 3:
        assert test.data.isa == 'list'
        assert test.data.private == False
        assert test.data.default == None
        assert test.data.required == False
        assert test.data.listof == None
        assert test.data.priority == 0
        assert test.data.class_type == None
        assert test.data.always_post

# Generated at 2022-06-11 09:36:58.461377
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=True, default=True)
    assert a.isa == 'list'
    assert a.private == True
    assert a.default == True


# Generated at 2022-06-11 09:37:09.589102
# Unit test for constructor of class Attribute
def test_Attribute():
    # define a class
    class Foo(object):
        # test simple cases
        n = Attribute(isa='int', default=42)
        m = Attribute(isa='int')

        # test alias
        o = Attribute(isa='int', alias='alias_o', default=42)

        # test multiple datatypes
        p = Attribute(isa=('dict', 'list'))

        # test listof
        q = Attribute(isa='list', listof='int')

        # test class_type
        r = Attribute(isa='class', class_type=dict)

    f = Foo()

    assert f.n == 42
    assert f.m == None
    assert f.n == f.o

    f.n = 1
    assert f.n == 1


# Generated at 2022-06-11 09:37:15.887607
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='bool',
        private=True,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
    )
    assert a.isa == 'bool'
    assert a.private == True
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.alias is None


# Generated at 2022-06-11 09:37:24.043527
# Unit test for constructor of class Attribute
def test_Attribute():

    atr = Attribute(isa="list", priority=1, required=True)
    assert atr
    assert atr.isa == "list"
    assert atr.private == False
    assert atr.default == None
    assert atr.required == True
    assert atr.listof == None
    assert atr.priority == 1
    assert atr.class_type == None
    assert atr.always_post_validate == False
    assert atr.inherit == True
    assert atr.alias == None
    assert atr.extend == False
    assert atr.prepend == False
    assert atr.static == False



# Generated at 2022-06-11 09:37:24.949956
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute()



# Generated at 2022-06-11 09:37:25.788365
# Unit test for constructor of class Attribute
def test_Attribute():
    # pass
    Attribute()


# Generated at 2022-06-11 09:37:35.035324
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # FieldAttribute.__init__(self,
    # isa=None,
    # private=False,
    # default=None,
    # required=False,
    # listof=None,
    # priority=0,
    # class_type=None,
    # always_post_validate=False,
    # inherit=True,
    # alias=None,
    # extend=False,
    # prepend=False,
    # 
    # )
    # Test1 with Class_type
    a = FieldAttribute(class_type=test_FieldAttribute)

    # Test2 with default, with class_type
    b = FieldAttribute(default=None, class_type=test_FieldAttribute)

    # Test3 with default, without class_type
    c = FieldAttribute(default=None)

    # Test4 with

# Generated at 2022-06-11 09:37:43.400843
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    f.isa = 'test'
    assert f.isa == 'test'
    f.private = True
    assert f.private == True
    f.default = 'test'
    assert f.default == 'test'
    f.required = 'test'
    assert f.required == 'test'
    f.listof = 'test'
    assert f.listof == 'test'
    f.priority = 'test'
    assert f.priority == 'test'
    f.class_type = 'test'
    assert f.class_type == 'test'
    f.always_post_validate = 'test'
    assert f.always_post_validate == 'test'
    f.inherit = 'test'
    assert f.inherit == 'test'

# Generated at 2022-06-11 09:37:44.840115
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    c = FieldAttribute(listof='str')
    assert c.listof == 'str'

# Generated at 2022-06-11 09:37:56.805809
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # FieldAttribute()
    fieldattribute = FieldAttribute()
    assert fieldattribute.isa is None
    assert fieldattribute.private is False
    assert fieldattribute.default is None
    assert fieldattribute.required is False
    assert fieldattribute.listof is None
    assert fieldattribute.priority == 0
    assert fieldattribute.class_type is None
    assert fieldattribute.always_post_validate is False
    assert fieldattribute.inherit is True
    assert fieldattribute.alias is None
    assert fieldattribute.extend is False
    assert fieldattribute.prepend is False
    assert fieldattribute.static is False

    # FieldAttribute(isa='str', private=True, default='abc', required=True,
    #                 listof='bcd', priority=1, class_type='class',
    #                 always_post_validate=True, inherit=

# Generated at 2022-06-11 09:38:01.371603
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a = FieldAttribute('a', default={})
    except Exception as e:
        assert(type(e) == TypeError)
    
    a = FieldAttribute('a', default=lambda: {}, static=True)

# Generated at 2022-06-11 09:38:12.482956
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def f():
        pass

    attribute = FieldAttribute(isa='test',
                               private=True,
                               default='test',
                               required=False,
                               listof='test',
                               priority=1,
                               class_type='test',
                               always_post_validate=False,
                               inherit=True,
                               alias='test',
                               extend=False,
                               prepend=False,
                               static=False)

    assert attribute.isa == 'test'
    assert attribute.private == True
    assert attribute.default == 'test'
    assert attribute.required == False
    assert attribute.listof == 'test'
    assert attribute.priority == 1
    assert attribute.class_type == 'test'
    assert attribute.always_post_validate == False
    assert attribute.inherit

# Generated at 2022-06-11 09:38:16.296389
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils import classproperty

    class Class(object):

        test = Attribute(isa='int', default=1)

    a = Class()
    assert a.test == 1
    a.test = 10
    assert a.test == 10

# Generated at 2022-06-11 09:38:21.012427
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Define a class Foo, with a FieldAttribute 'foo'.
    class Foo():
        foo = FieldAttribute(default=True)

    # Create a new object of class Foo.
    test = Foo()

    # Test if attribute "foo" is True.
    assert test.foo is True

    # Test if calling the constructor does not raise an exception.
    instance = FieldAttribute()



# Generated at 2022-06-11 09:38:23.355139
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = Attribute()
    a2 = FieldAttribute()
    assert isinstance(a, Attribute)
    assert isinstance(a2, Attribute)


# Generated at 2022-06-11 09:38:25.181844
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert isinstance(field_attribute, FieldAttribute)

# Generated at 2022-06-11 09:38:38.208467
# Unit test for constructor of class Attribute
def test_Attribute():
    import datetime as dt
    import time
    import pytz
    import unittest

    class TestModule(unittest.TestCase):

        def test_constructor(self):

            # Test no arguments
            attr = Attribute()
            self.assertEqual(attr.isa, "dict")
            self.assertEqual(attr.private, False)
            self.assertEqual(attr.default, None)
            self.assertEqual(attr.required, False)
            self.assertEqual(attr.listof, None)
            self.assertEqual(attr.priority, 0)
            self.assertEqual(attr.class_type, None)
            self.assertEqual(attr.always_post_validate, False)
            self.assertEqual(attr.inherit, True)
            self

# Generated at 2022-06-11 09:38:40.329157
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(default=1)
    assert attribute.default == 1
    assert attribute.required == False
    assert attribute.listof == None



# Generated at 2022-06-11 09:38:47.374629
# Unit test for constructor of class Attribute
def test_Attribute():
    # test defaults
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False

    # test all configs set

# Generated at 2022-06-11 09:38:59.271203
# Unit test for constructor of class Attribute
def test_Attribute():
    """This is a really simple test module, meant to be run by the python
    interpreter directly.  It tries to execute the Attribute __init__
    method with a few different combinations of parameters.
    """
    # The following should not raise any exceptions
    Attribute(isa='boolean')
    Attribute(isa='boolean', listof='string')
    Attribute(isa='list')
    Attribute(isa='list', listof='string')
    Attribute(isa='dict')
    Attribute(isa='dict', listof='string')
    Attribute(isa='string')
    Attribute(isa='string', listof='string')
    Attribute(isa='int')
    Attribute(isa='int', listof='string')

    # The following should raise an exception.

# Generated at 2022-06-11 09:39:09.590080
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert isinstance(attr, FieldAttribute)
    # the following line will fail until we fix the param defaults
    # see https://github.com/ansible/ansible/issues/2627
    # attr = FieldAttribute(isa='bool', default=True, required=True)
    attr = FieldAttribute(isa='bool', default=lambda: True, required=True)
    assert isinstance(attr, FieldAttribute)
    attr = FieldAttribute(isa='bool', default=True, required=True)
    assert isinstance(attr, FieldAttribute)
    pytest.raises(TypeError, FieldAttribute, isa='bool', default={}, required=True)
    pytest.raises(TypeError, FieldAttribute, isa='bool', default=True, required=True, inherit=True)

# Generated at 2022-06-11 09:39:11.546570
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=2, inherit=False)
    assert attr.isa == 'int'
    assert attr.default == 2
    assert attr.inherit is False

# Generated at 2022-06-11 09:39:12.948986
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='int')
    assert(a.isa == 'int')


# Generated at 2022-06-11 09:39:22.531445
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', class_type=list, listof='string')
    assert isinstance(attr, Attribute)
    assert attr.isa == 'list'
    assert attr.class_type == list
    assert attr.listof == 'string'

# Generated at 2022-06-11 09:39:25.209007
# Unit test for constructor of class Attribute
def test_Attribute():
    foo = Attribute(isa='foo', private=True, alias='bar')
    assert foo.isa == 'foo'
    assert foo.private is True
    assert foo.alias == 'bar'

# Generated at 2022-06-11 09:39:25.874413
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:39:29.251537
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # a = Attribute()
    # raise Exception(a.__dict__)
    # assert a.isa == "my_isa"
    # assert a.private == False
    # assert a.default == None
    pass



# Generated at 2022-06-11 09:39:35.535563
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='str', private=False, required=True, priority=9, class_type='str', inherit=True, always_post_validate=False)
    assert field.isa == 'str'
    assert field.private == False
    assert field.required == True
    assert field.priority == 9
    assert field.class_type == 'str'
    assert field.inherit == True
    assert field.always_post_validate == False


# used in specs for return values

# Generated at 2022-06-11 09:39:45.582542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # test constructor
    f = FieldAttribute()
    assert f.isa is None
    assert not f.private
    assert f.default is None
    assert not f.required
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None

    f = FieldAttribute(isa='int', default=0)
    assert f.isa == 'int'
    assert f.default == 0

    # test map to dict
    # this might be useful for external serialization
    f = FieldAttribute(isa='int', default=0)
    d = dict(f)
    assert d['isa'] == 'int'
    assert d['default'] == 0

# Generated at 2022-06-11 09:39:54.966397
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute('dict', default={}, required=True, priority=0, class_type='dict')
    assert attr.isa == 'dict'
    assert attr.private == False
    assert attr.default == {}
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == 'dict'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

# Generated at 2022-06-11 09:39:57.674478
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(required=True, default=5)
    assert attr.required == True
    assert attr.default == 5



# Generated at 2022-06-11 09:40:03.899462
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()
    FA = FieldAttribute(default={})
    FA = FieldAttribute(default=set())
    FA = FieldAttribute(default=list())
    FA = FieldAttribute(default="True")
    FA = FieldAttribute(default=True)
    try:
        FA = FieldAttribute(default=[])
        raise AssertionError("default list should have raised an exception")
    except TypeError:
        pass



# Generated at 2022-06-11 09:40:14.576976
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    a = FieldAttribute(
        isa='bool',
        private=False,
        default=True,
        required=False,
        listof='scalar',
        priority=0,
        class_type='scalar',
        always_post_validate=True,
        alias='alias1',
        extend=True,
        prepend=True,
        static=True,
    )

    assert a.isa == 'bool'
    assert a.private == False
    assert a.default == True
    assert a.required == False
    assert a.listof == 'scalar'
    assert a.priority == 0
    assert a.class_type == 'scalar'
    assert a.always_post_validate == True
    assert a.alias == 'alias1'
    assert a.extend == True


# Generated at 2022-06-11 09:40:26.174362
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute()



# Generated at 2022-06-11 09:40:27.092315
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()

# Generated at 2022-06-11 09:40:33.761948
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils.vars import combine_vars

    class Foo:
        x = FieldAttribute(default=42)
        y = FieldAttribute(default=lambda: 50)
        z = FieldAttribute(default=lambda: combine_vars({'important_value': 60}, {}))

    assert Foo.x.default == 42
    assert Foo.y.default == 50
    assert Foo.z.default == {'important_value': 60}
    assert Foo.x.required is False
    assert Foo.y.required is False
    assert Foo.z.required is False

# Generated at 2022-06-11 09:40:42.958045
# Unit test for constructor of class Attribute
def test_Attribute():
    # set up type of Attribute
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible

    def _load_yaml(self, data):
        return AnsibleLoader(data, Loader=AnsibleLoader, file_name=None, base_dir=None).get_single_data()

    def _load_list(self, attr, data, params=None):
        if not isinstance(data, (list, set, tuple)):
            raise TypeError()
        results = []
        for item in data:
            results.append(self._load_attr(attr, item, params=params))

# Generated at 2022-06-11 09:40:44.007011
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()



# Generated at 2022-06-11 09:40:50.376172
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test to see if we can create a valid Attribute
    attr1 = Attribute()

    # Test to see that we can't create an Attribute object with an invalid key
    try:
        attr2 = Attribute(foo='bar')
    except Exception:
        pass

    # Test to see that we can't create an Attribute object with a default that is mutable
    try:
        attr3 = Attribute(default={})
    except TypeError:
        pass

# Generated at 2022-06-11 09:41:00.977949
# Unit test for constructor of class Attribute
def test_Attribute():

    def test_default_value():

        a = Attribute()

        assert a.isa == None
        assert a.private == False
        assert a.default == None
        assert a.required == False
        assert a.listof == None
        assert a.priority == 0
        assert a.class_type == None
        assert a.always_post_validate == False
        assert a.inherit == True
        assert a.alias == None
        assert a.extend == False
        assert a.prepend == False
        assert a.static == False


# Generated at 2022-06-11 09:41:11.460290
# Unit test for constructor of class Attribute
def test_Attribute():
    # isa
    value = Attribute(isa='string')
    assert value.isa == 'string'

    # private
    value = Attribute(private=True)
    assert value.private == True

    # default
    value = Attribute(default='string')
    assert value.default == 'string'

    # required
    value = Attribute(required=True)
    assert value.required == True

    # listof
    value = Attribute(listof='list')
    assert value.listof == 'list'

    # priority
    value = Attribute(priority=5)
    assert value.priority == 5

    # class_type
    value = Attribute(class_type='test')
    assert value.class_type == 'test'

    # always_post_validate

# Generated at 2022-06-11 09:41:18.016534
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(listof='int') == FieldAttribute(listof='int')
    assert not FieldAttribute(listof='int') == FieldAttribute(listof='float')
    assert FieldAttribute(listof='int') < FieldAttribute(listof='float')
    assert not FieldAttribute(listof='int') > FieldAttribute(listof='float')
    assert FieldAttribute(listof='int') <= FieldAttribute(listof='float')
    assert not FieldAttribute(listof='int') >= FieldAttribute(listof='float')


# Generated at 2022-06-11 09:41:23.471007
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()


# a shared instance of the base class, used by classes to save a little space
# by avoiding storing the same attribute object over and over
_Unspecified = Attribute()


# the set of names that are known to be attribute objects, so we don't have
# to go looking in a dictionary to find the objects
_KNOWN_ATTRIBUTE_NAMES = frozenset(['_Unspecified'])



# Generated at 2022-06-11 09:41:53.511042
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    # test with no isa
    with pytest.raises(TypeError) as excinfo:
        Attribute()
    assert "__init__() missing 1 required positional argument: 'isa'" in str(excinfo.value)

    # test with an invalid isa <str>
    with pytest.raises(TypeError) as excinfo:
        Attribute("list")
    assert "list is not a valid isa value for an Attribute" in str(excinfo.value)

    # test with an invalid isa <str>
    with pytest.raises(TypeError) as excinfo:
        Attribute(list)
    assert "list is not a valid isa value for an Attribute" in str(excinfo.value)

    # test with an invalid isa <int>

# Generated at 2022-06-11 09:42:05.076984
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority is 0
    assert attribute.class_type is None
    assert attribute.inherit is True
    assert attribute.alias is None

    attribute = Attribute("Test",
                           False,
                           "test_default",
                           False,
                           "listof_test",
                           10,
                           "class_test",
                           False,
                           True,
                           "alias_test"
                          )

    assert attribute.isa == "Test"
    assert attribute.private is False
    assert attribute.default == "test_default"
    assert attribute.required is False
    assert attribute.listof

# Generated at 2022-06-11 09:42:07.395659
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(private=True)
    assert f.private == True
# End test of constructor of class FieldAttribute

# Generated at 2022-06-11 09:42:09.772972
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa = "test")
    assert a.listof is None
    assert a.priority == 0


# Generated at 2022-06-11 09:42:12.366460
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='string', default='foo', alias='bar')
    assert a.default == ['foo']
    assert a.alias == 'bar'


# Generated at 2022-06-11 09:42:17.882213
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test case: valid keyarg
    a = FieldAttribute(isa='int', default=1, required=True)
    a.default
    a.required

    # Test case: invalid keyarg
    try:
        a = FieldAttribute(isa='int', invalid='keyarg')
        raise Exception('FieldAttribute constructor did not catch invalid keyarg')
    except:
        pass

    # Test case: invalid kwarg option
    try:
        a = FieldAttribute(isa='int', data='data')
        raise Exception('FieldAttribute constructor did not catch invalid option')
    except:
        pass



# Generated at 2022-06-11 09:42:23.122734
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
  fa = FieldAttribute(isa ='bool', inherit=False)
  assert fa.isa == 'bool'
  assert fa.inherit == False
  assert fa.priority == 0
  fa = FieldAttribute(isa ='bool', inherit=False, priority = 10)
  assert fa.priority == 10
  assert fa == fa



# Generated at 2022-06-11 09:42:29.155376
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default={})
        # Attribute.__init__() should raise an exception if not callable was given
        raise AssertionError('Expected FieldAttribute to raise a TypeError')
    except TypeError:
        pass
    FieldAttribute(default=lambda: {})
    # If a callable was given as default, there should be no error
    FieldAttribute(default='asdf')
    # If a string was given as default, there should be no error



# Generated at 2022-06-11 09:42:36.465613
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False


# Generated at 2022-06-11 09:42:43.414395
# Unit test for constructor of class Attribute
def test_Attribute():
    class Test:
        test2 = Attribute(isa='bool', private=False, default=False, required=False, listof=None,
                          priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    t = Test()
    assert type(t.test2) == bool
    assert t.test2 == False
    t.test2 = True
    assert t.test2 == True
    try:
        t.test2 = "Foo"
    except TypeError:
        pass
    else:
        raise TypeError('should not be able to set test2 to string')



# Generated at 2022-06-11 09:43:38.826613
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:43:41.966215
# Unit test for constructor of class Attribute
def test_Attribute():
        pass

from ansible.module_utils.six import with_metaclass

from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 09:43:51.005696
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='int',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
    )
    assert a.isa == 'int'
    assert a.private is False
    assert a.default is None
    assert a.required is True
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True


# Generated at 2022-06-11 09:43:54.984746
# Unit test for constructor of class Attribute
def test_Attribute():

    # Check that dict is not an allowed field
    # Notice that Attribute is an inner class of class AnsibleBase
    # We don't want to import AnsibleBase, so we test using the actual
    # class name
    try:
        Attribute('AnsibleBase',isa='dict')
        assert(False)
    except TypeError:
        pass

# Generated at 2022-06-11 09:44:04.947916
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = 'DataObject'
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = 'DataObject'
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False
    test_obj = FieldAttribute(isa=isa,private=private,default=default,required=required,listof=listof,\
                              priority=priority,class_type=class_type,always_post_validate=always_post_validate,\
                              inherit=inherit,alias=alias,extend=extend,prepend=prepend,static=static)
    assert test_obj.isa == isa
    assert test_obj.private == private

# Generated at 2022-06-11 09:44:12.090161
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list')
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-11 09:44:14.333052
# Unit test for constructor of class Attribute
def test_Attribute():
    attr1 = Attribute()
    attr2 = Attribute(isa='string')
    assert attr1 == attr2



# Generated at 2022-06-11 09:44:15.988857
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(required=True)
    assert a.required is True
    assert a.private is False


# Generated at 2022-06-11 09:44:27.346880
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """ FieldAttribute object should have the following properties.
    """
    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    fa = FieldAttribute(static=True)
    assert fa.static == True
    fa = FieldAttribute(extend=True)
    assert fa.extend == True
    fa = FieldAttribute(prepend=True)
    assert fa.prepend == True



# Generated at 2022-06-11 09:44:30.399017
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='list', listof='str')
    assert attribute.isa == 'list'
    assert attribute.listof == 'str'

