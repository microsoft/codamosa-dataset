

# Generated at 2022-06-11 09:36:12.960999
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict')
    assert attr.isa == 'dict'
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    try:
        attr = FieldAttribute(isa='dict', default={'key': 'value'})
        assert False
    except TypeError:
        pass
    attr = FieldAttribute(isa='dict', default=lambda: {'key': 'value'})
    assert att

# Generated at 2022-06-11 09:36:14.200319
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test simple constructor
    a = Attribute(isa="string")
    assert a.isa == "string"


# Generated at 2022-06-11 09:36:22.068018
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute('basestring')
    assert attr.isa == 'basestring'

    attr = Attribute(isa='basestring', private=True)
    assert attr.isa == 'basestring'
    assert attr.private

    attr = Attribute(isa='basestring', default=None)
    assert attr.isa == 'basestring'
    assert attr.default == None

    attr = Attribute(isa='basestring', required=True)
    assert attr.isa == 'basestring'
    assert attr.required

    attr = Attribute(isa='list', listof='basestring')
    assert attr.isa == 'list'
    assert attr.listof == 'basestring'


# Generated at 2022-06-11 09:36:25.033132
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='string', alias='foo', always_post_validate=True)
    assert attr.isa == 'string'
    assert attr.alias == 'foo'
    assert attr.always_post_validate == True



# Generated at 2022-06-11 09:36:32.641260
# Unit test for constructor of class Attribute
def test_Attribute():
    attr1 = Attribute(isa='list', private=True, default=['a'], required=True, listof='int', priority=1, class_type=int, always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=True)

    # test equality with __ne__
    attr2 = Attribute(isa='list', private=True, default=['a'], required=True, listof='int', priority=1, class_type=int, always_post_validate=True, inherit=True, alias='alias', extend=True, prepend=True, static=True)
    assert not attr1 != attr2

    # test inequality with __ne__

# Generated at 2022-06-11 09:36:36.478966
# Unit test for constructor of class Attribute
def test_Attribute():
    my_attribute = Attribute(isa='dict', default=lambda: {}, priority=1, prepend=False)
    assert my_attribute.isa == 'dict' and my_attribute.default == {} and my_attribute.priority == 1 and my_attribute.prepend == False

# Generated at 2022-06-11 09:36:42.213373
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None



# Generated at 2022-06-11 09:36:51.822845
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(
        isa='list',
        default=list,
        required=True,
        listof='int',
        priority=1,
        class_type=list,
        inherit=True,
        alias='test_alias'
    )
    assert a.isa == 'list'
    assert a.default == list
    assert a.required is True
    assert a.listof == 'int'
    assert a.priority == 1
    assert a.class_type == list
    assert a.inherit is True
    assert a.alias == 'test_alias'



# Generated at 2022-06-11 09:36:59.282778
# Unit test for constructor of class Attribute
def test_Attribute():
    f = Attribute()
    assert f.isa == None
    assert f.private == False
    assert f.default == None
    assert f.required == False
    assert f.listof == None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate == False
    assert f.inherit == True
    assert f.alias == None
    assert f.extend == False
    assert f.prepend == False
    assert f.static == False



# Generated at 2022-06-11 09:37:01.179083
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        Attribute(isa='list', default=[])
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 09:37:09.247527
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type == None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None



# Generated at 2022-06-11 09:37:12.737847
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.always_post_validate is False
    assert attribute.class_type is None


# Generated at 2022-06-11 09:37:19.180479
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest

    for attr, value, error in [('private', 5, None), ('required', True, None),
                               ('listof', 'list', None), ('priority', 5, None),
                               ('class_type', None, None),
                               ('always_post_validate', True, None),
                               ('inherit', False, None), ('alias', 'foo', None),
                               ('extend', False, None), ('prepend', False, None),
                               ('static', False, None)]:
        a = FieldAttribute(**{attr: value})

        if error:
            with pytest.raises(TypeError) as e:
                FieldAttribute(**{attr: value})

            assert error in str(e.value)
        else:
            assert getattr(a, attr) == value




# Generated at 2022-06-11 09:37:28.296359
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = 'int'
    private = True
    default = 1
    required = False
    listof = 'int'
    priority = 1
    class_type = 'type'
    always_post_validate = True
    inherit = False
    alias = 'test'
    extend = False
    prepend = False
    static = False

    fa = FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    assert fa.isa == isa
    assert fa.private == private
    assert fa.default == default
    assert fa.required == required
    assert fa.listof == listof
    assert fa.priority == priority
    assert fa.class_type == class_type

# Generated at 2022-06-11 09:37:36.709498
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test default constructor
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    #Test constructor with arguments

# Generated at 2022-06-11 09:37:42.605771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldAttribute = FieldAttribute()
    assert fieldAttribute.isa == None
    assert fieldAttribute.private == False
    assert fieldAttribute.default == None
    assert fieldAttribute.required == False
    assert fieldAttribute.listof == None
    assert fieldAttribute.priority == 0
    assert fieldAttribute.class_type == None
    assert fieldAttribute.always_post_validate == False
    assert fieldAttribute.inherit == True
    assert fieldAttribute.alias == None
    assert fieldAttribute.extend == False
    assert fieldAttribute.prepend == False


# Generated at 2022-06-11 09:37:50.134361
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create an instance of the class FieldAttribute
    attribute = FieldAttribute()
    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False
    assert attribute.static == False

# Generated at 2022-06-11 09:38:03.091955
# Unit test for constructor of class Attribute
def test_Attribute():

    # Check that we throw an error if we try to set a default value
    # to a container. Use a dict to check this.

    errtext = "defaults for FieldAttribute may not be mutable"
    raised = False
    try:
        Attribute(isa="list", default={})
    except TypeError:
        raised = True
    assert raised, "Test did not throw TypeError"

    # Make sure isa works
    errtext = "Attribute 'Attribute' object has no attribute 'anattribute'"
    raised = False
    try:
        class MyClass(object):
            attribute = Attribute(isa=MyClass)
    except AttributeError as e:
        raised = True
        assert e.args[0] == errtext, "Error raised is not %s, but %s" % (errtext, e.args[0])
   

# Generated at 2022-06-11 09:38:05.072335
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(default=1)
    assert attribute.default == 1


# Generated at 2022-06-11 09:38:15.469710
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    a = Attribute()

    assert a is not None
    assert a.required == False
    assert a.private == False
    assert a.default == None
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(required=True)
    assert a.required == True

    a = Attribute(private=True)
    assert a.private == True

    a = Attribute(default="foo")
    assert a.default == "foo"

    a = Attribute(listof="list")
   

# Generated at 2022-06-11 09:38:19.046897
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attrib = FieldAttribute()
    print(attrib)



# Generated at 2022-06-11 09:38:24.596557
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(
        isa = 'int',
        private = False,
        default = 0,
        required = True,
        priority = 0,
        always_post_validate = True,
        inherit = True,
    )
    assert a.isa == "int"
    assert a.private == False
    assert a.default == 0
    assert a.required == True
    assert a.priority == 0
    assert a.always_post_validate == True
    assert a.inherit == True

# Generated at 2022-06-11 09:38:37.418023
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils.vars import isidentifier, camel_dict_to_snake_dict

    def _help_test_isa(isa):
        a = Attribute(isa=isa)
        assert a.isa == isa

    for isa in ['int', 'float', 'bool', 'string', 'dict', 'list', 'set', 'class', 'tuple', 'complex', 'bytes', 'None', Attribute]:
        yield _help_test_isa, isa

    # test that Attribute objects can be instantiated
    # using the synonym Attribute
    def _help_test_isa_synonym(isa):
        a = Attribute(isa=isa)
        assert a.isa == isa


# Generated at 2022-06-11 09:38:45.839952
# Unit test for constructor of class Attribute
def test_Attribute():
    class_definition = Attribute(
        always_post_validate=True,
        default=[1, 2, 3],
        isa='list',
        listof='dict',
        extend=True,
        prepend=True
    )
    assert class_definition.static == False
    assert class_definition.alias == None
    assert class_definition.inherit == True
    assert class_definition.always_post_validate == True
    assert class_definition.class_type == None
    assert class_definition.default == [1, 2, 3]
    assert class_definition.isa == 'list'
    assert class_definition.listof == 'dict'
    assert class_definition.priority == 0
    assert class_definition.private == False
    assert class_definition.extend == True

# Generated at 2022-06-11 09:38:57.717555
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test class constructor of class Attribute
    """
    attribute = Attribute(isa='list')
    assert attribute.isa == 'list'
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False
    assert attribute.static is False

    assert str(attribute) == '<attributes.Attribute isa=list default=None required=False listof=None priority=0 class_type=None always_post_validate=False inherit=True alias=None extend=False prepend=False static=False>'

# Generated at 2022-06-11 09:39:03.838715
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.private                 == False
    assert a.default                 == None
    assert a.required                == False
    assert a.priority                == 0
    assert a.class_type              == None
    assert a.always_post_validate    == False
    assert a.inherit                 == True
    assert a.alias                   == None
    assert a.extend                  == False
    assert a.prepend                 == False


# Generated at 2022-06-11 09:39:13.010066
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='integer', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert(a.isa == 'integer')
    assert(a.private == False)
    assert(a.default == None)
    assert(a.required == False)
    assert(a.listof == None)
    assert(a.priority == 0)
    assert(a.class_type == None)
    assert(a.always_post_validate == False)
    assert(a.inherit == True)
    assert(a.alias == None)
    assert(a.extend == False)

# Generated at 2022-06-11 09:39:23.442314
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', private=True, default=None, required=True, listof=None, priority=0, class_type=None,
                  always_post_validate=False)

    # test private true
    assert a.private is True

    # test isa
    assert a.isa is 'int'

    # test default
    assert a.default is None

    # test required
    assert a.required is True

    # test listof
    assert a.listof is None

    # test priority
    assert a.priority == 0

    # test class_type
    assert a.class_type is None

    # test always_post_validate
    assert a.always_post_validate is False

    # test eq
    b = Attribute(priority=2)
    assert (a == b) is False



# Generated at 2022-06-11 09:39:26.761747
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute(isa='foo').isa == 'foo'
    assert Attribute(isa='foo', default='bar').isa == 'foo'
    assert Attribute(isa='foo', default='bar').default == 'bar'

# Generated at 2022-06-11 09:39:29.466650
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str', private=True, default=255, required=True, priority=0, class_type=None, always_post_validate=False)

# Generated at 2022-06-11 09:39:38.798151
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.playbook.task import Task

    class SomeTask(Task):
        pass

    assert FieldAttribute(isa='list', default=[])
    assert FieldAttribute(isa='int', default=0)
    assert FieldAttribute(isa='str', default='')
    assert FieldAttribute(isa='dict', default={})
    assert FieldAttribute(isa='bool', default=True)
    assert FieldAttribute(isa='bool', default=Task)
    assert FieldAttribute(isa='bool', default=SomeTask)
    assert FieldAttribute(isa='bool', default=SomeTask())



# Generated at 2022-06-11 09:39:40.282098
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()


# Generated at 2022-06-11 09:39:52.573530
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute('str', True, 'no default', True, 'dict',
                                     True, class_type=dict)
    assert field_attribute.isa == 'str'
    assert field_attribute.private == True
    assert field_attribute.default == 'no default'
    assert field_attribute.required == True
    assert field_attribute.listof == 'dict'
    assert field_attribute.priority == True
    assert field_attribute.class_type == dict
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False



# Generated at 2022-06-11 09:39:57.774321
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict',private=True,default=None,required=True,
                     listof=None,priority=0,class_type=None,always_post_validate=False,
                     inherit=True,alias=None)
    for k,v in vars(attr).items():
        print(k,v)

# Generated at 2022-06-11 09:40:04.774023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Really just tests that all of the keyword arguments are actually accepted
    x = FieldAttribute(
        isa='blah',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )



# Generated at 2022-06-11 09:40:15.399598
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='list', required=True)
    assert attr.isa == 'list'
    assert attr.required
    assert attr.inherit
    assert attr.priority == 0
    assert not attr.private
    assert not attr.always_post_validate
    assert not attr.alias

    attr = Attribute(isa='bool', private=True, priority=10)
    assert attr.isa == 'bool'
    assert not attr.required
    assert attr.inherit
    assert attr.private
    assert attr.priority == 10
    assert not attr.always_post_validate
    assert not attr.alias

    attr = Attribute(isa='str', private=True, required=True, priority=0)

# Generated at 2022-06-11 09:40:24.960863
# Unit test for constructor of class Attribute
def test_Attribute():
    # Check default value of constructor
    a = Attribute(isa = "int")
    assert a.isa == "int"
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:40:34.177034
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None, \
        priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False

# Generated at 2022-06-11 09:40:39.170883
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

# Generated at 2022-06-11 09:40:46.704963
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=1, required=True)
    assert issubclass(attr.isa, int)
    assert attr.private is False
    assert attr.default == 1
    assert attr.required is True
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False



# Generated at 2022-06-11 09:40:57.980320
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().isa == None
    assert FieldAttribute().private == False
    assert FieldAttribute().default == None
    assert FieldAttribute().required == False
    assert FieldAttribute().listof == None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type == None
    assert FieldAttribute().always_post_validate == False
    assert FieldAttribute().inherit == True
    assert FieldAttribute().alias == None
    assert FieldAttribute().extend == False
    assert FieldAttribute().static == False



# Generated at 2022-06-11 09:41:04.161428
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr = Attribute(isa='list')
    attr = Attribute(listof='set')

    code = "attr = Attribute(default='foo')"
    assert Attribute(default='foo')
    try:
        eval(code)
    except TypeError:
        assert True, 'Attribute() raises TypeError for mutable default'
    else:
        assert False, 'Attribute() allows mutable default'



# Generated at 2022-06-11 09:41:05.644195
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute('str', static=True, default='foo', extend=True)

# Generated at 2022-06-11 09:41:12.900298
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute("set", required=True)
    assert a.isa == "set"
    assert a.required == True

    b = Attribute("str", required=True)
    assert b.isa == "str"
    assert b.required == True

    c = Attribute("int", required=True)
    assert c.isa == "int"
    assert c.required == True

    d = Attribute(isa="dict", listof="str", required=True)
    assert d.isa == "dict"
    assert d.listof == "str"
    assert d.required == True

# Generated at 2022-06-11 09:41:21.534902
# Unit test for constructor of class Attribute
def test_Attribute():
    #Test initializing a valid Attribute
    test_attr = Attribute(isa='str')
    assert test_attr.isa == 'str'

    #Test initializing an Attribute with an unsupported type
    bad_attr = Attribute(isa='foo')
    assert bad_attr.isa == 'foo'

    #Test initializing a mutable default
    bad_attr = Attribute(isa='list', default=[])
    assert bad_attr.isa == 'list'

    #Test initializing a callable default
    assert_attr = Attribute(isa='list', default=list)
    assert assert_attr.isa == 'list'
    assert callable(assert_attr.default)

# Generated at 2022-06-11 09:41:26.343137
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:41:30.154622
# Unit test for constructor of class Attribute
def test_Attribute():
    t = Attribute(isa='list', default=dict)
    assert t.isa == 'list'
    assert t.default() == dict()
    assert t.required is False
    assert t.listof is None
    assert t.priority == 0

# Generated at 2022-06-11 09:41:42.119532
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Base():
        pass

    x = FieldAttribute(isa='class', default=Base)
    assert x.isa == 'class'
    assert x.default == Base
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True

    # Test that an exception is raised when the default value is a mutable datatype
    try:        
        x = FieldAttribute(isa='list', default=list)
        assert x.isa == 'list'
        raise AssertionError('Default value is mutable datatype, but no exception was raised')
    except TypeError:
        pass


# Generated at 2022-06-11 09:41:43.397885
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test_attribute = FieldAttribute(isa='str', default='my_default', required=True)
    assert test_attribute.isa == 'str'
    assert test_attribute.default == 'my_default'
    assert test_attribute.required == True



# Generated at 2022-06-11 09:41:47.354375
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute(isa='bool', private=True, default=False, required=True, listof=None,
                   priority=9, class_type=None, always_post_validate=True, inherit=True,
                   alias=None, extend=False, prepend=False)


# Generated at 2022-06-11 09:41:59.723243
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute('test')
    assert field.isa == 'test'

# Generated at 2022-06-11 09:42:05.077545
# Unit test for constructor of class Attribute
def test_Attribute():

    # isa is None and default is None
    a = Attribute()

    # isa is not None and default is not None
    a = Attribute(isa='dict', default={})

    # isa is None and default is not None
    a = Attribute(default={})



# Generated at 2022-06-11 09:42:15.361503
# Unit test for constructor of class Attribute
def test_Attribute():
    import collections

    # Type specified
    attr = Attribute(isa='bool')
    assert attr.isa == bool

    # Type as class
    class FooClass():
        pass

    attr = Attribute(isa=FooClass)
    assert attr.isa == FooClass

    # Type as class name
    attr = Attribute(isa='builtins.dict')
    assert attr.isa == dict

    # isa cannot be anything other than a type or a string type
    def _attr():
        Attribute(isa=['list'])

    def _attr2():
        Attribute(isa=collections.defaultdict)

    def _attr3():
        Attribute(isa=True)

    def _attr4():
        Attribute(isa=None)

    assert_raises(TypeError, _attr)
   

# Generated at 2022-06-11 09:42:24.879802
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(isa='str')

    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    a = Attribute(isa='str', alias='foo')

    assert a.alias == 'foo'



# Generated at 2022-06-11 09:42:27.680917
# Unit test for constructor of class Attribute
def test_Attribute():
    new_attribute = Attribute(isa='int', default=True, private=True)
    assert (new_attribute.isa == 'int' and new_attribute.default == True and new_attribute.private == True)

# Generated at 2022-06-11 09:42:37.722594
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test equality operators
    a = FieldAttribute()
    b = FieldAttribute()
    assert a == b
    assert not a != b
    a.priority = 1
    assert a != b
    assert not a == b
    assert a > b
    assert a >= b
    assert b < a
    assert b <= a

    # Test exceptions raised by FieldAttribute constructor
    try:
        FieldAttribute(default=[1, 2, 3])
        assert False
    except TypeError:
        pass
    try:
        FieldAttribute(default={1: 1, 2: 2, 3: 3})
        assert False
    except TypeError:
        pass
    try:
        FieldAttribute(default={1, 2, 3})
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 09:42:43.138095
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='str', private=True, default='str_default', required=True,
        listof='str', priority=0, class_type='str', always_post_validate=True,
        inherit=True, alias='f', extend=True, prepend=True, static=True)
    assert f.isa == 'str'
    assert f.private == True
    assert f.default == 'str_default'
    assert f.required == True
    assert f.listof == 'str'
    assert f.priority == 0
    assert f.class_type == 'str'
    assert f.always_post_validate == True
    assert f.inherit == True
    assert f.alias == 'f'
    assert f.extend == True
    assert f.prepend == True
    assert f.static

# Generated at 2022-06-11 09:42:51.658239
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    att = FieldAttribute(
        isa=' str ',
        default=' abc ',
        required=True,
        always_post_validate=True,
        inherit=False,
        alias='def',
    )
    assert att.isa == 'str'
    assert att.default == 'abc'
    assert att.required is True
    assert att.always_post_validate is True
    assert att.inherit is False
    assert att.alias == 'def'
    # Private is False by default
    assert att.private is False

# Generated at 2022-06-11 09:43:01.044238
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.datetime import AnsibleDateTime
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # A simple test: trivial instantiation
    a = Attribute()

    # Test use of default values
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    # A more complex test: instantiation from keywords

# Generated at 2022-06-11 09:43:08.065086
# Unit test for constructor of class Attribute
def test_Attribute():
    atr_obj = Attribute()
    assert atr_obj.isa == None
    assert atr_obj.private == False
    assert atr_obj.default == None
    assert atr_obj.required == False
    assert atr_obj.listof == None
    assert atr_obj.priority == 0
    assert atr_obj.class_type == None
    assert atr_obj.always_post_validate == False
    assert atr_obj.inherit == True
    assert atr_obj.alias == None
    assert atr_obj.extend == False
    assert atr_obj.prepend == False
    assert atr_obj.static == False


# Generated at 2022-06-11 09:43:47.503712
# Unit test for constructor of class Attribute
def test_Attribute():

    # isa = None
    attr = Attribute()
    assert attr.isa == None, "Default value of isa is not None"

    # isa = "list"
    attr = Attribute(isa="list")
    assert attr.isa == "list", "Value of isa is not list"

    # isa = ["list"], listof = "dict"
    attr = Attribute(isa = "list", listof = "dict")
    assert attr.isa == "list" and attr.listof == "dict", "Values of isa and listof are not list and dict"

    # class_type = None
    attr = Attribute(class_type = None)
    assert attr.class_type == None, "Default value of class_type is not None"

    # class_type = MyClass()

# Generated at 2022-06-11 09:43:56.901788
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa='string',
                     private=True,
                     default=None,
                     required=True,
                     listof=None,
                     priority=0,
                     class_type=None,
                     always_post_validate=False,
                     inherit=True,
                     alias=None,
                     extend=False,
                     prepend=False,
                     static=False)
    assert attr.isa == 'string'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr

# Generated at 2022-06-11 09:44:06.949230
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa="str")
    assert a.isa == "str"
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None

    a = FieldAttribute(isa="str", default="tester")
    assert a.isa == "str"
    assert a.default == "tester"
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None

    a = FieldAttribute(isa="str", default="tester", class_type="SomeClass")
    assert a.isa == "str"
    assert a.default == None # Default is ignored when a class_type is provided
    assert a.required == False
    assert a

# Generated at 2022-06-11 09:44:16.284009
# Unit test for constructor of class Attribute
def test_Attribute():

    # test init
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute(default=None, inherit=False).inherit is False
    assert Attribute(default=None, inherit=True).inherit is True

    # test __eq__
    assert Attribute(priority=0) == Attribute(priority=0)

    # test __ne__
    assert Attribute(priority=0) != Attribute(priority=3)

    # test __lt__

# Generated at 2022-06-11 09:44:22.983446
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute1 = Attribute()

    assert attribute1.isa == None
    assert attribute1.private == False
    assert attribute1.default == None
    assert attribute1.required == False
    assert attribute1.listof == None
    assert attribute1.priority == 0
    assert attribute1.class_type == None
    assert attribute1.always_post_validate == False
    assert attribute1.inherit == True
    assert attribute1.alias == None

# Generated at 2022-06-11 09:44:34.060024
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None

    assert Attribute(isa='bool').isa == 'bool'
    assert Attribute(isa='int').isa == 'int'
    assert Attribute(isa='float').isa == 'float'
    assert Attribute(isa='dict').isa == 'dict'
    assert Attribute(isa='list').isa == 'list'
    assert Attribute(isa='set').isa == 'set'

# Generated at 2022-06-11 09:44:43.397977
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    attribute2 = Attribute(isa='list', default=list(), required=False, listof='string',
                           priority=1, class_type='list', always_post_validate=False,
                           inherit=True, alias='list', extend=False, prepend=False,
                           static=False)
    assert isinstance(attribute, Attribute)
    assert isinstance(attribute2, Attribute)
    try:
        Attribute(isa='list', default=list())
        assert False
    except TypeError:
        assert True
    try:
        Attribute(isa='list', default=None, required=True)
        assert False
    except TypeError:
        assert True
    assert attribute.required is False
    assert attribute2.required is False
    assert attribute2.isa is 'list'
   

# Generated at 2022-06-11 09:44:48.794394
# Unit test for constructor of class Attribute
def test_Attribute():
    # Boolean default value
    assert Attribute(default=True).default is True
    assert Attribute(default=False).default is False

    # Boolean, string and int can be passed as defaults without change
    assert Attribute(default=True, isa='boolean').default is True
    assert Attribute(default=True, isa='string').default is True
    assert Attribute(default=True, isa='int').default is True

    # List can not be passed as a default value without change
    try:
        Attribute(default=[], isa='list')
    except TypeError as e:
        assert(e.message == 'defaults for FieldAttribute may not be mutable, please provide a callable instead')
    else:
        raise AssertionError('Expected TypeError from Attribute()')

    # We can't pass the list object type

# Generated at 2022-06-11 09:44:59.128495
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Define some defaults
    keyword = 'default'
    value = 'value'
    boolean = True

    # Create an instance with keyword
    attr = FieldAttribute(keyword=value)

    assert keyword not in attr.__dict__
    assert value == attr.keyword

    # Attribute error, keyword does not exist

# Generated at 2022-06-11 09:45:04.238309
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa='list',
        private=False,
        default=[1,2,3],
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attribute != None
