

# Generated at 2022-06-11 09:36:08.113645
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import Mapping, MutableMapping

    def valid_attr_test(attr_name, args, kwargs, error_msg=''):
        attr = Attribute(*args, **kwargs)
        assert attr.__dict__[attr_name] == kwargs[attr_name]

    def invalid_attr_test(attr_name, args, kwargs, error_msg=''):
        try:
            attr = Attribute(*args, **kwargs)
        except TypeError as e:
            return
        print("Expecting 'TypeError' exception, but got no exception")

    valid_attr_test('isa', [], {'isa': bool})
    valid_attr_test('isa', [], {'isa': int})
    valid_attr_test('isa', [], {'isa': float})


# Generated at 2022-06-11 09:36:09.808043
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Unit test for constructor Attribute
    '''
    a = Attribute()
    assert isinstance(a,Attribute)

# Generated at 2022-06-11 09:36:13.493483
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='foo',
                        private=True,
                        required=True,
                        default='bar',
                        listof='baz')
    assert fa.isa == 'foo'
    assert fa.private == True
    assert fa.required == True
    assert fa.default == 'bar'
    assert fa.listof == 'baz'
    return


# Generated at 2022-06-11 09:36:19.318409
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test constructor with only required parameter
    assert Attribute('list', priority=0).isa == 'list'

    # Test constructor with all options in alphabetical order
    a = Attribute(
        alias="alias",
        always_post_validate=True,
        class_type=dict,
        default="default",
        inherit=False,
        isa="isa",
        listof="listof",
        prepend=True,
        private=True,
        priority=0,
        extend=True,
        required=True,
        static=True,
    )

    assert a.alias == "alias"
    assert a.always_post_validate
    assert a.class_type == dict
    assert a.default == "default"
    assert not a.inherit
    assert a.isa == "isa"

# Generated at 2022-06-11 09:36:27.139157
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create a new instance of class FieldAttribute with isa = int
    attr = FieldAttribute(isa=int)
    # Test if isa is set correctly
    assert attr.isa == int
    # Test if default value is set correctly
    assert attr.default is None
    # Test if required is set correctly
    assert attr.required == False
    # Test if listof is set correctly
    assert attr.listof is None
    # Test if priority is set correctly
    assert attr.priority == 0
    # Test if class_type is set correctly
    assert attr.class_type is None
    # Test if always_post_validate is set correctly
    assert attr.always_post_validate == False
    # Test if inherit is set correctly
    assert attr.inherit == True
    # Test if alias is set

# Generated at 2022-06-11 09:36:33.001270
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    foo_attribute = FieldAttribute()
    assert foo_attribute.isa == None
    assert foo_attribute.default == None
    assert foo_attribute.required != True
    assert foo_attribute.listof == None
    assert foo_attribute.priority == 0
    assert foo_attribute.class_type == None
    assert foo_attribute.inherit != False
    assert foo_attribute.alias == None
    assert foo_attribute.extend != True
    assert foo_attribute.prepend != True
    assert foo_attribute.static != True



# Generated at 2022-06-11 09:36:43.998816
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.vars import AnsibleVars
    f = FieldAttribute()
    assert isinstance(f, Attribute)
    assert type(f.isa) == type(None)
    assert f.private == False
    assert type(f.default) == type(None)
    assert f.required == False
    assert type(f.listof) == type(None)
    assert f.priority == 0
    assert type(f.class_type) == type(None)
    assert f.always_post_validate == False
    assert f.inherit == True
    assert type(f.alias) == type(None)

    assert f.extend == False
    assert f.prepend == False
    assert f.static == False

    f = FieldAttribute(isa="int")

# Generated at 2022-06-11 09:36:56.793380
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute(
        isa=1,
        private=False,
        default=1,
        required=False,
        listof=list(),
        priority=0,
        class_type=list(),
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=False,
        prepend=False,
    )
    # Testing FieldAttribute constructor
    assert attribute.isa == 1
    assert attribute.private == False
    assert attribute.default == 1
    assert attribute.required == False
    assert attribute.listof == list()
    assert attribute.priority == 0
    assert attribute.class_type == list()
    assert attribute.always_post_validate == True
    assert attribute.inherit == True
    assert attribute.alias == 'alias'
    assert attribute.extend

# Generated at 2022-06-11 09:37:01.979009
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    args = {
        'isa': 'int',
        'private': True,
        'default': 0,
        'required': True,
        'listof': None,
        'priority': 5,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    FieldAttribute(**args)


# Generated at 2022-06-11 09:37:09.962959
# Unit test for constructor of class Attribute
def test_Attribute():

    class test_t(Attribute):
        isa = "int"
        private = True
        default = 2
        required = True
        listof = "test_t"
        priority = 2
        inherit = True
        alias = None
        static = False

    result = test_t()
    expect = Attribute(isa="int", private=True, default=2, required=True, listof="test_t",
        priority=2, inherit=True, alias=None, static=False)

    assert result == expect



# Generated at 2022-06-11 09:37:19.027558
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert isinstance(attr, Attribute)

    attr = Attribute(isa='int')
    assert isinstance(attr, Attribute)
    assert attr.isa == 'int'

    attr = FieldAttribute(required=True, default=5)
    assert isinstance(attr, FieldAttribute)
    assert attr.required
    assert attr.default == 5

    attr = FieldAttribute(listof='bool')
    assert isinstance(attr, FieldAttribute)
    assert attr.listof == 'bool'

    attr = FieldAttribute(isa='bool')
    assert isinstance(attr, FieldAttribute)
    assert attr.isa == 'bool'

    attr = FieldAttribute(priority=9)
    assert isinstance(attr, FieldAttribute)
    assert attr.priority == 9

   

# Generated at 2022-06-11 09:37:26.067949
# Unit test for constructor of class Attribute
def test_Attribute():

    # test order of parameters
    attr = Attribute(isa="dict", default=False, private=True, required=False)

    assert attr.isa == "dict"
    assert attr.default == False
    assert attr.private == True
    assert attr.required == False

    # test order of parameters
    attr = FieldAttribute(isa="dict", default=False, private=True, required=False, class_type="my_class")

    assert attr.isa == "dict"
    assert attr.default == False
    assert attr.private == True
    assert attr.required == False
    assert attr.class_type == "my_class"

# Generated at 2022-06-11 09:37:28.548087
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', static=True)
    assert attr.isa == 'list'
    assert attr.static == True

# Generated at 2022-06-11 09:37:36.870346
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().class_type is None
    assert Attribute().always_post_validate is False
    assert Attribute().inherit is True
    assert Attribute().alias is None
    assert Attribute().extend is False
    assert Attribute().prepend is False
    assert Attribute().static is False
    default = Attribute(default='x')
    assert default.default == 'x'
    #assert Attribute(default=['x']).default == ['x']
    #assert Attribute(default={'x':'y'}).default == {'x':'y'}

# Unit test

# Generated at 2022-06-11 09:37:45.901722
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

#__init__(  self,
#            isa=None,
#            private=False,
#            default=None,
#            required=False,
#            listof=None,
#            priority=0,
#            class_type=None,
#            always_post_validate=False,
#            inherit=True,
#            alias=None,
#            extend=False,
#            prepend=False

# Generated at 2022-06-11 09:37:52.108507
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr1 = FieldAttribute()
    assert attr1.isa == None
    assert attr1.private == False
    assert attr1.default == None
    assert attr1.required == False
    assert attr1.listof == None
    assert attr1.priority == 0
    assert attr1.class_type == None
    assert attr1.always_post_validate == False

    attr2 = FieldAttribute(isa=int, private=True, default=1, required=True, listof=list, priority=2, always_post_validate=True)
    assert attr2.isa == int
    assert attr2.private == True
    assert attr2.default == 1
    assert attr2.required == True
    assert attr2.listof == list

# Generated at 2022-06-11 09:38:05.254690
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'test'
    private = False
    default = 'test'
    required = True
    listof = 'test'
    priority = 0
    class_type = 'test'
    always_post_validate = True
    inherit = False
    alias = 'test'
    extend = True
    prepend = True
    static = True

    a = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    assert a.isa == isa
    assert a.private == private
    assert a.default == default
    assert a.required == required
    assert a.listof == listof
    assert a.priority == priority
    assert a.class_type == class_type
    assert a.always_post_valid

# Generated at 2022-06-11 09:38:06.576087
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert isinstance(f, FieldAttribute)



# Generated at 2022-06-11 09:38:08.739609
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    my_attr = FieldAttribute()
    print(my_attr.isa)
    assert my_attr.isa is False



# Generated at 2022-06-11 09:38:19.230772
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa='list',
        class_type=['a', 'b', 'c'],
        required=True,
        alias='example'
    )

    if not attr.isa == 'list':
        raise TypeError('init fail.')
    if not attr.private == False:
        raise TypeError('init fail.')
    if not attr.default == None:
        raise TypeError('init fail.')
    if not attr.required == True:
        raise TypeError('init fail.')
    if not attr.listof == None:
        raise TypeError('init fail.')
    if not attr.priority == 0:
        raise TypeError('init fail.')
    if not attr.class_type == ['a', 'b', 'c']:
        raise TypeError

# Generated at 2022-06-11 09:38:31.845680
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # testing out the constructor
    x = FieldAttribute(isa='str', private=True, default='no', required=True,
                       listof='str', priority=0, class_type=None,
                       always_post_validate=False, inherit=False, alias=None,
                       extend=False, prepend=False)
    print(x.__dict__)
    assert x.isa == 'str'
    assert x.private is True
    assert x.default == 'no'
    assert x.required is True
    assert x.listof == 'str'
    assert x.priority == 0
    assert x.class_type is None
    assert x.always_post_validate is False
    assert x.inherit is False
    assert x.alias is None
    assert x.extend is False

# Generated at 2022-06-11 09:38:33.822589
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='int', default=1, required=True)


# Generated at 2022-06-11 09:38:44.050233
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)
    # check for invalid isa
    try:
        attr1 = FieldAttribute(isa=123456)
        raise AssertionError('isa have to be a string, class or None')
    except TypeError as e:
        print(e)

    # check for invalid private attribute
    try:
        attr2 = FieldAttribute(private='string')
        raise AssertionError('private have to be a boolean')
    except TypeError as e:
        print(e)

    # check for invalid default attribute

# Generated at 2022-06-11 09:38:45.598560
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute(default=[], isa='list')

# Generated at 2022-06-11 09:38:57.557169
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert not attribute.private
    assert attribute.default is None
    assert not attribute.required
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert not attribute.always_post_validate
    assert attribute.inherit
    assert attribute.alias is None

    attribute = Attribute(isa='foo', private=True, default='bar', required=True, listof='foo', priority=1,
                          class_type='foo', always_post_validate=True, inherit=False, alias='baz')
    assert attribute.isa == 'foo'
    assert attribute.private
    assert attribute.default == 'bar'
    assert attribute.required
    assert attribute.listof == 'foo'
    assert attribute.priority

# Generated at 2022-06-11 09:39:00.528011
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa='str')
    Attribute(isa='str', class_type=str)
    Attribute(isa='str', class_type=str, listof='str')

# Generated at 2022-06-11 09:39:01.531125
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa

# Generated at 2022-06-11 09:39:11.360461
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play_ds = dict(
        name = "Ansible Play",
        hosts = 'c86-rhel-vmm',
        tasks = [
            dict(action=dict(module='copy', args='src=file1 dest=file2'), register='copy1'),
            dict(action=dict(module='copy', args='src=file1 dest=file2'), register='copy2'),
        ]
    )

# Generated at 2022-06-11 09:39:17.833368
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa=list)

    field = Attribute(isa=list, default=[])
    assert isinstance(field.default, list)
    assert field.default == []

    field = Attribute(isa=list, default=lambda: [])
    assert isinstance(field.default, type(lambda: []))
    assert field.default() == []

    try:
        field = Attribute(isa=list, default=[1])
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute constructor did not raise TypeError with mutable default')

# Generated at 2022-06-11 09:39:28.444707
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def check_field_attribute(good_data, attrs):
        for k, v in good_data.items():
            if v is not True:
                good_data[k] = attrs.get(k, None)
        fa = FieldAttribute(**good_data)
        for k, v in attrs.items():
            assert getattr(fa, k) == v

    good_data = {
        'private': True,
        'default': 'a default value',
        'required': True,
        'listof': 'a listof value',
        'priority': 5,
        'class_type': 'type',
        'inherit': True,
        'alias': 'alias',
        'extend': True,
        'prepend': True,
        'static': True,
    }


# Generated at 2022-06-11 09:39:41.633908
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test constructor
    a = Attribute()
    assert isinstance(a, Attribute)

    # Test default values constructor
    a = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None,
                  always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert isinstance(a, Attribute)

    a = Attribute(isa='bool', private=False, default=None, required=False, listof=None, priority=0, class_type=None,
                  always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert isinstance(a, Attribute)

# Generated at 2022-06-11 09:39:42.865277
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a1 = FieldAttribute()


# Generated at 2022-06-11 09:39:45.581702
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError):
        Attribute(default=[]).default
    Attribute(default=lambda: []).default == []

# Generated at 2022-06-11 09:39:56.107998
# Unit test for constructor of class Attribute
def test_Attribute():
    # Optionally validates a YAML document containing the specified field at
    # post-validation time as a list containing only instances of the
    # specified class.
    #
    # For example:
    #
    # attr = FieldAttribute(isa='list', listof=class_name)
    #
    # NOTE: The isa value should be "list".

    # Tests
    attr = FieldAttribute(isa='list', listof=list)
    assert attr.isa == 'list'
    assert attr.listof == list

    attr = FieldAttribute(isa='int', default=42)
    assert attr.isa == 'int'
    assert attr.required is False
    assert attr.default == 42

    attr = FieldAttribute(isa='int', default=42, required=True)
    assert attr

# Generated at 2022-06-11 09:40:07.232387
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import sys
    import unittest

    class TestFieldAttribute(unittest.TestCase):
        """ Tests for FieldAttribute """

        def test_basic(self):
            a = Attribute(isa='list')
            assert a.isa == 'list'

        def test_default_not_mutable(self):
            mutable_value = []
            with self.assertRaises(TypeError):
                Attribute(isa='list', default=mutable_value)

            with self.assertRaises(TypeError):
                Attribute(isa='list', default=set(mutable_value))

            with self.assertRaises(TypeError):
                Attribute(isa='list', default=dict(foo='bar'))

        def test_default_is_mutable(self):
            value = []

# Generated at 2022-06-11 09:40:14.710376
# Unit test for constructor of class Attribute
def test_Attribute():
    import ansible.module_utils.six as six
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False


# Generated at 2022-06-11 09:40:21.589632
# Unit test for constructor of class Attribute
def test_Attribute():
    """ Attribute class should check the default value for
    list and dict type """
    try:
        Attribute(default=[])
    except TypeError as e:
        assert type(e) is TypeError, 'test_Attribute() failed'
    try:
        Attribute(default={})
    except TypeError as e:
        assert type(e) is TypeError, 'test_Attribute() failed'
    try:
        Attribute(default=set())
    except TypeError as e:
        assert type(e) is TypeError, 'test_Attribute() failed'


# Generated at 2022-06-11 09:40:30.962589
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute()
    assert attr.isa is None
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-11 09:40:38.505005
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)
    assert attr.isa is 1
    assert attr.private is 2
    assert attr.default is 3
    assert attr.required is 4
    assert attr.listof is 5
    assert attr.priority is 6
    assert attr.class_type is 7
    assert attr.always_post_validate is 8
    assert attr.inherit is 9
    assert attr.alias is 10
    assert attr.extend is 11
    assert attr.prepend is False



# Generated at 2022-06-11 09:40:48.071206
# Unit test for constructor of class Attribute
def test_Attribute():
    import types

    # setting default values should work
    args = dict(required=True, always_post_validate=True, inherit=True)
    obj = Attribute(**args)
    assert obj.required == True, "must be true but found %s" % obj.required
    assert obj.always_post_validate, "must be true but found %s" % obj.always_post_validate
    assert obj.inherit == True, "must be true but found %s" % obj.inherit

    # setting isa, listof, and class_type should be the same type
    for i in ('isa', 'listof', 'class_type'):
        for j in ('isa', 'listof', 'class_type'):
            if i == j:
                continue

# Generated at 2022-06-11 09:41:01.593610
# Unit test for constructor of class Attribute
def test_Attribute():
    fields = Attribute(
        isa         = 'None',
        required    = True,
        default     = 3,
        listof      = 'int',
        class_type  = 'dict',
        always_post_validate = True,
        priority    = 1,
        inherit     = False,
    )
    assert fields.isa == 'None'
    assert fields.required
    assert fields.default == 3
    assert fields.listof == 'int'
    assert fields.class_type == 'dict'
    assert fields.always_post_validate
    assert fields.priority == 1
    assert fields.inherit == False

# Generated at 2022-06-11 09:41:12.057153
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test the expected constructor
    test_instance = Attribute(
        isa='bool',
        private=False,
        default=True,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
    )

    # test the setters and getters of the instance
    assert test_instance.isa == 'bool'
    assert test_instance.private == False
    assert test_instance.default == True
    assert test_instance.required == False
    assert test_instance.listof == None
    assert test_instance.priority == 0
    assert test_instance.class_type == None
    assert test_instance.always_post_validate == False

    # test the expected constructor when wrong type is given

# Generated at 2022-06-11 09:41:22.249575
# Unit test for constructor of class Attribute

# Generated at 2022-06-11 09:41:26.758969
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(required=False)
    attr = Attribute(required=True)
    attr = Attribute(private=False)
    attr = Attribute(private=True)
    # If we can't call the constructor without getting an error, we're good.
    # If an error occurs, we fail the test.


# Generated at 2022-06-11 09:41:30.715235
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Negative testing with isa argument
    try:
        field_attribute = FieldAttribute(isa='list', default=['a', 'b'])
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 09:41:43.132912
# Unit test for constructor of class Attribute
def test_Attribute():
    class TestObject(object):
        pass
    # Test defaults
    default_attr = Attribute()
    assert default_attr.private == False
    assert default_attr.default == None
    assert default_attr.required == False
    assert default_attr.listof == None
    assert default_attr.priority == 0
    assert default_attr.class_type == None
    assert default_attr.always_post_validate == False
    assert default_attr.inherit == True
    assert default_attr.alias == None
    assert default_attr.extend == False
    assert default_attr.static == False

    # Test valid attribute init

# Generated at 2022-06-11 09:41:52.464836
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    attr = Attribute(1,2,3,4,5,6,7,8,9,10,11,12,13)
    assert attr.isa == 1
    assert attr.private == 2
    assert attr.default == 3
    assert attr.required == 4
   

# Generated at 2022-06-11 09:41:55.975698
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=['a', 'b', 'c'], required=False)
    assert a.isa == 'list'
    assert a.default == ['a', 'b', 'c']
    assert a.required == False



# Generated at 2022-06-11 09:42:08.189702
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='dict',
        private=False,
        default=None,
        required=False,
        listof='dict',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )

    assert fa.isa == 'dict'
    assert fa.private == False
    assert fa.default is None
    assert fa.required == False
    assert fa.listof == 'dict'
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias is None
    assert fa.extend == False

# Generated at 2022-06-11 09:42:12.110518
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # assert field_attribute.priority == 0
    # assert field_attribute.isa == 'basestring'
    # assert field_attribute.required == False
    # assert field_attribute.private == False
    field_attribute = FieldAttribute()
    assert field_attribute


# Generated at 2022-06-11 09:42:32.299304
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for the most basic initialization
    a1 = Attribute()
    assert a1.isa is None
    assert not a1.private
    assert a1.default is None
    assert not a1.required
    assert a1.listof is None
    assert a1.priority == 0
    assert a1.class_type is None
    assert not a1.always_post_validate
    assert a1.inherit
    assert a1.alias is None
    assert not a1.extend
    assert not a1.prepend
    assert not a1.static

    # Test for private=True
    a2 = Attribute(private=True)
    assert a2.private

    # Test for isa=list
    a3 = Attribute(isa='list')
    assert a3.isa == 'list'

    #

# Generated at 2022-06-11 09:42:33.520418
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    del a


# Generated at 2022-06-11 09:42:36.420386
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(attribute1='foo', attribute2='bar')
    assert attr.attribute1 == 'foo'
    assert attr.attribute2 == 'bar'


# Generated at 2022-06-11 09:42:42.210000
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a1 = FieldAttribute(isa="list", default=None)
    assert a1.isa == "list"
    assert a1.default == None
    assert a1.private == False
    assert a1.required == False
    assert a1.listof == None
    assert a1.priority == 0
    assert a1.class_type == None
    assert a1.always_post_validate == False
    assert a1.inherit == True
    assert a1.alias == None


# Generated at 2022-06-11 09:42:53.663723
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='string', private=True, default='a', required=True,
        listof='list', priority=0, class_type='class', always_post_validate=False,
        inherit=True, alias='alias')
    if attr.isa != 'string':
        raise AssertionError('fail to set isa attribute')
    if attr.private != True:
        raise AssertionError('fail to set private attribute')
    if not isinstance(attr.default, str):
        raise AssertionError('fail to set default attribute')
    if not isinstance(attr.listof, str):
        raise AssertionError('fail to set listof attribute')
    if attr.priority != 0:
        raise AssertionError('fail to set priority attribute')

# Generated at 2022-06-11 09:43:02.860324
# Unit test for constructor of class Attribute
def test_Attribute():
    att1 = Attribute(
        isa = 'boolean',
        private = False,
        default = True,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )

# Generated at 2022-06-11 09:43:10.055312
# Unit test for constructor of class Attribute
def test_Attribute():
    print("\n-----------------------------")
    print("Attribute test")

    print("\nTesting initialization of Attribute class with default values")
    default_test = Attribute()
    print(default_test)

    print("\nTesting initialization of Attributes class with custom values")
    custom_test = Attribute(
        default=True,
        required=True,
        isa='bool',
        inherit=True,
        always_post_validate=True
    )
    print(custom_test)

    print("\nTesting the comparison operator of Attributes class")
    print("default_test > custom_test")
    print(default_test > custom_test)
    print("default_test < custom_test")
    print(default_test < custom_test)
    print("default_test >= custom_test")

# Generated at 2022-06-11 09:43:20.049440
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert(field.isa == None)
    assert(field.private == False)
    assert(field.default == None)
    assert(field.required == False)
    assert(field.listof == None)
    assert(field.priority == 0)
    assert(field.class_type == None)
    assert(field.always_post_validate == False)
    assert(field.inherit == True)
    assert(field.alias == None)
    assert(field.extend == False)
    assert(field.prepend == False)
    assert(field.static == False)



# Generated at 2022-06-11 09:43:28.832981
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute(priority=100)
    a4 = Attribute(priority=100)
    a5 = Attribute(priority=101)
    a6 = Attribute(priority=101)

    assert(a1 == a2)
    assert(a3 == a4)
    assert(a5 == a6)
    assert(not (a1 == a3))
    assert(not (a1 == a4))
    assert(not (a2 == a3))
    assert(not (a2 == a4))

    assert(a1 != a3)
    assert(a1 != a4)
    assert(a2 != a3)
    assert(a2 != a4)
    assert(not (a3 != a4))

# Generated at 2022-06-11 09:43:37.797726
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # default parameters are set correctly
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True

    # non-dafult parameters are set correctly
    fa = FieldAttribute(isa='string')
    assert fa.isa == 'string'

    fa = FieldAttribute(private=True)
    assert fa.private is True

    fa = FieldAttribute(default=3)
    assert fa.default == 3

    fa = FieldAttribute(required=True)
    assert fa.required is True

    fa = FieldAttribute(listof = 'string')

# Generated at 2022-06-11 09:44:04.476312
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(1) == Attribute(1)
    assert Attribute(2) != Attribute(1)
    assert Attribute(1) < Attribute(2)
    assert Attribute(2) > Attribute(1)
    assert Attribute(1) <= Attribute(2)
    assert Attribute(2) >= Attribute(1)

# Generated at 2022-06-11 09:44:08.665267
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)

# Additional test to see if there is an error when default value is mutable and not callable

# Generated at 2022-06-11 09:44:17.607265
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    # isa is None
    assert f.isa == None
    # private is False
    assert f.private == False
    # default is None
    assert f.default == None
    # required is False
    assert f.required == False
    # listof is None
    assert f.listof == None
    # priority is 0
    assert f.priority == 0
    # class_type is None
    assert f.class_type == None
    # always_post_validate is False
    assert f.always_post_validate == False
    # inherit is True
    assert f.inherit == True
    # alias is None
    assert f.alias == None
    # extend is False
    assert f.extend == False
    # prepend is False
    assert f.prepend == False
    #

# Generated at 2022-06-11 09:44:29.420375
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa=None
    private=False
    default=None
    required=False
    listof=None
    priority=0
    class_type=None
    always_post_validate=False
    inherit=True
    alias=None
    attribute=FieldAttribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias)
    assert attribute.isa == isa
    assert attribute.private == private
    assert attribute.default == default
    assert attribute.required == required
    assert attribute.listof == listof
    assert attribute.priority == priority
    assert attribute.class_type == class_type
    assert attribute.always_post_validate == always_post_validate
    assert attribute.inherit == inherit
    assert attribute.alias == alias



# Generated at 2022-06-11 09:44:39.742408
# Unit test for constructor of class Attribute
def test_Attribute():
    def test_Attribute_constructor_missing_parameters():
        # A constructor call with no parameters
        assert Attribute() == Attribute()


# Generated at 2022-06-11 09:44:45.088038
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa = 'dict'
    listof = 'dict'
    default = {}
    required = False
    class_type = dict
    fa = FieldAttribute(isa=isa, listof=listof, default=default, required=required, class_type=class_type)

    # Test the constructor of class FieldAttribute
    assert fa.isa == isa
    assert fa.listof == listof
    assert fa.default == default
    assert fa.required == required
    assert fa.class_type == class_type



# Generated at 2022-06-11 09:44:51.855009
# Unit test for constructor of class Attribute
def test_Attribute():
    with pytest.raises(TypeError) as dummy:
        Attribute(default=2)
    with pytest.raises(TypeError) as dummy:
        Attribute(default=[])
    with pytest.raises(TypeError) as dummy:
        Attribute(default={})

    ok = Attribute(default=3)
    assert ok.default == 3
    ok = Attribute(default=tuple())
    assert ok.default == tuple()
    ok = Attribute(default=frozenset())
    assert ok.default == frozenset()



# Generated at 2022-06-11 09:45:02.005053
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.default is None
    assert a.class_type is None
    assert a.extend is False
    a = FieldAttribute(default="hello", class_type="class_name", extend=True)
    assert a.default == "hello"
    assert a.class_type == "class_name"
    assert a.extend is True

    # Check that constructor of class Attribute is called
    try:
        a = FieldAttribute(isa="list", listof="str")
        assert False
    except TypeError:
        pass
    try:
        a = FieldAttribute(isa="list", default=[""])
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 09:45:11.752144
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.role import Role

    class MyBase(Base):
        attr1 = FieldAttribute(isa='integer', required=True)
        attr2 = FieldAttribute(isa='float', inherit=True)
        attr3 = FieldAttribute(isa='boolean')
        attr4 = FieldAttribute(isa='string', required=True, default='hello')
        attr5 = FieldAttribute(isa='list', listof='string')
        attr6 = FieldAttribute(isa='list', required=True, listof=MyBase)
        attr7 = FieldAttribute(isa='Role', class_type=Role)
        attr8 = FieldAttribute(isa='dict', inherit=False)

    a = MyBase()
   

# Generated at 2022-06-11 09:45:18.308504
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()
    assert FA.isa == None
    assert not FA.private
    assert FA.default == None
    assert not FA.required
    assert FA.listof == None
    assert FA.priority == 0
    assert FA.class_type == None
    assert not FA.always_post_validate
    assert FA.inherit
    assert FA.extend == False
    assert FA.prepend == False
    assert FA.static == False
