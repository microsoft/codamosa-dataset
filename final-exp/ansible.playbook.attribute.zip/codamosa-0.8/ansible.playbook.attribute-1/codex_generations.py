

# Generated at 2022-06-11 09:36:06.044395
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.isa == None
    assert field_attribute.private == False
    assert field_attribute.default == None
    assert field_attribute.required == False
    assert field_attribute.listof == None
    assert field_attribute.priority == 0
    assert field_attribute.class_type == None
    assert field_attribute.always_post_validate == False
    assert field_attribute.inherit == True
    assert field_attribute.alias == None
    assert field_attribute.extend == False
    assert field_attribute.prepend == False
    assert field_attribute.static == False


# Generated at 2022-06-11 09:36:11.341142
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        attr = FieldAttribute(
            isa=int,
            private=False,
            default=0,
            required=True,
            listof=None,
            priority=1,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
            static=False
        )
        print(attr.priority)

    except TypeError as e:
        print(e)

test_FieldAttribute()

# Generated at 2022-06-11 09:36:17.813921
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # create an instance of the class FieldAttribute
    obj_instance = FieldAttribute()
    # test the instance's isa attribute
    assert not obj_instance.isa
    # test the instance's private attribute
    assert not obj_instance.private
    # test the instance's default attribute
    assert not obj_instance.default
    # test the instance's required attribute
    assert not obj_instance.required
    # test the instance's listof attribute
    assert not obj_instance.listof
    # test the instance's priority attribute
    assert not obj_instance.priority
    # test the instance's class_type attribute
    assert not obj_instance.class_type
    # test the instance's always_post_validate attribute
    assert not obj_instance.always_post_validate
    # test the instance's inherit attribute
    assert obj_instance.inherit

# Generated at 2022-06-11 09:36:25.789434
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='str',
        private=True,
        default='default',
        required=True,
        listof='str',
        priority=1,
        class_type=None,
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=False,
        prepend=True,
        static=False,
    )
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == 'default'
    assert a.required == True
    assert a.listof == 'str'
    assert a.priority == 1
    assert a.class_type == None
    assert a.always_post_validate == True
    assert a.inherit == True
    assert a.alias == 'alias'
    assert a

# Generated at 2022-06-11 09:36:27.878336
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a=FieldAttribute(isa='list',default={})
        assert(False)
    except TypeError:
        assert(True)
    a=FieldAttribute(isa='list',default=list())
    assert(a is not None)


# Generated at 2022-06-11 09:36:28.852903
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute()
    assert isinstance(obj, Attribute)

# Generated at 2022-06-11 09:36:38.941783
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    test_attr = FieldAttribute(
        isa='str',
        private=True,
        default=None,
        required=True,
        listof='str',
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert test_attr.isa == 'str'
    assert test_attr.private == True
    assert test_attr.default == None
    assert test_attr.required == True
    assert test_attr.listof == 'str'
    assert test_attr.priority == 1
    assert test_attr.class_type == None
    assert test_attr.always_post_validate == False

# Generated at 2022-06-11 09:36:51.180107
# Unit test for constructor of class Attribute
def test_Attribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None

    a = FieldAttribute(isa='str', private=True, default='', required=True, listof='list', priority=1, class_type='list',
                       always_post_validate=True, inherit=False, alias='aliased_name')
    assert a.isa == 'str'
    assert a.private == True
    assert a.default == ''
    assert a.required == True

# Generated at 2022-06-11 09:36:57.467020
# Unit test for constructor of class Attribute
def test_Attribute():
    _Attribute = Attribute

    a = _Attribute(isa='list')
    assert a.isa is list

    a = _Attribute(isa='dict')
    assert a.isa is dict

    a = _Attribute(isa='set', default=set)
    assert a.isa is set
    assert a.default == set

# Simple test to verify that FieldAttribute is a subclass of Attribute.

# Generated at 2022-06-11 09:37:01.859707
# Unit test for constructor of class Attribute
def test_Attribute():
    expected = Attribute(isa='str', private=False, default='hello world', required=False, listof='str', priority=0, always_post_validate=False, inherit=True)
    actual = Attribute(isa='str', private=False, default='hello world', required=False, listof='str', always_post_validate=False)

    assert actual == expected, 'Expected values to be equal!'


# Generated at 2022-06-11 09:37:13.837623
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    attr1 = Attribute()
    attr2 = Attribute(isa="list")
    # default
    assert attr1.default is None
    assert attr2.default is None
    attr3 = Attribute(default=set())
    assert attr3.default == set()
    # required
    assert attr1.required == False
    assert attr2.required == False
    attr4 = Attribute(required=True)
    assert attr4.required == True
    # listof
    assert attr1.listof is None
    assert attr2.listof is None
    attr5 = Attribute(listof="foo")
    assert attr5.listof == "foo"
    # priority
    assert attr1.priority == 0
    assert attr2.priority == 0

# Generated at 2022-06-11 09:37:21.667399
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', default='hello')
    assert f.isa == 'list'
    assert f.default == 'hello'

    f = FieldAttribute(isa='list', default=['a', 'b', 'c'])
    assert f.isa == 'list'
    assert f.default == ['a', 'b', 'c']

    f = FieldAttribute(isa='list', default=['a', 'b', 'c'])
    assert f.isa == 'list'
    assert f.default == ['a', 'b', 'c']
    assert f.default != ['a', 'b', 'c']

    f = FieldAttribute(isa='list', default=frozenset(['a', 'b', 'c']))
    assert f.isa == 'list'

# Generated at 2022-06-11 09:37:30.925283
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='yaml',
        private='yaml',
        default='yaml',
        required='yaml',
        listof='yaml',
        priority='yaml',
        class_type='yaml',
        always_post_validate='yaml',
        inherit='yaml',
        alias='yaml',
        extend='yaml',
        prepend='yaml',
        static='yaml'
    )
    assert fa.isa == 'yaml'
    assert fa.private == 'yaml'
    assert fa.default == 'yaml'
    assert fa.required == 'yaml'
    assert fa.listof == 'yaml'
    assert fa.priority == 'yaml'
    assert fa.class_type == 'yaml'
    assert fa.always_post_

# Generated at 2022-06-11 09:37:34.136446
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr1 = FieldAttribute(isa='string', private=True)
    field_attr2 = FieldAttribute(isa='list', class_type='list')

    assert field_attr1.isa == 'string' and field_attr2.class_type == 'list'



# Generated at 2022-06-11 09:37:35.568784
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f=FieldAttribute(isa="dict")
    assert f.isa=="dict"



# Generated at 2022-06-11 09:37:40.998196
# Unit test for constructor of class Attribute
def test_Attribute():
    # test required
    attr = Attribute(required=True)
    assert attr.required is True

    # test default
    assert attr.default is None

    # test isa
    attr = Attribute(isa='list')
    assert attr.isa == 'list'

    # test private
    assert attr.private is False

    # test listof
    attr = Attribute(isa='list', listof='str')
    assert attr.listof == 'str'

    # test priority
    assert attr.priority == 0

    # test class_type
    assert attr.class_type is None

    # test always_post_validate
    assert attr.always_post_validate is False


# Generated at 2022-06-11 09:37:42.779587
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr = Attribute(isa='bool')
    attr = Attribute(isa='percent')


# Generated at 2022-06-11 09:37:49.591725
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', default='default', listof='string')
    assert a.isa == 'string'
    assert a.default == 'default'
    assert a.listof == 'string'
    assert a.inherit == True


# FIXME: this is a mess and needs to be fixed in the future
#        might need a data structure approach, versus this
#        add_field() method below -- see the actual usage of
#        this class.


# Generated at 2022-06-11 09:38:02.515040
# Unit test for constructor of class Attribute
def test_Attribute():
    print("TEST_ATTRIBUTE TESTING")

    a = Attribute(isa="test",private=False,default=None,required=False,listof=None,priority=0,class_type=None,always_post_validate=False,inherit=True,alias=None,extend=False,prepend=False,static=False)
    a.__eq__(a)
    a.__ne__(a)
    a.__lt__(a)
    a.__gt__(a)
    a.__le__(a)
    a.__ge__(a)

    try:
        a.default = ['listof']
        print(a.default)
    except:
        print("Attribute.default should be a callable")

    print("TEST_ATTRIBUTE COMPLETED")




# Generated at 2022-06-11 09:38:13.076595
# Unit test for constructor of class Attribute
def test_Attribute():

    def c1(x): return x

    def c2(x): return x

    a = Attribute(isa='bool', private=True, default=True, required=False, listof=None, priority=0, class_type=int, always_post_validate=False, inherit=True, alias=None, static=False)
    b = Attribute(isa='bool', private=True, default=True, required=False, listof=None, priority=0, class_type=int, always_post_validate=False, inherit=True, alias=None, static=False)
    assert a == b


# Generated at 2022-06-11 09:38:20.630050
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.isa is None
    assert attribute.private is False
    assert attribute.default is None
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False
    assert attribute.prepend is False

# Generated at 2022-06-11 09:38:27.276933
# Unit test for constructor of class Attribute
def test_Attribute():
    global _CONTAINERS
    print("test for constructor of class Attribute")
    # test for __init__()
    # test for isa and default as 'list'
    try:
        a = Attribute(default = 'list', isa='list')
    except TypeError as err:
        assert('defaults for FieldAttribute may not be mutable' in err.args[0])
    # test for isa not in _CONTAINERS
    a = Attribute(default = [], isa='dict')
    # test for isa and default as 'tuple'
    a = Attribute(default = (), isa='tuple')
    assert(a != None)
    # test for isa and default as 'dict'
    a = Attribute(default = {}, isa='dict')
    assert(a != None)
    # test

# Generated at 2022-06-11 09:38:30.377952
# Unit test for constructor of class Attribute
def test_Attribute():
    def default_1():
        return 1
    def default_2():
        return dict(a=1)

    try:
        Attribute(isa="dict", default={})
    except TypeError as e:
        assert e.args[0] == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'

    assert Attribute(isa='dict', default=default_1).default == 1
    assert Attribute(isa='dict', default=default_2).default == dict(a=1)

# Generated at 2022-06-11 09:38:41.908738
# Unit test for constructor of class Attribute
def test_Attribute():
    pv = Attribute(isa='list', private=True, default=list(), required=True,
                   listof='boolean', priority=1, class_type='list',
                   always_post_validate=True, alias='alias')
    assert pv is not None


# Prepare the dependencies for FieldInclude
FieldInclude = FieldAttribute
for _field in ('path', 'name', 'role', 'o', '_copy_'):
    setattr(FieldInclude, _field, FieldAttribute())

FieldInclude.noop = FieldAttribute(default=False)
FieldInclude.tags = FieldAttribute(isa='list', default=list(), required=False)
FieldInclude.register = FieldAttribute(isa='list', default=None, required=False)


# Generated at 2022-06-11 09:38:52.674934
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test for private
    try:
        f = FieldAttribute(private=False)
        assert f.private == False
    except TypeError:
        assert False, "Type Error in Field Attribute Private"

    # test for required
    try:
        f = FieldAttribute(required=False)
        assert f.required == False
    except TypeError:
        assert False, "Type Error in Field Attribute Required"
    
    # test for always_post_validate
    try:
        f = FieldAttribute(always_post_validate=False)
        assert f.always_post_validate == False
    except TypeError:
        assert False, "Type Error in Field Attribute Always Post Validate"

    # test for inherit

# Generated at 2022-06-11 09:38:57.337518
# Unit test for constructor of class Attribute
def test_Attribute():
    import sys
    from ansible.module_utils.six import PY3
    if PY3:
        class_type = bytes
    else:
        class_type = str
    attr = Attribute(isa=class_type)
    assert (attr.isa == class_type)


# Generated at 2022-06-11 09:39:00.725832
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict', default=dict, required=True)
    assert attr.isa == 'dict'
    assert attr.default == dict
    assert attr.required == True


# Generated at 2022-06-11 09:39:01.714618
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute() is not None

# Generated at 2022-06-11 09:39:11.516165
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa=int,
        private=True,
        default=42,
        required=True,
        listof=str,
        priority=42,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='foo',
        extend=False,
        prepend=False,
    )

    assert attr.isa == int
    assert attr.private is True
    assert attr.default == 42
    assert attr.required is True
    assert attr.listof == str
    assert attr.priority == 42
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias == 'foo'
    assert attr

# Generated at 2022-06-11 09:39:13.266262
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa = "int", private = False)
    assert f.isa == "int"
    assert not f.private


# Generated at 2022-06-11 09:39:28.230730
# Unit test for constructor of class Attribute
def test_Attribute():
    badDefault = dict()
    badDefault['dict'] = {'wrong': 'thing'}
    badDefault['list'] = [1,2,3]
    badDefault['set'] = {'a', 'b', 'c'}
    for k in badDefault:
        try:
            attr = Attribute(k, default=badDefault[k])
        except TypeError:
            pass
        else:
            raise Exception('Expected TypeError for default value for Attribute(isa=%s)' % k)

    attr = Attribute(None)
    assert attr.isa == None

    attr = Attribute(isa='dict')
    assert attr.isa == 'dict'

    attr = Attribute(isa='dict', default=dict)
    assert attr.isa == 'dict'


# Generated at 2022-06-11 09:39:32.269331
# Unit test for constructor of class Attribute
def test_Attribute():
    #raise TypeError if the default value is not allowed
    try:
        field = FieldAttribute(isa='dict', default={'a':'b'})
        print(field.default)
    except TypeError as ex:
        print(ex)

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-11 09:39:33.759101
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert isinstance(Attribute(), FieldAttribute)


# Generated at 2022-06-11 09:39:37.893223
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    b = FieldAttribute(priority=10)
    c = FieldAttribute(priority=1)
    a == a
    a != b
    a > b
    a < b
    a >= b
    a >= b
    a >= b
    a >= c
    a <= c
    a <= b

# Generated at 2022-06-11 09:39:44.050733
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', private=True, default=None, required=False,
                          listof='set', priority=0, class_type=None, always_post_validate=False,
                          inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'list'
    assert attr.private == True
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == 'set'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False


# Generated at 2022-06-11 09:39:49.626017
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='dict', private=True).isa == 'dict'
    assert Attribute(isa='dict', private=True).private == True

    try:
        Attribute(isa='dict', private=True, default={})
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 09:40:00.435254
# Unit test for constructor of class Attribute
def test_Attribute():

    # test normal usage...
    a = Attribute(isa='dict', default=dict(), required=True, class_type=dict, priority=10)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == dict()
    assert a.required == True
    assert a.listof == None
    assert a.priority == 10



# Generated at 2022-06-11 09:40:10.977835
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='a', private=False, default='b', required=False)
    b = Attribute(isa='a', private=False, default='b', required=False)
    assert(a == b)

    a = Attribute(isa='a', private=False, default='b', required=False)
    b = Attribute(isa='a', private=False, default='c', required=False)
    assert(a != b)

    a = Attribute(isa='a', private=False, default='b', required=False)
    b = Attribute(isa='b', private=False, default='c', required=False)
    assert(a != b)

    a = Attribute(isa='a', private=False, default='b', required=False)

# Generated at 2022-06-11 09:40:19.172145
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class TestObject(object):
        test = FieldAttribute(isa='test',
                              private=False,
                              default=None,
                              required=False,
                              listof=None,
                              priority=0,
                              class_type=None,
                              always_post_validate=False,
                              inherit=False,
                              alias=None,
                              extend=False,
                              prepend=False,
                              static=False)
        pass

    testObject = TestObject()
    testObject.test = 'original_test'

    assert(testObject.test == 'original_test')


# Generated at 2022-06-11 09:40:26.083771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    Attribute = FieldAttribute()
    assert Attribute.isa is None
    assert Attribute.private is False
    assert Attribute.default is None
    assert Attribute.required is False
    assert Attribute.listof is None
    assert Attribute.priority == 0
    assert Attribute.class_type is None
    assert Attribute.always_post_validate is False
    assert Attribute.inherit is True
    assert Attribute.alias is None
    assert Attribute.extend is False
    assert Attribute.prepend is False
    assert Attribute.static is False


# Generated at 2022-06-11 09:40:39.990725
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(
        isa='str',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    print(x)

# Generated at 2022-06-11 09:40:49.856665
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
        Method: test_Attribute()
        Use Case:
            Test the constructor of class Attribute
        Supported Theories:
            a. The constructor of class Attribute has 8 parameters
            b. Each parameter has a specific type and range
            c. The names of parameters is the same with constructor in class Attribute
        Outcome:
            1. Pass
            2. Pass
            3. Pass
    '''
    a = Attribute()
    if len(a.__init__.__code__.co_varnames) == 8:
        print("1. Pass")

# Generated at 2022-06-11 09:41:00.555503
# Unit test for constructor of class Attribute
def test_Attribute():

    # create a new Attribute class/object
    a = Attribute(isa='str')

    assert a.isa == 'str'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None

    # create a new Attribute class/object with defaults
    a = Attribute()

    assert a.isa is None
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_

# Generated at 2022-06-11 09:41:03.801182
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', default=lambda: [], required=True)
    assert a.isa == 'list'
    assert a.default() == []
    assert a.required


# Generated at 2022-06-11 09:41:13.926151
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fa = FieldAttribute()
    assert fa.isa == None
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False

    fa = FieldAttribute(isa='bool')
    assert fa.isa == 'bool'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None

# Generated at 2022-06-11 09:41:15.833036
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='string')
    assert f.isa == 'string'



# Generated at 2022-06-11 09:41:16.437746
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()

# Generated at 2022-06-11 09:41:26.641145
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test the constructor of class Attribute
    """
    from six import PY3

    # isa default
    attr = Attribute()
    assert attr.default is None

    # isa string
    attr = Attribute(isa="string")
    assert attr.isa == "string"

    # isa boolean
    attr = Attribute(isa="boolean")
    assert attr.isa == "boolean"

    # isa list
    attr = Attribute(isa="list")
    assert attr.isa == "list"

    # isa dict
    attr = Attribute(isa="dict")
    assert attr.isa == "dict"

    # listof string
    attr = Attribute(listof="string")
    assert attr.listof == "string"

    # listof

# Generated at 2022-06-11 09:41:31.058182
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa='int', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)



# Generated at 2022-06-11 09:41:43.514581
# Unit test for constructor of class Attribute
def test_Attribute():

    assert Attribute(isa='dict', private=False, default=dict(),
                     required=True, listof=None, class_type=None, inherit=True,
                     extend=False, prepend=False, static=False).isa == 'dict'
    assert Attribute(isa='dict', private=False, default=dict(),
                     required=True, listof=None, class_type=None, inherit=True,
                     extend=False, prepend=False, static=False).private == False
    assert Attribute(isa='dict', private=False, default=dict(),
                     required=True, listof=None, class_type=None, inherit=True,
                     extend=False, prepend=False, static=False).default == dict()

# Generated at 2022-06-11 09:42:02.917795
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    test = FieldAttribute(isa='str')
    assert test.isa == 'str'



# Generated at 2022-06-11 09:42:10.234771
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa="string")
    assert a.isa == "string"
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None


# Generated at 2022-06-11 09:42:18.233296
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test initialization of Attribute class
    x = Attribute(isa='str', private=True, default='Hello', required=True, listof='str', priority=2,
                  class_type='MyClass', always_post_validate=True, inherit=False,
                  alias='Sample', static=True)

    assert x.isa == 'str'
    assert x.private == True
    assert x.default == 'Hello'
    assert x.required == True
    assert x.listof == 'str'
    assert x.priority == 2
    assert x.class_type == 'MyClass'
    assert x.always_post_validate == True
    assert x.inherit == False
    assert x.alias == 'Sample'
    assert x.static == True

    # Test initialization of Attribute class with isa = 'list' and no

# Generated at 2022-06-11 09:42:20.559343
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='boolean')
    assert fa.isa == 'boolean'


# Generated at 2022-06-11 09:42:23.322422
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='int', default=1)
    assert attr.isa == 'int'
    assert attr.default == 1


# Generated at 2022-06-11 09:42:33.219009
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='boolean')
    assert attr.isa == 'boolean'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None

    attr = FieldAttribute(isa='boolean', default='y', inherit=False)
    assert attr.isa == 'boolean'
    assert attr.private == False
    assert attr.default == 'y'
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0

# Generated at 2022-06-11 09:42:42.778710
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='string', private=False, default=None, required=False, listof=None,
            priority=0, class_type=None, always_post_validate=False, inherit=True,
            alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == 'string'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr

# Generated at 2022-06-11 09:42:54.342197
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='str',
        default='localhost',
        required=True,
        listof='list',
        priority=1,
        class_type='str',
        always_post_validate=True,
        inherit=True,
        alias='str',
        extend=False,
        prepend=False,
        static=False,
        )
    assert isinstance(attr, Attribute)

    attr = FieldAttribute(
        isa='str',
        default='localhost',
        required=True,
        listof='list',
        priority=1,
        class_type='str',
        always_post_validate=True,
        inherit=True,
        alias='str',
        extend=False,
        prepend=False,
        static=False,
        )

# Generated at 2022-06-11 09:43:02.817700
# Unit test for constructor of class Attribute
def test_Attribute():
    fields = Attribute(isa='list', static=False, required=False, default=None,
                       listof='string', class_type='Host', priority=0,
                       always_post_validate=False, inherit=True,
                       extend=False)

    assert(fields.isa == 'list')
    assert(fields.static == False)
    assert(fields.required == False)
    assert(fields.default == None)
    assert(fields.listof == 'string')
    assert(fields.class_type == 'Host')
    assert(fields.priority == 0)
    assert(fields.always_post_validate == False)
    assert(fields.inherit == True)
    assert(fields.extend == False)



# Generated at 2022-06-11 09:43:03.736499
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().isa is None



# Generated at 2022-06-11 09:43:51.163505
# Unit test for constructor of class Attribute
def test_Attribute():
    ## TODO: Test for class_type
    for type in ['str', 'int', 'bool', 'float']:
        att = Attribute(type)
        assert att.isa == type
        assert att.private == False
        assert att.default == None
        assert att.required == False
        assert att.listof == None
        assert att.priority == 0
        assert att.class_type == None
        assert att.always_post_validate == False
        assert att.inherit == True
        assert att.alias == None
        assert att.extend == False
        assert att.prepend == False
        assert att.static == False

    now_attr = lambda: 'default'
    default = [1, 2]
    att = Attribute('list', default=now_attr)
    assert att.default == now_attr


# Generated at 2022-06-11 09:44:00.701633
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa=int, required=False, default=None)
    Attribute(isa=int, required=False, default=0)
    Attribute(isa=int, required=True, default=0)
    Attribute(isa=int, required=True, default=None)
    Attribute(isa=int, required=False, default=None)
    Attribute(isa=list, required=False, default=[])
    Attribute(isa=list, required=False, default=None)
    Attribute(isa=list, required=True, default=None)
    Attribute(isa='int', required=False, default=None)
    Attribute(isa='list', required=True, default=None)
    Attribute(isa=dict, required=True, default=None)

# Generated at 2022-06-11 09:44:10.844801
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    attr = Attribute(isa="str")
    assert attr.isa == "str"
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None

# Generated at 2022-06-11 09:44:15.333677
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=lambda: [])
    assert a.isa == 'list'
    assert a.default() == []
    assert a.default() is not []
    try:
        a = Attribute(isa='list', default=[])
    except TypeError:
        pass
    else:
        assert False, 'TypeError not raised.'



# Generated at 2022-06-11 09:44:16.203555
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()



# Generated at 2022-06-11 09:44:27.573258
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(
        isa='str',
        private=True,
        default=None,
        required=False,
        listof=None,
        priority=10,
        class_type='Class',
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert type(field_attribute.isa) is str
    assert type(field_attribute.private) is bool
    assert field_attribute.default is None
    assert type(field_attribute.required) is bool
    assert field_attribute.listof is None
    assert type(field_attribute.priority) is int
    assert type(field_attribute.class_type) is str

# Generated at 2022-06-11 09:44:38.498504
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute1 = Attribute()
    assert attribute1.isa == None
    assert attribute1.private == False
    assert attribute1.default == None
    assert attribute1.required == False
    assert attribute1.listof == None
    assert attribute1.priority == 0
    assert attribute1.class_type == None
    assert attribute1.always_post_validate == False
    assert attribute1.inherit == True
    assert attribute1.alias == None
    assert attribute1.extend == False
    assert attribute1.prepend == False
    assert attribute1.static == False

# Generated at 2022-06-11 09:44:42.748431
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    attr = Attribute(isa='list')
    attr = Attribute(isa='list', default=lambda: [])
    attr = Attribute(isa='list', default=lambda: [1])
    try:
        attr = Attribute(isa='list', default=10)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 09:44:44.786480
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    test if FieldAttribute can be instantiated
    """

    fa = FieldAttribute(isa='any')

    # if execution arrives here, test succeeded
    assert fa



# Generated at 2022-06-11 09:44:47.996377
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        myfield = FieldAttribute(default=['foo'])
    except:
        print("FieldAttribute(default=['foo']) failed")
        raise
    else:
        print("FieldAttribute(default=['foo']) succeeded")

test_FieldAttribute()