

# Generated at 2022-06-11 09:36:05.562994
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='bool', default=True, always_post_validate=True)
    assert a.isa == 'bool'
    assert a.default == True
    assert a.always_post_validate == True

# Generated at 2022-06-11 09:36:13.129169
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int', required=True)
    assert a.isa == 'int'
    assert a.required == True

    a = Attribute(isa='number', required=True)
    assert a.isa == 'number'
    assert a.required == True

    a = Attribute(isa='boolean', required=True)
    assert a.isa == 'boolean'
    assert a.required == True

    a = Attribute(isa='list', required=True)
    assert a.isa == 'list'
    assert a.required == True

    a = Attribute(isa='dict', required=True)
    assert a.isa == 'dict'
    assert a.required == True

    a = Attribute(isa='set', required=True)
    assert a.isa == 'set'
    assert a.required == True

# Generated at 2022-06-11 09:36:20.762521
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])
    variable_manager.set_inventory(inventory)
    host = Host(name="localhost")
    host.set_variable("ansible_ssh_port", "22")
    group = Group("all")
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:36:25.269931
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='list')
    assert fa.isa == 'list'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None


# Generated at 2022-06-11 09:36:26.190102
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute()
    assert x is not None


# Generated at 2022-06-11 09:36:34.188014
# Unit test for constructor of class Attribute
def test_Attribute():

    from ansible.errors import AnsibleError

    # Test instantiating an Attribute object (Isa is a valid Python class)
    attr = Attribute(isa='ansible.errors.AnsibleError')
    assert type(attr.isa) == type
    assert attr.isa == AnsibleError

    # Test instantiating an Attribute object (Isa is a yaml type)
    attr = Attribute(isa='int')
    assert type(attr.isa) == str
    assert attr.isa == 'int'

    # Test instantiating an Attribute object (Isa is a '%' type)
    attr = Attribute(isa='%')
    assert type(attr.isa) == str
    assert attr.isa == '%'

    # Test instantiating an Attribute object (isa is invalid)

# Generated at 2022-06-11 09:36:41.756862
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test that the constructor throws an exception if a mutable 
    # type is provided for the default
    try:
        FieldAttribute(default=dict(), isa="list")
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'

    # test that the constructor does not throw an exception for
    # a callable object as the default
    try:
        FieldAttribute(default=lambda: dict(), isa="list")
    except TypeError:
        assert False, 'Unexpected TypeError'



# Generated at 2022-06-11 09:36:54.693495
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import unittest

    class TestFieldAttribute(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_default(self):
            field_attribute = FieldAttribute(default=[])
            self.assertEqual(field_attribute.default, [])

            # check default is immutable
            try:
                field_attribute = FieldAttribute(default=[1,2,3])
            except TypeError as e:
                self.assertEqual(str(e), 'defaults for FieldAttribute may not be mutable, please provide a callable instead')
            else:
                self.fail('Expected an error with message: {}'.format(str(e)))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestFieldAttribute)
    unittest.Text

# Generated at 2022-06-11 09:36:58.398330
# Unit test for constructor of class Attribute
def test_Attribute():
    def test(**kwargs):
        return Attribute(**kwargs)

    assert kwargs == dict(isa='str')
    assert kwargs == dict(isa='str', default=None)
    assert kwargs == dict(isa='str', default=None, required=None)



# Generated at 2022-06-11 09:37:02.908935
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute(): 
    test_attribute = FieldAttribute()
    assert test_attribute.isa is None
    assert test_attribute.private is False
    assert test_attribute.default is None
    assert test_attribute.required is False
    assert test_attribute.listof is None
    assert test_attribute.priority == 0
    assert test_attribute.class_type is None
    assert test_attribute.always_post_validate is False
    assert test_attribute.inherit is True
    assert test_attribute.alias is None



# Generated at 2022-06-11 09:37:11.722153
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Check the number of parameters
    f = FieldAttribute(isa=int, default=0, required=False)
    assert len(f.__dict__.keys()) == 11

    # Check that a reserved word used as key raises a TypeError
    # Use a mutable default
    test_dict = dict()
    test_dict['isa'] = bool
    test_dict['default'] = test_dict
    try:
        f = FieldAttribute(**test_dict)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 09:37:18.626565
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default='[]', inherit=False, static=True)
    assert a.__dict__ == {'default': '[]', 'inherit': False, 'isa': 'list', 'static': True}
    a = Attribute(isa='list', default='')
    assert a.__dict__ == {'default': '', 'inherit': True, 'isa': 'list'}
    a = Attribute(isa='list', default='default value')
    assert a.__dict__ == {'default': 'default value', 'inherit': True, 'isa': 'list'}
    a = Attribute(isa='list', default='["default", "value"]')

# Generated at 2022-06-11 09:37:27.039838
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """Tests the constructor of class FieldAttribute.

    The purpose of this test is to check that the constructor of the class FieldAttribute will
    raise an error if a mutable default value is passed.
    """
    # This is a list of attributes, which is a mutable object and thus is not allowed to be used
    # as a default value for a class FieldAttribute.
    mutable_value = []

    # This is a dict instead of a list, which is mutable and thus is not allowed to be used
    # as a default value for a class FieldAttribute.
    mutable_value = {}

    # This is a set instead of a list, which is mutable and thus is not allowed to be used
    # as a default value for a class FieldAttribute.
    mutable_value = {}

    # This is a string instead of a list, which is not mutable

# Generated at 2022-06-11 09:37:36.198392
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test "None" for "isa" parameter
    attr = FieldAttribute(isa=None, private=False, default=None,
                          required=True, listof=None, priority=0,
                          class_type=None, always_post_validate=False,
                          inherit=False, alias=None, extend=False)
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == True
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == False
    assert attr.alias == None
    assert attr.extend == False

    # Test "str" for "

# Generated at 2022-06-11 09:37:40.147871
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True
    )

    assert isinstance(a, Attribute)

# Generated at 2022-06-11 09:37:42.030834
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.static is False
    f = FieldAttribute(static=True)
    assert f.static is True



# Generated at 2022-06-11 09:37:43.180637
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa is not None


# Generated at 2022-06-11 09:37:46.838593
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Test(object):
        # The attribute name must be a string, no other type is allowed.
        my_attr = FieldAttribute(isa='str')

    test = Test()
    test.my_attr = 'some_value_string'



# Generated at 2022-06-11 09:37:50.527580
# Unit test for constructor of class Attribute
def test_Attribute():
    # Enforce the check in the Attribute constructor
    a = Attribute(default={})
    assert isinstance(a.default, set)
    a = Attribute(default=[])
    assert isinstance(a.default, list)
    a = Attribute(default=set())
    assert isinstance(a.default, set)
    a = Attribute(default=list())
    assert isinstance(a.default, list)



# Generated at 2022-06-11 09:37:54.233402
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='dict', private=True, default={}, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True)
    assert f.isa == 'dict'
    assert f.private == True
    assert f.default == {}
    assert f.required == False
    assert f.priority == 0
    assert f.class_type is None
    assert f.inherit == True
    assert f.alias is None

# Generated at 2022-06-11 09:38:07.895609
# Unit test for constructor of class Attribute
def test_Attribute():
    from unit.modules.utility import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    import ansible.module_utils.percent
    import ansible.module_utils.basic
    import ansible.module_utils.urls

    class TestAttribute(ModuleTestCase):
        module = ansible.module_utils.basic.AnsibleModule
        _ANSIBLE_ARGS = '{"argument_spec": {"test_attr": {"default": 123, "extend": true, "required": false, "type": "int"}}, "supports_check_mode": false}'

        def _get_args(self):
            return json.loads(self._ANSIBLE_ARGS)

        def setUp(self):
            super(TestAttribute, self).setUp()
            self.mock_module_helper = patch.multiple

# Generated at 2022-06-11 09:38:18.311261
# Unit test for constructor of class Attribute
def test_Attribute():
    # private defaults to False
    attr = Attribute(isa='string')
    assert attr.private == False

    # private set to True
    attr = Attribute(isa='string', private=True)
    assert attr.private == True

    # default defaults to None
    attr = Attribute(isa='string')
    assert attr.default == None

    # default set to 42
    attr = Attribute(isa='string', default=42)
    assert attr.default == 42

    # required defaults to False
    attr = Attribute(isa='string')
    assert attr.required == False

    # required set to True
    attr = Attribute(isa='string', required=True)
    assert attr.required == True

    # listof defaults to None
    attr = Attribute(isa='string')

# Generated at 2022-06-11 09:38:24.253020
# Unit test for constructor of class Attribute
def test_Attribute():

    try:
        list_attr = Attribute(isa='list')
    except Exception as e:
        assert False, "attribute constructor failed"

    try:
        list_attr = Attribute(isa='list',required=False,default=None,listof='str')
    except Exception as e:
        assert False, "attribute constructor failed"

    try:
        list_attr = Attribute(isa='str')
    except Exception as e:
        assert False, "attribute constructor failed"

    try:
        list_attr = Attribute(isa='dict',required=False,default=None,listof='str')
    except Exception as e:
        assert False, "attribute constructor failed"


# Generated at 2022-06-11 09:38:26.412209
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', listof='str')
    assert a.isa == 'list'
    assert a.listof == 'str'

# Generated at 2022-06-11 09:38:39.289453
# Unit test for constructor of class Attribute
def test_Attribute():
    # tests for isa
    Attribute()
    Attribute('string', extend=True)
    Attribute('int')
    Attribute('bool')
    Attribute('float')
    Attribute('list', listof='string')
    Attribute('dict', listof='string')
    Attribute('set', listof='string')
    Attribute('string', default=['a'], extend=True)
    Attribute('string', default=lambda: ['a'], extend=True)

    class TestFieldAttributeClass:
        pass

    Attribute('class', class_type=TestFieldAttributeClass)

    with pytest.raises(TypeError):
        Attribute('string', default=['a'], extend=True, isa='list', listof='string')

    with pytest.raises(AssertionError):
        Attribute

# Generated at 2022-06-11 09:38:45.289805
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a=FieldAttribute('list', default='yoyo', required=False, listof='str', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert 'list' == a.isa
    assert 'yoyo' == a.default
    assert False == a.required
    assert 'str' == a.listof
    assert 0 == a.priority
    assert None == a.class_type
    assert False == a.always_post_validate
    assert True == a.inherit
    assert None == a.alias

# Generated at 2022-06-11 09:38:50.827717
# Unit test for constructor of class Attribute
def test_Attribute():
    # test Attribute with correct values
    Attribute(isa='list')

    # test Attribute with incorrect values
    try:
        Attribute(isa='list', default=(1,2,3))
    except TypeError:
        pass
    else:
        raise Exception('Failed to catch non-callable default for mutable attribute')

# Generated at 2022-06-11 09:38:53.021851
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert isinstance(attr, Attribute)


# Generated at 2022-06-11 09:39:04.006214
# Unit test for constructor of class Attribute
def test_Attribute():

    # test if default is None
    a = Attribute(isa='dict',
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=0,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False)
    assert a.isa == 'dict'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

# Generated at 2022-06-11 09:39:13.074072
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.utils.vars import combine_vars

    attr1 = Attribute()
    assert attr1.isa is None
    assert attr1.private == False
    assert attr1.default is None
    assert attr1.required == False
    assert attr1.listof is None
    assert attr1.priority == 0
    assert attr1.always_post_validate == False
    assert attr1.inherit == True
    assert attr1.alias is None

    assert attr1 == attr1

    # check all the other __eq__ methods
    attr2 = Attribute(priority=1)
    assert attr2 != attr1
    attr2 = Attribute(priority=0)
    assert attr2 == attr1

    attr2 = Attribute()
   

# Generated at 2022-06-11 09:39:20.878692
# Unit test for constructor of class Attribute
def test_Attribute():
    foo = Attribute(isa='dict', private=False,
                    default={}, required=False,
                    listof='str', priority=0,
                    class_type='class', always_post_validate=False,
                    inherit=True, alias="alias")
    foo = Attribute(isa='dict', private=False, default={})


# Generated at 2022-06-11 09:39:27.245401
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string', required=True, default='default string')
    assert field.isa == 'string'
    assert field.required == True
    assert field.default == 'default string'
    # Set default to be a list
    try:
        FieldAttribute(isa='string', required=True, default=['default list'])
    except TypeError:
        pass


# TODO: replace this with some generic class that can be used in callbacks to check attributes?

# Generated at 2022-06-11 09:39:36.069125
# Unit test for constructor of class Attribute
def test_Attribute():
    # Does the constructor work as expected?
    attribute = Attribute(isa='test', private='test', default='test', required='test', listof='test', priority='test', class_type='test', always_post_validate='test', inherit='test', alias='test')
    assert attribute.isa == 'test'
    assert attribute.private == 'test'
    assert attribute.default == 'test'
    assert attribute.required == 'test'
    assert attribute.listof == 'test'
    assert attribute.priority == 'test'
    assert attribute.class_type == 'test'
    assert attribute.always_post_validate == 'test'
    assert attribute.inherit == 'test'
    assert attribute.alias == 'test'

# Generated at 2022-06-11 09:39:48.921682
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='dict')
    assert field.isa == 'dict'
    assert field.private == False
    assert field.default == None
    assert field.required == False
    assert field.listof == None
    assert field.priority == 0
    assert field.class_type == None
    assert field.always_post_validate == False
    assert field.inherit == True
    field = FieldAttribute(isa='dict', private=True, default={}, required=True, listof='list', priority=1, class_type='list')
    assert field.isa == 'dict'
    assert field.private == True
    assert field.default == {}
    assert field.required == True
    assert field.listof == 'list'
    assert field.priority == 1
    assert field.class_type == 'list'

# Generated at 2022-06-11 09:39:57.448874
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='str', default='foobar')
    assert fa.isa == 'str'
    assert fa.default == 'foobar'
    assert fa.required
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None

    fa = FieldAttribute(isa='str', default='foobar', required=False)
    assert fa.isa == 'str'
    assert fa.default == 'foobar'
    assert not fa.required
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True


# Generated at 2022-06-11 09:40:08.700643
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #test data
    isa = "test_isa"
    private = "test_private"
    default = "test_default"
    required = "test_required"
    listof = "test_listof"
    priority = "test_priority"
    class_type = "test_class_type"
    always_post_validate = "test_always_post_validate"
    inherit = "test_inherit"
    alias = "test_alias"

    #test call
    field_attribute = FieldAttribute(isa=isa, private=private, default=default, required=required,\
                            listof=listof, priority=priority, class_type=class_type,\
                            always_post_validate=always_post_validate, inherit=inherit, alias=alias)

    assert field_attribute

# Generated at 2022-06-11 09:40:14.709775
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_a = Attribute(isa='str', default='foo')
    attr_b = Attribute(isa='str', default='foo')
    assert attr_a == attr_b, 'Attribute: equality operator failed'
    assert attr_a >= attr_b, 'Attribute: greater than or equal to operator failed'
    assert attr_a <= attr_b, 'Attribute: less than or equal to operator failed'

# Generated at 2022-06-11 09:40:22.293575
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import inspect

    # Verify FieldAttribute does not accept mutable default values for containers
    for member, attr in inspect.getmembers(FieldAttribute):
        # Skip constructor
        if member == '__init__':
            continue

        # Skip members which are not Fields
        if not isinstance(attr, FieldAttribute):
            continue

        if attr.isa in _CONTAINERS and attr.default is not None and not callable(attr.default):
            raise TypeError('defaults of type %s for FieldAttribute %s must be callable, got %s instead' % (attr.isa, member, type(attr.default)))

test_FieldAttribute()

# Generated at 2022-06-11 09:40:31.710189
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test the default values
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

    # Test with all the parameters set to a different value

# Generated at 2022-06-11 09:40:32.261631
# Unit test for constructor of class Attribute
def test_Attribute():
    pass

# Generated at 2022-06-11 09:40:45.158246
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test with boolean default
    attr = Attribute(default=True)
    assert attr.default == True

    # Test with non-boolean default
    attr = Attribute(default='test')
    assert attr.default == 'test'

    # Test with callable default
    attr = Attribute(default=lambda: True)
    assert attr.default == True

    # Test with mutable non-callable default
    try:
        attr = Attribute(default=[])
    except TypeError:
        assert True
    else:
        assert False, 'TypeError not raised'



# Generated at 2022-06-11 09:40:55.867820
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(isa=1).isa == 1
    assert Attribute(private=True).private == True
    assert Attribute(default=1).default == 1
    assert Attribute(required=True).required == True
    assert Attribute(listof=1).listof == 1
    assert Attribute(priority=1).priority == 1
    assert Attribute(class_type=1).class_type == 1
    assert Attribute(always_post_validate=True).always_post_validate == True
    assert Attribute(inherit=True).inherit == True
    assert Attribute(alias='new_name').alias == 'new_name'
    assert Attribute(extend=True).extend == True
    assert Attribute(prepend=True).prepend == True
    assert Attribute(static=True).static == True


# Generated at 2022-06-11 09:40:56.626593
# Unit test for constructor of class Attribute
def test_Attribute():
    # calling Attribute class constructor and assigning the result to attribute1
    attribute1 = Attribute()


# Generated at 2022-06-11 09:40:58.539576
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='bool');
    assert attr.isa == 'bool'


# Generated at 2022-06-11 09:41:05.956733
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute()
    a2 = Attribute(isa='int')
    a3 = Attribute(isa='int',
                   private=False,
                   default=None,
                   required=False,
                   listof=None,
                   priority=0,
                   class_type=None,
                   always_post_validate=False,
                   inherit=True,
                   alias=None,
                   extend=False,
                   prepend=False,
                   static=False)
    assert a1 == a2
    assert a1 == a3



# Generated at 2022-06-11 09:41:10.048834
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(
        isa='list',
        private=False,
        default=None,
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None
    )

# Generated at 2022-06-11 09:41:15.608575
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(
        isa='list',
        private=False,
        default=list,
        required=False,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='test_alias',
        extend=True,
        prepend=False,
        static=True,
    )


# Generated at 2022-06-11 09:41:25.768538
# Unit test for constructor of class Attribute
def test_Attribute():
    # isa tests
    Attribute(isa='boolean')
    Attribute(isa='integer')
    Attribute(isa='float')
    Attribute(isa='string')
    Attribute(isa='list')
    Attribute(isa='dict')
    Attribute(isa='set')

    Attribute(isa='int')
    Attribute(isa='str')
    Attribute(isa='unicode')
    Attribute(isa='bool')

    Attribute(isa='ansible.module_utils.basic.AnsibleModule')
    Attribute(isa='ansible.module_utils.basic.AnsibleModule')

    # listof tests
    Attribute(isa='list', listof='int')
    Attribute(isa='list', listof='string')
    Attribute(isa='list', listof='boolean')

   

# Generated at 2022-06-11 09:41:27.734404
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute_instance = FieldAttribute(isa='list', default='none', listof='dict')
    assert field_attribute_instance.isa == 'list'
    assert field_attribute_instance.default == 'none'
    assert field_attribute_instance.listof == 'dict'


# Generated at 2022-06-11 09:41:39.883553
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def _test_Attribute(a):
        assert a.isa == 'bool'
        assert a.private == False
        assert a.default == True
        assert a.required == True
        assert a.listof == None
        assert a.priority == 0
        assert a.class_type == None
        assert a.always_post_validate == False
        assert a.inherit == True
        assert a.alias == None
        assert a.extend == False
        assert a.prepend == False
        assert a.static == False

    def _test_Attribute_private(a):
        assert a.isa == 'bool'
        assert a.private == True
        assert a.default == True
        assert a.required == True
        assert a.listof == None
        assert a.priority == 0

# Generated at 2022-06-11 09:41:54.950733
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("test_FieldAttribute")
    field = FieldAttribute(isa='str', default='foo', required=True, priority=42)
    assert field.isa == 'str'
    assert field.private == False
    assert field.default == 'foo'
    assert field.required == True
    assert field.priority == 42


# Generated at 2022-06-11 09:42:01.990509
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(default='b')
    assert a.default == 'b'
    assert a.private == False
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-11 09:42:05.293386
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Unit test for constructor of class FieldAttribute
    """
    attr = FieldAttribute()
    assert attr is not None

# Generated at 2022-06-11 09:42:11.603809
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute.__init__(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    ) == None


# Generated at 2022-06-11 09:42:18.827703
# Unit test for constructor of class Attribute
def test_Attribute():
    valid_args = ['str', 'list', 'dict', 'set', 'module_defaults', 'hash', 'bool', 'raw', 'cli']
    for _arg in valid_args:
        a = Attribute(isa=_arg)
        assert a.isa == _arg

    b = Attribute(isa='str', private=False)
    assert b.private == False
    assert b.default == None
    assert b.required == False
    assert b.listof == None
    assert b.priority == 0
    assert b.class_type == None
    assert b.always_post_validate == False
    assert b.inherit == True

    c = Attribute(isa='str', default='foo', required=True, always_post_validate=True, inherit=False)
    assert c.default == 'foo'
   

# Generated at 2022-06-11 09:42:29.461588
# Unit test for constructor of class Attribute
def test_Attribute():

    def new_attribute():
        return Attribute(
            isa='password',
            default='',
            required=False,
            listof=None,
            priority=0,
            class_type=None,
            always_post_validate=False,
            inherit=True,
            alias=None,
            extend=False,
            prepend=False,
        )

    attribute = new_attribute()
    assert attribute.isa == 'password'
    assert attribute.private is False
    assert attribute.default == ''
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type is None
    assert attribute.always_post_validate is False
    assert attribute.inherit is True
    assert attribute.alias is None
    assert attribute.extend is False

# Generated at 2022-06-11 09:42:39.688877
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    class Foo(AnsibleBaseYAMLObject):
        def __init__(self, foo=None):
            self.foo = foo
        def __repr__(self):
            return 'Foo(foo=%r)' % self.foo

    data = StringIO("""
    foo:
      foo: default
    bar:
      bar: bar bar bar
    """)
    yaml = AnsibleLoader(data, 'test_data')
    attr = FieldAttribute(isa='str', default='default', inherit=True)
    setattr(Foo, 'foo', attr)

# Generated at 2022-06-11 09:42:40.512693
# Unit test for constructor of class Attribute
def test_Attribute():
    obj = Attribute(isa='foo')


# Generated at 2022-06-11 09:42:46.958830
# Unit test for constructor of class Attribute
def test_Attribute():
    # No args.
    a = Attribute()
    assert not a.isa
    assert not a.private
    assert not a.default
    assert not a.required
    assert not a.listof
    assert not a.priority
    assert not a.class_type
    assert not a.always_post_validate
    assert a.inherit
    assert not a.alias
    assert not a.extend

    # All args.

# Generated at 2022-06-11 09:42:50.554111
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(default={})
    except TypeError as e:
        assert str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'



# Generated at 2022-06-11 09:43:22.325370
# Unit test for constructor of class Attribute
def test_Attribute():
        a = Attribute(isa=None, private=False, default=None, required=False,
                listof=None, priority=0, class_type=None, always_post_validate=False,
                inherit=True, alias=None)
        assert a.isa == None
        assert a.private == False
        assert a.default == None
        assert a.required == False
        assert a.listof == None
        assert a.priority == 0
        assert a.class_type == None
        assert a.always_post_validate == False
        assert a.inherit == True
        assert a.alias == None

# Generated at 2022-06-11 09:43:23.894434
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    obj = FieldAttribute()
    assert obj.isa == None


# Generated at 2022-06-11 09:43:26.962100
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    attr = Attribute(isa='dict', required=True, inherit=False)
    a = AnsibleBaseYAMLObject()
    assert a._attributes == dict(data=attr)

# Generated at 2022-06-11 09:43:32.253589
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    field_attribute = FieldAttribute(isa="string", private=False, default=None, required=False)
    assert hasattr(field_attribute, 'isa') and field_attribute.isa == "string"
    assert hasattr(field_attribute, 'private') and field_attribute.private == False
    assert hasattr(field_attribute, 'default') and field_attribute.default == None
    assert hasattr(field_attribute, 'required') and field_attribute.required == False

# Generated at 2022-06-11 09:43:38.535179
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-11 09:43:43.413470
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.utils.display import Display
    from ansible.inventory.host import Host
    from ansible import constants as C

    display = Display()
    h = Host(name='foobar', port=22)
    h.set_variable('groups', ['all', 'group1', 'ungrouped'])

    display.display('test_FieldAttribute')
    display.display(h.vars)



# Generated at 2022-06-11 09:43:47.911877
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(
        static=False,
        listof=None,
        prepend=False,
        extend=False,
        inherit=True,
        alias=None,
        isa='list',
        private=False,
        required=False,
        default=[],
        priority=0,
        always_post_validate=False,
        class_type=None,
    )

# Generated at 2022-06-11 09:43:57.212336
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    This is a simple unit test for class Attribute.
    """

    # test constructor of class Attribute
    test_dict = {
        'isa': 'dict',
        'private': True,
        'default': {'this': 'dict'},
        'required': False,
        'listof': 'dict',
        'priority': 5,
        'class_type': 'this is a class',
        'always_post_validate': False,
        'inherit': True,
        'alias': 'dict_alias'
    }
    attr = Attribute(**test_dict)
    for key, value in test_dict.items():
        if getattr(attr, key) != value:
            raise Exception('Attribute constructor failed to create a class object with key %s and value %s' % (key, value))

# Generated at 2022-06-11 09:44:07.125478
# Unit test for constructor of class Attribute
def test_Attribute():
   a = Attribute(isa='test', private=True, default='default', required=True, listof='list', priority=10, class_type='class', always_post_validate=True, inherit=False, alias='test', extend=True, prepend=True, static=True)
   assert a.isa == 'test', 'isa should be test, got %s' % a.isa
   assert a.private == True, 'private should be True, got %s' % a.private
   assert a.default == 'default', 'default should be default, got %s' % a.default
   assert a.required == True, 'required should be True, got %s' % a.required
   assert a.listof == 'list', 'listof should be list, got %s' % a.listof

# Generated at 2022-06-11 09:44:16.436465
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa == None
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False


# Generated at 2022-06-11 09:45:06.883924
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa="str", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert isinstance(a, FieldAttribute)



# Generated at 2022-06-11 09:45:17.221232
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str')
    b = Attribute(isa='str')
    c = Attribute(isa='str', private=True)
    d = Attribute(isa='str', default='val')
    e = Attribute(isa='str', required=True)
    f = Attribute(isa='str', listof='str')
    g = Attribute(isa='str', class_type=str)
    h = Attribute(isa='str', always_post_validate=True)
    i = Attribute(isa='str', inherit=False)
    j = Attribute(isa='str', alias='alias')
    k = Attribute(isa='str', extend=True)
    l = Attribute(isa='str', prepend=True)
    m = Attribute(isa='str', priority=10)


# Generated at 2022-06-11 09:45:22.258949
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa = 'dict',
        private = False,
        default = None,
        required = False,
        listof = None,
        priority = 0,
        class_type = None,
        always_post_validate = False,
        inherit = True,
        alias = None,
        extend = False,
        prepend = False,
        static = False,
    )

# Generated at 2022-06-11 09:45:24.065391
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list', default=list)
    assert f.default == list


# Generated at 2022-06-11 09:45:32.795049
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', default=None, required=True, listof="dict")
    assert a.isa == 'list'
    assert a.default is None
    assert a.required == True
    assert a.listof == "dict"

    try:
        a = Attribute(isa='list', default=dict(), required=True, listof="dict")
        raise Exception('should have thrown an error about mutable container')
    except TypeError:
        pass

    def def_func(): return dict()
    a = Attribute(isa='list', default=def_func, required=True, listof="dict")
    assert a.isa == 'list'
    assert a.default is def_func
    assert a.required == True
    assert a.listof == "dict"


FieldAttribute = Attribute

# Generated at 2022-06-11 09:45:34.149080
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='complex')
    assert attr


# Generated at 2022-06-11 09:45:36.493154
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    desc = "The role attribute declares the role that is required"
    attrib = FieldAttribute(isa='string', description=desc, inherited=False)


# Generated at 2022-06-11 09:45:45.592660
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # default
    fa = FieldAttribute()
    assert fa.isa is None
    assert not fa.private
    assert fa.default is None
    assert not fa.required
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert not fa.always_post_validate
    assert fa.inherit
    assert fa.alias is None
    assert not fa.extend
    assert not fa.prepend

    # non-default

# Generated at 2022-06-11 09:45:56.104048
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test for desc

    for a in [Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False),
              Attribute(isa='int', private=False, default=None, required=True, listof=None, priority=1, class_type=None, always_post_validate=True, inherit=False, alias=None, extend=False, prepend=False)]:
        assert a.isa == 'int'
        assert a.private == False
        assert a.default == None
        assert a.required == True
        assert a.listof == None
        assert a.priority == 1
        assert a.class_type == None

# Generated at 2022-06-11 09:46:04.831755
# Unit test for constructor of class Attribute
def test_Attribute():
    name = 'name'
    isa = 'isa'
    private = 'private'
    default = 'default'
    required = 'required'
    listof = 'listof'
    priority = 'priority'
    class_type = 'class_type'
    always_post_validate = 'always_post_validate'
    inherit = 'inherit'
    alias = 'alias'
    extend = 'extend'
    prepend = 'prepend'
    static = 'static'
    isa = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend,  prepend, static)
    
    assert isa.isa == isa
    assert isa.private == private
    assert isa.default == default