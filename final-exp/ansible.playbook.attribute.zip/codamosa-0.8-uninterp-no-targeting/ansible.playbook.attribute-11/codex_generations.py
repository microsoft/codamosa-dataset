

# Generated at 2022-06-21 00:01:09.138140
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1 == Attribute(priority=1)
    assert attribute2 > Attribute(priority=1)
    assert attribute1 < Attribute(priority=2)
    assert attribute1 <= Attribute(priority=2)
    assert attribute1 != Attribute(priority=2)
    assert attribute2 >= Attribute(priority=1)


# Generated at 2022-06-21 00:01:11.386058
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert FieldAttribute(priority = 1).__ne__(FieldAttribute(priority=1)) == False



# Generated at 2022-06-21 00:01:14.806045
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    obj1 = Attribute()
    obj2 = Attribute()
    obj2.priority = 1
    assert (not obj1 <= obj2)
    obj2.priority = 0
    assert (obj1 <= obj2)


# Generated at 2022-06-21 00:01:18.303217
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__ge__(attr)



# Generated at 2022-06-21 00:01:24.890692
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(isa='foo', private=False, default=None,
                      required=False, listof=None, priority=1,
                      class_type=None, always_post_validate=False)
    attr2 = Attribute(isa='foo', private=False, default=None,
                      required=False, listof=None, priority=2,
                      class_type=None, always_post_validate=False)
    assert attr1.__ge__(attr2)


# Generated at 2022-06-21 00:01:28.615526
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    import types
    attr = Attribute()
    attr.__eq__ = types.MethodType(lambda self: True, attr)
    assert attr.__eq__.__self__


# Generated at 2022-06-21 00:01:33.586531
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    def f():
        pass
    a = Attribute(default=f)
    b = Attribute(default=f, priority=2)
    c = Attribute(default=f, priority=0)
    assert not (a <= b)
    assert not (b <= a)
    assert a <= c
    assert not (c <= a)



# Generated at 2022-06-21 00:01:44.914868
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test with isa=list
    print('Test with isa=list')
    attr1 = Attribute(isa='list', priority=0)
    attr2 = Attribute(isa='list', priority=1)
    compare_value = attr1 >= attr2
    assert(compare_value==False)
    print('compare_value=', compare_value)

    # Test with isa=int
    print('Test with isa=int')
    attr1 = Attribute(isa='int', priority=0)
    attr2 = Attribute(isa='int', priority=1)
    compare_value = attr1 >= attr2
    assert(compare_value==False)
    print('compare_value=', compare_value)



# Generated at 2022-06-21 00:01:48.935633
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """
    Unit test for method __gt__ of class Attribute
    """
    class AttributeTest(Attribute):
        pass

    attr = AttributeTest()

    attr2 = AttributeTest()
    attr2.priority = 2

    assert attr > attr2



# Generated at 2022-06-21 00:01:56.556146
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute(isa='dict', private=False, default=None, required=True,
                          listof=None, priority=0, class_type=None,
                          always_post_validate=False, inherit=True, alias=None,
                          extend=False, prepend=False)

    assert isinstance(attribute, Attribute)

    # Check types
    assert attribute.isa == 'dict'
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == True
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True
    assert attribute.alias == None
    assert attribute.extend == False
    assert attribute.prepend == False



# Generated at 2022-06-21 00:01:59.677906
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute()
    attribute1.priority = 1
    attribute2 = Attribute()
    attribute2.priority = 2
    print(attribute1 < attribute2)



# Generated at 2022-06-21 00:02:01.980498
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__ge__(attr1)


# Generated at 2022-06-21 00:02:07.732576
# Unit test for constructor of class Attribute
def test_Attribute():
    default_list = [1, 2, 3]
    attr1 = Attribute(default=default_list)
    # The callable() checks the constructor uses a copy of the default argument.
    assert callable(attr1.default)
    assert attr1.default() == default_list
    assert attr1.default() is not default_list


# Generated at 2022-06-21 00:02:09.485004
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute(isa='int', required=True)
    assert attribute

# Generated at 2022-06-21 00:02:12.188857
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = Attribute(isa=dict, default={}, required=True, priority=1)
    assert attr.isa == dict
    assert attr.required == True



# Generated at 2022-06-21 00:02:19.267583
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test 1 - isa set to a string
    arg_isa = 'str'
    arg_private = False
    arg_default = None
    arg_required = False
    arg_listof = None
    arg_priority = 0
    arg_class_type = None
    arg_always_post_validate = False
    arg_inherit = True
    arg_alias = None
    arg_extend = False
    arg_prepend = False
    arg_static = False


# Generated at 2022-06-21 00:02:25.584461
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(private=False, default=None, required=False, listof=None, priority=0, class_type=None,
                                     always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False,
                                     isa='string')
    assert field_attribute.isa == 'string'

# Generated at 2022-06-21 00:02:27.673986
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(isa='list', priority=0)
    attr2 = Attribute(isa='list', priority=-1)
    assert attr1.__gt__(attr2)
    assert not attr2.__gt__(attr1)
    assert not attr1.__gt__(attr1)


# Generated at 2022-06-21 00:02:29.168488
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)
    assert (attr1 > attr2)
    assert not (attr2 > attr1)
    assert not (attr1 > attr3)



# Generated at 2022-06-21 00:02:32.235944
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # simple test
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=10)
    assert a1 < a2


# Generated at 2022-06-21 00:02:38.310531
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=1)
    d = Attribute(priority=2)

    assert (b <= a) != True
    assert (a <= a) == True
    assert (a <= b) != True
    assert (b <= c) == True
    assert (b <= d) != True


# Generated at 2022-06-21 00:02:43.886189
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    p0 = FieldAttribute(priority=0)
    p1 = FieldAttribute(priority=1)
    p2 = FieldAttribute(priority=1)

    # should return true when priority is different
    assert (p1 != p0)
    # should return false when priority is the same
    assert not (p2 != p1)



# Generated at 2022-06-21 00:02:48.085305
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(
        isa='str',
        private=True,
        default='test',
        required=True,
        listof='str',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
    )

    assert hasattr(attr, 'isa') == True
    assert hasattr(attr, 'private') == True
    assert hasattr(attr, 'default') == True
    assert hasattr(attr, 'required') == True
    assert hasattr(attr, 'listof') == True
    assert hasattr(attr, 'priority') == True
    assert hasattr(attr, 'class_type') == True
    assert hasattr(attr, 'always_post_validate') == True

# Generated at 2022-06-21 00:02:52.943993
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert(a == a)
    assert(b == b)
    assert(a != b)
    #assert(b != a) # assert failed, but should not!


# Generated at 2022-06-21 00:02:53.582258
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()

# Generated at 2022-06-21 00:03:03.158563
# Unit test for constructor of class Attribute
def test_Attribute():

    field = Attribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None
    assert field.extend is False
    assert field.prepend is False
    assert field.static is False

    field = Attribute(isa='integer')
    assert field.isa == 'integer'
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None

# Generated at 2022-06-21 00:03:05.943778
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()
    attr2 = Attribute()
    attr2.priority = 1
    assert(attr < attr2)


# Generated at 2022-06-21 00:03:09.627969
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 3)
    b = Attribute(priority = 5)
    c = Attribute(priority = 3)
    assert a >= b
    assert a >= c



# Generated at 2022-06-21 00:03:14.452512
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(default=True, priority=1)
    b = Attribute(default=None, priority=0)
    assert a.__le__(b) == True 
    assert a.__le__(a) == True
    assert b.__le__(a) == False

# Generated at 2022-06-21 00:03:16.931276
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=1)
    other = Attribute(priority=2)

    assert attr >= other


# Generated at 2022-06-21 00:03:24.865878
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # normal
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1.__gt__(attribute2) is False
    assert attribute2.__gt__(attribute1) is True



# Generated at 2022-06-21 00:03:28.397201
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = FieldAttribute(priority=5)
    attr2 = FieldAttribute(priority=10)
    res = attr1.__gt__(attr2)
    assert res == False



# Generated at 2022-06-21 00:03:33.853512
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = None
    private = False
    default = None
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    test_attr = Attribute(isa, private, default, required, listof,
                          priority, class_type, always_post_validate,
                          inherit, alias, extend, prepend, static)

    assert test_attr.isa == None
    assert test_attr.private == False
    assert test_attr.default == None
    assert test_attr.required == False
    assert test_attr.listof == None
    assert test_attr.priority == 0
    assert test_attr.class_type == None
   

# Generated at 2022-06-21 00:03:37.468367
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute1 = Attribute(priority=100)
    attribute2 = Attribute(priority=100)
    assert attribute1 != attribute2

    attribute3 = Attribute(priority=101)
    assert attribute1 != attribute3


# Generated at 2022-06-21 00:03:41.306895
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(isa='str', priority=1)
    attr2 = Attribute(isa='str', priority=2)
    assert attr1 < attr2
    assert not attr2 < attr1

# Generated at 2022-06-21 00:03:44.517186
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2 > attr1



# Generated at 2022-06-21 00:03:47.764972
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=2)
    print(a < b)



# Generated at 2022-06-21 00:03:51.312584
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__gt__(attr2) is False
    assert attr2.__gt__(attr1) is True

# Generated at 2022-06-21 00:03:53.450471
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)

# Generated at 2022-06-21 00:03:55.601057
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()


# Example usage of class FieldAttribute

# Generated at 2022-06-21 00:04:08.116851
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleModuleError

    fa = FieldAttribute(isa='dict')
    assert fa.private == False
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False
    assert fa.static == False


# Generated at 2022-06-21 00:04:19.741669
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    assert FieldAttribute().private is False
    assert FieldAttribute().default is None
    assert FieldAttribute().required is False
    assert FieldAttribute().listof is None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type is None
    assert not FieldAttribute().always_post_validate
    assert FieldAttribute().inherit is True
    assert FieldAttribute().alias is None
    assert not FieldAttribute().extend
    assert not FieldAttribute().prepend
    assert not FieldAttribute().static


# Generated at 2022-06-21 00:04:21.068210
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert (a != b) == (not (a == b))


# Generated at 2022-06-21 00:04:25.163139
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Create an Attribute with a priority of 1
    attr1 = Attribute(priority=1)
    # Create an Attribute with a priority of 2
    attr2 = Attribute(priority=2)
    # __lt__ should return True for attr1 and attr2
    assert attr1 < attr2


# Generated at 2022-06-21 00:04:27.700638
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    at1 = Attribute()
    at1.priority = 1
    at2 = Attribute()
    at2.priority = 2
    assert at1 < at2
    assert at2 > at1



# Generated at 2022-06-21 00:04:28.215577
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()

# Generated at 2022-06-21 00:04:29.153007
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    pass


# Generated at 2022-06-21 00:04:34.492747
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2
    assert not attr2 <= attr1


# Generated at 2022-06-21 00:04:38.361310
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field1 = Attribute(isa='list', priority=0)
    field2 = Attribute(isa='list', priority=2)
    f3 = Attribute(isa='list', priority=1)
    assert field1 < field2
    assert f3 < field2
    assert not field2 < f3


# Generated at 2022-06-21 00:04:41.409150
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2


# Generated at 2022-06-21 00:04:54.588773
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 > attr2

# Generated at 2022-06-21 00:04:56.420866
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=2) <= Attribute(priority=2)


# Generated at 2022-06-21 00:04:59.145112
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)

    assert attr2 < attr1


# Generated at 2022-06-21 00:05:02.546702
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    # definition of a class to test __ge__ method
    class TestAtt:
        def __init__(self, priority):
            self.priority = priority

    # creation of two instances of the class
    att1 = TestAtt(0)
    att2 = TestAtt(1)

    # test the __ge__ method
    assert att1.__ge__(att2) is False
    assert att2.__ge__(att1) is True
    assert att2.__ge__(att2) is True



# Generated at 2022-06-21 00:05:03.948508
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=5)
    b = Attribute(priority=10)
    assert (b > a)



# Generated at 2022-06-21 00:05:07.398986
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a.__ne__(b) != True:
        return False
    return True



# Generated at 2022-06-21 00:05:09.307759
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute
    assert a.__ne__(Attribute) == False


# Generated at 2022-06-21 00:05:12.873727
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', inherit=True, static=False)
    assert a.isa == "list"
    assert a.inherit == True
    assert a.static == False
    assert a.private == False

# Generated at 2022-06-21 00:05:14.810997
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a.__ne__(b)


# Generated at 2022-06-21 00:05:16.792211
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    assert attr == Attribute(priority=0)


# Generated at 2022-06-21 00:05:32.626101
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test that __ge__ works as expected.
    a_0 = Attribute(priority=0)
    a_1 = Attribute(priority=1)
    b_0 = Attribute(priority=0)

    assert not (a_0 >= a_1)
    assert a_0 >= b_0
    assert a_1 >= b_0



# Generated at 2022-06-21 00:05:34.236347
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    return a != b



# Generated at 2022-06-21 00:05:36.811287
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2
    assert not (attr2 <= attr1)


# Generated at 2022-06-21 00:05:38.565056
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().__le__(Attribute())


# Generated at 2022-06-21 00:05:39.863975
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    first = Attribute(priority = 8)
    second = Attribute(priority = 3)
    assert (first >= second)


# Generated at 2022-06-21 00:05:44.962012
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(isa=int, priority=0)
    attr2 = Attribute(isa=int, priority=1)
    if attr2.__gt__(attr1):
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-21 00:05:52.033804
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', listof='str', default=None, required=False)
    assert a is not None
    assert a.isa == 'list'
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof == 'str'
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False



# Generated at 2022-06-21 00:05:53.453639
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert (Attribute() == Attribute())



# Generated at 2022-06-21 00:06:05.307814
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    # in case of empty default, default must be None
    a = Attribute(default={})
    assert a.default is not None
    # in case of string or callable, default could be anything
    a = Attribute(default="")
    assert a.default == ""
    a = Attribute(default=())
    assert a.default == ()
    a = Attribute(default=1)
    assert a.default == 1


# Generated at 2022-06-21 00:06:12.813316
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test constructor of class Attribute
    a = Attribute('a')
    assert a.isa == 'a', "Isa value is not 'a'"

    b = Attribute(isa='b')
    assert b.isa == 'b', "Isa value is not 'b'"

    c = Attribute(isa='c', private=True)
    assert c.isa == 'c', "Isa value is not 'c'"
    assert c.private == True, "Private value is not 'True'"

    d = Attribute(isa='d', default='d')
    assert d.isa == 'd', "Isa value is not 'd'"
    assert d.default == 'd', "default value is not 'd'"

    e = Attribute(isa='e', required=True)
    assert e.isa == 'e', "Isa value is not 'e'"


# Generated at 2022-06-21 00:06:37.985238
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=20)
    assert attr1 < attr2

# Generated at 2022-06-21 00:06:40.976437
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    aa=Attribute(priority=5)
    bb=Attribute(priority=6)
    cc=Attribute(priority=5)
    assert aa.__ge__(bb) == True
    assert aa.__ge__(cc) == False


# Generated at 2022-06-21 00:06:48.072080
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    test = [FieldAttribute(priority = 5), FieldAttribute(priority = 2), FieldAttribute(priority = 9), FieldAttribute(priority = 7)]
    result = sorted(test)
    assert result[0].priority == 5
    assert result[1].priority == 7
    assert result[2].priority == 9
    assert result[3].priority == 2

# Generated at 2022-06-21 00:06:50.821469
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if not a1 <= a2:
        raise AssertionError("Attribute __le__ Test Failed")


# Generated at 2022-06-21 00:06:57.514966
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(alias='test_Attribute___ne____attr1')
    attr2 = Attribute(alias='test_Attribute___ne____attr2')
    attr3 = attr1
    assert(attr1 != attr2), "Attribute __ne__ failed: attr1 and attr2 are not the same"
    assert(attr1 == attr3), "Attribute __ne__ failed: attr1 and attr3 are the same"


# Generated at 2022-06-21 00:06:59.563122
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Simply call the instance method with a variety of arguments
    Attribute().__ne__(Attribute())



# Generated at 2022-06-21 00:07:09.063365
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(private=True, default='test', required=True, listof='list', priority=0, class_type='type', always_post_validate=False, inherit=True, alias='alias')
    assert attr.private == True
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'list'
    assert attr.priority == 0
    assert attr.class_type == 'type'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == 'alias'


# Generated at 2022-06-21 00:07:12.422128
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    return a.__gt__(b) is True and b.__gt__(a) is False


# Generated at 2022-06-21 00:07:21.569369
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml import objects
    import collections

    # test default isa setting
    a1 = Attribute(default='test')
    # isa should be 'str'
    assert a1.isa == 'str', a1.isa

    # test isa setting
    a2 = Attribute(isa='string', default='test')
    # isa should be 'string'
    assert a2.isa == 'string', a2.isa

    # test Container isa setting
    a3 = Attribute(isa=objects.AnsibleSequence)
    # isa should be 'list'
    assert a3.isa == 'list', a3.isa

    # test with a class type
    a4 = Attribute(isa=collections.Counter)
    # isa should be 'class'
    assert a4

# Generated at 2022-06-21 00:07:26.257790
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='string', private=False, default=None,
                          required=False, listof=None, priority=0,
                          class_type=None, always_post_validate=False,
                          inherit=True, alias=None, extend=False,
                          prepend=False)



# Generated at 2022-06-21 00:08:16.797472
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 > a1)


# Generated at 2022-06-21 00:08:21.979756
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    element1 = Attribute(isa='I am the first element', priority=3)
    element2 = Attribute(isa='I am the second element', priority=3)
    if element1 != element2:
        print('Attribute class method __ne__ OK')
    else:
        print('Attribute class method __ne__ KO')


# Generated at 2022-06-21 00:08:27.330830
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=2)

    assert a1 <= a2
    assert not a1 <= a1
    assert not a1 <= a3
    assert not a2 <= a1
    assert a2 <= a2
    assert a3 <= a2

    return True



# Generated at 2022-06-21 00:08:32.664477
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().default is None
    assert Attribute().required is False
    assert Attribute().listof is None
    assert Attribute().priority == 0
    assert Attribute().inherit is True
    assert Attribute().alias is None

    attribute = Attribute(isa='list', private=False, inherit=False, alias='foo')
    assert attribute.isa == 'list'
    assert attribute.private is False
    assert attribute.inherit is False
    assert attribute.alias == 'foo'



# Generated at 2022-06-21 00:08:38.846992
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    ret = a.__ne__(b)
    print("type(ret): %s" % type(ret))
    print("value of ret: %s" % ret)

if __name__ == "__main__":
    test_Attribute___ne__()

# Generated at 2022-06-21 00:08:42.980691
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=2)

    assert c > b
    assert not b > c
    assert b > a
    assert not a > b
    assert not a > c
    assert not c > a



# Generated at 2022-06-21 00:08:46.361007
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1, required=True)
    a2 = Attribute(priority=1, required=True)
    assert a1 == a2



# Generated at 2022-06-21 00:08:49.376447
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=20)
    assert a2 < a1


# Generated at 2022-06-21 00:08:59.689151
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(required=True)
    attr = Attribute(required=True, isa='dict')
    attr = Attribute(required=True, isa='dict', default=dict)
    attr = Attribute(required=True, isa='dict', default=dict, inherit=False)
    attr = Attribute(required=True, isa='dict', default=dict, inherit=True)

    # test inherit

    att = Attribute(default=dict)
    assert att.inherit

    att = Attribute(default=dict, inherit=False)
    assert att.inherit is False

    att = Attribute(default=dict, inherit=True)
    assert att.inherit is True

    # test always_post_validate

    att = Attribute()
    assert att.always_post_

# Generated at 2022-06-21 00:09:03.880990
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """
    Function to test __eq__

    Returns:
      None

    """
    a1 = Attribute(required=True)
    a2 = Attribute(required=True)

    assert a1 == a2


# Generated at 2022-06-21 00:10:59.367090
# Unit test for constructor of class Attribute
def test_Attribute():
#Case 1 :
    try:
        a = Attribute(default=[])
    except Exception as e:
        print(e)

#Case 2 :
    try:
        a = Attribute(default=copy([]))
    except Exception as e:
        print(e)

#Case 3 :
    try:
        a = Attribute(default=deepcopy([]))
    except Exception as e:
        print(e)

#Case 4 :
    a = Attribute(default=lambda: None)
    print(a)

#Case 5 :
    a = Attribute()
    print(a)


if __name__ == "__main__":
    test_Attribute()

# Generated at 2022-06-21 00:11:03.140164
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)

    try:
        assert a > b
    except:
        raise AssertionError('Attribute __gt__ method failed')

