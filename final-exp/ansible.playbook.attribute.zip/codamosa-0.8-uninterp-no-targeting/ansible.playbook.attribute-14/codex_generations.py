

# Generated at 2022-06-21 00:01:12.347594
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    '''
    Unit test for method __le__ of class Attribute
    '''
    attribute_object = Attribute()

    # __le__ of Attribute returns True if priority of attributes are equal
    assert attribute_object.__le__(attribute_object) == True

    # __le__ of Attribute returns True if priority of attributes is less than
    assert attribute_object.__le__(Attribute(priority = 1)) == True

    # __le__ of Attribute returns False if priority of attributes is greater than
    assert attribute_object.__le__(Attribute(priority=-1)) == False



# Generated at 2022-06-21 00:01:24.891245
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'set'
    private = True
    default = 'default'
    required = True
    listof = 'list'
    priority = 0
    class_type = 'class_type'
    always_post_validate = True
    inherit = False
    alias = 'alias'
    extend = True
    prepend = False
    static = False

    attribute = Attribute(isa, private, default, required, listof, priority, class_type, always_post_validate, inherit, alias, extend, prepend, static)

    assert attribute.isa == isa
    assert attribute.private == private
    assert attribute.default == default
    assert attribute.required == required
    assert attribute.listof == listof
    assert attribute.priority == priority
    assert attribute.class_type == class_type
    assert attribute.always_post

# Generated at 2022-06-21 00:01:32.167319
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # this test is added to cover a case where we have a failing test like:
    # assert not Attribute() >= Attribute()
    # where we might think a type error should be raised, but __ge__ is defined
    # in the class and that is enough to stop python from raising the error,
    # and the assert statement evaluates to false and we get a 'None' back from
    # the assert statement (which causes the test to fail)
    assert not Attribute() >= Attribute()

# Generated at 2022-06-21 00:01:35.150302
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute01 = Attribute(priority=0)
    attribute02 = Attribute(priority=1)
    assert attribute02 > attribute01
    assert not attribute01 > attribute02
    assert not attribute02 > attribute02



# Generated at 2022-06-21 00:01:41.596723
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    assert a >= a
    assert not a > a
    assert not a < a
    assert a <= a
    assert not a < a
    assert not a > a
    a1 = Attribute(priority=1)
    assert a >= a1
    a2 = Attribute(priority=2)
    assert not a >= a2
    assert a <= a2


# Generated at 2022-06-21 00:01:52.197684
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=30, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    b = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=40, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    c = Attribute(isa='dict', private=False, default=None, required=False, listof=None, priority=10, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

# Generated at 2022-06-21 00:01:56.028376
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    testA = Attribute(priority = 0)
    testB = Attribute(priority = 1)
    result = testA == testB
    assert result == False


# Generated at 2022-06-21 00:02:00.506123
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=100)
    assert attr1.__gt__(attr2) == False
    assert attr2.__gt__(attr1) == True



# Generated at 2022-06-21 00:02:03.464885
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_Attribute = Attribute(1)
    test_Attribute2 = Attribute(2)
    return test_Attribute.__ne__(test_Attribute2)



# Generated at 2022-06-21 00:02:09.711221
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private == False
    assert field.default is None
    assert field.required == False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias is None

# Generated at 2022-06-21 00:02:13.592033
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    assert (Attribute(priority=10) == Attribute(priority=10)) == True
    assert (Attribute(priority=10) == Attribute(priority=5)) == False



# Generated at 2022-06-21 00:02:17.493284
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class test_1(object):
            test = FieldAttribute(default=1, required=False)
            def __init__(self, test=None):
                self.test = test
    t = test_1()
    assert t.test == 1


# Generated at 2022-06-21 00:02:19.894049
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert (b >= a)


# Generated at 2022-06-21 00:02:23.105844
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    import pytest
    assert Attribute(priority=0) < Attribute(priority=1)
    assert not Attribute(priority=1) < Attribute(priority=0)


# Generated at 2022-06-21 00:02:24.604981
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    FA1 = FieldAttribute(priority=0)
    FA2 = FieldAttribute(priority=1)
    assert FA1 < FA2
    assert not FA1 > FA2
    assert not FA1 == FA2
    assert FA1 != FA2

# Generated at 2022-06-21 00:02:28.799063
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    not_lt = Attribute(priority=3)
    lt = Attribute(priority=2)
    result = not_lt <= lt
    assert result, 'test_Attribute___le__ assert#1 has failed'



# Generated at 2022-06-21 00:02:36.294047
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.isa is None
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None
    assert fa.extend is False
    assert fa.prepend is False
    assert fa.static is False


# Generated at 2022-06-21 00:02:39.672301
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa=str, default='', required=False)
    assert attr.isa == str
    assert attr.default == ''
    assert attr.required == False


# Generated at 2022-06-21 00:02:51.124844
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    a.priority = -1
    b.priority = -2
    print("(a.priority = %d) != (b.priority = %d) == " % (a.priority, b.priority) + str(a != b))
    a.priority = -2
    b.priority = -2
    print("(a.priority = %d) != (b.priority = %d) == " % (a.priority, b.priority) + str(a != b))
    a.priority = -3
    b.priority = -2
    print("(a.priority = %d) != (b.priority = %d) == " % (a.priority, b.priority) + str(a != b))
    a.priority = -2
    b.priority = -3
   

# Generated at 2022-06-21 00:02:58.031475
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 2
    assert a1.__ge__(a2) is False
    assert a2.__ge__(a1) is True
    a2.priority = 1
    assert a1.__ge__(a2) is True
    assert a2.__ge__(a1) is True


# Generated at 2022-06-21 00:03:10.577023
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert a1 <= a2
    assert not (a1 == a2)
    assert not (a1 > a2)
    assert not (a1 >= a2)
    assert a2 > a1
    assert a2 >= a1
    assert not (a2 == a1)
    assert not (a2 < a1)
    assert not (a2 <= a1)


# Generated at 2022-06-21 00:03:16.556353
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='boolean', private=True, default=True, required=True, listof='boolean', class_type='boolean')
    assert a.isa == 'boolean'
    assert a.private == True
    assert a.default == True
    assert a.required == True
    assert a.listof == 'boolean'
    assert a.class_type == 'boolean'

# Generated at 2022-06-21 00:03:22.251087
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print('\n----test_Attribute___ge__')

    a1 = Attribute(priority=3)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=3)
    print(a1.__ge__(a2)) # True
    print(a1.__ge__(a3)) # True



# Generated at 2022-06-21 00:03:24.735816
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    f = FieldAttribute()
    f.priority = 2
    g = FieldAttribute()
    g.priority = 3
    assert f < g


# Generated at 2022-06-21 00:03:36.534504
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    default = None
    required = False
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    field_attr = FieldAttribute(isa="boolean", private=False, default=default, required=required,
                                listof=None, priority=0, class_type=class_type,
                                always_post_validate=always_post_validate, inherit=inherit,
                                alias=alias, extend=extend, prepend=prepend, static=static)

    assert field_attr.isa == "boolean"
    assert field_attr.private == False
    assert field_attr.default == default
    assert field_attr.required == required
    assert field_attr.listof == None
   

# Generated at 2022-06-21 00:03:38.144302
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(default='default value')
    assert a.default == 'default value'

# Generated at 2022-06-21 00:03:46.662405
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test the case when priority is the same
    a1 = Attribute(priority=3, isa="list")
    a2 = Attribute(priority=3, isa="str")
    assert not a1.__gt__(a2)

    # Test the case when priority is different
    a1 = Attribute(priority=3, isa="list")
    a2 = Attribute(priority=4, isa="str")
    assert not a1.__gt__(a2)


# Generated at 2022-06-21 00:03:57.194733
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    class Foo(AnsibleBaseYAMLObject):
        def __init__(self, *args, **kwargs):
            self.bar = kwargs.pop('bar', None)
            self.baz_list = kwargs.pop('baz_list', None)
            super(Foo, self).__init__(*args, **kwargs)
            self._parent = kwargs.pop('_parent', None)


# Generated at 2022-06-21 00:04:02.503237
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_0 = FieldAttribute(priority=0)
    attr_10 = FieldAttribute(priority=10)
    assert attr_10 < attr_0
    assert attr_0 > attr_10
    assert attr_10 <= attr_0
    assert attr_0 >= attr_10
    assert attr_10 != attr_0
    assert attr_0 == attr_0


# Generated at 2022-06-21 00:04:06.204616
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1.__eq__(attr2)


# Generated at 2022-06-21 00:04:25.576469
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import os


# Generated at 2022-06-21 00:04:27.096388
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=1) != Attribute(priority=2)


# Generated at 2022-06-21 00:04:29.140949
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__eq__(attr2) == False


# Generated at 2022-06-21 00:04:34.492177
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    # The sample object
    attr = Attribute(priority=1)

    # expected value
    expected = False

    # actual value
    actual = attr.__ne__(attr)

    assert expected == actual

# Generated at 2022-06-21 00:04:37.090207
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=4)

    assert(attr1.__ge__(attr2))


# Generated at 2022-06-21 00:04:38.035432
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute


# Generated at 2022-06-21 00:04:38.581046
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    pass

# Generated at 2022-06-21 00:04:50.610687
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    src = '''
    - hosts: localhost
      tasks:
      - name: t1
        test_module_1:
          obj: "{{ some_var }}"
    '''

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    Password = None
    vault_pass = None
    connection = 'local'

# Generated at 2022-06-21 00:04:59.095509
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Check if Attribute class has __ne__ method
    # assert hasattr(Attribute, '__ne__')
    assert callable(Attribute.__ne__)

    # create an instance of Attribute class
    obj = Attribute()

    # call __ne__ method
    result = obj.__ne__("priority")
    assert result is not None
    assert isinstance(result, bool)

    # get name of __ne__ method
    name = Attribute.__ne__.__name__
    assert name == '__ne__'


# Unit test of class Attribute

# Generated at 2022-06-21 00:05:00.991765
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    f = Attribute(priority=5)
    g = Attribute(priority=10)
    assert g > f


# Generated at 2022-06-21 00:05:18.214368
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    Attribute.__le__(Attribute(priority=1), Attribute(priority=2)) == True

# Generated at 2022-06-21 00:05:24.309596
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof='dict', priority=10)
    b = Attribute(isa='list', private=False, default=None, required=False, listof='dict', priority=10)

    assert a is not b
    assert a == b
    assert not a != b
    assert not a < b
    assert not a > b
    assert a <= b
    assert a >= b

    assert a.priority == 10
    assert b.priority == 10



# Generated at 2022-06-21 00:05:26.190609
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute2 > attribute1


# Generated at 2022-06-21 00:05:29.070243
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute(priority=5)
    assert attribute >= Attribute(priority=5)
    assert not attribute >= Attribute(priority=6)
# /Unit test for method __ge__ of class Attribute



# Generated at 2022-06-21 00:05:37.953730
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create instance of class FieldAttribute
    fa = FieldAttribute(
        isa='foo',
        private=False,
        default=None,
        required=True,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )

    # Check constructor values
    assert fa.isa == 'foo'
    assert fa.private == False
    assert fa.default == None
    assert fa.required == True
    assert fa.listof == None
    assert fa.priority == 1
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa

# Generated at 2022-06-21 00:05:41.086708
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='list', listof='dict', priority=0, class_type=None)
    a2 = Attribute(isa='list', listof='dict', priority=0, class_type=None)
    a3 = Attribute(isa='list', listof='dict', priority=1, class_type=None)
    assert a1 == a2
    assert not a1 == a3


# Generated at 2022-06-21 00:05:51.502090
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    atr_1 = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                      priority=0, class_type=None, always_post_validate=False, inherit=True)
    atr_2 = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                      priority=1, class_type=None, always_post_validate=False, inherit=True)
    atr_3 = Attribute(isa='dict', private=False, default=None, required=False, listof=None,
                      priority=1, class_type=None, always_post_validate=False, inherit=True)
    if atr_2 < atr_1:
        raise AssertionError('ValueError')

# Generated at 2022-06-21 00:05:55.070035
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    attr = Attribute(isa=AnsibleUnicode)
    assert attr.isa == AnsibleUnicode

# Generated at 2022-06-21 00:05:58.890643
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute.__new__(Attribute)
    a.priority = 0
    b = Attribute.__new__(Attribute)
    b.priority = 1
    assert b < a


# Generated at 2022-06-21 00:06:02.753038
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    print('testing method __lt__')
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__lt__(b)
    print('passed test __lt__')


# Generated at 2022-06-21 00:06:33.684448
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)

    assert a <= b
    assert a == b



# Generated at 2022-06-21 00:06:36.140596
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(default=1)
    a2 = Attribute(default=2)
    assert (a1 != a2) == True


# Generated at 2022-06-21 00:06:38.909152
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 == attr2
    attr1.priority = 1
    assert not attr1 == attr2


# Generated at 2022-06-21 00:06:42.807054
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    p1 = Attribute(priority=1)
    p2 = Attribute(priority=2)

    assert p1 != p2
    assert p1 == p1


# Generated at 2022-06-21 00:06:53.432468
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute_gt = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    attribute_lt = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:06:56.101734
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    assert a < b


# Generated at 2022-06-21 00:07:07.961146
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.plugins.loader import connection_loader
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.release import __version__
    version_info = tuple(int(i) for i in __version__.split('.'))
    if version_info < (2, 6):
        from ansible import constants as C
    else:
        from ansible import context as C

    kev = FieldAttribute()
    kev.priority = 8

    if version_info < (2, 7):
        # monkeypatching
        connection_loader.get('local', class_only=True)._load_name = 'local'


# Generated at 2022-06-21 00:07:18.627152
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    import types
    from collections import Mapping
    from collections import MutableMapping
    from collections import MappingView
    from collections import KeysView
    from collections import ItemsView
    from collections import ValuesView
    from collections import OrderedDict
    from collections import defaultdict

    from collections import Sequence
    from collections import MutableSequence
    from collections import deque
    from collections import UserList
    from collections import UserString
    from collections import UserDict

    from collections import Set
    from collections import MutableSet
    from collections import Set
    from collections import MutableSet
    from collections import Hashable
    from collections import container
    from collections import Sized
    from collections import Collection
    from collections import Iterable
    from collections import Iterator
    from collections import Generator

    from collections import Callable
    from collections import AsyncIterable


# Generated at 2022-06-21 00:07:29.703753
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test init of Attribute
    a1 = Attribute()
    a2 = Attribute('int')
    a3 = Attribute(default='Default value')
    a4 = Attribute(required=True)
    a5 = Attribute(listof='int')
    a6 = Attribute(priority=30)
    a7 = Attribute(class_type=Attribute)
    a8 = Attribute(always_post_validate=True)
    a9 = Attribute(inherit=False)
    a10 = Attribute(static=True)
    for i in [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10]:
        assert isinstance(i, Attribute)
    a11 = Attribute(extend=True)
    a12 = Attribute

# Generated at 2022-06-21 00:07:33.677767
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    Test that the __lt__ method of class Attribute works properly
    '''
    a1 = Attribute(priority=1)
    assert a1 < Attribute(priority=2)



# Generated at 2022-06-21 00:08:37.999211
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # create an attribute named attribute_1
    attribute_1 = Attribute(priority=1)
    # create a second attribute named attribute_2
    attribute_2 = Attribute(priority=2)
    # assert that attribute_2 is less than attribute_1
    assert attribute_2 < attribute_1


# Generated at 2022-06-21 00:08:49.781033
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(required=True)
    attr2 = Attribute(required=True)

    assert(attr1 >= attr2)
    assert(attr1 == attr2)
    assert(not (attr1 < attr2))
    assert(attr1 <= attr2)
    assert(not (attr1 > attr2))
    assert(not (attr1 != attr2))

    attr3 = Attribute(required=True, priority=1)
    attr4 = Attribute(required=True, priority=2)

    assert(not (attr3 >= attr4))
    assert(attr3 < attr4)
    assert(attr3 <= attr4)
    assert(attr4 > attr3)
    assert(attr4 >= attr3)
    assert(attr3 != attr4)

# Generated at 2022-06-21 00:08:52.281431
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute = Attribute(priority=0)
    assert(attribute.__eq__(Attribute(priority=0)))


# Generated at 2022-06-21 00:08:58.126300
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert (Attribute() >= Attribute()) is True
    assert (Attribute(priority=1) >= Attribute(priority=1)) is True
    assert (Attribute(priority=1) >= Attribute()) is True
    assert (Attribute() >= Attribute(priority=1)) is False
    assert (Attribute(priority=1) >= Attribute(priority=2)) is False
    assert (Attribute(priority=2) >= Attribute(priority=1)) is True

# Generated at 2022-06-21 00:09:01.380767
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 <= a1)



# Generated at 2022-06-21 00:09:05.272882
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert a <= b
    assert b >= a
    assert a <= c
    assert c >= a

# Generated at 2022-06-21 00:09:07.606330
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr0 = FieldAttribute(isa='string')
    assert attr0.isa == 'string'

# Generated at 2022-06-21 00:09:16.645258
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert FieldAttribute(priority=-1) > FieldAttribute(priority=0)
    assert not FieldAttribute(priority=-1) > FieldAttribute(priority=-1)
    assert not FieldAttribute(priority=-1) > FieldAttribute(priority=-2)
    assert not FieldAttribute(priority=0) > FieldAttribute(priority=-1)
    assert not FieldAttribute(priority=0) > FieldAttribute(priority=0)
    assert FieldAttribute(priority=0) > FieldAttribute(priority=-1)
    assert not FieldAttribute(priority=0) > FieldAttribute(priority=-1)
    assert not FieldAttribute(priority=-2) > FieldAttribute(priority=-1)


# Generated at 2022-06-21 00:09:19.515759
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    print(a.__ne__(b))

# Generated at 2022-06-21 00:09:20.130044
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    pass
