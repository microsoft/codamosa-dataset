

# Generated at 2022-06-21 00:01:06.508953
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert True


# Generated at 2022-06-21 00:01:18.253428
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    class f(Attribute):
        def __init__(self):
            self.priority = 0

    class g(Attribute):
        def __init__(self):
            self.priority = 1

    class h(Attribute):
        def __init__(self):
            self.priority = 0

    fa = f()
    ga = g()
    ha = h()
    assert fa.__le__(fa) == True
    assert ga.__le__(ga) == True
    assert ha.__le__(ha) == True

    assert fa.__le__(ga) == True
    assert ga.__le__(fa) == False

    assert ga.__le__(ha) == False
    assert ha.__le__(ga) == True

    assert ha.__le__(fa) == True

# Generated at 2022-06-21 00:01:25.101664
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    if a1 != a2:
        raise AssertionError('Expected %s __ne__ %s to return True' % (a1, a2))
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    if a1 != a2:
        raise AssertionError('Expected %s __ne__ %s to return False' % (a1, a2))


# Generated at 2022-06-21 00:01:33.586439
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='foo',default=None,required=False,listof=None,
            priority=0,class_type=None,always_post_validate=False,inherit=True,
            alias=None,static=False)
    a2 = Attribute(isa='foo',default=None,required=False,listof=None,
            priority=0,class_type=None,always_post_validate=False,inherit=True,
            alias=None,static=False)
    print(a1 == a2)


# Generated at 2022-06-21 00:01:36.155214
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attrib1 = Attribute(isa='list')
    attrib2 = Attribute(isa='list')
    assert(attrib1.__ne__(attrib2))


# Generated at 2022-06-21 00:01:41.213207
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='boolean', private=False, default=False, required=False, listof=None, priority=10, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    print (fa)



# Generated at 2022-06-21 00:01:47.274419
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FieldAttribute(
        isa=str,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:01:50.750462
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert (attr1 != attr2) is False
    attr2.priority = 1
    assert (attr1 != attr2) is True

# Generated at 2022-06-21 00:01:54.322720
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)

    assert a < b
    assert not (a < c)
    assert not (b < a)

# Generated at 2022-06-21 00:01:58.051521
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__lt__(a2)


# Generated at 2022-06-21 00:02:12.091063
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from textwrap import dedent

    class TestAttribute():
        """
        Test class for method __gt__
        """
        def __init__(self, val = None):
            self.priority = val

        def __gt__(self, other):
            return self.priority > other.priority

    # Test case 1: Test case with expectation of return value to be True
    test_attr1 = TestAttribute(10)
    expected_attr1 = TestAttribute(1)
    result_attr1 = test_attr1.__gt__(expected_attr1)
    assert result_attr1 == True

    # Test case 2: Test case with expectation of return value to be False
    test_attr2 = TestAttribute(1)
    expected_attr2 = TestAttribute(10)

# Generated at 2022-06-21 00:02:13.544542
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='string')
    assert fa.isa == 'string'

# Generated at 2022-06-21 00:02:17.120439
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    args = {'default':False}
    a = Attribute(**args)
    b = Attribute(**args)
    assert a.__ne__(b) == False


# Generated at 2022-06-21 00:02:26.128094
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=7)
    b = Attribute(priority=4)
    c = Attribute(priority=0)
    d = Attribute(priority=7)
    # testing __lt__ when it is True
    assert b < a
    assert c < b
    assert c < a
    # testing __lt__ when not True
    assert a < b is False
    assert b < c is False
    assert a < c is False
    assert d < a is False
    assert d < b is False
    assert d < c is False


# Generated at 2022-06-21 00:02:30.124374
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__le__(a2) == False
    assert a2.__le__(a1) == True


# Generated at 2022-06-21 00:02:39.387029
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.extend is False
    assert a.prepend is False
    assert a.static is False
    b = Attribute(isa='list', default='foo', required=True,
                  listof='list', priority=1,
                  class_type='list', always_post_validate=True,
                  inherit=False, alias='b', extend=True, prepend=True,
                  static=True)


# Generated at 2022-06-21 00:02:43.767540
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = a.priority
    c = Attribute()
    c.priority = a.priority + 1
    assert a != b
    assert a != c
    assert b != c

# Generated at 2022-06-21 00:02:45.338906
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr is not None


# Generated at 2022-06-21 00:02:49.601513
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute1 = Attribute()
    attribute2 = Attribute()

    assert attribute2 != attribute1, 'The method __ne__ of class Attribute has a bug, please fix it'
    print('The method __ne__ of class Attribute works, congrats')


# Generated at 2022-06-21 00:02:56.318855
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    assert attr3 >= attr2
    assert not attr2 >= attr3
    assert attr2 >= attr1
    assert not attr1 >= attr2
    assert attr3 >= attr1
    assert not attr1 >= attr3

# Generated at 2022-06-21 00:03:04.101467
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='string',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

test_Attribute()

# Generated at 2022-06-21 00:03:15.457965
# Unit test for constructor of class Attribute
def test_Attribute():
    # Default constructor
    attr = Attribute()

    # Constructor with non-default value
    attr = Attribute(isa='boolean', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr.isa == 'boolean'
    assert attr.private == False
    assert attr.default is None
    assert attr.required == False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias is None

# Generated at 2022-06-21 00:03:16.838606
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    assert a.__ge__(a)


# Generated at 2022-06-21 00:03:28.972076
# Unit test for constructor of class Attribute
def test_Attribute():

    # Test the default values of constructor
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None
    assert a.static is False

    # Test the exception when passing a mutable default
    # FIXME: not working, the "default is not None and self.isa in _CONTAINERS..." is never true
    # FIXME: this code is not doing anything, because there is no "a = Attribute(default=[1, 2, 3])"
    # FIXME: in this unit test
    #try

# Generated at 2022-06-21 00:03:32.245884
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute()
    attribute2 = Attribute()
    attribute2.priority = 2
    assert attribute2.__ge__(attribute)


# Generated at 2022-06-21 00:03:37.201347
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    att1 = Attribute()
    att1.priority = 1
    att2 = Attribute()
    att2.priority = 2
    att3 = att1

    if not (att1 == att3 and att1 != att2):
        raise AssertionError("test_Attribute___eq__ fail")


test_Attribute___eq__()

# Generated at 2022-06-21 00:03:39.777399
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a <= b


# Generated at 2022-06-21 00:03:46.008531
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Create 2 objects of class Attribute
    a = Attribute()
    b = Attribute()
    # Set priority to one of the objects
    a.priority = 3
    b.priority = 3

    assert(a.__le__(b) == True), "test_Attribute___le__: FAILED"


# Generated at 2022-06-21 00:03:51.598616
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='string', priority=10)
    b = Attribute(isa='string', priority=10)
    assert a.__eq__(b) == True

    a = Attribute(isa='string', priority=1)
    b = Attribute(isa='string', priority=2)
    assert a.__eq__(b) == False


# Generated at 2022-06-21 00:03:54.718763
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='dict')
    assert isinstance(fa, FieldAttribute)
    assert fa.isa == 'dict'
    assert fa.extend == False


# Generated at 2022-06-21 00:04:06.185612
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a=Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=50,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    b=Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=10,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:04:11.171403
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # set up variables
    attr1 = Attribute(isa='int', priority=0)    # low priority
    attr2 = Attribute(isa='int', priority=1)    # high priority

    # test __lt__
    assert attr1 < attr2
    assert not attr1.__lt__(attr2)



# Generated at 2022-06-21 00:04:14.847279
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #define a FieldAttibute object and verify it
    fieldAttribute = FieldAttribute(isa='bool', default='True')
    assert fieldAttribute.isa == 'bool'
    assert fieldAttribute.default == 'True'

# Generated at 2022-06-21 00:04:18.402097
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    att1 = Attribute(priority=3)
    att2 = Attribute(priority=4)
    assert att1.__ne__(att2) , "test_Attribute___ne__"


# Generated at 2022-06-21 00:04:28.211289
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """
    test method __ge__ of the Attribute class

    """
    attr1 = FieldAttribute(priority=1)
    attr2 = FieldAttribute(priority=2)
    attr3 = FieldAttribute(priority=3)
    attr4 = FieldAttribute(priority=4)
    attr5 = FieldAttribute(priority=5)

    attrs = [attr1, attr2, attr3, attr4, attr5]

    return_bool = []
    for attr in attrs:
        attr_result = attr >= attr
        return_bool.append(attr_result)
    assert all(return_bool)

    return_bool = []
    for attr1 in attrs:
        for attr2 in attrs:
            attr_result = attr1 >= attr2
           

# Generated at 2022-06-21 00:04:37.348381
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # 1
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a >= b

    # 2
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert not a >= b

    # 3
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a >= b

    # 4
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert a >= b



# Generated at 2022-06-21 00:04:39.362085
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = FieldAttribute(priority=1)
    attr2 = FieldAttribute(priority=2)
    assert attr1 <= attr2


# Generated at 2022-06-21 00:04:41.307474
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert (Attribute() <= Attribute()) is True


# Generated at 2022-06-21 00:04:50.113634
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    c = a.__le__(b)
    assert c == False

    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 1
    c = a.__le__(b)
    assert c == True

    a = Attribute()
    a.priority = 2
    b = Attribute()
    b.priority = 1
    c = a.__le__(b)
    assert c == False



# Generated at 2022-06-21 00:04:51.293370
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=0)

    assert attribute2.__gt__(attribute1)

# Generated at 2022-06-21 00:04:58.789890
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    at1 = Attribute(required=True, priority=1)
    at2 = Attribute(required=True, priority=1)
    print(at1 == at2)
    return True



# Generated at 2022-06-21 00:05:03.786314
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    c = Attribute(priority = 2)
    d = Attribute(priority = 0)

    assert(a >= a)
    assert(b >= a)
    assert(c >= a)
    assert(d >= a)

    assert(not (a >= b))
    assert(b >= b)
    assert(c >= b)
    assert(d >= b)

    assert(not (a >= c))
    assert(not (b >= c))
    assert(c >= c)
    assert(d >= c)

    assert(a >= d)
    assert(b >= d)
    assert(c >= d)
    assert(d >= d)


# Generated at 2022-06-21 00:05:05.904608
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 2)

    assert attr1 <= attr2


# Generated at 2022-06-21 00:05:08.133901
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=0)
    assert attribute1 < attribute2



# Generated at 2022-06-21 00:05:09.308405
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='int')


# Generated at 2022-06-21 00:05:18.532627
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field0 = Attribute(priority=0)
    field1 = Attribute(priority=1)
    field2 = Attribute(priority=2)
    field3 = Attribute(priority=3)

    assert field0 < field1
    assert field0 < field2
    assert field0 < field3

    assert field1 < field2
    assert field1 < field3

    assert field2 < field3

    assert not(field1 < field0)
    assert not(field2 < field0)
    assert not(field3 < field0)

    assert not(field2 < field1)
    assert not(field3 < field1)

    assert not(field3 < field2)



# Generated at 2022-06-21 00:05:19.432528
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()



# Generated at 2022-06-21 00:05:23.435586
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2.__gt__(a1) == True
    assert a1.__gt__(a2) == False
    assert a1.__gt__(a1) == False


# Generated at 2022-06-21 00:05:31.060577
# Unit test for constructor of class Attribute
def test_Attribute():
    # init with no arguments
    attr = Attribute()
    assert attr.isa is None
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static

    # init with random arguments

# Generated at 2022-06-21 00:05:35.735773
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # create object of class Attribute
    obj = Attribute()

    # test the method
    try:
        obj.__lt__(1)
        raise AssertionError('Attribute.__lt__ did not raise TypeError')
    except TypeError:
        pass
    except Exception as e:
        raise AssertionError('Attribute.__lt__ raised wrong error: %s' % e)

# Generated at 2022-06-21 00:05:54.353443
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='string')
    assert f1.isa == "string"
    assert f1.extend is False
    assert f1.prepend is False
    f2 = FieldAttribute(isa='list', listof='string', inherit=False, extend=True, prepend=True)
    assert f2.isa == "list"
    assert f2.listof == "string"
    assert f2.inherit is False
    assert f2.extend is True
    assert f2.prepend is True

#   NB: _get_default_value() is defined to cover the case where default is a callable
    def get_default_value():
        return "a default value"
    f3 = FieldAttribute(isa='string', default=get_default_value)
    assert f3.isa == "string"

# Generated at 2022-06-21 00:05:57.793322
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2



# Generated at 2022-06-21 00:06:00.027451
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1 == a2



# Generated at 2022-06-21 00:06:02.752695
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute(priority=1)
    y = Attribute(priority=2)
    assert(x >= y)


# Generated at 2022-06-21 00:06:06.619965
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute_1 = Attribute(1, 1, 1, 1, 1, 1)
    attribute_2 = Attribute(2, 2, 2, 2, 2, 2)
    assert(not attribute_1 == attribute_2)



# Generated at 2022-06-21 00:06:11.951657
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', required=True)
    assert a.isa == 'dict'
    assert a.required == True
    assert a.private == False

    a = Attribute(isa='dict', required=True)
    assert a.isa == 'dict'
    assert a.required == True
    assert a.private == False



# Generated at 2022-06-21 00:06:14.852232
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    #uncomment this to test the Attribute type
    attr = FieldAttribute(private=False, default=None, required=False,
        listof=None, priority=0, class_type=None, always_post_validate=False,
        inherit=True, alias=None, extend=False, prepend=False, static=False)

# Generated at 2022-06-21 00:06:20.122668
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1.priority < attr_2.priority
    assert attr_2 > attr_1
    assert attr_2 >= attr_1
    assert attr_1 <= attr_2
    assert attr_1 <= attr_1
    assert attr_1 >= attr_1
    assert not attr_1 > attr_2

if __name__ == '__main__':
    test_Attribute___gt__()

# Generated at 2022-06-21 00:06:31.982132
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a1 = FieldAttribute(isa='dict')
    assert a1.isa == 'dict'
    # assert a1.private == False
    assert a1.default == None
    assert a1.required == False
    assert a1.listof == None
    assert a1.priority == 0
    assert a1.class_type == None
    assert a1.always_post_validate == False

    a2 = FieldAttribute(isa='list')
    assert a2.isa == 'list'
    # assert a2.private == False
    assert a2.default == None
    assert a2.required == False
    assert a2.listof == None
    assert a2.priority == 0
    assert a2.class_type == None
    assert a2.always_post_validate == False


# Generated at 2022-06-21 00:06:36.140665
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    attr.priority = 0
    attr2 = Attribute()
    attr2.priority = 0
    assert attr == attr2
    attr.priority = 1
    attr2.priority = 2
    assert attr != attr2


# Generated at 2022-06-21 00:07:05.481317
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2  # attr1 <= attr2 is true as attr2.priority < attr1.priority
    assert attr2 >= attr1  # attr2 >= attr1 is true as attr2.priority > attr1.priority



# Generated at 2022-06-21 00:07:09.157044
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    class X:
        a = Attribute()

    class Y(X):
        a = Attribute(priority=1)

    x = X()
    y = Y()
    assert x.a != y.a



# Generated at 2022-06-21 00:07:11.661673
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 >= a1


# Generated at 2022-06-21 00:07:17.246733
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert a < b
    
    a = Attribute(priority=20)
    b = Attribute(priority=10)
    assert a > b
    
    a = Attribute(priority=10)
    assert a <= b
    
    a = Attribute(priority=10)
    assert a >= b


# Generated at 2022-06-21 00:07:28.334411
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a.isa == 'string'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-21 00:07:31.192481
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    ansible_dict = {'foo': 'bar'}
    PrivIter = Attribute(listof=ansible_dict)
    assert not PrivIter < PrivIter



# Generated at 2022-06-21 00:07:35.024582
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    a.priority = 1
    b.priority = 2
    assert(a.__ge__(b) == 0)


# Generated at 2022-06-21 00:07:43.036596
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority = 0)
    attr2 = Attribute(priority = 1)
    attr3 = Attribute(priority = 1)
    assert(attr2.__lt__(attr1) == True)
    assert(attr1.__lt__(attr2) == False)
    assert(attr3.__lt__(attr2) == True)
    assert(attr3.__lt__(attr1) == True)
    assert(attr2.__lt__(attr3) == False)
    assert(attr1.__lt__(attr3) == False)

# Generated at 2022-06-21 00:07:44.103952
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
        Attribute.__ge__()


# Generated at 2022-06-21 00:07:47.734675
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(isa=object, priority=1)
    attr2 = Attribute(isa=object, priority=0)
    
    if not attr1 >= attr2:
        exit(1)

    exit(0)


# Generated at 2022-06-21 00:08:39.315447
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest

    with pytest.raises(TypeError) as excinfo:
        Attribute(default=dict())
    assert 'not be mutable' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        Attribute(default=[])
    assert 'not be mutable' in str(excinfo.value)



# Generated at 2022-06-21 00:08:40.692379
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2.__gt__(attr1)
    assert attr1.__gt__(attr2) is False

# Generated at 2022-06-21 00:08:43.066289
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    print(a<b)
    print(a<=b)
    print(a>b)
    print(a>=b)
    print(a==b)
    print(a!=b)



# Generated at 2022-06-21 00:08:44.138344
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute() >= Attribute()

# Generated at 2022-06-21 00:08:52.233194
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    assert attr < attr2
    assert attr < attr3
    assert attr2 < attr3

    attr = Attribute(priority=3)
    assert not attr < attr
    attr2 = Attribute(priority=3)
    assert not attr < attr2


# Generated at 2022-06-21 00:08:53.851285
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert (Attribute(priority=0) == Attribute(priority=0))
    assert not (Attribute(priority=0) == Attribute(priority=1))


# Generated at 2022-06-21 00:08:57.049895
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 0
    attr1 = Attribute()
    attr1.priority = 100
    print(attr != attr1)


# Generated at 2022-06-21 00:09:03.432693
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test FieldAttribute(isa='str', class_type='str', static=True)
    attr = FieldAttribute(isa='str', class_type='str', static=True)
    assert attr.isa == 'str'
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type == 'str'
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is True


# Generated at 2022-06-21 00:09:11.202203
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=2) <= Attribute(priority=3)
    assert not Attribute(priority=3) <= Attribute(priority=2)
    assert Attribute(priority=4) <= Attribute(priority=4)

if __name__ == '__main__':
    # Uncomment the test you want to run.
    # Please be aware that some of them will fail because the
    # caller of the tested function is missing.

    #test_Attribute___le__() 
    print('test successful!')

# Generated at 2022-06-21 00:09:16.427606
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert(a.isa is None)
    assert(a.private == False)
    assert(a.default is None)
    assert(a.required == False)
    assert(a.listof is None)
    assert(a.priority == 0)
    assert(a.class_type is None)
    assert(a.always_post_validate == False)
    assert(a.inherit == True)
    assert(a.extend == False)
    assert(a.prepend == False)
    assert(a.static == False)

    # keyword arguments