

# Generated at 2022-06-21 00:01:06.168038
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=1)
    assert attr_1 >= attr_2
    assert not attr_2 >= attr_1



# Generated at 2022-06-21 00:01:18.006227
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='string')
    assert not attr.private
    assert attr.isa == 'string'
    assert attr.default is None
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend

    attr = Attribute(isa='string', private=True, default=None, required=True, listof=attribute, priority=3, class_type=attribute, always_post_validate=True, inherit=False, alias='new_alias', extend=True, prepend=True)

# Generated at 2022-06-21 00:01:23.948413
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    l_gt = [FieldAttribute()]
    l_le = [Attribute()]

    try:
        l_gt > l_le
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute: object is not gt of object')

    try:
        l_gt < l_le
    except TypeError:
        pass
    else:
        raise AssertionError('Attribute: object is not gt of object')

# Generated at 2022-06-21 00:01:35.314016
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1=Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
                class_type=None, always_post_validate=False, inherit=True, alias=None)

    # case 1: equal
    attr2=Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0,
                class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr2.__eq__(attr1) == True

    # case 2: unequal

# Generated at 2022-06-21 00:01:38.503911
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='bool', priority=10)
    a2 = Attribute(isa='bool', priority=10)
    assert a1 == a2



# Generated at 2022-06-21 00:01:43.963421
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    foo = Attribute()
    bar = Attribute()
    assert not(foo <= bar)
    #foo.priority = 5
    #bar.priority = 5
    #assert foo == bar
    #assert foo <= bar
    #assert bar <= foo
    #assert not(foo < bar)
    #assert not(bar < foo)



# Generated at 2022-06-21 00:01:45.450495
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a != b, "Attribute __ne__ does not work."


# Generated at 2022-06-21 00:01:46.945978
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)


# Generated at 2022-06-21 00:01:51.182099
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    fa1 = Attribute(priority=0)
    fa2 = Attribute(priority=1)
    fa3 = Attribute(priority=2)

    assert fa2 >= fa1
    assert fa3 >= fa2
    assert not (fa1 >= fa2)
    assert not (fa2 >= fa2)



# Generated at 2022-06-21 00:01:52.406213
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority = 1) != Attribute(priority = 2)


# Generated at 2022-06-21 00:01:57.996292
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert(Attribute.__ne__(Attribute(), Attribute()))
    assert(not Attribute.__ne__(Attribute(priority = 1), Attribute(priority = 2)))

# Generated at 2022-06-21 00:02:09.721437
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(isa='list', default={})
        raise Exception('list default should raise because it is mutable')
    except TypeError:
        pass
    try:
        Attribute(isa='set', default={})
        raise Exception('set default should raise because it is mutable')
    except TypeError:
        pass
    try:
        Attribute(isa='dict', default={})
        raise Exception('dict default should raise because it is mutable')
    except TypeError:
        pass

    a1 = Attribute(isa='list', default=lambda: [])
    a2 = Attribute(isa='list', default=lambda: [])
    assert a1 == a2
    assert a1 != a1.default

    assert a1 != 'string'


# Generated at 2022-06-21 00:02:10.494678
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa.priority == 0


# Generated at 2022-06-21 00:02:18.329302
# Unit test for constructor of class Attribute
def test_Attribute():
    att = Attribute(isa='none',
                    private=False,
                    default=None,
                    required=False,
                    listof=None,
                    priority=0,
                    class_type=None,
                    always_post_validate=False,
                    inherit=True,
                    alias=None)

    assert att.isa == 'none'
    assert isinstance(att.private, bool)
    assert att.default is None
    assert isinstance(att.required, bool)
    assert att.listof is None
    assert isinstance(att.priority, int)
    assert att.class_type is None
    assert isinstance(att.always_post_validate, bool)
    assert isinstance(att.inherit, bool)
    assert att.alias is None

# Generated at 2022-06-21 00:02:28.693357
# Unit test for constructor of class Attribute
def test_Attribute():
    # Confirm that a TypeError is raised if a mutable object is passed to the constructor
    # as the default value.
    try:
        Attribute(default=[])
    except TypeError:
        pass
    else:
        assert False, 'expected a TypeError'
    # Confirm that the constructor does not raise a TypeError when a mutable object
    # is passed as the default value, if the default value is callable.
    assert Attribute(default=lambda: [])
    # Confirm that the constructor does not raise a TypeError when a non-mutable object
    # is passed as the default value.
    assert Attribute(default='')

# Generated at 2022-06-21 00:02:32.590128
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=0)

    assert(a1 == a3)
    assert(a1 != a2)


# Generated at 2022-06-21 00:02:41.378081
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='float', private=True, default=3.14, required=False, listof='complex', priority=0, class_type=complex, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert field.isa == 'float'
    assert field.private == True
    assert field.default == 3.14
    assert field.required == False
    assert field.listof == 'complex'
    assert field.priority == 0
    assert field.class_type == complex
    assert field.always_post_validate == False
    assert field.inherit == True
    assert field.alias == None
    assert field.extend == False
    assert field.prepend == False



# Generated at 2022-06-21 00:02:43.997579
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 > a1

# Generated at 2022-06-21 00:02:46.578798
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a1 < a2



# Generated at 2022-06-21 00:02:48.659942
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)

    if not attr1.__gt__(attr2):
        raise Exception('Attribute.__gt__ not working properly')



# Generated at 2022-06-21 00:02:55.481010
# Unit test for constructor of class Attribute
def test_Attribute():
    # This should pass
    test_pass = Attribute(
        isa='string'
    )
    # This should raise an error
    test_fail = Attribute(
        isa='string',
        default=[1,2,3]
    )

# Generated at 2022-06-21 00:02:56.903930
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert isinstance(attr, FieldAttribute)



# Generated at 2022-06-21 00:03:07.977951
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    isa='dict'
    private=False
    default=None
    required=False
    listof=None
    priority=0
    class_type=None
    always_post_validate=False
    inherit=True
    alias=None
    extend=False

    test_field_attribute = FieldAttribute(
        isa=isa,
        private=private,
        default=default,
        required=required,
        listof=listof,
        priority=priority,
        class_type=class_type,
        always_post_validate=always_post_validate,
        inherit=inherit,
        alias=alias,
        extend=extend,
    )

    assert test_field_attribute.isa == 'dict'
    assert test_field_attribute.private == False

# Generated at 2022-06-21 00:03:13.316828
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        bad = FieldAttribute(isa='dict', default={})
    except TypeError:
        pass

    # test defaults
    assert FieldAttribute().isa is None
    assert FieldAttribute().private is False
    assert FieldAttribute().default is None
    assert FieldAttribute().required is False
    assert FieldAttribute().listof is None
    assert FieldAttribute().priority == 0
    assert FieldAttribute().class_type is None
    assert FieldAttribute().always_post_validate is False
    assert FieldAttribute().inherit is True
    assert FieldAttribute().alias is None
    assert FieldAttribute().extend is False
    assert FieldAttribute().prepend is False
    assert FieldAttribute().static is False



# Generated at 2022-06-21 00:03:16.497458
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(private=True, priority=0)
    attr2 = Attribute(private=True, priority=100)
    attr3 = Attribute(private=True, priority=100)

    assert(attr1 != attr2)
    assert(attr2 == attr3)



# Generated at 2022-06-21 00:03:18.886486
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field1 = Attribute(priority = 0)
    field2 = Attribute(priority = 1)
    assert field2 <= field1


# Generated at 2022-06-21 00:03:31.183116
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
   attr = FieldAttribute()
   assert attr.isa == None
   assert attr.private == False
   assert attr.default == None
   assert attr.required == False
   assert attr.listof == None
   assert attr.priority == 0
   assert attr.class_type == None
   assert attr.always_post_validate == False
   assert attr.inherit == True
   assert attr.alias == None
   assert attr.extend == False
   assert attr.prepend == False
   assert attr.static == False

   attr2 = FieldAttribute(isa='str',private=True,required=True,listof='list')
   assert attr2.isa == 'str'
   assert attr2.private == True
   assert attr2.default == None
   assert attr

# Generated at 2022-06-21 00:03:34.975099
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa="list", priority=1)
    attr2 = Attribute(isa="list", priority=2)
    assert attr1 == attr1
    assert attr1 != attr2


# Generated at 2022-06-21 00:03:37.683893
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=5)
    attr2 = Attribute(priority=5)
    assert not attr.__ne__(attr2)


# Generated at 2022-06-21 00:03:43.161352
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    class ClassA(object):
        a = Attribute(default=1, inherit=True, priority=1)
        b = Attribute(default=2, inherit=True, priority=2)

    assert ClassA.a >= ClassA.b
    assert ClassA.b <= ClassA.a


# Generated at 2022-06-21 00:03:48.385461
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=0)
    assert attr1.__ge__(attr2)

# Generated at 2022-06-21 00:04:00.148429
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class Foo(AnsibleBaseYAMLObject):
        field1 = FieldAttribute()
        field2 = FieldAttribute(isa='bool')
        field3 = FieldAttribute(isa='list', listof='str')
        field4 = FieldAttribute(isa='str', default='foo')

    assert Foo.field1.isa is None
    assert Foo.field2.isa == 'bool'
    assert Foo.field3.isa == 'list'
    assert Foo.field3.listof == 'str'
    assert Foo.field4.isa == 'str'
    assert Foo.field4.default is 'foo'

    # test that we can't pass a mutable object to the default for a container type

# Generated at 2022-06-21 00:04:03.717363
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=1)
    print("a1 == a2:", a1 == a2)
    print("a1 == a3:", a1 == a3)


# Generated at 2022-06-21 00:04:05.140646
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    print (Attribute(isa='dict', priority=0) == Attribute(isa='dict', priority=0))


# Generated at 2022-06-21 00:04:06.209460
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__(): pass



# Generated at 2022-06-21 00:04:09.233166
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='str', required=True, default='test', priority=1)
    assert FieldAttribute(isa='int', required=True, default=10, priority=0)

# Generated at 2022-06-21 00:04:13.139486
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Function to test __le__ method of class Attribute
    """
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert(attr2 >= attr1)


# Generated at 2022-06-21 00:04:17.520482
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert a1 < a2 < a3
    assert a2 < a3
    assert not a1 < a1
    assert not a1 < a3

# Generated at 2022-06-21 00:04:20.627592
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    o = Attribute(priority=1)
    o1 = Attribute(priority=1)
    assert o != o1


# Generated at 2022-06-21 00:04:25.163362
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute()
    attr_gt = Attribute(priority=1)
    assert attr_gt > attr

    attr = Attribute(priority=1)
    attr_gt = Attribute(priority=1)
    assert not attr_gt > attr



# Generated at 2022-06-21 00:04:29.958733
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    a.priority = 5
    b.priority = 10
    assert a.__gt__(b)



# Generated at 2022-06-21 00:04:40.394730
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """Unit test for method __le__ of class Attribute"""

    attributeOne = Attribute()
    attributeOne.priority = 1
    attributeTwo = Attribute()
    attributeTwo.priority = 2
    assert attributeTwo.__ge__(attributeOne) == True
    assert attributeTwo.__le__(attributeOne) == False
    assert attributeOne.__ge__(attributeTwo) == False
    assert attributeOne.__le__(attributeTwo) == True
    attributeTwo.priority = 1
    assert attributeTwo.__ge__(attributeOne) == False
    assert attributeTwo.__le__(attributeOne) == False
    assert attributeOne.__ge__(attributeTwo) == False
    assert attributeOne.__le__(attributeTwo) == False


# Generated at 2022-06-21 00:04:42.535223
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    assert attr.__eq__(attr)


# Generated at 2022-06-21 00:04:48.593041
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    file_name_1=Attribute(priority=1)
    file_name_2=Attribute(priority=1)
    assert(file_name_1==file_name_2)

    file_name_1=Attribute(priority=1)
    file_name_2=Attribute(priority=2)
    assert(not(file_name_1==file_name_2))


# Generated at 2022-06-21 00:04:51.865910
# Unit test for constructor of class Attribute
def test_Attribute():
    a=Attribute(isa='dict', required=True, default=dict, inherit=False)
    a.isa
    a.required
    a.default
    a.inherit

# Generated at 2022-06-21 00:05:02.718372
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Negative test 1, where a is None
    a = Attribute()
    b = Attribute(priority=0)
    if a == b:
        raise Exception('Attribute: __ge__: negative test 1 failed')
    # Negative test 2, where b is None
    a = Attribute(priority=0)
    b = Attribute()
    if a == b:
        raise Exception('Attribute: __ge__: negative test 2 failed')
    # Negative test 3, Attribute__ge__ returns False
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a == b:
        raise Exception('Attribute: __ge__: negative test 3 failed')
    # Negative test 4, Attribute__ge__ returns False
    a = Attribute(priority=0)
    b = Attribute(priority=2)


# Generated at 2022-06-21 00:05:04.354888
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    A = Attribute()
    B = Attribute()

    assert A == B


# Generated at 2022-06-21 00:05:07.570199
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute()
    a2 = Attribute()
    a1.priority = 3
    a2.priority = 4

    assert a1 < a2



# Generated at 2022-06-21 00:05:11.167248
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute('a')
    assert a.isa == 'a'
    assert a.default is None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0


# Generated at 2022-06-21 00:05:19.422881
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    """
    Test function __ne__ of class Attribute 
    """
    # Test case 1
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a.priority == b.priority
    assert a == b
    assert not (a != b)
    assert not a != a
    assert not b != b

    # Test case 2
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.priority != b.priority
    assert a != b
    assert not (a == b)
    assert not a != a
    assert not b != b


# Generated at 2022-06-21 00:05:28.475618
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    pri1 = Attribute(priority=1)
    pri2 = Attribute(priority=2)
    assert pri2 < pri1
    pri1 = Attribute(priority=1)
    pri2 = Attribute(priority=2)
    assert not pri1 < pri2


# Generated at 2022-06-21 00:05:31.714125
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa='array', private=False, default=None, priority=0)
    b = Attribute(isa='array', private=False, default=None, priority=3)
    if a == b:
        print("error")
    elif a != b:
        print("ok")
    else:
        print("error")


# Generated at 2022-06-21 00:05:33.165831
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b

# Generated at 2022-06-21 00:05:34.562972
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    a = FieldAttribute(isa='bool', required=True)
    assert a.isa == 'bool'
    assert a.required == True



# Generated at 2022-06-21 00:05:37.952874
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority = 0)
    a2 = Attribute(priority = 10)
    assert a2.__gt__(a1) == True


# Generated at 2022-06-21 00:05:44.459312
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test default value of FieldAttribute
    attribute = FieldAttribute()
    defaults = {}
    for key in attribute.__dict__:
        defaults[key] = attribute.__dict__[key]

    # Test if there are new variable in FieldAttribute
    # which are not in defaults
    for key in attribute.__dict__:
        assert(key in defaults.keys())

    print("Field Attribute tests passed!")



# Generated at 2022-06-21 00:05:46.617817
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(priority=20)
    attr2 = Attribute(priority=10)
    assert attr >= attr2


# Generated at 2022-06-21 00:05:49.903685
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Set a few attributes that satisfy the __gt__ method condition
    attr = Attribute(priority=50)
    attr_other = Attribute(priority=51)
    assert attr_other.__gt__(attr) == True


# Generated at 2022-06-21 00:05:53.502829
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    value_1 = Attribute()
    value_1.priority = 10
    value_2 = Attribute()
    value_2.priority = 10
    rval = value_1 <= value_2
    assert rval is True

# Generated at 2022-06-21 00:05:55.506585
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Many of the arguments to the constructor of class
    # FieldAttribute are not supported.
    pass

# Generated at 2022-06-21 00:06:10.309316
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=5)
    b = Attribute(priority=5)
    c = Attribute(priority=7)

    assert a == c
    assert c == b
    assert a is not b
    assert b is not c
    assert a is not c



# Generated at 2022-06-21 00:06:13.938999
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(0)
    b = Attribute(1)
    assert(a <= b)  # a is lower or equal to b
    assert(b >= a)  # b is greater or equal to a


# Generated at 2022-06-21 00:06:16.186383
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=11)
    a2 = Attribute(priority=22)
    assert (a1.__ne__(a2) == (a1 != a2))

# Generated at 2022-06-21 00:06:20.533230
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr3 = Attribute(priority=1)
    assert attr1 == attr2
    assert not attr1 == attr3
    assert not attr2 == attr3
    # None equality
    attr4 = Attribute(priority=None)
    assert attr4 == attr4
    assert attr4 != attr1
    assert attr4 != attr2
    assert attr4 != attr3


# Generated at 2022-06-21 00:06:24.753617
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = Attribute()
    field1.priority = 2

    field2 = Attribute()
    field2.priority = 1

    assert field2.__ge__(field1)


# Generated at 2022-06-21 00:06:29.697075
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field_attribute = Attribute()
    field_attribute.priority = 5
    field_attribute2 = Attribute()
    field_attribute2.priority = 5
    if field_attribute != field_attribute2:
        print("test_Attribute___ne__(): fail")
    else:
        print("test_Attribute___ne__(): pass")



# Generated at 2022-06-21 00:06:32.104527
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a1_1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2
    assert a1 <= a1_1
    assert not (a2 <= a1)



# Generated at 2022-06-21 00:06:37.501333
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list', listof='int', private=True, default=lambda: [], required=True, priority=1)
    assert a.isa == 'list'
    assert a.listof == 'int'
    assert a.private == True
    assert a.default() == []
    assert a.required == True
    assert a.priority == 1
    a = FieldAttribute(isa='foo', private=True, default='bar', required=True, priority=1)
    assert a.isa == 'foo'
    assert a.default == 'bar'
    assert a.required == True
    assert a.priority == 1


# Generated at 2022-06-21 00:06:42.447948
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test that method __ge__ of class Attribute raises TypeError when invalid
    # parameters are passed into the method

    # Set __ge__ to an invalid name which is not a method of Attribute
    _ge__ = 'not_ge__'

    # Call method __ge__ of class Attribute with invalid parameters
    #   TypeError should be returned
    try:
        getattr(Attribute, _ge__)('invalid')
    except TypeError as te:
        print(str(te))



# Generated at 2022-06-21 00:06:45.855305
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute()
    y = Attribute()
    x.priority = 1
    y.priority = 2
    return x.__ge__(y)
