

# Generated at 2022-06-21 00:01:14.418153
# Unit test for constructor of class Attribute
def test_Attribute():
    testattr = Attribute(isa='string')
    assert testattr.isa == 'string'
    assert testattr.private == False
    assert testattr.default == None
    assert testattr.required == False
    assert testattr.listof == None
    assert testattr.priority == 0
    assert testattr.class_type == None
    assert testattr.always_post_validate == False
    assert testattr.inherit == True
    assert testattr.alias == None
    assert testattr.extend == False
    assert testattr.prepend == False
    assert testattr.static == False
    return True



# Generated at 2022-06-21 00:01:16.426784
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=10)
    assert a1 >= 10

# Generated at 2022-06-21 00:01:22.401189
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=1)

    assert (a < b) is True
    assert (a < c) is False
    assert (b < a) is False
    assert (b < c) is False
    assert (c < a) is False
    assert (c < b) is False


# Generated at 2022-06-21 00:01:30.353117
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a == b
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert not a == b
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert not a == b



# Generated at 2022-06-21 00:01:33.865366
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b

    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert a > b



# Generated at 2022-06-21 00:01:45.617921
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    INPUT = {
        'isa': 'string',
        'private': True,
        'default': 'default',
        'required': False,
        'listof': 'string',
        'priority': 10,
        'class_type': None,
        'always_post_validate': True,
        'inherit': False,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }

# Generated at 2022-06-21 00:01:48.407813
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=10)
    assert(attr2.__lt__(attr1))


# Generated at 2022-06-21 00:01:52.325254
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=0) <= Attribute(priority=0)
    assert Attribute(priority=1) <= Attribute(priority=1)
    assert Attribute(priority=0) <= Attribute(priority=1)
    assert not Attribute(priority=1) <= Attribute(priority=0)

# Generated at 2022-06-21 00:01:53.998486
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2


# Generated at 2022-06-21 00:02:06.108527
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='class', private=False, default=None, required=False, listof='string', priority=0,
                  class_type='test', always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False,
                  static=False)

    assert a.isa is not None
    assert a.private is not None
    assert a.default is not None
    assert a.required is not None
    assert a.listof is not None
    assert a.priority is not None
    assert a.class_type is not None
    assert a.always_post_validate is not None
    assert a.inherit is not None
    assert a.alias is not None



# Generated at 2022-06-21 00:02:17.493573
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test 1: if isa is set to "list", this can optionally be set to
    # ensure that all elements in the list are of the given type. Valid
    # values here are the same as those for isa.
    # Create a FieldAttribute instance
    field_attribute = FieldAttribute()
    field_attribute.isa = 'list'
    field_attribute.listof = 'int'
    assert field_attribute.isa == 'list'
    assert field_attribute.listof == 'int'

    # Test 2: If isa is set to "list", this can optionally be set to
    # ensure that all elements in the list are of the given type. Valid
    # values here are the same as those for isa.
    # Create a FieldAttribute instance
    field_attribute = FieldAttribute()
    field_attribute.isa = 'list'
    field

# Generated at 2022-06-21 00:02:19.961113
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=10)
    assert a < b


# Generated at 2022-06-21 00:02:28.852320
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa="TEST")
    assert a.isa == 'TEST'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

# Generated at 2022-06-21 00:02:32.341688
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=1)
    assert attr.__ne__(Attribute(priority=2))
    assert not attr.__ne__(Attribute(priority=1))


# Generated at 2022-06-21 00:02:40.289059
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute(isa="list", private=False, default=None,
                             required=False, listof=None, priority=0,
                             class_type=None, always_post_validate=False,
                             inherit=True, alias=None, extend=False,
                             prepend=False, static=False)
    y = Attribute(isa="list", private=False, default=None,
                           required=False, listof=None, priority=1,
                           class_type=None, always_post_validate=False,
                           inherit=True, alias=None, extend=False,
                           prepend=False, static=False)
    # print("Test Case #1 : x.__ge__(y)")

# Generated at 2022-06-21 00:02:42.070795
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='string')
    assert a.isa == 'string'

# Generated at 2022-06-21 00:02:45.954869
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attrOne = Attribute(priority = 0)
    attrTwo = Attribute(priority = 1)
    if attrOne.__gt__(attrTwo):
        print("method __gt__ of class Attribute is not working")


# Generated at 2022-06-21 00:02:48.026873
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) < Attribute(priority=0), "Attribute sorting is wrong"



# Generated at 2022-06-21 00:02:54.161121
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute(isa=int)
    assert FA.isa == int
    FA = FieldAttribute(isa='int')
    assert FA.isa == int
    FA = FieldAttribute(isa='int', default=0)
    assert FA.default == 0
    FA = FieldAttribute(isa='int', default=lambda: 1)
    assert FA.default == 1


# Generated at 2022-06-21 00:03:00.933575
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    values = [
        (Attribute(priority=1), Attribute(priority=1), True),
        (Attribute(priority=1), Attribute(priority=2), False),
        (Attribute(priority=2), Attribute(priority=1), True)
    ]

    for attr_a, attr_b, expected in values:
        assert (attr_a >= attr_b) is expected, "Attribute({}) >= Attribute({}) != {}".format(
            attr_a.priority, attr_b.priority, expected
        )



# Generated at 2022-06-21 00:03:06.732212
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a > b


# Generated at 2022-06-21 00:03:09.312780
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_Attribute = Attribute()
    assert test_Attribute.__ne__(Attribute()) == False


# Generated at 2022-06-21 00:03:12.678901
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute(priority=1)
    assert attribute.__ne__(Attribute(priority=2)) is True
    assert attribute.__ne__(Attribute(priority=1)) is False


# Generated at 2022-06-21 00:03:19.199396
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    at1= Attribute()
    at2= Attribute(priority=0)
    at3= Attribute(priority=1)
    at4= Attribute(priority=2)
    assert at1.__lt__(at2) == False
    assert at2.__lt__(at1) == False
    assert at2.__lt__(at3) == True
    assert at3.__lt__(at4) == True
    assert at4.__lt__(at3) == False



# Generated at 2022-06-21 00:03:20.699856
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=0) <= Attribute(priority=1)



# Generated at 2022-06-21 00:03:23.672224
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute()
    other = Attribute()
    other.priority = 1
    assert attribute.__gt__(other)==True


# Generated at 2022-06-21 00:03:28.451085
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    a.priority = 0
    b.priority = 1
    c = Attribute()
    c.priority = 0
    assert a < b
    assert b > a
    assert a <= b
    assert b >= a
    assert a <= c
    assert a >= c

# Generated at 2022-06-21 00:03:32.515876
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2.__lt__(attr1) == True
    assert attr1.__lt__(attr2) == False


# Generated at 2022-06-21 00:03:37.064199
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test if the constructor Attribute creates and object without any problems.
    a = Attribute(isa='list')
    assert isinstance(a, Attribute)
    # Test if the default constructor creates an object.
    b = Attribute()
    assert isinstance(b, Attribute)


# Generated at 2022-06-21 00:03:49.758895
# Unit test for constructor of class Attribute
def test_Attribute():
    #Pass
    a = Attribute()
    a = Attribute(isa="list", listof="str")
    a = Attribute(isa="int", default=1)
    a = Attribute(isa="str", default="default")
    a = Attribute(isa="dict", default={})
    a = Attribute(isa="list", default=lambda: [])
    a = Attribute(isa="str", alias="ansible_alias")
    a = Attribute(isa="dict", class_type=dict)
    a = Attribute(isa="str", extend=True)
    a = Attribute(isa="str", prepend=True)
    a = Attribute(isa="str", static=True)

    # Fail
    fail = False

# Generated at 2022-06-21 00:03:57.767300
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    assert not a < b



# Generated at 2022-06-21 00:04:00.476506
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1 != attr_2


# Generated at 2022-06-21 00:04:05.251071
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from ansible.playbook.attribute import FieldAttribute
    a1 = FieldAttribute(priority=1)
    a2 = FieldAttribute(priority=2)
    a3 = FieldAttribute(priority=3)
    a4 = FieldAttribute(priority=4)
    assert a2 > a1
    assert not (a2 > a2)
    assert not (a2 > a3)
    assert not (a2 > a4)


# Generated at 2022-06-21 00:04:09.010385
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute = Attribute()
    assert attribute.__lt__(attribute) == False
    attribute = Attribute(priority=100)
    assert attribute.__lt__(attribute) == False


# Generated at 2022-06-21 00:04:20.690025
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    default = VaultSecret(VaultLib(), b'123')
    a1 = Attribute(isa='bool', private=False, default=default, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    a2 = Attribute(isa='bool', private=False, default=default, required=False, listof=None, priority=2, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

# Generated at 2022-06-21 00:04:23.630691
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    a.priority = 4
    b.priority = 3
    assert a > b
    assert not b > a

# Generated at 2022-06-21 00:04:28.250897
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.module_utils.basic import AnsibleModule
    a = Attribute(isa='str', default='hello', inherit=True, alias='world')
    m = AnsibleModule({})
    assert a.isa == 'str'
    assert a.default == 'hello'
    assert a.inherit == True
    assert a.alias == 'world'
    m.fail_json(msg="foo")



# Generated at 2022-06-21 00:04:35.141255
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 0
    b = Attribute()
    b.priority = 0
    c = Attribute()
    c.priority = 1

    assert (a <= b) == True
    assert (b <= a) == True
    assert (a <= c) == False
    assert (c <= a) == True



# Generated at 2022-06-21 00:04:37.878834
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(default="foo", priority=0)
    a2 = Attribute(default="foo", priority=0)
    assert a1.__ge__(a2)



# Generated at 2022-06-21 00:04:49.670012
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """
    Attributes are compared based on their priority number if they are of class
    Attribute.
    """
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert(a2 >= a1)
    assert(a1 < a2)
    assert(a1 <= a1)
    assert(a2 >= a2)
    assert(a1 == a1)
    assert(a2 == a2)
    assert(a1 != a2)
    assert(a2 != a1)

    # a1 > a2 is False because a2.priority == 2 > a1.priority == 1
    assert(not (a1 > a2))
    # a2 < a1 is False because a1.priority == 1 < a2.priority == 2

# Generated at 2022-06-21 00:05:05.457982
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert a.isa is None
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-21 00:05:16.271905
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # We don't want to use the default attribute, because it is a special case.
    for attribute in (Attribute(), FieldAttribute()):
        assert attribute.__gt__(attribute) is False
        assert attribute.__lt__(attribute) is False
        assert attribute.__ge__(attribute) is True
        assert attribute.__le__(attribute) is True
        assert attribute.__eq__(attribute) is True
        assert attribute.__ne__(attribute) is False

    assert Attribute(priority=0) > Attribute(priority=1)
    assert Attribute(priority=1) < Attribute(priority=0)

    assert Attribute(priority=1) >= Attribute(priority=1)
    assert Attribute(priority=1) <= Attribute(priority=1)



# Generated at 2022-06-21 00:05:25.418488
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field_attr1 = Attribute(priority=1)
    field_attr2 = Attribute(priority=2)
    if not field_attr1 < field_attr2:
        raise AssertionError("__lt__ test failed")

    if not field_attr1 <= field_attr2:
        raise AssertionError("__le__ test failed")

    if field_attr2 == field_attr1:
        raise AssertionError("__eq__ test failed")

    if not field_attr1 == field_attr1:
        raise AssertionError("__eq__ test failed")

    if not field_attr1 != field_attr2:
        raise AssertionError("__ne__ test failed")

    if not field_attr1 != field_attr1:
        raise AssertionError("__ne__ test failed")

# Generated at 2022-06-21 00:05:35.110033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    fa = FieldAttribute()
    fa.isa = 'test'
    fa.private = True
    fa.default = 'test'
    fa.required = True
    fa.listof = 'test'
    fa.priority = 0
    fa.class_type = 'test'
    fa.always_post_validate = True
    fa.inherit = True
    fa.alias = 'test'
    fa.extend = True
    fa.prepend = True
    fa.static = True

    fa1 = FieldAttribute(required=True)
    assert fa1.required == True
    fa1 = FieldAttribute(required=False)
    assert fa1.required == False

    # test default value
    assert fa.isa == 'test'
    assert fa.private == True

# Generated at 2022-06-21 00:05:37.334978
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=1) != Attribute(priority=2) == True


# Generated at 2022-06-21 00:05:40.629800
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test with __gt__ with same priority
    with pytest.raises(AssertionError):
        assert Attribute(priority=1) > Attribute(priority=1) == False
    # Test with __gt__ with different priority
    assert Attribute(priority=1) > Attribute(priority=2) == False
    assert Attribute(priority=2) > Attribute(priority=1) == True

# Generated at 2022-06-21 00:05:48.419181
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None
    assert f.extend is False
    assert f.prepend is False
    assert f.static is False

# Generated at 2022-06-21 00:05:56.192487
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=3)
    b = Attribute(priority=4)
    c = Attribute(priority=5)
    d = Attribute(priority=6)

    assert a.__ge__(a)
    assert b.__ge__(a)
    assert c.__ge__(a)
    assert d.__ge__(a)
    assert not a.__ge__(b)
    assert not a.__ge__(c)
    assert not a.__ge__(d)


# Generated at 2022-06-21 00:05:57.947453
# Unit test for constructor of class Attribute
def test_Attribute():
    attribute = Attribute()
    assert attribute.static == False



# Generated at 2022-06-21 00:06:03.085436
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='str', private=False, default='a', required=False, listof='str', priority=0)
    f2 = FieldAttribute(isa='str', private=False, default='a', required=False, listof='str', priority=0)
    assert f1 == f2
    assert f1 is not f2



# Generated at 2022-06-21 00:06:20.505751
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # test true
    attribute1 = Attribute()
    attribute1.priority = 5
    attribute2 = Attribute()
    attribute2.priority = 2
    if not attribute1.__ne__(attribute2):
        raise AssertionError('attribute1.__ne__(attribute2) false with priority 5 and 2')
    # test false
    attribute1 = Attribute()
    attribute1.priority = 2
    attribute2 = Attribute()
    attribute2.priority = 2
    if attribute1.__ne__(attribute2):
        raise AssertionError('attribute1.__ne__(attribute2) true with priority 2 and 2')



# Generated at 2022-06-21 00:06:32.475843
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    assert (a < b) == False
    assert (b < a) == False

    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    assert (a < b) == True
    assert (b < a) == False

    a = Attribute(priority = 1)
    b = Attribute(priority = 1)
    assert (a < b) == False
    assert (b < a) == False

    # The method __lt__ is used for the method sort()
    # and the method sort() applied on a list is stable.
    # Therefore, in case of equality, the order is kept
    # and the same element is always returned.
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)
    c = Att

# Generated at 2022-06-21 00:06:41.344592
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 is not None
    assert attr2 is not None
    attr1.priority = 10
    attr2.priority = 10
    assert attr1 <= attr2
    assert attr2 <= attr1
    attr1.priority = 11
    attr2.priority = 10
    assert attr1 > attr2
    assert attr2 < attr1
    attr1.priority = 9
    attr2.priority = 10
    assert attr1 < attr2
    assert attr2 > attr1
    attr1.priority = 10
    attr2.priority = 11
    assert attr1 < attr2
    assert attr2 > attr1
    attr1.priority = 10
    att

# Generated at 2022-06-21 00:06:44.143377
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a_attr_1 = Attribute(priority=1)
    a_attr_2 = Attribute(priority=1)

    b_attr_1 = Attribute(priority=2)
    assert (a_attr_1 == a_attr_2)
    assert not (a_attr_1 == b_attr_1)


# Generated at 2022-06-21 00:06:49.541325
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=10)
    assert a < b
    a = Attribute(priority=10)
    b = Attribute(priority=5)
    assert not a < b
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert not a < b

# Generated at 2022-06-21 00:06:55.695288
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test that all keyword arguments work
    x = Attribute(isa='foo', private=True, default=3, required=True, listof='foobar', priority=5, class_type='class',
                  always_post_validate=True, inherit=False)
    assert x.isa == 'foo'
    assert x.private is True
    assert x.default == 3
    assert x.required is True
    assert x.listof == 'foobar'
    assert x.priority == 5
    assert x.class_type == 'class'
    assert x.always_post_validate is True
    assert x.inherit is False


# TODO: make this a metaclass rather than a function

# Generated at 2022-06-21 00:07:05.134902
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(isa='str', private=False, default=None, required=False, listof=None,
        priority=0, class_type=None, always_post_validate=False, inherit=True, static=False)
    attribute2 = Attribute(isa='str', private=False, default=None, required=False, listof=None,
        priority=1, class_type=None, always_post_validate=False, inherit=True, static=False)
    assert attribute2.__ge__(attribute1)
    assert not attribute1.__ge__(attribute2)


# Generated at 2022-06-21 00:07:16.177309
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = FieldAttribute(
        isa=dict,
        default=lambda: {'k': 1},
        required=True,
        listof=str,
        always_post_validate=True,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    assert isinstance(attr, Attribute)
    assert attr.required is True
    assert attr.listof == str
    assert attr.default() == {'k': 1}
    assert not hasattr(attr, 'property')


# Generated at 2022-06-21 00:07:18.497441
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='hello')
    a2 = Attribute(isa='hello')
    assert a1 == a2
    assert a2 == a1


# Generated at 2022-06-21 00:07:20.927901
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    first = Attribute(priority=10)
    second = Attribute(priority=1)
    assert first >= second
    second = Attribute(priority=10)
    assert first >= second



# Generated at 2022-06-21 00:07:55.736571
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Testing __le__ method of class Attribute
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    print(a1 <= a2)
    assert(a1 <= a2)


# Generated at 2022-06-21 00:08:00.981098
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    # Prepare test objects
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    c = Attribute(priority=1)

    # Test objects using __eq__
    assert a.__eq__(b)
    assert b.__eq__(a)
    assert not a.__eq__(c)



# Generated at 2022-06-21 00:08:04.404199
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(required=False, isa='str', private=False, priority=0, inherit=True)
    attr2 = Attribute(required=False, isa='str', private=False, priority=0, inherit=True)
    attr3 = Attribute(required=True, isa='str', private=True, priority=1, inherit=True)
    attr4 = Attribute(required=True, isa='str', private=True, priority=1, inherit=False)
    assert attr1 != attr2
    assert attr2 != attr3
    assert attr3 != attr4

    attr5 = Attribute(required=True, isa='int', private=True, priority=1, inherit=False)
    assert attr4 != attr5

# Generated at 2022-06-21 00:08:04.945145
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-21 00:08:08.431336
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=1)
    attr1 = Attribute(priority=1)
    assert attr == attr1, "Method __ne__ error"
    attr1.priority = 0
    assert attr != attr1, "Method __ne__ error"


# Generated at 2022-06-21 00:08:13.895713
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print ("###############################################################################\n"
        "Unit test for method __ge__ of class Attribute\n"
        "###############################################################################")

    # Declaration of an Attribute
    a = Attribute(isa=0, inherit=False, private=False, default=0, required=True, extend=True, prepend=True, static=True)

    # Declaration of an Attribute
    b = Attribute(isa=0, inherit=False, private=False, default=0, required=True, extend=True, prepend=True, static=True)

    # Les attributs a et b sont égaux.
    if a >= b:
        print("a >= b : true")
    else :
        print("a >= b : false")

    # Declaration of an Attribute

# Generated at 2022-06-21 00:08:24.292416
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    def test_cmp(priority1, priority2, expected):
        attr1 = FieldAttribute(priority=priority1)
        attr2 = FieldAttribute(priority=priority2)
        assert attr1 < attr2 == expected, "attr1: {}, attr2: {}".format(attr1, attr2)

    test_cmp(0, 0, False)
    test_cmp(0, 1, True)
    test_cmp(1, 0, False)

    try:
        test_cmp(None, 0, True)
    except TypeError as e:
        if "unorderable types" not in str(e):
            assert False, "expected 'unorderable types' in error message"



# Generated at 2022-06-21 00:08:27.588338
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class TestClass:
        test_field = FieldAttribute()

        def __init__(self):
            self.test_field = None

    tc = TestClass()
    assert tc.test_field == None
    return


# Generated at 2022-06-21 00:08:28.450589
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()



# Generated at 2022-06-21 00:08:31.287446
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test=['a','b']
    if 'a' not in test: 
        print ('wrong')

    if 'c' not in test: 
        print ('right')


if __name__ == '__main__':
    test_Attribute___ne__()

# Generated at 2022-06-21 00:09:17.337805
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    return not a >= b


# Generated at 2022-06-21 00:09:19.396314
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute() != Attribute()
    assert not Attribute() != Attribute()



# Generated at 2022-06-21 00:09:27.273632
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with a bool value
    fa1 = FieldAttribute(default=True)
    assert fa1.default
    test_bool = isinstance(fa1.default, bool)
    assert test_bool
    assert isinstance(fa1.default, bool)

    # Test with a dictionary
    fa2 = FieldAttribute(default={'a': 1})
    assert fa2.default
    assert isinstance(fa2.default, dict)

    # Test with a list
    fa3 = FieldAttribute(default=[1, 2, 3])
    assert fa3.default
    assert isinstance(fa3.default, list)

    # Test with a string
    fa4 = FieldAttribute(default='foo')
    assert fa4.default
    assert isinstance(fa4.default, str)

    # Test with an integer
    fa5 = FieldAttribute

# Generated at 2022-06-21 00:09:31.125935
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_a = FieldAttribute()
    attr_a.priority = 1

    attr_b = FieldAttribute()
    attr_b.priority = 2

    assert attr_a <= attr_b
    assert not attr_b <= attr_a



# Generated at 2022-06-21 00:09:35.518296
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    F = FieldAttribute
    fa = F()
    fa2 = F(priority=5)

    if not (fa <= fa2):
        raise AssertionError

    # Unit test for method __lt__ of class Attribute


# Generated at 2022-06-21 00:09:40.680631
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert (attr1 <= attr2) is True
    assert (attr1 <  attr2) is True
    assert (attr1 >= attr2) is False
    assert (attr1 >  attr2) is False
    assert (attr1 == attr2) is False
    assert (attr1 != attr2) is True


# Generated at 2022-06-21 00:09:49.805645
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 2)
    attr3 = Attribute(priority = 3)
    attr4 = Attribute(priority = 4)
    attr5 = Attribute(priority = 5)
    val = attr1.__ge__(attr2)
    assert val == False
    assert attr3.__ge__(attr4) == False
    assert attr4.__ge__(attr1) == True
    assert attr4.__ge__(attr4) == True
    assert attr5.__ge__(attr2) == True


# Generated at 2022-06-21 00:09:56.704110
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1500)
    a2 = Attribute(priority=1450)
    a3 = Attribute(priority=1450)
    a4 = Attribute(priority=1400)
    a5 = Attribute(priority=0)
    a6 = Attribute(priority=None)
    list = [a1, a2, a3, a4, a5]
    list.sort()
    assert list == [a1, a2, a3, a4, a5]
    assert a1 < a2
    assert a2 < a3
    assert a3 < a4
    assert a4 < a5
    assert a5 < a1
    assert a5 < a6
    assert a6 < a1

# Generated at 2022-06-21 00:10:00.647071
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__gt__(b)
    assert not b.__gt__(a)



# Generated at 2022-06-21 00:10:04.013567
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_attribute = Attribute(priority=0)
    field_attribute2 = Attribute(priority=1)
    assert (field_attribute.__lt__(field_attribute2))

