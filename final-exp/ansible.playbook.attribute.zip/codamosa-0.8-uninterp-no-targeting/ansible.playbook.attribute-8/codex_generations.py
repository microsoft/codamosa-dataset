

# Generated at 2022-06-21 00:01:14.128779
# Unit test for constructor of class Attribute
def test_Attribute():
    # test isa
    assert Attribute(isa='list').isa == 'list'
    assert Attribute(isa=list).isa == list
    assert Attribute(isa='%').isa == '%'

    # test private
    assert Attribute(private=False).private == False
    assert Attribute(private=True).private == True

    # test default
    assert Attribute(default=42).default == 42
    assert Attribute(default=None).default is None

    # test required
    assert Attribute(required=False).required == False
    assert Attribute(required=True).required == True

    # test class type
    assert Attribute(class_type=Attribute).class_type == Attribute

    # test always_post_validate
    assert Attribute(always_post_validate=False).always_post_validate == False


# Generated at 2022-06-21 00:01:16.476829
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = FieldAttribute()
    a.priority = 10
    assert a >= a




# Generated at 2022-06-21 00:01:20.298255
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__le__(a2) is True
    assert a2.__le__(a1) is False


# Generated at 2022-06-21 00:01:25.538191
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=4)

    assert(a1 < a2)
    assert(a1 < a3)
    assert(a1 < a4)
    assert(a2 < a3)
    assert(a2 < a4)
    assert(a3 < a4)



# Generated at 2022-06-21 00:01:36.839513
# Unit test for constructor of class Attribute
def test_Attribute():
    # test various types of required Attribute
    with open('/tmp/test_Attribute','w') as f:
        f.write("""
          # test boolean
          - hosts: all
            gather_facts: yes
          # test integer
          - name: /bin/foo
          # test string
          - name: foo
            ignore_errors: yes
          # test list
          - shell: ps -aux
            register: output
          - debug: var=item.USER
            with_items: "{{ output.results }}"
          # test dict
          - name: /bin/foo
            set_fact:
              var:
                var1: value1
                var2: value2
          # test class
          - name: a role
            include_role:
              name: test_role
        """)

# Generated at 2022-06-21 00:01:39.643957
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list')
    assert attr.default is None
    assert attr.isa == 'list'

# Generated at 2022-06-21 00:01:50.739309
# Unit test for constructor of class Attribute
def test_Attribute():
    #valid
    a = Attribute()
    a = Attribute(isa='str', private=False, default='some_str', required=False, listof='str')
    a = Attribute(isa='str', private=False, default='some_str', required=False, listof='str', priority=1)
    a = Attribute(isa='str', private=False, default='some_str', required=False, listof='str', priority=1, class_type='some_class')
    a = Attribute(isa='str', private=False, default='some_str', required=False, listof='str', priority=1, class_type='some_class', always_post_validate=True)

# Generated at 2022-06-21 00:02:00.124035
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # class Attribute with different priority values
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 2)
    attr3 = Attribute(priority = 3)
    attr4 = Attribute(priority = 4)
    # negative test
    assert attr1.__lt__(attr2) is False
    # positive tests
    assert attr1.__lt__(attr4) is True
    assert attr2.__lt__(attr4) is True
    assert attr3.__lt__(attr4) is True


# Generated at 2022-06-21 00:02:11.637230
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # test isa, private, default and inherit
    f1 = FieldAttribute(isa='str', private=True, default='hello', inherit=True)
    assert f1.isa == 'str'
    assert f1.private == True
    assert f1.default == 'hello'
    assert f1.inherit == True

    # test listof and required
    f2 = FieldAttribute(isa='list', listof='str', required=True)
    assert f2.isa == 'list'
    assert f2.listof == 'str'
    assert f2.required == True

    # test alias and extend
    f3 = FieldAttribute(isa='bool', alias='foobar', extend=True)
    assert f3.isa == 'bool'
    assert f3.alias == 'foobar'
    assert f3.extend == True

# Generated at 2022-06-21 00:02:13.142374
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    att1 = Attribute(priority=0)
    att2 = Attribute(priority=1)
    assert att1 > att2



# Generated at 2022-06-21 00:02:25.520044
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    a1 = Attribute(isa='foo')
    a2 = Attribute(isa='foo', priority=1)
    a3 = Attribute(isa='foo', priority=1)
    a4 = Attribute(isa='foo', priority=2)

    assert a1.__gt__(a2)
    assert not a1.__gt__(a4)
    assert not a2.__gt__(a1)
    assert not a2.__gt__(a3)
    assert not a2.__gt__(a4)
    assert a4.__gt__(a2)
    assert a4.__gt__(a3)


# Generated at 2022-06-21 00:02:30.834130
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)

    assert not (attr1 != attr1)
    assert attr2 != attr1
    assert attr1 != attr2
    assert not (attr1 != attr3)

# Generated at 2022-06-21 00:02:34.454129
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr2.priority = 10

    assert attr2.priority == 10
    assert attr1 <= attr2


# Generated at 2022-06-21 00:02:35.633786
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert a >= b

# Generated at 2022-06-21 00:02:39.979904
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test1 = Attribute()
    test2 = Attribute()
    test1.priority = 1
    test2.priority = 2
    if not test1 != test2:
        raise AssertionError("Unit test for method __ne__ of class Attribute failed")


# Generated at 2022-06-21 00:02:51.408652
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    def check_equal(x,y):
        assert(x == y)
        assert(y == x)
        assert(not x != y)
        assert(not y != x)
        assert(not x < y)
        assert(not y < x)
        assert(x <= y)
        assert(y <= x)
        assert(not x > y)
        assert(not y > x)
        assert(x >= y)
        assert(y >= x)
    def check_not_equal(x,y):
        assert(x != y)
        assert(y != x)
        assert(not x == y)
        assert(not y == x)
        assert(x < y or y < x)
        assert(x <= y or y <= x)
        assert(x > y or y > x)

# Generated at 2022-06-21 00:03:02.053238
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=True, default=dict, required=False, inherit=False, alias='foo')
    assert attr.isa == 'dict'
    assert attr.private == True
    assert attr.default == dict
    assert attr.required == False
    assert attr.inherit == False
    assert attr.alias == 'foo'

    attr = Attribute(isa='dict', private=True, default=dict(a='b'), required=False, inherit=False, alias='foo')
    assert attr.isa == 'dict'
    assert attr.private == True
    assert attr.default == dict(a='b')
    assert attr.required == False
    assert attr.inherit == False
    assert attr.alias == 'foo'

    attr = Attribute

# Generated at 2022-06-21 00:03:05.538150
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 < a1
    assert a1 >= a2


# Generated at 2022-06-21 00:03:06.639694
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert (Attribute(priority=1)) != (Attribute(priority=2)) , "Should be True"


# Generated at 2022-06-21 00:03:12.976262
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    if not attr1.__le__(attr2):
        raise AssertionError('Attribute(priority=1) > Attribute(priority=2)')
    if not attr1.__le__(attr3):
        raise AssertionError('Attribute(priority=1) > Attribute(priority=3)')
    if not attr2.__le__(attr3):
        raise AssertionError('Attribute(priority=2) > Attribute(priority=3)')
    if attr2.__le__(attr1):
        raise AssertionError('Attribute(priority=2) < Attribute(priority=1)')

# Generated at 2022-06-21 00:03:15.658104
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert(isinstance(attr, Attribute))
    assert(isinstance(attr, FieldAttribute))

# Generated at 2022-06-21 00:03:19.480163
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 100
    b = Attribute()
    b.priority = 99
    assert a > b
    assert not b > a
    b.priority = 101
    assert not a > b
    assert b > a
    b.priority = 100
    assert not a > b
    assert not b > a


# Generated at 2022-06-21 00:03:24.866222
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    ''' Test the method __lt__ of class Attribute
    '''
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert not (a1 < a1)
    assert a1 < a2
    assert not (a2 < a1)


# Generated at 2022-06-21 00:03:25.992409
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    assert Attribute() != Attribute()

# Generated at 2022-06-21 00:03:29.437090
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute(priority=1)
    assert attribute.__gt__(Attribute(priority=2)) is True
    assert attribute.__gt__(Attribute(priority=1)) is False



# Generated at 2022-06-21 00:03:36.110323
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print('Testing __le__() method of class Attribute')
    test1=Attribute(priority=10)
    test2=Attribute(priority=11)
    if test1 <= test2:
        print('Passed test 1')
    else:
        print('Failed test 1')
    if not (test1 <= test1):
        print('Passed test 2')
    else:
        print('Failed test 2')

# Generated at 2022-06-21 00:03:45.536237
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    '''
    This test checks for the correct behavior of method __ge__ of class Attribute.
    It does so by creating instances of class Attribute and comparing them according to the method.
    This method is used to compare two instances of the class Attribute, in order to sort them.
    '''

    instance_1 = Attribute(priority = 0)
    instance_2 = Attribute(priority = 4)

    assert instance_2 >= instance_1
    assert not(instance_1 >= instance_2)
    assert instance_1 >= instance_1
    assert instance_2 >= instance_2


# Generated at 2022-06-21 00:03:47.180320
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    target_class = Attribute
    target_method = '__ne__'

    methods_and_properties = dir(target_class)
    methods = [ a for a in methods_and_properties if not a.startswith('__') ]

    for method in methods:
        assert method != target_method


# Generated at 2022-06-21 00:03:52.298448
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test when the priority of other is less than the priority of self
    a_1 = Attribute()
    a_2 = Attribute(priority=2)
    assert a_2 <= a_1

    # Test when the priority of other is equal to the priority of self
    a_1 = Attribute()
    a_2 = Attribute()
    assert a_2 <= a_1

    # Test when the priority of other is greater than the priority of self
    a_1 = Attribute()
    a_2 = Attribute(priority=1)
    assert not a_2 <= a_1


# Generated at 2022-06-21 00:03:55.766707
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)
    assert not Attribute(priority=0) == Attribute(priority=1)


# Generated at 2022-06-21 00:04:03.622486
# Unit test for constructor of class Attribute
def test_Attribute():
    # Testing only for init
    result = Attribute(
        isa='boolean',
        private=True,
        default='no',
        required=True,
        listof='boolean',
        priority=10,
        class_type='boolean',
        always_post_validate=True,
        inherit=False,
        alias='check',
        extend=False,
        prepend=False,
        static=True,
    )

    assert result is not None


# Generated at 2022-06-21 00:04:09.341735
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(isa=None,
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=0,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False)
    b = Attribute(isa=None,
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=1,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False)
    print(b >= a)

test_Attribute___ge__

# Generated at 2022-06-21 00:04:21.012404
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    import unittest

    class Test_Attribute___lt__(unittest.TestCase):
        def test_case_1(self):

            # Setup
            attr1 = Attribute(priority=1)
            attr2 = Attribute(priority=2)

            # Expectations

            # Execution
            result = attr2 < attr1

            # Verification
            self.assertEqual(result, False)

        def test_case_2(self):

            # Setup
            attr1 = Attribute(priority=1)
            attr2 = Attribute(priority=2)

            # Expectations

            # Execution
            result = attr1 < attr2

            # Verification
            self.assertEqual(result, True)


# Generated at 2022-06-21 00:04:28.939968
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Unit test for method __le__ of class Attribute

    """

    # Set up variables, test class and test data
    a1 = Attribute(private=False, default=None, required=False, priority=0)
    a2 = Attribute(private=False, default=None, required=False, priority=1)
    a3 = Attribute(private=False, default=None, required=False, priority=0)
    a4 = Attribute(private=False, default=None, required=False, priority=3)
    a5 = Attribute(private=False, default=None, required=False, priority=4)
    # Check result of method __le__
    assert a1 <= a1
    assert a1 <= a2
    assert a1 <= a3
    assert not a1 <= a4
    assert not a1

# Generated at 2022-06-21 00:04:33.038006
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field = Attribute(priority=1)
    another_field = Attribute(priority=0)
    assert field > another_field


# Generated at 2022-06-21 00:04:36.104142
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    obj1=Attribute()
    obj2=Attribute()
    obj1.priority=1
    obj2.priority=2
    assert not (obj1 <= obj2)


# Generated at 2022-06-21 00:04:40.028484
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    result = FieldAttribute(isa='int', default=10, required=True)
    assert result._kwargs == {'required': True, 'default': 10}, "FieldAttribute constructor error"
    assert result.default == 10, "FieldAttribute constructor error with default constructor"


# Generated at 2022-06-21 00:04:42.260718
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert b > a

# Generated at 2022-06-21 00:04:42.912480
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass

# Generated at 2022-06-21 00:04:54.588536
# Unit test for constructor of class Attribute
def test_Attribute():
    class Test:
        foo = Attribute(isa='string', private=True, default='bar', required=True,
                listof='string', priority=1, class_type='string', always_post_validate=True,
                inherit=False, alias='bar', extend=True, prepend=False, static=True)
        bar = FieldAttribute(isa='string', private=True, default='bar', required=True,
                listof='string', priority=1, class_type='string', always_post_validate=True,
                inherit=False, alias='bar', extend=True, prepend=False, static=True)

    assert Test.bar == Test.foo
    assert Test.foo.__class__ == Attribute
    assert Test.bar.__class__ == FieldAttribute



# Generated at 2022-06-21 00:05:02.254209
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=10)
    assert attr.__ne__(Attribute(priority=10)) == False
    assert attr.__ne__(Attribute(priority=20)) == True


# Generated at 2022-06-21 00:05:04.598089
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=2)
    attribute2 = Attribute(priority=2)
    assert attribute1.__eq__(attribute2)


# Generated at 2022-06-21 00:05:06.039601
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='string')
    assert field.isa == 'string'



# Generated at 2022-06-21 00:05:08.718808
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert a2 > a1


# Generated at 2022-06-21 00:05:19.295596
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Unit test for method __le__ of class Attribute
    """
    import os, sys, time
    from time import sleep
    from runs.helpers.logger import log
    from runs.helpers import helpers, environment

    sleep(0.7777)

    log.info('Test for method __le__ of class Attribute in runs/helpers/module_docs.py starts')

    assert True == Attribute(priority = 1) <= Attribute(priority = 1)
    assert True == Attribute(priority = 1) <= Attribute(priority = 2)
    assert False == Attribute(priority = 2) <= Attribute(priority = 1)

    log.info('Test for method __le__ of class Attribute in runs/helpers/module_docs.py is finished')

    return True


# Generated at 2022-06-21 00:05:27.896244
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa=str, private=False, default="test", required=False,
        listof=None, priority=0, class_type=None, always_post_validate=False,
        inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert attr.isa == str
    assert attr.private == False
    assert attr.default == "test"
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr

# Generated at 2022-06-21 00:05:30.245712
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    obj1 = Attribute()
    obj2 = Attribute()

    obj1.priority = 1
    obj2.priority = 2

    assert (obj2 >= obj1)


# Generated at 2022-06-21 00:05:32.058360
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 >= a1


# Generated at 2022-06-21 00:05:35.268121
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attrib = Attribute()
    attrib2 = Attribute()
    attrib.priority = 0
    attrib2.priority = 0
    assert not attrib.__lt__(attrib2)
    attrib.priority = 1
    assert attrib.__lt__(attrib2)


# Generated at 2022-06-21 00:05:37.047522
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    Attribute.__ne__(None, None)



# Generated at 2022-06-21 00:05:48.894822
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
     a1 = Attribute()
     a1.priority = 5
     a2 = Attribute()
     a2.priority = 3
     return a1 > a2



# Generated at 2022-06-21 00:05:54.786010
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(default="world", priority=8)
    a2 = Attribute(default="hello", priority=4)
    if a1.__gt__(a2):
        print('a1.__gt__(a2) is True')
    if not a1.__lt__(a2):
        print('a1.__lt__(a2) is False')


# Generated at 2022-06-21 00:05:58.640394
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_1 = Attribute(priority=3)
    attr_2 = Attribute(priority=5)
    assert attr_2.__gt__(attr_1) == True



# Generated at 2022-06-21 00:06:06.989718
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import OrderedDict

    a = Attribute(default=1)
    assert a.default == 1

    b = Attribute(default=dict())
    assert b.default != {}
    assert b.default() == {}

    c = Attribute(default=OrderedDict())
    assert c.default != OrderedDict()
    assert c.default() == OrderedDict()

    from ansible.playbook.base import Base
    d = Attribute(default=Base())
    assert Base() == d.default
    assert Base() is not d.default

# Generated at 2022-06-21 00:06:15.783911
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(private=True, priority=0, required=True)
    attr2 = Attribute(private=True, priority=0, required=True)
    attr3 = Attribute(private=True, priority=0, required=False)
    attr4 = Attribute(private=True, priority=1, required=True)
    attr5 = Attribute(private=False, priority=0, required=True)

    assert attr1 == attr2
    assert not attr1 == attr3
    assert not attr1 == attr4
    assert not attr1 == attr5



# Generated at 2022-06-21 00:06:18.077386
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority = 10)
    b = Attribute(priority = 5)
    return a <= b

# Generated at 2022-06-21 00:06:24.692432
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(1)
    a2 = Attribute(2)
    a3 = Attribute(2)
    assert not a1 > a1
    assert not a1 > a2
    assert a2 > a1
    assert not a2 > a3
    assert not a3 > a1
    assert not a3 > a2


# Generated at 2022-06-21 00:06:30.459375
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    class Test1(Attribute):
        def __init__(self, priority):
            self.priority = priority

    class Test2(Attribute):
        def __init__(self, priority):
            self.priority = priority

    # Need to refactor
    test1 = Test1(2)
    test2 = Test2(1)
    print (test1 <= test2)

test_Attribute___le__()

# Generated at 2022-06-21 00:06:32.432877
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='str')
    assert attr.isa == 'str'



# Generated at 2022-06-21 00:06:36.535779
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_1 = Attribute(isa=1, priority=1)
    attribute_2 = Attribute(isa=2, priority=2)
    assert attribute_1.__ge__(attribute_2) == False
    assert attribute_2.__ge__(attribute_1) == True


# Generated at 2022-06-21 00:07:01.171343
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    att1 = Attribute()
    att2 = Attribute()
    att3 = Attribute()

    att2.priority = 2
    att3.priority = 1

    assert att3 < att2
    assert not att1 < att1
    assert not att2 < att1
    assert not att2 < att3


# Generated at 2022-06-21 00:07:04.000615
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    obj1 = Attribute(priority=1)
    obj2 = Attribute(priority=2)

    assert obj2 < obj1
    assert obj1 > obj2



# Generated at 2022-06-21 00:07:11.845470
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """Method to test the __ge__ method of class Attribute"""
    obj1 = Attribute(priority=10)
    obj2 = Attribute(priority=20)
    obj3 = Attribute(priority=20)
    obj4 = Attribute(priority=10)

    assert obj1.__ge__(obj2)
    assert obj2.__ge__(obj3)
    assert obj3.__ge__(obj1)
    assert obj1.__le__(obj4)
    assert obj4.__ge__(obj3)



# Generated at 2022-06-21 00:07:14.713874
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(isa='dict', priority=0)
    a2 = Attribute(isa='dict', priority=1)
    assert a2 > a1


# Generated at 2022-06-21 00:07:18.581173
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)

    assert (attr1.__eq__(attr3) == True)
    assert (attr2.__eq__(attr3) == False)


# Generated at 2022-06-21 00:07:21.783212
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """ Unit test for method __lt__ of class Attribute """

    #create two Attribute objects with different priority
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    #attr2 must be greater than attr1
    assert attr2>attr1


# Generated at 2022-06-21 00:07:25.632648
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__ge__(attr1) == False
    assert attr2.__ge__(attr2) == True

# Generated at 2022-06-21 00:07:29.656375
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
  fieldAttribute = FieldAttribute()
  fieldAttribute.priority = 2
  attribute = Attribute()
  attribute.priority = 1
  result = fieldAttribute.__le__(attribute)
  assert result == False, "Attribute.__le__() failed"


# Generated at 2022-06-21 00:07:39.308813
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    a = Attribute(alias="b", private=True)
    a = Attribute(isa="int", private=True, required=True, default=0)
    a = Attribute(isa="class", private=True, inherit=False, extend=True, prepend=False)
    a = Attribute(isa="yaml", private=False, required=True, default={}, listof=None, always_post_validate=True, inherit=False, alias="test", extend=False, prepend=True)
    a = Attribute(isa="dict", class_type=None, default={}, priority=5, private=False, required=False)
    assert True

# Generated at 2022-06-21 00:07:41.253528
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest

    with pytest.raises(TypeError):
        FieldAttribute(default={})

# Generated at 2022-06-21 00:08:29.470117
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Test case: a < b
    # 1 < 2
    a = FieldAttribute()
    a.priority = 1
    b = FieldAttribute()
    b.priority = 2
    expected = True
    result = a.__lt__(b)
    assert result == expected

    # Test case: a > b
    # 2 > 1
    a = FieldAttribute()
    a.priority = 2
    b = FieldAttribute()
    b.priority = 1
    expected = True
    result = a.__lt__(b)
    assert result == expected

    # Test case: a < b
    # 1 > 1
    a = FieldAttribute()
    a.priority = 1
    b = FieldAttribute()
    b.priority = 1
    expected = False
    result = a.__lt__(b)
    assert result == expected



# Generated at 2022-06-21 00:08:31.989831
# Unit test for constructor of class Attribute
def test_Attribute():
    """
    Test that a default default value produces no error.
    """
    field = Attribute(isa='str')



# Generated at 2022-06-21 00:08:41.871899
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    # create a new Attribute object for comparison
    attribute = Attribute(priority=0)

    # Create a new Attribute object with a priority equal to
    # that of the Attribute object created above
    attribute2 = Attribute(priority=0)

    assert (attribute >= attribute2)

    # Create a new Attribute object with a priority greater than
    # that of the Attribute object created above
    attribute3 = Attribute(priority=1)

    assert (attribute >= attribute3)

    # Create a new Attribute object with a priority less than
    # that of the Attribute object created above
    attribute4 = Attribute(priority=-1)

    assert (attribute >= attribute4)



# Generated at 2022-06-21 00:08:46.020924
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute=Attribute()
    attribute.priority=0
    other=Attribute()
    other.priority=0
    assert attribute.__ne__(other)==False
    assert attribute.__eq__(other)==True


# Generated at 2022-06-21 00:08:57.608316
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa="str", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a2 = Attribute(isa="str", private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a3 = Attribute(isa="str", private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a4 = 'hello world'
    assert (a1 == a2) is True

# Generated at 2022-06-21 00:08:59.762366
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    a.priority

    b = Attribute()
    b.priority

    assert a != b
    assert a == a
    assert b == b


# Generated at 2022-06-21 00:09:03.173279
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class Foo(object):
        one = FieldAttribute(
            priority=1
        )

        two = FieldAttribute(
            priority=2
        )

    assert Foo.one >= Foo.two



# Generated at 2022-06-21 00:09:07.925164
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert not Attribute() < Attribute()
    assert not Attribute(priority=1) < Attribute(priority=1)
    assert Attribute(priority=2) < Attribute(priority=1)
    assert not Attribute(priority=3) < Attribute(priority=2)



# Generated at 2022-06-21 00:09:12.205390
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 1
    attr_other = Attribute()
    attr_other.priority = 2
    assert attr != attr_other
    attr_other.priority = 0
    assert attr != attr_other



# Generated at 2022-06-21 00:09:23.667331
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(
        isa='str',
        private=False,
        default=None,
        class_type=None,
        required=False,
        listof=None,
        priority=0,
        always_post_validate=False,
        inherit=True,
    )
    assert fa.isa == 'str'
    assert not fa.private
    assert fa.default is None
    assert fa.class_type is None
    assert not fa.required
    assert fa.listof is None
    assert fa.priority == 0
    assert not fa.always_post_validate
    assert fa.inherit

    # Filter out all class attributes in the FieldAttribute object
    fafilter = set(field for field in dir(fa) if not field.startswith('__'))
    # Define the expected

# Generated at 2022-06-21 00:10:57.209616
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    data_type = 'dict'
    is_private = False
    default_value = None
    is_required = False
    list_of = None
    priority = 0
    class_type = None
    always_post_validate = False
    will_inherit = True
    alias = None
    extend_by = False
    prepend_to = False

    fa = FieldAttribute(data_type, is_private, default_value, is_required, list_of, priority, class_type,
        always_post_validate, will_inherit, alias, extend_by, prepend_to)

    # Make sure data_type is set correctly
    assert fa.isa == data_type

    # Make sure is_private is set correctly
    assert fa.private == is_private

    # Make sure default_value is set correctly

# Generated at 2022-06-21 00:11:07.811319
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False
