

# Generated at 2022-06-21 00:01:07.744266
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = FieldAttribute()
    a.priority = 10
    b = Attribute()
    b.priority = 20
    print(a.__gt__(b))


# Generated at 2022-06-21 00:01:08.192416
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()


# Generated at 2022-06-21 00:01:10.777833
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b.__le__(a)


# Generated at 2022-06-21 00:01:14.765136
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=10)
    if a >= b:
        print('Test Attribute.__ge__() passed')
    else:
        print('Test Attribute.__ge__() failed')


# Generated at 2022-06-21 00:01:18.632383
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa is None
    assert Attribute().private is False
    assert Attribute().always_post_validate is False
    assert Attribute().extend is False
    assert Attribute().prepend is False

# Generated at 2022-06-21 00:01:27.227706
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 1)

# Generated at 2022-06-21 00:01:30.020869
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=5)
    assert attr1.__ge__(attr2)


# Generated at 2022-06-21 00:01:41.476900
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Tests method __le__ of Attribute.
    """

    # Test Attribute without alias
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    assert a1 <= a2  # a1 has smaller priority than a2
    assert not a2 <= a1  # a2 has larger priority than a1

    # Test Attribute with alias
    a3 = Attribute(priority=9, alias='alias')
    a4 = Attribute(priority=11, alias='alias')
    assert a3 <= a4  # a3 has smaller priority than a4
    assert not a4 <= a3  # a4 has larger priority than a3

    # Test FieldAttribute without alias
    f1 = FieldAttribute(priority=0)
    f2 = FieldAttribute(priority=1)
    assert f1

# Generated at 2022-06-21 00:01:45.360308
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=3)
    b = Attribute(priority=4)
    c = Attribute(priority=3)
    assert a <= b
    assert a <= c
    assert b >= a
    assert a >= c



# Generated at 2022-06-21 00:01:47.273308
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute(priority=1)
    assert a <= b


# Generated at 2022-06-21 00:01:52.079409
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(isa=int, priority=3)
    attr2 = Attribute(isa=int, priority=4)
    assert attr2.__gt__(attr1) is True

# Generated at 2022-06-21 00:01:58.152219
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()

    assert a <= b
    assert b >= a
    assert not a == b
    assert not b == a
    assert a != b
    assert not a > b
    assert not b < a

debuggable = Attribute(
    private=True,
    always_post_validate=True
)

takes_context = Attribute(
    private=True,
    always_post_validate=True
)

boolean = Attribute(
    isa='bool',
    default=False
)

identity = Attribute(
    isa='str',
    required=True
)

token = Attribute(
    isa='str'
)

variable = Attribute(
    isa='str'
)

special_parameter = Attribute

# Generated at 2022-06-21 00:02:02.802788
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute('dict', default=dict, priority=0)
    b = Attribute('dict', default=dict, priority=1)
    assert (a.__ge__(b)) == False
    assert (b.__ge__(a)) == True



# Generated at 2022-06-21 00:02:06.820888
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priotity=1)
    b = Attribute(priotity=2)
    c = Attribute(priotity=1)
    assert a == c
    assert a != b
    assert b != c


# Generated at 2022-06-21 00:02:09.817675
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert(attr1 == attr2)


# Generated at 2022-06-21 00:02:12.090366
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a != b


# Generated at 2022-06-21 00:02:14.476341
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Setup a few Attribute instances
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=10)

# Generated at 2022-06-21 00:02:26.524914
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    at1 = Attribute(isa='integer', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    at2 = Attribute(isa='integer', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)
    at3 = Attribute(isa='integer', private=False, default=None, required=False, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=True, alias=None)

# Generated at 2022-06-21 00:02:30.910011
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    assert a < b, 'method __gt__ of FieldAttribute class failed!'
    assert b > a, 'method __gt__ of FieldAttribute class failed!'


# Generated at 2022-06-21 00:02:38.589795
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(default=11)
    attr2 = Attribute(default=23)
    attr3 = Attribute(default=23)
    assert attr2 < attr1
    assert attr2 <= attr1
    assert not attr2 < attr3
    assert attr2 <= attr3
    assert attr1 < attr2
    assert attr1 <= attr2
    assert not attr3 < attr2
    assert attr3 <= attr2


# TODO: wrap each of these in a method and add default get/set boilerplate
# allow override of get/set?

# Generated at 2022-06-21 00:02:43.448784
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=0, default=1)
    a2 = Attribute(priority=1, default=1)
    assert( a1 >= a2 )



# Generated at 2022-06-21 00:02:45.884355
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute()
    y = Attribute()
    assert x.__ne__(y) is False


# Generated at 2022-06-21 00:02:50.439843
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    # bool value of an instance is whether the instance has a non-zero value
    assert not attr

    attr = Attribute(isa='int')
    assert attr

    attr = Attribute(isa='int', default=3)
    assert attr

# Generated at 2022-06-21 00:02:55.632724
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert a1 < a3
    assert not a2 < a1
    assert not a3 < a1



# Generated at 2022-06-21 00:02:57.353068
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()

# these are used by base.py for the base object field descriptor class



# Generated at 2022-06-21 00:03:08.237511
# Unit test for constructor of class Attribute
def test_Attribute():
    res = Attribute(isa='dict')
    assert res.isa == 'dict'

    res = Attribute(isa='dict', private=False)
    assert res.isa == 'dict'
    assert res.private is False

    res = Attribute(isa='dict', private=True)
    assert res.isa == 'dict'
    assert res.private is True

    res = Attribute(isa='dict', default=None)
    assert res.isa == 'dict'
    assert res.default is None

    res = Attribute(isa='dict', default='test')
    assert res.isa == 'dict'
    assert res.default == 'test'

    res = Attribute(isa='dict', required=False)
    assert res.isa == 'dict'
    assert res.required is False


# Generated at 2022-06-21 00:03:11.267713
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 0
    return a >= b


# Generated at 2022-06-21 00:03:13.452327
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=10)
    b = Attribute(priority=9)
    assert a >= b
    assert not a <= b
    assert a >= a
    assert not a <= a

# Generated at 2022-06-21 00:03:16.331334
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute(priority=1);
    attr_p = Attribute(priority=2);

    assert attr < attr_p

    attr.priority = 2
    attr_p.priority = 1

    assert attr > attr_p


# Generated at 2022-06-21 00:03:18.613985
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2.__gt__(a1)


# Generated at 2022-06-21 00:03:32.354709
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    # Case: default
    o1 = Attribute()
    o2 = Attribute()
    assert o1.__le__(o2) == True
    assert o2.__le__(o1) == True

    # Case: not equal
    o1 = Attribute(priority=2)
    o2 = Attribute(priority=3)
    assert o1.__le__(o2) == True
    assert o2.__le__(o1) == False

    # Case: equal
    o1 = Attribute(priority=4)
    o2 = Attribute(priority=4)
    assert o1.__le__(o2) == True
    assert o2.__le__(o1) == True

# Generated at 2022-06-21 00:03:33.859427
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)


# Generated at 2022-06-21 00:03:35.049144
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=0)
    attr1 = Attribute(priority=1)
    assert attr__ne__(attr, attr1) == False


# Generated at 2022-06-21 00:03:39.545130
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_1 = Attribute()
    attr_2 = Attribute()
    attr_1.priority = 100
    attr_2.priority = 200
    assert attr_1.__lt__(attr_2) == True

# Generated at 2022-06-21 00:03:43.408202
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    assert (Attribute(priority=0) > Attribute(priority=1)) is True
    assert (Attribute(priority=1) > Attribute(priority=0)) is False

# Generated at 2022-06-21 00:03:45.956223
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    assert a != 3
    assert 3 != a



# Generated at 2022-06-21 00:03:50.747815
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=3)
    assert a.__ge__(b)
    assert a.__ge__(c) == False
    assert c.__ge__(a)


# Generated at 2022-06-21 00:03:53.446499
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    f = FieldAttribute()
    f.priority = 1
    assert not (f != f)


# Generated at 2022-06-21 00:04:04.283312
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test id: 0
    attr1 = Attribute(
        required=True,
        isa='dict',
        class_type=dict,
        priority=5,
        listof='dict',
        private=False,
        default=dict,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:04:16.326658
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    attribute = Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    '''
    attribute = Attribute()

    assert attribute.isa == None
    assert attribute.private == False
    assert attribute.default == None
    assert attribute.required == False
    assert attribute.listof == None
    assert attribute.priority == 0
    assert attribute.class_type == None
    assert attribute.always_post_validate == False
    assert attribute.inherit == True

# Generated at 2022-06-21 00:04:23.518085
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__ge__(b) == False
    assert b.__ge__(a) == True
    assert a.__ge__(a) == True
    assert b.__ge__(b) == True

# Generated at 2022-06-21 00:04:26.902400
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 2)
    attr3 = Attribute(priority = 1)
    assert(attr1 != attr2)
    assert(attr1 == attr3)


# Generated at 2022-06-21 00:04:29.733023
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = FieldAttribute(priority=1)
    field2 = FieldAttribute(priority=1)
    field3 = FieldAttribute(priority=3)
    assert field1 == field2
    assert field1 != field3


# Generated at 2022-06-21 00:04:34.307894
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: how to test calls to __init__
    #include_role_tasks = Attribute(isa='list')
    pass

# Generated at 2022-06-21 00:04:37.638483
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_1 = Attribute(priority = 1)
    attr_2 = Attribute(priority = 2)
    assert attr_2 >= attr_1
    assert not attr_1 >= attr_2


# Generated at 2022-06-21 00:04:49.392961
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(always_post_validate=False, private=False, listof=None, required=False, static=False,
                           prepend=False, extend=False, inherit=False, class_type=None, isa=None, alias=None,
                           priority=0, default=None)
    attribute2 = Attribute(always_post_validate=False, private=False, listof=None, required=False, static=False,
                           prepend=False, extend=False, inherit=False, class_type=None, isa=None, alias=None,
                           priority=1, default=None)

    if attribute1 > attribute2:
        return "Test Pass"
    else:
        return "Test Fail"

print(test_Attribute___gt__())



# Generated at 2022-06-21 00:05:00.890327
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='s',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=False,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    assert attr.isa == 's'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == False

# Generated at 2022-06-21 00:05:02.254420
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=1) != Attribute(priority=2)


# Generated at 2022-06-21 00:05:12.207991
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    name        = 'Foo'
    default     = None
    isa         = dict
    listof      = None
    static      = False
    private     = False
    required    = False
    priority    = 0
    class_type  = None

    field = FieldAttribute('Foo', default, isa, listof, static, private, required, priority, class_type)

    if field.name != name:
        raise AttributeError('test_FieldAttribute(): field is not initialized with name')

    if field.default != default:
        raise AttributeError('test_FieldAttribute(): field is not initialized with default')

    if field.isa != isa:
        raise AttributeError('test_FieldAttribute(): field is not initialized with isa')


# Generated at 2022-06-21 00:05:17.011251
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    inst1 = Attribute(priority=1)
    inst2 = Attribute(priority=0)
    inst3 = Attribute(priority=0)
    assert (inst1 >= inst2)
    assert (inst2 >= inst3)
    assert not (inst3 >= inst1)


# Generated at 2022-06-21 00:05:22.957370
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert(Attribute(isa='list').isa == 'list')



# Generated at 2022-06-21 00:05:26.149288
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    return not (a1 < a2) and not (a1 > a2) and (a1 <= a2) and not (a1 >= a2)


# Generated at 2022-06-21 00:05:28.390179
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a <= b


# Generated at 2022-06-21 00:05:30.022663
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)

    assert not (a > None)



# Generated at 2022-06-21 00:05:32.796982
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    attr.priority = 1
    attr1 = Attribute()
    attr1.priority = 2
    assert attr.__ge__(attr1)

# Generated at 2022-06-21 00:05:43.638714
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute(
        'bool',
        default=False,
        required=True,
        listof=False,
        priority=100,
        class_type=bool,
        always_post_validate=False,
        inherit=False,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert attr.isa == 'bool'
    assert attr.default == False
    assert attr.required == True
    assert attr.listof == False
    assert attr.priority == 100
    assert attr.class_type == bool
    assert attr.always_post_validate == False
    assert attr.inherit == False
    assert attr.alias == None
    assert attr.extend == False

# Generated at 2022-06-21 00:05:46.384933
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = FieldAttribute(priority=0)
    attr2 = FieldAttribute(priority=1)
    attr3 = FieldAttribute(priority=1)

    assert attr2.__lt__(attr1) == True
    assert attr1.__lt__(attr2) == False
    assert attr3.__lt__(attr2) == False
    assert attr3.__lt__(attr1) == True



# Generated at 2022-06-21 00:05:50.020476
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority = 1)
    a2 = Attribute(priority = 2)
    #N.B. not is a1.__gt__(a2) because the method is not called
    assert a1 > a2 #checks __gt__ method of Attribute

# Generated at 2022-06-21 00:05:57.789974
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    class A:
        def __init__(self, priority):
            self.priority = priority

    class B:
        def __init__(self, priority):
            self.priority = priority

    a = A(1)
    b = B(2)
    c = Attribute(default=1)
    d = Attribute(default=2)

    assert a < b
    assert c < d
    assert not a < c
    assert not c < a



# Generated at 2022-06-21 00:06:00.026967
# Unit test for constructor of class Attribute
def test_Attribute():

    # default is required
    with pytest.raises(TypeError):
        Attribute(isa='dict', default=None)



# Generated at 2022-06-21 00:06:14.119228
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert (Attribute(priority=1) < Attribute(priority=2)) is True
    assert (Attribute(priority=0) < Attribute(priority=1)) is True
    assert (Attribute(priority=2) < Attribute(priority=0)) is False
    assert (Attribute(priority=2) < Attribute(priority=2)) is False


# Generated at 2022-06-21 00:06:16.987687
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    Test case for method Attribute::__lt__
    """

    a = Attribute(priority=0)
    b = Attribute(priority=1)

    assert not (a < b)
    assert (b < a)


# Generated at 2022-06-21 00:06:29.102078
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    print("Testing FieldAttribute")
    print("Test1: does it accept all the optional arguments?")
    a = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias="an_alias",
        extend=False,
        prepend=False,
        static=False,
    )
    print("Test1 passed")

    print("Test2: does it accept all the optional arguments?")

# Generated at 2022-06-21 00:06:30.952970
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    assert not a < a
    assert a < b
    assert a < c
    assert b < c


# Generated at 2022-06-21 00:06:40.364677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr_1 = FieldAttribute()
    assert attr_1.isa is None
    assert attr_1.private is False
    assert attr_1.default is None
    assert attr_1.required is False
    assert attr_1.listof is None
    assert attr_1.priority == 0
    assert attr_1.class_type is None
    assert attr_1.always_post_validate is False
    assert attr_1.inherit is True
    assert attr_1.alias is None
    assert attr_1.extend is False
    assert attr_1.prepend is False
    assert attr_1.static is False

    attr_2 = FieldAttribute(priorty=2)
    assert attr_2.priority == 2

    # fail case

# Generated at 2022-06-21 00:06:43.437245
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()
    assert fa is not None


# Generated at 2022-06-21 00:06:49.090989
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Test when priority attributes are not equal
    Attribute1 = Attribute(priority=0)
    Attribute2 = Attribute(priority=1)
    assert Attribute1 != Attribute2

    # Test when priority attributes are equal
    Attribute3 = Attribute(priority=1)
    assert Attribute2 != Attribute3


# Generated at 2022-06-21 00:06:55.981644
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    global _CONTAINERS
    t1=Attribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:06:59.790519
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(is_a=1, priority=0)
    b = Attribute(is_a=1, priority=1000)
    if(a.__ge__(b)):
        exit(1)



# Generated at 2022-06-21 00:07:06.187942
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(1) <= Attribute(2)
    assert Attribute(1) <= Attribute(1)
    assert Attribute(1, priority=1) <= Attribute(2, priority=2)
    assert Attribute(1, priority=2) <= Attribute(2, priority=1)
    assert Attribute(1, priority=1) <= Attribute(1, priority=1)


# Generated at 2022-06-21 00:07:25.365559
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority = 1)
    b = Attribute(priority = 1)
    if a != b:
        assert False


# Generated at 2022-06-21 00:07:28.960435
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from collections import OrderedDict

    a = FieldAttribute(priority=1)
    b = FieldAttribute(priority=2)

    assert a < b
    assert not a > b

    assert b > a
    assert not b < a



# Generated at 2022-06-21 00:07:38.638712
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # First, we check that Attribute.__le__ has been implemented
    attribute_instance = Attribute()
    assert hasattr(attribute_instance.__le__, '__call__'), "Attribute class doesn't implement __le__"
    # Then, we check the comparison works
    test_attributes = [Attribute(priority=attrib_prio) for attrib_prio in range(3)]
    for attrib_prio in range(3):
        for tested_attrib in test_attributes:
            assert attribute_instance.__le__(tested_attrib) == (tested_attrib.priority <= attrib_prio), 'Wrong __le__ comparison'



# Generated at 2022-06-21 00:07:40.046030
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority = 1) < Attribute(priority = 2)


# Generated at 2022-06-21 00:07:41.784581
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert(False == (attr1 != attr2))


# Generated at 2022-06-21 00:07:44.155404
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a=Attribute()
    b=Attribute()
    assert (a.__lt__(b)==False)


# Generated at 2022-06-21 00:07:46.061764
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=10)

    assert a2 > a1


# Generated at 2022-06-21 00:07:47.734654
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(alias='foo')
    assert f.alias == 'foo'


# Generated at 2022-06-21 00:07:49.694652
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority = 5)
    b = Attribute(priority = 10)

    assert(a < b)


# Generated at 2022-06-21 00:07:55.648274
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    a.priority = 0
    b = Attribute()
    b.priority = 0
    c = Attribute()
    c.priority = 1
    assert a == b, "Failed: a == b"
    assert a != c, "Failed: a != c"


# Generated at 2022-06-21 00:08:58.126184
# Unit test for constructor of class Attribute
def test_Attribute():

    # Verify __init__ without any required arguments
    attr = Attribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False

    # Verify __init__ with partial required arguments
    attr = Attribute(isa='boolean', default=True, required=True, 
            extend=True, prepend=False)

# Generated at 2022-06-21 00:09:00.193085
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert (attr2 <= attr1) is True



# Generated at 2022-06-21 00:09:03.614841
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute()
    attr.priority = 3
    attr2 = Attribute()
    attr2.priority = 5
    assert attr.__le__(attr2)


# Generated at 2022-06-21 00:09:08.487788
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    field1 = Attribute(priority=10)
    field2 = Attribute(priority=20)

    try:
        assert (field1 >= field2) == True
    except AssertionError:
        print('Attribute.__ge__() failed with priority = 10 and priority = 20')
        raise



# Generated at 2022-06-21 00:09:11.111843
# Unit test for constructor of class Attribute
def test_Attribute():
    attr=Attribute(private=False,required=True,listof=False)
    assert attr.required == True


# Generated at 2022-06-21 00:09:15.993101
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()
    assert(a == b)

    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert(a == b)

    a = Attribute(priority=2)
    b = Attribute(priority=1)
    assert(a > b)

# Generated at 2022-06-21 00:09:20.483735
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert a == b
    assert b == a
    assert a != c
    assert c != a
    assert b != c
    assert c != b


# Generated at 2022-06-21 00:09:25.258508
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute()
    a1.priority = 0
    a2 = Attribute()
    a2.priority = 1
    assert a1.__gt__(a2) == True


# Generated at 2022-06-21 00:09:27.474422
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(1, "str")
    attr2 = Attribute(2, "int")
    assert attr1 == attr2


# Generated at 2022-06-21 00:09:38.604474
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Least priority value
    priority_1 = Attribute(priority=1)
    # Priority value greater than priority_1
    priority_2 = Attribute(priority=2)

    # Test for assert condition priority_1 <= priority_1
    try:
        assert priority_1 <= priority_1
    except:
        print("Test for assert condition priority_1 <= priority_1 FAILED")
    else:
        print("Test for assert condition priority_1 <= priority_1 PASSED")

    # Test for assert condition priority_1 <= priority_2
    try:
        assert priority_1 <= priority_2
    except:
        print("Test for assert condition priority_1 <= priority_2 FAILED")
    else:
        print("Test for assert condition priority_1 <= priority_2 PASSED")

    # Test for assert condition priority_2 <=