

# Generated at 2022-06-21 00:01:08.505378
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    attr = FieldAttribute(isa='str', private=True, default=None, required=True, listof=None, priority=1, class_type=None, always_post_validate=False, inherit=False, alias=None)



# Generated at 2022-06-21 00:01:10.680343
# Unit test for constructor of class Attribute
def test_Attribute():
    with raises(TypeError):
        x = Attribute(isa='list', default=dict())



# Generated at 2022-06-21 00:01:19.084564
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().isa is None
    assert FieldAttribute(isa='str').isa == 'str'
    assert FieldAttribute().listof is None
    assert FieldAttribute(listof='str').listof == 'str'
    assert FieldAttribute(extend=True).extend is True
    assert FieldAttribute(extend=True).prepend is False
    assert FieldAttribute(prepend=True).extend is False
    assert FieldAttribute(prepend=True).prepend is True
    assert FieldAttribute(static=False).static is False
    assert FieldAttribute(static=True).static is True

# Generated at 2022-06-21 00:01:22.119915
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(required=True)
    assert a == a
    new_a = Attribute(priority=1)
    assert a != new_a


# Generated at 2022-06-21 00:01:25.944059
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr10 = Attribute(priority=10)
    attr20 = Attribute(priority=20)
    assert attr20 > attr10



# Generated at 2022-06-21 00:01:27.404060
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert (b < a)



# Generated at 2022-06-21 00:01:36.623135
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    a3 = Attribute(priority=15)
    assert a1 is not a2, "a1 and a2 should not be the same object"
    assert a3 is not a1, "a1 and a3 should not be the same object"
    assert a3 is not a2, "a2 and a3 should not be the same object"
    assert a1 == a2, "priority should be the same"
    assert a1 < a3, "a1's priority is lower than a3's"
    assert not a3 < a1, "a3's priority is higher than a1's"



# Generated at 2022-06-21 00:01:39.858505
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=3)
    attribute2 = Attribute(priority=5)
    assert (attribute1 >= attribute2) == False


# Generated at 2022-06-21 00:01:45.563410
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    fa1 = Attribute(priority=1)
    fa2 = Attribute(priority=2)
    assert fa1.__gt__(fa2) == True
    assert fa2.__gt__(fa1) == False
    assert fa1.__gt__(fa1) == False
    assert fa2.__gt__(fa2) == False


# Generated at 2022-06-21 00:01:49.605999
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    attribute_3 = Attribute(priority=2)
    assert(attribute_1 != attribute_2)
    assert(not (attribute_2 != attribute_3))


# Generated at 2022-06-21 00:01:59.313379
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(private=True, priority=0, default=None, required=True, listof='list', isa='dict')
    other = Attribute(priority=1, private=False, isa='int')

    assert(attr != other)


# Generated at 2022-06-21 00:02:00.863037
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert isinstance(f, Attribute)



# Generated at 2022-06-21 00:02:05.384796
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    c = Attribute(priority=2)
    print(a == a) # True
    print(a == b) # False
    print(a == c) # True


# Generated at 2022-06-21 00:02:14.993632
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    bool_ge_correct = True

    a1 = Attribute(isa=None, private=False, default=None, required=False, listof=None,
                   priority=0, class_type=None, always_post_validate=False, inherit=True,
                   alias=None, extend=False, prepend=False, static=False)

    a2 = Attribute(isa=None, private=False, default=None, required=False, listof=None,
                   priority=1, class_type=None, always_post_validate=False, inherit=True,
                   alias=None, extend=False, prepend=False, static=False)

    assert a2.__ge__(a1) == bool_ge_correct



# Generated at 2022-06-21 00:02:22.652179
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class fakeobj():
        def __init__(self,attrib):
            self.priority = attrib

    a = Attribute('int')
    b = FieldAttribute('int')
    a1 = fakeobj(1)
    a2 = fakeobj(2)
    assert a == b
    assert a != a1
    assert a1 == a1
    assert a1 != a2
    assert a1 < a2
    assert a2 > a1
    assert a1 <= a2
    assert a2 >= a1

# Generated at 2022-06-21 00:02:25.519474
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 >= a2



# Generated at 2022-06-21 00:02:27.551680
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(required=False,default=None)
    b = Attribute(required=False,default=None,priority=2)
    c = Attribute(required=False,default=None,priority=3)
    d = Attribute(required=False,default=None,priority=4)
    assert a <= b <= c <= d


# Generated at 2022-06-21 00:02:30.484666
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    # _CONTAINERS is a read-only object
    # the following code should raise a TypeError
    a.__setattr__('isa', 'dict')

# Generated at 2022-06-21 00:02:35.630840
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    obj = Attribute()
    other = Attribute()

    obj.priority = 1
    other.priority = 2
    assert(other >= obj)

    obj.priority = 2
    other.priority = 1
    assert(other >= obj)

    obj.priority = 2
    other.priority = 2
    assert(other >= obj)



# Generated at 2022-06-21 00:02:47.384725
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test .priority equals .priority
    new_attrib = Attribute()
    new_attrib.priority = 2
    attrib = Attribute()
    attrib.priority = 2
    result = new_attrib.__le__(attrib)
    assert result is True

    # Test .priority not equals .priority
    new_attrib = Attribute()
    new_attrib.priority = 2
    attrib = Attribute()
    attrib.priority = 3
    result = new_attrib.__le__(attrib)
    assert result is False

    # Test .priority greater than .priority
    new_attrib = Attribute()
    new_attrib.priority = 2
    attrib = Attribute()
    attrib.priority = 1
    result = new_attrib.__le__(attrib)

# Generated at 2022-06-21 00:02:54.746554
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert attr1.__gt__(attr2)


# Generated at 2022-06-21 00:02:57.434693
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute1 = Attribute(priority=10)
    attribute2 = Attribute(priority=10)
    attribute3 = Attribute(priority=20)
    assert attribute1 >= attribute2
    assert attribute2 >= attribute1
    assert not attribute1 >= attribute3
    assert not attribute3 >= attribute1
    assert attribute1 >= attribute1
    assert attribute2 >= attribute2
    assert attribute3 >= attribute3


# Generated at 2022-06-21 00:02:59.282376
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute(priority=0)
    other_attribute = Attribute(priority=1)
    assert attribute != other_attribute



# Generated at 2022-06-21 00:03:02.078360
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa=int, priority=10)
    b = Attribute(isa=int, priority=10)
    assert a == b


# Generated at 2022-06-21 00:03:05.198322
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    assert attr >= attr, "Failed on Attribute.__ge__()"


# Generated at 2022-06-21 00:03:16.932186
# Unit test for constructor of class Attribute
def test_Attribute():
    from collections import OrderedDict
    a = Attribute(isa='int')
    assert a.isa == 'int'
    assert a.private == False
    assert a.default is None
    assert a.required == False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias is None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False


# Generated at 2022-06-21 00:03:20.509293
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 < attr2
    assert not attr2 < attr1


# Generated at 2022-06-21 00:03:31.393757
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    Unit test for method __lt__ of class Attribute
    '''
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)

    assert(attr2 < attr3)
    assert(attr1 < attr2)
    assert(attr1 < attr3)
    assert(attr3 > attr2)
    assert(attr3 > attr1)
    assert(attr2 > attr1)
    assert(not attr2 < attr2)
    assert(not attr1 < attr1)
    assert(not attr3 < attr3)


# Generated at 2022-06-21 00:03:35.636112
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__le__(a) == True
    assert b.__le__(a) == False
    assert a.__le__(b) == True


# Generated at 2022-06-21 00:03:42.794816
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(isa='list',listof='str',priority=2)
    attr2 = Attribute(isa='list',listof='str',priority=1)
    attr3 = Attribute(isa='list',listof='str',priority=2)
    if attr1 <= attr2:
        print('attr1 <= attr2')
        print(attr1.__eq__(attr2))
    else:
        print('attr1 > attr2')
        print(attr1.__eq__(attr2))

    if attr1 <= attr3:
        print('attr1 <= attr3\n')
        print(attr1.__eq__(attr3))
    else:
        print('attr1 > attr3\n')
        print(attr1.__eq__(attr3))

# Generated at 2022-06-21 00:03:51.831026
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    class AttributeStub1:
        def __init__(self, priority):
            self.priority = priority
    class AttributeStub2:
        def __init__(self, priority):
            self.priority = priority
    a1 = AttributeStub1(1)
    a2 = AttributeStub2(2)
    assert a2.__gt__(a1) == True


# Generated at 2022-06-21 00:03:53.525932
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__lt__(a2) == False
    assert a1 < a2 == False


# Generated at 2022-06-21 00:03:59.212166
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute()
    attribute1.priority = 1
    attribute2 = Attribute()
    attribute2.priority = 2
    assert attribute1 < attribute2 and attribute1 <= attribute2 and attribute1 != attribute2
    assert attribute2 > attribute1 and attribute2 >= attribute1 and attribute2 != attribute1


# Generated at 2022-06-21 00:04:03.558221
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """tests the method __le__ of class Attribute"""
    arg1 = Attribute(isInstance = 'hello')
    arg2 = Attribute(isInstance = 'hello')

    try:
        result = arg1.__le__(arg2)
    except Exception as e:
        fail('test__le__(Attribute) raised Exception: ' + str(e))



# Generated at 2022-06-21 00:04:07.588034
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=0) <= Attribute(priority=0)
    assert Attribute(priority=1) <= Attribute(priority=0)
    assert Attribute(priority=0) <= Attribute(priority=1)
    assert not Attribute(priority=1) <= Attribute(priority=2)
    assert not Attribute(priority=2) <= Attribute(priority=1)
    assert Attribute(priority=1) <= Attribute(priority=1)


# Generated at 2022-06-21 00:04:19.128033
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Create a FieldAttribute object
    attr = FieldAttribute(
        default='',
        required=False,
        listof='dict',
        priority=10,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        extend=True,
        prepend=False,
        static=False
    )
    # Check its values
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == ''
    assert attr.required == False
    assert attr.listof == 'dict'
    assert attr.priority == 10
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.extend == True
    assert attr

# Generated at 2022-06-21 00:04:22.906435
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert(Attribute() >= Attribute())
    assert(Attribute(priority=1) >= Attribute())
    assert(Attribute(priority=1) >= Attribute(priority=0))
    assert(not (Attribute() >= Attribute(priority=1)))


# Generated at 2022-06-21 00:04:31.063790
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from jinja2 import Template
    import yaml
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    Task = namedtuple('Task', ['name', 'tags'])


# Generated at 2022-06-21 00:04:39.730412
# Unit test for constructor of class Attribute
def test_Attribute():
    f_attr = Attribute()

    assert f_attr.isa is None
    assert f_attr.private is False
    assert f_attr.default is None
    assert f_attr.required is False
    assert f_attr.listof is None
    assert f_attr.priority == 0
    assert f_attr.class_type is None
    assert f_attr.always_post_validate is False
    assert f_attr.inherit is True
    assert f_attr.alias is None
    assert f_attr.extend is False
    assert f_attr.prepend is False
    assert f_attr.static is False



# Generated at 2022-06-21 00:04:52.230023
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    class TestAnsibleBaseYAMLObject(AnsibleBaseYAMLObject):
        _required_attributes = frozenset(['foo'])

        def _get_fields(self):
            return dict(
                foo = dict(
                    isa = 'bool',
                    default = True
                ),
                bar = dict(
                    isa = 'dict',
                    default = dict(),
                    prepend = True,
                )
            )

    test = TestAnsibleBaseYAMLObject()
    assert isinstance(test.foo, bool)
    assert test.foo == True

# Generated at 2022-06-21 00:05:04.758124
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute = Attribute()
    assert attribute.__gt__(attribute) == False
    return True


# Generated at 2022-06-21 00:05:16.512383
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    required_msg = 'defaults for FieldAttribute may not be mutable, please provide a callable instead'


# Generated at 2022-06-21 00:05:22.567569
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)

    assert (attr1 >= attr3) == False
    assert (attr1 >= attr2) == False
    assert (attr2 >= attr1) == True
    assert (attr2 >= attr2) == True
    assert (attr3 >= attr2) == True
    assert (attr3 >= attr1) == True



# Generated at 2022-06-21 00:05:27.421199
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(
        isa=str,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False
    )

# Generated at 2022-06-21 00:05:30.907962
# Unit test for constructor of class Attribute
def test_Attribute():
    # Valid Input
    try:
        attribute = Attribute(isa='str', default='bar', required=False, listof='list', priority=1, class_type='dict', alias='foo')
    except (AttributeError, TypeError):
        raise Exception('Failed attribute creation test')



# Generated at 2022-06-21 00:05:33.609159
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1.__ge__(attr2) == True
    assert attr2.__ge__(attr1) == True



# Generated at 2022-06-21 00:05:37.952606
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    "Attribute.__lt__"
    a = Attribute(isa='foo')
    b = Attribute(isa='bar', priority = 1)
    c = Attribute(isa='bat', priority = 0)
    assert (b < a)
    assert (a >= b)
    assert (c < a)
    assert (c < b)
    assert (b > c)
    assert (a > c)


# Generated at 2022-06-21 00:05:40.554631
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert (attr2 > attr1) is True


# Generated at 2022-06-21 00:05:43.738766
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=0) <= Attribute(priority=0)
    assert Attribute(priority=1) <= Attribute(priority=0)



# Generated at 2022-06-21 00:05:44.286386
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    pass


# Generated at 2022-06-21 00:06:08.809437
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    obj = Attribute(default=None, priority=0)
    obj2 = Attribute(default=None, priority=0)
    assert obj == obj2


# Generated at 2022-06-21 00:06:10.483730
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a <= b


# Generated at 2022-06-21 00:06:13.337850
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=1) <= Attribute(priority=2)
    assert not Attribute(priority=2) <= Attribute(priority=1)


# Generated at 2022-06-21 00:06:15.327096
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert (a <= b)



# Generated at 2022-06-21 00:06:16.591921
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field_attribute = FieldAttribute(isa='str')
    assert (field_attribute != None) == True


# Generated at 2022-06-21 00:06:26.599883
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-21 00:06:29.545837
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)
    assert attribute_2 > attribute_1


# Generated at 2022-06-21 00:06:38.359112
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    from nose.tools import assert_raises
    class Dummy():
        f1 = FieldAttribute(priority=1)
        f2 = FieldAttribute(priority=2)

    d = Dummy()

    assert(d.f1 > d.f2)
    assert_raises(ValueError, d.f2 >= d.f1)
    assert_raises(ValueError, d.f2 == d.f1)
    assert(d.f2 < d.f1)
    assert_raises(ValueError, d.f1 <= d.f2)
    assert_raises(ValueError, d.f1 == d.f2)

test_Attribute___gt__()



# Generated at 2022-06-21 00:06:44.343863
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=0, private=False, isa="list", default=None, alias=None,
                  inherit=True, always_post_validate=False, static=False,
                  listof=None, class_type=None, required=False, extend=False,
                  prepend=False)
    assert a != ''


# Generated at 2022-06-21 00:06:51.077871
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Test for the first block of the if statement
    attribute1 = Attribute(priority = 1)
    attribute2 = Attribute(priority = 1)
    assert attribute1.__lt__(attribute2) == False

    # Test for the second block of the if statement
    attribute1 = Attribute(priority = 1)
    attribute2 = Attribute(priority = 2)
    assert attribute1.__lt__(attribute2) == True


# Test for method __eq__ of class Attribute

# Generated at 2022-06-21 00:07:38.012746
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    A1 = Attribute(priority=0)
    A2 = Attribute(priority=10)

    assert A1 < A2
    assert A2 > A1


# Generated at 2022-06-21 00:07:39.714620
# Unit test for method __lt__ of class Attribute

# Generated at 2022-06-21 00:07:48.831369
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from ansible.utils.collection_loader import get_collection_files

    # Test file resides in Ansible tree directory:
    #   ./test/units/module_utils/test_collectionloader_attribute.py

    BASE_PATH = './test/units/module_utils'
    TEST_COLLECTIONS = './test/units/module_utils/test_collections'

    # Populate file_collection_list with the path to all the collections
    # found in the specified base dir
    collection_list = list(get_collection_files(BASE_PATH))

    # Test the module_utils/ansible files first
    for collection_path in collection_list:
        # Modules should not contain __ne__
        if collection_path.find(TEST_COLLECTIONS) != -1:
            continue


# Generated at 2022-06-21 00:07:55.542882
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field = FieldAttribute(isa='hello', private=False, default=None, required=False, listof=None, priority=0,
                        class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    a = field.__ne__(field)
    assert a == False



# Generated at 2022-06-21 00:08:00.440479
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print("\n--- test_Attribute___ge__ ---")

    attr_obj_a = Attribute(priority=0)
    attr_obj_b = Attribute(priority=1)
    print("attr_obj_a priority: %s" % attr_obj_a.priority)
    print("attr_obj_b priority: %s" % attr_obj_b.priority)
    print("attr_obj_b >= attr_obj_a: %s" % (attr_obj_b >= attr_obj_a))
    print("attr_obj_b >= attr_obj_b: %s" % (attr_obj_b >= attr_obj_b))
    print("attr_obj_a >= attr_obj_b: %s" % (attr_obj_a >= attr_obj_b))

# Generated at 2022-06-21 00:08:02.335423
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute().__ne__(Attribute()) is False, "Should be False"

# Generated at 2022-06-21 00:08:06.765047
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    assert a1.__ge__(a2)
    assert a2.__ge__(a1)
    a3 = Attribute(priority=6)
    assert a3.__ge__(a1)
    assert not a1.__ge__(a3)


# Generated at 2022-06-21 00:08:15.086000
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test if the method is implemented as expected
    attribute_1 = Attribute()
    attribute_2 = Attribute()
    assert attribute_1.__eq__(attribute_2)
    # Test if the method is implemented as expected
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)
    assert attribute_1.__eq__(attribute_2) == False
    # Test if the method is implemented as expected
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 1)
    assert attribute_1.__eq__(attribute_2)


# Generated at 2022-06-21 00:08:18.044276
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert(attr1 < attr2)
    assert(attr2 > attr1)


# Generated at 2022-06-21 00:08:28.903821
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.inherit is True
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False

# Generated at 2022-06-21 00:10:10.168761
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr1.priority = 10
    attr2 = Attribute()
    attr2.priority = 10
    attr3 = Attribute()
    attr3.priority = 20

    assert attr1 <= attr2
    assert not attr1 <= attr3



# Generated at 2022-06-21 00:10:12.267486
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute.__class__.__name__ == 'FieldAttribute'



# Generated at 2022-06-21 00:10:13.977610
# Unit test for constructor of class Attribute
def test_Attribute():
    test_attr = Attribute()

# Generated at 2022-06-21 00:10:16.686587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa="str", default="Foo")
    assert fa.isa == "str"
    assert fa.default == "Foo"



# Generated at 2022-06-21 00:10:25.201897
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert (a1 == a2)

    a1.priority = 1
    assert (a1 != a2)
    assert (a1 > a2)
    assert (a2 < a1)

    a2.priority = 2
    assert (a1 < a2)
    assert (a1 <= a2)
    assert (a2 > a1)

    a1.priority = 2
    assert (a1 == a2)
    assert (a1 >= a2)
    assert (a2 <= a1)


# Generated at 2022-06-21 00:10:32.807082
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    c = Attribute(priority=1)
    assert a > b == False
    assert b > a == True
    assert b > c == False

    try:
        a > None
    except TypeError:
        print('Attribute___gt__: OK')

    try:
        b > None
    except TypeError:
        print('Attribute___gt__: OK')

    try:
        c > None
    except TypeError:
        print('Attribute___gt__: OK')


# Generated at 2022-06-21 00:10:34.969556
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    required1 = Attribute(required=True)
    required2 = Attribute(required=False)

    assert(required1 != required2)



# Generated at 2022-06-21 00:10:37.965944
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # assertion
    assert Attribute(priority=1) == Attribute(priority=1)

    # assertion
    assert Attribute(priority=1) != Attribute(priority=10)



# Generated at 2022-06-21 00:10:44.470822
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=3)
    a4 = Attribute(priority=4)
    assert a1 == a2
    assert not a1 == a3
    assert not a1 == a4
    assert not a2 == a3
    assert not a2 == a4
    assert not a3 == a4



# Generated at 2022-06-21 00:10:46.427830
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)
