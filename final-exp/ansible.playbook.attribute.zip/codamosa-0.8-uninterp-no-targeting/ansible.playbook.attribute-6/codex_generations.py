

# Generated at 2022-06-21 00:01:07.585251
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a_gt_b = CmpTestAttribute(1) > CmpTestAttribute(2)
    assert a_gt_b is True
    b_gt_a = CmpTestAttribute(2) > CmpTestAttribute(1)
    assert b_gt_a is False


# Generated at 2022-06-21 00:01:09.870291
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    assert a != Attribute(priority=2)


# Generated at 2022-06-21 00:01:13.776181
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=3)
    c = Attribute(priority=3)

    assert a < b
    assert b < a == False
    assert b < c == False



# Generated at 2022-06-21 00:01:21.158528
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = FieldAttribute(priority=1)
    attr2 = FieldAttribute(priority=2)

    assert attr2.__ge__(attr1) == True
    assert attr2 > attr1 == True
    assert attr2 < attr1 == False
    assert attr2 >= attr1 == True
    assert attr2 <= attr1 == False
    assert attr2 == attr1 == False
    assert attr2 != attr1 == True




# Generated at 2022-06-21 00:01:24.376938
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert a == b


# Generated at 2022-06-21 00:01:27.151868
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b


# Generated at 2022-06-21 00:01:33.040317
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=0)
    attr3 = Attribute(priority=0)
    attr4 = Attribute(priority=3)

    #test compare greater
    assert(attr1 > attr2)
    assert(not attr2 > attr3)
    assert(attr4 > attr1)


# Generated at 2022-06-21 00:01:35.206968
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute(priority=0)
    print(a1 == a2)


# Generated at 2022-06-21 00:01:41.651214
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute()
    a1.priority = 1
    a2.priority = 2
    a3.priority = 1
    assert a1 <= a2
    assert a2 >= a1
    assert (a1 == a3 and a3 == a1)
    assert (a1 != a2 and a2 != a1)



# Generated at 2022-06-21 00:01:48.072762
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()
    attr.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    print(attr.__ge__(attr2))
    print(attr2.__ge__(attr))
    attr.priority = 1
    attr2.priority = 1
    print(attr.__ge__(attr2))
    print(attr2.__ge__(attr))


# Generated at 2022-06-21 00:01:50.514635
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute().__eq__(Attribute(priority=10)) == True


# Generated at 2022-06-21 00:01:52.280473
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()

    a.priority = 5
    b.priority = 4

    assert a > b


# Generated at 2022-06-21 00:02:01.242554
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    s = """
    class Attribute:
        def __eq__(self, other):
            return other.priority == self.priority
    """

    locals_ = {}
    exec(s, globals(), locals_)
    Attribute = locals_['Attribute']
    a1 = Attribute()
    a1.priority = 10
    a2 = Attribute()
    a2.priority = 20

    assert a1 == a1
    assert a2 == a2
    assert a1 != a2


# Generated at 2022-06-21 00:02:04.889558
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 <= attr2
    assert not attr2 <= attr1



# Generated at 2022-06-21 00:02:15.261336
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test with default args
    default_field_attribute = FieldAttribute()
    assert default_field_attribute.isa is None
    assert default_field_attribute.private is False
    assert default_field_attribute.default is None
    assert default_field_attribute.required is False
    assert default_field_attribute.listof is None
    assert default_field_attribute.priority == 0
    assert default_field_attribute.class_type is None
    assert default_field_attribute.always_post_validate is False
    assert default_field_attribute.inherit is True
    assert default_field_attribute.alias is None

    # Test with custom args
    custom_field_attribute = FieldAttribute(isa="class", private=True, default=True, required=True, listof="dict")

# Generated at 2022-06-21 00:02:27.370527
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a2 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    a3 = Attribute(isa=None, private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert (a1 == a2) == True
    assert (a1 != a2) == False


# Generated at 2022-06-21 00:02:37.953123
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    attribute1 = FieldAttribute(isa='str',
                                private=False,
                                default=None,
                                required=False,
                                listof=None,
                                priority=0,
                                class_type=None,
                                always_post_validate=False,
                                inherit=True,
                                alias=None,
                                extend=False,
                                prepend=False,
                                static=False)

# Generated at 2022-06-21 00:02:42.124037
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa='list',default=[])
    assert isinstance(x.default, list)
    try:
        x = Attribute(isa='list',default='[]')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 00:02:45.490756
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    my_attr_1 = Attribute(priority=0)
    my_attr_2 = Attribute(priority=1)
    assert my_attr_1.__ne__(my_attr_2)



# Generated at 2022-06-21 00:02:48.512123
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1 != attr2


# Generated at 2022-06-21 00:02:55.585283
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='boolean', default=False)
    assert attr.isa == 'boolean'
    assert attr.default == False
    try:
        FieldAttribute(isa='list', default='invalid')
    except:
        pass
    else:
        assert "Should have raised exception"

# Generated at 2022-06-21 00:03:00.841603
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    att_low = Attribute(priority=0)
    att_high = Attribute(priority=1)
    assert(att_low.__ge__(att_low) == True)
    assert(att_low.__ge__(att_high) == False)
    assert(att_high.__ge__(att_high) == True)
    assert(att_high.__ge__(att_low) == True)



# Generated at 2022-06-21 00:03:12.493770
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = {}
    FA = FieldAttribute
    f['isa'] = FA(isa='str')
    f['private'] = FA(private=True)
    f['default'] = FA(default='foo')
    f['required'] = FA(required=True)
    f['listof'] = FA(listof='str')
    f['priority'] = FA(priority=1)
    f['class_type'] = FA(class_type='str')
    f['always_post_validate'] = FA(always_post_validate=True)
    f['inherit'] = FA(inherit=True)
    f['alias'] = FA(alias='foo')
    f['extend'] = FA(extend=True)
    f['prepend'] = FA(prepend=True)

# Generated at 2022-06-21 00:03:18.540470
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert (attr1 < attr2) == False
    assert (attr2 < attr1) == True

    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert (attr1 < attr2) == False
    assert (attr2 < attr1) == False


# Generated at 2022-06-21 00:03:22.099301
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(0, priority=1)
    attr2 = Attribute(0, priority=2)
    assert attr2 >= attr1



# Generated at 2022-06-21 00:03:25.499701
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    if not (Attribute(priority=10) <= Attribute(priority=10)):
        raise AssertionError('__le__ method of class Attribute failed')
    if not (Attribute(priority=10) <= Attribute(priority=20)):
        raise AssertionError('__le__ method of class Attribute failed')
    if Attribute(priority=20) <= Attribute(priority=10):
        raise AssertionError('__le__ method of class Attribute failed')


# Generated at 2022-06-21 00:03:28.606183
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    a_0 = Attribute(priority=1)
    a_1 = Attribute(priority=0)
    assert a_0 < a_1


# Generated at 2022-06-21 00:03:32.246166
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1.__gt__(attr2) == False
    assert attr2.__gt__(attr1) == False


# Generated at 2022-06-21 00:03:33.733857
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 > a1
    assert a1 < a2



# Generated at 2022-06-21 00:03:37.380786
# Unit test for constructor of class Attribute
def test_Attribute():
    # Testing for Attribute
    attr = Attribute(isa='str')
    assert attr.isa == 'str'
    attr = Attribute(class_type=str)
    assert attr.class_type == str


# Generated at 2022-06-21 00:03:44.047422
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=20)
    assert (a1 >= a2) == True
    assert (a2 >= a1) == False


# Generated at 2022-06-21 00:03:49.020445
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Create attribute A
    a = Attribute(required=True, priority=1)
    # Create attribute B
    b = Attribute(priority=2)
    # A is less than B
    assert a < b
    # B is greater than A
    assert b > a


# Generated at 2022-06-21 00:03:55.655459
# Unit test for constructor of class Attribute
def test_Attribute():
    # TODO: improve this test
    a = Attribute(isa='int')
    assert a.isa == 'int'
    a = Attribute(isa=dict)
    assert a.isa == dict
    # Now try a bad value for isa
    bad_isa = dict(x=1, y=2)
    try:
        a = Attribute(isa=bad_isa)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 00:03:58.970576
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert (a <= b) == True
    assert (a >= b) == False

# Generated at 2022-06-21 00:04:04.285097
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # test when priority is equal
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert(not a > b)

    # test when priority is not equal
    a = Attribute(priority=0)
    b = Attribute(priority=10)
    assert(a > b)
    a = Attribute(priority=10)
    b = Attribute(priority=0)
    assert(not a > b)



# Generated at 2022-06-21 00:04:06.328565
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Default constructor
    a = FieldAttribute()
    assert a is not None

    # Non-default constructor
    a = FieldAttribute(isa='list')
    assert a.isa == 'list'


# Generated at 2022-06-21 00:04:08.115325
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=5) <= Attribute(priority=5)


# Generated at 2022-06-21 00:04:10.545567
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    b = Attribute()

    a.priority = 100
    b.priority = 10

    assert a < b


# Generated at 2022-06-21 00:04:13.601305
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='int')
    b = Attribute(isa='string', priority=1)
    assert a == a
    assert not a == b
    assert b == b

# Generated at 2022-06-21 00:04:17.639484
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    A simple test of FieldAttribute.__init__.
    """
    field_attr = FieldAttribute(
        isa = 'str',
        private = True,
        default = 'foo',
        required = False,
        listof = 'foo',
        priority = 0,
        class_type = 'foo',
        always_post_validate = False,
        inherit = True,
        alias = 'foo',
    )
    assert field_attr


# Generated at 2022-06-21 00:04:27.849787
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    assert a.__le__(b) is True and a.__ge__(b) is False

    a.priority = 1
    b.priority = 2

    assert a.__le__(b) is True and a.__ge__(b) is False

    a.priority = 3
    b.priority = 2

    assert a.__lt__(b) is True and a.__gt__(b) is False

# Generated at 2022-06-21 00:04:33.494788
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = FieldAttribute()
    b = FieldAttribute()
    a.priority = 1
    b.priority = 0
    assert a < b
    c = FieldAttribute()
    c.priority = 1
    assert a == c
    assert a < b


# Generated at 2022-06-21 00:04:40.256017
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test FieldAttribute when isa is a type and is valid
    field_attr = FieldAttribute(isa=str)
    assert field_attr.isa == str

    # Test FieldAttribute when isa is a type and is not valid
    try:
        field_attr = FieldAttribute(isa=object)
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to set \'isa\' to a class')

    # Test FieldAttribute when isa is a string and is valid
    isa_field_attr = FieldAttribute(isa='str')
    assert isa_field_attr.isa == str

    # Test FieldAttribute when isa is a string and is not valid
    try:
        isa_field_attr = FieldAttribute(isa='string')
    except TypeError:
        pass

# Generated at 2022-06-21 00:04:44.305576
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    instance = Attribute()
    value = 0
    expected = True
    actual = instance.__eq__(value)
    assert actual == expected, 'Expected %s, but got %s' % (expected, actual)



# Generated at 2022-06-21 00:04:45.866819
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute() == Attribute()


# Generated at 2022-06-21 00:04:57.589670
# Unit test for constructor of class Attribute
def test_Attribute():
    a1 = Attribute()
    a2 = Attribute(isa='list')
    a3 = Attribute(isa='list', default={}, required=True)

    assert a1.isa == None
    assert a1.default == None
    assert a1.required == False
    assert a1.listof == None
    assert a1.priority == 0
    assert a1.class_type == None

    assert a2.isa == 'list'
    assert a2.default == None
    assert a2.required == False
    assert a2.listof == None
    assert a2.priority == 0
    assert a2.class_type == None

    assert a3.isa == 'list'
    assert a3.default == {}
    assert a3.required == True
    assert a3.listof == None

# Generated at 2022-06-21 00:05:05.678371
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(isa='list', private=False, default=None, required=False, listof='str', priority=0, class_type=None,
                  always_post_validate=True, inherit=True, alias='FieldAttribute', extend=False, prepend=False,
                  static=False)
    b = Attribute(isa='str', private=False, default=None, required=False, listof='str', priority=0, class_type=None,
                  always_post_validate=True, inherit=True, alias='FieldAttribute', extend=False, prepend=False,
                  static=False)
    assert a.__ge__(b)


# Generated at 2022-06-21 00:05:07.878730
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute_type = Attribute()
    attribute_unit = Attribute()
    assert attribute_type == attribute_unit



# Generated at 2022-06-21 00:05:09.356326
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    x = Attribute()
    y = Attribute()
    assert y > x

# Generated at 2022-06-21 00:05:12.929987
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    if a1.__le__(a2):
        return True
    return False


# Generated at 2022-06-21 00:05:29.548408
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        FieldAttribute(isa='list', default=['a'])
        raise Exception('did not catch default mutable list')
    except TypeError:
        pass
    class A(object):
        pass
    # pass-through
    f = FieldAttribute(isa='list', class_type=A)
    assert f.isa == 'list'
    assert f.class_type is A


# Generated at 2022-06-21 00:05:32.250789
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    if b > a:
        assert True
    else:
        assert False

# Generated at 2022-06-21 00:05:36.190606
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa='list', priority=0)
    attr2 = Attribute(isa='list', priority=1)
    attr3 = Attribute(isa='list', priority=0)

    assert attr1 == attr3
    assert attr1 != attr2
    assert attr2 != attr3


# Generated at 2022-06-21 00:05:39.947102
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    a2.priority = 1
    assert a1 == a1
    assert not(a1 == a2)
    assert a2 == a2


# Generated at 2022-06-21 00:05:44.560361
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__lt__(a2) == False
    assert a2.__lt__(a1) == True


# Generated at 2022-06-21 00:05:49.141290
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr = Attribute(priority=100)

    attr2 = Attribute(priority=1)
    assert attr > attr2

    attr3 = Attribute(priority=200)
    assert not attr > attr3

    attr4 = Attribute(priority=100)
    assert not attr > attr4


# Generated at 2022-06-21 00:05:55.071038
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Equal fields
    attr1 = Attribute(isa="list")
    attr2 = Attribute(isa="list")
    assert attr1 == attr2

    # Inequal fields
    attr1 = Attribute(isa="list", priority=0)
    attr2 = Attribute(isa="list", priority=1)
    assert attr1 != attr2


# Generated at 2022-06-21 00:05:59.696996
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute()
    try:
        Attribute(default={})
        assert False == True
    except TypeError:
        assert True == True
    try:
        Attribute(default=[])
        assert False == True
    except TypeError:
        assert True == True

# Generated at 2022-06-21 00:06:11.587241
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(default=['foo', 'bar'])
    assert isinstance(attr.default, list)
    attr = FieldAttribute(default=('foo', 'bar'))
    assert isinstance(attr.default, tuple)
    attr = FieldAttribute(default={'foo': 'bar'})
    assert isinstance(attr.default, dict)
    attr = FieldAttribute(default=set(['foo', 'bar']))
    assert isinstance(attr.default, set)
    try:
        attr = FieldAttribute(default=['foo', 'bar'], listof=str)
        assert False, 'defaults for list cannot be literal lists (or other mutable types)'
    except TypeError:
        raise
    else:
        assert True, 'defaults for list can be literal lists (or other mutable types)'


# Generated at 2022-06-21 00:06:19.541524
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    attr = FieldAttribute()
    assert attr.default == None
    assert attr.required == False
    assert attr.inherit == True

    attr = FieldAttribute(default="foo")
    assert attr.default == "foo"
    assert attr.required == False
    assert attr.inherit == True

    attr = FieldAttribute(required=True, inherit=False)
    assert attr.default == None
    assert attr.required == True
    assert attr.inherit == False

    attr = FieldAttribute(default="foo", required=True, inherit=False)
    assert attr.default == "foo"
    assert attr.required == True
    assert attr.inherit == False

    attr = FieldAttribute(default=["foo"])

# Generated at 2022-06-21 00:06:45.641157
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_1 = Attribute(priority=0)
    attribute_2 = Attribute(priority=100)
    assert attribute_1.__ge__(attribute_2)



# Generated at 2022-06-21 00:06:51.635121
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Arrange
    attr1 = Attribute(priority=1, required=True)
    attr2 = Attribute(priority=2, required=True)

    # Act
    result1 = attr1.__ge__(attr2)  # 1 >= 2?
    result2 = attr2.__ge__(attr1)  # 2 >= 1?

    # Assert
    assert result1 == False
    assert result2 == True


# Generated at 2022-06-21 00:06:53.886280
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1=Attribute(priority=1)
    a2=Attribute(priority=2)
    assert a1 < a2


# Generated at 2022-06-21 00:06:57.355001
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute.__lt__(Attribute(priority=1),Attribute(priority=20))
    assert not Attribute.__lt__(Attribute(priority=20),Attribute(priority=1))



# Generated at 2022-06-21 00:06:58.971359
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute().__ne__(Attribute(priority = 1)) == True



# Generated at 2022-06-21 00:07:02.203438
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1.__ne__(attr2)



# Generated at 2022-06-21 00:07:04.813526
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute()
    assert isinstance(x, Attribute)


# getattr() is used a lot, so this is defined specially to be efficient

# Generated at 2022-06-21 00:07:08.917199
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='str')
    b = Attribute(isa='str', priority=0)
    c = Attribute(isa='str', priority=1)
    assert a.__eq__(b)
    assert a.__ne__(c)


# Generated at 2022-06-21 00:07:11.750422
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2



# Generated at 2022-06-21 00:07:20.316908
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    try:
        Attribute(default=['test'])
    except:
        raise RuntimeError('Expected Attribute(default=["test"]) to succeed but it did not')

    class Foo(object):
        attr = FieldAttribute()
        attr2 = FieldAttribute()

    f = Foo()
    f.attr = 'test'
    f.attr2 = 'test'

    assert f.attr == f.attr2

    # if you don't alias the field in the class, the dumper will automatically do so
    # for you

    assert Foo().attr.alias is None

    class Foo(object):
        attr = FieldAttribute(alias='othername')

    assert Foo().attr.alias == 'othername'

# Generated at 2022-06-21 00:08:12.415567
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    instance = Attribute()
    result = instance.__gt__(1)
    assert result == False


# Generated at 2022-06-21 00:08:16.662862
# Unit test for constructor of class Attribute
def test_Attribute():

    attr1 = Attribute('some_val')
    attr2 = Attribute('list')
    print(attr1.isa)
    print(attr2.listof)


# Unit tests for the constructor of the class FieldAttribute

# Generated at 2022-06-21 00:08:19.671222
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority=100)
    y = Attribute(priority=50)
    assert x >= y
    assert y < x


# Generated at 2022-06-21 00:08:29.521280
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    args = {}
    args['isa'] = 'list'
    args['private'] = True
    args['default'] = None
    args['required'] = True
    args['listof'] = None
    args['priority'] = 0
    args['class_type'] = []
    args['always_post_validate'] = True
    args['inherit'] = True
    args['alias'] = True
    args['extend'] = True

    assert f.isa == args['isa']
    assert f.private == args['private']
    assert f.default == args['default']
    assert f.required == args['required']
    assert f.listof == args['listof']
    assert f.priority == args['priority']
    assert f.class_type == args['class_type']
    assert f

# Generated at 2022-06-21 00:08:32.598380
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)
    assert not Attribute(priority=1) == Attribute(priority=2)


# Generated at 2022-06-21 00:08:35.065722
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a=Attribute(priority=1)
    b=Attribute(priority=2)
    print(a.__le__(b))

# Generated at 2022-06-21 00:08:39.315865
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    att1 = Attribute(priority=2)
    att2 = Attribute(priority=1)
    assert att1.__lt__(att2)


# Generated at 2022-06-21 00:08:41.921841
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
	a = Attribute(priority=1)
	b = Attribute(priority=1)
	assert a.__eq__(b) == True, "Priority comparison incorrect."


# Generated at 2022-06-21 00:08:43.471713
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute()
    y = Attribute()
    x.priority = 1
    y.priority = 2

    assert x.__ge__(y) == False


# Generated at 2022-06-21 00:08:49.726995
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print("++++test_Attribute___ne__")
    o1 = Attribute(priority=1)
    o2 = Attribute(priority=1)
    assert not o1.__ne__(o2)
    o2.priority = 2
    assert o1.__ne__(o2)
# Unit test over


# Generated at 2022-06-21 00:10:52.447723
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2


# Generated at 2022-06-21 00:11:01.799899
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    ctx = PlayContext()
    ctx.loader = loader
    ctx.vars = dict()

    fieldattribute = FieldAttribute(
        isa="string",
        private=False,
        default="",
        required=True,
        listof="string",
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )