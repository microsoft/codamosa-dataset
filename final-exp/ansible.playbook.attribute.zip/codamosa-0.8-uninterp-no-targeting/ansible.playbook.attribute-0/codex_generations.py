

# Generated at 2022-06-21 00:01:09.235955
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=4)
    a2 = Attribute(priority=10)
    assert a2 > a1
    assert a1 < a2


# Generated at 2022-06-21 00:01:17.446037
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()
    assert f.isa is None
    assert f.private is False
    assert f.default is None
    assert f.required is False
    assert f.listof is None
    assert f.priority == 0
    assert f.class_type is None
    assert f.always_post_validate is False
    assert f.inherit is True
    assert f.alias is None

    assert f.extend is False
    assert f.prepend is False
    assert f.static is False
    assert f.static is False



# Generated at 2022-06-21 00:01:21.291404
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field = Attribute(priority=1)
    assert field != Attribute(), "Two different Attributes should not be equal"
    assert not field.__ne__(Attribute(priority=1)), "Two identical Attributes should be equal"


# Generated at 2022-06-21 00:01:24.317536
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    assert not a1.__lt__(a1)
    assert a1.__lt__(Attribute(priority=2))
    assert not a1.__lt__(Attribute(priority=0))



# Generated at 2022-06-21 00:01:27.499884
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute1 = Attribute()
    attribute2 = Attribute()

    # test that the priority of the attributes is not equal
    assert attribute1 != attribute2



# Generated at 2022-06-21 00:01:32.168462
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1 < attr_2
    assert attr_1 <= attr_2
    assert attr_2 > attr_1
    assert attr_2 >= attr_1

# Generated at 2022-06-21 00:01:36.255404
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Given a dictionary used to create an instance of Attribute
    attributes = {'priority': 3}
    # and an instance of Attribute
    attribute = Attribute(**attributes)

    # When calling method __le__ with a priority value
    # then compare it with priority value of the attribute
    assert attribute.__ge__(2) == True


# Generated at 2022-06-21 00:01:41.329052
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute( priority = 0 )
    attr2 = Attribute( priority = 1 )
    attr3 = Attribute( priority = 0 )

    assert not attr1 > attr2
    assert attr2 > attr1
    assert not attr1 > attr3


# Generated at 2022-06-21 00:01:42.637468
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    pass    # Just for coverage


# Generated at 2022-06-21 00:01:44.020290
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1 == attr2


# Generated at 2022-06-21 00:01:47.050500
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass


# Generated at 2022-06-21 00:01:54.320921
# Unit test for constructor of class Attribute
def test_Attribute():
    # Define attributes and values to test
    isa = Attribute('str')
    test_dict = dict(isa=isa, private=False, default=None, required=False, listof=isa, priority=0, class_type=isa, always_post_validate=False, inherit=True, alias=isa)
    test_dict_from_constructor = vars(Attribute(**test_dict))

    # Check that each key in the test_dict has the same value as the test_dict created using a constructor
    for key in test_dict.keys():
        assert test_dict[key] == test_dict_from_constructor[key]

# Generated at 2022-06-21 00:01:55.383767
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass



# Generated at 2022-06-21 00:02:01.341538
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    # Test for print of Attribute class
    att = Attribute('int', default=0, priority=0)
    print(att)
    att2 = Attribute('int', default=0, priority=0)
    print(att2)
    # Test the method __le__
    assert (att <= att2) == True


# Generated at 2022-06-21 00:02:02.002001
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    pass

# Generated at 2022-06-21 00:02:09.197429
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=3)
    attr2 = Attribute(priority=1)
    if attr1 < attr2:
        print ("attr1 < attr2")
    elif attr1 > attr2:
        print ("attr1 > attr2")
    elif attr1 == attr2:
        print ("attr1 == attr2")
    else:
        print ("attr1 != attr2")



# Generated at 2022-06-21 00:02:17.887472
# Unit test for constructor of class Attribute
def test_Attribute():
    expected_result = Attribute(isa=int,
                                private=False,
                                default=1,
                                required=False,
                                listof=None,
                                priority=0,
                                class_type=None,
                                always_post_validate=False,
                                inherit=True,
                                alias=None,
                                extend=False,
                                prepend=False,
                                static=False)
    assert expected_result.isa == int
    assert expected_result.private == False
    assert expected_result.default == 1
    assert expected_result.required == False
    assert expected_result.listof == None
    assert expected_result.priority == 0
    assert expected_result.class_type == None
    assert expected_result.always_post_validate == False
    assert expected_result

# Generated at 2022-06-21 00:02:20.388704
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test_Attribute = FieldAttribute(isa='boolean')
    assert not test_Attribute.__ne__(test_Attribute)


# Generated at 2022-06-21 00:02:28.348760
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test with Attribute.priority equal to other.priority
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=1)
    assert attr_1 == attr_2

    # Test with other.priority not equal to Attribute.priority
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1 != attr_2


# Generated at 2022-06-21 00:02:38.405573
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    isa = "list"
    private = False
    default = ["a", "b", "c"]
    union = False
    required = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = "ansible_secret"
    extend = True
    prepend = True
    static = True
    f1 = FieldAttribute(isa=isa,
                        private=private,
                        default=default,
                        required=required,
                        listof=listof,
                        priority=priority,
                        class_type=class_type,
                        always_post_validate=always_post_validate,
                        inherit=inherit,
                        alias=alias,
                        extend=extend,
                        prepend=prepend,
                        static=static)

# Generated at 2022-06-21 00:02:47.188928
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert(a.__eq__(b) == True), "Attribute __eq__ fails"
    assert(a.__eq__(c) == False), "Attribute __eq__ fails"
    assert(a.__eq__(a) == True), "Attribute __eq__ fails"


# Generated at 2022-06-21 00:02:53.680875
# Unit test for constructor of class Attribute
def test_Attribute():
    _a = Attribute(isa='dict', default='test', static=True)
    assert _a.isa == 'dict'
    assert _a.private == False
    assert _a.default == 'test'
    assert _a.required == False
    assert _a.listof == None
    assert _a.priority == 0
    assert _a.class_type == None
    assert _a.static == True

# Generated at 2022-06-21 00:02:57.761615
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list')
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0



# Generated at 2022-06-21 00:02:59.281906
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert(a != b)



# Generated at 2022-06-21 00:03:02.363835
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field_a = FieldAttribute(priority=5)
    field_b = FieldAttribute(priority=4)
    result = field_a >= field_b
    assert result == True


# Generated at 2022-06-21 00:03:05.587468
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a1 < a0


# Generated at 2022-06-21 00:03:08.303290
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)
    assert not (Attribute(priority=0) != Attribute(priority=0))


# Generated at 2022-06-21 00:03:14.357060
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=1)
    assert a1.__ge__(a2)
    assert not a2.__ge__(a1)
    assert not a1.__ge__(a3)
    assert a3.__ge__(a1)

# Generated at 2022-06-21 00:03:19.102089
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='s')
    a = Attribute(isa='s', private=True, default='some', required=True, listof='s', priority=1, class_type='s',
                  always_post_validate=True, inherit=True, alias='a')
    a = Attribute(isa='s')
    a = Attribute(isa='s')

# Generated at 2022-06-21 00:03:22.459357
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr2.priority = 100
    assert comp(attr1 >= attr2, False)



# Generated at 2022-06-21 00:03:26.325646
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a == b


# Generated at 2022-06-21 00:03:27.936636
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
  a=Attribute()
  b=Attribute()
  assert a != b


# Generated at 2022-06-21 00:03:30.318672
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    assert a.__ge__(a) == True, "'Attribute.__ge__(a)' should be True."


# Generated at 2022-06-21 00:03:32.299167
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=0) != Attribute(priority=1)



# Generated at 2022-06-21 00:03:34.235410
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    return a >= b



# Generated at 2022-06-21 00:03:37.947892
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(default=25)
    attr1 = Attribute(default=26)
    assert attr.__ge__(attr1) == False
    assert attr1.__ge__(attr) == True



# Generated at 2022-06-21 00:03:50.278495
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class FakeAnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
    # Default argument_spec is None, it will be set in the method load_arg_spec
    # Check if the arg_spec is not None
    ansible_module = FakeAnsibleModule(None)
    if ansible_module.argument_spec is not None:
        raise AssertionError("The argument is not None, it should be None.")
    # Check if the type of the argument is dict
    ansible_module = FakeAnsibleModule(dict())
    if type(ansible_module.argument_spec) != dict:
        raise AssertionError("The argument is not dict, it should be dict.")


# Generated at 2022-06-21 00:04:01.630490
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # private field
    fa = FieldAttribute(isa='list', private=True, default=None, required=False,
                        listof=None, priority=0, class_type=None, always_post_validate=False,
                        inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert fa.isa == 'list'
    assert fa.private == True
    assert fa.default == None
    assert fa.required == False
    assert fa.listof == None
    assert fa.priority == 0
    assert fa.default == None
    assert fa.class_type == None
    assert fa.always_post_validate == False
    assert fa.inherit == True
    assert fa.alias == None
    assert fa.extend == False
    assert fa.prepend == False

# Generated at 2022-06-21 00:04:05.355345
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=100)
    attr2 = Attribute(priority=100)
    attr3 = Attribute(priority=101)
    assert(attr == attr2)
    assert(attr != attr3)
    ret = attr == attr3
    assert(ret is False)



# Generated at 2022-06-21 00:04:09.007455
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    """
    Unit test for method __ne__ defined in class Attribute
    """

    a = Attribute(priority=1)
    b = Attribute(priority=3)
    assert a != b



# Generated at 2022-06-21 00:04:17.520478
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=5)
    b = Attribute(priority=10)
    c = Attribute(priority=5)
    assert (not a < b and not a > b and not a == b) and a <= b
    assert (not a < c and not a > c and a == c) and a <= c


# Generated at 2022-06-21 00:04:23.824483
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attrib = FieldAttribute(isa='boolean')
    assert attrib.isa == 'boolean'
    assert attrib.inherit == True
    assert attrib.extend == False
    attrib = FieldAttribute(isa='boolean', inherit=False, extend=True)
    assert attrib.isa == 'boolean'
    assert attrib.inherit == False
    assert attrib.extend == True


# Generated at 2022-06-21 00:04:30.940214
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """
    Test for method __eq__ of class Attribute
    """
    attr = Attribute()
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    attr3 = Attribute()
    attr3.priority = 2
    attr4 = Attribute()
    attr4.priority = 0

    assert attr1 != attr2, "Bug in __ne__ method of class Attribute"
    assert attr2 == attr3, "Bug in __eq__ method of class Attribute"
    assert attr3 != attr4, "Bug in __ne__ method of class Attribute"



# Generated at 2022-06-21 00:04:36.058749
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=6)
    assert (attr1 >= attr2) == False
    assert (attr2 >= attr1) == True


# Generated at 2022-06-21 00:04:42.425582
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    if_eq = False
    att = Attribute(priority=1)
    the_eq = att.__ge__(Attribute(priority=1))
    if the_eq == True :
        if_eq = True
        return if_eq
    else :
        the_eq = att.__ge__(Attribute(priority=0))
        if the_eq == False :
            if_eq = True
            return if_eq


# Generated at 2022-06-21 00:04:45.245292
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__ge__(b)



# Generated at 2022-06-21 00:04:50.052680
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    # Test 1: test that the FieldAttribute constructor creates an object of type dict
    instance1 = FieldAttribute()

    # Test 2: test that the created instance contains two keys, named 'isa' and 'private'
    assert 'isa' in instance1
    assert 'private' in instance1


# Unit tests for method isa()

# Generated at 2022-06-21 00:04:58.111556
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test 1:
    # Verify that when compared attributes are equal,
    # the boolean value true is returned.
    attrib = Attribute(priority=9999)
    other_attrib = Attribute(priority=9999)
    assert attrib == other_attrib

    # Test 2:
    # Verify that when compared attributes are not equal,
    # the boolean value false is returned.
    attrib = Attribute(priority=9999)
    other_attrib = Attribute(priority=8888)
    assert not attrib == other_attrib


# Generated at 2022-06-21 00:05:01.197259
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    a.priority = 10
    b.priority = 10
    assert not a.__ne__(b), "__ne__() doesn't work"


# Generated at 2022-06-21 00:05:03.260611
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    first = Attribute()
    second = Attribute()

    first.priority = 1
    second.priority = 2

    assert second >= first


# Generated at 2022-06-21 00:05:13.367425
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert attr1 > attr2



# Generated at 2022-06-21 00:05:19.293553
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None



# Generated at 2022-06-21 00:05:22.732771
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(isa='dict', listof='list', inherit=True, required=True)
    attr2 = Attribute(isa='dict', listof='list', inherit=True, required=True)
    assert attr1 != attr2



# Generated at 2022-06-21 00:05:26.271844
# Unit test for constructor of class Attribute
def test_Attribute():
    Attribute(isa=str, private=False, default='foo',
        required=True, listof=str, priority=1, class_type=str,
        always_post_validate=True, inherit=True, alias=None,
        extend=False, prepend=False, static=False)

# Generated at 2022-06-21 00:05:28.475777
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 < attr2



# Generated at 2022-06-21 00:05:39.587967
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    attr2 = Attribute(isa='str', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert (attr1 == attr2) is True

# Generated at 2022-06-21 00:05:45.864972
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a1_1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__ge__(a2) == a2.__ge__(a1)
    assert a2.__ge__(a1) == a2.__ge__(a1_1)


# Generated at 2022-06-21 00:05:47.676561
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert(attr2 > attr1)


# Generated at 2022-06-21 00:05:54.413228
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field1 = Attribute()
    field2 = Attribute()
    field3 = Attribute(priority=3)
    field4 = Attribute(priority=3)

    try:
        field1.__eq__(field2)
    except ValueError as e:
        assert False, "Attribute's method __eq__ failed, it should not raise an exception. Error: {0}".format(e)

    try:
        field1.__eq__(field2)
    except ValueError as e:
        assert False, "Attribute's method __eq__ failed, it should not raise an exception. Error: {0}".format(e)


# Generated at 2022-06-21 00:05:58.690878
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute = Attribute(priority=10)
    assert (attribute<=Attribute(priority=9)) is False
    assert (attribute<=Attribute(priority=10)) is True
    assert (attribute<=Attribute(priority=11)) is True


# Generated at 2022-06-21 00:06:20.809332
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        # Setting default to a list of strings should raise TypeError
        f = FieldAttribute(isa='list', default=['a', 'b'])
        assert False
    except TypeError:
        # This is expected
        pass

    # Setting default to a callable list of strings should work
    f = FieldAttribute(isa='list', default=lambda: ['a', 'b'])
    assert isinstance(f.default(), list)
    assert 'a' == f.default()[0]

    # Setting default to a dict of strings should raise TypeError
    # See https://github.com/ansible/ansible/issues/26847
    try:
        f = FieldAttribute(isa='dict', default={'a': 'b'})
        assert False
    except TypeError:
        # This is expected
        pass


# Generated at 2022-06-21 00:06:26.312922
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = FieldAttribute(required=True)
    attr2 = FieldAttribute(required=True)
    assert attr1.__eq__(attr2) == True
    attr3 = FieldAttribute(required=False)
    assert attr1.__eq__(attr3) == False
    return


# Generated at 2022-06-21 00:06:28.416298
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='list')
    assert a.isa == 'list', a.isa


# Generated at 2022-06-21 00:06:34.369261
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=dict, required=True, listof='list', priority=0, class_type=list)
    assert a.isa == 'dict'
    assert a.private == True
    assert a.default == dict
    assert a.required == True
    assert a.listof == 'list'
    assert a.priority == 0
    assert a.class_type == list




# Generated at 2022-06-21 00:06:38.658039
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='str', priority=1)
    b = Attribute(isa='str', priority=1)
    c = Attribute(isa='str', priority=2)
    d = Attribute(isa='int', priority=1)
    assert a == b
    assert a != c
    assert a != d



# Generated at 2022-06-21 00:06:51.077301
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    '''test_Attribute___eq__'''
    def check(a1, a2, expect):
        got = a1.__eq__(a2)
        if got != expect:
            raise AssertionError('%s.__eq__(%s): not %r' % (a1, a2, expect))
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=1)
    check(a1, a1, True)
    check(a1, a2, False)
    check(a2, a1, False)
    check(a2, a2, True)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    check(a1, a1, True)
    check(a1, a2, True)
   

# Generated at 2022-06-21 00:06:55.122608
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    c = Attribute(priority=1)
    d = Attribute(priority=0)
    assert a <= b
    assert b == c
    assert b <= c
    assert b <= a
    assert d <= b



# Generated at 2022-06-21 00:07:04.814118
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert not attr2 < attr1
    attr3 = Attribute(priority=3)
    assert not attr2 < attr3
    attr4 = Attribute(priority=4)
    assert not attr1 < attr4
    assert not attr4 < attr1
    assert not attr2 < attr4
    assert not attr4 < attr2
    assert not attr3 < attr4
    assert not attr4 < attr3

# Generated at 2022-06-21 00:07:05.489491
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    pass



# Generated at 2022-06-21 00:07:09.770496
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=1)
    attribute3 = Attribute(priority=3)
    assert attribute1 == attribute2 and not attribute1 == attribute3 and not attribute2 == attribute3
test_Attribute___eq__()


# Generated at 2022-06-21 00:07:41.446638
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute0 = Attribute()
    attribute1 = Attribute()
    assert attribute0.__le__(attribute1) == True


# Generated at 2022-06-21 00:07:44.970489
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    result = attr1.__ne__(attr2)
    expected_result = True
    assert result == expected_result


# Generated at 2022-06-21 00:07:47.041210
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(isa='list')
    b = Attribute(isa='str')
    assert (a != b)


# Generated at 2022-06-21 00:07:58.855967
# Unit test for constructor of class Attribute
def test_Attribute():
    class A:
        a = FieldAttribute(default='a')
        b = FieldAttribute(required=True)
        c = FieldAttribute(isa='B')
        d = FieldAttribute(listof='E')
        e = FieldAttribute(isa='list')
        f = FieldAttribute(isa='dict')
        g = FieldAttribute(isa='int')
        h = FieldAttribute(isa='bool')
        i = FieldAttribute(isa='str')
        j = FieldAttribute(isa='float')
        k = FieldAttribute(isa=None)

    for attr_name in dir(A):
        if attr_name.startswith('_'):
            continue
        attr = getattr(A, attr_name)
        if attr.isa == 'B':
            assert isinstance(attr.default, Attribute)

# Generated at 2022-06-21 00:08:06.977762
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 0)
    assert a == b
    # object a has __ne__ method and object b doesn't
    # so we compare object b with object a
    assert not b.__ne__(a)
    b.priority = 1
    assert a != b
    # object a has __ne__ method and object b doesn't
    # so we compare object b with object a
    assert b.__ne__(a)
    # object a has __ne__ method and object b doesn't
    # so we compare object b with object a
    assert b != a


# Generated at 2022-06-21 00:08:17.403540
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test when isa=None
    att = Attribute()
    assert att.isa is None
    assert att.private is False
    assert att.default is None
    assert att.required is False
    assert att.listof is None
    assert att.priority == 0
    assert att.class_type is None
    assert att.always_post_validate is False
    assert att.inherit is True
    assert att.alias is None

    # Test when isa="list"
    att = Attribute(isa='list', default=None)
    assert att.isa == 'list'
    assert att.private is False
    assert att.default is None
    assert att.required is False
    assert att.listof is None
    assert att.priority == 0
    assert att.class_type is None
    assert att.always_post

# Generated at 2022-06-21 00:08:24.191706
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=0)
    assert a1 <= a2
    assert not (a1 > a2)
    assert a2 >= a1
    assert not (a2 < a1)
    assert not (a1 > a1)
    assert a1 >= a1
    assert not (a1 < a1)
    assert a1 <= a1


# Generated at 2022-06-21 00:08:26.770926
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute()
    a1.priority = 0
    a2 = Attribute()
    a2.priority = 0
    assert a1 != a2


# Generated at 2022-06-21 00:08:33.807108
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute().isa == None
    assert Attribute().private == False
    assert Attribute().default == None
    assert Attribute().required == False
    assert Attribute().listof == None
    assert Attribute().priority == 0
    assert Attribute().class_type == None
    assert Attribute().always_post_validate == False
    assert Attribute().inherit == True
    assert Attribute().alias == None
    assert Attribute().extend == False
    assert Attribute().prepend == False
    assert Attribute().static == False



# Generated at 2022-06-21 00:08:39.739778
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 < a0
    assert a2 < a1
    assert a2 < a2
    assert a1 < a0
    assert a1 < a1
    assert a0 < a0


# Generated at 2022-06-21 00:09:51.900080
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(
        private=False,
        default=False,
        required=False,
        always_post_validate=False,
        inherit=True,
    )
    assert f is not None
    assert f.private == False
    assert f.default == False
    assert f.required == False
    assert f.always_post_validate == False
    assert f.inherit == True

    # should raise an exception when default is not callable
    try:
        FieldAttribute(
            private=False,
            default=[],
            required=False,
            always_post_validate=False,
            inherit=True,
        )
        assert False
    except Exception as ve:
        assert isinstance(ve, TypeError)



# Generated at 2022-06-21 00:09:54.969319
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    _Attribute = Attribute()
    _Attribute.priority = 1
    _Attribute2 = Attribute()
    _Attribute2.priority = 2
    assert _Attribute != _Attribute2


# Generated at 2022-06-21 00:09:57.412448
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 <= attr2


# Generated at 2022-06-21 00:10:01.604814
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 3
    attr2.priority = 2
    assert attr1 > attr2



# Generated at 2022-06-21 00:10:07.859669
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert FieldAttribute(priority=5) > FieldAttribute(priority=100)
    assert FieldAttribute(priority=100) > FieldAttribute(priority=99)
    assert FieldAttribute(priority=100) < FieldAttribute(priority=101)
    assert FieldAttribute(priority=50) > FieldAttribute(priority=40)
    assert FieldAttribute(priority=50) > FieldAttribute(priority=41)
    assert FieldAttribute(priority=45) > FieldAttribute(priority=40)

# Generated at 2022-06-21 00:10:11.260051
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr1.__gt__(attr2)
    assert (False == attr2.__gt__(attr1))



# Generated at 2022-06-21 00:10:15.674979
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute2.__lt__(attribute1) == True
    assert attribute1.__lt__(attribute2) == False



# Generated at 2022-06-21 00:10:17.570490
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b

# Generated at 2022-06-21 00:10:27.251749
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """
    Test that Attribute.__gt__() returns the right boolean value.
    """
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=3)
    if not (attr1.__gt__(attr2)):
        return False
    attr1 = Attribute(priority=3)
    attr2 = Attribute(priority=0)
    if (attr1.__gt__(attr2)):
        return False
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    if (attr1.__gt__(attr2)):
        return False
    return True

# Generated at 2022-06-21 00:10:28.930703
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=0) >= Attribute(priority=0)
