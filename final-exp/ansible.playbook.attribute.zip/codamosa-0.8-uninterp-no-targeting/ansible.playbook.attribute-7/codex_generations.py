

# Generated at 2022-06-21 00:01:09.309789
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(required = True, priority = 10)
    b = Attribute(required = False, priority = 10)
    assert a == b
    a = Attribute(required = True, priority = 10)
    b = Attribute(required = True, priority = 9)
    assert a != b


# Generated at 2022-06-21 00:01:21.098001
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(
        isa='class',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )
    attr2 = Attribute(
        isa='class',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

# Generated at 2022-06-21 00:01:24.801479
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=0)
    assert a.__eq__(c)
    assert not a.__eq__(b)
    assert not b.__eq__(c)


# Generated at 2022-06-21 00:01:33.302005
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    a2_equal_a2 = Attribute(priority=2)
    assert a1 <= a2
    assert a1 <= a3
    assert a1 <= a2_equal_a2
    assert not a2 <= a1
    assert a2 <= a3
    assert a2 <= a2_equal_a2
    assert not a3 <= a1
    assert not a3 <= a2
    assert a3 <= a3



# Generated at 2022-06-21 00:01:35.525567
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    at1 = Attribute(priority = 10)
    at2 = Attribute(priority = 5)
    assert at2 < at1


# Generated at 2022-06-21 00:01:47.325252
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    import unittest
    from ansible.utils.unsafe_proxy import wrap_var

    class TestAttribute___ge__(unittest.TestCase):
        def setUp(self):
            self.attribute1 = Attribute()
            self.attribute2 = Attribute()

        def tearDown(self):
            del self.attribute1
            del self.attribute2

        def test__ge_eq(self):
            ''' Test the method __ge__ with equals priority '''
            self.attribute1.priority = 1
            self.attribute2.priority = 1
            self.assertEqual(self.attribute1 >= self.attribute2, True)

        def test__ge_gt(self):
            ''' Test the method __ge__ with smaller value '''
            self.attribute1.priority = 2
            self.attribute2.priority = 1

# Generated at 2022-06-21 00:01:48.538757
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    return a <= b


# Generated at 2022-06-21 00:01:50.738827
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute(priority=0) >= Attribute(priority=0)

if __name__ == '__main__':
    test_Attribute___ge__()

# Generated at 2022-06-21 00:01:53.822239
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attrib1 = Attribute()
    attrib2 = Attribute(priority=0)
    assert(attrib1 == attrib2)

    attrib3 = Attribute(priority=1)
    assert(attrib1 != attrib3)


# Generated at 2022-06-21 00:01:57.232587
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(constructor_only_arg=42)
    assert attr.constructor_only_arg == 42



# Generated at 2022-06-21 00:02:01.396884
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=100)
    assert(not a.__le__(b))
    assert(b.__ge__(a))
    assert(a.__le__(a))
    assert(b.__ge__(b))


# Generated at 2022-06-21 00:02:06.715341
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    #
    # setup test
    #
    att1 = Attribute()
    att2 = Attribute()
    att1.priority = 6
    att2.priority = 5
    #
    # perform test
    #
    #
    # evaluate test
    #
    assert bool(att1.__lt__(att2))

# Generated at 2022-06-21 00:02:09.711153
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    first = Attribute()
    second = Attribute()
    first.priority = 1
    second.priority = 2
    assert first.__le__(second)


# Generated at 2022-06-21 00:02:18.138639
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from collections import OrderedDict

    # Create objects for comparison
    obj0 = Attribute(priority=0)
    obj1 = Attribute(priority=1)

    # Create list for sorting comparison
    list_for_sorting = OrderedDict()
    list_for_sorting['obj1'] = obj1
    list_for_sorting['obj0'] = obj0

    # Sort list_for_sorting according to method __ge__
    list_for_sorting = OrderedDict(sorted(list_for_sorting.items(), key=lambda t: t[1]))

    # Set correct order
    correct_order_of_items = ['obj0', 'obj1']

    # Check order of list_for_sorting
    assert list(list_for_sorting.keys()) == correct_order_of

# Generated at 2022-06-21 00:02:21.853996
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # test class Attribute
    a = Attribute(priority=100)
    b = Attribute(priority=99)
    eq_(True, a.__gt__(b))



# Generated at 2022-06-21 00:02:25.741827
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    fieldAttribute_1 = FieldAttribute(priority=0)
    fieldAttribute_2 = FieldAttribute(priority=0)
    assert fieldAttribute_1 == fieldAttribute_2, "Eq operation fails"


# Generated at 2022-06-21 00:02:31.643542
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(private=True, required=True, isa='list')
    assert a.private == True
    assert a.required == True
    assert a.isa == 'list'

    a = Attribute(private=False, required=False, isa='list')
    assert a.private == False
    assert a.required == False
    assert a.isa == 'list'

# Generated at 2022-06-21 00:02:34.627589
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a1 <= a2
    assert not a2 <= a1


# Generated at 2022-06-21 00:02:36.712169
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a >= b


# Generated at 2022-06-21 00:02:40.180357
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    cls = Attribute()
    cls.priority = 0
    cls2 = Attribute()
    cls2.priority = 0
    assert cls <= cls2


# Generated at 2022-06-21 00:02:45.390108
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert not a.__ge__(b)
    a.priority = 1
    b.priority = 2
    assert a.__ge__(b)


# Generated at 2022-06-21 00:02:48.835031
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=100)
    attr2 = Attribute(priority=50)
    assert attr1 == attr1
    assert attr1 != attr2


# Generated at 2022-06-21 00:02:59.896059
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    '''
    Test FieldAttribute.__ge__()
    '''
    field_attribute = FieldAttribute()

    # Test parameters
    default = True
    required = False
    isa = None
    private = False
    listof = None
    priority = 0
    class_type = None
    always_post_validate = False
    inherit = True
    alias = None
    extend = False
    prepend = False
    static = False

    # Test a true case

# Generated at 2022-06-21 00:03:02.112250
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__lt__(b)



# Generated at 2022-06-21 00:03:03.963169
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute().__gt__(Attribute(priority=1)) == False


# Generated at 2022-06-21 00:03:07.096851
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    first = Attribute(isa='int', priority=1)
    second = Attribute(isa='str', priority=2)
    assert first != second


# Generated at 2022-06-21 00:03:08.782531
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute().__eq__(Attribute(priority=10)) == True
    assert Attribute().__eq__(Attribute(priority=5)) == False


# Generated at 2022-06-21 00:03:16.404920
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=100)
    a2 = Attribute(priority=1000)
    a3 = Attribute(priority=1000)

    assert a1 >= a2
    assert a2 >= a3
    # Test for true positive
    assert a2 >= a2

    # Test for false positive
    try:
        assert a2 >= a1
        raise AssertionError('__ge__ returns true when it should be false')
    except AssertionError:
        pass



# Generated at 2022-06-21 00:03:19.503088
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=3)
    attr2 = Attribute(priority=2)
    assert attr1 > attr2



# Generated at 2022-06-21 00:03:21.337275
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    assert attribute_1.__gt__(attribute_2) == True


# Generated at 2022-06-21 00:03:29.386795
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 4
    attr2.priority = 4
    assert attr1 < attr2 == False
    attr2.priority = 2
    assert attr1 < attr2 == False
    attr2.priority = 5
    assert attr1 < attr2 == True


# Generated at 2022-06-21 00:03:39.856446
# Unit test for constructor of class Attribute
def test_Attribute():
    import sys
    if sys.version_info >= (3, 0):
        attribute = Attribute(isa='python3')
        assert attribute.isa == 'python3'
        assert attribute.private == False
        assert attribute.default == None
        assert attribute.required == False
        assert attribute.listof == None
        assert attribute.priority == 0
        assert attribute.class_type == None
        assert attribute.always_post_validate == False
        assert attribute.inherit == True
        assert attribute.alias == None
        assert attribute.extend == False
        assert attribute.prepend == False
        assert attribute.static == False
    else:
        attribute = Attribute(isa='python2')
        assert attribute.isa == 'python2'
        assert attribute.private == False
        assert attribute.default == None
        assert attribute.required == False

# Generated at 2022-06-21 00:03:42.330288
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute()
    b = Attribute()
    assert a.__ne__(b) != True

# Generated at 2022-06-21 00:03:45.843040
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    obj1 = Attribute(priority=1)
    obj2 = Attribute(priority=2)

    assert obj2.priority > obj1.priority


# Generated at 2022-06-21 00:03:50.226390
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)
    assert(attr1 == attr2)
    assert(not attr1 == attr3)


# Generated at 2022-06-21 00:03:58.721743
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute("a", "b", "c", "d", 3, "e", "f", "g")
    assert(fa.isa == "a")
    assert(fa.private == "b")
    assert(fa.default == "c")
    assert(fa.required == "d")
    assert(fa.priority == 3)
    assert(fa.class_type == "e")
    assert(fa.always_post_validate == "f")
    assert(fa.inherit == "g")



# Generated at 2022-06-21 00:04:01.050515
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=-1)
    attr2 = Attribute(priority=1)
    assert attr1 < attr2



# Generated at 2022-06-21 00:04:04.284410
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    var1 = Attribute()
    var2 = Attribute()
    var3 = Attribute()
    var1.priority = 42
    var2.priority = 42
    var3.priority = 984
    assert var1 <= var2
    assert not var1 <= var3


# Generated at 2022-06-21 00:04:08.326786
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    left_field = Attribute(priority=0)
    right_field = Attribute(priority=1)
    if (left_field <= right_field):
        assert True
    else:
        assert False



# Generated at 2022-06-21 00:04:09.923822
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute(priority=1) <= Attribute(priority=2)


# Generated at 2022-06-21 00:04:20.576119
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    A1 = Attribute(isa='str', required=True, priority=10)
    A2 = Attribute(isa='str', required=True, priority=20)
    assert A2.__lt__(A1)
    assert not A1.__lt__(A2)
    assert not A1.__lt__(A1)

# Generated at 2022-06-21 00:04:29.517103
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute_1 = Attribute(alias=None,
                    always_post_validate=False,
                    class_type=None,
                    default=None,
                    inherit=True,
                    isa='dict',
                    listof=None,
                    private=False,
                    priority=0,
                    required=False)

    attribute_2 = Attribute(alias=None,
                    always_post_validate=False,
                    class_type=None,
                    default=None,
                    inherit=True,
                    isa='dict',
                    listof=None,
                    private=False,
                    priority=0,
                    required=False)

    try:
        attribute_1.__ne__(attribute_2)
        attribute_2.__ne__(attribute_1)
        return True
    except Exception as inst:
        return False



# Generated at 2022-06-21 00:04:30.101460
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    pass

# Generated at 2022-06-21 00:04:35.558751
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 4
    attr2.priority = 2
    assert attr1.__ge__(attr2)


# Generated at 2022-06-21 00:04:38.454022
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=6)
    assert attr1 <= attr2
    assert not attr2 <= attr1


# Generated at 2022-06-21 00:04:43.235699
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=1)
    other_attr = Attribute(priority=2)
    print(attr.__ne__(other_attr))
    print(issubclass(FieldAttribute, Attribute))

if __name__ == '__main__':
    test_Attribute___ne__()

# Generated at 2022-06-21 00:04:48.443462
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__gt__(attr2)
    assert not attr2.__gt__(attr1)
    assert not attr1.__gt__(attr1)


# Generated at 2022-06-21 00:04:55.220110
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute() > Attribute(priority=0)
    assert Attribute(priority=1) > Attribute(priority=0)
    assert Attribute(priority=0) == Attribute(priority=0)
    assert Attribute(priority=0) < Attribute(priority=1)
    assert Attribute(priority=1) <= Attribute(priority=1)
    assert Attribute(priority=0) >= Attribute(priority=0)



# Generated at 2022-06-21 00:04:58.633717
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 != a2

    a1.priority = 1
    a2.priority = 1
    assert a1 == a2


# Generated at 2022-06-21 00:05:01.689688
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0, isa="str")
    b = Attribute(priority=10, isa="int")
    assert a < b
    assert not (a > b)


# Generated at 2022-06-21 00:05:20.090688
# Unit test for constructor of class Attribute
def test_Attribute():

    a = Attribute(listof='str')
    assert type(a.listof) == str

    a = Attribute(listof=str)
    assert type(a.listof) == str

    a = Attribute(default='test')
    assert type(a.default) == str

    a = Attribute(default=lambda: 'test')
    assert type(a.default) == type(lambda: 'test')

    a = Attribute(default=None)
    assert type(a.default) == type(None)

    def test_default():
        return []

    a = Attribute(default=test_default, listof=bool)
    assert type(a.default()) == list


# Generated at 2022-06-21 00:05:29.112140
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=False)
    assert a.isa == 'list'
    assert a.private == False
    assert a.default == False
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False

    # Test setting specific attributes
    a = Attribute(private=True)
    assert a.private == True

    a = Attribute(required=True)
    assert a.required == True

    a = Attribute(listof='dict')
    assert a.list

# Generated at 2022-06-21 00:05:39.459276
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    a = FieldAttribute()

    assert a.isa is None
    assert not a.private
    assert a.default is None
    assert not a.required
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert not a.always_post_validate
    assert a.inherit
    assert a.alias is None
    assert not a.extend
    assert not a.prepend
    assert not a.static

    try:
        FieldAttribute(default=dict())
    except TypeError:
        pass
    else:
        raise AssertionError('defaults for FieldAttribute may not be mutable, please provide a callable instead')

    try:
        FieldAttribute(default=list())
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 00:05:42.860244
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
	# Creating objects
	attribute = Attribute(priority=0)
	other = Attribute(priority=0)
	# Testing
	assert attribute.__eq__(other) == True


# Generated at 2022-06-21 00:05:47.303832
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    assert (a1 == a2) == True
    a3 = Attribute(priority=2)
    assert (a1 == a3) == False


# Generated at 2022-06-21 00:05:49.547819
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError):
        # tests type of attribute 'default'
        FieldAttribute(default='foobar')

# Generated at 2022-06-21 00:06:01.585258
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    import unittest
    import sys

    class MockAttr1(Attribute):
        def __init__(self):
            Attribute.__init__(self, priority=1)

    class MockAttr2(Attribute):
        def __init__(self):
            Attribute.__init__(self, priority=2)

    class Test_Attribute___ge__(unittest.TestCase):
        def test_Attribute___ge__(self):
            self.assertTrue(MockAttr2() >= MockAttr1())

    test_suite = unittest.TestSuite()
    test_suite.addTest(unittest.makeSuite(Test_Attribute___ge__))

    result = unittest.TestResult()
    test_suite.run(result)


# Generated at 2022-06-21 00:06:09.276141
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_list = [
        Attribute(priority=1),
        Attribute(priority=2),
        Attribute(priority=3),
        Attribute(priority=4),
        Attribute(priority=5),
        Attribute(priority=6),
        Attribute(priority=7),
        Attribute(priority=8),
        Attribute(priority=9),
    ]
    for i in range(9):
        assert attr_list[i].__gt__(attr_list[i+1])



# Generated at 2022-06-21 00:06:11.414709
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert (a1.__ge__(a2)) == False


# Generated at 2022-06-21 00:06:13.795075
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(1)
    a2 = Attribute(2)
    assert a2.__ge__(a1)



# Generated at 2022-06-21 00:06:36.140320
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)

    assert(attr2.__gt__(attr1))


# Generated at 2022-06-21 00:06:40.459355
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=True, default='/etc/ansible/hosts', required=False,
            alias='original_path', extend=True)
    assert attr.isa == 'dict'
    assert attr.private == True
    assert attr.default == '/etc/ansible/hosts'
    assert attr.required == False
    assert attr.alias == 'original_path'
    assert attr.extend == True


# Generated at 2022-06-21 00:06:49.718034
# Unit test for constructor of class Attribute
def test_Attribute():
    def my_default_func(param):
        if param == 'a':
            return 'b'
        else:
            return {}
    a = Attribute(alias='que', default='scott', isa='str')
    #print("Attribute alias is 'que', default is 'scott', isa is 'str'")
    assert a.alias == 'que'
    assert a.default == 'scott'
    assert a.isa == 'str'
    #print("Attribute constructor test passed")


# Generated at 2022-06-21 00:07:00.961353
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # basic comparison:
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert attr2 > attr1

    # Attribute instances should not be equal if priorities are different.
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert not attr1 == attr2
    assert not attr2 == attr1

    assert attr1 != attr2
    assert attr2 != attr1

    # Attribute instances should be equal if priorities are the same.
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    assert attr1 == attr2
    assert attr2 == attr1


# Generated at 2022-06-21 00:07:03.785481
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert not attr1.__gt__(attr2)


# Generated at 2022-06-21 00:07:06.769810
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a.__ge__(b) == a >= b



# Generated at 2022-06-21 00:07:14.200267
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """ Tests the __ge__ method of class Attribute. """

    #Create a new attribute and another attribute with a priority which is greater by 1.
    a = Attribute(priority = 0)
    b = Attribute(priority = 1)

    #Test the condition when priority of 'a' is greater than priority of 'b'.
    assert a.__ge__(b) == False

    #Test the condition when priority of 'a' is greater than or equal to priority of 'b'.
    assert a.__ge__(a) == True

# Generated at 2022-06-21 00:07:17.044427
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    field1 = Attribute(priority=1)
    field1a = Attribute(priority=1)
    field2 = Attribute(priority=2)
    assert field2 >= field1
    assert field2 >= field1a
    assert field1a >= field1
    assert not field1a >= field2
    assert not field1 >= field2


# Generated at 2022-06-21 00:07:20.571741
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    Attribute_inst = Attribute(0,0,0,0,0,0)
    Attribute_inst2 = Attribute(0,0,0,0,0,0)
    bool_result = Attribute_inst.__eq__(Attribute_inst2)
    assert bool_result == True


# Generated at 2022-06-21 00:07:25.223206
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority = 1)
    attr2 = Attribute(priority = 0)
    assert attr1.__lt__(attr2) is True
    attr2 = Attribute(priority = 2)
    assert attr1.__lt__(attr2) is False


# Generated at 2022-06-21 00:08:11.778381
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='dict', private=True, default=dict, required=True, listof=False)
    b = a.isa
    c = a.private
    d = a.default
    e = a.required
    f = a.listof
    assert b == 'dict'
    assert c == True
    assert d == dict
    assert e == True
    assert f == False

# Generated at 2022-06-21 00:08:17.816599
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    c = Attribute(priority=3)
    assert a.__le__(b) == True
    assert a.__le__(c) == True
    assert b.__le__(a) == False
    assert b.__le__(c) == False


# Generated at 2022-06-21 00:08:21.522470
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 == attr2
    attr2.priority = 1
    assert attr1 != attr2


# Generated at 2022-06-21 00:08:22.752549
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='int')
    assert field.isa == int



# Generated at 2022-06-21 00:08:26.299980
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.priority = 2
    attr2.priority = 1
    assert attr1 > attr2


# Generated at 2022-06-21 00:08:28.945148
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2
    assert a1.__lt__(a2)


# Generated at 2022-06-21 00:08:33.089702
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    assert(a.isa == None)
    assert(a.private == False)
    assert(a.default == None)
    assert(a.required == False)
    assert(a.listof == None)
    assert(a.priority == 0)
    assert(a.class_type == None)
    assert(a.always_post_validate == False)
    assert(a.inherit == True)
    assert(a.alias == None)

# Generated at 2022-06-21 00:08:44.401846
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(
        isa='a',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    b = Attribute(
        isa='a',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=1,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    assert (a < b)



# Generated at 2022-06-21 00:08:51.135529
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=5)
    b = Attribute(priority=7)
    c = Attribute(priority=5)

    assert b > a
    assert not (b < a)
    assert not (b >= a)
    assert b >= c
    assert not (b < c)
    # Test whether __lt__ returns false for equal objects
    assert not (b < b)

# Generated at 2022-06-21 00:08:53.493167
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(required=True, default=None, priority=0)
    attr_1 = Attribute(priority=0)
    attr_2 = Attribute(priority=1)
    assert attr == attr_1
    assert attr_1 == attr
    assert not attr == attr_2
    assert not attr_2 == attr


# Generated at 2022-06-21 00:10:52.997674
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a0 = Attribute(priority=0)
    a1 = Attribute(priority=1)
    assert a1 < a0



# Generated at 2022-06-21 00:10:57.010291
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class Test1:
        __metaclass__ = Attribute
        field1= Attribute(priority=0)
        field2= Attribute(priority=1)
    assert Test1.field2 >= Test1.field1
    assert not Test1.field1 >= Test1.field2
    assert Test1.field2 >= 1
    assert Test1.field1 >= 0


# Generated at 2022-06-21 00:11:07.675536
# Unit test for method __eq__ of class Attribute