

# Generated at 2022-06-21 00:01:06.951081
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(isa='str', priority=10)
    attr2 = Attribute(isa='str', priority=20)
    assert attr1 < attr2
    assert attr2 >= attr1


# Generated at 2022-06-21 00:01:18.722229
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='list', private=False, default=None, required=False, listof=None,\
    priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=True,\
    prepend=True, static=True)
    assert attr.isa == 'list'
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == True
    assert attr.prepend == True

# Generated at 2022-06-21 00:01:23.571399
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    assert a.__gt__(b) == False
    assert b.__gt__(a) == True
    assert b.__gt__(c) == False
    assert c.__gt__(b) == True

# Generated at 2022-06-21 00:01:29.339192
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=100)
    b = Attribute(priority=100)
    c = Attribute(priority=101)
    assert a.__ge__(b)
    assert a.__ge__(c)
    assert not a.__ge__(a)
    assert not b.__ge__(c)



# Generated at 2022-06-21 00:01:31.831046
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='int', default='1')
    assert fa.isa == 'int'
    assert fa.default == '1'


# Generated at 2022-06-21 00:01:35.092153
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(isa='dict', default='foo', priority=2)
    a2 = Attribute(isa='dict', default='foo', priority=1)

    assert a2 >= a1, 'Attribute__ge__ test failed!'


# Generated at 2022-06-21 00:01:40.614581
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(required=True, priority=1)
    a2 = Attribute(required=True, priority=2)
    a3 = Attribute(required=True, priority=1)

    assert(a1 == a3)
    assert(not (a1 == a2))
    assert(not (a2 == a3))


# Generated at 2022-06-21 00:01:44.598903
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute = Attribute(priority=5)
    attribute1 = Attribute(priority=5)
    attribute2 = Attribute(priority=10)
    print(attribute <= attribute1)
    print(attribute <= attribute2)

# Generated at 2022-06-21 00:01:47.325572
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert(a == a)
    assert(b == b)
    assert(not a == b)

# Generated at 2022-06-21 00:01:49.651935
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert not attr1.__gt__(attr2)


# Generated at 2022-06-21 00:01:56.753055
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field_attr_1 = FieldAttribute(priority=1)
    field_attr_2 = FieldAttribute(priority=2)
    assert field_attr_1.__le__(field_attr_2) == True
    assert field_attr_2.__le__(field_attr_1) == False


# Generated at 2022-06-21 00:02:01.939385
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    if attr1 < attr2:
        print("Attribute 1 has a lower priority than Attribute 2")
    else:
        print("Attribute 1 has a higher or equal priority to Attribute 2")



# Generated at 2022-06-21 00:02:02.998983
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    raise NotImplementedError


# Generated at 2022-06-21 00:02:05.747090
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(required=True)
    attribute2 = Attribute(required=False)
    assert attribute1 != attribute2


# Generated at 2022-06-21 00:02:08.029643
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=2)
    assert a1 < a2


# Generated at 2022-06-21 00:02:09.376865
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute()


# Generated at 2022-06-21 00:02:09.937782
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    return


# Generated at 2022-06-21 00:02:14.162955
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 0
    attr1 = attr
    attr1.priority = 0
    assert(attr != attr1)
    attr2 = attr
    attr2.priority = 1
    assert(attr != attr2)


# Generated at 2022-06-21 00:02:16.929347
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute(inherit=False, priority=-5)
    assert (attr <= Attribute(inherit=False, priority=5))


# Generated at 2022-06-21 00:02:19.234175
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a == b
    assert b == a
    assert a != 2


# Generated at 2022-06-21 00:02:27.318641
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Ensure that the method is consistent with the 'less-than' comparator.
    """
    a = Attribute(isa=int, priority=2)
    b = Attribute(isa=int, priority=1)
    assert ((a <= b) == (a < b or a == b))

# Generated at 2022-06-21 00:02:31.920079
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    '''
    Test method __le__ of class Attribute
    '''
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1.__le__(attr2)


# Generated at 2022-06-21 00:02:35.467402
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=0)

    assert a < b
    assert b > a
    assert a > c
    assert c < a



# Generated at 2022-06-21 00:02:37.952715
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    assert attr1.__ne__(attr2)



# Generated at 2022-06-21 00:02:49.739138
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    import pytest

    a = Attribute(priority=0)
    b = Attribute(priority=1)

    c = Attribute(priority=2)
    d = Attribute(priority=2)

    assert d.__ge__(c) == True
    assert d.__ge__(b) == True
    assert d.__ge__(a) == True

    assert c.__ge__(b) == True
    assert c.__ge__(a) == True

    assert b.__ge__(a) == True

    with pytest.raises(AttributeError):
        a.__ge__(None)

    with pytest.raises(AttributeError):
        b.__ge__(None)

    with pytest.raises(AttributeError):
        c.__ge__(None)


# Generated at 2022-06-21 00:02:53.258457
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(default={}, isa="list")
    except TypeError as e:
        return
    raise AssertionError("Expected TypeError in Attribute constructor")

# Generated at 2022-06-21 00:02:55.480808
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(required=True)
    assert isinstance(f.required, bool)


# Generated at 2022-06-21 00:03:00.088011
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) < Attribute(priority=2)
    assert not Attribute(priority=1) < Attribute(priority=1)
    assert not Attribute(priority=2) < Attribute(priority=1)
    print('Attribute.__lt__() is OK')

if __name__ == '__main__':
    test_Attribute___lt__()



# Generated at 2022-06-21 00:03:02.145910
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    c = FieldAttribute()
    assert (a >= b) is False


# Generated at 2022-06-21 00:03:14.545800
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr0 = Attribute(priority=0)
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)

    assert attr0 >= attr0
    assert attr1 >= attr1
    assert attr2 >= attr2

    assert attr0 <= attr0
    assert attr1 <= attr1
    assert attr2 <= attr2

    assert attr0 == attr0
    assert attr1 == attr1
    assert attr2 == attr2

    assert attr0 != attr1
    assert attr0 != attr2
    assert attr1 != attr2

    assert attr1 > attr0
    assert attr1 > attr0
    assert attr2 > attr1
    assert attr2 > attr1



# Generated at 2022-06-21 00:03:22.198649
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='dict', listof='int')



# Generated at 2022-06-21 00:03:26.887707
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 == attr1
    assert not attr1 != attr1
    assert attr1 != attr2
    assert not attr1 == attr2



# Generated at 2022-06-21 00:03:29.331569
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    a3 = Attribute(priority=3)
    assert a1 < a2
    assert a2 < a3


# Generated at 2022-06-21 00:03:34.711962
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test the __gt__ method of class Attribute
    attr = Attribute()
    attr.priority = 1
    attr2 = Attribute()
    attr2.priority = 0
    assert attr.__gt__(attr2) == True
    assert attr2.__gt__(attr) == False


# Generated at 2022-06-21 00:03:39.695370
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(
        isa='str',
        private=False,
        default='default',
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
    )
    return a


# Generated at 2022-06-21 00:03:42.219414
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert b >= a


# Generated at 2022-06-21 00:03:54.770811
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='str', private=False, default='test', required=True,
        listof='int', priority=5, class_type='Base', inherit=False, alias='basename')
    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == 'test'
    assert attr.required == True
    assert attr.listof == 'int'
    assert attr.priority == 5
    assert attr.class_type == 'Base'
    assert attr.inherit is False
    assert attr.alias == 'basename'
    # some negative tests

# Generated at 2022-06-21 00:04:02.397873
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    fail_msg = "method __ge__ in class Attribute is not implemented properly"
    a = Attribute(isa=str,
                  private=False,
                  default=None,
                  required=False,
                  listof=None,
                  priority=0,
                  class_type=None,
                  always_post_validate=False,
                  inherit=True,
                  alias=None,
                  extend=False,
                  prepend=False,
                  static=False)

# Generated at 2022-06-21 00:04:06.036793
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 <= attr2



# Generated at 2022-06-21 00:04:10.248921
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert(FieldAttribute(
        isa='test',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
    ))



# Generated at 2022-06-21 00:04:24.716622
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=10)
    assert a1.__ge__(a2) == True


# Generated at 2022-06-21 00:04:26.651216
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = FieldAttribute(priority=1)
    assert(attr.__eq__(attr) == True)


# Generated at 2022-06-21 00:04:29.326772
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    assert(a < b)
    assert(a < c)
    assert(b < c)


# Generated at 2022-06-21 00:04:35.199477
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=2) == Attribute(priority=2)
    assert Attribute(priority=1) != Attribute(priority=2)
    assert Attribute(priority=2) != Attribute(priority=1)


# Generated at 2022-06-21 00:04:37.091176
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    import pytest
    a = FieldAttribute()
    assert isinstance(a, Attribute)



# Generated at 2022-06-21 00:04:41.568993
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=0)
    a2 = Attribute(priority=1)
    a3 = Attribute(priority=2)
    assert a2 < a1
    assert a3 < a2
    assert not a1 < a2
    assert not a1 < a3


# Generated at 2022-06-21 00:04:44.045016
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    if not isinstance(attr, Attribute):
        raise Exception('Attribute is not an instance of class Attribute')

# Generated at 2022-06-21 00:04:45.641429
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # TODO: implement tests
    pass



# Generated at 2022-06-21 00:04:47.654708
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute(priority=-10)
    assert attr >= attr


# Generated at 2022-06-21 00:04:49.616532
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute.__le__(Attribute(priority=0), Attribute(priority=1))


# Generated at 2022-06-21 00:05:17.413555
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute().__dict__ == Attribute().__dict__


# Generated at 2022-06-21 00:05:19.391735
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()
    assert a.__le__(b) == True


# Generated at 2022-06-21 00:05:21.456475
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1.__eq__(a2)



# Generated at 2022-06-21 00:05:24.989971
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert a < b
    assert a <= b
    assert b > a
    assert b >= a

    assert a == a
    assert a != b

if __name__ == "__main__":
    test_Attribute___gt__()

# Generated at 2022-06-21 00:05:31.891005
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute()
    assert attr.isa == None
    assert attr.private == False
    assert attr.default == None
    assert attr.required == False
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.alias == None
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False


# Generated at 2022-06-21 00:05:35.118179
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fieldattribute = FieldAttribute(isa='string')
    assert fieldattribute
    try:
        fieldattribute = FieldAttribute(isa='string', default={'ones': 'one'})
        assert False, "Should not be able to set a default to a mutable list"
    except TypeError:
        assert True


# Generated at 2022-06-21 00:05:38.828613
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='some_type', private=False)
    assert fa.isa == 'some_type'
    assert fa.private == False

# unit test for __eq__ method of class FieldAttribute

# Generated at 2022-06-21 00:05:47.853912
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute=FieldAttribute()
    assert field_attribute.isa is None
    assert field_attribute.private is False
    assert field_attribute.default is None
    assert field_attribute.required is False
    assert field_attribute.listof is None
    assert field_attribute.priority == 0
    assert field_attribute.class_type is None
    assert field_attribute.always_post_validate is False
    assert field_attribute.inherit is True
    assert field_attribute.alias is None
    assert field_attribute.extend is False
    assert field_attribute.prepend is False
    

# Generated at 2022-06-21 00:05:53.881255
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='test', private=False, default=None, required=False, listof=None, priority=0,
                  class_type=None, always_post_validate=False, inherit=True, alias=None)
    print("test_Attribute: test")
    print("------------------------------")
    print("%s" % a)
    print("------------------------------")


# Generated at 2022-06-21 00:06:05.941842
# Unit test for constructor of class Attribute
def test_Attribute():
    # test for default isa
    attr = Attribute()
    assert attr.isa == 'str'

    # test for default private
    attr = Attribute()
    assert attr.private == False

    # test for default default value
    attr = Attribute()
    assert attr.default is None

    # test for default required
    attr = Attribute()
    assert attr.required == False

    # test for default listof
    attr = Attribute()
    assert attr.listof is None

    # test for default priority
    attr = Attribute()
    assert attr.priority == 0

    # test for default class_type
    attr = Attribute()
    assert attr.class_type is None

    # test for default always_post_validate
    attr = Attribute()
   

# Generated at 2022-06-21 00:07:00.692897
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute() != object()


# Generated at 2022-06-21 00:07:05.062769
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    if a1 >= a2:
        print("test_Attribute___le__: a1 >= a2")
        return False
    else:
        return True



# Generated at 2022-06-21 00:07:09.719527
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Class FieldAttribute provides the attributes used to construct a class to be use as a data structure
    This test verifies the method __le__ of class FieldAttribute.
    The __le__ method is used to compare two FieldAttribute objects
    This test asserts that the comparison method is working correctly
    """

    pass



# Generated at 2022-06-21 00:07:19.734303
# Unit test for constructor of class Attribute
def test_Attribute():

    # default constructor
    a = Attribute()

    # Is a attribute object
    assert isinstance(a, Attribute)

    # check for all the fields in Attribute
    assert hasattr(a, 'isa')
    assert hasattr(a, 'private')
    assert hasattr(a, 'default')
    assert hasattr(a, 'required')
    assert hasattr(a, 'listof')
    assert hasattr(a, 'priority')
    assert hasattr(a, 'class_type')
    assert hasattr(a, 'always_post_validate')
    assert hasattr(a, 'inherit')
    assert hasattr(a, 'alias')
    assert hasattr(a, 'extend')
    assert hasattr(a, 'prepend')
    assert hasattr(a, 'static')

# Unit

# Generated at 2022-06-21 00:07:24.093119
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1.__ne__(attr2) == True
    assert attr2.__ne__(attr1) == True


# Generated at 2022-06-21 00:07:29.794531
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from random import shuffle
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    attr45 = Attribute(priority=4.5)
    attr5 = Attribute(priority=5.0)
    attr6 = Attribute(priority=6)

    attrs = [ attr6, attr5, attr45, attr3, attr2, attr1 ]
    shuffled_attrs = copy(attrs)
    shuffle(shuffled_attrs)

    l1 = sorted(shuffled_attrs, reverse=True)

    assert deepcopy(l1) == deepcopy(attrs)

# Generated at 2022-06-21 00:07:34.140627
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Dummy attribute objects
    attribute_1 = Attribute(0)
    attribute_2 = Attribute(1)

    # The two attribute objects are not equal
    assert not (attribute_1.priority != attribute_2.priority)



# Generated at 2022-06-21 00:07:44.613656
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa=bool, priority=0)
    b = Attribute(isa=bool, priority=1)
    assert a.__ne__(b)

    a = Attribute(isa=str, private=False, default="a", required=False, listof=None, priority=0,
                  class_type=None, always_post_validate=False, inherit=False, alias=None, extend=False,
                  prepend=False, static=False)
    b = Attribute(isa=str, private=False, default="a", required=False, listof=None, priority=1,
                  class_type=None, always_post_validate=False, inherit=False, alias=None, extend=False,
                  prepend=False, static=False)
    assert a.__ne__(b)

# Unit

# Generated at 2022-06-21 00:07:49.095529
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True



# Generated at 2022-06-21 00:08:00.936558
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    fail=0
    t1=Attribute(priority=0)
    t2=Attribute(priority=1)
    if t1.__gt__(t2) == True:
        print("test case 1 : passed")
    else:
        print("test case 1 : failed")
        fail += 1

    if t2.__gt__(t1) == False:
        print("test case 2 : passed")
    else:
        print("test case 2 : failed")
        fail += 1

    if t1.__gt__(t1) == False:
        print("test case 3 : passed")
    else:
        print("test case 3 : failed")
        fail += 1

    if fail > 0:
        raise Exception



# Generated at 2022-06-21 00:10:07.612223
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(alias='foo')
    y = Attribute(alias='foo')
    assert x == y, 'Error in Attribute class'
    assert not x != y, 'Error in Attribute class'
    assert not x < y, 'Error in Attribute class'
    assert not x > y, 'Error in Attribute class'
    assert x <= y, 'Error in Attribute class'
    assert x >= y, 'Error in Attribute class'
    z = Attribute(alias='bar', priority=1)
    assert z > y, 'Error in Attribute class'
    assert z != y, 'Error in Attribute class'
    assert not z < y, 'Error in Attribute class'
    assert not z == y, 'Error in Attribute class'
    assert y < z, 'Error in Attribute class'
    assert y

# Generated at 2022-06-21 00:10:17.336151
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """ Unit test for method __le__ of class Attribute """
    a1 = Attribute(isa='integer', priority=3)
    a2 = Attribute(isa='integer', priority=3)
    assert a1.__le__(a2)
    a1 = Attribute(isa='integer', priority=3)
    a2 = Attribute(isa='integer', priority=2)
    assert not a1.__le__(a2)
    a1 = Attribute(isa='integer', priority=2)
    a2 = Attribute(isa='integer', priority=3)
    assert a1.__le__(a2)
    return True


# Generated at 2022-06-21 00:10:25.037982
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert a < b
    assert not a > b
    assert not a == b
    a = Attribute(priority=1)
    b = Attribute(priority=0)
    assert a > b
    assert not a < b
    assert not a == b
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert not a < b
    assert not a > b
    assert a == b


# Generated at 2022-06-21 00:10:28.721443
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a2 < a1)


# Unit tests for method __eq__ of class Attribute

# Generated at 2022-06-21 00:10:29.864886
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=2)
    assert attr != Attribute(priority=1)


# Generated at 2022-06-21 00:10:30.822842
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    assert Attribute().__ge__(Attribute())

# Generated at 2022-06-21 00:10:33.789991
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field_attr1 = Attribute(isa='int', static=True, default=1)
    field_attr2 = Attribute(isa='int', static=True, default=2)
    assert field_attr1 != field_attr2


# Generated at 2022-06-21 00:10:38.625463
# Unit test for constructor of class Attribute
def test_Attribute():
    def test_kwargs():
        kwargs = {
            'isa': None,
            'private': False,
            'default': None,
            'required': False,
            'listof': None,
            'priority': 0,
            'class_type': None,
            'always_post_validate': False,
            'inherit': True,
            'alias': None,
        }
        return kwargs

    def test_is_instance():
        return isinstance(Attribute(**test_kwargs()), Attribute)

    def test_has_correct_attrs():
        attrs = test_kwargs()
        a = Attribute(**attrs)
        for k, v in attrs.items():
            assert(v == getattr(a, k))


# Generated at 2022-06-21 00:10:42.579331
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    try:
        a = FieldAttribute(isa='list', default=[])
        assert a is not None
        assert False
    except TypeError as e:
        assert 'defaults for FieldAttribute may not be mutable' in str(e)



# Generated at 2022-06-21 00:10:55.240159
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    from unittest import TestCase
    import time

    class Test(TestCase):
        def setUp(self):
            self.attributes = [('isa', 'string'),
                               ('private', False),
                               ('default', 'blah'),
                               ('required', True),
                               ('listof', None),
                               ('priority', 0),
                               ('class_type', None),
                               ('always_post_validate', False),
                               ('inherit', True),
                               ('alias', None)]
