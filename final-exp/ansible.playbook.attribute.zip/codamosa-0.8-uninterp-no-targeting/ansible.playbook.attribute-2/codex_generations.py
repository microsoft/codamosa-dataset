

# Generated at 2022-06-21 00:01:08.028758
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.private is False
    assert attr.required is False
    assert attr.priority is 0
    assert attr.inherit is True


# Generated at 2022-06-21 00:01:12.836572
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute1 < attribute2
    assert attribute1 <= attribute2
    assert not attribute1 > attribute2
    assert not attribute1 >= attribute2
    assert not attribute1 == attribute2
    assert attribute1 != attribute2



# Generated at 2022-06-21 00:01:19.588375
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test argument 'default'
    try:
        data = [1, 2, 3]
        FieldAttribute(default=data)
    except TypeError:
        FieldAttribute(default=lambda: data)
    # Test argument 'listof'
    try:
        data = [1, 2, 3]
        FieldAttribute(listof=data)
    except TypeError:
        FieldAttribute(listof=lambda: data)


# Generated at 2022-06-21 00:01:22.754886
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1.__ge__(a2) == True
    assert a2.__ge__(a1) == True


# Generated at 2022-06-21 00:01:28.876220
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    a.priority = 1
    b.priority = 2

    assert a >= b

    a.priority = 2
    b.priority = 2

    assert a >= b

    a.priority = 3
    b.priority = 2

    assert not a >= b



# Generated at 2022-06-21 00:01:35.046988
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    t1 = Attribute(priority=0)
    t2 = Attribute(priority=0)
    t3 = Attribute(priority=1)
    rs1 = t1.__ne__(t2)
    rs2 = t1.__ne__(t3)
    if rs1 or not rs2:
        print("test Attribute __ne__ passed")
    else:
        print("test Attribute __ne__ failed")


# Generated at 2022-06-21 00:01:40.111043
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    """
    This method is the unit test for method __lt__ in the class Attribute
    """
    a = FieldAttribute(priority=1)
    b = FieldAttribute(priority=2)

    # Assert that the priority of 'b' is greater than the priority of 'a'
    assert b > a


# Generated at 2022-06-21 00:01:42.799601
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()
    b = Attribute()
    assert a.__eq__(b) == False



# Generated at 2022-06-21 00:01:44.755512
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='percent')
    assert attr.isa == 'percent'



# Generated at 2022-06-21 00:01:45.736110
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    field_attributes = FieldAttribute(priority=10)
    assert field_attributes == field_attributes


# Generated at 2022-06-21 00:01:50.960980
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    assert not a.__lt__(Attribute(priority=1))
    assert a.__lt__(Attribute(priority=2))
    assert not a.__lt__(Attribute(priority=0))


# Generated at 2022-06-21 00:02:00.068023
# Unit test for constructor of class Attribute
def test_Attribute():

    test_obj = Attribute()
    assert test_obj is not None
    assert test_obj.isa is None
    assert test_obj.private is False
    assert test_obj.default is None
    assert test_obj.required is False
    assert test_obj.listof is None
    assert test_obj.priority == 0
    assert test_obj.class_type is None
    assert test_obj.always_post_validate is False
    assert test_obj.inherit is True
    assert test_obj.alias is None

# Generated at 2022-06-21 00:02:02.466018
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 1
    b = Attribute()
    b.priority = 2
    assert a <= b


# Generated at 2022-06-21 00:02:06.008563
# Unit test for constructor of class Attribute
def test_Attribute():
    attributes = [
        Attribute(isa="str", default="default"),
        Attribute(isa="int", required=True),
        Attribute(isa="list", listof="str"),
        Attribute(isa="dict", listof="str"),
        Attribute(isa="set", listof="str"),
        Attribute(isa="class", class_type=None),
        Attribute(isa="class")
    ]
    for attribute in attributes:
        assert isinstance(attribute, Attribute)



# Generated at 2022-06-21 00:02:16.079635
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    args = dict(isa='list',
                private=False,
                default=[],
                required=False,
                listof=None,
                priority=10,
                class_type=None,
                always_post_validate=False,
                inherit=True,
                alias=None,
                extend=False,
                prepend=False,
                static=False)

    a = FieldAttribute(**args)

    assert a.isa == 'list'
    assert a.private == False
    assert a.default == []
    assert a.required == False
    assert a.listof == None
    assert a.priority == 10
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == None

# Generated at 2022-06-21 00:02:19.457053
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    att = Attribute(priority=10)
    att2 = Attribute(priority=9)
    att3 = Attribute(priority=10)
    assert att >= att2
    assert att >= att3



# Generated at 2022-06-21 00:02:25.300063
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    x = FieldAttribute()
    y = FieldAttribute(priority=1)
    assert x < y
    assert x <= y
    assert not x == y
    assert x != y
    assert not x >= y
    assert not x > y
    assert y > x
    assert y >= x
    assert not y < x
    assert not y <= x

# Generated at 2022-06-21 00:02:29.019163
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=3)

    assert(a1 < a2)
    assert(not a2 < a1)



# Generated at 2022-06-21 00:02:32.081086
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='test', listof='bla')
    assert attr.isa == 'test'
    assert attr.listof == 'bla'



# Generated at 2022-06-21 00:02:33.833822
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute(priority=2) != Attribute(priority=3)


# Generated at 2022-06-21 00:02:40.075846
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    return attr1 > attr2


# Generated at 2022-06-21 00:02:49.428053
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    ######################################################################
    # Unit test for method __gt__ of class Attribute
    #  @param self The object pointer
    ######################################################################
    def test_Attribute___gt__():

        ######################################################################
        # Unit test for method __gt__ of class Attribute
        #  @param self The object pointer
        ######################################################################
        def test_Attribute___gt__():

            ######################################################################
            # Unit test for method __gt__ of class Attribute
            #  @param self The object pointer
            ######################################################################
            def test_Attribute___gt__():
                pass

            pass

        pass

    pass



# Generated at 2022-06-21 00:02:53.733179
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    field_1 = FieldAttribute(priority=1)
    field_2 = FieldAttribute(priority=2)
    field_3 = FieldAttribute(priority=3)

    assert field_3 > field_2
    assert field_2 > field_1

# Generated at 2022-06-21 00:02:57.039850
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1=Attribute(isa="class", priority=1, class_type="test_class", default=None, required=False, listof=None, inherit=None, alias=None, extend=False, prepend=False, static=False)
    attr2=Attribute(isa="class", priority=1, class_type="test_class", default=None, required=False, listof=None, inherit=None, alias=None, extend=False, prepend=False, static=False)
    res=attr1.__ne__(attr2)
    return res==False


# Generated at 2022-06-21 00:03:03.538277
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    error_message = 'error in method __gt__ of class Attribute'
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    if attribute_1.__gt__(attribute_2):
        raise AssertionError(error_message)
    attribute_2 = Attribute(priority=1)
    if attribute_1.__gt__(attribute_2):
        raise AssertionError(error_message)


# Generated at 2022-06-21 00:03:12.448019
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # python2 version
    if sys.version_info < (3, 0):
        assert Attribute(priority=2) >= Attribute(priority=1)
        assert Attribute(priority=2) >= Attribute(priority=2)
        assert not Attribute(priority=1) >= Attribute(priority=2)
    # python3 version
    else:
        assert Attribute(priority=2) >= Attribute(priority=1)
        assert Attribute(priority=2) >= Attribute(priority=2)
        assert not Attribute(priority=1) >= Attribute(priority=2)

# Generated at 2022-06-21 00:03:17.858654
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(isa='dict', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    assert attr.default == None
    assert attr.required == True


# Generated at 2022-06-21 00:03:24.866093
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    '''
    Test for method __le__
    '''
    # $ python -c 'from collections import namedtuple; nt = namedtuple("a", ["priority"]); a = nt(priority=1); nt1 = nt(priority=1); print(a >= nt1)'
    # self.assertEqual(expected, Attribute.__le__(other))
    raise SkipTest 


# Generated at 2022-06-21 00:03:26.888826
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b > a

# Generated at 2022-06-21 00:03:30.844628
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    from ansible.module_utils.basic import AnsibleModule
    class ModuleAttribute(Attribute):
        def post_validate(self, obj, value):
            return value
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2
    assert not(a1 >= a2)
    assert a1 < a2
    assert not(a1 > a2)
    assert not(a1 != a2)
    assert a1 == a2
    assert not(a1 is a2)

# Generated at 2022-06-21 00:03:36.634783
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr2.__gt__(attr1)


# Generated at 2022-06-21 00:03:44.229844
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    '''
    This function will test the __ne__ method of the class Attribute
    '''
    # Create an object for representing a Attribute
    my_obj1 = Attribute(priority=1)
    my_obj2 = Attribute(priority=2)
    my_obj3 = my_obj1

    # Check if objects are not equal
    assert(not my_obj1 == my_obj2)
    assert(not my_obj1 == my_obj3)


# Generated at 2022-06-21 00:03:48.738530
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    instance1 = Attribute(priority=1)
    instance2 = Attribute(priority=2)

    if not (instance1 <= instance2):
        raise AssertionError('Attribute.__le__() failed')


# Generated at 2022-06-21 00:03:50.880440
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    assert (a <= b) is True
    assert (a <= a) is True
    assert (b <= a) is False


# Generated at 2022-06-21 00:04:02.157960
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # test all parameters
    a1 = FieldAttribute(isa='list', private=True, default=None, required=True, listof='dict', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a1, "a1 should be returned"

    # test all parameters with a `class_type`
    a2 = FieldAttribute(isa='class', private=True, default=None, required=True, listof='dict', priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert a2, "a2 should be returned"

    # test all parameters with a `listof`

# Generated at 2022-06-21 00:04:04.323563
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2.__ge__(attr1) == True


# Generated at 2022-06-21 00:04:05.680998
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    assert a.__le__(Attribute(priority=0))



# Generated at 2022-06-21 00:04:08.105652
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute = Attribute()
    attribute.priority = 0

    assert attribute != Attribute()
    assert attribute != Attribute(priority=1)



# Generated at 2022-06-21 00:04:12.476723
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attribute1 = Attribute(priority = 1)
    attribute2 = Attribute(priority = 2)
    assert attribute2 > attribute1
    assert attribute1 < attribute2
    assert not (attribute2 < attribute1)
    assert not (attribute1 > attribute2)


# Generated at 2022-06-21 00:04:21.838923
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    class Foo:
        def __init__(self, x=0, y=0):
            self.x = x
            self.y = y

    f1 = Foo(y=1)
    f2 = Foo(y=2)

    assert f1._attr_priority <= f2._attr_priority
    assert f1._attr_priority == f1._attr_priority
    assert not f1._attr_priority > f2._attr_priority
    assert not f1._attr_priority < f2._attr_priority
    assert not f1._attr_priority != f1._attr_priority
    assert f1._attr_priority != f2._attr_priority

# Generated at 2022-06-21 00:04:37.719512
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field1 = Attribute(isa="bool")
    field2 = Attribute(isa="bool")
    field3 = Attribute(isa="bool")
    field1.priority = 1
    field2.priority = 2
    field3.priority = 3

    assert not field1 > field1
    assert field1 > field2
    assert field1 > field3
    assert not field2 > field1
    assert not field2 > field2
    assert field2 > field3
    assert not field3 > field1
    assert not field3 > field2
    assert not field3 > field3


# Generated at 2022-06-21 00:04:49.459060
# Unit test for method __eq__ of class Attribute

# Generated at 2022-06-21 00:04:52.229654
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute(isa='str')
    assert 'str' == getattr(field_attribute, 'isa')



# Generated at 2022-06-21 00:04:57.494956
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    fe1 = FieldAttribute(priority=0)
    fe2 = FieldAttribute(priority=10)
    fe3 = FieldAttribute(priority=5)
    fe4 = FieldAttribute(priority=5)
    assert fe1 < fe2
    assert fe3 < fe2
    assert not fe3 < fe4
    assert not fe2 < fe2



# Generated at 2022-06-21 00:05:00.222950
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=0)
    a2 = FieldAttribute(priority=9)
    if not a1 <= a2:
        raise AssertionError()



# Generated at 2022-06-21 00:05:07.971472
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Two Attributes with different value of default
    a1 = Attribute(default=1)
    a2 = Attribute(default=2)
    assert(a1 < a2)
    assert(not a2 < a1)
    # Two Attributes with different value of priority
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert(a1 < a2)
    assert(not a2 < a1)
    # Two Attributes with same values of default and priority
    a1 = Attribute(default=1, priority=1)
    a2 = Attribute(default=1, priority=1)
    assert(not a1 < a2)


# Generated at 2022-06-21 00:05:18.802302
# Unit test for constructor of class Attribute
def test_Attribute():
    # Test for Attribute constructor
    Attribute()
    Attribute(isa = 'str')
    Attribute(required = True)
    Attribute(private = False)
    Attribute(default = 1)
    Attribute(listof = [1, 2, 3])
    Attribute(priority = 1)
    Attribute(class_type = 'int')
    Attribute(inherit = True)
    Attribute(alias = 'test')

    # Test for Attribute's default values
    attr = Attribute()
    assert attr.isa == None
    assert attr.required == False
    assert attr.private == False
    assert attr.default == None
    assert attr.listof == None
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.inherit

# Generated at 2022-06-21 00:05:21.935377
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=3)
    b = Attribute(priority=4)
    c = Attribute(priority=3)
    assert a != c
    assert b != c
    assert b != a


# Generated at 2022-06-21 00:05:28.654431
# Unit test for constructor of class Attribute
def test_Attribute():
    import unittest

    class TestAttribute(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestAttribute, self).__init__(*args, **kwargs)
            self.valid_init = Attribute(isa='dict')
            self.invalid_init = Attribute(isa='dict', default=dict())

        def test_valid_Attribute(self):
            with self.assertRaises(TypeError):
                self.invalid_init

        def test_invalid_Attribute(self):
            self.assertIsInstance(self.valid_init, Attribute)

    unittest.main()

# Generated at 2022-06-21 00:05:31.392132
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr = Attribute()
    attr2 = Attribute()
    assert(attr <= attr2)
    attr3 = Attribute(priority=1)
    assert not(attr <= attr3)
    attr4 = Attribute(priority=1)
    assert(attr3 <= attr4)



# Generated at 2022-06-21 00:05:48.167411
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='int')
    assert a.isa == 'int'

    a = Attribute(isa='int', default=5)
    assert a.default == 5

    a = Attribute(isa='int', required=True)
    assert a.required == True

    a = Attribute(isa='int', listof='int')
    assert a.listof == 'int'

    a = Attribute(isa='int', priority=2)
    assert a.priority == 2

    a = Attribute(isa='int', class_type=str)
    assert a.class_type == str

    a = Attribute(isa='int', always_post_validate=True)
    assert a.always_post_validate == True

    a = Attribute(isa='int', inherit=False)
    assert a.inherit

# Generated at 2022-06-21 00:05:49.826182
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(None)
    assert f
    assert isinstance(f, Attribute)



# Generated at 2022-06-21 00:05:52.200121
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a >= b


# Generated at 2022-06-21 00:05:57.157547
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__ge__(b) == False
    assert a.__ge__(a) == True
    assert b.__ge__(a) == True


# Generated at 2022-06-21 00:06:08.591351
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    # Test method __lt__ with Attribute a = Attribute() and b = Attribute()
    attribute_a = Attribute()
    attribute_b = Attribute()
    assert attribute_a == attribute_b
    assert attribute_b == attribute_a
    assert not(attribute_a != attribute_b)
    assert not(attribute_b != attribute_a)

    # Test method __lt__ with Attribute a = Attribute() and b = Attribute(priority=1)
    attribute_a = Attribute()
    attribute_b = Attribute(priority=1)
    assert attribute_b == attribute_a
    assert attribute_b >= attribute_a
    assert attribute_a <= attribute_b
    assert attribute_a < attribute_b
    assert attribute_b > attribute_a
    assert not(attribute_a > attribute_b)

# Generated at 2022-06-21 00:06:11.375191
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=10)
    assert attr1 <= 10
    assert attr1 >= 10


# Generated at 2022-06-21 00:06:19.690419
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Test with isa, inherit and private as None, False and True respectively
    # expected result is True
    a1 = Attribute(isa=None, inherit=False, private=True)
    a2 = Attribute(isa=None, inherit=False, private=True)
    assert (a1 != a2)

    # Test with isa, inherit and private as None, True and False respectively
    # expected result is False
    a3 = Attribute(isa=None, inherit=True, private=False)
    a4 = Attribute(isa=None, inherit=True, private=False)
    assert (not (a3 != a4))

    # Test with isa, inherit and private as None, True and False respectively
    # expected result is False
    a5 = Attribute(isa=None, inherit=True, private=False)
    a

# Generated at 2022-06-21 00:06:31.460922
# Unit test for constructor of class Attribute
def test_Attribute():
    # No value set
    attr = Attribute()
    # Check if it is an instance of Attribute class
    assert isinstance(attr, Attribute)
    # Check if it is not a string
    assert not isinstance(attr, str)

    # All values set
    attr = Attribute(isa="int", private="True", default=5, required=True, listof="boolean", priority=1, class_type="str",
                     always_post_validate=False, inherit=True, alias="al", extend=True, prepend=True, static=False)
    # Check if it is an instance of Attribute class
    assert isinstance(attr, Attribute)
    # Check if it is not a string
    assert not isinstance(attr, str)
    # Check the type of each value

# Generated at 2022-06-21 00:06:33.397413
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute()
    attr2 = attr

    assert attr == attr2



# Generated at 2022-06-21 00:06:36.185877
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)
    assert attribute2 >= attribute1

if __name__ == "__main__":
    test_Attribute___le__()

# Generated at 2022-06-21 00:07:13.891687
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    def valid_1(value):
      
        attribute=Attribute(priority=1)

        return attribute <= value

    def invalid_1():
        attribute=Attribute(priority=1)
        value=2

        return attribute<=value

    def valid_2(value):
        attribute=Attribute(priority=2)

        return attribute<=value

    def invalid_2():
        attribute=Attribute(priority=2)
        value=1

        return attribute<=value
    
    assert valid_1(1) is True
    assert invalid_1() is False
    assert valid_1(2) is True
    assert valid_2(2) is True
    assert valid_2(1) is True
    assert invalid_2() is False
    assert valid_2(3) is True


# Generated at 2022-06-21 00:07:22.471256
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f1 = FieldAttribute(isa='test-isa', private=False, default="test-default", required=False, listof='test-listof',
                     priority=1, class_type='test-class_type', always_post_validate=False, inherit=False, alias='test-alias',
                     extend=False, prepend=False, static=False)
    assert f1.isa == "test-isa"
    assert f1.private == False
    assert f1.default == "test-default"
    assert f1.required == False
    assert f1.listof == "test-listof"
    assert f1.priority == 1
    assert f1.class_type == "test-class_type"
    assert f1.always_post_validate == False
    assert f1.inherit == False
    assert f

# Generated at 2022-06-21 00:07:23.793362
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert not Attribute().__ne__(Attribute(priority=1))
    assert Attribute().__ne__(Attribute(priority=0))



# Generated at 2022-06-21 00:07:28.513142
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 <= attr2

    attr1.priority = 1
    attr2.priority = 2
    assert attr1 <= attr2

    attr1.priority = 3
    attr2.priority = 2
    assert not attr1 <= attr2

# Generated at 2022-06-21 00:07:39.799079
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute(isa='list', listof='str') != FieldAttribute(isa='list', listof='int')
    assert FieldAttribute(isa='list', listof='str') == FieldAttribute(isa='list', listof='str')
    assert FieldAttribute(isa='list', listof='str') > FieldAttribute(isa='list', listof='int')
    assert FieldAttribute(isa='list', listof='int') < FieldAttribute(isa='list', listof='str')
    assert FieldAttribute(isa='list', listof='int', priority=1) < FieldAttribute(isa='list', listof='int', priority=2)
    assert FieldAttribute(isa='list', listof='int', priority=1) <= FieldAttribute(isa='list', listof='int', priority=2)

# Generated at 2022-06-21 00:07:41.678557
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    att_1 = Attribute(priority = 1)
    att_2 = Attribute(priority = 2)
    assert att_1.__le__(att_2)



# Generated at 2022-06-21 00:07:49.927259
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Test Attribute.__lt__(self, other)
    # Test case 1: when attribute priority are equal

    attr1 = Attribute(isa='str', priority=0)
    attr2 = Attribute(isa='str', priority=0)
    assert not attr1.__lt__(attr2) is True, "Should return False when attribute priority are equal"

    # Test case 2: when attribute priority of 'other' is higher than self
    attr3 = Attribute(isa='str', priority=0)
    attr4 = Attribute(isa='str', priority=1)

    assert attr3.__lt__(attr4) is True, "Should return True when attribute priority of 'other' is higher than self"

    # Test case 3: when attribute priority of 'other' is smaller than self
    attr5 = Attribute

# Generated at 2022-06-21 00:07:55.013806
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=10)
    b = Attribute(priority=20)
    assert(b > a)
    a = Attribute(priority=20)
    b = Attribute(priority=10)
    assert(not b > a)

# Generated at 2022-06-21 00:07:57.683859
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert (a >= b) is False
    assert (b >= a) is True



# Generated at 2022-06-21 00:07:58.719880
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b

# Generated at 2022-06-21 00:08:34.862645
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2
    assert not attr1 > attr2
    assert attr2 > attr1
    assert not attr2 < attr1
    return True


# Generated at 2022-06-21 00:08:39.316857
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute_1 = Attribute(priority=1)
    attribute_2 = Attribute(priority=2)
    assert attribute_1 <= attribute_2, 'Attribute priority should be less or equal than 2'



# Generated at 2022-06-21 00:08:43.352376
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test constructor of FieldAttribute
    field1 = FieldAttribute(isa="class", default=None, required=False, priority=0,
                            class_type=None, always_post_validate=False, inherit=True,
                            alias=None)
    assert field1.isa == "class"
    assert field1.private == False
    assert field1.default == None
    assert field1.required == False
    assert field1.priority == 0
    assert field1.class_type == None
    assert field1.always_post_validate == False
    assert field1.inherit == True
    assert field1.alias == None



# Generated at 2022-06-21 00:08:46.263901
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute()
    attr2 = Attribute()
    attr1.__le__(attr2)


# Generated at 2022-06-21 00:08:56.065500
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    fa = FieldAttribute(isa='str')
    fa = FieldAttribute(isa='str', private=False)
    fa = FieldAttribute(isa='str', default=None)
    fa = FieldAttribute(isa='str', required=False)
    fa = FieldAttribute(isa='str', listof=None)
    fa = FieldAttribute(isa='str', priority=0)
    fa = FieldAttribute(isa='str', class_type=None)
    fa = FieldAttribute(isa='str', always_post_validate=False)
    fa = FieldAttribute(isa='str', inherit=True)
    fa = FieldAttribute(isa='str', alias=None)



# Generated at 2022-06-21 00:09:00.229185
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attribute = Attribute(priority=1)
    assert (attribute < Attribute(priority=2)) is True
    assert (attribute > Attribute(priority=2)) is False

    attribute = Attribute(priority=1)
    assert (attribute < Attribute(priority=1, required=False)) is True
    assert (attribute < Attribute(priority=1, required=True)) is False


# Generated at 2022-06-21 00:09:06.374781
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Test for all possible values of priority
    for i in range(100):
        for j in range(100):
            t1 = Attribute(priority=i)
            t2 = Attribute(priority=j)
            eq_(t1.__lt__(t2), i < j)
            eq_(t2.__lt__(t1), j < i)


# Generated at 2022-06-21 00:09:09.961825
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert FieldAttribute(priority=0) < FieldAttribute(priority=1)
    assert FieldAttribute(priority=0) < FieldAttribute(priority=0)
    assert not FieldAttribute(priority=1) < FieldAttribute(priority=0)



# Generated at 2022-06-21 00:09:13.217701
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert not a1 < a1
    assert a1 < a2
    assert not a2 < a1




# Generated at 2022-06-21 00:09:15.346737
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa='class')
    assert field.isa == 'class'



# Generated at 2022-06-21 00:10:27.160952
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    # model 1
    attribute1 = Attribute(priority=2)
    # model 2
    attribute2 = Attribute(priority=3)

    # compare.
    c = attribute1.__gt__(attribute2)
    assert c == False



# Generated at 2022-06-21 00:10:35.860901
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    field1 = {"a": 1, "b": 2, "c": 3}
    field2 = {"a": 1, "b": 2, "c": 4}
    field3 = {"a": 1, "b": 2, "c": 3}
    field4 = {"a": 1, "b": 2}

    assert Attribute(**field1).__gt__(Attribute(**field2)) == False
    assert Attribute(**field1).__gt__(Attribute(**field3)) == False
    assert Attribute(**field1).__gt__(Attribute(**field4)) == False
    assert Attribute(**field2).__gt__(Attribute(**field1)) == True
    assert Attribute(**field3).__gt__(Attribute(**field1)) == False

# Generated at 2022-06-21 00:10:39.154084
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute()
    a2 = Attribute(priority=1)
    a3 = Attribute()

    assert a1 < a2
    assert not (a1 < a3)


# Generated at 2022-06-21 00:10:51.133532
# Unit test for constructor of class Attribute
def test_Attribute():

    # test __init__ argument name "isa"
    attr_isa = Attribute(isa="test")
    assert attr_isa.isa == "test"

    # test __init__ argument name "private"
    attr_private = Attribute(private=True)
    assert attr_private.private is True

    # test __init__ argument name "default"
    attr_default = Attribute(default=True)
    assert attr_default.default is True

    # test __init__ argument name "required"
    attr_required = Attribute(required=True)
    assert attr_required.required is True

    # test __init__ argument name "listof"
    attr_listof = Attribute(listof="test")
    assert attr_listof.listof == "test"

    # test __init

# Generated at 2022-06-21 00:10:53.488024
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=20)
    assert attr1 <= attr2


# Generated at 2022-06-21 00:10:57.610521
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(isa='list', required=True, priority=1)
    b = Attribute(isa='dict', required=False, priority=1)
    c = Attribute(isa='str', required=False, priority=3)
    d = Attribute(isa='str', required=False, priority=1)
    assert a != b
    assert a != c
    assert b != d


# Generated at 2022-06-21 00:11:03.837029
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # preparing the test data - test data is same
    attribute1=Attribute(isa='str')
    attribute2=Attribute(isa='str')
    # preparing expected result - expected result is true
    expected_result=True

    # running the test
    result = attribute1.__eq__(attribute2)

    # asserting the result
    assert expected_result==result
