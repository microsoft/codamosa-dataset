

# Generated at 2022-06-21 00:01:06.613409
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    foo = Attribute(priority=11)
    bar = Attribute(priority=22)
    baz = Attribute(priority=22)
    assert foo < bar
    assert foo <= bar
    assert not baz < bar
    assert baz <= bar



# Generated at 2022-06-21 00:01:12.117428
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    A = Attribute(priority = 1,required = False)
    B = Attribute(priority = 2,required = False)
    assert(A.__gt__(B))
    assert(not A.__gt__(A))
    assert(not B.__gt__(A))
    assert(not B.__gt__(B))


# Generated at 2022-06-21 00:01:14.641782
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 < attr1


# Generated at 2022-06-21 00:01:17.711222
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert b >= a


# Generated at 2022-06-21 00:01:19.136674
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Make sure we don't crash when constructing.
    f = FieldAttribute()



# Generated at 2022-06-21 00:01:27.743244
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test default isa
    attr = FieldAttribute()
    assert attr.isa is None

    # Test invalid alias
    try:
        attr = FieldAttribute(alias=42)
        raise AssertionError("FieldAttribute allowed invalid alias of %s: %s" % (type(42), 42))
    except TypeError:
        pass

    # Test default value
    attr = FieldAttribute(default="test")
    assert attr.default == "test"
    assert "default" in dir(attr)

    # Test listof isa
    attr = FieldAttribute(listof="test")
    assert attr.listof == "test"
    assert "listof" in dir(attr)

    # Test class_type isa
    attr = FieldAttribute(class_type="test")
    assert attr.class_type

# Generated at 2022-06-21 00:01:32.371964
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr_A = Attribute(priority=1)
    attr_B = Attribute(priority=2)
    attr_C = Attribute(priority=3)
    assert attr_C <= attr_B
    assert not attr_C <= attr_A


# Generated at 2022-06-21 00:01:34.950532
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute()
    assert(a.__ge__(b))
    assert(not b.__ge__(a))



# Generated at 2022-06-21 00:01:41.379215
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    instance1 = Attribute(priority=2)
    instance2 = Attribute(priority=3)
    assert not (instance1 <= instance2)

    instance1 = Attribute(priority=2)
    instance2 = Attribute(priority=2)
    assert (instance1 <= instance2)

    instance1 = Attribute(priority=2)
    instance2 = Attribute(priority=1)
    assert (instance1 <= instance2)

# Generated at 2022-06-21 00:01:52.035514
# Unit test for constructor of class Attribute
def test_Attribute():
    assert Attribute(default=False) == Attribute(default=False)
    assert Attribute(default=False) != Attribute(default=True)

    assert not Attribute(default=True) < Attribute(default=True)
    assert not Attribute(default=True) > Attribute(default=True)

    assert not Attribute(default=True) < Attribute(default=False)
    assert not Attribute(default=True) > Attribute(default=False)

    assert Attribute(default=False) < Attribute(default=True)
    assert Attribute(default=False) > Attribute(default=True)

    assert Attribute(default=False) <= Attribute(default=True)
    assert Attribute(default=False) >= Attribute(default=True)


# Generated at 2022-06-21 00:02:02.049833
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute()
    a = FieldAttribute(isa='bool', default=False)
    a = FieldAttribute(isa='list', default=list, listof='str')
    a = FieldAttribute(isa='list', default=list, listof='str', inherit=False)
    a = FieldAttribute(isa='str', default='default value', inherit=False)

# Generated at 2022-06-21 00:02:05.260596
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)

    assert c > a
    assert b < c

# Generated at 2022-06-21 00:02:10.337421
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority = 1)
    a2 = Attribute(priority = 2)
    a3 = Attribute(priority = 1)

    assert a2 < a1
    assert not a1 < a3
    assert not a2 < a3
    assert not a3 < a1
    assert not a3 < a2


# Generated at 2022-06-21 00:02:11.650113
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    field_attr = Attribute(priority=0)
    assert field_attr <= Attribute(priority=1)


# Generated at 2022-06-21 00:02:23.710904
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    type_a = Attribute(priority=1)
    type_b = Attribute(priority=2)
    type_c = Attribute(priority=3)
    type_equal_c = Attribute(priority=3)
    type_less_c = Attribute(priority=2)
    type_greater_c = Attribute(priority=4)
    assert (type_a == type_b) is False
    assert (type_b == type_a) is False
    assert (type_a == type_c) is False
    assert (type_a == type_a) is True
    assert (type_b == type_b) is True
    assert (type_c == type_equal_c) is True
    assert (type_less_c == type_c) is False

# Generated at 2022-06-21 00:02:34.411096
# Unit test for constructor of class Attribute
def test_Attribute():

    attribute = Attribute(
        isa='str',
        private=False,
        default={'test': 'test'},
        required=False,
        listof=None,
        priority=0,
        class_type='str',
        inherit=False,
        always_post_validate=True,
    )

    assert attribute.isa == 'str'
    assert attribute.private is False
    assert attribute.default == {'test': 'test'}
    assert attribute.required is False
    assert attribute.listof is None
    assert attribute.priority == 0
    assert attribute.class_type == 'str'
    assert attribute.inherit is False
    assert attribute.always_post_validate is True



# Generated at 2022-06-21 00:02:41.154638
# Unit test for constructor of class Attribute
def test_Attribute():
    # test with no argument
    obj1 = Attribute()

    # for private attribute
    assert obj1.private == False

    # for isa attribute
    assert obj1.isa is None

    # for default attribute
    assert obj1.default == None

    # for required attribute
    assert obj1.required == False

    # for listof attribute
    assert obj1.listof is None

    # for priority attribute
    assert obj1.priority == 0

    # for class_type attribute
    assert obj1.class_type is None

    # for always_post_validate attribute
    assert obj1.always_post_validate == False

    # for inherit attribute
    assert obj1.inherit == True

    # for alias attribute
    assert obj1.alias is None

    # for extend attribute
    assert obj1.extend == False

# Generated at 2022-06-21 00:02:48.795834
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # verify test input
    # isa=None,private=False,default=None,required=False,listof=None,priority=0,class_type=None,
    # always_post_validate=False,inherit=True,alias=None,extend=False,prepend=False
    # expected result is it returns False
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 == attr2 == 0


# Generated at 2022-06-21 00:02:51.135628
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=10)
    b = Attribute(priority=10)
    assert not (a != b)


# Generated at 2022-06-21 00:03:01.806158
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    class Foo(object):
        field1 = FieldAttribute(isa='str', private=True, default='hello', required=True, listof='str', priority=10, class_type='str', always_post_validate=True, inherit=False, alias='field2')

        def __init__(self, field1, field2, field3):
            self.field1 = field1
            self.field2 = field2
            self.field3 = field3

    f = Foo('abc', 'def', 'ghi')
    assert f.field1 == 'abc'
    assert f.field2 == 'def'
    assert f.field3 == 'ghi'
    try:
        assert f.field4 == 'jkl'
    except AttributeError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-21 00:03:06.946660
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr = Attribute()
    attr2 = Attribute(priority=2)

    assert attr2 < attr



# Generated at 2022-06-21 00:03:09.792961
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()

    a.priority = 3
    b.priority = 2

    assert a > b


# Generated at 2022-06-21 00:03:12.732602
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=100)
    b = Attribute(priority=300)
    assert a < b
    assert b > a
    assert a <= b
    assert b >= a

# Generated at 2022-06-21 00:03:16.300226
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert not (a1 == a2)
    assert (a1 != a2)


# Generated at 2022-06-21 00:03:21.834738
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)
    print(attr1 >= attr2)
    print(attr1 >= attr3)
    print(attr2 >= attr1)
    print(attr2 >= attr3)

# Generated at 2022-06-21 00:03:26.801437
# Unit test for constructor of class Attribute
def test_Attribute():
    import pytest
    # default constructor
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None

    # a = Attribute(isa='foo', private=True, required=True, inherit=False)
    # assert a.isa == 'foo'
    # assert a.private == True
    # assert a.required == True
    # assert a.inherit == False

    # test attribute with default mutable value
    def _default():
        return []

# Generated at 2022-06-21 00:03:37.156604
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    class A:
        pass

    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)
    a = A()
    a.is_attr_ne_value = a.is_attr_eq_value = False
    a.attr2 = attr2
    a.attr3 = attr3
    if a.attr2 != a.attr3:
        a.is_attr_ne_value = True
    if a.attr2 == a.attr3:
        a.is_attr_eq_value = True

    assert a.is_attr_ne_value == True
    assert a.is_attr_eq_value == False


# Generated at 2022-06-21 00:03:42.894192
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr_1 = Attribute(priority=1)
    attr_2 = Attribute(priority=2)
    assert attr_1.__ge__(attr_2) == False
    assert attr_2.__ge__(attr_1) == True
    assert attr_1.__ge__(attr_1) == True


# Generated at 2022-06-21 00:03:45.969269
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute = Attribute()
    if attribute >= attribute:
        print("Test passed.")
    else:
        print("Test failed.")


# Generated at 2022-06-21 00:03:50.809437
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    x = Attribute(2)
    y = Attribute(2)
    if x.__ne__(y):
        raise RuntimeError("Attribute objects are not equal")
    if not x.__ne__(Attribute(1)):
        raise RuntimeError("Attribute objects are equal")


# Generated at 2022-06-21 00:03:58.148332
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attribute1 = Attribute()
    attribute2 = Attribute(priority=1)

    assert attribute1 >= attribute2
    assert attribute2 <= attribute1
    assert attribute2 >= attribute2
    assert attribute1 <= attribute1



# Generated at 2022-06-21 00:04:01.698383
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(
        isa='test',
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
    )
    assert attr.is_attribute() is True


# Generated at 2022-06-21 00:04:03.557772
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=10)
    attr2 = Attribute(priority=10)
    assert attr1 == attr2


# Generated at 2022-06-21 00:04:05.132119
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    assert a.priority >= 0

# Generated at 2022-06-21 00:04:12.555148
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    print('Class Attribute method __ne__ unit test start!')
    attr = Attribute()
    attr.priority = 5
    attr1 = Attribute()
    attr1.priority = 4
    print(attr != attr1)
    attr1.priority = 5
    print(attr != attr1)
    print('Class Attribute method __ne__ unit test over!')

if __name__ == '__main__':
    test_Attribute___ne__()

# Generated at 2022-06-21 00:04:19.074668
# Unit test for constructor of class Attribute
def test_Attribute():
    # set some new attributes
    attr = Attribute('str', True, [1, 2, 3], True, 'str', 0, 'class')
    # check if everything was set correct
    assert attr.isa == 'str'
    assert attr.private == True
    assert attr.default == [1, 2, 3]
    assert attr.required == True
    assert attr.listof == 'str'
    assert attr.priority == 0
    assert attr.class_type == 'class'
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert attr.extend == False
    assert attr.prepend == False
    assert attr.static == False
    # now test the __eq__ method
    assert attr == Attribute()
    # set

# Generated at 2022-06-21 00:04:21.632556
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    """
    Unit test for FieldAttribute
    :return: None
    """
    test_field_attribute = FieldAttribute()



# Generated at 2022-06-21 00:04:30.141270
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    '''
    Test method __lt__ of class Attribute
    Unit test for method __lt__ of class Attribute
    '''
    a = Attribute(priority=5, isa='dict', private=False, default=None, required=False, listof=None, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)
    b = Attribute(priority=10, isa='dict', private=False, default=None, required=False, listof=None, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False)

    assert(not a < b == b >= a)
    a.priority = 10
    b.priority = 5


# Generated at 2022-06-21 00:04:36.332513
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    my_attribute = Attribute()
    my_attribute.priority = 3
    other_attribute = Attribute()
    other_attribute.priority = 4
    if not my_attribute.__ge__(other_attribute):
        raise AssertionError()


# Generated at 2022-06-21 00:04:42.632341
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Test that method __gt__ returns correct values when called with correct parameters.
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    # Test that __gt__ returns False when called with an Attribute with a higher priority.
    assert not (a1 > a2)
    # Test that __gt__ returns True when called with an Attribute with a lower priority.
    assert a2 > a1


# Generated at 2022-06-21 00:04:53.054513
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=3)
    attr3 = Attribute(priority=2)

    assert attr1 != attr2
    assert attr1 != attr3
    assert attr2 != attr3


# Generated at 2022-06-21 00:04:58.265650
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    assert not a >= b
    assert b >= a
    assert not c >= b
    assert not b >= c
    assert a >= a
    assert b >= b
    assert c >= c


# Generated at 2022-06-21 00:05:07.971316
# Unit test for constructor of class Attribute
def test_Attribute():

    attr = Attribute(
        isa='str',
        private=False,
        default='1',
        required=False,
        listof='int',
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert attr.isa == 'str'
    assert attr.private == False
    assert attr.default == '1'
    assert attr.required == False
    assert attr.listof == 'int'
    assert attr.priority == 0
    assert attr.class_type == None
    assert attr.always_post_validate == False
    assert attr.inherit == True
    assert att

# Generated at 2022-06-21 00:05:18.803704
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)

    # method __eq__ of class Attribute
    assert(attr1 == attr1)  # True
    assert(attr2 == attr2)  # True
    assert(attr3 == attr3)  # True

    assert(attr1 == attr3)  # True
    assert(attr3 == attr1)  # True

    assert(attr1 != attr2)  # True
    assert(attr2 != attr1)  # True

    assert(attr1 != attr1)  # False
    assert(attr2 != attr2)  # False
    assert(attr3 != attr3)  # False


# Generated at 2022-06-21 00:05:27.949656
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    test = Attribute(isa=int, private=False, default=None,
                     required=False, listof=None, priority=0,
                     class_type=None, always_post_validate=False,
                     inherit=True, alias=None)
    test2 = Attribute(isa=int, private=False, default=None,
                     required=False, listof=None, priority=1,
                     class_type=None, always_post_validate=False,
                     inherit=True, alias=None)
    assert test != test2
    test3 = Attribute(isa=int, private=False, default=None,
                     required=False, listof=None, priority=0,
                     class_type=None, always_post_validate=False,
                     inherit=True, alias=None)
    assert test == test3



# Generated at 2022-06-21 00:05:29.823275
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    attr = Attribute(priority=1)
    not_attr = None

    assert isinstance(attr, Attribute)
    assert attr < not_attr


# Generated at 2022-06-21 00:05:31.572978
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    Attribute.__gt__(Attribute(priority=3), Attribute(priority=4))


# Generated at 2022-06-21 00:05:34.940944
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():

    f = Attribute()
    f.priority = 2

    f1 = Attribute()
    f1.priority = 2

    assert(f != f1)

    f1.priority = 3

    assert(f != f1)


# Generated at 2022-06-21 00:05:45.763667
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    with pytest.raises(TypeError) as excinfo:
        FieldAttribute( default={} )
    assert 'may not be mutable' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        FieldAttribute( default=[] )
    assert 'may not be mutable' in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        FieldAttribute( default=set() )
    assert 'may not be mutable' in str(excinfo.value)

    assert FieldAttribute( default=None )

    def _default_factory():
        return set()
    assert FieldAttribute( default=_default_factory )



# Generated at 2022-06-21 00:05:53.607763
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    FA = FieldAttribute()
    if FA.isa is not None:
        raise AssertionError('FA.isa should be None after initialization but is %s' % repr(FA.isa))
    if FA.private is not False:
        raise AssertionError('FA.private should be False after initialization but is %s' % repr(FA.private))
    if FA.default is not None:
        raise AssertionError('FA.default should be None after initialization but is %s' % repr(FA.default))
    if FA.required is not False:
        raise AssertionError('FA.required should be False after initialization but is %s' % repr(FA.required))
    if FA.listof is not None:
        raise AssertionError('FA.listof should be None after initialization but is %s' % repr(FA.listof))

# Generated at 2022-06-21 00:06:07.962616
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    assert attr2 > attr1

# Generated at 2022-06-21 00:06:17.994333
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():

    # Test for correct type of class Attribute
    a1 = Attribute(default='a', priority=1)
    assert isinstance(a1, Attribute)
    a2 = Attribute(default='b', priority=2)
    assert isinstance(a2, Attribute)

    # Test that all of the comparisons return the correct values,
    # and that they all return the same type of value
    assert a1.__lt__(a2) == False
    assert isinstance(a1.__lt__(a2), bool)
    assert a1.__le__(a2) == False
    assert isinstance(a1.__le__(a2), bool)
    assert a1.__ge__(a2) == True
    assert isinstance(a1.__ge__(a2), bool)
    assert a1.__

# Generated at 2022-06-21 00:06:19.986910
# Unit test for constructor of class Attribute
def test_Attribute():
    s = Attribute()
    assert isinstance(s, Attribute)

# Test equality comparisons of class Attribute

# Generated at 2022-06-21 00:06:22.915262
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b
    assert not b < a



# Generated at 2022-06-21 00:06:25.656510
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=1)
    other = Attribute(priority=1)

    assert (attr != other) == False

# Generated at 2022-06-21 00:06:32.380412
# Unit test for constructor of class Attribute
def test_Attribute():
    field = FieldAttribute()
    assert field.isa is None
    assert field.private is False
    assert field.default is None
    assert field.required is False
    assert field.listof is None
    assert field.priority == 0
    assert field.class_type is None
    assert field.always_post_validate is False
    assert field.inherit is True
    assert field.alias is None

if __name__ == '__main__':
    test_Attribute()

# Generated at 2022-06-21 00:06:36.492484
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=1)

    assert(attr1._Attribute__eq__(attr3))
    assert(not attr2._Attribute__eq__(attr1))



# Generated at 2022-06-21 00:06:40.904519
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=10, always_post_validate=True)
    attr2 = Attribute(priority=10, always_post_validate=False)
    assert(attr1 == attr2)
    attr2 = Attribute(isa="list", priority=10, always_post_validate=True)
    assert(attr1 != attr2)


# Generated at 2022-06-21 00:06:52.742906
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    print("\n=============start test_Attribute___ge__=============\n")
    import os
    import sys
    import pandas as pd
    
    # Save the current command line arguments.
    _, *script_args = sys.argv
    # print("sys.argv[0] = ", sys.argv[0])
    # print("script_args = ", script_args)
    # Save the current working directory.
    cur_dir = os.getcwd()
    # print("cur_dir = ", cur_dir)

    # print("sys.executable = ", sys.executable)
    # print("sys.path = ", sys.path)
    
    # Get the path of this file.
    this_python_file_path = os.path.realpath(__file__)

# Generated at 2022-06-21 00:06:54.600680
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a >= b


# Generated at 2022-06-21 00:07:20.013498
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a2 < a1, "Method __lt__(Attribute, Attribute) is incorrect"


# Generated at 2022-06-21 00:07:27.652305
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute(isa='str')
    assert a.isa == 'str'
    assert a.private == False
    assert a.default == None
    assert a.required == False
    assert a.listof == None
    assert a.priority == 0
    assert a.class_type == None
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.extend == False
    assert a.prepend == False
    assert a.static == False



# Generated at 2022-06-21 00:07:37.773955
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    description = u'This is a test'
    a = FieldAttribute(isa='boolean', private=True, default='test', required=True, listof='boolean', priority=0, class_type='test', always_post_validate=True, inherit=False, alias=description)
    assert a.isa == 'boolean'
    assert a.private == True
    assert a.default == 'test'
    assert a.required == True
    assert a.listof == 'boolean'
    assert a.priority == 0
    assert a.class_type == 'test'
    assert a.always_post_validate == True
    assert a.inherit == False
    assert a.alias == description


# Generated at 2022-06-21 00:07:38.780385
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute() <= Attribute()


# Generated at 2022-06-21 00:07:40.197456
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attr = FieldAttribute(isa='dict')
    assert attr.isa == 'dict'

# Generated at 2022-06-21 00:07:42.980858
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute()

    assert(not a.__eq__(Attribute(priority=1)))
    assert(a.__eq__(Attribute(priority=0)))

# Generated at 2022-06-21 00:07:50.568917
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    f = FieldAttribute(isa='list')
    assert(f.isa == 'list')
    assert(f.private == False)
    assert(f.default == None)
    assert(f.required == False)
    assert(f.listof == None)
    assert(f.priority == 0)
    assert(f.always_post_validate == False)

    def my_func():
        return 1

    f = FieldAttribute(isa='list', private=True, default=my_func, required=True, listof=True, priority=1, always_post_validate=True)
    assert(f.isa == 'list')
    assert(f.private == True)
    assert(f.default == my_func)
    assert(f.required == True)
    assert(f.listof == True)

# Generated at 2022-06-21 00:07:55.130655
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=10)
    assert attr.__ne__(Attribute(priority=0)) is True
    assert attr.__ne__(Attribute(priority=10)) is False


# Generated at 2022-06-21 00:08:05.728119
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Enforce constructor parameters of class FieldAttribute
    # NB: order of parameters from https://docs.python.org/3/library/functions.html?#__init__
    # so add precedence to the last one
    a = FieldAttribute(isa='int',
                       private=True,
                       default=10,
                       required=True,
                       listof='str',
                       priority=10,
                       class_type='str',
                       always_post_validate=True,
                       inherit=True,
                       alias='field')
    b = FieldAttribute(isa='int',
                       private=True,
                       default=10,
                       required=True,
                       listof='str',
                       priority=10,
                       class_type='str',
                       always_post_validate=True,
                       inherit=True,
                       alias='field')

# Generated at 2022-06-21 00:08:11.671412
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from ansible.playbook.attribute import Attribute
    a = Attribute(priority=2)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    assert(a >= b)
    assert(a >= c)

# All attributes which may be set on a base object
BASE_OBJECT_FIELDS = frozenset((
    '_name',
    '_parent',
    '_ds',
    '_load_name',
    '_role_name',
    '_role_path',
    '_role_params',
))

# base class for all task and playbook objects

# Generated at 2022-06-21 00:09:08.867166
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    assert a.__gt__(b) == False
    assert a.__lt__(b) == False
    assert a.__eq__(b) == True
    assert a.__ge__(b) == True
    assert a.__le__(b) == True

    b.priority = 1

    assert a.__gt__(b) == False
    assert a.__lt__(b) == True
    assert a.__eq__(b) == False
    assert a.__ge__(b) == False
    assert a.__le__(b) == False


# Generated at 2022-06-21 00:09:12.722574
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    if a.__ne__(b) != True:
        print('Attribute method __ne__ of class Attribute failed')


# Generated at 2022-06-21 00:09:13.658453
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()


# Generated at 2022-06-21 00:09:18.964151
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a, b = Attribute(), Attribute()

    a.priority = 5
    b.priority = 5
    assert not (a < b)

    a.priority = 5
    b.priority = 10
    assert a < b

    a.priority = 20
    b.priority = 10
    assert not (a < b)



# Generated at 2022-06-21 00:09:23.713866
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute()
    b = Attribute(priority=1)
    c = Attribute(priority=5)

    assert (b >= a) is True
    assert (a >= a) is True
    assert (a >= b) is False
    assert (a >= c) is False
    assert (c >= a) is True
    assert (c >= b) is True



# Generated at 2022-06-21 00:09:32.284911
# Unit test for constructor of class Attribute
def test_Attribute():
    """This is a functional test of the Attribute class and its __init__ method.
    """
    # This __init__ method is extremely simple, it is a good candidate to be
    # removed and use the parent class __init__ method directly (configuring
    # the args through a meta class, see the ModelBase class).

    # Warming up:
    Attribute()

    attr = Attribute(
        isa='dict',
        private=True,
        default='de',
        required=True,
        listof='list',
        priority=1,
        class_type='list',
        always_post_validate=True,
        inherit=True,
        alias='alias',
        extend=False,
        prepend=False,
        static=True,
    )
    assert attr.isa == 'dict'

# Generated at 2022-06-21 00:09:39.680258
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr = Attribute()

    attr.priority = 1
    other_attr = copy(attr)
    other_attr.priority = 0
    assert attr.__ge__(other_attr) is True

    other_attr.priority = 1
    assert attr.__ge__(other_attr) is True

    other_attr.priority = 2
    assert attr.__ge__(other_attr) is False



# Generated at 2022-06-21 00:09:45.143948
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    attribute = FieldAttribute("", True, 2, True, 2)
    assert attribute.isa == ""
    assert attribute.private == True
    assert attribute.default == 2
    assert attribute.required == True
    assert attribute.listof == 2

# Unit tests for operation of method __init__ of FieldAttribute class

# Generated at 2022-06-21 00:09:49.756219
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(isa=str, private=False, default='example', required=False, listof=None,
                     priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None)
    assert attr == attr
    assert not (attr != attr)


# Generated at 2022-06-21 00:09:58.515035
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a=Attribute(isa='string', private=True, default=None, required=True, listof=None, priority=0, class_type=None, always_post_validate=True, inherit=True, alias=None, extend=True, prepend=False, static=True)
    b=Attribute(isa='integer', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=True, inherit=True, alias=None, extend=True, prepend=True, static=True)