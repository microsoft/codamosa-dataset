

# Generated at 2022-06-21 00:01:09.680030
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    if attr1.__ne__(attr2):
        return True
    else:
        return False


# Generated at 2022-06-21 00:01:21.479806
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    """Unit test for method __ge__ of class Attribute"""

    a1 = Attribute()
    a2 = Attribute()
    assert a1.__ge__(a2)
    assert a2.__ge__(a1)
    a1 = Attribute(priority=5)
    a2 = Attribute()
    assert a1.__ge__(a2)
    assert not a2.__ge__(a1)
    a1 = Attribute(priority=5)
    a2 = Attribute(priority=5)
    assert a1.__ge__(a2)
    assert a2.__ge__(a1)
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=5)
    assert a1.__ge__(a2)
    assert not a2.__ge

# Generated at 2022-06-21 00:01:24.890752
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2


# Generated at 2022-06-21 00:01:36.260856
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print("========== test_Attribute___le__ ==========")
    class_type = 'class_type'
    always_post_validate = True
    inherit = True
    alias = 'alias'
    extend = False
    prepend = False
    static = False

    a = Attribute(isa='isa', private='private', default='default',
        required='required', listof='listof', priority=0, class_type=class_type,
        always_post_validate=always_post_validate, inherit=inherit,
        alias=alias, extend=extend, prepend=prepend, static=static
        )

# Generated at 2022-06-21 00:01:44.650504
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    first = Attribute(priority=1)
    second = Attribute(priority=2)
    assert (not first == second)
    assert (first != second)
    assert (first <= second)
    assert (not first >= second)
    assert (first < second)
    assert (not first > second)
    assert (second >= first)
    assert (second > first)
    assert (second <= first)
    assert (not second < first)
    assert (not second == first)
    assert (second != first)


# Generated at 2022-06-21 00:01:46.945999
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)

    assert(a < b)


# Generated at 2022-06-21 00:01:48.585580
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    a.priority = 1
    assert a <= a
    b = Attribute()
    b.priority = 2
    assert a <= b
    b.priority = 1
    assert a <= b

# Generated at 2022-06-21 00:01:56.398699
# Unit test for constructor of class Attribute
def test_Attribute():
    isa = 'number'
    private = False
    default = 3.14
    required = False
    listof = 'string'
    priority = 0
    class_type = 'str'
    always_post_validate = False
    inherit = True
    alias = None,
    extend = False
    prepend = False
    static = False

# Generated at 2022-06-21 00:01:59.840095
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1 == attr2


# Generated at 2022-06-21 00:02:06.106856
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    # Test with two different instances
    objA = Attribute()
    objB = Attribute()
    assert objA == objB, "The priority value should be equals."

    # Test with two different instances but with different priority values
    objA = Attribute(priority=4)
    objB = Attribute(priority=2)
    assert objA != objB, "The priority value should be different."



# Generated at 2022-06-21 00:02:10.698248
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # return_value = class_instance.method()
    assert Attribute.__ne__(Attribute(), Attribute()) == "to be implemented!"



# Generated at 2022-06-21 00:02:14.760655
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr1 > attr2
    assert not attr1 < attr2
    assert attr2 < attr1
    assert not attr2 > attr1


# Generated at 2022-06-21 00:02:20.281239
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    Attribute1 = Attribute(priority=1)
    Attribute2 = Attribute(priority=2)
    print('Attribute1 <= Attribute1:', Attribute1 <= Attribute1)
    print('Attribute1 <= Attribute2:', Attribute1 <= Attribute2)
    print('Attribute2 <= Attribute1:', Attribute2 <= Attribute1)
#test_Attribute___le__()

# Generated at 2022-06-21 00:02:24.277254
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr2 = Attribute()
    attr.priority = 1
    attr2.priority = 2
    assert(attr != attr2)



# Generated at 2022-06-21 00:02:27.370200
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a = Attribute(0)
    b = Attribute(0)
    c = Attribute(1)
    assert a != c
    assert b != c
    assert not a != b

# Generated at 2022-06-21 00:02:37.954331
# Unit test for constructor of class FieldAttribute

# Generated at 2022-06-21 00:02:44.883991
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr01 = FieldAttribute(required=True, priority=0)
    attr02 = FieldAttribute(required=True, priority=1)

    assert attr02 < attr01
    assert attr01 > attr02

    attr01 = FieldAttribute(required=True, priority=0)
    attr02 = FieldAttribute(required=True, priority=1)

    assert attr02 < attr01
    assert attr01 > attr02



# Generated at 2022-06-21 00:02:48.784292
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=6)
    a2 = Attribute(priority=6)
    a3 = Attribute(priority=4)
    assert(a1 == a2)
    assert(a1 != a3)


# Generated at 2022-06-21 00:02:57.398228
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert not attr.private
    assert attr.default is None
    assert not attr.required
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias is None
    assert not attr.extend
    assert not attr.prepend
    assert not attr.static
    assert isinstance(attr, Attribute)



# Generated at 2022-06-21 00:02:58.901994
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(isa='list', priority=0) == Attribute(isa='list', priority=0)


# Generated at 2022-06-21 00:03:05.071295
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    attr1 = Attribute(priority=2)
    attr2 = Attribute(priority=1)
    assert attr1.__ge__(attr2)


# Generated at 2022-06-21 00:03:12.300796
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    pri1 = Attribute(priority=1)
    pri2 = Attribute(priority=2)
    pri3 = Attribute(priority=3)
    assert pri2 > pri1
    assert pri2 < pri3
    assert not (pri2 < pri1)
    assert not (pri2 > pri3)
    assert not (pri2 <= pri1)
    assert not (pri1 >= pri2)
    assert not (pri2 >= pri3)
    assert not (pri3 <= pri2)

# Generated at 2022-06-21 00:03:17.367681
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # Test standard constructor
    FieldAttribute()

    # Test constructor with all options
    FieldAttribute(
        isa='string',
        private=True,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias='alias',
        extend=False,
        prepend=False,
        static=False,
    )

# Unit test of operator overloads

# Generated at 2022-06-21 00:03:20.129867
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    a.priority = 10
    assert a.__gt__(b)



# Generated at 2022-06-21 00:03:24.010461
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attribute1 = Attribute(priority=0)
    attribute2 = Attribute(priority=1)
    assert attribute1 == attribute1
    assert not attribute1 == attribute2
    assert not attribute1 == 1

# Generated at 2022-06-21 00:03:27.776737
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='something', static=True)
    assert fa.isa == 'something'
    assert fa.static == True
    assert fa.listof == None
    assert fa.prepend == False
    assert fa.extend == False


# Generated at 2022-06-21 00:03:39.557143
# Unit test for constructor of class Attribute
def test_Attribute():
    fields = {}
    fields['requires_ansible_vars'] = FieldAttribute(
        isa='list',
        default=[],
        static=True,
        inherit=True,
        listof='string',
        priority=128
    )
    fields['name'] = FieldAttribute(
        isa='string',
        default=None,
        inherit=False,
        priority=32
    )

    assert len(fields) == 2
    assert fields['requires_ansible_vars'].isa == 'list'
    assert fields['requires_ansible_vars'].inherit
    assert fields['requires_ansible_vars'].listof == 'string'
    assert fields['requires_ansible_vars'].priority == 128
    assert fields['requires_ansible_vars'].static


# Generated at 2022-06-21 00:03:47.871581
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=1)
    attr3 = Attribute(priority=2)
    print("attr1 == attr2: %s" % (attr1 == attr2))
    print("attr1 == attr3: %s" % (attr1 == attr3))
    print("attr2 == attr3: %s" % (attr2 == attr3))


# Generated at 2022-06-21 00:03:55.766493
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # Tests for the method __gt__ of class Attribute
    field0 = FieldAttribute(priority=0)
    field1 = FieldAttribute(priority=1)
    field2 = FieldAttribute(priority=2)

    assert field1.__gt__(field0)
    assert field2.__gt__(field1)
    assert field2.__gt__(field0)

    assert not field0.__gt__(field0)
    assert not field0.__gt__(field1)
    assert not field1.__gt__(field2)

# Generated at 2022-06-21 00:03:59.444463
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    att1 = Attribute()
    att1.priority = 1
    att2 = Attribute()
    att2.priority = 2
    assert att1.__ne__(att2) == True



# Generated at 2022-06-21 00:04:16.045097
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=3)
    a2 = Attribute(priority=5)
    if not a2.__ge__(a1):
        raise AssertionError("a2 should be greater than or equal to a1")
    a3 = Attribute(priority=4)
    if not a2.__ge__(a3):
        raise AssertionError("a2 should be greater than or equal to a3")
    a4 = Attribute(priority=4)
    if a2.__ge__(a4):
        raise AssertionError("a2 should be less than a4")

# Generated at 2022-06-21 00:04:18.839114
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=0) == Attribute(priority=0)
    assert not Attribute(priority=0) == Attribute()


# Generated at 2022-06-21 00:04:28.515380
# Unit test for constructor of class Attribute
def test_Attribute():
    is_a = "string"
    default = "TESTING"
    required = True
    a = Attribute(isa=is_a, default=default, required=required)
    assert a.isa == is_a
    assert a.default == default
    assert a.required == required
    try:
        a = Attribute(isa=is_a, default=[], required=required)
        raise AssertionError('Attribute constructor should fail')
    except TypeError as e:
        assert e.args[0] == 'defaults for FieldAttribute may not be mutable, please provide a callable instead'
    # test class_type
    class_type = 'class_type'
    a = Attribute(isa='class', class_type=class_type)
    assert a.class_type == class_type
    # test listof


# Generated at 2022-06-21 00:04:36.650179
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute(isa='string')
    assert fa.isa == 'string'
    assert fa.private is False
    assert fa.default is None
    assert fa.required is False
    assert fa.listof is None
    assert fa.priority == 0
    assert fa.class_type is None
    assert fa.always_post_validate is False
    assert fa.inherit is True
    assert fa.alias is None



# Generated at 2022-06-21 00:04:41.930838
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute()
    a1.priority = 123
    a2 = Attribute()
    a2.priority = 123
    r1 = a1 > a2
    r2 = a2 > a1
    assert r1 == r2
    print("Test of method __gt__ of class Attribute is resolved")

test_Attribute___gt__()

# Generated at 2022-06-21 00:04:45.809909
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    try:
        assert isinstance(a1 <= a2, bool)
    except:
        assert False



# Generated at 2022-06-21 00:04:50.106846
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr_1 = Attribute(priority=10)
    attr_2 = Attribute(priority=5)
    assert attr_1.__gt__(attr_2) is True
    assert attr_2.__gt__(attr_1) is False


# Generated at 2022-06-21 00:05:01.449503
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from collections import namedtuple

    class X(object):
        x_attr = FieldAttribute(default='m', priority=1)

    x = X()
    x.x_attr = 1
    assert x.x_attr == 1

    x_attr = FieldAttribute(default='m', priority=1)

    assert x_attr >= X
    assert x_attr <= X
    assert x_attr != X
    assert x_attr != 1

    assert x_attr >= AnsibleBaseYAMLObject
    assert x_attr <= AnsibleBaseYAMLObject
    assert x_attr != AnsibleBaseYAMLObject
    assert x_attr != 1

    Point = namedtuple('Point', ['x', 'y'])
    p = Point

# Generated at 2022-06-21 00:05:03.900339
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=5)
    attr2 = Attribute(priority=1)
    assert attr1.__lt__(attr2) is True


# Generated at 2022-06-21 00:05:15.378588
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    Attribute1 = Attribute(priority=1)
    Attribute2 = Attribute(priority=2)
    Attribute3 = Attribute(priority=3)
    Attribute4 = Attribute(priority=4)
    Attribute5 = Attribute(priority=5)
    assert Attribute1 < Attribute2
    assert Attribute1 < Attribute3
    assert Attribute1 < Attribute4
    assert Attribute1 < Attribute5
    assert not Attribute2 < Attribute1
    assert Attribute2 < Attribute3
    assert Attribute2 < Attribute4
    assert Attribute2 < Attribute5
    assert not Attribute3 < Attribute1
    assert not Attribute3 < Attribute2
    assert Attribute3 < Attribute4
    assert Attribute3 < Attribute5
    assert not Attribute4 < Attribute1


# Generated at 2022-06-21 00:05:35.848241
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    first_attr = Attribute(priority = 2)
    second_attr = Attribute(priority = 1)
    third_attr = Attribute(priority = 0)
    assert(first_attr > second_attr)
    assert(first_attr > third_attr)
    assert(second_attr > third_attr)


# Generated at 2022-06-21 00:05:45.608388
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attr = FieldAttribute()
    assert field_attr.isa == None
    assert field_attr.private == False
    assert field_attr.default == None
    assert field_attr.required == False
    assert field_attr.listof == None
    assert field_attr.priority == 0
    assert field_attr.class_type == None
    assert field_attr.always_post_validate == False
    assert field_attr.inherit == True
    assert field_attr.alias == None
    assert field_attr.extend == False
    assert field_attr.prepend == False
    assert field_attr.static == False


# Generated at 2022-06-21 00:05:52.428492
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    """Check Attribute.__eq__() method
    Successfully instantiate two attributes object and check that __eq__()
    method works as expected"""
    # Instantiate two attributes attributes object
    attr1 = Attribute()
    attr2 = Attribute()
    # Make sure __eq__() method works as expected (same priority -> True)
    assert attr1.__eq__(attr2) is True
    # Change priority of attr2
    attr2.priority = 1
    # Make sure __eq__() method works as expected (different priority -> False)
    assert attr1.__eq__(attr2) is False


# Generated at 2022-06-21 00:06:01.890952
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    temp = FieldAttribute(
        isa=None,
        private=False,
        default=None,
        required=False,
        listof=None,
        priority=0,
        class_type=None,
        always_post_validate=False,
        inherit=True,
        alias=None,
        extend=False,
        prepend=False,
        static=False,
    )

    assert temp.__le__(temp)
    assert temp.__le__(Attribute(priority=0))
    assert not temp.__le__(Attribute(priority=1))


# Generated at 2022-06-21 00:06:13.615897
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():

    a1 = Attribute(priority=114)
    a2 = Attribute(priority=114)
    a3 = Attribute(priority=-1)
    a4 = Attribute(priority=-2)
    a5 = Attribute(priority=0)
    a6 = Attribute(priority=1)

    assert not a1.__gt__(a1)
    assert not a1.__gt__(a2)
    assert a1.__gt__(a3)
    assert a1.__gt__(a4)
    assert a1.__gt__(a5)
    assert a1.__gt__(a6)
    assert not a2.__gt__(a1)
    assert not a2.__gt__(a2)
    assert a2.__gt__(a3)
    assert a2.__

# Generated at 2022-06-21 00:06:16.870963
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)

    assert attr1 == attr2
    assert attr2 != attr3


# Generated at 2022-06-21 00:06:29.048677
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    x = FieldAttribute(isa='dict')
    assert x.isa == 'dict'
    assert x.private == False
    assert x.default == None
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None
    assert x.extend == False
    assert x.prepend == False
    assert x.static == False

    x = FieldAttribute(isa='dict', private=True, default=True, required=True, listof=True,
                       priority=1, always_post_validate=True, inherit=False, alias='test',
                       extend=True, prepend=True, static=True)

# Generated at 2022-06-21 00:06:29.975099
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    attr = Attribute(priority=0)
    assert attr == attr


# Generated at 2022-06-21 00:06:33.592587
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)

    assert a2.__gt__(a1) == True
    assert a1.__gt__(a2) == False


# Generated at 2022-06-21 00:06:36.049325
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute()
    b = Attribute()
    a.priority = 0
    b.priority = 10
    return a > b
assert test_Attribute___gt__()

# Generated at 2022-06-21 00:06:50.298161
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute()
    a1.priority = 1
    a2 = Attribute()
    a2.priority = 2
    print (a1.__le__(a2))


# Generated at 2022-06-21 00:06:52.571316
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=1)
    b = Attribute(priority=1)
    assert a == b



# Generated at 2022-06-21 00:07:01.275735
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    myF = FieldAttribute()
    assert myF.isa == None
    assert myF.private == False
    assert myF.default == None
    assert myF.required == False
    assert myF.listof == None
    assert myF.priority == 0
    assert myF.class_type == None
    assert myF.always_post_validate == False
    assert myF.inherit == True
    assert myF.alias == None
    assert myF.extend == False
    assert myF.prepend == False
    assert myF.static == False



# Generated at 2022-06-21 00:07:04.813525
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute()
    attr.priority = 1
    attr1 = Attribute()
    attr1.priority = 1
    assert attr != attr1



# Generated at 2022-06-21 00:07:08.967879
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute()
    a.priority = 10
    b = Attribute()
    b.priority = 11
    d = Attribute()
    d.priority = 10

    assert a == d
    assert not a == b
    assert a < b
    assert not a > b



# Generated at 2022-06-21 00:07:11.432551
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2



# Generated at 2022-06-21 00:07:16.682889
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__eq__(a1.default) is False
    assert a1.__eq__(a2) is False
    assert a2.__eq__(a1) is False
    assert a2.__eq__(a2) is True


# Generated at 2022-06-21 00:07:20.856519
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=0)
    b = Attribute(priority=1)
    c = Attribute(priority=2)
    d = Attribute(priority=3)
    assert b.__gt__(a) == True
    assert b.__gt__(b) == False
    assert d.__gt__(b) == True



# Generated at 2022-06-21 00:07:23.565940
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=5)
    b = Attribute(priority=6)
    assert a != b


# Generated at 2022-06-21 00:07:26.503129
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    assert Attribute().priority <= Attribute().priority
    assert Attribute().priority <= Attribute(priority=0).priority
    assert not Attribute().priority <= Attribute(priority=-1).priority


# Generated at 2022-06-21 00:07:54.712499
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=2)
    b = Attribute(priority=2)
    c = Attribute(priority=1)
    assert (a == b)
    assert not(a == c)
    assert not(b == c)


# Generated at 2022-06-21 00:08:05.380470
# Unit test for constructor of class Attribute
def test_Attribute():

    test_input = {'name': {'isa': 'str', 'private': False, 'default': None, 'required': True, 'listof': None}}
    expected_output = {'name': {'isa': 'str', 'private': False, 'default': None, 'required': True, 'listof': None}}
    test_object = Attribute(test_input['name']['isa'], test_input['name']['private'], test_input['name']['default'], test_input['name']['required'], test_input['name']['listof'])
    assert test_object.__dict__ == expected_output['name']
    assert test_object.__dict__['listof'] == None


# Generated at 2022-06-21 00:08:06.933917
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=0)
    assert(attr1 > attr2)


# Generated at 2022-06-21 00:08:07.891372
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(static=True)
    assert isinstance(attr, Attribute)

# Generated at 2022-06-21 00:08:15.237546
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    # create two Attribute instances
    attr1=Attribute(priority=1)
    attr2=Attribute(priority=2)

    # expect that greater method return True if two instances priority value compares greater than
    print("Expected that attr2 > attr1, and result is %s" % (attr2.__gt__(attr1)))
    print("Expected that attr1 < attr2, and result is %s" % (attr1.__lt__(attr2)))

test_Attribute___gt__()

# Generated at 2022-06-21 00:08:26.388161
# Unit test for constructor of class Attribute
def test_Attribute():

    attributes = ('isa', 'private', 'default', 'required', 'listof', 'priority', 'class_type',
                  'always_post_validate', 'inherit', 'alias', 'extend', 'prepend', 'static')

    # test Attribute constructor
    attribute = Attribute(isa='list',
                          private=False,
                          default=['1.1.1.10', '1.1.1.11'],
                          required=False,
                          listof=['str'],
                          priority=0,
                          class_type=None,
                          always_post_validate=False,
                          inherit=False,
                          alias=None,
                          extend=False,
                          prepend=False,
                          static=False)

    for name in attributes:
        assert attribute.__

# Generated at 2022-06-21 00:08:29.326309
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=3)
    b = Attribute(priority=3)
    c = Attribute(priority=1)
    assert a >= b
    assert a >= c
    assert not b > c


# Generated at 2022-06-21 00:08:37.523750
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute()
    a_list = [a.isa,a.private,a.default,a.required,a.listof,a.priority,a.class_type,a.always_post_validate,a.inherit,a.alias,a.extend,a.prepend,a.static]
    expected_list = [None,False,None,False,None,0,None,False,True,None,False,False,False]

    assert a_list == expected_list


# Generated at 2022-06-21 00:08:39.315894
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    fa = FieldAttribute()



# Generated at 2022-06-21 00:08:44.807352
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # TODO: fix the counter-example, or change the semantics of the method.
    # Normal operation
    a0 = Attribute(priority=5)
    a1 = Attribute(priority=5)
    assert a1 >= a0

    # Counter-example
    a0 = Attribute(priority=5)
    a1 = Attribute(priority=7)
    assert a1 >= a0


# Generated at 2022-06-21 00:09:35.611037
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=2)
    a2 = Attribute(priority=3)
    assert(a1.__ge__(a2) == False)
    assert(a2.__ge__(a1) == True)


# Generated at 2022-06-21 00:09:37.072771
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():

    attr2 = Attribute(priority=2)
    attr3 = Attribute(priority=3)

    assert attr2 != attr3


# Generated at 2022-06-21 00:09:39.415111
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=0)
    assert a.__le__(Attribute(priority=0)) is True
    assert a.__le__(Attribute(priority=1)) is True
    assert a.__le__(Attribute(priority=-1)) is False


# Generated at 2022-06-21 00:09:41.844317
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert (Attribute('test1') == Attribute('test2'))


# Generated at 2022-06-21 00:09:44.705745
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attribute_1 = Attribute(priority = 1)
    attribute_2 = Attribute(priority = 2)
    assert attribute_2 >= attribute_1


# Generated at 2022-06-21 00:09:47.383354
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=1)
    assert attr2.__ne__(attr1) == True


# Generated at 2022-06-21 00:09:50.904298
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    atr1 = Attribute(priority=1)
    atr2 = Attribute(priority=1)
    atr3 = Attribute(priority=2)
    assert atr1 == atr2
    assert atr1 != atr3



# Generated at 2022-06-21 00:09:53.384837
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2 < attr1


# Generated at 2022-06-21 00:09:54.566386
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    assert Attribute(priority=1) == Attribute(priority=1)


# Generated at 2022-06-21 00:09:59.566282
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    #Case 1:
    #Setting up the ne value
    a1 = Attribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    a2 = Attribute(isa='string', private=False, default=None, required=False, listof=None, priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False, prepend=False, static=False)
    assert(a1 != a2)

    #Case 2:
    #Setting up the ne value