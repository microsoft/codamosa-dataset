

# Generated at 2022-06-21 00:01:10.017171
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa='int')
    assert x.isa == 'int'
    y = Attribute(isa='int', default=42)
    assert y.default == 42
    assert x.default is None
    assert y.__class__ == Attribute
    assert y.alias is None

# Generated at 2022-06-21 00:01:19.981819
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='test',private=True,default='test',required=True,listof='test',priority=0,class_type='test',always_post_validate=False,inherit=True,alias='test')
    assert a.isa == 'test'
    assert a.private == True
    assert a.default == 'test'
    assert a.required == True
    assert a.listof == 'test'
    assert a.priority == 0
    assert a.class_type == 'test'
    assert a.always_post_validate == False
    assert a.inherit == True
    assert a.alias == 'test'
    

# Generated at 2022-06-21 00:01:22.709652
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr1 < attr2


# Generated at 2022-06-21 00:01:35.209130
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute()
    assert attr.isa is None
    assert attr.private is False
    assert attr.default is None
    assert attr.required is False
    assert attr.listof is None
    assert attr.priority == 0
    assert attr.class_type is None
    assert attr.always_post_validate is False
    assert attr.alias is None
    assert attr.extend is False
    assert attr.prepend is False
    assert attr.static is False


# Generated at 2022-06-21 00:01:37.929876
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=0)
    attr2 = Attribute(priority=0)
    assert attr1 >= attr2



# Generated at 2022-06-21 00:01:49.370628
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    '''
    This is a unit test for method __ne__ of class Attribute
    '''
    a = Attribute(isa='class', private=False, default=None, required=False, listof=None, priority=11, class_type=None, always_post_validate=None, inherit=None, alias=None, extend=None, prepend=None)
    b = Attribute(isa='class', private=False, default=None, required=False, listof=None, priority=22, class_type=None, always_post_validate=None, inherit=None, alias=None, extend=None, prepend=None)
    assert a.__ne__(b), '__ne__ #1 failed'
    assert not b.__ne__(a), '__ne__ #2 failed'
    return



# Generated at 2022-06-21 00:01:55.572594
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a =  Attribute()     
    b =  Attribute()

    a.priority = 1
    b.priority = 2

    if a > b:
        print(a, 'greater than', b)
    if a < b:
        print(a, 'less than', b) 
    if a == b:
        print(a, 'equal to', b)
    if b <= a:
        print(b, 'less than or equal to', a)




# Generated at 2022-06-21 00:02:07.834564
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    a1 = Attribute(isa='test',private=False,default=None,required=False,listof=None,priority=1,class_type=None,always_post_validate=False,inherit=True,alias=None,extend=False,prepend=False,static=False)
    a2 = Attribute(isa='test',private=False,default=None,required=False,listof=None,priority=1,class_type=None,always_post_validate=False,inherit=True,alias=None,extend=False,prepend=False,static=False)

# Generated at 2022-06-21 00:02:10.024382
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    assert a1 == a2


# Generated at 2022-06-21 00:02:11.182730
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr = Attribute(priority=0)
    attr2 = Attribute(priority=10)
    assert attr != attr2

# Generated at 2022-06-21 00:02:17.736536
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        a = Attribute(default=['a', 'b'], isa='list')
    except Exception as e:
        if str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead':
            pass
        else:
            raise Exception("Unexpected exception {}".format(e))

# Generated at 2022-06-21 00:02:27.318459
# Unit test for constructor of class Attribute
def test_Attribute():
    args = {
        'isa': None,
        'private': False,
        'default': None,
        'required': False,
        'listof': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    a = Attribute(**args)
    for key in args.keys():
        assert getattr(a, key) == args[key]

# Generated at 2022-06-21 00:02:29.493445
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    class TestAttribute():
        priority = 1

    a = Attribute()

    assert a >= TestAttribute()


# Generated at 2022-06-21 00:02:31.584994
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 0)
    b = Attribute(priority = 10)
    return a >= b

# Generated at 2022-06-21 00:02:37.311498
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_obj_1 = Attribute()
    attr_obj_1.priority = 1
    attr_obj_2 = Attribute()
    attr_obj_2.priority = 2
    assert attr_obj_1.__ne__(attr_obj_2) == True
    attr_obj_2.priority = 1
    assert attr_obj_1.__ne__(attr_obj_2) == False

# Generated at 2022-06-21 00:02:41.856894
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=2)
    c.__le__(b)
    a.__le__(b)
    b.__le__(a)


# Generated at 2022-06-21 00:02:45.650692
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    f1 = FieldAttribute(priority=0)
    f2 = FieldAttribute(priority=1)
    assert f1.__ge__(f2) is True
    assert f2.__ge__(f1) is False


# Generated at 2022-06-21 00:02:53.575783
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():

    assert Attribute(priority=4) <= Attribute(priority=4), "Attribute with priority=4 should be less or equal to itself."
    assert Attribute(priority=4) <= Attribute(priority=5), "Attribute with priority=4 should be less or equal to an attribute with priority=5."
    assert not Attribute(priority=5) <= Attribute(priority=4), "Attribute with priority=5 should not be less or equal to an attribute with priority=4."

    print("OK")

test_Attribute___le__()

# Generated at 2022-06-21 00:02:56.183181
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    if Attribute(priority=0) != Attribute(priority=1):
        raise ValueError("Attribute.__ne__ failed")


# Generated at 2022-06-21 00:02:59.302932
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    p1 = FieldAttribute(isa='int', default=1)
    if p1.isa != 'int':
        raise Exception('isa is not int')
    if p1.default != 1:
        raise Exception('default is not 1')



# Generated at 2022-06-21 00:03:05.490914
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b


# Generated at 2022-06-21 00:03:08.173634
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    assert attr2.__ge__(attr1)

# Generated at 2022-06-21 00:03:11.267703
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()

    assert a1 == a2
    assert a2 == a1


# Generated at 2022-06-21 00:03:13.784281
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a = Attribute(priority=0)
    b = Attribute(priority=0)
    assert(a == b)



# Generated at 2022-06-21 00:03:15.853226
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    x = Attribute(alias='wwww')
    y = Attribute(alias='yyyy')
    assert((x >= y) == True)


# Generated at 2022-06-21 00:03:18.841629
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute()
    a2 = Attribute()
    a3 = Attribute(priority=3)
    assert a1 == a2
    assert not (a1 == a3)
    assert not (a2 == a3)


# Generated at 2022-06-21 00:03:21.786069
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert(Attribute(priority=0) < Attribute(priority=1))
    assert(Attribute(priority=1) > Attribute(priority=0))

# Generated at 2022-06-21 00:03:26.543816
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr_1_ne = Attribute(priority=1)
    attr_2_ne = Attribute(priority=2)
    assert id(attr_1_ne) != id(attr_2_ne)
    assert attr_1_ne != attr_2_ne


# Generated at 2022-06-21 00:03:33.005331
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    # example 1, create an empty field
    f1 = Attribute()

    # example 2, create a field with all possible attributes
    f2 = FieldAttribute(isa='dict', listof='string', private='True', default='value', required='True', priority=1, class_type='class', always_post_validate='True', inherit='True', alias='alias', extend='True', prepend='True')


# Generated at 2022-06-21 00:03:35.795076
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) > Attribute(priority=2)
    assert Attribute(priority=2) < Attribute(priority=1)


# Generated at 2022-06-21 00:03:51.692192
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():

    a = FieldAttribute()
    assert a.private is False, \
        "private should be False by default"

    a = FieldAttribute(private=True)
    assert a.private is True, \
        "private should be True"

    a = FieldAttribute(default=5)
    assert a.default == 5, \
        "default should be five"

    a = FieldAttribute(listof=5)
    assert a.listof == 5, \
        "listof should be five"

    a = FieldAttribute(priority=7)
    assert a.priority == 7, \
        "priority should be seven"

    a = FieldAttribute(class_type=7)
    assert a.class_type == 7, \
        "class_type should be seven"

    a = FieldAttribute(always_post_validate=True)

# Generated at 2022-06-21 00:03:55.296308
# Unit test for constructor of class Attribute
def test_Attribute():
    '''
    Unit test for constructor of class Attribute
    '''
    a = Attribute()
    assert a.isa is None
    assert a.private is False
    assert a.default is None
    assert a.required is False
    assert a.listof is None
    assert a.priority == 0
    assert a.class_type is None
    assert a.always_post_validate is False
    assert a.inherit is True
    assert a.alias is None


# Generated at 2022-06-21 00:03:57.349448
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    # Test set up
    a = Attribute()
    b = Attribute()

    # Test execution
    assert (a >= b) == (b <= a)


# Generated at 2022-06-21 00:04:00.518829
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', required=True, default=[1])
    assert a.isa == 'list'
    assert a.required == True
    assert a.default == [1]



# Generated at 2022-06-21 00:04:04.086495
# Unit test for constructor of class Attribute
def test_Attribute():
    try:
        Attribute(default='test')
    except TypeError as e:
        assert(str(e) == 'defaults for FieldAttribute may not be mutable, please provide a callable instead')
    else:
        assert(False)
    Attribute(default=lambda: 'test')


# Generated at 2022-06-21 00:04:04.885916
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    pass


# Generated at 2022-06-21 00:04:16.825979
# Unit test for constructor of class Attribute
def test_Attribute():
    x = Attribute(isa="foo")
    assert x.isa == "foo"
    assert x.private == False
    assert x.default == None
    assert x.required == False
    assert x.listof == None
    assert x.priority == 0
    assert x.class_type == None
    assert x.always_post_validate == False
    assert x.inherit == True
    assert x.alias == None
    assert x.extend == False
    assert x.prepend == False
    assert x.static == False
    Attribute(isa="foo", default=2)
    Attribute(isa="foo", required=True)
    Attribute(isa="foo", listof="foo")
    Attribute(isa="foo", priority=2)
    Attribute(isa="foo", class_type=None)
    Att

# Generated at 2022-06-21 00:04:22.337153
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attr1 = Attribute()
    attr2 = Attribute()
    assert attr1 == attr2
    attr2.priority = 1
    assert attr1 != attr2


# for variable names which are reserved in Python
# for example, 'pass' is a reserved word and therefore cannot be used as
# an attribute name in Python

# Generated at 2022-06-21 00:04:25.163318
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field = FieldAttribute(isa=int, alias="some_alias")
    assert field.alias == "some_alias"


# Generated at 2022-06-21 00:04:32.301281
# Unit test for constructor of class Attribute
def test_Attribute():

    # test custom class object
    class SimpleClass():
        pass
    attr = Attribute(isa='class', class_type=SimpleClass)
    assert isinstance(attr, Attribute)

    # test list object
    attr = Attribute(isa='list', listof='string')
    assert isinstance(attr, Attribute)

    # test with default as a string
    attr = Attribute(isa='string', default='ciao')
    assert isinstance(attr, Attribute)
    assert getattr(attr, 'default') == 'ciao'

    # test with default as a callable
    attr = Attribute(isa='string', default=lambda: 'world')
    assert isinstance(attr, Attribute)
    assert getattr(attr, 'default')() == 'world'

# Generated at 2022-06-21 00:04:44.199035
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    from __main__ import Attribute
    from pytest import raises
    a = Attribute()
    b = Attribute()
    with raises(Exception) as excinfo:
        a.__ne__(b)
    assert 'object has no attribute' in str(excinfo.value)


# Generated at 2022-06-21 00:04:46.699536
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    assert Attribute.__ne__(Attribute(), Attribute(priority=1)) is True


# Generated at 2022-06-21 00:04:50.106984
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    first_attr = Attribute(priority=5)
    second_attr = Attribute(priority=6)
    assert first_attr < second_attr
    assert not second_attr < first_attr



# Generated at 2022-06-21 00:04:52.735901
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 <= a2


# Generated at 2022-06-21 00:04:57.064171
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1 < a2

    a1 = Attribute(priority=1)
    a2 = Attribute(priority=1)
    assert a1 >= a2



# Generated at 2022-06-21 00:05:01.403565
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    print('Testing method __le__ of class Attribute')
    a = Attribute(priority=1)
    b = Attribute(priority=10)
    if a.__le__(b):
        print('test method __le__ success')
    else:
        print('test method __le__ failed')


# Generated at 2022-06-21 00:05:02.762713
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    field_attribute = FieldAttribute()
    assert field_attribute


# Generated at 2022-06-21 00:05:04.067293
# Unit test for constructor of class Attribute
def test_Attribute():
    attr_obj = Attribute()
    assert isinstance(attr_obj, Attribute)

# Generated at 2022-06-21 00:05:08.882063
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():

    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert(a.__ge__(b) is False)
    assert(b.__ge__(a) is True)
    assert(a.__ge__(a) is True)



# Generated at 2022-06-21 00:05:19.397312
# Unit test for constructor of class Attribute
def test_Attribute():
    base_attrs = {
        'isa': 'dict',
        'private': False,
        'default': None,
        'required': False,
        'listof': None,
        'priority': 0,
        'class_type': None,
        'always_post_validate': False,
        'inherit': True,
        'alias': None,
        'extend': False,
        'prepend': False,
        'static': False,
    }
    attr = Attribute()
    assert attr.__dict__ == base_attrs


# Generated at 2022-06-21 00:05:34.737553
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    attribute1 = Attribute(priority=1)
    attribute2 = Attribute(priority=2)

    assert attribute1 != attribute2


# Generated at 2022-06-21 00:05:37.237643
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=0) < Attribute(priority=1)
    assert not Attribute(priority=1) < Attribute(priority=0)

# Generated at 2022-06-21 00:05:38.564722
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert FieldAttribute() == FieldAttribute()



# Generated at 2022-06-21 00:05:44.299103
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    assert Attribute.__gt__(Attribute(priority = 2), Attribute(priority = 1)) == True
    assert Attribute.__gt__(Attribute(priority = 1), Attribute(priority = 2)) == False
    assert Attribute.__gt__(Attribute(priority = 1), Attribute(priority = 1)) == False


# Generated at 2022-06-21 00:05:49.942557
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    # Test the case where the two priorities are the same
    a = Attribute (private=False, priority=1)
    b = Attribute (private=True, priority=1)
    assert (a != b)
    # Test the case where the two priorities are different
    a = Attribute (private=True, priority=2)
    b = Attribute (private=True, priority=1)
    assert (a != b)



# Generated at 2022-06-21 00:05:53.568928
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    c = Attribute(priority=3)
    return (a<=b, a<=c, b<=c)

# Generated at 2022-06-21 00:05:55.124004
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    a = FieldAttribute('Test')
    assert a.isa == 'Test'

# Generated at 2022-06-21 00:05:58.115406
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a1 = Attribute(priority=28)
    a2 = Attribute(priority=16)
    assert a1 > a2



# Generated at 2022-06-21 00:06:00.386207
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a1 = Attribute(priority=10)
    a2 = Attribute(priority=10)
    assert a1 >= a2


# Generated at 2022-06-21 00:06:02.037270
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    assert type(FieldAttribute(isa="dict")) is FieldAttribute



# Generated at 2022-06-21 00:06:31.564388
# Unit test for method __eq__ of class Attribute
def test_Attribute___eq__():
    a1 = Attribute(isa='String', default='test')
    a2 = Attribute(isa='String', default='test')
    assert(a1 == a2)



# Generated at 2022-06-21 00:06:38.990306
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    assert Attribute(priority=1) > Attribute(priority=2)
    assert Attribute(priority=2) < Attribute(priority=1)
    assert Attribute(priority=1) >= Attribute(priority=1)
    assert Attribute(priority=2) <= Attribute(priority=2)
    assert Attribute(priority=1) < Attribute(priority=2)
    assert Attribute(priority=1) <= Attribute(priority=2)
    assert Attribute(priority=2) > Attribute(priority=1)
    assert Attribute(priority=2) >= Attribute(priority=1)



# Generated at 2022-06-21 00:06:51.482169
# Unit test for constructor of class Attribute
def test_Attribute():
    a = Attribute(isa='list', private=False, default=None, required=False, listof=None, priority=0,
                  class_type=None, always_post_validate=False, inherit=True, alias=None, extend=False,
                  prepend=False, static=False)
    assert a.isa == 'list', a.isa
    assert a.private == False, a.private
    assert a.default == None, a.default
    assert a.required == False, a.required
    assert a.listof == None, a.listof
    assert a.priority == 0, a.priority
    assert a.class_type == None, a.class_type
    assert a.always_post_validate == False, a.always_post_validate
    assert a.inherit == True, a.inher

# Generated at 2022-06-21 00:06:57.303477
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    attr1 = Attribute(priority=1)
    attr2 = Attribute(priority=2)
    if not attr1 < attr2:
        raise AssertionError
    if not attr1 <= attr2:
        raise AssertionError
    if attr1 >= attr2:
        raise AssertionError
    if attr1 > attr2:
        raise AssertionError


# Generated at 2022-06-21 00:07:01.935675
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    attr1 = Attribute()
    attr1.priority = 1
    attr2 = Attribute()
    attr2.priority = 2
    # attr1 has a lower priority than attr2
    assert attr2.__ge__(attr1)

# Generated at 2022-06-21 00:07:06.187761
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a1 = Attribute(priority=1)
    a2 = Attribute(priority=2)
    assert a1.__le__(a2)
    assert not a1.__le__(a1)
    assert not a2.__le__(a1)



# Generated at 2022-06-21 00:07:11.751041
# Unit test for method __lt__ of class Attribute
def test_Attribute___lt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a < b
    assert not a > b
    assert not a == b
    assert not a >= b
    assert a <= b
    assert not b < a
    assert b > a
    assert not b == a
    assert b >= a
    assert not b <= a



# Generated at 2022-06-21 00:07:14.663025
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    x = Attribute(priority=1)
    y = Attribute(priority=2)
    assert x <= y
    assert y >= x
    assert x != y


# Generated at 2022-06-21 00:07:23.713282
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    class Temp(object):
        def __init__(self, value):
            self.value = value

        def __ne__(self, other):
            print("Temp.__ne__ called")
            return False

    class Temp2(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            print("Temp2.__eq__ called")
            return False

    a = Attribute(priority=1)
    b = Attribute(priority=1)

    assert a != b

    aa = Temp(value=1)
    assert aa != b

    bb = Temp2(value=1)
    assert not aa == bb


# Generated at 2022-06-21 00:07:27.702761
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority = 5)
    b = Attribute(priority = 6)
    if a.__ge__(b):
        raise Exception("__ge__(self, other) failed. %s is greater than %s." % (b, a))


# Generated at 2022-06-21 00:08:30.734766
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    """
    Test that Attribute.__le__() correctly compares two Attributes
    """

    # Test for equality
    a = Attribute(1, priority=0)
    b = Attribute(1, priority=0)
    assert a <= b


    # Test for higher priority number
    a = Attribute(1, priority=0)
    b = Attribute(1, priority=1)
    assert a <= b

    # Test for lower priority number
    a = Attribute(1, priority=1)
    b = Attribute(1, priority=0)
    assert not a <= b



# Generated at 2022-06-21 00:08:42.713606
# Unit test for constructor of class Attribute
def test_Attribute():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.attribute import FieldAttribute
    # FIXME: use a real test in unit tests
    def dv1():
        return 42

    def dv2():
        return {}

    def dv3():
        return []

    attr1 = Attribute(isa='str', default='foobar')
    attr2 = Attribute(isa='dict', default=dv2)
    attr3 = Attribute(isa='list', default=dv3)
    attr4 = Attribute(isa='list', default=42)

    # test attribute
    assert attr1.isa == 'str'
    assert attr1.default == 'foobar'
    assert attr1.private == False
    assert attr1.required == False
    assert attr

# Generated at 2022-06-21 00:08:46.072525
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    a = Attribute(priority=1)
    b = Attribute(priority=2)
    assert a.__gt__(b) == True


# Generated at 2022-06-21 00:08:54.516054
# Unit test for method __gt__ of class Attribute
def test_Attribute___gt__():
    """
    Unit test for method __gt__ of class Attribute
    """
    high_p_attr = Attribute(priority=100)
    low_p_attr = Attribute(priority= -100)
    assert high_p_attr > low_p_attr
    assert low_p_attr < high_p_attr
    high_p_attr = Attribute(priority=0)
    assert not high_p_attr > low_p_attr
    assert not low_p_attr < high_p_attr


# Generated at 2022-06-21 00:08:56.835330
# Unit test for method __ge__ of class Attribute
def test_Attribute___ge__():
    a = Attribute(priority=2)
    b = Attribute(priority=3)
    assert a.__ge__(b) == False

# Generated at 2022-06-21 00:08:58.753936
# Unit test for method __le__ of class Attribute
def test_Attribute___le__():
    a = Attribute()
    b = Attribute()

    a.priority = 1
    b.priority = 2

    assert a <= b


# Generated at 2022-06-21 00:09:07.831908
# Unit test for constructor of class FieldAttribute
def test_FieldAttribute():
    def test_list_default():
        field = FieldAttribute(default = [])
        assert field.default == []
    def test_dict_default():
        field = FieldAttribute(default = {})
        assert field.default == {}
    def test_set_default():
        field = FieldAttribute(default = set())
        assert field.default == set()
    def test_nested_default():
        field = FieldAttribute(default = {'k1' : [1,2,3]})
        assert field.default == {'k1' : [1,2,3]}

# Generated at 2022-06-21 00:09:19.108460
# Unit test for constructor of class Attribute
def test_Attribute():
    attr = Attribute(
        isa=bool,
        private=False,
        default=True,
        required=False,
        listof=str,
        priority=0,
        class_type=str,
        always_post_validate=False,
        inherit=True,
        alias='test_alias',
        extend=False,
        prepend=False,
        static=False
    )
    assert attr.isa is bool
    assert not attr.private
    assert attr.default is True
    assert not attr.required
    assert attr.listof is str
    assert attr.priority == 0
    assert attr.class_type is str
    assert not attr.always_post_validate
    assert attr.inherit
    assert attr.alias == 'test_alias'


# Generated at 2022-06-21 00:09:27.089314
# Unit test for method __ne__ of class Attribute
def test_Attribute___ne__():
    field = Attribute(isa='str', private=True, default=None, required=True, listof=None,
                      priority=0, class_type=None, always_post_validate=False, inherit=True, alias=None,
                      extend=False, prepend=False, static=True)

    post_validated_defaults = {'isa': 'str', 'private': False, 'default': None, 'required': False, 'listof': None,
                               'priority': 0, 'class_type': None, 'always_post_validate': False,
                               'inherit': True, 'alias': None, 'extend': False, 'prepend': False, 'static': True}

    field2 = Attribute(**post_validated_defaults)


# Generated at 2022-06-21 00:09:35.611204
# Unit test for constructor of class Attribute
def test_Attribute():
    kwargs = dict(isa='some',
                  private=True,
                  default='some',
                  required=False,
                  listof='some',
                  priority=0,
                  class_type='some',
                  always_post_validate=False,
                  inherit=True,
                  alias='some',
                  extend=False,
                  prepend=False,
                  static=False
                  )

    obj = Attribute(**kwargs)

    for k, v in kwargs.items():
        assert getattr(obj, k) == v

