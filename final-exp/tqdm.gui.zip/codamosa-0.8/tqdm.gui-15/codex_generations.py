

# Generated at 2022-06-12 14:58:21.675001
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        mpl = plt = None
        import sys
        print("Matplotlib is not installed! -> skip tqdm_gui testing")
        sys.exit(0)

    from .gui import tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.display()
            pbar.update()
    # return pbar


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-12 14:58:30.544603
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Unit test for method display of class tqdm_gui"""
    from unittest import TestCase

    class tqdm_gui_display(TestCase):
        def setUp(self):  # noqa
            self.xdata = []
            self.ydata = []
            self.zdata = []

        def test_none_total(self):
            from time import time

            a = tqdm_gui('')
            b = time()
            a.n = 100
            a.last_print_n = 50
            a.start_t = time() - 20
            a.last_print_t = time() - 11
            a.start_t = b
            a.total = None
            a.xdata = self.xdata
            a.ydata = self.ydata


# Generated at 2022-06-12 14:58:33.827505
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    total = 100
    # import matplotlib
    # gui = tqdm_gui(total=total, gui=True, leave=False, disable=False)
    gui = tqdm_gui(total=total, gui=True, leave=False)
    for x in gui:
        time.sleep(0.1)
    gui.close()

# Generated at 2022-06-12 14:58:38.785800
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    toolbar = mpl.rcParams['toolbar']
    wasinteractive = plt.isinteractive()
    t = tqdm_gui(range(10))
    assert (t.mpl.rcParams['toolbar'] == 'None')
    assert (not plt.isinteractive())
    t.close()
    assert (mpl.rcParams['toolbar'] == toolbar)
    assert (plt.isinteractive() == wasinteractive)

# Generated at 2022-06-12 14:58:42.307546
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    >>> with tqdm_gui(total=10) as t:
    ...    for i in range(10):
    ...        t.update()
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 14:58:49.173855
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for the constructor of class tqdm_gui
    """
    import time
    from tqdm.gui import tqdm as tqdm_gui, trange
    from .std import TqdmDeprecationWarning

    pbar = tqdm_gui(4)
    for i in range(4):
        pbar.update(1)
        time.sleep(0.5)
    pbar.close()
    warn("Using tqdm.gui.tqdm() is deprecated, use tqdm.gui.tqdm_gui() instead!",
         TqdmDeprecationWarning, stacklevel=2)

    with tqdm_gui(total=5) as pbar:
        for i in range(5):
            pbar.update(1)
            time.sleep(0.5)



# Generated at 2022-06-12 14:58:57.543229
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    # use first instance of tqdm
    t = tqdm(range(10))
    for i in t:
        sleep(0.01)
    t.close()
    # use second instance of tqdm
    # and check that closing doesn't affect first instance
    t = tqdm(range(10))
    for i in t:
        sleep(0.01)
    # Test that instance removal works
    assert t._instances.count(t) == 1
    t.close()
    print("tqdm_gui method close passed")


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-12 14:59:07.671585
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test class tqdm_gui with matplotlib"""
    from time import sleep
    from numpy import random
    # Set non-interactive backend
    import matplotlib as mpl
    mpl.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    try:
        plt.rcParams["savefig.bbox"] = "tight"
    except KeyError:
        pass

    try:
        plt.rcParams["savefig.pad_inches"] = 0
    except KeyError:
        pass

    try:
        plt.rcParams["savefig.transparent"] = True
    except KeyError:
        pass

    # Save images in document folder

# Generated at 2022-06-12 14:59:11.887329
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=5) as pbar:
        try:
            assert(not pbar.disable)
            pbar.clear()
        except AttributeError:
            assert(0)
    assert(pbar.disable)

if __name__ == '__main__':
    test_tqdm_gui_clear()  # pragma: no cover

# Generated at 2022-06-12 14:59:15.419968
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import time

    with tqdm_gui(total=3) as pbar:
        for i in range(3):
            pbar.update()
            time.sleep(1)
    input('press any key to exit')  # noqa


if __name__ == "__main__":
    test_tqdm_gui_display()