

# Generated at 2022-06-12 14:58:35.716511
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from doctest import run_docstring_examples
    from time import sleep  # NOQA
    from .gui import tqdm
    from .utils import _term_move_up

    _range = xrange if str is bytes else range

    class tqdm_gui_test(tqdm):
        def __init__(self, *args, **kwargs):  # NOQA
            self.lastlen = 0
            super(tqdm_gui_test, self).__init__(*args, **kwargs)

        def display(self, *args, **kwargs):  # NOQA
            super(tqdm_gui_test, self).display(*args, **kwargs)
            # emulate time.sleep

# Generated at 2022-06-12 14:58:39.755005
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time

    tbar = tqdm_gui(total=100)
    for i in tbar:
        time.sleep(0.1)
        tbar.set_description("text: {0}".format(i + 1))
        tbar.update()
    tbar.close()

# Generated at 2022-06-12 14:58:42.554075
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import numpy as np
        a = np.array([1, 2, 3])
        t = tqdm_gui(a)
    except:
        pass
    t.close()

# Generated at 2022-06-12 14:58:50.777186
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        import matplotlib.pyplot as plt
        assert plt.get_backend().lower() != 'template'
    except ImportError:
        return
    with tqdm_gui(total=100) as t:
        for i in range(10):
            t.update()
            plt.pause(0.01)
        t.n = 5
        t.refresh()
        plt.pause(0.01)
        t.close()

# Generated at 2022-06-12 14:58:58.310902
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()
    plt.ion()
    ax.set_title('test')
    fig.canvas.draw()
    toolbar = plt.rcParams['toolbar']
    wasion = plt.isinteractive()
    t = tqdm_gui(total=3)
    assert plt.rcParams['toolbar'] == 'None'
    t.close()
    assert plt.rcParams['toolbar'] == toolbar
    if not wasion:
        assert not plt.isinteractive()

# Generated at 2022-06-12 14:59:02.367670
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # test that clear on GUI does nothing
    try:
        with tgrange(1) as t:
            t.update()
            t.clear()
    except Exception as e:
        raise e
    # test that clear on stdout works
    try:
        with tgrange(1) as t:
            t.update()
            t.clear(nolock=True)
    except Exception as e:
        raise e

# Generated at 2022-06-12 14:59:04.920695
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    t = tqdm_gui(total=100, gui=True)
    for i in t:
        t.display()
        sleep(0.01)
        pass

# Generated at 2022-06-12 14:59:11.424012
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    import matplotlib.pyplot as plt

    # Simulate a not interactive environment
    plt.ioff()
    # Create a figure
    fig = plt.figure(figsize=(2, 2))
    # Hide the toolbar
    plt.rcParams['toolbar'] = 'None'

    # Create tqdm
    t = tqdm(total=4, desc="Test", leave=True, disable=False)

    # Simulate an interactive environment
    plt.ion()

    # Simulate an external environment toolbars
    plt.rcParams['toolbar'] = 'toolbar'

    # Close tqdm
    t.close()

    # Check the figure is still here
    assert(fig.number)

    # Check we are in interactive mode
    assert(plt.isinteractive())

# Generated at 2022-06-12 14:59:16.585352
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test tqdm_gui.display"""
    from time import sleep
    from matplotlib.figure import Figure
    t = tqdm_gui(total=101, unit_scale=False)
    test = t.display()
    assert test is None, test
    sleep(1)
    assert type(t.fig) is Figure, type(t.fig)
    assert t.fig.axes, t.fig.axes
    t.close()

# Generated at 2022-06-12 14:59:19.774870
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    def test():
        for i in tqdm(range(1000)):
            yield i
            i += 1
    tqdm.disable = True
    for i in test():
        pass