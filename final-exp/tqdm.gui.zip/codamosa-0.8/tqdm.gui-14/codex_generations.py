

# Generated at 2022-06-12 14:58:28.763835
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui method clear."""
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except Exception:
        warn("Test of method clear of class tqdm_gui skipped (missing matplotlib).", TqdmExperimentalWarning, stacklevel=2)
        return
    ax = plt.subplot()
    ax.plot(range(100))
    with tqdm_gui(total=100) as pbar:
        for i in pbar:
            pass
        pbar.clear()
        for i in pbar:
            pass
    plt.close("all")

# Generated at 2022-06-12 14:58:35.622158
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    def int2str():
        return ''.join(str(i) for i in range(10000))
    import time
    import sys
    try:
        import numpy as np
        if not np.get_printoptions()['edgeitems']:
            np.set_printoptions(edgeitems=4, threshold=4)
    except ImportError:
        pass
    # Test:
    # - with iterable
    # - with no `total`
    # - totally unordered
    # - with `leave=True`
    # - with manual `close`
    # - with exception
    # - with nested bar
    # - without `total`
    for total in [100, None]:
        for unit_scale in [False, True]:
            unit = ("B", "KB") if unit_scale else ("", "K")
            x

# Generated at 2022-06-12 14:58:44.768460
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import OrderedDict
    from time import sleep

    for n in enumerate(tqdm(range(5), unit='it', total=5)):
        sleep(0.05)

    for n in enumerate(tqdm(range(20), unit='it', total=20, desc='foo')):
        sleep(0.05)

    for n in enumerate(tqdm(range(10), unit='it', total=10, position=0)):
        sleep(0.05)

    for n in enumerate(tqdm(range(10), unit='it', total=10, position=1)):
        sleep(0.05)

    # Test named-column mode
    l = []

# Generated at 2022-06-12 14:58:46.317764
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    x = tqdm_gui(total=100, leave=True)
    plt.close()
    assert x.mininterval == 0.5
    assert x.gui

# Generated at 2022-06-12 14:58:47.758039
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            t.update()


test_tqdm_gui()

# Generated at 2022-06-12 14:58:55.972037
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test optional gui decorator on `range` with `pandas.DataFrame` as unit"""
    import pandas
    from time import sleep
    # import pandas as pd
    # pd.DataFrame(range(10)).to_csv(tqdm(range(10), unit="pandas.DataFrame"))
    with tqdm(pandas.DataFrame(range(10)), unit="pandas.DataFrame") as t:
        for i in t:
            sleep(0.1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:56.837191
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    x = tqdm_gui(range(10))
    x.close()
    x.clear()

# Generated at 2022-06-12 14:58:58.545994
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    from time import sleep
    progress = tqdm(total=1000, unit_scale=1)
    for i in range(1000):
        progress.update()
        sleep(0.01)
    progress.close()
    return True

# Generated at 2022-06-12 14:59:02.588158
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test tqdm_gui display method"""
    t = tqdm_gui(10)
    t.display()
    t.format_dict['bar_format'] = 'bar'
    t.display()



# Generated at 2022-06-12 14:59:12.034199
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    >>> t = tqdm_gui(["a", "b", "c"])
    >>> next(t)
    'a'
    >>> next(t)
    'b'
    >>> t.last_print_n
    2
    >>> t.n
    2
    >>> t.close()

    >>> # Test with `range` function (non-xrange)
    >>> t = tqdm_gui(range(3))
    >>> next(t)
    0
    >>> next(t)
    1
    >>> next(t)
    2
    >>> t.close()
    """

