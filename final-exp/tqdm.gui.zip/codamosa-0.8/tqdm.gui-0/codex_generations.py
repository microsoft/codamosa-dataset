

# Generated at 2022-06-12 14:58:26.793552
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        tqdm_gui(total=10).clear()
    except Exception:
        raise Exception("Method clear failed")

# Generated at 2022-06-12 14:58:27.290417
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tgrange(10)

# Generated at 2022-06-12 14:58:31.689374
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from multiprocessing import Process
    from tqdm import tqdm

    def target_func(i):
        for j in tqdm(range(50), desc='Process %d' % i, leave=False):
            sleep(0.02)
        print('process %d is finished' % i)

    workers = []
    for i in range(3):
        process = Process(
            target=target_func, args=(i, )
        )
        workers.append(process)
    for w in workers:
        w.start()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-12 14:58:40.939601
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # pylint: disable=protected-access
    import numpy as np
    from .utils import PretendModule

    module = PretendModule()
    module._instances = []
    module.__dict__.update(locals())
    t = tqdm_gui(total=100, unit='it')
    t._time = lambda: 10
    t.start_t = 0
    t.last_print_t = 0
    t.last_print_n = 0

    # Test initialization
    assert isinstance(t.plt, PretendModule)
    assert isinstance(t.fig, PretendModule)
    assert isinstance(t.ax, PretendModule)
    assert isinstance(t.line1, PretendModule)
    assert isinstance(t.line2, PretendModule)

# Generated at 2022-06-12 14:58:46.225594
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm as std_tqdm
    from .std import TqdmExperimentalWarning as std_TqdmExperimentalWarning

    with std_tqdm(total=1, mininterval=0, miniters=None) as t:
        assert isinstance(t.__iter__(), std_tqdm)
        assert t.gui is False
        assert t.mininterval == 0
        assert t.miniters == 0

    with std_tqdm(total=1, mininterval=0, miniters=None, gui=False) as t:
        assert isinstance(t.__iter__(), std_tqdm)
        assert t.gui is False
        assert t.mininterval == 0
        assert t.miniters == 0


# Generated at 2022-06-12 14:58:57.201212
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method _repr_html_ of class tqdm
    """

    def trace_close():
        """Function that traces the calls to tqdm_gui.close"""
        tqdm_gui.close_called = False
        def _run_close(*args, **kwargs):
            """Internal function that mimics the behavior of tqdm_gui.close"""
            tqdm_gui.close_called = True
            return super(tqdm_gui, tqdm_gui).close(*args, **kwargs)
        return _run_close

    tqdm_gui.close = trace_close()
    tqdm_gui.close_called = False
    tqdm_gui.disable = False
    tqdm_gui.total = True
    tqdm_gui.leave = True
   

# Generated at 2022-06-12 14:58:59.265823
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for _ in tqdm_gui(range(100), "Testing tqdm_gui", ascii=True):
        sleep(0.01)

# Generated at 2022-06-12 14:59:06.810563
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=10)
    t.update(3)
    assert t.n == 3
    t.close()
    # should not throw
    t.update(4)


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in trange(10):
        sleep(0.1)
    for i in tqdm(["a", "b", "c", "d"]):
        sleep(0.1)
    for i in tqdm_gui(["a", "b", "c", "d"], ascii=True):
        sleep(0.1)
    print('done')

# Generated at 2022-06-12 14:59:16.159008
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt

        # Remember if external environment uses toolbars
        toolbar = mpl.rcParams['toolbar']

        # Remember if external environment is interactive
        wasion = plt.isinteractive()

        # Adding empty tqdm_gui instance
        from .gui import tqdm_gui
        t = tqdm_gui()

        # Closing tqdm_gui instance
        t.close()

        # Check that toolbar is restored
        assert toolbar == mpl.rcParams['toolbar']

        # Check that non-interactive mode is restored
        assert wasion == plt.isinteractive()
    except ImportError:
        warn('tqdm.gui not available - skipping gui.tqdm.test()')

# Generated at 2022-06-12 14:59:23.730469
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import time
    import warnings
    warnings.filterwarnings('ignore', category=TqdmExperimentalWarning)
    try:
        t = tqdm_gui(total=10)
        t.close()
        plt.close(t.fig)
    except Exception as e:
        print(str(e))
        raise e
    finally:
        plt.ioff()
        plt.show()
        time.sleep(3)

# Generated at 2022-06-12 14:59:45.035592
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import TqdmDeprecationWarning, TqdmExperimentalWarning, tqdm as std_tqdm
    import random
    import warnings

    warnings.simplefilter('ignore', TqdmDeprecationWarning)
    warnings.simplefilter('ignore', TqdmExperimentalWarning)

    with std_tqdm(total=200) as x:
        for i in x:
            x.set_description("Description: " + str(i))
            x.display()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:53.557399
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=4) as t:
        for i in _range(4):
            assert isinstance(t, tqdm_gui)
            assert isinstance(t, std_tqdm)
            t.update()


if __name__ == "__main__":
    r = tqdm_gui(total=4)
    for i in _range(4):
        r.update()
    r.close()
    test_tqdm_gui()
    # Testing trange and tqdm
    trange(100)
    tqdm(total=100)

# Generated at 2022-06-12 15:00:03.272175
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit test for method display of class tqdm_gui
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from .std import tqdm

    # progressbar = tqdm_gui(iterable=[_range(0, 5)] * 15, leave=False,
    #                         mininterval=0.01,
    #                         miniters=1, total=5,
    #                         dynamic_ncols=True, smoothing=0.2)
    progressbar = tqdm(iterable=[_range(0, 5)] * 15, leave=False,
                       mininterval=0.01,
                       miniters=1, total=5,
                       dynamic_ncols=True, smoothing=0.2)
    # display

# Generated at 2022-06-12 15:00:11.417150
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time
    with tqdm_gui(total=None, leave=True) as t:
        for _ in range(100):
            t.display()
            time.sleep(0.01)
    # Restore toolbars
    mpl.rcParams['toolbar'] = t.toolbar
    # Return to non-interactive mode
    if not t.wasion:
        plt.ioff()
    if t.leave:
        t.display()
    else:
        plt.close(t.fig)

# Generated at 2022-06-12 15:00:19.356802
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest import mock
    from .std import tqdm
    m = mock.MagicMock()
    iterbar = tqdm_gui(range(10), clear=m)
    iterbar.clear()
    m.assert_called_with(iterbar, None)
    m.reset_mock()
    iterbar.close()
    m.assert_not_called()
    with mock.patch.object(tqdm, 'tqdm') as m:
        iterbar = tqdm_gui(range(10), clear=m)
        iterbar.clear()
    m.assert_called_with(iterbar)


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    # try:
    #     # Automatically close tqdm (not recommended in notebooks

# Generated at 2022-06-12 15:00:23.209025
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import time
    try:
        a = tqdm_gui(total=10)
        for i in tqdm_gui(range(1, 11)):
            time.sleep(0.2)
    except Exception:
        pass
    plt.close()

# Generated at 2022-06-12 15:00:30.926329
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib
    import matplotlib.pyplot as plt

    old_toolbar = matplotlib.rcParams['toolbar']
    old_isinteractive = plt.isinteractive()

    a = tqdm_gui(total=10)
    a.update()
    a.close()

    assert matplotlib.rcParams['toolbar'] == old_toolbar
    assert plt.isinteractive() == old_isinteractive

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-12 15:00:32.523803
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # tqdm.clear() should do nothing, but shouldn't fail
    tqdm.clear()

# Generated at 2022-06-12 15:00:39.415800
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot as plt
    from numpy.testing import assert_array_equal


# Generated at 2022-06-12 15:00:49.215280
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    from tqdm import tqdm_gui
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    toolbars = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()
    pbar = tqdm_gui(total=100)
    pbar.close()
    assert mpl.rcParams['toolbar'] == toolbars
    assert plt.isinteractive() == wasion
    # test side effects on close
    pbar = tqdm_gui(total=10)
    pbar.close()
    assert plt.isinteractive() == wasion
    # test if closing a closed bar does something
    pbar = tqdm_gui(total=10)
    pbar.close()
    pbar.close()
   