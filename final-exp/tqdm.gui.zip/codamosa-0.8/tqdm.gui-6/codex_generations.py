

# Generated at 2022-06-12 14:58:27.379339
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import executable
    from subprocess import Popen, STDOUT, PIPE

    p = Popen([executable, '-c', 'from tqdm import tqdm_gui as t; t().close()'],
              stdout=PIPE, stderr=STDOUT,
              universal_newlines=True)
    out, _ = p.communicate()
    assert p.returncode == 0, (p.returncode, out, _)
test_tqdm_gui_close.test = True

# Generated at 2022-06-12 14:58:28.691904
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=10) as t:
        try:
            t.clear()
        except NotImplementedError:  # pragma: no cover
            t.update()

# Generated at 2022-06-12 14:58:34.665593
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from textwrap import dedent
    from .utils import formatted_duration

    it = tqdm_gui(total=1000, leave=True, desc="tqdm_gui_close test")
    for i in it:
        pass
    with it.gui:  # Re-parse leave=True
        it.close()
    assert it.disable
    assert it.gui.disable
    assert it._instances == []

    it.reset(total=1000)
    it.gui.last_print_t = it.start_t - it.gui.mininterval - 1
    it.gui.total = 1000
    # 1000 batches of 1
    for _ in it:
        it.update()
    # 1000 batches of 1
    for _ in it:
        it.update()
    # 1000 batches of 1

# Generated at 2022-06-12 14:58:44.035549
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

# Generated at 2022-06-12 14:58:45.939489
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot as plt

    try:
        for _ in ttqdm_gui(range(5)):
            plt.pause(1)
    except Exception:
        pass  # pragma: no cover
    finally:
        plt.close()



# Generated at 2022-06-12 14:58:51.882642
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from ...tests import TestCase
    except:
        from unittest import TestCase
    from matplotlib.testing.decorators import cleanup

    @cleanup
    @tqdm_gui()
    def test():
        for _ in range(10):
            yield

    with TestCase().subTest(msg="clear"):
        test()

# Generated at 2022-06-12 14:59:00.702776
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import isnan, asarray, arange

    plt = tqdm_gui.plt
    t = tqdm_gui(total=100, disable=False, leave=False)
    sleep(0.1)
    t.clear()
    sleep(0.2)
    t.display()
    sleep(0.1)
    t.close()
    sleep(0.1)

    t = tqdm_gui(total=100, leave=False)
    sleep(0.1)
    t.clear()
    sleep(0.2)
    t.display()
    sleep(0.1)
    t.close()
    sleep(0.1)

    t = tqdm_gui(total=100)
    sleep(0.1)

# Generated at 2022-06-12 14:59:05.784641
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Unit test for method clear of class tqdm_gui"""
    from .tqdm import trange
    import os
    os.environ["TZ"] = "UTC"  # to display test times the same way
    with trange(60) as t:
        for i in t:
            if i == 30:
                t.clear()
                t.display()
            t.refresh()

# Generated at 2022-06-12 14:59:08.975483
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = trange(10)
    t.close()
    assert (t.disable == True)

# Generated at 2022-06-12 14:59:12.189197
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test function for method close of class tqdm_gui.
    """
    from .utils import FreezableClass

    with FreezableClass(tqdm_gui):
        tqdm_gui(disable=True).close()

# Generated at 2022-06-12 14:59:44.444516
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time

    t = tqdm_gui(total=100, desc='testing display')
    t.xdata = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    t.ydata = [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5]
    t.zdata = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

    t.update(35)
    t.display()

    assert t.line1.get_data() == (t.xdata, t.ydata)

# Generated at 2022-06-12 14:59:55.134032
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from os import geteuid
    if geteuid() == 0:  # check if root, to avoid popups
        return
    try:
        import matplotlib  # noqa
    except ImportError:
        return
    range(10) + range(10)  # init MPL GUI
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
    assert isinstance(t.format(""), str)
    assert isinstance(t.format("{l_bar}"), str)
    assert isinstance(t.format("{bar}"), str)
    assert isinstance(t.format("{r_bar}"), str)
    assert isinstance(t.format("{bar}", 100), str)

# Generated at 2022-06-12 15:00:05.025398
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # test_display_basic is enough since this method is only called by
    # tqdm_gui itself. This function is here for completeness.
    from tqdm.gui import tqdm_gui

    t = tqdm_gui(0)
    t.display(1)
    t.display(2)
    t.display(3)
    t.display(4)
    t.display(4.1)
    t.display(4.2)
    t.display(4.3)


if __name__ == "__main__":
    from time import sleep
    from tqdm.gui import tqdm_gui

    with tqdm_gui(10) as t:
        for i in range(10):
            sleep(0.1)
            t.update(1)
    test_tq

# Generated at 2022-06-12 15:00:15.127267
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _supports_unicode
    from .utils import brightness


# Generated at 2022-06-12 15:00:20.844525
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    iterable = range(1000)

    # Test with total
    with tqdm_gui(iterable, total=len(iterable)) as pbar:
        for i in pbar:
            pbar.display()

    # Test without total
    with tqdm_gui(iterable) as pbar:
        for i in pbar:
            pbar.display()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-12 15:00:23.411912
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=5) as pbar:
        pbar.update()
        pbar.clear()
        pbar.write("Test write")
        pbar.update()
    return pbar

# Generated at 2022-06-12 15:00:30.071313
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep

    t = [tqdm_gui(range(1000), total=1000, gui=False),
         tqdm_gui(range(1000), total=1000, gui=True)]
    for i in t:
        for j in i:
            sleep(0.01)
    for i in t:
        i.close()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 15:00:37.919318
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    class _tqdm_gui(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self.last_update = None
            self.cleared = 0
            super(_tqdm_gui, self).__init__(*args, **kwargs)

        def clear(self, nolock=False):
            self.cleared += 1

        def display(self, nolock=False):
            self.last_update = self.n

    from time import sleep
    from .utils import FormatCustomTextExt


# Generated at 2022-06-12 15:00:40.089564
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        t = tqdm(total=1)
        t.clear()  # No crash
    except Exception as e:
        raise type(e)("tqdm_gui clear method test failed!").with_traceback(e.__traceback__)



# Generated at 2022-06-12 15:00:50.067426
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plt.plot([1, 2, 3], [1, 2, 3], label='test1')
    plt.plot([1, 2, 3], [3, 2, 1], label='test2')
    plt.legend(loc='upper left')
    plt.show()
    plt.close()
    import sys
    if sys.version_info.major == 3:
        _range = range
    else:
        _range = __builtins__['xrange']
    from .utils import format_sizeof
    from .utils import format_interval
