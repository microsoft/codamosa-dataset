

# Generated at 2022-06-12 14:58:30.513891
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import random

    std_tqdm._instances.clear()  # Disable clear() from __del__

# Generated at 2022-06-12 14:58:32.552798
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm import tqdm
    import time
    import matplotlib.pyplot as plt
    for _ in tqdm_gui(range(10)):
        time.sleep(1)
        plt.close("all")

# Generated at 2022-06-12 14:58:40.406637
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    from matplotlib import pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm import trange

    def test_close(t, old_tb):
        # Set tb as old_tb
        mpl.rcParams['toolbar'] = old_tb
        # Check if status (disable, wasion and leave) is the same after close
        t.close()
        assert t.disable
        wasion = plt.isinteractive()
        assert t.wasion == wasion
        assert not t.leave
        # Check if the instances list is empty
        assert not t._instances

    # Test for trange
    old_tb = mpl.rcParams['toolbar']
    t = trange(1)
    test

# Generated at 2022-06-12 14:58:41.489955
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=3) as t:
        t.update()



# Generated at 2022-06-12 14:58:43.998068
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm import tqdm_gui

    with tqdm_gui(total=3) as pbar:
        pbar.update(1)
        pbar.clear()
        pbar.update(1)
        pbar.clear()
        pbar.update()
        pbar.clear()


# Generated at 2022-06-12 14:58:54.696836
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm_gui as t
    from .std import TqdmDeprecationWarning
    from contextlib import contextmanager

    @contextmanager
    def _mock_io():
        yield

    t.stdout = t.stderr = _mock_io()
    with t(100) as n:
        pass
    try:
        n.close()
    except Exception as e:
        assert str(e) == "i/o operation on closed file"
    with t(100) as n:
        with t(100) as n2:
            pass
        assert len(n2._instances) == 1
        assert n2._instances.pop() is n
    n.set_description("description")
    n.close()
    n.update()
    n.update(10)
    n

# Generated at 2022-06-12 14:59:02.579844
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib
    from .tests.gui import _test_tqdm_gui as _test
    from .utils import _term_move_up

    if not tqdm_gui.gui_env_ok():
        print("SKIP: GUI tests (matplotlib not found)")
        return

    with _term_move_up():
        # Test zero and None total
        with _test(tqdm_gui(total=5, leave=True)):
            for i in tqdm_gui(total=5, leave=True):
                print('H')
                pass

        # Test unit
        with _test(tqdm_gui(unit="iB", total=9, leave=True)):
            for i in range(9):
                print('H')
                pass

        # Test

# Generated at 2022-06-12 14:59:13.912401
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.utils import _decode_unicode

    # Testable code
    import matplotlib.pyplot as plt
    mpl = plt
    fig, ax = plt.subplots(figsize=(9, 2.2))
    # self.fig.subplots_adjust(bottom=0.2)
    total = 20  # avoids TypeError on None #971
    xdata = [0, 0.5, 1, 1.5]
    ydata = [0, 0.3, 0.6, 0.9]
    zdata = [0, 0.2, 0.4, 0.6]
    line1, = ax.plot(xdata, ydata, color='b')
    line2, = ax.plot(xdata, zdata, color='k')
    ax.set_

# Generated at 2022-06-12 14:59:24.536486
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_in, assert_not_in

    with tqdm(total=15, gui=True) as t:
        # Display with message
        t.reset(total=10)
        t.write("Message 1")
        t.clear()
        assert_in('\x1b[A', t.gui.last_line)
        assert_not_in('\x1b[2K', t.gui.last_line)

        # Display with message and empty bar
        t.reset(total=10)
        t.write("Message 2", end='\n')
        t.bar_format = None
        t.clear()
        assert_in('\x1b[A\x1b[2K', t.gui.last_line)

        # Display without message

# Generated at 2022-06-12 14:59:26.207215
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm

    def test_func():
        for _ in tqdm(range(100)):
            pass

    test_func()

# Generated at 2022-06-12 14:59:46.538162
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import threading
    from time import sleep
    x = tqdm(total=10)
    assert plt.isinteractive()
    plt.ion()

    def main_thread():
        try:
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
            sleep(2)
            x.update(1)
        finally:
            x.close()


# Generated at 2022-06-12 14:59:55.823554
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np

    sp = np.random.standard_normal(100)
    # set up figure
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    total = len(sp)
    # set up graph
    xdata = np.linspace(0, 100, len(sp))
    ydata = sp
    zdata = [np.mean(sp[:i]) for i in range(1, len(sp) + 1)]
    zmin = np.min(zdata)
    zmax = np.max(zdata)
    zrange = zmax - zmin
    line1, = ax.plot(xdata, ydata, color='b')
   

# Generated at 2022-06-12 15:00:02.167217
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear(): # pragma: no cover
    try:
        import mock
    except ImportError:
        warn("Mock library not found. "
            "Please install it to run tqdm tests: "
            "pip install mock", TqdmExperimentalWarning, stacklevel=2)
        return
    with mock.patch.object(tqdm.stdout, 'write') as mock_write:
        t = tqdm_gui(total=10)
        t.clear()
        assert mock_write.called == False

# Generated at 2022-06-12 15:00:09.369035
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import tqdm
    from .utils import format_sizeof
    from os import getpid
    import psutil
    from time import sleep

    # Get the current memory usage
    # On Windows, memory usage of Python process is not available
    if hasattr(psutil, "Process") and hasattr(psutil.Process, "memory_info"):
        def get_resource_usage():
            return psutil.Process(getpid()).memory_info()
    else:
        def get_resource_usage():
            return type("usage", (object,), {})

    # Get the current CPU usage
    # On Windows, CPU usage of Python process is not available
    if hasattr(psutil, "Process") and hasattr(psutil.Process, "cpu_percent"):
        def get_cpu_usage():
            return psutil

# Generated at 2022-06-12 15:00:11.378360
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm
    t = tqdm(['a', 'b', 'c'])
    t.close()

# Generated at 2022-06-12 15:00:19.325779
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """ Unit test for method display of class tqdm_gui """
    import matplotlib.pyplot as plt
    import numpy as np
    class TqdmGUI(tqdm_gui):
        def __init__(self, *args, **kwargs):
            super(TqdmGUI, self).__init__(*args, **kwargs)
            self.mininterval = 1e-9
            self.xdata = []
            self.ydata = []
            self.zdata = []
        def display(self, *_, **__):
            cur_t = self._time()
            elapsed = cur_t - self.start_t
            delta_it = self.n - self.last_print_n
            delta_t = cur_t - self.last_print_t


# Generated at 2022-06-12 15:00:23.198753
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.display()


if __name__ == '__main__':
    try:
        test_tqdm_gui()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-12 15:00:25.915095
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    import matplotlib.pyplot as plt

    for _ in tqdm_gui(range(5)):
        sleep(1)

    plt.close()

# Generated at 2022-06-12 15:00:35.315126
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from collections import deque
    from tqdm.gui import trange, tqdm
    t = tqdm(trange(5))
    assert len(t) == 5
    assert isinstance(t.xdata, deque)
    assert isinstance(t.ydata, deque)
    assert isinstance(t.zdata, deque)
    assert isinstance(t.line1, plt.Line2D)
    assert isinstance(t.line2, plt.Line2D)
    assert isinstance(t.hspan, plt.Polygon)
    assert isinstance(t.__len__(), int)
    assert isinstance(t.ax, plt.Axes)
    t.close()
    t = tqdm(total=5)


# Generated at 2022-06-12 15:00:41.367965
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    try:
        # Calling matplotlib.interactive will fail if there is no display
        import matplotlib.pyplot as plt
        try:
            plt.interactive(True)
        except RuntimeError:
            pass
        # Test a specific error if there is no display
        # an ImportError should be thrown as well if there is no DISPLAY
        import matplotlib as mpl
        mpl.use('Qt4Agg')
        import matplotlib.pyplot as plt
        import matplotlib.animation as animation
        print("Matplotlib version: {0}".format(mpl.__version__))
    except ImportError:
        raise unittest.SkipTest("No matplotlib")

    import time
    import random
    import os
