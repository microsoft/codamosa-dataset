

# Generated at 2022-06-12 14:58:30.150891
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=100) as gui:
        for i in range(100):
            sleep(0.1)
            gui.update(i+1)
    with tqdm_gui(total=100) as gui:
        for i in range(100):
            sleep(0.1)
            gui.update(1)
    with tqdm_gui(total=100, leave=True) as gui:
        for i in range(100):
            sleep(0.1)
            gui.update(1)
    with tqdm_gui(total=100, leave=False) as gui:
        for i in range(100):
            sleep(0.1)
            gui.update(1)

# Generated at 2022-06-12 14:58:34.825387
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # disable the test if no display is available
    # is not installed on the current environment
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    # normal test
    t = tqdm(total=100)
    t.close()
    # test with toolbars
    with tqdm(total=100) as t:
        import matplotlib as mpl
        mpl.rcParams['toolbar'] = 'toolbar'
        t.close()

# Generated at 2022-06-12 14:58:38.995444
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close of class tqdm_gui.
    This should not fail nor raise exeptions even if the plot isn't shown.
    """
    pbar = trange(0)  # pragma: no cover
    pbar.close()
    pbar.display()
    pbar.close()

# Generated at 2022-06-12 14:58:47.131812
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import nose.tools as nt

    mpl.rcParams['toolbar'] = 'None'
    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()

    gui = tqdm_gui(range(10))
    gui.close()

    nt.assert_equal(mpl.rcParams['toolbar'], toolbar)
    nt.assert_equal(plt.isinteractive(), wasion)

    gui = tqdm_gui(range(10), leave=True)
    gui.close()

    nt.assert_equal(mpl.rcParams['toolbar'], toolbar)
    nt.assert_equal(plt.isinteractive(), wasion)

# Generated at 2022-06-12 14:58:50.409491
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy import random

    for _ in tqdm_gui(range(5)):
        sleep(random.uniform(0,1))

# Generated at 2022-06-12 14:58:57.710669
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for the tqdm_gui widget.
    """
    from .autonotebook import tqdm
    from time import sleep

    @tqdm(total=100)
    def test_dec(*args, **kwargs):
        # return decorator wrapping function
        return tqdm(total=100)

    @test_dec
    def tst(*args, **kwargs):
        # close function
        for i in tgrange(100):
            sleep(0.01)
        return "Hello"

    tst()

# Generated at 2022-06-12 14:58:59.126977
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm

    for i in tqdm(range(10), gui=True, desc="gui: "):
        pass
        # tqdm.clear()

# Generated at 2022-06-12 14:59:03.235954
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for j in tqdm_gui(range(3), "Sleeping", leave=True):
        for i in tqdm_gui(range(20), leave=True):
            sleep(0.01)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:08.307107
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib.pyplot as plt

        # Create the tqdm_gui object
        with tqdm_gui(total=1) as t:
            tgrange(1)
            assert t.disable
            assert plt.isinteractive() == t.wasion
            assert plt.isinteractive()
        assert not plt.isinteractive()
    except ImportError:
        # Matplotlib not installed
        return
    finally:
        plt.ioff()

# Generated at 2022-06-12 14:59:09.461123
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    for _ in tqdm([1]):
        time.sleep(1)
        assert True