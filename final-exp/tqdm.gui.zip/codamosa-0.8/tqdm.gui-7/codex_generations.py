

# Generated at 2022-06-12 14:58:25.697072
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for tqdm_gui.clear"""
    import sys
    try:
        from StringIO import StringIO
    except ImportError:  # pragma: no cover
        from io import StringIO
    from concurrent.futures import ProcessPoolExecutor
    from time import sleep
    from .std import _supports_unicode

    for gui in (False, True):
        for n in range(0, 2):
            buf = StringIO()
            t = tqdm_gui(total=1, disable=not gui, file=buf)
            with ProcessPoolExecutor() as ppe:
                ppe.map(t.update, range(1, n + 1))
            with ProcessPoolExecutor() as ppe:
                ppe.map(t.update, range(1, n + 1))
            t.close()

# Generated at 2022-06-12 14:58:33.194554
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test tqdm.gui.tqdm.display(self) method"""

    import matplotlib.pyplot as plt
    import os
    import sys
    import time

    plt.close('all')

    if os.environ.get('TRAVIS', None) != 'true':
        fig_tmp = plt.figure()  # to test if another figure disables `plt.show`
        g = tqdm_gui(total=100, unit_scale=True, smoothing=0)
        for i in range(25, 51, 2):
            g.update(i)
            time.sleep(0.5)
        for i in g:
            time.sleep(0.5)
        time.sleep(0.5)
        g.close()
        time.sleep

# Generated at 2022-06-12 14:58:39.257281
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        f = h = tqdm_gui(total=10)
        assert h.disable is False
        h.disable = True
        h.close()
        assert h.disable is True

        h = tqdm_gui(total=10)
        assert h.disable is False
        h.disable = True
        f.close()
        assert h.disable is True
    finally:
        try:
            f.close()
        except Exception:
            pass

# Generated at 2022-06-12 14:58:44.772653
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Get mpld3
    try:
        import mpld3
    except ImportError:
        mpld3 = None

    # Define GUI parameters
    mininterval = 0.5
    total = 10
    n = 1
    unit = "it"
    unit_scale = True
    leave = True
    disable = False
    colour = "g"

    # Set mock toolbars state
    old_toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Set mock interactive state
    old_wasion = plt.isinteractive()
    plt.ion()

    # Mock class

# Generated at 2022-06-12 14:58:54.386498
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib
    except ImportError:
        try:
            import tkinter
        except ImportError:
            # OSX-specific workaround (otherwise unpassable)
            import os
            os.environ['DISPLAY'] = ':0'
            import matplotlib
    import matplotlib.pyplot as plt
    import pandas as pd

    matplotlib.style.use('ggplot')
    t = tqdm_gui(pd.date_range('2012-01-01', periods=20, freq="H"))
    for _ in t:
        if t.n > 5:
            break
    plt.close(t.fig)
    t.close()

# Generated at 2022-06-12 14:59:02.387346
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui.
    """
    try:
        import matplotlib as mpl
        mpl.use('Agg')
    except AttributeError:
        pass

    try:
        tqdm_gui(range(10))
    except Exception as e:
        raise Exception("%s" % e)


if __name__ == '__main__':
    from time import sleep
    from .gui import tqdm as gtqdm
    from .gui import tgrange as gtrange

    for i in gtrange(10, desc="desc1", unit="iter"):
        sleep(0.1)
    for i in gtrange(10, desc="desc2", unit="iter"):
        sleep(0.1)

# Generated at 2022-06-12 14:59:07.272484
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")
    t = tqdm_gui(total=101, gui=True, leave=False, ascii=True, desc='testing',
                 unit='iB', unit_scale=True)
    t.update(1)
    for i in _range(100):
        t.update(1)
        t.display()
    assert ax.get_xlim() == (0, 100)
    mpl.rcParams['toolbar'] = t.toolbar
    plt.close(fig)



# Generated at 2022-06-12 14:59:16.400610
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import TqdmExperimentalWarning
    from .utils import _range
    import matplotlib as mpl
    # import matplotlib.pyplot as plt

    total = 100

    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    t = tqdm_gui(_range(total), total=total, file=None)
    for i in _range(total):
        t.update()

    if mpl.get_backend() in ('Qt5Agg', 'Qt4Agg', 'CocoaAgg', 'GTKAgg', 'nbAgg'):
        # Check GUI
        assert t.fig.canvas.manager.window.title() == "tqdm " + tqdm.__version__

# Generated at 2022-06-12 14:59:24.937819
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase, main
    from tqdm import tqdm_gui
    from tqdm.utils import _range

    class Foo(object):
        """An object with a fake `total` attribute"""
        def __init__(self, total):
            self.total = total

        def __len__(self):
            return self.total

    class TestTqdmGuiDisplay(TestCase):
        """Tests tqdm.gui.tqdm.display()"""

# Generated at 2022-06-12 14:59:26.508852
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test for tqdm_gui method clear"""
    tgrange(10, 0, -1, desc='Test').clear()

# Generated at 2022-06-12 14:59:52.101408
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    >>> import time
    >>> total = 1000
    >>> @tqdm_gui(total=total)
    ... def _test_tqdm_gui_display(self):
    ...     for i in self:
    ...         time.sleep(0.001)
    ...     return self
    >>> t = _test_tqdm_gui_display()
    >>> t.n == total
    True
    >>> t.close()
    >>> import matplotlib
    >>> matplotlib.rcParams['toolbar']
    'None'
    >>> matplotlib.rcParams['toolbar'] = 'toolbar'
    """
    pass

# Generated at 2022-06-12 14:59:55.241528
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    for _ in tqdm_gui(range(10), desc='hello'):
        sleep(0.2)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:56.708888
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=100)
    t.update()
    t.display()
    t.close()

# Generated at 2022-06-12 15:00:05.559578
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm._utils import _term_move_up

    t = tqdm_gui(total=None)
    t.display()
    t.clear()


if __name__ == '__main__':
    from time import sleep
    from random import random, randint

    total = 100
    for i in trange(total):
        for _j in range(randint(1, 10)):
            sleep(random() / 5)
        # check dynamic messages
        t.set_description("Task %i, step %i" % (randint(1, 5), i))
        # check miniters/mininterval parameters (except last iteration)
        t.update(1 + i % 3)

    # Some tests with None total

# Generated at 2022-06-12 15:00:15.275348
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_true, assert_equals, assert_almost_equals

    t = tqdm(total=None, leave=False)
    # tqdm.write("tqdm_gui")
    # import matplotlib.pyplot as plt
    # plt.preview()

    for i in range(3):
        t.update()
        t.display()
        t.last_print_n = t.n
        t.last_print_t += t.miniters / 3
    assert_true(t.xdata)
    assert_equals(len(t.xdata), len(t.ydata))
    assert_true(t.xdata[-1] > t.xdata[0])
    t.miniters *= 10

# Generated at 2022-06-12 15:00:22.689308
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt

    with tqdm(total=80, disable=False) as t:
        for i in trange(10):
            t.set_description('Tqdm.gui')
            for j in trange(8):
                t.update()
        # Now pause and call `display()` to flush the gui
        t.pause()
        t.display()  # Should be unnecessary
        # assert that the GUI is still there
        assert t.gui_nrows


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 15:00:25.406573
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    >>> from tqdm._gui import tqdm_gui; tqdm_gui().display()  # doctest: +SKIP
    """
    pass

# Generated at 2022-06-12 15:00:34.923159
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(10, disable=True)
    t.miniters = 1
    t.mininterval = 0.01
    t.last_print_n = 5
    t.last_print_t = 1
    t.start_t = 0
    t.n = 6
    t.total = 10
    t.disable = False
    t.leave = False
    t.xdata = []
    t.ydata = []
    t.zdata = []
    t.fig, (ax1, ax2) = t.plt.subplots(ncols=2, figsize=(9, 2.2))
    t.ax = ax1

# Generated at 2022-06-12 15:00:36.057895
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    for i in tqdm([1, 2, 3]):
        time.sleep(0.001)

# Generated at 2022-06-12 15:00:42.224660
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque
    from .utils import TqdmDeprecationWarning
    from .utils import human_sizes

    try:
        with tqdm() as t:
            assert t.gui
            assert t.disable
        assert t.disable
        assert t.leave
    except TqdmDeprecationWarning:
        pass

    with tqdm(0, leave=False) as t:
        pass
    assert t._instances == []
    assert not t.leave
    assert t.disable

    with tqdm(0) as t:
        assert t.disable
        assert t.leave
        assert t.total is not None
        assert t.miniters == 0
        assert t.mininterval == 0.1
        assert t.unit == 'it'
        assert t.gui
        assert t.x