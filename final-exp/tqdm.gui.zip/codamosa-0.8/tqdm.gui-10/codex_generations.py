

# Generated at 2022-06-12 14:58:20.598227
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(total=1000)
    for x in range(10):
        t.update(100)
        t.display()
    t.close()

# Generated at 2022-06-12 14:58:23.882872
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pbar = tqdm_gui()
    assert pbar._instances == [pbar]
    pbar.close()
    assert pbar._instances == []



# Generated at 2022-06-12 14:58:32.007511
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import decimal
    import warnings
    from sys import version_info
    from tqdm.gui import tqdm
    if version_info[0] >= 3:
        from tqdm.gui import tgrange
    else:
        from tqdm.gui import trange as tgrange
    from tqdm.utils import format_interval, format_meter

    # Manually set `miniters` and `mininterval` to test with 1 iteration
    with warnings.catch_warnings():
        with tqdm(total=100, miniters=1, mininterval=0,
                  unit_scale=True, unit="B", desc="test") as t:
            t.update(1)
            assert t.dynamic_miniters
            assert t.miniters == 1

# Generated at 2022-06-12 14:58:35.346511
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(0.1)
    # assert (rcParams['toolbar'] == self.toolbar)

# Generated at 2022-06-12 14:58:44.551920
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test chunked display of tqdm_gui instance"""
    import pickle

    # base case & basic timeit
    t = tqdm_gui(total=100, leave=False)
    for i in tgrange(15):
        t.update(5)
        t.display()  # display() is not automatically called

    # test total=None (same as total=0)
    t = tqdm_gui(leave=False, smoothing=1)
    for i in tgrange(100):
        t.update()
        t.display()  # display() is not automatically called

    # test dynamic plot range for total=None case
    t = tqdm_gui(leave=False, smoothing=1)
    for i in tgrange(150):
        t.update()
        t.display()  #

# Generated at 2022-06-12 14:58:47.701138
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # test_tqdm_gui_close.__self__.close()
    from .gui import tqdm_gui
    from tqdm.utils import _range
    import time as _time

    for _ in tqdm_gui(_range(1000), leave=True):
        _time.sleep(0.01)

# Generated at 2022-06-12 14:58:58.081276
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from six.moves import cStringIO as StringIO
    from contextlib import contextmanager
    import sys
    import matplotlib.pyplot as plt

    @contextmanager
    def no_stdout():
        savestdout = sys.stdout
        sys.stdout = StringIO()
        yield
        sys.stdout = savestdout

    with no_stdout():
        from .std import tqdm
        from .std import TqdmTypeError, TqdmKeyError

        # Test various bad input
        with tqdm(total=100) as t:
            try:
                t.display('a')
                assert False, "Exception not raised"
            except TypeError:
                pass

# Generated at 2022-06-12 14:59:07.695437
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for class tqdm_gui
    """
    from pytest import raises
    from time import sleep

    with raises(ValueError):
        std_tqdm(ascii=True)

    try:
        import matplotlib as mpl
    except ImportError:
        print("matplotlib not found, skipping test...")
        return

    # >  <bar/>  42%|██████▏          | 25/60 [00:00<00:00, 245.51it/s]
    with tqdm(total=60) as pbar:
        for _ in range(25):
            sleep(0.01)
            pbar.update()


# Generated at 2022-06-12 14:59:13.904418
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    with tqdm(total=10) as pbar:
        for i in range(5):
            time.sleep(1)
            pbar.update()
        pbar.close()
        assert pbar.disable is True
        pbar.update()  # closed
        pbar.close()  # Already closed
        pbar.close()  # Already closed
        # pbar.__exit__()  # no effect (closed)


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-12 14:59:18.648850
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    for _ in tqdm(iter(int, 1), desc='1st loop'):
        for _ in tqdm(iter(int, 1), desc='2nd loop', leave=False):
            for _ in tqdm(iter(int, 1), desc='3nd loop', leave=False):
                pass
        pass

# Generated at 2022-06-12 14:59:34.222271
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .gui.tests import test_tqdm_gui
    test_tqdm_gui()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:36.058269
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm(total=100, leave=True) as pbar:
        for i in range(10):
            pbar.update(10)

# Generated at 2022-06-12 14:59:41.462924
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from unittest import mock
    except ImportError:
        from unittest import mock
    from .gui import tqdm_gui
    with mock.patch('matplotlib.pyplot.close') as mock_func:
        tqdm_gui(total=1)
        assert not mock_func.called
        tqdm_gui(total=1).close()
        assert mock_func.called

# Generated at 2022-06-12 14:59:44.431540
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    with tqdm_gui(total=10) as pbar:
        for i in tqdm_gui(xrange(10)):
            time.sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:48.152195
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        for _ in tgrange(10):
            pass
    finally:
        tqdm_gui.close(tqdm_gui._instances[0])

# Generated at 2022-06-12 14:59:53.434150
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    import unittest

    class TqdmGuiTest(unittest.TestCase):
        def test_tqdm_gui_bar(self):
            with tqdm(total=100) as t:
                for _ in range(100):
                    time.sleep(0.01)
                    t.update()

    unittest.main(verbosity=5, failfast=True)

# Generated at 2022-06-12 15:00:01.052958
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from unittest import TestCase

    __test__ = True


    class Test(TestCase):
        def test(self):
            t = tqdm(total=10)
            t.clear()
            t.close()

            t = tqdm(total=None)
            t.clear()
            t.close()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    for i in tqdm_gui(range(100)):
        sleep(0.05)

# Generated at 2022-06-12 15:00:06.036515
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    import matplotlib.pyplot as plt
    plt.ion()
    with tqdm(total=10, desc="Test_tqdm_gui") as pbar:
        for i in range(10):
            pbar.set_description("Test_tqdm_gui: task %s" % i)
            plt.pause(0.25)
            pbar.update()
    plt.ioff()
    plt.show()

# Generated at 2022-06-12 15:00:15.689639
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from collections import deque
    from .utils import format_dict
    from .std import FormatShowMixin
    from .utils import FormatMixin
    from .std import tqdm
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError, TqdmKeyError

    # Warn about deprecation for Python 2.6, 2.7, 3.0 and 3.1
    try:
        from collections import OrderedDict
    except ImportError:
        try:
            from ordereddict import OrderedDict
        except ImportError:
            # Py2.6+ compatibility
            OrderedDict = dict

    # Warn about deprecated widgets

# Generated at 2022-06-12 15:00:22.070404
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import modules
    # If Matplotlib is not installed/configured, skip this test
    if "matplotlib" not in modules:
        return
    # If Matplotlib is installed, make sure that it is configured
    mpl = modules["matplotlib"]
    mpl.use("Agg")
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    import matplotlib
    if not plt.get_fignums():
        plt.figure()
    # Make sure that the toolbar is always 'None'
    if rcParams['toolbar'] == 'None':
        old_toolbar = rcParams['toolbar']
        rcParams['toolbar'] = 'toolbar'

    # Simulate a new tqdm_gui instance
    # class tqdm_gui(

# Generated at 2022-06-12 15:00:41.764760
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    import time

    mytqdm = tqdm_gui(total=6, leave=False)
    mytqdm.display()
    mytqdm.update()
    mytqdm.display()
    time.sleep(2)
    mytqdm.update()
    mytqdm.update()
    mytqdm.display()
    time.sleep(3)
    mytqdm.update(3)
    mytqdm.display()
    time.sleep(1)
    mytqdm.close()

# Generated at 2022-06-12 15:00:43.710148
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
  from inspect import isfunction
  assert isfunction(tqdm_gui.close)

# Generated at 2022-06-12 15:00:48.875251
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm.auto import trange
    for _ in trange(3, desc='foo', leave=False, disable=False):
        sleep(1)


if __name__ == '__main__':
    import time
    from time import sleep

    sleep(1)
    test_tqdm_gui()
    sleep(1)
    test_tqdm_gui()
    sleep(1)

# Generated at 2022-06-12 15:00:57.683159
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import time

    # Test for progressbar
    pg = tqdm_gui(total=4)
    pg.display()
    assert pg.n == 0
    assert pg.last_print_n == 0
    assert pg.last_print_n == 0
    assert pg.last_print_t == pg.start_t
    assert pg.xdata == [0]
    assert pg.ydata == [0]
    assert pg.zdata == [0]
    assert [round(i, 4) for i in pg.ax.get_ylim()] == [0, 0.001]
    assert [round(i, 4) for i in pg.ax.get_xlim()] == [0, 100]

# Generated at 2022-06-12 15:01:05.838031
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep as tsleep
    from random import randint
    import matplotlib.pyplot as plt
    from os import name as osname

    @tqdm_gui
    def test_tqdm(it):
        for i in it:
            yield i
            tsleep(0.1)
    # list comprehension to test total
    # it = test_tqdm([randint(1, 50) for _ in range(100)])
    # generator to test no total
    it = test_tqdm((randint(1, 50) for _ in range(100)))
    while not it.disable:
        it.update()
    # to avoid patching problems with mpl+windows
    if osname == 'nt':
        plt.close('all')


# Generated at 2022-06-12 15:01:14.162938
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc

    # First check if a progress bar is correctly managed when closed
    q = tqdm_gui(total=1)
    refcount_init = len(gc.get_referrers(q))
    q.close()
    assert len(gc.get_referrers(q)) == refcount_init - 1

    # Then check if the figure is correctly closed
    for i in range(3):
        q = tqdm_gui(total=1)
        q.n = 1
        q.close()
        assert not q.plt.get_fignums()

    # Check if correct when no figure
    q = tqdm_gui(total=1)
    q.n = 1
    q.disable = True
    q.close()

    # Check if correct when external figure

# Generated at 2022-06-12 15:01:24.179982
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10, desc="test_tqdm_gui") as t:
        for x in range(10):
            t.display()
            t.update()

    with tqdm_gui() as t:
        for x in range(10):
            t.display()
            t.update()

    with tqdm_gui(total=10, bar_format="{bar_fill}{bar}|") as t:
        for x in range(10):
            t.display()
            t.update()

    with tqdm_gui(total=10, bar_format="{bar_fill}{bar_percentage:3.2f}%|") as t:
        for x in range(10):
            t.display()
            t.update()


# Generated at 2022-06-12 15:01:34.187469
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from sys import argv
    from time import sleep
    from .utils import _term_move_up

    # @TODO:
    #     # Code to test in a subprocess to simulate a new instance of python
    #     # See issue #890
    #     if __name__ == '__main__':
    #         t = tqdm_gui(total=3, gui=True, ncols=20)
    #         for i in range(3):
    #             t.update()
    #             sleep(0.5)
    #         t.close()

    t = tqdm_gui(total=3, gui=True, ncols=20)
    for i in range(3):
        t.update()
        sleep(0.5)
        _term_move_up()
        t.clear

# Generated at 2022-06-12 15:01:36.796859
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test tqdm_gui().close() method
    from time import sleep
    from threading import Thread
    t = tqdm(total=10)
    for i in range(10):
        t.update()
        sleep(0.5)
    # Must not raise any exception if called multiple time in many threads
    Thread(target=lambda: t.close()).start()
    t.close()
    t.close()

# Generated at 2022-06-12 15:01:38.195204
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
  t = tqdm_gui(total=10, ascii=True)
  t.close()
  assert t.disable is True