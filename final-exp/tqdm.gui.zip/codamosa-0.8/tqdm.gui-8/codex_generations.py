

# Generated at 2022-06-12 14:58:21.960839
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy.random import rand
    plt, __ = tqdm.gui.plt, tqdm.gui.__
    for n in tqdm(tqdm.gui.trange(60, desc='tqdm', ascii=True), ascii=False):
        sleep(1)
        __(rand(10))

    # Restore external interactive mode
    if not __.isinteractive():
        plt.ioff()
        plt.show()


# Generated at 2022-06-12 14:58:28.198434
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from matplotlib import pyplot
        from matplotlib import cm as _cm
    except ImportError:
        warn("Test suite requires matplotlib")
        return

    from .tests import tests
    from .autonotebook import tqdm_notebook

    tests.test_tqdm_display(tqdm_gui)
    tests.test_tqdm_display(tqdm_notebook)


if __name__ == "__main__":
    # Test
    test_tqdm_gui_display()

# Generated at 2022-06-12 14:58:32.064715
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    t = tqdm_gui(total=100, leave=False)
    t.refresh()
    regex = re.compile(r'^[\s\x00-\x7f]*$')
    assert(regex.match(t.format_dict['bar']))
    assert(regex.match(t.format_dict['n']))
    t.close()

# Generated at 2022-06-12 14:58:40.354407
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import format_sizeof
    from .utils import get_free_space
    from .utils import format_interval
    from .utils import format_interval_short
    from .utils import format_meter
    from .utils import format_number
    from .utils import human_size
    from .utils import list_prog_bar_updates
    from .utils import percentage
    from .utils import time_units
    from .utils import _unicode
    from .utils import _term_move_up
    from .utils import _term_move_down
    from .utils import _term_clear_line
    from .utils import _length_hint
    from .utils import _environ_cols_wrapper
    from .utils import _environ_cols
    from .utils import _range
    from .utils import _unich

# Generated at 2022-06-12 14:58:45.390231
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for cls in (tqdm, tqdm_gui, trange, tgrange):
        with cls(total=5) as pbar:
            for i in pbar:
                pbar.update()
        try:
            pbar.display()  # should be disabled
        except Exception:
            pass
        else:
            raise AssertionError()


if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-12 14:58:56.255767
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit tests for method `display` of class `tqdm_gui`"""
    import time
    import matplotlib
    matplotlib.interactive(False)
    from .compat import PY2, text_type
    from .gui import tqdm

    def _test(**kwargs):
        # TODO: Add verbosity argument to unit test
        verbose = None if kwargs.pop('verbose') is None else False
        t = tqdm(unit='MB', **kwargs)
        for _ in t:
            if _ > 2:
                t.close()
                break
            if _ > 1:
                if PY2:
                    t.write(text_type("Hello World " * 10))
                else:
                    t.write("Hello World " * 10)
                t.update()
           

# Generated at 2022-06-12 14:58:57.530019
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    unit test for class tqdm_gui
    """
    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.update()
            t.display()

# Generated at 2022-06-12 14:59:07.660797
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    try:
        import numpy as np
    except ImportError:
        np = None

    t = tqdm_gui(total=100, desc='testingtqdm ')

# Generated at 2022-06-12 14:59:14.182354
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    plt.ion()
    test = tqdm_gui(total=100)
    test.display()
    assert test.hspan.get_xy()[2, 0] == 0.0
    assert test.hspan.get_xy()[2, 1] == 0.001
    test.update()
    test.display()
    assert test.hspan.get_xy()[2, 0] == 1.0
    assert test.hspan.get_xy()[2, 1] > 0.001
    test.close()

# Generated at 2022-06-12 14:59:23.115240
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .tests import dummy_gui_tqdm
    dummy_gui_tqdm(_range(100))
    dummy_gui_tqdm(xrange(100))
    dummy_gui_tqdm(xrange(100), leave=True)
    dummy_gui_tqdm(xrange(100), leave=False)
    dummy_gui_tqdm(xrange(100), unit="it", bar_format="{n}/{total} [{bar}]")


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:37.853606
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=50)
    t.clear()
    t.close()

# Generated at 2022-06-12 14:59:44.878285
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            time.sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit='it') as t:
        for i in _range(10):
            time.sleep(0.1)
            t.update()
    with tqdm_gui(10) as t:
        for i in _range(10):
            time.sleep(0.1)
            t.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:49.661544
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from time import sleep
    with tqdm(total=1) as pbar:
        pbar.clear()
        sleep(0.1)
        pbar.clear()

# Unit tests for module tqdm_gui

# Generated at 2022-06-12 14:59:57.790495
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    p = tqdm_gui()
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True
    p.disable = False
    p.disable = True


# Generated at 2022-06-12 15:00:06.355340
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    try:
        from nose.tools import assert_equal, assert_greater
    except ImportError:
        from unittest import TestCase


# Generated at 2022-06-12 15:00:15.729728
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import format_sizeof, set_lock
    from .std import format_interval, format_meter
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    set_lock(False)

    t = tqdm_gui(10)
    assert t.disable == False
    assert t._instances == [t]
    assert t.toolbar == mpl.rcParams['toolbar']
    assert t.wasion == plt.isinteractive()
    assert t.mininterval == max(t.mininterval, 0.5)
    assert t.total == 10

# Generated at 2022-06-12 15:00:17.096233
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=100, unit='it', unit_scale=True, unit_divisor=1000) as t:
        for i in range(100):
            t.update()
    t.close()

# Generated at 2022-06-12 15:00:18.371562
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    for _ in trange(9, 0, -1):
        time.sleep(0.1)

# Generated at 2022-06-12 15:00:19.725250
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(gui=True)
    t.close()

# Generated at 2022-06-12 15:00:30.029106
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import unittest
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    class Test_tqdm_gui_display(unittest.TestCase):
        """Test method display of class tqdm_gui."""
        def test_display(self):
            """Test method display of class tqdm_gui."""
            if mpl.get_backend() != "TkAgg":
                self.skipTest("Matplotlib backend must be TkAgg")

# Generated at 2022-06-12 15:01:07.824614
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test GUI features of tqdm_gui"""
    import time
    # Test with total steps known
    with tqdm_gui(total=100, bar_format='{bar} {r_bar} {postfix}') as t:
        for i in t:
            time.sleep(0.1)
            t.set_description_str('description')
            t.set_postfix(str(i), refresh=True)
    # Test with total steps unknown
    with tqdm_gui(bar_format='{bar}|{postfix}') as t:
        for i in t:
            time.sleep(0.1)
            t.set_postfix(postfix=str(i), refresh=True)
            if i == 5:
                break
    # Test progressive total

# Generated at 2022-06-12 15:01:10.894800
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for method close of class tqdm_gui"""
    for _ in tqdm_gui(range(5)):
        pass

# trigger unit test when execution file
if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-12 15:01:14.771777
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from math import log, sin
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    for _ in tqdm_gui(map(log, range(10)), desc='Clearly a test', leave=True):
        sleep(0.01)
    plt.plot([sin(x) for x in range(10)])

# Generated at 2022-06-12 15:01:21.350346
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test if the tqdm_gui is correctly closing the mpl figure.
    """
    try:
        from matplotlib.pyplot import close
        from matplotlib.tests import set_font
    except ImportError:
        return
    except Exception as e:
        # mpl is not installed, ignore this file
        warn("tqdm_gui: %s" % e)
        return
    try:
        set_font()  # set the default font to DejaVu Sans
    except Exception:
        pass  # ignore font errors

    g = tqdm_gui(total=10)
    assert close.call_count == 0
    g.update()
    assert close.call_count == 0
    g.close()
    assert close.call_count == 1

# Generated at 2022-06-12 15:01:25.056254
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    cur_t = 0
    t = tqdm_gui(1000)
    for index, item in enumerate(t):
        cur_t += 1
        t.display()
        assert(t.xlim == (0, 1.1))
        assert(t.ylim == (0, 0.0001))

# Generated at 2022-06-12 15:01:27.583929
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .__init__ import tqdm
    from time import sleep

    for _ in tqdm(range(10)):
        sleep(0.05)
    tqdm.close()

# Generated at 2022-06-12 15:01:36.968441
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    def _test():
        f = tqdm_gui(total=100)
        f.n = 40
        f.display()
        assert not f.disable
        assert f.disable_counter == 0
        assert f.unit_scale == True
        assert f.miniters == 1
        assert f._decimals == 1
        assert f.dynamic_ncols == True
        assert f.smoothing == 0.3
        assert f.bar_format == '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}{postfix}]'
        assert f.unit == ''
        assert f.unit_scale == True
        assert f.miniters == 1
        assert f.mininterval == 0.1
        return True
    assert _test()

# Generated at 2022-06-12 15:01:42.193702
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm(total=100, bar_format="{l_bar}{bar}{r_bar}") as t:
        for i in range(10):
            t.update()
    with tgrange(10) as t:
        for i in t:
            pass


if __name__ == "__main__":  # pragma: no cover
    import time
    # Unit test
    test_tqdm_gui()
    # Demo
    time.sleep(0.5)
    with tqdm(total=50, desc='Second demo', leave=False) as t:
        for i in range(50):
            time.sleep(0.1)
            t.update()
    time.sleep(1)

# Generated at 2022-06-12 15:01:50.463024
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib.backends.backend_qt4 import _BackendQT4
    from matplotlib.backends.backend_qt5agg import _BackendQT5
    from matplotlib.backends.backend_tkagg import _BackendTkAgg
    from matplotlib.backends.backend_wx import _BackendWx

    # Create a tqdm_gui object
    # Ln 45: This *should* raise a TqdmExperimentalWarning
    progress = tqdm_gui(total=100, leave=True)
    # Check that TqdmExperimentalWarning is raised
    assert progress.total == 100
    assert progress.leave == True
    # Assert that the imported matplotlib backends are valid backends
    assert _BackendQT4
    assert _BackendQT5


# Generated at 2022-06-12 15:01:57.019768
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from copy import copy

    # TODO: check tests for tqdm_gui with tqdm_notebook?

    # Initialisation
    t = tqdm_gui(ncols=30)
    t._instances = []
    t.cur = 4.
    t.start_t = t._time()
    t.last_print_n = 0
    t.last_print_t = t.start_t
    t.n = 3.
    t.dynamic_ncols = True
    t.total = None

    # GUI test
    # TODO: fix matplotlib import warning (is it needed to set backend?)
    t.close()  # reset
    t.display()  # display
    t.clear()  #

# Generated at 2022-06-12 15:02:49.566410
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    ''' Test the close method of class tqdm_gui '''
    import sys
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    myprogressbar = tqdm_gui(0)
    myprogressbar.disable = False
    myprogressbar._instances = []
    myprogressbar._instances.append(myprogressbar)
    myprogressbar.mpl = mpl
    myprogressbar.plt = plt
    myprogressbar.toolbar = myprogressbar.mpl.rcParams['toolbar']
    myprogressbar.mpl.rcParams['toolbar'] = 'None'
    myprogressbar.mininterval = max(myprogressbar.mininterval, 0.5)

# Generated at 2022-06-12 15:03:00.433403
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit test function for method display of class tqdm_gui"""
    tgui = tqdm_gui(total=None, leave=True)
    tgui.xdata = [1, 2, 3, 4, 5, 6, 7]
    tgui.ydata = [1, 2, 3, 4, 5, 6, 7]
    tgui.zdata = [2, 3, 5, 7, 11, 13, 17]
    tgui.ax.set_ylim(0, 20)
    tgui.ax.set_xlim(-60, 0)
    tgui.ax.invert_xaxis()
    tgui.display()


if __name__ == '__main__':
    from time import sleep

# Generated at 2022-06-12 15:03:08.384179
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from os import get_terminal_size
    from sys import platform
    assert platform != 'win32'
    try:
        import numpy as np
    except ImportError:
        np = None

    with tqdm_gui(total=100, desc="test_tqdm_gui",
                  bar_format="{desc}: {percentage:3.0f}%|{bar}| ") as t:
        for i in _range(100):
            t.update()
            if np is not None:
                np.exp(i)
            else:
                i ** 2


# Generated at 2022-06-12 15:03:17.250821
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    if not hasattr(tqdm, 'display'):  # pragma: no cover
        raise ImportError('expected tqdm to have method _gui_print')

    # Remark: display should be called the first time in order to compute the
    #         scale factor of the progress bar according to the initial
    #         time. In this way, progress bar takes into account the initial
    #         time/speed of iterations
    # Initialise tqdm_gui instance
    t = tqdm(total=5)

    # Call method display one time
    t.display()

    # Assert that class attribute delta_it is properly initialised
    assert t.delta_it == 0

    # Assert that class attribute delta_t is properly initialised
    assert t.delta_t == 0

    # Update class attribute

# Generated at 2022-06-12 15:03:24.038799
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from tqdm.gui import tqdm
    list(tqdm(range(10)))


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    with tqdm(total=100, leave=False, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]") as pbar:
        for i in range(100):
            sleep(0.05)
            pbar.update(1)
    test_tqdm_gui_close()
    print("tqdm_gui done")

# Generated at 2022-06-12 15:03:31.393198
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    import matplotlib.pyplot as plt

    # test class constructor
    f = plt.figure()
    assert tqdm_gui(f)


# Generated at 2022-06-12 15:03:37.140591
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    a = tqdm_gui(total=100)
    a.display()
    a.update()
    plt.close(a.fig)


if __name__ == "__main__":
    from time import sleep
    for i in trange(10):
        sleep(0.5)
    for i in tgrange(10):
        sleep(0.5)

# Generated at 2022-06-12 15:03:41.296829
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from random import random
    from time import sleep
    progress = tqdm_gui(total=100)
    for i in range(100):
        progress.set_postfix(foo='bar')
        progress.display(dynamic_ncols=True)
        sleep(random() * 0.01)
        progress.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-12 15:03:43.310886
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        t = tqdm_gui(total=10, leave=True)
        assert not t.disable
        t.close()
    except Exception as e:
        print(e)
        assert False
    assert t.disable


# Generated at 2022-06-12 15:03:48.800969
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from matplotlib.pyplot import switch_backend
        switch_backend('Qt4Agg')
    except ImportError:
        pass
    except RuntimeError:
        pass
    for _ in tqdm(range(3)):
        pass
    tqdm_gui.clear()