

# Generated at 2022-06-12 14:58:19.244046
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(0)
    t.clear()



# Generated at 2022-06-12 14:58:23.232225
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in range(10):
        for instance in tqdm_gui._instances:
            instance._instances.clear()
        tqdm_gui._instances.add(tqdm(total=10))


if __name__ == '__main__':  # pragma: no cover
    with tqdm_gui(total=1000000) as t:
        for i in t:
            t.display()
    input("Done. Press any key to continue...")

# Generated at 2022-06-12 14:58:31.576411
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os, sys, re
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        # Skip test if matplotlib is not installed
        return

    # Reset matplotlib to non-interactive
    mpl.interactive(False)
    # Check if matplotlib is interactive
    if plt.isinteractive():
        raise RuntimeError("Matplotlib is interactive")

    # Back up matplotlib settings
    old_backend = mpl.get_backend()
    mpl.use('Agg')
    old_toolbar = mpl.rcParams['toolbar']

    # Create a dummy tqdm

# Generated at 2022-06-12 14:58:32.735704
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    if isinstance(tqdm_gui(0), tqdm_gui):
        pass

# Generated at 2022-06-12 14:58:40.440073
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    pbar = tqdm_gui()
    pbar.total = None
    pbar.n = 60
    pbar.last_print_n = 0
    pbar.last_print_t = 0
    pbar.start_t = 0
    pbar.display()
    pbar.update(30)
    pbar.n = 90
    pbar.display()
    # TODO: find and restore this failing test
    # pbar.n = 100
    # pbar.display()
    # pbar.close()
    # plt.show()
    # pbar = tqdm_gui(total=100, leave=False)
    # pbar.start()
    # arr = np.arange(0, 10000, 0.

# Generated at 2022-06-12 14:58:42.371300
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    for _ in tqdm_gui(range(10), desc="tqdm_gui"):
        time.sleep(0.05)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:54.482206
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for method close of class tqdm_gui"""
    # pylint: disable=protected-access
    import os
    import sys
    if sys.version_info.major > 2:
        from tqdm import _tqdm
    else:
        from tqdm._tqdm import _tqdm

    tqdm._instances = set()
    tqdm._instances.add(tqdm_gui(disable=True, unit='it', total=9,
                                 leave=True,
                                 disable_tqdm=False))
    tqdm_gui._instances = set()
    tqdm.disable = False
    tqdm._decr_instances()
    assert len(tqdm._instances) == 0

# Generated at 2022-06-12 14:59:02.448920
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from matplotlib.figure import Figure

    with tqdm_gui(total=10) as t:
        assert isinstance(t.fig, Figure)
        sleep(0.01)
        assert isinstance(t.fig.axes[0], t.plt.Axes)
        for i in t:
            pass

    assert t.ax.get_xlim()[0] == 0
    assert t.ax.get_xlim()[1] == 100
    assert isinstance(t.xdata, list)
    assert t.xdata == list(t.ax.get_lines()[0].get_xdata())
    assert t.ydata == list(t.ax.get_lines()[0].get_ydata())
    assert t.zdata == list

# Generated at 2022-06-12 14:59:07.334220
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from numpy import random
    for _ in tqdm_gui(xrange(10), desc='Test'):
        sleep(random.rand())


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-12 14:59:12.741017
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for _ in range(10):
        t = trange(100)
        for i in t:
            t.n = i
            t.update()
    t.close()


if __name__ == "__main__":
    # TODO: create proper tests and unittest or py.test!
    test_tqdm_gui_close()

# Generated at 2022-06-12 14:59:28.512866
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    pbar = tqdm_gui(total=10)
    for i in range(10):
        pbar.update()
        sleep(0.01)
    pbar.close()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:38.035943
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for :meth:`tqdm_gui.display`.
    """
    from time import sleep
    from tempfile import mkdtemp
    from os.path import join as join_path
    from os import path

    def create_instance(total=None, leave=False, unit='it', unit_scale=False,
                        dynamic_ncols=True, ncols=None):
        """
        Return an instance of :class:`tqdm_gui`.
        """
        from os.path import basename
        from os import path

        __name__ = basename(path.splitext(path.basename(__file__))[0])

# Generated at 2022-06-12 14:59:43.138913
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    pytest_tqdm = tqdm_gui(5) # tqdm_gui will create a new figure if pytest_tqdm.disable is False
                                 # using plt.close, the figure was closing but was not removed from plt.get_fignums()
    pytest_tqdm.close()
    assert pytest_tqdm.disable == True

# Generated at 2022-06-12 14:59:50.190205
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui

    # Restore toolbars
    mpl.rcParams['toolbar'] = 'toolbar'
    # Return to non-interactive mode
    if not plt.isinteractive():
        plt.on()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-12 14:59:58.114356
# Unit test for method close of class tqdm_gui

# Generated at 2022-06-12 15:00:00.804834
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # with patch.object(tqdm_gui, 'display', return_value=None) as mock:
    for _ in trange(10, desc="testing clear()", unit="emosibar"):
        pass

# Generated at 2022-06-12 15:00:08.411576
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from ._tqdm import _range_iterator, trange  # class tqdm
    assert isinstance(tqdm_gui(), tqdm_gui)  # check class constructor
    assert isinstance(tqdm_gui(0), tqdm_gui)  # check class constructor
    assert isinstance(tqdm_gui(_range_iterator(0)), tqdm_gui)  # check class constructor
    assert isinstance(tqdm_gui(0, 0), tqdm_gui)  # check class constructor
    assert isinstance(tqdm_gui(0, 0, trange), tqdm_gui)  # check class constructor
    assert isinstance(tqdm_gui(0, 0, trange), trange)  # check class constructor


# Testing basic tqdm_gui iterators

# Generated at 2022-06-12 15:00:17.094044
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    @author: Casper da Costa-Luis <casper@casperdcl.tech>
    """
    try:
        import numpy as np
    except ImportError:
        np = None

    class tqdm_gui_fake(tqdm_gui):
        "tqdm.tqdm_gui subclass that does not do any iteration"
        def __init__(self, *args, **kwargs):
            # Do not print anything, for easier testing:
            kwargs['disable'] = True
            # Do not use xrange (replaced by range on Py 3):
            kwargs['miniters'] = kwargs.pop('mininterval', 0)
            super(tqdm_gui_fake, self).__init__(*args, **kwargs)


# Generated at 2022-06-12 15:00:26.703211
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .utils import _supports_unicode
    from .std import tqdm_gui as tqdm
    from time import sleep
    import gc
    # Test Unicode
    with tqdm(u"\u23f0") as t:
        # Test iterable-style
        assert t in tqdm(tqdm(u"\u23f1"))
        sleep(0.1)
        assert t in tqdm(tqdm(u"\u23f2", leave=False))
        sleep(0.1)
        assert t in tqdm(tqdm(u"\u23f3", leave=True))
        sleep(0.1)
        assert t in tqdm(tqdm(u"\u23f4", leave=False))

# Generated at 2022-06-12 15:00:35.533863
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm import gui, trange
    from time import sleep
    from numpy.random import randn

    for i in trange(10, desc='1st loop', leave=True):
        for j in trange(5, desc='2nd loop'):
            for k in trange(100):
                sleep(0.01)
        sleep(0.01)
    # Test close()
    pbar1 = trange(10)
    pbar1.close()
    pbar1.n = 5
    pbar1.display()
    pbar2 = trange(10)
    pbar2.n = 5
    pbar2.close()
    pbar2.display()
    # Test with numpy
    pbar3 = trange(10)