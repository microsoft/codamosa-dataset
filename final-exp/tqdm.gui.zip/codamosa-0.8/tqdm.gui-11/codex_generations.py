

# Generated at 2022-06-12 14:58:32.310752
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest import TestCase
    from tqdm import gui
    gui.tqdm.clear()



# Generated at 2022-06-12 14:58:40.384427
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import tqdm, TqdmDeprecationWarning
    from .std import tqdm_gui

    t = tqdm(total=100, unit="it", miniters=1)
    for _ in t:
        if t.last_print_t:
            rate = (t.n - t.last_print_n) / (t._time() - t.last_print_t)
        else:
            rate = float('nan')
        t.write(rate=(rate, 'it/s'), bar_format='{rate_fmt}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_noinv_fmt}]')  # noqa
    t.close()

# Generated at 2022-06-12 14:58:48.002283
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase
    from sys import platform
    from time import sleep
    from .utils import _term_move_up as term_move_up
    class _TestDisplay(TestCase):
        def test_print(self):
            # Test display
            with tqdm_gui(total=10, leave=False) as pbar:
                # manually update
                _rng = _range(10)
                i = 0
                while i < 10:
                    pbar.update()
                    sleep(0.2 * i)
                    i += 1
                    if platform == 'win32':
                        print(term_move_up(), end="")
                self.assertEqual(i, 10)
                # manual close
                pbar.close()
    _TestDisplay().test_print()



# Generated at 2022-06-12 14:58:58.119524
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # TODO: @classmethod: write() on GUI?
    from distutils.version import LooseVersion
    import time
    import numpy as np
    import matplotlib as mpl

    try:
        from multiprocessing import Process
    except ImportError:
        from processing import Process

    mpl.use('TkAgg')
    assert LooseVersion(mpl.__version__) < "2.0", \
        "matplotlib 2+ is not supported yet"
    # TODO: support for matplotlib 2+
    # TODO: support for bars without total (e.g. cumsum)

    def test_gui(q):
        try:
            import matplotlib.pyplot as plt
        except:
            q.put('no')
            return


# Generated at 2022-06-12 14:59:03.943748
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=100) as pbar:
        pbar.clear()

    with tqdm(total=100, ascii=True) as pbar:
        pbar.clear()

    with tqdm(total=100, ascii=True, file=open('/dev/null', 'w')) as pbar:
        pbar.clear()



# Generated at 2022-06-12 14:59:10.854288
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmDeprecationWarning
    import matplotlib.pyplot as plt
    t = tqdm_gui(total=1000)
    for i in range(1000):
        t.update(1)
    t.close()

    plt.draw()
    t = tqdm_gui(total=1000)
    for i in range(1000):
        t.update(1)
        if i == 500:
            t.clear()
    t.close()

    plt.draw()
    t = tqdm_gui(total=1000)
    for i in range(1000):
        t.update(1)
        if i == 500:
            t.clear(wait=True)
    t.close()

    plt.draw()

# Generated at 2022-06-12 14:59:11.979445
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(1) as t:
        # t.clear()  # TODO: enable me when implemented
        pass

# Generated at 2022-06-12 14:59:20.875852
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Check that GUI is not broken due to #407
    import matplotlib.pyplot as plt
    plt.ion()

    # Test unit auto-scale
    with tqdm_gui(unit_scale=True, unit='iB') as t:
        for i in _range(100):
            t.update(100 * 1024 * 1024)
        t.total = 100 * 1024 * 1024
        t.display()

    with tqdm(unit_scale=True, unit='iB') as t:
        for i in _range(100):
            t.update(10 * 1024 * 1024)
        t.close()
        t.display()
    plt.close('all')

# Generated at 2022-06-12 14:59:28.631860
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib.pyplot import pause
    from time import time, sleep
    from numpy import random
    import matplotlib.pyplot as plt
    # tqdm.pandas is recommended only for pandas>=0.17
    try:  # pandas and tqdm.pandas
        from tqdm import tqdm as tqdm_pd  # noqa
        try:
            from tqdm.autonotebook import tqdm as tqdm_notebook  # noqa
        except ImportError:
            from tqdm.notebook import tqdm as tqdm_notebook  # noqa
        # from pandas import DataFrame
    except ImportError:  # pandas and tqdm.pandas not installed
        tqdm_pd = None
        tqdm_note

# Generated at 2022-06-12 14:59:38.178209
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Unit test for method display of class tqdm_gui"""

    class Test(tqdm_gui):
        """Specific class for testing"""

        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)

        def display(self, *_, **__):
            # pylint: disable=arguments-differ
            """Overrides the display method"""
            self.show_display(*_, **__)

        def show_display(self, *_, **__):
            # pylint: disable=arguments-differ
            """To be tested"""
            n = self.n
            cur_t = self._time()
            elapsed = cur_t - self.start_t