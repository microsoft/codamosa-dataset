

# Generated at 2022-06-12 14:58:27.037443
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import time
    t = tqdm_gui(total=10)
    t.start_t = time()
    t.n = 0
    t.last_print_n = 0
    t.last_print_t = t.start_t
    for _ in range(20):
        t.n += 1
        t.display()
        t.last_print_n = t.n
        t.last_print_t = t._time()

# Generated at 2022-06-12 14:58:31.226796
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt
    from time import sleep
    bar = tqdm_gui(downrange(1000), ascii=True, leave=True)
    for i in bar:
        sleep(0.01)
        bar.display()

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:35.105137
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Test 1: display output with more than 1 element in xdata, ydata, zdata
    # and total=3
    obj = tqdm_gui(total=3)
    obj.xdata = [1, 2, 3]
    obj.ydata = [4, 5, 6]
    obj.zdata = [7, 8, 9]
    obj.display()



# Generated at 2022-06-12 14:58:39.257368
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    t = tqdm_gui([1, 2, 3])
    for i in t:
        sleep(0.01)
        # raise RuntimeError()
        t.update()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:42.391073
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui."""
    with tqdm(total=10, gui=True, desc="tqdm_gui_clear") as t:
        for _ in range(10):
            t.clear()

# Generated at 2022-06-12 14:58:54.434587
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # with self.assertRaises(KeyError):
    #     tqdm_gui(**{'ascii': True})
    #     tqdm_gui(**{'gui': False})
    #     tqdm_gui(**{'mininterval': -1})
    tqdm_gui(**{'bar_format': '{bar}'})
    tqdm_gui(**{'bar_format': '{bar}'})
    tqdm_gui(**{'bar_format': '{bar}'})
    # with self.assertRaises(ValueError):
    #     tqdm(**{'total': -1})
    #     tqdm_gui(**{'total': 'a'})
    #     tqdm_gui(**{'total': 1, 'dynamic

# Generated at 2022-06-12 14:59:02.419189
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import exit
    from os import system
    from time import sleep
    from multiprocessing import Process
    from random import randrange
    from traceback import print_exc

    # Get the current figure and other parameters from env
    from matplotlib import get_backend
    get_backend()
    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    wasion = plt.isinteractive()
    plt.ioff()
    # Get a fresh figure
    plt.figure()
    fig = plt.gcf()

    # Check if the method close of the class tqdm_gui is done well
    # Expected results:
    # - The class attribute 'disable' is set to True
    # - The object is

# Generated at 2022-06-12 14:59:09.629710
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test tqdm_gui class constructor.
    """
    from sys import executable as exe

    try:
        from subprocess import Popen, PIPE
    except ImportError:
        warn("subprocess module not found. Skipping GUI test.")
        return

    # test both with, and without, tqdm's subprocess import
    for imp in (False, True):
        p = Popen((exe, "test_gui.py", str(imp)), stdout=PIPE, stderr=PIPE, cwd="./tests")
        out, err = p.communicate()
        assert err == b"", "test_gui.py failed with error: " + err

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:17.323529
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('matplotlib.pyplot.pause') as mk_pause:
        with mock.patch('time.time') as mk_time:
            # prepare mock
            mk_time.side_effect = [ti / 2.0 for ti in range(1, 11)]
            mk_time.side_effect += [ti / 5.0 for ti in range(11, 20)]

            # with leave=True
            with tqdm_gui(total=10, leave=True) as pbar:
                for i in range(2):
                    pbar.update()
                    time.sleep(0.002)
            pyplot = pbar.plt
            subplots = pyplot.subplots
            assert subplots

# Generated at 2022-06-12 14:59:26.402975
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit test for method display of class tqdm_gui"""
    # import unittest
    # import matplotlib.pyplot as plt
    import time
    import sys

    # class TqdmGuiTest(unittest.TestCase):
    #     """"""

    #     def test_gui_display(self):
    tgui = tqdm_gui(range(10), disable=False, leave=False)
    time.sleep(0.3)
    tgui.update()
    time.sleep(0.3)
    tgui.update()
    time.sleep(0.3)
    tgui.update()
    # plt.pause(3)
    # sys.exit(0)

# Generated at 2022-06-12 14:59:42.671523
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(1)):
        pass



# Generated at 2022-06-12 14:59:50.190963
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import time
    from .std import sleep
    from .std import isclose

    with tqdm(total=10) as pbar:
        for i in _range(10):
            sleep(.01)
            pbar.update()
    end_time = time() - pbar.last_print_time
    assert isclose(end_time, 0.1, abs_tol=0.005),\
        "Expected True, got False.\nend_time: {}".format(end_time)

# Generated at 2022-06-12 14:59:56.366752
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy
    from tqdm.gui import tqdm_gui
    t = tqdm_gui(ascii=True, gui=False, total=10, dynamic_ncols=True)
    ys = numpy.random.randn(10)
    zs = numpy.random.randn(10)
    for i in _range(10):
        t.xdata.append(i)
        t.ydata.append(ys[i])
        t.zdata.append(zs[i])
    t.display()



# Generated at 2022-06-12 15:00:05.381041
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from time import sleep
    from sys import stdout

# Generated at 2022-06-12 15:00:11.618557
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    global _instances
    _instances = []
    instance = tqdm_gui()
    # Because _instances is a list and not a set, there are duplicates.
    assert len(set(_instances)) == 1
    first_instance_id = id(list(set(_instances))[0])
    second_instance_id = id(instance)
    assert first_instance_id == second_instance_id
    instance.close()
    assert len(set(_instances)) == 0

# Generated at 2022-06-12 15:00:19.570512
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import time

    class MockTqdmFile(object):
        """
        Supposed to replace sys.std*
        """
        def __init__(self, encoding=None):
            self.encoding = encoding
            self.value = ""

        def write(self, x):
            if not isinstance(x, str if sys.version_info.major > 2 else unicode):
                x = str(x)
            self.value += x
            if x.endswith('\r'):
                self.value = re.sub(r'\r$', '', self.value)

        def flush(self):
            pass

        def isatty(self):
            return False


# Generated at 2022-06-12 15:00:29.864214
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(total=100)
    t.n = 0
    t.last_print_n = 0
    t.last_print_t = t._time() - t.mininterval
    t.start_t = t.last_print_t
    for _ in range(1, 101):
        t.update()
    # Suppress output
    t.display = lambda *args, **kwargs: None
    for _ in range(1, 101):
        t.update()
    t.close()


# quick test

# Generated at 2022-06-12 15:00:30.803479
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    assert not tqdm_gui.clear()

# Generated at 2022-06-12 15:00:35.872926
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Unit test for constructor of class tqdm_gui"""
    t = tqdm_gui(total=20)
    assert t.total == 20

if __name__ == '__main__':
    # Test
    import time

    test_tqdm_gui()
    for i in trange(30):
        time.sleep(0.01)
        if i == 10:
            trange(30, leave=True)

# Generated at 2022-06-12 15:00:39.948185
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import FormatWarnings
    from .std import TqdmExperimentalWarning
    with FormatWarnings("ignore"):
        with warnings.catch_warnings():
            warnings.filterwarnings("once", category=TqdmExperimentalWarning)
            with tqdm_gui(total=2, leave=True) as t:
                t.write("Hello", file=sys.stdout)
                assert t.disable
                assert not t.dynamic_miniters

test_tqdm_gui_close()

# Generated at 2022-06-12 15:01:03.938778
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm._utils import _term_move_up
    from .utils import _decode

    with tqdm_gui(total=10, file=open(os.devnull, "w")) as pbar:
        pbar.set_description_str('test')
        for i in _range(10):
            pbar.update()
            sleep(.1)

        pbar.display()
        cur_t = pbar._time()
        pbar.n = pbar.last_print_n = 5
        pbar.last_print_t = cur_t - 5
        pbar.set_description_str('test')
        pbar.display()
        assert 'test' in _decode(pbar.write.getvalue())

# Generated at 2022-06-12 15:01:09.481426
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from matplotlib import pyplot as plt

    from .utils import _decr_instances

    t = tqdm_gui([])
    data = []
    for i in t:
        data.append(i)
        t.display()
        sleep(0.01)

    t.close()
    plt.close()
    _decr_instances()

# Generated at 2022-06-12 15:01:16.317452
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt

    t = tqdm_gui(total=100, position=1, mininterval=0)
    for i in trange(10):
        t.update()
        plt.pause(0.5)
    for i in trange(10, 20, mininterval=0):
        t.update()
        plt.pause(0.5)
    for i in trange(30, 40, mininterval=0):
        t.update(2)
        plt.pause(0.5)
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 15:01:19.429332
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=1)
    t.update()
    t.close()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.05)

# Generated at 2022-06-12 15:01:21.463719
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test setup of tqdm_gui class"""
    from .tqdm import tqdm_gui as init

    init()
    return True


# Generated at 2022-06-12 15:01:31.705744
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit test for the method display of the class tqdm_gui.

    The test compares the result with a reference image and an image
    generated by an alternative implementation.
    """
    from .std import PY3
    from .tests import common
    from os.path import abspath, join
    from os import remove
    from PIL import Image
    from matplotlib import pyplot as plt

    if not PY3:
        return

    try:
        import numpy as np
    except ImportError:
        return

    t = tqdm(total=100)
    for _ in range(101):
        t.update()
        t.display()
    t.close()
    fig = t.fig

# Generated at 2022-06-12 15:01:39.126860
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test function for class tqdm_gui"""
    from time import time
    class TqdmGui(tqdm_gui):
        """Decorator for iterators to display a progress meter."""
        def __init__(self, *args, **kwargs):
            self.start_t = time()
            self.last_print_n = None
            self.last_print_t = self.start_t
            self.n = 0
            self.mininterval = kwargs.pop('mininterval', 0.1)
            self.maxinterval = kwargs.pop('maxinterval', 10)
            self.miniters = kwargs.pop('miniters', None)
            self.unit = kwargs.pop('unit', '') or ''
            self.unit_scale = kwargs

# Generated at 2022-06-12 15:01:48.447342
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from sys import version_info
    from time import sleep
    if version_info[0] < 3:
        from time import time as time_func
    else:
        from time import perf_counter as time_func
    from numpy.random import poisson
    t0 = time_func()
    with tqdm_gui(desc="B1", smoothing=0, gui=True) as tr:
        for i in range(16):
            TI = poisson(1.7)
            sleep(TI)
            tr.update(1)
    t1 = time_func()
    assert (t1 - t0) >= 12, "Test failed to run for 12 seconds"



# Generated at 2022-06-12 15:01:51.746524
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from ._tqdm import main_test
    from .tqdm import gui as gui_tqdm
    main_test(gui_tqdm)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 15:01:56.299150
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    # Test methods of class tqdm_gui
    # use of normal tqdm.tqdm to test the GUI version
    for i in tqdm(xrange(3)):
        for j in xrange(4):
            for k in xrange(5):
                sys.stdout.write("#")
                sys.stdout.flush()
            print("")
        print("")