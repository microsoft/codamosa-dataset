

# Generated at 2022-06-12 14:58:32.012605
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib
    with matplotlib.rc_context({'toolbar': 'None'}):
        from matplotlib import pyplot as plt
        from numpy.testing import assert_almost_equal
        from unittest.mock import patch
        from tqdm import trange

        with patch('tqdm.gui.matplotlib.pyplot.pause') as mock_pause:
            t = trange(10)
            t.display()
            assert mock_pause.call_count == 1
            assert_almost_equal(mock_pause.call_args[0][0], 1e-9)
            mock_pause.reset_mock()
            t.display()
            assert mock_pause.call_count == 1

# Generated at 2022-06-12 14:58:38.747997
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib as mpl  # NOQA
        import matplotlib.pyplot as plt  # NOQA
    except ImportError:
        return None
    else:
        with tqdm(total=1) as t:
            plt.close()
            t.close()
            mpl_toolbar_was_on = mpl.rcParams['toolbar']

        assert t._instances == []
        assert t._lock._value == 0
        assert mpl.rcParams['toolbar'] == mpl_toolbar_was_on

# Generated at 2022-06-12 14:58:43.882508
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt

    plt.ion()
    t = tqdm(total=100, ascii=True)
    for i in range(20):
        t.display()
        t.update()
        plt.pause(0.5)
    plt.close()


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-12 14:58:45.822377
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=1) as pbar:
        pbar.update(1)
        pbar.clear()
        pbar.close()

# Generated at 2022-06-12 14:58:46.868688
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        t.clear()

# Generated at 2022-06-12 14:58:48.900800
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test method close of class tqdm_gui.

    """
    n = 8
    with tqdm_gui(total=n) as progressbar:
        for i in progressbar:
            progressbar.update()
            progressbar._refresh()

import doctest
doctest.testmod()

# Generated at 2022-06-12 14:58:58.574936
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_xlabel("percent")
    ax.set_ylabel("it/s")
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 100)
    ax.grid()
    t = tqdm_gui(total=1000, disable=True)
    assert t.fig == fig
    assert t.ax == ax
    assert t.line1 == ax.get_lines()[0]
    assert t.line2 == ax.get_lines()[1]
    assert t.hspan == ax.get_children()[-1]
    plt.close(fig)
    ###############################
    fig = plt

# Generated at 2022-06-12 14:59:04.264275
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt  # noqa
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    import io
    f = io.BytesIO()

    t = tqdm_gui(total=100)
    c = FigureCanvas(t.fig)
    c.print_png(f)
    t.close()

# Generated at 2022-06-12 14:59:06.355570
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar_gui:
        pbar_gui.clear()

# Generated at 2022-06-12 14:59:15.970415
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test tqdm_gui"""
    import matplotlib.pyplot as plt

    # Test tqdm_gui constructor
    with tqdm_gui(total=10, miniters=0, mininterval=0, ncols=40,
                  disable=False, leave=True, dynamic_ncols=True) as pbar:
        for _ in range(10):
            pbar.display()
            pbar.update()

    # Test tqdm_gui constructor with non-default colour
    with tqdm_gui(total=10, miniters=0, mininterval=0, ncols=40,
                  disable=False, leave=True, dynamic_ncols=True,
                  colour='r') as pbar:
        for _ in range(10):
            pbar.display()
           