

# Generated at 2022-06-12 14:58:30.478046
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Need to import `tqdm_gui` module
    from tqdm.gui import tqdm_gui
    from tqdm import trange
    from time import sleep
    from sys import stderr
    from io import StringIO

    # Change stdout stream to StringIO
    stdout = stderr  # to avoid print()
    stderr = StringIO()

    # Test `clear()` method of class `tqdm_gui`
    with trange(10, file=stderr) as t:
        for i in t:
            # `clear()` function of tqdm_gui class
            t.clear()
            stdout.write('\r\033[K' + str(i))
            sleep(.1)

    # Restore stderr stream
    stderr = stdout
    del std

# Generated at 2022-06-12 14:58:38.917083
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .std import GetLongT
    from .std import time
    from numpy.random import randint
    total = GetLongT(1000)
    g = tqdm(total=total)
    for _ in range(1000):
        cur_t = time()
        if cur_t - g.last_print_t > 0.5:
            # do drawing
            # Inline due to multiple calls
            n = g.n
            delta_it = n - g.last_print_n
            delta_t = cur_t - g.last_print_t

            xdata = g.xdata
            ydata = g.ydata
            zdata = g.zdata
            ax = g.ax
            line1 = g.line1
            line2 = g.line2
           

# Generated at 2022-06-12 14:58:47.069591
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    import time
    # Test without real GUI
    with std_tqdm(total=10, leave=True, gui=True, disable=True) as t:
        # Reset:
        t.xdata = []
        t.ydata = []
        t.zdata = []
        t.start_t = t._time()
        # Dummy input:
        t.n = 0
        t.last_print_n = 0
        t.last_print_t = t.start_t
        # Dummy output:
        t.hspan = t.plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
        t.line1, = t.ax.plot(t.xdata, t.ydata, color='b')
       

# Generated at 2022-06-12 14:58:52.198828
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib import pyplot as plt
    from time import sleep

    plt.ion()
    for i in tqdm_gui(range(9)):
        sleep(0.1)

    assert tqdm_gui._instances == []
    assert not plt.isinteractive()

# Generated at 2022-06-12 14:59:00.906421
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm
    from time import sleep

    for _ in tqdm(range(4), desc='1st loop'):
        for _ in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        assert len(tqdm._instances) == 2
    assert len(tqdm._instances) == 1

if __name__ == "__main__":
    from sys import argv
    test_tqdm_gui_close()
    bar = tqdm_gui(range(int(argv[1]) if len(argv) > 1 else 100))
    for i in bar:
        bar.set_description("Step %i" % i)
        try:
            pass
        except:
            raise
        #sleep(0.01)

# Generated at 2022-06-12 14:59:08.845908
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import inspect
    import sys
    from .gui import tqdm_gui
    from .std import tqdm
    from .std import TqdmKeyError
    from .utils import _range

    # Test 0-100 range on stdout
    sys.stderr = sys.stdout
    with tqdm(total=100, file=sys.stdout) as pbar:
        for i in range(100):
            pbar.set_postfix_str(str(i))
            pbar.update()
    # Test 0-100 range on stderr
    sys.stderr = sys.__stderr__
    with tqdm(total=100, file=sys.stderr) as pbar:
        for i in range(100):
            pbar.set_postfix_str(str(i))


# Generated at 2022-06-12 14:59:15.138174
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    The `close` method of class `tqdm_gui` should restore the Matplotlib settings
    to their original values.
    """
    from importlib import import_module
    from .utils import _range

    matplotlib = import_module("matplotlib")
    toolbar = matplotlib.rcParams["toolbar"]
    t = tqdm_gui(_range(10))
    assert matplotlib.rcParams["toolbar"] == "None"
    t.close()
    assert matplotlib.rcParams["toolbar"] == toolbar

# Generated at 2022-06-12 14:59:24.794931
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # smoketest
    with tqdm(total=10, desc="test_tqdm_gui") as t:
        for i in _range(10):
            t.update()

    # with tqdm(_range(10), desc="test_tqdm_gui") as t:
    #     for i in t:
    #         t.update()
    #     with t.set_description("new_desc"):
    #         for i in t:
    #             t.update()
    #     for i in t:
    #         t.update()

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-12 14:59:30.496486
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase, main
    from time import sleep
    from sys import executable
    from subprocess import Popen

    t = tqdm_gui(
        10, bar_format="{percentage:3.0f}%",
        postfix={"a": "b", "c": "d"})
    for i in _range(10):
        sleep(0.1)
        t.update(1)
        sleep(0.1)

    def get_data():
        xlim = t.ax.get_xlim()
        ylim = t.ax.get_ylim()

# Generated at 2022-06-12 14:59:40.302025
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import os
    try:
        os.remove('tqdm_gui_clear.log')
    except FileNotFoundError:  # pragma: no cover
        pass
    log_file = open('tqdm_gui_clear.log', 'a')

    @tqdm_gui
    def nop(*a, **kw):
        """Process a line"""
        pass

    nop.write('a')
    try:
        for _ in nop(['a']):
            pass
    except:  # noqa
        pass
    try:
        for i in nop(tqdm_gui(range(3))):
            pass
    except:  # noqa
        pass

    log_file.close()