

# Generated at 2022-06-12 14:58:15.980238
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        t.update(1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:23.119260
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from random import randrange as r

    t = tqdm_gui(
        [0], unit='1', leave=False,
        dynamic_ncols=True, unit_scale=True, miniters=1)
    for _ in t:
        t.total = r(1.5e4, 2.5e5)
        t.display()
        t.total = r(2e5, 3.5e5)
        t.display()
        t.total = r(2.5e5, 3.5e5)
        t.display()
        t.total = r(1e6, 2e6)
        t.display()
        t.close()
    t = tqdm_gui(
        iter([]), leave=False, dynamic_ncols=True)

# Generated at 2022-06-12 14:58:26.013475
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(xrange(10), unit="test", unit_scale=True):
        assert i < 10
        assert i >= 0


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:27.752781
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import doctest
    doctest.testmod(tqdm_gui.display, verbose=True)

# Generated at 2022-06-12 14:58:30.314458
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Test the tqdm_gui constructor."""
    from time import sleep

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.25)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-12 14:58:38.581135
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm
    from time import sleep

    t = tqdm(total=60, leave=False)
    for n in t:
        t.display()
        sleep(1)

    t = tqdm(total=60, leave=False)
    for n in t:
        t.display()
        sleep(1)
    t.close()

    t = tqdm(total=60, leave=False)
    for n in t:
        t.display()
        sleep(1)

    plt.close('all')

    t = tqdm(range(60))
    for n in t:
        t.display()
        sleep(1)

    plt.close('all')
    t

# Generated at 2022-06-12 14:58:46.868965
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from .std import tqdm as std_tqdm
    from .std import TqdmExperimentalWarning
    from .utils import _range

    assert mpl.rcParams['toolbar'] == 'toolbar2'
    assert plt.isinteractive() is True

    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    assert mpl.rcParams['toolbar'] == 'toolbar2'
    assert plt.isinteractive() is True
    with tqdm_gui(total=10) as t:
        assert mpl.rcParams['toolbar'] == 'None'
        assert plt.isinteractive() is True
        for i in _range(10):
            t.update

# Generated at 2022-06-12 14:58:49.958397
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(1, desc='hi')
    assert t.desc == 'hi', "Dummy test failed"


# Generated at 2022-06-12 14:58:59.482594
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    # On import, matplotlib checks if a DISPLAY is defined
    # This is not the case when running test from a different computer.
    # Therefore, we add a null backend to avoid matplotlib error messages
    import matplotlib as mpl
    mpl.use('module://mpl_test_backend')

    # Start testing
    def _test_display(t):
        for i in t:
            if i > 5:
                raise ValueError
            sleep(0.01)

    t = tqdm_gui(total=10, leave=False)
    _test_display(t)
    t = tqdm_gui(total=None, leave=False)
    _test_display(t)
    t.close()



# Generated at 2022-06-12 14:59:08.006549
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    # test if warning is raised when tqdm_gui is used
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        tqdm_gui(
            range(100),
            desc="tqdm_gui test",
            ascii=True,
            unit='B',
            unit_scale=True,
            mininterval=0.5,
            miniters=1,
            postfix={"str": "test", "obj": "test"})
        assert issubclass(w[-1].category, TqdmExperimentalWarning)
        assert "GUI is experimental/alpha" in str(w[-1].message)

    # test that tqdm_gui won't crash if created, closed and then updated