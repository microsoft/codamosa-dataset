

# Generated at 2022-06-22 05:20:10.771456
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm_gui as tqdm
    for _ in tqdm(range(20), desc='TEST', leave=False):
        pass

# Generated at 2022-06-22 05:20:16.868353
# Unit test for function tgrange
def test_tgrange():
    i = 0
    for _ in trange(1, 101, unit_scale=True, unit='iB', unit_divisor=1024):
        i += 10**6
        if i == 2**20:
            break
    assert i == 2**20


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 05:20:27.634916
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import TqdmDeprecationWarning, TqdmExperimentalWarning
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from collections import deque
    from .utils import _range

    # Toolbars should be removed
    assert mpl.rcParams['toolbar'] == 'None'

    # Interactive mode should be on
    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    assert plt.isinteractive()

    # Loading tqdm_gui
    tqdm_gui(range(2))

    # Toolbars should not be restored
    assert mpl.rcParams['toolbar'] == 'None'

    # Interactive mode should not be off
    assert plt.isinteractive()

    # Loading tqdm_gui with the option leave

# Generated at 2022-06-22 05:20:31.369507
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import time
    for _ in tqdm(range(100)):
        time.sleep(0.01)
    # test close()
    tqdm._instances.close()

# Generated at 2022-06-22 05:20:37.595909
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib
    t = tqdm_gui(range(10))
    t.close()
    assert not t._instances

    matplotlib.rcParams['toolbar'] = 'toolbar'  # restore toolbar


if __name__ == "__main__":
    # Unit test for method close of class tqdm_gui
    test_tqdm_gui_close()

# Generated at 2022-06-22 05:20:41.495431
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # import matplotlib.pyplot as plt
    # import time
    # t = tqdm_gui(total=10, leave=False)
    # for _ in t:
    #     time.sleep(0.01)
    # t.clear()
    # t.disable = True
    # plt.show(block=True)
    # print("clear() success")
    pass


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:20:52.860078
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .tests import TestCase
    from .utils import format_sizeof

    for buf in [False, True]:
        for unit in ['', 'bytes']:
            msg = 'close buffer: {} unit: {}'.format(
                "no " if buf == False else "yes", unit)

            with TestCase(buf=buf, unit=unit, unit_scale=False):
                t = tqdm_gui(total=100, miniters=1)
                t.start()
                t.update(10)
                t.close()


if __name__ == "__main__":
    # https://github.com/tqdm/tqdm/issues/836
    import multiprocessing as mp
    mp.set_start_method('spawn')

    for _ in trange(10):
        pass

    # https

# Generated at 2022-06-22 05:20:55.001222
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from .tests.gui_tests import test_tqdm_gui_close_func
    except ImportError:
        return None
    test_tqdm_gui_close_func(tqdm_gui)

# Generated at 2022-06-22 05:21:06.190085
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test that close method restores external environment.
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Save external environment
    wasion = plt.isinteractive()
    toolbar = mpl.rcParams['toolbar']
    # Test
    with tqdm(total=10, leave=False) as pbar:
        pbar.update(10)
        # Test environment
        assert (plt.isinteractive())
        assert (mpl.rcParams['toolbar'] == 'None')
    # Restored environment
    assert (plt.isinteractive() == wasion)
    assert (mpl.rcParams['toolbar'] == toolbar)

# Generated at 2022-06-22 05:21:11.259182
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_equal
    try:
        from matplotlib.testing.decorators import cleanup
        import matplotlib.pyplot as plt
    except ImportError:
        @cleanup
        def test_tqdm_gui_display():
            func()
    else:
        func()



# Generated at 2022-06-22 05:21:33.341902
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Testcase for class tqdm_gui"""
    import matplotlib.pyplot as plt
    t = tqdm_gui(total=150)
    for i in range(100):
        t.update()
    t.close()
    plt.show()

# Generated at 2022-06-22 05:21:37.214571
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    from tqdm.gui import tqdm
    for _ in tqdm(range(10), file=sys.stdout):
        pass

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:21:46.467954
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from platform import system
    from os import name
    from time import sleep

    if name == 'nt' and system() == 'Windows':
        warn("Skipping unit test for Windows platform!")
        return
    try:
        from matplotlib.pyplot import close as mpl_close
        for _ in tqdm(range(10), leave=True):
            sleep(0.1)
        mpl_close("all")
    except ImportError:
        warn("Skipping unit test! (matplotlib not installed)",
             TqdmExperimentalWarning, stacklevel=2)
        pass  # matplotlib not installed

# Generated at 2022-06-22 05:21:50.473158
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        with tqdm_gui(total=1000) as t:
            for i in t:
                _ = (i + 1) ** 2
            assert t.n == t.total
    finally:
        t._instances._remove(t)

# Generated at 2022-06-22 05:21:57.237074
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    trange(3).close()
    with trange(3) as t:
        for i in t:
            time.sleep(0.01)
    # Non-interactive mode
    with trange(3) as t:
        for i in t:
            time.sleep(0.01)
        t.close()
    # Leave axe (visible)
    with trange(3) as t:
        for i in t:
            time.sleep(0.01)
        t.close(leave=True)

# Generated at 2022-06-22 05:22:05.193989
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    plt.show()

    # Clear any previous figure
    plt.close("all")
    tq = tqdm_gui(total=100, leave=True)
    for i in range(101):
        tq.update(1)
        if i % 10 == 0 and i != 0:
            tq.set_postfix({"i": i})
        tq.display()
    plt.show()


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:22:14.972873
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Prepare test
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    my_tqdm = tqdm_gui(gui=True)
    # Test
    my_tqdm.close()
    # Check if tqdm_gui is disabled
    assert my_tqdm.disable
    # Check if mpl's toolbar is restored to its original status
    assert mpl.rcParams['toolbar'] == my_tqdm.toolbar
    # Check if matplotlib is in non-interactive mode
    assert not plt.isinteractive()
    # Check if the figure is closed
    assert my_tqdm.fig.number not in plt.get_fignums()


# Generated at 2022-06-22 05:22:17.691136
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10), desc='foobar'):
        sleep(0.1)


# Generated at 2022-06-22 05:22:27.997401
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .compatibility import unicode
    from .utils import _term_move_up

    inst = tqdm_gui(total=10)
    inst.display()
    assert unicode(inst) == '{0}\n10/10 [00:00<??:??, ?it/s]\n'.format(
        _term_move_up())
    inst.display()
    assert unicode(inst) == '{0}\n10/10 [00:00<??:??, ?it/s]\n{1}\n10/10 [00:00<00:00, ?it/s]\n'.format(
        _term_move_up(2),
        _term_move_up())
    inst.close()

# Generated at 2022-06-22 05:22:32.773346
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test `tqdm.gui.clear()` method"""
    # Issue #789
    t = tqdm(iterable=["1"], gui=True)
    t.clear()
    t.close()

# Avoid silent failure:
# raise error if matplotlib is not installed
try:
    import matplotlib
except ImportError:
    raise ImportError(
        "Please install matplotlib (pip install matplotlib)")