

# Generated at 2022-06-22 05:20:14.695311
# Unit test for function tgrange
def test_tgrange():
    """Unit test for tgrange()"""
    import sys
    try:
        import numpy as np
    except ImportError:
        np = None
    # Testing no iteration
    rng = tgrange(0)
    assert rng.gui is True  # should have gui set
    rng.close()
    # Testing no iteration
    rng = tgrange(0)
    rng.close()
    # Testing no iteration
    rng = tgrange(2)
    rng.update(1)
    rng.close()
    # Testing normal iteration
    rng = tgrange(10)
    for i in rng:
        assert isinstance(i, int)
        assert i == rng.n
    rng.close()

    # Testing unconvertable input iteration

# Generated at 2022-06-22 05:20:19.316768
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui"""
    import doctest
    import sys
    from .std import tqdm as orig_tqdm
    tqdm = tqdm_gui
    doctest.testmod(sys.modules[__name__])
    tqdm = orig_tqdm

# Generated at 2022-06-22 05:20:24.718640
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Create a dummy tqdm object
    tqdm_gui_clear_object = tqdm_gui()
    # Call the method
    tqdm_gui_clear_object.clear()
    # Remove the object
    del(tqdm_gui_clear_object)
    # Method has been called, no exception raised:
    # => test is passed
    return

# Generated at 2022-06-22 05:20:28.719416
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib.pyplot as plt
    import time
    for _ in trange(10):
        time.sleep(0.2)


if __name__ == "__main__":
    test_tgrange()
    plt.show()

# Generated at 2022-06-22 05:20:41.630612
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Tests the clear method of the tqdm_gui class using the same script
    that is used for the tqdm class
    """
    from time import sleep as time_sleep
    from random import random
    import warnings

    # with warnings.catch_warnings(record=True):
        # warnings.simplefilter("ignore")
        # t = tqdm_gui(total=100)
    #
    # for i in range(10):
    #     t.update(10)
    #     time_sleep(0.25 * random())
    # t.close()

    # with warnings.catch_warnings(record=True):
    #     warnings.simplefilter("ignore")
    #     t = tqdm_gui(total=100)
    #     for i in range(10):
    #         t.update(

# Generated at 2022-06-22 05:20:49.383825
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # unit test for tqdm_gui
    from matplotlib.testing.decorators import cleanup
    from time import sleep

    @cleanup
    def _test_tqdm_gui_cleanup():
        try:
            with tqdm_gui(total=10) as bar:
                sleep(0.1)
        except Exception as e:
            print('Error with tqdm_gui decorator:', e)
            raise
    _test_tqdm_gui_cleanup()

# Generated at 2022-06-22 05:20:54.996078
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm as std_tqdm
    from .std import tqdm_gui as std_tqdm_gui
    with std_tqdm_gui(100) as t:
        std_tqdm.clear()
    assert t.disable

# Generated at 2022-06-22 05:21:03.240475
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    sys.stdout.write('')  # flush
    from mpi4py import MPI
    rank = MPI.COMM_WORLD.Get_rank()
    if rank == 0:
        with tqdm_gui(total=5) as pbar:
            with pbar.clear():
                for i in range(5):
                    if i == 3:
                        pbar.clear()
                    pbar.update()
    MPI.Finalize()



# Generated at 2022-06-22 05:21:07.440246
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(desc='testing tqdm_gui.clear', total=10) as pbar:
        assert pbar.disable is False
        pbar.clear()
        pbar.close()
        assert pbar.disable is True


# Generated at 2022-06-22 05:21:19.672527
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np

    # Update title
    t = tqdm(total=10, desc="Cur")
    t.display()
    assert t.ax.get_title() == "Cur:   0%|          | 0/10 [00:00<?, ?it/s]"
    t.close()
    plt.close(t.fig)

    # Update current rate
    t = tqdm(total=10, desc="Cur", unit="it")
    t.update(4)
    t.display()
    np.testing.assert_array_equal(t.xdata, [4])
    np.testing.assert_array_equal(t.ydata, [4])
    t.close()