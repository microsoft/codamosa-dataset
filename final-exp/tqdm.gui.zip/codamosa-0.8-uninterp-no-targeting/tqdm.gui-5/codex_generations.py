

# Generated at 2022-06-22 05:20:01.331834
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    p = tqdm_gui(total=20)
    for i in _range(10):
        p.update(1)
    assert p.disable == False
    p.close()
    assert p.disable == True

# Generated at 2022-06-22 05:20:13.644772
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import freeze_support, format_sizeof, format_interval
    with freeze_support():  # pragma: no cover
        from multiprocessing import Pool

        # optional: testing with a mockup Tcl interpreter
        import sys as _sys
        if not _sys.platform.startswith("win"):
            import tkinter as tk
            Tcl = tk.Tcl()
            Tcl._counter = 0

            class MockupTcl(object):
                """Mockup class to replace methods of the Tcl interpreter.
                """

                def __init__(self):
                    """The constructor."""
                    self.eval = Tcl.eval

                def call(self, *args, **kw):
                    """Mock method for Tcl interpreter."""
                    Tcl._counter += 1

# Generated at 2022-06-22 05:20:18.678998
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import kivy
    import kivy.app
    app = kivy.app.App()
    grid = kivy.uix.gridlayout.GridLayout(rows=1)
    grid.add_widget(tqdm_gui(total=50))
    app.add_widget(grid)
    app.run()

# Generated at 2022-06-22 05:20:20.488406
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(4):
        sleep(0.1)


# Generated at 2022-06-22 05:20:32.471542
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    pbar = tqdm_gui(total=1000)
    plt.ion()
    x = np.linspace(-1, 1, 100)
    y = x ** 2
    z = x ** 3
    for i in range(100):
        pbar.update()
        pbar.xdata.append(x[i])
        pbar.ydata.append(y[i])
        pbar.zdata.append(z[i])
        pbar.line1.set_data(pbar.xdata, pbar.ydata)
        pbar.line2.set_data(pbar.xdata, pbar.zdata)
        pbar.plt.draw()
        pbar.plt

# Generated at 2022-06-22 05:20:38.878830
# Unit test for method close of class tqdm_gui

# Generated at 2022-06-22 05:20:47.784946
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        with tqdm_gui(total=10, leave=True) as t:
            for i in t:
                pass
    except Exception:
        from sys import stdout
        from .main import tqdm_gui  # XXX: should not need
        for i in tqdm_gui(total=10, leave=True, disable=True):
            stdout.write('\b=>'[i] * (i + 1))
            stdout.flush()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-22 05:20:53.853417
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    total = 1000
    with tgrange(1, total, unit='it',
                 unit_scale=True, desc='Testing GUI') as t:
        for i in t:
            sleep(0.01)
            if i == total - 1:
                break

# Generated at 2022-06-22 05:20:56.134505
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    # Just testing tgrange...
    for i in tgrange(4):
        for j in tqdm(tgrange(10)):
            sleep(0.01)

# Generated at 2022-06-22 05:21:09.136300
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test the method tqdm_gui.close()
    """
    try:
        from matplotlib.pyplot import subplots_adjust, close, isinteractive, ion, ioff
    except ImportError:
        from nose.plugins.skip import SkipTest
        raise SkipTest("matplotlib is required to run this test")

# Generated at 2022-06-22 05:21:28.096975
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm([])
    assert t.toolbar == 'None'
    assert t.wasion
    t.close()
    assert t.toolbar == 'toolbar2'
    assert not t.wasion
    t = tqdm([], disable=True)
    t.close()
    assert t.toolbar == 'toolbar2'
    assert not t.wasion

# Generated at 2022-06-22 05:21:40.354605
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    total = 400

# Generated at 2022-06-22 05:21:50.313321
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import warnings
    import matplotlib.pyplot as plt
    from tqdm import tqdm_gui

    warnings.filterwarnings('ignore')
    if not plt.isinteractive():
        plt.ion()

    # Discrete case
    with tqdm_gui(total=100, leave=False) as _t:
        for i in range(100):
            _t.update()
    # Continuous case
    with tqdm_gui() as _t:
        for i in range(100):
            _t.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-22 05:21:57.146029
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from nose.tools import raises
    from .std import tqdm
    from .utils import _range

    def get_legends():
        return [l.get_text() for l in t.ax.get_legend().get_texts()]

    t = tqdm(_range(200), desc="desc", unit_scale=False, unit='i')
    assert t.disable == False
    assert len(t) == 200
    assert t.miniters == 1
    assert t.mininterval == 0.5
    assert t.maxinterval == 10.0
    assert t._instances is tqdm._instances
    assert isinstance(t.gui, bool) and t.gui == True
    assert t.gui_rate_scale == 1.0
    assert t.gui_dynamic

# Generated at 2022-06-22 05:22:07.992866
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=2) as t:
        t.update()  # 1
        t.clear()
        assert t.n == 1
        t.update()  # 2
        t.clear()
        assert t.n == 1


if __name__ == "__main__":
    import sys
    import inspect
    import doctest

    if inspect.getmodule(inspect.currentframe()).__name__ == "__main__":
        doctest.testmod(sys.modules[__name__])

    # self test
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("requires matplotlib")
        sys.exit(0)

    with tgrange(1000) as t:  # pragma: no cover
        for i in t:
            pl

# Generated at 2022-06-22 05:22:13.039739
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    from nose.tools import assert_greater_equal

    with tqdm(tgrange(10), desc='test', leave=True) as t:
        for _ in t:
            sleep(0.01)

    assert_greater_equal(t.n, t.total)



# Generated at 2022-06-22 05:22:14.728733
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    with tqdm(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-22 05:22:25.095718
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    import os
    import matplotlib

    matplotlib.use("WXAgg")
    from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg
    from matplotlib.figure import Figure

    from tqdm._tqdm import tqdm
    from tqdm._tqdm_gui import tqdm_gui

    fig = Figure()
    canvas = FigureCanvasWxAgg(fig)

    def check_gui(*args, **kwargs):
        kwargs['total'] = 10
        with tqdm(*args, **kwargs, disable=False) as pbar:
            pbar.update()
        tqdm(*args, **kwargs)

    assert matplotlib.rcParams['toolbar'] == 'None'

    # Test simple usage
    tq

# Generated at 2022-06-22 05:22:29.294790
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from random import uniform

    t = tqdm_gui(total=100, leave=False)
    for _ in t:
        t.update()
        t.display()
        t.sleep(uniform(-0.1, 0.1))

# Generated at 2022-06-22 05:22:31.055474
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tgrange(100):
        pass

