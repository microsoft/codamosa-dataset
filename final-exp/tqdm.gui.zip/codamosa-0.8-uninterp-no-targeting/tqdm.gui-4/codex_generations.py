

# Generated at 2022-06-22 05:20:29.613099
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    list(tqdm_gui(tqdm_gui(["1", "2", "3"])))

    # check correct inheritance
    t = tqdm_gui(["1", "2", "3"])
    assert isinstance(t, std_tqdm)
    assert not isinstance(t, tqdm)
    assert isinstance(t, tqdm_gui)


if __name__ == "__main__":
    from time import sleep
    from itertools import chain

    # test example from https://github.com/tqdm
    # text = ""
    # for char in tqdm(["a", "b", "c", "d"]):
    #     sleep(0.25)
    #     text 

# Generated at 2022-06-22 05:20:33.159192
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pbar = tqdm_gui(total=10)
    for i in pbar:
        time.sleep(0.1)
        pbar.clear()


# Generated at 2022-06-22 05:20:38.648089
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt

    t = tqdm(total=1, leave=False)
    assert plt.fignum_exists(t.fig.number) is True
    t.close()

    # t = tqdm(total=1, leave=False)
    # assert plt.fignum_exists(t.fig.number) is True
    # t.close()


# Generated at 2022-06-22 05:20:42.767076
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .gui import tqdm_gui

    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.update()


# Unit tests for decorator tqdm_gui

# Generated at 2022-06-22 05:20:53.673742
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest import TestCase
    from collections import namedtuple

    class _TqdmGuiMock(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self._nums = args[0]
            super(_TqdmGuiMock, self).__init__(*args, **kwargs)

        def __iter__(self):
            for n in self._nums:
                yield n

    class _TqdmGuiTest(TestCase):
        def test_tqdm_gui_clear(self):
            Foo = namedtuple("Foo", "n")
            foos = [Foo(n) for n in range(10)]
            for f in _TqdmGuiMock(foos, mininterval=0):
                f

# Generated at 2022-06-22 05:20:58.890351
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt

    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    plt.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    t = tqdm_gui(range(3), leave=True, smoothing=0)
    for i in t:
        t.set_description(str(i))
    t.close()

    # Restore toolbars
    plt.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()

# Generated at 2022-06-22 05:21:02.102465
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from ._tqdm.gui import tqdm as gui_tqdm
    with gui_tqdm() as t:
        for i in t:
            t.clear()

# Generated at 2022-06-22 05:21:04.747202
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=100)
    t.n = 50
    t.close()


# Generated at 2022-06-22 05:21:11.722140
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Tests that tqdm_gui.close can be used without failing
    """
    with tqdm_gui(total=10) as t:
        t.close()


if __name__ == "__main__":  # pragma: no cover
    import time
    with tqdm(total=100) as t:
        for i in _range(100):
            t.update()
            time.sleep(0.01)

# Generated at 2022-06-22 05:21:23.435541
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import os
    import time

    # Define a dummy empty class for testing purposes
    class FakeTqdm(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self.disable = False
            self.total = 100
            self.n = 0
            self.pos = 0
            self.maxinterval = 0
            self.mininterval = 0
            self.mean_slower = 0.0
            self.mean_faster = 0.0
            self.values = [0, 0]
            self.last_print_t = 0.0
            self.last_print_n = 0
            self.last_print_values = [0, 0]
            self.unit_scale = 1
            self.unit = "it"
            self.leave

# Generated at 2022-06-22 05:21:49.004515
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for class tqdm_gui
    """
    from .utils import format_sizeof, format_interval
    from .std import tqdm_gui
    import matplotlib.pyplot as plt
    import sys

    # Smoke test
    with tqdm_gui(total=100, file=sys.stderr) as pbar:
        for _ in range(100):
            pbar.update()
        pbar.close()

    # Regression tests
    assert str(tqdm_gui(total=None)) == "100%|##########|"
    assert str(tqdm_gui(total=0)) == "100%|##########|"

# Generated at 2022-06-22 05:21:53.750590
# Unit test for function tgrange
def test_tgrange():
    from time import sleep

    with tgrange(10) as trange_instance:
        for i in trange_instance:
            sleep(0.2)



# Generated at 2022-06-22 05:22:05.950155
# Unit test for function tgrange
def test_tgrange():
    """Unit test for function tgrange."""
    # pylint: disable=protected-access
    from time import sleep
    from numpy.random import random
    for _ in tgrange(4, desc='1st loop'):
        for _ in tgrange(5, desc='2nd loop', leave=True):
            for _ in tgrange(50):
                sleep(0.01)
                if random() < 0.1:
                    tqdm.write("error")
            x = random()  # noqa
            if random() < 0.2:
                break
        else:
            continue  # this gets executed if the inner loop did NOT break
        break  # this gets executed if the inner loop DID break
    tgrange(range(100), desc="hello")._instances[0]._gui._close()




# Generated at 2022-06-22 05:22:16.659967
# Unit test for function tgrange
def test_tgrange():
    import sys
    import os
    import time
    import multiprocessing
    from multiprocessing import Queue

    BAR_FORMAT = "[{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]"

    def f(q):
        for i in tgrange(100, desc='Loading...'):
            time.sleep(0.01)
            q.put(i)

    q = Queue()
    p = multiprocessing.Process(target=f, args=(q,))
    p.start()
    for i in tgrange(100, desc='Testing...'):
        time.sleep(0.01)
        j = q.get()
        assert i == j, (i, j)
    p.join()

    sys

# Generated at 2022-06-22 05:22:21.177882
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    pbar = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.1)
        pbar.update(1)
        assert pbar.n == i + 1
    pbar.close()


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui_display()  # pragma: no cover

# Generated at 2022-06-22 05:22:33.053854
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import os
    import sys
    import time

    # Check if the environment is clean
    try:
        assert os.environ['TQDM_GUI'] == 'off'
    except:
        pass
    try:
        assert os.environ['TQDM_GUI'] == 'on'
    except:
        pass
    os.environ['TQDM_GUI'] = 'on'
    try:
        assert os.environ['TQDM_GUI'] == 'on'
        print("Test environment is OK")
    except:
        print("Test environment is NOT OK")
        sys.exit(-1)

    # Check if tgrange behaves well
    tgrange(5)
    time.sleep(0.5)
    tgrange(5, desc='i')

# Generated at 2022-06-22 05:22:36.349580
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui([])
    t.n = 10
    t.clear()
    assert t.n == 10, "Clear should not reset n"

# Generated at 2022-06-22 05:22:39.341271
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import TestTqdmExperimentalWarning
    from tqdm.gui import trange
    with TestTqdmExperimentalWarning():
        for _ in trange(10):
            pass

# Generated at 2022-06-22 05:22:47.123433
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=None)
    assert t.gui
    assert t.disable == False
    assert t.mininterval == 0.5
    assert t.toolbar == t.mpl.rcParams['toolbar']
    assert t.wasion == t.plt.isinteractive()
    t.close()
    assert t.disable == True
    assert t.mpl.rcParams['toolbar'] == t.toolbar
    assert t.plt.isinteractive() == t.wasion
    assert t not in t._instances

# Generated at 2022-06-22 05:22:57.316810
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from operator import add

    assert list(tgrange(10)) == list(_range(10))
    assert list(tgrange(10, 20)) == list(_range(10, 20))
    assert list(tgrange(10, 20, 2)) == list(_range(10, 20, 2))
    assert list(tgrange(0, 1, 0.2)) == list(_range(0, 1, 0.2))
    assert list(tgrange(0, 10, 0.01)) == list(_range(0, 10, 0.01))
    assert list(tgrange(0, 1, 0.2, 1)) == list(_range(0, 1, 0.2))