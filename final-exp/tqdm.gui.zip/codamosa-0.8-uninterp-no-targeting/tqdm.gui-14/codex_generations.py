

# Generated at 2022-06-22 05:20:20.443718
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return
    try:
        with tqdm_gui(total=2, mininterval=0.5) as t:
            t.n = 1
            t.display()
    except Exception as e:
        import traceback
        print('Traceback (most recent call last):\n{}'.format(
            "".join(traceback.format_tb(e.__traceback__))))
        raise
    try:
        mpl.rcParams['toolbar'] = 'None'
        with tqdm_gui(total=2, mininterval=0.5) as t:
            t.n = 1
            t.display()
    except Exception as e:
        import traceback

# Generated at 2022-06-22 05:20:27.209976
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():

    t = tqdm_gui(total=5)
    assert not t.disable
    t.close()
    assert t.disable
    assert t.__class__.close.__name__ == 'close'
    assert t.__class__.close.__doc__ == '\n        Clean up and remove instance from internal list.\n        '
    assert t.__class__.close.__module__ == 'tqdm.gui'

# Generated at 2022-06-22 05:20:36.276737
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm
    from time import sleep

    # Empty bar
    t = tqdm_gui()
    t.close()

    # Set max value
    t = tqdm_gui(10)
    t.close()

    # Manual update
    t = tqdm_gui(0)
    t.n = 10
    t.close()
    t = tqdm_gui(10)
    t.n = 0
    t.close()

    # Manual iteration
    t = tqdm_gui(3)
    t.update()
    t.update()
    t.update()
    t.close()

    # Iterable
    for c in tqdm_gui([1, 2, 3]):
        pass
    t = tqdm_gui([1, 2, 3])
   

# Generated at 2022-06-22 05:20:41.753823
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tgrange(4, 1, -1):
        pass
    for _ in tgrange(4, 1, -1, unit_scale=True):
        pass


if __name__ == '__main__':
    import doctest
    print(doctest.testmod(verbose=True).failed)

# Generated at 2022-06-22 05:20:47.345385
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # pylint: disable=global-statement
    global tqdm  # Work around for Travis CI
    # Initialize tqdm_gui
    tqdm_gui.clear(tqdm)
    # Restore tqdm
    from .std import tqdm as std_tqdm
    tqdm = std_tqdm

# Generated at 2022-06-22 05:20:54.106138
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    t = tqdm_gui(100, mininterval=1, miniters=100)
    for x in t:
        t.miniters = 0
        t.update()
        pass
    t.close()


if __name__ == '__main__':  # pragma: no cover
    # from time import sleep
    test_tqdm_gui()

# Generated at 2022-06-22 05:20:59.271312
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return
    mpl.use('Agg')  # fix pytest-mpl plugin bug
    from .gui import tqdm
    from .utils import _range
    from .std import _supports_unicode

    for k in [1, 10, 100]:
        for leave in [True, False]:
            for ascii_ in [True, False]:
                with tqdm(_range(k), desc='tqdm', leave=leave,
                          disable=False, mininterval=0, ascii=ascii_) as t:
                    t.update(1)
                    t.clear()



# Generated at 2022-06-22 05:21:02.940340
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    unit testing for method clear of class tqdm_gui
    """
    import pytest
    # pytest.raise()
    # pytest.skip()
    # pytest.fail()



# Generated at 2022-06-22 05:21:07.560475
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Unit test for constructor of class tqdm_gui"""
    if __name__ != "__main__":
        ignore = ("display", "clear", "close", "pause", "to_window_title")
        for k in vars(tqdm_gui).keys():
            if k not in ignore:
                assert getattr(tqdm, k) != getattr(std_tqdm, k)
    with tqdm(total=10) as t:
        for i in _range(10):
            t.update()
        t.disable = True


test_tqdm_gui()

# Generated at 2022-06-22 05:21:12.890707
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt
    with tqdm_gui(total=10) as t:
        for i in t:
            t.set_postfix_str("{}, {}".format(i, i**2))
    plt.show()

# Generated at 2022-06-22 05:21:39.596561
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    try:
        from pytest import mark
        mark.gui
        import matplotlib
    except ImportError:
        pass
    else:
        t = trange(5)
        t.disable = False

        assert(matplotlib.rcParams['toolbar'] == 'None')
        t.close()
        assert(matplotlib.rcParams['toolbar'] != 'None')
        assert(t.disable)

# Generated at 2022-06-22 05:21:51.728696
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from numpy import isnan

    t = tqdm_gui(total=10)
    t.display()
    assert len(t.xdata) == 1
    assert len(t.ydata) == 1
    assert len(t.zdata) == 1
    assert isnan(t.xdata[0])
    assert isnan(t.ydata[0])
    assert isnan(t.zdata[0])

    t.update(1)
    t.display()
    assert len(t.xdata) == 2
    assert len(t.ydata) == 2
    assert len(t.zdata) == 2
    assert isnan(t.xdata[0])
    assert isnan(t.ydata[0])
   

# Generated at 2022-06-22 05:21:55.851170
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import gui
    gui.trange(3).close()
    gui.tqdm(3).close()
    gui.tqdm(xrange(3)).close()
    gui.tqdm(list(range(3))).close()
    gui.tqdm(dict(enumerate(range(3)))).close()

# Generated at 2022-06-22 05:21:59.613181
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=10)
    t.close()
    t = tqdm_gui(total=10)
    t.disable = True
    t.close()


# Generated at 2022-06-22 05:22:10.436732
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import sys
    import matplotlib.pyplot as plt

    def state():
        return repr((t.xdata, t.ydata, t.zdata, t.hspan.get_xy(), t.ax.get_xlim()))
    t = tqdm_gui(total=100, leave=True)
    t.display()
    s0 = state()
    t.display()
    assert(s0 == state())
    sys.stdout.write('Test tqdm_gui.display passed\n')
    sys.stdout.flush()
    t.close()
    plt.close('all')


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:22:12.281281
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # method clear of class tqdm_gui
    # should do nothing
    pass

# Generated at 2022-06-22 05:22:18.597816
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test method close of class tqdm_gui"""
    from .autonotebook import tqdm

    with tqdm(5, desc="test_tqdm_gui_close", leave=True) as t:
        for i in t:
            t.clear()
        assert t.disable
        assert t.mpl.rcParams['toolbar'] == 'toolbar2'
        assert not t.plt.isinteractive()

# Generated at 2022-06-22 05:22:29.025564
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test case for method close of class tqdm_gui"""
    import pytest
    from matplotlib.pyplot import plot, pause, close
    t = tqdm_gui(total=10)
    # plot
    p = plot(t)
    pause(0.1)
    with pytest.raises(PyCallGraphException):
        # this case should raise a PyCallGraphException
        t.close()
    # close
    close()
    # test close without bar
    t = tqdm_gui(total=10, leave=True)
    with pytest.raises(PyCallGraphException):
        # this case should raise a PyCallGraphException
        t.close()
    pytest.fail("method close of class tqdm_gui tested")


# Generated at 2022-06-22 05:22:38.127332
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for method close of class tqdm_gui
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    args = {
        'total' : 2
    }
    kwargs = {
        'disable' : False,
        'gui' : True
    }
    tqdm_gui_close_instance = tqdm_gui(**args, **kwargs)
    tqdm_gui_close_instance.close()
    # Test if the instance which should be closed is successfully closed
    assert tqdm_gui_close_instance.disable == True
    assert tqdm_gui_close_instance.wasion == plt.isinteractive()
    # Test if the last print is successfully closed
    assert mpl.rcParams['toolbar'] == 'None'

# Generated at 2022-06-22 05:22:48.828035
# Unit test for function tgrange
def test_tgrange():
    """Unit test for function tgrange."""
    from unittest import TestCase
    from tqdm.contrib import bcolors as bc
    from tqdm.contrib.test_examples import TestExample

    class TestTqdm(TestExample, TestCase):
        """Unit test for class tqdm."""
        tgrange = staticmethod(tgrange)
        example = TestExample.tgrange

    TestTqdm().run_tqdm_tests(__name__, _range=_range,
                              bcolors=bc,
                              total=False)

