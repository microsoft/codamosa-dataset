

# Generated at 2022-06-22 05:20:14.346383
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for `tqdm.gui.tqdm_gui.clear`"""
    bar1 = tqdm_gui(["a", "b", "c"])
    bar2 = tqdm_gui("def", position=1)
    bar1.clear()
    t = bar2.format_dict['elapsed']
    bar2.clear()
    assert bar1.format_dict['bar_format'] == bar2.format_dict['bar_format']
    assert bar2.format_dict['elapsed'] == t
    for i in range(4):
        bar1.update(1)
        bar2.update()
        assert bar1.format_dict['bar_format'] == bar2.format_dict['bar_format']
        assert bar2.format_dict['elapsed'] == t

# Generated at 2022-06-22 05:20:17.790894
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmDeprecationWarning

    with warnings.catch_warnings(record=True):
        x = tqdm_gui(range(3))
        x.clear()



# Generated at 2022-06-22 05:20:24.768215
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    # Test that tqdm_gui works
    g = tqdm_gui(total=5, leave=False)
    g.update(1)
    g.reset()
    # Test that tqdm_gui can be closed
    g.close()

if __name__ == '__main__':
    import sys
    import time
    for _ in tgrange(10):
        time.sleep(0.5)
    sys.exit(test_tqdm_gui_close())

# Generated at 2022-06-22 05:20:27.633548
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4, desc="Test tgrange"):
        sleep(1)

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-22 05:20:32.319296
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit tests for class tqdm_gui"""
    import matplotlib.pyplot as plt

    t = tqdm_gui(range(10))
    t.clear()

    assert t.ax == plt.gca()

    plt.close()

# Generated at 2022-06-22 05:20:34.834755
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    for i in tgrange(10):
        tgrange(5)

# Generated at 2022-06-22 05:20:47.121749
# Unit test for constructor of class tqdm_gui

# Generated at 2022-06-22 05:20:57.734473
# Unit test for function tgrange
def test_tgrange():
    l = tgrange(5)
    for _ in l:
        pass
    assert l.n == 5


if __name__ == "__main__":
    from time import sleep
    # print("Running a test demo of the GUI version...")
    t = tqdm_gui(range(300),
                 desc='1st loop', ascii=False, dynamic_ncols=True,
                 unit='it')
    for i in t:
        # Print using tqdm class method .write()
        t.write("Done %d iterations" % i)
        sleep(0.01)
    t.close()

    # Test resetting
    l = tqdm_gui(total=300)
    for i in range(100):
        l.update(1)
        sleep(0.01)

# Generated at 2022-06-22 05:21:08.961465
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm
    prev_t = t = 0
    pbar = tqdm(total=210)
    for _ in range(10):
        pbar.update()
        # from time import sleep
        # sleep(0.120)  # test maxinterval
        # pbar.display()  # test window resize
        t = pbar._time()
        assert (t - prev_t) <= pbar.mininterval + .05
        prev_t = t


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in tqdm(range(15)):
        sleep(.8)

# Generated at 2022-06-22 05:21:13.311371
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import time
    import numpy as np
    x = tqdm_gui(np.arange(100), mininterval=0)
    for _ in x:
        time.sleep(0.1)
        x.display()