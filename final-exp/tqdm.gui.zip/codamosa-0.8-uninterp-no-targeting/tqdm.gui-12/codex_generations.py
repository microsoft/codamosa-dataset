

# Generated at 2022-06-22 05:20:13.916133
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    pbar = tqdm_gui(total=100)
    for i in range(10):
        pbar.update(10)
        plt.pause(0.001)
    plt.close(pbar.fig)
    return

# Generated at 2022-06-22 05:20:20.125286
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .gui import trange
    from time import sleep
    for i in trange(3,  # show default pos
                    desc='1st loop',
                    leave=True):
        for j in trange(25, desc='2nd loop', leave=True, miniters=1):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
    print('loop ended')

# Generated at 2022-06-22 05:20:32.240105
# Unit test for function tgrange
def test_tgrange():
    from os import remove
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from .utils import FormatTest
    from .utils import suppress_stdout
    with suppress_stdout():
        for desc in ('', 'desc', 'foobar'):
            for n in (-10, 0, 1, 2, 10):
                with FormatTest(desc, n) as t:
                    for i in tgrange(n):
                        t()
                    with tqdm(total=n) as t:
                        for i in tgrange():
                            t()
                            if t.n >= n:
                                break

# Generated at 2022-06-22 05:20:43.482251
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .utils import format_sizeof
    from time import sleep as time_sleep
    from math import log as math_log
    for i in tqdm_gui(iterable=range(1, 10), total=10, mininterval=0.01,
                      desc='test clear on GUI', unit='B', unit_scale=True):
        time_sleep(i / 10)
        tqdm_gui.clear()
        tqdm_gui.write(format_sizeof(10 ** math_log(i, 2), unit='B'))


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:20:47.516320
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm
    from time import sleep
    for i in tqdm(range(1000)):
        sleep(0.0001)
    for i in tqdm(range(1000)):
        sleep(0.0001)

# Generated at 2022-06-22 05:20:54.648895
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib
    matplotlib.use('Agg')
    with tqdm(total=None) as pbar:
        import time
        pbar.update(1)
        time.sleep(0.02)
        pbar.clear()
        for i in range(4):
            time.sleep(0.02)
            pbar.update(1)
    assert len(pbar.xdata) == 5

# Generated at 2022-06-22 05:20:55.842926
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    bar = tqdm_gui(unit="i", leave=False)
    bar.close()

# Generated at 2022-06-22 05:21:00.986478
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from sys import version_info
    py3 = version_info[0] >= 3
    for _ in tgrange(2, leave=py3):
        for i in tgrange(2, leave=py3):
            sleep(.1)

# Generated at 2022-06-22 05:21:10.399881
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Unit test for method clear of class tqdm_gui"""
    from sys import version_info, stderr
    # Mocking
    std_tqdm.clear = lambda *args, **kwargs: None
    if version_info[0] == 2:
        tqdm_gui.xrange = xrange
    else:
        tqdm_gui.xrange = range
    # Unit test
    with tqdm_gui(total=7, file=stderr) as pbar:
        assert isinstance(pbar, tqdm_gui)
        pbar.clear()

# Generated at 2022-06-22 05:21:22.379482
# Unit test for method display of class tqdm_gui

# Generated at 2022-06-22 05:22:07.380576
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    import matplotlib.pyplot as plt

    t = tqdm(total=20)
    for i in t:
        sleep(1)
        t.display()

    t = tqdm(total=20)
    for i in t:
        sleep(1)
        t.display()
    t.close()
    plt.close()

    t = tqdm(total=20, leave=True)
    for i in t:
        sleep(1)
        t.display()
    t.close()
    plt.close()


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-22 05:22:18.399169
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=100) as t:
        for i in _range(100):
            t.update()


if __name__ == '__main__':
    from time import sleep
    from random import randint
    # In Python2, `range` does not support `float`
    for i in tqdm_gui(xrange(100), ascii=True):
        sleep(0.01)
    for i in trange(50, desc='1st loop'):
        sleep(0.01)
    for i in trange(10, desc='2nd loop'):
        for j in trange(5, desc='2nd loop, set %d' % j, leave=False):
            sleep(0.01)

# Generated at 2022-06-22 05:22:29.167516
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .std import tqdm
    import matplotlib.pyplot as plt
    import sys
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    if len(sys.argv) > 2:
        plt.interactive(True)
        if sys.stdout.isatty():
            sys.stdout.write("\x1b[?25l")
        try:
            for _ in tgrange(n, leave=False, disable=False):
                plt.pause(0.001)
        finally:
            if sys.stdout.isatty():
                sys.stdout.write("\x1b[?25h")
    else:
        for _ in tgrange(n):
            pass


# Generated at 2022-06-22 05:22:31.159118
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for n in tqdm(range(10)):
        if n % 3 == 0:
            tqdm.clear()
    pass


# Generated at 2022-06-22 05:22:34.750565
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import sys
    from .utils import _range
    from .std import tqdm_gui, tqdm
    for t in (tqdm_gui, tqdm):
        for i in t(_range(10)):
            t.clear()

# Generated at 2022-06-22 05:22:40.759113
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from contextlib import closing
    from tqdm.auto import trange
    import sys
    import time

    with closing(trange(1, ascii=True, dynamic_ncols=True)) as t:
        for i in t:
            sys.stdout.write("\r\r")  # fake rendering of progressbar
            time.sleep(0.1)
##################################################################

# Generated at 2022-06-22 05:22:46.456748
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    pbar = tqdm_gui(total=3)
    pbar.refresh(n=0)
    pbar.refresh(n=1)
    pbar.refresh(n=2)
    pbar.refresh(n=3)
    pbar.close()
    print("OK")


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:22:56.281992
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import types
    from io import StringIO
    from contextlib import contextmanager
    # we have to mock the `write` method
    @contextmanager
    def _mock_stdout():
        stdout = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout
        sys.stdout = stdout
    if six.PY3:
        unicode_ = str
    else:
        unicode_ = unicode
    # We change the stdout to mock it (it's what we want to test)

# Generated at 2022-06-22 05:23:06.977071
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import numpy as np
    import matplotlib.pyplot as plt

    # Create fake tqdm_gui instance
    t = type(std_tqdm())()
    t.mininterval = 0.5
    t.disable = False
    t.last_print_n = -1
    t.last_print_t = -1
    t.start_t = -1
    t.total = None
    t.n = 0
    t._time = None
    t.disable = True
    t.leave = True
    t.unit = "it"
    t.unit_scale = True
    t.format_dict = {}
    t.mpl = plt
    t.plt = plt
    t.toolbar = False
    t.fig, ax = plt

# Generated at 2022-06-22 05:23:13.881598
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Test function tgrange."""
    from os import devnull
    # Just test it runs
    with open(devnull, 'w') as null:
        # Can't directly assert on `tgrange` as it's a generator
        assert sum(tgrange(1000, file=null)) == sum(xrange(1000))
        assert sum(tgrange(1000, disable=True)) == sum(xrange(1000))