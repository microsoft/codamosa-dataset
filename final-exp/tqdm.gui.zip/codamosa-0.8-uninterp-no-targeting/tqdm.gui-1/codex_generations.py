

# Generated at 2022-06-22 05:20:22.594195
# Unit test for function tgrange
def test_tgrange():
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange

    # Check that tgrange is _range based
    assert (std_tqdm(tgrange(5)) ==
            std_tqdm(std_trange(5)))
    assert (std_tqdm(tgrange(5, 10)) ==
            std_tqdm(std_trange(5, 10)))
    assert (std_tqdm(tgrange(5, 10, 2)) ==
            std_tqdm(std_trange(5, 10, 2)))

    # Check that tgrange is tqdm based
    assert (tgrange(5, desc="tgrange") ==
            std_tqdm(std_trange(5), desc="tgrange"))


# Generated at 2022-06-22 05:20:29.093515
# Unit test for function tgrange
def test_tgrange():
    import sys
    from .gui import tgrange
    from .gui import trange
    from .gui import tqdm
    for func in [tgrange, trange, tqdm]:
        for n in func(sys.maxsize, desc="test_tgrange()"):
            break
        else:
            raise ValueError("Loop didn't break")

# Generated at 2022-06-22 05:20:39.025854
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    tqdm_gui.close() should restore toolbars and non-interactive mode if
    external environment is not interactive on __init__().
    """
    import matplotlib as mpl
    mpl.rcParams['toolbar'] = 'toolbar'

    wasion = mpl.is_interactive()
    if wasion:
        mpl.interactive(False)
    tqdm_gui().close()
    assert mpl.rcParams['toolbar'] == 'toolbar'
    assert not mpl.is_interactive() == wasion
    mpl.interactive(wasion)

# Generated at 2022-06-22 05:20:46.146542
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep

    for _ in tqdm([1], desc="1 loop"):
        for _ in tqdm([1, 2], desc="2 loops"):
            for _ in tqdm([1, 2, 3], desc="3 loops"):
                sleep(0.01)

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-22 05:20:56.074423
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with open('tqdm/_tqdm.py', 'r') as f:
        txt = f.read()
    txt = re.sub(r'(\r|\n)+', '\n', txt)
    txt = re.sub(r'#.+$', '', txt, flags=re.M)
    txt = re.sub(r'class .+\n', '', txt)
    txt = re.sub(r'_tqdm\(.+\)$', '', txt)

    txt = txt.split('def display(')[1]
    txt = 'def display(n, elapsed, delta_it, delta_t, cur_t, total, xmin, xmax, ' + txt

# Generated at 2022-06-22 05:21:00.787358
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from random import random
    from numpy.random import rand
    a = []
    for i in trange(5):
        sleep(0.3)
        a.append(i + random())



# Generated at 2022-06-22 05:21:13.425455
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from collections import deque
    # Inline due to multiple calls
    self = tqdm_gui()
    n = self.n
    cur_t = self._time()
    elapsed = cur_t - self.start_t
    delta_it = n - self.last_print_n
    delta_t = cur_t - self.last_print_t

    total = self.total
    xdata = self.xdata
    ydata = self.ydata
    zdata = self.zdata
    ax = self.ax
    line1 = self.line1
    line2 = self.line2
    # instantaneous rate
    y = delta_it / delta_t
    # overall rate
    z = n / elapsed
    # update

# Generated at 2022-06-22 05:21:17.837569
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test whether an error appears when calling close() function.
    """
    with tqdm(total=1, bar_format='{bar}') as t:
        assert t.disable == False
        t.update()
        t.close()
        assert t.disable == True

# Generated at 2022-06-22 05:21:24.397835
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest import mock
    except ImportError:
        from mock import patch as mock  # noqa: F811

    t = tqdm_gui([], disable=True)
    with mock.patch('matplotlib.pyplot.pause') as mock_pause:
        t.clear()
    mock_pause.assert_called_with(0.001)
    t.write('foo')
    t.clear()
    assert t.desc == ''
    t.close()



# Generated at 2022-06-22 05:21:26.937531
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_raises
    with assert_raises(NotImplementedError):
        tqdm_gui().clear()

# Generated at 2022-06-22 05:21:54.013510
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from sys import version_info as ver
    # Test for python 2 or 3 with python-future
    if ver[0] == 2 or (ver[0] == 3 and ver[1] > 3):
        from future.tests.base import unittest
        from unittest import TestCase
    else:
        import unittest
        TestCase = unittest.TestCase

    class TestTqdmGUI(TestCase):
        """Test tqdm GUI display method."""

        def _test_tqdm_gui_display_test(self, a, b, c):
            """Run tqdm_gui in main test function."""
            import matplotlib.pyplot as plt
            plt.ion()
            self.cpt = 0

# Generated at 2022-06-22 05:22:00.208292
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    x = tqdm_gui(disable=True)  # create a tqdm_gui object
    x.disable = False  # enable the object
    try:
        x.close()
    except Exception:
        assert False, "Exception while closing tqdm_gui object"
    else:
        assert x.disable, "tqdm_gui object should be disabled"


# Generated at 2022-06-22 05:22:04.948320
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    tqdm_gui(tgrange(3), "test_tgrange", leave=True, ncols=50)


if __name__ == '__main__':  # pragma: no cover
    test_tgrange()


# test for close() method

# Generated at 2022-06-22 05:22:05.999095
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass



# Generated at 2022-06-22 05:22:17.300145
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    xdata = np.arange(0, 1, 0.05)
    xdata = np.asarray(list(xdata) + [1])
    xdata *= 0.01
    ydata = xdata * xdata
    xdata += 0.3
    ydata += 0.3
    ydata = np.asarray(list(ydata) + [1])
    xdata += 0.3
    ydata += 0.3
    p = tqdm_gui(total=len(xdata))
    for x, y in zip(xdata, ydata):
        p.update()
        p.xdata.append(x)
        p.ydata.append(y)
    p.display()


# Generated at 2022-06-22 05:22:28.342921
# Unit test for function tgrange
def test_tgrange():
    try:
        from tqdm._utils import _term_move_up
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return

    # Mock out stdout
    with open(__file__, 'rb') as f:
        stdout = f.read().decode('utf-8')
    save_stdout = sys.stdout
    sys.stdout = stdout

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()


# Generated at 2022-06-22 05:22:34.065344
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    import matplotlib.pyplot as plt

    t = tqdm_gui(total=10, mininterval=0.5)
    for i in t:
        sleep(0.3)
        plt.pause(1e-9)
    t.close()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-22 05:22:40.375673
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .utils import _range
    from time import sleep

    with tqdm(total=10) as pbar:
        for i in _range(11):  # loop 11 times
            sleep(0.1)
            pbar.update()
            pbar.clear()
            pbar.refresh()
            pbar.close()
            pbar.write("hello")

# Generated at 2022-06-22 05:22:46.802919
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy import random
    from collections import deque
    from numpy import sum
    from numpy import linspace
    for n in [10, None]:
        with tqdm(total=n, mininterval=0.5) as pbar:
            for i in linspace(0, n-1, n):
                sleep(0.1)
                pbar.update(1)
                # pbar.clear()


# Generated at 2022-06-22 05:22:57.082937
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from contextlib import contextmanager
    from matplotlib.testing.decorators import image_comparison
    import matplotlib.pylab as plt

    @image_comparison(baseline_images=['test_gui_display'], extensions=['png'])
    def doit():
        import matplotlib.pylab as plt
        import numpy as np

        with tqdm_gui(total=100) as pbar:
            for x in plt.frange(0, 10, 0.01):
                y = np.sin(x)
                pbar.update(1)
                pbar.set_description('x={x:.2f}, y={y:.2f}'.format(x=x, y=y))

# Generated at 2022-06-22 05:23:20.087543
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test of tqdm_gui.close"""
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    orig_toolbar = mpl.rcParams['toolbar']
    orig_isinteractive = plt.isinteractive()

    with tqdm_gui(total=10) as t:
        for i in range(11):
            t.update()

    assert mpl.rcParams['toolbar'] == orig_toolbar
    assert plt.isinteractive() == orig_isinteractive

# Generated at 2022-06-22 05:23:25.384438
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test function tqdm_gui"""
    try:
        import matplotlib
        matplotlib.use('TkAgg')
    except ImportError:
        return None

    with tqdm(total=30) as pbar:
        for i in range(30):
            pbar.update(1)
            pbar.clear()

# Generated at 2022-06-22 05:23:28.839806
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for _ in tqdm_gui(range(0)):
        pass

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-22 05:23:32.951138
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import warnings
    warnings.resetwarnings()
    warnings.simplefilter('ignore')
    t = tqdm_gui(100)
    assert t.n == 0
    t.update(10)
    t.close()
    assert t.n == 10

# Generated at 2022-06-22 05:23:44.683804
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange

    for i in tqdm_gui(xrange(100)):
        pass
    for i in std_tqdm(xrange(100)):
        pass
    tqdm([])
    tqdm(iter([1, 2, 3]))
    tqdm(iter([]))
    tqdm(iter([1, 2, 3]), desc="custom")

    # test trange
    for i in trange(100):
        pass
    for i in std_trange(100):
        pass
    trange([])
    trange(iter([1, 2, 3]))
    trange(iter([]))

# Generated at 2022-06-22 05:23:55.868715
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import sys
    from tqdm.gui import trange
    from tqdm.auto import tqdm

    # Check if matplotlib is installed
    if os.name == 'posix' and sys.version_info[0] < 3:
        try:
            import subprocess32 as subprocess  # pip install subprocess32
        except ImportError:
            import subprocess
        try:
            import matplotlib
        except ImportError:
            missing = subprocess.check_output(
                ['python', '-c', 'import sys;'
                 ' print(sys.executable);'
                 ' import matplotlib']).decode().strip()

# Generated at 2022-06-22 05:24:06.679843
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib
        matplotlib.use('Agg')
    except ImportError:
        return
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup
    t = tqdm_gui(total=10)
    t.update()
    assert(t.xdata == [0])
    assert(t.ydata == [0])
    assert(t.zdata == [0])
    t.display()
    assert(t.xdata == [0])
    assert(t.ydata == [0])
    assert(t.zdata == [0])
    t.update()
    assert(t.xdata == [0])
    assert(t.ydata == [1])
    assert(t.zdata == [0.1])
    t

# Generated at 2022-06-22 05:24:12.052561
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from random import random
    from numpy import ceil

    for _ in tqdm(range(10)):
        sleep(random())


if __name__ == '__main__':
    test_tqdm_gui_clear()  # pragma: no cover

# Generated at 2022-06-22 05:24:21.932770
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib import rcParams
    from matplotlib.pyplot import ion, isinteractive

    ion()
    gui = tqdm()
    gui_toolbar = rcParams['toolbar']

    gui.disable = False
    gui._instances = [gui]
    gui.start_t = gui._time()
    gui.last_print_t = gui._time()
    gui.n = 0
    gui.last_print_n = 0
    gui.leave = True
    gui.disable = False
    gui.total = 100
    gui.mininterval = 0.5
    gui.unit = None
    gui.unit_scale = True
    gui.unit_divisor = 1000
    gui.dynamic_ncols = True

    gui.close()

# Generated at 2022-06-22 05:24:23.327562
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(1000):
        if i > 100:
            break