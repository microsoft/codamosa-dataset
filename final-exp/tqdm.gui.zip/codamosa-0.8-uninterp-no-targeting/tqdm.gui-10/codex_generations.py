

# Generated at 2022-06-22 05:19:58.089922
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        with tqdm_gui(total = 100, gui = True) as t:
            for i in range(100):
                t.clear()
    except AttributeError:
        print("Error: method clear of class tqdm_gui is not correctly implemented")


# Generated at 2022-06-22 05:20:01.979921
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep

    for n in tqdm_gui(range(1, 9), desc='test', ncols=80):
        sleep(0.25)

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:20:14.193715
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import freeze_support, format_interval
    from .std import TotalTimeUnknownError
    from .std import TqdmDeprecationWarning, TqdmExperimentalWarning

    try:
        from sys import _getframe
    except ImportError:
        # For Python2 or IronPython
        def _getframe(count):
            """Return a frame object from the call stack.

            back is the number of frames to go back.
            returns None if no frame is available.
            """
            # borrowed from traceback.py
            try:
                f = sys._getframe(count)  # pylint: disable=protected-access
                while f.f_globals.get('__name__', '') == __name__:
                    f = f.f_back
                return f
            except ValueError:
                return None



# Generated at 2022-06-22 05:20:21.190750
# Unit test for function tgrange
def test_tgrange():
    # test auto-scale
    tqdm_gui(tgrange(100))

    # test hook
    hook = lambda *a, **k: None
    for i in tgrange(10, hook=hook):
        pass
    hook = lambda *a, **k: None
    tgrange(10, hook=hook)

    # test auto-close
    tgrange(5)
    tgrange(5, leave=True)
    tgrange(5, leave=False)

test_tgrange()

# Generated at 2022-06-22 05:20:33.049658
# Unit test for function tgrange
def test_tgrange():
    from sys import version_info
    from time import sleep
    from .utils import format_dict
    # Avoid displaying "Using matplotlib backend: ..." message
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import matplotlib as mpl
        mpl.use('Agg')

    def time_gen(grid=False, n=1000, format_="{l_bar}<bar/>{n_fmt}/{total_fmt} [{elapsed}<{remaining} {rate_fmt}{postfix}]"):
        for i in tgrange(n, unit_scale=True, unit="B", ascii=False,
                         bar_format=format_):
            sleep(0.001)
            yield


# Generated at 2022-06-22 05:20:39.437637
# Unit test for function tgrange
def test_tgrange():
    """Test function tgrange (internal function)"""
    # Dataset
    from time import sleep

    # Unittest
    with tgrange(4) as pbar:
        for _ in pbar:
            sleep(.4)
        for _ in pbar:
            sleep(.4)
    assert pbar._instances == [], \
        "tgrange has to properly close GUI progressbar."



# Generated at 2022-06-22 05:20:41.101324
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from .gui import tgrange
    for i in tgrange(4):
        sleep(.5)

# Generated at 2022-06-22 05:20:52.550580
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import os
    import sys
    import time
    # Delay import of GUI libs
    from .gui import tgrange

    if os.getenv('TEST_TQDM_GUI', 0):
        for i in tgrange(4):
            time.sleep(0.1)

        # subprocess
        tgrange(0)
        sys.stdout.flush()
        time.sleep(1)
        p = tgrange.popen_sp(["echo", "hi"], stdout=sys.stdout)
        p.communicate()
        time.sleep(1)
        tgrange(0)

        # iterables

# Generated at 2022-06-22 05:20:53.560142
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(leave=False) as tr:
        tr.clear()

# Generated at 2022-06-22 05:20:56.800836
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm_gui as tqdm_gui_std

    for t in (tqdm_gui, tqdm_gui_std):
        with t(total=10) as pbar:
            for _ in range(10):
                pbar.update()
                time.sleep(0.1)
            pbar.close()

# Generated at 2022-06-22 05:21:20.046767
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from os import get_terminal_size as term_size
    for _ in trange(10, desc="test", leave=True):
        sleep(0.1)
        # print(term_size())  # always (80, 24)

# Generated at 2022-06-22 05:21:22.005216
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=5) as t:
        t.clear()
        

# Generated at 2022-06-22 05:21:34.461683
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    import numpy as np
    import random

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    def f(x, y):
        return np.sin(x) + np.cos(y)

    x = np.linspace(0, 2 * np.pi, 120)
    y = np.linspace(0, 2 * np.pi, 100).reshape(-1, 1)
    im = ax.imshow(f(x, y), animated=True)

    def updatefig(*args):
        global x, y
        x += np.pi / 15.
        x %= 2 * np.pi
        y += np.pi / 20.

# Generated at 2022-06-22 05:21:41.358996
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=10)
    assert t._instances
    t.close()
    assert not t._instances
    # Test closing with existing instances
    t1 = tqdm_gui(total=10)
    t2 = tqdm_gui(total=10)
    assert len(tqdm_gui._instances) == 2
    tqdm_gui.close_all()
    assert not tqdm_gui._instances

# Generated at 2022-06-22 05:21:47.785623
# Unit test for function tgrange
def test_tgrange():
    with tqdm(total=10) as t:
        for i in tgrange(10):
            t.update()
    with tqdm(total=10) as t:
        for i in trange(10):
            t.update()

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_tgrange()

# Generated at 2022-06-22 05:21:53.126484
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        with tqdm_gui(total=1, unit='B', unit_scale=True,
                      unit_divisor=1024, miniters=1, mininterval=0.5) as t:
            assert t.gui
            t.clear()
            assert True
    except Exception as e:
        assert False, "Failed with exception: " + str(e)

# Generated at 2022-06-22 05:22:03.152358
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    for _ in trange(4, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', leave=False):
            for _ in trange(50, desc='3nd loop'):
                time.sleep(0.01)
    time.sleep(1)
    for _ in tqdm(range(50), desc='1st loop', miniters=0):
        for _ in trange(5, desc='2nd loop', leave=False, gui=True):
            for _ in trange(50, desc='3nd loop'):
                time.sleep(0.01)

# Generated at 2022-06-22 05:22:05.998707
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm(range(10), gui=True):
        sleep(1)
        clear()

# Generated at 2022-06-22 05:22:16.705227
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from io import StringIO
    except ImportError:
        from cStringIO import StringIO
    from .utils import FormatCustomTextTest, _environ
    import contextlib
    from .gui import tqdm
    from sys import executable, exit

    # Define decorator for temporary environment variable
    @contextlib.contextmanager
    def env_state(*args, **kwargs):
        saved = _environ.copy()
        _environ.update(*args, **kwargs)
        try:
            yield
        finally:
            _environ.clear()
            _environ.update(saved)


# Generated at 2022-06-22 05:22:20.073872
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()
    t = tqdm(total=100, leave=False)
    t.close()
    assert mpl.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion