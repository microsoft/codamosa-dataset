

# Generated at 2022-06-22 05:20:18.048404
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from timeit import default_timer as timer
    t = tqdm_gui(total=10)
    for i in range(10):
        t.update()
        t.display()
        plt.pause(0.2)
    t.close()
    t = tqdm_gui()
    t.start()
    start = timer()
    while timer() - start < 5:
        t.update()
        t.display()
        plt.pause(0.2)
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:20:30.215624
# Unit test for constructor of class tqdm_gui

# Generated at 2022-06-22 05:20:37.582074
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.testing.decorators import cleanup, image_comparison

    @cleanup
    def main():
        import matplotlib.pyplot as plt
        import numpy as np
        import time

        n = 1000
        fig, ax = plt.subplots()
        # progressbar
        hspan = plt.axhspan(0, 1, xmin=0, xmax=0, color='green')
        xdata = []
        ydata = []
        zdata = []
        ax.set_ylim(0, 1)
        ax.set_xlim(0, 100)
        ax.set_xlabel('percent')
        line1, = ax.plot(xdata, ydata, color='b')

# Generated at 2022-06-22 05:20:41.494362
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    with tqdm_gui(total=100) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update(10)
        time.sleep(2)
        t.close()
    with tqdm_gui(total=None) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update(1)
        time.sleep(2)



# Generated at 2022-06-22 05:20:45.613232
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test tqdm_gui() constructor"""
    from .utils import _term_move_up

    with tqdm_gui(1) as t:
        t.set_description("Done")
    _term_move_up()

# Generated at 2022-06-22 05:20:48.459580
# Unit test for function tgrange
def test_tgrange():
    # Initialise tgrange
    with tgrange(4) as pbar:
        for i in pbar:
            # update
            pbar.update()


# Generated at 2022-06-22 05:20:58.867890
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # initialize the tqdm_gui instance
    from time import sleep
    from tqdm import tqdm_gui
    from inspect import getfullargspec
    t = tqdm_gui(total=100)
    sleep(0.5)  # should raise a warning

    # check that the method clear exists
    assert hasattr(t, 'clear'), \
        ("method clear of class tqdm_gui not found"
         " (or a method with same name but incompatible signature)")
    func = getattr(t, 'clear')
    # check it's a function
    assert callable(func), \
        "method clear of class tqdm_gui is not a function"

    # check number of arguments
    arg_spec = getfullargspec(func)

# Generated at 2022-06-22 05:21:04.443739
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from tqdm.utils import _term_move_up
    with tgrange(3) as pbar:
        for i in pbar:
            if i > 0:
                sleep(1)
                _term_move_up()
                pbar.set_description("This is a TGRANGE")

# Generated at 2022-06-22 05:21:09.601249
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Should be called before importing matplotlib.pyplot
    (due to some tests)
    """
    # init
    t = tqdm_gui(10)
    assert t._instances == [t]

    # close
    t.close()
    assert t._instances == []

# Generated at 2022-06-22 05:21:21.696853
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from tqdm.gui import tqdm
    t = tqdm(total=100, ncols=50)
    for i in range(10):
        t.update()
        t.display()
    t.close()

# Alias
test_tqdm_gui = test_tqdm_gui_display


if __name__ == "__main__":  # pragma: no cover
    import time

    for i in tqdm(range(10), desc="1st loop"):
        for j in tqdm(range(1), desc="2nd loop", leave=False):
            for k in tqdm(range(5), desc="3rd loop", leave=False):
                time.sleep(0.01)
    # for i in trange(10, desc="1