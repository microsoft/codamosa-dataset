

# Generated at 2022-06-22 05:20:16.402992
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .tests import TestTqdm
    from inspect import cleandoc
    with TestTqdm.mock_gui_env():
        @TestTqdm.wrap
        def tst_clear(bar, *args, **kwargs):
            """
            >>> for i in tst_clear():
            ...     pass
            """
            for i in range(kwargs['total']):
                bar.clear()
                yield
        try:
            print(cleandoc(tst_clear.__doc__))
        except TypeError:
            print("no doctests found")
        tst_clear(total=2)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:20:27.199003
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib.pyplot as plt
    from time import sleep
    from sys import version_info

    plt.ion()
    try:
        for i in tgrange(4):  # auto-refreshes every 50ms
            plt.title(str(i))
            sleep(0.5)
            if i == 1:
                t.set_description("foo")
            elif i == 2:
                t.set_description(desc="bar", refresh=False)
            elif i == 3:
                t.set_description(desc="foobar")
    finally:
        # Resets to non-interactive mode, you can use plt.show() again.
        plt.ioff()
        # workaround for https://github.com/tqdm/tqdm/issues

# Generated at 2022-06-22 05:20:39.747713
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase
    from mock import patch

    class GUI_close_TestCase(TestCase):
        def test_close(self):
            with patch.object(std_tqdm, '_instances', []) as mock_instances:
                with patch.object(tqdm_gui, '_range') as mock_range:
                    with patch.object(tqdm_gui.mpl, 'rcParams', {'toolbar': 'None'}) as mock_params:
                        with patch.object(tqdm_gui.plt, 'close') as mock_close:
                            with patch.object(tqdm_gui.plt, 'isinteractive') as mock_isinteractive:
                                mock_isinteractive.return_value = True

# Generated at 2022-06-22 05:20:51.456303
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit test for method display of class tqdm_gui"""
    import re
    import sys
    import time
    from threading import Thread
    from tqdm.gui import trange
    from tqdm.utils import _term_move_up

    if sys.version_info[0] == 3:
        r = range
    else:
        r = xrange

    # Note: if the plots are not closed, the tests will not exit
    # because the Threads are still running

    def test(unit='it', total=None, leave=True, **kwargs):
        """Sub-function to launch the test"""
        if total is None:
            with trange(1, 60, unit=unit, **kwargs) as t:
                prev = 0
                while t.n < 60:
                    delta = t.n - prev

# Generated at 2022-06-22 05:20:53.594642
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    for n in tqdm_gui(range(10)):
        tqdm_gui.clear()

# Generated at 2022-06-22 05:20:55.688852
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tgrange(4):
        for __ in tgrange(5):
            for ___ in tgrange(6):
                pass



# Generated at 2022-06-22 05:21:08.602841
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .std import time

    # Test static methods
    with tqdm(total=100, leave=False) as pbar:
        assert pbar.total == 100
        pbar.update(10)
        assert pbar.n == 10
        # Percentage
        assert pbar.format_dict["percentage"] == " 10%|"
        # Bar
        assert pbar.format_dict["bar"] == "<bar/>"
        # Iteration
        assert pbar.format_dict["n"] == "10it"
        # Rate
        assert pbar.format_dict["rate"] == "  0.00it/s"
        # Time
        assert pbar.format_dict["elapsed"] == "  0s"
        assert pbar.format_dict["remaining"] == "4s"



# Generated at 2022-06-22 05:21:20.684879
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    try:
        t = tqdm(total=100, desc="tqdm")
    except:
        raise unittest.SkipTest("matplotlib is not installed... skipping test! "
                                "Install it with `pip install tqdm[gui]`.")

    t.__next__()
    t.postfix.clear()
    t.close()

    t = tqdm(total=80, leave=False, desc="tqdm", mininterval=0.1)
    t.set_description("tqdm")
    for i in range(30):
        t.__next__()
        t.display()
        plt.pause(0.01)
    t.close()


# Generated at 2022-06-22 05:21:25.585145
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Test that GUI doesn't crash upon calling clear() method
    from tqdm.gui import tqdm
    from time import sleep
    # Run tqdm for a random amount of time
    for i in tqdm(range(3)):
        sleep(0.5)
        if i == 1:
            tqdm.clear()
        if i == 2:
            # Close tqdm
            tqdm.close()

# Generated at 2022-06-22 05:21:29.492994
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tq = tqdm_gui(total=10)
    assert getattr(tq, "disable", False) == False

    tq.close()
    assert getattr(tq, "disable", False) == True