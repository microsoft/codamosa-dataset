

# Generated at 2022-06-22 05:20:18.628479
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import trange as std_trange
    from .std import tqdm as std_tqdm
    from .std import TqdmExperimentalWarning

    def side_effect(*args, **kwargs):
        raise _tqdm_gui_close_stop_iteration()

    def tqdm_gui_close(*args, **kwargs):
        # Create a new tqdm_gui instance
        t = tqdm_gui(*args, **kwargs)
        with std_tqdm._instances_mutex:
            # Remove this tqdm_gui instance from tqdm.std._instances
            std_tqdm._instances.remove(t)
        # Copy previous gui functions
        gui_instances_old = tqdm_gui._instances

# Generated at 2022-06-22 05:20:25.950756
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep

    from .tqdm import tgrange, tqdm_gui
    from .std import TqdmExperimentalWarning

    old_threshold = TqdmExperimentalWarning.threshold
    try:
        TqdmExperimentalWarning.threshold = 0
        with tqdm_gui(range(10), desc="Toto") as t:
            for i in t:
                sleep(0.2)
    finally:
        TqdmExperimentalWarning.threshold = old_threshold

# Generated at 2022-06-22 05:20:34.193547
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from sys import stdout
    for i in trange(2, desc="1st loop", disable=False):
        for j in trange(5, desc="2nd loop", leave=False, disable=False):
            for k in trange(100, desc="3rd loop", leave=False, disable=False):
                sleep(0.01)
                stdout.flush()
        stdout.flush()
    print("\n" + "done")

# Generated at 2022-06-22 05:20:42.526276
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import time
    it = tqdm_gui(3)
    it.clear()
    it.update()
    it.update()
    it.update()
    it.clear()
    plt.show()
    time.sleep(2.0)
    it.display()
    plt.show()
    time.sleep(2.0)
    it.close()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-22 05:20:52.552196
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from sys import stderr
    from .std import TqdmTypeError
    # test duration: 10s
    with tqdm(total=100) as pbar:
        assert pbar.gui
        pbar.display()  # avoids final display
        pbar.write("foo", file=stderr)
        for i in range(100):
            pbar.display()
            sleep(0.1)
    # check negative max
    with tqdm(total=-100) as pbar:
        assert pbar.gui
        try:
            pbar.display()
            assert False
        except (TqdmTypeError, ValueError):
            pass



# Generated at 2022-06-22 05:20:56.077724
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(range(3), leave=False, disable=False):
        assert len(tqdm_gui._instances) == 1
        tqdm_gui.clear()
        assert len(tqdm_gui._instances) == 1

# Generated at 2022-06-22 05:21:07.028550
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=4) as t:
        for i in _range(4):
            t.update()
        for i in _range(4):
            t.update()
            assert len(t.xdata) == 2 * (i + 1)

    with tqdm_gui(total=4, unit='iB', unit_scale=True) as t:
        assert re.search(r"\w*/s", t.format_dict['unit'])
        for i in _range(4):
            t.update()
        for i in _range(4):
            t.update()
            assert len(t.xdata) == 2 * (i + 1)

# Generated at 2022-06-22 05:21:16.234521
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os

    try:
        import gc
        gc.disable()
    except ImportError:
        pass
    try:
        import objgraph
    except ImportError:
        pass
    else:
        objgraph.show_growth()

    t = tqdm_gui(total=100, colour='g', leave=True)
    t.close()
    assert os.system('ps aux | grep [t]kinter > /dev/null') == 0, 'GUI still present'

    if 'objgraph' in globals():
        objgraph.show_growth()

# Generated at 2022-06-22 05:21:25.790352
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from collections import deque
    from six.moves import _thread as thread
    from .std import tqdm as std_tqdm
    # assert std_tqdm is tqdm  # make sure we're testing the GUI version

    total = 11
    with std_tqdm(total=total) as t:
        xdata = t.xdata
        ydata = t.ydata
        zdata = t.zdata
        # assert len(xdata) >= total  # make sure xdata is filled first
        assert len(xdata) == 0
        assert len(ydata) == 0
        assert len(zdata) == 0

        def run():
            t.set_description("bar")
            for i in _range(total):
                t.set_description("foo")
                t

# Generated at 2022-06-22 05:21:38.266334
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    For the scope of this test, we mock out the following methods.
        - _instances.remove
        - get_lock
        - rmtree
    This method tests the close method of the class tqdm_gui
    and for the scope of this test, we mock out only the following methods
        - _instances.remove
        - get_lock
        - rmtree
    The test is successfull if the method close is called without raising any
    exception.
    """
    import mock
    import tempfile


# Generated at 2022-06-22 05:21:57.236726
# Unit test for function tgrange
def test_tgrange():
    from .std import TestTqdm

    for T in [TestTqdm, TestTqdmGui]:
        with T(disable=not T.enabled()):  # `disable` option is added in TqdmExperimentalWarning
            for i in range(0, 3):
                tgrange(i)


if __name__ == "__main__":
    r = tqdm_gui(total=9 * 2)
    for i in r:
        r.display()
        r.update()
    r.close()

# Generated at 2022-06-22 05:22:06.599180
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(total=2, leave=False)
    for _ in t:
        t.display()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    # Test unit
    test_tqdm_gui_display()

    # Test all

# Generated at 2022-06-22 05:22:17.245965
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from sys import getsizeof
    from time import sleep
    from collections import deque
    from .std import TqdmDeprecationWarning
    from .std import tgrange as ttgrange
    warn("This test method is deprecated, use the unit test test_gui instead",
         TqdmDeprecationWarning, stacklevel=2)
    # Testing method tqdm_gui.display
    t = tqdm_gui()
    t.xdata = []
    t.ydata = []
    t.zdata = []
    t.start_t = t._time()
    t.last_print_n = 0
    t.last_print_t = t.start_t
    t.total = 3

# Generated at 2022-06-22 05:22:22.163936
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initialize a tqdm bar
    with tqdm_gui(total=2) as pbar:
        # Update the bar in different ways
        pbar.update()
        pbar.update(1)
    # Test result of close method
    assert pbar.disable == True

# Test __init__ method

# Generated at 2022-06-22 05:22:31.448816
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange
    """
    for _ in tgrange(5):
        pass


if __name__ == '__main__':
    from time import sleep
    from tqdm import tqdm, tnrange
    for _ in tqdm(range(20), "GUI Test"):
        test_tgrange()
    sleep(1)

    # Close all figures upon exiting
    try:
        tgrange(10)
    except KeyboardInterrupt:
        import matplotlib.pyplot as plt
        plt.close("all")

    tnrange(40)

# Generated at 2022-06-22 05:22:40.657552
# Unit test for function tgrange
def test_tgrange():
    """Unit tests for tgrange"""
    # Reset
    stdout = sys.stdout
    tqdm_gui.clear()
    sys.stdout = stdout

    # Test
    with closing(StringIO()) as our_file:
        sys.stdout = our_file
        tgrange(0)
        assert "0it [00:00, ?" not in our_file.getvalue()
        tgrange(1)
        assert "0it [00:00, ?it/s]" not in our_file.getvalue()
        tgrange(1)
        assert "1it [00:00, ?it/s]" not in our_file.getvalue()
        tgrange(2)
        assert "1it [00:00, ?it/s]" not in our_file.getvalue()
       

# Generated at 2022-06-22 05:22:51.854035
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from ._utils import _supports_unicode
    from ._utils import _term_move_up
    import sys
    import matplotlib.pyplot as plt

    # Initialise tqdm_gui and set some parameters
    tqdm_gui.clear(False)
    ncols = 60

    def plotter(it, total=None):
        t = tqdm_gui(it, total=total,
                     bar_format='{elapsed}<{bar}>|{n_fmt}/{total_fmt}',
                     disable=not _supports_unicode(sys.stdout))

        for i in t:
            pass
        t.close()

    # test tqdm_gui with a total number of iterations
    plotter(range(100), total=100)
    t = tqdm_

# Generated at 2022-06-22 05:23:04.144252
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import warnings
    warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
    t = tqdm_gui(10)
    t.display()
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == 1
    t.clear()
    t.display()
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == 2
    t.clear()
    t.display()
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == 3
    t.close()



# Generated at 2022-06-22 05:23:08.031107
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import pytest
    with tqdm_gui(ascii=True) as bar:
        bar.update()
        bar.close()
        pytest.raises(ValueError, bar.update)


if __name__ == "__main__":
    from .main import _main
    _main()

# Generated at 2022-06-22 05:23:13.724643
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from unittest import TestCase
    from tqdm.gui import tqdm, trange
    for cls in [tqdm, trange]:
        with TestCase.assertRaises(TestCase, NotImplementedError):
            for i in cls(range(3)):
                cls.clear()

# Generated at 2022-06-22 05:23:48.344119
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from sys import argv
    from os import remove
    from itertools import repeat, chain
    from time import sleep
    from copy import copy
    from cStringIO import StringIO
    from collections import deque, namedtuple
    from random import random

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    sleep(0.1)

    class TestTqdmGuiDisplay(unittest.TestCase):
        """Test display method of class tqdm_gui."""

        class T(tqdm_gui):
            """Test class which is only a tqdm_gui instance."""

# Generated at 2022-06-22 05:24:00.490969
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Unit test for function tgrange"""
    from .utils import FormatCustomText, FormatCustomTextTest
    from .utils import _get_term_width, _range

    # Test basic GUI elements
    with tgrange(4) as pbar:
        list(pbar)

    # Test closing Figure
    with tgrange(4) as pbar:
        for _ in pbar:
            pbar.close()

    # Test closing Figure with try/finally block
    try:
        with tgrange(4) as pbar:
            for _ in pbar:
                raise
    except KeyboardInterrupt:
        pass
    else:
        raise ValueError

    # Test custom GUI elements

# Generated at 2022-06-22 05:24:12.146947
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np
    import time
    # Force matplotlib to not use any Xwindows backend
    mpl.use('Agg')

    def main():
        t = tqdm(total=100)
        while not t.disable:
            time.sleep(0.02)
            t.update()
        t.close()
        try:
            plt.close('all')
        except Exception:
            pass

    def main2():
        for i in tqdm(np.arange(15)):
            time.sleep(0.1)

    main()
    main2()


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:24:22.397821
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    from numpy.testing import assert_allclose

    wasion = plt.isinteractive()
    plt.ion()

# Generated at 2022-06-22 05:24:24.705772
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    with tqdm_gui(total=100) as bar:
        for i in range(10):
            bar.update()
            bar.display()
            np.random.random(1e2)

# Generated at 2022-06-22 05:24:34.902776
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from unittest.case import TestCase
    from .utils import pretest_checks
    from .std import TqdmDeprecationWarning

    pretest_checks()

    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        raise unittest.SkipTest

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        t = tqdm_gui(total=9)

    class T(TestCase):
        def test_value(self):
            i = len(t.xdata)
            d = t.format_dict
            self.assertEqual(d['percentage'], 100.0 * i / t.total)

# Generated at 2022-06-22 05:24:46.860457
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Test for method clear of class tqdm_gui."""
    from .tests import dummy_gui_tqdm
    from .utils import _progbar_counter, _supports_unicode
    import sys

    with dummy_gui_tqdm() as t:
        p = _progbar_counter()
        t.update(1)
        p.update(2)
        t.clear()
        p.close()
        if _supports_unicode():
            try:
                # Just to trigger UnicodeEncodeError...
                t.write(u"\u0394")
            except UnicodeEncodeError:
                pass
        # Test encoding failure on write
        try:
            reload(sys)  # Python 2
        except NameError:
            pass  # Python 3

# Generated at 2022-06-22 05:24:58.212983
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from unittest import TestCase

    with TestCase(TestCase) as testcase:
        unit_kwargs = {'unit': 'it',
                       'unit_scale': True,
                       'unit_divisor': 1024,
                       'miniters': 2,
                       'gui': True}
        progressbar = tqdm_gui(**unit_kwargs)
        assert progressbar.format_dict['rate'] == '{rate_fmt}{postfix}'
        progressbar.close()

        progressbar = tqdm_gui()
        progressbar.close()

        progressbar = tqdm_gui(**unit_kwargs)
        assert progressbar.format_dict['rate'] == '{rate_fmt}{postfix}'
        progressbar.close()


# Generated at 2022-06-22 05:25:01.192056
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys

    total = 50
    with tgrange(total, file=sys.stderr, desc="Close test") as bar:
        for i in bar:
            bar.set_description("Desc: %i" % i)

# Generated at 2022-06-22 05:25:11.818118
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialization of the class
    from cStringIO import StringIO
    import matplotlib.pyplot as plt
    import numpy as np
    import sys
    try:
        from unittest.mock import patch
    except ImportError:  # python < 3.3
        from mock import patch

    from .gui import tqdm as tqdm_gui

    try:
        from matplotlib import get_backend
    except ImportError:  # old MPL
        get_backend = plt.get_backend

    backend = get_backend()

# Generated at 2022-06-22 05:26:01.538744
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method `clear` of class `tqdm_gui`."""
    from .tests import setup_tests, run_tests
    setup_tests()

    tqdm_gui.clear()

    run_tests()

# Generated at 2022-06-22 05:26:03.709201
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method."""
    t = tqdm_gui(range(1))
    t.clear()
    t.close()

# Generated at 2022-06-22 05:26:13.957651
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import free_port
    from .gui import tqdm
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        HOST, PORT = 'localhost', free_port()
        s.bind((HOST, PORT))
        s.listen(1)
        t = tqdm(range(10), file=s)
        assert t.disable == False

        t.close()
        assert t.disable == True
        t.clear()
    except:
        pass
    pass

if __name__ == "__main__":
    #Unit test for method close of class tqdm_gui
    def test_tqdm_gui_close():
        from .gui import tqdm
        t = tqdm(range(10))

# Generated at 2022-06-22 05:26:23.863962
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test the display method of tqdm_gui class"""
    # Test with a known (small) numeric value
    t = tqdm_gui(total=10**6)
    for i in tqdm_gui(xrange(10**6)):
        t.update(50)
        assert t.n >= i + 50
    t.close()
    # Test with a unknown (large) numeric value
    t = tqdm_gui(total=None)
    for _ in tqdm_gui(xrange(10)):
        t.update(50)
        assert t.n >= 50
    t.close()



# Generated at 2022-06-22 05:26:33.517947
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm_gui as tq
    for i in tq(range(1000)):
        if i == 500:
            tq.clear()
            break
        pass
    for i in tq(range(1000)):
        pass
    tq.close()

if __name__ == '__main__':  # pragma: no cover
    from .std import tqdm
    from time import sleep
    # test
    test_tqdm_gui_clear()
    # test GUI
    with tqdm(total=99, smoothing=0, dynamic_ncols=True, ascii=True) as pbar:
        for i in range(50):
            pbar.display()
            sleep(0.01)
            pbar.update()

# Generated at 2022-06-22 05:26:38.021943
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import random
    from matplotlib.pyplot import draw, pause, show, axes, legend
    bar = tqdm_gui(total=100)
    for i in bar:
        # do something
        sleep(0.01)
        bar.set_description("Loss: %g" % random.random())
        ax = the_current_axes()
        ydata = ax.lines[0].get_ydata()
        ydata = list(ydata) + [random.random()]
        ax.lines[0].set_ydata(ydata)
        # plt.show(block=False)
        draw()
        pause(0.01)
        # show()
    legend(loc='upper left')
    show()
    return bar




# Generated at 2022-06-22 05:26:39.084072
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    t = tqdm_gui(total=10)
    t.write("boing!")
    sleep(0.5)
    t.close()

# Generated at 2022-06-22 05:26:42.132322
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tgrange(10):
        pass



# Generated at 2022-06-22 05:26:53.395566
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .tests import TestCase
    from .tests import pretest_posttest
    from .std import time


# Generated at 2022-06-22 05:27:03.927408
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from numpy.random import randint
    except ImportError:
        warn("Test requires numpy", RuntimeWarning)
        return

    # test if the method close works in GUI mode

    # TODO: with build_docstring, no coverage.
    # TODO: @classmethod: write() on GUI?
    class tqdm_gui(std_tqdm):  # pragma: no cover
        """Experimental Matplotlib GUI version of tqdm!"""
        def __init__(self, *args, **kwargs):
            std_tqdm.__init__(self, *args, **kwargs)
            self._close_called = False

        def close(self):
            self._close_called = True
