

# Generated at 2022-06-22 05:20:24.865638
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test tqdm_gui display update"""
    from time import sleep
    from pandas import DataFrame
    from pandas import read_csv
    from numpy import polyfit

    def display_test():
        """Display test"""
        # Avoid python3 division truncation
        from __future__ import division
        # Create a test DataFrame
        test_df = read_csv(__file__,
                           header=None,
                           skiprows=15,
                           comment="#",
                           encoding="utf-8",
                           skipinitialspace=True,
                           skip_blank_lines=True,
                           error_bad_lines=False,
                           warn_bad_lines=False,
                           delim_whitespace=True)

# Generated at 2022-06-22 05:20:33.554412
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import random
    import time
    random.seed(42)
    tot = 100
    progress = tqdm_gui(total=tot)
    lines = ["Line 1", "Line 2", "Line 3", "Line 4", "Line 5"]
    for i in range(1, tot + 1):
        progress.display()
        t = random.random() / 3.0
        time.sleep(t)
        progress.update()
    progress.close()


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-22 05:20:45.852057
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import matplotlib.animation as anim
    from .utils import _range

    fig = plt.figure()
    ax = fig.add_subplot(111)
    li, = ax.plot([], [])
    ax.set_ylim(0, 1)
    ax.set_xlim([0, 100])
    ax.set_xlabel("percent")
    fig.legend((li,), ("cur",), loc='upper right')
    ax.grid()

    with tqdm_gui(_range(100), unit="B", unit_scale=True, unit_divisor=1024,
                  miniters=0, mininterval=0, leave=False, ncols=80) as t:
        def update_plot(i):
            t.display()

# Generated at 2022-06-22 05:20:57.094531
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from unittest.mock import patch
    except ImportError:
        # Python 2.7
        from mock import patch
    import numpy as np
    with patch('matplotlib.pyplot.pause', return_value=None) as mock_pause, \
            patch('matplotlib.pyplot.figure', return_value=None) as mock_fig, \
            patch('matplotlib.pyplot.axhspan', return_value=None) as mock_axhspan, \
            patch('matplotlib.pyplot.axvspan', return_value=None) as mock_axvspan:
        t = tqdm_gui(np.arange(10))
        for i in range(10):
            t.update()
        assert mock_fig.call_count >= 1

# Generated at 2022-06-22 05:21:04.861472
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm(total=0, unit="B", leave=True) as pbar:
        pbar.display()
        pbar.close()
    with tqdm(unit="B", leave=True) as pbar:
        pbar.update(100)
        pbar.display()
        pbar.close()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-22 05:21:17.396182
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Test `tqdm.gui.tqdm.display()` method
    """
    # Test instant variable initialization
    gui = tqdm_gui()
    assert gui.toolbar == gui.mpl.rcParams['toolbar']
    assert gui.wasion == gui.plt.isinteractive()
    assert gui.interval == 0.5
    assert len(gui.xdata) == len(gui.ydata) == len(gui.zdata) == 0
    # Test close method
    gui.close()
    assert len(tqdm_gui._instances) == 0
    assert gui.disable
    assert gui.mpl.rcParams['toolbar'] == gui.toolbar
    assert gui.plt.isinteractive() == gui.wasion
    # Test display() method
    gui.display

# Generated at 2022-06-22 05:21:22.433734
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui.clear() method works properly."""
    import matplotlib.pyplot as plt
    with tqdm_gui(total=10, bar_format='{postfix}') as t:
        for i in range(10):
            t.update()
            t.clear()
            plt.pause(0.5)

# Generated at 2022-06-22 05:21:34.516338
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    import sys

    with trange(5) as t:
        for i in t:
            t.set_description('process %i' % i)
            t.set_postfix(i=i, refresh=False)
            sleep(.5)

    with tqdm(total=(9 * 5)) as t:
        for i in range(9):
            t.update(5)
            t.set_description('process %i' % i)
            t.set_postfix({'process_name': 'process %i' % i, 'refresh': False})
            # t.set_postfix(process_name='process %i' % i, refresh=False)
            sleep(.5)
        t.clear()


# Generated at 2022-06-22 05:21:46.524917
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    # Inline
    plt = tqdm_gui.plt
    class TqdmTypeError(TypeError):
        pass
    class TqdmKeyboardInterrupt(KeyboardInterrupt):
        pass
    class TqdmException(Exception):
        pass

    # Require matplotlib
    try:
        import matplotlib as _  # NOQA
    except ImportError:
        raise unittest.SkipTest('tqdm_gui requires matplotlib')
    # Require Tk
    try:
        import Tkinter as _  # NOQA
    except ImportError:
        raise unittest.SkipTest('tqdm_gui requires Tk')

    from tqdm.gui import tqdm_gui

    def raise_exc(e):
        raise e



# Generated at 2022-06-22 05:21:55.684974
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    # Display of class tqdm_gui methods.
    from tqdm.auto import tqdm
    from time import sleep
    from copy import deepcopy
    from sys import getrefcount as grc

    # Filter out deprecation warnings
    from warnings import simplefilter
    simplefilter("ignore")

    tqdm.write("")
    tqdm.write("Testing function display method . . .")

    for i in tqdm([1, 2, 3], desc="Testing display method"):
        sleep(0.01)
        tqdm.write("blah")
        tqdm.write("blah", miniters=1)
        tqdm.write("blah", mininterval=0.5)

# Generated at 2022-06-22 05:22:18.171336
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.utils import _term_move_up
    from os import get_terminal_size
    from time import sleep
    from numpy.random import uniform
    from cStringIO import StringIO
    with StringIO() as s:
        t = tqdm_gui(s, total=get_terminal_size().columns)
        for k in t:
            t.display()
            t.clear()
            r = uniform(k - 0.5, k + 0.5)
            t.update(r - k)
            sleep(0.1)
        s.seek(0)
        print(s.read())

# Generated at 2022-06-22 05:22:24.152426
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in trange(4, desc='1st loop', leave=True):
        for j in trange(25, desc='2nd loop', leave=True):
            for k in trange(100, desc='3nd loop', leave=True, mininterval=0.005):
                assert i+j+k >= 0, \
                    "tgrange counting not working properly"



# Generated at 2022-06-22 05:22:35.731213
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .utils import FormatStopIteration
    from .std import tqdm

    # if mpl is not installed, we skip this test
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        try:
            import unittest.mock as mock
        except ImportError:  # python2
            import mock
        return mock.MagicMock()

    # define dummy object
    class DummyTqdmGui:
        def __init__(self):
            self.xdata = [0]
            self.ydata = [0]
            self.zdata = [0]
            self.n = 0
            self.total = 10
            self.ax = plt.axes([0, 0, 1, 1])

# Generated at 2022-06-22 05:22:47.034957
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    # import matplotlib.backend_bases as mb
    # import matplotlib.pyplot as plt
    # import matplotlib as mpl
    from tqdm.gui import tqdm_gui, trange
    from tqdm.utils import _range

    # Get state of tqdm instances before
    old_instances = tqdm_gui._instances.copy()
    gc.collect()
    # Create a tqdm instance, force no GUI and set leave=True
    with tqdm_gui(_range(10), gui=False, leave=True) as pbar:
        pass

    # Get state of tqdm instances after (none should have been created)
    new_instances = tqdm_gui._instances.copy()
    gc.collect()

# Generated at 2022-06-22 05:22:54.067137
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .utils import _supports_unicode
    t = tgrange(4)
    for i in t:
        # Check that the length of the bar is correct
        # (should be exactly 2 * len(str(i)) + 1)
        assert len(t.format_dict['bar']) == len(str(i)) * 2 + 1 + \
            (2 if _supports_unicode() else 0)
        if i == 2:
            t.close()



# Generated at 2022-06-22 05:23:05.280892
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .utils import _screen_shape  # recursive import
    from .std import _term_move_up

    # Testbar and update
    for n in tqdm(list(range(10)), desc='Testing...', unit='i'):
        pass
    with tqdm(list(range(10)), desc='Testing...', unit='i', ascii=True) as t:
        for n in t:
            pass
    with tqdm(total=1000, leave=True, unit='B', unit_scale=True,
              miniters=None, mininterval=0, mininterval_local=0,
              dynamic_ncols=False, smoothing=0.3) as t:
        assert t._instances
        assert len(t._instances) == 1

# Generated at 2022-06-22 05:23:13.212634
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    from matplotlib.figure import Figure
    from matplotlib.text import Text
    p = tqdm_gui(["a", "b", "c", "d"], leave=False)
    p.write("hello")  # not implemented
    p.clear()  # not implemented
    p.close()

    caption = "test_tqdm_gui(): "
    assert isinstance(p.fig, Figure)  # plt.subplots()
    assert isinstance(p.fig.canvas, FigureCanvas)
    ax = p.ax
    assert isinstance(ax, p.plt.Subplot)
    assert isinstance(ax.get_xlabel(), Text)

# Generated at 2022-06-22 05:23:23.581158
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit testing for tqdm_gui.display"""
    # init object
    tqdm_g = tqdm_gui(total=1000)
    tqdm_g.show_interval = True
    tqdm_g.format_dict = dict()
    tqdm_g.format_dict['n'] = 100
    tqdm_g.format_dict['total'] = 1000
    tqdm_g.format_dict['unit'] = ''
    tqdm_g.format_dict['bar_format'] = '{l_bar}<bar/>{r_bar}'
    tqdm_g.format_dict['l_bar'] = ''
    tqdm_g.format_dict['r_bar'] = ''

    tqdm_g.start_t = 0
    tqdm_

# Generated at 2022-06-22 05:23:35.643925
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    # disable tqdm bar
    t = tqdm_gui(disable=True)
    t.close()
    # enable tqdm bar
    t = tqdm_gui(disable=False)
    t.close()

    for i in tqdm_gui(xrange(10), disable=True):
        pass
    for i in tqdm_gui(xrange(10), disable=False):
        pass
    tqdm_gui(xrange(10), disable=True)

    # test with no total
    with tqdm_gui(disable=False) as t:
        for i in t:
            pass

    # test mininterval

# Generated at 2022-06-22 05:23:47.047230
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit test for method display of class tqdm_gui."""
    import os
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from matplotlib.pyplot import gcf

    from .std import tqdm
    from .gui import tqdm_gui
    from .utils import _range

    # Patch out subplots
    import matplotlib.pyplot as plt
    plt.subplots = lambda *a, **kw: (plt, plt.figure().add_subplot(111))

    # Patch out savefig
    from contextlib import contextmanager

    @contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = StringIO()
       

# Generated at 2022-06-22 05:24:08.038564
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from .utils import FormatLabel
    for _ in tgrange(4, desc='1st loop', leave=True, mininterval=0.2,
                     miniters=1):
        for __ in tgrange(5, desc='2nd loop', mininterval=0.01, miniters=1):
            for ___ in tgrange(50, desc='3nd loop', leave=False,
                               mininterval=0.01, miniters=1):
                time.sleep(0.01)
        time.sleep(0.01)

# Generated at 2022-06-22 05:24:15.989311
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    t = tqdm_gui(total=10.0, leave=True, bar_format='{bar}', unit='s',
                 mininterval=1, miniters=1)
    for i in range(4):
        for j in range(4):
            assert t.n == (i * 4 + j)
            assert len(t.xdata) == j + 1
            assert len(t.ydata) == j + 1
            assert len(t.zdata) == j + 1
            t.update()
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == 4
    t.close()

# Generated at 2022-06-22 05:24:18.066082
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    for i in tgrange(10):
        sleep(0.01)
        # pass
    assert 1 == 1

# Generated at 2022-06-22 05:24:27.289325
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from mock import patch
    t = tqdm_gui(disable=False)
    t.disable = False
    with patch.object(t, '_instances', [t]) as mock_instances:
        with patch.object(t.mpl, 'rcParams', {'toolbar': 'None'}) as mock_toolbar:
            with patch.object(t, 'warn') as mock_warn:
                with patch.object(t.plt, 'isinteractive', return_value=False) as mock_isinteractive:
                    t.close()
                    assert mock_instances.remove.call_count == 1
                    assert mock_toolbar['toolbar'] == 'None' # TODO: figure out how to assert this again
                    assert mock_warn.call_count == 1
                    assert mock_isinteractive.call_count

# Generated at 2022-06-22 05:24:38.674185
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from contextlib import contextmanager
    from textwrap import dedent

    # Mock out stuff that isn't important for testing method close
    @contextmanager
    def mock_mpl():
        mpl = mock.MagicMock()
        mpl.rcParams.__getitem__.return_value = 'None'
        mpl_obj = mock.MagicMock()
        mpl_obj.isinteractive.return_value = False
        mpl_obj.close.return_value = None
        mpl_obj.ioff.return_value = None
        mpl_obj.isinteractive.return_value = False
        mpl.pyplot.return_value = mpl_obj
        yield mpl

    @contextmanager
    def mock_wasion():
        wasion = mock.Mock()

# Generated at 2022-06-22 05:24:49.338900
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    tgrange(1000)
    tgrange(100)
    tgrange(100, 100)
    tgrange(100, 100, 5)

    tqdm(100)
    tqdm(100, 1)
    tqdm(100, 1, 5)
    tqdm(100, 1, 5, 1)
    tqdm(100, 1, 5, 1, ())
    tqdm(100, 1, 5, 1, {'foo': 'bar'})
    tqdm(100, 1, 5, 1, 'foobar')
    tqdm(100, 1, 5, 1, 'foobar', False)
    tqdm(100, 1, 5, 1, 'foobar', False, True)

# Generated at 2022-06-22 05:24:56.456200
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            time.sleep(0.1)
            pbar.update(1)
        pbar.close()
        try:
            pbar.update(0)
        except:
            raise AssertionError(
                "pbar doesn't allow update() once closed.")
            return -1


# Generated at 2022-06-22 05:24:59.083672
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            t.update()
    t.clear()



# Generated at 2022-06-22 05:25:09.694112
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange
    """
    with tgrange(4) as t:
        for _ in t:
            pass
    with tgrange(4, leave=True) as t:
        for _ in t:
            pass
    with tgrange(4) as t:
        for i in t:
            assert i == t.n - 1
    with tgrange(4) as t:
        for i in t:
            if i == t.total // 4:
                t.set_postfix(foo='foo is bar', bar='bar is foo')
    with tgrange(4, ascii=True) as t:
        for _ in t:
            pass

# Generated at 2022-06-22 05:25:11.938083
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=100) as t:
        pass
