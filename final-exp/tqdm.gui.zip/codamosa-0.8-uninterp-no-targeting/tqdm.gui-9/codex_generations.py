

# Generated at 2022-06-22 05:20:10.468330
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    std_tqdm(100)
    tqdm(100)

# Generated at 2022-06-22 05:20:13.388935
# Unit test for function tgrange
def test_tgrange():
    for x in tgrange(5, desc='desc', ascii=True, leave=False):
        pass
    assert True

# Generated at 2022-06-22 05:20:18.059617
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib
    except ImportError:
        return
    try:
        t = tqdm_gui(total=20)
        t.display()
        t.close()
    except Exception as e:
        warn("test_tqdm_gui_display: {}".format(e))

# Generated at 2022-06-22 05:20:30.251775
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    from time import sleep

    # Simple test
    with tqdm_gui(total=100, unit="B", unit_scale=True, mininterval=2) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.2)
    assert pbar.n == 100
    plt.close(pbar.fig)
    del pbar

    # Complex test
    with tqdm_gui(total=100, unit="B", unit_scale=True, mininterval=2) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.8)
    assert pbar.n == 100
    plt.close(pbar.fig)
    del pbar

# Generated at 2022-06-22 05:20:34.994635
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test clear() method"""
    with tqdm(total=100) as t:
        t.update(10)
        t.clear()
        t.update(20)
        t.clear()
        t.update(30)
        t.update(40)

# Generated at 2022-06-22 05:20:36.269913
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tgrange(10)()

# Generated at 2022-06-22 05:20:42.645243
# Unit test for function tgrange
def test_tgrange():
    import time
    import matplotlib.pyplot as plt
    for i in trange(4):
        time.sleep(0.25)
    plt.show()


# Add as an attribute for IDEs (PyCharm and IPython notebooks, see #455)
setattr(tqdm, "__name__", __name__)


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-22 05:20:45.911561
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    t = tqdm_gui(total=10)
    for _ in t:
        t.display()
    t.close()

# Generated at 2022-06-22 05:20:52.676315
# Unit test for function tgrange
def test_tgrange():
    """Test Tkinter GUI progressbar.
    """
    from time import sleep

    tgrange(3)
    tgrange(3, file=open('/dev/null', 'w'))
    with tgrange(3, file=open('/dev/null', 'w')) as t:
        for i in t:
            sleep(.1)

# Generated at 2022-06-22 05:20:58.791274
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    # tqdm.tqdm_gui only runs with matplotlib installed
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        return
    # tqdm.tqdm_gui only runs in an interactive Python session
    if plt.isinteractive():
        import time
        # default tqdm instance
        t = tqdm(total=5)
        for i in _range(5):
            t.update(1)
            time.sleep(0.4)
        t.close()
        # tqdm instance with iterable of a known length
        t = tqdm(_range(5))
        for i in t:
            time.sleep(0.4)
        t.close()
        # tqdm instance with unknown iterable
       