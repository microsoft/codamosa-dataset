

# Generated at 2022-06-22 05:20:09.047414
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from multiprocessing import Process, Event
    from time import sleep
    from matplotlib import is_interactive

    def target(bar, event):
        try:
            for i in bar:
                sleep(0.1)
            event.set()
        except KeyboardInterrupt:
            assert False, 'Failed to suppress KeyboardInterrupt.'

    bar = tqdm(range(10))
    event = Event()
    p = Process(target=target, args=(bar, event))
    try:
        assert is_interactive()
        p.start()
        event.wait()
        p.join()
    finally:
        p.terminate()
        p.join()

    # try to capture exit errors
    try:
        bar.close()
    except SystemExit:
        raise
   

# Generated at 2022-06-22 05:20:19.220454
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        import matplotlib as mpl
        mpl.use('Agg')
        import matplotlib.pyplot as plt
        tr = tqdm_gui(total=10)
        fig = tr.fig
        plt.close(fig)
        assert not fig.canvas.is_drawn()
        # check that the figure and axis are set properly
        assert plt.fignum_exists(fig.number)
        assert fig.get_axes()[0] == tr.ax
        # check that the figure gets automatically closed
        tr.close()
        assert not plt.fignum_exists(fig.number)
        plt.close('all')
    except Exception:
        pass

# Generated at 2022-06-22 05:20:22.941854
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update()
    plt.close()

# Generated at 2022-06-22 05:20:35.376876
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import unittest as ut
    from matplotlib.testing.decorators import image_comparison
    from .utils import FormatCustomTestCase
    from .tests_tqdm import with_setup

    # Monkey-patch class with custom test suit
    tqdm_gui.__bases__ = (FormatCustomTestCase, ) + tqdm_gui.__bases__

    class Tests(ut.TestCase):
        @staticmethod
        @image_comparison(baseline_images=['tqdm_gui_test'], remove_text=True)
        def test_tqdm_gui():
            """Custom tests"""
            pass


# Generated at 2022-06-22 05:20:45.852050
# Unit test for function tgrange
def test_tgrange():
    """Test for function `tgrange`"""
    from ._version import get_versions
    assert get_versions()['version'] == '4.40.2'
    ni = int(1e6)
    list(tgrange(ni))
test_tgrange()  # noqa


# Disable if not in interactive mode
try:
    import __main__
except ImportError:
    # This is not interactive
    __main__ = None

if not __main__ or not (hasattr(__main__, '__file__') or
                        hasattr(__main__, '__name__')):
    # Disable GUI
    tqdm_gui.gui = False

# Generated at 2022-06-22 05:20:47.135548
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    #TODO
    pass



# Generated at 2022-06-22 05:20:54.201152
# Unit test for function tgrange
def test_tgrange():
    from numpy.random import random
    t = tgrange(10)
    for i in t:
        t.set_description('i=%s' % i)
        t.set_postfix(exc=i % 2, b=100, a=100 * random())
        t.update()
    t.close()


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-22 05:20:56.857887
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Instantiate tqdm_gui object
    with tqdm(total=10) as pbar:
        # Assert that object instantiates without errors
        assert pbar is not None

        # Assert that tqdm_gui object does not raise error
        # when method clear is called
        pbar.clear()

# Generated at 2022-06-22 05:21:04.081743
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import tqdm.std as ts
    import tqdm.gui as tg
    ts.trange(3)
    tg.trange(3)
    tg.trange(3).close()
    ts.tqdm.close()
    for i in ts.trange(3, leave=True):
        pass
    for i in tg.trange(3, leave=True):
        pass

# Generated at 2022-06-22 05:21:16.670343
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import io
    import sys
    from collections import OrderedDict

    # Set up dummy display
    sys.stdout = io.StringIO()

    progress = tqdm_gui(total=1)
    progress.n = 1
    progress.last_print_n = 0
    progress.last_print_t = 0
    progress.start_t = 1
    progress.miniters = 1
    progress.total = 1
    progress.xdata = [0]
    progress.ydata = [0]
    progress.zdata = [0]
    progress.ax = 'ax'
    progress.line1 = 'line1'
    progress.line2 = 'line2'
    progress.hspan = 'hspan'

    progress.display()

    # Check output
    # sys.stdout.seek(0)
