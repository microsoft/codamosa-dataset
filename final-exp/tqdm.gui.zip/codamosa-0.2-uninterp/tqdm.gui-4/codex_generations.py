

# Generated at 2022-06-18 11:36:51.316932
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import version_info
    from matplotlib import pyplot as plt
    from matplotlib import rcParams

    # Remember if external environment uses toolbars
    toolbar = rcParams['toolbar']
    rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Test
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    assert pbar.n == 100, "tqdm_gui: error in __init__()"

    # Restore toolbars
    rcParams['toolbar'] = toolbar
    # Return to non-interactive mode

# Generated at 2022-06-18 11:37:02.108006
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import seed

    seed(0)
    for i in trange(10, desc="1st loop"):
        sleep(uniform(0.1, 0.5))
        for j in trange(5, desc="2nd loop", leave=False):
            sleep(uniform(0.1, 0.5))
            for k in trange(100, desc="3rd loop", leave=False):
                sleep(uniform(0.001, 0.005))
                if randint(0, 10) == 0:
                    break

# Generated at 2022-06-18 11:37:13.148449
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    plt.close(pbar.fig)

    with tqdm_gui(total=100, unit='iB', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    plt.close(pbar.fig)

    with tqdm_gui(total=100, unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

# Generated at 2022-06-18 11:37:23.657015
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    from sys import stderr
    from os import getpid
    from os import kill
    from signal import SIGTERM
    from multiprocessing import Process

    def test_display(t):
        for i in t:
            sleep(0.01)

    # Test with total
    t = tqdm(total=100, file=stderr)
    test_display(t)
    t.close()

    # Test without total
    t = tqdm(file=stderr)
    test_display(t)
    t.close()

    # Test with total and dynamic_ncols
    t = tqdm(total=100, file=stderr, dynamic_ncols=True)
    test_display

# Generated at 2022-06-18 11:37:33.915257
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import stderr
    from os import getpid
    from os import kill
    from signal import SIGTERM
    from multiprocessing import Process
    from multiprocessing import Queue
    from multiprocessing import Event
    from multiprocessing import Value
    from multiprocessing import cpu_count
    from multiprocessing import current_process
    from multiprocessing import freeze_support

    def _test_tqdm_gui_close(q, e, v):
        from time import sleep
        from sys import stderr
        from os import getpid
        from os import kill
        from signal import SIGTERM
        from multiprocessing import cpu_count
        from multiprocessing import current_process
        from multiprocessing import freeze_support


# Generated at 2022-06-18 11:37:43.700132
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from time import sleep
    from tqdm.gui import tqdm
    from tqdm.gui import tqdm_gui

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()

    # Close the tqdm_gui instance
    t.close()

    # Restore toolbars

# Generated at 2022-06-18 11:37:47.394702
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm_gui(range(10)):
        sleep(0.1)
        tqdm_gui.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:37:54.465639
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100), desc='1st loop'):
        for j in tqdm_gui(random.randn(100), desc='2nd loop', leave=False):
            for k in tqdm_gui(random.randn(100), desc='3nd loop', leave=False):
                sleep(0.01)

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-18 11:38:03.467530
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test method close of class tqdm_gui.
    """
    from .std import TqdmExperimentalWarning
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .gui import tqdm_gui
    from warnings import catch_warnings, simplefilter
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import os

    # Test if method close of class tqdm_gui works
    # when disable is True
    with catch_warnings(record=True) as w:
        simplefilter("always")
        t = tqdm_gui(range(10), disable=True)
        t.close()
        assert len(w) == 1
        assert issubclass(w[-1].category, TqdmExperimentalWarning)

# Generated at 2022-06-18 11:38:11.378575
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import random
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import log
    from numpy import exp
    from numpy import sqrt
    from numpy import sin
    from numpy import cos
    from numpy import tan
    from numpy import arcsin
    from numpy import arccos
    from numpy import arctan
    from numpy import sinh
    from numpy import cosh
    from numpy import tanh