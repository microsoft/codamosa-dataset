

# Generated at 2022-06-18 11:36:35.877440
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import linspace
    from matplotlib import pyplot as plt

    # Test for total
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)

    # Test for no total
    with tqdm(unit='i', unit_scale=True) as pbar:
        for i in linspace(0, 1, 100):
            sleep(random())
            pbar.update(1)

    # Test for no total
    with tqdm(unit='i', unit_scale=True) as pbar:
        for i in linspace(0, 1, 100):
            sleep(random())
            pbar.update(1)

    # Test for no

# Generated at 2022-06-18 11:36:46.825696
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import uniform
    from numpy import array

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(uniform(0.01, 0.1))

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(uniform(0.01, 0.1))
        pbar.close()

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(uniform(0.01, 0.1))
        pbar.close()
        pbar.close()


# Generated at 2022-06-18 11:36:53.134220
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in t:
        sleep(0.01)
    assert_array_equal(array(t.xdata), array(t.ydata))
    assert_array_equal(array(t.xdata), array(t.zdata))
    t.close()

# Generated at 2022-06-18 11:37:04.832251
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy.testing import assert_allclose
    from .utils import FormatCustomTextTest

    class TqdmTest(tqdm_gui):
        def __init__(self, *args, **kwargs):
            super(TqdmTest, self).__init__(*args, **kwargs)
            self.xdata = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            self.ydata = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            self.zdata = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
            self.line1.set_data(self.xdata, self.ydata)
            self.line2.set_data

# Generated at 2022-06-18 11:37:07.829274
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from random import random
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(random())

# Generated at 2022-06-18 11:37:16.568463
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit='iB', unit_scale=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit_scale=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit_scale=True, miniters=1) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:37:19.361663
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    t.close()

# Generated at 2022-06-18 11:37:23.913500
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:37:34.222215
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.testing import assert_array_equal

    # Test with total
    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(random() / 10)
    t.close()
    assert_array_equal(t.xdata, array(range(100)))
    assert_array_equal(t.ydata, array(range(100)))
    assert_array_equal(t.zdata, array(range(100)))

    # Test without total
    t = tqdm_gui()
    for i in range(100):
        t.update()
        sleep(random() / 10)
    t.close()

# Generated at 2022-06-18 11:37:43.748973
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import random as nprandom
    from numpy import array
    from numpy import linspace
    from numpy import sin
    from numpy import pi
    from numpy import cos
    from numpy import sqrt
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import concatenate
    from numpy import append
    from numpy import diff
    from numpy import sum
    from numpy import mean
    from numpy import std
    from numpy import var
    from numpy import median
    from numpy import amin
    from numpy import amax
    from numpy import argmin
    from numpy import argmax
    from numpy import argsort
    from numpy import sort

# Generated at 2022-06-18 11:38:04.995902
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

# Generated at 2022-06-18 11:38:13.259119
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for method close of class tqdm_gui
    """
    from .std import tqdm
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    import time

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm_gui(total=10)
    for i in range(10):
        time.sleep(0.1)
        t.update()

    # Close the tqdm_gui instance
    t.close()

    # Restore toolbars
    mpl.rc

# Generated at 2022-06-18 11:38:19.991008
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from tqdm import tqdm_gui
    from tqdm.utils import _term_move_up

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
    print(_term_move_up() + "test_tqdm_gui passed")


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:38:30.940133
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for method close of class tqdm_gui.
    """
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    from matplotlib import rcParamsDefault
    from matplotlib import rc_context
    from matplotlib import get_backend
    from matplotlib.testing.decorators import image_comparison

    # Test if method close restores the original matplotlib settings
    with rc_context(rc={"toolbar": "toolbar"}):
        # Create a tqdm_gui instance
        t = tqdm_gui(total=10)
        # Check if the matplotlib settings are changed
        assert rcParams["toolbar"] == "None"
        assert plt.isinteractive()
        # Close the tqdm_gui instance

# Generated at 2022-06-18 11:38:40.084857
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _range
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Create a tqdm_gui instance
    t = tqdm_gui(_range(10))
    # Close the tqdm_gui instance
    t.close()
    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff

# Generated at 2022-06-18 11:38:44.866540
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            pbar.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:38:56.384696
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit='B', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit='B', unit_scale=True, miniters=1) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

# Generated at 2022-06-18 11:39:04.685890
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test if the method close of class tqdm_gui is working properly.
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _range

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Create a tqdm_gui object
    for i in tqdm_gui(_range(10)):
        pass

    # Check if the method close is working properly
    assert mpl.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion

# Generated at 2022-06-18 11:39:07.241502
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:39:09.415842
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm_gui(range(10), desc="test_tqdm_gui_clear"):
        sleep(0.1)

# Generated at 2022-06-18 11:39:45.296124
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:39:57.120780
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close as plt_close

    t = tqdm_gui(total=10)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    plt_close(t.fig)

    t = tqdm_gui(total=None)

# Generated at 2022-06-18 11:40:06.966023
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from matplotlib.testing.decorators import cleanup
    from matplotlib.testing.decorators import image_comparison
    from matplotlib.testing.decorators import knownfailureif

    @cleanup
    @knownfailureif(mpl.__version__ < '1.5')
    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'])
    def test():
        import numpy as np
        import matplotlib.pyplot as plt
        from tqdm.gui import tqdm

        with tqdm(total=100) as pbar:
            for i in range(10):
                pbar.update(10)
                plt

# Generated at 2022-06-18 11:40:14.666957
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close of class tqdm_gui.
    """
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm_gui_leave
    from tqdm.gui import tqdm_gui_close_all
    from tqdm.gui import tqdm_gui_close_all_leave

    # Test tqdm_gui
    t = tqdm_gui(range(10))
    for i in t:
        sleep(0.1)
    t.close()

    # Test tqdm_gui_leave
    t = tqdm_gui_leave(range(10))
    for i in t:
        sleep(0.1)
    t.close()

    # Test tqdm_gui_close_all

# Generated at 2022-06-18 11:40:17.415440
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm.gui import tqdm
    import time
    for _ in tqdm(range(10)):
        time.sleep(0.1)
        tqdm.clear()

# Generated at 2022-06-18 11:40:19.695432
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm(random.rand(100)):
        sleep(0.01)

# Generated at 2022-06-18 11:40:30.490174
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()

   

# Generated at 2022-06-18 11:40:33.911083
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for _ in tqdm(_range(10), gui=True):
        sleep(0.1)
    for _ in tqdm(_range(10), gui=True):
        sleep(0.1)

# Generated at 2022-06-18 11:40:35.926436
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    assert not tqdm_gui._instances

# Generated at 2022-06-18 11:40:43.255443
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .std import TqdmDeprecationWarning
    with tqdm(total=10) as t:
        t.close()
        assert t.disable
        assert t.gui
        assert not t.dynamic_miniters
        assert t.miniters == 1
        assert t.mininterval == 0.1
        assert t.maxinterval == 10.0
        assert t.unit == ''
        assert t.unit_scale
        assert t.unit_divisor == 1000
        assert t.ascii
        assert not t.desc
        assert not t.leave
        assert t.file is None
        assert t.n == 0
        assert t.total is None
        assert t.last_print_n == 0
        assert t.last_print_t is None
       

# Generated at 2022-06-18 11:41:34.032249
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # Test that tqdm_gui.close() does not raise any exception
    tqdm.close()

# Generated at 2022-06-18 11:41:36.314259
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:41:42.469019
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('tqdm.gui.tqdm_gui.plt') as mock_plt:
        t = tqdm_gui(total=10)
        t.clear()
        assert mock_plt.cla.called


if __name__ == "__main__":
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:41:49.824859
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_number
    from .std import tqdm
    from .std import trange
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning

    # Test for GUI
    with tqdm(total=10, desc='Test', leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test for GUI
    with tqdm(total=10, desc='Test', leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test for GUI

# Generated at 2022-06-18 11:41:59.973934
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from .utils import _range

    # Create a dummy tqdm_gui instance
    t = tqdm_gui(_range(100), leave=True)
    t.start_t = 0
    t.last_print_n = 0
    t.last_print_t = 0
    t.n = 0
    t.total = 100
    t.xdata = []
    t.ydata = []
    t.zdata = []
    t.ax = plt.subplot()
    t.line1, = t.ax.plot(t.xdata, t.ydata, color='b')

# Generated at 2022-06-18 11:42:03.105907
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:42:05.784673
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:42:15.994402
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True, disable=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False, disable=True):
        sleep(0.01)

# Generated at 2022-06-18 11:42:23.310638
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import time

    # Create a new figure
    fig, ax = plt.subplots(figsize=(9, 2.2))
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    plt.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a new tqdm_gui instance
    t = tqdm_gui(total=100, leave=False)
    t.fig = fig
    t.ax = ax
    t.plt = plt
    t.mpl = plt.mpl
    t.toolbar = toolbar

# Generated at 2022-06-18 11:42:32.792477
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup
    from matplotlib.testing.decorators import image_comparison

    @cleanup
    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'],
                      remove_text=True)
    def test():
        # Remember if external environment uses toolbars
        toolbar = mpl.rcParams['toolbar']
        mpl.rcParams['toolbar'] = 'None'

        # Remember if external environment is interactive
        wasion = plt.isinteractive()
        plt.ion()

        # Create a tqdm_gui instance
        t = tqdm_gui(total=100)

# Generated at 2022-06-18 11:44:24.572658
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _term_move_up
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test for #971
    with tqdm_gui(total=None) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test for #971
    with tqdm_gui(total=None) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test for #971

# Generated at 2022-06-18 11:44:33.643703
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10), desc='desc'):
        sleep(0.1)
    for i in tqdm(range(10), desc='desc', leave=True):
        sleep(0.1)
    for i in tqdm(range(10), desc='desc', leave=True, unit='i'):
        sleep(0.1)
    for i in tqdm(range(10), desc='desc', leave=True, unit='i', unit_scale=True):
        sleep(0.1)

# Generated at 2022-06-18 11:44:41.286813
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm.gui import tqdm_gui

    # Create a progressbar
    pbar = tqdm_gui(total=100, leave=False)
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    plt.rcParams['toolbar'] = 'None'
    # Create a figure
    fig, ax = plt.subplots(figsize=(9, 2.2))
    # Create a line
    line, = ax.plot([], [], color='b')
    # Set the limits of the x and y axes
    ax.set

# Generated at 2022-06-18 11:44:43.631405
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-18 11:44:52.508878
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_display():
        """Test tqdm_gui.display()"""
        # Initialize tqdm_gui
        t = tqdm_gui(total=100)
        # Test tqdm_gui.display()
        for i in range(10):
            sleep(0.1)
            t.update(10)
        # Check if the plot is correct
        xdata = t.xdata
        ydata = t.ydata
        zdata = t.zdata
        assert allclose(xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])

# Generated at 2022-06-18 11:44:54.525460
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm_gui(range(10)):
        sleep(0.1)
        tqdm_gui.clear()

# Generated at 2022-06-18 11:44:58.105124
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import time

    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
    plt.close()

# Generated at 2022-06-18 11:45:05.857901
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.testing import assert_allclose
    from .utils import FormatCustomTextType

    # Test with total
    with tqdm(total=100) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert_allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert_allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

# Generated at 2022-06-18 11:45:08.628464
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:45:11.490568
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)

if __name__ == '__main__':
    test_tqdm_gui()