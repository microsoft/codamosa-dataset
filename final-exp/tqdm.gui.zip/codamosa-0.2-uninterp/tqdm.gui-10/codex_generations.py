

# Generated at 2022-06-18 11:36:29.623156
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # Check that tqdm_gui.close() does not raise an exception
    tqdm.close()

# Generated at 2022-06-18 11:36:36.551085
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:36:44.714456
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm import tqdm_gui
    from tqdm.utils import _term_move_up

    with tqdm_gui(total=10, leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test that the progressbar is correctly displayed
    assert t.hspan.get_xy()[2, 0] == 1.0
    # Test that the progressbar is correctly erased
    assert _term_move_up() + '\r' in t.hspan.get_xy()[2, 0]

# Generated at 2022-06-18 11:36:54.918922
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100, leave=False)
    # Initialize the display
    t.display()
    # Test the display
    for i in range(100):
        sleep(0.01)
        t.update()
        t.display()
    # Close the display
    t.close()
    # Test the display
    assert allclose(t.xdata, t.ydata)
    assert allclose(t.xdata, t.zdata)
    assert allclose(t.ydata, t.zdata)
    assert allclose(t.xdata, plt.gca().get_xlim())

# Generated at 2022-06-18 11:37:06.777846
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import random
    from numpy.testing import assert_equal
    from tqdm.gui import tqdm_gui
    from tqdm.gui import trange
    from tqdm.gui import tqdm
    from tqdm.gui import tgrange

    # Test tqdm_gui
    for _ in tqdm_gui(range(10)):
        sleep(0.1)

    # Test trange
    for _ in trange(10):
        sleep(0.1)

    # Test tqdm
    for _ in tqdm(range(10)):
        sleep(0.1)

    # Test tgrange
    for _ in tgrange(10):
        sleep(0.1)

    # Test tqdm_

# Generated at 2022-06-18 11:37:15.881362
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Simulate a loop
    for i in range(100):
        sleep(0.01)
        t.update(1)
    # Close the tqdm_gui instance
    t.close()

    # Check if the plot is correct
    xdata = t.xdata
    ydata = t.ydata
    zdata = t.zdata
    assert allclose(xdata, [i * 1. for i in range(100)])
    assert allclose(ydata, [1. for i in range(100)])
    assert allclose(zdata, [1. for i in range(100)])

   

# Generated at 2022-06-18 11:37:25.963101
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import normal

    # Test with no total
    with tqdm(unit="B", unit_scale=True, miniters=1,
              desc="Downloading..") as t:
        for i in range(100):
            sleep(0.01)
            t.update(randint(0, 1000))
        t.set_description("Done!")

    # Test with total
    with tqdm(total=100, unit="B", unit_scale=True, miniters=1,
              desc="Downloading..") as t:
        for i in range(100):
            sleep(0.01)

# Generated at 2022-06-18 11:37:31.993745
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update

# Generated at 2022-06-18 11:37:40.172465
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()
    assert_allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)


# Generated at 2022-06-18 11:37:50.074908
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Test with total
    with tqdm(total=100) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert allclose(t.xdata, [10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

# Generated at 2022-06-18 11:38:13.775727
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:38:24.189908
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randint

    # Test with no total
    with tqdm_gui(unit="i", unit_scale=True, miniters=1,
                  mininterval=0.1, smoothing=0) as pbar:
        for i in range(20):
            sleep(random())
            pbar.update(i)

    # Test with total
    with tqdm_gui(total=100, unit="i", unit_scale=True, miniters=1,
                  mininterval=0.1, smoothing=0) as pbar:
        for i in range(100):
            sleep(random())
            pbar.update(i)

    # Test with total and dynamic miniters

# Generated at 2022-06-18 11:38:26.589319
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.close()

# Generated at 2022-06-18 11:38:37.495732
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep

    # Create a new figure
    plt.figure()
    # Create a new subplot from a grid of 1x1
    ax = plt.subplot(111)
    # Plot a line
    ax.plot([1, 2, 3])
    # Set the labels
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    # Show the grid
    ax.grid()

    # Create a new figure
    plt.figure()
    # Create a new subplot from a grid of 1x1
    ax = plt.subplot(111)
    # Plot a line
    ax.plot([1, 2, 3])
    # Set the labels

# Generated at 2022-06-18 11:38:38.885664
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:38:40.924115
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()


# Generated at 2022-06-18 11:38:42.963539
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()


# Generated at 2022-06-18 11:38:54.345005
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy import linspace
    from numpy import array
    from numpy import concatenate
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import sqrt
    from numpy import exp
    from numpy import pi
    from numpy import sin
    from numpy import cos
    from numpy import log
    from numpy import log10
    from numpy import log2
    from numpy import log1p
    from numpy import ceil
    from numpy import floor
    from numpy import trunc
    from numpy import sinh
    from numpy import cosh
    from numpy import tanh
    from numpy import arcsin
    from numpy import arccos
    from numpy import arct

# Generated at 2022-06-18 11:39:03.470753
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import random
    from numpy.testing import assert_array_equal
    from matplotlib.pyplot import close


# Generated at 2022-06-18 11:39:05.513062
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)

# Generated at 2022-06-18 11:39:31.356390
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    from time import sleep
    from numpy import random
    from tqdm.gui import tqdm_gui
    from tqdm.gui import trange
    from tqdm.gui import tqdm
    from tqdm.gui import tgrange

    # Test tqdm_gui
    for i in tqdm_gui(random.rand(100)):
        sleep(0.01)

    # Test tgrange
    for i in tgrange(100):
        sleep(0.01)

    # Test tqdm
    for i in tqdm(random.rand(100)):
        sleep(0.01)

    # Test trange
    for i in trange(100):
        sleep(0.01)

    # Test tqdm_gui with

# Generated at 2022-06-18 11:39:39.626906
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    close(t.fig)

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update

# Generated at 2022-06-18 11:39:46.380965
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False, disable=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False, disable=False):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False, disable=False, unit='iB'):
        sleep(0.1)

# Generated at 2022-06-18 11:39:50.729563
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:40:01.906741
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop'):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep

# Generated at 2022-06-18 11:40:10.949838
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    # Initialize tqdm_gui
    t = tqdm_gui(total=100)
    # Test if tqdm_gui is initialized
    assert t.disable is False
    assert t.mininterval == 0.5
    assert t.maxinterval == 10.0
    assert t.miniters == 1
    assert t.ascii is False
    assert t.unit == ''
    assert t.unit_scale is False
    assert t.unit_divisor is 1
    assert t.dynamic_ncols is False
    assert t.smoothing is 0.3
    assert t.avg_time is None

# Generated at 2022-06-18 11:40:20.483563
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import platform
    from os import getpid
    from os import kill
    from signal import SIGKILL
    from multiprocessing import Process

    def test_tqdm_gui_close_process():
        t = tqdm_gui(total=100)
        for i in range(100):
            sleep(0.01)
            t.update(1)
        t.close()

    if platform == 'win32':
        # Windows does not support SIGKILL
        p = Process(target=test_tqdm_gui_close_process)
        p.start()
        p.join()
    else:
        p = Process(target=test_tqdm_gui_close_process)
        p.start()
        sleep(0.1)

# Generated at 2022-06-18 11:40:24.130731
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:40:27.367754
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    for _ in tqdm_gui(range(10)):
        time.sleep(0.01)
        tqdm_gui.clear()
        time.sleep(0.01)

# Generated at 2022-06-18 11:40:30.565751
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # test that the progressbar is closed
    assert tqdm.disable

# Generated at 2022-06-18 11:41:08.882134
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Create a tqdm_gui instance
    t = tqdm(total=100)
    # Close the tqdm_gui instance
    t.close()
    # Check if the tqdm_gui instance has been removed from the list of
    # tqdm_gui instances
    assert t not in tqdm._instances
    # Check if the toolbars have been restored
    assert mpl.rcParams['toolbar'] == toolbar
    # Check if the interactive mode has been

# Generated at 2022-06-18 11:41:16.408200
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    from time import sleep
    from numpy import array, allclose

    t = tqdm_gui(total=10)
    for i in range(10):
        t.update(1)
        sleep(0.1)
    t.close()
    assert allclose(array(t.xdata), array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90]))
    assert allclose(array(t.ydata), array([0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]))

# Generated at 2022-06-18 11:41:25.059125
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import uniform
    from numpy import arange
    from matplotlib import pyplot as plt
    from matplotlib import animation

    # Fix #971
    t = tqdm_gui(None)
    t.close()
    # Fix #971
    t = tqdm_gui(None, total=None)
    t.close()

    # Fix #971
    t = tqdm_gui(None, total=None, leave=True)
    t.close()

    # Fix #971
    t = tqdm_gui(None, total=None, leave=False)
    t.close()

    # Fix #971
    t = tqdm_gui(None, total=None, leave=False, disable=True)
    t.close()

# Generated at 2022-06-18 11:41:31.390863
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100, leave=False, mininterval=0.1)
    # Test if the instance is correctly created
    assert t.total == 100
    assert t.leave == False
    assert t.mininterval == 0.1
    assert t.disable == False
    assert t.gui == True
    assert t.mpl == plt
    assert t.plt == plt
    assert t.toolbar == 'None'
    assert t.wasion == False
    assert t.ax.get_xlabel() == "percent"
    assert t.ax.get_ylabel() == "it/s"
   

# Generated at 2022-06-18 11:41:35.370047
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear(i)
        if i == 7:
            tqdm_gui.clear(i)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:41:37.920587
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()


# Generated at 2022-06-18 11:41:40.523048
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:41:46.027740
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()
    assert_array_equal(array(t.xdata), array(t.ydata))
    assert_array_equal(array(t.xdata), array(t.zdata))

# Generated at 2022-06-18 11:41:54.971568
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from numpy.testing import assert_array_equal

    # Test with no total
    with tqdm_gui(unit="B", unit_scale=True, miniters=1,
                  mininterval=0.1, smoothing=0) as t:
        for i in range(20):
            sleep(randint(10) / 100)
            t.update(randint(1000))

    # Test with total
    with tqdm_gui(total=100, unit="B", unit_scale=True, miniters=1,
                  mininterval=0.1, smoothing=0) as t:
        for i in range(20):
            sleep(randint(10) / 100)

# Generated at 2022-06-18 11:41:59.384285
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()