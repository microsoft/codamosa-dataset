

# Generated at 2022-06-18 11:36:40.591065
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:36:46.223232
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time
    from tqdm.gui import tqdm_gui
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
    plt.close()

# Generated at 2022-06-18 11:36:51.220612
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from matplotlib import pyplot as plt
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    plt.close(t.fig)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:37:02.015205
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from sys import stderr
    from io import StringIO
    from contextlib import contextmanager
    from unittest import TestCase

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = stderr, stderr
        try:
            stderr, stderr = new_out, new_err
            yield stderr, stderr
        finally:
            stderr, stderr = old_out, old_err


# Generated at 2022-06-18 11:37:08.023946
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:37:11.854055
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.01)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:37:18.595587
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from time import sleep
    import matplotlib.pyplot as plt
    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    # Test closing
    pbar = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        pbar.update(10)
    pbar.close()
    # Test closing with leave
    pbar = tqdm_

# Generated at 2022-06-18 11:37:27.870175
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm_gui
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Create a tqdm_gui object
    t = tqdm_gui(total=100)
    # Close the tqdm_gui object
    t.close()
    # Check if the tqdm_gui object is closed
    assert t.disable == True
    # Check if the toolbars are restored
    assert mpl.rcParams['toolbar'] == toolbar
    # Check if the interactive mode is restored
    assert plt.isinteractive() == wasion


# Generated at 2022-06-18 11:37:37.256604
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    import matplotlib.pyplot as plt
    import time
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm
    from tqdm.gui import trange

    # Test tqdm_gui
    for _ in tqdm_gui(range(10)):
        time.sleep(0.1)

    # Test tgrange
    for _ in tgrange(10):
        time.sleep(0.1)

    # Test tqdm
    for _ in tqdm(range(10)):
        time.sleep(0.1)

    # Test trange
    for _ in trange(10):
        time.sleep

# Generated at 2022-06-18 11:37:42.427127
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert plt.fignum_exists(t.fig.number)
    t.clear()
    assert not plt.fignum_exists(t.fig.number)

# Generated at 2022-06-18 11:38:04.165757
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import choice

    # Initialize tqdm_gui
    t = tqdm_gui(total=100)
    # Test with total=100
    for i in range(100):
        t.update()
        sleep(uniform(0.01, 0.1))
    # Test with total=None
    t = tqdm_gui(total=None)
    for i in range(100):
        t.update()
        sleep(uniform(0.01, 0.1))
    # Test with total=None and random update
    t = tqdm_gui(total=None)

# Generated at 2022-06-18 11:38:09.627112
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm_gui
    t = tqdm_gui(total=1)
    t.close()
    assert t.disable is True
    assert t.mpl.rcParams['toolbar'] == 'None'
    assert t.wasion is False
    assert t.leave is False
    assert t.fig.canvas.manager.window is None
    assert t.fig.canvas.manager.toolbar is None
    assert t.fig.canvas.manager.toolmanager is None
    assert t.fig.canvas.manager.window is None
    assert t.fig.canvas.manager.toolbar is None
    assert t.fig.canvas.manager.toolmanager is None
    assert t.fig.canvas.manager.window is None
    assert t.fig.canvas.manager.toolbar is None

# Generated at 2022-06-18 11:38:12.000308
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()


# Generated at 2022-06-18 11:38:15.403147
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:38:21.186255
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    assert tqdm.disable == True
    assert tqdm.mpl.rcParams['toolbar'] == 'None'
    assert tqdm.wasion == False
    assert tqdm.plt.isinteractive() == False
    assert tqdm.plt.get_fignums() == []

# Generated at 2022-06-18 11:38:32.291117
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import linspace
    from matplotlib import pyplot as plt

    # Test 1
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)

    # Test 2
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)
        pbar.close()

    # Test 3
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)
        pbar.close()
        pbar.display()

    # Test 4

# Generated at 2022-06-18 11:38:40.794025
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    sleep(0.5)
   

# Generated at 2022-06-18 11:38:46.282275
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)
    with tqdm_gui(total=100, unit='it') as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)
    with tqdm_gui(total=100, unit='it', unit_scale=True) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)
    with tqdm_gui(total=100, unit='it', unit_scale=True, miniters=1) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)

# Generated at 2022-06-18 11:38:50.484950
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()
    tqdm_gui.close()


# Generated at 2022-06-18 11:38:55.785913
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm import tqdm_gui
    from tqdm.utils import _term_move_up
    from tqdm.utils import _range

    for _ in tqdm_gui(_range(10), desc='test', leave=True):
        sleep(0.1)
        _term_move_up()
        print('test')

# Generated at 2022-06-18 11:39:30.049244
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn

    # Test with total
    with tqdm(total=100) as pbar:
        for i in range(100):
            sleep(rand())
            pbar.update(1)

    # Test without total
    with tqdm() as pbar:
        for i in range(100):
            sleep(rand())
            pbar.update(1)

    # Test with total and smoothing
    with tqdm(total=100, smoothing=0.1) as pbar:
        for i in range(100):
            sleep(rand())
            pbar.update(1)

    # Test without total and smoothing

# Generated at 2022-06-18 11:39:38.584043
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(random.rand())
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(random.rand())

# Generated at 2022-06-18 11:39:40.932571
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for i in tqdm(_range(10), desc='test', leave=True):
        sleep(0.1)

# Generated at 2022-06-18 11:39:42.730181
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:39:45.946823
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.01)

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-18 11:39:57.920456
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import random
    from numpy.random import uniform
    from numpy.random import exponential
    from numpy.random import normal
    from numpy.random import lognormal
    from numpy.random import weibull

    # Test for progressbar
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(uniform(0, 0.1))
            pbar.update()

    # Test for progressbar with random sleep times
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(exponential(0.1))
            pbar.update()

    # Test for progressbar with random sleep

# Generated at 2022-06-18 11:40:07.762376
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.testing import assert_allclose
    from .std import tqdm

    for i in tqdm(range(10), desc='test_tqdm_gui_display', leave=False):
        sleep(randint(1, 10) / 100)

    # test if the display method works
    t = tqdm(range(10), desc='test_tqdm_gui_display', leave=False)
    for i in t:
        sleep(randint(1, 10) / 100)
        t.display()

    # test if the display method works
    t = tqdm(range(10), desc='test_tqdm_gui_display', leave=False)

# Generated at 2022-06-18 11:40:15.156590
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import version_info
    from .utils import _range

    # Test GUI
    with tqdm(total=10) as t:
        for i in _range(10):
            sleep(0.1)
            t.update(1)
    # Test GUI with `leave`
    with tqdm(total=10, leave=True) as t:
        for i in _range(10):
            sleep(0.1)
            t.update(1)
    # Test GUI with `leave` and `disable`
    with tqdm(total=10, leave=True, disable=True) as t:
        for i in _range(10):
            sleep(0.1)
            t.update(1)
    # Test GUI with `leave` and `disable` and `miniters`

# Generated at 2022-06-18 11:40:18.063026
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:40:28.927755
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm
    from tqdm.gui import tqdm_gui
    from tqdm.gui import trange
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Create a tqdm_gui instance
    t = tqdm(total=10)
    # Close the tqdm_gui instance
    t.close()
    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode