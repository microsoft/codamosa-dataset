

# Generated at 2022-06-18 11:36:34.355839
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .utils import _range
    for i in tqdm(_range(10)):
        pass
    tqdm.close()
    assert not tqdm._instances

# Generated at 2022-06-18 11:36:45.006845
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt
    from matplotlib.testing.decorators import image_comparison
    from .utils import FormatCustom

    @image_comparison(baseline_images=['tqdm_gui_display'],
                      extensions=['png'], remove_text=True)
    def doit():
        # Create a figure with a single subplot
        f, ax = plt.subplots(1, 1)
        # Set up the axes with gridspec
        gs = plt.GridSpec(1, 1)
        ax = plt.subplot(gs[0])
        # Set the labels
        ax.set_xlabel('x label')
        ax.set_ylabel('y label')
        # Set the limits


# Generated at 2022-06-18 11:36:48.345517
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # TODO: test if the figure is closed


# Generated at 2022-06-18 11:36:58.881515
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import time
    from numpy.testing import assert_array_almost_equal
    from .utils import FormatCustom
    from .std import tqdm

    with tqdm(total=100, unit_scale=True, unit='B',
              bar_format=FormatCustom("{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]")) as t:
        for i in range(10):
            t.update()
            time.sleep(0.1)
        assert_array_almost_equal(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])

# Generated at 2022-06-18 11:37:00.967929
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:37:12.125269
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep

    for i in tqdm_gui(range(2), desc='1st loop', leave=False):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
                plt.pause(0.001)
    plt.close()


# Generated at 2022-06-18 11:37:23.417193
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:37:33.641800
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_display():
        with tqdm_gui(total=100) as t:
            for i in range(100):
                sleep(0.01)
                t.update()


# Generated at 2022-06-18 11:37:40.824536
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.close()

    assert_allclose(t.xdata, t.ydata, atol=1e-2)
    assert_allclose(t.xdata, t.zdata, atol=1e-2)
    assert allclose(t.xdata[-1], 100)
    assert allclose(t.ydata[-1], t.zdata[-1], atol=1e-2)
    assert allclose(t.ydata[-1], t.zdata[-1], atol=1e-2)



# Generated at 2022-06-18 11:37:45.004320
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:38:20.298851
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()
    assert_array_equal(array(t.xdata), array([10, 20, 30, 40, 50, 60, 70, 80, 90, 100]))
    assert_array_equal(array(t.ydata), array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))

# Generated at 2022-06-18 11:38:23.544723
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:38:34.507998
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    from time import sleep
    from sys import platform
    from os import getpid
    from os import kill
    from signal import SIGKILL
    from subprocess import Popen
    from subprocess import PIPE
    from subprocess import STDOUT
    from subprocess import check_output
    from subprocess import CalledProcessError
    from tempfile import mkdtemp
    from tempfile import mkstemp
    from shutil import rmtree
    from os.path import join
    from os.path import isfile
    from os.path import isdir
    from os import remove
    from os import close
    from os import devnull
    from os import getcwd
    from os import chdir
    from os import listdir
    from os import environ
    from os import getenv

# Generated at 2022-06-18 11:38:42.091943
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import image_comparison

    rcParams['toolbar'] = 'None'
    plt.ioff()

    @image_comparison(baseline_images=['tqdm_gui_display'],
                      extensions=['png'], remove_text=True)
    def test():
        t = tqdm_gui(total=100)
        for i in range(100):
            t.update()
            sleep(0.01)
        t.close()

    test()

    # Test if the progressbar is correctly displayed
    t = tqdm_gui(total=100)

# Generated at 2022-06-18 11:38:53.700042
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update()
    with tqdm_gui(total=100, unit='iB', unit_scale=True) as t:
        for i in range(100):
            sleep(0.01)
            t.update()
    with tqdm_gui(total=100, unit_scale=True) as t:
        for i in range(100):
            sleep(0.01)
            t.update()
    with tqdm_gui(total=100, unit_scale=True, unit_divisor=1024) as t:
        for i in range(100):
            sleep(0.01)
            t.update()

# Generated at 2022-06-18 11:39:02.989312
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint

    # Initialize tqdm_gui
    t = tqdm_gui(total=100, leave=False)
    # Test progressbar
    for i in range(100):
        sleep(randint(1, 5) / 100)
        t.update()
    # Test instantaneous rate
    t.clear()
    t.display()
    assert allclose(t.ydata[-1], 1.0)
    # Test overall rate
    t.clear()
    t.display()
    assert allclose(t.zdata[-1], 1.0)
    # Test progressbar
    t.clear()
    t.display()

# Generated at 2022-06-18 11:39:10.828254
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()

# Generated at 2022-06-18 11:39:18.901785
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import _range
    from .std import tqdm
    from .gui import tqdm_gui
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Test tqdm_gui
    with tqdm_gui(_range(10), leave=True) as t:
        for i in t:
            pass
    assert mpl.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion

    # Test tqdm
    with tqdm(_range(10), leave=True) as t:
        for i in t:
            pass
    assert m

# Generated at 2022-06-18 11:39:22.705279
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:39:26.016736
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:00.774617
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal
    from .utils import FormatCustomTextType

    # Test with total
    with tqdm_gui(total=10, leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test without total
    with tqdm_gui(leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test with total and bar_format

# Generated at 2022-06-18 11:40:03.576711
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import stderr
    for i in tqdm_gui(range(10), file=stderr):
        sleep(0.1)

# Generated at 2022-06-18 11:40:12.477686
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import time
    from tqdm.gui import tqdm_gui

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)

    # Test with total and smoothing
    with tqdm_gui(total=100, smoothing=0.1) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

    # Test

# Generated at 2022-06-18 11:40:22.367084
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose

    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-18 11:40:32.437546
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose

    t = tqdm_gui(total=100, leave=False)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

    t = tqdm_gui(total=100, leave=False)
    for i in range(10):
        t.update(10)
        sleep(0.1)

# Generated at 2022-06-18 11:40:38.982654
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Update the progressbar
    for i in range(10):
        t.update()
        sleep(0.1)
    # Get the data from the progressbar
    xdata = array(t.xdata)
    ydata = array(t.ydata)
    zdata = array(t.zdata)
    # Close the progressbar
    t.close()
    # Check the data
    assert_array_equal(xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90])

# Generated at 2022-06-18 11:40:40.837156
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:45.673682
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Create a tqdm_gui object
    t = tqdm_gui(total=100)
    # Close the tqdm_gui object
    t.close()
    # Check if the tqdm_gui object is closed
    assert t.disable == True
    # Check if the toolbars are restored
    assert mpl.rcParams['toolbar'] == toolbar
    # Check if the interactive mode is restored
    assert plt.isinteractive() == wasion

# Generated at 2022-06-18 11:40:46.674741
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:40:48.496120
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:41:41.540050
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import time
    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    assert plt.isinteractive() == False
    assert plt.get_fignums() == []
    assert plt.get_backend() == 'module://ipykernel.pylab.backend_inline'
    assert plt.rcParams['toolbar'] == 'None'


# Generated at 2022-06-18 11:41:49.263852
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import random
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(random.rand())
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(random.rand())
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(random.rand())
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(random.rand())
    t.close()

   

# Generated at 2022-06-18 11:41:51.401409
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for _ in tqdm_gui(range(3)):
        sleep(0.1)

# Generated at 2022-06-18 11:42:02.183219
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:42:06.719335
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Update the progressbar
    for i in range(100):
        t.update(1)
        sleep(0.01)
    # Clear the progressbar
    t.clear()
    # Close the progressbar
    t.close()

# Generated at 2022-06-18 11:42:16.840051
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _term_move_up
    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.display()
            sleep(0.01)
            t.update()
    # Test for #971
    with tqdm_gui(total=None) as t:
        for i in range(100):
            t.display()
            sleep(0.01)
            t.update()
    # Test for #971
    with tqdm_gui(total=None) as t:
        for i in range(100):
            t.display()
            sleep(0.01)
            t.update()
    # Test for #9

# Generated at 2022-06-18 11:42:23.731447
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()
    assert allclose(t.xdata, [10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [100, 100, 100, 100, 100, 100, 100, 100, 100, 100])
    assert allclose(t.zdata, [100, 100, 100, 100, 100, 100, 100, 100, 100, 100])
    close(t.fig)

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep

# Generated at 2022-06-18 11:42:33.140077
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import stderr
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def nostderr():
        save_stderr = stderr
        stderr = StringIO()
        yield
        stderr = save_stderr

    with nostderr():
        with tqdm_gui(total=10) as t:
            for i in range(10):
                sleep(0.1)
                t.update()
        assert t.disable
        assert t.n == 10
        assert t.last_print_n == 10
        assert t.last_print_t == t.start_t + 1
        assert t.total == 10
        assert t.unit == 'it'
        assert t.unit_scale is False
        assert t.minit

# Generated at 2022-06-18 11:42:41.989893
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm.gui import tqdm_gui

    # test progressbar
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)

    # test plot
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)
            pbar.set_description("test")
            pbar.set_postfix(OrderedDict(loss=np.random.random()))

    # test plot with no total

# Generated at 2022-06-18 11:42:43.708615
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()

# Generated at 2022-06-18 11:44:28.957835
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    for i in tqdm_gui(range(10)):
        sleep(random())

# Generated at 2022-06-18 11:44:37.847483
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import random
    from numpy import linspace
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar

    from PyQt4 import QtGui, QtCore

    class Window(QtGui.QDialog):
        def __init__(self, parent=None):
            super(Window, self).__init__(parent)

            # a figure instance to plot on
            self.figure = plt.figure()

            # this is the Canvas Widget that displays the `figure`
            # it takes the `figure` instance as a parameter to __init__
            self

# Generated at 2022-06-18 11:44:39.829875
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-18 11:44:41.356592
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    # TODO: assert that the figure is closed

# Generated at 2022-06-18 11:44:46.131363
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    import time
    t = tqdm_gui(total=100)
    for i in range(100):
        time.sleep(0.01)
        t.update(1)
    t.close()
    assert plt.isinteractive() == False
    assert mpl.rcParams['toolbar'] == 'None'
    assert plt.get_fignums() == []

# Generated at 2022-06-18 11:44:54.410180
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:44:59.430569
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(randint(1, 10) * 0.01)
        t.update()
    t.close()
    assert allclose(t.xdata, t.ydata)
    assert allclose(t.xdata, t.zdata)

# Generated at 2022-06-18 11:45:01.972520
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:45:09.658611
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10
    assert t.last_print_t == t.start_t + 1
    assert t.total == 10
    assert t.disable is True
    assert t.leave is False
    assert t.gui is True
    assert t.mininterval == 0.5
    assert t.miniters == 1
    assert t.maxinterval == 10.0
    assert t.maxiters == 0
    assert t.unit == ''
    assert t.unit_scale is False
    assert t.dynamic_ncols is False
    assert t.smoothing == 0

# Generated at 2022-06-18 11:45:14.917590
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm
    from .std import TqdmTypeError

    # Test for TypeError
    try:
        tqdm(None)
    except TqdmTypeError:
        pass
    else:
        raise AssertionError()

    # Test for GUI
    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()