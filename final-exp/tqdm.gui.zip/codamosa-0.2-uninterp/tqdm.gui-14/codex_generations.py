

# Generated at 2022-06-18 11:36:47.104181
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-18 11:36:57.161416
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 100)
        t.update()
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 100)
        t.update()
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 100)
        t.update()
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 100)

# Generated at 2022-06-18 11:36:59.881849
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.rand(100)):
        sleep(0.01)

# Generated at 2022-06-18 11:37:03.051061
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from sys import stderr
    from tqdm.gui import tqdm
    for i in tqdm(range(10), file=stderr):
        sleep(0.1)

# Generated at 2022-06-18 11:37:08.218128
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('tqdm.gui.tqdm.clear') as mock_clear:
        tqdm_gui(range(10)).clear()
        assert mock_clear.call_count == 0

# Generated at 2022-06-18 11:37:16.800171
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from random import random
    from numpy import array

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update()
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(i)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(i + 1)
    t

# Generated at 2022-06-18 11:37:19.577321
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:37:23.785281
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from .std import tqdm
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

# Generated at 2022-06-18 11:37:34.046580
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm
    from .std import tgrange
    from .std import trange
    from .std import tqdm_gui
    from .std import tgrange_gui
    from .std import trange_gui
    from .std import tqdm_notebook
    from .std import tgrange_notebook
    from .std import trange_notebook
    from .std import tqdm_pandas
    from .std import tqdm_gui_pandas
    from .std import tqdm_notebook_pandas
    from .std import tqdm_pandas_gui
    from .std import tqdm_pandas_notebook
    from .std import tqdm_pandas_gui_notebook
    from .std import tqdm_pandas_

# Generated at 2022-06-18 11:37:37.278632
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(3)):
        sleep(0.1)
    # Test that tqdm_gui.close() does not raise an exception
    tqdm_gui(range(3)).close()

# Generated at 2022-06-18 11:38:00.467440
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint

# Generated at 2022-06-18 11:38:07.178659
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    from tqdm import tqdm_gui

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a progressbar
    pbar = tqdm_gui(total=100, leave=False)

    # Update progressbar
    for i in range(100):
        pbar.update(1)
        sleep(0.01)

    # Close progressbar
    pbar.close()

   

# Generated at 2022-06-18 11:38:16.603544
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import exponential
    from numpy.random import normal
    from numpy.random import poisson
    from numpy.random import binomial
    from numpy.random import negative_binomial
    from numpy.random import geometric
    from numpy.random import hypergeometric
    from numpy.random import pareto
    from numpy.random import weibull
    from numpy.random import power
    from numpy.random import laplace
    from numpy.random import gumbel
    from numpy.random import logistic
    from numpy.random import lognormal

# Generated at 2022-06-18 11:38:26.505461
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from numpy.testing import assert_array_equal

    # Test for total
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(randint(1, 10) / 100)
            pbar.update()
    # Test for no total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(randint(1, 10) / 100)
            pbar.update()
    # Test for total and smoothing
    with tqdm_gui(total=10, smoothing=0.1) as pbar:
        for i in range(10):
            sleep(randint(1, 10) / 100)

# Generated at 2022-06-18 11:38:37.378922
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import version_info
    from os import get_terminal_size

    # Test basic GUI
    with tqdm(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test nested GUI
    with tqdm(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
            with tqdm(total=10) as t2:
                for j in range(10):
                    sleep(0.1)
                    t2.update()

    # Test nested GUI with manual leave
    with tqdm(total=10, leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:38:39.322739
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    assert True

# Generated at 2022-06-18 11:38:50.446605
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import choice
    from numpy.random import shuffle
    from numpy import array
    from numpy import concatenate
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import exp
    from numpy import log
    from numpy import sin
    from numpy import cos
    from numpy import tan
    from numpy import arcsin
    from numpy import arccos
    from numpy import arctan
    from numpy import sinh

# Generated at 2022-06-18 11:39:00.505793
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from numpy.testing import assert_array_equal

    # Test with total
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(randint(1, 10) / 1000)
            t.update()
    assert_array_equal(array(t.xdata), array(t.ydata))
    assert_array_equal(array(t.xdata), array(t.zdata))

    # Test without total
    with tqdm_gui() as t:
        for i in range(100):
            sleep(randint(1, 10) / 1000)
            t.update()
    assert_array_equal(array(t.xdata), array(t.ydata))

# Generated at 2022-06-18 11:39:03.193443
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    plt.close()

# Generated at 2022-06-18 11:39:10.996799
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import random
    from numpy.random import uniform
    from numpy.random import normal
    from numpy.random import exponential
    from numpy.random import poisson
    from numpy.random import binomial
    from numpy.random import beta
    from numpy.random import gamma
    from numpy.random import lognormal
    from numpy.random import vonmises
    from numpy.random import pareto
    from numpy.random import weibull
    from numpy.random import zipf
    from numpy.random import triangular
    from numpy.random import dirichlet
    from numpy.random import multinomial
    from numpy.random import multivariate_normal

# Generated at 2022-06-18 11:39:44.994565
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close
    t = tqdm_gui(total=100, leave=False)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])
    close(t.fig)

# Generated at 2022-06-18 11:39:56.761953
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
    close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
    t.close()

    t = t

# Generated at 2022-06-18 11:40:03.947761
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_close():
        rcParams['toolbar'] = 'toolbar'
        plt.ion()
        plt.figure()
        t = tqdm_gui(total=1)
        t.close()
        assert rcParams['toolbar'] == 'toolbar'
        assert not plt.isinteractive()

    test_tqdm_gui_close()

# Generated at 2022-06-18 11:40:12.722672
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy.testing import assert_array_equal
    from .std import tqdm
    from .utils import _range

    # Test with total
    with tqdm(total=10) as t:
        for i in _range(10):
            sleep(0.01)
            t.update()
    assert_array_equal(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert_array_equal(t.ydata, [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01,
                                 0.01, 0.01, 0.01, 0.01])

# Generated at 2022-06-18 11:40:22.911231
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import image_comparison

    @image_comparison(baseline_images=['tqdm_gui'], extensions=['png'])
    def test_tqdm_gui_image():
        # Test tqdm_gui
        rcParams['toolbar'] = 'None'
        with tqdm_gui(total=100) as pbar:
            for i in range(100):
                sleep(0.01)
                pbar.update(1)
        # Test tqdm_gui with manual close

# Generated at 2022-06-18 11:40:29.902660
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Test
    t = tqdm_gui(total=10)
    t.close()
    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()

# Generated at 2022-06-18 11:40:32.647050
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:40:35.455158
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    # test that the figure is closed
    assert tqdm_gui.fig.canvas.manager.window is None

# Generated at 2022-06-18 11:40:38.061626
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:40:44.530977
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import random
    from numpy import linspace
    from numpy import arange
    from numpy import array
    from numpy import concatenate
    from numpy import zeros
    from numpy import ones
    from numpy import nan
    from numpy import inf
    from numpy import isinf
    from numpy import isnan
    from numpy import ma
    from numpy import random
    from numpy import arange
    from numpy import array
    from numpy import concatenate
    from numpy import zeros
    from numpy import ones
    from numpy import nan
    from numpy import inf
    from numpy import isinf
    from numpy import isnan
    from numpy import ma
    from numpy import random
    from numpy import arange
   

# Generated at 2022-06-18 11:41:44.129626
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:41:51.843901
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from time import sleep
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 60)
    ax.invert_xaxis()
    ax.set_xlabel("seconds")
    ax.legend(("cur", "est"), loc='lower left')
    ax.grid()

# Generated at 2022-06-18 11:41:54.807324
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()
            pbar.display()

# Generated at 2022-06-18 11:42:05.310331
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import random
    from numpy.random import randn

    # Test with total
    with tqdm_gui(total=100, leave=False) as pbar:
        for i in range(100):
            sleep(random() * 0.01)
            pbar.update(1)
    # Test without total
    with tqdm_gui(leave=False) as pbar:
        for i in range(100):
            sleep(random() * 0.01)
            pbar.update(1)
    # Test with total and smoothing
    with tqdm_gui(total=100, smoothing=0.5, leave=False) as pbar:
        for i in range(100):
            sleep

# Generated at 2022-06-18 11:42:07.921816
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()


# Generated at 2022-06-18 11:42:14.189857
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update()
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(random.randint(1, 10))
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(random.randint(1, 10))
            p

# Generated at 2022-06-18 11:42:22.262389
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy.random import randint
    from numpy import array, arange
    from matplotlib.pyplot import plot, show, close

    # Test with total
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(randint(1, 10) / 100)
        t.update()
    t.close()

    # Test without total
    t = tqdm_gui()
    for i in range(100):
        sleep(randint(1, 10) / 100)
        t.update()
    t.close()

    # Test with random data
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(randint(1, 10) / 100)
       

# Generated at 2022-06-18 11:42:31.865057
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import time

    def test_tqdm_gui_display_1():
        # Test with total
        with tqdm_gui(total=100) as pbar:
            for i in range(100):
                pbar.update()
                time.sleep(0.1)
        plt.close(pbar.fig)

    def test_tqdm_gui_display_2():
        # Test without total
        with tqdm_gui() as pbar:
            for i in range(100):
                pbar.update()
                time.sleep(0.1)
        plt.close(pbar.fig)


# Generated at 2022-06-18 11:42:34.565775
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.close()

# Generated at 2022-06-18 11:42:37.275852
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from random import random
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(random())
    tqdm.close()

# Generated at 2022-06-18 11:44:31.412945
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:44:33.962636
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.01)
    assert True

# Generated at 2022-06-18 11:44:41.536549
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui.clear()"""
    from time import sleep
    from random import random
    from numpy import array
    from numpy.testing import assert_array_equal

    # Test with total
    with tqdm(total=10) as pbar:
        for _ in range(10):
            sleep(random())
            pbar.update()
    assert_array_equal(array(pbar.xdata), array(range(10)))
    assert_array_equal(array(pbar.ydata), array([1] * 10))
    assert_array_equal(array(pbar.zdata), array([1] * 10))

    # Test without total
    with tqdm() as pbar:
        for _ in range(10):
            sleep(random())
            pbar.update()
    assert_array

# Generated at 2022-06-18 11:44:43.929780
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-18 11:44:52.879196
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from io import StringIO
    import sys
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Test tqdm_gui.close()

# Generated at 2022-06-18 11:45:00.903907
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='desc'):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='desc', total=20):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='desc', total=20, leave=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='desc', total=20, leave=True,
                      disable=True):
        sleep(0.1)

# Generated at 2022-06-18 11:45:08.836340
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint

# Generated at 2022-06-18 11:45:11.104156
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:45:15.088514
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import stdout
    from os import getpid
    from random import random

    with tqdm(total=100, file=stdout, desc="PID: %d" % getpid()) as pbar:
        for i in range(100):
            sleep(random() / 10)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:45:23.220968
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close
    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        sleep(0.01)
        t.update()
    close(t.fig)