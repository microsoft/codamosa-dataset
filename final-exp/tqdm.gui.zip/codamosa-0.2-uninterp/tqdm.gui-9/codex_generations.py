

# Generated at 2022-06-18 11:36:46.124792
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Initialize the plot
    t.display()
    # Update the plot
    for i in range(100):
        t.update()
        sleep(0.01)
    # Close the plot
    t.close()
    # Check the plot
    assert allclose(t.xdata, t.ydata)
    assert allclose(t.xdata, t.zdata)
    assert allclose(t.xdata, t.xdata)
    assert allclose(t.ydata, t.zdata)
    assert allclose(t.ydata, t.ydata)

# Generated at 2022-06-18 11:36:56.301751
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm_gui
    from tqdm.gui import trange
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time
    import sys

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Test tqdm_gui
    for i in tqdm_gui(range(10)):
        time.sleep(0.1)

    # Test trange

# Generated at 2022-06-18 11:37:01.204851
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()
    assert allclose(array(t.ydata), array(t.zdata))

# Generated at 2022-06-18 11:37:04.781348
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import linspace
    for i in tqdm(linspace(0, 1, 100)):
        sleep(0.01)

# Generated at 2022-06-18 11:37:07.382109
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:37:16.265883
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import random
    from numpy import array
    from numpy import allclose
    from numpy import linspace
    from numpy import mean
    from numpy import std
    from numpy import sqrt
    from numpy import var
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import concatenate
    from numpy import hstack
    from numpy import vstack
    from numpy import dstack
    from numpy import stack
    from numpy import column_stack
    from numpy import row_stack
    from numpy import c_
    from numpy import r_
    from numpy import tile
    from numpy import repeat
    from numpy import kron
    from numpy import empty


# Generated at 2022-06-18 11:37:26.276029
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear(self=None)
            tqdm_gui.clear(self=None, nolock=False)
            tqdm_gui.clear(self=None, nolock=True)
            tqdm_gui.clear(self=None, nolock=False, lock_args=(), lock_kwargs={})
            tqdm_gui.clear(self=None, nolock=True, lock_args=(), lock_kwargs={})
            tqdm_gui.clear(self=None, nolock=False, lock_args=(), lock_kwargs={'bar_format': '{l_bar}'})
            tq

# Generated at 2022-06-18 11:37:36.037221
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmKeyboardInterrupt
    from .std import TqdmCliWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmSkipWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmExperimentalWarning
   

# Generated at 2022-06-18 11:37:45.638853
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import image_comparison

    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'], remove_text=True)
    def test():
        # Test if tqdm_gui.close() restores the environment
        rcParams['toolbar'] = 'toolmanager'
        plt.ion()
        plt.figure()
        plt.plot(randint(0, 100, (100,)))
        plt.title('Test plot')
        plt.xlabel('x')
        plt.ylabel('y')
       

# Generated at 2022-06-18 11:37:55.326475
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    plt.close(pbar.fig)

    with tqdm_gui(total=100, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    plt.close(pbar.fig)

    with tqdm_gui(total=100, leave=True, unit='B', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    plt

# Generated at 2022-06-18 11:38:17.060305
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand

    # Test 1
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test 2
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
            pbar.set_description("Test %i" % i)

    # Test 3
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
            pbar

# Generated at 2022-06-18 11:38:23.992497
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from numpy.random import randint
    # Create a tqdm_gui object
    t = tqdm_gui(total=100, leave=False)
    # Update the progressbar
    for i in range(100):
        t.update(1)
        sleep(randint(1, 10) / 100)
    # Clear the progressbar
    t.clear()
    # Close the progressbar
    t.close()

# Generated at 2022-06-18 11:38:35.034659
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for method close of class tqdm_gui.
    """
    from .std import tqdm
    from .std import TqdmDeprecationWarning
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from collections import deque
    from .utils import _range

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Test for method close of class tqdm_gui
    # Test for method close of class tqdm_gui
    # Test for method close of class tqdm_gui
    # Test for method close of class tqdm_gui
    # Test for method close of class tqdm_gui
    # Test for method close

# Generated at 2022-06-18 11:38:42.402020
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from matplotlib import pyplot as plt
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_display():
        """Test tqdm_gui display method"""
        with tqdm_gui(total=10) as t:
            for i in range(10):
                sleep(0.1)
                t.update()
        assert allclose(array(t.xdata), array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90]))
        assert allclose(array(t.ydata), array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))

# Generated at 2022-06-18 11:38:46.464344
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update(1)
    plt.close()

# Generated at 2022-06-18 11:38:50.703592
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # test close
    tqdm.close()


# Generated at 2022-06-18 11:39:00.723311
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm import tqdm_gui

    plt.ion()
    plt.figure(figsize=(9, 2.2))
    plt.grid()
    plt.xlabel("seconds")
    plt.ylabel("it/s")
    plt.ylim(0, 0.001)
    plt.xlim(0, 60)
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    plt.legend(("cur", "est"), loc='lower left')
    plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
    pl

# Generated at 2022-06-18 11:39:09.015755
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from os import getpid
    from os.path import exists
    from os import remove
    from tempfile import gettempdir
    from multiprocessing import Process
    from multiprocessing import Queue
    from multiprocessing import Event

    def _test_tqdm_gui_close(q, e):
        try:
            t = tqdm_gui(total=100)
            for i in range(100):
                sleep(0.01)
                t.update()
            t.close()
            q.put(True)
        except Exception as e:
            q.put(e)
        finally:
            e.set()

    e = Event()
    q = Queue()
    p = Process(target=_test_tqdm_gui_close, args=(q, e))

# Generated at 2022-06-18 11:39:10.681568
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    assert True

# Generated at 2022-06-18 11:39:13.322647
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:39:46.027725
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import isclose
    from numpy.testing import assert_array_equal, assert_array_almost_equal

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update

# Generated at 2022-06-18 11:39:50.481650
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from tqdm.gui import tqdm
    for _ in tqdm(range(10)):
        pass
    tqdm.clear()

# Generated at 2022-06-18 11:39:52.332943
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-18 11:40:03.289523
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.01)
        t.update()
    close(t.fig)

# Generated at 2022-06-18 11:40:12.191825
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(100)):
        sleep(0.01)
    for i in tqdm_gui(range(100), leave=True):
        sleep(0.01)
    for i in tqdm_gui(range(100), leave=False):
        sleep(0.01)
    for i in tqdm_gui(range(100), disable=True):
        sleep(0.01)
    for i in tqdm_gui(range(100), disable=False):
        sleep(0.01)
    for i in tqdm_gui(range(100), unit='iB', unit_scale=True):
        sleep(0.01)

# Generated at 2022-06-18 11:40:21.761635
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import choice
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import uniform
    from numpy.random import choice
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import uniform
    from numpy.random import choice
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import uniform
    from numpy.random import choice

# Generated at 2022-06-18 11:40:28.808928
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import random
    from numpy import linspace
    # from matplotlib.pyplot import show
    with tqdm(total=100) as pbar:
        for i in linspace(0, 1, 100):
            sleep(0.01)
            pbar.update(1)
            pbar.set_description("test %0.2f" % (i * random()))
    # show()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:36.750649
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import _range
    from time import sleep

    t = tqdm(total=100)
    for i in _range(10):
        t.update()
        sleep(0.1)
    t.close()

    t = tqdm(total=100)
    for i in _range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t = tqdm(total=100)
    for i in _range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t = tqdm(total=100)
    for i in _range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t

# Generated at 2022-06-18 11:40:39.174798
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:40:41.052207
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()