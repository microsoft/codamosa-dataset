

# Generated at 2022-06-18 11:36:50.160198
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True, disable=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False, disable=True):
        sleep(0.01)

# Generated at 2022-06-18 11:36:59.042322
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Create a tqdm_gui object
    t = tqdm_gui(total=10)
    # Close the tqdm_gui object
    t.close()
    # Check if the tqdm_gui object is closed
    assert t.disable
    # Check if the toolbars are restored
    assert plt.rcParams['toolbar'] == toolbar
    # Check if the interactive mode is restored
    assert plt.isinteractive() == wasion

# Generated at 2022-06-18 11:37:01.530936
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(5)):
        sleep(0.1)
    assert True

# Generated at 2022-06-18 11:37:12.645324
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import version_info
    from os import remove
    from os.path import exists

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Update it
    for i in range(100):
        t.update()
        sleep(0.01)
    # Close it
    t.close()

    # Check if the figure has been closed
    assert not t.fig.axes, "The figure has not been closed"

    # Check if the toolbars have been restored
    assert t.mpl.rcParams['toolbar'] == t.toolbar, "The toolbars have not been restored"

    # Check if the interactive mode has been restored
    assert t.plt.isinteractive() == t.wasion, "The interactive mode has not been restored"

# Generated at 2022-06-18 11:37:16.987168
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    from time import sleep
    for i in tqdm_gui(range(10), desc="test_tqdm_gui_clear"):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear(i)
            break

# Generated at 2022-06-18 11:37:19.407579
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import tqdm_gui
    t = tqdm_gui(total=10)
    t.close()
    assert t.disable == True

# Generated at 2022-06-18 11:37:23.954840
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:37:34.222451
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import choice
    from numpy import array
    from numpy import mean
    from numpy import std
    from numpy import sqrt
    from numpy import arange
    from numpy import linspace
    from numpy import histogram
    from numpy import digitize
    from numpy import bincount
    from numpy import cumsum
    from numpy import sum as npsum
    from numpy import diff
    from numpy import concatenate
    from numpy import ones
    from numpy import zeros
    from numpy import array_equal
    from numpy import isclose
    from numpy import inf
   

# Generated at 2022-06-18 11:37:43.748202
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit='B', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

# Generated at 2022-06-18 11:37:53.524553
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint

# Generated at 2022-06-18 11:38:07.285398
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    from .std import tqdm
    t = tqdm(total=100)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:38:11.425618
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:38:15.500255
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # Test if the figure is closed
    assert tqdm.plt.get_fignums() == []

# Generated at 2022-06-18 11:38:25.370472
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.close()
    assert tqdm_gui.disable
    assert tqdm_gui.mpl.rcParams['toolbar'] == 'None'
    assert tqdm_gui.wasion
    assert tqdm_gui.leave
    assert tqdm_gui.fig.canvas.manager.window.isVisible()
    tqdm_gui.close()
    assert not tqdm_gui.fig.canvas.manager.window.isVisible()
    assert tqdm_gui.mpl.rcParams['toolbar'] == 'None'
    assert tqdm_gui.wasion

# Generated at 2022-06-18 11:38:32.977026
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        sleep(0.01)
        t.update(1)
    t.close()
    assert_allclose(t.xdata, t.ydata, atol=1e-3)
    assert allclose(t.xdata, t.zdata, atol=1e-3)

# Generated at 2022-06-18 11:38:41.176870
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import TqdmDeprecationWarning
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speeddata
    from .utils import format_stats
    from .utils import format_size
    from .utils import format_line
    from .utils import format_overhead
    from .utils import format_bar
    from .utils import format_width
    from .utils import format_postfix
    from .utils import format_interval_float
    from .utils import format_interval_short
    from .utils import format_inter

# Generated at 2022-06-18 11:38:46.545352
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _term_move_up

    # Test with total
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test with total and leave
    with tqdm_gui(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test without total and leave

# Generated at 2022-06-18 11:38:49.561106
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:38:52.619007
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()


# Generated at 2022-06-18 11:38:56.182631
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for constructor of class tqdm_gui
    """
    from time import sleep
    for _ in tqdm_gui(range(10)):
        sleep(0.1)