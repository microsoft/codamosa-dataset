

# Generated at 2022-06-18 11:36:43.318493
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import random as nprandom
    from numpy import linspace
    from numpy import arange
    from numpy import array
    from numpy import zeros
    from numpy import ones
    from numpy import concatenate
    from numpy import ndarray
    from numpy import float64
    from numpy import float32
    from numpy import int64
    from numpy import int32
    from numpy import int16
    from numpy import int8
    from numpy import uint64
    from numpy import uint32
    from numpy import uint16
    from numpy import uint8
    from numpy import nan
    from numpy import inf
    from numpy import nan_to_num
    from numpy import isfinite

# Generated at 2022-06-18 11:36:47.679108
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:36:57.704235
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint

# Generated at 2022-06-18 11:37:01.625432
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:37:12.728730
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from .std import tqdm_gui
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100, leave=True) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()
    with tqdm_gui(total=100, leave=True, mininterval=0.1) as t:
        for i in range(100):
            time.sleep(0.01)

# Generated at 2022-06-18 11:37:23.624418
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100), desc="1st loop"):
        for j in tqdm_gui(random.randn(100), desc="2nd loop", leave=False):
            for k in tqdm_gui(random.randn(100), desc="3rd loop", leave=False):
                sleep(0.01)
    for i in tqdm_gui(random.randn(100), desc="1st loop"):
        for j in tqdm_gui(random.randn(100), desc="2nd loop", leave=False):
            for k in tqdm_gui(random.randn(100), desc="3rd loop", leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:37:26.730596
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:37:36.376350
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import format_sizeof
    import time

    # Test 1:
    # Test with total=None
    t = tqdm(total=None, leave=True, gui=True)
    for i in range(10):
        t.update()
        time.sleep(0.1)
    t.close()

    # Test 2:
    # Test with total=100
    t = tqdm(total=100, leave=True, gui=True)
    for i in range(10):
        t.update()
        time.sleep(0.1)
    t.close()

    # Test 3:
    # Test with total=100 and unit='B'
    t = tqdm(total=100, unit='B', leave=True, gui=True)

# Generated at 2022-06-18 11:37:45.987992
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from random import random
    from numpy import array, allclose

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update()
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(i)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(i)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update(i)
   

# Generated at 2022-06-18 11:37:48.846897
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    assert True