

# Generated at 2022-06-18 11:36:46.613285
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from random import random
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random() / 10)
        t.update()
    t.close()

# Generated at 2022-06-18 11:36:56.704836
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(randint(10) / 1000)
            pbar.update()
    assert allclose(pbar.xdata, pbar.ydata)
    assert allclose(pbar.xdata, pbar.zdata)
    assert allclose(pbar.xdata, pbar.xdata[0] + pbar.xdata[-1])

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(100):
            sleep(randint(10) / 1000)
            pbar.update()

# Generated at 2022-06-18 11:36:59.788228
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:37:02.627783
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
    assert t.n == 10

# Generated at 2022-06-18 11:37:12.938919
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)

    # Close the tqdm_gui instance
    t.close()

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()

# Generated at 2022-06-18 11:37:23.613200
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update

# Generated at 2022-06-18 11:37:33.868599
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm_gui_close
    from tqdm.gui import tqdm_gui_close_all
    from tqdm.gui import tqdm_gui_close_all_instances
    from tqdm.gui import tqdm_gui_close_all_instances_of_class
    from tqdm.gui import tqdm_gui_close_all_instances_of_class_tqdm_gui
    from tqdm.gui import tqdm_gui_close_all_

# Generated at 2022-06-18 11:37:43.651167
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)
            tqdm_gui.clear()
            sleep(0.1)


# Generated at 2022-06-18 11:37:53.415935
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    # Test with a list
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    # Test with a generator
    with tqdm(random.randn(100)) as pbar:
        for i in pbar:
            sleep(0.1)
    # Test with a generator
    with tqdm(random.randn(100)) as pbar:
        for i in pbar:
            sleep(0.1)
    # Test with a generator
    with tqdm(random.randn(100)) as pbar:
        for i in pbar:
            sleep(0.1)
    # Test with a generator
   

# Generated at 2022-06-18 11:38:02.615457
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='2nd loop'):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='3nd loop', leave=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='4nd loop', leave=True, mininterval=0.5):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc='5nd loop', leave=True, mininterval=0.5,
                      miniters=1):
        sleep(0.1)

# Generated at 2022-06-18 11:38:26.156544
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import stdout
    from numpy import random
    from numpy.random import randint

    with tqdm(total=100, file=stdout) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)

    with tqdm(total=100, file=stdout) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)

    with tqdm(total=100, file=stdout) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)

    with tqdm(total=100, file=stdout) as pbar:
        for i in range(10):
            p

# Generated at 2022-06-18 11:38:30.390052
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:38:34.397045
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import _range
    from time import sleep

    for i in tqdm(_range(100), desc="test_tqdm_gui_display", gui=True):
        sleep(0.01)
    print("\n")

# Generated at 2022-06-18 11:38:42.032960
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from .utils import _term_move_up

    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    print("\n" * 3)
    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    print("\n" * 3)
    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    print("\n" * 3)

# Generated at 2022-06-18 11:38:53.688406
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close
    from .utils import FormatCustomTextType

    # Test with total
    t = tqdm_gui(total=10, leave=False)
    for i in range(10):
        sleep(0.1)
        t.update()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(t.ydata, [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])

# Generated at 2022-06-18 11:38:56.333724
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        i.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:39:04.955442
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    import time
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Close the tqdm_gui instance
    t.close()
    # Check if the tqdm_gui instance is closed
    assert t.disable
    # Check if the tqdm_gui instance is removed from the list of instances
    assert t not in tqdm_gui._instances
    # Check if the toolbars are restored
   

# Generated at 2022-06-18 11:39:08.337189
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=True):
        sleep(0.1)

# Generated at 2022-06-18 11:39:09.407899
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=100)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:39:10.882033
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:39:44.381678
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase, main
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    class TestTqdmGuiClose(TestCase):
        def setUp(self):
            self.mpl = mpl
            self.plt = plt
            self.toolbar = self.mpl.rcParams['toolbar']
            self.wasion = self.plt.isinteractive()
            self.tqdm_gui = tqdm_gui(total=100)

        def test_close(self):
            self.tqdm_gui.close()
            self.assertEqual(self.mpl.rcParams['toolbar'], self.toolbar)
            self.assertEqual(self.plt.isinteractive(), self.wasion)

    main()

# Generated at 2022-06-18 11:39:49.229206
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from random import random
    from numpy import arange
    with tqdm_gui(total=100) as t:
        for i in arange(0, 1, 0.01):
            sleep(0.01)
            t.update(1)
    with tqdm_gui(total=100, leave=True) as t:
        for i in arange(0, 1, 0.01):
            sleep(0.01)
            t.update(1)
    with tqdm_gui(total=100, leave=True, unit='B', unit_scale=True) as t:
        for i in arange(0, 1, 0.01):
            sleep(0.01)
            t.update(1)

# Generated at 2022-06-18 11:39:53.931601
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(10)
    plt.close()

# Generated at 2022-06-18 11:39:59.879343
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:40:02.797753
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:40:05.541812
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:09.436265
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:40:11.818361
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:14.537909
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(3)):
        sleep(0.1)
    # test if the figure is closed
    assert tqdm_gui.plt.get_fignums() == []

# Generated at 2022-06-18 11:40:25.029757
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(randint(1, 3) / 10)
            pbar.update(10)
    assert allclose(pbar.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(pbar.ydata, pbar.zdata)

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(randint(1, 3) / 10)
            pbar.update(1)

# Generated at 2022-06-18 11:41:24.807317
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm.gui import tqdm_gui

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)


# Generated at 2022-06-18 11:41:31.000308
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random

    # Test with no total
    with tqdm_gui(unit="i", unit_scale=True, miniters=1,
                  mininterval=0.1) as t:
        for i in range(3):
            sleep(random() * 0.01)
            t.update()

    # Test with total
    with tqdm_gui(total=4, unit="i", unit_scale=True, miniters=1,
                  mininterval=0.1) as t:
        for i in range(3):
            sleep(random() * 0.01)
            t.update()

    # Test with total and leave

# Generated at 2022-06-18 11:41:37.919284
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
    plt.close(pbar.fig)

    with tqdm_gui(total=None) as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)
    plt.close(pbar.fig)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:41:46.666753
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _range

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Test
    for i in tqdm_gui(_range(10)):
        pass

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()
    plt.close()

# Generated at 2022-06-18 11:41:55.928219
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase
    import matplotlib.pyplot as plt

    class TestTqdmGuiDisplay(TestCase):
        def setUp(self):
            self.t = tqdm_gui(total=100, leave=False)

        def test_display(self):
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
            self.t.display()
            self.t.update(10)
           

# Generated at 2022-06-18 11:42:06.373976
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from random import random
    from numpy import mean

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(random() * 0.01)
            pbar.update(1)

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(random() * 0.01)
            pbar.update(1)
            if random() < 0.1:
                pbar.n = i

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(random() * 0.01)
            pbar.update(1)
            if random() < 0.1:
                pbar.total = i

# Generated at 2022-06-18 11:42:16.516685
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_display_cleanup():
        t = tqdm_gui(total=100)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.update(10)
        t.display()
        t.close()


# Generated at 2022-06-18 11:42:19.599035
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
    plt.close('all')

# Generated at 2022-06-18 11:42:22.106552
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10), desc="test"):
        sleep(0.01)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:42:26.797351
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    plt.close(t.fig)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:44:28.045133
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100, leave=False)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()
    assert allclose(array(t.xdata), array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90]))
    assert allclose(array(t.ydata), array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
    assert allclose(array(t.zdata), array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
    close(t.fig)



# Generated at 2022-06-18 11:44:36.932487
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randint
    # from matplotlib.pyplot import plot
    # from matplotlib.pyplot import show

    # test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)

    # test without total
    with tqdm_gui(unit='i', unit_scale=True) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(randint(1, 100000))

    # test with total and dynamic message

# Generated at 2022-06-18 11:44:38.075464
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:44:43.896766
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, leave=False, disable=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:44:47.140492
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    from sys import stdout
    for i in tqdm(_range(10), file=stdout):
        sleep(0.1)

# Generated at 2022-06-18 11:44:48.820571
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:44:51.062545
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:44:56.633846
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    from time import sleep
    from sys import stderr
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10), file=stderr):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear(tqdm_gui)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:45:03.121962
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test the method clear of class tqdm_gui
    """
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 2:
            tqdm_gui.clear()
        if i == 4:
            tqdm_gui.clear()
        if i == 6:
            tqdm_gui.clear()
        if i == 8:
            tqdm_gui.clear()
        if i == 10:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:45:05.689703
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()