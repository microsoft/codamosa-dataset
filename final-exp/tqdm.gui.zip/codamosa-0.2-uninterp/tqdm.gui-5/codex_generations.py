

# Generated at 2022-06-18 11:36:44.959138
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from matplotlib.pyplot import close
    from .utils import _range

    # Test with total
    t = tqdm_gui(_range(100), total=100, leave=True)
    for i in _range(100):
        sleep(0.01)
        t.update()
    close(t.fig)
    assert allclose(t.xdata, array(range(100)) * 1.0)
    assert allclose(t.ydata, array(range(100)) * 0.01)
    assert allclose(t.zdata, array(range(100)) * 0.01)

    # Test without total
    t = tqdm_gui(_range(100), leave=True)

# Generated at 2022-06-18 11:36:55.090782
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import log
    from numpy import exp
    from numpy import sqrt
    from numpy import sin
    from numpy import cos
    from numpy import pi
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import random
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import random
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import random
    from numpy import arange
   

# Generated at 2022-06-18 11:37:04.238963
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from sys import stdout

    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False,
                              total=100, miniters=1, mininterval=0.1):
                sleep(0.01 * random())
                stdout.flush()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:37:13.827770
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import time
    from tqdm.gui import tqdm_gui
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Create a progressbar
    pbar = tqdm_gui(total=100)
    # Update progressbar
    for i in range(100):
        time.sleep(0.01)
        pbar.update(1)
    # Close progressbar
    pbar.close()
    # Check if toolbars are restored
    assert plt.rcParams['toolbar'] == toolbar
    # Check if interactive mode is restored
    assert plt.isinteractive() == wasion

# Generated at 2022-06-18 11:37:24.162884
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.testing import assert_allclose

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(randint(1, 10) / 1000)
            pbar.update()
    assert_allclose(pbar.xdata, pbar.ydata)
    assert_allclose(pbar.xdata, pbar.zdata)
    assert allclose(pbar.xdata, pbar.xdata[0] + pbar.xdata[-1] *
                    (pbar.xdata - pbar.xdata[0]) / pbar.xdata[-1])

    # Test without total

# Generated at 2022-06-18 11:37:27.374496
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:37:36.849915
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10), leave=False):
        sleep(0.1)
    for i in tqdm(range(10), leave=True):
        sleep(0.1)
    for i in tqdm(range(10), leave=True, unit='it'):
        sleep(0.1)
    for i in tqdm(range(10), leave=True, unit='it', unit_scale=True):
        sleep(0.1)
    for i in tqdm(range(10), leave=True, unit='it', unit_scale=True,
                  mininterval=0.1):
        sleep(0.1)

# Generated at 2022-06-18 11:37:46.666412
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    # Test
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(random.rand())
    # Test disable
    with tqdm(total=100, disable=True) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(random.rand())
    # Test close
    pbar = tqdm(total=100)
    for i in range(10):
        pbar.update(10)
        sleep(random.rand())
    pbar.close()
    # Test leave
    pbar = tqdm(total=100, leave=True)
    for i in range(10):
        p

# Generated at 2022-06-18 11:37:56.261170
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock
    with mock.patch('tqdm.gui.tqdm_gui.plt.pause') as mock_pause:
        with mock.patch('tqdm.gui.tqdm_gui.plt.close') as mock_close:
            with mock.patch('tqdm.gui.tqdm_gui.plt.ioff') as mock_ioff:
                with mock.patch('tqdm.gui.tqdm_gui.plt.isinteractive') as mock_isinteractive:
                    mock_isinteractive.return_value = True
                    t = tqdm_gui(total=10)
                    t.close()
                    assert mock_pause.call_count == 1

# Generated at 2022-06-18 11:38:00.932246
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # Test if the figure is closed
    assert tqdm.plt.get_fignums() == []

if __name__ == '__main__':
    test_tqdm_gui_close()