

# Generated at 2022-06-18 11:36:33.876016
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:36:36.715770
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:36:47.302593
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import randint

# Generated at 2022-06-18 11:36:52.844907
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm
    from time import sleep
    for i in tqdm(range(10), desc='1st loop', leave=False):
        for j in tqdm(range(5), desc='2nd loop', leave=True):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
    print('done')

# Generated at 2022-06-18 11:36:55.716601
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:37:07.571595
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from time import sleep
    from numpy import random
    from numpy.random import randint

    # Test for total=None
    for i in tqdm(range(10)):
        sleep(0.1)
    # Test for total=int
    for i in tqdm(range(10), total=10):
        sleep(0.1)
    # Test for total=None, miniters=1
    for i in tqdm(range(10), miniters=1):
        sleep(0.1)
    # Test for total=int, miniters=1
    for i in tqdm(range(10), total=10, miniters=1):
        sleep(0.1)
    # Test for total=None,

# Generated at 2022-06-18 11:37:16.386866
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm_gui_close
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    # Close the tqdm_gui instance
    t.close()
    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode

# Generated at 2022-06-18 11:37:26.346703
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import choice
    from numpy.random import shuffle
    from numpy.random import permutation
    from numpy.random import beta
    from numpy.random import binomial
    from numpy.random import chisquare
    from numpy.random import dirichlet
    from numpy.random import exponential
    from numpy.random import f
    from numpy.random import gamma
    from numpy.random import geometric
    from numpy.random import gumbel
    from numpy.random import hypergeometric
    from numpy.random import laplace
    from numpy.random import logistic
    from numpy.random import logn

# Generated at 2022-06-18 11:37:36.117253
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit='iB') as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit='iB', unit_scale=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10, unit='iB', unit_scale=True, miniters=1) as t:
        for i in range(10):
            sleep(0.1)

# Generated at 2022-06-18 11:37:39.137707
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()
    tqdm_gui.close()

# Generated at 2022-06-18 11:37:54.421038
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:37:57.189258
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)

# Generated at 2022-06-18 11:38:05.369621
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert_allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1], atol=1e-3)
    assert_allclose(t.zdata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1], atol=1e-3)

# Generated at 2022-06-18 11:38:12.917252
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import tqdm_gui
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)
    t.close()

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()

# Generated at 2022-06-18 11:38:16.687818
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for i in tqdm(_range(10), gui=True):
        sleep(0.1)
    assert tqdm._instances == []

# Generated at 2022-06-18 11:38:26.505409
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy.random import uniform
    from numpy import array
    from numpy import concatenate
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import ceil
    from numpy import floor
    from numpy import round
    from numpy import sqrt
    from numpy import sin
    from numpy import cos
    from numpy import tan
    from numpy import arcsin
    from numpy import arccos
    from numpy import arctan
    from numpy import sinh
    from numpy import cosh
    from numpy import tanh
    from numpy import arcsinh


# Generated at 2022-06-18 11:38:37.378382
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import version_info
    from os import remove
    from os.path import exists
    from tempfile import mkstemp
    from .utils import _range

    # Test for issue #971
    with tqdm_gui(total=None) as t:
        for i in _range(10):
            t.update()
            sleep(0.01)

    # Test for issue #1023
    with tqdm_gui(total=None) as t:
        for i in _range(10):
            t.update()
            sleep(0.01)
        t.close()

    # Test for issue #1023
    with tqdm_gui(total=None) as t:
        for i in _range(10):
            t.update()
            sleep(0.01)
       

# Generated at 2022-06-18 11:38:39.322811
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import trange
    for i in trange(10):
        sleep(0.1)
    trange(10).close()

# Generated at 2022-06-18 11:38:50.384100
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt
    from matplotlib import animation

    # Fix #971
    tqdm_gui(None)

    # Fix #971
    tqdm_gui(None, total=None)

    # Fix #971
    tqdm_gui(None, total=None, mininterval=0.5)

    # Fix #971
    tqdm_gui(None, total=None, mininterval=0.5, leave=True)

    # Fix #971
    tqdm_gui(None, total=None, mininterval=0.5, leave=True, disable=True)

    # Fix #971

# Generated at 2022-06-18 11:38:57.222721
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import random
    from numpy.testing import assert_array_equal
    from tqdm.gui import tqdm_gui
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random.rand())
        t.update()
    t.close()
    assert_array_equal(t.xdata, t.ydata)
    assert_array_equal(t.xdata, t.zdata)

# Generated at 2022-06-18 11:39:30.005447
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm import tqdm_gui

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    # Test with total and smoothing
    with tqdm_gui(total=100, smoothing=0.5) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test without total and smoothing


# Generated at 2022-06-18 11:39:32.862570
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:39:35.407282
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    assert tqdm.disable

# Generated at 2022-06-18 11:39:42.983051
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import version_info
    from os import devnull
    from contextlib import contextmanager
    from io import open

    @contextmanager
    def stdout_redirect(where):
        sys = __import__('sys')
        sys.stdout = where
        try:
            yield where
        finally:
            sys.stdout = sys.__stdout__

    with open(devnull, 'w') as fnull:
        with stdout_redirect(fnull):
            for _ in tqdm_gui(range(3)):
                sleep(0.1)
            for _ in tqdm_gui(range(3), leave=True):
                sleep(0.1)
            for _ in tqdm_gui(range(3), leave=False):
                sleep(0.1)


# Generated at 2022-06-18 11:39:53.834854
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt
    from matplotlib import animation

    # Fix #971
    tqdm_gui(None)

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test with total and dynamic miniters

# Generated at 2022-06-18 11:39:58.396230
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    from time import sleep
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            pbar.clear()


# Generated at 2022-06-18 11:40:01.127154
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()
        sleep(0.1)

# Generated at 2022-06-18 11:40:10.624665
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    from matplotlib import rc_context
    from matplotlib import pyplot

    # Remember if external environment uses toolbars
    toolbar = rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    with rc_context(rc={'toolbar': 'None'}):
        # Create a tqdm_gui object
        t = tqdm_gui(total=100)
        # Check that the tqdm_gui object is created
        assert t.disable is False
        assert t.mpl is pyplot
        assert t.plt is pyplot
        assert t.toolbar == toolbar
        assert t.wasion == wasion
        assert t.mininterval == 0.5


# Generated at 2022-06-18 11:40:13.425121
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui.clear()"""
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    t.clear()
    assert t.disable

# Generated at 2022-06-18 11:40:15.391777
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from .std import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:41:09.547187
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Initialize tqdm_gui
    t = tqdm_gui(total=100, leave=False)
    # Test display()
    t.display()
    # Test display() with n=0
    t.n = 0
    t.display()
    # Test display() with n=1
    t.n = 1
    t.display()
    # Test display() with n=2
    t.n = 2
    t.display()
    # Test display() with n=3
    t.n = 3
    t.display()
    # Test display() with n=4
    t.n = 4
    t.display()
    # Test display() with n=5
    t.n = 5
   

# Generated at 2022-06-18 11:41:17.008302
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from random import random
    from numpy import random as nprandom

    try:
        from matplotlib import pyplot as plt
    except ImportError:
        return

    for i in tqdm(nprandom.rand(100)):
        sleep(random() * 0.01)

    for i in tqdm(nprandom.rand(100), desc="1st loop"):
        for j in tqdm(nprandom.rand(100), desc="2nd loop", leave=False):
            sleep(random() * 0.01)
        sleep(random() * 0.01)


# Generated at 2022-06-18 11:41:25.787502
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close of class tqdm_gui.
    """
    from .std import TqdmExperimentalWarning
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .gui import tqdm_gui
    from .gui import tgrange
    from .gui import tqdm
    from .gui import trange
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import warnings
    warnings.simplefilter('ignore', TqdmExperimentalWarning)
    kwargs = {}
    kwargs['gui'] = True
    colour = kwargs.pop('colour', 'g')
    tqdm_gui_test = tqdm_gui(_range(10), **kwargs)
    t

# Generated at 2022-06-18 11:41:31.419519
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    from time import sleep
    from tqdm.gui import tqdm
    from tqdm.gui import trange

    # Test tqdm_gui
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test trange
    for i in trange(10):
        sleep(0.1)

    # Test toolbar
    assert rcParams['toolbar'] == 'None'
    assert plt.isinteractive()
    assert plt.get_fignums() == []

# Generated at 2022-06-18 11:41:34.803568
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-18 11:41:44.385263
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    with tqdm_gui(total=100, unit='B', unit_scale=True,
                  miniters=1, mininterval=0.1) as t:
        for i in range(10):
            sleep(0.1)
            t.update(10)
    with tqdm_gui(total=100, unit='B', unit_scale=True,
                  miniters=1, mininterval=0.1) as t:
        for i in range(10):
            sleep(0.1)
            t.update(10)

# Generated at 2022-06-18 11:41:45.908844
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(1, 100)):
        sleep(0.01)
    tqdm_gui.close()

# Generated at 2022-06-18 11:41:54.808860
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Test with total
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    assert allclose(pbar.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(pbar.ydata, [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100])
    assert allclose(pbar.zdata, [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100])
    plt.close(pbar.fig)

    # Test without total

# Generated at 2022-06-18 11:41:59.175255
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:42:01.798036
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:43:51.122415
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randint
    from numpy.testing import assert_array_equal

    # Test 1
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

    # Test 2
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(1)

    # Test 3
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(i)

    # Test 4

# Generated at 2022-06-18 11:43:59.289831
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from matplotlib.pyplot import close
    from .std import tqdm_gui

    # Test with total
    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        sleep(0.1)
    assert allclose(array(t.xdata), array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90]))
    assert allclose(array(t.ydata), array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))

# Generated at 2022-06-18 11:44:00.750206
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=10)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:44:07.326928
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from time import sleep
    from matplotlib import pyplot as plt
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_cleanup():
        """
        Unit test for constructor of class tqdm_gui
        """
        with tqdm(total=100) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update(10)
        plt.close(pbar.fig)

    test_tqdm_gui_cleanup()

# Generated at 2022-06-18 11:44:10.268212
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()
            t.close()

# Generated at 2022-06-18 11:44:12.754438
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            pbar.clear()
            pbar.display()


# Generated at 2022-06-18 11:44:16.270625
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:44:23.254539
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import seed
    from numpy import array
    from numpy import mean
    from numpy import std
    from numpy import concatenate
    from numpy import linspace
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import array
    from numpy import concatenate
    from numpy import linspace
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import array
    from numpy import concatenate
    from numpy import linspace

# Generated at 2022-06-18 11:44:32.278276
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt
    from matplotlib.pyplot import close as plt_close

    # Test GUI
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random.rand())
            pbar.update()
    plt.close(pbar.fig)

    # Test GUI with no total
    with tqdm() as pbar:
        for i in range(10):
            sleep(random.rand())
            pbar.update()
    plt.close(pbar.fig)

    # Test GUI with no total and leave
    with tqdm(leave=True) as pbar:
        for i in range(10):
            sleep(random.rand())
            pbar.update

# Generated at 2022-06-18 11:44:40.266061
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from time import sleep
    from numpy.random import randint
    from numpy import array
    from matplotlib import pyplot as plt

    # Test with total
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

    # Test with iterable
    for _ in tqdm([1, 2, 3]):
        sleep(0.1)

    # Test with manual updates
    pbar = tqdm(total=100)
    for i in range(10):
        sleep(0.1)
        pbar.update(10)
    pbar.close()

    # Test closing