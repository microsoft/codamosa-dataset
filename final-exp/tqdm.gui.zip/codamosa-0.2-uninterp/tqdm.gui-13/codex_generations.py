

# Generated at 2022-06-18 11:36:41.052424
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:36:43.684640
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        pbar.clear()
        pbar.display()

# Generated at 2022-06-18 11:36:52.519590
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:36:56.140076
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:37:07.926986
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update

# Generated at 2022-06-18 11:37:16.627631
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-18 11:37:26.516871
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm
    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10
    assert t.last_print_t == t.start_t + 1
    assert t.total == 10
    assert t.dynamic_miniters
    assert t.miniters == 1
    assert t.unit == 'it'
    assert t.unit_scale == False
    assert t.desc == ''
    assert t.leave == True
    assert t.disable == True
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.miniters == 1

# Generated at 2022-06-18 11:37:32.738085
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)
        sleep(0.01)
    assert_array_equal(array(t.xdata), array(t.ydata))
    assert_array_equal(array(t.xdata), array(t.zdata))
    t.close()

# Generated at 2022-06-18 11:37:36.077500
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # test if the figure is closed
    assert tqdm.plt.get_fignums() == []

# Generated at 2022-06-18 11:37:45.678034
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import exponential
    from numpy.random import poisson
    from numpy.random import binomial
    from numpy.random import negative_binomial
    from numpy.random import geometric
    from numpy.random import hypergeometric
    from numpy.random import logseries
    from numpy.random import zipf
    from numpy.random import pareto
    from numpy.random import weibull
    from numpy.random import power
    from numpy.random import laplace
    from numpy.random import gumbel
    from numpy.random import logistic

# Generated at 2022-06-18 11:38:03.754782
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmGuiClear(TestCase):
        def test_clear(self):
            with patch('tqdm.gui.tqdm_gui.tqdm_gui.clear') as mock_clear:
                tqdm_gui.clear()
                mock_clear.assert_called_once_with()

    TestTqdmGuiClear().test_clear()

# Generated at 2022-06-18 11:38:11.773871
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, leave=True, unit='iB', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

# Generated at 2022-06-18 11:38:21.975184
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=True, mininterval=0.1):
        sleep(0.1)
    for i in tqdm_gui(range(10), leave=False, mininterval=0.1):
        sleep(0.1)

# Generated at 2022-06-18 11:38:24.695630
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()

# Generated at 2022-06-18 11:38:32.968450
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose

    # Test with total
    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(0.01)
    assert allclose(t.hspan.get_xy()[2, 0], 1)

    # Test without total
    t = tqdm_gui()
    for i in range(100):
        t.update()
        sleep(0.01)
    assert allclose(t.hspan.get_xy()[2, 0], 1)

# Generated at 2022-06-18 11:38:41.177331
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import random
    from numpy.testing import assert_allclose

    # Test with total
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random.rand())
        t.update()
    t.close()

    # Test without total
    t = tqdm_gui()
    for i in range(100):
        sleep(random.rand())
        t.update()
    t.close()

    # Test with total and smoothing
    t = tqdm_gui(total=100, smoothing=0.9)
    for i in range(100):
        sleep(random.rand())
        t.update()
    t.close()

    # Test without total and smoothing

# Generated at 2022-06-18 11:38:53.134759
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10), leave=False):
        sleep(0.1)
    for i in tqdm(range(10), leave=True):
        sleep(0.1)
    for i in tqdm(range(10), leave=True, disable=True):
        sleep(0.1)
    for i in tqdm(range(10), leave=False, disable=True):
        sleep(0.1)
    for i in tqdm(range(10), leave=False, disable=False):
        sleep(0.1)

# Generated at 2022-06-18 11:39:02.564231
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)
        sleep(0.1)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        t.update(10)
        sleep(0.1)

# Generated at 2022-06-18 11:39:10.461806
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint

# Generated at 2022-06-18 11:39:13.066710
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for i in tqdm(_range(10), gui=True):
        sleep(0.1)
    assert tqdm._instances == []

# Generated at 2022-06-18 11:39:40.267898
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:39:41.870768
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()


# Generated at 2022-06-18 11:39:51.870445
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    from time import sleep
    from numpy import random
    from numpy.testing import assert_array_equal

    # test with total
    t = tqdm_gui(total=100, leave=False)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-18 11:39:55.010542
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    # test close
    tqdm.close()

# Generated at 2022-06-18 11:39:59.710751
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random

    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(random() / 5)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-18 11:40:09.517774
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmTypeError

    with tqdm(total=10, disable=True) as t:
        assert t.disable
        assert t.gui
        t.close()
        assert t.disable
        assert t.gui

    with tqdm(total=10, disable=False) as t:
        assert not t.disable
        assert t.gui
        t.close()
        assert t.disable
        assert t.gui

    with tqdm(total=10, disable=False, gui=False) as t:
        assert not t.disable
        assert not t.gui
        t.close()
        assert t.disable
        assert not t.gui


# Generated at 2022-06-18 11:40:12.754580
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:40:22.909565
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose

    # Test with total
    with tqdm_gui(total=100, leave=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    assert_allclose(pbar.xdata, [10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert allclose(pbar.ydata, [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0])

# Generated at 2022-06-18 11:40:32.758436
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from sys import stdout
    from numpy import random
    from tqdm.gui import tqdm_gui

    for i in tqdm_gui(range(10), file=stdout):
        sleep(0.1)
        stdout.flush()

    for i in tqdm_gui(range(10), file=stdout, leave=True):
        sleep(0.1)
        stdout.flush()

    for i in tqdm_gui(range(10), file=stdout, leave=True,
                      bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]"):
        sleep(0.1)
        stdout.flush()


# Generated at 2022-06-18 11:40:40.544065
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(10):
        sleep(0.1)
        t.update(10)

# Generated at 2022-06-18 11:41:37.710741
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import image_comparison
    import numpy as np

    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'], remove_text=True)
    def test():
        # Test if tqdm_gui.close() restores the environment
        rcParams['toolbar'] = 'toolmanager'
        plt.ioff()
        with tqdm_gui(total=10) as t:
            for i in range(10):
                t.update()
                plt.plot(np.random.rand(10))
                plt.draw()
        plt.ion()

# Generated at 2022-06-18 11:41:40.333134
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm_gui
    for _ in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:41:48.538121
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import time
    from .std import tqdm
    from .std import TqdmTypeError

    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.total == 10

    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update(1)
    assert t.n == 10
    assert t.total == 10

    with tqdm(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update(i)
    assert t.n == 45
    assert t.total == 10


# Generated at 2022-06-18 11:41:58.616705
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt

    # Test GUI
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)

    # Test GUI with random sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(random.rand())
            pbar.update(1)

    # Test GUI with random sleep and dynamic mininterval
    with tqdm_gui(total=100, mininterval=0.5) as pbar:
        for i in range(100):
            sleep(random.rand())
            pbar.update(1)

    # Test GUI with random sleep and dynamic mininter

# Generated at 2022-06-18 11:42:06.016750
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Test tqdm_gui constructor"""
    from time import sleep
    from numpy import random

    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
            pbar.set_description("test_tqdm_gui")
            pbar.set_postfix(OrderedDict(loss=random.random(),
                                         acc=random.random()))


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:42:16.194923
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    import matplotlib.pyplot as plt

    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Test 1
    plt.ion()
    plt.rcParams['toolbar'] = 'None'
    t = tqdm(total=10)
    t.close()
    assert plt.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion

    # Test 2
    plt.ioff()
    plt.rcParams['toolbar'] = 'toolmanager'
    t = tqdm(total=10)
    t.close()
    assert plt.rcParams

# Generated at 2022-06-18 11:42:23.418284
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # test with total
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-18 11:42:29.030433
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import random
    from numpy.testing import assert_array_equal
    from tqdm.gui import tqdm_gui
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(random.rand())
        t.update()
    assert_array_equal(t.xdata, t.ydata)
    assert_array_equal(t.xdata, t.zdata)
    t.close()

# Generated at 2022-06-18 11:42:30.800545
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    for _ in tqdm(range(10)):
        pass

# Generated at 2022-06-18 11:42:39.905991
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.testing import assert_allclose
    from .utils import FormatCustomTextType, FormatCustomTextTypeStdIO

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    assert_allclose(pbar.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    assert_allclose(pbar.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])