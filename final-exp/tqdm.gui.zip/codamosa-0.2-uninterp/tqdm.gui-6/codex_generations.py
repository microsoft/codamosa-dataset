

# Generated at 2022-06-18 11:36:40.278979
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc="desc"):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc="desc", leave=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc="desc", leave=True,
                      unit="it", unit_scale=True):
        sleep(0.1)
    for i in tqdm_gui(range(10), desc="desc", leave=True,
                      unit="it", unit_scale=True, mininterval=0.5):
        sleep(0.1)

# Generated at 2022-06-18 11:36:44.665575
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)
            pbar.clear()
            pbar.display()

# Generated at 2022-06-18 11:36:54.876498
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randn

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)

    # Test without total
    with tqdm_gui(unit='i', unit_scale=True) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(randn() * 1e5)

    # Test with total and smoothing
    with tqdm_gui(total=100, smoothing=0.9) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)

    # Test with total and dynamic

# Generated at 2022-06-18 11:37:06.718396
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup
    from matplotlib.testing.decorators import image_comparison

    @cleanup
    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'])
    def test_tqdm_gui_close():
        # Remember if external environment uses toolbars
        toolbar = mpl.rcParams['toolbar']
        mpl.rcParams['toolbar'] = 'None'

        # Remember if external environment is interactive
        wasion = plt.isinteractive()
        plt.ion()

        # Create a tqdm_gui instance

# Generated at 2022-06-18 11:37:15.857732
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import random
    from numpy.testing import assert_allclose
    from .utils import FormatCustom

    # Test with total
    with tqdm_gui(total=100, unit_scale=True, unit='iB',
                  unit_divisor=1024, miniters=1,
                  mininterval=0.1, desc='Test', leave=True,
                  bar_format=FormatCustom("{percentage:3.0f}%|{bar}|")) as t:
        for i in range(10):
            sleep(random.random() / 2)
            t.update()

    # Test without total

# Generated at 2022-06-18 11:37:25.961922
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy.random import randint
    from numpy.random import random
    from numpy import array
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import log
    from numpy import exp
    from numpy import sqrt
    from numpy import sin
    from numpy import cos
    from numpy import pi
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import concatenate
    from numpy import append
    from numpy import diff
    from numpy import cumsum
    from numpy import cumprod
    from numpy import sum
    from numpy import prod
    from numpy import mean
    from numpy import median


# Generated at 2022-06-18 11:37:35.798212
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import time
    from .utils import _range

    # Test with total
    with tqdm_gui(total=100, leave=False) as pbar:
        for i in _range(100):
            pbar.update()
            time.sleep(0.01)
    plt.close(pbar.fig)

    # Test without total
    with tqdm_gui(leave=False) as pbar:
        for i in _range(100):
            pbar.update()
            time.sleep(0.01)
    plt.close(pbar.fig)

    # Test with total and smoothing

# Generated at 2022-06-18 11:37:38.649558
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=100)
    t.close()
    assert t.disable == True
    assert t.mpl.rcParams['toolbar'] == 'None'
    assert t.wasion == False


# Generated at 2022-06-18 11:37:48.543427
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm_gui_close
    from tqdm.gui import tqdm_gui_close_test
    from tqdm.gui import tqdm_gui_close_test_toolbar
    from tqdm.gui import tqdm_gui_close_test_wasion
    from tqdm.gui import tqdm_gui_close_test_wasion_toolbar
    from tqdm.gui import tqdm_gui_close_test_wasion_toolbar_leave
    from tqdm.gui import tqdm_gui_close_test_wasion_toolbar_leave_disable

# Generated at 2022-06-18 11:37:54.143823
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test method clear of class tqdm_gui
    """
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:38:16.891351
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True, disable=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False, disable=True):
        sleep(0.01)

# Generated at 2022-06-18 11:38:20.722670
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:38:31.399270
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib import pyplot as plt

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100, leave=False)
    # Simulate some work
    for i in range(100):
        sleep(0.01)
        t.update()
    # Close the instance
    t.close()

    # Check if the plot is correct
    assert allclose(t.ydata, t.zdata)
    assert allclose(t.ydata[-1], t.zdata[-1])
    assert t.ydata[-1] > 0
    assert t.zdata[-1] > 0

    # Close the plot
    plt.close(t.fig)

# Generated at 2022-06-18 11:38:40.369238
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _range

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm_gui(_range(10), leave=True)

    # Close the tqdm_gui instance
    t.close()

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar

    # Return to non-interactive mode
    if not wasion:
        pl

# Generated at 2022-06-18 11:38:43.360508
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep

    for _ in tqdm_gui(range(10)):
        sleep(0.1)
        tqdm_gui.clear()

# Generated at 2022-06-18 11:38:54.792611
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Tests that the close method of tqdm_gui works correctly.
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui instance
    t = tqdm_gui(total=100)

    # Close the tqdm_gui instance
    t.close()

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar

    # Return to non-interactive mode
    if not wasion:
        plt.io

# Generated at 2022-06-18 11:39:03.805811
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:39:11.684761
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import tqdm
    from .utils import FormatCustomTextType, FormatCustomTextExt
    from .utils import format_dict, format_interval, format_meter
    from .utils import format_sizeof, format_time, format_number
    from .utils import format_interval_short, format_interval_long
    from .utils import format_interval_floating
    from .utils import format_interval_scientific
    from .utils import format_interval_mixed
    from .utils import format_interval_mixed_units
    from .utils import format_interval_mixed_units_long
    from .utils import format_interval_mixed_units_short
    from .utils import format_interval_mixed_units_floating
    from .utils import format_inter

# Generated at 2022-06-18 11:39:14.334285
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.clear()

# Generated at 2022-06-18 11:39:21.021838
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from sys import version_info
    from os import get_terminal_size
    from shutil import rmtree
    from tempfile import mkdtemp
    from os.path import join
    from matplotlib import pyplot as plt
    from matplotlib import get_backend
    from matplotlib import rcParams
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

    # Create a temporary directory
    tmpdir = mkdtemp()
    # Create a figure
    fig = Figure(figsize=(9, 2.2))
    # Create a canvas
    canvas = FigureCanvas(fig)
    # Create a subplot
    ax = fig.add_subplot(111)
    # Create a progressbar
    p

# Generated at 2022-06-18 11:39:49.100789
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import _range
    from time import sleep
    for i in tqdm(_range(10), gui=True):
        sleep(0.1)

# Generated at 2022-06-18 11:39:53.033895
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.close()

# Generated at 2022-06-18 11:39:54.917540
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:39:59.625941
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-18 11:40:02.878625
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_gui.clear()


# Generated at 2022-06-18 11:40:07.937530
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for i in tqdm_gui(random.randn(100)):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=True):
        sleep(0.01)
    for i in tqdm_gui(random.randn(100), leave=False):
        sleep(0.01)

# Generated at 2022-06-18 11:40:15.233675
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm_gui
    from tqdm.utils import _term_move_up

    # Test with total
    with tqdm_gui(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test without total
    with tqdm_gui() as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test with total and miniters
    with tqdm_gui(total=10, miniters=1) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    # Test without total and miniters

# Generated at 2022-06-18 11:40:17.365582
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from random import random
    for _ in tqdm_gui(range(10)):
        sleep(random())

# Generated at 2022-06-18 11:40:19.694409
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm_gui
    t = tqdm_gui(total=100)
    t.clear()
    t.close()

# Generated at 2022-06-18 11:40:29.276268
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    t = tqdm_gui(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()
    assert allclose(t.xdata, [0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    assert allclose(t.ydata, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    assert allclose(t.zdata, [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1])

# Generated at 2022-06-18 11:41:28.686551
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    import time

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a tqdm_gui object
    t = tqdm(total=100)
    for i in range(10):
        time.sleep(0.1)
        t.update(10)

    # Close the tqdm_gui object
    t.close()

    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-inter

# Generated at 2022-06-18 11:41:30.893969
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    assert not tqdm_gui._instances

# Generated at 2022-06-18 11:41:39.672143
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.01)
    for i in tqdm_gui(range(10), leave=True):
        sleep(0.01)
    for i in tqdm_gui(range(10), leave=False):
        sleep(0.01)
    for i in tqdm_gui(range(10), leave=False, disable=True):
        sleep(0.01)
    for i in tqdm_gui(range(10), leave=False, disable=False):
        sleep(0.01)
    for i in tqdm_gui(range(10), leave=False, disable=True, gui=True):
        sleep(0.01)

# Generated at 2022-06-18 11:41:43.792268
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for _ in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-18 11:41:45.620694
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:41:54.324007
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close()"""
    from matplotlib import pyplot as plt
    from matplotlib import rcParams
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_close():
        """Test tqdm_gui.close()"""
        # Remember if external environment uses toolbars
        toolbar = rcParams['toolbar']
        rcParams['toolbar'] = 'None'
        # Remember if external environment is interactive
        wasion = plt.isinteractive()
        plt.ion()
        # Create a tqdm_gui
        t = tqdm_gui(total=10)
        # Close it
        t.close()
        # Restore toolbars
        rcParams['toolbar'] = toolbar
        # Return to non

# Generated at 2022-06-18 11:41:57.863302
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    tqdm_gui.close()

# Generated at 2022-06-18 11:42:07.827476
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm as std_tqdm
    from .std import tgrange as std_tgrange
    from .std import trange as std_trange

    # Test tqdm_gui
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
    assert pbar.n == 100

    # Test tqdm_gui
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
    assert pbar.n == 100

    # Test tqdm_gui
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
    assert pbar.n

# Generated at 2022-06-18 11:42:17.657049
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tqdm

# Generated at 2022-06-18 11:42:20.215524
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test tqdm_gui.clear() method.
    """
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10), desc='test'):
        sleep(0.01)
        tqdm.clear()
    tqdm.close()