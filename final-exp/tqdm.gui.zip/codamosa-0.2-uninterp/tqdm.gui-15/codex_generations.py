

# Generated at 2022-06-18 11:36:35.269105
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .std import tqdm
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-18 11:36:46.223028
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from os import getpid
    from os.path import exists
    from tempfile import gettempdir
    from multiprocessing import Process
    from multiprocessing.managers import SyncManager
    from multiprocessing.managers import BaseManager
    from multiprocessing.managers import BaseProxy
    from multiprocessing.managers import DictProxy
    from multiprocessing.managers import Namespace
    from multiprocessing.managers import ValueProxy
    from multiprocessing.managers import ArrayProxy
    from multiprocessing.managers import ListProxy
    from multiprocessing.managers import Server
    from multiprocessing.managers import State
    from multiprocessing.managers import RLock
    from multiprocessing.managers import Condition

# Generated at 2022-06-18 11:36:47.963614
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:36:52.317626
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    assert tqdm._instances == []
    assert tqdm.mpl.rcParams['toolbar'] == 'None'

# Generated at 2022-06-18 11:37:02.910653
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from time import sleep
    from tqdm.gui import tqdm_gui

    # test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    # test without total
    with tqdm_gui() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    # test with total and dynamic miniters
    with tqdm_gui(total=100, miniters=1) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    # test without total and

# Generated at 2022-06-18 11:37:13.834814
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from time import sleep

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Create a figure
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")
    ax.legend(("cur", "est"), loc='center right')

# Generated at 2022-06-18 11:37:16.540170
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:37:26.450399
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit='iB', unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit_scale=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    with tqdm_gui(total=100, unit='iB') as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)

# Generated at 2022-06-18 11:37:36.193155
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:37:38.436887
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()


# Generated at 2022-06-18 11:38:01.540007
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from tqdm import tqdm_gui
    from tqdm.utils import _term_move_up
    # from tqdm.gui import tqdm_gui
    # from tqdm.gui import _term_move_up
    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()
    # Test with no total
    t = tqdm_gui()
    for i in range(100):
        sleep(0.01)
        t.update()
    t.close()
    # Test with no total and miniters
    t = tqdm_gui(miniters=1)
    for i in range(100):
        sleep(0.01)
        t

# Generated at 2022-06-18 11:38:09.216361
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Create a tqdm_gui instance
    t = tqdm_gui(total=10)
    # Check if the tqdm_gui instance is created
    assert t is not None
    # Check if the tqdm_gui instance is added to the list of instances
    assert t in tqdm_gui._instances

    # Close the tqdm_gui instance
    t.close()
    # Check if the tqdm_gui instance is removed from the list of instances

# Generated at 2022-06-18 11:38:10.614211
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)

# Generated at 2022-06-18 11:38:20.511605
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint

    # Initialize tqdm_gui
    t = tqdm_gui(total=100, leave=False)
    # Check if tqdm_gui is initialized correctly
    assert t.disable is False
    assert t.total == 100
    assert t.leave is False
    assert t.n == 0
    assert t.last_print_n == 0
    assert t.last_print_t == t._time()
    assert t.start_t == t.last_print_t
    assert t.dynamic_ncols is True
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.miniters == 1
    assert t.ascii is False

# Generated at 2022-06-18 11:38:31.603722
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from time import sleep
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_close():
        # Test that tqdm_gui.close() restores the environment
        # (interactive mode and toolbars)
        # and closes the figure
        plt.ion()
        plt.rcParams['toolbar'] = 'toolmanager'
        t = tqdm_gui(total=10)
        sleep(0.1)
        t.close()
        assert not plt.isinteractive()
        assert plt.rcParams['toolbar'] == 'toolmanager'
        assert not plt.fignum_exists(t.fig.number)

    test_tqdm_gui_close()

# Generated at 2022-06-18 11:38:40.437666
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import seed
    from numpy.random import choice
    from numpy.random import shuffle
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand

# Generated at 2022-06-18 11:38:44.998191
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    plt.ion()
    t = tqdm_gui(total=100)
    for i in range(10):
        t.update()
        t.display()
    t.close()
    plt.ioff()
    plt.show()

# Generated at 2022-06-18 11:38:56.429817
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def test_tqdm_gui_close():
        # Remember if external environment uses toolbars
        toolbar = mpl.rcParams['toolbar']
        mpl.rcParams['toolbar'] = 'None'

        # Remember if external environment is interactive
        wasion = plt.isinteractive()
        plt.ion()

        # Create a progressbar
        t = tqdm_gui(total=100)

        # Close the progressbar
        t.close()

        # Restore toolbars
        mpl.rcParams['toolbar'] = toolbar

        # Return to non-interactive mode
        if not wasion:
            plt.ioff()

# Generated at 2022-06-18 11:38:59.581548
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:39:07.210574
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(randint(10, 100) * 1e-3)
    for i in tqdm_gui(range(10), desc='1st loop'):
        for j in tqdm_gui(range(5), desc='2nd loop', leave=False):
            for k in tqdm_gui(range(100), desc='3nd loop', leave=False):
                sleep(randint(10, 100) * 1e-3)

# Generated at 2022-06-18 11:39:36.179545
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm_gui(range(10)):
        sleep(0.1)
        tqdm_gui.clear()

# Generated at 2022-06-18 11:39:37.878329
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:39:41.066202
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm_gui
    for i in tqdm_gui(range(10)):
        sleep(0.1)
    # Test that the figure is closed
    assert not plt.fignum_exists(tqdm_gui.fig.number)

# Generated at 2022-06-18 11:39:42.619143
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:39:53.278546
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, allclose
    from numpy.random import randint
    from numpy.testing import assert_allclose

    # Test with total
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(randint(1, 10) / 1000)
            pbar.update()
    assert_allclose(pbar.xdata, array(range(100)))
    assert_allclose(pbar.ydata, array(range(100)))
    assert_allclose(pbar.zdata, array(range(100)))
    assert allclose(pbar.hspan.get_xy()[2, 0], 1)

    # Test without total

# Generated at 2022-06-18 11:39:57.413633
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.clear()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:40:07.356107
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from .gui import tqdm
    for i in tqdm(range(10)):
        time.sleep(0.1)
    for i in tqdm(range(10), leave=True):
        time.sleep(0.1)
    for i in tqdm(range(10), leave=False):
        time.sleep(0.1)
    for i in tqdm(range(10), leave=False, disable=True):
        time.sleep(0.1)
    for i in tqdm(range(10), leave=True, disable=True):
        time.sleep(0.1)
    for i in tqdm(range(10), leave=True, disable=False):
        time.sleep(0.1)

# Generated at 2022-06-18 11:40:14.929696
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from matplotlib.pyplot import close
    from .std import tqdm_gui as tqdm


# Generated at 2022-06-18 11:40:17.817638
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.clear()

# Generated at 2022-06-18 11:40:20.798547
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:41:16.475363
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from random import random
    for i in tqdm_gui(range(10)):
        sleep(random())
    for i in tqdm_gui(range(10)):
        sleep(random())

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:41:24.509952
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()
    # Create a tqdm_gui object
    t = tqdm_gui(total=100)
    # Test the close method
    t.close()
    # Restore toolbars
    mpl.rcParams['toolbar'] = toolbar
    # Return to non-interactive mode
    if not wasion:
        plt.ioff()


# Generated at 2022-06-18 11:41:33.004019
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import randn
    from numpy.random import choice
    from numpy import array
    from numpy import concatenate
    from numpy import arange
    from numpy import linspace
    from numpy import logspace
    from numpy import log10
    from numpy import sqrt
    from numpy import sin
    from numpy import cos
    from numpy import pi
    from numpy import exp
    from numpy import log
    from numpy import log2
    from numpy import log10
    from numpy import log1p
    from numpy import ceil
    from numpy import floor
    from numpy import trunc
    from numpy import around
    from numpy import fabs
   

# Generated at 2022-06-18 11:41:42.144329
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array
    from numpy.testing import assert_array_equal

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.close()

    t = tqdm_gui(total=100)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.close()

   

# Generated at 2022-06-18 11:41:46.102237
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        time.sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-18 11:41:55.043243
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from sys import version_info
    from os import getpid
    from os.path import basename
    from random import random
    from math import sqrt
    from numpy import array
    from numpy.random import randn

    # Test for issue #971
    t = tqdm_gui(None, leave=True)
    t.display()
    t.close()

    # Test for issue #971
    t = tqdm_gui(None, leave=True)
    t.display()
    t.close()

    # Test for issue #971
    t = tqdm_gui(None, leave=True)
    t.display()
    t.close()

    # Test for issue #971
    t = tqdm_gui(None, leave=True)

# Generated at 2022-06-18 11:42:05.514567
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import allclose
    from numpy.testing import assert_allclose
    from matplotlib.pyplot import close as plt_close

    t = tqdm_gui(total=100, leave=True)
    for i in t:
        sleep(0.01)
        t.display()
    t.close()

    t = tqdm_gui(total=100, leave=True)
    for i in t:
        sleep(0.01)
        t.display()
        if i == 50:
            t.n = 0
    t.close()

    t = tqdm_gui(total=100, leave=True)
    for i in t:
        sleep(0.01)
        t.display()
        if i == 50:
            t.last_print_

# Generated at 2022-06-18 11:42:15.744249
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import time
    from .std import tqdm

    # Test 1
    t = tqdm(total=100, leave=False)
    for i in range(100):
        time.sleep(0.01)
        t.update()
    t.close()
    assert plt.fignum_exists(t.fig.number)

    # Test 2
    t = tqdm(total=100, leave=False)
    for i in range(100):
        time.sleep(0.01)
        t.update()
    t.close()
    assert plt.fignum_exists(t.fig.number)

    # Test 3
    t = tqdm(total=100, leave=False)

# Generated at 2022-06-18 11:42:23.196073
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import random
    for _ in tqdm_gui(range(10), desc='1st loop'):
        for _ in tqdm_gui(range(100), desc='2nd loop', leave=False):
            for _ in tqdm_gui(range(50), desc='3nd loop', leave=False):
                sleep(0.01)
                random.randint(0, 100)
    for _ in tqdm_gui(range(10), desc='1st loop'):
        for _ in tqdm_gui(range(100), desc='2nd loop', leave=False):
            for _ in tqdm_gui(range(50), desc='3nd loop', leave=False):
                sleep(0.01)
                random.randint(0, 100)

# Generated at 2022-06-18 11:42:32.752711
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import randint
    from numpy import array
    import matplotlib.pyplot as plt
    # Test 1
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)
    # Test 2
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update()
    # Test 3
    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)
    # Test 4