

# Generated at 2022-06-24 10:12:31.135618
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm
    from .gui import tgrange
    from time import sleep
    iterable = tgrange(10)
    for item in iterable:
        sleep(0.1)
    tqdm_gui_01 = tqdm(total=10)
    tqdm_gui_01.close()

# Generated at 2022-06-24 10:12:40.168788
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """ Unit test for method clear of class tqdm_gui """
    import os
    import shutil
    from .utils import _term_move_up
    from .standard import tqdm as std_tqdm

    testing_folder = '/tmp/.tqdm.test_tqdm_gui_clear'
    if os.path.isdir(testing_folder):
        shutil.rmtree(testing_folder)
    os.mkdir(testing_folder)
    os.chdir(testing_folder)


# Generated at 2022-06-24 10:12:46.800723
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    try:
        from matplotlib import pyplot as plt
        from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    except ImportError:
        raise unittest.SkipTest("Tests for tqdm_gui requires Matplotlib")
    plt.ion()
    with tqdm_gui(total=100) as pbar2:
        for i in range(100):
            pbar2.update(1)
            time.sleep(0.01)


if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:12:52.988908
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    tqdm_gui(range(100))


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:03.982438
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import tqdm as tqdm_std
    from numpy.random import random

    for _ in tqdm_std(range(12)):
        for _ in tqdm_gui(range(3600)):
            _ = sum(random(10000))


# Simple unittest
if __name__ == '__main__':  # pragma: no cover
    from .std import tqdm as tqdm_std

    # Unit test for method display of class tqdm
    test_tqdm_gui_display()

    # Unit test for class tqdm_gui
    with tqdm_gui(total=1000) as t:
        for _ in tqdm_std(range(1000)):
            t.n += 1
            t.refresh()

# Generated at 2022-06-24 10:13:06.162224
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=100) as pbar:
        for _ in range(100):
            pbar.update()

# Generated at 2022-06-24 10:13:10.112461
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui, tgrange
    t1 = tqdm_gui(_range(100), gui=True)
    t2 = tgrange(100, gui=True)
    t1.clear()
    t2.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:13:15.862691
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        tt = tqdm(total=1000)
        for i in _range(1000):
            tt.update()
    except Exception:
        # DEBUG
        import traceback
        traceback.print_exc()
        pass
    finally:
        tt.close()

# Generated at 2022-06-24 10:13:20.333435
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from math import sqrt

    def progress_bar_test(n):
        t = tqdm(n, gui=True, leave=False)
        for i in t:
            sqrt(i)
        t.close()

    progress_bar_test(100)


# The following code is purely for documentation purposes
# (it is not run as an actual test)

# Generated at 2022-06-24 10:13:32.620031
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import time
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)
            pbar.clear(total=20, n=10)
        pbar.clear()


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    # test_tqdm_gui_clear()
    # from sys import argv
    # from numpy import random
    # x = int(argv[1])
    # for i in trange(x):
    #     sleep(random.rand())
    # test_tqdm_gui_clear()

# Generated at 2022-06-24 10:13:44.824194
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    from numpy import isclose
    from numpy.random import uniform

    for _ in tqdm_gui(
            tgrange(1000), desc="Tqdm(tgrange())", leave=True, unit="it"):
        sleep(uniform(0, 0.01))

    assert isclose(tqdm_gui(0)[0].n, 1000)
    assert isclose(tqdm_gui(0).n, 1000)


if __name__ == "__main__":  # pragma: no cover

    # TqdmTypeError is raised if GUI package is not installed properly
    # Python >= 2.6 (excluding 3.x)
    assert "tqdm._tqdm" in str(tqdm_gui)

# Generated at 2022-06-24 10:13:51.920276
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    assert tqdm_gui()._instances == []
    pbar = tqdm_gui()
    assert pbar._instances == [pbar]
    pbar.close()
    assert pbar._instances == []
    assert pbar.disable
    assert tqdm_gui()._instances == []


# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================




# Generated at 2022-06-24 10:13:55.839449
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    assert tqdm_gui.close is tqdm.close
    iterable = range(3)
    for item in iterable:
        pass
    tqdmg = tqdm(iterable)
    try:
        assert tqdmg._instances
        tqdmg.close()
        assert tqdmg._instances == []
    except (AttributeError, TypeError):
        pass

# Generated at 2022-06-24 10:13:59.061784
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(5):
        for j in tgrange(10):
            for k in tgrange(100):
                pass

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:14:09.697450
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for method close of class tqdm_gui"""
    import gc
    from unittest import TestCase
    from matplotlib import pyplot as plt

    class tqdm_gui_close(TestCase):
        """Unit test for method close of class tqdm_gui"""
        def test_clean_up(self):
            """Test that all objects of tqdm_gui are removed from memory after close"""
            tqdm_obj = tqdm_gui(range(10))
            del tqdm_obj
            gc.collect()
            self.assertEqual(plt.fignum_exists(1), False)

    return tqdm_gui_close

# Generated at 2022-06-24 10:14:15.971029
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for _ in tgrange(4):
        for _ in trange(100):
            sleep(0.01)
    for _ in tgrange(4):
        for _ in trange(10, 100, 3):
            sleep(0.01)
    for _ in tgrange(4):
        for _ in trange(10, 9, -1):
            sleep(0.01)


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:14:25.002699
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np
    f, ax = plt.subplots()

# Generated at 2022-06-24 10:14:34.695751
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Tests tqdm_gui.clear()"""
    try:
        tqdm_gui([1], desc="Test clear", leave=True)
    except Exception as e:
        raise_from(AssertionError(e), None)


if __name__ == "__main__":
    from time import sleep
    import sys

    with tqdm_gui(total=4, desc='1st loop ', leave=True) as pbar:
    # with tqdm(total=4, desc='1st loop') as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-24 10:14:42.386822
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm_gui
    from .utils import _range
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    for i in tqdm_gui(_range(10), leave=True, disable=False):
        if i > 5:
            break

    # If a figure is still open (because leave=True), then it was not closed
    # correctly.
    assert(not plt.get_fignums())
    # Restore toolbars (in case they were disabled)
    mpl.rcParams['toolbar'] = 'toolbar2'

# Generated at 2022-06-24 10:14:50.824229
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for `tqdm.gui.tqdm(xrange(*args), **kwargs)`.
    On Python3+, `range` is used instead of `xrange`.
    """
    # skip if no display available
    import os
    gotdisplay = bool(os.environ.get('DISPLAY'))
    try:
        import matplotlib.pyplot as plt
        gotdisplay = gotdisplay and (plt.get_backend() != 'Agg')
    except ImportError:
        pass  # no Qt5Agg backend for matplotlib installed
    if not gotdisplay:
        return True

    import sys
    import multiprocessing


# Generated at 2022-06-24 10:14:52.366258
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(0) as t:
        pass
    t.close()

# Generated at 2022-06-24 10:14:54.839257
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        assert pbar.disable is False
        pbar.clear()
        assert pbar.disable is False

# Generated at 2022-06-24 10:15:04.845226
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test that display method is matplotlib-compatible."""
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib.axes import Axes
    # import numpy as np
    from sys import version_info as python_version

    assert python_version[:2] >= (2, 7)  # use unittest.skipif?

    if mpl.get_backend().lower() not in ('module://ipykernel.pylab.backend_inline', 'agg'):  # NOQA
        return

    if python_version >= (3, 0):
        from_iter = range
    else:
        from_iter = xrange

    # inline plot
    # %matplotlib inline
    plt.ion()


# Generated at 2022-06-24 10:15:14.906423
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import os

    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        mpl = None
        plt = None

    # test if running from within non-interactive environment
    already_interactive = plt.isinteractive()
    if already_interactive:
        plt.ioff()

    # recreate the GUI class to make sure plotting works
    tqdm_gui(['a'])
    tqdm_gui(['b'])

    # test that interactive mode is enabled
    assert tqdm_gui(['c']).wasion is True
    assert tqdm_gui(['d']).wasion is True

    # test that interactive mode was turned on and then off
    assert plt.isinteractive() is False

# Generated at 2022-06-24 10:15:20.137949
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from multiprocessing import Process
    from .std import tqdm

    def plot_and_close():
        sleep(0.1)
        tqdm.close()

    tqdm.disable = False
    tqdm.inits()
    p = Process(target=plot_and_close)
    p.start()
    for i in tqdm(range(100)):
        sleep(0.01)
    p.join()

if __name__ == "__main__":
    test_tqdm_gui_close()

# Copyright (c) 2009-2013, Last.fm Limited <hughsie@last.fm>
# Copyright (c) 2013, Ken Reitz <mr.ken@kenreitz.com>
# All rights reserved.
#
# Redistribution and use

# Generated at 2022-06-24 10:15:29.741536
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # import os
    import pytest
    t = tqdm_gui(total=5, mininterval=0)
    with pytest.raises(KeyError):
        t.display()
    t.last_print_n = 5

    t.display()
    t.display()

    t = tqdm_gui(mininterval=0)
    with pytest.raises(KeyError):
        t.display()
    t.display()
    t.display()
    t.close()
    # os.system('echo Exit test_tqdm_gui_display')

# Generated at 2022-06-24 10:15:37.797455
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import numpy as np
    from math import sqrt

    # Create mock objects
    class Mock(object):
        def __getattr__(self, _):
            return Mock()

        def __call__(self, *_, **__):
            return Mock()

        @classmethod
        def __getattr__(cls, _):
            return cls

    mpl = Mock()
    tqdm_gui.plt = mpl
    tqdm_gui.mpl = mpl

    class Mock_axes(object):
        def __getattribute__(self, name):
            if name == "set_xlabel":
                # so that the function returns normally
                return lambda _: None
            elif name == "get_xlim":
                # so that the function returns normally
                return

# Generated at 2022-06-24 10:15:40.049552
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=3)
    t.update()
    t.clear()
    t.close()

# Generated at 2022-06-24 10:15:50.645161
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import IS_PYTHON, LOCALE, PYTHON_VERSION, _term_move_up
    import sys

    default_format_string = tqdm_gui.format_defaults['bar_format']
    # TODO: wrap
    # with tqdm_gui(total=10, bar_format='<{bar}>', ncols=100) as pbar:
    #     pbar.clear()
    #     assert pbar.pos == 0
    #     assert pbar.n == 0
    #     assert pbar.last_print_n == 0
    default_format_string = tqdm_gui.format_defaults['bar_format']

# Generated at 2022-06-24 10:15:54.530341
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    t = tqdm_gui(["a", "b", "c", "d"])
    for i in t:
        sleep(0.1)

# Generated at 2022-06-24 10:15:59.339160
# Unit test for function tgrange
def test_tgrange():
    from .tests.gui import _test_exception_stderr  # noqa
    import sys
    import time
    with _test_exception_stderr():
        if [i for i in tqdm(tgrange(3), position=2)]:
            time.sleep(0.1)
            # test GUI closing
            sys.exit(2)

# Generated at 2022-06-24 10:16:07.987631
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from copy import copy
    from time import sleep

    try:
        from matplotlib import pyplot as plt
        from numpy.testing import assert_allclose
    except:
        return

    def _test_tqdm_display(cls):
        # type: (tqdm_gui) -> None
        """Test the display method of tqdm_gui with a timer-based tqdm"""
        assert cls.disable is False, "Test tqdm_gui after cls.close()"

# Generated at 2022-06-24 10:16:18.105096
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from tqdm._std_tqdm import _LocaleManagedStringIO, tnrange, tqdm
    import sys
    import time

    with _LocaleManagedStringIO() as f:
        for _ in tqdm(range(2),
                      file=f,
                      ncols=10,
                      desc="tqdm(gui=True)",
                      gui=True):
            time.sleep(1)

        if sys.version_info >= (3, 3):
            assert "tqdm(gui=True): 100%|██████████| 2/2 [00:02<00:00,  1.01s/it]" \
                == f.getvalue().replace("\r", "")

# Generated at 2022-06-24 10:16:18.920729
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tgrange(10):
        sleep(0.01)

# Generated at 2022-06-24 10:16:20.190599
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui
    t = tqdm_gui(range(5), bar_format='<bar/>')
    t.clear()

# Generated at 2022-06-24 10:16:29.454039
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from os import getpid
    from sys import executable, argv, stdout

    try:
        from subprocess import Popen, PIPE
    except ImportError:
        Popen, PIPE = None, None

    def test_method_display(total, display_args):
        t = tqdm(total=total, file=stdout)
        last_print_i = None
        for i in _range(total):
            t.update()
            t.display(*display_args)
            t.refresh()
            assert t.last_print_n == last_print_i, (t.last_print_n, last_print_i)
            last_print_i = t.last_print_n


# Generated at 2022-06-24 10:16:39.412636
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for method close of class tqdm_gui

    Usage:
    $ python -m tqdm.gui test_tqdm_gui_close
    """
    from time import sleep
    from sys import argv

    tqdm().close()
    tqdm_gui(1).close()

    if argv.count("--leave"):
        tqdm_gui(1, leave=True).close()
        tqdm_gui(1, leave=False).close()
    for _ in tqdm_gui(range(100)):
        sleep(0.01)
    tqdm_gui(1).close()
    tqdm_gui(1, leave=True).close()
    tqdm_gui(1, leave=False).close()

# Generated at 2022-06-24 10:16:49.409771
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import os
    import sys
    import time
    import optparse
    import doctest
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Parse command line arguments
    p = optparse.OptionParser(usage="%prog [options]",
                              description="Test GUI progressbar in tqdm")
    p.add_option('-c', "--leave", help="leave traces after execution",
                 default=False, action="store_true")
    p.add_option('-t', "--time", help="test time-based instead of iteration-based",
                 default=False, action="store_true")
    p.add_option('-s', "--sleep", help="sleep N seconds at each iteration",
                 default=0.0, type="float")
    p.add_option

# Generated at 2022-06-24 10:17:01.652863
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import format_sizeof
    from sys import getsizeof
    from time import sleep, perf_counter
    from os import devnull

    for __ in tqdm_gui(total=None, leave=True, unit="B",
                       unit_scale=True, dynamic_ncols=True,
                       desc="test_tqdm_gui", mininterval=0.5,
                       miniters=0, ascii=False, file=devnull):
        sleep(0.2)
    with open(devnull, 'w') as fd:
        fd.write("\n")

# Generated at 2022-06-24 10:17:05.900003
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    # Create a tqdm_gui object with initial value and maximal value
    obj = tqdm_gui(4, 0, 4)
    for i in obj:
        obj.set_postfix(foo=i)
        sleep(1)
    # Close the GUI graph
    obj.close()

# Generated at 2022-06-24 10:17:09.032228
# Unit test for function tgrange
def test_tgrange():
    from .gui import tgrange

    assert list(tgrange(4)) == [0, 1, 2, 3]



# Generated at 2022-06-24 10:17:12.084895
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Tests method clear of class tqdm_gui."""
    with tqdm(total=10) as t:
        t.write('test')
        assert t.clear() is None
        t.update()

# Generated at 2022-06-24 10:17:21.840874
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    objs = [tqdm_gui(total=3), tqdm(total=3), tqdm_gui(total=3, miniters=1),
            tqdm(total=3, miniters=1), tqdm_gui(total=3, mininterval=1),
            tqdm(total=3, mininterval=1), tqdm_gui(total=3, mininterval=1,
                                                   miniters=1),
            tqdm(total=3, mininterval=1, miniters=1)]
    [obj.start() for obj in objs]
    [obj.update() for obj in objs]
    [obj.update() for obj in objs]
    [obj.clear() for obj in objs]

# Generated at 2022-06-24 10:17:25.948958
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from contextlib import closing
    except ImportError:
        from contextlib2 import closing

    with closing(tqdm(total=3)) as t:
        for i in range(4):
            t.update()



# Generated at 2022-06-24 10:17:35.034672
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import time
    try:
        from time import monotonic as time
    except ImportError:
        from time import time

    # To test the method clear() of class tqdm_gui :
    # in a loop of 10 interations, we use the method clear to update only the
    # progressbar

    t0 = time()
    t = tqdm_gui(total=10)
    for i in range(10):
        t.clear()
        t.update(1)
    t.close()
    t1 = time()
    time_needed = t1 - t0
    assert time_needed < 1, 'Method clear() of class tqdm_gui is slow'

# Generated at 2022-06-24 10:17:39.422809
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm(range(10)):
        sleep(0.01)
    for i in tqdm(range(9, -1, -1)):
        sleep(0.01)
        if i in [0, 2, 3, 4, 6, 8]:
            tqdm.clear()



# Generated at 2022-06-24 10:17:41.326517
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(1)
    t.clear()
    t.close()

# Generated at 2022-06-24 10:17:46.429324
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(ascii=True, total=10) as pbar:
        for i in range(10):
            pbar.clear()
    # test that tqdm_gui.__init__() raises no exception
    tqdm_gui(ascii=True)


# Generated at 2022-06-24 10:17:55.408641
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Unitary test
    # Only tests init/display/close in stdout mode
    # using stdout=PIPE, stdout.write() and stdout.flush()
    import io
    import sys
    import re

    buf = io.StringIO()
    t = tqdm_gui(tgrange(100), file=buf)
    for i in tgrange(100):
        t.display()
        buf.write(buf.getvalue().replace('<bar/>', '='))
        buf.flush()
    t.close()
    buf.close()
    sys.stdout.write(re.sub(r'\[[^]]*?\]', '', buf.getvalue()))  # strip colors

# Generated at 2022-06-24 10:17:58.776514
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm(range(4)):
        sleep(3)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:18:04.887539
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from time import sleep
    from sys import argv

    print("".join(argv))
    sleep(0.1)
    for i in tqdm(range(100), leave=False):
        sleep(0.01)
        if i == 2:
            tqdm.clear()
            print("".join(argv))
            sleep(0.1)
    tqdm.close()

# Generated at 2022-06-24 10:18:09.948804
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import FormatWidget
    from .cli import TqdmTypeError, TqdmKeyError
    with tqdm(total=10) as pbar:
        pbar.clear()
        try:
            pbar.clear(1, 2, 3)
        except TypeError:
            raise TqdmTypeError
        try:
            pbar.clear(message='abc', some_other_kwarg=None)
        except TypeError:
            raise TqdmTypeError
        try:
            pbar.clear(some_other_kwarg=None)
        except KeyError:
            raise TqdmKeyError



# Generated at 2022-06-24 10:18:19.356206
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        from tkinter import TclError     # Python 3
    except ImportError:
        from Tkinter import TclError     # Python 2
    import time
    import matplotlib

    # Detect and override if matplotlib tries to display a window
    try:
        save_display = matplotlib.rcParams['backend.qt4']
        matplotlib.use('Agg', warn=False)
        time.sleep(1)
    except (TypeError, KeyError, TclError, AttributeError):
        pass


# Generated at 2022-06-24 10:18:21.778575
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui.clear"""
    t = tqdm_gui(range(10))
    t.clear()
    t.close()

# Generated at 2022-06-24 10:18:29.506247
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from numpy import inf
        from matplotlib.testing.decorators import cleanup
        from matplotlib.pyplot import close
    except ImportError:
        return

    with cleanup():
        for leave in [True, False]:
            for mininterval in [0, 0.5, 2]:
                for n in [10, 100, 1000]:
                    t = tqdm_gui(total=n, leave=leave,
                                 mininterval=mininterval)
                    for _ in t:
                        pass
                    t.close()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:18:31.257093
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for i in tgrange(10, desc="foo bar"):
        sleep(0.1)

# Generated at 2022-06-24 10:18:34.116127
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    t = tqdm(total=5)
    for i in range(5):
        t.update()
        sleep(0.2)
    t.close()

# Generated at 2022-06-24 10:18:36.563451
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=1, ascii=True, gui=True) as pbar:
        pbar.update()
        pbar.clear()
        pbar.close()

# Generated at 2022-06-24 10:18:45.216392
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    import time
    try:
        import psutil
        psutil.Process().nice(15)
    except (AttributeError, ImportError):
        pass

    with tgrange(0, 20) as tr:
        for i in tr:
            tr.set_description("desc {}".format(i))
            tr.display()
            time.sleep(0.1)

    with tgrange(0, 20) as tr:
        for i in tr:
            tr.set_description("desc {}".format(i))
            tr.display()
            time.sleep(0.1)

    for i in tgrange(0, 20):
        time.sleep(0.1)
        sys.stdout.write("{}\n".format(i))

# Generated at 2022-06-24 10:18:50.343387
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from time import sleep
    from os import remove
    from .utils import _range

    dirty_close = False
    try:
        plt.close()
        remove('test_tqdm_gui_close')
    except:
        dirty_close = True

    with tqdm(_range(10), ascii=True, file=open('test_tqdm_gui_close', 'w')) as t:
        for i in t:
            try:
                sleep(0.3)
            except KeyboardInterrupt:
                t.close()
                raise
    close_demo = open('test_tqdm_gui_close').read()
    remove('test_tqdm_gui_close')
    assert close_demo == ''


# Generated at 2022-06-24 10:18:59.906913
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from mock import patch

    from .gui import tqdm_gui
    fake = tqdm_gui(gui=True, disable=True)
    try:  # Python 2
        import __builtin__ as builtins
    except ImportError:
        import builtins
    fake.plt = patch(builtins.__name__ + ".plt")
    fake.mpl = patch(builtins.__name__ + ".mpl")
    fake.close()

    fake.disable = False
    fake.wasion = False
    fake.plt.isinteractive.return_value = True
    fake.close()
    fake.plt.ioff.assert_called_once_with()
    fake.plt.close.assert_called_with(fake.fig)

    fake.wasion = True

# Generated at 2022-06-24 10:19:03.521940
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as pbar:
        for i in _range(10):
            pbar.update()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:08.201181
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for class tqdm_gui

    test_tqdm_gui()
    """
    import time
    @tqdm_gui
    def _tqdm_gui(*args, **kwargs):
        time.sleep(0.05)
        return std_tqdm(*args, **kwargs)

    # test on list
    for _ in _tqdm_gui(list(range(10))):
        pass
    # test on generator
    for _ in _tqdm_gui(i for i in range(10)):
        pass


if __name__ == '__main__':
    from tqdm import main
    main()

# Generated at 2022-06-24 10:19:16.925393
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import time
    with tqdm_gui(total=10, unit='B', unit_scale=True) as t:
        for i in _range(10):
            time()
            t.update()
    assert t.disable


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    with tqdm(total=100) as t:
        for i in trange(10):
            sleep(0.01)
            t.update(10)
    x = list(range(1000))
    with tqdm(total=len(x)) as t:
        for i in x:
            sleep(0.001)
            t.update()

# Generated at 2022-06-24 10:19:22.969977
# Unit test for method clear of class tqdm_gui

# Generated at 2022-06-24 10:19:26.818215
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from time import sleep
    x = tqdm_gui([1, 2, 3, 4])
    for _ in x:
        sleep(1)
        x.clear()
    x.close()

# Generated at 2022-06-24 10:19:29.518866
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    for i in tqdm_gui(iterable=range(100)):
        time.sleep(0.01)

# Generated at 2022-06-24 10:19:41.755096
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Testing method close of class tqdm_gui
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import warnings
    import collections

    # Test of decorator tqdm_gui
    test_list = list(range(0, 100))
    warnings.filterwarnings("ignore")
    with tqdm_gui(test_list, total=100) as bar:
        for i in bar:
            pass
    with tqdm_gui(test_list) as bar:
        for i in bar:
            pass
    with tqdm_gui(test_list, leave=1) as bar:
        for i in bar:
            pass
    with tqdm_gui(test_list, leave=0) as bar:
        for i in bar:
            pass


# Generated at 2022-06-24 10:19:46.990327
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        import matplotlib as mpl
    except ImportError:
        return

    mpl.use('TkAgg')
    from .std import tqdm

    t = tqdm(total=100)
    for i in t:
        t.update()
        if i == 5:
            t.close()
            break

# Generated at 2022-06-24 10:19:54.627929
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from re import sub
    from numpy import array, poly1d, polyfit, polyval
    from math import isnan

    t = tqdm_gui(total=100)
    for i in range(100):
        sleep(0.01)
        t.display(i)
    if bool(t.total):
        assert (t.xdata == t.ax.get_xlim())
    else:
        assert (t.xdata == t.ax.get_ylim())
    assert (t.xdata == array(t.ax.get_xlim()))

    # Finalise plot
    t.close()

    # Check is ydata is a polynomial
    ydata = array(t.ydata)
    xdata = array(t.xdata)

# Generated at 2022-06-24 10:20:05.625660
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as t:
        for i in range(10):
            sleep(0.1)
            t.update(10)
    t.close()

    with tqdm_gui(total=100, unit='blocks', unit_scale=True, mininterval=0.2) as t:
        for i in range(10):
            sleep(0.1)
            t.update(10)
    t.close()

    with tqdm_gui(total=100, unit='blocks', unit_scale=False, mininterval=0.2) as t:
        for i in range(10):
            sleep(0.1)
            t.update(10)
    t.close()


# Generated at 2022-06-24 10:20:15.105555
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    T = tqdm(total=42)
    # get time and start
    T.start_t = T._time()
    T.last_print_t = T.start_t
    T.last_print_n = 0
    T.n = 11
    T.miniters = 1
    T.stateful_meters = "spam"
    T.total = 42
    T.xdata = [0, 0]
    T.ydata = [0, 0]
    T.zdata = [0, 0]
    T.ax = None
    T.line1 = None
    T.line2 = None
    # display the progress bar
    T.display()

if __name__ == '__main__':
    test_tqdm_gui_display()