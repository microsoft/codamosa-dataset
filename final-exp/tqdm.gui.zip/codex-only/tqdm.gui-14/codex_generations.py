

# Generated at 2022-06-24 10:12:32.097048
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close()"""
    from matplotlib import pyplot as plt
    pbar = tqdm_gui(total=10)
    pbar.close()
    plt.close('all')

# Generated at 2022-06-24 10:12:40.777965
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        # Avoid importing numpy if not installed
        import numpy as np
        from tqdm.auto import tqdm
    except ImportError:
        assert True
        return
    try:
        # Test if tqdm is patched by tqdm_gui
        tqdm_gui.orig_tqdm = tqdm.tqdm
    except AttributeError:
        # tqdm is not patched
        assert True
        return

    t = tqdm(np.zeros(10))
    t.display()
    t.close()
    mpl = t.mpl
    plt = t.plt
    assert mpl.rcParams['toolbar'] == 'None'
    assert not plt.isinteractive()

# Generated at 2022-06-24 10:12:43.520457
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            t.update(1)
            t.set_description("TEST")
            t.set_postfix(OrderedDict(std="test"))

# Generated at 2022-06-24 10:12:50.483482
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from sys import version_info
    from unittest import TestCase

    from io import StringIO
    from unittest.mock import MagicMock

    class MockTextInjector(StringIO):
        """Mock TextInjector class."""
        def writeln(self, string):
            """Mock writeln method."""
            self.write(string + "\n")

    class MockBar(object):
        """Mock Bar class."""
        def __init__(self, string):
            self.string = string

    class TestTqdmGuiDisplay(TestCase):
        """Test TqdmGuiDisplay class."""
        def test_display_type_error(self):
            """Test type errors from display method."""
            # TypeError only occurs with python 2.x (due to int division)

# Generated at 2022-06-24 10:13:01.120525
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    if not (_range and tqdm_gui):
        return
    t = tqdm_gui(_range(1, 20), disable=False)
    with t:
        for i in t:
            t.display()
            if i > 10:
                t.miniters = 1
                t.mininterval = 100
            if i > 13:
                t.mininterval = 0.05
            if i > 15:
                t.miniters = 10
                t.mininterval = 0.001


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:09.313030
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from io import StringIO
        from contextlib import redirect_stdout
    except ImportError:  # pragma: no cover
        return None
    t = tqdm_gui(total=1)
    t.update(1)
    (t.set_description("test")
     .set_postfix(a=1, b=2, c=3)
     .set_postfix_str("abc")
     .update(1))
    with redirect_stdout(StringIO()) as s:
        t.clear()
    assert len(s.getvalue()) == 0

# Generated at 2022-06-24 10:13:16.273063
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time

    # Remember if external environment uses toolbars
    was_on = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    start_t = time.time()

    a = [i for i in tqdm_gui(range(10))]
    b = [i ** 2 for i in tqdm_gui(range(10), total=10)]

    # Restore toolbars
    mpl.rcParams['toolbar'] = was_on
    # Return to non-interactive mode
    if not wasion:
        plt

# Generated at 2022-06-24 10:13:28.446040
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from io import StringIO
    from warnings import warn
    from .utils import _range
    from .utils import format_sizeof
    import sys

    # test against broken Python 3.4
    if sys.version_info[:2] == (3, 4):
        with StringIO() as f:
            tqdm_gui(_range(1), file=f).clear()
            assert not f.getvalue()
    else:
        with StringIO() as f:
            with tqdm_gui(_range(1), file=f) as t:
                assert t.disable == False
                t.clear()
            assert not f.getvalue()

    # test against broken Python 3.4

# Generated at 2022-06-24 10:13:38.843996
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from numpy.random import random
    from time import sleep
    from random import random as r
    from nose.tools import assert_equal
    # test
    for i in tgrange(10, None, 7, (4, 1), -4, leave=True,
                     mininterval=0, miniters=1, ascii=None,
                     disable=False, unit="foob", unit_scale=True,
                     dynamic_ncols=False):
        j = i / 10.0
        sleep(r() / 10)
    # with tqdm(total=None) as pbar:
    #     for i in range(10):
    #         assert isinstance(i, int)
    #         pbar.update()
    assert_equal(i, 18)

# Generated at 2022-06-24 10:13:44.079958
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Simple test of `tqdm_gui` constructor to avoid errors.
    # Can be launched with:
    # `python -c "from tqdm.gui import tqdm_gui; test_tqdm_gui()"`
    t = tqdm_gui(total=100, leave=True)
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:54.813122
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    import sys
    from .std import TestTqdmGui

    TestTqdmGui(tqdm).test()

    with tqdm(total=100, file=sys.stdout, ncols=100, ascii=True,
              bar_format='{bar} {n:>5}/{total}',
              smoothing=0.1, mininterval=1, miniters=0) as t:
        assert t.get_lock() is not None
        for i in _range(10):
            sleep(0.1)
            t.set_description('i = {}'.format(i))
            t.update(i * 10)
        t.clear()


if __name__ == "__main__":
    test_tqdm_

# Generated at 2022-06-24 10:13:59.015059
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test.
    """
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        from warnings import warn
        warn("matplotlib not found: GUI tests skipped")
        return

    from .utils import FormatStub

    for i in tqdm_gui(range(10), leave=False):
        pass

    for i in tqdm_gui(_range(10), leave=False):
        pass

    for i in tqdm_gui(range(10), total=100, leave=False):
        pass

    for i in tqdm_gui(_range(10), total=100, leave=False):
        pass

    plt.close('all')

    with tqdm_gui(leave=False) as t:
        for i in range(10):
            t.update

# Generated at 2022-06-24 10:14:05.182670
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    sys.argv.append('--leave')
    t = tqdm_gui(total=20)
    for i in t:
        t.clear()
    t.close()
    sys.argv.remove('--leave')

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:14:10.313329
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui."""
    import sys
    from .utils import _range

    with tqdm(_range(100)) as t:
        t.clear()
        if not sys.stdout.isatty():
            sys.exit(1)

# Generated at 2022-06-24 10:14:19.694485
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt  # NOQA

    for leave in [True, False]:
        with tqdm_gui(total=9, leave=leave, dynamic_ncols=True) as pbar:
            for i in range(9):
                pbar.update(1)
        pbar.display()
        plt.close()

    for leave in [True, False]:
        with tqdm_gui(unit='iB', unit_scale=True, leave=leave) as pbar:
            for i in range(9):
                pbar.update(2 ** (10 * i / 8))
        pbar.display()
        plt.close()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:24.975019
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():

    import time
    import numpy as np
    from six.moves import xrange

    # test for infinite loop
    for _ in tqdm(xrange(2)):
        for i in tqdm(xrange(5), leave=True):
            time.sleep(0.5)
            tqdm.write('{}'.format(i))
        print('End of loop')

    # test for finite loop with exception
    try:
        for i in tqdm(xrange(10)):
            time.sleep(1)
            tqdm.write('{}'.format(i))
            if not np.random.randint(3):
                raise Exception
    except Exception:
        print('Catch an exception')

    # test for finite loop without exception

# Generated at 2022-06-24 10:14:31.627849
# Unit test for function tgrange
def test_tgrange():
    from nose.plugins.skip import SkipTest

    raise SkipTest
    import nose.tools as nt

    with nt.assert_raises(StopIteration):
        list(tgrange(0))
    with nt.assert_raises(StopIteration):
        list(tgrange(0, len([1])))
    with nt.assert_raises(StopIteration):
        for _ in tgrange(len([1]) - 1, len([1])):
            pass
    nt.assert_equal(list(tgrange(10, 0, -1)), list(range(10, 0, -1)))



# Generated at 2022-06-24 10:14:38.438383
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        for i in tqdm(range(10)):
            pass
    finally:
        # This may cause the test suite to hang on Windows
        #  if run in an external process (e.g., nosetests)
        #  due to an issue with matplotlib (probably)
        tqdm.close()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:14:45.244947
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from random import random

    # N = 1000
    # x, y = 0, 0
    for i in tqdm(range(100)):
        sleep(random() / 1000)

    # l, = ax.plot([], [], 'r-')
    # ax.set_xlim(0, 1)
    # ax.set_ylim(0, 1)
    # ax.grid()

    # plt.show()


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:53.351179
# Unit test for method clear of class tqdm_gui

# Generated at 2022-06-24 10:15:03.360181
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=1000)
    for i in range(1000):  # pragma: no cover
        assert t.n == i
        t.clear()
        t.n += 1

if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    from random import random
    from sys import stderr
    stderr.write("\n\nNo example available (yet).\n")
    stderr.write("Try `pip install matplotlib`\n\n")
    t = tqdm_gui(total=100, leave=True)
    for i in range(100):
        sleep(random() * 0.1)
        t.update()
    t = tqdm_gui(total=100, leave=False)

# Generated at 2022-06-24 10:15:14.062314
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import sys

    for i in tqdm_gui(range(10000), gui=False,
                      leave=False, dynamic_ncols=True):
        if i > 100:
            break

    tqdm_gui(total=100, disable=True, gui=False,
             leave=True, dynamic_ncols=True).close()

    try:
        sys.stdout.close()
        sys.stdout = sys.__stdout__
    except AttributeError:
        # Not required for python3
        pass
    tqdm_gui(file=sys.stdout, gui=False,
             leave=True, dynamic_ncols=True).close()

# Generated at 2022-06-24 10:15:21.602377
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from itertools import count
    list(tqdm_gui(count(), desc='Dynamic bar', leave=True))
    for i in tqdm_gui(range(10), desc='Static bar'):
        sleep(0.01)
    for i in tqdm_gui(range(100), leave=True, dynamic_ncols=True):
        if i > 5:
            tqdm_gui.set_description('Dynamic bar 2', refresh=True)
        sleep(0.01)
    for i in tqdm_gui(range(20), leave=True, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'):
        sleep(0.1)

# Generated at 2022-06-24 10:15:33.570862
# Unit test for function tgrange
def test_tgrange():
    import os
    import sys
    import time
    import matplotlib.pyplot as plt
    try:
        # Py3
        from itertools import zip_longest
    except ImportError:
        # Py2
        from itertools import izip_longest as zip_longest

    def fmt(it):
        return [x[0] for x in it]

    with tgrange(10, 20, 30) as t:
        for i in t:
            assert t.total == 60
            assert t.n == i
            assert t.last_print_n == (i % 30)
            t.set_description(str(i))

    assert t.n == 60

    with tgrange(10, 20, 30) as t:
        for i in t:
            assert t.total == 60


# Generated at 2022-06-24 10:15:40.995046
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import io
    import sys

    with io.StringIO() as buf, tqdm(total=50, file=buf, dynamic_ncols=True) as t:
        t.n = 10
        text = buf.getvalue()
        t.clear()
        sys.stdout.write(text)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    # test_tqdm_gui_clear()

# Generated at 2022-06-24 10:15:44.166016
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        with tqdm_gui(total=1, desc=':', gui=True) as t:
            pass
    except:
        raise AssertionError("tqdm_gui.close failed")

# Generated at 2022-06-24 10:15:53.789643
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import nose
    import nose.tools as nt
    from time import sleep


# Generated at 2022-06-24 10:16:02.728239
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    try:
        from line_profiler import LineProfiler

        lp = LineProfiler(tqdm_gui.display)
        display = lp(tqdm_gui.display)
    except ImportError:
        return

    dummy = tqdm_gui(total=100)
    dummy.display()
    dummy.update(3)
    dummy.display()
    dummy.update(2)
    dummy.display()
    dummy.update(15)
    dummy.display()
    dummy.update(4)
    dummy.display()
    dummy.update(10)
    dummy.display()
    dummy.update(20)
    dummy.display()
    dummy.close()
    lp.print_stats()

# Generated at 2022-06-24 10:16:08.451904
# Unit test for function tgrange
def test_tgrange():
    from .std import tgrange
    return tgrange


if __name__ == '__main__':  # pragma: no cover
    import time
    from numpy.random import randint

    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(randint(1, 5)/10)
    print("TEST FINISHED")

# Generated at 2022-06-24 10:16:18.541537
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    import time
    from .tqdm_gui import tqdm_gui

    def range_with_print(*args):
        for _ in range(*args):
            print('test_print')
            yield

    with tqdm_gui(total=100, disable=False) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update(1)

    with tqdm_gui(total=100, disable=False) as t:
        for i in range_with_print(100):
            time.sleep(0.01)
            t.update(1)
            t.clear()

    with tqdm_gui(total=100, disable=False) as t:
        for i in range(100):
            time.sleep(0.01)
            t

# Generated at 2022-06-24 10:16:21.393648
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for off in [False, True]:
        for n in [1000, None]:
            with tqdm_gui(total=n, disable=off) as pbar:
                for i in _range(1000):
                    pbar.update()

# Generated at 2022-06-24 10:16:33.197315
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque

    import numpy as np
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    # a unit test for method display of class tqdm_gui

    timestamps = []
    timestamps.append(0)
    timestamps.append(1)
    timestamps.append(2)
    timestamps.append(3)
    timestamps.append(4)
    timestamps.append(5)
    timestamps.append(6)
    timestamps.append(7)
    timestamps.append(8)  # timestamps = [0, 1, 2, 3, 4, 5, 6, 7, 8]
    timestamps = deque(timestamps)  # timestamps = de

# Generated at 2022-06-24 10:16:34.693386
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=100) as pbar:
        pbar.clear()

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:16:37.968379
# Unit test for function tgrange
def test_tgrange():
    # Test on 10000 items
    n = 10000
    with tqdm(total=n) as pbar:
        for k in tgrange(n):
            pbar.update(1)


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:16:42.839031
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui"""
    t = tqdm_gui(100, desc='testing', leave=False)
    for i in _range(100):
        t.update(1)
        t.clear()
 

# Generated at 2022-06-24 10:16:46.079854
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep

    from .gui import tqdm
    for i in tqdm(range(50)):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:16:55.088281
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # import doctest
    # print(doctest.testmod())
    text = 'It will take approx. 5 sec.'

    # build a list of strings
    text = "foobarbaz"  # "A barber is a person. a barber is good person. a barber is huge person. he Knew A Secret! The Secret He Kept, Is The Secret To Life."
    for i in tqdm([_ for _ in range(0, 3700)],
                  unit="foobar",
                  unit_scale=True,
                  miniters=1,
                  mininterval=0.5,
                  desc=text):
        pass
    # test output
    # from .std import TestTqdm
    # TestTqdm(tqdm._instances).assert_empty()



# Generated at 2022-06-24 10:16:58.674891
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-24 10:17:03.563072
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    import time
    t = tqdm_gui(total=10)
    try:
        for i in _range(8):
            time.sleep(0.1)
            t.update()
        t.clear()
    except KeyboardInterrupt:
        t.close()
        sys.exit(1)
    t.close()

# Generated at 2022-06-24 10:17:04.947320
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(3)):
        pass

# Generated at 2022-06-24 10:17:10.946628
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in trange(10):
        sleep(.01)
        trange.clear(cls=tqdm_gui)
        # trange.refresh(cls=tqdm_gui)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:17:20.780403
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Default interactive backend
    try:
        mpl.use('Qt4Agg')
    except Exception:
        pass

    from time import sleep
    total = 10
    for i in tqdm_gui(range(total), desc='Test', unit='it',
                      unit_scale=True, miniters=1, mininterval=0.2,
                      maxinterval=3, maxiter=total):
        sleep(0.5)
    for i in tqdm_gui(range(total), desc='Dynamic bar width',
                      bar_format='{l_bar}{bar}{r_bar}'):
        sleep(0.1)


# Generated at 2022-06-24 10:17:24.342268
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    with tqdm(total=10) as t:
        t.clear()
    with tqdm(total=10) as t:
        sys.stderr.write("\x1b[?25h")  # Show cursor
        t.clear()
test_tqdm_gui_clear()

# Generated at 2022-06-24 10:17:30.068362
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        import matplotlib
    except ImportError:
        matplotlib = False

    if not matplotlib:
        return
    with tqdm(total=1000) as t:
        for i in _range(1000):
            # sleep(0.01)
            t.update()

# Generated at 2022-06-24 10:17:40.776197
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import types
    from collections import deque
    from io import StringIO
    from itertools import count
    from random import random
    from sys import stdout
    from time import sleep

    f = StringIO()
    for r in tqdm_gui(count(), file=f, desc="foo", leave=True,
                      leave_on_ctrl_c=False,
                      miniters=1, mininterval=0,
                      maxinterval=random, maxinterval_gen=lambda: random()):
        sleep(r / 1000)
    s = f.getvalue()
    assert "foo " in s
    assert "\r" not in s
    f.close()

    f = StringIO()

# Generated at 2022-06-24 10:17:49.546479
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .trange import trange
    from .tests import tests

    for t in tests + [{'total': None}]:
        t = dict((k, v) for k, v in t.items() if k != 'dynamic_ncols')
        for bar_format in ['{bar}',  # vanilla, for unit test purposes
                           '{l_bar}{bar:10}{r_bar}'  # padding
                           ]:
            t['bar_format'] = bar_format  # override
            t['gui'] = True  # GUI tqdm
            t['disable'] = False  # disable override
            t['dynamic_ncols'] = False
            tqdm(**t)
            tqdm(**t)  # test repeated
            tqdm(**t)


# Generated at 2022-06-24 10:17:51.813538
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt

    with tqdm(total=100) as t:
        for i in range(10):
            t.update()
            plt.pause(0.1)

# Generated at 2022-06-24 10:17:54.435890
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    t = tqdm(xrange(100))
    t.clear()
    t.start()
    t.update()


if __name__ == '__main__':
    test_tqdm_gui_clear()  # pragma: no cover

# Generated at 2022-06-24 10:17:56.541700
# Unit test for function tgrange
def test_tgrange():
    """Tests tqdm_gui.tgrange"""
    list(tqdm(tgrange(10)))

# Generated at 2022-06-24 10:18:01.647015
# Unit test for function tgrange
def test_tgrange():
    from itertools import islice
    with tgrange(100) as pbar:
        for i in islice(pbar, 0, 50):
            pbar.set_description("Desc: %i" % i)
            pass
        assert pbar.n == 50
        for i in islice(pbar, 50, 100):
            pbar.set_postfix(foo=i)
            pass
        assert pbar.n == 100

# Generated at 2022-06-24 10:18:10.663270
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import matplotlib.axes as maxes
    t = tqdm_gui(total=100)
    assert isinstance(t.fig, plt.Figure)
    assert isinstance(t.ax, maxes.Axes)
    assert isinstance(t.line1, plt.Line2D)
    assert isinstance(t.line2, plt.Line2D)
    assert isinstance(t.hspan, plt.Polygon)
    t.update(1)
    assert len(t.xdata) == 1 and len(t.ydata) == 1 and len(t.zdata) == 1
    t.update(2)
    assert len(t.xdata) == 3 and len(t.ydata) == 3 and len(t.zdata)

# Generated at 2022-06-24 10:18:20.556034
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import six
    import time
    import math
    import pytest
    import matplotlib as mpl
    mpl.use('Agg')  # set backend to Agg to avoid warning
    mpl.rcParams['toolbar'] = 'None'  # disable toolbar so that it doesn't block
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup
    from numpy.testing import assert_array_equal
    from .std import TqdmExperimentalWarning

    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)

    fig = plt.figure()
    axes = fig.add_subplot(111)

    bar = tqdm_gui(total=3, bar_format='{bar}')
    bar.display()


# Generated at 2022-06-24 10:18:30.116743
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    no_show = mpl.rcParams['interactive'] is False

# Generated at 2022-06-24 10:18:38.048169
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import gui
    import time
    t = gui.tqdm(gui._range(3))
    time.sleep(1)
    t.close()
    time.sleep(1)
    t = gui.tqdm(gui._range(3), leave=True)
    time.sleep(1)
    t.close()
    time.sleep(1)
    t = gui.tqdm(gui._range(3), leave=True, position=42)
    time.sleep(1)
    t.close()

if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:18:47.730053
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from time import sleep as real_sleep
    from unittest.mock import patch

    with patch('tqdm.gui.tqdm_gui.get_lock') as get_lock_mock:
        with patch('tqdm.gui.tqdm_gui._time') as _time_mock:
            _time_mock.return_value = 0
            t = tqdm(total=100, smoothing=1)
            _time_mock.return_value = 1
            t.display = real_sleep
            t.display()
            t.close()

            t = tqdm(total=100, smoothing=1)
            t.display = real_sleep
            t.disable = True
            t.close()
            assert not get_lock_mock.called

           

# Generated at 2022-06-24 10:18:48.844618
# Unit test for function tgrange
def test_tgrange():
    x = tgrange(4)
    for _ in x:
        pass

# Generated at 2022-06-24 10:18:52.505633
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=2) as t:
        t.update(1)
        t.clear()
        t.update(1)

# Generated at 2022-06-24 10:18:54.511272
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """
    Passes if no exceptions are raised.
    """
    trange(3)
    trange(3, 5)
    trange(3, 5, 2)

# Generated at 2022-06-24 10:18:59.130092
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .testing import pretest_posttest
    from random import randint
    from time import sleep

    with pretest_posttest() as (pt, pta):
        for i in tgrange(10):
            assert i == pta(i)
            sleep(randint(1, 10) / 100)


if __name__ == "__main__":  # pragma: no cover
    from .main import main

    main()

# Generated at 2022-06-24 10:19:00.914623
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=2) as pbar:
        pbar.display()
        pbar.clear()

# Generated at 2022-06-24 10:19:10.733764
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from nose.tools import (
        assert_raises, assert_greater_equal, assert_is_instance,
        assert_in, assert_equal)

    class TestTqdmGuiDisplay(tqdm_gui):
        _instances = []

        def __init__(self, *args, **kwargs):
            tqdm_gui.__init__(self, *args, **kwargs)
            # init mocks
            self.n = 0
            self.last_print_n = 0
            self.last_print_t = 0
            self._time = lambda: 0.0
            self.start_t = 0.0
            self.total = 0
            self.xdata = []
            self.ydata = []
            self.zdata = []

# Generated at 2022-06-24 10:19:13.226031
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)

# Generated at 2022-06-24 10:19:22.215762
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: nocover
    from time import sleep
    t0 = tqdm_gui(total=100, unit_scale=True, unit="B", miniters=1)
    t = tqdm_gui(total=100, unit_scale=True, unit="B", miniters=1)
    for _ in t:
        sleep(0.01)
    t.close()  # Put the progressbar back to lowest fixed position
    for _ in t0:
        pass
    t0.close()


if __name__ == "__main__":  # pragma: no cover
    # Unit test
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:25.188433
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy.random import random
    for i in tqdm(range(10), total=100):
        sleep(0.02 * random())

# Generated at 2022-06-24 10:19:27.019353
# Unit test for function tgrange
def test_tgrange():
    from .gui import tgrange
    for _ in tgrange(10):
        pass



# Generated at 2022-06-24 10:19:39.351161
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import subprocess
    import sys
    if sys.version_info[0] == 2:
        STR = "<type 'instance'>"
    else:
        STR = "<class 'tqdm_gui._tqdm_gui'>"

    if os.name == 'nt':
        py = 'python'
    else:
        py = 'python3'

    proc = subprocess.Popen([py, '-c', 'from tqdm import tqdm_gui; \
                             from time import sleep; \
                             for i in tqdm_gui(range(5)): sleep(0.1)'],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate()
    # Check if tq

# Generated at 2022-06-24 10:19:44.396101
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pbar = tqdm_gui(total=None, unit='s', unit_scale=False, mininterval=0, miniters=0)
    assert pbar.leave
    pbar = tqdm_gui(total=10, unit='s', unit_scale=False, mininterval=0, miniters=1)
    pbar.close()
    assert not pbar.leave

# Generated at 2022-06-24 10:19:46.203238
# Unit test for function tgrange
def test_tgrange():
    lst = []
    for _ in tgrange(7):
        lst.append(_)
    assert lst == list(range(7))

# Generated at 2022-06-24 10:19:49.221093
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import warnings
    warnings.simplefilter("ignore", TqdmExperimentalWarning)
    t = tqdm_gui(range(0, 1000, 10), leave=True)
    t.close()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:53.190884
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=1, gui=True, leave=True) as pbar:
        pbar.display()
        pbar.clear()


if __name__ == '__main__':
    from time import sleep

    for i in trange(10):
        sleep(1)
    for _ in tqdm(range(10)):
        sleep(1)

# Generated at 2022-06-24 10:20:03.821511
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import io

    with io.open("close.txt", "wb") as f_out:
        i = tqdm_gui(iterable=f_out, total=1000,
                     bar_format="{postfix} {n:.0f}/{total:.0f} {bar}",
                     gui=True, leave=False)
        for j in range(1000):
            i.update(1)
        i.close()

    try:
        import matplotlib as mpl
        mpl.rcParams['toolbar'] = 'toolmanager'
    except ImportError:
        pass


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:20:10.705630
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib import pyplot as plt
    from sys import version_info
    if version_info[0] == 2:
        from mock import Mock
    else:  # pragma: py3
        from unittest.mock import Mock
    
    # Mock matplotlib
    plt.close = Mock()
    plt.isinteractive = Mock(return_value=False)
    plt.ioff = Mock()
    mpl = Mock()
    gui = tqdm_gui(total=0, disable=False, gui=True)
    gui.mpl = mpl
    gui.plt = plt
    gui._instances = [gui]
    gui.disable = False
    gui.wasion = False
    gui.toolbar = False
    gui.leave = False
    gui.close()
   

# Generated at 2022-06-24 10:20:19.722724
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import sys
    # remember previous interactive mode
    prev_interactive = plt.isinteractive()

# Generated at 2022-06-24 10:20:25.264809
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import _tqdm_gui_instances_list
    from .std import tqdm_gui
    tqdm_gui(range(10)).close()
    assert _tqdm_gui_instances_list() == []
    tqdm_gui(range(10)).display().close()
    assert _tqdm_gui_instances_list() == []


# Generated at 2022-06-24 10:20:30.179946
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot
    from tempfile import mktemp

    i = 0
    with tqdm(unit="i", unit_scale=True, miniters=1, mininterval=0.5) as t:
        for _ in t:
            t.display()
            i += 1
            if i >= 10000:
                break


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:20:38.250403
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import time
    import numpy
    # Display should accept and ignore all arguments to
    # be compatible with future versions of tqdm
    # (in case new non-keyword arguments are added)
    total = 5
    out = tqdm_gui(total=total, leave=True, ascii=True, file=sys.stdout,
                   dynamic_ncols=True, gui=True)
    for _ in out:
        time.sleep(1)
        out.display()

    time.sleep(0.5)
    for _ in tqdm_gui(total=total, leave=True, dyn_ncols=True, gui=True):
        time.sleep(0.3)

    time.sleep(0.5)

# Generated at 2022-06-24 10:20:41.114241
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for method close of class tqdm_gui"""
    from time import sleep
    from numpy import random

    try:
        t = tqdm_gui(range(50))
        for i in t:
            sleep(random.random() / 50)
    except KeyboardInterrupt:
        t.close()
        print("\nClosed...\n")
    t.close()


# Generated at 2022-06-24 10:20:44.675471
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    try:
        for i in tqdm_gui(range(10)):
            sleep(0.05)
    except Exception:
        pass


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:20:48.395396
# Unit test for function tgrange
def test_tgrange():
    with tgrange(10) as t:
        for i in t:  # pragma: no cover
            pass


if __name__ == "__main__":  # pragma: no cover
    # self test
    test_tgrange()

# Generated at 2022-06-24 10:20:50.601819
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_raises
    assert_raises(NotImplementedError, tqdm_gui.clear, tqdm_gui())

# Generated at 2022-06-24 10:20:59.564466
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui

    :func:`test_tqdm_gui_clear` is called automatically
    if :envvar:`UNITTEST` is set to ``True``.

    This test does not guarantee that the method clear works
    flawlessly. However, it should catch the most obvious
    mistakes that may lead to segfaults.

    Note that this unit test depends on the environment variable
    ``$DISPLAY`` for the proper functioning of PyPlot."""
    assert isinstance(tqdm_gui(total=10), tqdm_gui)
    assert isinstance(tqdm_gui(total=10).close(), NoneType)

if __name__ == "__main__":
    from os import environ
    if "UNITTEST" in environ:
        test_tqdm_

# Generated at 2022-06-24 10:21:06.808019
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    from matplotlib import pyplot as plt

    with tqdm(total=100) as pbar:
        for i in _range(10):
            pbar.update(10)
            time.sleep(0.1)
    # To check for the randomness of the order of the examples
    plt.pause(0.1)
    time.sleep(1)
    try:
        plt.show()
    except TypeError:
        # required in some versions of matplotlib
        plt.show(block=True)

# Generated at 2022-06-24 10:21:17.098359
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    import sys
    import os
    if sys.version_info >= (3,):
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    from .utils import _supports_unicode
    pbar = tqdm_gui(total=10)
    for i in pbar:
        time.sleep(0.1)
        pbar.set_description("Test " + "description string"[i % 4::4])
        pbar.set_postfix(ordered_dict={"postfix key": "postfix value"})
    pbar.close()

    # Test default bar_format
    pbar = tqdm_gui(total=10)
    pbar.close()

    # Test with nested loops

# Generated at 2022-06-24 10:21:29.166707
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm as std_tqdm

    class tqdm_gui4test(tqdm_gui):
        def __init__(self, *args, **kwargs):
            super(tqdm_gui4test, self).__init__(*args, **kwargs)
            self.n = 0
            self.last_print_n = 0
            self.last_print_t = 0
            self.start_t = 0
            self.disable = False
            self.xdata = []
            self.ydata = []
            self.zdata = []
        def _get_eta(self, **_):
            return std_tqdm._get_eta(self, **_)

    # Test with total

# Generated at 2022-06-24 10:21:38.193002
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test the method close of tqdm_gui class.

    """
    # Create some tests variables
    iterable = xrange(10)
    total = len(iterable)
    miniters = total / 5
    mininterval = 0.5
    maxinterval = 10
    lock = False
    disable = False
    dynamic_ncols = False
    unit = 'it'
    unit_scale = False
    leave = False
    gui = True
    color = 'g'
    smoothing = 0.1
    bar_format = None
    ascii = False
    postfix = None
    ncols = None
    mininterval = mininterval
    maxinterval = maxinterval
    miniters = miniters
    dynamic_ncols = dynamic_ncols
    asci

# Generated at 2022-06-24 10:21:41.334043
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """test_tqdm_gui_clear"""
    with tqdm(total=30, desc='Test clear: ', gui=True) as t:
        for i in range(5):
            t.clear()
            t.update(5)



# Generated at 2022-06-24 10:21:43.422887
# Unit test for function tgrange
def test_tgrange():
    with tqdm_gui(total=100) as t:
        for i in tgrange(100):
            t.update()

# Generated at 2022-06-24 10:21:48.497944
# Unit test for function tgrange
def test_tgrange():
    import time
    n_iter = 5
    duration = 0.1
    with tgrange(n_iter, desc="dummy", unit="s", mininterval=0) as xbar:
        for i in xbar:
            time.sleep(duration)
        assert i == (n_iter - 1)



# Generated at 2022-06-24 10:21:50.848099
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    t = tqdm_gui(range(10), desc='testing GUI', file=sys.stderr)
    for i in t:
        pass
    return t

# Generated at 2022-06-24 10:22:00.310724
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib
    matplotlib.use('Agg')  # avoid the need to install GUI backend
    import matplotlib.pyplot as plt

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.xaxis.set_visible(False)
    ax.yaxis.set_visible(False)
    ax.set_frame_on(False)
    fig.patch.set_alpha(0.0)

    g = tqdm_gui(total=1000, disable=False, unit='it')
    g.last_print_t = g.start_t - 2 * g.mininterval
    g.xdata = [0, 1, 2]
    g.ydata = [1, 1, 1]
    g.zdata = [1, 1, 1]
   

# Generated at 2022-06-24 10:22:10.732235
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pass


if __name__ == "__main__":
    import time
    import sys

    # Unbuffered output
    # https://stackoverflow.com/questions/107705/disable-output-buffering
    class Unbuffered(object):
        def __init__(self, stream):
            self.stream = stream

        def write(self, data):
            self.stream.write(data)
            self.stream.flush()

        def __getattr__(self, attr):
            return getattr(self.stream, attr)

    sys.stdout = Unbuffered(sys.stdout)
    sys.stderr = Unbuffered(sys.stderr)

    with trange(10) as bar:
        for _ in bar:
            bar.write("hello")

# Generated at 2022-06-24 10:22:14.336354
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=0) as t:
        t.close()
    tqdm_gui(total=0, leave=True).close()
    tqdm_gui(total=0, leave=False).close()
    tqdm_gui(total=0, disable=True)

# Generated at 2022-06-24 10:22:21.126488
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import sys
    import time
    from io import StringIO
    from subprocess import Popen, PIPE, STDOUT

    # Test that a non-valid `self.*` is created
    if not sys.platform.startswith('win'):
        p = Popen(["python2 -m tqdm"], stdout=PIPE, stderr=STDOUT, shell=True)
        out, err = p.communicate()
        out = out.decode('utf-8')
        assert not out

    # Test that it works
    out = StringIO()
    t = tqdm_gui(range(5), file=out, unit='foo', dynamic_ncols=True)
    time.sleep(1)
    t.close()
    assert out.getvalue() == ''

    #

# Generated at 2022-06-24 10:22:32.391482
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        # explicit code for python2
        from StringIO import StringIO
    except ImportError:
        # python3 already has the function in the main namespace
        from io import StringIO
    import sys
    from contextlib import redirect_stdout, redirect_stderr

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()
