

# Generated at 2022-06-24 10:12:40.738402
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import platform
    from .std import tqdm_gui

    def is_mac_os():
        return platform.system().startswith("Darwin")

    def is_windows():
        return platform.system() == "Windows"

    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        # Matplotlib is already imported and the interactive mode is activated
        plt.ion()
    except ImportError:
        # Matplotlib is not installed
        mpl = None
        plt = None

    get_name = lambda obj: obj.__name__
    assert get_name(tqdm_gui) == "tqdm_gui"

    # Using only an iterator

# Generated at 2022-06-24 10:12:44.514593
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=3) as pbar:
        assert pbar.total == 3
        for _ in range(3):
            pbar.update()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()  # pragma: no cover

# Generated at 2022-06-24 10:12:56.418887
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from matplotlib import pyplot as plt
    # No toolbar
    plt.rcParams['toolbar'] = 'None'
    # No interactive (blocking)
    plt.ioff()

    # Initial toolbars
    toolbar = plt.rcParams['toolbar']
    # Initial interactive
    wasion = plt.isinteractive()

    # Initialize a tqdm_gui and check if it is instantiated
    tq = tqdm_gui(["a", "list"], total=2)
    assert tq in tq._instances

    # Close tqdm_gui and check if it is closed
    tq.close()
    assert tq not in tq._instances

    # Check restored toolbar
    assert plt.rcParams['toolbar'] == toolbar

    #

# Generated at 2022-06-24 10:13:00.240736
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    l = list(tgrange(10))
    assert l == list(_range(10))
    sleep(2)


# Generated at 2022-06-24 10:13:05.285714
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # pylint: disable=unused-argument
    t = tqdm_gui(['a', 'b'])
    t.clear()
    t.close()
    # pylint: enable=unused-argument

# Generated at 2022-06-24 10:13:13.603331
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import time
    # import tqdm_gui
    import matplotlib.pyplot as plt
    plt.ion()
    fig, ax = plt.subplots(figsize=(12, 4))
    ax.set_ylim(0, 1)
    ax.set_xlim(0, 60)
    ax.invert_xaxis()
    ax.set_xlabel("seconds")
    ax.legend(("cur", "est"), loc='lower left')
    ax.grid()
    ax.set_ylabel("seconds")
    # ax.set_xlabel('seconds')
    ax.set_ylabel("seconds/s")
    t = tqdm_gui(total=60, smoothing=0, leave=True, gui=True)

# Generated at 2022-06-24 10:13:24.379821
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for _ in _range(5):
            pbar.clear()
    return True


if __name__ == '__main__':
    from time import sleep
    for i in tqdm_gui(total=100, desc="1st loop"):
        for j in tqdm_gui(total=100, desc="2nd loop", leave=False):
            for k in tqdm_gui(total=100, desc="3rd loop", leave=False,
                              mininterval=0.001):
                sleep(0.0001)
    assert test_tqdm_gui_clear()

# Generated at 2022-06-24 10:13:36.057182
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .std import trange
    import time
    import matplotlib.pyplot as plt

    for i in trange(10):
        time.sleep(0.01)
    with trange(10) as t:
        for i in t:
            time.sleep(0.01)
    a = trange(5, desc="1st loop")
    b = trange(100, desc="2nd loop")

# Generated at 2022-06-24 10:13:39.219988
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10, miniters=2) as t:
        for i in range(10):
            t.update()
            import time; time.sleep(0.01)

# Generated at 2022-06-24 10:13:41.105277
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    i = 0
    for _ in tgrange(3, leave=True):
        i += 1
    assert i == 3

# Generated at 2022-06-24 10:13:52.765621
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from sys import stdout
    import matplotlib.pyplot as plt
    # initialise
    with tqdm(total=7, desc="constructor", unit="units", disable=False,
              miniters=1, mininterval=0.5, ascii=False, file=stdout, ncols=70) as t:
        for i in range(7):
            t.update(1)
            assert t.n == i + 1
            assert len(t) == 7
            assert t.total == 7
        t.clear()  # clear line
        assert len(t.format_dict) != 0  # check format_dict
        t.close()  # disable
        assert t.disable  # __bool__
        t.display()  # display
        assert t.dynamic_ncols  # dynamic

# Generated at 2022-06-24 10:13:54.759452
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    for _ in tqdm_gui(5):
        pass


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:58.557521
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Unit test for method clear of class tqdm_gui"""
    t = tqdm_gui(total=10)
    t.update(1)
    t.update(2)
    t.update(3)
    t.clear()

# Generated at 2022-06-24 10:14:09.980144
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    import sys
    # Redirect stdout to a buffer to capture output
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    # Unit test for method clear of class tqdm_gui
    for i in tqdm_gui(range(20), smoothing=0, ncols=50, ascii=False,
                      bar_format="{suffix[0]} {percentage:3.0f}%|"):
        pass
    # Reset stdout to normal and print captured output
    sys.stdout = old_stdout
    with open('temp.txt', 'w') as f:
        f.write(mystdout.getvalue())

# Generated at 2022-06-24 10:14:19.738674
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Tests that the display method of `tqdm_gui` works properly."""
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Patching to avoid matplotlib warnings

# Generated at 2022-06-24 10:14:23.723620
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from .std import TqdmExperimentalWarning

    with tqdm_gui(1, ascii=True, dynamic_ncols=True) as t:
        for i in range(4):
            t.write(' ' * i * 4 + 'Hello World!')
            t.update()

        # set toolbar
        toolbar = plt.rcParams['toolbar']
        # set matplotlib mode
        wasion = plt.isinteractive()

        t.close()

        # test if python did return to initial matplotlib mode
        if wasion != plt.isinteractive():
            raise AssertionError()

        # test if python did restore initial toolbar
        if toolbar != plt.rcParams['toolbar']:
            raise AssertionError()

       

# Generated at 2022-06-24 10:14:27.409327
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    t = tqdm_gui(range(10))
    t.start()
    for _ in t:
        t.display()
    t.close()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:34.172213
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Unit test for method display of class tqdm_gui"""
    with open(__file__) as f:
        rng = f.readlines()
    t = tqdm_gui(ascii=True)
    for _ in rng[::-1]:
        t.update(1)

# Generated at 2022-06-24 10:14:38.767235
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(unit='cells') as t:
        for i in range(50):
            t.update()
            t.update_interval_header()
            t.display()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:48.043551
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from matplotlib import pyplot as plt
    t = trange(100, desc='1st loop')
    for i in t:
        sleep(0.01)
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == t.last_print_n
    t.close()

    t = trange(100, desc='2nd loop', leave=True)
    for i in t:
        sleep(0.01)
    assert len(t.xdata) == len(t.ydata) == len(t.zdata) == t.last_print_n
    t.close()
    plt.show()


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:14:59.503725
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy
    # import pytest

    mpl.use(u'TkAgg')
    wasion = plt.isinteractive()
    plt.ion()
    ax = plt.gca()

    xdata = [0]
    ydata = [0]
    zdata = [0]
    n = numpy.random.random()
    cur_t = n
    start_t = n
    last_print_n = n
    last_print_t = n
    total = None
    elapsed = n
    delta_it = n
    delta_t = n
    # unit = n
    # unit_scale = n
    # dynamic_ncols = n
    # format_dict = n

    total

# Generated at 2022-06-24 10:15:01.882548
# Unit test for function tgrange
def test_tgrange():
    import time
    for i in tqdm(tgrange(1000), unit="f"):
        time.sleep(1e-4)

# Generated at 2022-06-24 10:15:09.155359
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import sys
    import matplotlib as mpl

    __saved_interactive = mpl.is_interactive()
    for backend in ['Qt4Agg', 'Qt5Agg', 'TkAgg', 'WXAgg']:
        if backend in mpl.rcsetup.interactive_bk:
            mpl.use(backend, warn=False)
            break
    else:
        # Fallback to Agg
        mpl.use('Agg', warn=False)


# Generated at 2022-06-24 10:15:18.954519
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    # check that ``range`` is used on python 3
    # with tqdm(range(10)) as t:
    #     for i in t:
    #         pass
    #     assert type(t.range) is range
    for _ in tqdm(range(1000)):
        pass


try:
    from matplotlib import pyplot as plt

    for _ in tqdm_gui(range(1000)):
        pass

except ImportError as e:
    tqdm_gui = None
    tgrange = None
    trange = None
    tqdm = std_tqdm
    warn("tqdm.gui requires matplotlib, skipped", ImportWarning,
         stacklevel=2)
except Exception as e:
    tqdm_gui = None
    tgr

# Generated at 2022-06-24 10:15:31.645705
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui(): 
    import time
    import matplotlib.pyplot as plt

    with tqdm_gui(total=19, unit='B',
                  unit_scale=True, unit_divisor=1024, leave=False) as pbar:
        for i in range(20):
            pbar.update(1)
            time.sleep(0.01)

        if hasattr(pbar, 'hspan'):
            poly_lims = pbar.hspan.get_xy()
            poly_lims[0, 1] = 0
            poly_lims[1, 1] = 1
            poly_lims[2] = [20.0 / 19, 1]
            poly_lims[3] = [poly_lims[2, 0], 0]

# Generated at 2022-06-24 10:15:43.136300
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for the constructor of class tqdm_gui
    """
    try:
        from collections import deque
    except ImportError:  # pragma: no cover
        # python 2
        def deque(maxlen=None):
            return []
        deque.popleft = list.pop
        deque.append = list.append

    # import matplotlib as mpl
    # import matplotlib.pyplot as plt
    # kwargs = kwargs.copy()
    # kwargs['gui'] = True
    # colour = kwargs.pop('colour', 'g')
    #
    # self.mpl = mpl
    # self.plt = plt

    # Remember if external environment uses toolbars
    # self.toolbar = self.m

# Generated at 2022-06-24 10:15:53.101484
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase
    from .gui import tqdm
    from .gui import trange

    class _Test_display(TestCase):
        def tearDown(self):
            try:
                self.pbar.close()
            except AttributeError:
                pass

        def test_format(self):
            self.pbar = tqdm(total=None)
            self.pbar.display(0)
            self.pbar.display(0)
            self.pbar.close()
            # with file output
            with open(__file__, 'rb') as fobj:
                fpbar = tqdm(fobj, total=None, leave=True)
                fpbar.display(0)
                fpbar.display(0)

        def test_update(self):
            self.p

# Generated at 2022-06-24 10:15:57.118940
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with trange(4) as t:
        for i in t:
            pass
    with trange(4, leave=False) as t:
        for i in t:
            pass


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:59.203076
# Unit test for function tgrange
def test_tgrange():
    with tqdm_gui(total=123) as t:
        for i in tgrange(total=123):
            t.update()

# Generated at 2022-06-24 10:16:05.829060
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    t = tqdm_gui([1,2,3])
    t.update()
    sleep(1)
    toolbar_before = mpl.rcParams['toolbar']
    plt.ioff()
    wasion_before = plt.isinteractive()
    t.close()
    toolbar_after = mpl.rcParams['toolbar']
    wasion_after = plt.isinteractive()
    assert toolbar_after == toolbar_before
    assert wasion_after == wasion_before

# Generated at 2022-06-24 10:16:16.111914
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    mpl = plt
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    total = 100
    xdata = []
    ydata = []
    zdata = []
    line1, = ax.plot(xdata, ydata, color='b')
    line2, = ax.plot(xdata, zdata, color='k')
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")
    fig.legend((line1, line2), ("cur", "est"),
               loc='center right')
    # progressbar

# Generated at 2022-06-24 10:16:17.687236
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    with tqdm_gui(total=100) as t:
        for i in range(10):
            # Update the progress bar
            t.update(i)
    plt.close('all')



# Generated at 2022-06-24 10:16:19.118569
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import time
    from tqdm.gui import trange

    for i in trange(10, smoothing=1):
        time.sleep(0.25)
        print(i)

# Generated at 2022-06-24 10:16:28.330411
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .gui.utils import binit, bexit
    from .gui.tqdm import tqdm

    if std_tqdm._instances:
        raise Exception("tqdm instances are not empty!")
    with binit():
        with tqdm(total=10) as t:
            for i in range(10):
                t.update()
        assert t._instances == []
        with tqdm(total=10) as t:
            for i in range(10):
                t.update()
        assert t._instances == []
    with bexit():
        pass


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:38.499439
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy.testing import assert_almost_equal  # type: ignore

    t = tqdm_gui(total=100, miniters=50, mininterval=0.5, leave=False)
    sleep(.1)
    assert_almost_equal(t.n + t.delta_it, t.last_print_n + t.last_print_delta_it)
    assert t.n == t.last_print_n
    assert t.last_print_delta_it == t.delta_it
    sleep(.1)
    t.display()
    sleep(.1)
    assert_almost_equal(t.n + t.delta_it, t.last_print_n + t.last_print_delta_it)

# Generated at 2022-06-24 10:16:48.782159
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array_equal, round

    t = tqdm_gui(range(10), leave=True, mininterval=0.1)
    for x in t:
        sleep(0.01)
    t.close()

    xdata = t.xdata
    ydata = t.ydata
    zdata = t.zdata
    assert round(xdata[-1]) == 100
    assert round(ydata[-1]) == round(zdata[-1])
    assert array_equal(xdata, zdata)
    assert not array_equal(xdata, ydata)


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in trange(50):
        sleep(0.1)
    test_tq

# Generated at 2022-06-24 10:17:00.813516
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import io
    import sys
    import time

    # py3 compat
    try:
        _range = xrange
    except NameError:
        _range = range

    # Make a pseudorandom widget
    with io.StringIO() as our_file:
        for _ in tqdm_gui(_range(100), file=our_file):
            time.sleep(0.01)

    # Test that the widget is cleared
        for _ in tqdm_gui(_range(10), file=our_file):
            our_file.truncate(0)
            our_file.seek(0)
            sys.stdout.flush()

        our_file.truncate(0)
        our_file.seek(0)
        sys.stdout.flush()

    # Check that file is

# Generated at 2022-06-24 10:17:12.123015
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm
    import sys
    import os
    import time

    class Stream(object):
        """
        Fake output stream for unit testing.
        """
        _data = None

        @property
        def data(self):
            """
            Returns the stream data
            """
            return self._data

        def __init__(self, data=None):
            """
            Create the stream with the given data if provided.
            """
            if data is None:
                data = []
            self._data = data

        def write(self, s):
            """
            Fake the write method.
            """
            self.data.append(s)

        def flush(self):
            """
            Fake the flush method.
            """
            return True

    with Stream() as stream:
        sys.stdout = stream

# Generated at 2022-06-24 10:17:17.871070
# Unit test for function tgrange
def test_tgrange():
    """
    Tests trange in a simple way.
    """
    from .utils import format_interval
    import time
    with tgrange(4) as t:
        for i in t:
            t.set_description('GEN %i' % i)
            time.sleep(0.5)
        t.set_description('DONE in %s' % format_interval(t.elapsed))
        time.sleep(0.5)

# Generated at 2022-06-24 10:17:19.132609
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(10), gui=True):
        tqdm_gui.clear()

# Generated at 2022-06-24 10:17:27.278126
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with suppress_stdout():
        from matplotlib import pyplot as plt
        # from .tests_tqdm import StringIO, closing, nested
        from .tests_tqdm import closing, nested
        from .gui import tqdm_gui

        orig = plt.isinteractive()
        if orig:
            plt.ioff()


# Generated at 2022-06-24 10:17:34.875736
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    # Test with example
    for _ in tgrange(10):
        pass
    # Test with list
    for _ in tgrange([10]):
        pass
    # Test with numpy array
    try:
        import numpy as np
    except ImportError:
        pass
    else:
        for _ in tgrange(np.arange([10])):
            pass
    # Test with range
    for _ in tgrange(xrange(10)):
        pass

# Generated at 2022-06-24 10:17:36.040599
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(3)):
        tqdm.clear()

# Generated at 2022-06-24 10:17:45.281639
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    from .std import tqdm
    from .std import TqdmKeyError

    if sys.version_info < (3,):
        xrange = xrange
    else:
        xrange = range

    with tqdm(xrange(10), gui=True) as t:
        for i in t:
            if i > 5:
                t.close()
                break
    with tqdm(gui=True) as t:
        raise Exception("Should not raise")
    with tqdm(gui=True) as t:
        t.disable = True
        raise Exception("Should not raise")
    with tqdm(gui=True) as t:
        _t = t
        _t.disable = True
        raise Exception("Should not raise")

# Generated at 2022-06-24 10:17:55.241205
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test: Ensure that the display method behaves similarly to the GUI version"""
    # assert tqdm_gui is a subclass of tqdm
    assert issubclass(tqdm_gui, std_tqdm)
    # instantiate tqdm_gui and tqdm with the same arguments
    tw = tqdm_gui(range(10), desc="foo", bar_format="{l_bar}{bar}{r_bar}")
    to = std_tqdm(range(10), desc="foo", bar_format="{l_bar}{bar}{r_bar}")
    # assert both instances have the same attributes
    assert tw.desc == to.desc
    assert tw.bar_format == to.bar_format
    # assert tqdm_gui behaves similarly to tqdm
    tw.display(0)
    to.display

# Generated at 2022-06-24 10:17:57.348075
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Tests GUI display method."""
    d = tqdm_gui(range(1000), leave=False, async_=False)
    while d.n <= d.total:
        d.update()

# Generated at 2022-06-24 10:18:03.094049
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    # from time import sleep
    for i in tqdm_gui(range(10)):
        # sleep(0.01)
        pass
    try:
        print(plt.close())
    except TypeError:
        pass
    else:
        raise TypeError("tqdm_gui not working as expected")

# Generated at 2022-06-24 10:18:11.857569
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    import fake_rpi, matplotlib
    try:
        matplotlib.use('Agg')
    except:
        pass
    finally:
        import matplotlib.pyplot as plt
    # matplotlib.use('Agg')
    # import matplotlib.pyplot as plt
    from time import sleep, time
    # t = tqdm_gui(total=10)

    fig, ax = plt.subplots()
    xdata = []
    ydata = []
    line1, = ax.plot(xdata, ydata)
    # ax.set_xlim(0, 100)
    # ax.set_ylim(0, 5)

    xmin = 0
    xmax = 100
    ymin

# Generated at 2022-06-24 10:18:17.737625
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np

    from .gui import tqdm_gui

    x = np.linspace(0, 2*np.pi, 100)
    y = np.sin(x)
    z = np.sin(x + 0.1)
    with tqdm_gui(total=len(x)) as pb:
        for i in range(len(x)):
            pb.update(1)
            pb.display(x[i], y[i], z[i])

# Generated at 2022-06-24 10:18:22.342764
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(sys, 'stderr', sys.stdout):
        for _ in trange(3):
            pass
        for _ in tgrange(3):
            pass

# Generated at 2022-06-24 10:18:32.041408
# Unit test for function tgrange
def test_tgrange():
    from .std import TemporaryFile, text_type
    from .utils import format_sizeof
    # Random inputs
    for total in [None, 1000, 1118, 94, 6, 7, 4, 1]:
        if total is not None:
            print(total, "loops")
        else:
            print("infinite", "loops")
        lst = []

        # Test 1: simple iteration
        with trange(total) as t:
            for i in t:
                lst.append(i)
        assert len(lst) == total
        lst = []

        # Test 2: iterator/generator function
        def gen(total):
            for i in tqdm(
                    _range(total), total=total, mininterval=0.1,
                    leave=True):
                yield i

# Generated at 2022-06-24 10:18:36.256144
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for _ in tqdm(range(100), desc="clear test", leave=False):
        sleep(1e-4)
        if _ % 3 == 0:
            tqdm.clear()


if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:18:44.082445
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        tqdm_gui().close()
    except AttributeError as e:
        assert "has no attribute 'close'" in str(e), "close()"
    try:
        tqdm_gui().display()
    except AttributeError as e:
        assert "has no attribute 'display'" in str(e), "display()"
    t = tqdm_gui()
    try:
        t.clear()
    except Exception as e:
        t.close()
        assert False, e.__class__.__name__
    t.close()


# Generated at 2022-06-24 10:18:50.395026
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _supports_unicode
    from .std import TqdmDeprecationWarning, TqdmExperimentalWarning

    # check if warnings are raised
    with warnings.catch_warnings(record=True) as ws:
        with tqdm_gui(total=10) as t:
            assert len(ws) == 1
            assert issubclass(ws[-1].category, TqdmExperimentalWarning)
            assert "GUI" in str(ws[-1].message)

        with tqdm_gui(
            total=10, desc=str("test"), file=sys.stderr, leave=True
        ) as t:
            assert len(ws) == 2
            assert issubclass(ws[-1].category, TqdmDeprecationWarning)

# Generated at 2022-06-24 10:18:58.036251
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    t = tqdm_gui(total=100)
    t.display(1)
    t.display(50)
    t.display(63)
    t.display(1)
    t.display(50)
    t.display(63)
    t.display(99)
    t.clear(1)
    t.display(99)
    t.display(99)
    t.display(99)
    t.display(99)
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:19:00.223754
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 10:19:09.905092
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    mpl.backend_bases.FigureCanvasBase = lambda x: x
    mpl.backends.backend_agg.FigureCanvasAgg = lambda x: x
    from matplotlib.figure import Figure
    from matplotlib.axes import Axes
    from mpl_toolkits.axes_grid1.axes_divider import make_axes_locatable
    from mpl_toolkits.axes_grid1.axes_size import Fixed
    from matplotlib.artist import Artist

    class FakeFigure(object):
        def __init__(self):
            self.canvas = list()
            self.axes = list()
            self.artists = list()
            self.texts = list()
            self.images = list()
            self.lines

# Generated at 2022-06-24 10:19:11.333719
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    t = tqdm_gui()
    t.close()


# Generated at 2022-06-24 10:19:22.171511
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep, time

    pgb = tqdm_gui(total=3)
    pgb.start()
    sleep(0.5)
    pgb.update()
    sleep(0.5)
    pgb.update()
    sleep(0.5)
    pgb.update()
    pgb.close()

    for _ in pgb:
        pass

    with pgb:
        sleep(0.5)
        pgb.update()
        sleep(0.5)
        pgb.update()
        sleep(0.5)
        pgb.update()

    pgb = tqdm_gui(total=3, leave=False)
    pgb.close()

    with pgb:
        sleep(0.5)
        pgb.update()
        sleep(0.5)


# Generated at 2022-06-24 10:19:26.361145
# Unit test for function tgrange
def test_tgrange():
    try:
        tgrange(1)
        tgrange(2, 3)
    except:
        raise Exception("tgrange test failed")

if __name__ == '__main__':
    import atexit
    atexit.register(test_tgrange)

# Generated at 2022-06-24 10:19:30.817523
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(total=None, leave=False)
    _t1 = t._time()
    t.start_t = _t1 - 10
    t.last_print_t = _t1
    for i in tqdm_gui(range(5), leave=False):
        _t2 = t._time()
        yield _t2 - _t1 - i
        _t1 = _t2

# Generated at 2022-06-24 10:19:32.585161
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    list(tqdm([]))


# Generated at 2022-06-24 10:19:43.782724
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import numpy as np
    from .std import TqdmExperimentalWarning
    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    from matplotlib import pyplot as plt
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_ylim(0, 0.0001)
    ax.set_xlim(0, 10)
    from matplotlib.patches import Rectangle
    hspan = Rectangle((0, 0), 0, 0, facecolor='g')
    hspan.set_xy([[0, 0],
                  [0, ax.get_ylim()[1]],
                  [0, ax.get_ylim()[1]],
                  [0, 0]])
    ax

# Generated at 2022-06-24 10:19:51.482052
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from io import StringIO
    from platform import system
    from unittest import main
    from .tests import _TestGuiClear

    @tqdm_gui.write
    def iterable():
        for char in "1234567890":
            if system() == 'Windows':
                import time
                time.sleep(0.05)
            yield char

    it = iterable()
    with StringIO() as our_file:
        it.set_file(our_file)
        next(it)
        assert our_file.getvalue() == "1", (
            our_file.getvalue())
        it.clear()
        assert our_file.getvalue() == "", (
            our_file.getvalue())
        next(it)

# Generated at 2022-06-24 10:20:03.061353
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import matplotlib.pyplot as plt
    from multiprocessing import Pool

    # Force interactive mode
    plt.ion()

    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']

    # Forcing non-interactive mode
    plt.ioff()
    # Check that we do not get any error
    std_tqdm(total=10, gui=True).close()
    # Check that we do not get any error
    std_tqdm(total=10, gui=True, leave=True).close()

    # Check leave=True without progress
    plt.close('all')
    with std_tqdm(total=10, gui=True, leave=True) as t:
        t.update(10)

# Generated at 2022-06-24 10:20:06.328065
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .tests.gui import test_wrap_tqdm
    test_wrap_tqdm(tqdm_gui)



# Generated at 2022-06-24 10:20:15.694113
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    from sys import version_info

    rcParams['toolbar'] = 'None'
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    """Experimental Matplotlib GUI version of tqdm!"""
    # TODO: @classmethod: write() on GUI?
    assert rcParams['toolbar'] == 'None'
    ax.grid()
    ax.set_xlabel('seconds')
    ax.set_ylabel('it/s')
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

# Generated at 2022-06-24 10:20:25.113010
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Unit test for tqdm_gui"""
    try:
        import matplotlib as mpl
        mpl.use('TkAgg')
        # import matplotlib.pyplot as plt
        import sys
        if sys.version_info < (3, 0, 0):
            range_ = xrange
        else:
            range_ = range
    except ImportError:
        return

    # with trange(10) as t:
    #     for i in t:
    #         t.set_description('Gen %i' % i)
    tot = 1e5

# Generated at 2022-06-24 10:20:27.218022
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    t = tqdm_gui(total=100, disable=False)
    t.disable = True
    t.close()

# Generated at 2022-06-24 10:20:33.665913
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib
    matplotlib.use('TkAgg')
    from tqdm.gui import tqdm_gui
    from tqdm.gui import tgrange
    from tqdm.gui import tqdm
    from tqdm.gui import trange
    from tqdm.autonotebook import trange
    import time

    # Test tqdm_gui
    with tqdm_gui(total=9, smoothing=1) as pbar:
        time.sleep(0.25)
        pbar.n = 1
        time.sleep(0.25)
        pbar.n = 2
        time.sleep(0.25)
        pbar.n = 3
        time.sleep(0.25)
        pbar.n = 4
        time.sleep

# Generated at 2022-06-24 10:20:35.152045
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    trange(1).close()

# Generated at 2022-06-24 10:20:40.173556
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """run function and check known outputs"""
    import matplotlib as mpl
    for _i in tgrange(15):
        try:
            mpl.use("Qt4Agg")
        except ImportError:
            pass
        else:
            break
        try:
            mpl.use("Agg")
        except ImportError:
            pass
        else:
            break
    from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
    for _i in tgrange(15):
        try:
            FigureCanvas
        except NameError:
            pass
        else:
            break

# Generated at 2022-06-24 10:20:41.747988
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    pass


# Generated at 2022-06-24 10:20:51.601308
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    from random import randrange
    from random import gauss
    from time import sleep

    cur_t = tqdm.last_print_t = 0
    n = tqdm.n = 1
    tqdm.last_print_n = 0
    tqdm.total = 10
    tqdm.xdata = deque()
    tqdm.ydata = deque()
    tqdm.zdata = deque()
    tqdm.ax = None
    tqdm.plt = None
    tqdm.hspan = None
    tqdm.line1 = None
    tqdm.line2 = None
    tqdm.fig = None

    def _time():
        return cur_t

    def _sleep(t):
        nonlocal cur_t
       

# Generated at 2022-06-24 10:20:56.886304
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from numpy import linspace
    t = tqdm_gui(total=100)
    for i in linspace(0, 1):
        sleep(1)
        t.update()
        t.refresh()
        sleep(1)
        t.update()
    sleep(2)
    t.close()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:21:05.141308
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        fig, ax = plt.subplots(figsize=(9, 2.2))
        plt.ion()
        plt.pause(0.01)
        progressbar = tqdm_gui("bar", total=4, file=open("/dev/null", 'w'))
        progressbar.close()
        assert not progressbar._instances
        plt.ioff()
        plt.pause(0.01)
        assert ax.get_visible()
        plt.close(fig)
    except:
        plt.ioff()
        plt.close(fig)
        raise



# Generated at 2022-06-24 10:21:15.674677
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    import matplotlib
    import matplotlib.pyplot as plt

    pbar = tqdm_gui(total=100, dynamic_ncols=True)
    # pbar.logger.propagate = False
    pbar.logger.setLevel("INFO")
    pbar.logger.addHandler(matplotlib.backends.backend_pdf.PdfPages("debug.pdf"))

    pbar.start()
    try:
        for i in xrange(10):
            pbar.update(10)
            plt.pause(1e-6)
    except KeyboardInterrupt as e:
        pbar.close()
        # Without restoring the original matplotlib state, there would be an
        # error on Ctrl+C:
        #
        # "RuntimeError: main thread is not in

# Generated at 2022-06-24 10:21:20.910244
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    import os
    import sys
    for i in tqdm(range(100000), desc="tqdm(range(100000))"):
        if i > 200:
            break
    for i in tqdm(range(10), desc="tqdm(range(10))"):
        if i > 5:
            break
    tqdm.close()
    tqdm._instances.clear()
    try:
        os.close(sys.stdout.fileno())
    except OSError:
        pass

# Generated at 2022-06-24 10:21:23.197060
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .tests import test_tqdm_gui_closure
    test_tqdm_gui_closure(tqdm_gui)

# Generated at 2022-06-24 10:21:31.571281
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import sys
    # sys.stdout.write
    sys.stdout = sys.stderr = open('/dev/null', 'w')
    # create terminal version
    t = tqdm_gui(100)
    t.display()
    # test display
    t.display()
    # test update
    t.update()
    # test display_hook
    t.display()
    # test close
    t.close()
    # test write
    t.write('hello')
    # test close
    t.close()

# Generated at 2022-06-24 10:21:37.106765
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt

    plt.ion()

    # Create tqdm instance
    for i in tqdm(xrange(5)):
        plt.pause(1)
        # Clear the line
        tqdm.clear()
        # Draw the line again
        tqdm.display()

    # If the close function is not triggered, we would have to
    # explicitly close windows after the figure is done
    plt.close('all')

# Generated at 2022-06-24 10:21:42.807151
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from random import randint
    from numpy import allclose
    from matplotlib.figure import Figure
    from matplotlib.pyplot import close
    from tqdm.gui import trange
    figure_list = [plt.figure() for i in range(3)]
    for fig in figure_list:
        ax = fig.add_subplot(111)
        ax.plot([1, 2, 3])
        plt.pause(1e-9)

# Generated at 2022-06-24 10:21:47.425122
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as pbar:
        curr = 0
        while curr <= 10:
            pbar.update(1)
            curr += 1

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:21:49.844318
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test method clear of class tqdm_gui
    """
    t = tqdm_gui(xrange(10))
    for j in t:
        t.clear()

# Generated at 2022-06-24 10:21:52.159617
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()


# Generated at 2022-06-24 10:22:01.222426
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from nose.tools import assert_equal
    from .utils import FormatCustom
    t = tqdm_gui(total=100,
                 mininterval=0.5,
                 miniters=1,
                 file=None,
                 bar_format=FormatCustom("{bar} |"),
                 unit_scale=True)

    for i in t:
        sleep(0.05)
        t.display()

    t.close()
    with t.get_lock():
        assert_equal(t.miniters, t.last_print_n)
        # Test leave=True
        t = tqdm_gui(total=100,
                     miniters=1,
                     leave=True,
                     file=None)
        for i in t:
            pass
        t.close()

# Generated at 2022-06-24 10:22:04.377507
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib as mpl
    except ImportError:
        return
    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmExperimentalWarning)
        for i in tqdm_gui(range(10)):
            pass
        t = tqdm_gui(range(10))
        t.close()

# Generated at 2022-06-24 10:22:06.445875
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for i in tqdm(range(10), clear=True):
        pass


# Generated at 2022-06-24 10:22:12.466021
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    test the method display of class tqdm_gui.

    This function is not used in code, but it is kept here
    to show running example of tqdm_gui
    (which can't be done in IPython due to GUI event loop).
    """
    from sys import stdout
    from time import sleep

    # xrange is not used in the code, but it is kept here as example
    for i in tqdm_gui(range(100), file=stdout):
        sleep(0.1)

# Generated at 2022-06-24 10:22:18.155601
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    try:
        import matplotlib
    except ImportError:
        print("tqdm.gui needs matplotlib to run properly")
    else:
        matplotlib.use('TkAgg')
        with tqdm_gui(unit='it', unit_scale=True, miniters=1, mininterval=1) \
                as t:
            for i in _range(100):
                sleep(0.2)
                t.update(i)
            t.close()
        print("tqdm.gui is successfully imported!")

# Generated at 2022-06-24 10:22:24.291763
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    import matplotlib.pyplot as plt

    sum(tqdm_gui(
        xrange(100),
        leave=False, mininterval=0.2, miniters=1,
        desc='test', position=0, ncols=100, unit='test',
        bar_format=r'{percentage:3.0f}%|{bar}|{n_fmt}/{total_fmt}'))
    # too many sleeps to be in docstring/tests:
    for _ in tqdm_gui(xrange(10), gui=True, leave=False, file=open('/dev/null', 'w')):
        time.sleep(0.1)

# Generated at 2022-06-24 10:22:35.295985
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # First step: create an instance of tqdm_gui.
    t = tqdm_gui(1)
    # Check that the instance is in the list of _instances.
    # If it is not, raise an exception!
    if not t in tqdm_gui._instances:
        raise Exception("The instance of tqdm_gui was not created correctly. "
                        "The list of _instances subjects is empty.")
    # Second step: call the function close()
    t.close()
    # Check that the instance is no longer in the list of _instances.
    # If it is still there, raise an exception!
    if t in tqdm_gui._instances:
        raise Exception("The instance of tqdm_gui is still in the list of "
                        "_instances even after closing.")
    # If the instance