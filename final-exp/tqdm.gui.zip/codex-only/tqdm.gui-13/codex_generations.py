

# Generated at 2022-06-24 10:12:32.005923
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import tqdm
    import sys

    # initialize tqdm
    for i in tqdm(iterable=range(3), disable=True):
        sys.stdout.write("{0}\n".format(i))

    # test tqdm_gui.display()
    for i in tqdm(iterable=range(3), disable=True):
        tqdm.display()

    if sys.version_info[0] > 2:
        # test tqdm_gui.display()
        for i in tqdm(iterable=range(3), disable=True):
            tqdm.display()

# Generated at 2022-06-24 10:12:40.746688
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .gui import tqdm_gui
    from .std import tqdm
    from .utils import _unicode

    for desc in [str(""), None]:
        for total in [None, 10, -1]:
            for unit in [None, "it", "i", "", "it "]:
                t = tqdm_gui(desc=desc, total=total, unit=unit)
                t.close()
                t = tqdm(desc=desc, total=total, unit=unit)
                t.close()

    t = tqdm_gui(desc=None, total=None, unit=None)
    assert t.total is None
    assert t.unit is None
    t.close()


# Generated at 2022-06-24 10:12:44.243752
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Test tqdm_gui
    with tqdm_gui(unit="i") as t:
        for i in range(10):
            t.update(1)
        t.clear()
        t.display()
        t.clear()



# Generated at 2022-06-24 10:12:48.479776
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(1)
    assert len(tqdm_gui._instances) == 1
    t.close()
    assert len(tqdm_gui._instances) == 0

# Generated at 2022-06-24 10:12:55.506571
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    pbar = tqdm_gui(total=4)
    for i in range(4):
        sleep(1)
        pbar.update(1)
    pbar.close()



# Generated at 2022-06-24 10:13:01.631192
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    mess = [
    "I tried my best, but in the end, it doesn't even matter...",
    'I had to fall',
    'To lose it all',
    'But in the end',
    "It doesn't even matter",
    ]
    for i in tqdm(mess):
        pass

if __name__ == '__main__':
    assert test_tqdm_gui_close() == None

# Generated at 2022-06-24 10:13:11.971229
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_equal
    from datetime import datetime
    from .std import tqdm
    from .gui import tqdm_gui
    for unit in [None, 'it', 's', 'ms', 'us', 'ns', '%']:
        for total in [None, 100]:
            for desc in [None, 'desc']:
                for n in [0, 1, 999, 1000]:
                    tqdm_obj = tqdm(total=total, desc=desc, unit=unit)
                    tqdm_obj.start()
                    tqdm_obj.last_print_t = datetime(1970, 1, 1)
                    tqdm_obj.start_t = datetime(1970, 1, 1)


# Generated at 2022-06-24 10:13:24.931713
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    import time
    from time import sleep
    from numpy import mean, std

    report = []
    sizes = []
    times = []
    for _ in tqdm_gui(range(20)):
        sz = tqdm_gui().display()
        t = time.time()
        sleep(0.01)
        t = time.time() - t
        report.append(sz)
        sizes.append(sz)
        times.append(t)
    assert all(sz <= t for sz, t in zip(sizes, times))
    assert mean(times) > mean(sizes)
    assert std(times) > std(sizes)

# Generated at 2022-06-24 10:13:37.196075
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close.
    """
    import xmlrpclib
    try:
        server = xmlrpclib.ServerProxy('http://localhost:9000')
        server.subtract(5, 2)
        raise AssertionError("server is on, but should be off")
    except Exception:
        pass
    from .gui import tqdm
    from time import sleep
    for j in tqdm(xrange(1000)):
        sleep(1e-4)
    for i in tqdm(xrange(1000)):
        sleep(1e-4)

# Generated at 2022-06-24 10:13:44.432363
# Unit test for function tgrange
def test_tgrange():
    """Test that tgrange works on all Pythons."""
    try:
        # Check that tgrange works with and without arguments
        assert tgrange()
        assert tgrange(1)
        assert tgrange(1, 2)
        assert tgrange(1, 2, 3)
    except Exception as e:
        raise(e)


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:13:59.511940
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np

    t = tqdm_gui(total=10)
    t.start_t = 0.
    t.last_print_t = 0.
    t.last_print_n = 0

    t.xdata = np.linspace(10, 0, 60)
    t.ydata = np.log(t.xdata)
    t.zdata = np.log(t.xdata)

    t.display()
    np.testing.assert_almost_equal(t.xdata[-1], 0.01)
    np.testing.assert_almost_equal(t.ydata[-1], np.log(0.01))
    np.testing.assert_almost_equal(t.zdata[-1], np.log(0.01))

    # Test with total=None
   

# Generated at 2022-06-24 10:14:06.771226
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm_gui as tqdm_gui_real

    def __init__(self, *args, **kwargs):
        super(tqdm, self).__init__(*args, **kwargs)

    tqdm_gui_real.__init__ = __init__
    tqdm_gui_real(['a', 'b'])


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:11.243746
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=50, leave=False) as t:
        for i in _range(50):
            t.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:20.878365
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    # test for Python 2, 3 and PyPy
    for ver in [2, 3, "PyPy"]:
        if sys.version_info[0] == ver:
            break
    else:
        raise Exception("unexpected Python version")

    import matplotlib.pyplot as plt
    from matplotlib.rcsetup import all_backends
    # check whether matplotlib supports the current backend
    backend = plt.get_backend()
    assert backend in all_backends, "unexpected matplotlib backend"

    # create a progressbar
    total = 5
    pb = tqdm_gui(total=total, desc='testing_close')
    for _ in range(total):
        pb.update()
    # close the progressbar
    pb.close()
    # check whether the progress

# Generated at 2022-06-24 10:14:31.401185
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    if not tqdm_gui._instances:
        tqdm_gui(total=10)
    else:  # pragma: no cover
        tgrange(10)


if __name__ == '__main__':  # pragma: no cover
    import time

# Generated at 2022-06-24 10:14:39.457527
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from sys import executable
    from subprocess import check_output
    from time import sleep
    print(check_output([executable, __file__],
                       stderr=open('nul', 'r+b') if "win" in sys.platform else None))
    sleep(5)
if __name__ == '__main__':
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(.5)
            pbar.update(10)
        pbar.close()

# Generated at 2022-06-24 10:14:42.565820
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import doctest
    doctest.testmod(tqdm, verbose=False)
    doctest.run_docstring_examples(tqdm_gui.display, tqdm_gui())

# Generated at 2022-06-24 10:14:51.501229
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from collections import namedtuple

    with tqdm_gui(total=10) as pbar:
        for _ in range(10):
            pbar.update()

    class TestClass:
        tqdm_gui = tqdm_gui
        @tqdm_gui
        def test_method(self, iterable, *args, **kwargs):
            try:
                for _ in iterable:
                    pass
            finally:
                self.tqdm_gui.clear(*args, **kwargs)

    class TestSubClass(TestClass):
        tqdm_gui = tqdm_gui

    TestClass().test_method(range(5))
    TestSubClass().test_method(range(5))

# Generated at 2022-06-24 10:14:54.891773
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    t = tqdm_gui(100)

    for i in t:
        sleep(0.01)

# Generated at 2022-06-24 10:14:56.409075
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    if not gui.matplotlib_imported:
        return
    assert gui.tqdm_gui().close() is None


# Generated at 2022-06-24 10:15:01.686256
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Unit test for tqdm_gui"""
    for n in tqdm([0, 1, 2, 3]):
        pass
    for i in tqdm(tgrange(5)):
        pass
    with tqdm(total=4) as t:
        for i in range(4):
            t.update()

# Generated at 2022-06-24 10:15:09.020439
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy import random
    import matplotlib.pyplot as plt
    for _ in tqdm([1, 2, 3]):
        sleep(0.1)
    for _ in tqdm(range(5)):
        sleep(0.1)
    for _ in tqdm(random.randn(10)):
        sleep(0.1)
    pbar = tqdm(total=100)
    for i in range(100):
        pbar.update()
        sleep(0.01)
    pbar.close()

    # Smoke test random data #94
    try:
        for _ in tqdm(random.randn(10000)):
            pass
    except Exception:
        # We don't care about its output
        tqdm

# Generated at 2022-06-24 10:15:14.150364
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        for i in range(10):
            tqdm(total=10, leave=False).update()
    except AttributeError:
        print("tqdm_gui.close() failed!")
        raise
    else:
        print("tqdm_gui.close() passed!")


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:15:16.895044
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm
    from time import sleep
    for _ in tqdm.tqdm_gui(range(8), desc='foo', leave=False):
        sleep(0.25)
    sleep(0.5)


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:15:29.941244
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import mock
    from .utils import format_dict
    from .std import TqdmTypeError

    with mock.patch('matplotlib.pyplot.pause', return_value=True) \
            as m_fig_pause:
        with mock.patch('matplotlib.pyplot.close', return_value=True) \
            as m_fig_close:
            with mock.patch('matplotlib.pyplot.isinteractive',
                            return_value=True) as m_fig_isinteractive:
                with mock.patch('matplotlib.pyplot.ion', return_value=True) \
                    as m_fig_ion:

                    tqdm_disp = tqdm_gui()
                    tqdm_disp.disable = False
                    tqdm_disp.iterable = _range(100)

# Generated at 2022-06-24 10:15:32.838856
# Unit test for function tgrange
def test_tgrange():
    import os, sys, time
    with tgrange(10, desc="1st loop") as t:
        for i in t:
            assert i < 10
            time.sleep(0.01)
            if i == 1:
                from tqdm import trange
                with trange(5, desc="2nd loop") as tt:
                    for j in tt:
                        assert j < 5
                        time.sleep(0.02)

# Generated at 2022-06-24 10:15:38.084289
# Unit test for function tgrange
def test_tgrange():
    with tgrange(1, 2, 3) as iterator:
        assert hasattr(iterator, '_gui')  # gui instance
        assert isinstance(iterator, tqdm_gui)
        for _ in iterator:
            pass
    assert not hasattr(iterator, '_gui')  # gui instance



# Generated at 2022-06-24 10:15:40.311189
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test `tqdm_gui.close` method"""
    assert tqdm_gui.close != tqdm_gui.close.__base__
    assert tqdm_gui.close.__module__ == tqdm_gui.__module__
    assert tqdm_gui.close.__doc__ == tqdm_gui.close.__base__.__doc__


# Generated at 2022-06-24 10:15:44.461006
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm(total=100, unit="B", unit_scale=True,
              unit_divisor=1024, gui=True, desc="TEST") as t:
        for i in range(100):
            t.update()
            sleep(0.2)

# Generated at 2022-06-24 10:15:52.640582
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        tqdm_gui()
    except:
        raise AssertionError("constructor")


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    for i in tqdm_gui(tgrange(10)):
        sleep(.25)
        # if i == 2:
        #     import psutil
        #     for p in psutil.process_iter():
        #         try:
        #             if p.cmdline() == ['python', '~/tqdm_gui.py']:
        #                 p.kill()
        #         except:
        #             pass

# Generated at 2022-06-24 10:16:02.485540
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import os
    import time
    import random
    from io import StringIO
    from contextlib import contextmanager
    from subprocess import Popen, PIPE

    @contextmanager
    def capture_output():
        oldout, olderr = sys.stdout, sys.stderr
        try:
            out=[StringIO(), StringIO()]
            sys.stdout,sys.stderr = out
            yield out
        finally:
            sys.stdout,sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    # patching `os` is required to force the use of `tqdm`
    # instead of the built-in version of tqdm (e.g. in pand

# Generated at 2022-06-24 10:16:07.376166
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Mimic tqdm and test class method display."""
    import time as _time
    # import tqdm.gui as gui
    gui = sys.modules[__name__]
    t = gui.tgrange(4)
    for _ in t:
        t.display()
        _time.sleep(0.1)
    t.close()

# Generated at 2022-06-24 10:16:12.610238
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test for clear() method for tqdm_gui"""
    from nose.tools import ok_
    from time import sleep
    for i in tqdm_gui(range(10), desc="test"):
        sleep(1e-2)
        if i == 5:
            tqdm_gui.clear()
            ok_(True)
        sleep(1e-2)

# Generated at 2022-06-24 10:16:13.248195
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass

# Generated at 2022-06-24 10:16:18.754090
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import sys
    import time
    from io import StringIO

    stdout = sys.stdout
    sys.stdout = StringIO()

    with tqdm(range(50), unit="it", unit_scale=True, unit_divisor=1000) as t:
        for i in t:
            time.sleep(0.1)
        t.close()

    sys.stdout = stdout



# Generated at 2022-06-24 10:16:20.174015
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=2) as pbar:
        pbar.update()
        pbar.close()

# Generated at 2022-06-24 10:16:28.361000
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import _term_move_up
    from .gui import tqdm_gui
    for i in tqdm_gui(range(2), desc='toto', leave=True):
        for j in tqdm_gui(range(3), desc='titi', leave=False):
            for k in tqdm_gui(range(2), desc='tata', leave=True):
                assert k == 0 or k == 1
                assert j == 0 or j == 1 or j == 2
                assert i == 0 or i == 1
                import time
                time.sleep(0.1)
    _term_move_up()

# Generated at 2022-06-24 10:16:30.067722
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(4, 8):
        time.sleep(0.3)

# Generated at 2022-06-24 10:16:39.774394
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for method close of class tqdm_gui"""
    # pylint: disable=protected-access
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # pylint: disable=redefined-outer-name

    inst = tqdm_gui(disable=True)
    # Force closing (i.e. with self.disable=True) without going through the
    # `close` method of `tqdm`.
    inst.clear()
    assert inst._instances == []
    assert mpl.rcParams['toolbar'] == 'None'
    assert plt.isinteractive() is False

    inst = tqdm_gui(disable=False)
    inst.clear()
    assert inst._instances == []
    assert mpl.rcParams

# Generated at 2022-06-24 10:16:49.361811
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    items = list(range(10))
    with tqdm(items, unit_scale=True, unit='iB') as pbar:
        for item in pbar:
            pbar.display(item, pbar.n, pbar.rate, pbar.n / pbar.total,
                         pbar.dynamic_messages)
    with tqdm(total=len(items), position=0, leave=True) as pbar:
        for item in items:
            pbar.display(item, pbar.n, pbar.rate, pbar.n / pbar.total,
                         pbar.dynamic_messages)


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:17:01.609183
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .utils import _range
    from .std import format_interval, format_meter
    from .std import format_size, format_timespan
    import locale
    import math
    import sys
    import time

    def d(n):
        tq.display()
        time.sleep(0.1)
        return n

    # Test 1st n digits rounding
    with tqdm(total=256, ncols=100) as tq:
        for i in _range(8):
            tq.postfix[i] = 'i={0}'.format(i)
            tq.update(d(8))
            time.sleep(0.1)
            # postfix = tq.format_dict['postfix']

    # Test don't format if no digits

# Generated at 2022-06-24 10:17:09.130234
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():     # pragma: no cover
    from .utils import FreezableClass
    t = tqdm_gui(range(1000), leave=False)
    for i in t:
        t.clear()
        if i == 200:
            break
    t.close()
    t = FreezableClass(tqdm_gui(range(1000), leave=False))
    for i in t:
        t.freeze_attr('clear')()
        if i == 200:
            break
    t.close()

# Generated at 2022-06-24 10:17:12.446706
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    total = 99
    with tqdm(total=total) as t:
        for i in t:
            pass
    for i in range(total):
        t.update()
    t.close()
    del t

# Generated at 2022-06-24 10:17:22.184893
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .tests import TestCase  # noqa
    from .tests import ClassMethod  # noqa
    from .tests import setup_environment  # noqa
    from .tests import _get_elapsed  # noqa
    from .tests import _test_reset  # noqa
    from .tests import _test_gui_output  # noqa

    class tqdm_test(tqdm_gui):  # noqa
        def __init__(self, *args, **kwargs):
            kwargs = kwargs.copy()
            kwargs['gui'] = True
            super(tqdm_test, self).__init__(*args, **kwargs)

        @ClassMethod
        def clear(self, nolock=False):
            if nolock:
                self.last_print_n = 0
                self

# Generated at 2022-06-24 10:17:33.763406
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from threading import Thread
    from itertools import product

    try:
        from IPython.lib.pretty import pretty as pp  # type: ignore
    except ImportError:
        pp = str
    lg = locals()

    pbar = tgrange(1, 10, desc='Test', leave=False)
    for i in pbar:
        pbar.display()
        try:
            sleep(1)
        except KeyboardInterrupt:
            break
    pbar.close()
    print(pp(dir(pbar)))
    print(pp(lg))

    pbar = trange(1, 10, desc='Test', leave=False)
    for i in pbar:
        pbar.display()
        try:
            sleep(1)
        except KeyboardInterrupt:
            break


# Generated at 2022-06-24 10:17:43.315619
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4):
        assert i == 0  # tgrange(4) display nothing and only yield 0


# Test
if __name__ == "__main__":
    # Unit test for tqdm_gui
    import time
    try:
        assert int(time.time()) != 0
    except AssertionError:
        raise AssertionError(
            'Please set your system clock to run this test properly')

    with tqdm_gui(total=10) as t:
        for i in range(t.total):
            t.update()
            time.sleep(0.1)

    with tqdm_gui(total=10) as t:
        for i in range(4):
            t.update()
            time.sleep(0.1)
        t.close()

    # Unit

# Generated at 2022-06-24 10:17:51.002129
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .signal import pause
    from .utils import get_term_width
    width = get_term_width() - 10
    for _ in trange(20, position=10, leave=False, desc='test',
                    bar_format='{desc}[{elapsed}<{remaining}, {rate_fmt}]'):
        if width > 0:
            with tqdm(total=width, bar_format='{bar}') as pbar:
                for _ in range(width):
                    pbar.update()
        else:
            pause(0.5)

# Generated at 2022-06-24 10:17:53.056635
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import doctest

    doctest.testmod()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:17:55.505108
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui(range(3), file=open(os.devnull, 'w')).clear()

# Generated at 2022-06-24 10:18:06.291337
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    plt.close()  # close all figures if last call wiped out
    try:
        import seaborn as sns
        sns.set_style('white')
    except:
        pass
    try:  # pragma: no cover
        from IPython import get_ipython
        ip = get_ipython()
        if ip and ip.__class__.__name__ == 'ZMQInteractiveShell':
            ip.enable_matplotlib()
    except ImportError:
        pass
    p = tqdm(total=100, desc="test_tqdm_gui_display")
    for i in range(10):
        p.update()
        plt.pause(0.1)
    p.close()
    plt.pause

# Generated at 2022-06-24 10:18:12.612936
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    import time
    v = sys.version_info
    if v[:2] >= (2, 7):
        try:
            import unittest2 as unittest
        except ImportError:
            import unittest
    else:
        import unittest
    import pylab as plt
    try:
        plt.ion()
    except TypeError:
        return False  # pragma: no cover
    try:
        plt.show()
    except AttributeError:
        return False  # pragma: no cover

    f = sys.stdout

# Generated at 2022-06-24 10:18:16.995289
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    for x in tqdm_gui(range(3)):
        tqdm_gui.clear()

    with patch.object(tqdm_gui, 'display') as display:
        tqdm_gui.clear()
        assert not display.called

# Generated at 2022-06-24 10:18:26.739979
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np

    x = np.random.rand(100)

    # this is the method to test
    def display_test(xdata, ydata, zdata, ax, line1, line2, hspan):
        n = len(ydata)
        cur_t = n
        elapsed = cur_t
        delta_it = n
        delta_t = cur_t

        # Inline due to multiple calls
        total = None
        # xdata = self.xdata
        # ydata = self.ydata
        # zdata = self.zdata
        # ax = self.ax
        # line1 = self.line1
        # line2 = self.line2
        # # instantaneous rate
        y = delta_it / delta_t
        # overall rate
        z = n / elapsed
        # update line

# Generated at 2022-06-24 10:18:36.696143
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm._utils import _term_move_up
    from tqdm._utils import _time
    from tqdm._utils import _unicode
    from tqdm._version import __version__
    from tqdm.std import tqdm as std_tqdm
    from .utils import format_sizeof
    from .utils import _range

    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import sys
    iterable = _range(20)
    n = len(iterable)
    # instantiating tqdm (commented out, see docstring)
    for i in tqdm_gui(iterable, unit="it",
                      total=n, leave=False, file=sys.stdout):
        _time()
        pass

    # Testing class GUI
    # instant

# Generated at 2022-06-24 10:18:39.686310
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import tqdm_gui, trange
    from time import sleep
    for i in trange(5):
        sleep(0.4)


# Generated at 2022-06-24 10:18:48.679969
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit tests for `tqdm.gui.tqdm.display` method.
    """
    import matplotlib.pyplot as plt

    try:
        import pytest
    except ImportError:  # pragma: no cover
        return
    else:
        try:
            import numpy as np
        except ImportError:  # pragma: no cover
            return

    @pytest.fixture(autouse=True)
    def close_plt(request):
        def fin():
            plt.close("all")
        request.addfinalizer(fin)


# Generated at 2022-06-24 10:18:58.711946
# Unit test for method clear of class tqdm_gui

# Generated at 2022-06-24 10:19:00.484308
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .tests import TestTqdmGuiClear

    TestTqdmGuiClear().test()

# Generated at 2022-06-24 10:19:04.345669
# Unit test for function tgrange
def test_tgrange():
    from time import sleep

    gui_range = list(tgrange(10))
    assert gui_range == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for _ in tgrange(10):
        sleep(0.01)



# Generated at 2022-06-24 10:19:13.734258
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui"""
    from unittest import TestCase

    class Dummy:
        """Dummy output stream"""
        closed = False
        _deque = None

        def write(self, msg):
            """Dummy method"""
            assert isinstance(msg, str)  # msg is a string
            if self._deque is None:
                self._deque = deque(maxlen=100)
            self._deque.append(msg)  # save msg to deque

        @property
        def buf(self):
            """Return the whole content of the buffer"""
            if self._deque is None:
                self._deque = deque(maxlen=100)
            return "".join(self.buf)
    dummy = Dummy()

    # Test a clear with no bars

# Generated at 2022-06-24 10:19:16.320027
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.backends as mb
    assert hasattr(mb, 'backend_interact')

# Generated at 2022-06-24 10:19:17.874828
# Unit test for function tgrange
def test_tgrange():
    return list(tgrange(2)) == [0, 1]

# Generated at 2022-06-24 10:19:23.908965
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tqdm

    pbar_widgets = [
        'Test: ', tqdm.format_meter(0, 100, 20), ' | ',
        tqdm.format_meter(101, 200, 20),
        ' | ETA: ', tqdm.format_timedelta(20),
    ]
    with tqdm_gui(total=5, bar_format="{l_bar}{bar}{r_bar}",
                  bar_format="{bar}!") as pbar:
        for i in pbar(range(50)):
            pbar.update()

# Generated at 2022-06-24 10:19:35.653679
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from subprocess import call
    import sys
    import time

    # Open in background thread (else may block process)
    if sys.version_info[0] == 2:
        import thread
        thread.start_new_thread(call, ([sys.executable, __file__]))
    else:
        import _thread
        _thread.start_new_thread(call, ([sys.executable, __file__]))
    time.sleep(1)

    import math
    from matplotlib import pyplot as plt
    from datetime import datetime

    def f(x):
        return math.sin(x)  # replace with your own function/iterator

    i = 2000
    pbar = tgrange(i)

# Generated at 2022-06-24 10:19:46.632968
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm import gui, _tqdm
    gui.tqdm_gui(gui.trange(8), desc="tqdm_gui")
    gui.tqdm_gui(gui.trange(8), total=10,
                 desc="tqdm_gui")
    gui.tqdm_gui(gui.trange(8), total=10, ascii=True,
                 desc="tqdm_gui")
    gui.tqdm_gui(gui.trange(8), total=10, miniters=1,
                 desc="tqdm_gui")
    gui.tqdm_gui(gui.trange(8), total=10, mininterval=0.01,
                 desc="tqdm_gui")

# Generated at 2022-06-24 10:19:54.352218
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib
    import matplotlib.pyplot as plt
    import warnings
    warnings.simplefilter('ignore', TqdmExperimentalWarning)

    # Remember if external environment uses toolbars
    toolbar = matplotlib.rcParams['toolbar']

    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    try:
        # Test the closing of the tqdm_gui
        with tqdm(total=1000, leave=True) as t:
            for i in range(10):
                t.update()
            t.close()

        # Test if toolbars are preserved
        assert matplotlib.rcParams['toolbar'] == toolbar

        # Test if interactive mode is preserved
        assert plt.isinteractive() == wasion
    finally:
        # Restore toolbars
        mat

# Generated at 2022-06-24 10:19:55.963419
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    with tqdm(total=10, desc="Close method test") as t:
        for i in _range(10):
            t.update()

# Generated at 2022-06-24 10:20:03.698899
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from shutil import rmtree
    import tempfile

    tempdir = tempfile.mkdtemp()
    try:
        for i in tqdm(range(10), desc='Test', unit='B', unit_scale=True,
                      file=open(tempdir + "\\test.log", "w", encoding="UTF-8")):
            pass
    except AttributeError:
        rmtree(tempdir)
    else:
        raise EnvironmentError("Fail: an exception should have been raised!")
    finally:
        rmtree(tempdir)

# Generated at 2022-06-24 10:20:08.950861
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return False
    pbar = tqdm_gui(total=100, desc='tqdm')
    pbar.display()
    xtics, _ = pbar.line1.get_data()
    assert xtics == [0.0], "Wrong value for xtics!"
    pbar.close()
    plt.cla()

# test_tqdm_gui_display()

# Generated at 2022-06-24 10:20:13.934692
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method `tqdm_gui.clear`
    """
    # create an instance of class tqdm_gui
    f = tqdm_gui(ascii=True)
    # reset the instance
    f.clear(nolock=True)
    # check if the istance has been resetted
    assert f.__dict__.get('disable') is True
    # close the instance
    f.close()



# Generated at 2022-06-24 10:20:15.159214
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=10); t.close()

# Generated at 2022-06-24 10:20:17.756405
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Test tqdm_gui class constructor
    @tqdm_gui()
    def test():
        for i in _range(100):
            pass

    test()

# Generated at 2022-06-24 10:20:20.386126
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(10) as pbar:
        for _ in range(10):
            pbar.update(1)
            pbar.clear()



# Generated at 2022-06-24 10:20:28.661366
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib
    iterable = range(1000)
    with tqdm_gui(iterable, gui=True) as t:
        for i in t:
            if i == 100:
                t.set_postfix_str("pf")
            elif i == 500:
                t.set_description("desc")
    assert t.n == 1000, "There were not enough iterations"
    assert matplotlib.rcParams['toolbar'] == 'None', \
        "Matplotlib toolbar not disabled correctly"
    assert not matplotlib.is_interactive(), "Matplotlib not in non-interactive"

    # Test input parsing
    with tqdm_gui(0, 0, total=100) as t:
        assert 1000 == t.total and 0 == t.n

# Generated at 2022-06-24 10:20:31.948842
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    @tqdm_gui
    def test():
        pass
    test()
    test.clear()

# Generated at 2022-06-24 10:20:34.471441
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import time
    for i, x in tgrange(10, desc="til 10"):
        time.sleep(0.2)
    # Add progressbar to existing iterable:
    for i, x in tgrange(enumerate([1, 2, 3, 4, 5])):
        time.sleep(0.4)

# Generated at 2022-06-24 10:20:36.892821
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Simple unit test function for function tgrange"""
    for _ in tgrange(4):
        pass
    assert True


# Generated at 2022-06-24 10:20:40.302311
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .gui import tgrange, trange
    l = [10, 5, 2, 7]
    for i in trange(len(l)):
        for j in tgrange(l[i]):
            pass


# Generated at 2022-06-24 10:20:45.008748
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import time

    progress = tqdm_gui(range(100), colour='g')
    t0 = time.time()
    for i in progress:
        time.sleep(0.01)
        progress.clear()
        plt.pause(0.001)
    print(time.time() - t0)

# Generated at 2022-06-24 10:20:54.219238
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Unit test"""
    from numpy import random
    import matplotlib.pyplot as plt
    try:
        with tqdm_gui(total=5) as pbar:
            for i in range(5):
                pbar.update()
                plt.pause(0.01)
                plt.clf()
    except KeyboardInterrupt:
        pass
    try:
        for i in tqdm_gui(random.randn(100)):
            plt.pause(0.01)
            plt.clf()
    except KeyboardInterrupt:
        pass
    plt.close()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:21:02.304899
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test if tqdm_gui.close() succeeds.
    """
    from matplotlib.testing.decorators import image_comparison, cleanup

    @cleanup
    @image_comparison(baseline_images=['tqdm_gui_close'],
                      extensions=['png'])
    def test():
        import matplotlib.pyplot as plt

        with tqdm_gui(total=5) as pbar:
            pbar.desc = "Testing gui close"
            for _ in range(5):
                pbar.update()
            plt.pause(0.5)
            pbar.close()

    test()

# Generated at 2022-06-24 10:21:05.187697
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(1)
    plt = t.plt
    fig = t.fig
    t.close()
    assert not plt.isinteractive()
    assert fig._shown is None

# Generated at 2022-06-24 10:21:10.407368
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from ._utils import _eq, FakeGUI

    t = tqdm_gui([], gui=True)
    t.start_t = 0
    t.last_print_n = 0
    t.last_print_t = 0
    t.postfix["init"] = 0
    t.display()
    _eq(t.xdata, [])
    _eq(t.ydata, [])
    _eq(t.zdata, [])

    del t.postfix["init"]
    t.last_print_t = -60
    t.last_print_n = 0
    with FakeGUI() as (fig, canvas):
        # t.display()  # pragma: no cover
        pass
    # import matplotlib.pyplot as plt
    # plt.show()

# Generated at 2022-06-24 10:21:14.485014
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import warnings
    warnings.simplefilter("ignore", TqdmExperimentalWarning)
    from os import remove

    f = open('test_file.txt', 'w')
    f.close()
    for i in trange(1, 5):
        pass
    tqdm.close()
    remove('test_file.txt')

# Generated at 2022-06-24 10:21:16.454772
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from .tests.gui import test_gui_close
    test_gui_close(tqdm_gui)



# Generated at 2022-06-24 10:21:24.806939
# Unit test for function tgrange
def test_tgrange():
    from time import sleep

    for i in tgrange(10, desc="With tgrange", leave=True):
        assert i in (10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        sleep(0.1)

    for i in tqdm_gui(10, desc="With tqdm_gui", leave=True):
        assert i in (10, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        sleep(0.1)

# Generated at 2022-06-24 10:21:35.120289
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from sys import version_info

    # Define a tqdm_gui object
    t = tqdm_gui(total=100)

    # Fill up the progressbar
    for i in range(100):
        t.update(1)
        sleep(0.01)

    # Check if we are in the expected state
    assert t.disable is False

    # Close the progressbar
    t.close()

    # Check if the progressbar is in the correct state
    assert t.disable is True


# Generated at 2022-06-24 10:21:41.636284
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase
    from matplotlib import pyplot as plt
    import unittest

    # Test that close() works as expected
    plt = plt
    # Test that tqdm_gui.close() is called at end of gui usage
    class TestGuiClose(TestCase):
        def setUp(self):
            self.fig = plt.figure()  # create the figure
            with self.assertRaises(SystemExit):
                self.fig.close()
        # setUp() is called before every test_ method
        def test_close(self):
            # Test that the figure instance is created
            self.assertTrue(self.fig)
            # Test that the figure window is open and active
            self.assertFalse(self.fig.canvas.manager.window.is_active())
    unitt

# Generated at 2022-06-24 10:21:51.947368
# Unit test for constructor of class tqdm_gui

# Generated at 2022-06-24 10:22:01.054946
# Unit test for function tgrange
def test_tgrange():
    """Unittest of tgrange"""
    l = []
    for i in tgrange(5):
        l.append(i)
        import time
        time.sleep(0.5)
    assert list(range(5)) == l


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    from random import random

    for _ in tqdm(xrange(500), desc='1st loop'):
        for _ in tqdm(xrange(500), desc='2nd loop', leave=False):
            for _ in tqdm(xrange(500), desc='3nd loop'):
                sleep(0.01)

    # Test with "external" loop
    l = tqdm(xrange(100))
    for i in l:
        l.set_

# Generated at 2022-06-24 10:22:06.779218
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from multiprocessing import Process, Queue
    from time import sleep
    # Initialize and open the GUI
    for _ in tqdm(range(1)):
        sleep(0.01)
    p = Process(target=test_tqdm_gui_close_subprocess, args=(Queue(),))
    p.start()
    p.join()



# Generated at 2022-06-24 10:22:15.652120
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    from time import sleep
    from tqdm import gui

    gui.tqdm_gui.clear = std_tqdm.clear
    with gui.tqdm_gui(total=10) as t:
        t.display = std_tqdm.display
        for i in _range(10):
            t.update(1)
            t.display()
            sleep(0.1)
        t.clear()
        print("t.clear()")
        t.display()
        print("t.display()")
        t.display()
        print("t.display()")
        t.clear()
        print("t.clear()")
        sys.stdout.write("\033[F")
        sys.stdout.flush()
        t.display()
        print("t.display()")
       

# Generated at 2022-06-24 10:22:19.785845
# Unit test for function tgrange
def test_tgrange():
    assert tgrange(2) == [0, 1]
    assert tgrange(2, 6, 4) == [2, 6]
    assert tgrange(6, 2, -4) == [6, 2]
    assert tgrange(2, -2, -1) == [2, 1, 0, -1]
    assert tgrange(1.5, 9.5, 3) == [1.5, 4.5, 7.5]

# Generated at 2022-06-24 10:22:25.013685
# Unit test for function tgrange
def test_tgrange():
    ''' Unit test for function tgrange '''
    from time import sleep
    from sys import version_info

    t = tgrange(3, desc='T:', unit='blah')
    for i in t:
        assert t.n == i
        sleep(0.1)
    t.close()

    # on python 2.x
    if version_info < (3, 0):
        t = tgrange(3, desc='T:', unit='blah')
        for i in t:
            assert t.n == i
            sleep(0.1)
        t.close()