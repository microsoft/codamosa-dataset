

# Generated at 2022-06-24 10:12:37.894194
# Unit test for function tgrange
def test_tgrange():
    """Test of tgrange"""
    import sys

    # NOTE: We often test with a large number of iterations
    # to check for lockups, so if testing on a slow system
    # one can uncomment the line below to reduce the number
    # of iterations.
    # sys.excepthook = reduce_excepthook
    for i in tgrange(10):
        assert i == next(tgrange(10))

    assert list(tgrange(0)) == []
    assert list(tgrange(10, 0, -1)) == [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert list(tgrange(10, 0, -2)) == [10, 8, 6, 4, 2]

# Generated at 2022-06-24 10:12:46.224687
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    from .gui import tqdm_gui
    from .utils import _time
    from threading import Thread
    import matplotlib.pyplot as plt
    import time
    import sys

    def test_display_func(input_list, leave=0, **topkwargs):
        d = deque(input_list, 10)
        t = tqdm_gui(total=len(input_list), leave=leave, **topkwargs)
        for i in range(len(input_list)):
            # display at every 5 steps
            if i % 5:
                t.display()
            if not t.disable:
                # update the instance object
                t.update(n=i % 5)
                time.sleep(0.1)
        if t.disable:
            return

        #

# Generated at 2022-06-24 10:12:51.447109
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Run tqdm_gui(range(10)) without raising errors"""
    @tqdm_gui(disable=True)  # override disable to avoid "Exception ignored"
    def tqdm_gui_test():
        return [i**2 for i in tqdm_gui(range(10), leave=True)]
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")  # Always trigger all warnings
        tqdm_gui_test()
        assert issubclass(w[-1].category, TqdmExperimentalWarning)
        # avoid TypeError: list indices must be integers, not NoneType
        assert len(w) > 0

# Generated at 2022-06-24 10:13:03.125941
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    plt.ioff()
    t = tqdm_gui(total=100)

    xdata, ydata, zdata = t.xdata, t.ydata, t.zdata
    ax = t.ax
    ymin, ymax = ax.get_ylim()

    t.display()
    assert xdata == [0]
    assert ydata == [0]
    assert zdata == [0]
    assert t.hspan.get_xy()[2, :2].tolist() == [0, ymax]

    t.update(10)
    t.display()
    assert xdata == [0, 10]
    assert ydata == [0, 1.0]
    assert zdata == [0, 1.0]
    assert t.h

# Generated at 2022-06-24 10:13:12.382217
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from nose.tools import assert_equal
    for _ in trange(1000, desc="Test1", bar_format='{desc}: {percentage:3.0f}%|{bar}|'):
        pass
    for _ in trange(1000, desc="Test2", leave=True):
        pass
    t = trange(10, desc="Test3")
    assert_equal(next(t), 0)
    assert_equal(next(t), 1)
    t.close()
    with tqdm(total=1000, desc="Test4") as t1:
        for _ in trange(1000, desc="Test5", leave=True):
            t1.update(1)
    assert_equal(t1.n, 1000)

# Generated at 2022-06-24 10:13:14.037014
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    t = tqdm_gui(total=100)
    for i in range(0, 100):
        sleep(0.025)
        t.update()
    t.close()

# Generated at 2022-06-24 10:13:26.629289
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from ._utils import _term_move_up
    from time import sleep
    from sys import stderr, platform

    t = tqdm_gui(["a", "b", "c", "d"], file=stderr)
    for i in t:
        sleep(0.05)
    t.close()

    if platform == "win32":
        assert _term_move_up + "a b c d\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r"

# Generated at 2022-06-24 10:13:33.354039
# Unit test for function tgrange
def test_tgrange():
    """Unit test for function tgrange"""
    from .std import tqdm as std_tqdm

    for n in tgrange(4, leave=True):
        for _ in tgrange(n):
            pass

    # make sure it behaves the same as the std version
    for n in std_tqdm(4, leave=True):
        for _ in tgrange(n):
            pass

# Generated at 2022-06-24 10:13:38.046183
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import time

    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.display()
            time.sleep(0.01)

# Generated at 2022-06-24 10:13:45.662637
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test TqdmGui"""
    from nose.tools import assert_equal

    for n in tqdm_gui(list(range(50)), leave=False):
        pass

    for n in tqdm_gui(list(range(50)), leave=False):
        pass

if __name__ == '__main__':
    from doctest import testmod
    testmod(verbose=True)
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:58.557569
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from time import sleep
    # TODO: check that the bar gets updated and that the expected runtime
    # is respected
    with tqdm_gui(total=100, unit="it", unit_scale=True) as pbar:
        for i in _range(100):
            pbar.update()
            sleep(0.1)
    pbar.close()
    # check that the toolbar has been reset
    assert mpl.rcParams['toolbar'] == 'None'
    # check that the plot is closed
    assert not plt.fignum_exists(pbar.fig.number)

# Generated at 2022-06-24 10:13:59.443695
# Unit test for function tgrange
def test_tgrange():
    for _ in tgrange(3):
        pass



# Generated at 2022-06-24 10:14:11.052960
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test GUI minimal constructor"""
    from unittest import TestCase

    class TestTqdmGui(TestCase):

        @staticmethod
        def test_gui_constructor():
            tqdm_gui(total=10)
            tqdm_gui(total=10, leave=False)
            tqdm_gui(total=10, leave=False, colour='r')
            tqdm_gui(total=10, leave=False, colour='r')
            tqdm_gui(total=10, leave=False, colour='r', dynamic_ncols=True)
            tqdm_gui(total=10, leave=False, colour='r', dynamic_ncols=True, ncols=85)

# Generated at 2022-06-24 10:14:20.708297
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """unit test for method display of class tqdm_gui"""
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots()

    xdata = [10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5]
    ydata = [8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84,
             4.82, 5.68]
    ax.plot(xdata, ydata, 'o')

    # All tests pass
    # assert_equal(self.hspan.get_xy(),[])
    # assert_equal(ax.get_title(), "")
    # assert_equal(self.line1.get_data(),(xdata, ydata))
   

# Generated at 2022-06-24 10:14:28.130979
# Unit test for function tgrange
def test_tgrange():
    from tqdm.gui import trange
    from time import sleep

    # Prefill trange bar
    for i in trange(10):
        sleep(0.1)

    # Update manually
    for i in trange(10, desc='1st loop'):
        sleep(0.1)
    for i in trange(5, desc='2nd loop'):
        sleep(0.1)

# Generated at 2022-06-24 10:14:40.297522
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase, mock  # python3 only
    from io import StringIO

    class test_close(TestCase):
        def test_close(self):
            # restore previous environment state
            with mock.patch('matplotlib.pyplot.isinteractive',
                            side_effect=lambda: False):
                with mock.patch('matplotlib.pyplot.close',
                                side_effect=lambda *x, **y: None):
                    with mock.patch('sys.stdout', new=StringIO()):
                        with tqdm(total=10, leave=True) as q:
                            q.update(5)
                            q.close()
                            self.assertEqual(q.n, 5)
                            self.assertEqual(q.disable, True)

    test_close().test_

# Generated at 2022-06-24 10:14:41.608393
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with std_tqdm(total=10) as pbar:
        pbar.clear(False)

# Generated at 2022-06-24 10:14:50.307669
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange

    # create the object
    total = float(2e4)
    t1 = tqdm_gui(total=total, position=0, leave=False, ascii=True)
    _ = tqdm_gui(total=total, position=1, leave=True, ascii=True)
    t2 = tqdm_gui(total=total, position=2, leave=True, ascii=True)
    # check if the GUI bar has been displayed in the right way
    t1.start()
    assert t1.xdata == [0]
    assert t1.ydata == [0]
    assert t1

# Generated at 2022-06-24 10:14:59.903340
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    assert list(tgrange(3)) == [0, 1, 2]
    assert list(tgrange(1)) == [0]
    assert list(tgrange(0)) == []
    assert list(tgrange(-1)) == []
    # Test KWargs
    assert list(tgrange(3, desc='desc')) == [0, 1, 2]
    assert list(tgrange(3, desc='desc', ascii=True)) == [0, 1, 2]
    assert list(tgrange(3, desc='desc', miniters=1)) == [0, 1, 2]
    assert list(tgrange(3, desc='desc', miniters=1, mininterval=1e-6)) == [0, 1, 2]

# Generated at 2022-06-24 10:15:09.310683
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm_gui as tgd, tqdm as t
    for i in tgd(tgd.xrange(10), desc='test_tqdm_gui_display'):
        assert i == tgd.tgrange(10)[i]
        assert i == tgd.tqdm(t.xrange(10), desc='test_tqdm_gui_display')[i]
        assert i == tgd.trange(10)[i]

# Generated at 2022-06-24 10:15:18.882480
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test GUI."""
    from tqdm._utils import _term_move_up
    import time

    # Empty
    with tqdm_gui(total=0) as t:
        t.update()
    # Create and close empty
    with tqdm_gui(total=0) as t:
        t.update()
    # Normal
    with tqdm_gui(total=3) as t:
        for i in _range(1, 5):
            time.sleep(0.1 / i)
            t.update(i)
    # Normal - open/close
    for _ in _range(3):
        with tqdm_gui(total=3) as t:
            for i in _range(1, 5):
                time.sleep(0.1 / i)
                t.update(i)


# Generated at 2022-06-24 10:15:31.602456
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test if tqdm_gui closes correctly and properly."""
    from matplotlib.figure import Figure
    # import warnings
    import sys

    # Iterate over several iterations
    for _ in tqdm(range(3), desc="testing", ascii=True):
        pass

    # Test normal closure
    try:
        tqdm_gui(total=3).close()
        tqdm(total=3, desc="testing", ascii=True).close()
    except Exception:
        tb = sys.exc_info()[2]
        tb_info = traceback.extract_tb(tb)
        filename, line, func, text = tb_info[-1]
        raise AssertionError("'close' is failing")

    # Test if Figure is closed

# Generated at 2022-06-24 10:15:33.387031
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for i in tqdm_gui(range(8)):
        pass

    assert True

# Generated at 2022-06-24 10:15:44.663375
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import sys
    import io
    import time
    import unittest
    import tqdm.gui

    with io.StringIO() as our_file:
        with tqdm.gui.tqdm(total=9, file=our_file) as progressbar:
            progressbar.update(3)
            progressbar.close()
        our_file.seek(0)
        our_file_contents = our_file.read()

    class Tests(unittest.TestCase):
        def test_file(self):
            self.assertEqual(our_file_contents,
                             "  0%|                                          "
                             "| 3/9 [00:00<???, ?it/s]")


# Generated at 2022-06-24 10:15:47.029562
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    tqdm_gui( total=10).close()



# Generated at 2022-06-24 10:15:50.381006
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from tqdm.gui import tqdm_gui

    t = tqdm_gui(total=10)
    for _ in t:
        sleep(1)
        t.close()
        t.clear()

# Generated at 2022-06-24 10:15:58.561053
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=2, unit='B', unit_scale=True,
                  unit_divisor=1024, dynamic_ncols=False,
                  disable=False) as t:
        t.update(1)
        t.clear()
    # return t.n == 1
    try:
        return t.n == 1
    except AssertionError:
        raise AssertionError("The attribute `n` of a tqdm_gui object "
                             "should be 1 after a `clear()` method call")

# Generated at 2022-06-24 10:16:06.672045
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """ Unit test for class tqdm_gui """
    import time
    from numpy import linspace, random

    # Test with total
    with tqdm(total=100) as pbar:
        for i in linspace(0, 1, 200):
            time.sleep(random.uniform(0, 0.01))
            pbar.update()

    # Test without total
    with tqdm() as pbar:
        for i in linspace(0, 1, 200):
            time.sleep(random.uniform(0, 0.01))
            pbar.update()



# Generated at 2022-06-24 10:16:14.714385
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import time
    try:
        from pytest import raises
    except ImportError:  # pragma: no cover
        from unittest import SkipTest
        raise SkipTest("pytest is needed for tqdm.gui.test")
    for i in tqdm(list(range(2)), desc="1st loop", leave=True):
        for j in tqdm(list(range(2)), desc="2nd loop", leave=True):
            time.sleep(0.01)
            if j == 1:
                with raises(RuntimeError):
                    tqdm.close()

# Generated at 2022-06-24 10:16:21.239524
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = StringIO(), StringIO()

    t = tqdm_gui(0, 1, position=0, leave=True, file=sys.stderr)
    for i in t:
        assert t.last_print_n == i, t
        t.display()

    sys.stdout, sys.stderr = stdout, stderr

# Generated at 2022-06-24 10:16:29.654411
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import os
    from .main import tgrange

    try:
        # Make sure we are not in a notebook
        # To prevent from fig.show() showing the figure
        get_ipython().__module__  # pragma: no cover
        raise Exception()
    except (ImportError, NameError):
        pass

    for gui in ('inline', 'qt5', 'wx'):
        try:
            plt = __import__('matplotlib.pyplot')
            # Suppress propagation if additional windows are opened
            plt.switch_backend(gui)
            x = tgrange(1)
            x.display()  # pragma: no cover
            x.update()  # pragma: no cover
            x.close()
        except Exception:
            if gui == 'inline':
                raise

# Generated at 2022-06-24 10:16:33.473547
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    tqdm_gui(total=10, leave=True).write("Testing clear")
    sleep(3)
    tqdm_gui(total=10, leave=True).clear()

# Generated at 2022-06-24 10:16:41.353375
# Unit test for function tgrange
def test_tgrange():
    import sys
    sys.stderr = open("/dev/null", "w")

    # test tgrange
    try:
        import numpy as np
    except:
        np = None

    from time import sleep

    for n in tgrange(10):
        sleep(0.01)

    for n in tqdm(tgrange(10)):
        sleep(0.01)

    for n in tgrange(10, 15):
        sleep(0.01)

    for n in tgrange(10, 20, 3):
        sleep(0.01)

    for n in tqdm(tgrange(10, 20, 3)):
        sleep(0.01)


# Generated at 2022-06-24 10:16:51.567174
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import rcParams
    from matplotlib import pyplot as plt
    # Note: do not use `toolbar` for testing,
    #       for it adds another progressbar,
    #       and tests are already complicated as it is
    #       (See issue #1227)
    toolbar = rcParams['toolbar']
    rcParams['toolbar'] = 'None'
    # Calls to pyplot are needed
    # to initialize the interactive mode
    plt.figure()
    plt.subplot()
    # Test static
    pbar = tqdm_gui(total=100, leave=False)
    assert pbar.disable == False
    assert pbar.total == 100
    assert pbar.unit == ''
    assert pbar.unit_scale == False
    assert pbar.desc == ''
   

# Generated at 2022-06-24 10:17:03.321980
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import sys

    t = tqdm_gui(total=100)
    for i in t:
        t.display()
        if i >= 20:  # speed up test
            break
    t.close()

    t = tqdm_gui(total=100, leave=False)
    for i in t:
        t.display()
        if i >= 20:  # speed up test
            break
    t.close()

    t = tqdm_gui(100)
    for i in t:
        t.display()
        if i >= 20:  # speed up test
            break
    t.close()

    t = tqdm_gui(100, mininterval=0)
    for i in t:
        t.display()

# Generated at 2022-06-24 10:17:07.612385
# Unit test for function tgrange
def test_tgrange():
    import unittest
    class Test(unittest.TestCase):
        def test_tgrange(self):
            for n in tqdm.tgrange(1000):
                pass
            self.assertEqual(n, 999)
    unittest.main(__name__)

# Generated at 2022-06-24 10:17:18.092148
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Tests for tqdm_gui
    """
    from time import sleep
    from copy import copy

    # Testing the constructor
    vals = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    for i in tqdm_gui(vals):
        sleep(0.05)
    sleep(0.2)

    vals_nontotal = copy(vals)
    vals_nontotal[-1] = None
    for i in tqdm_gui(vals_nontotal):
        sleep(0.05)
    sleep(0.2)

    # Testing close
    pbar = tqdm_gui(vals)
    sleep(0.2)
    pbar.close()
    sleep(0.2)

    # Testing leave
    pbar = t

# Generated at 2022-06-24 10:17:20.452911
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Unit test for function tgrange"""
    list(tqdm_gui(tgrange(500), leave=True))


# Generated at 2022-06-24 10:17:28.063624
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .utils import FormatLabel
    assert issubclass(tqdm_gui, std_tqdm)
    assert hasattr(tqdm_gui, 'write')
    assert hasattr(tqdm_gui, 'reset')
    assert hasattr(tqdm_gui, 'close')
    assert hasattr(tqdm_gui, '__enter__')
    assert hasattr(tqdm_gui, '__exit__')
    assert hasattr(tqdm_gui, 'format_meter')
    assert hasattr(tqdm_gui, '_instances')
    assert hasattr(tqdm_gui, '_time')
    assert isinstance(tqdm_gui.format_dict, FormatLabel)
    assert hasattr(tqdm_gui, 'miniters')


# Generated at 2022-06-24 10:17:36.706837
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        # Check if matplotlib is installed
        import matplotlib.pyplot as plt
    except ImportError:
        # Skip tests if matplotlib is not installed
        return
    try:
        plt.ion()
        with tqdm(total=100, desc="Initial",
                  bar_format="{l_bar}{bar}{r_bar}") as t:
            for _ in range(5):
                t.update(10)
                t.set_description("Current: {}".format(t.n))
                t.refresh()
    finally:
        plt.close('all')

# Generated at 2022-06-24 10:17:40.040826
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from ._tqdm.tqdm import tnrange
    from time import sleep
    for n in tnrange(1, 10):
        sleep(0.1)
        if n == 5:
            break

# Generated at 2022-06-24 10:17:46.379922
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm
    import matplotlib as mpl

    t = tqdm(total=1)
    assert t.disable is False
    assert t.toolbar == 'None'
    assert mpl.rcParams['toolbar'] == 'None'
    t.close()
    assert t.disable is True
    assert t.toolbar != mpl.rcParams['toolbar']

# Generated at 2022-06-24 10:17:47.854188
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test bugfix 971"""
    tqdm_gui(total=None).close()

# Generated at 2022-06-24 10:17:58.289844
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    with tqdm_gui(total=1) as t:
        t._instances = set([t])  # force leave
        t.close()
        assert t.disable
        assert t._instances == set()
        t._instances = set([t])  # force leave
        t.disable = False  # force close
        t.close()
        assert t.disable
        assert t._instances == set()
        t._instances = set([t])  # force leave
        t.disable = False  # force close
        t.close()
        t.__dict__  # force close
        t.disable = False  # force close
        t._lock = None  # force close
        t.close()
        assert t

# Generated at 2022-06-24 10:18:08.441532
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pbar = tqdm_gui()
    assert pbar._instances == [pbar]
    pbar.close()
    assert pbar._instances == []

if __name__ == '__main__':
    from time import sleep
    import numpy as np


# Generated at 2022-06-24 10:18:16.689443
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    # with immediate=True
    with tqdm_gui(total=10) as pbar2:
        for i in range(10):
            pbar2.update()
            sleep(0.01)

    # with dynamic_ncols=True
    with tqdm_gui(total=10, dynamic_ncols=True) as pbar2:
        for i in range(10):
            pbar2.update()
            sleep(0.01)

    # with leave=False
    with tqdm_gui(total=10, leave=False) as pbar2:
        for i in range(10):
            pbar2.update()
            sleep(0.01)

    # with immediate=False

# Generated at 2022-06-24 10:18:26.426890
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close() method.

    Test that tqdm_gui.close method works properly.

    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    tolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    wasion = plt.isinteractive()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    plt.ioff()
    hspan = plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
    tqdm_gui_obj = tqdm_gui(total=100, leave=True)
    tqdm_gui_obj.close()

# Generated at 2022-06-24 10:18:30.028144
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for i in tgrange(3, desc='test tgrange'):
        sleep(0.2)
    # test tqdm.gui.tgrange(0)
    tgrange(desc='test tgrange(0)', total=0)

# Generated at 2022-06-24 10:18:31.877361
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    for i in tqdm_gui(range(100)):
        sleep(0.1)

# Generated at 2022-06-24 10:18:38.757968
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    """Test method close of class tqdm_gui."""
    import sys
    if sys.version_info[0] == 2:
        from mock import patch
        patcher = patch('matplotlib.pyplot.close')
        mock_plt_close = patcher.start()
        from matplotlib import pyplot
        mock_plt = pyplot.pyplot
        tqdm_gui(range(3)).close()
        assert mock_plt.close.call_count == 1  # pragma: no cover
        patcher.stop()

# Generated at 2022-06-24 10:18:48.278605
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit tests for method display of class tqdm_gui"""
    import copy
    import sys
    try:
        from inspect import signature
    except ImportError:
        try:
            from funcsigs import signature
        except ImportError:
            def signature(func):
                return None

    # instantiate class tqdm_gui
    g = tqdm_gui(total=None)

    # set args to test
    #  n > last_print_n
    g.n = 1
    g.last_print_n = 0
    #  cur_t > last_print_t
    cur_t = g._time()
    g.last_print_t = cur_t - 1.0
    #  total is None
    #  g.total is None
    n = g.n
    total = g.total

# Generated at 2022-06-24 10:18:58.191492
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import random
    from time import sleep
    from .utils import format_sizeof

    # Create a test data
    data = [random.randint(-0x1111111, 0x1111111) for _ in range(30)]
    # Initialize and display the progress bar
    pbar = tqdm_gui(data)
    for n, int_ in enumerate(data):
        # Check the format dictionary
        assert format_sizeof(pbar.format_dict['n'], human_readable=False) == \
            format_sizeof(n, human_readable=False)
        assert format_sizeof(pbar.format_dict['n_fmt'], human_readable=False) == \
            format_sizeof(n, human_readable=False)

# Generated at 2022-06-24 10:18:59.950746
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=3) as pbar:
        pbar.update()
        pbar.clear()

# Generated at 2022-06-24 10:19:02.496264
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=10) as gui:
        gui.close()
        gui.close()
    gui.close()
    assert gui.disable


# Generated at 2022-06-24 10:19:08.075031
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Test the tqdm_gui display method.
    """
    from .std import TqdmTypeError, TqdmKeyError, TqdmWarning
    import os, sys
    # Handle unicode output
    if sys.version_info < (3, 0):
        try:
            import codecs
            codecs.lookup('cp65001')
            os.dup2(1, 3)  # stdout -> stderr
        except (LookupError, AttributeError):
            pass
    # Minimum example
    pbar = tqdm_gui([])  # or just tqdm_gui()
    pbar.update(10)
    pbar.close()

    # Asynchronous/overlapping bars example
    import time
    import threading
    bar1 = tq

# Generated at 2022-06-24 10:19:14.036014
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    sys.path.append('.')
    from tqdm import tqdm, trange

    pbar = tqdm(trange(100), gui=True, leave=False)
    for i in pbar:
        pbar.display(**pbar.format_dict)
    pbar.close()


if __name__ == "__main__":
    try:
        test_tqdm_gui_display()
        input('Press Enter to continue...')
    except:
        print('Press Ctrl-C to stop.')

# Generated at 2022-06-24 10:19:18.012133
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    i = tqdm_gui(total=10)
    try:
        for _ in i:
            sleep(0.01)
            i.update()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:19:22.220300
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        for _ in trange(3):
            pass
    except Exception as e:
        pass
    else:
        assert False, "trange passed test_tqdm_gui_clear"
    finally:
        assert True, "tqdm_gui_clear requires XTerm 256 to pass"

# Generated at 2022-06-24 10:19:26.007049
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(1)

# test_tqdm_gui()

# Generated at 2022-06-24 10:19:34.991001
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import os
    import shutil
    from .std import TemporaryFile, _range

    with TemporaryFile(prefix='tqdm_test_', suffix='.png') as f:
        # Create tqdm_gui
        t = tqdm_gui(total=10, unit="B", unit_scale=True, unit_divisor=1024,
                     file=f, leave=False)
        for i in _range(10):
            t.update()
        shutil.copy(f.name, os.path.dirname(__file__) + '/tqdm_gui_test.png')

# Generated at 2022-06-24 10:19:42.434332
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from nose.tools import raises

    @raises(TqdmExperimentalWarning)
    def test_tgrange():
        for i in tgrange(2):
            sleep(.5)

    test_tgrange()

    @raises(TqdmExperimentalWarning)
    def test_tqdm():
        for i in tqdm(xrange(2)):
            sleep(.5)

    test_tqdm()

# Generated at 2022-06-24 10:19:49.295442
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    import time, sys

    t = tqdm_gui(total=100, unit='it')
    t.update(10)
    time.sleep(0.3)
    t.update(10)
    time.sleep(0.3)
    t.update(10)
    time.sleep(0.1)
    t.close()
    assert t.is_hidden
    plt.close()
    try:
        t.update(10)
    except:
        assert t.is_hidden
    else:
        raise "should have raised"



# Generated at 2022-06-24 10:19:56.329250
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit test for method display of class tqdm_gui
    """
    from .std import TqdmDeprecationWarning
    from .gui import tqdm_gui, trange
    from .utils import _term_move_up
    from .tests import pretest_posttest

    for n, ncols in zip([3, 2, 1], [None, 80, 40]):
        for bar_format in [None, '{l_bar}{bar:6.6}{r_bar}']:
            with pretest_posttest(ncols=ncols):
                t = trange(10, mininterval=0.1, leave=False,
                           desc='b', bar_format=bar_format, ncols=ncols)

# Generated at 2022-06-24 10:20:06.657234
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    for i in tqdm_gui(total=6, leave=True, desc="1st loop", unit="it"):
        for j in tqdm_gui(total=5, leave=True, desc="2nd loop", unit="it",
                          total=10, unit_scale=True):
            for k in tqdm_gui(total=4, leave=True, desc="3rd loop", unit="it",
                              unit_scale=True):
                sleep(0.01)
    # Use `trange` as a shortcut for `tqdm_gui(xrange(i))`
    for i in trange(3, desc='1st loop'):
        for j in trange(3, desc='2nd loop'):
            sleep(0.01)




# Generated at 2022-06-24 10:20:14.119155
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    assert list(tgrange(4)) == [0, 1, 2, 3]
    assert list(tgrange(4, 2)) == []
    assert list(tgrange(4, 12)) == [4, 5, 6, 7, 8, 9, 10, 11]
    assert list(tgrange(4, 12, 2)) == [4, 6, 8, 10]
    assert list(tgrange(12, 4, -2)) == [12, 10, 8, 6]
    assert list(tgrange(12, 4, -3)) == [12, 9, 6]

# Generated at 2022-06-24 10:20:19.666289
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui.

    Returns
    -------
    None.
    """
    t = tqdm_gui(range(100), unit='B', unit_scale=True, mininterval=0,
                 gui=False, leave=False, disable=False, position=None,
                 dynamic_ncols=False, ascii=None, **kwargs)

# Generated at 2022-06-24 10:20:21.496370
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for leave in [True, False]:
        t = tqdm_gui(range(3), leave=leave)
        t.close()

# Generated at 2022-06-24 10:20:26.166439
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Tests tqdm_gui.close()"""
    pbar = tqdm_gui(total=10)
    for i in pbar:
        pbar.n = i  # fast-forward
        pbar.display()
        sleep(0.5)
    pbar.close()


if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:20:34.178274
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase

    class _Tcase(TestCase):
        def test_tqdm_gui(self):
            from tqdm._tqdm import _range
            from tqdm.gui import tqdm_gui
            with tqdm_gui(_range(1000), ncols=50, unit_scale=0.1) as pbar:
                for i in _range(1000):
                    pbar.update(1)
                    pbar.display()

    from multiprocessing import Process, Value, Lock
    from time import sleep

    def target(i):
        sleep(0.1)

# Generated at 2022-06-24 10:20:39.693820
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from os import devnull
    from sys import stderr, stdout
    from tempfile import mkstemp
    from contextlib import contextmanager
    from io import open

    @contextmanager
    def replace_stdout_stderr():
        """Replace stdout, stderr for unit testing tqdm_gui."""
        # Save origianl file descriptors
        orig_stdout_fd = stdout.fileno()
        orig_stderr_fd = stderr.fileno()

        def _replace_stdout_stderr(to_fd):
            """Replace stdout/stderr file descriptor."""
            # Flush and close sys.stdout/sys.stderr.
            stdout.close()
            stderr.close()

            # Make original file descriptors point to devnull.


# Generated at 2022-06-24 10:20:47.155940
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    l = 4
    prev = 0
    for i in tgrange(l):
        assert i - prev == 1
        assert i < l
        prev = i
    assert i == l - 1


if __name__ == '__main__':  # pragma: no cover
    import time
    for i in tgrange(100, desc='Testing GUI', bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining},{rate_fmt}{postfix}]"):
        time.sleep(0.01)

# Generated at 2022-06-24 10:20:51.330179
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    def func1():
        return tqdm_gui(total=3)
    i = func1()
    assert len(_instances) == 1
    i.close()
    # Ensures that the instance is removed from the _instances
    assert len(_instances) == 0



# Generated at 2022-06-24 10:20:53.713400
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=1) as pbar:
        assert pbar._instances == [pbar]
        pbar.close()
        assert pbar._instances == []

# Generated at 2022-06-24 10:20:59.751029
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # clean up before tests
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    mpl.rcParams['toolbar'] = 'toolbar'
    plt.close('all')
    assert(plt.get_fignums() == [])

    # test tqdm_gui close
    t = tqdm_gui(total=10)
    t.close()
    plt.close('all')
    assert(plt.get_fignums() == [])

# Generated at 2022-06-24 10:21:01.596337
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(range(4)):
        _ = input()
        pass

# Generated at 2022-06-24 10:21:12.071996
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib
        matplotlib.use('WXAgg')
        from matplotlib import pyplot as plt
    except ImportError:
        warn("Matplotlib not found. "
             "tqdm_gui requires matplotlib to operate properly.")
        raise

    mpl = matplotlib


# Generated at 2022-06-24 10:21:20.383527
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    import matplotlib.pyplot as plt
    tpbar = tqdm_gui(total=20)
    assert tpbar.row_len == 0
    assert len(tpbar.xdata) == 0
    assert len(tpbar.ydata) == 0
    assert len(tpbar.zdata) == 0
    for _ in range(10):
        tpbar.update()
    assert tpbar.rows[0][2:] == '100%'
    assert len(tpbar.xdata) == 10
    assert len(tpbar.ydata) == 10
    assert len(tpbar.zdata) == 10
    assert tpbar.row_len == 5
    tpbar.clear()
    assert tpbar.row_len == 0

# Generated at 2022-06-24 10:21:31.254662
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest.case import TestCase

    class Display(TestCase):
        def test_display_n_inf(self):
            pbar = tqdm_gui(leave=True)
            pbar.display()
            pbar.close()

        def test_display_n_0(self):
            pbar = tqdm_gui(0, leave=True)
            pbar.display()
            pbar.close()

        def test_display_n_int(self):
            pbar = tqdm_gui(100, leave=True)
            pbar.display()
            pbar.close()

    Display().test_display_n_inf()
    Display().test_display_n_0()
    Display().test_display_n_int()

# Generated at 2022-06-24 10:21:40.139913
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import time
    from .std import sleep
    from .std import PY3

    # Create a progressbar with default options
    n = 1000
    for i in trange(n):
        sleep(1e-3)
    # Create a progressbar with specific options
    for i in trange(n, leave=True, desc='Processed',
                    unit='k', ascii=True):
        sleep(1e-3)
    # Create a progressbar with specific options
    with trange(n, miniters=1, file=open('/dev/null', 'w')) as t:
        for i in t:
            sleep(1e-3)
    # Create a progressbar with specific options
    t = trange(n, mininterval=1)
    for i in t:
        t.set

# Generated at 2022-06-24 10:21:50.849905
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import time
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        warn("matplotlib not found", TqdmExperimentalWarning, stacklevel=2)
        return

    for two_lines in (True, False):
        for leave in (True, False):
            for total in (None, 100):
                for write_mode in ("replace", "append"):
                    # Prepare
                    std_out = sys.stdout
                    sys.stdout = open('test_tqdm_gui_display.txt', 'w')
                    # Remove old test data
                    if total is not None:
                        if leave:
                            std_tqdm.write(
                                '', file=std_out, end='')

# Generated at 2022-06-24 10:21:51.411122
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pass

# Generated at 2022-06-24 10:21:54.017389
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Test function for tqdm_gui.clear"""
    gui = tqdm_gui
    gui().close()

# Generated at 2022-06-24 10:22:01.937586
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .utils import FormatCustom, FormatCustomText
    from .std import TqdmTypeError
    from os import getpid
    import time

    with open('tqdm_gui_test_%s.txt' % getpid(), 'wb') as f:
        pbar = tqdm(total=0, file=f, mininterval=0.1, ascii=True, dynamic_ncols=True)
        try:
            pbar.display()
            assert False
        except TqdmTypeError:
            pass
        pbar.update(0)
        pbar.display()
        pbar.n = 1
        pbar.display()
        pbar = tqdm(total=2, file=f, mininterval=0.1, ascii=True, dynamic_ncols=True)
       

# Generated at 2022-06-24 10:22:05.364103
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(.1)

if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:22:06.098895
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass

# Generated at 2022-06-24 10:22:08.897888
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:22:12.639044
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test clear"""
    from .gui import tqdm_gui
    from .std import TqdmKeyError
    try:
        for _ in tqdm_gui(unit="test"):
            pass
    except TqdmKeyError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 10:22:14.963403
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=100)
    t.update()
    t.update()
    t.update()
    t.update()
    t.clear()
    t.close()
    del t

# Generated at 2022-06-24 10:22:22.374437
# Unit test for function tgrange

# Generated at 2022-06-24 10:22:28.853916
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        return
    with tqdm(total=100) as pbar:
        toolbar = mpl.rcParams['toolbar']
        wasion = plt.isinteractive()
    assert toolbar == mpl.rcParams['toolbar']
    assert wasion == plt.isinteractive()