

# Generated at 2022-06-24 10:12:29.755572
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for i in tqdm_gui(range(10)):
        pass

if __name__ == '__main__':
    import time
    try:
        from time import monotonic as time
    except ImportError:
        pass
    time.sleep(0.01)
    test_tqdm_gui_close()
    time.sleep(0.01)

# Generated at 2022-06-24 10:12:31.778130
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=2)
    t.update()
    t.close()

# Generated at 2022-06-24 10:12:34.527819
# Unit test for function tgrange
def test_tgrange():
    x = list(tgrange(10))
    assert x == list(std_tqdm([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))

# Generated at 2022-06-24 10:12:43.195489
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    print(" ".join(str(n) for n in tgrange(10)))
    # and a demo of window closing
    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.25)
            pbar.update(10)

# Generated at 2022-06-24 10:12:45.875198
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=10, disable=True) as t:
        with t.external_write_mode():
            for i in range(10):
                t.write("foo" * 100 + "\n")
        t.close()

# Generated at 2022-06-24 10:12:57.045719
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Unit test for constructor of class tqdm_gui"""
    with tqdm(total=10, gui=True) as t:
        assert t.disable == False
        assert isinstance(t.mpl, type(__import__('matplotlib'))) == True
        assert isinstance(t.plt, type(__import__('matplotlib.pyplot'))) == True
        assert isinstance(t.__len__(), int) == True
        assert isinstance(t.xdata, list) == True
        assert isinstance(t.ydata, list) == True
        assert isinstance(t.zdata, list) == True
        assert isinstance(t.fig, type(__import__('matplotlib.figure'))) == True
        assert t.wasion == False

# Generated at 2022-06-24 10:12:58.917334
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:13:02.784924
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(ascii=True, total=10)
    for i in _range(10):
        t.display()
        t.update()
    t.close()

# Generated at 2022-06-24 10:13:07.051057
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    with tqdm_gui(total=10) as pbar:
        for i in _range(10):
            pbar.set_description("test")
            pbar.update()
            time.sleep(.5)
            pbar.clear()

# Generated at 2022-06-24 10:13:09.313747
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:13:16.994954
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test case for tqdm_gui"""
    import time
    from matplotlib.pyplot import close as plt_close

    # give some time to display properly the gui
    time.sleep(.5)
    t = tqdm_gui(total=100, desc="Nice", leave=True)
    for i in t:
        time.sleep(.01)
    time.sleep(.5)

    # give some time to display properly the gui
    time.sleep(.5)
    q = tqdm_gui(leave=True)
    for i in range(100):
        q.update()
        time.sleep(.01)
    time.sleep(.5)
    plt_close('all')


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:20.971597
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui, trange
    from .tests import pretest_posttest
    pretest_posttest(tqdm_gui)
    for _ in trange(4):
        for _ in trange(3):
            pass

if __name__ == "__main__":
    from .gui import tqdm_gui, trange
    for _ in trange(4):
        for _ in trange(3):
            pass

# Generated at 2022-06-24 10:13:33.061616
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for constructor of class tqdm_gui.
    """
    from time import sleep
    from numpy.random import randint
    from numpy.linalg import norm
    from itertools import combinations
    from .gui import tqdm
    assert (tqdm_gui is tqdm)
    # Test simple, 1-iteration
    with tqdm(1, disable=True) as pbar:
        pbar.update()

    with tqdm(1) as pbar:
        pbar.update()

    with tqdm(1, leave=True) as pbar:
        pbar.update()

    # Test simple, 1-iteration
    with tqdm(1, disable=True) as pbar:
        pbar.update()


# Generated at 2022-06-24 10:13:37.805588
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        t = tqdm_gui(10, gui=True)
        t.display()
        t.close()
        assert True
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        assert False


# Unit tests for tqdm_gui

# Generated at 2022-06-24 10:13:39.328162
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=1) as pbar:
        pbar.clear()

# Generated at 2022-06-24 10:13:42.309699
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
    t.close()

# Generated at 2022-06-24 10:13:53.694959
# Unit test for function tgrange
def test_tgrange():
    """Test tgrange() functionalities."""
    from .utils import _ansi_cols_len as ansi_cols_len
    from .utils import _locale_volatile as locale_volatile
    from .utils import _environ_cols_wrapper as environ_cols_wrapper

    ###############
    # Test main use cases
    for i in tgrange(4):
        pass

    with tqdm(total=10) as t:
        for i in tgrange(10):
            t.update()

    ##################
    # Test `ascii` arg
    with environ_cols_wrapper(None):
        with locale_volatile():
            # Test ascii (should not crash)
            t = tgrange(10, ascii=True)
            t.update

# Generated at 2022-06-24 10:14:01.237258
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test basic GUI
    with tqdm(total=20) as t:
        for i in range(20):
            t.update()
    # Test gui kwargs
    with tqdm(total=20, gui=True) as t:
        for i in range(20):
            t.update()
    # Test mininterval
    from time import sleep
    with tqdm(total=20, mininterval=0.01, gui=True) as t:
        for i in range(20):
            sleep(0.01)
            t.update()
    # Test no total
    with tqdm(miniters=20, mininterval=0.01, gui=True) as t:
        for i in range(20):
            sleep(0.01)
            t.update()
    # Test closing

# Generated at 2022-06-24 10:14:12.127412
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """
    Unit tests for `tqdm.gui.tqdm` method `clear`.

    This test is designed to be run from the command-line (not using `pytest`
    as it requires an active display).
    """
    from subprocess import Popen, PIPE, STDOUT, check_call
    try:
        check_call(["which", "python"])
    except:
        print("SKIP: tqdm_gui unit test (python not found)")
        return
    # Command-line for python that does not conflict with current python
    if Popen(["which", "python3"], stdout=PIPE, stderr=STDOUT).stdout.read():
        pycmd = ["python3", "-c"]

# Generated at 2022-06-24 10:14:14.226027
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=100)
    assert not t.disable
    t.close()
    assert t.disable

# Generated at 2022-06-24 10:14:22.204550
# Unit test for function tgrange
def test_tgrange():
    from .gui import trange
    from .gui import trange as trange_gui
    from .utils import _range
    for f in [trange, trange_gui]:
        for a in ["0", 1, 5]:
            for b in ["20", "30", 40]:
                for c in ["10", 20, 100]:
                    assert list(f(a, b, c)) == list(_range(a, b, c))
        for a in ["0", 1, -5]:
            for b in ["20", "30", -40]:
                assert list(f(a, b)) == list(_range(a, b))
        assert list(f(20)) == list(_range(20))

# Generated at 2022-06-24 10:14:28.661609
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from multiprocessing import Lock
    lock = Lock()
    with lock:
        t = tqdm_gui(["hi", "bye"], dynamic_ncols=True)
        assert t.l_bar == '['
        assert t.r_bar == ']'
        assert t.bar_format == '[{l_bar}|{bar}|{r_bar}]'
        assert t.disable is False
        assert t.mininterval == 0.1
        assert t.bar_template == '{desc}{percentage:3.0f}%|{bar}'
        assert t.format_dict['bar_format'] == '{l_bar}|{bar}|{r_bar}'
        assert not t._instances



# Generated at 2022-06-24 10:14:37.951459
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4):
        for j in tgrange(4):
            for k in tgrange(4):
                pass


if __name__ == '__main__':
    from time import sleep
    for i in tqdm_gui(tgrange(4), ascii=True):
        for j in tqdm_gui(tgrange(4), ascii=True, desc="jloop"):
            for k in tqdm_gui(tgrange(4), ascii=True, desc="kloop"):
                sleep(0.04)
    test_tgrange()

# Generated at 2022-06-24 10:14:44.926322
# Unit test for function tgrange
def test_tgrange():
    from sys import version_info
    from time import sleep

    try:
        tgrange(0).close()
        tgrange(1, 0).close()
    except ValueError:
        pass

    if version_info[0] >= 3:
        try:
            tgrange(1, 0, -1).close()
        except ValueError:
            pass

    q = tgrange(10)
    for i in q:
        pass
    q.close()

    q = tgrange(10)
    for i in q:
        sleep(.1)
    q.close()

    q = tgrange(10, desc="Desc", leave=True)
    for i in q:
        sleep(.1)
    q.close()


# Generated at 2022-06-24 10:14:49.382545
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui_clear"""
    import time
    import matplotlib

    # test_tqdm_gui_clear()
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            time.sleep(0.1)
    matplotlib.use('Agg')



# Generated at 2022-06-24 10:14:58.363475
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import __version__
    from .gui import tqdm_gui
    from .std import format_sizeof

    iterations = int(1e9)
    pbar = tqdm_gui(total=iterations, unit='B', unit_scale=True, position=0)

    # Pre-check
    xdata = pbar.xdata
    ydata = pbar.ydata
    zdata = pbar.zdata
    ax = pbar.ax
    line1 = pbar.line1
    line2 = pbar.line2
    xmin, xmax = ax.get_xlim()
    ymin, ymax = ax.get_ylim()
    assert xmin <= xmax
    assert 0 <= xmin < xmax
    assert ymin <= ymax
    assert 0 <= ymin < ymax

# Generated at 2022-06-24 10:15:01.646396
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # call trange to create an instance of tqdm_gui
    for i in trange(100):
        pass


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:15:04.794392
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=1) as p:
        p.close()


# Generated at 2022-06-24 10:15:08.922989
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    with tqdm_gui(total=10, leave=True) as pbar:
        for i in range(10):
            # Test if clear() call is ignored
            pbar.clear()
            pbar.update()
            time.sleep(.1)

# Generated at 2022-06-24 10:15:18.551101
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test `tqdm.gui.tqdm_gui.display()` method"""
    from numpy.testing import assert_allclose
    from time import sleep, time
    t = tqdm_gui(total=100)
    t.display(0)  # testing with 0/100
    assert_allclose(t.ax.get_ylim(), [0, 0.001])
    t.display(1000)  # testing with 1000/100
    assert_allclose(t.ax.get_ylim(), [0, 10.01])
    t.display()
    t.close()
    t = tqdm_gui(bar_format='{percentage:3.0f}% {r_bar}')
    t.display()
    t.close()

# Generated at 2022-06-24 10:15:28.499637
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import unittest
    if tqdm_gui.__doc__:
        tqdm_gui.__doc__ += ": "
    else:
        tqdm_gui.__doc__ = ""
    tqdm_gui.__doc__ += unittest.__doc__
    unittest.main('tqdm', None, [unittest.__file__, '-v'], 0)


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:15:36.708837
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from nose.tools import assert_equal
    from sys import version
    try:
        from itertools import izip
    except ImportError:
        izip = zip
    if version[0] == '2':
        assert_equal(list(tgrange(1, 5)), [1, 2, 3, 4])
        assert_equal(list(tgrange(1, 5, 3)), [1, 4])
        assert_equal(list(tgrange(1, 5, 3, 3)), [1, 4])
        assert_equal(list(tgrange(1, 5, step=3)), [1, 4])
        assert_equal(list(tgrange(1, 5, 3, -1)), [1, 4])

# Generated at 2022-06-24 10:15:47.844791
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from .gui import tqdm

    with mock.patch('sys.stderr', new_callable=mock.PropertyMock) as mock_stderr, \
            mock.patch.dict('tqdm.gui.tqdm_gui._instances', clear=True):
        tqdm([1, 2, 3])
        tqdm([1, 2, 3]).close()
        assert len(tqdm_gui._instances) == 0


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    total = 10
    with tqdm(total=total) as pbar:
        for i in range(total):
            sleep(0.01)

# Generated at 2022-06-24 10:15:48.504124
# Unit test for function tgrange
def test_tgrange():
    from .tests import test_tgrange
    test_tgrange(tgrange)

# Generated at 2022-06-24 10:15:59.430024
# Unit test for function tgrange
def test_tgrange():
    import numpy as np
    # Will create new progress bars
    with tgrange(5) as pbar:
        # Will add progress of 25% to the progress bar
        # with a time estimation of 1s
        with tgrange(5, leave=False, unit='pbar') as pbar2:
            for _ in pbar2:
                pbar.update(1)
                pbar.set_description('desc')
                pbar.set_postfix(OrderedDict(p1=1, p2='long_str'))
                # Will add progress of 50% to the progress bar
                # with a time estimation of 10s
                for _ in pbar:
                    pbar.set_postfix(OrderedDict(p1='longer_str', p2=2, p3=np.random.random()))

# Generated at 2022-06-24 10:16:03.578407
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    list(tgrange(10))
    list(tgrange(10, ncols=90))
    list(tgrange(10, desc='testing tgrange'))
    list(tgrange(10, ascii=True))
    list(tgrange(10, file=sys.stdout))

# Generated at 2022-06-24 10:16:05.860962
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            t.update()


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:09.329339
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10) as t:
        for _ in range(10):
            t.update()


# For python2.7 - 3 compatibility
try:
    FileNotFoundError
except NameError:
    FileNotFoundError = IOError


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:12.234477
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(list(range(10))):
        tqdm_gui.clear()
        tqdm_gui.write("Hello World")

# Generated at 2022-06-24 10:16:19.559559
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    import matplotlib
    import tqdm.gui
    # Test if process does not crash
    with tqdm.gui.tqdm(total=10) as t:
        for i in range(10):
            t.update()
    # Test if process does not crash
    with tqdm.gui.tqdm(total=10) as t:
        for i in range(10):
            t.update()
    # Test if process does not crash
    with tqdm.gui.tqdm(total=10) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:16:26.196468
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    with tqdm_gui() as t:
        t.total = 2
        t.update()
        t.display()
        t.close()
    plt.close()


if __name__ == '__main__':
    try:
        for i in tqdm_gui(xrange(1, 1000)):
            pass
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:16:28.360116
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=1, desc='test_tqdm_gui_close')
    t.close()

# Generated at 2022-06-24 10:16:35.600818
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        t.clear()


if __name__ == "__main__":
    import timeit
    t0 = timeit.time.time()
    # t = trange(100)
    t = tqdm(total=100)
    for i in range(100):
        timeit.sleep(0.01)
        t.update()
    t.clear()
    print(timeit.time.time() - t0)

# Generated at 2022-06-24 10:16:42.055349
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Tests that the method `display` of the class `tqdm_gui`
    doesn't crash if the input is :
    - (n=x, total=None, ncols=None)
    """
    t = tqdm_gui(ncols=None)
    t.update(x)
    t.display()
    t.close()

# Generated at 2022-06-24 10:16:52.609607
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    from tqdm._utils import _term_move_up
    from tqdm.gui import tqdm
    from time import sleep

    if sys.version_info[0] == 2:
        from itertools import izip as zip
    for n in tqdm(list(range(15)), desc="test", unit="it",
                  unit_scale=True, unit_divisor=1024):
        sleep(0.05)
    with tqdm(_range(4), desc="test", unit="it",
              unit_scale=True, unit_divisor=1024) as t:
        for n in t:
            t.set_description('test')
            sleep(0.05)

# Generated at 2022-06-24 10:16:55.936170
# Unit test for function tgrange
def test_tgrange():
    t = tgrange(3)
    t.update(1)
    assert t.n == 1
    t.update(2)
    assert t.n == 3


# Generated at 2022-06-24 10:17:00.701335
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib as mpl
        from matplotlib import pyplot as plt
        from tqdm import tqdm
        x = tqdm(total=10)
        for i in range(10):
            1+1
        x.update()
        x.close()
        assert mpl.rcParams['toolbar'] == 'toolbar2'
        assert plt.isinteractive()
        assert not x.disable
    except (ImportError, BaseException):
        # If matplotlib is not installed, there's nothing to test
        pass

# Generated at 2022-06-24 10:17:10.502708
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import time
    import numpy as np

    n = 600
    x = np.arange(n)
    t = np.random.uniform(0.1, 0.2, size=n)
    y_ = np.random.random(n)

    pg = tqdm_gui(x, miniters=1)
    for i in pg:
        y = np.roll(y_, i)
        time.sleep(t[i])
        pg.set_postfix(y=y[i])
        pg.update(t[i])
    pg.close()

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:17:13.472634
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .tests import MockWarnings, pretest_posttest

    @pretest_posttest
    def main():
        for i in tqdm(tgrange(10000), smoothing=0):
            assert i == (i + 1) - 1

    main()

# Generated at 2022-06-24 10:17:15.077727
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # TODO: add tests
    pass

# Generated at 2022-06-24 10:17:20.149478
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=100, leave=True)
    toolbars = t.mpl.rcParams['toolbar']
    t.close()
    assert t.disable == True
    assert t.toolbar == toolbars
    assert t.mpl.rcParams['toolbar'] == t.toolbar
    assert t.total == 100
    assert t.leave == True


# Generated at 2022-06-24 10:17:23.870448
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    l = list(range(10))
    t = tqdm_gui(l, bar_format='{bar}')
    assert t.__len__() == len(l)
    for x in t:
        t.set_description('{x}')
    t.close()



# Generated at 2022-06-24 10:17:28.616363
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        t = tqdm_gui(total=100)
        for _ in t:
            pass
        t.clear()
    except Exception as e:
        warn("FAILED unit test!")
        warn(str(e))
        raise



# Generated at 2022-06-24 10:17:39.465957
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test tqdm display method."""
    import numpy as np
    import time

    with tqdm_gui(total=100) as t:
        for i in range(10):
            time.sleep(0.05)
            t.update(10)

    t = tqdm_gui(unit_scale=True)
    for foo in t:
        try:
            t.set_description('Processing %s' % foo)
            t.set_postfix({'int': 42, 'float': 1.23456})
            t.update()
            raise RuntimeError
        except RuntimeError:
            time.sleep(0.1)
            t.set_postfix({'subprocess': np.random.random()**2})
        if foo == 32:
            break


# Generated at 2022-06-24 10:17:48.568788
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test clear method of tqdm_gui class"""
    from time import sleep
    from numpy import random
    from matplotlib import pyplot as plt
    try:
        t = tqdm_gui(range(100))
        for i in t:
            sleep(0.01)
            t.clear()
        t.display()
    except Exception:
        import traceback
        traceback.print_exc()
        plt.close('all')
        raise
    else:
        assert not plt.fignum_exists(t.fig.number)
    finally:
        plt.close('all')



# Generated at 2022-06-24 10:17:50.841129
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import pytest

    with pytest.raises(NotImplementedError):
        tqdm_gui(disable=True, gui=True).clear()

# Generated at 2022-06-24 10:17:56.234225
# Unit test for function tgrange
def test_tgrange():
    """Test tgrange"""
    with tqdm(total=10) as n:
        for _ in tgrange(5):
            n.update()
            time.sleep(0.5)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print("\nTesting tgrange")
    test_tgrange()

# Generated at 2022-06-24 10:18:02.780781
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test Method `close` of class `tqdm_gui`.
    """
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        return
    import time
    with tqdm(total=3, desc="Close test", leave=True) as pbar:
        for i in range(3):
            time.sleep(1)
            pbar.update()
    # check that toolbars are restored
    assert plt.rcParams['toolbar'] == "None"
    assert tqdm.toolbar == "None"
    assert pbar.toolbar == "None"

# Generated at 2022-06-24 10:18:11.505965
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .utils import FormatCustom
    from .std import tqdm_pandas

    f = FormatCustom('{n}|{bar}|{n_fmt}/{total_fmt} ({percentage:3.0f}%)')
    t = tqdm_gui(total=1000, ascii=False, bar_format=f, gui=True)
    for i in _range(10):
        t.display()
    # tqdm version
    t = tqdm_gui(total=1000, ascii=False, bar_format=f, gui=True)
    for i in _range(10):
        t.display()
    t.display(n=1000)
    t.display(n=1001)


# Generated at 2022-06-24 10:18:12.425362
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for n in tqdm_gui(range(2)):
        tqdm_gui().close()  # noqa: F841

# Generated at 2022-06-24 10:18:16.232267
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    with tqdm_gui(total=10) as bar:
        for i in tgrange(10):
            bar.update()
            time.sleep(0.05)


if __name__ == "__main__":
    from .main import main
    main()

# Generated at 2022-06-24 10:18:18.757203
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close()"""
    from .utils import _range
    t = tqdm_gui(_range(100))
    t.close()

# Generated at 2022-06-24 10:18:27.922177
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import pytest
    from cStringIO import StringIO

    f = StringIO()

    with pytest.raises(AttributeError):  # no .toolbar
        tqdm(total=5, file=f, leave=True,  disable=False).close()
    assert f.getvalue() == ''

    with pytest.raises(AttributeError):  # no .toolbar
        tqdm(total=5, file=f, leave=False, disable=False).close()
    assert f.getvalue() == ''

    with tqdm(total=5, file=f, leave=True) as pbar:
        for _ in _range(4):
            pbar.update()
        pbar.close()
    assert f.getvalue() != ''

# Generated at 2022-06-24 10:18:31.159545
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=1e9)
    assert any(t._instances)
    t.close()
    assert all(not i for i in t._instances)
    for _ in tqdm(range(10)):
        pass

# Generated at 2022-06-24 10:18:34.397788
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=0, gui=True)
    bar = t.bar_format
    t.close()
    t.close()
    assert t.bar_format == bar

# Generated at 2022-06-24 10:18:45.981784
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        import matplotlib as mpl
        mpl.use('Agg')
    except:
        pass
    from tqdm import trange
    from matplotlib.testing.decorators import cleanup
    from nose.tools import assert_raises

    @cleanup
    def test_no_plt():
        with assert_raises(AttributeError):
            with tqdm(total=10) as pbar:
                pbar.clear()
                pbar.display()
                pbar.update(10)

    @cleanup
    def test_plt():
        with tqdm(total=10) as pbar:
            pbar.clear()
            pbar.display()
            pbar.update(10)


# Generated at 2022-06-24 10:18:49.011864
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    with trange(10) as t:
        for i in t:
            sleep(0.01)
    plt.close(mpl.pyplot.gcf())

# Generated at 2022-06-24 10:18:55.310892
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    with tgrange(99) as t:
        for i in t:
            pass


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    for i in tgrange(9, desc="window name and desc"):
        sleep(.2)
    for i in trange(10):
        print(i)

# Generated at 2022-06-24 10:19:03.258891
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt

    # Save original toolbar and interactive state
    toolbar = plt.rcParams['toolbar']
    wasion = plt.isinteractive()
    # Create a new tqdm_gui object
    t = tqdm_gui(total=75)

    # Mock an update
    t.display()

    # Test closing the tqdm_gui object
    t.close()

    # Assert restoring of toolbar and interactive state
    assert plt.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion

# Generated at 2022-06-24 10:19:06.246807
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for `tqdm_gui.clear`"""
    import sys
    import time
    # Check that `tqdm_gui.clear()` doesn't fail
    try:
        with tqdm(total=1, file=sys.stdout) as pbar:
            time.sleep(0.01)
            pbar.clear()
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:19:08.001773
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    t = tqdm_gui(total=3)
    t.close()

# Generated at 2022-06-24 10:19:12.536625
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    t = tqdm_gui(total=10*10**10, leave=False)
    for i in range(10):
        t.display()
        t.update(10**10)
    plt.close(t.fig)

if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:19:19.644253
# Unit test for function tgrange
def test_tgrange():
    from .std import time
    from .std import sleep

    ans = []
    for t in trange(0, 50, 10):
        time.sleep(1)
        ans += [t]
    assert ans == list(range(0, 50, 10)), 'Wrong values'
    # still work with a float
    for t in trange(0, 50, 10.1):
        sleep(1)
    # should not raise
    trange(10, 20, 0.1, desc="test")

# Generated at 2022-06-24 10:19:30.221716
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase, main

    from .std import TqdmTypeError

    class Test_tqdm_gui_display(TestCase):
        def test_init_set_attr(self):
            # INIT_SET_ATTR
            # Instantiate _tqdm class
            _tqdm_gui = tqdm_gui(total=1000)

            # Check some attributes have been correctly set
            self.assertEqual(_tqdm_gui.mininterval, 0.5)
            self.assertEqual(_tqdm_gui.leave, False)
            self.assertEqual(_tqdm_gui.gui, True)
            self.assertEqual(_tqdm_gui.color, "green")


# Generated at 2022-06-24 10:19:42.351168
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from matplotlib.testing.decorators import image_comparison
    from unittest import TestCase

    class _Test_tqdm_gui_display(TestCase):
        def test_no_total(self):
            @image_comparison(baseline_images=['tqdm_gui_no_total'],
                              extensions=['png'])
            def _test_no_total():
                from os import devnull
                from sys import stdout
                from time import sleep

                with open(devnull, 'w') as f:
                    pbar = tqdm_gui(stdout=f, leave=False)
                    for i in range(20):
                        sleep(0.1)
                        pbar.update(1)


# Generated at 2022-06-24 10:19:47.473360
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    with tqdm(total=10) as tbar:
        for _ in _range(10):
            tbar.display()
            tbar.update()

    # And a windowed test
    plt.ion()
    plt.plot([3, 2, 1])
    plt.show()

    for i in tqdm(range(50)):
        pass

# Generated at 2022-06-24 10:19:52.073694
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib
        matplotlib.use('Agg')
    except ImportError:
        return
    t = tqdm(total=1)
    t.close()
    return True


if __name__ == '__main__':
    print("tqdm_gui module is not meant to be run by itself.")

# Generated at 2022-06-24 10:20:03.732559
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display(): # pragma: no cover
    import warnings
    warnings.simplefilter('error')
    import time
    import numpy as np
    t = tqdm(total=100)
    for i in t:
        t.display()
        time.sleep(0.5)
        t.update()
        if i == 50:
            break
    t.close()
    t = tqdm(total=None)
    for i in t:
        t.display()
        time.sleep(0.5)
        t.update()
        if i == 20:
            break
    t.close()
    t = tqdm(total=100)
    for i in t:
        t.display()
        time.sleep(0.5)
        t.update()
        if i == 20:
            t.close()
           

# Generated at 2022-06-24 10:20:06.066226
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        tqdm_gui(total=10).clear()
    except:
        raise AssertionError("Test `tqdm_gui_clear` failed!")

# Generated at 2022-06-24 10:20:10.328228
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Test if `display` method can be called multiple times
    def test():
        t = tqdm_gui([], leave=True)
        for _ in ['a', 'b', 'c']:
            t.display()
    test()
    test()

test_tqdm_gui_display()

# Generated at 2022-06-24 10:20:14.911604
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest import mock
    t = tqdm_gui(10)
    with mock.patch("matplotlib.pyplot.draw") as m:
        t.update(3)
        t.refresh()
        t.clear()
        t.refresh()
    plt.close()
    assert not m.called


# Generated at 2022-06-24 10:20:18.966033
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test that close doesn't crash and no figure is open after close.
    """
    import matplotlib.pyplot as plt
    t = tqdm(total=10)
    t.close()
    # Check that no figure is open
    assert(len(plt.get_fignums()) == 0)

# Generated at 2022-06-24 10:20:28.636443
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    # Instanciation of object tqdm_gui
    t = tqdm_gui(
        total=100, unit="foo", unit_scale=True, mininterval=0.5,
        miniters=1, maxinterval=10, miniters=1, maxinterval=10,
        leave=True, disable=False
    )
    t.start_t = 0
    t.last_print_n = 0
    t.last_print_t = 0
    _range = range
    range = _range(0, 10)
    t.start()
    n = t.n
    t.display()
    t.display()
    assert t.ax.get_xlim() == (0, 10)
    assert t

# Generated at 2022-06-24 10:20:33.473520
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=1, leave=False) as t:
        pass


if __name__ == '__main__':
    # test_tqdm_gui_close()
    print(type(tqdm()))

# Generated at 2022-06-24 10:20:36.268898
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    for _ in tqdm(total=10):
        sleep(0.1)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:20:42.146762
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from os import getpid
    tt = tqdm(iterable=range(10), desc="pid:%d" % getpid())
    for i in tt:
        # tt.write("i: %s" % i)
        sleep(i / 100)
    tt.close()
    tt.clear()
    tt.close()
    tt.clear()
    tt.close()
    tt.close()
    tt.clear()

# Generated at 2022-06-24 10:20:47.756436
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for n in tqdm_gui(10):
        pass
    # Test to make sure that close doesn't break when there is no GUI instance


"""
    from tqdm._tqdm import _main as test_tqdm_gui_close
    test_tqdm_gui_close()

    # Test to make sure that close doesn't break if the instance is not in the
    # correct position.
    test_tqdm_gui_close()
"""

# Generated at 2022-06-24 10:20:57.251477
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    assert sys.version_info[0] >= 3, "Should be python3+"

    import os
    import signal
    import threading
    from time import sleep

    from matplotlib.pyplot import show
    from .utils import _term_move_up
    from .utils import format_sizeof
    from .utils import format_interval

    os.nice(19)
    signal.signal(signal.SIGINT, lambda *args: print("\n"))

    # test tgrange()
    for i in tgrange(3):
        assert i == 0  # for coverage
        sleep(1)

    import requests
    from urllib3.util.url import parse_url


# Generated at 2022-06-24 10:21:07.393371
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import locale
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
    with tqdm_gui(total=10, unit='iB', unit_scale=True,
                  unit_divisor=1024, miniters=1, mininterval=0.1, maxinterval=1) as t:
        for i in range(10):
            t.update()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    from random import random, randint

    try:
        # noinspection PyUnresolvedReferences
        from tqdm import trange
    except ImportError:
        from tqdm.gui import trange

    # use `trange` instead of `tqdm` if and only

# Generated at 2022-06-24 10:21:13.525761
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit test for display() method of class tqdm_gui.
    """
    try:
        from matplotlib.pyplot import pause
    except ImportError:
        return

    with std_tqdm(total=10) as t:
        for i in range(10):
            t.display()
            pause(0.1)
            t.update()

# Generated at 2022-06-24 10:21:20.492501
# Unit test for function tgrange
def test_tgrange():
    from .gui import tqdm_gui as tqdm
    import sys
    import time

    for i in tqdm.tgrange(7):
        time.sleep(0.25)
    for i in tqdm.tgrange(7):
        time.sleep(0.25)
        sys.stdout.write(".")
    for i in tqdm.tgrange(7):
        time.sleep(0.25)
        sys.stdout.write("+")
        sys.stdout.flush()


# Generated at 2022-06-24 10:21:31.765288
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """ Unit test for function tgrange """
    import sys
    import time

    total = 1000000
    # Check `total` argument
    with tqdm(total=total, file=sys.stdout) as pbar:
        for i in tgrange(total):
            pbar.update()
    # Check no `total` argument
    with tgrange(total, file=sys.stdout) as pbar:
        for i in pbar:
            pass
    # Check manual control over the loop
    pbar = tgrange(total)
    for i in pbar:
        pbar.update()
    # Check `mininterval` and `miniters`

# Generated at 2022-06-24 10:21:35.905662
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4, bar_format='{l_bar}|{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]'):
        pass


if __name__ == "__main__":  # pragma: no cover
    test_tgrange()

# Generated at 2022-06-24 10:21:37.388670
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """tqdm.tqdm_gui_close()"""

    # return object of type tqdm_gui
    t = tqdm_gui(total=5)
    t.disable = False

    # return object of type tqdm_gui
    t.close()

# Generated at 2022-06-24 10:21:44.587563
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import sys
    from matplotlib.pyplot import isinteractive, ioff, ion
    ioff()
    default_interactivity = isinteractive()
    ioff()
    t = tqdm_gui(10)
    assert isinteractive()
    assert not default_interactivity
    t.close()
    assert not isinteractive()
    assert not default_interactivity
    # restore interactivity
    ion()
    # save output on win32
    sys.stdout = open(os.devnull, 'w')
    t = tqdm_gui(10, leave=True)
    assert isinteractive()
    assert not default_interactivity
    t.close()
    assert isinteractive()
    assert not default_interactivity
    # restore interactivity
    ioff()
    # save output on

# Generated at 2022-06-24 10:21:55.643572
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close(): # pragma: no cover
    from .gui import tqdm
    import sys

    assert not tqdm._instances
    with tqdm(total=1) as t:
        pass
    assert t._instances == []
    with tqdm(total=1, file=sys.stderr) as t:
        pass
    assert t._instances == []

    class IgnoreException(Exception):
        pass

    try:
        raise IgnoreException
    except:
        pass
    else:  # pragma: no cover
        t = tqdm(total=1)
        t.close()
        assert t._instances == []
        t = tqdm(total=1, file=sys.stderr)
        t.close()
        assert t._instances == []

# Generated at 2022-06-24 10:22:03.291588
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Test the ``tgrange`` function"""
    from time import sleep
    from numpy.random import random
    # test with the `range` builtin
    for _ in tgrange(1, 11, desc='range(1,11)'):
        sleep(0.01 * random())

    # test with the `xrange` builtin
    for _ in tgrange(1, 21, desc='xrange(1,21)'):
        sleep(0.01 * random())

# Generated at 2022-06-24 10:22:08.947801
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    with tqdm_gui(total=10) as t:
        l = [1, 2, 3, 4, 5] + [None] * 5
        for i, j in zip(l, t):
            time.sleep(0.01)
            t.set_description("Test %i" % j)
            t.update()
    assert t.total == 10


# Generated at 2022-06-24 10:22:17.173229
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib
    import matplotlib.pyplot as plt
    import multiprocessing as mp
    import time

    def foo():
        for _ in trange(5, desc="1st loop", leave=False):
            time.sleep(0.01)
            for _ in trange(5, desc="nested loop", leave=False):
                time.sleep(0.01)

    def bar():
        for _ in trange(5, desc="2nd loop", leave=False):
            time.sleep(0.01)

    with mp.Pool(2) as p:  # nb: multiprocessing is gui-unaware!
        p.map(foo, ('',))
        p.map(bar, ('',))

    # This should not throw an exception
    plt

# Generated at 2022-06-24 10:22:20.703982
# Unit test for function tgrange
def test_tgrange():
    import sys
    try:
        with trange(0, 100) as x:
            if sys.version_info[0] > 2:
                assert isinstance(x, range)
            else:
                assert isinstance(x, xrange)
    except Exception as e:
        raise e
    finally:
        tqdm.close()

# Generated at 2022-06-24 10:22:25.641455
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import mock
    m = mock.Mock()
    c = tqdm_gui(1, leave=False, clear_on_iter=False, mininterval=0)
    c.close = m.close
    c.display = m.display
    c.clear()
    c.close()
    assert not c.disable
    assert m.close.call_count == 1
    assert m.display.call_count == 0