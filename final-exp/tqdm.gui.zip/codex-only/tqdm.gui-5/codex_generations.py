

# Generated at 2022-06-24 10:12:37.985833
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from sys import version_info as py_version
    from random import random as rnd
    from time import sleep

    total = 1013
    t0 = tqdm(total=total, leave=False, gui=True)
    py2_or_3 = int(not py_version.major == 2)
    for _ in range(total):
        t0.update()
        sleep(rnd() / 2 ** 10)
    t0.close()

# Generated at 2022-06-24 10:12:40.822453
# Unit test for function tgrange
def test_tgrange():
    for x in tqdm_gui(tgrange(*_range(0, 4))):
        assert isinstance(x, int)
        assert x == _range(0, 4)[x]

# Generated at 2022-06-24 10:12:44.758013
# Unit test for function tgrange
def test_tgrange():
    from .utils import FormatTracker
    with FormatTracker() as ft:
        list(tqdm(tgrange(20),
                  desc="My tgrange!", unit="it", unit_scale=True))
    assert (ft.smoothed_format == " My tgrange!: 100%|██████████| 20/20 [00:00<?, ?it/s]")

# Generated at 2022-06-24 10:12:56.702249
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test the function `tqdm_gui.display`"""
    from .utils import FormatCustom, GetDistributedType, Colors, Sizeof
    from .version import __version__
    from io import StringIO

    file = StringIO()

# Generated at 2022-06-24 10:13:02.748594
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import __version__
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    from .std import tqdm_gui as std_tqdm_gui
    from .std import tgrange as std_tgrange
    from .std import tqdm_notebook as std_tqdm_nb
    from .std import tnrange as std_tnrange
    from .std import tqdm_pandas as std_tqdm_pandas
    from .std import tqdm_stdlib as std_tqdm_stdlib

    # Global variables
    _instances = std_tqdm._instances
    tqdm_BAR_DESC = std_tqdm.tqdm_BAR_DESC
    _tq

# Generated at 2022-06-24 10:13:12.387049
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from unittest.case import TestCase, skipIf
    from sys import version_info

    class TqdmTest(TestCase):

        def test_tqdm_gui(self):
            if version_info[0] != 2:
                raise unittest.SkipTest

            try:
                from matplotlib import pyplot as plt
            except ImportError:
                plt.plot([])
            fig = plt.gcf()
            ax = plt.gca()
            x, y = plt.plot([], [])
            with tqdm(total=1) as n:
                n.update(1)
            plt.close()
            self.assertTrue(not fig.canvas)
            self.assertTrue(not x)
            self.assertTrue(not y)

# Generated at 2022-06-24 10:13:13.904552
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=10)
    assert t._instances == [t]
    t.update(5)
    t.close()
    assert t._instances == []

# Generated at 2022-06-24 10:13:19.848214
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .tests import dummy_tqdm_gui
    from .tests import closing_attributes_values as cls
    dummy_tqdm_gui.disable = True
    dummy_tqdm_gui.close()
    assert dummy_tqdm_gui.toolbar == cls.toolbar
    del dummy_tqdm_gui

# Generated at 2022-06-24 10:13:32.336734
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque

    class Bunch(dict):
        """Bunch pattern"""
        def __init__(self, *args, **kwargs):
            dict.__init__(self, *args, **kwargs)
            self.__dict__ = self

    try:
        # Copy-paste from tqdm/__init__.py
        import numpy as np
    except ImportError:
        # Probably alpine or Windows
        return
    n = 1000
    try:
        # Python 3
        from time import perf_counter as time
    except ImportError:
        # Python 2 fallback
        from time import time

    # Test overall rate

# Generated at 2022-06-24 10:13:37.194318
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for i in tgrange(4):
        sleep(0.25)


# python -m tqdm.gui
if __name__ == "__main__":
    from time import sleep
    for i in tgrange(4):
        sleep(0.25)

# Generated at 2022-06-24 10:13:39.219794
# Unit test for function tgrange
def test_tgrange():
    tr = tgrange(1)
    next(tr)
    tr.close()
    with tr:
        for _ in tr:
            pass

# Generated at 2022-06-24 10:13:44.259536
# Unit test for function tgrange
def test_tgrange():
    from .gui.tests.test_tqdm_gui import test_tgrange
    test_tgrange(trange, tqdm)

if __name__ == "__main__":
    import unittest
    unittest.main()
    # test_tgrange()

# Generated at 2022-06-24 10:13:54.883904
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import pytest
    from collections import deque
    assert len(tqdm._instances) == 0
    t = tqdm_gui()
    assert len(tqdm._instances) == 1
    assert t.mpl.rcParams['toolbar'] == 'None'
    assert t.wasion
    assert len(t.xdata) == len(t.ydata)
    assert len(t.xdata) == len(t.zdata)
    assert t.xdata.__class__ is deque
    assert t.ydata.__class__ is deque
    assert t.zdata.__class__ is deque

    # Return to non-interactive mode
    t.close()
    assert len(tqdm._instances) == 0
    # Restore toolbars
    assert t.mpl.rcPar

# Generated at 2022-06-24 10:13:58.966154
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close(): # pragma: no cover
    """
    Test function for class :code:`tqdm_gui` and it's method :code:`close()`.

    """
    t = tqdm_gui(range(10))
    t.close()

# Generated at 2022-06-24 10:14:10.524781
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import _term_move_up
    from .std import __version__
    from .std import FakeGui
    from .std import _unicode

    def close_test():
        # with standard tqdm
        with tqdm(total=None) as t:
            for _ in t:
                pass
        # with tqdm_gui
        with tqdm_gui(total=None) as t:
            for _ in t:
                pass

    # test directly with tqdm_gui
    close_test()
    # test with FakeGui
    with FakeGui():
        close_test()

    # Docstring examples

# Generated at 2022-06-24 10:14:12.600275
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        with tqdm_gui(total=1) as t:
            t.close()
    except ValueError:
        pass

# Generated at 2022-06-24 10:14:20.446281
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from numpy.testing import assert_array_equal

    bar = tqdm_gui()

    bar.start_t, bar.last_print_t = 0, 0
    bar.last_print_n = 0
    bar.xdata = []
    bar.ydata = []
    bar.zdata = []
    for w in [-1, 0, 1, 1, 0]:
        bar.n = w
        bar.display()
        # Test that the update function has not crashed
        assert_array_equal(bar.xdata, bar.ydata)
        assert_array_equal(bar.ydata, bar.zdata)

# Generated at 2022-06-24 10:14:25.605559
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from numpy import random
    n = 1000
    with tgrange(n) as t:
        for i in t:
            sleep(random.rand() / 10.0)

# Generated at 2022-06-24 10:14:32.948405
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from .utils import format_dict
    from .std import _term_move_up
    from time import time
    bar_format = "{bar}{rate_fmt}{postfix}"
    with tqdm_gui(total=30,
                  mininterval=0,
                  miniters=0,
                  file=None,
                  leave=True,
                  bar_format=bar_format,
                  ascii=True) as pbar:
        pbar.set_description(format_dict['desc']('tqdm'), True)
        with open('test.txt', 'w') as fd:
            fd.write(_term_move_up())
        for i in range(15):
            pbar.update()
        pbar.reset(total=40)

# Generated at 2022-06-24 10:14:39.995900
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib
    except ImportError:
        return
    import matplotlib.pyplot as plt
    from tqdm._utils import _term_move_up

    if plt.get_backend().lower() != 'qt4agg':
        return

    # test that the GUI closes
    with tqdm(total=100) as pbar:
        for i in range(50):
            pbar.update(0)
            _term_move_up()
    # test that all instances are removed
    with tqdm(total=100) as pbar:
        assert len(pbar._instances) == 1
    assert len(pbar._instances) == 0

# Generated at 2022-06-24 10:14:49.339255
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    try:
        import pytest
        from multiprocessing import Process
        from matplotlib import pyplot as plt
    except ImportError:
        return

    try:
        from numpy import inf
    except ImportError:
        inf = float('inf')

    def f(p):
        p.display()


# Generated at 2022-06-24 10:14:56.006484
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep as stoop
    for _ in trange(4, desc="1st loop", ascii=True):
        for _ in trange(5, desc="2nd loop"):
            for _ in trange(50):
                stoop(0.01)
    # Test closing
    pbar = tqdm_gui(desc="test")
    pbar.close()
    # Test closing w/ ascii
    pbar = tqdm_gui(desc="test", ascii=True)
    pbar.close()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:00.552625
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=5, gui=True) as pbar:
        for _ in range(5):
            pbar.clear()
            pbar.update(1)


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:15:04.154601
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    A unit test for method close of class tqdm_gui.
    """

    # Create a tqdm_gui object
    t = tqdm_gui(total=10)

    # Call method close of class tqdm_gui
    t.close()

# Generated at 2022-06-24 10:15:14.542148
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    assert list(tgrange(5)) == list(_range(5))
    assert list(tgrange(2, 3)) == [2]
    assert list(tgrange(2, 5, 2)) == [2, 4]
    assert list(tgrange(6, 5, -1)) == [6, 5, 4]
    assert list(tgrange(-3, -4, -1)) == [-3]


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar

# Generated at 2022-06-24 10:15:19.919730
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def mock_stdout():
        """Mock stdout"""
        sys.stdout = StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = sys.__stdout__

    # Test display method
    with mock_stdout() as m:
        with tqdm_gui(_range(100), leave=True) as t:
            for i in _range(100):
                t.display()
                t.update()
        assert m.getvalue() == ''

    # Test in case of None total
    with mock_stdout() as m:
        with tqdm_gui(_range(100)) as t:
            for i in _range(100):
                t.display()


# Generated at 2022-06-24 10:15:32.810318
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import shutil
    import time
    from io import StringIO
    from sys import platform

    total = 100
    buf = StringIO()
    t = tqdm(total=total, file=buf)
    # Test the .display() method
    for i in range(total):
        t.display()
        time.sleep(0.01)
        t.update(1)
    # Test disabling
    t.disable = True

    # Test leave=True
    with tqdm(total=total, file=buf, leave=True) as t:
        for _ in _range(total):
            t.update(1)
            time.sleep(0.01)
    buf.seek(0)
    out = buf.read()


# Generated at 2022-06-24 10:15:41.244429
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Set the disable variable of tqdm_gui to False
    tqdm_gui.disable = False

    # Create an instance of gui_tqdm
    gui_tqdm = tqdm_gui(range(1000))
    gui_tqdm.__len__ = lambda: 100
    gui_tqdm.disable = True
    # Set the disable variable to True
    gui_tqdm.disable = True
    # Call the close() method
    gui_tqdm.close()
    # Check if disable is True
    assert gui_tqdm.disable == True

# Generated at 2022-06-24 10:15:43.123173
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(10**6):
        assert i <= 10**6
    assert i == 10**6

# Generated at 2022-06-24 10:15:49.057423
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4):
        pass
    for i in tgrange(4, 11):
        pass
    for i in tgrange(4, 11, 3):
        pass
    with tgrange(1200) as t:
        for i in tgrange(5):
            t.set_description("desc %i" % i)
            time.sleep(0.05)



# Generated at 2022-06-24 10:15:57.874515
# Unit test for function tgrange
def test_tgrange():
    """Unit test for tgrange"""
    from time import sleep
    from tqdm import tgrange
    import sys
    if sys.version_info[0] >= 3:
        from tqdm.gui import _range
    else:
        from tqdm.gui import _range as xrange

    for _ in tgrange(4):
        for _ in tgrange(5):
            for _ in tgrange(50):
                for _ in tgrange(100):
                    sleep(0.01)

if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:16:06.428814
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep

    # External variables
    t = None
    widget = None

    # Simulation of tqdm GUI (and mock of matplotlib)
    class tqdm_gui(tqdm_gui):
        def __init__(self, *args, **kwargs):
            global t, widget
            super(tqdm_gui, self).__init__(*args, **kwargs)
            t = self.total
            self.mpl = {}
            self.plt = {}
            self.fig = {}
            self.fig.canvas = {}
            self.ax = widget = {}
            self.line1 = {}
            self.line2 = {}
            self.hspan = {}
            self.toolbar = {}
            self.mpl.rcParams = {}
            self.mpl.rcParams

# Generated at 2022-06-24 10:16:10.060423
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    if __name__ == '__main__':
        from .gui import tgrange
        from time import sleep
        for i in tgrange(5, desc='foobar'):
            sleep(0.5)



# Generated at 2022-06-24 10:16:13.374535
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for _ in tqdm_gui(tgrange(8), leave=True):
        sleep(0.5)

if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:16:14.859600
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .tests import _test_gui
    _test_gui(tqdm_gui)

# Generated at 2022-06-24 10:16:16.203119
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in trange(10, leave=False):
        pass

# Generated at 2022-06-24 10:16:18.235928
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    for n in tqdm_gui(10):
        pass
    assert n == 9



# Generated at 2022-06-24 10:16:24.546530
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import warnings
    import re

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', TqdmExperimentalWarning)
        from .gui import tqdm_gui
        i = tqdm_gui(range(100))
        for j in i:
            pass

    # Close tqdm_gui
    i.close()
    # Verify that the figure has been closed
    # by checking that the string 'Figure x'
    # is not found in the string from interactive
    # mode (where x is a number)
    interactive = str(i.plt.isinteractive())
    for j in range(100):
        if re.search('Figure ' + str(j), interactive) is not None:
            break
    else:
        raise AssertionError('The figure has not been closed')

# Generated at 2022-06-24 10:16:35.776648
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from unittest import TestCase
    import numpy as np
    from sys import version_info

    class TestDisplay(TestCase):
        def setUp(self):
            self.t = tqdm_gui(total=100)

        def tearDown(self):
            self.t.close()

        def test_absolute_values(self):
            # Test display of absolute values
            self.t.total = 1000
            self.t.display()
            self.assertEqual(self.t.xdata[-1], 100.0 / 1000)

            self.t.n = 200
            self.t.display()
            self.assertEqual(self.t.xdata[-1], 200.0 / 1000)

            self.t.n = 400
            self.t.display()
           

# Generated at 2022-06-24 10:16:39.447453
# Unit test for function tgrange
def test_tgrange():
    try:
        import matplotlib
        import matplotlib.pyplot as plt
    except ImportError:
        return

    mpv = tqdm(tgrange(20, 30), miniters=2)
    for i in mpv:
        plt.pause(0.01)
    mpv.update(30)

# Generated at 2022-06-24 10:16:43.405033
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=1) as t:
        t.close()
        assert t.disable

    with tqdm(total=1, leave=True) as t:
        t.close()
        assert t.disable

# Generated at 2022-06-24 10:16:44.730446
# Unit test for function tgrange
def test_tgrange():
    assert list(tgrange(9)) == list(_range(9))

# Generated at 2022-06-24 10:16:54.541581
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    for disable in [False, True]:
        for leave in [False, True]:
            try:
                plt.close()
            except:
                pass
            try:
                plt.figure(1)
            except:
                plt.figure()
            fig = plt.gcf()
            fig.canvas.start_event_loop = lambda x: None
            fig.canvas.stop_event_loop = lambda x: None
            t = t

# Generated at 2022-06-24 10:17:05.090992
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    t = tqdm_gui(total=100)
    for i in range(50):
        t.update()
        sleep(0.02)
    t.close()
    assert t.disable
    assert t.mpl.rcParams['toolbar'] == 'None'
    assert not t.plt.isinteractive()
    assert t.wasion


# if __name__ == "__main__":
#     import sys
#     try:
#         total = int(sys.argv[1])
#     except:
#         total = 100
#     with tqdm(total=total, unit="B", unit_scale=True, unit_divisor=1024) as t:
#         for i in range(total + 1):
#             sleep(0.01)
#             t

# Generated at 2022-06-24 10:17:11.847148
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit tests for tqdm_gui display function
    """
    # Check that display function does not throw exceptions
    t = tqdm_gui(total=None, disable=True)
    t.display()
    t = tqdm_gui(total=None, disable=False)
    t.display()


if __name__ == '__main__':
    from .gui import _test_gui
    _test_gui()

# Generated at 2022-06-24 10:17:21.620943
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    a = tqdm_gui(range(5))
    assert(repr(a) == "<tqdm_gui [0/5]>")

    b = tqdm_gui(range(5), leave=True)
    assert(repr(b) == "<tqdm_gui [0/5]>")

    c = tqdm_gui(range(5), leave=False)
    assert(repr(c) == "<tqdm_gui [0/5]>")

    d = tqdm_gui(range(5), leave=True, disable=True)
    assert(repr(d) == "<tqdm_gui [0/5]>")

    e = tqdm_gui(range(5), leave=False, disable=True)

# Generated at 2022-06-24 10:17:28.552615
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep, time
    from numpy import array, linspace

    t = time()
    with tqdm_gui(total=100, unit_scale=True) as pbar:
        for i in linspace(0, 30, 31):
            sleep(0.01)
            if i == 0:
                xdata = array([0, 1 * 100.0 / 100, 2 * 100.0 / 100, 3 * 100.0 / 100,
                               4 * 100.0 / 100, 5 * 100.0 / 100, 6 * 100.0 / 100,
                               7 * 100.0 / 100, 8 * 100.0 / 100, 9 * 100.0 / 100])

# Generated at 2022-06-24 10:17:39.380774
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .utils import _unittest_range
    from .std import tqdm

    with tqdm(2) as t:
        next(t)
        t.set_description("testing")
        assert(t.n == 1)

    with tqdm(tgrange(2), ncols=70) as t:
        next(t)
        t.set_description("testing", True)
        assert(t.n == 1)

    with tqdm(tgrange(2), ncols=70) as t:
        list(t)  # consuming iterator
        t.set_description("testing", True)
        assert(t.n == 2)


# Generated at 2022-06-24 10:17:50.176586
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .utils import _range
    from .std import format_dict, format_meter
    from .std import TqdmDeprecationWarning
    warn("The GUI progressbar is experimental for now!", TqdmDeprecationWarning)
    t = tqdm_gui(_range(30000),
        desc='test_g', unit='c',
        unit_scale=False, leave=False,
        mininterval=0.1, miniters=1,
        maxinterval=0.1, maxiters=1)
    for _ in _range(30):
        t.update(1000)
    i = 0
    for i, _ in enumerate(t):
        pass
    d = t.format_dict
    d['bar_format'] = (t.format_dict['bar_format'] or '{bar}')


# Generated at 2022-06-24 10:17:56.493408
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui

# Generated at 2022-06-24 10:17:57.890244
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pbar = tqdm_gui(total=100)
    pbar.close()
    assert pbar.disable

# Generated at 2022-06-24 10:18:03.763927
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with tqdm_gui(total=10, unit='test', unit_scale=True, dynamic_ncols=True) as t:
        for i in range(10):
            t.update()


if __name__ == '__main__':
    from .version import _version as __version__
    from .gui import _notebook as __notebook__

    # test
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:18:05.833648
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        a = tqdm(range(5))
        a.close()
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:18:10.701112
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(iter(range(10)), desc='testing', unit='it'):
        pass
    for i in tqdm_gui(iter(range(10)), desc='testing', unit='it', total=10):
        pass


if __name__ == "__main__":
    try:
        test_tqdm_gui()
    except KeyboardInterrupt:
        print('Thanks for using tqdm')

# Generated at 2022-06-24 10:18:14.322648
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    for i in tqdm_gui(range(100)):
        time.sleep(0.05)

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:18:18.308911
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pbar = tqdm_gui(total=100)
    pbar.update(50)
    assert pbar.n == 50
    pbar.clear()
    pbar.display(force=True)
    assert pbar.n == 50

# Generated at 2022-06-24 10:18:24.085486
# Unit test for function tgrange
def test_tgrange():
    try:
        for i in tgrange(4, 5):
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        plt.close('all')


if __name__ == '__main__':
    try:
        test_tgrange()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        plt.close('all')

# Generated at 2022-06-24 10:18:34.010875
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    import sys
    try:
        plt.ion()
        t = tqdm_gui(total=100, mininterval=0.1)
        for i in range(0, 101, 5):
            t.display()
            # Next lines are used to make the graphes more "interesting"
            t.total = np.random.randint(100, 1000)
            t.mininterval = np.random.rand() * i / 100
            plt.pause(0.005)
        t.close()
        plt.ioff()
    except (KeyboardInterrupt, SystemExit):
        print('Passed!')
        sys.exit(0)
    print('Error!')
    sys.exit(1)



# Generated at 2022-06-24 10:18:35.754791
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .tests.gui_test import tqdm_gui_display
    tqdm_gui_display()

# Generated at 2022-06-24 10:18:38.665181
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import _decompose
    with trange(10) as t:
        for i in t:
            _decompose(i / 10)
            t.clear()

# Generated at 2022-06-24 10:18:48.205446
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # get ready for ctypes.windll.kernel32.SetConsoleCP(0)
    import os
    os.getcwd()

    from time import sleep
    from numpy.random import randint
    from numpy import mean, median
    from .utils import format_sizeof

    with tqdm(total=5) as pbar:
        for i in range(5):
            pbar.update()
            sleep(0.5)

    with tqdm(total=lambda: 100) as pbar:
        for i in range(100):
            pbar.update()
            sleep(0.02)

    with tqdm(total=25, miniters=10) as pbar:
        for i in range(25):
            pbar.update()
            sleep(0.02)

# Generated at 2022-06-24 10:18:58.121315
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    from io import StringIO
    from time import sleep
    from .std import tqdm

    f = StringIO()
    with tqdm(total=2, file=f, gui=True) as pbar:
        pbar.display()
        assert sys.stderr.write("\x1b[?25h")
        sleep(1)
        sys.stderr = StringIO()
        pbar.update()
        pbar.clear()
        assert pbar.disable
        assert pbar.disable == pbar.miniters
        pbar.update()
        pbar.clear()
        assert sys.stderr.getvalue() == ""
# Testing
if __name__ == '__main__':
    r = trange(100)

# Generated at 2022-06-24 10:19:08.090738
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .std import TqdmKeyError, TqdmTypeError
    from .std import tqdm as std_tqdm
    from .utils import _range

    try:
        tqdm(total=None)
        tqdm(10, total=None)
        tqdm(total=None, position=2)  # Already tested in test_tqdm_std
    except TqdmKeyError:
        pass
    except (ValueError, TqdmTypeError):
        try:
            tqdm()
            tqdm(10)
            tqdm(position=2)  # Already tested in test_tqdm_std
        except (ValueError, TqdmTypeError):
            pass

    # Basic
    tqdm_gui().clear()
    tqdm_

# Generated at 2022-06-24 10:19:17.321916
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(0, 0, 1, total=None)
    t.display()
    assert (t.ax.get_ylim() == (0, 0.001))
    assert (t.xdata == [0])
    assert (t.ydata == [0])
    assert (t.zdata == [0])
    t.update(1)
    t.display()
    assert (t.ydata == [0, float('inf')])
    assert (t.zdata == [0, float('inf')])
    t.update(1)
    t.display()
    assert (t.ydata == [0, float('inf'), 1])
    assert (t.zdata == [0, float('inf'), 1])

# Generated at 2022-06-24 10:19:23.419304
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    class FakeTqdm(tqdm_gui):
        """Patch bars parent class"""
        def __init__(self):
            self.disable = False
            self.last_print_n = self.last_print_t = None

# Generated at 2022-06-24 10:19:35.138526
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test tqdm_gui display method."""
    import copy
    import sys
    import threading
    import time

    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .tqdm import TqdmTypeError

    try:
        tqdm_gui.clear()
    except Exception:
        pass
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmDeprecationWarning)
        with tqdm_gui(total=10) as pbar:
            pbar.update(1)
            pbar.close()
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)

# Generated at 2022-06-24 10:19:43.314271
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    import numpy as np
    try:
        counter = tqdm_gui(range(100))
        for i in counter:
            time.sleep(0.01)
    except:  # pragma: no cover
        print("User closed plot")
        counter = tqdm_gui(range(100))
        for i in counter:
            time.sleep(0.01)
    else:
        counter = tqdm_gui(range(100))
        for i in counter:
            time.sleep(0.01)


# Generated at 2022-06-24 10:19:51.226025
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        with tqdm_gui(total=2) as t:
            for i in range(5):
                t.update()
                t.clear()
    except AttributeError:
        pass  # expected error
    else:
        assert False  # NOQA


if __name__ == "__main__":
    import time
    from .std import tqdm

    # Define a callback function
    def callback(x, y=0, **attrs):
        print("{}: {}{}".format(x, y, attrs))


# Generated at 2022-06-24 10:19:56.514902
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test method display of class tqdm_gui"""
    from time import sleep

    n = 42
    t = tqdm_gui(total=n)
    for i in range(n):
        assert t.n == i + 1
        sleep(0.002)
        t.display()
        assert t.n == i + 1

# Generated at 2022-06-24 10:20:00.691547
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from os import getpid
    from time import sleep

    with tqdm_gui(total=100) as pbar:
        for _ in range(100):
            pbar.set_description('%04i' % getpid())
            pbar.update()
            sleep(0.01)

# Generated at 2022-06-24 10:20:09.280670
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from numpy import allclose
        from numpy.random import random
        from unittest.mock import Mock
        import matplotlib.pyplot as plt
    except ImportError:
        return

    # Create mock axes object

# Generated at 2022-06-24 10:20:16.462966
# Unit test for function tgrange
def test_tgrange():
    """Unit tests for function tgrange"""
    from .gui import trange
    from nose.plugins.skip import SkipTest
    # GUI stuff is not available on all platforms
    from sys import platform
    if platform.startswith("win") or platform.startswith("linux"):
        try:
            with trange(2) as t:
                for i in t:
                    assert i < t.total
            raise SkipTest
        except ImportError:
            pass
    else:
        raise SkipTest

# Generated at 2022-06-24 10:20:20.755897
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from numpy.random import random
    for i in tgrange(10, desc='test tgrange'):
        sleep(random() / 10)

if __name__ == "__main__":
    test_tgrange()
    # show() not needed if using IPython

# Generated at 2022-06-24 10:20:23.258302
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=10)
    try:
        for i in range(10):
            t.update(1)
    finally:
        t.close()

# Generated at 2022-06-24 10:20:25.744013
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .tests import _test_iterable

    _test_iterable(tgrange(7), "tgrange(7)", **{"miniters": 1})



# Generated at 2022-06-24 10:20:33.913887
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    '''See https://github.com/tqdm/tqdm/issues/831'''
    import numpy as np

    n = 1000
    x = np.random.rand(n)
    y = np.zeros(n)
    z = np.zeros(n)

    for i in tqdm(range(n), total=n):
        y[i] = np.mean(x[:i])
        z[i] = np.std(x[:i])

# def test_gui_stdout():
#     from .utils import _decompose
#     from .std import tqdm_pandas
#     from sys import stdout, executable
#     from subprocess import Popen
#     import time
#     p = Popen([executable, "-c",
#                "from t

# Generated at 2022-06-24 10:20:38.113231
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Test correctness of method display of class tqdm_gui.
    """
    gui = tqdm_gui(total=100, leave=False)
    gui.update(8)

    try:
        gui.display()
    except Exception as e:
        raise e
    finally:
        gui.close()

# Generated at 2022-06-24 10:20:48.356081
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.testing.decorators import cleanup
    import os

    @cleanup
    def test(total, leave, dynamic_ncols, ncols, unit, unit_scale, mininterval,
             miniters, n_samples, **kwargs):
        from time import sleep
        from numpy import argmax

        try:
            from IPython import get_ipython as ipython
        except ImportError:  # pragma: no cover
            ipython = lambda: None

        if n_samples < 501:
            n_samples = 500

        # Ignore the following user warnings:
        # - Matplotlib is currently using agg, which is a non-GUI backend, thus
        #   cannot show the figure.
        # - Mat

# Generated at 2022-06-24 10:20:50.556915
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .tests import test_tqdm_gui_clear

    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:20:59.538991
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import sys
    from io import StringIO
    from matplotlib import pyplot as plt
    plt.rcParams['toolbar'] = 'None'
    class PrintCatcher(StringIO):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            sys.stdout = self._stdout
            self._stdout = None

    with PrintCatcher() as p:
        g = tqdm(total=1000)
        for i in range(1000):
            g.update(1)
        g.display()

    with PrintCatcher() as p:
        g = tqdm(total=None)

# Generated at 2022-06-24 10:21:06.761159
# Unit test for function tgrange
def test_tgrange():
    import sys

    # Mock stdout and stderr
    _stderr = sys.stderr
    _stdout = sys.stdout
    sys.stderr = sys.stdout = open("/dev/null", "w")

    from time import sleep

    try:
        for i in tgrange(4):
            sleep(0.1)
    except KeyboardInterrupt:
        import os
        os._exit(0)
    finally:
        # Restore stdout and stderr
        sys.stderr = _stderr
        sys.stdout = _stdout