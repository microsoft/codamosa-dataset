

# Generated at 2022-06-24 10:12:29.084715
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    with tqdm_gui(total=1) as t:
        assert len(t._instances) == 1
        gc.collect()
        t.close()
        gc.collect()
        assert len(t._instances) == 0

# Generated at 2022-06-24 10:12:35.701849
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    *_, ax = plt.subplots()
    assert isinstance(tqdm_gui(total=1, position=0, miniters=0,
                               desc='a', disable=False, unit='b',
                               unit_scale=False, dynamic_ncols=False,
                               leave=True,
                               ax=ax),
                      tqdm_gui)
    plt.close('all')

# Generated at 2022-06-24 10:12:38.054685
# Unit test for function tgrange
def test_tgrange():
    for _ in trange(10):
        pass

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:12:41.505129
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    try:
        t = tqdm_gui(range(10))
        t.clear()
        t.write()
    except BaseException as e:
        print(e)
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:12:45.948497
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    x = tqdm_gui(total=None, unit='B', unit_scale=True, miniters=None,
                 leave=False)
    x.start()
    import time
    for i in _range(60):
        x.update(i)
        time.sleep(1)
    x.close()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:12:52.281381
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .std import time
    # time.sleep is required to see the updates,
    # and we need to use a higher miniters in GUI
    # mode to have the windows time to process it
    for i in trange(100, miniters=20):  # total=100):
        time.sleep(.01)
        # Update the progressbar
        # (with fake data, of course)
        tqdm.write('Foobar')
        tqdm.write(str(i))

# Generated at 2022-06-24 10:13:02.897745
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Dummy range object
    class DummyRange(object):
        def __init__(self):
            self.curr = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.curr == 100:
                raise StopIteration
            self.curr += 1
            return self.curr

        def next(self):
            return self.__next__()

    # Create an instance of the tqdm_gui class
    test = tqdm_gui(DummyRange(), desc="dummy")
    # Call the method to test
    test.clear()
    # Check that the bar is properly cleared
    assert test.last_print_n == 0

# Generated at 2022-06-24 10:13:12.183684
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    with tqdm_gui(total=None, leave=False) as t:
        for _ in range(60):
            t.update(1)
            t.set_postfix({"a": t.n, "b": t.rate})
        plt.pause(0.5)
    with tqdm_gui(total=200) as t:
        for _ in range(200):
            t.update(1)
            t.set_postfix({"a": t.n, "b": t.rate})
        plt.pause(0.5)
    for _ in range(60):
        with tqdm_gui(total=None, leave=False) as t:
            t.update(1)
            t.set_

# Generated at 2022-06-24 10:13:16.698453
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock
    import matplotlib as mpl
    from .gui import tqdm
    # Matplotlib GUI is not tested:
    # - it is an external dependency
    # - it is not installed on CI
    with mock.patch.object(tqdm_gui, 'mpl', new=mpl):
        # method clear of class tqdm_gui should not raise an error
        tqdm(total=5).clear()


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:13:25.039195
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    try:
        import matplotlib
        import matplotlib.pyplot as plt
    except ImportError:
        return  # matplotlib not installed
    matplotlib.rcParams['toolbar'] = ""
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # create a tqdm instance
    tqdm(total=10).close()
    assert plt.isinteractive() == wasion
    # close interactive environment
    plt.ioff()

# Generated at 2022-06-24 10:13:37.272536
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    try:
        # check if GUI is available
        import Tkinter as tk
    except ImportError:
        return
    try:
        plt.figure()
        plt.plot(list(range(4)))
        plt.gca()
    except Exception as exc:
        warn(str(exc) + " with matplotlib backend: "
             + repr(plt.get_backend()) + ". TqdmDeprecationWarning")
        return

# Generated at 2022-06-24 10:13:43.842889
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import platform
    from os import remove
    from os.path import isfile
    from time import sleep

    tqdm_gui.write = tqdm_gui._write
    tqdm_gui.close()
    tqdm_gui.clear()

    def get_fig_num():
        return tqdm_gui.plt.get_fignums()[-1]

    if platform == 'darwin':
        SCREENSHOT_PATH = "/tmp/tqdm_gui_test_screenshot_{0}.png"
    else:
        SCREENSHOT_PATH = "C:\\temp\\tqdm_gui_test_screenshot_{0}.png"

    with tqdm_gui(total=100) as t:
        t.display()
        sleep(0.2)
        fig

# Generated at 2022-06-24 10:13:54.776272
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import unittest
    import mock
    import os

    class TestDisplay(unittest.TestCase):
        """Unit test for method display of class tqdm_gui"""

        def setUp(self):
            # Unit test for each method
            from .gui import tqdm_gui, tqdm

            self.t = self.tqdm = tqdm_gui(
                total=100, leave=True, desc="TestDisplay")
            self.tqdm.start_t = 20
            self.tqdm.last_print_n = 10
            self.tqdm.last_print_t = 20
            self.t.set_description("Unit test for method display of class tqdm_gui")
            # set self.n = 100 to call self.close()

# Generated at 2022-06-24 10:14:00.455352
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from io import StringIO

    with StringIO() as our_file, tqdm_gui(total=10,
                                          file=our_file,
                                          leave=False) as t:
        for _ in range(10):
            sleep(0.01)
            t.update()


if __name__ == '__main__':
    test_tqdm_gui_close()
    input("Press Enter to continue...")

# Generated at 2022-06-24 10:14:06.842593
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Test the method tqdm_gui.display.

    Checks that the method tqdm_gui.display
    does not create an infinite loop.
    """
    import time
    from .auto import tqdm

    for _ in tqdm(range(10)):
        time.sleep(0.1)

# Generated at 2022-06-24 10:14:17.431609
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    assert list(tgrange(5)) == [0, 1, 2, 3, 4]
    assert list(tgrange(0, 5)) == [0, 1, 2, 3, 4]
    assert list(tgrange(0, 6, 2)) == [0, 2, 4]
    assert list(tgrange(0, 3, 0.5)) == [0.0, 0.5, 1.0, 1.5, 2.0, 2.5]

# Generated at 2022-06-24 10:14:25.893920
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from ._utils import _decode_bytes
    from .gui import trange

    widgets = ['\n', 'Test: ', tqdm.Counter(), '/', str(10), ' ',
               tqdm.Timer(), ' ', tqdm.AdaptiveETA(), ' ',
               tqdm.AdaptiveTransferSpeed(),
               ]

    t = trange(10, miniters=0, mininterval=0.1,
               maxinterval=0.1, ascii=True,
               widgets=widgets, desc='Test')
    for i in t:
        _decode_bytes(i)
        t.update()


# Generated at 2022-06-24 10:14:29.006757
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm
    from time import sleep
    for i in tqdm(["a", "b", "c", "d"]):
        sleep(0.06)
    tqdm.clear()

# Generated at 2022-06-24 10:14:36.580950
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    import matplotlib.pyplot as plt

    try:
        for i in tqdm_gui(range(10)):
            time.sleep(0.1)
    finally:
        plt.close()

    try:
        for i in tqdm_gui(range(10), leave=True):
            time.sleep(0.1)
    finally:
        plt.close()



# Generated at 2022-06-24 10:14:37.829367
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    for i in trange(5):
        sleep(0.01)


# Generated at 2022-06-24 10:14:49.662311
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep, time
    from unittest import TestCase, TestLoader, TextTestRunner
    from unittest.mock import patch

    class Tqdm_gui_clear(TestCase):
        """
        Does clear() do anything on progressbar and axes?
        """
        def test(self):
            sentinel = object()

# Generated at 2022-06-24 10:14:51.657717
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Check that clear() do not raise error, especially when called twice
    t = tqdm_gui.__init__()
    t.clear()
    t.clear()

# Generated at 2022-06-24 10:14:53.842145
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    progress_bar = tqdm_gui(total=100)
    progress_bar.close()

# Generated at 2022-06-24 10:15:03.531740
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from multiprocessing import Process
    import sys
    if sys.version_info >= (3, 0):  # pragma: no cover
        range = _range
    else:  # pragma: no cover
        range = xrange

    def test_clear(total=200):
        try:
            pbar = tqdm_gui(total=total)
            for i in range(total):
                pbar.update()
                if not i % 5:
                    pbar.clear()
        except KeyboardInterrupt:
            pbar.clear()
            print("\nexit")
            sys.exit(0)

    try:
        p = Process(target=test_clear)
        p.start()
        p.join()
    except KeyboardInterrupt:
        print("\nexit")

# Generated at 2022-06-24 10:15:06.256063
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for i in tgrange(4):
        # Do stuff
        sleep(0.5)


# Generated at 2022-06-24 10:15:09.599230
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    for i in tqdm_gui(range(50), unit="s", leave=False):
        sleep(0.02)

if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:15:19.091504
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_raises
    from io import StringIO
    from sys import stderr, stdout
    import matplotlib as mpl
    mpl.use('Agg')
    from matplotlib import pyplot as plt
    from .utils import _decr
    # StringIOs to fake stdout and stderr
    sout = StringIO()
    serr = StringIO()
    # Save original references to stdout and stderr
    old_sout, old_serr = stdout, stderr

# Generated at 2022-06-24 10:15:24.227221
# Unit test for function tgrange
def test_tgrange():
    # trivial case
    for _ in tgrange(int(1e6)):
        pass

    # trivial case
    for _ in tgrange(1, int(1e6)):
        pass

# Generated at 2022-06-24 10:15:27.650511
# Unit test for function tgrange
def test_tgrange():
    tgrange(10)
    with tgrange(10) as t:
        for _ in t:
            pass


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:15:30.312593
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10, desc="gui") as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:15:38.109271
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for the method clear of class tqdm_gui.

    It tests the following cases:
    0. simple call of clear method
    1. simple call of clear method with *args
    2. simple call of clear method with **kwargs
    3. simple call of clear method with *args, **kwargs
    """
    from tqdm import gui

    pbar = gui.tqdm()
    for i in pbar:
        pbar.clear()
        if i == 1:
            break

    pbar = gui.tqdm()
    for i in pbar:
        pbar.clear(1, 2)
        if i == 1:
            break

    pbar = gui.tqdm()

# Generated at 2022-06-24 10:15:48.797840
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test the method tqdm_gui.clear.
    """
    # this test is only useful on Travis, otherwise it counts the number
    # of tests in the current directory
    from .std import _is_running_from_notebook, __IPYTHON__
    if _is_running_from_notebook() or __IPYTHON__ is None:
        return
    import multiprocessing
    for i in range(2):
        try:
            multiprocessing.set_start_method('spawn')
            break
        except RuntimeError:
            continue
    from multiprocessing import Pool
    from .std import _PY3
    from .std import tqdm as std_tqdm
    try:
        from queue import Queue
    except ImportError:
        from Queue import Queue
   

# Generated at 2022-06-24 10:15:50.770974
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pbar = tqdm_gui(total=2, leave=False)
    pbar.update(1)
    pbar.close()

# Generated at 2022-06-24 10:15:55.478014
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import trange
    for i in trange(1000):
        pass


if __name__ == '__main__':  # pragma: no cover
    from .gui import trange
    for i in trange(100):
        pass

# Generated at 2022-06-24 10:15:56.880354
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tgrange(10):
        pass
    print('done')

# Generated at 2022-06-24 10:16:01.824467
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .utils import format_interval, format_sizeof
    from .utils import TqdmDeprecationWarning
    from .utils import _supports_unicode

    # Tests
    with tgrange(4) as t:
        for i in t:
            pass

    # Checks
    assert t.disable == True
    assert t.n == 4



# Generated at 2022-06-24 10:16:05.448231
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test for the clear method of class tqdm_gui."""
    from .std import tqdm_gui as tqdm
    t = tqdm(total=10, unit="test", disable=True)
    t.clear()
    assert True

# Generated at 2022-06-24 10:16:14.215846
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from multiprocessing import current_process
    n = 5
    p = current_process()
    with tqdm_gui(n) as t:
        assert t.gui is True, t.gui
        assert t.disable is False, t.disable
        assert t.gui_isopen is True, t.gui_isopen
        for i in range(n):
            sleep(0.1)
            t.update()
    assert t.disable is True, t.disable


if __name__ == "__main__":
    r = test_tqdm_gui()
    print('Test success' if r is None else 'Test failure: '+str(r))

# Generated at 2022-06-24 10:16:23.931611
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _range, FormatCustomText
    from .utils import format_interval, format_number, format_meter
    from .std import TqdmDefaultWriteOffset
    from .std import tqdm
    import os


# Generated at 2022-06-24 10:16:35.200943
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import TqdmDeprecationWarning
    import matplotlib as mpl
    mpl.use('TkAgg')

    with tqdm(total=100) as progress:
        progress.display()
        progress.update()

    with tqdm(total=100) as progress:
        progress.display()
        progress.update()

    with tqdm(total=100) as progress:
        progress.display()
        progress.update()

    with tqdm(total=100, leave=True) as progress:
        progress.display()
        progress.update()

    # Test for deprecation wrapper
    with tqdm(total=100, unit=1, dynamic_ncols=True) as progress:
        try:
            progress.update_to(10)
        except TypeError:
            pass


# Generated at 2022-06-24 10:16:40.806315
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        with tqdm_gui(total=3) as pbar:
            pbar.update()
            pbar.clear()
            pbar.update()
            pbar.clear()
            pbar.update()
    except Exception as e:
        raise AssertionError("Exception: %s" % str(e))

# Generated at 2022-06-24 10:16:51.059822
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for method 'close' of class tqdm_gui"""
    import time
    import sys
    import matplotlib.pyplot as plt

    # test closing the progress bar inside the loop
    for i in tqdm(range(100)):
        time.sleep(0.01)
        if i >= 10:
            tqdm.close()

    # tqdm.close()
    # assert len(plt.get_fignums()) == 0

    # test closing the progress bar outside the loop
    for i in tqdm(range(100)):
        time.sleep(0.01)

    tqdm.close()
    assert len(plt.get_fignums()) == 0

    # test closing the progress bar outside the loop with an exception

# Generated at 2022-06-24 10:16:58.120179
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange.
    """
    from .std import term_move_up

    for i in tgrange(4, 10, 0.1):
        term_move_up()


if __name__ == "__main__":  # pragma: no cover
    from .std import term_move_up

    for i in tgrange(4, 10, 0.1):
        term_move_up()

# Generated at 2022-06-24 10:17:09.511673
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    import sys
    import time
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation

    def update_line(num, data, line):
        line.set_data(data[..., :num])
        return line,

    fig = plt.figure()
    data = [0, 1, 2]
    l, = plt.plot([], [], 'r-')
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.xlabel('x')
    plt.title('test')
    line_ani = animation.FuncAnimation(fig, update_line, 1,
                                       fargs=(data, l),
                                       interval=50, blit=True)
    plt.show()


# Generated at 2022-06-24 10:17:19.391415
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Main script"""
    import time

    with tqdm_gui(unit='i', total=2) as pbar:
        pbar.clear()
        for i in _range(2):
            pbar.update(1)
            time.sleep(0.5)

    for i in tqdm_gui(total=4):
        time.sleep(0.5)
        if i == 1:
            tqdm_gui.clear()
        tqdm_gui.display()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_clear()
    # test_tqdm_gui_close()

    # TODO: write() on GUI?
    # @classmethod
    # def write(cls, msg, file=None):
    #     """

# Generated at 2022-06-24 10:17:27.438680
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    try:
        import matplotlib as mpl
        if mpl.get_backend() == 'Agg':
            raise ImportError()
    except ImportError:
        return
    import matplotlib.pyplot as plt
    from .gui import tqdm_gui
    from .utils import _range, format_interval

    try:
        input = raw_input
    except NameError:
        pass

    # All the tqdm kwargs for the progressbar

# Generated at 2022-06-24 10:17:32.015196
# Unit test for function tgrange
def test_tgrange():
    list(tgrange(3))
    import matplotlib as mpl
    assert mpl.rcParams['toolbar'] == 'None'
    list(tgrange(3))
    assert mpl.rcParams['toolbar'] == 'None'


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:17:42.238197
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for `tqdm_gui`."""
    from tqdm.gui import tqdm
    from .version import __version__
    from .utils import _supports_unicode, _environ_cols_wrapper
    with _environ_cols_wrapper():  # TODO: check to remove
        if _supports_unicode():
            tgr = tgrange(10)
            tgr.close()
            tgr = tgrange(10)
            tgr.leave = True
            tgr.close()
        else:
            tgr = tgrange(10)
            tgr.close()
            tgr = tgrange(10)
            tgr.leave = True
            tgr.close()
        tg = tqdm(10, leave=True)
        tg.close

# Generated at 2022-06-24 10:17:50.684787
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui
    from unittest.mock import patch

    with patch('tqdm.gui.tqdm_gui.plt.pause') as mp:
        # only test if line1 and line2 have been updated
        # total=100, leave=False
        t = tqdm_gui(total=100, leave=False)
        n = t.n
        cur_t = t._time()
        elapsed = cur_t - t.start_t
        delta_it = n - t.last_print_n
        delta_t = cur_t - t.last_print_t
        msg = t.format_meter(**t.format_dict)
        y = delta_it / delta_t
        z = n / elapsed
        x = n * 100.0 / t

# Generated at 2022-06-24 10:18:02.082581
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    from numpy import array
    try:
        from io import BytesIO
    except ImportError:
        from io import BytesIO
    f = BytesIO()
    t = tqdm_gui(total=100, desc='Plotting')
    t.start_t = 0
    t.last_print_n = 0
    t.last_print_t = 0
    for i in t:
        t.display()
        t.moveto(i)
        sleep(0.05)
        if i == 50:
            t.n = 100 - i
            t.last_print_n = 0
            t.last_print_t = 0
            t.start_t = 50
            t.total = 100
    assert array(t.xdata).all()

# Generated at 2022-06-24 10:18:06.013648
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.clear(True)
            t.clear(leave=True)
            t.clear(False)
            t.clear(leave=False)

# Generated at 2022-06-24 10:18:11.435035
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=3) as t:
        t.clear()
        assert t.n == t.last_print_n == 0
        assert t.start_t == t._time()
        for _ in t:
            t.clear()
            assert t.n == t.last_print_n == 0
            assert t.start_t == t._time()
            t.update(1)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:18:20.978060
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Unit test for the tqdm_gui constructor"""
    import matplotlib.pyplot as plt
    from .utils import _supports_unicode
    from .std import tqdm as std_tqdm

    # Test with unicode bar
    if _supports_unicode():
        t = tqdm_gui(['a', 'b', 'c'], bar_format='{l_bar}{bar}{r_bar}')
        with t:
            for i in t:
                pass

    # Test with non-unicode bar

# Generated at 2022-06-24 10:18:26.473399
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test the method `clear()` of class `tqdm_gui`."""
    for _ in tqdm([0, 1], desc='test', ascii=True, ncols=90,
                  bar_format='{desc}: {percentage:3.0f}%|{bar}| '
                             '{n_fmt}/{total_fmt}| '
                             '{elapsed_s}<{remaining_s}| '
                             '{rate_fmt}'):
        pass

# Generated at 2022-06-24 10:18:36.433965
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    A quick unit test for method clear of class tqdm_gui.
    Tests if the graphics window is opened, if so we run the function tqdm_gui.clear().
    This function should close the graphics window.
    """
    # If the graphics window is already opened, the test will close it.
    from six.moves import input
    from .std import tgrange
    test_range = tgrange(0, 10)

# Generated at 2022-06-24 10:18:40.124963
# Unit test for function tgrange
def test_tgrange():
    from .gui import tgrange, tqdm
    for n in tgrange(4):
        for i in tqdm(range(100)):
            pass

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:18:41.684713
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.std import sleep
    for _ in trange(10):
        sleep(0.01)

# Generated at 2022-06-24 10:18:44.235082
# Unit test for function tgrange
def test_tgrange():
    assert tuple(tgrange(10)) == (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-24 10:18:50.361331
# Unit test for function tgrange
def test_tgrange():
    from .std import tqdm
    from .std import tgrange
    import sys
    import time

    for i in tgrange(4):
        for j in tqdm(tgrange(25), desc='1st loop'):
            time.sleep(0.01)
        for j in tqdm(tgrange(25), desc='2nd loop'):
            time.sleep(0.01)
        time.sleep(0.1)

    time.sleep(0.1)
    for i in tqdm(tgrange(4), desc='disc'):
        time.sleep(0.1)

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:18:52.542616
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update(n=1)

# Generated at 2022-06-24 10:18:59.070637
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for constructor of class tqdm_gui.
    """
    from .std import tqdm_gui as tqdm_ba  # for coverage

    for cls in [tqdm, tqdm_ba]:
        for total in [None, 4]:
            for leave in [False, True]:
                with cls(total=total, leave=leave, mininterval=0.1) as pbar:
                    pbar.display()
                    pbar.update()
                    pbar.close()

# Generated at 2022-06-24 10:19:02.362365
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
            plt.pause(0.5)

# Generated at 2022-06-24 10:19:12.050718
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui.
    """
    # import os
    # import sys
    # import time
    # if os.name == 'java':  # pragma: no cover
    #     sys.exit()
    # # TODO: unit test
    # tq = tqdm_gui(["a", "b", "c", "d"], total=4, miniters=1)
    # for i in _range(4):
    #     tq.update()
    #     time.sleep(0.1)
    # tq = tqdm_gui(["a", "b", "c", "d"], total=4, miniters=1)
    # for i in _range(4):
    #     tq.update()
    #     time.sleep(0

# Generated at 2022-06-24 10:19:21.583779
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for _ in tqdm_gui(range(10)):
        pass
    for _ in tqdm_gui(range(1000), bar_format='{n}'):
        pass
    for _ in tqdm_gui(range(10000), unit='it'):
        pass
    for _ in tqdm_gui(range(10), bar_format='{rate:.2f}'):
        pass
    for _ in tqdm_gui(range(10), bar_format='{rate:.2f}', unit='it'):
        pass
    for _ in tqdm_gui(range(10), bar_format='{rate:.2f} {unit}', unit='it'):
        pass

# Generated at 2022-06-24 10:19:32.919315
# Unit test for function tgrange
def test_tgrange():
    from sys import version
    from random import random as rd, shuffle as sh
    from time import sleep as slp, time
    from pprint import pprint

    print('Python version: ' + version)
    if version > '3':
        print('\nUsing the range type.')
        rng = range
    else:
        print('\nUsing the xrange type.')
        rng = xrange
    print('\nProceeding with the tests:\n')

    test_samples = 1000
    print('Tests using the range/xrange type\n')
    print('1/6 Testing with one iteration:')
    slp(rd())
    tic = time()
    tqdm(rng(1), desc='1')
    toc = time() - tic

# Generated at 2022-06-24 10:19:42.604007
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque

    t = tqdm_gui(total=10, leave=True)
    t.xdata = deque(maxlen=60)
    t.ydata = deque(maxlen=60)
    t.zdata = deque(maxlen=60)
    t.xdata.appendleft(1)
    t.ydata.appendleft(2)
    t.zdata.appendleft(3)
    t.n = 2
    t.last_print_n = 1
    t.last_print_t = 5
    t.start_t = 1
    t._time = lambda: 10
    assert t.display() is None

# Generated at 2022-06-24 10:19:44.898680
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    with tgrange(10) as pbar:
        for i in pbar:
            sleep(0.1)

# Generated at 2022-06-24 10:19:48.578898
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy import random
    random.seed(0)
    n = 10
    sleep_time = 0.01
    for _ in tqdm_gui(range(n)):
        sleep(sleep_time)

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:19:52.877889
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    with tqdm(total=0) as t:
        plt.pause(1)
        for _ in range(60):
            t.display()
            plt.pause(1)
        # Make sure the plot does not close when t == end
        t.update(1)  # for tqdm < 4
        t.close()
    plt.show()

# Generated at 2022-06-24 10:19:59.160586
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit tests for tqdm_gui
    """
    t = tqdm_gui([])
    # t.close()
    t.clear()
    t.update()
    t.update(0)
    t.update(0, 0)
    t.set_description("desc")
    t.write("write")
    t.close()

# Generated at 2022-06-24 10:20:02.967246
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Test function of tgrange"""
    import matplotlib.pyplot as plt
    plt.ion()  # interactive mode on
    for i in tgrange(3):
        plt.pause(.5)

# Generated at 2022-06-24 10:20:05.524607
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for i in tgrange(5):
        sleep(0.5)


# Generated at 2022-06-24 10:20:11.471848
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    from numpy.testing import assert_raises
    import sys

    q = tqdm_gui(total=4)
    for i in q:
        q.display()
        sleep(0.1)
    if sys.version_info[0] == 3:
        with assert_raises(SystemExit):
            q.close()
    else:
        # fails: https://github.com/tqdm/tqdm/issues/445
        pass

# Generated at 2022-06-24 10:20:13.743299
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(["a", "b", "c", "d"])
    t.clear()


# Generated at 2022-06-24 10:20:23.338511
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import executable
    from time import sleep
    from subprocess import Popen, PIPE

    # Create simple script for test
    with open("test_gui.py", "w") as test_file:
        test_file.write("""
from tqdm.gui import tqdm
import time
for i in tqdm(range(30)):
    if i > 10:
        print("Hello")
    time.sleep(0.005)
""")

    # Call script in subprocess and redirect stderr
    p = Popen([executable, "test_gui.py"], stderr=PIPE)
    sleep(0.1)
    p.terminate()
    _, stderr = p.communicate()

    # Check if process did not finish successfully
    assert p.poll() != 0

   

# Generated at 2022-06-24 10:20:30.836590
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    # Test print with *_time()
    from time import sleep
    from .utils import _time
    t = tqdm_gui(total=1)
    t.display()
    sleep(0.001)
    t.update(1)
    elapsed = _time() - t.start_time
    assert (int(elapsed) == 1)

    # Test print with *time()
    from time import time
    t = tqdm_gui(total=1)
    t.display()
    sleep(0.001)
    t.update(1)
    elapsed = time() - t.start_time
    assert (int(elapsed) == 1)


# Generated at 2022-06-24 10:20:35.454625
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import tqdm
    from .utils import _range

    with tqdm(_range(100)) as t:
        for i in _range(100):
            t.update(1)
            assert t.display(4, 4, 4) is None


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:20:37.513556
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    for j in tgrange(6, desc="Test"):
        sleep(0.2)


# For testing only
if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:20:39.804861
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    for i in tgrange(3):
        sleep(0.1)

# Generated at 2022-06-24 10:20:49.734291
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import nose
    import nose.tools as nt
    import sys

    with nt.assert_raises(SystemExit):
        with nt.assert_raises(KeyboardInterrupt):
            # Ctrl+C, since this is the only way to close ...
            tgrange(10)

# Generated at 2022-06-24 10:20:51.804436
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep

    t = tqdm_gui(range(100))
    sleep(1)
    t.close()

# Generated at 2022-06-24 10:20:57.588398
# Unit test for function tgrange
def test_tgrange():
    # Check tgrange is compatible with regular tqdm
    assert tqdm(tgrange(10)) == tqdm(xrange(10))
    assert tqdm(tgrange(10)) == tqdm(range(10))


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    for i in trange(10):
        for j in trange(5, leave=False):
            sleep(0.01)
        sleep(0.1)