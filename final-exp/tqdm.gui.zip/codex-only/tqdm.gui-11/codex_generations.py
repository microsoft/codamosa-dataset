

# Generated at 2022-06-24 10:12:36.727317
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Simple unit test for tqdm_gui"""
    import os
    import time

    try:
        import matplotlib as mpl
        mpl.use('Qt5Agg')
    except ImportError:
        return
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    from .std import tqdm as std_tqdm
    with std_tqdm(total=10, bar_format="{l_bar}{bar}|") as pbar:
        test_time = 2.0
        for i in range(10):
            time.sleep(test_time / 10)
            pbar.update(1)
    print("plotting...")
    plt.show()



# Generated at 2022-06-24 10:12:45.397390
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test function for function tqdm_gui.display"""
    import math
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np
    # Since the following doesn't work with PyPy
    #   - https://github.com/matplotlib/matplotlib/issues/973
    #   - https://github.com/pypy/pypy/issues/1861
    #   <http://stackoverflow.com/a/13779459/355230>:
    if not hasattr(mpl, 'backends'):  # pragma: no cover
        raise unittest.SkipTest("Matplotlib backend not available.")

# Generated at 2022-06-24 10:12:56.819512
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm gui close method"""
    # TODO: if pyplot import failed at top of file (ImportError)
    # how are we supposed to test it?
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()

    mpl.rcParams['toolbar'] = 'None'
    plt.ion()
    fig, ax = plt.subplots()
    instance = tqdm_gui(total=100)
    instance.close()
    # Test that the instance is removed from _instances and
    # that the plot is closed
    assert len(tqdm_gui._instances) == 0
    # Test that the toolbars are restored and
    # that the interactive mode

# Generated at 2022-06-24 10:13:01.318608
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=9) as pbar:
        for i in range(3):
            pbar.update()
            pbar.clear()
    assert list(pbar.xdata) == [0., 33.33333333333333, 66.66666666666666]

# Generated at 2022-06-24 10:13:03.949444
# Unit test for function tgrange
def test_tgrange():
    """Test function tgrange"""
    tgrange(100).close()

# Generated at 2022-06-24 10:13:12.780407
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    assert tgrange(0) == list(range(1))
    assert tgrange(1) == list(range(1))
    assert tgrange(1, 2) == list(range(1, 2))
    assert tgrange(0, 0) == list(range(1))
    assert tgrange(1, 2, 3) == list(range(1, 2, 3))
    assert tgrange(0, 2, 3) == list(range(0, 2, 3))
    assert tgrange(1, 2, 3.0) == list(range(1, 2, 3))
    assert tgrange(1, 3, 2) == list(range(1, 3, 2))

# Generated at 2022-06-24 10:13:23.679856
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    with tqdm_gui(total=100) as pbar:
        for i in _range(20):
            pbar.update(i)
            pbar.clear()
            pbar.write("some write")
            pbar.close()
    with tqdm_gui(total=100) as pbar:
        for i in _range(20):
            pbar.update(i)
            pbar.clear(False)
    with tqdm_gui(total=100) as pbar:
        for i in _range(20):
            pbar.update(i)
            pbar.clear(True)

# Generated at 2022-06-24 10:13:32.731279
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    import sys

    def iterate_over_tgrange():
        for i in tgrange(5):
            sys.stdout.write('{0}\r'.format("*" * i))
            sys.stdout.flush()
            sleep(0.2)

    if __name__ == '__main__':
        iterate_over_tgrange()
        sys.stdout.write("\n")
        print("Please close the plot window")


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:13:42.960235
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from numpy.random import rand
    from matplotlib import pyplot as plt
    from tqdm.gui import tqdm_gui

    # Setup
    plt.ion()
    plt.figure(figsize=(9, 3))
    n = 100
    for i in tqdm_gui(range(n), desc='progress', leave=False):
        plt.cla()
        plt.plot(rand(i+1))
        plt.pause(1e-9)
        sleep(0.01)
    plt.close()

if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:13:54.188504
# Unit test for function tgrange
def test_tgrange():
    import sys
    import time
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
    except ImportError:
        pass
    else:
        for _ in tgrange(4, 0, -0.4, color='g'):
            time.sleep(1)
        for _ in tgrange(4, 0, -0.4, desc='Hey!', leave=True):
            time.sleep(1)
        for _ in tgrange(4, 0, -0.4, leave=True, desc='You', total=8):
            time.sleep(1)
    finally:
        plt.close()
        if sys.version_info[0] >= 3:
            time.sleep(2)
        else:
            time.sleep(6)

# Generated at 2022-06-24 10:13:58.978877
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from matplotlib.pylab import close
    plt.ion()
    t = tqdm_gui(total=10)
    for x in _range(10):
        t.update()
    t.close()
    close(t.fig)

# Generated at 2022-06-24 10:14:10.561182
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import gc
    import time
    from os import getpid
    # Test Antigravity
    tqdm(["hi", "there", "guys"], file=None)
    # Test closing manually while tqdm instance is in a reference cycle
    t = tqdm(["hi", "there", "guys"])
    gc.collect()
    time.sleep(0.01)
    pid = getpid()
    t.close()
    assert (str(t)).endswith("pid %s>" % pid)
    del t
    del gc.garbage[:]
    gc.collect()
    # Test closing manually after tqdm instance is in a reference cycle
    t = tqdm(["hi", "there", "guys"])
    del t
    gc.collect()

# Generated at 2022-06-24 10:14:13.022711
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=10)
    t.clear()
    t.close()
    assert True  # if we are here, no error was raised

# Generated at 2022-06-24 10:14:15.101652
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=10)
    t.close()
    t.update(2)
    t.close()

# Generated at 2022-06-24 10:14:16.061955
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass



# Generated at 2022-06-24 10:14:25.075123
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """ Unit test for method close of class tqdm_gui """
    try:
        import matplotlib as _mpl
    except ImportError:
        warn("Matplotlib GUI is not available, skipping tests",
             TqdmExperimentalWarning, stacklevel=2)
        return
    except RuntimeError:  # pragma: no cover
        pass
    except Exception:  # pragma: no cover
        # Known to fail with TkAgg backend on Mac OSX
        # Known to fail with Agg backend + when DISPLAY env var is not set
        pass
    else:
        # Don't mess with user settings
        orig_interactive = _mpl.is_interactive()

    # Avoid lengthy tests on Travis-CI
    if orig_interactive:  # pragma: no cover
        return

    _mpl.interactive(True)

# Generated at 2022-06-24 10:14:32.771276
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _supports_unicode
    from .std import TqdmDefaultWriteLock
    from .std import tqdm as std_tqdm

    # Create a tqdm instance
    total = 5
    t = tqdm_gui(total=total)
    assert len(t) == total
    t.close()

    # Force disable GUI
    t = tqdm_gui(total=total, disable=True)
    assert t.disable
    t.close()

    # Check the tgrange works
    t = tgrange(total)
    assert len(t) == total
    t.close()

    # Check that tqdm function works
    t = tqdm(total=total)
    assert len(t) == total

    # Check that tqdm is still a singleton
    assert t

# Generated at 2022-06-24 10:14:34.674392
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10, desc="Flower", disable=True) as t:
        t.clear()

# Generated at 2022-06-24 10:14:38.003114
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    __import__('unittest').main('tqdm.tests.test_gui', exit=False)


if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:14:43.837168
# Unit test for function tgrange
def test_tgrange():
    from .autonotebook import tqdm
    from .gui import tgrange
    import sys

    @tqdm(total=10, file=sys.stdout)
    def for_test_tgrange(i):
        pass

    @tgrange(10, file=sys.stdout)
    def for_test_tgrange2(i):
        pass

    for_test_tgrange2()
    try:
        for_test_tgrange()
    finally:
        del(for_test_tgrange)


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:14:48.331033
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui.
    """
    with tqdm_gui(total=tqdm_gui.__len__()) as t:
        for i in t:
            # Update progress bar
            t.display()
            # Update iterable
            t.update()



# Generated at 2022-06-24 10:14:57.706053
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    tqdm_gui_test = tqdm_gui(total=100)
    tqdm_gui_test.close()
    assert plt.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion
    plt.close('all')

# Generated at 2022-06-24 10:14:58.867800
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    for _ in tgrange(3):
        pass

# Generated at 2022-06-24 10:15:05.976867
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib.pyplot as plt
    import time

    # reset tqdm_gui state
    plt.close('all')
    # test tqdm_gui
    for i in tqdm(range(1, 12), desc='desc_tqdm'):
        time.sleep(i / 10.)

    # reset trange state
    plt.close('all')
    # test trange
    for i in trange(1, 12, desc='desc_tgrange'):
        time.sleep(i / 10.)

# Generated at 2022-06-24 10:15:15.438670
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import pkg_resources
    pkg_resources.require("tqdm")
    from tqdm.gui import tqdm
    from tqdm.gui import tqdm_gui
    from matplotlib import pyplot as plt

    tqd = tqdm(total = 100)
    tqd.close()
    assert not tqd.mpl.rcParams['toolbar']
    assert not plt.isinteractive()

    tqg = tqdm_gui(total = 100)
    tqg.leave = True
    tqg.close()
    assert not tqg.mpl.rcParams['toolbar']
    assert not plt.isinteractive()

    tqg.leave = False
    tqg.close()
    assert not tqg.mpl.rc

# Generated at 2022-06-24 10:15:16.623977
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    for _ in tgrange(4):
        pass


# Generated at 2022-06-24 10:15:21.728927
# Unit test for function tgrange
def test_tgrange():
    """Test trange with GUI"""
    from time import sleep
    # progress bar with GUI
    for i in tgrange(10):
        sleep(0.1)
    # progress bar with GUI (explicit)
    for i in tgrange(10, gui=True):
        sleep(0.1)
    # progress bar with GUI (explicit, different color)
    for i in tgrange(10, gui=True, colour='y'):
        sleep(0.1)
    # progress bar WITHOUT GUI (explicit)
    for i in tgrange(10, gui=False):
        sleep(0.1)

# Generated at 2022-06-24 10:15:33.606858
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .autonotebook import trange
    from .std import TqdmTypeError, TqdmKeyError
    from .std import tqdm as _tqdm
    from .std import tqdm_gui as _tqdm_gui

    assert tqdm_gui is _tqdm_gui
    assert _tqdm is not _tqdm_gui
    assert _tqdm_gui is not _tqdm

    with trange(5, 25, 2) as t:
        assert t.__iter__ is t.__next__
        assert next(t) == 5

        assert t.miniters
        t.miniters = 0
        assert t.miniters == 0
        t.miniters = None
        assert t.miniters is None

        lst

# Generated at 2022-06-24 10:15:39.449383
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib.pyplot as plt
    import time

    with trange(100) as t:
        for i in t:
            time.sleep(0.01)

    assert not plt.fignum_exists(t.fig.number)
    plt.close('all')

# Generated at 2022-06-24 10:15:48.150616
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for method close of class tqdm_gui"""
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()

    try:
        with tqdm_gui(total=5) as pbar:
            pbar.close()

        assert mpl.rcParams['toolbar'] == toolbar
        assert plt.isinteractive() == wasion
    finally:
        mpl.rcParams['toolbar'] = toolbar
        if not wasion:
            plt.ioff()

# Generated at 2022-06-24 10:15:57.658664
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import version_info
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    with tqdm(total=1) as t:
        toolbar = mpl.rcParams['toolbar']
        wasion = plt.isinteractive()
        assert mpl.rcParams['toolbar'] == 'None'
        t.close()
        assert mpl.rcParams['toolbar'] == toolbar
        if version_info.major == 2:
            assert not plt.isinteractive()
        else:
            assert plt.isinteractive() == wasion
if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:16:00.767928
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import time
    with tqdm(tgrange(1000), smoothing=0) as pbar:
        for i in pbar:
            time.sleep(0.001)


# Generated at 2022-06-24 10:16:05.981186
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # clear method of class tqdm_gui must be defined as abstract
    # method of the parent class.
    # It must be overriden without calling super().
    assert tqdm_gui.clear.__code__ is getattr(std_tqdm, 'clear').__code__

test_tqdm_gui_clear()

# Generated at 2022-06-24 10:16:16.251572
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit tests for `tqdm.gui`.
    """
    
    from time import sleep
    from numpy.random import uniform
    from .gui import tqdm_gui
    # Eg. 1
    for _ in tqdm_gui(range(100), desc="1st loop"):
        for _ in tqdm_gui(range(100), desc="2nd loop", leave=False):
            sleep(uniform(0.001, 0.01))
        sleep(uniform(0.001, 0.01))
    # Eg. 2
    tqdm_gui(range(50), desc="3rd loop")
    # Eg. 3

# Generated at 2022-06-24 10:16:25.301079
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        with tqdm_gui(
                total=len(range(10)),
                file=open(os.devnull, 'w'),
                leave=False
        ) as t:
            for i in t:
                assert t.total == 10
                assert len(t.xdata) == len(t.ydata) == len(t.zdata)
                t.display()
                assert len(t.xdata) == len(t.ydata) == len(t.zdata)
    except Exception as e:
        print(e)


if __name__ == "__main__":  # pragma: no cover
    from .main import _main
    _main(tqdm=tqdm_gui)

# Generated at 2022-06-24 10:16:36.390857
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(0.1)

    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        plt.ion()
        mpl.rcParams['toolbar'] = 'None'
    except ImportError:
        warn("For a progressbar, you need matplotlib!")
        return

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(0.1)
            if i == 5:
                pbar.close()
                return


# Generated at 2022-06-24 10:16:42.426613
# Unit test for function tgrange
def test_tgrange():
    for x in tgrange(4, 12, 2):
        assert x % 2 == 0
    for x in tgrange(4, 12, -1):
        assert x > 0
    for x in tgrange(4, 12, -2):
        assert x >= 0
    for x in tgrange(12, 4, -2):
        assert x <= 0



# Generated at 2022-06-24 10:16:49.142044
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time
    try:
        t = tqdm_gui(total=2, disable=False)
    except Exception as e:
        raise type(e)(str(e) +
                      "\nYou have to have DISPLAY variable set to a valid X server")
    time.sleep(0.3)
    for i in t:
        time.sleep(0.1)
    plt.close(t.fig)
    del t


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:17:01.371050
# Unit test for function tgrange
def test_tgrange():
    """Unit test for function tgrange"""
    from ._tqdm import __version__ as tqdm_version  # NOQA
    from ._tqdm import tqdm
    # Check that it has the exact same output (including newlines)
    for n in [21, 12, 14, 23]:
        for i in tgrange(n):
            pass

        for i in tqdm(list(range(n))):
            pass

        f = open('test_tgrange.tmp', 'w')
        for i in tgrange(n):
            f.write('#')
        f.close()

        g = open('test_tgrange.tmp', 'r')
        content = g.read()
        g.close()

        f = open('test_tqdm.tmp', 'w')

# Generated at 2022-06-24 10:17:08.494614
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        t = tqdm([1,2,3])
        assert not t.disable
        assert t.mpl.rcParams['toolbar']=='None'
        # Restore old value of toolbar
        t.close()
        assert t.disable
        assert t.mpl.rcParams['toolbar'] == 'toolbar2'
    except:
        print("Test of tqdm_gui.close() failed.")
        raise


# Generated at 2022-06-24 10:17:17.871400
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(range(10)):
        pass


if __name__ == "__main__":
    from time import sleep
    try:
        with tqdm(total=100, ascii=True) as pbar:
            for i in range(10):
                pbar.update(10)
                sleep(0.05)
        input("Press Enter to continue...")
    finally:
        plt.ioff()
    try:
        with tqdm(total=100, ascii=True) as pbar:
            for i in range(10):
                pbar.update(10)
                sleep(0.05)
        input("Press Enter to continue...")
    finally:
        plt.ioff()

# Generated at 2022-06-24 10:17:26.142152
# Unit test for function tgrange
def test_tgrange():
    from unittest import TestCase, main
    from time import sleep
    for i in tgrange(10, desc="Test"):
        sleep(0.01)
    # Test reset
    for i in tgrange(3, desc="Test"):
        sleep(0.01)
        # Test update
        for j in tgrange(100):
            pass
    # Test nested
    for i in tgrange(3, desc="Test"):
        sleep(0.01)
        for j in tgrange(100, desc="More tests"):
            sleep(0.001)
            for k in tgrange(50, desc="Even more tests"):
                sleep(0.001)


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:17:30.949162
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:  # Remove this when drop Python 2.6 support
        from unittest import mock
    except ImportError:
        from unittest.mock import mock

    with mock.patch('tqdm.gui.tqdm.display'):
        with tqdm(total=10) as n:
            n.clear()

# Generated at 2022-06-24 10:17:36.065783
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(total=100)
    t.update(69)
    t.clear()
    assert not t.sp, 'tqdm_gui.clear failed'
    t.close()


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:17:44.549602
# Unit test for function tgrange
def test_tgrange():
    import sys
    import time
    # Test trange with default arguments
    for _ in tgrange(5):
        pass
    # Test trange with custom arguments
    with tgrange(9, 0, -1, leave=True) as t:
        for i in t:
            time.sleep(0.1)
    # Test trange with custom arguments and unit keyword
    with tgrange(100, unit='K') as t:
        for i in t:
            time.sleep(0.01)
    # Test trange with custom arguments and unit keyword
    sys.stdout.write(
        ''.join(tgrange(100, unit='K', bar_format='<{bar}>')))



# Generated at 2022-06-24 10:17:45.428363
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tqdm_gui(tgrange(10)):
        pass

# Generated at 2022-06-24 10:17:52.356361
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib import pyplot as plt
    import matplotlib as mpl
    from time import sleep
    from .std import tqdm

    with tqdm(total=5) as pbar:
        for i in range(5):
            sleep(1)
            pbar.update(1)


    mpl.rcParams['toolbar'] = 'toolbar'
    pbar = tqdm(total=1)
    pbar.close()
    plt.close()
    pbar = tqdm(total=1)
    pbar.close()
    plt.close()

# Generated at 2022-06-24 10:17:56.144142
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=2) as pbar:
        pbar.update()
    assert pbar.disable


if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:18:05.180274
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import subprocess
    from time import sleep
    from os import kill
    from signal import SIGKILL

    p = subprocess.Popen(["python", "-c",
                          "import sys; from tqdm.gui import trange; "
                          "for i in trange(3, desc='1st loop'):"
                          "    for j in trange(25, desc='2nd loop', leave=False, "
                          "    miniters=1):"
                          "        sys.stdout.write('{:d}+{:d}\r' % (i, j))"
                          "        sys.stdout.flush()"],
                         stdout=subprocess.PIPE)
    # wait for window to open and close
    sleep(5)
    # close it

# Generated at 2022-06-24 10:18:13.548891
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for tqdm_gui method close."""
    # test whether overlapping instances are not allowed
    with std_tqdm(1) as t:
        t = tqdm(1)
        t.close()
        t.close()
        # since tqdm(1) is closed, tqdm(10) should be a new instance (==1)
        assert tqdm(10).instance_number == 1


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    import sys

    # test whether overlapping instances are not allowed
    with tqdm(1) as t:
        t = tqdm(1)
        t.close()
        t.close()
        # since tqdm(1) is closed, tqdm(10) should be a new instance

# Generated at 2022-06-24 10:18:24.640618
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    import sys

    if sys.version_info[0] < 3:
        from time import time as time_monotonic
    else:
        # time.monotonic() was added in Python 3.3
        from time import monotonic as time_monotonic

    test_rate = 2.0
    testsize = 2
    t0 = time_monotonic()
    for x in tgrange(testsize):
        sleep(0.5 / test_rate)
    t1 = time_monotonic()
    total_time = t1 - t0

# Generated at 2022-06-24 10:18:27.059389
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=1) as t:
        t.display()
        assert t.disable == False
        t.close()
        assert t.disable == True

# Generated at 2022-06-24 10:18:28.521869
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .cli import cli

    cli.clear_output()

# Generated at 2022-06-24 10:18:30.633349
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        for i in _range(10):
            pbar.update()

# Generated at 2022-06-24 10:18:33.876304
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=100,
                  miniters=100, mininterval=0,
                  desc="Test") as t:
        for dummy in _range(100):
            t.update()

# Generated at 2022-06-24 10:18:39.585734
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tqdm(tgrange(9)):
        pass
    for i in tqdm(tgrange(9), bar_format="{percentage:3.0f}%%"):
        pass
    for i in tqdm(tgrange(9), leave=True):
        pass
    for i in tqdm(tgrange(9), smoothing=1.0, leave=True):
        pass



# Generated at 2022-06-24 10:18:48.577528
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    t = tqdm_gui(total=100)
    t.display()
    assert t.ax.get_title() == "  0%|          | 0/100 [00:00<?, ?it/s]"
    assert t.ax.get_xlabel() == 'percent'
    assert t.mpl.rcParams['toolbar'] == 'None'
    t.display()
    assert t.ax.get_title() == "  0%|          | 0/100 [00:00<?, ?it/s]"
    t.update(50)
    t.display()

# Generated at 2022-06-24 10:18:58.451520
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui([])
    assert t.total is None
    t.n, t.last_print_n, t.last_print_t = 0, 0, 0.
    xdata = t.xdata
    ydata = t.ydata
    zdata = t.zdata
    t.display()
    assert xdata == [0.0]
    assert ydata == [0.0]
    assert zdata == [0.0]
    t.n = 1
    t.display()
    assert xdata == [0.0, 1.0]
    assert ydata == [0.0, 0.0]
    assert zdata == [0.0, 0.0]
    t.n, t.last_print_n, t.last_print_t = 10, 1, 0
   

# Generated at 2022-06-24 10:19:03.521412
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        class tqdm_test(tqdm_gui):
            pass
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as e:
        raise ValueError(
            "Exception `%r` raised while testing tqdm_gui()" % e)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:05.823817
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(total=2) as pbar:
        pbar.update()
    assert pbar.disable



# Generated at 2022-06-24 10:19:14.506197
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Unit test for method `display` of class `tqdm_gui`"""
    import time
    from .std import TqdmKeyError

    # Instantiation
    with tqdm_gui(total=None, disable=False) as pbar:
        # Assertions
        assert pbar.disable is False
        # Testing `display` method
        for i in range(20):
            pbar.update()
            time.sleep(0.01)
            if i == 10:
                # Testing exceptions
                try:
                    pbar.format_dict.pop('bar_format')
                except TqdmKeyError:
                    pass
                else:
                    raise RuntimeError('The key `bar_format` is expected to '
                                       'be required')

# Generated at 2022-06-24 10:19:18.148760
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(range(10)):
        pass
    print('\nTest passed!\n')
    input('Press any key to close the program. . .')

# Generated at 2022-06-24 10:19:21.506510
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys

    total = 100
    def testrange(total):
        return tqdm(range(total))

    if sys.version_info < (3,):
        from nose.tools import assert_equal
        assert_equal(list(testrange(total)), list(xrange(total)))


# Simple unit test for class tqdm_gui

# Generated at 2022-06-24 10:19:26.767206
# Unit test for function tgrange
def test_tgrange():
    t = tqdm(tgrange(10**3))
    assert next(t) == 0
    assert t.n == 1
    # Make sure it prints correctly
    if not hasattr(t, '_instances'):
        t._instances = [t]
    for i in t:
        if i >= 1:
            break
    assert t.n == 2

# Generated at 2022-06-24 10:19:39.026003
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange
    """
    from sys import version
    from .utils import _range, FormatCustomText
    from .std import FakeTqdmFile

    for i in tgrange(4, unit="songs"):
        with tqdm(total=7, bar_format="{l_bar}{bar}|") as bar:
            for j in tqdm(_range(7), desc="Dance", leave=False):
                if j == 3:
                    bar.set_postfix_str(str(i))
                elif j == 6:
                    bar.set_postfix_str('{:.{prec}f}'.format(10, prec=2))
                bar.update()

# Generated at 2022-06-24 10:19:42.644719
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    pbar = tqdm_gui(total=2)
    pbar.update(1)
    sleep(1)
    pbar.update(2)
    pbar.close()
    # pbar.display()
    sleep(0.5)

# Generated at 2022-06-24 10:19:47.144437
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for tqdm_gui.close"""
    try:
        iterable_list = list(range(1000))
        with tqdm_gui(iterable_list, mininterval=0) as t:
            for x in t:
                pass
        t.close()
    except Exception as e:
        raise(e)

# Generated at 2022-06-24 10:19:53.211831
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from os import getpid
    from time import sleep
    import unittest

    class TestTqdmGuiDisplay(unittest.TestCase):
        def setUp(self):
            self.t = tqdm(total=100, gui=True)
            self.t.start()

        def test_display_minimal(self):
            with self.assertRaises(TypeError):
                self.t.display()

        def test_display_total(self):
            with self.assertRaises(TypeError):
                self.t.display(total=100)

        def test_display_dumb(self):
            with self.assertRaises(RuntimeError):
                self.t.disable = True
                self.t.display(n=0)


# Generated at 2022-06-24 10:20:04.560628
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test case : interactivity of tqdm GUI
    import matplotlib.pyplot as plt
    t = tqdm_gui(disable=False, leave=True)
    # t.close()

    # t.wasion = plt.isinteractive()
    # t.plt.ion()
    # assert t.wasion != plt.isinteractive(), "It should change the interactivity of matplotlib in t.close()"

    # Test case : toolbars of tqdm GUI
    t = tqdm_gui(disable=False, leave=True)
    # t.close()

    # toolbar = plt.rcParams['toolbar']
    # assert t.toolbar != toolbar, "It should restore potential toolbar changes in t.close()"

# Generated at 2022-06-24 10:20:06.615699
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=5) as t:
        for i in range(5):
            t.update()


# Generated at 2022-06-24 10:20:11.514823
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    from sys import stdout
    for i in tgrange(50):
        sleep(0.1)
        stdout.write("\033[2K\033[G")
        print(i, end='')


if __name__ == '__main__':
    r = test_tgrange()

# Generated at 2022-06-24 10:20:21.432222
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import _is_in_notebook
    if not _is_in_notebook():
        return
    import matplotlib.pyplot as plt
    from IPython.core.pylabtools import figsize
    import numpy as np

    plt.ioff()
    fig = plt.figure(figsize=figsize(2, 2))
    bar = tqdm_gui(total=100, leave=True)
    for i in range(100):
        time.sleep(0.02)
        bar.update()
    bar.close()
    fig.canvas.get_supported_filetypes()
    # plt.savefig(os.path.join(os.path.expanduser("~"), "test.png"))
    plt.close(fig)


# Generated at 2022-06-24 10:20:29.636493
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from matplotlib.pyplot import subplots, close, pause
    except ImportError:
        from nose.plugins.skip import SkipTest
        raise SkipTest

    def assert_is_progressbar(t, axes):
        # print(t.last_print_n, t.start_t, t.last_print_t, t.n, t._time())
        new_n = 1.
        new_t = t._time()
        # update to new display value
        t.update(n=new_n, last_print_t=new_t)
        # assert values are updated
        assert t.n == new_n
        assert t.last_print_t == new_t
        # check if progressbar increase 
        progressbar_current, progressbar_total = axes.patches[0].get

# Generated at 2022-06-24 10:20:34.786721
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    t = tqdm_gui(10)
    for i in t:
        t.display()
        plt.pause(1e-9)
    t.close()
    assert plt.fignum_exists(t.fig.number)

# Generated at 2022-06-24 10:20:43.587911
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import tqdm_gui
    from time import sleep
    from numpy import allclose

    def hspan(xy):
        return allclose(xy, [[0.0, 0.0, 0.25233645, 0.0, 0.0],
                             [0.001, 0.0, 0.001, 0.0, 0.0]])

    t = tqdm_gui(100)  # noqa
    sleep(0.1)
    t.n = 10  # noqa
    t.last_print_t = t._time() - 1  # noqa
    t.last_print_n = 9  # noqa
    t.display()  # noqa
    assert hspan(t.hspan.get_xy())



# Generated at 2022-06-24 10:20:45.720985
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    for i in tgrange(5):
        sleep(0.5)


# Generated at 2022-06-24 10:20:48.302933
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .tests.gui import test_close as tc
    tc(tqdm_gui)


del absolute_import, division, print_function, unicode_literals

# Generated at 2022-06-24 10:20:52.702045
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    import numpy as np
    # TODO: remove this if-clause once the warning is solved
    from warnings import catch_warnings
    with catch_warnings(record=True):
        for i in tqdm(np.linspace(0, 1, 100), ncols=75):
            time.sleep(0.01)

# Generated at 2022-06-24 10:20:55.950074
# Unit test for function tgrange
def test_tgrange():
    with tqdm(tgrange(3), desc="tgrange") as t:
        for i in t:
            pass


if __name__ == '__main__':
    # Run tests
    test_tgrange()

# Generated at 2022-06-24 10:20:59.553641
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot
    t = tqdm_gui(10)
    t.close()
    assert matplotlib.pyplot.isinteractive() is False
    assert t.disable is True


# Generated at 2022-06-24 10:21:09.989222
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Test for method display of class tqdm_gui
    # Should be run only with python -m tqdm.gui
    import time

    t = tqdm_gui(total=None,
                 desc="test_tqdm_gui_display",
                 bar_format="{desc}:{percentage:3.0f}%|{bar}| {n_fmt:>{n_digits}d}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]",
                 interval=0.5,
                 unit="it",
                 unit_scale=True,
                 initial=2,
                 position=2,
                 leave=True)
    for j in range(4):
        for i in t:
            time.sleep(0.01)

# Generated at 2022-06-24 10:21:11.640130
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test clear method of tqdm_gui"""
    gui = tqdm_gui(total=1)
    gui.clear()



# Generated at 2022-06-24 10:21:20.126570
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import time
    import matplotlib.pyplot as plt
    test = tqdm_gui(total=100)
    for i, t in enumerate(test):
        time.sleep(0.1)
        test.display()
    assert (not test.n) or (test.smoothing[-1] > 0.01)
    test = tqdm_gui(total=100, smoothing=0)
    for i, t in enumerate(test):
        time.sleep(0.1)
        test.display()
    assert test.smoothing[-1] < 0.01
    test = tqdm_gui(total=100, smoothing=1)
    for i, t in enumerate(test):
        test.display()

# Generated at 2022-06-24 10:21:31.437425
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib
    import matplotlib.pyplot as plt
    assert matplotlib.__version__ >= '1.3'
    with tqdm_gui(total=1000, unit="iB", unit_scale=True, desc="test",
                  leave=False, disable=False) as t:
        for i in _range(1000):
            t.update()
            plt.pause(0.01)


# Setup environments (we need to check if we have a GUI or not)
if __name__ == '__main__':  # pragma: no cover
    import sys
    import time
    from .main import main

# Generated at 2022-06-24 10:21:40.303431
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Mock a tqdm instance and test that it closes properly

    This functions mocks the tqdm_gui instance and tests its closing methods.
    """
    from unittest import mock
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    class DummyAxis(mock.MagicMock):
        def set_xlabel(self, text):
            print("Set xlabel to %s" % text)

    class DummyFigure(mock.MagicMock):
        pass

    class DummyPlot(mock.MagicMock):
        def __call__(self, data1, data2, color='b'):
            return

    class DummyAxhspan(mock.MagicMock):
        def __call__(self, *args, **kwargs):
            return Dummy

# Generated at 2022-06-24 10:21:51.019614
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    class dummy_class(object):
        def __init__(self):
            self.disable = False
            self.last_print_n = 0
            self.n = 1
            self.total = None
            self.n_fmt = '{n}'
            self.n = 1
            self.avg_time = None
            self.iterable = _range(5)
            self.desc = "test"
            self.format_dict = {'n': self.n, 'bar': '', 'n_fmt': self.n_fmt,
                                'desc': self.desc, 'rate': '100it/s',
                                'bar_format': "test_tqdm"}
            self.start_t = None
            self.last_print_t = 0

    dummy

# Generated at 2022-06-24 10:22:00.436885
# Unit test for function tgrange
def test_tgrange():
    from .sequence import tqdm
    for i in tqdm(tgrange(10)):
        i
        if i == 4:
            break
    for i in tqdm(tgrange(10)):
        i
        if i == 4:
            raise ValueError()
    for i in tgrange(10):
        i
        if i == 4:
            break
    for i in tgrange(10):
        i
        if i == 4:
            raise ValueError()


if __name__ == '__main__':
    import time
    from .sequence import tqdm

    for i in tqdm(range(10)):
        i
        time.sleep(0.2)
        if i == 4:
            break

# Generated at 2022-06-24 10:22:06.066984
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    t = tqdm_gui(total=50, ncols=100)
    try:
        for i in t:
            t.display()
            t.update(5)
            plt.pause(0.1)
        plt.pause(0.5)
    finally:
        t.close()

# Generated at 2022-06-24 10:22:09.691094
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(unit='B', unit_scale=True, unit_divisor=1024) as t:
        t.clear()
        t.update(10)

import io
import sys
from contextlib import contextmanager


# Generated at 2022-06-24 10:22:11.293833
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for n in tgrange(10**6):
        pass



# Generated at 2022-06-24 10:22:16.582455
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .utils import _range

    # print("\n\n*** TESTING GUI ***")
    with tqdm_gui(total=1) as pbar:
        try:
            for i in _range(2):
                pbar.display()
        except KeyboardInterrupt:
            pass
    # print("\n*** END TESTING GUI ***")

if __name__ == '__main__':  # pragma: no cover
    # Run test suite
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:22:23.858202
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Hack for testing purposes
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import inspect

    sys.stderr = StringIO()
    tqdm_gui()
    tqdm_gui(10)
    tqdm_gui(10, bar_format="{l_bar} {bar} {r_bar}")
    tqdm_gui(10, unit="it", unit_scale=True)
    tqdm_gui(10, initial=5)
    tqdm_gui(10, miniters=1)
    tqdm_gui(10, mininterval=0.2)
    tqdm_gui(10, mininterval=0.2, miniters=1)
    tq

# Generated at 2022-06-24 10:22:35.055372
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from .utils import FormatCustomTextTest, FormatCustomTextTest1

    # Test 1:
    with tqdm(total=100, unit='B', unit_scale=True) as pbar:
        for i in pbar:
            sleep(0.01)

    # Test 2:
    with tqdm(total=100, unit='B', unit_scale=True,
              bar_format="{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]") as pbar:
        for i in pbar:
            sleep(0.01)

    # Test 3: