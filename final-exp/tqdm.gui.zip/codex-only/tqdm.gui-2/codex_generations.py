

# Generated at 2022-06-24 10:12:25.332148
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """ Unit tests for method clear of class tqdm_gui."""
    return True

# Generated at 2022-06-24 10:12:35.878119
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import time

    if sys.version_info >= (3, 3):
        from inspect import signature
        assert len(signature(tqdm_gui).parameters) == len(tqdm_gui.__init__.__code__.co_varnames)
    vn = tqdm_gui.__init__.__code__.co_varnames
    assert vn[0] == 'self'
    assert len(vn) == len(list(set(vn)))

    # check if the toolbar gets disabled
    t = tqdm_gui("")
    assert t.toolbar == t.mpl.rcParams['toolbar']
    t.close()

    # check if the interactive mode is enabled
    t = tqdm_gui("")
    time.sleep(0.05)


# Generated at 2022-06-24 10:12:42.985530
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()
    # plot some garbage to avoid empty figure
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.plot([1, 2, 3], [4, 5, 6], color='b', lw=0.5)
    ax.set_title("this is a test", fontsize=14)
    ax.set_xlabel("this is xlabel")
    ax.set_ylabel("this is ylabel")
    # restore original matplotlib setup
    mpl.rcParams['toolbar'] = toolbar
    if not wasion:
        plt.ioff()
    # run test
   

# Generated at 2022-06-24 10:12:50.110894
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import time
    from contextlib import closing
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from .utils import format_sizeof, IS_PYTHON
    # Test close() method

# Generated at 2022-06-24 10:13:02.648843
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    '''Unit test for the method display of class tqdm_gui'''
    import os,sys
    if not os.isatty(sys.stdin.fileno()):
        raise RuntimeError("Need to be attached to an interactive terminal "
            "to run this unittest. Try running `python -i test_tqdm.py`.")
    from .gui import tqdm
    from time import sleep, time
    N = 100
    tot = 5.1
    with tqdm(total=N) as t:
        for i in range(N):
            sleep(tot / N / 2)
            t.update()
        t.n = 0
        t.total = None
        t.last_print_n = 0
        t.last_print_t = time()
        sleep(1)

# Generated at 2022-06-24 10:13:12.291960
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    assert hasattr(sys, 'pypy_version_info') or sys.version_info[0] >= 3, \
        "This test requires Python 3+ or pypy"
    from tqdm.gui import tgrange

    assert tgrange(3) == list(range(3))
    assert tgrange(3, 6) == list(range(3, 6))
    assert tgrange(3, 8, 2) == list(range(3, 8, 2))

    # Unit test for function tqdm(iterable) #998
    assert tqdm(xrange(3)) == list(tgrange(3))
    assert tqdm(xrange(3, 6)) == list(tgrange(3, 6))

# Generated at 2022-06-24 10:13:18.553866
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    # Patch mpl
    import matplotlib.pyplot as plt
    tqdm_gui.plt = plt

    # Prepare test
    from io import StringIO

    class FakeStream(StringIO):
        def write(self, *_):
            pass

        def flush(self, *_):
            pass

    stream = (FakeStream(), FakeStream(), FakeStream())
    for s in stream:
        plt.switch_backend('template')
        plt.ioff()
        fig = plt.figure()
        tqdm_gui.leave = False
        tqdm_gui.wasion = False
        tqdm_gui.toolbar = 'None'
        tqdm_gui.mpl = plt.__class__
        tqdm_gui.fig = fig

# Generated at 2022-06-24 10:13:21.702516
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .gui import tqdm_gui
    from time import sleep
    with tqdm_gui(total=4) as pbar:
        for i in range(4):
            sleep(0.5)
            pbar.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:13:26.751838
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    from time import sleep
    pbar = tqdm_gui(total=10)
    for i in range(10):
        pbar.display()
        sleep(1)
        pbar.update(1)
    plt.close(pbar.fig)

# Generated at 2022-06-24 10:13:38.937748
# Unit test for constructor of class tqdm_gui

# Generated at 2022-06-24 10:13:41.855084
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from time import sleep
    from sys import stderr
    from itertools import cycle

    for _ in tqdm_gui(cycle(['.', '_']), file=stderr):
        sleep(.1)

# Generated at 2022-06-24 10:13:45.720243
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import tqdm
    t = tqdm(total=None)
    for i in t:
        t.display()
        if i >= 60:
            break

# Generated at 2022-06-24 10:13:49.957849
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)
    pbar.close()

# Generated at 2022-06-24 10:14:00.613443
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import cleanup
    from six.moves import xrange
    from .utils import FormatCustomTextType, FormatCustomTextExtension, percentage
    f_tqdm = tqdm

    @cleanup(plt.close)
    def internal_test(leave=True):
        for i in f_tqdm(xrange(10), ascii=True, miniters=1, mininterval=1e-3,
                        ncols=80, disable=False, unit_scale=False):
            if i == 2:
                f_tqdm.clear()
            plt.pause(0.1)


# Generated at 2022-06-24 10:14:07.191217
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """
    Tests that tqdm_gui.clear() does not raise exceptions.

    Unit test for method clear of class tqdm_gui
    """
    for _ in tqdm_gui(range(4)):
        pass
    tqdm_gui.clear()
    for _ in tqdm_gui(range(4)):
        pass

# Generated at 2022-06-24 10:14:17.567871
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from nose.plugins.skip import SkipTest
    raise SkipTest

    from time import sleep
    import sys

    @tqdm_gui(total=10, leave=True)
    def n():
        for i in _range(10):
            sleep(0.1)
            yield

    @tqdm_gui(total=10, leave=True, unit='B', unit_scale=True, miniters=1)
    def b():
        for i in _range(10):
            sleep(0.02)
            yield 1 << (i * 10)

    @tqdm_gui(total=10, leave=True, unit_scale=True, miniters=1)
    def s():
        for i in _range(10):
            sleep(0.01)

# Generated at 2022-06-24 10:14:26.004252
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from .autonotebook import tqdm as tqdm_notebook
    for tqdm in [tqdm_gui, tqdm_notebook]:
        with tqdm(range(3), desc='clear1', leave=False) as pbar:
            pbar.clear()
        with tqdm(range(3), desc='clear2', leave=False) as pbar:
            pbar.clear(True)
        with tqdm(range(3), desc='clear3', leave=False) as pbar:
            pbar.clear(True, True)
        with tqdm(range(3), desc='clear4', leave=False) as pbar:
            pbar.clear(nolock=True)


# Generated at 2022-06-24 10:14:33.073159
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    # Avoid displaying the GUI
    import matplotlib as mpl
    mpl.use('Agg')

    from tempfile import NamedTemporaryFile
    from .std import tqdm_gui as tgui

    with NamedTemporaryFile(suffix='.png') as fout:
        for _ in tgui(np.linspace(0, 10, 1e4)):
            pass
        tgui.display()
        tgui.fig.savefig(fout.name)

        # Read the png back
        from sys import version_info
        if version_info[0] >= 3:
            fopen = open
        with fopen(fout.name, 'rb') as fin:
            from .utils import _b64encode

# Generated at 2022-06-24 10:14:37.304194
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from time import sleep
    for _ in tqdm_gui(range(100)):
        sleep(0.5)
    return True


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:46.023393
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from tqdm.gui import tqdm
    import time
    # with progressbar
    progressbar = tqdm(total=100)
    for i in range(100):
        progressbar.update()
        time.sleep(0.01)
    # without progressbar
    progressbar = tqdm(total=None)
    for i in range(100):
        progressbar.update()
        time.sleep(0.01)



# Generated at 2022-06-24 10:14:49.316409
# Unit test for function tgrange
def test_tgrange():
    """Test function tgrange()"""
    with tqdm(tgrange(3)) as t:
        for i in t:
            pass
        t.clear()
        t.close()
        assert not len(t)



# Generated at 2022-06-24 10:14:55.794670
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    class FakeTqdmGui(tqdm_gui):
        """Fake class to test the method display"""
        def __init__(self):
            super(FakeTqdmGui, self).__init__()

            self.ax = lambda: None
            self.ax.get_ylim = lambda: (0, 0)
            self.ax.set_ylim = lambda ymin, ymax: None
            self.ax.figure = lambda: None
            self.ax.figure.canvas = lambda: None
            self.ax.figure.canvas.draw = lambda: None
            self.ax.set_title = lambda title, fontname="DejaVu Sans Mono", fontsize=11: None
            self.ax.set_xlim = lambda xmin, xmax: None
            self.ax

# Generated at 2022-06-24 10:15:01.646958
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .gui import tqdm_gui
    from time import sleep

    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            sleep(0.2)
            pbar.update(1)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:08.247257
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # this is a strange test because we won't see if anything fails
    #  but if everything is fine, the GUI should close
    import matplotlib.pyplot as plt
    plt.figure(num=None, figsize=(9, 2), dpi=80, facecolor='w', edgecolor='k')
    plt.subplots_adjust(left=0.25, bottom=0.25)

    t = tqdm(total=100)
    for i in range(100):
        t.update()
    t.close()
    # restore matplotlib state before exiting
    plt.ion()
    plt.show()
    plt.clf()
    plt.close()

# Generated at 2022-06-24 10:15:18.047996
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib

    import matplotlib.pyplot as plt
    t = tqdm_gui(total=0, desc="Test", leave=False)
    mock_isinteractive = mocker.patch("matplotlib.pyplot.isinteractive")
    mock_isinteractive.return_value = True
    mocker.patch("matplotlib.pyplot.close")
    mocker.patch("tqdm.gui.tqdm.plt.close")
    t.close()
    mock_close = mocker.patch("matplotlib.pyplot.close")
    mock_close.assert_called_once_with(t.fig)
    mock_isinteractive.assert_called_once_with()
    mock_close.reset_mock()
    t.wasion = False  # was NOT in interactive

# Generated at 2022-06-24 10:15:20.963225
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    t = tqdm_gui(total=1)
    plt.ion()
    t.clear()

# Generated at 2022-06-24 10:15:28.525487
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    for _ in tqdm_gui(xrange(5)):
        sleep(0.1)
    sleep(0.5)
    for _ in tqdm_gui(xrange(5), leave=True):
        sleep(0.1)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:35.591273
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase

    class TestTqdm(TestCase):
        def test_tqdm_gui_close(self):
            t = tqdm_gui(bar_format="{l_bar}{bar}|{n_fmt}|{r_bar}", total=512,
                         leave=False)
            ('|0/512|                                                         '
             '                                  | 0 B/s |')
            for i in t:
                pass
            _ = t.close()  # if no exception raised: OK
    t = TestTqdm()
    t.test_tqdm_gui_close()

# Generated at 2022-06-24 10:15:43.425644
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    pbar = tqdm(total=2)
    pbar.update(1)
    # remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # remember if external environment is interactive
    wasion = plt.isinteractive()
    pbar.close()
    # check if the environment was restored properly
    assert plt.rcParams['toolbar'] == toolbar
    assert plt.isinteractive() == wasion

# Generated at 2022-06-24 10:15:46.087840
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Unit test for constructor of class tqdm_gui"""
    with tqdm(total=100) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:15:54.714907
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Unit test for method clear of class tqdm_gui
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return
    # Total is None
    my_tqdm = tqdm_gui()
    assert (len(my_tqdm.xdata) == 0
            and len(my_tqdm.ydata) == 0
            and len(my_tqdm.zdata) == 0)
    my_tqdm.n = 10
    my_tqdm.last_print_n = 5
    my_tqdm.last_print_t = 0
    my_tqdm.start_t = 0
    my_tqdm.display()

# Generated at 2022-06-24 10:15:58.560717
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from tqdm import trange
    from time import sleep
    list(trange(10))
    sleep(1)
    try:
        list(trange(10))
    except:
        raise TypeError("Test fails: cannot create a second progressbar")

# Generated at 2022-06-24 10:16:07.520952
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from unittest import TestCase, main

    class TestTqdmGuiDisplay(TestCase):
        def setUp(self):
            from threading import Lock
            # Reset params
            tqdm_gui._instances = []
            tqdm_gui.disable = False
            # Initialize tqdm_gui instance
            self.t = tqdm_gui(
                total=1, mininterval=0.0,
                desc='test', ncols=1, ascii=True, disable=False,
                unit='it', unit_scale=False, dynamic_ncols=False,
                smoothing=0.3, bar_format=None, initial=0, position=None,
                leave=False, miniters=None)
            self.t._lock = Lock()


# Generated at 2022-06-24 10:16:17.752172
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    warn("Test not implemented", TqdmExperimentalWarning, stacklevel=2)


if __name__ == '__main__':
    import time
    # total = 100
    total = None
    for i in tqdm(range(total), desc='test', unit='it'):
        time.sleep(0.01)
        if i == 5:
            raise ValueError()
    for i in tqdm(range(total), desc='test', unit='it', leave=True):
        time.sleep(0.01)
    for i in tqdm(total=total, desc='test', unit='it'):
        i += 1
        time.sleep(0.01)

# Generated at 2022-06-24 10:16:26.593629
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test method close of class tqdm_gui"""
    import sys
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    mpl.rcParams['toolbar'] = 'None'
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")
    ax.grid()
    ax.set_ylabel((1 if 1 else "it") + "/s")
    ax.legend(("cur", "est"), loc='lower left')
    ax.set_title("OK", fontname="DejaVu Sans Mono", fontsize=11)
    ax.invert_x

# Generated at 2022-06-24 10:16:29.466681
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm_gui(0,leave=True) as t:
        t.close()

if __name__ == "__main__":
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:16:32.919104
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm
    from .utils import _range
    for i in tqdm(_range(5)):
        tqdm.clear()
    tqdm.close()

# Generated at 2022-06-24 10:16:35.350500
# Unit test for function tgrange
def test_tgrange():
    # simple sanity test
    from time import sleep
    from numpy.random import uniform
    sleep(uniform(0.1, 1))
    for i in tgrange(10):
        sleep(uniform(0.05, 0.2))
    print("", flush=True)



# Generated at 2022-06-24 10:16:45.185919
# Unit test for function tgrange
def test_tgrange():
    import sys
    import time
    a = 0
    with tqdm_gui(total=100) as pbar:
        for i in tgrange(10):
            a += i
            pbar.set_description("Processing %i" % i)
            time.sleep(1)
    # ensure the output is correct
    assert a == 45
    # ensure the progressbar is updated
    if sys.version_info[0] > 2:
        try:
            pbar.set_description(u"\U0001F4A9")
        except UnicodeEncodeError:
            pass

test_tgrange()
del test_tgrange

# Generated at 2022-06-24 10:16:49.411290
# Unit test for function tgrange
def test_tgrange():
    import matplotlib
    for i in tgrange(10):
        assert i == i


# Unit tests for class tqdm_gui

# Generated at 2022-06-24 10:16:52.716021
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui, trange
    for i in trange(100):
        pass



# Generated at 2022-06-24 10:16:55.546284
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=100) as pbar:
        for _ in range(100):
            pbar.clear()

# Generated at 2022-06-24 10:17:06.034538
# Unit test for function tgrange
def test_tgrange():
    """Test function tgrange"""
    from .utils import _progbar
    from .std import TqdmTypeError, TqdmDeprecationWarning
    from .std import tqdm_ecli, tqdm_notebook
    from .utils import Printing

    # Test if print(tqdm_notebook) works
    assert tqdm_notebook(1, file=None)

    # Test if tgrange works
    with _progbar(1) as pbar:
        assert isinstance(pbar, tqdm_gui)
    g = tgrange(3, file=None)
    assert repr(g) == 'tgrange(3)'  # Test repr
    iter(g)
    g.close()
    with Printing():
        with _progbar(3):
            pass

# Generated at 2022-06-24 10:17:11.284435
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """test_tqdm_gui_clear"""
    with tqdm(total=10) as t:
        for _ in range(5):
            t.clear()
            t.update()
        t.clear()
        t.refresh()
        t.clear()
        t.update()

# Generated at 2022-06-24 10:17:13.568641
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for _ in tgrange(3):
        pass
    for _ in tgrange(0, 3):
        pass
    for _ in tgrange(0, 3, 1):
        pass



# Generated at 2022-06-24 10:17:19.101384
# Unit test for function tgrange
def test_tgrange():
    import matplotlib.pyplot as plt

    plt.close('all')
    for i in tqdm(tgrange(10 ** 3), desc='Loop'):
        plt.pause(1e-10)
    for i in tqdm(tgrange(10), desc='Loop'):
        plt.pause(1e-10)


if __name__ == '__main__':
    print('Testing tqdm_gui()')
    test_tgrange()

# Generated at 2022-06-24 10:17:27.249571
# Unit test for function tgrange
def test_tgrange():
    from .std import TqdmDeprecationWarning
    from .std import tqdm as std_tqdm

    with std_tqdm(ascii=True, total=0) as pbar:
        assert 'gui' in pbar.format_dict['bar_format']

    with std_tqdm(ascii=True, total=0) as pbar:
        assert not pbar.gui
        warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
        pbar.gui = True
        assert pbar.gui

    with std_tqdm(ascii=True, total=0) as pbar:
        pbar.gui = True
        assert pbar.gui
        pbar.gui = False
        assert not pbar.gui
        pbar.gui = True


# Generated at 2022-06-24 10:17:36.634197
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Method display test"""
    class TqdmGui(tqdm_gui):
        """Shorter class name"""
        _instances = []
        def __init__(self, *args, **kwargs):
            """Initialisation method"""
            self.disable = False
            self.last_print_t = 0.0
            self.last_print_n = 0
            self._instances.append(self)
            self._iterable = args[0]
            self.start_t = None
            length = kwargs.get('total', None)
            if length is None:
                try:
                    length = len(self._iterable)
                except (TypeError, AttributeError):
                    length = None
            self.total = length
            self.n = 0
            self.mininterval = 0.1


# Generated at 2022-06-24 10:17:48.035360
# Unit test for function tgrange
def test_tgrange():
    """Unit test for tgrange"""
    assert tgrange(7).__repr__() == "0%|                                      | 0/7 [00:00<?, ?it/s]"
    assert tgrange(7).__str__() == "0%|                                      | 0/7 [00:00<?, ?it/s]"
    assert tgrange(7, 2).__repr__() == "0%|                                      | 0/7 [00:00<?, ?it/s]"
    assert tgrange(7, 2).__str__() == "0%|                                      | 0/7 [00:00<?, ?it/s]"
    assert tgrange(7, 2, 0.001).__repr__() == " 0%|                                          | 0/7 [00:00<?, ?it/s]"


# Generated at 2022-06-24 10:17:49.145549
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=10) as t:
        t.close()

# Generated at 2022-06-24 10:17:56.201569
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    """Tests tqdm.gui.tqdm_gui.close()"""
    # Cygwin: matplotlib not available
    import os
    if os.name == 'posix' and os.uname()[0] == 'CYGWIN_NT-5.1':
        return
    from .utils import _supports_unicode

    if not _supports_unicode():
        return

    import matplotlib as mpl
    old_toolbar = mpl.rcParams['toolbar']
    # tqdm_gui.close()
    tqdm_gui().close()
    assert mpl.rcParams['toolbar'] == old_toolbar
    mpl.rcParams['toolbar'] = 'toolbar2'
    # tqdm_gui.close()


# Generated at 2022-06-24 10:18:06.924251
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from random import random
    from time import sleep
    from copy import copy
    import matplotlib.pyplot as plt
    plt.ion()
    # Initialize:
    t = tqdm(total=100)
    # Those values don't matter
    t.last_print_n = t.last_print_t = 0
    t.start_t = t._time() - 3600

    # Initialize the plot
    t.display()

    # Generate random data with random "ticks"
    total = 100
    y = [0] * total
    z = [0] * total
    for i in range(total):
        # "tick"
        y[i] = max(0, random() - 0.3)
        z[i] = max(0, random() - 0.3)
        t