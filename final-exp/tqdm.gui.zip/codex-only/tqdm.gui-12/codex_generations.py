

# Generated at 2022-06-24 10:12:33.951772
# Unit test for function tgrange
def test_tgrange():
    from .utils import FormatStop, RawTextFormatStop
    from ._version import __version__

    for _ in trange(10):
        pass
    with trange(10) as t:
        for _ in t:
            t.set_postfix(t="test")
    list(trange(10))
    trange(10, desc="desc")
    trange(10, 10)
    trange(10, desc="desc", unit="test")
    trange(10, desc="desc", unit="", leave=True)
    trange(10, desc="desc", ascii=True,
           unit="test", leave=True, mininterval=0.1)
    trange(10, desc="desc", unit="test",
           total=10, leave=True, mininterval=0.1)
    trange

# Generated at 2022-06-24 10:12:38.127021
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    class x(tqdm_gui):
        def clear(self, *_, **__):
            exit(1)

    try:
        with x(1) as bar:
            pass
    except Exception:
        pass
    else:
        assert 1 == 2, "If the code reaches here, then the unit test is broken."

# Generated at 2022-06-24 10:12:46.410536
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase
    from numpy import array
    from matplotlib import pyplot as plt

    t = tqdm_gui(total=100, leave=False)
    for _ in t:
        t.display()
    assert t.hspan.get_xy()[2, 0] == 1.0
    t.close()

    t = tqdm_gui(leave=False)
    for _ in t:
        t.display()
    assert t.hspan.get_xy()[2, 0] == 0.0
    t.close()

    # Test that progressbar goes beyond 100%
    t = tqdm_gui(total=100, leave=False)
    for _ in t:
        t.update(10)

# Generated at 2022-06-24 10:12:49.585492
# Unit test for function tgrange
def test_tgrange():
    from os import system

    for i in tgrange(15):
        system('sleep 1')


if __name__ == '__main__':  # pragma: no cover
    test_tgrange()

# Generated at 2022-06-24 10:12:56.940735
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time

    with tqdm_gui(total=1000, leave=False) as pbar:
        for i in range(1000):
            pbar.update(1)
            time.sleep(0.01)

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:02.872812
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    from numpy.random import rand
    from numpy import linspace
    from numpy import sum as npsum

    for i in tgrange(10):
        sleep(0.1)

    for i in tgrange(9, -1, -1):
        sleep(0.1)

    for i in tgrange(9, -1, -1, desc='desc', leave=True,
                     bar_format="{percentage:3.0f}%|{bar}|"):
        sleep(0.1)

    for i in tgrange(10, desc='desc', leave=True,
                     ascii=True, unit='i', unit_scale=True, miniters=1):
        sleep(rand())


# Generated at 2022-06-24 10:13:06.303833
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    tgrange(20)
    time.sleep(5)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:12.595536
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib
    matplotlib.use('TkAgg')
    from time import sleep
    from tqdm import tqdm
    from numpy import random
    n = 100
    pbar = tqdm(total=n)
    for i in range(n):
        pbar.set_description("Example iteration %i" % i)
        pbar.update(1)
        sleep(random.randint(10) / 100.0)
    pbar.close()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:15.936042
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from matplotlib.pyplot import ion, ioff, close
    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.update()
    with tqdm_gui(total=100) as t:
        ion()
        for i in range(100):
            t.update()
        t.close()
        ioff()
        close('all')

# Generated at 2022-06-24 10:13:28.122539
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_equal

    x = tqdm_gui(total=None, gui=True, leave=True)
    x.last_print_n = 0
    x.n = 0
    x.start_t = 0

    x.display()
    assert_equal([x.xdata, x.ydata, x.zdata, x.last_print_t], [[0.0], [0.0], [0.0], 0.0])

    x.display()
    assert_equal([x.xdata, x.ydata, x.zdata, x.last_print_t], [[0.0, 0.0], [0.0, 0.0], [0.0, 0.0], 0.0])

    x.display()

# Generated at 2022-06-24 10:13:32.819945
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for tqdm_gui
    """
    # Create a window for the progressbar
    import matplotlib.pyplot as plt
    from time import sleep

    t = tqdm_gui(total=100)
    for i in t:
        sleep(0.1)
    plt.close("all")
    assert t.n == 100
    assert t.disable == True


# Test on random module

# Generated at 2022-06-24 10:13:35.123297
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    with tqdm_gui(total=2) as pbar:
        pbar.close()



# Generated at 2022-06-24 10:13:41.265939
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import os

    orig_stdout = sys.stdout
    sys.stdout = codecs.getwriter('utf-8')(io.StringIO())
    t = tqdm_gui(total=100, leave=False)
    t.display()
    t.update(1)
    t.display(nolock=1)
    t.update(2)
    t.close()
    del t
    sys.stdout = orig_stdout


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:13:52.890740
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    from .utils import FormatCustomText
    for n in tqdm(range(1001), desc='[test]', ncols=40, leave=False):
        t = tqdm(range(100), desc='[test]', ncols=40, leave=n != 1000,
                 bar_format=FormatCustomText(
                        '{bar}',
                        '{desc}',
                        '{percentage:3.0f}%',
                        bar_desc_delim=' ',
                        bar_desc_pos='left',
                        bar_postfix_sep=' '),
                 dynamic_ncols=n != 10)
        for i in t:
            if n != 10:
                t.display()

if __name__ == '__main__':
    test_tqdm_gui

# Generated at 2022-06-24 10:13:59.788918
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui(total=50, desc="foo").clear()


if __name__ == "__main__":  # pragma: no cover
    # Unit test for class tqdm_gui
    import time
    for i in tqdm_gui(range(10), desc='foobar'):
        time.sleep(0.1)
    for i in tqdm_gui(range(10), desc='foobar', disable=True):
        time.sleep(0.1)
    for i in tqdm_gui(range(10), desc='foobar', ascii=True):
        time.sleep(0.1)
    for i in tqdm_gui(range(10), desc='foobar', ncols=200):
        time.sleep(0.1)

# Generated at 2022-06-24 10:14:06.807112
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Unit test for method display of class tqdm_gui"""
    from time import sleep
    import numpy as np
    for i in tqdm_gui(np.arange(10), leave=False):
        sleep(0.1)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:11.289493
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib.testing.decorators import cleanup

    # Avoid "ValueError: k was not found in the axes dictionary"
    @cleanup
    def _test_tqdm_gui():
        t = tqdm_gui(range(100), leave=True)
        t.close()
    _test_tqdm_gui()

# Generated at 2022-06-24 10:14:14.819845
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:20.446221
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    tgrange(2)
    tgrange(2, 3)
    tgrange(2, 3, 3)
    tgrange(100000, bar_format='{l_bar}{bar:10}{r_bar}')
    for i in tgrange(11, desc="TESTING", total=11):
        pass


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:14:31.370570
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test init and close"""
    with tqdm(total=100) as pbar:
        assert pbar.disable is False
        pbar.close()
        assert pbar.disable is True
        pbar.close()  # test double close

    with tqdm(total=100, disable=True) as pbar:
        assert pbar.disable is True
        pbar.close()

    with tqdm(total=100, disable=True, unit='it', unit_scale=True) as pbar:
        assert pbar.unit == 'it'
        assert pbar.unit_scale is True

    with tqdm(total=100, disable=True, unit='it', leave=False) as pbar:
        assert pbar.leave is False

    with tqdm(total=100) as pbar:
        p

# Generated at 2022-06-24 10:14:42.700349
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    import sys
    import time

    # Prepare the figure
    fig, ax = plt.subplots()
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")
    ax.set_ylabel("unit/s")

    # Prepare the progressbar
    progress_bar = ax.axvspan(0, 0, color='g')
    plt.pause(1e-9)

    progress = 0
    xdata = []
    ydata = []

    # Keep testing until
    while progress < 100:
        xdata.append(progress)
        ydata.append(np.random.rand() * 40)

        ax.set_ylim(0, np.array(ydata).max()*1.1)

# Generated at 2022-06-24 10:14:51.565823
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test behaviours of method close of class tqdm_gui"""
    try:
        import matplotlib
    except ImportError:
        try:
            import sys
            import tqdm.gui
            print("Matplotlib is not installed")
            print("Please install Matplotlib using: pip install matplotlib")
            print("(You can safely ignore the above-mentioned warning for now)")
            print(tqdm.gui.__file__)
            sys.exit(1)
        except ImportError:
            print("Matplotlib is not installed")
            print("Please install Matplotlib using: pip install matplotlib")
            print("(You can safely ignore the above-mentioned warning for now)")
            import sys
            sys.exit(1)
    t = tqdm_gui(total=100, desc="Downloading")


# Generated at 2022-06-24 10:14:55.260910
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import _range

    for leave in [True, False]:
        for _ in tqdm_gui(_range(5), leave=leave):
            pass

# Generated at 2022-06-24 10:15:05.298844
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():

    msg = "Enter key: "
    tqdm_gui.write(msg, file=sys.stdout)
    try:
        input()
    except KeyboardInterrupt:
        tqdm_gui.write(len(msg) * ' ', file=sys.stdout)
        tqdm_gui.write('\b' * len(msg), file=sys.stdout)
        tqdm_gui.write('\r', file=sys.stdout)
        raise
    tqdm_gui.write(len(msg) * ' ', file=sys.stdout)
    tqdm_gui.write('\b' * len(msg), file=sys.stdout)
    tqdm_gui.write('\r', file=sys.stdout)

if __name__ == '__main__':
    test_

# Generated at 2022-06-24 10:15:12.181328
# Unit test for function tgrange
def test_tgrange():
    import sys
    import time
    if sys.version_info[0] < 3:
        tgrange_ =  tqdm_gui(xrange(10), leave=True)
    else:
        tgrange_ =  tqdm_gui(range(10), leave=True)
    for i in tgrange_:
        if i == 6:
            tgrange_.n = 5
        if i == 8:
            tgrange_.close()
        time.sleep(0.1)


# Generated at 2022-06-24 10:15:17.963122
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    import time
    total = 10

    with tgrange(total) as progressbar:
        progressbar.display = lambda *args, **kwargs: None
        for i in progressbar:
            progressbar.write("\b" * progressbar.width)
            progressbar.write("\r" + "o" * i + "*")
            sys.stdout.flush()
            time.sleep(0.1)

# Generated at 2022-06-24 10:15:21.810054
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10) as t:
        for i in t:
            t.n = i + 1
            t.display()
            t.update(1)
            assert t.miniters == 1
            assert t.desc == "unknown"
            assert t.total == 10

        assert t.miniters == 1
        assert t.desc == "unknown"
        assert t.total == 10
        assert t.disable is True

        t.close()

# Generated at 2022-06-24 10:15:27.002836
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():   # pragma: no cover
    from time import sleep
    from random import random
    from .utils import _range

    import matplotlib.pyplot as plt
    # Create a new figure for the progressbar
    fig = plt.figure()
    # Create a new set of axes for this figure
    ax = fig.add_subplot(111)

    for i in tqdm_gui(range(10), total=10, ascii=True,
                   mininterval=0.5, miniters=1,
                   desc='1st loop'):
        sleep(0.1)
        # Update the progressbar with each iteration
        ax.plot(range(10), range(10), color='#66ff66')
        ax.set_title("1st loop (finished %d/10)" % (i+1))
        fig

# Generated at 2022-06-24 10:15:30.583820
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for leave in [True, False]:
        t = tqdm(total=10, leave=leave)
        for i in xrange(10):
            t.clear()
            t.update(1)
        t.close()

# Generated at 2022-06-24 10:15:34.468387
# Unit test for function tgrange
def test_tgrange():
    import time
    import sys
    if sys.version_info[0] > 2:
        tgrange = tqdm_gui  # pragma: no cover
    for i in tqdm(tgrange(4, 25, 2)):
        time.sleep(0.1)
        pass

# Generated at 2022-06-24 10:15:41.244531
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    try:
        for _ in tqdm(range(10), gui=True):
            pass
    except (UnicodeDecodeError, UnicodeEncodeError):
        warn("Unicode error on Windows, which may be normal "
             "(see https://bugs.python.org/issue18378#msg215215 for details)",
             UserWarning)



# Generated at 2022-06-24 10:15:43.038761
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(total=2)
    t.close()
    assert t.disable

# Generated at 2022-06-24 10:15:53.033534
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Check the GUI close method for a singlebar case"""
    from matplotlib.pylab import close
    import time
    import numpy as np

    t = tqdm_gui(total=10, ncols=50, leave=False, unit='i')
    for i in np.linspace(0, 5, 50):
        time.sleep(.1+1e-6)
        t.update(i+1)

    # Test close method
    t.close()

    # Test close on last instance
    t = tqdm_gui(total=10, ncols=50, leave=False, unit='i')
    for i in np.linspace(0, 5, 50):
        time.sleep(.1+1e-6)
        t.update(i+1)

    # Test close on last

# Generated at 2022-06-24 10:15:56.643111
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=100) as pbar:
        for i in range(100):
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:05.606563
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from io import BytesIO
    try:
        from unittest.mock import call
    except ImportError:
        from mock import call

# Generated at 2022-06-24 10:16:07.880584
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    sys.stderr = open('/dev/null', 'w')
    instance = tqdm(total=200)
    instance.display()
    instance.close()

# Generated at 2022-06-24 10:16:12.770738
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm.gui import tqdm
    from time import sleep

    for _ in tqdm(range(10), disable=False):
        sleep(0.1)
    for _ in tqdm(range(10), disable=True):
        sleep(0.1)
    for _ in tqdm(range(10), disable=True):
        sleep(0.1)


if __name__ == '__main__':
    from time import sleep
    import numpy as np
    g = tqdm(total=1000)
    for i in range(20):
        sleep(0.2)
        g.update(10)
    g.close()

    d_arr = np.random.normal(size=1000)

    for i in tgrange(1000):
        sleep(0.001)
        d_

# Generated at 2022-06-24 10:16:21.985483
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.pyplot import figure

    from .std import setsig
    from .utils import naturalsize

    setsig(True)


# Generated at 2022-06-24 10:16:29.677093
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase, main
    from time import sleep
    import sys

    class TestProgressbar(std_tqdm, TestCase):
        def __init__(self, *args, **kwargs):
            super(TestProgressbar, self).__init__(*args, **kwargs)
            # To test that desc is taken into account
            self.desc = "TEST"
        def close(self):
            super(TestProgressbar, self).close()
            self.assertAlmostEqual(self.n, 20, delta=1)
            self.assertEqual(self.total, 20)
            self.assertAlmostEqual(self.last_print_t - self.start_t, 0.2,
                                   delta=0.05)

# Generated at 2022-06-24 10:16:35.284650
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from unittest import TestCase, main
    from time import sleep

    class TestTqdmGui(TestCase):

        def test_tqdm_gui_n_set(self):
            """Check if tqdm_gui instantiated with n=10"""
            t = tqdm_gui(10, leave=False)
            self.assertEqual(t.n, 10)

        def test_tqdm_gui_total_set(self):
            """Check if tqdm_gui instantiated with total=10"""
            t = tqdm_gui(total=10, leave=False)
            self.assertEqual(t.total, 10)

        def test_tqdm_gui_total_unset(self):
            """Check if tqdm_gui instantiated with total=None"""
            t = t

# Generated at 2022-06-24 10:16:40.355947
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(1), desc='desc', leave=False, disable=False):
        pass
    try:
        for _ in tqdm(range(1), desc='desc1', leave=False, disable=False):
            for _ in tqdm(range(1), desc='desc2', leave=False):
                pass
    except AttributeError:
        raise Exception("passed")


if __name__ == "__main__":
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:16:50.755153
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from sys import exc_info
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('sys.stderr') as p:
        with tqdm(total=10) as t:
            t.clear()
        from sys import version_info as v
        if v.major >= 3:
            # There is no more xrange
            p.write.assert_called_with(
                "tqdm_gui: clearing the Progressbar (calling tqdm_gui.close() "
                "without Ctrl-C or -q)", file=None)

# Generated at 2022-06-24 10:16:54.930822
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=100) as t:
        for i in range(100):
            t.update()
            # t.refresh()  # makes no sense

# Generated at 2022-06-24 10:16:55.506192
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass

# Generated at 2022-06-24 10:17:03.706861
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from random import random
    from time import sleep
    from .std import tqdm
    list(tqdm_gui(
        list(tqdm(range(10000), unit='B', unit_scale=True,
                  unit_divisor=1024, miniters=1000, mininterval=1e-2))
    ))
    from .gui import trange
    for i in trange(100, desc="testing"):
        sleep(1e-4 * random())

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:17:08.745401
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib.pyplot as plt
    plt.close('all')
    tgr = tgrange(60)
    for _ in tgr:
        tgr.display()
        if tgr.n >= 30:
            tgr.n = 0

# Generated at 2022-06-24 10:17:18.808827
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test for tqdm_gui's display method"""
    from .utils import format_sizeof, FormatCustomTextTest, UnicodeIO

    from collections import deque
    from time import sleep

    # __init__
    t = tqdm_gui(total=100, leave=True, miniters=1)
    assert hasattr(t, 'fig')
    assert hasattr(t, 'line1')
    assert hasattr(t, 'line2')
    # format_meter
    t.format_meter = FormatCustomTextTest()
    t.format_meter()  # initializes
    t.format_meter().split('|')

# Generated at 2022-06-24 10:17:25.167313
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:  # Catch import error
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        with tqdm_gui(unit="B", unit_scale=True,
                      unit_divisor=1024, miniters=1, desc="Gathering Data") as t:
            for i in _range(5):
                t.clear()
                # Must not crash here
        mpl.rcParams['toolbar'] = 'toolbar'
        plt.ion()
        plt.ioff()
        assert True
    except:
        assert False

# Generated at 2022-06-24 10:17:35.259607
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from unittest import TestCase
    except ImportError:  # pragma: no cover
        from unittest2 import TestCase
    from unittest.mock import MagicMock

    class Test(TestCase):
        def setUp(self):
            # patch the required functions
            self.plt_pause_mock = MagicMock()
            self.fig_canvas_draw_mock = MagicMock()

            def plt_pause(n):
                self.plt_pause_mock(n)
            self.plt_pause_patch = MagicMock(spec=plt_pause, side_effect=plt_pause)
            self.plt_pause_patch.return_value = self.plt_pause_patch


# Generated at 2022-06-24 10:17:36.960962
# Unit test for function tgrange
def test_tgrange():  # NOQA
    from time import sleep
    tot = 0
    for i in tgrange(5):
        sleep(1)
        tot += i
    assert tot == 10

# Generated at 2022-06-24 10:17:41.371268
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui(total=10, leave=True)
    for i in _range(10):
        t.display()
        t.update()
        t.last_print_t = t._time()
        t.last_print_n = t.n

# Generated at 2022-06-24 10:17:46.111725
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close() method."""
    t = tqdm(total=3)
    t.close()
    assert t.disable
    t = tqdm(total=3)
    t.disable = True
    t.close()
    assert t.disable

# Generated at 2022-06-24 10:17:56.234054
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time


# Generated at 2022-06-24 10:18:06.971257
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    from random import random

    pbar = tqdm_gui(total=1000)
    pbar.n, pbar.total = 0, 1000
    pbar.xdata = []
    pbar.ydata = deque([])
    pbar.zdata = deque([])
    pbar.last_print_n = 0
    pbar.last_print_t = 0
    for i in range(1000):
        with pbar.get_lock():
            pbar.update()
            pbar.n += 1
            pbar.last_print_n = pbar.n
            pbar.last_print_t = pbar.last_print_t or pbar._time()
            cur_t = pbar.last_print_t + random()
        pbar.display()
   

# Generated at 2022-06-24 10:18:17.440374
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import time
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Suppress tqdm deprecation warning in versions below 4.6.0
    std_tqdm._instances = set()

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    t = std_tqdm.tqdm(range(100), desc="Description", leave=True, unit='',
                      ascii=True, dynamic_ncols=True, disable=False,
                      unit_scale=True, mininterval=0)

# Generated at 2022-06-24 10:18:27.237263
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange
    """
    assert tgrange[:2] == tqdm[:2]


if __name__ == '__main__':  # pragma: no cover
    import time
    import pickle
    try:
        with open('_tqdm_gui_checkpoint', 'rb') as f:
            checkpoint = pickle.load(f)
    except:
        checkpoint = None
    if checkpoint:
        t = tqdm_gui(total=20, initial=checkpoint['i'], leave=True)
    else:
        t = tqdm_gui(total=20, leave=True)
    for i in t:
        time.sleep(0.1)
    with open('_tqdm_gui_checkpoint', 'wb') as f:
        pick

# Generated at 2022-06-24 10:18:29.685433
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for n in tqdm(range(2)):
        tqdm.clear()
tqdm_gui.clear = test_tqdm_gui_clear

# Generated at 2022-06-24 10:18:39.543258
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from sys import platform
    import numpy as np
    for i in trange(2, ncols=80):
        if i > 0:
            sleep(0.5)
    for i in trange(100, desc="Second one"):
        if i > 0:
            sleep(1e-2)
    for i in trange(200, desc="Second one", unit="it"):
        if i > 0:
            sleep(1e-3)
    for i in trange(500, postfix=["postfix line1", "postfix line2"],
                    ncols=60):
        if i > 0:
            sleep(1e-4)
    for i in trange(1000, leave=True):
        if i > 0:
            sleep(1e-3)

# Generated at 2022-06-24 10:18:40.784023
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm()
    t.clear()