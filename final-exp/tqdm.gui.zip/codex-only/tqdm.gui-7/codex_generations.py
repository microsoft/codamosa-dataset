

# Generated at 2022-06-24 10:12:39.437011
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    from numpy.random import randn

    # test normal
    total = 100
    for i in trange(total):
        z = randn(1000, 1000)
        _ = z.mean() ** 2
        sleep(1e-3)

    # test mininterval
    total = 100
    for i in trange(total, mininterval=0.2):
        z = randn(1000, 1000)
        _ = z.mean() ** 2
        sleep(0.01)

    # test miniters and mininterval
    total = 100
    for i in trange(total, mininterval=0.2, miniters=10):
        z = randn(1000, 1000)
        _ = z.mean() ** 2

# Generated at 2022-06-24 10:12:49.842814
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from inspect import getargspec
    from random import random

    pbar = tqdm_gui(total=100)
    assert getargspec(pbar.display).args == ["pos", "**kwargs"], \
        "wrong display() arguments"

# Generated at 2022-06-24 10:12:56.767245
# Unit test for function tgrange
def test_tgrange():
    from .std import trange
    from .std import tqdm

    for func in (trange, tqdm):
        with func(100) as bar:
            for i in bar:
                pass


if __name__ == '__main__':  # pragma: no cover
    # test here
    test_tgrange()

# Generated at 2022-06-24 10:13:00.948836
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # run tests with a tqdm_gui instance and make sure there's no error
    import gc
    from .utils import format_sizeof
    from .std import Bar
    from .std import TqdmExperimentalWarning

    with TqdmExperimentalWarning():
        for i in tqdm(range(10), desc="test", smoothing=0.0):
            pass
        gc.collect()
        assert format_sizeof(Bar) == "", "Bar object not deleted"

# Generated at 2022-06-24 10:13:06.162190
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from time import sleep
    import numpy as np

    a = np.random.rand(100)
    for i in ranged(5):
        for i in tqdm_gui(a, total=len(a), desc="test"):
            sleep(0.1)

# Generated at 2022-06-24 10:13:15.508412
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    from time import sleep
    from collections import defaultdict


# Generated at 2022-06-24 10:13:18.205935
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    with tqdm_gui(total=0) as pbar:
        pass
    assert pbar.disable



# Generated at 2022-06-24 10:13:29.647559
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from nose.tools import raises

    @raises(TypeError)
    def test_tqdm_gui_wrong_param():
        with tqdm_gui(range(3), file=__file__) as t:
            for i in t:
                pass
    test_tqdm_gui_wrong_param()

if __name__ == "__main__":
    # Test
    import sys

    f = None if sys.stdout.isatty() else open('/dev/null', 'w')
    with tqdm(range(10), file=f) as t:
        for i in t:
            pass

    with tqdm_gui(range(10), file=f) as t:
        for i in t:
            pass

# Generated at 2022-06-24 10:13:41.765375
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm._utils import _term_move_up
    from tqdm._utils import IS_PY2
    from tqdm._utils import _environ_cols_wrapper
    from tqdm._tqdm import FormatCustomText

    class TqdmTypeError(TypeError):
        pass

    try:
        hasattr(int, '__index__')  # Python <3
    except Exception:
        _int_classes = (int, long)  # pragma: no cover
    else:
        _int_classes = int


# Generated at 2022-06-24 10:13:47.681240
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    global tqdm_gui
    from .gui import tqdm as tqdm_gui
    try:
        prog = tqdm_gui(total=100)
        prog.clear()
        prog.update(10)
        prog.close()
    except Exception as e:
        raise e

# Generated at 2022-06-24 10:13:50.386219
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(3):
        sleep(0)
    with trange(3) as t:
        for _ in t:
            sleep(0)
            t.set_postfix(foo="bar")



# Generated at 2022-06-24 10:13:52.744647
# Unit test for function tgrange
def test_tgrange():
    for _ in tgrange(1):
        pass



# Generated at 2022-06-24 10:13:58.047507
# Unit test for function tgrange
def test_tgrange():
    l = tgrange(5)
    for _ in l:
        pass
    assert l.n == 5
    l.close()

    l = tgrange(5, 5)
    for _ in l:
        pass
    assert l.n == 5
    l.close()

    l = tgrange(5, -5)
    for _ in l:
        pass
    assert l.n == 5
    l.close()

    l = tgrange(5, 0)
    for _ in l:
        pass
    assert l.n == 0
    l.close()

# Generated at 2022-06-24 10:14:09.472011
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    DummyTqdmGui = tqdm_gui.__base__
    dummy_instance = DummyTqdmGui()
    # test parameter of dummy_instance is given from arguments
    with tqdm_gui(ascii=True, miniters=1, mininterval=3) as t:
        for i in t:
            sleep(0.1)
    assert t.ascii == True and t.miniters == 1 and t.mininterval == 3
    # test parameter of dummy_instance is given from kwargs
    with tqdm_gui(ascii=True, miniters=1, mininterval=3) as t:
        for i in t:
            sleep(0.1)
    assert t.ascii == True

# Generated at 2022-06-24 10:14:11.531712
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    for i in tgrange(10):
        sleep(0.1)
    # Just test that it runs
    # TODO: add complete unit tests

# Generated at 2022-06-24 10:14:17.520780
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # import matplotlib.pyplot as plt
    with tqdm(total=10) as pbar:
        for i in range(5):
            pbar.update()
        # plt.pause(0.2)  # let's pause for a while
        for i in range(5):
            pbar.update()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:25.972531
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        import matplotlib.pyplot as plt
        import matplotlib as mpl
        i = tqdm_gui(total=10, leave=False)
        i.n = 10
        for _ in i:
            pass
        assert len(i.xdata) == len(i.ydata) == len(i.zdata) == len(i.xdata)
        assert mpl.rcParams['toolbar'] == 'None'
        assert not plt.isinteractive()
        i.close()
        assert mpl.rcParams['toolbar'] == i.toolbar
        assert not plt.isinteractive()
    except ImportError:
        pass


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:34.879509
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """ Test class tqdm_gui """
    # Test ctor
    with tqdm_gui(total=10) as t:
        assert t._instances
        assert len(t._instances) == 1
        # Test context manager closing
        assert t._instances
        assert len(t._instances) == 1
        t.close()
        assert not t._instances
    # Test clear
    with tqdm_gui(total=10, unit='it', mininterval=1e-5) as t:
        t.update(2)
        t.clear()
        t.update(2)
        assert t.n == 4
        t.display()


if __name__ == "__main__":
    r = test_tqdm_gui()

# Generated at 2022-06-24 10:14:43.226611
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from ._utils import _decref_after

    import matplotlib.pyplot as plt

    with _decref_after(plt.gcf()):
        plt.figure()
        t = tqdm(total=100, leave=False)
        for i in range(100):
            t.update()
            t.display()
        t.close()

        plt.figure()
        t = tqdm(leave=False)
        for i in range(10):
            t.update()
            t.display()
        t.close()

    plt.close('all')
    return True

# Generated at 2022-06-24 10:14:47.477366
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    os.environ['TKAGG'] = 'xpy'  # force default backend

    pbar = tqdm_gui(total=100)
    pbar.update()
    pbar.close()
    assert pbar.disable
    assert pbar.lock is None
    assert pbar._instances is None

# Generated at 2022-06-24 10:14:49.423717
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(10):
        pass


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:14:58.403861
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    class dummy_tqdm_gui(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self.total = 0
            self.xdata = [0]
            self.ydata = [0]
            self.zdata = [0]
            self.hspan = self.plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
            self.ax = True
            self.disable = False
            self.n = 0
            self.start_t = 1
            self.last_print_t = 1
            self.last_print_n = 1
            self.line1, self.line2 = True, True
            self.plt = True
            self.mpl = True

# Generated at 2022-06-24 10:15:07.268531
# Unit test for function tgrange
def test_tgrange():
    """Test base tgrange"""
    import sys
    for i in tgrange(10):
        pass
    for i in tgrange(100):
        for j in tgrange(100):
            pass
    for i in tgrange(100, unit="it"):
        for j in tgrange(100, unit="it"):
            pass
    for i in tgrange(100, unit="it", unit_scale=True):
        for j in tgrange(100, unit="it", unit_scale=True):
            pass
    for i in tgrange(100, desc="one"):
        for j in tgrange(100, desc="{0:03d}".format(i)):
            pass

# Generated at 2022-06-24 10:15:12.385104
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10, mininterval=1) as t:
        for i in _range(10):
            t.update()
    with tqdm_gui(total=10, mininterval=1) as t:
        for i in _range(10):
            t.update()
            t.close()

# Generated at 2022-06-24 10:15:19.849532
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    with tqdm(total=7) as gui_tqdm:
        gui_tqdm.update(1)
        gui_tqdm.close()
        gui_tqdm.display()
        gui_tqdm.refresh()
        gui_tqdm.update(3)
        gui_tqdm.update(3)
        gui_tqdm.display()
        gui_tqdm.clear()

    for i in tgrange(4, 5):
        time.sleep(0.1)

    for i in trange(4, 5):
        time.sleep(0.1)

# Generated at 2022-06-24 10:15:32.764430
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .std import TqdmTypeError, TqdmKeyError, TqdmDeprecationWarning
    from .std import _range

    # Testing arguments
    with std_tqdm(total=100) as pbar:
        # Test total
        assert (pbar.total == 100)
        # Test position
        assert (pbar.n == 0)
        # Test dynamic_mess
        assert (pbar.dynamic_mess == [])
        # Test format
        assert (pbar.format_dict == {'bar_format': '{l_bar}{bar}{r_bar}'})
        # Test mininterval
        assert (pbar.mininterval == 0.1)
        # Test miniters
        assert (pbar.miniters == 1)
        # Test unit_scale

# Generated at 2022-06-24 10:15:43.874263
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    plt.figure(figsize=(9, 2.2))
    cur = 10
    est = 100
    percent = cur / est
    x_data = [cur / est]
    y_data = [percent]
    z_data = [percent]
    plt.plot(x_data, y_data, color='b')
    plt.plot(x_data, z_data, color='k')
    plt.axhspan(0, 1, xmin=0, xmax=1, color='g')
    plt.grid()
    plt.ylim(0, 1)
    plt.xlim(0, 100)
    plt.show()


if __name__ == '__main__':
    test_tqdm_gui_display

# Generated at 2022-06-24 10:15:46.594769
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with tqdm_gui(total=100, desc="test", leave=True) as pbar:
        pbar.display()
    return 'done'

# Generated at 2022-06-24 10:15:50.734407
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    t = tqdm_gui(total=2)
    t.update()
    t.close()
    try:
        t.update()
        raise RuntimeError("`disable` flag didn't work correctly.")
    except:  # pragma: no cover
        gc.collect()

# Generated at 2022-06-24 10:16:01.737656
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    from io import StringIO

    with StringIO() as fake_stdout, StringIO() as fake_stderr:
        sys.stdout = fake_stdout
        sys.stderr = fake_stderr
        bar = tqdm_gui(total=10, desc='TEST', mininterval=0)

        for i in _range(10):
            bar.update(1)
            if i == 5:
                bar.close()
            d = bar.format_dict
            # remove {bar}
            d['bar_format'] = (d['bar_format'] or "{l_bar}<bar/>{r_bar}").replace(
                "{bar}", "<bar/>")
            msg = bar.format_meter(**d)

# Generated at 2022-06-24 10:16:09.231070
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import array, arange

    # test 1D case
    pbar = tqdm_gui(range(100))
    for i, v in enumerate(pbar):
        pbar.display()
        sleep(0.01)

    # test 2D case
    pbar = tqdm_gui(arange(100))
    for i, v in enumerate(pbar):
        pbar.display()
        sleep(0.01)

if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:16:19.263675
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy.testing as npt
    from numpy.random import randint

    sample_data = []
    for _ in _range(10):
        sample_data.append((randint(0, 100), randint(0, 100)))
    xdata, ydata = zip(*sample_data)
    sample_data = []
    for _ in _range(10):
        sample_data.append((randint(0, 100), randint(0, 100)))
    xdata_new, ydata_new = zip(*sample_data)
    # after 10 additions
    t = tqdm_gui(total=100)
    t.xdata = xdata
    t.ydata = ydata
    t.zdata = ydata
    t.display(1, 5)

# Generated at 2022-06-24 10:16:25.277331
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import executable, argv
    from subprocess import Popen, PIPE, STDOUT
    from os import remove
    from tempfile import mkstemp
    from time import sleep

    source = """from __future__ import absolute_import, division, print_function
from tqdm import tqdm_gui
from time import sleep
import sys
for _ in tqdm_gui(range(1000),
                  desc='A single loop',
                  unit='it', unit_scale=True):
    sleep(0.01)
tqdm_gui.write('\\n...and now we wait')
sleep(2)
sys.exit(42)
"""

# Generated at 2022-06-24 10:16:28.671496
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10, ncols=40) as pbar:
        for _ in range(10):
            pbar.update()
            pbar.clear()
            pbar.refresh()

# Generated at 2022-06-24 10:16:32.487188
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Functional test for `tgrange()`."""
    with tqdm(tgrange(1000)) as t:
        for _ in t:
            _ = None

# Generated at 2022-06-24 10:16:40.772292
# Unit test for function tgrange
def test_tgrange():
    from .std import trange
    from .std import tgrange
    from .std import tqdm
    from .std import tqdm_gui
    from .gui import tgrange as tgrange_g

    assert repr(list(tgrange(0))).endswith("tqdm_gui(0)>")
    assert repr(list(tqdm_gui(0))).endswith("tqdm_gui(0)>")
    assert repr(list(tgrange(10))).endswith("tqdm_gui(10)>")

    # Ensure trange and tqdm still work
    assert repr(list(trange(0))).endswith("tqdm(0)>")

# Generated at 2022-06-24 10:16:46.166215
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.testing.decorators import cleanup

    @cleanup
    def inner():
        import time

        tqdm_gui.display()
        tqdm_gui.miniters = 1
        tqdm_gui.display()
        for i in tqdm_gui(range(4), leave=True, unit="i"):
            time.sleep(0.1)

    inner()

# Generated at 2022-06-24 10:16:52.359683
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .gui import tqdm
    for n in tqdm(range(1000), disable=True):  # Will crash if display fails
        pass


if __name__ == '__main__':
    from time import sleep
    from random import random
    try:
        for i in tqdm(range(1000), disable=True):
            sleep(random() * 0.01)
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:16:56.186263
# Unit test for function tgrange
def test_tgrange():
    """Simple unit testing"""
    for x in tgrange(4):
        assert x <= 4
        for y in tgrange(x, x + 4):
            assert x <= y < x + 4

# Generated at 2022-06-24 10:16:59.794579
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test that method clear() does not raise an exception.

    The method does not do anything for the class tqdm_gui.
    """
    from tqdm import gui
    gui.tqdm_gui().clear()

# Generated at 2022-06-24 10:17:11.141960
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from unittest import TestCase, main
    try:
        from numpy.random import randint
    except ImportError:
        from random import randint

    from .gui import tqdm_gui as tqdm

    class TqdmGUIdisplay(TestCase):
        def test_int(self):
            """Kwarg `total` = int."""
            tgr = tgrange(10, total=10, file=sys.stdout, disable=True)
            for i in tgr:
                self.assertEqual(tgr.miniters, 1)
                self.assertEqual(tgr.unit_scale, 1)
                self.assertEqual(tgr.n, i + 1)
                self.assertEqual(tgr.dynamic_ncols, True)


# Generated at 2022-06-24 10:17:20.956921
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import os

    # Check if we can import Tkinter
    try:
        import Tkinter as tk
        import ttk
    except ImportError:
        return


# Generated at 2022-06-24 10:17:28.276811
# Unit test for function tgrange
def test_tgrange():
    """Functional test."""
    from os import getpid
    from os import kill
    try:
        from signal import SIGKILL
    except ImportError:
        SIGKILL = None
    from time import sleep
    from subprocess import Popen

    if SIGKILL is None:
        try:
            from signal import CTRL_BREAK_EVENT
        except ImportError:
            return
        else:
            # On windows, SIGKILL is always an error :(
            SIGKILL = CTRL_BREAK_EVENT

    for _ in tqdm.tgrange(2):
        for i in tqdm.tgrange(5, desc='1st loop'):
            sleep(0.01)
        for i in tqdm.tgrange(100, desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-24 10:17:33.133643
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import sys

    x = tqdm_gui(total=100, desc='Test', gui=True)
    for i in range(10):
        x.update()
        plt.pause(0.1)
        sys.stdout.flush()
    x.close()

# Generated at 2022-06-24 10:17:37.129048
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    from tqdm import tqdm_gui as tg
    for i in tg(list(range(10)), ascii=True):
        sleep(.5)
        if i == 5:
            tg.clear()



# Generated at 2022-06-24 10:17:46.168138
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import os
    import sys
    import tempfile
    from time import sleep
    from subprocess import Popen, PIPE, STDOUT

    def read_file(fname):
        with open(fname, 'r') as fdesc:
            return fdesc.read()

    if sys.platform == 'darwin' and 'DISPLAY' not in os.environ:
        raise unittest.SkipTest("No DISPLAY set")
    if os.name == 'nt' and 'DISPLAY' not in os.environ:
        raise unittest.SkipTest("No DISPLAY set")

    # Return (stdout, stderr) of a process

# Generated at 2022-06-24 10:17:53.879598
# Unit test for function tgrange
def test_tgrange():
    import numpy
    assert numpy.allclose(
        [i for i in tgrange(10, 25)],
        [i for i in _range(10, 25)]
    )
    assert numpy.allclose(
        [i for i in tgrange(10, 25, 7)],
        [i for i in _range(10, 25, 7)]
    )
    assert numpy.allclose(
        [i for i in tgrange(25, 10, -7)],
        [i for i in _range(25, 10, -7)]
    )
    assert numpy.allclose(
        [i for i in tgrange(25, 10, -7, 2)],
        [i for i in _range(25, 10, -7, 2)]
    )

# Generated at 2022-06-24 10:18:02.770965
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from matplotlib.pyplot import close
    from random import randrange
    from time import sleep

    for i in tqdm(range(4)):
        try:
            for j in tqdm(range(10), leave=False):
                sleep(0.1)
                tqdm.write(str(i) + ";" + str(j))
                tqdm.clear()
            close('all')
        except ValueError:
            pass
    tqdm.close()


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:18:05.210141
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    t = tqdm_gui(range(15))
    t.close()
    assert t.disable



# Generated at 2022-06-24 10:18:08.950947
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    from time import sleep
    from tqdm.gui import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.clear()

# Generated at 2022-06-24 10:18:12.199289
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_true, assert_false
    from .gui import trange
    t = trange(4, leave=True)
    for i in t:
        t.display()
    assert_false(t.disable)
    t.close()
    assert_true(t.disable)

# Generated at 2022-06-24 10:18:15.276730
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        pbar = tqdm_gui(total=100)
        for i in _range(8):
            pbar.update(10)
            pbar.clear()
    finally:
        pbar.close()

# Generated at 2022-06-24 10:18:23.867543
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import mock

    # Test-1
    with mock.patch('matplotlib.pyplot.pause') as plt_pause, \
            mock.patch('matplotlib.pyplot.plot') as plt_plot:
        plt_plot.return_value = [1], [2]
        with tqdm_gui(total=50) as t:
            for i in _range(3):
                t.update()
        expected_list_of_args = [[1, 2], [1, 2], [1, 2]]
        assert plt_plot.call_count == 2
        assert plt_plot.call_args_list == expected_list_of_args
        expected_list_of_args = [[], [], []]
        assert plt_pause.call_count == 3
        assert plt

# Generated at 2022-06-24 10:18:31.123304
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """Test tqdm_gui.display()"""
    from .utils import FormatCustomText, FormatCustomTextTest
    from .std import tqdm_gui

    class DisplayTest(tqdm_gui):
        """Test for method display of class tqdm_gui"""
        def __init__(self, *args, **kwargs):
            """
            Initialization
            :param args: arguments
            :param kwargs: key-word arguments
            """
            # Initialize the "tqdm_gui" object
            super(DisplayTest, self).__init__(*args, **kwargs)
            self.title = "test"
            self.n = self.total = 100
            self.bar_format = "{title} {bar}"
            self.last_print_n = 0
            self.last

# Generated at 2022-06-24 10:18:36.564672
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib
    try:
        matplotlib.use("QT4Agg")
        import matplotlib.pyplot as plt

        tgrange(0)
        assert plt.isinteractive()
        plt.close("all")
    except matplotlib.cbook.MatplotlibDeprecationWarning:
        # Matplotlib backend not available
        pass

# Generated at 2022-06-24 10:18:46.625007
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.testing.decorators import cleanup
    import matplotlib.pyplot as plt
    import numpy as np


# Generated at 2022-06-24 10:18:51.848849
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    import matplotlib.pyplot as plt
    import gc

    test_tqdm_gui = tqdm_gui(total=10)
    # initialize the toolbars
    test_tqdm_gui.toolbar = plt.rcParams['toolbar']
    # initialize the wasion
    test_tqdm_gui.wasion = plt.isinteractive()
    # check to see if the total is equal to 10
    assert test_tqdm_gui.total == 10
    # call the method close
    test_tqdm_gui.close()
    # test to see if it is disabled
    assert test_tqdm_gui.disable
    # test to see if it is no longer an instance
    assert test_tqdm_gui not in test_tqdm_

# Generated at 2022-06-24 10:18:54.745511
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from random import randint
    from time import sleep
    from tqdm import tqdm_gui
    for _ in tqdm_gui(range(randint(1, 9)), unit='i'):
        sleep(0.01)

# Generated at 2022-06-24 10:19:02.635454
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm_gui

    pbar = tqdm_gui(10)

    # Remember if external environment uses toolbars
    toolbar = pbar.mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = pbar.plt.isinteractive()

    pbar.close()

    # Test if toolbars of external environment was restored
    assert pbar.mpl.rcParams['toolbar'] == toolbar
    # Test if non-interactive mode of external environment was restored
    assert pbar.plt.isinteractive() == wasion

# Generated at 2022-06-24 10:19:04.727530
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import gui, std
    gui.tqdm.close()
    gui.tqdm.clear()
    gui.tqdm.display()
    assert gui.tqdm.disable is True
    assert std.tqdm.disable is True

# Generated at 2022-06-24 10:19:07.868857
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        for i in tqdm_gui(range(10)):
            tqdm_gui.clear()
    except Exception as e:
        print(e)
        return False
    else:
        return True

# Generated at 2022-06-24 10:19:13.039338
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # TODO: Unit test that draws the GUI
    n = 1000
    t = tqdm_gui(total=n)
    for i in range(n):
        t.set_description('Spam %i' % i)
        t.update()
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:23.409128
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # open test_tqdm_gui_clear.py with idle
    # copy and paste it in the function test_tqdm_gui_clear
    # update the values of nb_loop and nb_test
    # play the function
    # close test_tqdm_gui_clear.py
    from types import GeneratorType  # to check iterators
    import matplotlib.pyplot as plt
    import time

    global nb_loop
    global nb_test

    #n = 4
    #t = 0.8
    #t = 0.1
    it = tqdm_gui(total=nb_loop)
    for i in range(nb_loop):
        it.clear()
        #it.close()
        #plt.close(it.fig)
        #d = plt.get_

# Generated at 2022-06-24 10:19:24.766840
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui(total=10).clear()

# Generated at 2022-06-24 10:19:34.939357
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=5) as pbar:
        assert hasattr(pbar, 'ax'), "tqdm_gui pbar has no 'ax' attribute."
        assert hasattr(pbar.ax, 'set_title'), "tqdm_gui pbar.ax has no 'set_title' attribute."
        pbar.clear()
        assert hasattr(pbar, 'ax'), "tqdm_gui pbar has no 'ax' attribute after clear."
        assert hasattr(pbar.ax, 'set_title'), "tqdm_gui pbar.ax has no 'set_title' attribute after clear."
        for i in _range(5):
            pbar.update()


# Generated at 2022-06-24 10:19:41.362349
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    t = tqdm_gui(total=1000, leave=True)
    try:
        time.sleep(0.2)
        t.clear()
        time.sleep(0.2)
    finally:
        t.close()

if __name__ == "__main__":
    for i in tqdm(range(1000)):
        time.sleep(.001)

# Generated at 2022-06-24 10:19:47.884609
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import trange
    from time import sleep
    from tqdm import _tqdm

    # Test create bar
    for i in trange(10):
        sleep(0.1)

    # Test close bar
    for i in trange(10):
        sleep(0.1)
        if i >= 1:
            _tqdm._instances.close()


if __name__ == '__main__':
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:19:49.482830
# Unit test for function tgrange
def test_tgrange():
    from .gui import tgrange
    from time import sleep
    for i in tgrange(4):
        sleep(.5)

# Generated at 2022-06-24 10:19:55.607043
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import matplotlib.pyplot as plt
    import matplotlib
    a = tqdm_gui(range(100), smoothing=0, leave=False)
    a.display()
    for i in a:
        pass
    assert a.disable
    assert matplotlib.rcParams['toolbar'] == 'None'
    assert not plt.isinteractive()
    a.close()
    assert matplotlib.rcParams['toolbar'] != 'None'
    # assert not plt.fignum_exists(a.fig.number)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:20:06.144964
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from nose.tools import nottest
        nottest
    except ImportError:
        from unittest import TestCase as nottest
    from .gui import tqdm_gui
    from time import sleep
    
    class TqdmGuiCloseTest(unittest.TestCase):
        def test_close(self):
            try:
                from matplotlib.pyplot import close  # matplotlib 1.5.1
            except ImportError:
                close = "close"
            with tqdm_gui(total=10) as pbar:
                for i in range(10):
                    sleep(0.04)
                    pbar.update(1)
            sleep(0.04)
            close('all')
    
    tqdm_gui.close()


# Generated at 2022-06-24 10:20:11.429799
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    # type: () -> None
    """Test `tqdm.gui.tgrange` function."""
    # pylint: disable=protected-access
    import random
    import time

    random.seed(0)
    with tgrange(1000, ncols=80) as t:
        for i in t:
            time.sleep(random.random() / 100)

# Generated at 2022-06-24 10:20:15.740315
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    with tqdm_gui(unit='foo', desc='testing clear()') as t:
        for i in _range(10):
            sleep(0.1)
            t.clear()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:20:22.853275
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    for i in tqdm_gui(range(4), disable=False):
        pass
        # tqdm_gui.clear()
    for i in tqdm_gui(range(4), disable=False):
        pass
        # tqdm_gui.clear()
    for i in tqdm_gui(range(4), disable=False):
        pass
        # tqdm_gui.clear()
    for i in tqdm_gui(range(4), disable=False):
        pass
        # tqdm_gui.clear()



# Generated at 2022-06-24 10:20:27.219124
# Unit test for function tgrange
def test_tgrange():
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        return

    for i in tgrange(5):
        for j in tgrange(10000):
            k = j / 2
        plt.pause(0.01)


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:20:30.955729
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.clear()
            t.display()
            t.update()

# Generated at 2022-06-24 10:20:33.598095
# Unit test for function tgrange
def test_tgrange():
    """Test for tgrange"""
    with tgrange(10, desc='Test!') as t:
        for _ in t:
            pass


# Generated at 2022-06-24 10:20:35.640255
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    with trange(3) as t:
        for i in t:
            pass



# Generated at 2022-06-24 10:20:41.448339
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import numpy as np
    # import time


# Generated at 2022-06-24 10:20:51.284476
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .std import tqdm_gui
    from .tqdm import TqdmTypeError
    from .utils import FormatCustomTextType
    from .utils import AutoBar as abst
    from .utils import CallbackIOWrapper as ciw

    # Check exceptions
    class TestException(Exception):
        pass

    with tqdm_gui(total=3) as pbar:
        pbar.update(1)
        try:
            raise TestException
        except TestException:
            pbar.write("Error!")
            pass
    with tqdm_gui(total=3) as pbar:
        pbar.update(1)
        try:
            raise TestException
        except TestException:
            pbar.write("Error!")
            pbar.write("2nd error!")


# Generated at 2022-06-24 10:20:56.310514
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import time

    for i in tqdm_gui(range(4), leave=True):
        plt.pause(1.0)

    for i in range(4):
        for i in tqdm_gui(range(10), leave=True):
            plt.pause(1.0)
        plt.close()
        time.sleep(1.0)

# Generated at 2022-06-24 10:20:59.604210
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Unit test for method clear of class tqdm_gui"""
    with tqdm_gui(total=10) as t:
        t.update()
        t.clear()



# Generated at 2022-06-24 10:21:09.196258
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmTypeError
    from .std import tqdm_gui as tg
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('matplotlib.pyplot.pause') as mock_pause:
        t = tg(total=100)
        t.clear()
        t.close()
        assert t.disable
        assert mock_pause.call_count == 1

if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    with tqdm_gui(total=100) as t:
        for i in range(100):
            sleep(0.02)
            t.update(1)

# Generated at 2022-06-24 10:21:15.055279
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    cnt = 0
    try:
        for i in tqdm_gui(range(100), leave=False, ncols=100):
            time.sleep(0.1)
            cnt += 1
    finally:
        assert cnt == 100
        tqdm_gui.close('all')
        print('done')


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:21:21.978972
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: nocover
    from time import sleep

    import matplotlib.pyplot as plt
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()

    # Test close()
    # 1) No leave, no disable
    pg = tqdm(total=10)
    pg.close()
    assert (toolbar == plt.rcParams['toolbar'] and
            wasion == plt.isinteractive())

    # 2) No leave, with disable
    pg = tqdm(total=10, disable=True)
    pg.close()
    assert (toolbar == plt.rcParams['toolbar'] and
            wasion == plt.isinteractive())

    #

# Generated at 2022-06-24 10:21:33.069004
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """Test for tqdm_gui constructor"""
    from time import sleep
    from numpy import std
    # test simple GUI (i.e. no axis)
    pbar_gui = tqdm_gui(total=10, desc='testing GUI', leave=False)
    for i in _range(10):
        sleep(0.01)
        pbar_gui.update(1)
    pbar_gui.close()
    # test GUI class in a subprocess
    with tqdm_gui(total=100, desc='testing GUI subprocess', leave=False) as pbar:
        # test with 100 time measurements
        for _ in tqdm_gui(total=100, leave=False):
            sleep(0.01)
            pbar.update(1)
    # test GUI (axis)

# Generated at 2022-06-24 10:21:37.146904
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy.testing import assert_equal

    n = 100
    pbar = tqdm_gui(total=n)
    for i in range(n):
        sleep(0.001)
        pbar.display()

    assert_equal(pbar.n, pbar.total)
    pbar.close()

# Generated at 2022-06-24 10:21:39.313490
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from time import sleep

    timer = tqdm_gui(loop=5)
    for i in timer:
        sleep(0.1)
    timer.close()
    assert timer.disable is True

# Generated at 2022-06-24 10:21:47.785331
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from ._utils import __interactive__  # pylint: disable=import-error
    if not (__interactive__ and tqdm.gui._matplotlib_available):
        return

    try:
        import matplotlib.pyplot as plt  # noqa
    except ImportError:
        return
    import time

    with tqdm.gui.tqdm() as t:
        for i in t:
            time.sleep(0.001)
            t.display()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:21:57.895847
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from ._utils import _decode_unicode
    from .std import tqdm as std_tqdm

    if std_tqdm.gui:
        warn("Skipping GUI test (requires cli)")
        return

    for msg in [None, "Testing..."]:
        fp = open(__file__, 'rb')

# Generated at 2022-06-24 10:21:59.606603
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=1000) as t:
        for i in _range(1000):
            t.update()

# Generated at 2022-06-24 10:22:05.364192
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    from time import sleep
    t = tqdm_gui(total=3)
    t.update()
    sleep(0.1)
    t.update()
    sleep(0.1)
    t.update()
    t.close()
    try:
        t.update()
    except:
        assert False, "Should not raise exception after close"

# Generated at 2022-06-24 10:22:14.537707
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_equal

    progress = tqdm_gui(total=10)
    progress.clear()

# Override slow tests for this specific class
# Uses `override` instead of `patch` to avoid calling the function twice
import nose
from .tests import TqdmTestCase
import tqdm.tests.override_tqdm_gui_tests
tests = TqdmTestCase(std_tqdm, tqdm_gui)
# Add tests only to subclass tests (not to std_tqdm tests)
tests.__name__ = "tqdm_gui_tests"
tests.__doc__ = "Tests specific to tqdm_gui"
tests.__test__["test_gui_deprecated"] = tests.__test__["test_override_gui_deprecated"]
del tests.__test

# Generated at 2022-06-24 10:22:21.982692
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import TqdmKeyError
    from time import sleep
    progressbar = tqdm_gui(total=None)
    progressbar.display()
    msg = progressbar.format_meter(10)
    assert msg.split(' ')[-2] == '0.00it/s'
    progressbar.last_print_n = 10
    progressbar.last_print_t = progressbar._time()
    progressbar.display()
    msg = progressbar.format_meter(10)
    assert msg.split(' ')[-2] == ' 0.00it/s'
    progressbar.last_print_n = 20
    progressbar.last_print_t = progressbar._time()
    progressbar.display()
    msg = progressbar.format_meter(10)

# Generated at 2022-06-24 10:22:24.952041
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(range(5)):
        pass
    for _ in tqdm_gui(range(5)):
        pass
    for _ in tqdm_gui(range(5)):
        pass

# Generated at 2022-06-24 10:22:29.335511
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    x = tqdm(range(10))
    for i in x:
        x.display()
        plt.pause(1e-9)
    x.close()

# Generated at 2022-06-24 10:22:33.339818
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for i in trange(4, desc='2nd loop'):
        for j in tqdm(range(100), desc='1st loop', leave=False, mininterval=0.01):
            pass
        print('finish')
        # tqdm_gui.clear(wait=False)