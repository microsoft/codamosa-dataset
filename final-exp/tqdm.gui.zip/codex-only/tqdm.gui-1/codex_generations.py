

# Generated at 2022-06-24 10:12:37.164517
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for i in tqdm_gui(xrange(2)):
        t = tqdm_gui(xrange(10))
        for j in t:
            t.clear()
            t.write('abcde')
            t.clear()
            t.write('f' * (5 + j))
        t.clear()
        t.close()


# Generated at 2022-06-24 10:12:42.465365
# Unit test for function tgrange
def test_tgrange():
    from collections import defaultdict
    from .std import tgrange

    # Test for issue #301
    for d in [defaultdict(int), defaultdict(lambda: None)]:
        for _ in tgrange(1000, miniters=1000, mininterval=0.1, leave=False,
                         ascii=True, total=1000, dynamic_ncols=True,
                         disable=False, unit='tests', ncols=1, unit_scale=False,
                         desc='testing', postfix=d):
            pass


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:12:49.716973
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import os
    # Incomplete unit tests for `tqdm_gui`
    for _ in tqdm(range(5)):
        pass
    for _ in tqdm(range(5), ascii=True):
        pass
    for _ in tqdm(range(5)):
        time.sleep(0.1)
        if _ == 3:
            break
    for _ in tqdm(range(5)):
        time.sleep(1)
        if _ == 3:
            break
    for _ in tqdm(range(5)):
        time.sleep(10)
        if _ == 3:
            break
    for _ in tqdm([]):
        pass
    for _ in tqdm(range(5), position=3):
        pass

# Generated at 2022-06-24 10:13:01.630596
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    if sys.version_info[0] < 3:
        # raise Warning('tqdm_gui.close() cannot be used with Python 2')
        return
    import matplotlib.pyplot as plt
    import time

    with tqdm(total=10) as mytqdm:
        for i in range(10):
            mytqdm.update()
            time.sleep(1)
    if plt.fignum_exists(mytqdm.fig.number):
        raise AssertionError('mytqdm.close() failed')
    if plt.isinteractive():
        raise AssertionError('plt.ion() not disabled by mytqdm.close()')

# Generated at 2022-06-24 10:13:08.846759
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from numpy import random
    random.seed(0)

    for i in tqdm(tgrange(4)):
        for j in tqdm(tgrange(100), total=100, leave=False):
            sleep(random.random() * 1e-3)
    for i in tqdm(tgrange(4)):
        for j in tqdm(tgrange(100), total=100, leave=True):
            sleep(random.random() * 1e-3)

# Generated at 2022-06-24 10:13:13.779707
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for tqdm.gui.tqdm's close method."""
    from .gui import tqdm
    with tqdm(total=100, unit='iB', leave=False, desc="Cleaning up files",
              miniters=1) as bar:
        bar.update(10)
        bar.close()
        assert bar.disable
        assert not bar.leave
    # check if the progressbar is closed

# Generated at 2022-06-24 10:13:17.529687
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=10) as pbar:
        pbar.clear()
        for i in range(10):
            pbar.update()

# Generated at 2022-06-24 10:13:21.426488
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=10) as t:
        for i in _range(10):
            sleep(0.1)
            t.update()

# Generated at 2022-06-24 10:13:33.353720
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .utils import format_interval
    from .std import tqdm_pandas as _tqdm_pandas
    from random import shuffle
    try:
        import pandas as pd
    except ImportError:  # pragma: no cover
        raise unittest.SkipTest()

    # Test data
    class Timed:
        def __init__(self, duration):
            self.duration = duration

    S = pd.Series([Timed(i * 0.01) for i in range(1, 101)])
    L = [Timed(i * 0.01) for i in range(1, 101)]
    D = pd.DataFrame(L)
    shuffle(L)
    shuffle(S.values)
    shuffle(D.values)

    # Test methods


# Generated at 2022-06-24 10:13:45.823904
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    def _test_tqdm_gui_display(t, v_t, v_t_prev, v_n, v_n_prev, v_t_i,
                           v_t_i_prev):
        """
        test `tqdm_gui.display` function
        """
        # set initial values
        t.last_print_t = v_t_prev
        t.last_print_n = v_n_prev
        t.start_t = v_t_i_prev
        # call method display
        t.display(n=v_n, v_t=v_t, v_t_i=v_t_i)
        # testing
        assert t.last_print_t == v_t or t.last_print_t == v_t_prev
        assert t.last_

# Generated at 2022-06-24 10:13:53.654863
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Test with generator
    assert next(tqdm_gui(range(1))) == 0
    # Test with list
    assert next(tqdm_gui(list(range(1)))) == 0
    # Test with list
    assert next(tqdm_gui(list(range(1)), total=5)) == 0
    # Test with iterator
    assert next(tqdm_gui(iter(range(1)))) == 0
    # Test with iterator
    assert next(tqdm_gui(iter(range(1)), total=5)) == 0



# Generated at 2022-06-24 10:13:56.872216
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    import numpy as np
    n = 20
    arr = np.arange(n)
    with tqdm_gui(total=n) as pbar:
        for i in arr:
            time.sleep(0.1)
            pbar.update()

# Test module
if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:59.806834
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Unit test for function tgrange."""
    import time
    with trange(5) as t:
        for _ in t:
            time.sleep(0.2)



# Generated at 2022-06-24 10:14:11.367188
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tgrange
    import matplotlib.pyplot as plt
    #import time
    #time.sleep(1)
    n = 100
    with tgrange(n, leave=True) as t:
        for i in t:
            #plt.pause(0.01)
            #time.sleep(0.01)
            #t.clear()
            pass
    return locals()


if __name__ == "__main__":
    print('Press Ctrl+C to stop')
    # test_tqdm_gui_clear()
    from .std import trange
    import matplotlib.pyplot as plt
    import time

    #for i in trange(10):
    for i in trange(10, leave=True):
        time.sleep(0.1)

# Generated at 2022-06-24 10:14:15.606448
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm import trange
    from time import sleep
    with trange(10) as t:
        for i in t:
            sleep(0.1)
            t.set_postfix(refresh=False)
            t.clear()
            sleep(0.1)
            t.update()


# Generated at 2022-06-24 10:14:20.491066
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot as plt
    x = tqdm_gui(total=100)
    for _ in x:
        x.update(1)
        plt.pause(1e-9)
    x.close()
    plt.pause(1e-9)


if __name__ == '__main__':
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:26.104037
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    trange(3, leave=False)
    time.sleep(0.5)

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:35.140260
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    try:
        from unittest import mock  # python >= 3.3
    except ImportError:
        from mock import mock
    from tqdm.gui import trange, tqdm
    from tqdm.utils import _term_move_up

    def reset_all():
        for obj in list(tqdm._instances):
            obj.close()
        tqdm.set_lock(None)

    def get_time(t):
        return t


# Generated at 2022-06-24 10:14:45.290535
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm import tqdm
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.gui import trange, tgrange
    from tqdm.gui import tqdm as tqdm_gui

    old_toolbar = mpl.rcParams['toolbar']
    old_wasion = plt.isinteractive()
    p = tqdm(range(2))
    p = tqdm(range(2), color='g')
    p = trange(5)
    p = tgrange(5)
    p.close()
    assert mpl.rcParams['toolbar'] == old_toolbar
    assert plt.isinteractive() == old_wasion


# Generated at 2022-06-24 10:14:53.383302
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test the method close of class tqdm_gui."""
    from tqdm.utils import _term_move_up
    from tqdm._utils import _environ_cols_wrapper
    from .std import _term_move_up

    # Test disable functionality
    with std_tqdm(total=10) as t:
        for i in t:
            pass
        assert t.disable
        assert t.desc == ""
        assert t.dynamic_ncols
        assert t.leave
        assert t.mininterval == 0.1
        assert t.n == t.total == 10
        assert t.ncols == _environ_cols_wrapper()
        assert t.postfix == {}
        assert t.disable_tqdm_csi
        assert t.unit == ''

# Generated at 2022-06-24 10:14:55.683631
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for i in trange(10):
        # tqdm_gui.clear does nothing, as expected
        tqdm_gui.clear(i)

# Generated at 2022-06-24 10:15:05.711568
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from numpy import isclose

    # Test 1
    total = 10
    cur_t = 0
    elapsed = 0
    delta_t = 1
    last_print_t = cur_t - delta_t
    last_print_n = 0
    start_t = cur_t

    for i in tgrange(total):
        sleep(1)
        cur_t = cur_t + 1
        elapsed = cur_t - start_t
        delta_it = i - last_print_n
        delta_t = cur_t - last_print_t

        # Inline due to multiple calls
        xdata = [i * 100.0 / total if total else cur_t]
        ydata = [delta_it / delta_t]
        zdata = [i / elapsed]

        y

# Generated at 2022-06-24 10:15:08.002966
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .gui import trange

    for _ in trange(4):
        pass



# Generated at 2022-06-24 10:15:11.451957
# Unit test for function tgrange
def test_tgrange():
    """
    Unit test for function tgrange
    """
    res = list(tgrange(5))
    try:
        assert res == list(range(5))
    except NameError:
        assert res == list(xrange(5))

# Generated at 2022-06-24 10:15:15.561566
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import time
    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:19.837646
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test constructor
    fig, ax = tqdm_gui.__init__(total=None, miniters=10, mininterval=0)
    assert len(fig.axes) == 1  # 1 axis
    assert len(ax.lines) == 2  # 2 lines
    assert len(ax.collections) == 1  # 1 hspan polygon



# Generated at 2022-06-24 10:15:31.773020
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Unit test for `tqdm_gui.close`"""
    t = tqdm_gui(total=100)
    t.close()
    t.display()
    t.close()


if __name__ == '__main__':
    from time import sleep as tsleep
    for i in tqdm(tqdm_gui(range(10)), desc='1st loop'):
        for j in tqdm(tqdm_gui(tqdm_gui(range(100)), desc='2nd loop'),
                      desc='2nd loop', leave=False):
            for k in tqdm(tqdm_gui(range(100)), desc='3nd loop', leave=False):
                tsleep(0.01)
    tsleep(0.5)
    print("done")

# Generated at 2022-06-24 10:15:33.506832
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui(10)
    t.close()



# Generated at 2022-06-24 10:15:41.292271
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    for _ in tgrange(1, 11):
        sleep(0.1)
    sleep(0.5)
    for _ in tgrange(0, 10):
        sleep(0.15)
    sleep(0.5)
    for _ in tgrange(1, 100, 10):
        sleep(0.01)
    sleep(0.5)
    for _ in tgrange(1, 1000, 100):
        sleep(0.001)

# Generated at 2022-06-24 10:15:51.683360
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    """
    Unit test of method display of class tqdm_gui
    """
    import random
    import sys
    import time

    # This is an integration test

    def _setup():
        sys.argv = sys.argv[:1]
        import matplotlib
        matplotlib.use("Agg")

    def _teardown():
        sys.argv = sys.argv[1:]

    _setup()

    for _ in tqdm_gui(range(100)):
        time.sleep(0.01)

    for _ in tqdm_gui(range(100), leave=False):
        time.sleep(0.01)

    for _ in tqdm_gui(range(100), leave=True):
        time.sleep(0.01)


# Generated at 2022-06-24 10:15:53.789191
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm(total=1)
    t.close()

# Generated at 2022-06-24 10:15:56.362791
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch("tqdm.gui.tqdm_gui.display") as disp:
        with tqdm_gui(total=10) as t:
            t.clear()
        disp.assert_not_called()

# Generated at 2022-06-24 10:16:03.395404
# Unit test for function tgrange
def test_tgrange():
    """
    Test for tqdm.gui.tgrange.
    """
    from sys import version_info as v
    from time import sleep

    for i in tgrange(15, 25, 5):
        sleep(0.01)

    for i in tgrange(5):
        sleep(0.01)

    if v[0] == 3:
        assert not i.total, "Python 3 range() should be total=None"
    else:
        assert i.total == 5, "Python 2 xrange() should be total=5"

# Generated at 2022-06-24 10:16:07.515622
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=10) as pbar:
        pass
    assert pbar.disable  # sanity check
    assert pbar.n == 10  # sanity check
    pbar.clear()
    assert pbar.disable  # nothing should happen (and not raise Exception)



# Generated at 2022-06-24 10:16:17.751029
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys
    import subprocess
    from time import sleep
    from math import sqrt
    if sys.version_info[:2] == (2, 6):
        from unittest2 import TestCase
    else:
        from unittest import TestCase
    try:
        subprocess.check_call("python -c 'import matplotlib'", shell=True,
                              stdout=open('/dev/null'))
    except:
        raise unittest.SkipTest("matplotlib not found")

    class TgrangeTest(TestCase):

        def test_tgrange(self):
            with tgrange(100) as t:
                for i in t:
                    sleep(0.01)

# Generated at 2022-06-24 10:16:19.015431
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # initialization
    from time import sleep
    for _ in tqdm(range(3)):
        sleep(0.01)
    # cleaning
    tqdm.clear()

# Generated at 2022-06-24 10:16:28.949583
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import platform

    # noinspection PyTypeChecker
    for i in tqdm_gui(iter(None, None), leave=True, total=None):
        pass

    # mpl.use('Qt4Agg') # causes import error on Travis-CI
    # Trigger automatic selection of TkAgg or WxAgg or QtAgg?
    if not platform.startswith('win'):
        # noinspection PyUnresolvedReferences
        import matplotlib as mpl
        # noinspection PyUnresolvedReferences
        import matplotlib.pyplot as plt
        mpl.use('TkAgg')
        # noinspection PyUnresolvedReferences,PyUnusedLocal

# Generated at 2022-06-24 10:16:35.822159
# Unit test for function tgrange
def test_tgrange():
    # Test range and trange - should be equal at the end
    total = 10
    with tqdm(total=total) as pbar:
        for i in tgrange(10):
            assert i == i  # to make sure loop runs
            pbar.update()

    with tqdm(total=total, leave=True) as pbar:
        pbar.display()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:16:47.181001
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        import matplotlib as mpl
        mpl.use('agg')  # noqa
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "Please install matplotlib to use the tqdm_gui function")

    time.sleep(0.1)

    with tqdm_gui(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    plt.close('all')


if __name__ == "__main__":
    from .main import _tqdm_gui
    _tqdm_gui.test_tqdm_gui = test_tqdm_gui
    _tqdm_gui()

# Generated at 2022-06-24 10:16:56.696753
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close(): # pragma: no cover
    import time as time_orig
    from .std import TqdmDeprecationWarning, TqdmExperimentalWarning, time

    with warnings.catch_warnings(record=True) as warn_list:
        warnings.filterwarnings("always")
        t = tqdm_gui(10.0)
        time_orig.sleep(0.1)
        t.close()
        assert t._instances == []
        assert len(warn_list) == 0
        assert tqdm.default_gui == True
        t = tqdm_gui(10.0, gui=False)
        time_orig.sleep(0.1)
        t.close()
        assert t._instances == []
        assert len(warn_list) == 0
        t = tqdm_gui(10.0)


# Generated at 2022-06-24 10:17:01.982039
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    n = 1000
    x = np.arange(n)
    s = 10000.
    def dummy(x):
        for i in range(len(x)):
            x[i] = np.sqrt(x[i])
            yield
    for i in tqdm(dummy(x), total=n):
        pass

# Generated at 2022-06-24 10:17:13.083926
# Unit test for function tgrange
def test_tgrange():
    try:
        import numpy as np
        rand = np.random.rand
        randint = np.random.randint
    except ImportError:
        import random
        rand = random.random
        randint = random.randint

    # test on unknown range
    rng = tqdm(tgrange(0))
    _rng = rng.__iter__()
    assert rng.total is None
    rng.n = -10
    try:
        assert next(_rng) == 0
        assert next(_rng) == 1
        assert next(_rng) == 2
    except StopIteration:
        pass

    for _ in range(50):
        # test on known range
        pos_int = randint(0, 100)

# Generated at 2022-06-24 10:17:21.979802
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """
    Unit test for function tgrange.
    """
    import time
    import sys
    import subprocess
    sleep_time = 0.15 / 4.0
    py3 = sys.version_info[0] >= 3
    cols, _ = subprocess.check_output(["tput", "cols"]).strip(), None
    try:  # python2#pip install future
        from future.builtins import xrange, range
        for _ in tgrange(100):
            time.sleep(sleep_time)
    finally:
        sys.argv[1:] = ['-q']
        subprocess.Popen(['reset']).wait()

if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:17:27.711241
# Unit test for function tgrange
def test_tgrange():
    from .gui import tgrange
    from .utils import format_interval
    from time import sleep

    with tgrange(10) as t:
        for i in t:
            sleep(0.05)
            # should print 50% after 5 seconds
            assert format_interval(t.elapsed * 0.5) in t.format_dict['bar']


# Generated at 2022-06-24 10:17:29.974207
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_values = list(range(100))
    for i in tqdm(test_values):
        assert i == test_values[i]

# Generated at 2022-06-24 10:17:40.697144
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test display() method of tqdm_gui"""
    import time
    import matplotlib.pyplot as plt

    plt.ioff()
    i = tqdm_gui(total=None, mininterval=0.5, miniters=1, smoothing=1)
    for ii in range(100):
        i.update(1)
        i.display()
        time.sleep(0.01)

    for ii in range(100):
        i.update(1)
        i.display()
        time.sleep(0.01)

    i = tqdm_gui(i.total, mininterval=0.5, miniters=1, smoothing=1)
    for ii in range(100):
        i.update(1)
        i.display()

# Generated at 2022-06-24 10:17:49.477774
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui method close()"""
    from .gui import tqdm
    import matplotlib as mpl
    import sys

    try:
        for _ in tqdm(range(1), desc="Test", ascii=True, disable=False):
            pass

        assert mpl.rcParams['toolbar'] == 'None'
    finally:
        mpl.rcParams['toolbar'] = 'toolbar2'  # Restore toolbar

    if 'win' in sys.platform:
        warn("Matplotlib GUI progressbars can not be tested on Windows.")
    else:
        # minimal test
        tqdm._instances.clear()
        for i in tqdm(range(1), desc="Test", ascii=True, disable=False):
            pass
        assert tqdm._instances 

# Generated at 2022-06-24 10:17:51.044153
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm(range(1), disable=True, gui=True):
        pass

# Generated at 2022-06-24 10:18:02.538581
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test tqdm_gui GUI"""

# Generated at 2022-06-24 10:18:05.695124
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from tqdm.gui import trange
    for i in trange(10):
        pass


if __name__ == '__main__':  # pragma: no cover
    # unit test
    test_tgrange()

# Generated at 2022-06-24 10:18:09.133544
# Unit test for function tgrange
def test_tgrange():
    import time
    for i in trange(5, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            time.sleep(0.01)

if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:18:14.236883
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test ability to clear bars"""
    r = tqdm(total=2)
    r.set_description("toto")
    r.clear()
    u = tqdm(total=2, leave=False)
    u.set_description("toto")
    u.clear()
    u.close()

# Generated at 2022-06-24 10:18:21.894179
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Create the tqdm_gui instance
    t = tqdm_gui(total=100)
    t.disable = False
    # Call the close method on the tqdm_gui instance
    t.close()
    assert t.disable
    # Restore toolbar parameter
    mpl.rcParams['toolbar'] = t.toolbar
    # Restore interactive state of matplotlib
    if not t.wasion:
        plt.ioff()

# Generated at 2022-06-24 10:18:26.557777
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from os import linesep
    import re

    for i in tgrange(4):
        # Check first line
        if i == 0:
            assert re.match(r" \d+%|\|#+\| +$", linesep)

if __name__ == "__main__":  # pragma: no cover
    test_tgrange()

# Generated at 2022-06-24 10:18:30.534816
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    >>> tqdm_gui(["a", "b", "c"], disable=True)
    <tqdm_gui disabled>

    >>> t = tqdm_gui(["a", "b", "c"], disable=True)
    >>> t.clear()

    """
    pass

# Generated at 2022-06-24 10:18:34.159532
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _range
    import time
    for n in tqdm_gui(tgrange(100)):
        time.sleep(0.1)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:18:38.288341
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Test fix FormatStrFormatter issue #1360
    with tqdm(total=1) as pbar:
        pbar.set_description('{first}{second}')
        pbar.set_postfix_str('{third}')
        pbar.set_postfix(fourth=4)

# Generated at 2022-06-24 10:18:44.402010
# Unit test for function tgrange
def test_tgrange():
    from .gui import trange
    from .utils import _term_move_up

    for i in trange(5, leave=False):
        with trange(5) as t:
            for j in t:
                _term_move_up()
                t.set_description("i=%i" % i)
                t.set_postfix(j=(j + 1) / 5.0, refresh=False)
                t.update()

# Generated at 2022-06-24 10:18:50.669205
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Tests tqdm_gui constructor"""
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        warn("matplotlib not found. Please install it.")
        return
    import multiprocessing as mp
    try:
        mp.set_start_method('spawn')
    except AttributeError:
        pass
    mp.Dateable.debug = True
    mp.Pool.debug = True
    from multiprocessing.pool import ThreadPool

    def _test_counter(maxit):
        """Simple `count`-like iterator"""
        for i in range(maxit + 1):
            yield i

    # Default (no total)
    t = tqdm_gui(_test_counter(100))

# Generated at 2022-06-24 10:18:59.391238
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import TqdmKeyError
    from .std import tqdm as std_tqdm
    from .std import tgrange as std_tgrange

    # Tests
    try:
        tqdm_gui  # noqa: F841
        tgrange  # noqa: F841
    except (NameError, TqdmKeyError):
        return

# Generated at 2022-06-24 10:19:02.315277
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(100)):
        sleep(0.01)


if __name__ == '__main__':
    test_tqdm_gui_clear()

# Generated at 2022-06-24 10:19:06.882304
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import matplotlib.pyplot as plt
    import time

    t = tqdm(tgrange(int(1e6)))
    for i in t:
        pass
    time.sleep(1)
    try:
        plt.close()
    except Exception:
        pass



# Generated at 2022-06-24 10:19:10.081625
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    f = tqdm_gui(total=100)
    f.close()
    assert f.disable
    assert f.mpl.rcParams['toolbar'] == f.toolbar
    assert plt.isinteractive() == f.wasion
    # Test leave=False
    f = tqdm_gui(total=100, leave=False)
    assert not f.fig.axes
    f.close()
    assert f.fig.axes
    f.fig.close()

# Generated at 2022-06-24 10:19:14.653384
# Unit test for function tgrange
def test_tgrange():
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        import nose
        raise nose.SkipTest
    try:
        a = tgrange(1000)
        b = tgrange(1000)
        for i in b:
            a.update()
        a.close()
        b.close()
    finally:
        plt.close()


# Unit tests for function trange

# Generated at 2022-06-24 10:19:22.260767
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm(range(20)):
        sleep(.1)
    for i in trange(0, 20, 2):
        sleep(.1)
    for i in tqdm(range(20), desc='Test', leave=True):
        sleep(.1)
    for i in tqdm(range(20), desc='Test', leave=False):
        sleep(.1)

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:19:28.907592
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm as tqdm_gui
    from tqdm import tqdm

    for t in [tqdm, tqdm_gui]:
        with t(total=10) as pbar:
            for i in range(12):
                pbar.update()
            pbar.clear()
            for i in range(4):
                pbar.update()
            pbar.clear()
            for i in range(4):
                pbar.update()

# Generated at 2022-06-24 10:19:33.207090
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """
    Unit tests for method clear of class tqdm_gui
    """
    with tqdm(total=10, desc="testing clear") as t:
        assert t.display() is None
        t.clear()

# Generated at 2022-06-24 10:19:38.263638
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=1) as t:
        t.update()
        t.close()
    with tqdm(total=1) as t:
        t.update()
        t.close(None)
    with tqdm(total=1) as t:
        t.update()
        t.close(True)
    with tqdm(total=1) as t:
        t.update()
        t.close(False)
    with tqdm(total=1) as t:
        t.update()
        t.close(True, None)
    with tqdm(total=1) as t:
        t.update()
        t.close(True, True)
    with tqdm(total=1) as t:
        t.update()
        t.close(True, False)

# Generated at 2022-06-24 10:19:44.542319
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Run `python -m tqdm.gui` for full GUI test."""
    # Smoke test
    assert trange(1, 2)
    assert trange(1, 2, 3)


# compatibility with `python-tqdm` package (Python2)
if __name__ == '__main__':  # pragma: no cover
    from sys import executable as sys_executable
    from os import execlp as os_execlp
    os_execlp(sys_executable, sys_executable, "-m", "tqdm.gui")

# Generated at 2022-06-24 10:19:47.607248
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close of class tqdm_gui
    """
    import matplotlib.pyplot as plt
    t = tqdm_gui(total=1)
    t.close()
    assert len(plt.get_fignums()) == 0

# Generated at 2022-06-24 10:19:55.082984
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import _term_move_up
    assert _term_move_up('bar') == "\x1b[F\x1b[K"
    assert _term_move_up(u'bar') == "\x1b[F\x1b[K"
    assert _term_move_up(u'\u2588') == "\x1b[F\x1b[K"
    assert isinstance(_term_move_up(u'\u2588'), str)

    from .gui import tqdm_gui
    import sys
    import time

    def test_print(s, file=sys.stderr):
        time.sleep(0.01)
        print(s, file=file)

    pbar1 = tqdm_gui(total=10)
    pbar1.display()
   

# Generated at 2022-06-24 10:19:59.015850
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    sys.stderr = sys.stdout
    with tqdm_gui(total=10) as pbar:
        for i in _range(10):
            pbar.display()
            pbar.update(1)

# Generated at 2022-06-24 10:20:08.194192
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initialization of tqdm_gui
    import matplotlib.pyplot as plt
    progress = tqdm_gui(range(10))
    # To enter in the close method of the tqdm_gui class
    progress.disable = False
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    # Remember if external environment uses toolbars
    toolbar = plt.rcParams['toolbar']
    # Assert in these value if we not enter in the close method
    assert progress.wasion == wasion
    assert progress.mpl.rcParams['toolbar'] == toolbar
    progress.close()
    # Assert in these value if we enter in the close method
    assert progress.wasion == wasion
    assert progress.mpl.rcParams['toolbar'] == toolbar

# Generated at 2022-06-24 10:20:11.596353
# Unit test for function tgrange
def test_tgrange():
    from itertools import count
    from time import sleep
    for i in trange(10):
        for _ in trange(5):
            for _ in tqdm(count(), leave=False):
                sleep(.01)
    return True



# Generated at 2022-06-24 10:20:15.596533
# Unit test for function tgrange
def test_tgrange():
    for i in trange(4, 11, 2):  # tests: trange, unit="it"
        pass
    for i in trange(4, 11, 2, unit='units'):  # tests: trange, unit with s
        pass
    for i in tgrange(4, 15, 3):  # tests: tgrange
        pass

# Generated at 2022-06-24 10:20:22.856036
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import sys
    try:
        import unittest.mock as mock
    except Exception:
        import mock

    assert tqdm_gui.clear()  # noqa: B110
    t = tqdm_gui(total=2)
    t.close()  # noqa: B305

    with mock.patch.object(sys, "stderr", StringIO()):
        with tqdm_gui(total=2) as t:
            t.clear()  # noqa: B305
        assert " \r" in sys.stderr.getvalue()

# Generated at 2022-06-24 10:20:30.806018
# Unit test for function tgrange
def test_tgrange():
    stop = 100
    try:
        import numpy as np
    except ImportError:
        l = range(stop)
    else:
        l = np.arange(stop)
    # test with a list
    for n in tgrange(stop):
        assert n in l
        l.remove(n)
    # test with an iterable
    for n in tgrange(iterable=l):
        assert n in l
        l.remove(n)
    # print(l)
    assert not l
    # test with a generator
    gen = (i for i in range(stop))
    for n in tgrange(iterable=gen):
        assert n in l
        l.remove(n)
    # print(l)
    assert not l
    # test with a None iterable

# Generated at 2022-06-24 10:20:40.627572
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmTypeError
    import time
    t = tqdm_gui(10)
    # add some data
    t.n = 5
    assert t.dynamic_messages == {}
    try:
        t.clear()
    except TqdmTypeError:
        pass
    else:
        raise AssertionError()
    t.close()
    # create new tqdm_gui
    t = tqdm_gui(10, dynamic_messages={'a': 'xyz'})
    # add some data
    t.n = 5
    assert t.dynamic_messages == {'a': 'xyz'}
    t.clear()
    assert t.dynamic_messages == {}
    t.close()
    # create new tqdm_gui
    t = tq

# Generated at 2022-06-24 10:20:44.541289
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import time
    for i in tqdm(tgrange(10)):
        time.sleep(.01)


if __name__ == "__main__":  # pragma: no cover
    try:
        test_tgrange()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:20:47.437765
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    l = 50
    with tqdm_gui(_range(l), total=l) as pbar:
        pbar.clear()  # no effect
        for i in _range(l):
            pbar.update()

# Generated at 2022-06-24 10:20:49.780128
# Unit test for function tgrange
def test_tgrange():
    with tgrange(10, desc="Example") as t:
        for i in t:
            assert i == t.n-1

# Generated at 2022-06-24 10:20:56.886511
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from unittest import main, TestCase

    with tqdm(total=2) as pbar:
        for i in tgrange(10):
            pbar.update()

    class TgrangeCase(TestCase):
        def test_total(self):
            for total in [200, 1000]:
                with tqdm(total=total) as pbar:
                    for i in tgrange(total * 2):
                        pbar.update()

    main()


if __name__ == '__main__':  # pragma: no cover
    test_tgrange()

# Generated at 2022-06-24 10:21:07.078881
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    import matplotlib
    import matplotlib.pyplot as plt

    t = tqdm(total=1)
    t.clear()
    t.close()  # close to not break other tests
    # Test the plt.show() still works
    t = tqdm(total=1)
    t.close()  # close to not break other tests
    # Test the plt.show() still works
    t = tqdm(total=1)
    t.close()  # close to not break other tests
    assert matplotlib.is_interactive()
    # Test the plt.show() still works
    plt.figure()
    # Test the plt.show() still works
    matplotlib.interactive(False)

# Generated at 2022-06-24 10:21:17.332686
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Just tests that `tgrange` is correct (re-entrant, email-compose mode, etc.)"""
    assert list(tgrange(5, 0, -1)) == list(reversed(list(tgrange(5))))
    assert list(tgrange(5, 0, -1)) == list(reversed(list(tgrange(0, 5))))
    assert list(tgrange(5, 0, -1)) == list(reversed(list(tgrange(0, 5, 1))))
    assert list(tgrange(5, step=-1)) == list(reversed(list(tgrange(5))))
    assert list(tgrange(5, step=-1)) == list(reversed(list(tgrange(0, 5))))
    assert list

# Generated at 2022-06-24 10:21:24.014664
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.pyplot import close
    from time import sleep
    from numpy import inf
    close('all')
    tqdm_gui(total=1e9, leave=False).display()
    sleep(1)
    tqdm_gui(total=None, leave=False).display()
    sleep(1)
    tqdm_gui(total=inf, leave=False).display()
    sleep(1)

# Generated at 2022-06-24 10:21:34.591325
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from contextlib import closing
    # check case tqdm.disable = True
    with closing(tqdm([])) as pbar:
        pbar.disable = True
        assert (not pbar.instances.remove.called)
    # mock out matplotlib functions and attributes
    with patch('tqdm.gui.tqdm_gui.plt') as mock_plt, \
            patch('tqdm.gui.tqdm_gui.mpl') as mock_mpl:
        with closing(tqdm([], disable=True)) as pbar:
            mock_mpl.use.assert_not_called()
            mock_plt.isinteractive.assert_not_called()

# Generated at 2022-06-24 10:21:40.547770
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from matplotlib import pyplot as plt
    from math import sin, cos, pi
    plt.close()
    for i in trange(22, desc="testing tqdm_gui.display"):
        plt.plot(i + sin(2 * pi * i) + cos(2 * pi * i))
        plt.pause(1e-3)
    plt.close()

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:21:51.277637
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import sys
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    count = 10
    bar = tqdm_gui(total=count)
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    for i in range(count):
        bar.update()
    bar.close()
    # Check if toolbars is unchanged
    assert mpl.rcParams['toolbar'] == toolbar
    # Check if interactive mode is unchanged
    assert plt.isinteractive() == wasion
    # Check if stdout is clear
    assert sys.stdout.getvalue() == ""
    # Check if warning has been issued
    assert len(_range) == 1

# Generated at 2022-06-24 10:22:00.622119
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep, time
    from random import random

    for i in tqdm_gui(range(10)):
        sleep(0.1 * random())

    for i in trange(10, desc="tgrange"):
        sleep(0.1 * random())

    with tqdm_gui(total=100, dynamic_ncols=True) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)
            if not i % 10:
                pbar.set_description("{:.2f}".format(time()))

# Generated at 2022-06-24 10:22:03.706766
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(1e-4)


# Generated at 2022-06-24 10:22:08.102976
# Unit test for function tgrange
def test_tgrange():
    from time import sleep

    for i in tgrange(7, desc='1st loop'):
        sleep(0.1)
        for j in tgrange(5, desc='2nd loop', leave=True):
            sleep(0.1)
            if j == 1:
                break
    print()

# Generated at 2022-06-24 10:22:16.584562
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm import trange
    for _ in trange(4, desc='test_tqdm_gui_clear'):
        pass


if __name__ == '__main__':
    from time import sleep
    from random import random, randint

    # testing tqdm_gui bar
    for i in tqdm_gui(range(5),
                      desc='1st loop', mininterval=1):
        for j in tqdm_gui(range(10000), desc='2nd loop', leave=False):
            k = j * i
            sleep(0.0001 * k)
        sleep(0.01)

    # testing tqdm_gui bar

# Generated at 2022-06-24 10:22:19.933579
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep

    # Check unit test runs without errors
    for j in tgrange(3):
        for i in tgrange(100):
            sleep(0.01)
        sleep(0.2)


if __name__ == "__main__":
    test_tgrange()  # pragma: no cover

# Generated at 2022-06-24 10:22:22.048353
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Create a dummy tqdm_gui object
    tqdm_object = tqdm_gui()
    # Try to call method clear()
    tqdm_object.clear()

# Generated at 2022-06-24 10:22:32.929149
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        import matplotlib as mpl
    except ImportError as e:
        import sys
        import os
        # Display and raise original exception to know there's an issue
        sys.stderr.write(os.linesep * 2)
        raise
